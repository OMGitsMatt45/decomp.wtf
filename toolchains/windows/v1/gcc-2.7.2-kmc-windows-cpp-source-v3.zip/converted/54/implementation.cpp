// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/config/mips/mips.c
/* Subroutines for insn-output.c for MIPS
   Copyright (C) 1989, 90, 91, 93, 94, 1995 Free Software Foundation, Inc.
   Contributed by A. Lichnewsky, lich@inria.inria.fr.
   Changes by Michael Meissner, meissner@osf.org.
   64 bit r4000 support by Ian Lance Taylor, ian@cygnus.com, and
   Brendan Eich, brendan@microunity.com.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/file.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int target_isnan(...) asm("_target_isnan");
extern int target_negative(...) asm("_target_negative");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int push_topmost_sequence(...) asm("_push_topmost_sequence");
extern int pop_topmost_sequence(...) asm("_pop_topmost_sequence");
extern int output_quoted_string(...) asm("_output_quoted_string");
extern int aggregate_value_p(...) asm("_aggregate_value_p");
extern int const_section(...) asm("_const_section");
extern int true_regnum(...) asm("_true_regnum");
struct n64_tag_args_size;
struct n64_tag_cmp_info;
struct n64_tag_extern_list;
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;





enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum___stab_debug_code{
N_GSYM=0x20,



N_FNAME=0x22,




N_FUN=0x24,



N_STSYM=0x26,


N_LCSYM=0x28,



N_MAIN=0x2a,



N_PC=0x30,


N_NSYMS=0x32,


N_NOMAP=0x34,



N_OBJ=0x38,




N_OPT=0x3c,


N_RSYM=0x40,


N_M2C=0x42,



N_SLINE=0x44,


N_DSLINE=0x46,


N_BSLINE=0x48,




N_BROWS=0x48,





N_DEFD=0x4a,




N_EHDECL=0x50,

N_MOD2=0x50,






N_CATCH=0x54,


N_SSYM=0x60,



N_SO=0x64,



N_LSYM=0x80,




N_BINCL=0x82,



N_SOL=0x84,



N_PSYM=0xa0,





N_EINCL=0xa2,


N_ENTRY=0xa4,





N_LBRAC=0xc0,





N_EXCL=0xc2,


N_SCOPE=0xc4,



N_RBRAC=0xe0,


N_BCOMM=0xe2,



N_ECOMM=0xe4,



N_ECOML=0xe8,




N_NBTEXT=0xF0,
N_NBDATA=0xF2,
N_NBBSS=0xF4,
N_NBSTS=0xF6,
N_NBLCS=0xF8,



N_LENG=0xfe,
LAST_UNUSED_STAB_CODE
};
typedef __underlying_type(enum n64_cpp_enum___stab_debug_code) n64_enum___stab_debug_code;

extern void abort(void) asm("_abort");
extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");

extern rtx adj_offsettable_operand(...) asm("_adj_offsettable_operand");
extern rtx copy_to_reg(...) asm("_copy_to_reg");
extern void error(...) asm("_error");
extern void fatal(...) asm("_fatal");
extern tree lookup_name(...) asm("_lookup_name");
extern void pfatal_with_name(...) asm("_pfatal_with_name");
extern void warning(...) asm("_warning");

extern FILE *asm_out_file;





enum n64_cpp_enum_internal_test{
    ITEST_EQ,
    ITEST_NE,
    ITEST_GT,
    ITEST_GE,
    ITEST_LT,
    ITEST_LE,
    ITEST_GTU,
    ITEST_GEU,
    ITEST_LTU,
    ITEST_LEU,
    ITEST_MAX
  };
typedef __underlying_type(enum n64_cpp_enum_internal_test) n64_enum_internal_test;








int mips_section_threshold = -1;


int num_source_filenames = 0;



int sdb_label_count = 0;


int sym_lineno = 0;



int inside_function = 0;




FILE *asm_out_data_file;
FILE *asm_out_text_file;





struct n64_tag_extern_list {
  struct n64_tag_extern_list *next;
  char *name;
  int size;
} *extern_head = 0;


char *current_function_file = "";



int file_in_function_warning = 0;



int ignore_line_number = 0;


int set_noreorder;
int set_noat;
int set_nomacro;
int set_volatile;


int mips_branch_likely;


int dslots_load_total;
int dslots_load_filled;
int dslots_jump_total;
int dslots_jump_filled;


int dslots_number_nops;


int num_refs[3];


rtx mips_load_reg, mips_load_reg2, mips_load_reg3, mips_load_reg4;



rtx branch_cmp[2];


n64_enum_cmp_type branch_type;


static int prev_half_pic_ptrs = 0;
static int prev_half_pic_refs = 0;


n64_enum_processor_type mips_cpu;


int mips_isa;


char *mips_cpu_string;
char *mips_isa_string;
char *mips_abi_string;


n64_enum_mips_abicalls_type mips_abicalls;




double dfhigh, dflow, sfhigh, sflow;



char mips_hard_regno_mode_ok[(int)MAX_MACHINE_MODE][68];


struct n64_tag_mips_frame_info current_frame_info;


struct n64_tag_mips_frame_info zero_frame_info;



static char *temp_filename;




rtx embedded_pic_fnaddr_rtx;


char mips_print_operand_punct[256];


int mips_dbx_regno[68];



static char volatile_buffer[60];




char mips_reg_names[][8] =
{
 "$0", "$1", "$2", "$3", "$4", "$5", "$6", "$7",
 "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15",
 "$16", "$17", "$18", "$19", "$20", "$21", "$22", "$23",
 "$24", "$25", "$26", "$27", "$28", "$sp", "$fp", "$31",
 "$f0", "$f1", "$f2", "$f3", "$f4", "$f5", "$f6", "$f7",
 "$f8", "$f9", "$f10", "$f11", "$f12", "$f13", "$f14", "$f15",
 "$f16", "$f17", "$f18", "$f19", "$f20", "$f21", "$f22", "$f23",
 "$f24", "$f25", "$f26", "$f27", "$f28", "$f29", "$f30", "$f31",
 "hi", "lo", "accum","$fcr31"
};




char mips_sw_reg_names[][8] =
{
  "$zero","$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3",
  "$t0", "$t1", "$t2", "$t3", "$t4", "$t5", "$t6", "$t7",
  "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7",
  "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra",
  "$f0", "$f1", "$f2", "$f3", "$f4", "$f5", "$f6", "$f7",
  "$f8", "$f9", "$f10", "$f11", "$f12", "$f13", "$f14", "$f15",
  "$f16", "$f17", "$f18", "$f19", "$f20", "$f21", "$f22", "$f23",
  "$f24", "$f25", "$f26", "$f27", "$f28", "$f29", "$f30", "$f31",
  "hi", "lo", "accum","$fcr31"
};


n64_enum_reg_class mips_regno_to_class[] =
{
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  GR_REGS, GR_REGS, GR_REGS, GR_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  FP_REGS, FP_REGS, FP_REGS, FP_REGS,
  HI_REG, LO_REG, HILO_REG, ST_REGS
};


n64_enum_reg_class mips_char_to_class[256] =
{
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
  NO_REGS, NO_REGS, NO_REGS, NO_REGS,
};





int
uns_arith_operand(rtx op, n64_enum_machine_mode mode) asm("_uns_arith_operand");
int
uns_arith_operand(rtx op, n64_enum_machine_mode mode)
{
  if (((op)->code) == CONST_INT && ((unsigned int) (((op)->fld[0].rtwint)) < 0x10000))
    return 1;

  return register_operand (op, mode);
}




int
arith_operand(rtx op, n64_enum_machine_mode mode) asm("_arith_operand");
int
arith_operand(rtx op, n64_enum_machine_mode mode)
{
  if (((op)->code) == CONST_INT && ((unsigned int) (((op)->fld[0].rtwint) + 0x8000) < 0x10000))
    return 1;

  return register_operand (op, mode);
}




int
arith32_operand(rtx op, n64_enum_machine_mode mode) asm("_arith32_operand");
int
arith32_operand(rtx op, n64_enum_machine_mode mode)
{
  if (((op)->code) == CONST_INT)
    return 1;

  return register_operand (op, mode);
}



int
small_int(rtx op, n64_enum_machine_mode mode) asm("_small_int");
int
small_int(rtx op, n64_enum_machine_mode mode)
{
  return (((op)->code) == CONST_INT && ((unsigned int) (((op)->fld[0].rtwint) + 0x8000) < 0x10000));
}




int
large_int(rtx op, n64_enum_machine_mode mode) asm("_large_int");
int
large_int(rtx op, n64_enum_machine_mode mode)
{
  int value;

  if (((op)->code) != CONST_INT)
    return 0;

  value = ((op)->fld[0].rtwint);
  if ((value & ~0x0000ffff) == 0)
    return 0;

  if (((unsigned long)(value + 32768)) <= 32767)
    return 0;

  if ((value & 0x0000ffff) == 0)
    return 0;

  return 1;
}



int
reg_or_0_operand(rtx op, n64_enum_machine_mode mode) asm("_reg_or_0_operand");
int
reg_or_0_operand(rtx op, n64_enum_machine_mode mode)
{
  switch (((op)->code))
    {
    default:
      break;

    case CONST_INT:
      return (((op)->fld[0].rtwint) == 0);

    case CONST_DOUBLE:
      if (op != (const_tiny_rtx[0][(int) (mode)]))
 return 0;

      return 1;

    case REG:
    case SUBREG:
      return register_operand (op, mode);
    }

  return 0;
}



int
mips_const_double_ok(rtx op, n64_enum_machine_mode mode) asm("_mips_const_double_ok");
int
mips_const_double_ok(rtx op, n64_enum_machine_mode mode)
{
  double d;

  if (((op)->code) != CONST_DOUBLE)
    return 0;

  if (mode == VOIDmode)
    return 1;

  if (mode != SFmode && mode != DFmode)
    return 0;

  if (op == (const_tiny_rtx[0][(int) (mode)]))
    return 1;


  if (0)
    return 0;

  do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);

  if ((target_isnan (d)))
    return 0;

  if ((target_negative (d)))
    d = ereal_negate (d);

  if (mode == DFmode)
    {
      if ((ereal_cmp ((d), (dfhigh)) == -1)
   && (ereal_cmp ((dflow), (d)) == -1))
 return 1;
    }
  else
    {
      if ((ereal_cmp ((d), (sfhigh)) == -1)
   && (ereal_cmp ((sflow), (d)) == -1))
 return 1;
    }

  return 0;
}




int
simple_memory_operand(rtx op, n64_enum_machine_mode mode) asm("_simple_memory_operand");
int
simple_memory_operand(rtx op, n64_enum_machine_mode mode)
{
  rtx addr, plus0, plus1;


  if (((op)->code) != MEM)
    return 0;


  if ((mode_size[(int)(((op)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
    return 0;


  addr = ((op)->fld[0].rtx);
  switch (((addr)->code))
    {
    default:
      break;

    case REG:
      return 1;

    case CONST_INT:
      return ((unsigned int) (((op)->fld[0].rtwint) + 0x8000) < 0x10000);

    case PLUS:
      plus0 = ((addr)->fld[0].rtx);
      plus1 = ((addr)->fld[1].rtx);
      if (((plus0)->code) == REG
   && ((plus1)->code) == CONST_INT
   && ((unsigned int) (((plus1)->fld[0].rtwint) + 0x8000) < 0x10000))
 return 1;

      else if (((plus1)->code) == REG
        && ((plus0)->code) == CONST_INT
        && ((unsigned int) (((plus0)->fld[0].rtwint) + 0x8000) < 0x10000))
 return 1;

      else
 return 0;
    }

  return 0;
}



int
equality_op(rtx op, n64_enum_machine_mode mode) asm("_equality_op");
int
equality_op(rtx op, n64_enum_machine_mode mode)
{
  if (mode != ((op)->mode))
    return 0;

  return (((op)->code) == EQ || ((op)->code) == NE);
}



int
cmp_op(rtx op, n64_enum_machine_mode mode) asm("_cmp_op");
int
cmp_op(rtx op, n64_enum_machine_mode mode)
{
  if (mode != ((op)->mode))
    return 0;

  return ((rtx_class[(int)(((op)->code))]) == '<');
}



int
pc_or_label_operand(rtx op, n64_enum_machine_mode mode) asm("_pc_or_label_operand");
int
pc_or_label_operand(rtx op, n64_enum_machine_mode mode)
{
  if (op == pc_rtx)
    return 1;

  if (((op)->code) == LABEL_REF)
    return 1;

  return 0;
}






int
call_insn_operand(rtx op, n64_enum_machine_mode mode) asm("_call_insn_operand");
int
call_insn_operand(rtx op, n64_enum_machine_mode mode)
{
  if (((op)->code) == MEM
      && (((((((op)->fld[0].rtx))->code) == LABEL_REF || ((((op)->fld[0].rtx))->code) == SYMBOL_REF || ((((op)->fld[0].rtx))->code) == CONST_INT || ((((op)->fld[0].rtx))->code) == HIGH || (((((op)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((op)->fld[0].rtx))) && ! 0)) && (!0 || !0))
   || (((((op)->fld[0].rtx))->code) == REG
       && ((op)->fld[0].rtx) != arg_pointer_rtx
       && !(((((op)->fld[0].rtx))->fld[0].rtint) >= 68
     && ((((op)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3)))))
    return 1;
  return 0;
}
char *
mips_fill_delay_slot(char *ret, n64_enum_delay_type type, rtx *operands, rtx cur_insn) asm("_mips_fill_delay_slot");
char *
mips_fill_delay_slot(char *ret, n64_enum_delay_type type, rtx *operands, rtx cur_insn)
{
  register rtx set_reg;
  register n64_enum_machine_mode mode;
  register rtx next_insn = (cur_insn) ? ((cur_insn)->fld[2].rtx) : (rtx)0;
  register int num_nops;

  if (type == DELAY_LOAD || type == DELAY_FCMP)
    num_nops = 1;

  else if (type == DELAY_HILO)
    num_nops = 2;

  else
    num_nops = 0;


  next_insn = ((cur_insn)->fld[2].rtx);
  while (next_insn != (rtx)0 && ((next_insn)->code) == NOTE)
    next_insn = ((next_insn)->fld[2].rtx);

  dslots_load_total += num_nops;
  if ((target_flags & 0x01000000)
      || !optimize
      || type == DELAY_NONE
      || operands == (rtx *)0
      || cur_insn == (rtx)0
      || next_insn == (rtx)0
      || ((next_insn)->code) == CODE_LABEL
      || (set_reg = operands[0]) == (rtx)0)
    {
      dslots_number_nops = 0;
      mips_load_reg = (rtx)0;
      mips_load_reg2 = (rtx)0;
      mips_load_reg3 = (rtx)0;
      mips_load_reg4 = (rtx)0;
      return ret;
    }

  set_reg = operands[0];
  if (set_reg == (rtx)0)
    return ret;

  while (((set_reg)->code) == SUBREG)
    set_reg = ((set_reg)->fld[0].rtx);

  mode = ((set_reg)->mode);
  dslots_number_nops = num_nops;
  mips_load_reg = set_reg;
  if ((mode_size[(int)(mode)])
      > (((unsigned) ((((set_reg)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? ((target_flags & 0x00000200) ? 8 : 4) : ((target_flags & 0x00002000) ? 8 : 4)))
    mips_load_reg2 = gen_rtx (REG, SImode, ((set_reg)->fld[0].rtint) + 1);
  else
    mips_load_reg2 = 0;

  if (type == DELAY_HILO)
    {
      mips_load_reg3 = gen_rtx (REG, SImode, 64);
      mips_load_reg4 = gen_rtx (REG, SImode, 64 +1);
    }
  else
    {
      mips_load_reg3 = 0;
      mips_load_reg4 = 0;
    }

  return ret;
}






void
mips_count_memory_refs(rtx op, int num) asm("_mips_count_memory_refs");
void
mips_count_memory_refs(rtx op, int num)
{
  int additional = 0;
  int n_words = 0;
  rtx addr, plus0, plus1;
  n64_enum_rtx_code code0, code1;
  int looping;

  if ((target_flags & 0x10000000))
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "\n========== mips_count_memory_refs:\n");
      debug_rtx (op);
    }


  addr = (((op)->code) != MEM) ? op : ((op)->fld[0].rtx);


  do
    {
      looping = 0;
      switch (((addr)->code))
 {
 default:
   break;

 case REG:
 case CONST_INT:
   break;

 case PLUS:
   plus0 = ((addr)->fld[0].rtx);
   plus1 = ((addr)->fld[1].rtx);
   code0 = ((plus0)->code);
   code1 = ((plus1)->code);

   if (code0 == REG)
     {
       additional++;
       addr = plus1;
       looping = 1;
       continue;
     }

   if (code0 == CONST_INT)
     {
       addr = plus1;
       looping = 1;
       continue;
     }

   if (code1 == REG)
     {
       additional++;
       addr = plus0;
       looping = 1;
       continue;
     }

   if (code1 == CONST_INT)
     {
       addr = plus0;
       looping = 1;
       continue;
     }

   if (code0 == SYMBOL_REF || code0 == LABEL_REF || code0 == CONST)
     {
       addr = plus0;
       looping = 1;
       continue;
     }

   if (code1 == SYMBOL_REF || code1 == LABEL_REF || code1 == CONST)
     {
       addr = plus1;
       looping = 1;
       continue;
     }

   break;

 case LABEL_REF:
   n_words = 2;
   break;

 case CONST:
   addr = ((addr)->fld[0].rtx);
   looping = 1;
   continue;

 case SYMBOL_REF:
   n_words = ((addr)->volatil) ? 1 : 2;
   break;
 }
    }
  while (looping);

  if (n_words == 0)
    return;

  n_words += additional;
  if (n_words > 3)
    n_words = 3;

  num_refs[n_words-1] += num;
}





rtx
embedded_pic_offset(rtx x) asm("_embedded_pic_offset");
rtx
embedded_pic_offset(rtx x)
{
  if (embedded_pic_fnaddr_rtx == 
                                ((void *)0)
                                    )
    {
      rtx seq;

      embedded_pic_fnaddr_rtx = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
      start_sequence ();
      emit_insn (gen_get_fnaddr (embedded_pic_fnaddr_rtx,
     ((((current_function_decl)->decl.rtl))->fld[0].rtx)));
      seq = gen_sequence ();
      end_sequence ();
      push_topmost_sequence ();
      emit_insn_after (seq, get_insns ());
      pop_topmost_sequence ();
    }

  return gen_rtx (CONST, ((target_flags & 0x00000002) ? DImode : SImode),
    gen_rtx (MINUS, ((target_flags & 0x00000002) ? DImode : SImode), x,
      ((((current_function_decl)->decl.rtl))->fld[0].rtx)));
}



char *
mips_move_1word(rtx *operands, rtx insn, int unsignedp) asm("_mips_move_1word");
char *
mips_move_1word(rtx *operands, rtx insn, int unsignedp)
{
  char *ret = 0;
  rtx op0 = operands[0];
  rtx op1 = operands[1];
  n64_enum_rtx_code code0 = ((op0)->code);
  n64_enum_rtx_code code1 = ((op1)->code);
  n64_enum_machine_mode mode = ((op0)->mode);
  int subreg_word0 = 0;
  int subreg_word1 = 0;
  n64_enum_delay_type delay = DELAY_NONE;

  while (code0 == SUBREG)
    {
      subreg_word0 += ((op0)->fld[1].rtint);
      op0 = ((op0)->fld[0].rtx);
      code0 = ((op0)->code);
    }

  while (code1 == SUBREG)
    {
      subreg_word1 += ((op1)->fld[1].rtint);
      op1 = ((op1)->fld[0].rtx);
      code1 = ((op1)->code);
    }

  if (code0 == REG)
    {
      int regno0 = ((op0)->fld[0].rtint) + subreg_word0;

      if (code1 == REG)
 {
   int regno1 = ((op1)->fld[0].rtint) + subreg_word1;



   if (regno0 == regno1 && set_nomacro == 0)
     ret = "";

   else if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
     {
       if (((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
  ret = "move\t%0,%1";

       else if (((unsigned) ((regno1) - 64) < (66 - 64 + 1)))
  {
    delay = DELAY_HILO;
    if (regno1 != (64 + 2))
      ret = "mf%1\t%0";
    else
      ret = "mflo\t%0";
  }

       else
  {
    delay = DELAY_LOAD;
    if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)))
      ret = "mfc1\t%0,%1";

    else if (regno1 == 67)
      ret = "cfc1\t%0,$31";
  }
     }

   else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
     {
       if (((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
  {
    delay = DELAY_LOAD;
    ret = "mtc1\t%1,%0";
  }

       if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)))
  ret = "mov.s\t%0,%1";
     }

   else if (((unsigned) ((regno0) - 64) < (66 - 64 + 1)))
     {
       if (((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
  {
    delay = DELAY_HILO;
    if (regno0 != (64 + 2))
      ret = "mt%0\t%1";
  }
     }

   else if (regno0 == 67)
     {
       if (((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
  {
    delay = DELAY_LOAD;
    ret = "ctc1\t%0,$31";
  }
     }
 }

      else if (code1 == MEM)
 {
   delay = DELAY_LOAD;

   if ((target_flags & 0x00000040))
     mips_count_memory_refs (op1, 1);

   if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
     {


       switch (((op1)->mode))
  {
  default:
    break;
  case SFmode:
    ret = "lw\t%0,%1";
    break;
  case SImode:
    ret = ((unsignedp && (target_flags & 0x00002000))
    ? "lwu\t%0,%1"
    : "lw\t%0,%1");
    break;
  case HImode:
    ret = (unsignedp) ? "lhu\t%0,%1" : "lh\t%0,%1";
    break;
  case QImode:
    ret = (unsignedp) ? "lbu\t%0,%1" : "lb\t%0,%1";
    break;
  }
     }

   else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)) && (mode == SImode || mode == SFmode))
     ret = "l.s\t%0,%1";

   if (ret != (char *)0 && ((op1)->volatil))
     {
       int i = strlen (ret);
       if (i > sizeof (volatile_buffer) - sizeof ("%{%}"))
  abort ();

       sprintf (volatile_buffer, "%%{%s%%}", ret);
       ret = volatile_buffer;
     }
 }

      else if (code1 == CONST_INT
        || (code1 == CONST_DOUBLE
     && ((op1)->mode) == VOIDmode))
 {
   if (code1 == CONST_DOUBLE)
     {



       operands[1] = op1 = gen_rtx (CONST_INT, VOIDmode, (int) (((op1)->fld[2].rtwint)));
     }

   if (((op1)->fld[0].rtwint) == 0)
     {
       if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
  ret = "move\t%0,%z1";

       else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
  {
    delay = DELAY_LOAD;
    ret = "mtc1\t%z1,%0";
  }

       else if (((unsigned) ((regno0) - 64) < (66 - 64 + 1)))
  {
    delay = DELAY_HILO;
    ret = "mt%0\t%.";
  }
     }

   else if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
     ret = (((op1)->fld[0].rtwint) < 0) ? "li\t%0,%1\t\t\t# %X1" : "li\t%0,%X1\t\t# %1";
 }

      else if (code1 == CONST_DOUBLE && mode == SFmode)
 {
   if (op1 == (const_tiny_rtx[0][(int) (SFmode)]))
     {
       if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
  ret = "move\t%0,%.";

       else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
  {
    delay = DELAY_LOAD;
    ret = "mtc1\t%.,%0";
  }
     }

   else
     {
       delay = DELAY_LOAD;
       ret = "li.s\t%0,%1";
     }
 }

      else if (code1 == LABEL_REF)
 {
   if ((target_flags & 0x00000040))
     mips_count_memory_refs (op1, 1);

   ret = "la\t%0,%a1";
 }

      else if (code1 == SYMBOL_REF || code1 == CONST)
 {
   if (0 && (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH) && 0)
     {
       rtx offset = const0_rtx;

       if (((op1)->code) == CONST)
  op1 = eliminate_constant_term (((op1)->fld[0].rtx), &offset);

       if (((op1)->code) == SYMBOL_REF)
  {
    operands[2] = op1;

    if ((target_flags & 0x00000040))
      mips_count_memory_refs (operands[2], 1);

    if (((offset)->fld[0].rtwint) == 0)
      {
        delay = DELAY_LOAD;
        ret = (unsignedp && (target_flags & 0x00002000)
        ? "lwu\t%0,%2"
        : "lw\t%0,%2");
      }
    else
      {
        dslots_load_total++;
        operands[3] = offset;
        if (unsignedp && (target_flags & 0x00002000))
   ret = (((unsigned int) (((offset)->fld[0].rtwint) + 0x8000) < 0x10000))
      ? "lwu\t%0,%2%#\n\tadd\t%0,%0,%3"
      : "lwu\t%0,%2%#\n\t%[li\t%@,%3\n\tadd\t%0,%0,%@%]";
        else
   ret = (((unsigned int) (((offset)->fld[0].rtwint) + 0x8000) < 0x10000))
      ? "lw\t%0,%2%#\n\tadd\t%0,%0,%3"
      : "lw\t%0,%2%#\n\t%[li\t%@,%3\n\tadd\t%0,%0,%@%]";
      }
  }
     }
   else
     {
       if ((target_flags & 0x00000040))
  mips_count_memory_refs (op1, 1);

       ret = "la\t%0,%a1";
     }
 }

      else if (code1 == PLUS)
 {
   rtx add_op0 = ((op1)->fld[0].rtx);
   rtx add_op1 = ((op1)->fld[1].rtx);

   if (((((op1)->fld[1].rtx))->code) == REG && ((((op1)->fld[0].rtx))->code) == CONST_INT)
     {
       add_op0 = ((op1)->fld[1].rtx);
       add_op1 = ((op1)->fld[0].rtx);
     }

   operands[2] = add_op0;
   operands[3] = add_op1;
   ret = "add%:\t%0,%2,%3";
 }
    }

  else if (code0 == MEM)
    {
      if ((target_flags & 0x00000040))
 mips_count_memory_refs (op0, 1);

      if (code1 == REG)
 {
   int regno1 = ((op1)->fld[0].rtint) + subreg_word1;

   if (((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
     {
       switch (mode)
  {
  default: break;
  case SFmode: ret = "sw\t%1,%0"; break;
  case SImode: ret = "sw\t%1,%0"; break;
  case HImode: ret = "sh\t%1,%0"; break;
  case QImode: ret = "sb\t%1,%0"; break;
  }
     }

   else if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)) && (mode == SImode || mode == SFmode))
     ret = "s.s\t%1,%0";
 }

      else if (code1 == CONST_INT && ((op1)->fld[0].rtwint) == 0)
 {
   switch (mode)
     {
     default: break;
     case SFmode: ret = "sw\t%z1,%0"; break;
     case SImode: ret = "sw\t%z1,%0"; break;
     case HImode: ret = "sh\t%z1,%0"; break;
     case QImode: ret = "sb\t%z1,%0"; break;
     }
 }

      else if (code1 == CONST_DOUBLE && op1 == (const_tiny_rtx[0][(int) (mode)]))
 {
   switch (mode)
     {
     default: break;
     case SFmode: ret = "sw\t%.,%0"; break;
     case SImode: ret = "sw\t%.,%0"; break;
     case HImode: ret = "sh\t%.,%0"; break;
     case QImode: ret = "sb\t%.,%0"; break;
     }
 }

      if (ret != (char *)0 && ((op0)->volatil))
 {
   int i = strlen (ret);
   if (i > sizeof (volatile_buffer) - sizeof ("%{%}"))
     abort ();

   sprintf (volatile_buffer, "%%{%s%%}", ret);
   ret = volatile_buffer;
 }
    }

  if (ret == (char *)0)
    {
      abort_with_insn (insn, "Bad move");
      return 0;
    }

  if (delay != DELAY_NONE)
    return mips_fill_delay_slot (ret, delay, operands, insn);

  return ret;
}




char *
mips_move_2words(rtx *operands, rtx insn) asm("_mips_move_2words");
char *
mips_move_2words(rtx *operands, rtx insn)
{
  char *ret = 0;
  rtx op0 = operands[0];
  rtx op1 = operands[1];
  n64_enum_rtx_code code0 = ((operands[0])->code);
  n64_enum_rtx_code code1 = ((operands[1])->code);
  int subreg_word0 = 0;
  int subreg_word1 = 0;
  n64_enum_delay_type delay = DELAY_NONE;

  while (code0 == SUBREG)
    {
      subreg_word0 += ((op0)->fld[1].rtint);
      op0 = ((op0)->fld[0].rtx);
      code0 = ((op0)->code);
    }

  while (code1 == SUBREG)
    {
      subreg_word1 += ((op1)->fld[1].rtint);
      op1 = ((op1)->fld[0].rtx);
      code1 = ((op1)->code);
    }

  if (code0 == REG)
    {
      int regno0 = ((op0)->fld[0].rtint) + subreg_word0;

      if (code1 == REG)
 {
   int regno1 = ((op1)->fld[0].rtint) + subreg_word1;



   if (regno0 == regno1 && set_nomacro == 0)
     ret = "";

   else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
     {
       if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)))
  ret = "mov.d\t%0,%1";

       else
  {
    delay = DELAY_LOAD;
    if ((target_flags & 0x00000200))
      {
        if (!(target_flags & 0x00002000))
   abort_with_insn (insn, "Bad move");





   ret = "dmtc1\t%1,%0";
      }
    else
      ret = "mtc1\t%L1,%0\n\tmtc1\t%M1,%D0";
  }
     }

   else if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)))
     {
       delay = DELAY_LOAD;
       if ((target_flags & 0x00000200))
  {
    if (!(target_flags & 0x00002000))
      abort_with_insn (insn, "Bad move");





      ret = "dmfc1\t%0,%1";
  }
       else
  ret = "mfc1\t%L0,%1\n\tmfc1\t%M0,%D1";
     }

   else if (((unsigned) ((regno0) - 64) < (66 - 64 + 1)) && ((unsigned) ((regno1) - 0) < (31 - 0 + 1)))
     {
       delay = DELAY_HILO;
       if ((target_flags & 0x00002000))
  {
    if (regno0 != (64 + 2))
      ret = "mt%0\t%1";
    else if (regno1 == 0)
      ret = "mtlo\t%.\n\tmthi\t%.";
  }
       else
  ret = "mthi\t%M1\n\tmtlo\t%L1";
     }

   else if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)) && ((unsigned) ((regno1) - 64) < (66 - 64 + 1)))
     {
       delay = DELAY_HILO;
       if ((target_flags & 0x00002000))
  {
    if (regno1 != (64 + 2))
      ret = "mf%1\t%0";
  }
       else
  ret = "mfhi\t%M0\n\tmflo\t%L0";
     }

   else if ((target_flags & 0x00002000))
     ret = "move\t%0,%1";

   else if (regno0 != (regno1+1))
     ret = "move\t%0,%1\n\tmove\t%D0,%D1";

   else
     ret = "move\t%D0,%D1\n\tmove\t%0,%1";
 }

      else if (code1 == CONST_DOUBLE)
 {


   if (op1 != (const_tiny_rtx[0][(int) (((op1)->mode))])
       || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && ((unsigned) ((regno0) - 32) < (63 - 32 + 1))))
     {
       if (((op1)->mode) == DFmode)
  {
    delay = DELAY_LOAD;
      ret = "li.d\t%0,%1";
  }

       else if ((target_flags & 0x00002000))
  ret = "dli\t%0,%1";

       else
  {
    split_double (op1, operands + 2, operands + 3);
    ret = "li\t%0,%2\n\tli\t%D0,%3";
  }
     }

   else
     {
       if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
  ret = ((target_flags & 0x00002000)



         )
    ? "move\t%0,%."
      : "move\t%0,%.\n\tmove\t%D0,%.";

       else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
  {
    delay = DELAY_LOAD;
    ret = ((target_flags & 0x00002000))
    ? "dmtc1\t%.,%0"
    : "mtc1\t%.,%0\n\tmtc1\t%.,%D0";
  }
     }
 }

      else if (code1 == CONST_INT && ((op1)->fld[0].rtwint) == 0)
 {
   if (((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
     ret = ((target_flags & 0x00002000))
                         ? "move\t%0,%."
    : "move\t%0,%.\n\tmove\t%D0,%.";

   else if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
     {
       delay = DELAY_LOAD;
       ret = ((target_flags & 0x00002000))
    ? "dmtc1\t%.,%0"
    : ((target_flags & 0x00000200)
       ? "li.d\t%0,%1"
       : "mtc1\t%.,%0\n\tmtc1\t%.,%D0");
     }
   else if (((unsigned) ((regno0) - 64) < (66 - 64 + 1)))
     {
       delay = DELAY_HILO;
       if (regno0 != (64 + 2))
  ret = "mt%0\t%.\n";
       else
  ret = "mtlo\t%.\n\tmthi\t%.";
     }
 }

      else if (code1 == CONST_INT && ((op0)->mode) == DImode && ((unsigned) ((regno0) - 0) < (31 - 0 + 1)))
 {
   if ((target_flags & 0x00002000))
     {
       if (32 < 64)


  ret = ((((op1)->fld[0].rtwint) < 0) ? "dli\t%0,%1\t\t\t# %X1"
         : "dli\t%0,%X1\t\t# %1");
       else


  ret = "dli\t%0,%X1\t\t# %1";
     }
   else
     {
       operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (((operands[1])->fld[0].rtwint) >= 0 ? 0 : -1));
       ret = "li\t%M0,%2\n\tli\t%L0,%1";
     }
 }

      else if (code1 == MEM)
 {
   delay = DELAY_LOAD;

   if ((target_flags & 0x00000040))
     mips_count_memory_refs (op1, 2);

   if (((unsigned) ((regno0) - 32) < (63 - 32 + 1)))
     ret = "l.d\t%0,%1";

   else if ((target_flags & 0x00002000))
     {
  ret = "ld\t%0,%1";
     }

   else if (offsettable_address_p (1, DFmode, ((op1)->fld[0].rtx)))
     {
       operands[2] = adj_offsettable_operand (op1, 4);
       if (reg_mentioned_p (op0, op1))
  ret = "lw\t%D0,%2\n\tlw\t%0,%1";
       else
  ret = "lw\t%0,%1\n\tlw\t%D0,%2";
     }

   if (ret != (char *)0 && ((op1)->volatil))
     {
       int i = strlen (ret);
       if (i > sizeof (volatile_buffer) - sizeof ("%{%}"))
  abort ();

       sprintf (volatile_buffer, "%%{%s%%}", ret);
       ret = volatile_buffer;
     }
 }

      else if (code1 == LABEL_REF
        || code1 == SYMBOL_REF
        || code1 == CONST)
 {
   if ((target_flags & 0x00000040))
     mips_count_memory_refs (op1, 2);

   ret = "dla\t%0,%a1";
 }
    }

  else if (code0 == MEM)
    {
      if (code1 == REG)
 {
   int regno1 = ((op1)->fld[0].rtint) + subreg_word1;

   if (((unsigned) ((regno1) - 32) < (63 - 32 + 1)))
     ret = "s.d\t%1,%0";

   else if ((target_flags & 0x00002000))
     {





  ret = "sd\t%1,%0";
     }

   else if (offsettable_address_p (1, DFmode, ((op0)->fld[0].rtx)))
     {
       operands[2] = adj_offsettable_operand (op0, 4);
       ret = "sw\t%1,%0\n\tsw\t%D1,%2";
     }
 }

      else if (((code1 == CONST_INT && ((op1)->fld[0].rtwint) == 0)
  || (code1 == CONST_DOUBLE
      && op1 == (const_tiny_rtx[0][(int) (((op1)->mode))])))
        && ((target_flags & 0x00002000)
     || offsettable_address_p (1, DFmode, ((op0)->fld[0].rtx))))
 {
   if ((target_flags & 0x00002000))
     ret = "sd\t%.,%0";
   else
     {
       operands[2] = adj_offsettable_operand (op0, 4);
       ret = "sw\t%.,%0\n\tsw\t%.,%2";
     }
 }

      if ((target_flags & 0x00000040))
 mips_count_memory_refs (op0, 2);

      if (ret != (char *)0 && ((op0)->volatil))
 {
   int i = strlen (ret);
   if (i > sizeof (volatile_buffer) - sizeof ("%{%}"))
     abort ();

   sprintf (volatile_buffer, "%%{%s%%}", ret);
   ret = volatile_buffer;
 }
    }

  if (ret == (char *)0)
    {
      abort_with_insn (insn, "Bad move");
      return 0;
    }

  if (delay != DELAY_NONE)
    return mips_fill_delay_slot (ret, delay, operands, insn);

  return ret;
}





int
mips_address_cost(rtx addr) asm("_mips_address_cost");
int
mips_address_cost(rtx addr)
{
  switch (((addr)->code))
    {
    default:
      break;

    case LO_SUM:
    case HIGH:
      return 1;

    case LABEL_REF:
      return 2;

    case CONST:
      {
 rtx offset = const0_rtx;
 addr = eliminate_constant_term (((addr)->fld[0].rtx), &offset);
 if (((addr)->code) == LABEL_REF)
   return 2;

 if (((addr)->code) != SYMBOL_REF)
   return 4;

 if (! ((unsigned int) (((offset)->fld[0].rtwint) + 0x8000) < 0x10000))
   return 2;
      }


    case SYMBOL_REF:
      return ((addr)->volatil) ? 1 : 2;

    case PLUS:
      {
 register rtx plus0 = ((addr)->fld[0].rtx);
 register rtx plus1 = ((addr)->fld[1].rtx);

 if (((plus0)->code) != REG && ((plus1)->code) == REG)
   {
     plus0 = ((addr)->fld[1].rtx);
     plus1 = ((addr)->fld[0].rtx);
   }

 if (((plus0)->code) != REG)
   break;

 switch (((plus1)->code))
   {
   default:
     break;

   case CONST_INT:
     return (((unsigned int) (((plus1)->fld[0].rtwint) + 0x8000) < 0x10000) ? 1 : 2);

   case CONST:
   case SYMBOL_REF:
   case LABEL_REF:
   case HIGH:
   case LO_SUM:
     return mips_address_cost (plus1) + 1;
   }
      }
    }

  return 4;
}




int
pic_address_needs_scratch(rtx x) asm("_pic_address_needs_scratch");
int
pic_address_needs_scratch(rtx x)
{

  if (((x)->code) == CONST && ((((x)->fld[0].rtx))->code) == PLUS
      && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == SYMBOL_REF
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && ! ((unsigned int) (((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) + 0x8000) < 0x10000))
    return 1;

  return 0;
}



static n64_enum_internal_test
map_test_to_internal_test(n64_enum_rtx_code test_code) asm("_map_test_to_internal_test");
static n64_enum_internal_test
map_test_to_internal_test(n64_enum_rtx_code test_code)
{
  n64_enum_internal_test test = ITEST_MAX;

  switch (test_code)
    {
    default: break;
    case EQ: test = ITEST_EQ; break;
    case NE: test = ITEST_NE; break;
    case GT: test = ITEST_GT; break;
    case GE: test = ITEST_GE; break;
    case LT: test = ITEST_LT; break;
    case LE: test = ITEST_LE; break;
    case GTU: test = ITEST_GTU; break;
    case GEU: test = ITEST_GEU; break;
    case LTU: test = ITEST_LTU; break;
    case LEU: test = ITEST_LEU; break;
    }

  return test;
}
rtx
gen_int_relational(n64_enum_rtx_code test_code, rtx result, rtx cmp0, rtx cmp1, int *p_invert) asm("_gen_int_relational");
rtx
gen_int_relational(n64_enum_rtx_code test_code, rtx result, rtx cmp0, rtx cmp1, int *p_invert)
{
  struct n64_tag_cmp_info {
    n64_enum_rtx_code test_code;
    int const_low;
    int const_high;
    int const_add;
    int reverse_regs;
    int invert_const;
    int invert_reg;
    int unsignedp;
  };

  static struct n64_tag_cmp_info info[ (int)ITEST_MAX ] = {

    { XOR, 0, 65535, 0, 0, 0, 0, 0 },
    { XOR, 0, 65535, 0, 0, 1, 1, 0 },
    { LT, -32769, 32766, 1, 1, 1, 0, 0 },
    { LT, -32768, 32767, 0, 0, 1, 1, 0 },
    { LT, -32768, 32767, 0, 0, 0, 0, 0 },
    { LT, -32769, 32766, 1, 1, 0, 1, 0 },
    { LTU, -32769, 32766, 1, 1, 1, 0, 1 },
    { LTU, -32768, 32767, 0, 0, 1, 1, 1 },
    { LTU, -32768, 32767, 0, 0, 0, 0, 1 },
    { LTU, -32769, 32766, 1, 1, 0, 1, 1 },
  };

  n64_enum_internal_test test;
  n64_enum_machine_mode mode;
  struct n64_tag_cmp_info *p_info;
  int branch_p;
  int eqne_p;
  int invert;
  rtx reg;
  rtx reg2;

  test = map_test_to_internal_test (test_code);
  if (test == ITEST_MAX)
    abort ();

  p_info = &info[ (int)test ];
  eqne_p = (p_info->test_code == XOR);

  mode = ((cmp0)->mode);
  if (mode == VOIDmode)
    mode = ((cmp1)->mode);


  branch_p = (result == (rtx)0);
  if (branch_p)
    {
      if (((cmp0)->code) == REG || ((cmp0)->code) == SUBREG)
 {

   if (((cmp1)->code) == CONST_INT && ((cmp1)->fld[0].rtwint) == 0)
     return (rtx)0;


   if (eqne_p)
     return (rtx)0;
 }


      result = gen_reg_rtx (mode);
    }


  if (((cmp0)->code) == CONST_INT)
    cmp0 = force_reg (mode, cmp0);

  if (((cmp1)->code) == CONST_INT)
    {
      int value = ((cmp1)->fld[0].rtwint);
      if (value < p_info->const_low
   || value > p_info->const_high

   || ((target_flags & 0x00002000)
       && 32 < 64
       && p_info->const_add != 0
       && ((p_info->unsignedp
     ? ((unsigned int) (value + p_info->const_add)
        > ((cmp1)->fld[0].rtwint))
     : (value + p_info->const_add) > ((cmp1)->fld[0].rtwint))
    != (p_info->const_add > 0))))
 cmp1 = force_reg (mode, cmp1);
    }


  invert = (((cmp1)->code) == CONST_INT)
  ? p_info->invert_const
  : p_info->invert_reg;

  if (p_invert != (int *)0)
    {
      *p_invert = invert;
      invert = 0;
    }



  if (((cmp1)->code) == CONST_INT)
    {
      if (p_info->const_add != 0)
 {
   int cxx_new = ((cmp1)->fld[0].rtwint) + p_info->const_add;



   if ((p_info->unsignedp
        ? (unsigned int) cxx_new > ((cmp1)->fld[0].rtwint)
        : cxx_new > ((cmp1)->fld[0].rtwint))
       != (p_info->const_add > 0))
     {



       emit_move_insn (result, invert ? const0_rtx : const_true_rtx);
       return result;
     }
   else
     cmp1 = gen_rtx (CONST_INT, VOIDmode, (int) (cxx_new));
 }
    }
  else if (p_info->reverse_regs)
    {
      rtx temp = cmp0;
      cmp0 = cmp1;
      cmp1 = temp;
    }

  if (test == ITEST_NE && ((cmp1)->code) == CONST_INT && ((cmp1)->fld[0].rtwint) == 0)
    reg = cmp0;
  else
    {
      reg = (invert || eqne_p) ? gen_reg_rtx (mode) : result;
      convert_move (reg, gen_rtx (p_info->test_code, mode, cmp0, cmp1), 0);
    }

  if (test == ITEST_NE)
    {
      convert_move (result, gen_rtx (GTU, mode, reg, const0_rtx), 0);
      invert = 0;
    }

  else if (test == ITEST_EQ)
    {
      reg2 = (invert) ? gen_reg_rtx (mode) : result;
      convert_move (reg2, gen_rtx (LTU, mode, reg, const1_rtx), 0);
      reg = reg2;
    }

  if (invert)
    convert_move (result, gen_rtx (XOR, mode, reg, const1_rtx), 0);

  return result;
}






void
gen_conditional_branch(rtx *operands, n64_enum_rtx_code test_code) asm("_gen_conditional_branch");
void
gen_conditional_branch(rtx *operands, n64_enum_rtx_code test_code)
{
  static n64_enum_machine_mode mode_map[(int)CMP_MAX][(int)ITEST_MAX] = {
    {
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
      SImode,
    },
    {
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
      DImode,
    },
    {
      CC_FPmode,
      CC_REV_FPmode,
      CC_FPmode,
      CC_FPmode,
      CC_FPmode,
      CC_FPmode,
      VOIDmode,
      VOIDmode,
      VOIDmode,
      VOIDmode,
    },
    {
      CC_FPmode,
      CC_REV_FPmode,
      CC_FPmode,
      CC_FPmode,
      CC_FPmode,
      CC_FPmode,
      VOIDmode,
      VOIDmode,
      VOIDmode,
      VOIDmode,
    },
  };

  n64_enum_machine_mode mode;
  n64_enum_cmp_type type = branch_type;
  rtx cmp0 = branch_cmp[0];
  rtx cmp1 = branch_cmp[1];
  rtx label1 = gen_rtx (LABEL_REF, VOIDmode, operands[0]);
  rtx label2 = pc_rtx;
  rtx reg = (rtx)0;
  int invert = 0;
  n64_enum_internal_test test = map_test_to_internal_test (test_code);

  if (test == ITEST_MAX)
    {
      mode = word_mode;
      goto fail;
    }


  mode = mode_map[(int)type][(int)test];
  if (mode == VOIDmode)
    goto fail;

  switch (type)
    {
    default:
      goto fail;

    case CMP_SI:
    case CMP_DI:
      reg = gen_int_relational (test_code, (rtx)0, cmp0, cmp1, &invert);
      if (reg != (rtx)0)
 {
   cmp0 = reg;
   cmp1 = const0_rtx;
   test_code = NE;
 }


      else if (((cmp1)->code) == CONST_INT && ((cmp1)->fld[0].rtwint) != 0)
 cmp1 = force_reg (mode, cmp1);

      break;

    case CMP_DF:
    case CMP_SF:
      {
 rtx reg = gen_rtx (REG, mode, 67);
 emit_insn (gen_rtx (SET, VOIDmode, reg, gen_rtx (test_code, mode, cmp0, cmp1)));
 cmp0 = reg;
 cmp1 = const0_rtx;
 test_code = NE;
      }
      break;
    }


  if (invert)
    {
      label2 = label1;
      label1 = pc_rtx;
    }

  emit_jump_insn (gen_rtx (SET, VOIDmode,
      pc_rtx,
      gen_rtx (IF_THEN_ELSE, VOIDmode,
        gen_rtx (test_code, mode, cmp0, cmp1),
        label1,
        label2)));

  return;

fail:
  abort_with_insn (gen_rtx (test_code, mode, cmp0, cmp1), "bad test");
}
static void
block_move_loop(rtx dest_reg, rtx src_reg, int bytes, int align, rtx orig_src) asm("_block_move_loop");
static void
block_move_loop(rtx dest_reg, rtx src_reg, int bytes, int align, rtx orig_src)
{
  rtx dest_mem = gen_rtx (MEM, BLKmode, dest_reg);
  rtx src_mem = gen_rtx (MEM, BLKmode, src_reg);
  rtx align_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (align));
  rtx label;
  rtx final_src;
  rtx bytes_rtx;
  int leftover;

  if (bytes < 2*(4 * ((target_flags & 0x00002000) ? 8 : 4)))
    abort ();

  leftover = bytes % (4 * ((target_flags & 0x00002000) ? 8 : 4));
  bytes -= leftover;

  label = gen_label_rtx ();
  final_src = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
  bytes_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (bytes));

  if (bytes > 0x7fff)
    {
      if ((target_flags & 0x00000002))
 {
   emit_insn (gen_movdi (final_src, bytes_rtx));
   emit_insn (gen_adddi3 (final_src, final_src, src_reg));
 }
      else
 {
   emit_insn (gen_movsi (final_src, bytes_rtx));
   emit_insn (gen_addsi3 (final_src, final_src, src_reg));
 }
    }
  else
    {
      if ((target_flags & 0x00000002))
 emit_insn (gen_adddi3 (final_src, src_reg, bytes_rtx));
      else
 emit_insn (gen_addsi3 (final_src, src_reg, bytes_rtx));
    }

  emit_label (label);

  bytes_rtx = gen_rtx (CONST_INT, VOIDmode, (int) ((4 * ((target_flags & 0x00002000) ? 8 : 4))));
  emit_insn (gen_movstrsi_internal (dest_mem, src_mem, bytes_rtx, align_rtx));
  if ((target_flags & 0x00000002))
    {
      emit_insn (gen_adddi3 (src_reg, src_reg, bytes_rtx));
      emit_insn (gen_adddi3 (dest_reg, dest_reg, bytes_rtx));
      emit_insn (gen_cmpdi (src_reg, final_src));
    }
  else
    {
      emit_insn (gen_addsi3 (src_reg, src_reg, bytes_rtx));
      emit_insn (gen_addsi3 (dest_reg, dest_reg, bytes_rtx));
      emit_insn (gen_cmpsi (src_reg, final_src));
    }
  emit_jump_insn (gen_bne (label));

  if (leftover)
    emit_insn (gen_movstrsi_internal (dest_mem, src_mem,
          gen_rtx (CONST_INT, VOIDmode, (int) (leftover)),
          align_rtx));
}




static void
block_move_call(rtx dest_reg, rtx src_reg, rtx bytes_rtx) asm("_block_move_call");
static void
block_move_call(rtx dest_reg, rtx src_reg, rtx bytes_rtx)
{


  if (((bytes_rtx)->mode) != VOIDmode
      && ((bytes_rtx)->mode) != ((target_flags & 0x00000002) ? DImode : SImode))
    bytes_rtx = convert_to_mode (((target_flags & 0x00000002) ? DImode : SImode), bytes_rtx, 1);


  emit_library_call (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "memcpy"), 0,
       VOIDmode, 3,
       dest_reg, ((target_flags & 0x00000002) ? DImode : SImode),
       src_reg, ((target_flags & 0x00000002) ? DImode : SImode),
       bytes_rtx, ((target_flags & 0x00000002) ? DImode : SImode));







}
void
expand_block_move(rtx *operands) asm("_expand_block_move");
void
expand_block_move(rtx *operands)
{
  rtx bytes_rtx = operands[2];
  rtx align_rtx = operands[3];
  int constp = (((bytes_rtx)->code) == CONST_INT);
  int bytes = (constp ? ((bytes_rtx)->fld[0].rtwint) : 0);
  int align = ((align_rtx)->fld[0].rtwint);
  rtx orig_src = operands[1];
  rtx src_reg;
  rtx dest_reg;

  if (constp && bytes <= 0)
    return;

  if (align > ((target_flags & 0x00002000) ? 8 : 4))
    align = ((target_flags & 0x00002000) ? 8 : 4);


  dest_reg = copy_addr_to_reg (((operands[0])->fld[0].rtx));
  src_reg = copy_addr_to_reg (((orig_src)->fld[0].rtx));

  if ((target_flags & 0x00000080))
    block_move_call (dest_reg, src_reg, bytes_rtx);






  else if (constp && bytes <= 2*(4 * ((target_flags & 0x00002000) ? 8 : 4)))
    emit_insn (gen_movstrsi_internal (gen_rtx (MEM, BLKmode, dest_reg),
          gen_rtx (MEM, BLKmode, src_reg),
          bytes_rtx, align_rtx));

  else if (constp && align >= ((target_flags & 0x00002000) ? 8 : 4) && optimize)
    block_move_loop (dest_reg, src_reg, bytes, align, orig_src);

  else if (constp && optimize)
    {




      rtx temp = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
      rtx aligned_label = gen_label_rtx ();
      rtx join_label = gen_label_rtx ();
      int leftover = bytes % (4 * ((target_flags & 0x00002000) ? 8 : 4));

      bytes -= leftover;

      if ((target_flags & 0x00000002))
 {
   emit_insn (gen_iordi3 (temp, src_reg, dest_reg));
   emit_insn (gen_anddi3 (temp, temp, gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 8 : 4)-1))));
   emit_insn (gen_cmpdi (temp, const0_rtx));
 }
      else
 {
   emit_insn (gen_iorsi3 (temp, src_reg, dest_reg));
   emit_insn (gen_andsi3 (temp, temp, gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 8 : 4)-1))));
   emit_insn (gen_cmpsi (temp, const0_rtx));
 }
      emit_jump_insn (gen_beq (aligned_label));


      block_move_loop (dest_reg, src_reg, bytes, 1, orig_src);
      emit_jump_insn (gen_jump (join_label));
      emit_barrier ();


      emit_label (aligned_label);
      block_move_loop (dest_reg, src_reg, bytes, ((target_flags & 0x00002000) ? 8 : 4), orig_src);
      emit_label (join_label);


      if (leftover)
 {






     emit_insn (gen_movstrsi_internal (gen_rtx (MEM, BLKmode, dest_reg),
           gen_rtx (MEM, BLKmode, src_reg),
           gen_rtx (CONST_INT, VOIDmode, (int) (leftover)),
           gen_rtx (CONST_INT, VOIDmode, (int) (align))));
 }
    }

  else
    block_move_call (dest_reg, src_reg, bytes_rtx);
}
char *
output_block_move(rtx insn, rtx *operands, int num_regs, n64_enum_block_move_type move_type) asm("_output_block_move");
char *
output_block_move(rtx insn, rtx *operands, int num_regs, n64_enum_block_move_type move_type)
{
  rtx dest_reg = ((operands[0])->fld[0].rtx);
  rtx src_reg = ((operands[1])->fld[0].rtx);
  int bytes = ((operands[2])->fld[0].rtwint);
  int align = ((operands[3])->fld[0].rtwint);
  int num = 0;
  int offset = 0;
  int use_lwl_lwr = 0;
  int last_operand = num_regs+4;
  int safe_regs = 4;
  int i;
  rtx xoperands[10];

  struct {
    char *load;
    char *load_nop;
    char *store;
    char *final;
    char *last_store;
    int offset;
    n64_enum_machine_mode mode;
  } load_store[4];




  for (i = 4;
       i < last_operand && safe_regs < (sizeof(xoperands) / sizeof(xoperands[0]));
       i++)
    {
      if (!reg_mentioned_p (operands[i], operands[0])
   && !reg_mentioned_p (operands[i], operands[1]))

 xoperands[safe_regs++] = operands[i];
    }

  if (safe_regs < last_operand)
    {
      xoperands[0] = operands[0];
      xoperands[1] = operands[1];
      xoperands[2] = operands[2];
      xoperands[3] = operands[3];
      return output_block_move (insn, xoperands, safe_regs-4, move_type);
    }




  if (num_regs > 2 && (bytes > 2*align || move_type != BLOCK_MOVE_NORMAL))
    {
      if ((((src_reg)->code) == LABEL_REF || ((src_reg)->code) == SYMBOL_REF || ((src_reg)->code) == CONST_INT || ((src_reg)->code) == CONST_DOUBLE || ((src_reg)->code) == CONST || ((src_reg)->code) == HIGH))
 {
   if ((target_flags & 0x00000040))
     mips_count_memory_refs (operands[1], 1);

   src_reg = operands[ 3 + num_regs-- ];
   if (move_type != BLOCK_MOVE_LAST)
     {
       xoperands[1] = operands[1];
       xoperands[0] = src_reg;
       if (((target_flags & 0x00000002) ? DImode : SImode) == DImode)
  output_asm_insn ("dla\t%0,%1", xoperands);
       else
  output_asm_insn ("la\t%0,%1", xoperands);
     }
 }

      if ((((dest_reg)->code) == LABEL_REF || ((dest_reg)->code) == SYMBOL_REF || ((dest_reg)->code) == CONST_INT || ((dest_reg)->code) == CONST_DOUBLE || ((dest_reg)->code) == CONST || ((dest_reg)->code) == HIGH))
 {
   if ((target_flags & 0x00000040))
     mips_count_memory_refs (operands[0], 1);

   dest_reg = operands[ 3 + num_regs-- ];
   if (move_type != BLOCK_MOVE_LAST)
     {
       xoperands[1] = operands[0];
       xoperands[0] = dest_reg;
       if (((target_flags & 0x00000002) ? DImode : SImode) == DImode)
  output_asm_insn ("dla\t%0,%1", xoperands);
       else
  output_asm_insn ("la\t%0,%1", xoperands);
     }
 }
    }

  if (num_regs > (sizeof (load_store) / sizeof (load_store[0])))
    num_regs = (sizeof (load_store) / sizeof (load_store[0]));

  else if (num_regs < 1)
    abort_with_insn (insn, "Cannot do block move, not enough scratch registers");

  while (bytes > 0)
    {
      load_store[num].offset = offset;

      if ((target_flags & 0x00002000) && bytes >= 8 && align >= 8)
 {
   load_store[num].load = "ld\t%0,%1";
   load_store[num].load_nop = "ld\t%0,%1%#";
   load_store[num].store = "sd\t%0,%1";
   load_store[num].last_store = "sd\t%0,%1";
   load_store[num].final = (char *)0;
   load_store[num].mode = DImode;
   offset += 8;
   bytes -= 8;
 }


      else if ((target_flags & 0x00002000) && bytes >= 8)
 {
   if (((target_flags & 0x00010000) != 0))
     {
       load_store[num].load = "ldl\t%0,%1\n\tldr\t%0,%2";
       load_store[num].load_nop = "ldl\t%0,%1\n\tldr\t%0,%2%#";
       load_store[num].store = "sdl\t%0,%1\n\tsdr\t%0,%2";
       load_store[num].last_store = "sdr\t%0,%2";
       load_store[num].final = "sdl\t%0,%1";
     }
   else
     {
       load_store[num].load = "ldl\t%0,%2\n\tldr\t%0,%1";
       load_store[num].load_nop = "ldl\t%0,%2\n\tldr\t%0,%1%#";
       load_store[num].store = "sdl\t%0,%2\n\tsdr\t%0,%1";
       load_store[num].last_store = "sdr\t%0,%1";
       load_store[num].final = "sdl\t%0,%2";
     }
   load_store[num].mode = DImode;
   offset += 8;
   bytes -= 8;
   use_lwl_lwr = 1;
 }

      else if (bytes >= 4 && align >= 4)
 {
   load_store[num].load = "lw\t%0,%1";
   load_store[num].load_nop = "lw\t%0,%1%#";
   load_store[num].store = "sw\t%0,%1";
   load_store[num].last_store = "sw\t%0,%1";
   load_store[num].final = (char *)0;
   load_store[num].mode = SImode;
   offset += 4;
   bytes -= 4;
 }

      else if (bytes >= 4)
 {
   if (((target_flags & 0x00010000) != 0))
     {
       load_store[num].load = "lwl\t%0,%1\n\tlwr\t%0,%2";
       load_store[num].load_nop = "lwl\t%0,%1\n\tlwr\t%0,%2%#";
       load_store[num].store = "swl\t%0,%1\n\tswr\t%0,%2";
       load_store[num].last_store = "swr\t%0,%2";
       load_store[num].final = "swl\t%0,%1";
     }
   else
     {
       load_store[num].load = "lwl\t%0,%2\n\tlwr\t%0,%1";
       load_store[num].load_nop = "lwl\t%0,%2\n\tlwr\t%0,%1%#";
       load_store[num].store = "swl\t%0,%2\n\tswr\t%0,%1";
       load_store[num].last_store = "swr\t%0,%1";
       load_store[num].final = "swl\t%0,%2";
     }
   load_store[num].mode = SImode;
   offset += 4;
   bytes -= 4;
   use_lwl_lwr = 1;
 }

      else if (bytes >= 2 && align >= 2)
 {
   load_store[num].load = "lh\t%0,%1";
   load_store[num].load_nop = "lh\t%0,%1%#";
   load_store[num].store = "sh\t%0,%1";
   load_store[num].last_store = "sh\t%0,%1";
   load_store[num].final = (char *)0;
   load_store[num].mode = HImode;
   offset += 2;
   bytes -= 2;
 }

      else
 {
   load_store[num].load = "lb\t%0,%1";
   load_store[num].load_nop = "lb\t%0,%1%#";
   load_store[num].store = "sb\t%0,%1";
   load_store[num].last_store = "sb\t%0,%1";
   load_store[num].final = (char *)0;
   load_store[num].mode = QImode;
   offset++;
   bytes--;
 }

      if ((target_flags & 0x00000040) && move_type != BLOCK_MOVE_LAST)
 {
   dslots_load_total++;
   dslots_load_filled++;

   if ((((src_reg)->code) == LABEL_REF || ((src_reg)->code) == SYMBOL_REF || ((src_reg)->code) == CONST_INT || ((src_reg)->code) == CONST_DOUBLE || ((src_reg)->code) == CONST || ((src_reg)->code) == HIGH))
     mips_count_memory_refs (src_reg, 1);

   if ((((dest_reg)->code) == LABEL_REF || ((dest_reg)->code) == SYMBOL_REF || ((dest_reg)->code) == CONST_INT || ((dest_reg)->code) == CONST_DOUBLE || ((dest_reg)->code) == CONST || ((dest_reg)->code) == HIGH))
     mips_count_memory_refs (dest_reg, 1);
 }




      if (++num == num_regs || bytes == 0)
 {

   if (num == 1)
     {
       load_store[0].load = load_store[0].load_nop;
       if ((target_flags & 0x00000040) && move_type != BLOCK_MOVE_LAST)
  dslots_load_filled--;
     }

   if (move_type != BLOCK_MOVE_LAST)
     {
       for (i = 0; i < num; i++)
  {
    int offset;

    if (!operands[i+4])
      abort ();

    if (((operands[i+4])->mode) != load_store[i].mode)
      operands[i+4] = gen_rtx (REG, load_store[i].mode, ((operands[i+4])->fld[0].rtint));

    offset = load_store[i].offset;
    xoperands[0] = operands[i+4];
    xoperands[1] = gen_rtx (MEM, load_store[i].mode,
       plus_constant_wide (src_reg, (int) (offset)));

    if (use_lwl_lwr)
      {
        int extra_offset;
        extra_offset = (mode_size[(int)(load_store[i].mode)]) - 1;
        xoperands[2] = gen_rtx (MEM, load_store[i].mode,
           plus_constant_wide (src_reg, (int) (extra_offset + offset))

                     );
      }

    output_asm_insn (load_store[i].load, xoperands);
  }
     }

   for (i = 0; i < num; i++)
     {
       int last_p = (i == num-1 && bytes == 0);
       int offset = load_store[i].offset;

       xoperands[0] = operands[i+4];
       xoperands[1] = gen_rtx (MEM, load_store[i].mode,
          plus_constant_wide (dest_reg, (int) (offset)));


       if (use_lwl_lwr)
  {
    int extra_offset;
    extra_offset = (mode_size[(int)(load_store[i].mode)]) - 1;
    xoperands[2] = gen_rtx (MEM, load_store[i].mode,
       plus_constant_wide (dest_reg, (int) (extra_offset + offset))

                 );
  }

       if (move_type == BLOCK_MOVE_NORMAL)
  output_asm_insn (load_store[i].store, xoperands);

       else if (move_type == BLOCK_MOVE_NOT_LAST)
  {
    if (!last_p)
      output_asm_insn (load_store[i].store, xoperands);

    else if (load_store[i].final != (char *)0)
      output_asm_insn (load_store[i].final, xoperands);
  }

       else if (last_p)
  output_asm_insn (load_store[i].last_store, xoperands);
     }

   num = 0;
   use_lwl_lwr = 0;
 }
    }

  return "";
}






void
init_cumulative_args(CUMULATIVE_ARGS *cum, tree fntype, rtx libname) asm("_init_cumulative_args");
void
init_cumulative_args(CUMULATIVE_ARGS *cum, tree fntype, rtx libname)
{
  static CUMULATIVE_ARGS zero_cum;
  tree param, next_param;

  if ((target_flags & 0x02000000))
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "\ninit_cumulative_args, fntype = 0x%.8lx", (long)fntype);
      if (!fntype)
 fputc ('\n', 
             (__acrt_iob_func(2))
                   );

      else
 {
   tree ret_type = ((fntype)->common.type);
   fprintf (
           (__acrt_iob_func(2))
                 , ", fntype code = %s, ret code = %s\n",
     tree_code_name[ (int)((n64_enum_tree_code) (fntype)->common.code) ],
     tree_code_name[ (int)((n64_enum_tree_code) (ret_type)->common.code) ]);
 }
    }

  *cum = zero_cum;







  for (param = (fntype) ? ((fntype)->type.values) : 0;
       param != (tree)0;
       param = next_param)
    {
      next_param = ((param)->common.chain);
      if (next_param == (tree)0 && ((param)->list.value) != void_type_node)
 cum->gp_reg_found = 1;
    }
}



void
function_arg_advance(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named) asm("_function_arg_advance");
void
function_arg_advance(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named)
{
  if ((target_flags & 0x02000000))
    fprintf (
            (__acrt_iob_func(2))
                  ,
      "function_adv( {gp reg found = %d, arg # = %2d, words = %2d}, %4s, 0x%.8x, %d )\n\n",
      cum->gp_reg_found, cum->arg_number, cum->arg_words, (mode_name[(int)(mode)]),
      type, named);

  cum->arg_number++;
  switch (mode)
    {
    case VOIDmode:
      break;

    default:
      if ((mode_class[(int)(mode)]) != MODE_COMPLEX_INT
   && (mode_class[(int)(mode)]) != MODE_COMPLEX_FLOAT)
 abort ();
      cum->gp_reg_found = 1;
      cum->arg_words += (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1)
    / ((target_flags & 0x00002000) ? 8 : 4));
      break;

    case BLKmode:
      cum->gp_reg_found = 1;
      cum->arg_words += ((int_size_in_bytes (type) + ((target_flags & 0x00002000) ? 8 : 4) - 1)
    / ((target_flags & 0x00002000) ? 8 : 4));
      break;

    case SFmode:
      cum->arg_words++;
      break;

    case DFmode:
      cum->arg_words += ((target_flags & 0x00002000) ? 1 : 2);
      break;

    case DImode:
      cum->gp_reg_found = 1;
      cum->arg_words += ((target_flags & 0x00002000) ? 1 : 2);
      break;

    case QImode:
    case HImode:
    case SImode:
      cum->gp_reg_found = 1;
      cum->arg_words++;
      break;
    }
}




struct n64_tag_rtx_def *
function_arg(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named) asm("_function_arg");
struct n64_tag_rtx_def *
function_arg(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named)
{
  rtx ret;
  int regbase = -1;
  int bias = 0;
  int struct_p = ((type != (tree)0)
    && (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
        || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE));

  if ((target_flags & 0x02000000))
    fprintf (
            (__acrt_iob_func(2))
                  ,
      "function_arg( {gp reg found = %d, arg # = %2d, words = %2d}, %4s, 0x%.8x, %d ) = ",
      cum->gp_reg_found, cum->arg_number, cum->arg_words, (mode_name[(int)(mode)]),
      type, named);

  switch (mode)
    {
    case SFmode:
      if (! 0 || mips_isa < 3)
 {
   if (cum->gp_reg_found || cum->arg_number >= 2 || (target_flags & 0x00000100))
     regbase = (0 + 4);
   else
     {
       regbase = (32 + 12);


       if (cum->arg_words == 1)
  bias = 1;
     }
 }
      else
 regbase = ((target_flags & 0x00000100) || ! named ? (0 + 4) : (32 + 12));
      break;

    case DFmode:
      if (! (target_flags & 0x00002000))
 cum->arg_words += (cum->arg_words & 1);
      if (! 0 || mips_isa < 3)
 regbase = ((cum->gp_reg_found
      || (target_flags & 0x00000100)
      || (target_flags & 0x00020000)
      || cum->arg_number >= 2)
     ? (0 + 4)
     : (32 + 12));
      else
 regbase = ((target_flags & 0x00000100) || (target_flags & 0x00020000) || ! named
     ? (0 + 4) : (32 + 12));
      break;

    default:
      if ((mode_class[(int)(mode)]) != MODE_COMPLEX_INT
   && (mode_class[(int)(mode)]) != MODE_COMPLEX_FLOAT)
 abort ();


    case BLKmode:
      if (type != (tree)0 && ((type)->type.align) > ((target_flags & 0x00002000) ? 64 : 32)
   && ! (target_flags & 0x00002000))
 cum->arg_words += (cum->arg_words & 1);

      regbase = (0 + 4);
      break;

    case VOIDmode:
    case QImode:
    case HImode:
    case SImode:
      regbase = (0 + 4);
      break;

    case DImode:
      if (! (target_flags & 0x00002000))
 cum->arg_words += (cum->arg_words & 1);
      regbase = (0 + 4);
    }

  if (cum->arg_words >= 4)
    {
      if ((target_flags & 0x02000000))
 fprintf (
         (__acrt_iob_func(2))
               , "<stack>%s\n", struct_p ? ", [struct]" : "");

      ret = (rtx)0;
    }
  else
    {
      if (regbase == -1)
 abort ();

      ret = gen_rtx (REG, mode, regbase + cum->arg_words + bias);

      if ((target_flags & 0x02000000))
 fprintf (
         (__acrt_iob_func(2))
               , "%s%s\n", reg_names[regbase + cum->arg_words + bias],
   struct_p ? ", [struct]" : "");
      if (struct_p && int_size_in_bytes (type) < ((target_flags & 0x00002000) ? 8 : 4)
   && ! (target_flags & 0x00002000))
 {
   rtx amount = gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 64 : 32) - int_size_in_bytes (type) * 8))
                                               ;
   rtx reg = gen_rtx (REG, word_mode, regbase + cum->arg_words + bias);
   if ((target_flags & 0x00002000))
     cum->adjust[ cum->num_adjusts++ ] = gen_ashldi3 (reg, reg, amount);
   else
     cum->adjust[ cum->num_adjusts++ ] = gen_ashlsi3 (reg, reg, amount);
 }
    }

  if (mode == VOIDmode && cum->num_adjusts > 0)
    ret = gen_rtx (PARALLEL, VOIDmode, gen_rtvec_v (cum->num_adjusts, cum->adjust));

  return ret;
}


int
function_arg_partial_nregs(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named) asm("_function_arg_partial_nregs");
int
function_arg_partial_nregs(CUMULATIVE_ARGS *cum, n64_enum_machine_mode mode, tree type, int named)
{
  if ((mode == BLKmode
       || (mode_class[(int)(mode)]) != MODE_COMPLEX_INT
       || (mode_class[(int)(mode)]) != MODE_COMPLEX_FLOAT)
      && cum->arg_words < 4)
    {
      int words;
      if (mode == BLKmode)
 words = ((int_size_in_bytes (type) + ((target_flags & 0x00002000) ? 8 : 4) - 1)
   / ((target_flags & 0x00002000) ? 8 : 4));
      else
 words = ((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4);

      if (words + cum->arg_words <= 4)
 return 0;

      if ((target_flags & 0x02000000))
 fprintf (
         (__acrt_iob_func(2))
               , "function_arg_partial_nregs = %d\n",
   4 - cum->arg_words);

      return 4 - cum->arg_words;
    }

  else if (mode == DImode && cum->arg_words == 4 -1
    && ! (target_flags & 0x00002000))
    {
      if ((target_flags & 0x02000000))
 fprintf (
         (__acrt_iob_func(2))
               , "function_arg_partial_nregs = 1\n");

      return 1;
    }

  return 0;
}




static struct {char *name; int value;} target_switches []
  = { {"int64", 0x00000001 | 0x00000002}, {"long64", 0x00000002}, {"mips-as", -0x00000010}, {"gas", 0x00000010}, {"rnames", 0x00000020}, {"no-rnames", -0x00000020}, {"gpOPT", 0x00000008}, {"gpopt", 0x00000008}, {"no-gpOPT", -0x00000008}, {"no-gpopt", -0x00000008}, {"stats", 0x00000040}, {"no-stats", -0x00000040}, {"memcpy", 0x00000080}, {"no-memcpy", -0x00000080}, {"mips-tfile", 0x00000000}, {"no-mips-tfile", -0x00000000}, {"soft-float", 0x00000100}, {"hard-float", -0x00000100}, {"fp64", 0x00000200}, {"fp32", -0x00000200}, {"gp64", 0x00002000}, {"gp32", -0x00002000}, {"abicalls", 0x00000400}, {"no-abicalls", -0x00000400}, {"half-pic", 0x00000800}, {"no-half-pic", -0x00000800}, {"long-calls", 0x00001000}, {"no-long-calls", -0x00001000}, {"embedded-pic", 0x00004000}, {"no-embedded-pic", -0x00004000}, {"embedded-data", 0x00008000}, {"no-embedded-data", -0x00008000}, {"eb", 0x00010000}, {"el", -0x00010000}, {"single-float", 0x00020000}, {"double-float", -0x00020000}, {"mad", 0x00040000}, {"no-mad", -0x00040000}, {"4650", 0x00040000 | 0x00020000}, {"debug", 0x40000000}, {"debuga", 0x20000000}, {"debugb", 0x10000000}, {"debugc", 0x08000000}, {"debugd", 0x04000000}, {"debuge", 0x02000000}, {"debugf", 0x01000000}, {"debugg", 0x00800000}, {"debugh", 0x00400000}, {"debugi", 0x00200000}, {"debugj", 0x00100000}, {"", (0x00000010 | 0 | 0x00010000)} };

void
print_options(FILE *out) asm("_print_options");
void
print_options(FILE *out)
{
  int line_len;
  int len;
  int j;
  char **p;
  int mask = 0x00000010;




  if ((target_flags & 0x40000000))
    return;

  fprintf (out, "\n # %s %s", language_string, version_string);

  fprintf (out, " %s %s", "[AL 1.1, MM 40]", "GNU MIPS/ELF");


  fprintf (out, " compiled by GNU C\n\n");




  fprintf (out, " # Cc1 defaults:");
  line_len = 32767;
  for (j = 0; j < sizeof target_switches / sizeof target_switches[0]; j++)
    {
      if (target_switches[j].name[0] != '\0'
   && target_switches[j].value > 0
   && (target_switches[j].value & mask) == target_switches[j].value)
 {
   mask &= ~ target_switches[j].value;
   len = strlen (target_switches[j].name) + 1;
   if (len + line_len > 79)
     {
       line_len = 2;
       fputs ("\n #", out);
     }
   fprintf (out, " -m%s", target_switches[j].name);
   line_len += len;
 }
    }

  fprintf (out, "\n\n # Cc1 arguments (-G value = %d, Cpu = %s, ISA = %d):",
    mips_section_threshold, mips_cpu_string, mips_isa);

  line_len = 32767;
  for (p = &save_argv[1]; *p != (char *)0; p++)
    {
      char *arg = *p;
      if (*arg == '-')
 {
   len = strlen (arg) + 1;
   if (len + line_len > 79)
     {
       line_len = 2;
       fputs ("\n #", out);
     }
   fprintf (out, " %s", *p);
   line_len += len;
 }
    }

  fputs ("\n\n", out);
}




void
abort_with_insn(rtx insn, char *reason) asm("_abort_with_insn");
void
abort_with_insn(rtx insn, char *reason)
{
  error (reason);
  debug_rtx (insn);
  abort ();
}




void
trace(char *s, char *s1, char *s2) asm("_trace");
void
trace(char *s, char *s1, char *s2)
{
  fprintf (
          (__acrt_iob_func(2))
                , s, s1, s2);
}
void
override_options(void) asm("_override_options");
void
override_options(void)
{
  register int i, start;
  register int regno;
  register n64_enum_machine_mode mode;

  mips_section_threshold = (g_switch_set) ? g_switch_value : 8;

  if (mips_section_threshold <= 0)
    target_flags &= ~0x00000008;
  else if (optimize)
    target_flags |= 0x00000008;


  if (mips_isa_string == (char *)0)
    {



      mips_isa = 1;

    }

  else if (isdigit (*mips_isa_string))
    {
      mips_isa = atoi (mips_isa_string);
      if (mips_isa < 1 || mips_isa > 4)
 {
   error ("-mips%d not supported", mips_isa);
   mips_isa = 1;
 }
    }

  else
    {
      error ("bad value (%s) for -mips switch", mips_isa_string);
      mips_isa = 1;
    }
  if (mips_cpu_string == (char *)0
      || !strcmp (mips_cpu_string, "default")
      || !strcmp (mips_cpu_string, "DEFAULT"))
    {
      switch (mips_isa)
 {
 default:
   mips_cpu_string = "3000";
   mips_cpu = PROCESSOR_R3000;
   break;
 case 2:
   mips_cpu_string = "6000";
   mips_cpu = PROCESSOR_R6000;
   break;
 case 3:
   mips_cpu_string = "4000";
   mips_cpu = PROCESSOR_R4000;
   break;
 case 4:
   mips_cpu_string = "8000";
   mips_cpu = PROCESSOR_R8000;
   break;
 }
    }

  else
    {
      char *p = mips_cpu_string;

      if (*p == 'r' || *p == 'R')
 p++;




      mips_cpu = PROCESSOR_DEFAULT;
      switch (*p)
 {
 case '2':
   if (!strcmp (p, "2000") || !strcmp (p, "2k") || !strcmp (p, "2K"))
     mips_cpu = PROCESSOR_R3000;
   break;

 case '3':
   if (!strcmp (p, "3000") || !strcmp (p, "3k") || !strcmp (p, "3K"))
     mips_cpu = PROCESSOR_R3000;
   break;

 case '4':
   if (!strcmp (p, "4000") || !strcmp (p, "4k") || !strcmp (p, "4K"))
     mips_cpu = PROCESSOR_R4000;


   else if (!strcmp (p, "4400"))
     mips_cpu = PROCESSOR_R4000;
   else if (!strcmp (p, "4600"))
     mips_cpu = PROCESSOR_R4600;
   else if (!strcmp (p, "4650"))
     mips_cpu = PROCESSOR_R4650;
   break;

 case '6':
   if (!strcmp (p, "6000") || !strcmp (p, "6k") || !strcmp (p, "6K"))
     mips_cpu = PROCESSOR_R6000;
   break;

 case '8':
   if (!strcmp (p, "8000"))
     mips_cpu = PROCESSOR_R8000;
   break;

 case 'o':
   if (!strcmp (p, "orion"))
     mips_cpu = PROCESSOR_R4600;
   break;
 }

      if (mips_cpu == PROCESSOR_DEFAULT)
 {
   error ("bad value (%s) for -mcpu= switch", mips_cpu_string);
   mips_cpu_string = "default";
 }
    }

  if ((mips_cpu == PROCESSOR_R3000 && mips_isa > 1)
      || (mips_cpu == PROCESSOR_R6000 && mips_isa > 2)
      || ((mips_cpu == PROCESSOR_R4000
    || mips_cpu == PROCESSOR_R4600
    || mips_cpu == PROCESSOR_R4650)
   && mips_isa > 3))
    error ("-mcpu=%s does not support -mips%d", mips_cpu_string, mips_isa);


  if (mips_isa < 3)
    {
      if ((target_flags & 0x00000001))
 fatal ("Only MIPS-III or MIPS-IV CPUs can support 64 bit ints");

      else if ((target_flags & 0x00000002))
 fatal ("Only MIPS-III or MIPS-IV CPUs can support 64 bit longs");

      else if ((target_flags & 0x00000200))
 fatal ("Only MIPS-III or MIPS-IV CPUs can support 64 bit fp registers");

      else if ((target_flags & 0x00002000))
 fatal ("Only MIPS-III or MIPS-IV CPUs can support 64 bit gp registers");
    }

  if (0 && mips_isa >= 3)
    flag_pcc_struct_return = 0;


  if ((target_flags & 0x00000800))
    error ("half-pic init called on systems that don't support it.");





  if ((target_flags & 0x00000400))
    {
      mips_abicalls = MIPS_ABICALLS_YES;
      flag_pic = 1;
      if (mips_section_threshold > 0)
 warning ("-G is incompatible with PIC code which is the default");
    }
  else
    mips_abicalls = MIPS_ABICALLS_NO;
  if ((target_flags & 0x00004000))
    {
      flag_pic = 1;
      if ((target_flags & 0x00000400))
 warning ("-membedded-pic and -mabicalls are incompatible");
      if (g_switch_set)
 warning ("-G and -membedded-pic are incompatible");





      mips_section_threshold = 0x7fffffff;
    }






  if ((target_flags & 0x00000020))
    memcpy ((char *) mips_reg_names,(char *) mips_sw_reg_names,sizeof (mips_reg_names));
  dfhigh = ereal_atof ("1.0e300", DFmode);
  dflow = ereal_atof ("1.0e-300", DFmode);
  sfhigh = ereal_atof ("1.0e38", SFmode);
  sflow = ereal_atof ("1.0e-38", SFmode);

  mips_print_operand_punct['?'] = 1;
  mips_print_operand_punct['#'] = 1;
  mips_print_operand_punct['&'] = 1;
  mips_print_operand_punct['!'] = 1;
  mips_print_operand_punct['*'] = 1;
  mips_print_operand_punct['@'] = 1;
  mips_print_operand_punct['.'] = 1;
  mips_print_operand_punct['('] = 1;
  mips_print_operand_punct[')'] = 1;
  mips_print_operand_punct['['] = 1;
  mips_print_operand_punct[']'] = 1;
  mips_print_operand_punct['<'] = 1;
  mips_print_operand_punct['>'] = 1;
  mips_print_operand_punct['{'] = 1;
  mips_print_operand_punct['}'] = 1;
  mips_print_operand_punct['^'] = 1;

  mips_char_to_class['d'] = GR_REGS;
  mips_char_to_class['f'] = (((! (target_flags & 0x00000100))) ? FP_REGS : NO_REGS);
  mips_char_to_class['h'] = HI_REG;
  mips_char_to_class['l'] = LO_REG;
  mips_char_to_class['a'] = HILO_REG;
  mips_char_to_class['x'] = MD_REGS;
  mips_char_to_class['b'] = ALL_REGS;
  mips_char_to_class['y'] = GR_REGS;
  mips_char_to_class['z'] = ST_REGS;




  for (i = 0; i < 68; i++)
    mips_dbx_regno[i] = -1;

  start = 0 - 0;
  for (i = 0; i <= 31; i++)
    mips_dbx_regno[i] = i + start;

  start = ((write_symbols == DBX_DEBUG) ? 38 : 32) - 32;
  for (i = 32; i <= 63; i++)
    mips_dbx_regno[i] = i + start;
  for (mode = VOIDmode;
       mode != MAX_MACHINE_MODE;
       mode = (n64_enum_machine_mode)((int)mode + 1))
    {
      register int size = (mode_size[(int)(mode)]);
      register n64_enum_mode_class cxx_class = (mode_class[(int)(mode)]);

      for (regno = 0; regno < 68; regno++)
 {
   register int temp;

   if (mode == CC_FPmode || mode == CC_REV_FPmode)
     temp = (regno == 67);

   else if (((unsigned) ((regno) - 0) < (31 - 0 + 1)))
     temp = ((regno & 1) == 0 || (size <= ((target_flags & 0x00002000) ? 8 : 4)));

   else if (((unsigned) ((regno) - 32) < (63 - 32 + 1)))
     temp = (((target_flags & 0x00000200) || ((regno & 1) == 0))
      && (cxx_class == MODE_FLOAT
   || cxx_class == MODE_COMPLEX_FLOAT
   || ((target_flags & 0x00400000) && cxx_class == MODE_INT))
      && (! (target_flags & 0x00020000) || size <= 4));

   else if (((unsigned) ((regno) - 64) < (66 - 64 + 1)))
     temp = (cxx_class == MODE_INT
      && (size <= ((target_flags & 0x00002000) ? 8 : 4)
   || (regno == 64 && size == 2 * ((target_flags & 0x00002000) ? 8 : 4))));

   else
     temp = 0;

   mips_hard_regno_mode_ok[(int)mode][regno] = temp;
 }
    }
}
int
mips_debugger_offset(rtx addr, int offset) asm("_mips_debugger_offset");
int
mips_debugger_offset(rtx addr, int offset)
{
  rtx offset2 = const0_rtx;
  rtx reg = eliminate_constant_term (addr, &offset2);

  if (!offset)
    offset = ((offset2)->fld[0].rtwint);

  if (reg == stack_pointer_rtx || reg == frame_pointer_rtx)
    {
      int frame_size = (!current_frame_info.initialized)
    ? compute_frame_size (get_frame_size ())
    : current_frame_info.total_size;

      offset = offset - frame_size;
    }






  return offset;
}
void
print_operand(FILE *file, rtx op, int letter) asm("_print_operand");
void
print_operand(FILE *file, rtx op, int letter)
{
  register n64_enum_rtx_code code;

  if (mips_print_operand_punct[letter])
    {
      switch (letter)
 {
 default:
   error ("PRINT_OPERAND: Unknown punctuation '%c'", letter);
   break;

 case '?':
   if (mips_branch_likely)
     putc ('l', file);
   break;

 case '@':
   fputs (reg_names [0 + 1], file);
   break;

 case '^':
   fputs (reg_names [(0 + 25)], file);
   break;

 case '.':
   fputs (reg_names [0 + 0], file);
   break;

 case '&':
   if (final_sequence != 0 && set_noreorder++ == 0)
     fputs (".set\tnoreorder\n\t", file);
   break;

 case '*':
   if (final_sequence != 0)
     {
       if (set_noreorder++ == 0)
  fputs (".set\tnoreorder\n\t", file);

       if (set_nomacro++ == 0)
  fputs (".set\tnomacro\n\t", file);
     }
   break;

 case '!':
   if (final_sequence != 0 && set_nomacro++ == 0)
     fputs ("\n\t.set\tnomacro", file);
   break;

 case '#':
   if (set_noreorder != 0)
     fputs ("\n\tnop", file);

   else if ((target_flags & 0x00000040))
     fputs ("\n\t#nop", file);

   break;

 case '(':
   if (set_noreorder++ == 0)
     fputs (".set\tnoreorder\n\t", file);
   break;

 case ')':
   if (set_noreorder == 0)
     error ("internal error: %%) found without a %%( in assembler pattern");

   else if (--set_noreorder == 0)
     fputs ("\n\t.set\treorder", file);

   break;

 case '[':
   if (set_noat++ == 0)
     fputs (".set\tnoat\n\t", file);
   break;

 case ']':
   if (set_noat == 0)
     error ("internal error: %%] found without a %%[ in assembler pattern");

   else if (--set_noat == 0)
     fputs ("\n\t.set\tat", file);

   break;

 case '<':
   if (set_nomacro++ == 0)
     fputs (".set\tnomacro\n\t", file);
   break;

 case '>':
   if (set_nomacro == 0)
     error ("internal error: %%> found without a %%< in assembler pattern");

   else if (--set_nomacro == 0)
     fputs ("\n\t.set\tmacro", file);

   break;

 case '{':
   if (set_volatile++ == 0)
     fprintf (file, "%s.set\tvolatile\n\t", ((!(target_flags & 0x00000010))) ? "" : "#");
   break;

 case '}':
   if (set_volatile == 0)
     error ("internal error: %%} found without a %%{ in assembler pattern");

   else if (--set_volatile == 0)
     fprintf (file, "\n\t%s.set\tnovolatile", ((!(target_flags & 0x00000010))) ? "" : "#");

   break;
 }
      return;
    }

  if (! op)
    {
      error ("PRINT_OPERAND null pointer");
      return;
    }

  code = ((op)->code);
  if (letter == 'C')
    switch (code)
      {
      case EQ: fputs ("eq", file); break;
      case NE: fputs ("ne", file); break;
      case GT: fputs ("gt", file); break;
      case GE: fputs ("ge", file); break;
      case LT: fputs ("lt", file); break;
      case LE: fputs ("le", file); break;
      case GTU: fputs ("gtu", file); break;
      case GEU: fputs ("geu", file); break;
      case LTU: fputs ("ltu", file); break;
      case LEU: fputs ("leu", file); break;

      default:
 abort_with_insn (op, "PRINT_OPERAND, invalid insn for %%C");
      }

  else if (letter == 'N')
    switch (code)
      {
      case EQ: fputs ("ne", file); break;
      case NE: fputs ("eq", file); break;
      case GT: fputs ("le", file); break;
      case GE: fputs ("lt", file); break;
      case LT: fputs ("ge", file); break;
      case LE: fputs ("gt", file); break;
      case GTU: fputs ("leu", file); break;
      case GEU: fputs ("ltu", file); break;
      case LTU: fputs ("geu", file); break;
      case LEU: fputs ("gtu", file); break;

      default:
 abort_with_insn (op, "PRINT_OPERAND, invalid insn for %%N");
      }

  else if (letter == 'S')
    {
      char buffer[100];

      do { sprintf (buffer, "*.%s%d", "LS", ((op)->fld[3].rtint)); } while (0);
      assemble_name (file, buffer);
    }

  else if (code == REG)
    {
      register int regnum = ((op)->fld[0].rtint);

      if ((letter == 'M' && ! ((target_flags & 0x00010000) != 0))
   || (letter == 'L' && ((target_flags & 0x00010000) != 0))
   || letter == 'D')
 regnum++;

      fprintf (file, "%s", reg_names[regnum]);
    }

  else if (code == MEM)
    output_address (((op)->fld[0].rtx));

  else if (code == CONST_DOUBLE
    && (mode_class[(int)(((op)->mode))]) == MODE_FLOAT)
    {
      double d;
      char s[30];

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
      (ereal_to_decimal (d, s));
      fprintf (file, s);
    }

  else if ((letter == 'x') && (((op)->code) == CONST_INT))
    fprintf (file, "0x%04x", 0xffff & (((op)->fld[0].rtwint)));

  else if ((letter == 'X') && (((op)->code) == CONST_INT)
    && 32 == 32)
    fprintf (file, "0x%08x", ((op)->fld[0].rtwint));

  else if ((letter == 'X') && (((op)->code) == CONST_INT)
    && 32 == 64)
    fprintf (file, "0x%016lx", ((op)->fld[0].rtwint));

  else if ((letter == 'd') && (((op)->code) == CONST_INT))
    fprintf (file, "%d", (((op)->fld[0].rtwint)));

  else if (letter == 'z'
    && (((op)->code) == CONST_INT)
    && ((op)->fld[0].rtwint) == 0)
    fputs (reg_names[0], file);

  else if (letter == 'd' || letter == 'x' || letter == 'X')
    fatal ("PRINT_OPERAND: letter %c was found & insn was not CONST_INT", letter);

  else if (letter == 'B')
    fputs (code == EQ ? "z" : "n", file);
  else if (letter == 'b')
    fputs (code == EQ ? "n" : "z", file);
  else if (letter == 'T')
    fputs (code == EQ ? "f" : "t", file);
  else if (letter == 't')
    fputs (code == EQ ? "t" : "f", file);

  else
    output_addr_const (file, op);
}
void
print_operand_address(FILE *file, rtx addr) asm("_print_operand_address");
void
print_operand_address(FILE *file, rtx addr)
{
  if (!addr)
    error ("PRINT_OPERAND_ADDRESS, null pointer");

  else
    switch (((addr)->code))
      {
      default:
 abort_with_insn (addr, "PRINT_OPERAND_ADDRESS, invalid insn #1");
 break;

      case REG:
 if (((addr)->fld[0].rtint) == 0)
   abort_with_insn (addr, "Arg pointer not eliminated.");

 fprintf (file, "0(%s)", reg_names [((addr)->fld[0].rtint)]);
 break;

      case PLUS:
 {
   register rtx reg = (rtx)0;
   register rtx offset = (rtx)0;
   register rtx arg0 = ((addr)->fld[0].rtx);
   register rtx arg1 = ((addr)->fld[1].rtx);

   if (((arg0)->code) == REG)
     {
       reg = arg0;
       offset = arg1;
       if (((offset)->code) == REG)
  abort_with_insn (addr, "PRINT_OPERAND_ADDRESS, 2 regs");
     }
   else if (((arg1)->code) == REG)
     {
       reg = arg1;
       offset = arg0;
     }
   else if ((((arg0)->code) == LABEL_REF || ((arg0)->code) == SYMBOL_REF || ((arg0)->code) == CONST_INT || ((arg0)->code) == CONST_DOUBLE || ((arg0)->code) == CONST || ((arg0)->code) == HIGH) && (((arg1)->code) == LABEL_REF || ((arg1)->code) == SYMBOL_REF || ((arg1)->code) == CONST_INT || ((arg1)->code) == CONST_DOUBLE || ((arg1)->code) == CONST || ((arg1)->code) == HIGH))
     {
       output_addr_const (file, addr);
       break;
     }
   else
     abort_with_insn (addr, "PRINT_OPERAND_ADDRESS, no regs");

   if (!(((offset)->code) == LABEL_REF || ((offset)->code) == SYMBOL_REF || ((offset)->code) == CONST_INT || ((offset)->code) == CONST_DOUBLE || ((offset)->code) == CONST || ((offset)->code) == HIGH))
     abort_with_insn (addr, "PRINT_OPERAND_ADDRESS, invalid insn #2");

 if (((reg)->fld[0].rtint) == 0)
   abort_with_insn (addr, "Arg pointer not eliminated.");

   output_addr_const (file, offset);
   fprintf (file, "(%s)", reg_names [((reg)->fld[0].rtint)]);
 }
 break;

      case LABEL_REF:
      case SYMBOL_REF:
      case CONST_INT:
      case CONST:
 output_addr_const (file, addr);
 break;
    }
}
int
mips_output_external(FILE *file, tree decl, char *name) asm("_mips_output_external");
int
mips_output_external(FILE *file, tree decl, char *name)
{
  register struct n64_tag_extern_list *p;
  int len;

  if ((target_flags & 0x00000008)
      && ((((n64_enum_tree_code) (decl)->common.code)) != FUNCTION_DECL)
      && ((len = int_size_in_bytes (((decl)->common.type))) > 0))
    {
      p = (struct n64_tag_extern_list *)permalloc ((long) sizeof (struct n64_tag_extern_list));
      p->next = extern_head;
      p->name = name;
      p->size = len;
      extern_head = p;
    }
  return 0;
}
static FILE *
make_temp_file(void) asm("_make_temp_file");
static FILE *
make_temp_file(void)
{
  FILE *stream;
  char *base = getenv ("TMPDIR");
  int len;

  if (base == (char *)0)
    {

      if (access (
                 "\\"
                         , 
                           4 
                                | 
                                  2
                                      ) == 0)
 base = 
       "\\"
               ;
      else

 if (access ("/usr/tmp", 
                        4 
                             | 
                               2
                                   ) == 0)
   base = "/usr/tmp/";
 else
   base = "/tmp/";
    }

  len = strlen (base);

  temp_filename = (char *) xmalloc (len + sizeof("/ctXXXXXX"));
  strcpy (temp_filename, base);
  if (len > 0 && temp_filename[len-1] != '/')
    temp_filename[len++] = '/';

  strcpy (temp_filename + len, "ctXXXXXX");
  mktemp (temp_filename);

  stream = fopen (temp_filename, "w+");
  if (!stream)
    pfatal_with_name (temp_filename);





  unlink (temp_filename);

  return stream;
}






void
mips_output_filename(FILE *stream, char *name) asm("_mips_output_filename");
void
mips_output_filename(FILE *stream, char *name)
{
  static int first_time = 1;
  char ltext_label_name[100];

  if (first_time)
    {
      first_time = 0;
      ++num_source_filenames;
      current_function_file = name;
      do { fprintf (stream, "\t.file\t%d ", num_source_filenames); output_quoted_string (stream, name); fputs ("\n", stream); } while (0);

      if (!(target_flags & 0x00000010) && write_symbols == DBX_DEBUG)
 fprintf (stream, "\t#@stabs\n");
    }

  else if (write_symbols == DBX_DEBUG)
    {
      do { sprintf (ltext_label_name, "*.%s%d", "Ltext", 0); } while (0);
      fprintf (stream, "%s ", (((target_flags & 0x00000010)) ? ".stabs" : " #.stabs"));
      output_quoted_string (stream, name);
      fprintf (stream, ",%d,0,0,%s\n", N_SOL, &ltext_label_name[1]);
    }

  else if (name != current_function_file
      && strcmp (name, current_function_file) != 0)
    {
      if (inside_function && !(target_flags & 0x00000010))
 {
   if (!file_in_function_warning)
     {
       file_in_function_warning = 1;
       ignore_line_number = 1;
       warning ("MIPS ECOFF format does not allow changing filenames within functions with #line");
     }
 }
      else
 {
   ++num_source_filenames;
   current_function_file = name;
   do { fprintf (stream, "\t.file\t%d ", num_source_filenames); output_quoted_string (stream, name); fputs ("\n", stream); } while (0);
 }
    }
}







void
mips_output_lineno(FILE *stream, int line) asm("_mips_output_lineno");
void
mips_output_lineno(FILE *stream, int line)
{
  if (write_symbols == DBX_DEBUG)
    {
      ++sym_lineno;
      fprintf (stream, "%sLM%d:\n\t%s %d,0,%d,%sLM%d\n",
        ".", sym_lineno, (((target_flags & 0x00000010)) ? ".stabn" : " #.stabn"), N_SLINE, line,
        ".", sym_lineno);
    }

  else
    {
      fprintf (stream, "\n\t%s.loc\t%d %d\n",
        (ignore_line_number) ? "#" : "",
        num_source_filenames, line);

      ;
    }
}
void
final_prescan_insn(rtx insn, rtx *opvec, int noperands) asm("_final_prescan_insn");
void
final_prescan_insn(rtx insn, rtx *opvec, int noperands)
{
  if (dslots_number_nops > 0)
    {
      rtx pattern = ((insn)->fld[3].rtx);
      int length = get_attr_length (insn);


      if (length == 0
   || (mips_load_reg != (rtx)0 && reg_mentioned_p (mips_load_reg, pattern))
   || (mips_load_reg2 != (rtx)0 && reg_mentioned_p (mips_load_reg2, pattern))
   || (mips_load_reg3 != (rtx)0 && reg_mentioned_p (mips_load_reg3, pattern))
   || (mips_load_reg4 != (rtx)0 && reg_mentioned_p (mips_load_reg4, pattern)))
 fputs ("\t#nop\n", asm_out_file);

      else
 dslots_load_filled++;

      while (--dslots_number_nops > 0)
 fputs ("\t#nop\n", asm_out_file);

      mips_load_reg = (rtx)0;
      mips_load_reg2 = (rtx)0;
      mips_load_reg3 = (rtx)0;
      mips_load_reg4 = (rtx)0;
    }

  if ((target_flags & 0x00000040))
    {
      n64_enum_rtx_code code = ((insn)->code);
      if (code == JUMP_INSN || code == CALL_INSN)
 dslots_jump_total++;
    }
}
void
mips_asm_file_start(FILE *stream) asm("_mips_asm_file_start");
void
mips_asm_file_start(FILE *stream)
{
  mips_output_filename (stream, main_input_filename);






  if ((!(target_flags & 0x00000010)) && optimize && flag_delayed_branch)
    fprintf (stream, "\t.set\tnobopt\n");





  if ((target_flags & 0x00000400))

    fprintf (stream, "\t%s\n", ".abicalls");



  if (0 && mips_isa >= 3)
    fprintf (stream, "\t.section\t.text\n");
  if ((target_flags & 0x00000008))
    {
      asm_out_data_file = stream;
      asm_out_text_file = make_temp_file ();
    }
  else
    asm_out_data_file = asm_out_text_file = stream;

  print_options (stream);
}
void
mips_asm_file_end(FILE *file) asm("_mips_asm_file_end");
void
mips_asm_file_end(FILE *file)
{
  char buffer[8192];
  tree name_tree;
  struct n64_tag_extern_list *p;
  int len;

  if (0)
    ;

  if (extern_head)
    {
      fputs ("\n", file);

      for (p = extern_head; p != 0; p = p->next)
 {
   name_tree = get_identifier (p->name);


   if (! ((name_tree)->common.asm_written_flag))
     {
       ((name_tree)->common.asm_written_flag) = 1;





  {
    fputs ("\t.extern\t", file);
    assemble_name (file, p->name);
    fprintf (file, ", %d\n", p->size);
  }
     }
 }
    }

  if ((target_flags & 0x00000008))
    {
      fprintf (file, "\n\t.text\n");
      rewind (asm_out_text_file);
      if (ferror (asm_out_text_file))
 fatal_io_error (temp_filename);

      while ((len = fread (buffer, 1, sizeof (buffer), asm_out_text_file)) > 0)
 if (fwrite (buffer, 1, len, file) != len)
   pfatal_with_name (asm_file_name);

      if (len < 0)
 pfatal_with_name (temp_filename);

      if (fclose (asm_out_text_file) != 0)
 pfatal_with_name (temp_filename);




    }
}






void
mips_declare_object(FILE *stream, char *name, char *init_string, char *final_string, int size) asm("_mips_declare_object");
void
mips_declare_object(FILE *stream, char *name, char *init_string, char *final_string, int size)
{
  fputs (init_string, stream);
  assemble_name (stream, name);
  fprintf (stream, final_string, size);

  if ((target_flags & 0x00000008))
    {
      tree name_tree = get_identifier (name);
      ((name_tree)->common.asm_written_flag) = 1;
    }
}





void
mips_output_double(FILE *stream, double value) asm("_mips_output_double");
void
mips_output_double(FILE *stream, double value)
{

  long value_long[2];
  (etardouble ((value), (value_long)));

  fprintf (stream, "\t.word\t0x%08lx\t\t# %.20g\n\t.word\t0x%08lx\n",
    value_long[0], value, value_long[1]);



}





void
mips_output_float(FILE *stream, double value) asm("_mips_output_float");
void
mips_output_float(FILE *stream, double value)
{

  long value_long;
  ((value_long) = etarsingle ((value)));

  fprintf (stream, "\t.word\t0x%08lx\t\t# %.12g (float)\n", value_long, value);



}





int
epilogue_reg_mentioned_p(rtx insn) asm("_epilogue_reg_mentioned_p");
int
epilogue_reg_mentioned_p(rtx insn)
{
  register char *fmt;
  register int i;
  register n64_enum_rtx_code code;
  register int regno;

  if (insn == (rtx)0)
    return 0;

  if (((insn)->code) == LABEL_REF)
    return 0;

  code = ((insn)->code);
  switch (code)
    {
    case REG:
      regno = ((insn)->fld[0].rtint);
      if (regno == (0 + 29))
 return 1;

      if (regno == (0 + 30) && frame_pointer_needed)
 return 1;

      if (!call_used_regs[regno])
 return 1;

      if (regno != (0 + 12) && regno != (0 + 13))
 return 0;

      if (!current_frame_info.initialized)
 compute_frame_size (get_frame_size ());

      return (current_frame_info.total_size >= 32768);

    case SCRATCH:
    case CC0:
    case PC:
    case CONST_INT:
    case CONST_DOUBLE:
      return 0;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((insn)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (epilogue_reg_mentioned_p (((insn)->fld[i].rtvec->elem[j].rtx)))
       return 1;
 }
      else if (fmt[i] == 'e' && epilogue_reg_mentioned_p (((insn)->fld[i].rtx)))
 return 1;
    }

  return 0;
}
long
compute_frame_size(int size) asm("_compute_frame_size");
long
compute_frame_size(int size)
{
  int regno;
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  long gp_reg_rounded;
  long gp_reg_size;
  long fp_reg_size;
  long mask;
  long fmask;
  int fp_inc;
  long fp_bits;

  gp_reg_size = 0;
  fp_reg_size = 0;
  mask = 0;
  fmask = 0;
  extra_size = ((((((target_flags & 0x00000400)) ? ((target_flags & 0x00002000) ? 8 : 4) : 0))+7) & ~7);
  var_size = (((size)+7) & ~7);
  args_size = (((current_function_outgoing_args_size)+7) & ~7);






  if (args_size == 0 && current_function_calls_alloca)
    args_size = 4*((target_flags & 0x00002000) ? 8 : 4);

  total_size = var_size + args_size + extra_size;


  for (regno = 0; regno <= 31; regno++)
    {
      if (((regs_ever_live[regno] && !call_used_regs[regno]) || (regno == (0 + 30) && frame_pointer_needed) || (regno == (0 + 31) && regs_ever_live[0 + 31])))
 {
   gp_reg_size += ((target_flags & 0x00002000) ? 8 : 4);
   mask |= 1L << (regno - 0);
 }
    }


  if ((target_flags & 0x00000200) || (target_flags & 0x00020000))
    {
      fp_inc = 1;
      fp_bits = 1;
    }
  else
    {
      fp_inc = 2;
      fp_bits = 3;
    }

  for (regno = 32; regno <= 63; regno += fp_inc)
    {
      if (regs_ever_live[regno] && !call_used_regs[regno])
 {
   fp_reg_size += fp_inc * ((target_flags & 0x00000200) ? 8 : 4);
   fmask |= fp_bits << (regno - 32);
 }
    }

  gp_reg_rounded = (((gp_reg_size)+7) & ~7);
  total_size += gp_reg_rounded + (((fp_reg_size)+7) & ~7);





  if (total_size == extra_size && ! (0 && mips_isa >= 3))
    total_size = extra_size = 0;
  else if ((target_flags & 0x00000400))
    {

      gp_reg_size += ((target_flags & 0x00002000) ? 8 : 4);
      mask |= 1L << ((0 + 28) - 0);
      total_size -= gp_reg_rounded;
      gp_reg_rounded = (((gp_reg_size)+7) & ~7);
      total_size += gp_reg_rounded;
    }



  if (0 && mips_isa >= 3)
    total_size += (((current_function_pretend_args_size)+7) & ~7);


  current_frame_info.total_size = total_size;
  current_frame_info.var_size = var_size;
  current_frame_info.args_size = args_size;
  current_frame_info.extra_size = extra_size;
  current_frame_info.gp_reg_size = gp_reg_size;
  current_frame_info.fp_reg_size = fp_reg_size;
  current_frame_info.mask = mask;
  current_frame_info.fmask = fmask;
  current_frame_info.initialized = reload_completed;
  current_frame_info.num_gp = gp_reg_size / ((target_flags & 0x00002000) ? 8 : 4);
  current_frame_info.num_fp = fp_reg_size / (fp_inc * ((target_flags & 0x00000200) ? 8 : 4));

  if (mask)
    {
      unsigned long offset = (args_size + extra_size + var_size
         + gp_reg_size - ((target_flags & 0x00002000) ? 8 : 4));
      current_frame_info.gp_sp_offset = offset;
      current_frame_info.gp_save_offset = offset - total_size;
    }
  else
    {
      current_frame_info.gp_sp_offset = 0;
      current_frame_info.gp_save_offset = 0;
    }


  if (fmask)
    {
      unsigned long offset = (args_size + extra_size + var_size
         + gp_reg_rounded + fp_reg_size
         - fp_inc * ((target_flags & 0x00000200) ? 8 : 4));
      current_frame_info.fp_sp_offset = offset;
      current_frame_info.fp_save_offset = offset - total_size + ((target_flags & 0x00002000) ? 8 : 4);
    }
  else
    {
      current_frame_info.fp_sp_offset = 0;
      current_frame_info.fp_save_offset = 0;
    }


  return total_size;
}
static void
save_restore_insns(int store_p, rtx large_reg, long int large_offset, FILE *file) asm("_save_restore_insns");
static void
save_restore_insns(int store_p, rtx large_reg, long int large_offset, FILE *file)
{
  long mask = current_frame_info.mask;
  long fmask = current_frame_info.fmask;
  int regno;
  rtx base_reg_rtx;
  long base_offset;
  long gp_offset;
  long fp_offset;
  long end_offset;

  if (frame_pointer_needed && !(((mask) & (1L << ((0 + 30) - 0))) != 0))
    abort ();

  if (mask == 0 && fmask == 0)
    return;







  if (mask)
    {






      gp_offset = current_frame_info.gp_sp_offset;
      end_offset = gp_offset - (current_frame_info.gp_reg_size - ((target_flags & 0x00002000) ? 8 : 4));

      if (gp_offset < 0 || end_offset < 0)
 fatal ("gp_offset (%ld) or end_offset (%ld) is less than zero.",
        gp_offset, end_offset);

      else if (gp_offset < 32768)
 {
   base_reg_rtx = stack_pointer_rtx;
   base_offset = 0;
 }

      else if (large_reg != (rtx)0
        && (((unsigned long)(large_offset - gp_offset)) < 32768)
        && (((unsigned long)(large_offset - end_offset)) < 32768))
 {
   base_reg_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 13));
   base_offset = large_offset;
   if (file == (FILE *)0)
     {
       if ((target_flags & 0x00000002))
  emit_insn (gen_adddi3 (base_reg_rtx, large_reg, stack_pointer_rtx));
       else
  emit_insn (gen_addsi3 (base_reg_rtx, large_reg, stack_pointer_rtx));
     }
   else
     fprintf (file, "\t%s\t%s,%s,%s\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       reg_names[(0 + 13)],
       reg_names[((large_reg)->fld[0].rtint)],
       reg_names[(0 + 29)]);
 }

      else
 {
   base_reg_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 13));
   base_offset = gp_offset;
   if (file == (FILE *)0)
     {
       emit_move_insn (base_reg_rtx, gen_rtx (CONST_INT, VOIDmode, (int) (gp_offset)));
       if ((target_flags & 0x00000002))
  emit_insn (gen_adddi3 (base_reg_rtx, base_reg_rtx, stack_pointer_rtx));
       else
  emit_insn (gen_addsi3 (base_reg_rtx, base_reg_rtx, stack_pointer_rtx));
     }
   else
     fprintf (file, "\tli\t%s,0x%.08lx\t# %ld\n\t%s\t%s,%s,%s\n",
       reg_names[(0 + 13)],
       (long)base_offset,
       (long)base_offset,
       (target_flags & 0x00000002) ? "daddu" : "addu",
       reg_names[(0 + 13)],
       reg_names[(0 + 13)],
       reg_names[(0 + 29)]);
 }

      for (regno = 31; regno >= 0; regno--)
 {
   if ((((mask) & (1L << (regno - 0))) != 0))
     {
       if (file == (FILE *)0)
  {
    rtx reg_rtx = gen_rtx (REG, word_mode, regno);
    rtx mem_rtx = gen_rtx (MEM, word_mode,
      gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), base_reg_rtx,
        gen_rtx (CONST_INT, VOIDmode, (int) (gp_offset - base_offset))));

    if (store_p)
      emit_move_insn (mem_rtx, reg_rtx);
    else if (!(target_flags & 0x00000400) || (0 && mips_isa >= 3)
      || regno != ((0 + 28) - 0))
      emit_move_insn (reg_rtx, mem_rtx);
  }
       else
  {
    if (store_p || !(target_flags & 0x00000400) || (0 && mips_isa >= 3)
        || regno != ((0 + 28) - 0))
      fprintf (file, "\t%s\t%s,%ld(%s)\n",
        ((target_flags & 0x00002000)
         ? (store_p) ? "sd" : "ld"
         : (store_p) ? "sw" : "lw"),
        reg_names[regno],
        gp_offset - base_offset,
        reg_names[((base_reg_rtx)->fld[0].rtint)]);

  }
       gp_offset -= ((target_flags & 0x00002000) ? 8 : 4);
     }
 }
    }
  else
    {
      base_reg_rtx = (rtx)0;
      base_offset = 0;
    }


  if (fmask)
    {
      int fp_inc = ((target_flags & 0x00000200) || (target_flags & 0x00020000)) ? 1 : 2;
      int fp_size = fp_inc * ((target_flags & 0x00000200) ? 8 : 4);


      fp_offset = current_frame_info.fp_sp_offset;
      end_offset = fp_offset - (current_frame_info.fp_reg_size - fp_size);

      if (fp_offset < 0 || end_offset < 0)
 fatal ("fp_offset (%ld) or end_offset (%ld) is less than zero.",
        fp_offset, end_offset);

      else if (fp_offset < 32768)
 {
   base_reg_rtx = stack_pointer_rtx;
   base_offset = 0;
 }

      else if (base_reg_rtx != (rtx)0
        && (((unsigned long)(base_offset - fp_offset)) < 32768)
        && (((unsigned long)(base_offset - end_offset)) < 32768))
 {
   ;
 }

      else if (large_reg != (rtx)0
        && (((unsigned long)(large_offset - fp_offset)) < 32768)
        && (((unsigned long)(large_offset - end_offset)) < 32768))
 {
   base_reg_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 13));
   base_offset = large_offset;
   if (file == (FILE *)0)
     {
       if ((target_flags & 0x00000002))
  emit_insn (gen_adddi3 (base_reg_rtx, large_reg, stack_pointer_rtx));
       else
  emit_insn (gen_addsi3 (base_reg_rtx, large_reg, stack_pointer_rtx));
     }
   else
     fprintf (file, "\t%s\t%s,%s,%s\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       reg_names[(0 + 13)],
       reg_names[((large_reg)->fld[0].rtint)],
       reg_names[(0 + 29)]);
 }

      else
 {
   base_reg_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 13));
   base_offset = fp_offset;
   if (file == (FILE *)0)
     {
       emit_move_insn (base_reg_rtx, gen_rtx (CONST_INT, VOIDmode, (int) (fp_offset)));
       if ((target_flags & 0x00000002))
  emit_insn (gen_adddi3 (base_reg_rtx, base_reg_rtx, stack_pointer_rtx));
       else
  emit_insn (gen_addsi3 (base_reg_rtx, base_reg_rtx, stack_pointer_rtx));
     }
   else
     fprintf (file, "\tli\t%s,0x%.08lx\t# %ld\n\t%s\t%s,%s,%s\n",
       reg_names[(0 + 13)],
       (long)base_offset,
       (long)base_offset,
       (target_flags & 0x00000002) ? "daddu" : "addu",
       reg_names[(0 + 13)],
       reg_names[(0 + 13)],
       reg_names[(0 + 29)]);
 }

      for (regno = 63 -1; regno >= 32; regno -= fp_inc)
 {
   if ((((fmask) & (1L << (regno - 32))) != 0))
     {
       if (file == (FILE *)0)
  {
    n64_enum_machine_mode sz =
      (target_flags & 0x00020000) ? SFmode : DFmode;
    rtx reg_rtx = gen_rtx (REG, sz, regno);
    rtx mem_rtx = gen_rtx (MEM, sz,
      gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), base_reg_rtx,
        gen_rtx (CONST_INT, VOIDmode, (int) (fp_offset - base_offset))));

    if (store_p)
      emit_move_insn (mem_rtx, reg_rtx);
    else
      emit_move_insn (reg_rtx, mem_rtx);
  }
       else
  fprintf (file, "\t%s\t%s,%ld(%s)\n",
    ((target_flags & 0x00020000)
     ? ((store_p) ? "s.s" : "l.s")
     : ((store_p) ? "s.d" : "l.d")),
    reg_names[regno],
    fp_offset - base_offset,
    reg_names[((base_reg_rtx)->fld[0].rtint)]);


       fp_offset -= fp_size;
     }
 }
    }
}




void
function_prologue(FILE *file, int size) asm("_function_prologue");
void
function_prologue(FILE *file, int size)
{
  char *fnname;
  long tsize = current_frame_info.total_size;

  mips_output_filename (file, ((current_function_decl)->decl.filename));
  fnname = ((((((current_function_decl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr);

  inside_function = 1;
  fputs ("\t.ent\t", file);
  assemble_name (file, fnname);
  fputs ("\n", file);

  assemble_name (file, fnname);
  fputs (":\n", file);

  fprintf (file, "\t.frame\t%s,%d,%s\t\t# vars= %d, regs= %d/%d, args= %d, extra= %d\n",
    reg_names[ (frame_pointer_needed) ? (0 + 30) : (0 + 29) ],
    tsize,
    reg_names[31 + 0],
    current_frame_info.var_size,
    current_frame_info.num_gp,
    current_frame_info.num_fp,
    current_function_outgoing_args_size,
    current_frame_info.extra_size);

  fprintf (file, "\t.mask\t0x%08lx,%d\n\t.fmask\t0x%08lx,%d\n",
    current_frame_info.mask,
    current_frame_info.gp_save_offset,
    current_frame_info.fmask,
    current_frame_info.fp_save_offset);

  if ((target_flags & 0x00000400) && ! (0 && mips_isa >= 3))
    {
      char *sp_str = reg_names[(0 + 29)];

      fprintf (file, "\t.set\tnoreorder\n\t.cpload\t%s\n\t.set\treorder\n",
        reg_names[(0 + 25)]);
      if (tsize > 0)
 {
   fprintf (file, "\t%s\t%s,%s,%d\n",
     ((target_flags & 0x00000002) ? "dsubu" : "subu"),
     sp_str, sp_str, tsize);
   fprintf (file, "\t.cprestore %d\n", current_frame_info.args_size);
 }
    }
}




void
mips_expand_prologue(void) asm("_mips_expand_prologue");
void
mips_expand_prologue(void)
{
  int regno;
  long tsize;
  rtx tmp_rtx = (rtx)0;
  char *arg_name = (char *)0;
  tree fndecl = current_function_decl;
  tree fntype = ((fndecl)->common.type);
  tree fnargs = (((n64_enum_tree_code) (fntype)->common.code) != METHOD_TYPE)
   ? ((fndecl)->decl.arguments)
   : 0;
  rtx next_arg_reg;
  int i;
  tree next_arg;
  tree cur_arg;
  CUMULATIVE_ARGS args_so_far;


  if (aggregate_value_p (((fndecl)->decl.result))
      && ! current_function_returns_pcc_struct
      && struct_value_incoming_rtx == 0)
    {
      tree type = build_pointer_type (fntype);
      tree function_result_decl = build_decl (PARM_DECL, (tree) 
                                                        ((void *)0)
                                                                 , type);
      ((function_result_decl)->decl.initial) = type;
      ((function_result_decl)->common.chain) = fnargs;
      fnargs = function_result_decl;
    }



  init_cumulative_args (&args_so_far, fntype, (rtx)0);
  regno = (0 + 4);

  for (cur_arg = fnargs; cur_arg != (tree)0; cur_arg = next_arg)
    {
      tree passed_type = ((cur_arg)->decl.initial);
      n64_enum_machine_mode passed_mode = ((passed_type)->type.mode);
      rtx entry_parm;

      if (((passed_type)->type.needs_constructing_flag))
 {
   passed_type = build_pointer_type (passed_type);
   passed_mode = ((target_flags & 0x00000002) ? DImode : SImode);
 }

      entry_parm = function_arg( &args_so_far, passed_mode, passed_type, 1);

      if (entry_parm)
 {
   int words;


   if (((entry_parm)->mode) == BLKmode)
     words = (int_size_in_bytes (passed_type) + 3) / 4;
   else
     words = ((mode_size[(int)(((entry_parm)->mode))]) + 3) / 4;

   regno = ((entry_parm)->fld[0].rtint) + words - 1;
 }
      else
 {
   regno = (0 + 7)+1;
   break;
 }

      function_arg_advance (&args_so_far, passed_mode, passed_type, 1);

      next_arg = ((cur_arg)->common.chain);
      if (next_arg == (tree)0)
 {
   if (((cur_arg)->decl.name))
     arg_name = ((((cur_arg)->decl.name))->identifier.pointer);

   break;
 }
    }
  next_arg_reg = function_arg( &args_so_far, VOIDmode, void_type_node, 1);
  if (next_arg_reg != (rtx)0 && ((next_arg_reg)->code) == PARALLEL)
    {
      rtvec adjust = ((next_arg_reg)->fld[0].rtvec);
      int num = ((adjust)->num_elem);

      for (i = 0; i < num; i++)
 {
   rtx pattern = ((adjust)->elem[(i)].rtx);
   if (((pattern)->code) != SET
       || ((((pattern)->fld[1].rtx))->code) != ASHIFT)
     abort_with_insn (pattern, "Insn is not a shift");

   ((((pattern)->fld[1].rtx))->code = (ASHIFTRT));
   emit_insn (pattern);
 }
    }

  tsize = compute_frame_size (get_frame_size ());



  if ((! 0 || mips_isa < 3)
      && ((((fntype)->type.values) != 0
    && (((tree_last (((fntype)->type.values)))->list.value) != void_type_node))
   || (arg_name != (char *)0
       && ((arg_name[0] == '_' && strcmp (arg_name, "__builtin_va_alist") == 0)
    || (arg_name[0] == 'v' && strcmp (arg_name, "va_alist") == 0)))))
    {
      int offset = (regno - (0 + 4)) * ((target_flags & 0x00002000) ? 8 : 4);
      rtx ptr = stack_pointer_rtx;


      if ((target_flags & 0x00000400) && ! (0 && mips_isa >= 3))
 offset += tsize;

      for (; regno <= (0 + 7); regno++)
 {
   if (offset != 0)
     ptr = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), stack_pointer_rtx, gen_rtx (CONST_INT, VOIDmode, (int) (offset)));
   emit_move_insn (gen_rtx (MEM, word_mode, ptr),
     gen_rtx (REG, word_mode, regno));
   offset += ((target_flags & 0x00002000) ? 8 : 4);
 }
    }

  if (tsize > 0)
    {
      rtx tsize_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (tsize));


      if (!(target_flags & 0x00000400) || (0 && mips_isa >= 3))
 {
   if (tsize > 32767)
     {
       tmp_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 12));
       emit_move_insn (tmp_rtx, tsize_rtx);
       tsize_rtx = tmp_rtx;
     }

   if ((target_flags & 0x00000002))
     emit_insn (gen_subdi3 (stack_pointer_rtx, stack_pointer_rtx,
       tsize_rtx));
   else
     emit_insn (gen_subsi3 (stack_pointer_rtx, stack_pointer_rtx,
       tsize_rtx));
 }

      save_restore_insns (1, tmp_rtx, tsize, (FILE *)0);

      if (frame_pointer_needed)
 {
   if ((target_flags & 0x00002000))
     emit_insn (gen_movdi (frame_pointer_rtx, stack_pointer_rtx));
   else
     emit_insn (gen_movsi (frame_pointer_rtx, stack_pointer_rtx));
 }

      if ((target_flags & 0x00000400) && (0 && mips_isa >= 3))
 emit_insn (gen_loadgp (((((current_function_decl)->decl.rtl))->fld[0].rtx)));
    }




  if (profile_flag || profile_block_flag)
    emit_insn (gen_blockage ());
}







void
function_epilogue(FILE *file, int size) asm("_function_epilogue");
void
function_epilogue(FILE *file, int size)
{
  char *fnname;
  long tsize;
  char *sp_str = reg_names[(0 + 29)];
  char *t1_str = reg_names[(0 + 12)];
  rtx epilogue_delay = current_function_epilogue_delay_list;
  int noreorder = (epilogue_delay != 0);
  int noepilogue = 0;
  int load_nop = 0;
  int load_only_r31;
  rtx tmp_rtx = (rtx)0;
  rtx restore_rtx;
  int i;






  if (dslots_number_nops > 0)
    {
      if (dslots_number_nops == 1)
 {
   dslots_number_nops = 0;
   dslots_load_filled++;
 }
      else
 {
   while (--dslots_number_nops > 0)
     fputs ("\t#nop\n", asm_out_file);
 }
    }

  if (set_noat != 0)
    {
      set_noat = 0;
      fputs ("\t.set\tat\n", file);
      error ("internal gcc error: .set noat left on in epilogue");
    }

  if (set_nomacro != 0)
    {
      set_nomacro = 0;
      fputs ("\t.set\tmacro\n", file);
      error ("internal gcc error: .set nomacro left on in epilogue");
    }

  if (set_noreorder != 0)
    {
      set_noreorder = 0;
      fputs ("\t.set\treorder\n", file);
      error ("internal gcc error: .set noreorder left on in epilogue");
    }

  if (set_volatile != 0)
    {
      set_volatile = 0;
      fprintf (file, "\t%s.set\tnovolatile\n", ((!(target_flags & 0x00000010))) ? "" : "#");
      error ("internal gcc error: .set volatile left on in epilogue");
    }

  size = (((size)+7) & ~7);
  tsize = (!current_frame_info.initialized)
  ? compute_frame_size (size)
  : current_frame_info.total_size;

  if (tsize == 0 && epilogue_delay == 0)
    {
      rtx insn = get_last_insn ();



      if (((insn)->code) == NOTE)
 insn = prev_nonnote_insn (insn);
      if (insn && ((insn)->code) == BARRIER)
 noepilogue = 1;

      noreorder = 0;
    }

  if (!noepilogue)
    {




      if (noreorder)
 fprintf (file, "\t.set\tnoreorder\n");

      if (tsize > 32767)
 {
   fprintf (file, "\tli\t%s,0x%.08lx\t# %ld\n", t1_str, (long)tsize, (long)tsize);
   tmp_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 12));
 }

      if (frame_pointer_needed)
 fprintf (file, "\tmove\t%s,%s\t\t\t# sp not trusted here\n",
   sp_str, reg_names[(0 + 30)]);

      save_restore_insns (0, tmp_rtx, tsize, file);

      load_only_r31 = (((current_frame_info.mask
    & ~ ((target_flags & 0x00000400) && ! (0 && mips_isa >= 3)
         ? (1 << ((0 + 28) - 0)) : 0))
   == ((long) 0x80000000))
         && current_frame_info.fmask == 0);

      if (noreorder)
 {





   if (load_only_r31)
     {
       if (epilogue_delay)
    final_scan_insn (((epilogue_delay)->fld[0].rtx),
       file,
       1,
       -2,
       1);
       else
  {
    fprintf (file, "\tnop\n");
    load_nop = 1;
  }
     }

   fprintf (file, "\tj\t%s\n", reg_names[0 + 31]);

   if (tsize > 32767)
     fprintf (file, "\t%s\t%s,%s,%s\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       sp_str, sp_str, t1_str);

   else if (tsize > 0)
     fprintf (file, "\t%s\t%s,%s,%d\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       sp_str, sp_str, tsize);

   else if (!load_only_r31 && epilogue_delay != 0)
     final_scan_insn (((epilogue_delay)->fld[0].rtx),
        file,
        1,
        -2,
        1);

   fprintf (file, "\t.set\treorder\n");
 }

      else
 {
   if (tsize > 32767)
     fprintf (file, "\t%s\t%s,%s,%s\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       sp_str, sp_str, t1_str);

   else if (tsize > 0)
     fprintf (file, "\t%s\t%s,%s,%d\n",
       (target_flags & 0x00000002) ? "daddu" : "addu",
       sp_str, sp_str, tsize);

   fprintf (file, "\tj\t%s\n", reg_names[0 + 31]);
 }
    }




  fnname = ((((((current_function_decl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr);

  fputs ("\t.end\t", file);
  assemble_name (file, fnname);
  fputs ("\n", file);

  if ((target_flags & 0x00000040))
    {
      int num_gp_regs = current_frame_info.gp_reg_size / 4;
      int num_fp_regs = current_frame_info.fp_reg_size / 8;
      int num_regs = num_gp_regs + num_fp_regs;
      char *name = fnname;

      if (name[0] == '*')
 name++;

      dslots_load_total += num_regs;

      if (!noepilogue)
 dslots_jump_total++;

      if (noreorder)
 {
   dslots_load_filled += num_regs;




   if (load_only_r31 && epilogue_delay == 0)
     dslots_load_filled--;

   if (tsize > 0 || (!load_only_r31 && epilogue_delay != 0))
     dslots_jump_filled++;
 }

      fprintf (
              (__acrt_iob_func(2))
                    ,
        "%-20s fp=%c leaf=%c alloca=%c setjmp=%c stack=%4ld arg=%3ld reg=%2d/%d delay=%3d/%3dL %3d/%3dJ refs=%3d/%3d/%3d",
        name,
        (frame_pointer_needed) ? 'y' : 'n',
        ((current_frame_info.mask & ((long) 0x80000000)) != 0) ? 'n' : 'y',
        (current_function_calls_alloca) ? 'y' : 'n',
        (current_function_calls_setjmp) ? 'y' : 'n',
        (long)current_frame_info.total_size,
        (long)current_function_outgoing_args_size,
        num_gp_regs, num_fp_regs,
        dslots_load_total, dslots_load_filled,
        dslots_jump_total, dslots_jump_filled,
        num_refs[0], num_refs[1], num_refs[2]);

      if (0 > prev_half_pic_ptrs)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , " half-pic=%3d", 0 - prev_half_pic_ptrs);
   prev_half_pic_ptrs = 0;
 }

      if (0 > prev_half_pic_refs)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , " pic-ref=%3d", 0 - prev_half_pic_refs);
   prev_half_pic_refs = 0;
 }

      fputc ('\n', 
                  (__acrt_iob_func(2))
                        );
    }


  inside_function = 0;
  ignore_line_number = 0;
  dslots_load_total = 0;
  dslots_jump_total = 0;
  dslots_load_filled = 0;
  dslots_jump_filled = 0;
  num_refs[0] = 0;
  num_refs[1] = 0;
  num_refs[2] = 0;
  mips_load_reg = (rtx)0;
  mips_load_reg2 = (rtx)0;
  current_frame_info = zero_frame_info;





  if ((target_flags & 0x00000008))
    asm_out_file = asm_out_data_file;
}




void
mips_expand_epilogue(void) asm("_mips_expand_epilogue");
void
mips_expand_epilogue(void)
{
  long tsize = current_frame_info.total_size;
  rtx tsize_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (tsize));
  rtx tmp_rtx = (rtx)0;

  if (tsize > 32767)
    {
      tmp_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 12));
      emit_move_insn (tmp_rtx, tsize_rtx);
      tsize_rtx = tmp_rtx;
    }

  if (tsize > 0)
    {
      if (frame_pointer_needed)
 {
   if ((target_flags & 0x00000002))
     emit_insn (gen_movdi (stack_pointer_rtx, frame_pointer_rtx));
   else
     emit_insn (gen_movsi (stack_pointer_rtx, frame_pointer_rtx));
 }

      save_restore_insns (0, tmp_rtx, tsize, (FILE *)0);

      if ((target_flags & 0x00000002))
 emit_insn (gen_adddi3 (stack_pointer_rtx, stack_pointer_rtx,
          tsize_rtx));
      else
 emit_insn (gen_addsi3 (stack_pointer_rtx, stack_pointer_rtx,
          tsize_rtx));
    }

  emit_jump_insn (gen_return_internal (gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), 0 +31)));
}







int
mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
int
mips_epilogue_delay_slots(void)
{
  if (!current_frame_info.initialized)
    (void) compute_frame_size (get_frame_size ());

  if (current_frame_info.total_size == 0)
    return 1;

  if (current_frame_info.mask == ((long) 0x80000000) && current_frame_info.fmask == 0)
    return 1;

  return 0;
}






int
simple_epilogue_p(void) asm("_simple_epilogue_p");
int
simple_epilogue_p(void)
{
  if (!reload_completed)
    return 0;

  if (current_frame_info.initialized)
    return current_frame_info.total_size == 0;

  return (compute_frame_size (get_frame_size ())) == 0;
}




mips_select_rtx_section(n64_enum_machine_mode mode, rtx x)
{
  if ((target_flags & 0x00008000))
    {


      const_section ();
    }
  else
    {







 const_section ();
    }
}




mips_select_section(tree decl, int reloc)
{
  int size = int_size_in_bytes (((decl)->common.type));

  if ((target_flags & 0x00004000)
      && ((n64_enum_tree_code) (decl)->common.code) == STRING_CST
      && !flag_writable_strings)
    {




      text_section ();
    }
  else if ((target_flags & 0x00008000))
    {



      if (((((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
     && ((decl)->common.readonly_flag) && !((decl)->common.side_effects_flag)
     && ((decl)->decl.initial)
     && (((decl)->decl.initial) == error_mark_node
  || ((((decl)->decl.initial))->common.constant_flag)))

    || (((n64_enum_tree_code) (decl)->common.code) != VAR_DECL
        && (((n64_enum_tree_code) (decl)->common.code) != STRING_CST
     || !flag_writable_strings)))
   && ! (flag_pic && reloc))
 const_section ();


      else
 data_section ();
    }
  else
    {





             if (((((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
   && ((decl)->common.readonly_flag) && !((decl)->common.side_effects_flag)
   && ((decl)->decl.initial)
   && (((decl)->decl.initial) == error_mark_node
       || ((((decl)->decl.initial))->common.constant_flag)))

  || (((n64_enum_tree_code) (decl)->common.code) != VAR_DECL
      && (((n64_enum_tree_code) (decl)->common.code) != STRING_CST
   || !flag_writable_strings)))
        && ! (flag_pic && reloc))
 const_section ();
      else
 data_section ();
    }
}
n64_enum_reg_class
mips_secondary_reload_class(n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, rtx x, int in_p) asm("_mips_secondary_reload_class");
n64_enum_reg_class
mips_secondary_reload_class(n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, rtx x, int in_p)
{
  int regno = -1;

  if (((x)->code) == REG || ((x)->code) == SUBREG)
    regno = true_regnum (x);




  if (cxx_class == HILO_REG && regno != 0 + 0)
    {
      if (! in_p
   && ((unsigned) ((regno) - 0) < (31 - 0 + 1))
   && (mode_size[(int)(mode)]) <= (mode_size[(int)(SImode)]))
 return NO_REGS;
      return GR_REGS;
    }
  if (regno == (64 + 2))
    {
      if (in_p
   && cxx_class == GR_REGS
   && (mode_size[(int)(mode)]) <= (mode_size[(int)(SImode)]))
 return NO_REGS;
      return GR_REGS;
    }



  if (cxx_class == HI_REG || cxx_class == LO_REG || cxx_class == MD_REGS)
    {
      if (((unsigned) ((regno) - 0) < (31 - 0 + 1)))
 return NO_REGS;
      return GR_REGS;
    }
  if (((unsigned) ((regno) - 64) < (66 - 64 + 1)))
    {
      if (cxx_class == GR_REGS)
 return NO_REGS;
      return GR_REGS;
    }

  return NO_REGS;
}

