Windows N64 KMC GCC 2.7.2 and binutils 2.6: GNU C++98 host source port.
GPL-2.0-or-later. See COPYING and COPYING.LIB; see COPYING.MinGW for the system runtime.
Original target algorithms and C game output are retained. All 170 project implementation
translation units are compiled by G++; the original C build supplies configuration
and typed K&R definitions. Generic MinGW system libraries retain their upstream languages.
CPP-BUILD.json lists source and object checksums. Corresponding source, generated C++
and reproducible recipes: gcc-2.7.2-kmc-windows-cpp-source-v3.zip alongside this archive.
Run: python3 recipe/build_kmc_cpp.py sources NEW_BUILD_DIRECTORY
Requires native GCC, Python 3.10+, make, patch, i686 MinGW GCC/G++ and binutils.
Upstreams: decompals/mips-gcc-2.7.2@43d1cdb67ed135879869b5266f01efaaada5e35a
and decompals/mips-binutils-2.6@54514ded39ceb32165a125ddba04ca5b551773a2.
Host changes: recipe/patches/*-windows.patch, windows_spawn.c and windows_tmpfile.c.
C++ transformation: recipe/port_kmc_cpp.py; complete build: recipe/build_kmc_cpp.py.
