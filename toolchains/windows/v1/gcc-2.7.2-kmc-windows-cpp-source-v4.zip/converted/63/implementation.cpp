// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int call_insn_operand(...) asm("_call_insn_operand");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;




extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

extern rtx gen_split_6(...) asm("_gen_split_6");
extern rtx gen_split_7(...) asm("_gen_split_7");
extern rtx gen_split_9(...) asm("_gen_split_9");
extern rtx gen_split_10(...) asm("_gen_split_10");
extern rtx gen_split_19(...) asm("_gen_split_19");
extern rtx gen_split_20(...) asm("_gen_split_20");
extern rtx gen_split_22(...) asm("_gen_split_22");
extern rtx gen_split_23(...) asm("_gen_split_23");
extern rtx gen_split_88(...) asm("_gen_split_88");
extern rtx gen_split_91(...) asm("_gen_split_91");
extern rtx gen_split_94(...) asm("_gen_split_94");
extern rtx gen_split_98(...) asm("_gen_split_98");
extern rtx gen_split_101(...) asm("_gen_split_101");
extern rtx gen_split_152(...) asm("_gen_split_152");
extern rtx gen_split_156(...) asm("_gen_split_156");
extern rtx gen_split_174(...) asm("_gen_split_174");
extern rtx gen_split_178(...) asm("_gen_split_178");
extern rtx gen_split_185(...) asm("_gen_split_185");
extern rtx gen_split_186(...) asm("_gen_split_186");
extern rtx gen_split_188(...) asm("_gen_split_188");
extern rtx gen_split_189(...) asm("_gen_split_189");
extern rtx gen_split_195(...) asm("_gen_split_195");
extern rtx gen_split_196(...) asm("_gen_split_196");
extern rtx gen_split_198(...) asm("_gen_split_198");
extern rtx gen_split_199(...) asm("_gen_split_199");
extern rtx gen_split_205(...) asm("_gen_split_205");
extern rtx gen_split_206(...) asm("_gen_split_206");
extern rtx gen_split_208(...) asm("_gen_split_208");
extern rtx gen_split_209(...) asm("_gen_split_209");
extern rtx gen_split_239(...) asm("_gen_split_239");
extern rtx gen_split_241(...) asm("_gen_split_241");
extern rtx gen_split_246(...) asm("_gen_split_246");
extern rtx gen_split_248(...) asm("_gen_split_248");
extern rtx gen_split_254(...) asm("_gen_split_254");
extern rtx gen_split_256(...) asm("_gen_split_256");
extern rtx gen_split_264(...) asm("_gen_split_264");
extern rtx gen_split_266(...) asm("_gen_split_266");
extern rtx gen_split_272(...) asm("_gen_split_272");
extern rtx gen_split_274(...) asm("_gen_split_274");
extern rtx gen_split_282(...) asm("_gen_split_282");
extern rtx gen_split_284(...) asm("_gen_split_284");
rtx recog_operand[10];

rtx *recog_operand_loc[10];

rtx *recog_dup_loc[2];

char recog_dup_num[2];



int
recog_1(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_1");
int
recog_1(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[1].rtx);
  switch (((x1)->mode))
    {
    case SImode:
      switch (((x1)->code))
 {
 case PLUS:
   goto L444;
 case MINUS:
   goto L91;
 case MULT:
   goto L179;
 case TRUNCATE:
   goto L309;
 case DIV:
   goto L735;
 case MOD:
   goto L769;
 case UDIV:
   goto L803;
 case UMOD:
   goto L837;
 case ABS:
   goto L867;
 case FFS:
   goto L892;
 case NEG:
   goto L909;
 case NOT:
   goto L944;
 case AND:
   goto L962;
 case IOR:
   goto L982;
 case XOR:
   goto L997;
 case ZERO_EXTEND:
   goto L1051;
 case SIGN_EXTEND:
   goto L1098;
 case ASHIFT:
   goto L1335;
 case ASHIFTRT:
   goto L1407;
 case LSHIFTRT:
   goto L1479;
 case EQ:
   goto L1615;
 case NE:
   goto L1645;
 case GT:
   goto L1675;
 case GE:
   goto L1685;
 case LT:
   goto L1705;
 case LE:
   goto L1715;
 case GTU:
   goto L1745;
 case GEU:
   goto L1755;
 case LTU:
   goto L1775;
 case LEU:
   goto L1785;
 case IF_THEN_ELSE:
   goto L2047;
 }
    }
  if (((x1)->code) == UNSPEC && ((x1)->fld[1].rtint) == 0 && ((x1)->fld[0].rtvec->num_elem) == 1 && 1)
    goto L1182;
  goto ret0;

  L444:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == MULT && 1)
    goto L445;
  if (reg_or_0_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L14;
    }
  goto ret0;

  L445:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L446;
    }
  goto ret0;

  L446:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L447;
    }
  goto ret0;

  L447:
  x2 = ((x1)->fld[1].rtx);
  if (rtx_equal_p (x2, ro[0]) && pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00040000))
      {
 *pnum_clobbers = 2;
 return 45;
      }
  goto ret0;

  L14:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768)
 return 3;
      }
  goto ret0;

  L91:
  x2 = ((x1)->fld[0].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L92;
    }
  goto ret0;

  L92:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768)
 return 16;
      }
  goto ret0;

  L179:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L180;
    }
  goto ret0;

  L180:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  if (register_operand (x2, SImode))
    goto L198;
  L216:
  if (pnum_clobbers != 0 && register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00040000))
 {
   *pnum_clobbers = 3;
   return 31;
 }
      }
  goto ret0;

  L198:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x2;
      if (mips_cpu != PROCESSOR_R4000)
 {
   *pnum_clobbers = 2;
   return 29;
 }
      }
  L199:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x2;
      if (mips_cpu == PROCESSOR_R4000)
 {
   *pnum_clobbers = 3;
   return 30;
 }
      }
  goto L216;

  L309:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case LSHIFTRT:
      goto L310;
    case ASHIFTRT:
      goto L1034;
    case ASHIFT:
      goto L1046;
    case SUBREG:
    case REG:
      if (register_operand (x2, DImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 104;
   }
    }
  goto ret0;

  L310:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) != DImode)
    goto ret0;
  if (((x3)->code) == MULT && 1)
    goto L311;
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1041;
    }
  goto ret0;

  L311:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) != DImode)
    goto ret0;
  switch (((x4)->code))
    {
    case SIGN_EXTEND:
      goto L312;
    case ZERO_EXTEND:
      goto L375;
    }
  goto ret0;

  L312:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L313;
    }
  goto ret0;

  L313:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == SIGN_EXTEND && 1)
    goto L314;
  goto ret0;

  L314:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L315;
    }
  goto ret0;

  L315:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 32 && pnum_clobbers != 0 && 1)
    {
      *pnum_clobbers = 2;
      return 38;
    }
  goto ret0;

  L375:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L376;
    }
  goto ret0;

  L376:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == ZERO_EXTEND && 1)
    goto L377;
  goto ret0;

  L377:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L378;
    }
  goto ret0;

  L378:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 32 && pnum_clobbers != 0 && 1)
    {
      *pnum_clobbers = 2;
      return 42;
    }
  goto ret0;

  L1041:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000))
 return 108;
      }
  goto ret0;

  L1034:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1035;
    }
  goto ret0;

  L1035:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000))
 return 107;
      }
  goto ret0;

  L1046:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1047;
    }
  goto ret0;

  L1047:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000))
 return 109;
      }
  goto ret0;

  L735:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L736;
    }
  goto ret0;

  L736:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, SImode))
    {
      ro[2] = x2;
      if (!optimize)
 {
   *pnum_clobbers = 3;
   return 64;
 }
      }
  goto ret0;

  L769:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L770;
    }
  goto ret0;

  L770:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, SImode))
    {
      ro[2] = x2;
      if (!optimize)
 {
   *pnum_clobbers = 3;
   return 66;
 }
      }
  goto ret0;

  L803:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L804;
    }
  goto ret0;

  L804:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, SImode))
    {
      ro[2] = x2;
      if (!optimize)
 {
   *pnum_clobbers = 3;
   return 68;
 }
      }
  goto ret0;

  L837:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L838;
    }
  goto ret0;

  L838:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, SImode))
    {
      ro[2] = x2;
      if (!optimize)
 {
   *pnum_clobbers = 3;
   return 70;
 }
      }
  goto ret0;

  L867:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      return 74;
    }
  goto ret0;

  L892:
  x2 = ((x1)->fld[0].rtx);
  if (pnum_clobbers != 0 && register_operand (x2, SImode))
    {
      ro[1] = x2;
      *pnum_clobbers = 2;
      return 78;
    }
  goto ret0;

  L909:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      return 80;
    }
  goto ret0;

  L944:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  if (((x2)->code) == IOR && 1)
    goto L945;
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      return 86;
    }
  goto ret0;

  L945:
  x3 = ((x2)->fld[0].rtx);
  if (reg_or_0_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L946;
    }
  goto ret0;

  L946:
  x3 = ((x2)->fld[1].rtx);
  if (reg_or_0_operand (x3, SImode))
    {
      ro[2] = x3;
      return 89;
    }
  goto ret0;

  L962:
  x2 = ((x1)->fld[0].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L963;
    }
  goto ret0;

  L963:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 92;
    }
  goto ret0;

  L982:
  x2 = ((x1)->fld[0].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L983;
    }
  goto ret0;

  L983:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 96;
    }
  goto ret0;

  L997:
  x2 = ((x1)->fld[0].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L998;
    }
  goto ret0;

  L998:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 99;
    }
  goto ret0;

  L1051:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case HImode:
      if (((x2)->code) == TRUNCATE && 1)
 goto L1052;
      if (nonimmediate_operand (x2, HImode))
 {
   ro[1] = x2;
   return 115;
 }
      break;
    case QImode:
      if (((x2)->code) == TRUNCATE && 1)
 goto L1057;
      if (nonimmediate_operand (x2, QImode))
 {
   ro[1] = x2;
   return 118;
 }
    }
  goto ret0;

  L1052:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      if ((target_flags & 0x00002000))
 return 110;
      }
  goto ret0;

  L1057:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      if ((target_flags & 0x00002000))
 return 111;
      }
  goto ret0;

  L1098:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case HImode:
      if (memory_operand (x2, HImode))
 {
   ro[1] = x2;
   return 125;
 }
      break;
    case QImode:
      if (memory_operand (x2, QImode))
 {
   ro[1] = x2;
   return 129;
 }
    }
  goto ret0;

  L1335:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1336;
    }
  goto ret0;

  L1336:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 181;
    }
  goto ret0;

  L1407:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1408;
    }
  goto ret0;

  L1408:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 191;
    }
  goto ret0;

  L1479:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1480;
    }
  goto ret0;

  L1480:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 201;
    }
  goto ret0;

  L1615:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1616;
    }
  goto ret0;

  L1616:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->code) == CONST_INT && ((x2)->fld[0].rtwint) == 0 && 1)
    return 236;
  L1626:
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 238;
      }
  goto ret0;

  L1645:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1646;
    }
  goto ret0;

  L1646:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->code) == CONST_INT && ((x2)->fld[0].rtwint) == 0 && 1)
    return 243;
  L1656:
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 245;
      }
  goto ret0;

  L1675:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1676;
    }
  goto ret0;

  L1676:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[2] = x2;
      return 250;
    }
  goto ret0;

  L1685:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1686;
    }
  goto ret0;

  L1686:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 253;
      }
  goto ret0;

  L1705:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1706;
    }
  goto ret0;

  L1706:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 258;
    }
  goto ret0;

  L1715:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1726;
    }
  goto ret0;

  L1726:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 263;
      }
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[2] = x2;
      if (((recog_operand[2])->fld[0].rtwint) < 32767)
 return 261;
      }
  goto ret0;

  L1745:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1746;
    }
  goto ret0;

  L1746:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[2] = x2;
      return 268;
    }
  goto ret0;

  L1755:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1756;
    }
  goto ret0;

  L1756:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 271;
      }
  goto ret0;

  L1775:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1776;
    }
  goto ret0;

  L1776:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      return 276;
    }
  goto ret0;

  L1785:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1796;
    }
  goto ret0;

  L1796:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000))
 return 281;
      }
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[2] = x2;
      if (((recog_operand[2])->fld[0].rtwint) < 32767)
 return 279;
      }
  goto ret0;

  L2047:
  x2 = ((x1)->fld[0].rtx);
  if (equality_op (x2, VOIDmode))
    {
      ro[4] = x2;
      goto L2048;
    }
  L2055:
  if (equality_op (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L2056;
    }
  goto ret0;

  L2048:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L2049;
    }
  goto L2055;

  L2049:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2050;
  goto L2055;

  L2050:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[2] = x2;
      goto L2051;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L2055;

  L2051:
  x2 = ((x1)->fld[2].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[3] = x2;
      if (mips_isa >= 4)
 return 328;
      }
  x2 = ((x1)->fld[0].rtx);
  goto L2055;

  L2056:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L2057;
  goto ret0;

  L2057:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2058;
  goto ret0;

  L2058:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L2059;
    }
  goto ret0;

  L2059:
  x2 = ((x1)->fld[2].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[2] = x2;
      if (mips_isa >= 4)
 return 329;
      }
  goto ret0;

  L1182:
  x2 = ((x1)->fld[0].rtvec->elem[0].rtx);
  if (general_operand (x2, QImode))
    {
      ro[1] = x2;
      return 148;
    }
  goto ret0;
 ret0: return -1;
}

int
recog_2(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_2");
int
recog_2(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != DImode)
    goto ret0;
  switch (((x1)->code))
    {
    case PLUS:
      goto L463;
    case SIGN_EXTEND:
      goto L75;
    case MINUS:
      goto L148;
    case MULT:
      goto L266;
    case TRUNCATE:
      goto L397;
    case DIV:
      goto L752;
    case MOD:
      goto L786;
    case UDIV:
      goto L820;
    case UMOD:
      goto L854;
    case ABS:
      goto L871;
    case FFS:
      goto L905;
    case NEG:
      goto L920;
    case NOT:
      goto L950;
    case AND:
      goto L967;
    case IOR:
      goto L987;
    case XOR:
      goto L1002;
    case ZERO_EXTEND:
      goto L1066;
    case ASHIFT:
      goto L1402;
    case ASHIFTRT:
      goto L1474;
    case LSHIFTRT:
      goto L1546;
    case EQ:
      goto L1620;
    case NE:
      goto L1650;
    case GT:
      goto L1680;
    case GE:
      goto L1695;
    case LT:
      goto L1710;
    case LE:
      goto L1720;
    case GTU:
      goto L1750;
    case GEU:
      goto L1765;
    case LTU:
      goto L1780;
    case LEU:
      goto L1790;
    case IF_THEN_ELSE:
      goto L2063;
    }
  goto ret0;

  L463:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == MULT && 1)
    goto L464;
  if (reg_or_0_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L71;
    }
  goto ret0;

  L464:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) != DImode)
    goto ret0;
  switch (((x3)->code))
    {
    case SIGN_EXTEND:
      goto L465;
    case ZERO_EXTEND:
      goto L511;
    }
  goto ret0;

  L465:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L466;
    }
  goto ret0;

  L466:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == SIGN_EXTEND && 1)
    goto L467;
  goto ret0;

  L467:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L468;
    }
  goto ret0;

  L468:
  x2 = ((x1)->fld[1].rtx);
  if (rtx_equal_p (x2, ro[0]) && 1)
    goto L492;
  goto ret0;

  L492:
  if (pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00040000) && ! (target_flags & 0x00002000))
      {
 *pnum_clobbers = 1;
 return 46;
      }
  L493:
  if (pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00040000) && (target_flags & 0x00002000))
      {
 *pnum_clobbers = 2;
 return 47;
      }
  goto ret0;

  L511:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L512;
    }
  goto ret0;

  L512:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == ZERO_EXTEND && 1)
    goto L513;
  goto ret0;

  L513:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L514;
    }
  goto ret0;

  L514:
  x2 = ((x1)->fld[1].rtx);
  if (rtx_equal_p (x2, ro[0]) && 1)
    goto L538;
  goto ret0;

  L538:
  if (pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00040000) && ! (target_flags & 0x00002000))
      {
 *pnum_clobbers = 1;
 return 48;
      }
  L539:
  if (pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00040000) && (target_flags & 0x00002000))
      {
 *pnum_clobbers = 2;
 return 49;
      }
  goto ret0;

  L71:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768))
 return 11;
      }
  goto ret0;

  L75:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      switch (((x2)->code))
 {
 case PLUS:
   goto L76;
 case MINUS:
   goto L154;
 case SUBREG:
 case MEM:
   if (memory_operand (x2, SImode))
     {
       ro[1] = x2;
       if ((target_flags & 0x00002000))
   return 121;
       }
 }
      break;
    case HImode:
      if (memory_operand (x2, HImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 123;
   }
      break;
    case QImode:
      if (memory_operand (x2, QImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 131;
   }
    }
  goto ret0;

  L76:
  x3 = ((x2)->fld[0].rtx);
  if (reg_or_0_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L77;
    }
  goto ret0;

  L77:
  x3 = ((x2)->fld[1].rtx);
  if (arith_operand (x3, SImode))
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000) && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768))
 return 12;
      }
  goto ret0;

  L154:
  x3 = ((x2)->fld[0].rtx);
  if (reg_or_0_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L155;
    }
  goto ret0;

  L155:
  x3 = ((x2)->fld[1].rtx);
  if (arith_operand (x3, SImode))
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000) && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768))
 return 25;
      }
  goto ret0;

  L148:
  x2 = ((x1)->fld[0].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L149;
    }
  goto ret0;

  L149:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != -32768))
 return 24;
      }
  goto ret0;

  L266:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case SIGN_EXTEND:
      goto L267;
    case ZERO_EXTEND:
      goto L330;
    case SUBREG:
    case REG:
      if (register_operand (x2, DImode))
 {
   ro[1] = x2;
   goto L233;
 }
    }
  goto ret0;

  L267:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L268;
    }
  goto ret0;

  L268:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == SIGN_EXTEND && 1)
    goto L269;
  goto ret0;

  L269:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    goto L289;
  goto ret0;

  L289:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x3;
      if (!(target_flags & 0x00002000))
 {
   *pnum_clobbers = 1;
   return 36;
 }
      }
  L290:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000))
 {
   *pnum_clobbers = 2;
   return 37;
 }
      }
  goto ret0;

  L330:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L331;
    }
  goto ret0;

  L331:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == ZERO_EXTEND && 1)
    goto L332;
  goto ret0;

  L332:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    goto L352;
  goto ret0;

  L352:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x3;
      if (!(target_flags & 0x00002000))
 {
   *pnum_clobbers = 1;
   return 40;
 }
      }
  L353:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x3;
      if ((target_flags & 0x00002000))
 {
   *pnum_clobbers = 2;
   return 41;
 }
      }
  goto ret0;

  L233:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    goto L251;
  goto ret0;

  L251:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && mips_cpu != PROCESSOR_R4000)
 {
   *pnum_clobbers = 2;
   return 33;
 }
      }
  L252:
  if (pnum_clobbers != 0 && 1)
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && mips_cpu == PROCESSOR_R4000)
 {
   *pnum_clobbers = 3;
   return 34;
 }
      }
  goto ret0;

  L397:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == TImode && ((x2)->code) == LSHIFTRT && 1)
    goto L398;
  goto ret0;

  L398:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == TImode && ((x3)->code) == MULT && 1)
    goto L399;
  goto ret0;

  L399:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) != TImode)
    goto ret0;
  switch (((x4)->code))
    {
    case SIGN_EXTEND:
      goto L400;
    case ZERO_EXTEND:
      goto L425;
    }
  goto ret0;

  L400:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, DImode))
    {
      ro[1] = x5;
      goto L401;
    }
  goto ret0;

  L401:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == TImode && ((x4)->code) == SIGN_EXTEND && 1)
    goto L402;
  goto ret0;

  L402:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, DImode))
    {
      ro[2] = x5;
      goto L403;
    }
  goto ret0;

  L403:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 64 && pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00002000))
      {
 *pnum_clobbers = 2;
 return 43;
      }
  goto ret0;

  L425:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, DImode))
    {
      ro[1] = x5;
      goto L426;
    }
  goto ret0;

  L426:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == TImode && ((x4)->code) == ZERO_EXTEND && 1)
    goto L427;
  goto ret0;

  L427:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, DImode))
    {
      ro[2] = x5;
      goto L428;
    }
  goto ret0;

  L428:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 64 && pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00002000))
      {
 *pnum_clobbers = 2;
 return 44;
      }
  goto ret0;

  L752:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L753;
    }
  goto ret0;

  L753:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 {
   *pnum_clobbers = 3;
   return 65;
 }
      }
  goto ret0;

  L786:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L787;
    }
  goto ret0;

  L787:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 {
   *pnum_clobbers = 3;
   return 67;
 }
      }
  goto ret0;

  L820:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L821;
    }
  goto ret0;

  L821:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 {
   *pnum_clobbers = 3;
   return 69;
 }
      }
  goto ret0;

  L854:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L855;
    }
  goto ret0;

  L855:
  x2 = ((x1)->fld[1].rtx);
  if (pnum_clobbers != 0 && nonmemory_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 {
   *pnum_clobbers = 3;
   return 71;
 }
      }
  goto ret0;

  L871:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      if ((target_flags & 0x00002000))
 return 75;
      }
  goto ret0;

  L905:
  x2 = ((x1)->fld[0].rtx);
  if (pnum_clobbers != 0 && register_operand (x2, DImode))
    {
      ro[1] = x2;
      if ((target_flags & 0x00002000))
 {
   *pnum_clobbers = 2;
   return 79;
 }
      }
  goto ret0;

  L920:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      if ((target_flags & 0x00002000))
 return 83;
      }
  goto ret0;

  L950:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  if (((x2)->code) == IOR && 1)
    goto L951;
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      return 87;
    }
  goto ret0;

  L951:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L952;
    }
  goto ret0;

  L952:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      return 90;
    }
  goto ret0;

  L967:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L968;
    }
  goto ret0;

  L968:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) || !(target_flags & 0x00800000))
 return 93;
      }
  L978:
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 95;
      }
  goto ret0;

  L987:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L988;
    }
  goto ret0;

  L988:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) || !(target_flags & 0x00800000))
 return 97;
      }
  goto ret0;

  L1002:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1003;
    }
  goto ret0;

  L1003:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) || !(target_flags & 0x00800000))
 return 100;
      }
  L1013:
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 102;
      }
  goto ret0;

  L1066:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (memory_operand (x2, SImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 114;
   }
      break;
    case HImode:
      if (nonimmediate_operand (x2, HImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 116;
   }
      break;
    case QImode:
      if (nonimmediate_operand (x2, QImode))
 {
   ro[1] = x2;
   if ((target_flags & 0x00002000))
     return 119;
   }
    }
  goto ret0;

  L1402:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1403;
    }
  goto ret0;

  L1403:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 190;
      }
  goto ret0;

  L1474:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1475;
    }
  goto ret0;

  L1475:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 200;
      }
  goto ret0;

  L1546:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1547;
    }
  goto ret0;

  L1547:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 210;
      }
  goto ret0;

  L1620:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1621;
    }
  goto ret0;

  L1621:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->code) == CONST_INT && ((x2)->fld[0].rtwint) == 0 && 1)
    if ((target_flags & 0x00002000))
      return 237;
  L1636:
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 240;
      }
  goto ret0;

  L1650:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1651;
    }
  goto ret0;

  L1651:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->code) == CONST_INT && ((x2)->fld[0].rtwint) == 0 && 1)
    if ((target_flags & 0x00002000))
      return 244;
  L1666:
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 247;
      }
  goto ret0;

  L1680:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1681;
    }
  goto ret0;

  L1681:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 251;
      }
  goto ret0;

  L1695:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1696;
    }
  goto ret0;

  L1696:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 255;
      }
  goto ret0;

  L1710:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1711;
    }
  goto ret0;

  L1711:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 259;
      }
  goto ret0;

  L1720:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1736;
    }
  goto ret0;

  L1736:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 265;
      }
  if (((x2)->code) == CONST_INT && small_int (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && ((recog_operand[2])->fld[0].rtwint) < 32767)
 return 262;
      }
  goto ret0;

  L1750:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1751;
    }
  goto ret0;

  L1751:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 269;
      }
  goto ret0;

  L1765:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1766;
    }
  goto ret0;

  L1766:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 273;
      }
  goto ret0;

  L1780:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1781;
    }
  goto ret0;

  L1781:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000))
 return 277;
      }
  goto ret0;

  L1790:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1806;
    }
  goto ret0;

  L1806:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000))
 return 283;
      }
  if (((x2)->code) == CONST_INT && small_int (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && ((recog_operand[2])->fld[0].rtwint) < 32767)
 return 280;
      }
  goto ret0;

  L2063:
  x2 = ((x1)->fld[0].rtx);
  if (equality_op (x2, VOIDmode))
    {
      ro[4] = x2;
      goto L2064;
    }
  L2071:
  if (equality_op (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L2072;
    }
  goto ret0;

  L2064:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L2065;
    }
  goto L2071;

  L2065:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2066;
  goto L2071;

  L2066:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[2] = x2;
      goto L2067;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L2071;

  L2067:
  x2 = ((x1)->fld[2].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[3] = x2;
      if (mips_isa >= 4)
 return 330;
      }
  x2 = ((x1)->fld[0].rtx);
  goto L2071;

  L2072:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L2073;
  goto ret0;

  L2073:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2074;
  goto ret0;

  L2074:
  x2 = ((x1)->fld[1].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L2075;
    }
  goto ret0;

  L2075:
  x2 = ((x1)->fld[2].rtx);
  if (reg_or_0_operand (x2, DImode))
    {
      ro[2] = x2;
      if (mips_isa >= 4)
 return 331;
      }
  goto ret0;
 ret0: return -1;
}

int
recog_3(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_3");
int
recog_3(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtx);
  switch (((x1)->mode))
    {
    case DFmode:
      if (register_operand (x1, DFmode))
 {
   ro[0] = x1;
   goto L2;
 }
    L1234:
      if (nonimmediate_operand (x1, DFmode))
 {
   ro[0] = x1;
   goto L1235;
 }
      break;
    case SFmode:
      if (register_operand (x1, SFmode))
 {
   ro[0] = x1;
   goto L7;
 }
    L1226:
      if (nonimmediate_operand (x1, SFmode))
 {
   ro[0] = x1;
   goto L1227;
 }
      break;
    case SImode:
      if (register_operand (x1, SImode))
 {
   ro[0] = x1;
   goto L12;
 }
    L1125:
      if (general_operand (x1, SImode))
 {
   ro[0] = x1;
   goto L1126;
 }
    L1202:
      if (nonimmediate_operand (x1, SImode))
 {
   ro[0] = x1;
   goto L1203;
 }
      break;
    case DImode:
      if (((x1)->code) == REG && ((x1)->fld[0].rtint) == 28 && 1)
 goto L1256;
    L68:
      if (register_operand (x1, DImode))
 {
   ro[0] = x1;
   goto L69;
 }
    L1149:
      if (general_operand (x1, DImode))
 {
   ro[0] = x1;
   goto L1150;
 }
    L1188:
      if (nonimmediate_operand (x1, DImode))
 {
   ro[0] = x1;
   goto L1189;
 }
      break;
    case HImode:
      if (register_operand (x1, HImode))
 {
   ro[0] = x1;
   goto L1024;
 }
    L1210:
      if (nonimmediate_operand (x1, HImode))
 {
   ro[0] = x1;
   goto L1211;
 }
      break;
    case QImode:
      if (register_operand (x1, QImode))
 {
   ro[0] = x1;
   goto L1028;
 }
    L1184:
      if (memory_operand (x1, QImode))
 {
   ro[0] = x1;
   goto L1185;
 }
    L1218:
      if (nonimmediate_operand (x1, QImode))
 {
   ro[0] = x1;
   goto L1219;
 }
      break;
    case CC_FPmode:
      switch (((x1)->code))
 {
 case REG:
   if (((x1)->fld[0].rtint) == 67 && 1)
     goto L1814;
 }
      break;
    case CC_REV_FPmode:
      switch (((x1)->code))
 {
 case REG:
   if (((x1)->fld[0].rtint) == 67 && 1)
     goto L1819;
 }
    }
  if (((x1)->code) == PC && 1)
    goto L1878;
  L1936:
  if (register_operand (x1, VOIDmode))
    {
      ro[0] = x1;
      goto L1937;
    }
  goto ret0;

  L2:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != DFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1234;
    }
  switch (((x1)->code))
    {
    case PLUS:
      goto L543;
    case MINUS:
      goto L557;
    case MULT:
      goto L159;
    case NEG:
      goto L571;
    case DIV:
      goto L601;
    case SQRT:
      goto L859;
    case ABS:
      goto L875;
    case FLOAT_EXTEND:
      goto L1114;
    case FLOAT:
      goto L1166;
    case IF_THEN_ELSE:
      goto L2095;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L543:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1234;
    }
  if (((x2)->code) == MULT && 1)
    goto L544;
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      goto L4;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L544:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[1] = x3;
      goto L545;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L545:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[2] = x3;
      goto L546;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L546:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 50;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L4:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 0;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L557:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1234;
    }
  if (((x2)->code) == MULT && 1)
    goto L558;
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      goto L588;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L558:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[1] = x3;
      goto L559;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L559:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[2] = x3;
      goto L560;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L560:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 52;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L588:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1234;
    }
  if (((x2)->code) == MULT && 1)
    goto L589;
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 13;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L589:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[2] = x3;
      goto L590;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L590:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[3] = x3;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 56;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L159:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      goto L160;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L160:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 26;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L571:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1234;
    }
  if (((x2)->code) == PLUS && 1)
    goto L572;
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 84;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L572:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == DFmode && ((x3)->code) == MULT && 1)
    goto L573;
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L573:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, DFmode))
    {
      ro[1] = x4;
      goto L574;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L574:
  x4 = ((x3)->fld[1].rtx);
  if (register_operand (x4, DFmode))
    {
      ro[2] = x4;
      goto L575;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L575:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DFmode))
    {
      ro[3] = x3;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 54;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L601:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      goto L602;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L602:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 58;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L859:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (mips_isa >= 2) && (! (target_flags & 0x00020000)))
 return 72;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L875:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 76;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L1114:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 132;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L1166:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (nonimmediate_operand (x2, SImode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
     return 137;
   }
      break;
    case DImode:
      if (nonimmediate_operand (x2, DImode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
     return 138;
   }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L2095:
  x2 = ((x1)->fld[0].rtx);
  if (equality_op (x2, VOIDmode))
    {
      ro[4] = x2;
      goto L2096;
    }
  L2103:
  if (equality_op (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L2104;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L2096:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L2097;
    }
  goto L2103;

  L2097:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2098;
  goto L2103;

  L2098:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      goto L2099;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L2103;

  L2099:
  x2 = ((x1)->fld[2].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 334;
      }
  x2 = ((x1)->fld[0].rtx);
  goto L2103;

  L2104:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L2105;
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L2105:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2106;
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L2106:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      goto L2107;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L2107:
  x2 = ((x1)->fld[2].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[2] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 335;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1234;

  L1235:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, DFmode))
    goto L1239;
  L1243:
  if (general_operand (x1, DFmode))
    {
      ro[1] = x1;
      if (((target_flags & 0x00000100) || (target_flags & 0x00020000))
   && (register_operand (recog_operand[0], DFmode)
       || register_operand (recog_operand[1], DFmode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (DFmode)])))
 return 173;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1239:
  ro[1] = x1;
  if ((! (target_flags & 0x00000100)) && !((target_flags & 0x00000200) && !(target_flags & 0x00002000))
   && (! (target_flags & 0x00020000))
   && (register_operand (recog_operand[0], DFmode)
       || register_operand (recog_operand[1], DFmode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (DFmode)])))
    return 171;
  L1240:
  ro[1] = x1;
  if ((! (target_flags & 0x00000100)) && ((target_flags & 0x00000200) && !(target_flags & 0x00002000))
   && (! (target_flags & 0x00020000))
   && (register_operand (recog_operand[0], DFmode)
       || register_operand (recog_operand[1], DFmode))
       || (((recog_operand [0])->code) == MEM
    && ((((recog_operand[1])->code) == CONST_INT
  && ((recog_operand[1])->fld[0].rtwint) == 0)
        || recog_operand[1] == (const_tiny_rtx[0][(int) (DFmode)]))))
    return 172;
  goto L1243;

  L7:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != SFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1226;
    }
  switch (((x1)->code))
    {
    case PLUS:
      goto L550;
    case MINUS:
      goto L564;
    case MULT:
      goto L164;
    case NEG:
      goto L579;
    case DIV:
      goto L606;
    case SQRT:
      goto L863;
    case ABS:
      goto L879;
    case FLOAT_TRUNCATE:
      goto L1017;
    case FLOAT:
      goto L1174;
    case IF_THEN_ELSE:
      goto L2079;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L550:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1226;
    }
  if (((x2)->code) == MULT && 1)
    goto L551;
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      goto L9;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L551:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[1] = x3;
      goto L552;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L552:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[2] = x3;
      goto L553;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L553:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 51;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L9:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)))
 return 1;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L564:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1226;
    }
  if (((x2)->code) == MULT && 1)
    goto L565;
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      goto L595;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L565:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[1] = x3;
      goto L566;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L566:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[2] = x3;
      goto L567;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L567:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 53;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L595:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1226;
    }
  if (((x2)->code) == MULT && 1)
    goto L596;
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)))
 return 14;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L596:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[2] = x3;
      goto L597;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L597:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[3] = x3;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 57;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L164:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      goto L165;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L165:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)))
 return 27;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L579:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SFmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1226;
    }
  if (((x2)->code) == PLUS && 1)
    goto L580;
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 85;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L580:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == SFmode && ((x3)->code) == MULT && 1)
    goto L581;
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L581:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SFmode))
    {
      ro[1] = x4;
      goto L582;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L582:
  x4 = ((x3)->fld[1].rtx);
  if (register_operand (x4, SFmode))
    {
      ro[2] = x4;
      goto L583;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L583:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SFmode))
    {
      ro[3] = x3;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 55;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L606:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      goto L607;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L607:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)))
 return 59;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L863:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (mips_isa >= 2))
 return 73;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L879:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 77;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L1017:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 103;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L1174:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (nonimmediate_operand (x2, SImode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)))
     return 139;
   }
      break;
    case DImode:
      if (nonimmediate_operand (x2, DImode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
     return 140;
   }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L2079:
  x2 = ((x1)->fld[0].rtx);
  if (equality_op (x2, VOIDmode))
    {
      ro[4] = x2;
      goto L2080;
    }
  L2087:
  if (equality_op (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L2088;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L2080:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L2081;
    }
  goto L2087;

  L2081:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2082;
  goto L2087;

  L2082:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      goto L2083;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L2087;

  L2083:
  x2 = ((x1)->fld[2].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[3] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 332;
      }
  x2 = ((x1)->fld[0].rtx);
  goto L2087;

  L2088:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L2089;
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L2089:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L2090;
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L2090:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      goto L2091;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L2091:
  x2 = ((x1)->fld[2].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[2] = x2;
      if (mips_isa >= 4 && (! (target_flags & 0x00000100)))
 return 333;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1226;

  L1227:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, SFmode))
    goto L1231;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1231:
  ro[1] = x1;
  if ((! (target_flags & 0x00000100))
   && (register_operand (recog_operand[0], SFmode)
       || register_operand (recog_operand[1], SFmode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (SFmode)])))
    return 168;
  L1232:
  ro[1] = x1;
  if ((target_flags & 0x00000100)
   && (register_operand (recog_operand[0], SFmode)
       || register_operand (recog_operand[1], SFmode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (SFmode)])))
    return 169;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;
 L12:
  tem = recog_1 (x0, insn, pnum_clobbers);
  if (tem >= 0) return tem;
  x1 = ((x0)->fld[0].rtx);
  goto L1125;

  L1126:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) == SImode && ((x1)->code) == FIX && 1)
    goto L1127;
  x1 = ((x0)->fld[0].rtx);
  goto L1202;

  L1127:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (pnum_clobbers != 0 && register_operand (x2, DFmode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
     {
       *pnum_clobbers = 2;
       return 133;
     }
   }
      break;
    case SFmode:
      if (pnum_clobbers != 0 && register_operand (x2, SFmode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)))
     {
       *pnum_clobbers = 2;
       return 134;
     }
   }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1202;

  L1203:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, SImode))
    goto L1207;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1207:
  ro[1] = x1;
  if ((target_flags & 0x00400000)
   && (register_operand (recog_operand[0], SImode)
       || register_operand (recog_operand[1], SImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 158;
  L1208:
  ro[1] = x1;
  if (!(target_flags & 0x00400000)
   && (register_operand (recog_operand[0], SImode)
       || register_operand (recog_operand[1], SImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 159;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1256:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->code) == UNSPEC_VOLATILE && ((x1)->fld[1].rtint) == 2 && ((x1)->fld[0].rtvec->num_elem) == 1 && 1)
    goto L1257;
  x1 = ((x0)->fld[0].rtx);
  goto L68;

  L1257:
  x2 = ((x1)->fld[0].rtvec->elem[0].rtx);
  if (pnum_clobbers != 0 && address_operand (x2, DImode))
    {
      ro[0] = x2;
      *pnum_clobbers = 1;
      return 175;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L68;
 L69:
  tem = recog_2 (x0, insn, pnum_clobbers);
  if (tem >= 0) return tem;
  x1 = ((x0)->fld[0].rtx);
  goto L1149;

  L1150:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) == DImode && ((x1)->code) == FIX && 1)
    goto L1151;
  x1 = ((x0)->fld[0].rtx);
  goto L1188;

  L1151:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (pnum_clobbers != 0 && register_operand (x2, DFmode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
     {
       *pnum_clobbers = 1;
       return 135;
     }
   }
      break;
    case SFmode:
      if (pnum_clobbers != 0 && register_operand (x2, SFmode))
 {
   ro[1] = x2;
   if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
     {
       *pnum_clobbers = 1;
       return 136;
     }
   }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1188;

  L1189:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, DImode))
    goto L1196;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1196:
  ro[1] = x1;
  if (!(target_flags & 0x00002000)
   && (register_operand (recog_operand[0], DImode)
       || register_operand (recog_operand[1], DImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (DImode)])))
    return 151;
  L1197:
  ro[1] = x1;
  if ((target_flags & 0x00002000)
   && (register_operand (recog_operand[0], DImode)
       || register_operand (recog_operand[1], DImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)
       || recog_operand[1] == (const_tiny_rtx[0][(int) (DImode)])))
    return 153;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1024:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != HImode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1210;
    }
  switch (((x1)->code))
    {
    case TRUNCATE:
      goto L1025;
    case ZERO_EXTEND:
      goto L1061;
    case SIGN_EXTEND:
      goto L1102;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1210;

  L1025:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      if ((target_flags & 0x00002000))
 return 105;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1210;

  L1061:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != QImode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1210;
    }
  if (((x2)->code) == TRUNCATE && 1)
    goto L1062;
  if (nonimmediate_operand (x2, QImode))
    {
      ro[1] = x2;
      return 117;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1210;

  L1062:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      if ((target_flags & 0x00002000))
 return 112;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1210;

  L1102:
  x2 = ((x1)->fld[0].rtx);
  if (memory_operand (x2, QImode))
    {
      ro[1] = x2;
      return 127;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1210;

  L1211:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, HImode))
    goto L1215;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1215:
  ro[1] = x1;
  if ((target_flags & 0x00400000)
   && (register_operand (recog_operand[0], HImode)
       || register_operand (recog_operand[1], HImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 162;
  L1216:
  ro[1] = x1;
  if (!(target_flags & 0x00400000)
   && (register_operand (recog_operand[0], HImode)
       || register_operand (recog_operand[1], HImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 163;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1028:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) == QImode && ((x1)->code) == TRUNCATE && 1)
    goto L1029;
  x1 = ((x0)->fld[0].rtx);
  goto L1184;

  L1029:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      if ((target_flags & 0x00002000))
 return 106;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1184;

  L1185:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->code) == UNSPEC && ((x1)->fld[1].rtint) == 1 && ((x1)->fld[0].rtvec->num_elem) == 1 && 1)
    goto L1186;
  x1 = ((x0)->fld[0].rtx);
  goto L1218;

  L1186:
  x2 = ((x1)->fld[0].rtvec->elem[0].rtx);
  if (reg_or_0_operand (x2, SImode))
    {
      ro[1] = x2;
      return 149;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1218;

  L1219:
  x1 = ((x0)->fld[1].rtx);
  if (general_operand (x1, QImode))
    goto L1223;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1223:
  ro[1] = x1;
  if ((target_flags & 0x00400000)
   && (register_operand (recog_operand[0], QImode)
       || register_operand (recog_operand[1], QImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 165;
  L1224:
  ro[1] = x1;
  if (!(target_flags & 0x00400000)
   && (register_operand (recog_operand[0], QImode)
       || register_operand (recog_operand[1], QImode)
       || (((recog_operand[1])->code) == CONST_INT && ((recog_operand[1])->fld[0].rtwint) == 0)))
    return 166;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1814:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != CC_FPmode)
    {
      x1 = ((x0)->fld[0].rtx);
      goto L1936;
    }
  switch (((x1)->code))
    {
    case EQ:
      goto L1815;
    case LT:
      goto L1825;
    case LE:
      goto L1830;
    case GT:
      goto L1835;
    case GE:
      goto L1840;
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1815:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1816;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1846;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1816:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 285;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1846:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 291;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1825:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1826;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1856;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1826:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 287;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1856:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 293;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1830:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1831;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1861;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1831:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 288;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1861:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 294;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1835:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1836;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1866;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1836:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 289;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1866:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 295;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1840:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1841;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1871;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1841:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 290;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1871:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 296;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1819:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) == CC_REV_FPmode && ((x1)->code) == NE && 1)
    goto L1820;
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1820:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DFmode:
      if (register_operand (x2, DFmode))
 {
   ro[0] = x2;
   goto L1821;
 }
      break;
    case SFmode:
      if (register_operand (x2, SFmode))
 {
   ro[0] = x2;
   goto L1851;
 }
    }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1821:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 286;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1851:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SFmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 292;
      }
  x1 = ((x0)->fld[0].rtx);
  goto L1936;

  L1878:
  x1 = ((x0)->fld[1].rtx);
  switch (((x1)->mode))
    {
    case SImode:
      if (register_operand (x1, SImode))
 {
   ro[0] = x1;
   if (!(target_flags & 0x00000002))
     return 299;
   }
      break;
    case DImode:
      if (register_operand (x1, DImode))
 {
   ro[0] = x1;
   if ((target_flags & 0x00000002))
     return 300;
   }
    }
  switch (((x1)->code))
    {
    case IF_THEN_ELSE:
      goto L1551;
    case LABEL_REF:
      goto L1875;
    }
  goto ret0;

  L1551:
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case CC_FPmode:
      switch (((x2)->code))
 {
 case NE:
   goto L1552;
 case EQ:
   goto L1568;
 }
      break;
    case CC_REV_FPmode:
      switch (((x2)->code))
 {
 case NE:
   goto L1560;
 case EQ:
   goto L1576;
 }
      break;
    case SImode:
      if (cmp_op (x2, SImode))
 {
   ro[0] = x2;
   goto L1584;
 }
    L1599:
      if (equality_op (x2, SImode))
 {
   ro[0] = x2;
   goto L1600;
 }
      break;
    case DImode:
      if (cmp_op (x2, DImode))
 {
   ro[0] = x2;
   goto L1592;
 }
    L1607:
      if (equality_op (x2, DImode))
 {
   ro[0] = x2;
   goto L1608;
 }
    }
  goto ret0;

  L1552:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L1553;
  goto ret0;

  L1553:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1554;
  goto ret0;

  L1554:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1555;
    }
  goto ret0;

  L1555:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 217;
      }
  goto ret0;

  L1568:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L1569;
  goto ret0;

  L1569:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1570;
  goto ret0;

  L1570:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1571;
    }
  goto ret0;

  L1571:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 219;
      }
  goto ret0;

  L1560:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_REV_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L1561;
  goto ret0;

  L1561:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1562;
  goto ret0;

  L1562:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1563;
    }
  goto ret0;

  L1563:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 218;
      }
  goto ret0;

  L1576:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == CC_REV_FPmode && ((x3)->code) == REG && ((x3)->fld[0].rtint) == 67 && 1)
    goto L1577;
  goto ret0;

  L1577:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1578;
  goto ret0;

  L1578:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1579;
    }
  goto ret0;

  L1579:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[1] = x2;
      if ((! (target_flags & 0x00000100)))
 return 220;
      }
  goto ret0;

  L1584:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L1585;
    }
  goto L1599;

  L1585:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1586;
  goto L1599;

  L1586:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[2] = x2;
      goto L1587;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1599;

  L1587:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[3] = x2;
      return 221;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1599;

  L1600:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L1601;
    }
  goto ret0;

  L1601:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L1602;
    }
  goto ret0;

  L1602:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L1603;
    }
  goto ret0;

  L1603:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[4] = x2;
      return 223;
    }
  goto ret0;

  L1592:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1593;
    }
  goto L1607;

  L1593:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && ((x3)->fld[0].rtwint) == 0 && 1)
    goto L1594;
  goto L1607;

  L1594:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[2] = x2;
      goto L1595;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1607;

  L1595:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[3] = x2;
      return 222;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1607;

  L1608:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1609;
    }
  goto ret0;

  L1609:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L1610;
    }
  goto ret0;

  L1610:
  x2 = ((x1)->fld[1].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[3] = x2;
      goto L1611;
    }
  goto ret0;

  L1611:
  x2 = ((x1)->fld[2].rtx);
  if (pc_or_label_operand (x2, VOIDmode))
    {
      ro[4] = x2;
      return 224;
    }
  goto ret0;

  L1875:
  x2 = ((x1)->fld[0].rtx);
  ro[0] = x2;
  return 297;

  L1937:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->code) == UNSPEC && ((x1)->fld[1].rtint) == 1 && ((x1)->fld[0].rtvec->num_elem) == 1 && 1)
    goto L1938;
  goto ret0;

  L1938:
  x2 = ((x1)->fld[0].rtvec->elem[0].rtx);
  if (pnum_clobbers != 0 && 1)
    {
      ro[1] = x2;
      if ((target_flags & 0x00004000)
   && ((recog_operand[1])->code) == SYMBOL_REF)
 {
   *pnum_clobbers = 1;
   return 310;
 }
      }
  goto ret0;
 ret0: return -1;
}

int
recog_4(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_4");
int
recog_4(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case PLUS:
      goto L452;
    case MINUS:
      goto L97;
    case MULT:
      goto L257;
    case DIV:
      goto L657;
    case UDIV:
      goto L713;
    case NEG:
      goto L914;
    case ASHIFT:
      goto L1341;
    case ASHIFTRT:
      goto L1413;
    case LSHIFTRT:
      goto L1485;
    }
  goto ret0;

  L452:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) != DImode)
    goto ret0;
  if (((x3)->code) == MULT && 1)
    goto L453;
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L20;
    }
  goto ret0;

  L453:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) != DImode)
    goto ret0;
  switch (((x4)->code))
    {
    case SIGN_EXTEND:
      goto L454;
    case ZERO_EXTEND:
      goto L500;
    }
  goto ret0;

  L454:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L455;
    }
  goto ret0;

  L455:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == SIGN_EXTEND && 1)
    goto L456;
  goto ret0;

  L456:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L457;
    }
  goto ret0;

  L457:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[0]) && 1)
    goto L458;
  goto ret0;

  L458:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L459;
  goto ret0;

  L459:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      if ((target_flags & 0x00040000) && ! (target_flags & 0x00002000))
 return 46;
      }
  goto ret0;

  L500:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L501;
    }
  goto ret0;

  L501:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == ZERO_EXTEND && 1)
    goto L502;
  goto ret0;

  L502:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L503;
    }
  goto ret0;

  L503:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[0]) && 1)
    goto L504;
  goto ret0;

  L504:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L505;
  goto ret0;

  L505:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      if ((target_flags & 0x00040000) && ! (target_flags & 0x00002000))
 return 48;
      }
  goto ret0;

  L20:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L21;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      goto L47;
    }
  goto ret0;

  L21:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L22;
  goto ret0;

  L22:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 5;
      }
  goto ret0;

  L47:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L48;
  goto ret0;

  L48:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000) && ((recog_operand[2])->fld[0].rtwint) != -32768)
 return 8;
      }
  goto ret0;

  L97:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L98;
    }
  goto ret0;

  L98:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L99;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      goto L125;
    }
  goto ret0;

  L99:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L100;
  goto ret0;

  L100:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 18;
      }
  goto ret0;

  L125:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L126;
  goto ret0;

  L126:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000) && ((recog_operand[2])->fld[0].rtwint) != -32768)
 return 21;
      }
  goto ret0;

  L257:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) != DImode)
    goto ret0;
  switch (((x3)->code))
    {
    case SIGN_EXTEND:
      goto L258;
    case ZERO_EXTEND:
      goto L321;
    }
  goto ret0;

  L258:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L259;
    }
  goto ret0;

  L259:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == SIGN_EXTEND && 1)
    goto L260;
  goto ret0;

  L260:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L261;
    }
  goto ret0;

  L261:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L262;
  goto ret0;

  L262:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000))
 return 36;
      }
  goto ret0;

  L321:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L322;
    }
  goto ret0;

  L322:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == ZERO_EXTEND && 1)
    goto L323;
  goto ret0;

  L323:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L324;
    }
  goto ret0;

  L324:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L325;
  goto ret0;

  L325:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000))
 return 40;
      }
  goto ret0;

  L657:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L658;
    }
  goto ret0;

  L658:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L659;
    }
  goto ret0;

  L659:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L660;
  goto ret0;

  L660:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L661;
    }
  goto ret0;

  L661:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == MOD && 1)
    goto L662;
  goto ret0;

  L662:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L663;
  goto ret0;

  L663:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00002000) && optimize)
      {
 *pnum_clobbers = 3;
 return 61;
      }
  goto ret0;

  L713:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L714;
    }
  goto ret0;

  L714:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L715;
    }
  goto ret0;

  L715:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L716;
  goto ret0;

  L716:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L717;
    }
  goto ret0;

  L717:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == UMOD && 1)
    goto L718;
  goto ret0;

  L718:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L719;
  goto ret0;

  L719:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && pnum_clobbers != 0 && 1)
    if ((target_flags & 0x00002000) && optimize)
      {
 *pnum_clobbers = 3;
 return 63;
      }
  goto ret0;

  L914:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L915;
    }
  goto ret0;

  L915:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L916;
  goto ret0;

  L916:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      if (! (target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 82;
      }
  goto ret0;

  L1341:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1342;
    }
  goto ret0;

  L1342:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L1343;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1351;
    }
  goto ret0;

  L1343:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1344;
  goto ret0;

  L1344:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 183;
      }
  goto ret0;

  L1351:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1352;
  goto ret0;

  L1352:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1379;
  goto ret0;

  L1379:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000) && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return 184;
  L1380:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000)
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return 187;
  goto ret0;

  L1413:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1414;
    }
  goto ret0;

  L1414:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L1415;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1423;
    }
  goto ret0;

  L1415:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1416;
  goto ret0;

  L1416:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 193;
      }
  goto ret0;

  L1423:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1424;
  goto ret0;

  L1424:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1451;
  goto ret0;

  L1451:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000) && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return 194;
  L1452:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000)
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return 197;
  goto ret0;

  L1485:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1486;
    }
  goto ret0;

  L1486:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L1487;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1495;
    }
  goto ret0;

  L1487:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1488;
  goto ret0;

  L1488:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000))
 return 203;
      }
  goto ret0;

  L1495:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1496;
  goto ret0;

  L1496:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1523;
  goto ret0;

  L1523:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000) && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return 204;
  L1524:
  ro[3] = x2;
  if (!(target_flags & 0x00002000) && !(target_flags & 0x00800000)
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return 207;
  goto ret0;
 ret0: return -1;
}

int
recog_5(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_5");
int
recog_5(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case DImode:
      if (register_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L18;
 }
    L1143:
      if (general_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L1144;
 }
      break;
    case SImode:
      if (register_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L628;
 }
    }
  L1249:
  switch (((x2)->code))
    {
    case REG:
      if (((x2)->mode) == DImode && ((x2)->fld[0].rtint) == 28 && 1)
 goto L1250;
      break;
    case PC:
      goto L1885;
    }
  L1930:
  if (register_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1931;
    }
  goto ret0;
 L18:
  tem = recog_4 (x0, insn, pnum_clobbers);
  if (tem >= 0) return tem;
  x2 = ((x1)->fld[0].rtx);
  goto L1143;

  L1144:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == FIX && 1)
    goto L1145;
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L1145:
  x3 = ((x2)->fld[0].rtx);
  switch (((x3)->mode))
    {
    case DFmode:
      if (register_operand (x3, DFmode))
 {
   ro[1] = x3;
   goto L1146;
 }
      break;
    case SFmode:
      if (register_operand (x3, SFmode))
 {
   ro[1] = x3;
   goto L1157;
 }
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L1146:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1147;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L1147:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
 return 135;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L1157:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1158;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L1158:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DFmode))
    {
      ro[2] = x2;
      if ((! (target_flags & 0x00000100)) && (target_flags & 0x00002000) && (! (target_flags & 0x00020000)))
 return 136;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1249;

  L628:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SImode)
    {
      x2 = ((x1)->fld[0].rtx);
      goto L1930;
    }
  switch (((x2)->code))
    {
    case DIV:
      goto L629;
    case UDIV:
      goto L685;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L629:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L630;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L630:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L631;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L631:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L632;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L632:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L633;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L633:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == MOD && 1)
    goto L634;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L634:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L635;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L635:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && pnum_clobbers != 0 && 1)
    if (optimize)
      {
 *pnum_clobbers = 3;
 return 60;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L685:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L686;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L686:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L687;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L687:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L688;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L688:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L689;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L689:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == UMOD && 1)
    goto L690;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L690:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L691;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L691:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && pnum_clobbers != 0 && 1)
    if (optimize)
      {
 *pnum_clobbers = 3;
 return 62;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L1250:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->code) == UNSPEC_VOLATILE && ((x2)->fld[1].rtint) == 2 && ((x2)->fld[0].rtvec->num_elem) == 1 && 1)
    goto L1251;
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L1251:
  x3 = ((x2)->fld[0].rtvec->elem[0].rtx);
  if (address_operand (x3, DImode))
    {
      ro[0] = x3;
      goto L1252;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L1252:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1253;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L1253:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == REG && ((x2)->fld[0].rtint) == 1 && 1)
    return 175;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1930;

  L1885:
  x2 = ((x1)->fld[1].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (register_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L1886;
 }
      break;
    case DImode:
      if (register_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L1893;
 }
    }
  if (((x2)->mode) == SImode && ((x2)->code) == MEM && 1)
    goto L1918;
  goto ret0;

  L1886:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == USE && 1)
    goto L1887;
  goto ret0;

  L1887:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == LABEL_REF && 1)
    goto L1888;
  goto ret0;

  L1888:
  x3 = ((x2)->fld[0].rtx);
  ro[1] = x3;
  if (!(target_flags & 0x00000002))
    return 302;
  goto ret0;

  L1893:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == USE && 1)
    goto L1894;
  goto ret0;

  L1894:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == LABEL_REF && 1)
    goto L1895;
  goto ret0;

  L1895:
  x3 = ((x2)->fld[0].rtx);
  ro[1] = x3;
  if ((target_flags & 0x00000002))
    return 303;
  goto ret0;

  L1918:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == SImode && ((x3)->code) == PLUS && 1)
    goto L1919;
  goto ret0;

  L1919:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) == SImode && ((x4)->code) == MULT && 1)
    goto L1920;
  goto ret0;

  L1920:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[0] = x5;
      goto L1921;
    }
  goto ret0;

  L1921:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->code) == CONST_INT && ((x5)->fld[0].rtwint) == 4 && 1)
    goto L1922;
  goto ret0;

  L1922:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == LABEL_REF && 1)
    goto L1923;
  goto ret0;

  L1923:
  x5 = ((x4)->fld[0].rtx);
  ro[1] = x5;
  goto L1924;

  L1924:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1925;
  goto ret0;

  L1925:
  x2 = ((x1)->fld[0].rtx);
  if (pnum_clobbers != 0 && register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00004000))
 {
   *pnum_clobbers = 1;
   return 307;
 }
      }
  goto ret0;

  L1931:
  x2 = ((x1)->fld[1].rtx);
  switch (((x2)->code))
    {
    case UNSPEC:
      if (((x2)->fld[1].rtint) == 1 && ((x2)->fld[0].rtvec->num_elem) == 1 && 1)
 goto L1932;
      break;
    case CALL:
      goto L1989;
    }
  goto ret0;

  L1932:
  x3 = ((x2)->fld[0].rtvec->elem[0].rtx);
  ro[1] = x3;
  goto L1933;

  L1933:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1934;
  goto ret0;

  L1934:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == REG && ((x2)->fld[0].rtint) == 31 && 1)
    if ((target_flags & 0x00004000)
   && ((recog_operand[1])->code) == SYMBOL_REF)
      return 310;
  goto ret0;

  L1989:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->code) != MEM)
    goto ret0;
  if (call_insn_operand (x3, VOIDmode))
    {
      ro[1] = x3;
      goto L1990;
    }
  L2007:
  if (((x3)->code) != MEM)
    goto ret0;
  switch (((x3)->mode))
    {
    case SImode:
      goto L2008;
    case DImode:
      goto L2017;
    }
  goto ret0;

  L1990:
  x3 = ((x2)->fld[1].rtx);
  ro[2] = x3;
  goto L1991;

  L1991:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1992;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  x3 = ((x2)->fld[0].rtx);
  goto L2007;

  L1992:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L2001;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  x3 = ((x2)->fld[0].rtx);
  goto L2007;

  L2001:
  ro[3] = x2;
  if (!(target_flags & 0x00000400) && !(target_flags & 0x00001000))
    return 319;
  L2002:
  ro[3] = x2;
  if ((target_flags & 0x00000400) && !(target_flags & 0x00001000))
    return 320;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  x3 = ((x2)->fld[0].rtx);
  goto L2007;

  L2008:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L2009;
    }
  goto ret0;

  L2009:
  x3 = ((x2)->fld[1].rtx);
  ro[2] = x3;
  goto L2010;

  L2010:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L2011;
  goto ret0;

  L2011:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L2030;
  goto ret0;

  L2030:
  ro[3] = x2;
  if (!(target_flags & 0x00000002) && !(target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 321;
  L2031:
  ro[3] = x2;
  if (!(target_flags & 0x00000002) && (target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 323;
  goto ret0;

  L2017:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, DImode))
    {
      ro[1] = x4;
      goto L2018;
    }
  goto ret0;

  L2018:
  x3 = ((x2)->fld[1].rtx);
  ro[2] = x3;
  goto L2019;

  L2019:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L2020;
  goto ret0;

  L2020:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L2041;
  goto ret0;

  L2041:
  ro[3] = x2;
  if ((target_flags & 0x00000002) && !(target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 322;
  L2042:
  ro[3] = x2;
  if ((target_flags & 0x00000002) && (target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 324;
  goto ret0;
 ret0: return -1;
}

int
recog_6(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_6");
int
recog_6(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case MULT:
      goto L274;
    case TRUNCATE:
      goto L383;
    case PLUS:
      goto L473;
    case FFS:
      goto L897;
    }
  goto ret0;

  L274:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) != DImode)
    goto ret0;
  switch (((x3)->code))
    {
    case SIGN_EXTEND:
      goto L275;
    case ZERO_EXTEND:
      goto L338;
    case SUBREG:
    case REG:
      if (register_operand (x3, DImode))
 {
   ro[1] = x3;
   goto L224;
 }
    }
  goto ret0;

  L275:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L276;
    }
  goto ret0;

  L276:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == SIGN_EXTEND && 1)
    goto L277;
  goto ret0;

  L277:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L278;
    }
  goto ret0;

  L278:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L279;
  goto ret0;

  L279:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L280;
    }
  goto ret0;

  L280:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L281;
  goto ret0;

  L281:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00002000))
 return 37;
      }
  goto ret0;

  L338:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L339;
    }
  goto ret0;

  L339:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == ZERO_EXTEND && 1)
    goto L340;
  goto ret0;

  L340:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L341;
    }
  goto ret0;

  L341:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L342;
  goto ret0;

  L342:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L343;
    }
  goto ret0;

  L343:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L344;
  goto ret0;

  L344:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00002000))
 return 41;
      }
  goto ret0;

  L224:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L225;
    }
  goto ret0;

  L225:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L226;
  goto ret0;

  L226:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L227;
    }
  goto ret0;

  L227:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L228;
  goto ret0;

  L228:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00002000) && mips_cpu != PROCESSOR_R4000)
 return 33;
      }
  goto ret0;

  L383:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == TImode && ((x3)->code) == LSHIFTRT && 1)
    goto L384;
  goto ret0;

  L384:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) == TImode && ((x4)->code) == MULT && 1)
    goto L385;
  goto ret0;

  L385:
  x5 = ((x4)->fld[0].rtx);
  if (((x5)->mode) != TImode)
    goto ret0;
  switch (((x5)->code))
    {
    case SIGN_EXTEND:
      goto L386;
    case ZERO_EXTEND:
      goto L411;
    }
  goto ret0;

  L386:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, DImode))
    {
      ro[1] = x6;
      goto L387;
    }
  goto ret0;

  L387:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->mode) == TImode && ((x5)->code) == SIGN_EXTEND && 1)
    goto L388;
  goto ret0;

  L388:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, DImode))
    {
      ro[2] = x6;
      goto L389;
    }
  goto ret0;

  L389:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == CONST_INT && ((x4)->fld[0].rtwint) == 64 && 1)
    goto L390;
  goto ret0;

  L390:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L391;
  goto ret0;

  L391:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L392;
    }
  goto ret0;

  L392:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L393;
  goto ret0;

  L393:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00002000))
 return 43;
      }
  goto ret0;

  L411:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, DImode))
    {
      ro[1] = x6;
      goto L412;
    }
  goto ret0;

  L412:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->mode) == TImode && ((x5)->code) == ZERO_EXTEND && 1)
    goto L413;
  goto ret0;

  L413:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, DImode))
    {
      ro[2] = x6;
      goto L414;
    }
  goto ret0;

  L414:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == CONST_INT && ((x4)->fld[0].rtwint) == 64 && 1)
    goto L415;
  goto ret0;

  L415:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L416;
  goto ret0;

  L416:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L417;
    }
  goto ret0;

  L417:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L418;
  goto ret0;

  L418:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00002000))
 return 44;
      }
  goto ret0;

  L473:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == MULT && 1)
    goto L474;
  goto ret0;

  L474:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) != DImode)
    goto ret0;
  switch (((x4)->code))
    {
    case SIGN_EXTEND:
      goto L475;
    case ZERO_EXTEND:
      goto L521;
    }
  goto ret0;

  L475:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L476;
    }
  goto ret0;

  L476:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == SIGN_EXTEND && 1)
    goto L477;
  goto ret0;

  L477:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L478;
    }
  goto ret0;

  L478:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[0]) && 1)
    goto L479;
  goto ret0;

  L479:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L480;
  goto ret0;

  L480:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L481;
    }
  goto ret0;

  L481:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L482;
  goto ret0;

  L482:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00040000) && (target_flags & 0x00002000))
 return 47;
      }
  goto ret0;

  L521:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[1] = x5;
      goto L522;
    }
  goto ret0;

  L522:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == ZERO_EXTEND && 1)
    goto L523;
  goto ret0;

  L523:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[2] = x5;
      goto L524;
    }
  goto ret0;

  L524:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[0]) && 1)
    goto L525;
  goto ret0;

  L525:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L526;
  goto ret0;

  L526:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L527;
    }
  goto ret0;

  L527:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L528;
  goto ret0;

  L528:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00040000) && (target_flags & 0x00002000))
 return 49;
      }
  goto ret0;

  L897:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L898;
    }
  goto ret0;

  L898:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L899;
  goto ret0;

  L899:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[2] = x2;
      goto L900;
    }
  goto ret0;

  L900:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L901;
  goto ret0;

  L901:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      if ((target_flags & 0x00002000))
 return 79;
      }
  goto ret0;
 ret0: return -1;
}

int
recog_7(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_7");
int
recog_7(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (register_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L169;
 }
    L1117:
      if (general_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L1118;
 }
      break;
    case DImode:
      if (register_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L222;
 }
    }
  if (((x2)->code) == PC && 1)
    goto L1903;
  goto ret0;

  L169:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SImode)
    {
      x2 = ((x1)->fld[0].rtx);
      goto L1117;
    }
  switch (((x2)->code))
    {
    case MULT:
      goto L170;
    case TRUNCATE:
      goto L295;
    case PLUS:
      goto L433;
    case FFS:
      goto L884;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L170:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L171;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L171:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L172;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L172:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L173;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L173:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L174;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L174:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L175;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L175:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      if (mips_cpu != PROCESSOR_R4000)
 return 29;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L295:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == DImode && ((x3)->code) == LSHIFTRT && 1)
    goto L296;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L296:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) == DImode && ((x4)->code) == MULT && 1)
    goto L297;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L297:
  x5 = ((x4)->fld[0].rtx);
  if (((x5)->mode) != DImode)
    {
      x2 = ((x1)->fld[0].rtx);
      goto L1117;
    }
  switch (((x5)->code))
    {
    case SIGN_EXTEND:
      goto L298;
    case ZERO_EXTEND:
      goto L361;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L298:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, SImode))
    {
      ro[1] = x6;
      goto L299;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L299:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->mode) == DImode && ((x5)->code) == SIGN_EXTEND && 1)
    goto L300;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L300:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, SImode))
    {
      ro[2] = x6;
      goto L301;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L301:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == CONST_INT && ((x4)->fld[0].rtwint) == 32 && 1)
    goto L302;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L302:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L303;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L303:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L304;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L304:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L305;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L305:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      return 38;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L361:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, SImode))
    {
      ro[1] = x6;
      goto L362;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L362:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->mode) == DImode && ((x5)->code) == ZERO_EXTEND && 1)
    goto L363;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L363:
  x6 = ((x5)->fld[0].rtx);
  if (register_operand (x6, SImode))
    {
      ro[2] = x6;
      goto L364;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L364:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == CONST_INT && ((x4)->fld[0].rtwint) == 32 && 1)
    goto L365;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L365:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L366;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L366:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L367;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L367:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L368;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L368:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      return 42;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L433:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == SImode && ((x3)->code) == MULT && 1)
    goto L434;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L434:
  x4 = ((x3)->fld[0].rtx);
  if (register_operand (x4, SImode))
    {
      ro[1] = x4;
      goto L435;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L435:
  x4 = ((x3)->fld[1].rtx);
  if (register_operand (x4, SImode))
    {
      ro[2] = x4;
      goto L436;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L436:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[0]) && 1)
    goto L437;
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L437:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L438;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L438:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L439;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L439:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L440;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L440:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      if ((target_flags & 0x00040000))
 return 45;
      }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L884:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L885;
    }
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L885:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L886;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L886:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[2] = x2;
      goto L887;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L887:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L888;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L888:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      return 78;
    }
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1117;

  L1118:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == FIX && 1)
    goto L1119;
  goto ret0;

  L1119:
  x3 = ((x2)->fld[0].rtx);
  switch (((x3)->mode))
    {
    case DFmode:
      if (register_operand (x3, DFmode))
 {
   ro[1] = x3;
   goto L1120;
 }
      break;
    case SFmode:
      if (register_operand (x3, SFmode))
 {
   ro[1] = x3;
   goto L1133;
 }
    }
  goto ret0;

  L1120:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1121;
  goto ret0;

  L1121:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[2] = x2;
      goto L1122;
    }
  goto ret0;

  L1122:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1123;
  goto ret0;

  L1123:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DFmode))
    {
      ro[3] = x2;
      if ((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000)))
 return 133;
      }
  goto ret0;

  L1133:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1134;
  goto ret0;

  L1134:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[2] = x2;
      goto L1135;
    }
  goto ret0;

  L1135:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1136;
  goto ret0;

  L1136:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SFmode))
    {
      ro[3] = x2;
      if ((! (target_flags & 0x00000100)))
 return 134;
      }
  goto ret0;
 L222:
  return recog_6 (x0, insn, pnum_clobbers);

  L1903:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == MEM && 1)
    goto L1904;
  goto ret0;

  L1904:
  x3 = ((x2)->fld[0].rtx);
  if (((x3)->mode) == SImode && ((x3)->code) == PLUS && 1)
    goto L1905;
  goto ret0;

  L1905:
  x4 = ((x3)->fld[0].rtx);
  if (((x4)->mode) == SImode && ((x4)->code) == MULT && 1)
    goto L1906;
  goto ret0;

  L1906:
  x5 = ((x4)->fld[0].rtx);
  if (register_operand (x5, SImode))
    {
      ro[0] = x5;
      goto L1907;
    }
  goto ret0;

  L1907:
  x5 = ((x4)->fld[1].rtx);
  if (((x5)->code) == CONST_INT && ((x5)->fld[0].rtwint) == 4 && 1)
    goto L1908;
  goto ret0;

  L1908:
  x4 = ((x3)->fld[1].rtx);
  if (((x4)->code) == LABEL_REF && 1)
    goto L1909;
  goto ret0;

  L1909:
  x5 = ((x4)->fld[0].rtx);
  ro[1] = x5;
  goto L1910;

  L1910:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1911;
  goto ret0;

  L1911:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      goto L1912;
    }
  goto ret0;

  L1912:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1913;
  goto ret0;

  L1913:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == REG && ((x2)->fld[0].rtint) == 31 && 1)
    if ((target_flags & 0x00004000))
      return 307;
  goto ret0;
 ret0: return -1;
}

int
recog_8(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_8");
int
recog_8(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (register_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L184;
 }
      break;
    case DImode:
      if (register_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L237;
 }
    }
  goto ret0;

  L184:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  switch (((x2)->code))
    {
    case MULT:
      goto L185;
    case DIV:
      goto L724;
    case MOD:
      goto L758;
    case UDIV:
      goto L792;
    case UMOD:
      goto L826;
    }
  goto ret0;

  L185:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L186;
    }
  goto ret0;

  L186:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L187;
    }
  goto ret0;

  L187:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L188;
  goto ret0;

  L188:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L189;
    }
  goto ret0;

  L189:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L190;
  goto ret0;

  L190:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L191;
    }
  goto ret0;

  L191:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L192;
  goto ret0;

  L192:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    goto L217;
  goto ret0;

  L217:
  ro[5] = x2;
  if (mips_cpu == PROCESSOR_R4000)
    return 30;
  L218:
  ro[5] = x2;
  if ((target_flags & 0x00040000))
    return 31;
  goto ret0;

  L724:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L725;
    }
  goto ret0;

  L725:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L726;
    }
  goto ret0;

  L726:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L727;
  goto ret0;

  L727:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L728;
    }
  goto ret0;

  L728:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L729;
  goto ret0;

  L729:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L730;
    }
  goto ret0;

  L730:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L731;
  goto ret0;

  L731:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (!optimize)
 return 64;
      }
  goto ret0;

  L758:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L759;
    }
  goto ret0;

  L759:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L760;
    }
  goto ret0;

  L760:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L761;
  goto ret0;

  L761:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L762;
    }
  goto ret0;

  L762:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L763;
  goto ret0;

  L763:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L764;
    }
  goto ret0;

  L764:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L765;
  goto ret0;

  L765:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (!optimize)
 return 66;
      }
  goto ret0;

  L792:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L793;
    }
  goto ret0;

  L793:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L794;
    }
  goto ret0;

  L794:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L795;
  goto ret0;

  L795:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L796;
    }
  goto ret0;

  L796:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L797;
  goto ret0;

  L797:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L798;
    }
  goto ret0;

  L798:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L799;
  goto ret0;

  L799:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (!optimize)
 return 68;
      }
  goto ret0;

  L826:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L827;
    }
  goto ret0;

  L827:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L828;
    }
  goto ret0;

  L828:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L829;
  goto ret0;

  L829:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L830;
    }
  goto ret0;

  L830:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L831;
  goto ret0;

  L831:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L832;
    }
  goto ret0;

  L832:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L833;
  goto ret0;

  L833:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (!optimize)
 return 70;
      }
  goto ret0;

  L237:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case MULT:
      goto L238;
    case DIV:
      goto L741;
    case MOD:
      goto L775;
    case UDIV:
      goto L809;
    case UMOD:
      goto L843;
    }
  goto ret0;

  L238:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L239;
    }
  goto ret0;

  L239:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L240;
    }
  goto ret0;

  L240:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L241;
  goto ret0;

  L241:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L242;
    }
  goto ret0;

  L242:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L243;
  goto ret0;

  L243:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L244;
    }
  goto ret0;

  L244:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L245;
  goto ret0;

  L245:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[5] = x2;
      if ((target_flags & 0x00002000) && mips_cpu == PROCESSOR_R4000)
 return 34;
      }
  goto ret0;

  L741:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L742;
    }
  goto ret0;

  L742:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L743;
    }
  goto ret0;

  L743:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L744;
  goto ret0;

  L744:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L745;
    }
  goto ret0;

  L745:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L746;
  goto ret0;

  L746:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L747;
    }
  goto ret0;

  L747:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L748;
  goto ret0;

  L748:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 return 65;
      }
  goto ret0;

  L775:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L776;
    }
  goto ret0;

  L776:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L777;
    }
  goto ret0;

  L777:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L778;
  goto ret0;

  L778:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L779;
    }
  goto ret0;

  L779:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L780;
  goto ret0;

  L780:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L781;
    }
  goto ret0;

  L781:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L782;
  goto ret0;

  L782:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 return 67;
      }
  goto ret0;

  L809:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L810;
    }
  goto ret0;

  L810:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L811;
    }
  goto ret0;

  L811:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L812;
  goto ret0;

  L812:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L813;
    }
  goto ret0;

  L813:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L814;
  goto ret0;

  L814:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L815;
    }
  goto ret0;

  L815:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L816;
  goto ret0;

  L816:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 return 69;
      }
  goto ret0;

  L843:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L844;
    }
  goto ret0;

  L844:
  x3 = ((x2)->fld[1].rtx);
  if (nonmemory_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L845;
    }
  goto ret0;

  L845:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L846;
  goto ret0;

  L846:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L847;
    }
  goto ret0;

  L847:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L848;
  goto ret0;

  L848:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L849;
    }
  goto ret0;

  L849:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L850;
  goto ret0;

  L850:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && !optimize)
 return 71;
      }
  goto ret0;
 ret0: return -1;
}

int
recog_9(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog_9");
int
recog_9(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  switch (((x2)->mode))
    {
    case SImode:
      if (register_operand (x2, SImode))
 {
   ro[0] = x2;
   goto L611;
 }
      break;
    case DImode:
      if (register_operand (x2, DImode))
 {
   ro[0] = x2;
   goto L639;
 }
    }
  goto ret0;

  L611:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  switch (((x2)->code))
    {
    case DIV:
      goto L612;
    case UDIV:
      goto L668;
    }
  goto ret0;

  L612:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L613;
    }
  goto ret0;

  L613:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L614;
    }
  goto ret0;

  L614:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L615;
  goto ret0;

  L615:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L616;
    }
  goto ret0;

  L616:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == MOD && 1)
    goto L617;
  goto ret0;

  L617:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L618;
  goto ret0;

  L618:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && 1)
    goto L619;
  goto ret0;

  L619:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L620;
  goto ret0;

  L620:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L621;
    }
  goto ret0;

  L621:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L622;
  goto ret0;

  L622:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[5] = x2;
      goto L623;
    }
  goto ret0;

  L623:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L624;
  goto ret0;

  L624:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (optimize)
 return 60;
      }
  goto ret0;

  L668:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L669;
    }
  goto ret0;

  L669:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, SImode))
    {
      ro[2] = x3;
      goto L670;
    }
  goto ret0;

  L670:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L671;
  goto ret0;

  L671:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[3] = x2;
      goto L672;
    }
  goto ret0;

  L672:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == SImode && ((x2)->code) == UMOD && 1)
    goto L673;
  goto ret0;

  L673:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L674;
  goto ret0;

  L674:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && 1)
    goto L675;
  goto ret0;

  L675:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L676;
  goto ret0;

  L676:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L677;
    }
  goto ret0;

  L677:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L678;
  goto ret0;

  L678:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[5] = x2;
      goto L679;
    }
  goto ret0;

  L679:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L680;
  goto ret0;

  L680:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      if (optimize)
 return 62;
      }
  goto ret0;

  L639:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case DIV:
      goto L640;
    case UDIV:
      goto L696;
    }
  goto ret0;

  L640:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L641;
    }
  goto ret0;

  L641:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L642;
    }
  goto ret0;

  L642:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L643;
  goto ret0;

  L643:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L644;
    }
  goto ret0;

  L644:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == MOD && 1)
    goto L645;
  goto ret0;

  L645:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L646;
  goto ret0;

  L646:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && 1)
    goto L647;
  goto ret0;

  L647:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L648;
  goto ret0;

  L648:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L649;
    }
  goto ret0;

  L649:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L650;
  goto ret0;

  L650:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[5] = x2;
      goto L651;
    }
  goto ret0;

  L651:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L652;
  goto ret0;

  L652:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && optimize)
 return 61;
      }
  goto ret0;

  L696:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L697;
    }
  goto ret0;

  L697:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L698;
    }
  goto ret0;

  L698:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == SET && 1)
    goto L699;
  goto ret0;

  L699:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[3] = x2;
      goto L700;
    }
  goto ret0;

  L700:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == DImode && ((x2)->code) == UMOD && 1)
    goto L701;
  goto ret0;

  L701:
  x3 = ((x2)->fld[0].rtx);
  if (rtx_equal_p (x3, ro[1]) && 1)
    goto L702;
  goto ret0;

  L702:
  x3 = ((x2)->fld[1].rtx);
  if (rtx_equal_p (x3, ro[2]) && 1)
    goto L703;
  goto ret0;

  L703:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L704;
  goto ret0;

  L704:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[4] = x2;
      goto L705;
    }
  goto ret0;

  L705:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L706;
  goto ret0;

  L706:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[5] = x2;
      goto L707;
    }
  goto ret0;

  L707:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L708;
  goto ret0;

  L708:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, DImode))
    {
      ro[6] = x2;
      if ((target_flags & 0x00002000) && optimize)
 return 63;
      }
  goto ret0;
 ret0: return -1;
}

int
recog(register rtx x0, rtx insn, int *pnum_clobbers) asm("_recog");
int
recog(register rtx x0, rtx insn, int *pnum_clobbers)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  int tem;

  L0:
  switch (((x0)->code))
    {
    case SET:
      goto L1;
    case PARALLEL:
      if (((x0)->fld[0].rtvec->num_elem) == 2 && 1)
 goto L16;
      if (((x0)->fld[0].rtvec->num_elem) == 3 && 1)
 goto L167;
      if (((x0)->fld[0].rtvec->num_elem) == 4 && 1)
 goto L182;
      if (((x0)->fld[0].rtvec->num_elem) == 5 && 1)
 goto L609;
      if (((x0)->fld[0].rtvec->num_elem) == 8 && 1)
 goto L1259;
      break;
    case UNSPEC_VOLATILE:
      if (((x0)->fld[1].rtint) == 0 && ((x0)->fld[0].rtvec->num_elem) == 1 && 1)
 goto L1927;
      break;
    case CONST_INT:
      if (((x0)->fld[0].rtwint) == 0 && 1)
 return 326;
    }
  goto ret0;
 L1:
  return recog_3 (x0, insn, pnum_clobbers);

  L16:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  switch (((x1)->code))
    {
    case SET:
      goto L17;
    case RETURN:
      goto L1898;
    case CALL:
      goto L1941;
    }
  goto ret0;
 L17:
  return recog_5 (x0, insn, pnum_clobbers);

  L1898:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == USE && 1)
    goto L1899;
  goto ret0;

  L1899:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[0] = x2;
      return 305;
    }
  goto ret0;

  L1941:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) != MEM)
    goto ret0;
  if (call_insn_operand (x2, VOIDmode))
    {
      ro[0] = x2;
      goto L1942;
    }
  L1955:
  if (((x2)->code) != MEM)
    goto ret0;
  switch (((x2)->mode))
    {
    case SImode:
      goto L1956;
    case DImode:
      goto L1963;
    }
  goto ret0;

  L1942:
  x2 = ((x1)->fld[1].rtx);
  ro[1] = x2;
  goto L1943;

  L1943:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1944;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1955;

  L1944:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1951;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1955;

  L1951:
  ro[2] = x2;
  if (!(target_flags & 0x00000400) && !(target_flags & 0x00001000))
    return 312;
  L1952:
  ro[2] = x2;
  if ((target_flags & 0x00000400) && !(target_flags & 0x00001000))
    return 313;
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[0].rtx);
  goto L1955;

  L1956:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[0] = x3;
      goto L1957;
    }
  goto ret0;

  L1957:
  x2 = ((x1)->fld[1].rtx);
  ro[1] = x2;
  goto L1958;

  L1958:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1959;
  goto ret0;

  L1959:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1974;
  goto ret0;

  L1974:
  ro[2] = x2;
  if (!(target_flags & 0x00000002) && !(target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 314;
  L1975:
  ro[2] = x2;
  if (!(target_flags & 0x00000002) && (target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 316;
  goto ret0;

  L1963:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[0] = x3;
      goto L1964;
    }
  goto ret0;

  L1964:
  x2 = ((x1)->fld[1].rtx);
  ro[1] = x2;
  goto L1965;

  L1965:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1966;
  goto ret0;

  L1966:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L1983;
  goto ret0;

  L1983:
  ro[2] = x2;
  if ((target_flags & 0x00000002) && !(target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 315;
  L1984:
  ro[2] = x2;
  if ((target_flags & 0x00000002) && (target_flags & 0x00000400) && (target_flags & 0x00001000))
    return 317;
  goto ret0;

  L167:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L168;
  goto ret0;
 L168:
  return recog_7 (x0, insn, pnum_clobbers);

  L182:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L183;
  goto ret0;
 L183:
  return recog_8 (x0, insn, pnum_clobbers);

  L609:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L610;
  goto ret0;
 L610:
  return recog_9 (x0, insn, pnum_clobbers);

  L1259:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L1260;
  goto ret0;

  L1260:
  x2 = ((x1)->fld[0].rtx);
  if (memory_operand (x2, BLKmode))
    {
      ro[0] = x2;
      goto L1261;
    }
  goto ret0;

  L1261:
  x2 = ((x1)->fld[1].rtx);
  if (memory_operand (x2, BLKmode))
    {
      ro[1] = x2;
      goto L1262;
    }
  goto ret0;

  L1262:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1263;
  goto ret0;

  L1263:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L1264;
    }
  goto ret0;

  L1264:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1265;
  goto ret0;

  L1265:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[5] = x2;
      goto L1266;
    }
  goto ret0;

  L1266:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1267;
  goto ret0;

  L1267:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[6] = x2;
      goto L1268;
    }
  goto ret0;

  L1268:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1269;
  goto ret0;

  L1269:
  x2 = ((x1)->fld[0].rtx);
  if (scratch_operand (x2, SImode))
    {
      ro[7] = x2;
      goto L1270;
    }
  goto ret0;

  L1270:
  x1 = ((x0)->fld[0].rtvec->elem[5].rtx);
  if (((x1)->code) == USE && 1)
    goto L1271;
  goto ret0;

  L1271:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[2] = x2;
      goto L1272;
    }
  goto ret0;

  L1272:
  x1 = ((x0)->fld[0].rtvec->elem[6].rtx);
  if (((x1)->code) == USE && 1)
    goto L1273;
  goto ret0;

  L1273:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[3] = x2;
      goto L1274;
    }
  goto ret0;

  L1274:
  x1 = ((x0)->fld[0].rtvec->elem[7].rtx);
  if (((x1)->code) == USE && 1)
    goto L1275;
  goto ret0;

  L1275:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) != CONST_INT)
    goto ret0;
  if (((x2)->fld[0].rtwint) == 0 && 1)
    return 177;
  if (((x2)->code) != CONST_INT)
    goto ret0;
  if (((x2)->fld[0].rtwint) == 1 && 1)
    return 179;
  if (((x2)->fld[0].rtwint) == 2 && 1)
    return 180;
  goto ret0;

  L1927:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == CONST_INT && ((x1)->fld[0].rtwint) == 0 && 1)
    return 309;
  goto ret0;
 ret0: return -1;
}

rtx
split_1(register rtx x0, rtx insn) asm("_split_1");
rtx
split_1(register rtx x0, rtx insn)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  rtx tem;

  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  switch (((x2)->code))
    {
    case PLUS:
      goto L27;
    case MINUS:
      goto L105;
    case ASHIFT:
      goto L1357;
    case ASHIFTRT:
      goto L1429;
    case LSHIFTRT:
      goto L1501;
    }
  goto ret0;

  L27:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L28;
    }
  goto ret0;

  L28:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L29;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      goto L55;
    }
  goto ret0;

  L29:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L30;
  goto ret0;

  L30:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L39;
  goto ret0;

  L39:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && (((recog_operand[0])->fld[0].rtint) != ((recog_operand[1])->fld[0].rtint)
       || ((recog_operand[0])->fld[0].rtint) != ((recog_operand[2])->fld[0].rtint)))
    return gen_split_6 (recog_operand);
  L40:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && (((recog_operand[0])->fld[0].rtint) != ((recog_operand[1])->fld[0].rtint)
       || ((recog_operand[0])->fld[0].rtint) != ((recog_operand[2])->fld[0].rtint)))
    return gen_split_7 (recog_operand);
  goto ret0;

  L55:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L56;
  goto ret0;

  L56:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L65;
  goto ret0;

  L65:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->fld[0].rtwint) > 0)
    return gen_split_9 (recog_operand);
  L66:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->fld[0].rtwint) > 0)
    return gen_split_10 (recog_operand);
  goto ret0;

  L105:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L106;
    }
  goto ret0;

  L106:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      goto L107;
    }
  if (((x3)->code) == CONST_INT && small_int (x3, DImode))
    {
      ro[2] = x3;
      goto L133;
    }
  goto ret0;

  L107:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L108;
  goto ret0;

  L108:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L117;
  goto ret0;

  L117:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
    return gen_split_19 (recog_operand);
  L118:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
    return gen_split_20 (recog_operand);
  goto ret0;

  L133:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L134;
  goto ret0;

  L134:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    goto L143;
  goto ret0;

  L143:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->fld[0].rtwint) > 0)
    return gen_split_22 (recog_operand);
  L144:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->fld[0].rtwint) > 0)
    return gen_split_23 (recog_operand);
  goto ret0;

  L1357:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1358;
    }
  goto ret0;

  L1358:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1359;
    }
  goto ret0;

  L1359:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1360;
  goto ret0;

  L1360:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  if (register_operand (x2, SImode))
    goto L1369;
  L1388:
  if (register_operand (x2, SImode))
    goto L1397;
  goto ret0;

  L1369:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_185 (recog_operand);
  L1370:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_186 (recog_operand);
  goto L1388;

  L1397:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_188 (recog_operand);
  L1398:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_189 (recog_operand);
  goto ret0;

  L1429:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1430;
    }
  goto ret0;

  L1430:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1431;
    }
  goto ret0;

  L1431:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1432;
  goto ret0;

  L1432:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  if (register_operand (x2, SImode))
    goto L1441;
  L1460:
  if (register_operand (x2, SImode))
    goto L1469;
  goto ret0;

  L1441:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_195 (recog_operand);
  L1442:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_196 (recog_operand);
  goto L1460;

  L1469:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_198 (recog_operand);
  L1470:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_199 (recog_operand);
  goto ret0;

  L1501:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L1502;
    }
  goto ret0;

  L1502:
  x3 = ((x2)->fld[1].rtx);
  if (((x3)->code) == CONST_INT && small_int (x3, SImode))
    {
      ro[2] = x3;
      goto L1503;
    }
  goto ret0;

  L1503:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1504;
  goto ret0;

  L1504:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != SImode)
    goto ret0;
  if (register_operand (x2, SImode))
    goto L1513;
  L1532:
  if (register_operand (x2, SImode))
    goto L1541;
  goto ret0;

  L1513:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_205 (recog_operand);
  L1514:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 32) != 0)
    return gen_split_206 (recog_operand);
  goto L1532;

  L1541:
  ro[3] = x2;
  if (reload_completed && !((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_208 (recog_operand);
  L1542:
  ro[3] = x2;
  if (reload_completed && ((target_flags & 0x00010000) != 0) && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((recog_operand[0])->fld[0].rtint) < 68
   && ((recog_operand[1])->code) == REG && ((recog_operand[1])->fld[0].rtint) < 68
   && (((recog_operand[2])->fld[0].rtwint) & 63) < 32
   && (((recog_operand[2])->fld[0].rtwint) & 63) != 0)
    return gen_split_209 (recog_operand);
  goto ret0;
 ret0: return 0;
}

rtx
split_2(register rtx x0, rtx insn) asm("_split_2");
rtx
split_2(register rtx x0, rtx insn)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  rtx tem;

  x1 = ((x0)->fld[0].rtx);
  switch (((x1)->mode))
    {
    case DImode:
      if (register_operand (x1, DImode))
 {
   ro[0] = x1;
   goto L939;
 }
      break;
    case SImode:
      if (register_operand (x1, SImode))
 {
   ro[0] = x1;
   goto L1629;
 }
      break;
    case DFmode:
      if (register_operand (x1, DFmode))
 {
   ro[0] = x1;
   goto L1246;
 }
    }
  goto ret0;

  L939:
  x1 = ((x0)->fld[1].rtx);
  if (((x1)->mode) != DImode)
    goto ret0;
  switch (((x1)->code))
    {
    case NOT:
      goto L956;
    case AND:
      goto L972;
    case IOR:
      goto L992;
    case XOR:
      goto L1007;
    case EQ:
      goto L1640;
    case NE:
      goto L1670;
    case GE:
      goto L1700;
    case LE:
      goto L1740;
    case GEU:
      goto L1770;
    case LEU:
      goto L1810;
    case SUBREG:
    case REG:
      if (register_operand (x1, DImode))
 {
   ro[1] = x1;
   if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
     return gen_split_152 (recog_operand);
   }
    }
  goto ret0;

  L956:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) != DImode)
    goto ret0;
  if (((x2)->code) == IOR && 1)
    goto L957;
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_88 (recog_operand);
      }
  goto ret0;

  L957:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, DImode))
    {
      ro[1] = x3;
      goto L958;
    }
  goto ret0;

  L958:
  x3 = ((x2)->fld[1].rtx);
  if (register_operand (x3, DImode))
    {
      ro[2] = x3;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_91 (recog_operand);
      }
  goto ret0;

  L972:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L973;
    }
  goto ret0;

  L973:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_94 (recog_operand);
      }
  goto ret0;

  L992:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L993;
    }
  goto ret0;

  L993:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_98 (recog_operand);
      }
  goto ret0;

  L1007:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1008;
    }
  goto ret0;

  L1008:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[2])->code) == REG && ((unsigned) ((((recog_operand[2])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_101 (recog_operand);
      }
  goto ret0;

  L1640:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1641;
    }
  goto ret0;

  L1641:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000)
    && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != 0))
 return gen_split_241 (recog_operand);
      }
  goto ret0;

  L1670:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1671;
    }
  goto ret0;

  L1671:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000)
    && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != 0))
 return gen_split_248 (recog_operand);
      }
  goto ret0;

  L1700:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1701;
    }
  goto ret0;

  L1701:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_256 (recog_operand);
      }
  goto ret0;

  L1740:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1741;
    }
  goto ret0;

  L1741:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_266 (recog_operand);
      }
  goto ret0;

  L1770:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1771;
    }
  goto ret0;

  L1771:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_274 (recog_operand);
      }
  goto ret0;

  L1810:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[1] = x2;
      goto L1811;
    }
  goto ret0;

  L1811:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, DImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x00002000) && (target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_284 (recog_operand);
      }
  goto ret0;

  L1629:
  x1 = ((x0)->fld[1].rtx);
  switch (((x1)->mode))
    {
    case SImode:
      switch (((x1)->code))
 {
 case EQ:
   goto L1630;
 case NE:
   goto L1660;
 case GE:
   goto L1690;
 case LE:
   goto L1730;
 case GEU:
   goto L1760;
 case LEU:
   goto L1800;
 }
    }
  if (((x1)->code) == CONST_INT && large_int (x1, SImode))
    {
      ro[1] = x1;
      if (!(target_flags & 0x04000000))
 return gen_split_156 (recog_operand);
      }
  goto ret0;

  L1630:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1631;
    }
  goto ret0;

  L1631:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000)
    && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != 0))
 return gen_split_239 (recog_operand);
      }
  goto ret0;

  L1660:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1661;
    }
  goto ret0;

  L1661:
  x2 = ((x1)->fld[1].rtx);
  if (uns_arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000)
    && (((recog_operand[2])->code) != CONST_INT || ((recog_operand[2])->fld[0].rtwint) != 0))
 return gen_split_246 (recog_operand);
      }
  goto ret0;

  L1690:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1691;
    }
  goto ret0;

  L1691:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_254 (recog_operand);
      }
  goto ret0;

  L1730:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1731;
    }
  goto ret0;

  L1731:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_264 (recog_operand);
      }
  goto ret0;

  L1760:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1761;
    }
  goto ret0;

  L1761:
  x2 = ((x1)->fld[1].rtx);
  if (arith_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_272 (recog_operand);
      }
  goto ret0;

  L1800:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[1] = x2;
      goto L1801;
    }
  goto ret0;

  L1801:
  x2 = ((x1)->fld[1].rtx);
  if (register_operand (x2, SImode))
    {
      ro[2] = x2;
      if ((target_flags & 0x08000000) && !(target_flags & 0x04000000))
 return gen_split_282 (recog_operand);
      }
  goto ret0;

  L1246:
  x1 = ((x0)->fld[1].rtx);
  if (register_operand (x1, DFmode))
    {
      ro[1] = x1;
      if (reload_completed && !(target_flags & 0x00002000) && !(target_flags & 0x04000000) && !(target_flags & 0x00800000)
   && ((recog_operand[0])->code) == REG && ((unsigned) ((((recog_operand[0])->fld[0].rtint)) - 0) < (31 - 0 + 1))
   && ((recog_operand[1])->code) == REG && ((unsigned) ((((recog_operand[1])->fld[0].rtint)) - 0) < (31 - 0 + 1)))
 return gen_split_174 (recog_operand);
      }
  goto ret0;
 ret0: return 0;
}

rtx
split_insns(register rtx x0, rtx insn) asm("_split_insns");
rtx
split_insns(register rtx x0, rtx insn)
{
  register rtx *ro = &recog_operand[0];
  register rtx x1, x2, x3, x4, x5, x6;
  rtx tem;

  L23:
  switch (((x0)->code))
    {
    case PARALLEL:
      if (((x0)->fld[0].rtvec->num_elem) == 2 && 1)
 goto L24;
      if (((x0)->fld[0].rtvec->num_elem) == 8 && 1)
 goto L1277;
      break;
    case SET:
      goto L938;
    }
  goto ret0;

  L24:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L25;
  goto ret0;

  L25:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, DImode))
    {
      ro[0] = x2;
      goto L26;
    }
  goto ret0;
 L26:
  return split_1 (x0, insn);

  L1277:
  x1 = ((x0)->fld[0].rtvec->elem[0].rtx);
  if (((x1)->code) == SET && 1)
    goto L1278;
  goto ret0;

  L1278:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->mode) == BLKmode && ((x2)->code) == MEM && 1)
    goto L1279;
  goto ret0;

  L1279:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[0] = x3;
      goto L1280;
    }
  goto ret0;

  L1280:
  x2 = ((x1)->fld[1].rtx);
  if (((x2)->mode) == BLKmode && ((x2)->code) == MEM && 1)
    goto L1281;
  goto ret0;

  L1281:
  x3 = ((x2)->fld[0].rtx);
  if (register_operand (x3, SImode))
    {
      ro[1] = x3;
      goto L1282;
    }
  goto ret0;

  L1282:
  x1 = ((x0)->fld[0].rtvec->elem[1].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1283;
  goto ret0;

  L1283:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[4] = x2;
      goto L1284;
    }
  goto ret0;

  L1284:
  x1 = ((x0)->fld[0].rtvec->elem[2].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1285;
  goto ret0;

  L1285:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[5] = x2;
      goto L1286;
    }
  goto ret0;

  L1286:
  x1 = ((x0)->fld[0].rtvec->elem[3].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1287;
  goto ret0;

  L1287:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[6] = x2;
      goto L1288;
    }
  goto ret0;

  L1288:
  x1 = ((x0)->fld[0].rtvec->elem[4].rtx);
  if (((x1)->code) == CLOBBER && 1)
    goto L1289;
  goto ret0;

  L1289:
  x2 = ((x1)->fld[0].rtx);
  if (register_operand (x2, SImode))
    {
      ro[7] = x2;
      goto L1290;
    }
  goto ret0;

  L1290:
  x1 = ((x0)->fld[0].rtvec->elem[5].rtx);
  if (((x1)->code) == USE && 1)
    goto L1291;
  goto ret0;

  L1291:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[2] = x2;
      goto L1292;
    }
  goto ret0;

  L1292:
  x1 = ((x0)->fld[0].rtvec->elem[6].rtx);
  if (((x1)->code) == USE && 1)
    goto L1293;
  goto ret0;

  L1293:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == CONST_INT && small_int (x2, SImode))
    {
      ro[3] = x2;
      goto L1294;
    }
  goto ret0;

  L1294:
  x1 = ((x0)->fld[0].rtvec->elem[7].rtx);
  if (((x1)->code) == USE && 1)
    goto L1295;
  goto ret0;

  L1295:
  x2 = ((x1)->fld[0].rtx);
  if (((x2)->code) == CONST_INT && ((x2)->fld[0].rtwint) == 0 && 1)
    if (reload_completed && !(target_flags & 0x04000000) && ((recog_operand[2])->fld[0].rtwint) > 0)
      return gen_split_178 (recog_operand);
  goto ret0;
 L938:
  return split_2 (x0, insn);
 ret0: return 0;
}

