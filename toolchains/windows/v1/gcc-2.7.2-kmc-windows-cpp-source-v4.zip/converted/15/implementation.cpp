// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/print-tree.c
/* Prints out tree in human readable form - GNU C-compiler
   Copyright (C) 1990, 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int obfree(...) asm("_obfree");
extern int target_isinf(...) asm("_target_isinf");
extern int target_isnan(...) asm("_target_isnan");
extern int print_obstack_name(...) asm("_print_obstack_name");
extern int object_permanent_p(...) asm("_object_permanent_p");
extern int print_lang_decl(...) asm("_print_lang_decl");
extern int print_rtl(...) asm("_print_rtl");
extern int print_lang_type(...) asm("_print_lang_type");
extern int print_lang_identifier(...) asm("_print_lang_identifier");
struct n64_tag_bucket;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");


extern char **tree_code_name;

extern char *mode_name[];

void print_node(...) asm("_print_node");
void indent_to(...) asm("_indent_to");






struct n64_tag_bucket
{
  tree node;
  struct n64_tag_bucket *next;
};

static struct n64_tag_bucket **table;





void
debug_tree(tree node) asm("_debug_tree");
void
debug_tree(tree node)
{
  char *object = (char *) oballoc (0);

  table = (struct n64_tag_bucket **) oballoc (37 * sizeof (struct n64_tag_bucket *));
  memset ((char *) table,0,37 * sizeof (struct n64_tag_bucket *));
  print_node (
             (__acrt_iob_func(2))
                   , "", node, 0);
  table = 0;
  obfree (object);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}



void
print_node_brief(FILE *file, char *prefix, tree node, int indent) asm("_print_node_brief");
void
print_node_brief(FILE *file, char *prefix, tree node, int indent)
{
  char cxx_class;

  if (node == 0)
    return;

  cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]);



  if (indent > 0)
    fprintf (file, " ");
  fprintf (file, "%s <%s ", prefix, tree_code_name[(int) ((n64_enum_tree_code) (node)->common.code)]);
  fprintf (file, sizeof (int) == sizeof (char *) ? "%x" : "%lx", (int) node);

  if (cxx_class == 'd')
    {
      if (((node)->decl.name))
 fprintf (file, " %s", ((((node)->decl.name))->identifier.pointer));
    }
  else if (cxx_class == 't')
    {
      if (((node)->type.name))
 {
   if (((n64_enum_tree_code) (((node)->type.name))->common.code) == IDENTIFIER_NODE)
     fprintf (file, " %s", ((((node)->type.name))->identifier.pointer));
   else if (((n64_enum_tree_code) (((node)->type.name))->common.code) == TYPE_DECL
     && ((((node)->type.name))->decl.name))
     fprintf (file, " %s",
       ((((((node)->type.name))->decl.name))->identifier.pointer));
 }
    }
  if (((n64_enum_tree_code) (node)->common.code) == IDENTIFIER_NODE)
    fprintf (file, " %s", ((node)->identifier.pointer));

  if (((n64_enum_tree_code) (node)->common.code) == INTEGER_CST)
    {
      if (((node)->common.static_flag))
 fprintf (file, " overflow");

      if (((node)->int_cst.int_cst_high) == 0)
 fprintf (file,

   " %1u",



   ((node)->int_cst.int_cst_low));
      else if (((node)->int_cst.int_cst_high) == -1
        && ((node)->int_cst.int_cst_low) != 0)
 fprintf (file,

   " -%1u",



   -((node)->int_cst.int_cst_low));
      else
 fprintf (file,
   " 0x%x%08x",


   ((node)->int_cst.int_cst_high), ((node)->int_cst.int_cst_low));
    }
  if (((n64_enum_tree_code) (node)->common.code) == REAL_CST)
    {
      double d;

      if (((node)->common.public_flag))
 fprintf (file, " overflow");


      d = ((node)->real_cst.real_cst);
      if ((target_isinf (d)))
 fprintf (file, " Inf");
      else if ((target_isnan (d)))
 fprintf (file, " Nan");
      else
 {
   char string[100];

   (ereal_to_decimal (d, string));
   fprintf (file, " %s", string);
 }
    }

  fprintf (file, ">");
}

void
indent_to(FILE *file, int column) asm("_indent_to");
void
indent_to(FILE *file, int column)
{
  int i;


  if (column > 0)
    fprintf (file, "\n");
  for (i = 0; i < column; i++)
    fprintf (file, " ");
}




void
print_node(FILE *file, char *prefix, tree node, int indent) asm("_print_node");
void
print_node(FILE *file, char *prefix, tree node, int indent)
{
  int hash;
  struct n64_tag_bucket *b;
  n64_enum_machine_mode mode;
  char cxx_class;
  int len;
  int first_rtl;
  int i;

  if (node == 0)
    return;

  cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]);





  if (indent > 24)
    {
      print_node_brief (file, prefix, node, indent);
      return;
    }

  if (indent > 8 && (cxx_class == 't' || cxx_class == 'd'))
    {
      print_node_brief (file, prefix, node, indent);
      return;
    }


  if (((n64_enum_tree_code) (node)->common.code) == ERROR_MARK)
    {
      print_node_brief (file, prefix, node, indent);
      return;
    }

  hash = ((unsigned int) node) % 37;


  for (b = table[hash]; b; b = b->next)
    if (b->node == node)
      {
 print_node_brief (file, prefix, node, indent);
 return;
      }


  b = (struct n64_tag_bucket *) oballoc (sizeof (struct n64_tag_bucket));
  b->node = node;
  b->next = table[hash];
  table[hash] = b;


  indent_to (file, indent);


  fprintf (file, "%s <%s ", prefix, tree_code_name[(int) ((n64_enum_tree_code) (node)->common.code)]);
  fprintf (file, sizeof (int) == sizeof (char *) ? "%x" : "%lx", (int) node);


  if (cxx_class == 'd')
    {
      if (((node)->decl.name))
 fprintf (file, " %s", ((((node)->decl.name))->identifier.pointer));
    }
  else if (cxx_class == 't')
    {
      if (((node)->type.name))
 {
   if (((n64_enum_tree_code) (((node)->type.name))->common.code) == IDENTIFIER_NODE)
     fprintf (file, " %s", ((((node)->type.name))->identifier.pointer));
   else if (((n64_enum_tree_code) (((node)->type.name))->common.code) == TYPE_DECL
     && ((((node)->type.name))->decl.name))
     fprintf (file, " %s",
       ((((((node)->type.name))->decl.name))->identifier.pointer));
 }
    }
  if (((n64_enum_tree_code) (node)->common.code) == IDENTIFIER_NODE)
    fprintf (file, " %s", ((node)->identifier.pointer));

  if (((n64_enum_tree_code) (node)->common.code) == INTEGER_CST)
    {
      if (indent <= 4)
 print_node_brief (file, "type", ((node)->common.type), indent + 4);
    }
  else
    {
      print_node (file, "type", ((node)->common.type), indent + 4);
      if (((node)->common.type))
 indent_to (file, indent + 3);

      print_obstack_name ((char *) node, file, "");
      indent_to (file, indent + 3);
    }


  if (object_permanent_p (node) != ((node)->common.permanent_flag))
    {
      if (((node)->common.permanent_flag))
 fputs (" !!permanent object in non-permanent obstack!!", file);
      else
 fputs (" !!non-permanent object in permanent obstack!!", file);
      indent_to (file, indent + 3);
    }

  if (((node)->common.side_effects_flag))
    fputs (" side-effects", file);
  if (((node)->common.readonly_flag))
    fputs (" readonly", file);
  if (((node)->common.constant_flag))
    fputs (" constant", file);
  if (((node)->common.addressable_flag))
    fputs (" addressable", file);
  if (((node)->common.volatile_flag))
    fputs (" volatile", file);
  if (((node)->common.unsigned_flag))
    fputs (" unsigned", file);
  if (((node)->common.asm_written_flag))
    fputs (" asm_written", file);
  if (((node)->common.used_flag))
    fputs (" used", file);
  if (((node)->common.raises_flag))
    fputs (" raises", file);
  if (((node)->common.permanent_flag))
    fputs (" permanent", file);
  if (((node)->common.public_flag))
    fputs (" public", file);
  if (((node)->common.static_flag))
    fputs (" static", file);
  if (((node)->common.lang_flag_0))
    fputs (" tree_0", file);
  if (((node)->common.lang_flag_1))
    fputs (" tree_1", file);
  if (((node)->common.lang_flag_2))
    fputs (" tree_2", file);
  if (((node)->common.lang_flag_3))
    fputs (" tree_3", file);
  if (((node)->common.lang_flag_4))
    fputs (" tree_4", file);
  if (((node)->common.lang_flag_5))
    fputs (" tree_5", file);
  if (((node)->common.lang_flag_6))
    fputs (" tree_6", file);



  switch ((*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]))
    {
    case 'd':
      mode = ((node)->decl.mode);

      if (((node)->decl.ignored_flag))
 fputs (" ignored", file);
      if (((node)->decl.abstract_flag))
 fputs (" abstract", file);
      if (((node)->decl.in_system_header_flag))
 fputs (" in_system_header", file);
      if (((node)->decl.common_flag))
 fputs (" common", file);
      if (((node)->decl.external_flag))
 fputs (" external", file);
      if (((node)->decl.regdecl_flag))
 fputs (" regdecl", file);
      if (((node)->decl.regdecl_flag))
 fputs (" packed", file);
      if (((node)->decl.nonlocal_flag))
 fputs (" nonlocal", file);
      if (((node)->decl.inline_flag))
 fputs (" inline", file);

      if (((n64_enum_tree_code) (node)->common.code) == TYPE_DECL && ((node)->decl.external_flag))
 fputs (" suppress-debug", file);

      if (((n64_enum_tree_code) (node)->common.code) == FUNCTION_DECL && ((node)->decl.bit_field_flag))
 fputs (" built-in", file);
      if (((n64_enum_tree_code) (node)->common.code) == FUNCTION_DECL && ((node)->common.unsigned_flag))
 fputs (" built-in-nonansi", file);

      if (((n64_enum_tree_code) (node)->common.code) == FIELD_DECL && ((node)->decl.bit_field_flag))
 fputs (" bit-field", file);
      if (((n64_enum_tree_code) (node)->common.code) == LABEL_DECL && ((node)->decl.bit_field_flag))
 fputs (" too-late", file);
      if (((n64_enum_tree_code) (node)->common.code) == VAR_DECL && ((node)->decl.bit_field_flag))
 fputs (" in-text-section", file);

      if (((node)->decl.virtual_flag))
 fputs (" virtual", file);
      if (((node)->decl.defer_output))
 fputs (" defer-output", file);
      if (((node)->decl.transparent_union))
 fputs (" transparent-union", file);

      if (((node)->decl.lang_flag_0))
 fputs (" decl_0", file);
      if (((node)->decl.lang_flag_1))
 fputs (" decl_1", file);
      if (((node)->decl.lang_flag_2))
 fputs (" decl_2", file);
      if (((node)->decl.lang_flag_3))
 fputs (" decl_3", file);
      if (((node)->decl.lang_flag_4))
 fputs (" decl_4", file);
      if (((node)->decl.lang_flag_5))
 fputs (" decl_5", file);
      if (((node)->decl.lang_flag_6))
 fputs (" decl_6", file);
      if (((node)->decl.lang_flag_7))
 fputs (" decl_7", file);

      fprintf (file, " %s", mode_name[(int) mode]);

      fprintf (file, " file %s line %d",
        ((node)->decl.filename), ((node)->decl.linenum));

      print_node (file, "size", ((node)->decl.size), indent + 4);
      print_node (file, "attributes", ((node)->type.attributes), indent + 4);
      indent_to (file, indent + 3);
      if (((n64_enum_tree_code) (node)->common.code) != FUNCTION_DECL)
 fprintf (file, " align %d", ((node)->decl.frame_size.u));
      else if (((node)->decl.inline_flag))
 fprintf (file, " frame_size %d", ((node)->decl.frame_size.i));
      else if (((node)->decl.bit_field_flag))
 fprintf (file, " built-in code %d", ((node)->decl.frame_size.f));
      if (((n64_enum_tree_code) (node)->common.code) == FIELD_DECL)
 print_node (file, "bitpos", ((node)->decl.arguments), indent + 4);
      print_node_brief (file, "context", ((node)->decl.context), indent + 4);
      print_node_brief (file, "machine_attributes", ((node)->decl.machine_attributes), indent + 4);
      print_node_brief (file, "abstract_origin",
   ((node)->decl.abstract_origin), indent + 4);

      print_node (file, "arguments", ((node)->decl.arguments), indent + 4);
      print_node (file, "result", ((node)->decl.result), indent + 4);
      print_node_brief (file, "initial", ((node)->decl.initial), indent + 4);

      print_lang_decl (file, node, indent);

      if (((node)->decl.rtl) != 0)
 {
   indent_to (file, indent + 4);
   print_rtl (file, ((node)->decl.rtl));
 }

      if (((node)->decl.saved_insns.r) != 0)
 {
   indent_to (file, indent + 4);
   if (((n64_enum_tree_code) (node)->common.code) == PARM_DECL)
     {
       fprintf (file, "incoming-rtl ");
       print_rtl (file, ((node)->decl.saved_insns.r));
     }
   else if (((n64_enum_tree_code) (node)->common.code) == FUNCTION_DECL)
     {
       fprintf (file, "saved-insns ");
       fprintf (file, sizeof (int) == sizeof (char *) ? "%x" : "%lx",
          (int) ((node)->decl.saved_insns.r));
     }
 }


      if (indent == 4)
 print_node (file, "chain", ((node)->common.chain), indent + 4);
      else
 print_node_brief (file, "chain", ((node)->common.chain), indent + 4);
      break;

    case 't':
      if (((node)->type.no_force_blk_flag))
 fputs (" no-force-blk", file);
      if (((node)->type.string_flag))
 fputs (" string-flag", file);
      if (((node)->type.needs_constructing_flag))
 fputs (" needs-constructing", file);
      if (((node)->type.transparent_union_flag))
 fputs (" transparent-union", file);
      if (((node)->type.packed_flag))
 fputs (" packed", file);

      if (((node)->type.lang_flag_0))
 fputs (" type_0", file);
      if (((node)->type.lang_flag_1))
 fputs (" type_1", file);
      if (((node)->type.lang_flag_2))
 fputs (" type_2", file);
      if (((node)->type.lang_flag_3))
 fputs (" type_3", file);
      if (((node)->type.lang_flag_4))
 fputs (" type_4", file);
      if (((node)->type.lang_flag_5))
 fputs (" type_5", file);
      if (((node)->type.lang_flag_6))
 fputs (" type_6", file);

      mode = ((node)->type.mode);
      fprintf (file, " %s", mode_name[(int) mode]);

      print_node (file, "size", ((node)->type.size), indent + 4);
      indent_to (file, indent + 3);

      fprintf (file, " align %d", ((node)->type.align));
      fprintf (file, " symtab %d", ((node)->type.symtab.address));

      print_node (file, "attributes", ((node)->type.attributes), indent + 4);

      if (((n64_enum_tree_code) (node)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (node)->common.code) == SET_TYPE)
 print_node (file, "domain", ((node)->type.values), indent + 4);
      else if (((n64_enum_tree_code) (node)->common.code) == INTEGER_TYPE
        || ((n64_enum_tree_code) (node)->common.code) == BOOLEAN_TYPE
        || ((n64_enum_tree_code) (node)->common.code) == CHAR_TYPE)
 {
   fprintf (file, " precision %d", ((node)->type.precision));
   print_node (file, "min", ((node)->type.minval), indent + 4);
   print_node (file, "max", ((node)->type.maxval), indent + 4);
 }
      else if (((n64_enum_tree_code) (node)->common.code) == ENUMERAL_TYPE)
 {
   fprintf (file, " precision %d", ((node)->type.precision));
   print_node (file, "min", ((node)->type.minval), indent + 4);
   print_node (file, "max", ((node)->type.maxval), indent + 4);
   print_node (file, "values", ((node)->type.values), indent + 4);
 }
      else if (((n64_enum_tree_code) (node)->common.code) == REAL_TYPE)
 fprintf (file, " precision %d", ((node)->type.precision));
      else if (((n64_enum_tree_code) (node)->common.code) == RECORD_TYPE
        || ((n64_enum_tree_code) (node)->common.code) == UNION_TYPE
        || ((n64_enum_tree_code) (node)->common.code) == QUAL_UNION_TYPE)
 print_node (file, "fields", ((node)->type.values), indent + 4);
      else if (((n64_enum_tree_code) (node)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (node)->common.code) == METHOD_TYPE)
 {
   if (((node)->type.maxval))
     print_node_brief (file, "method basetype", ((node)->type.maxval), indent + 4);
   print_node (file, "arg-types", ((node)->type.values), indent + 4);
 }
      if (((node)->type.context))
 print_node_brief (file, "context", ((node)->type.context), indent + 4);

      print_lang_type (file, node, indent);

      if (((node)->type.pointer_to) || ((node)->common.chain))
 indent_to (file, indent + 3);
      print_node_brief (file, "pointer_to_this", ((node)->type.pointer_to), indent + 4);
      print_node_brief (file, "reference_to_this", ((node)->type.reference_to), indent + 4);
      print_node_brief (file, "chain", ((node)->common.chain), indent + 4);
      break;

    case 'b':
      print_node (file, "vars", ((node)->block.vars), indent + 4);
      print_node (file, "tags", ((node)->block.type_tags), indent + 4);
      print_node (file, "supercontext", ((node)->block.supercontext), indent + 4);
      print_node (file, "subblocks", ((node)->block.subblocks), indent + 4);
      print_node (file, "chain", ((node)->common.chain), indent + 4);
      print_node (file, "abstract_origin",
    ((node)->block.abstract_origin), indent + 4);
      return;

    case 'e':
    case '<':
    case '1':
    case '2':
    case 'r':
    case 's':
      switch (((n64_enum_tree_code) (node)->common.code))
 {
 case BIND_EXPR:
   print_node (file, "vars", ((node)->exp.operands[0]), indent + 4);
   print_node (file, "body", ((node)->exp.operands[1]), indent + 4);
   print_node (file, "block", ((node)->exp.operands[2]), indent + 4);
   return;
 }

      first_rtl = len = tree_code_length[(int) ((n64_enum_tree_code) (node)->common.code)];


      switch (((n64_enum_tree_code) (node)->common.code))
 {
 case SAVE_EXPR:
   first_rtl = 2;
   break;
 case CALL_EXPR:
   first_rtl = 2;
   break;
 case METHOD_CALL_EXPR:
   first_rtl = 3;
   break;
 case WITH_CLEANUP_EXPR:

   first_rtl = 1;
   break;
 case RTL_EXPR:
   first_rtl = 0;
 }
      for (i = 0; i < len; i++)
 {
   if (i >= first_rtl)
     {
       indent_to (file, indent + 4);
       fprintf (file, "rtl %d ", i);
       if (((node)->exp.operands[i]))
  print_rtl (file, (struct rtx_def *) ((node)->exp.operands[i]));
       else
  fprintf (file, "(nil)");
       fprintf (file, "\n");
     }
   else
     {
       char temp[10];

       sprintf (temp, "arg %d", i);
       print_node (file, temp, ((node)->exp.operands[i]), indent + 4);
     }
 }
      break;

    case 'c':
    case 'x':
      switch (((n64_enum_tree_code) (node)->common.code))
 {
 case INTEGER_CST:
   if (((node)->common.static_flag))
     fprintf (file, " overflow");

   if (((node)->int_cst.int_cst_high) == 0)
     fprintf (file,

       " %1u",



       ((node)->int_cst.int_cst_low));
   else if (((node)->int_cst.int_cst_high) == -1
     && ((node)->int_cst.int_cst_low) != 0)
     fprintf (file,

       " -%1u",



       -((node)->int_cst.int_cst_low));
   else
     fprintf (file,
       " 0x%x%08x",


       ((node)->int_cst.int_cst_high), ((node)->int_cst.int_cst_low));
   break;

 case REAL_CST:
   {
     double d;

     if (((node)->common.public_flag))
       fprintf (file, " overflow");


     d = ((node)->real_cst.real_cst);
     if ((target_isinf (d)))
       fprintf (file, " Inf");
     else if ((target_isnan (d)))
       fprintf (file, " Nan");
     else
       {
  char string[100];

  (ereal_to_decimal (d, string));
  fprintf (file, " %s", string);
       }
   }
   break;

 case COMPLEX_CST:
   print_node (file, "real", ((node)->complex.real), indent + 4);
   print_node (file, "imag", ((node)->complex.imag), indent + 4);
   break;

 case STRING_CST:
   fprintf (file, " \"%s\"", ((node)->string.pointer));

   if (indent == 4)
     print_node (file, "chain", ((node)->common.chain), indent + 4);
   else
     print_node_brief (file, "chain", ((node)->common.chain), indent + 4);
   break;

 case IDENTIFIER_NODE:
   print_lang_identifier (file, node, indent);
   break;

 case TREE_LIST:
   print_node (file, "purpose", ((node)->list.purpose), indent + 4);
   print_node (file, "value", ((node)->list.value), indent + 4);
   print_node (file, "chain", ((node)->common.chain), indent + 4);
   break;

 case TREE_VEC:
   len = ((node)->vec.length);
   for (i = 0; i < len; i++)
     if (((node)->vec.a[i]))
       {
  char temp[10];
  sprintf (temp, "elt %d", i);
  indent_to (file, indent + 4);
  print_node_brief (file, temp, ((node)->vec.a[i]), 0);
       }
   break;

 case OP_IDENTIFIER:
   print_node (file, "op1", ((node)->list.purpose), indent + 4);
   print_node (file, "op2", ((node)->list.value), indent + 4);
 }

      break;
    }

  fprintf (file, ">");
}

