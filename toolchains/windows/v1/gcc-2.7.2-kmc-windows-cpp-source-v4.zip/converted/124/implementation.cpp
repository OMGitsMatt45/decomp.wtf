// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);



extern int bcmp (char *s1 , char *s2 , int length) asm("_bcmp");
extern void bcopy (char *s1 , char *s2 , int length) asm("_bcopy");
extern void bzero (char *s , int length) asm("_bzero");
extern unsigned long clock(...) asm("_clock");
extern int getopt (int argc , char **argv , const char *optstring) asm("_getopt");

extern int getpagesize(...) asm("_getpagesize");
extern char* getcwd (char *buf , int len) asm("_getcwd");
extern char* index (char *s , int c) asm("_index");
extern void insque(...) asm("_insque");
extern void * memchr (const void * s , int c , size_t length) asm("_memchr");
extern int memcmp (const void * s1 , const void * s2 , size_t length) asm("_memcmp");

extern void * memcpy (void * s1 , const void * s2 , size_t length) asm("_memcpy");
extern void * memmove (void * s1 , const void * s2 , size_t length) asm("_memmove");
extern void * memset (void * s , int val , size_t length) asm("_memset");
extern long int random (void) asm("_random");


extern int rename (char *f , char *t) asm("_rename");


extern char* rindex (char *s , int c) asm("_rindex");
extern int strcasecmp (char *s1 , char *s2) asm("_strcasecmp");
extern int strncasecmp (char *s1 , char *s2 , int n) asm("_strncasecmp");
extern char* strchr (const char *s , int c) asm("_strchr");
extern char* strdup (char * s1) asm("_strdup");
extern char* strrchr (const char *s , int c) asm("_strrchr");
extern char* strstr(...) asm("_strstr");
extern double strtod(...) asm("_strtod");
extern long strtol(...) asm("_strtol");
extern unsigned long strtoul(...) asm("_strtoul");
extern char * tmpnam (char * s) asm("_tmpnam");


extern int vfork(void) asm("_vfork");


extern int vfprintf(...) asm("_vfprintf");
extern int vprintf(...) asm("_vprintf");
extern int vsprintf(...) asm("_vsprintf");


extern int sigsetmask(...) asm("_sigsetmask");
extern void * __builtin_alloca (size_t size) asm("___builtin_alloca");
extern int waitpid (int pid , int* statp , int opts) asm("_waitpid");
extern int sys_nerr;
extern char *sys_errlist[];
extern char *sys_siglist[];







extern char* strerror(...) asm("_strerror");
extern void psignal (unsigned signo , char *message) asm("_psignal");
extern char * basename (const char *name) asm("_basename");



int
main(int argc, char **argv) asm("_main");
int
main(int argc, char **argv)
{
{ char *s1 = 0; char *s2 = 0; int length; bcmp (s1, s2, length); }
{ char *s1 = 0; char *s2 = 0; int length; bcopy (s1, s2, length); }
{ char *s = 0; int length; bzero (s, length); }
{ ; clock (); }
{ int argc = 0; char **argv = 0; const char *optstring; getopt (argc, argv, optstring); }

{ ; getpagesize (); }
{ char *buf = 0; int len; getcwd (buf, len); }
{ char *s = 0; int c; index (s, c); }
{ ; insque (); }
{ const void * s = 0; int c = 0; size_t length; memchr (s, c, length); }
{ const void * s1 = 0; const void * s2 = 0; size_t length; memcmp (s1, s2, length); }

{ void * s1 = 0; const void * s2 = 0; size_t length; memcpy (s1, s2, length); }
{ void * s1 = 0; const void * s2 = 0; size_t length; memmove (s1, s2, length); }
{ void * s = 0; int val = 0; size_t length; memset (s, val, length); }
{ ; random (); }


{ char *f = 0; char *t; rename (f, t); }


{ char *s = 0; int c; rindex (s, c); }
{ char *s1 = 0; char *s2; strcasecmp (s1, s2); }
{ char *s1 = 0; char *s2 = 0; int n; strncasecmp (s1, s2, n); }
{ const char *s = 0; int c; strchr (s, c); }
{ char * s1; strdup (s1); }
{ const char *s = 0; int c; strrchr (s, c); }
{ ; strstr (); }
{ ; strtod (); }
{ ; strtol (); }
{ ; strtoul (); }
{ char * s; tmpnam (s); }


{ ; vfork (); }


{ ; vfprintf (); }
{ ; vprintf (); }
{ ; vsprintf (); }


{ ; sigsetmask (); }
{ size_t size; __builtin_alloca (size); }
{ int pid = 0; int* statp = 0; int opts; waitpid (pid, statp, opts); }
{ sys_nerr = 0; }
{ sys_errlist[0] = 0; }
{ sys_siglist[0] = 0; }







{ ; strerror (); }
{ unsigned signo = 0; char *message; psignal (signo, message); }
{ const char *name; basename (name); }

  return (0);
}

