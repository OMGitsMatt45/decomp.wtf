// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cexp.c
/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int pedwarn(...) asm("_pedwarn");
extern int check_assertion(...) asm("_check_assertion");
extern int error(...) asm("_error");
extern int warning(...) asm("_warning");
extern int parse_escape(...) asm("_parse_escape");
extern int lookup(...) asm("_lookup");
struct n64_tag_arglist;
struct n64_tag_constant;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_name;
struct n64_tag_token;
struct n64_tag_yyltype;


extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");









typedef unsigned char U_CHAR;


struct n64_tag_arglist {
  struct n64_tag_arglist *next;
  U_CHAR *name;
  int length;
  int argno;
};
int yylex(void) asm("_yylex");
void yyerror(...) asm("_yyerror");
int expression_value;

static jmp_buf parse_return_error;


static int keyword_parsing = 0;



static int skip_evaluation;


extern unsigned char is_idstart[], is_idchar[], is_hor_space[];

extern char *xmalloc(...) asm("_xmalloc");


extern int pedantic;


extern int traditional;
static void integer_overflow(void) asm("_integer_overflow");
static long left_shift(...) asm("_left_shift");
static long right_shift(...) asm("_right_shift");
struct n64_tag_name {U_CHAR *address; int length;};
struct n64_tag_constant {long value; int unsignedp;};
typedef union {
  struct n64_tag_constant integer;
  struct n64_tag_name name;
  struct n64_tag_arglist *keywords;
} YYSTYPE;


typedef
  struct n64_tag_yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
static const char yytranslate[] = { 0,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 29, 2, 31, 2, 27, 14, 2, 32,
    33, 25, 23, 9, 24, 2, 26, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 8, 2, 17,
     2, 18, 7, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 13, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 12, 2, 30, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 1, 2, 3, 4, 5,
     6, 10, 11, 15, 16, 19, 20, 21, 22, 28
};
static const short yyr1[] = { 0,
    34, 35, 35, 36, 36, 36, 36, 36, 37, 36,
    36, 36, 36, 36, 36, 36, 36, 36, 36, 36,
    36, 36, 36, 36, 36, 36, 36, 38, 36, 39,
    36, 40, 41, 36, 36, 36, 36, 42, 42, 42
};

static const short yyr2[] = { 0,
     1, 1, 3, 2, 2, 2, 2, 2, 0, 6,
     3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
     3, 3, 3, 3, 3, 3, 3, 0, 4, 0,
     4, 0, 0, 7, 1, 1, 1, 0, 4, 2
};

static const short yydefact[] = { 0,
    35, 36, 37, 0, 0, 0, 0, 0, 0, 1,
     2, 6, 4, 5, 7, 8, 0, 0, 32, 30,
    28, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 11, 3,
     0, 0, 0, 27, 26, 25, 19, 20, 23, 24,
    21, 22, 17, 18, 15, 16, 12, 13, 14, 38,
     0, 31, 29, 38, 38, 0, 33, 40, 0, 10,
     0, 38, 34, 39, 0, 0, 0
};

static const short yydefgoto[] = { 75,
    10, 11, 38, 43, 42, 41, 71, 66
};

static const short yypact[] = { 12,
-32768,-32768,-32768, 12, 12, 12, 12, 1, 12, 4,
    79,-32768,-32768,-32768,-32768, -21, 31, 12,-32768,-32768,
-32768, 12, 12, 12, 12, 12, 12, 12, 12, 12,
    12, 12, 12, 12, 12, 12, 12, 30,-32768, 79,
    12, 12, 12, 110, 124, 137, 148, 148, 155, 155,
   155, 155, 160, 160, -17, -17,-32768,-32768,-32768, 2,
    58, 34, 95, 2, 2, 54,-32768,-32768, 55,-32768,
    12, 2, 79,-32768, 63, 188,-32768
};

static const short yypgoto[] = {-32768,
   180, -4,-32768,-32768,-32768,-32768,-32768, -60
};





static const short yytable[] = { 12,
    13, 14, 15, 68, 69, 16, 64, 35, 36, 37,
    -9, 74, 18, 40, 1, 2, 3, 44, 45, 46,
    47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
    57, 58, 59, 65, 4, 5, 61, 62, 63, 18,
     6, 7, 8, 9, 21, 22, 23, 24, 25, 26,
    27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 60, 76, 39, 19, 67, 73, 20, 21, 22,
    23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 19, 70, 72, 20, 21,
    22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
    36, 37, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 24, 25, 26,
    27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 25, 26, 27, 28, 29, 30, 31, 32, 33,
    34, 35, 36, 37, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 31, 32, 33, 34, 35,
    36, 37, 33, 34, 35, 36, 37, 77, 17
};

static const short yycheck[] = { 4,
     5, 6, 7, 64, 65, 5, 5, 25, 26, 27,
    32, 72, 9, 18, 3, 4, 5, 22, 23, 24,
    25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
    35, 36, 37, 32, 23, 24, 41, 42, 43, 9,
    29, 30, 31, 32, 11, 12, 13, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
    27, 32, 0, 33, 7, 8, 71, 10, 11, 12,
    13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
    23, 24, 25, 26, 27, 7, 33, 33, 10, 11,
    12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
    22, 23, 24, 25, 26, 27, 12, 13, 14, 15,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 14, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
    27, 15, 16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27, 17, 18, 19, 20, 21, 22,
    23, 24, 25, 26, 27, 21, 22, 23, 24, 25,
    26, 27, 23, 24, 25, 26, 27, 0, 9
};
int yychar;
YYSTYPE yylval;







int yynerrs;
int yyparse (void) asm("_yyparse");
int
yyparse(void) asm("_yyparse");
int
yyparse(void)
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;
  int yychar1 = 0;

  short yyssa[200];
  YYSTYPE yyvsa[200];

  short *yyss = yyssa;
  YYSTYPE *yyvs = yyvsa;
  int yystacksize = 200;
  YYSTYPE yyval;



  int yylen;






  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = -2;






  yyssp = yyss - 1;
  yyvsp = yyvs;







yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {


      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;





      int size = yyssp - yyss + 1;
      if (yystacksize >= 10000)
 {
   yyerror("parser stack overflow");
   return 2;
 }
      yystacksize *= 2;
      if (yystacksize > 10000)
 yystacksize = 10000;
      yyss = (short *) 
                      __builtin_alloca((
                      yystacksize * sizeof (*yyssp)
                      ))
                                                            ;
      __builtin_memcpy((char *)yyss,(char *)yyss1,size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) 
                        __builtin_alloca((
                        yystacksize * sizeof (*yyvsp)
                        ))
                                                              ;
      __builtin_memcpy((char *)yyvs,(char *)yyvs1,size * sizeof (*yyvsp));






      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
      if (yyssp >= yyss + yystacksize - 1)
 return(1);
    }






  goto yybackup;
 yybackup:







  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yydefault;






  if (yychar == -2)
    {




      yychar = yylex();
    }



  if (yychar <= 0)
    {
      yychar1 = 0;
      yychar = 0;





    }
  else
    {
      yychar1 = ((unsigned)(yychar) <= 270 ? yytranslate[yychar] : 43);
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > 189 || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == 77)
    return(0);
  if (yychar != 0)
    yychar = -2;

  *++yyvsp = yylval;





  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;


yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen];
  switch (yyn) {

case 1:
{ expression_value = yyvsp[0].integer.value; ;
    break;}
case 3:
{ if (pedantic)
       pedwarn ("comma operator in operand of `#if'");
     yyval.integer = yyvsp[0].integer; ;
    break;}
case 4:
{ yyval.integer.value = - yyvsp[0].integer.value;
     if ((yyval.integer.value & yyvsp[0].integer.value) < 0 && ! yyvsp[0].integer.unsignedp)
       integer_overflow ();
     yyval.integer.unsignedp = yyvsp[0].integer.unsignedp; ;
    break;}
case 5:
{ yyval.integer.value = ! yyvsp[0].integer.value;
     yyval.integer.unsignedp = 0; ;
    break;}
case 6:
{ yyval.integer = yyvsp[0].integer; ;
    break;}
case 7:
{ yyval.integer.value = ~ yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[0].integer.unsignedp; ;
    break;}
case 8:
{ yyval.integer.value = check_assertion (yyvsp[0].name.address, yyvsp[0].name.length,
            0, ((void *)0));
     yyval.integer.unsignedp = 0; ;
    break;}
case 9:
{ keyword_parsing = 1; ;
    break;}
case 10:
{ yyval.integer.value = check_assertion (yyvsp[-4].name.address, yyvsp[-4].name.length,
            1, yyvsp[-1].keywords);
     keyword_parsing = 0;
     yyval.integer.unsignedp = 0; ;
    break;}
case 11:
{ yyval.integer = yyvsp[-1].integer; ;
    break;}
case 12:
{ yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp;
     if (yyval.integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value * yyvsp[0].integer.value;
     else
       {
         yyval.integer.value = yyvsp[-2].integer.value * yyvsp[0].integer.value;
         if (yyvsp[-2].integer.value
      && (yyval.integer.value / yyvsp[-2].integer.value != yyvsp[0].integer.value
          || (yyval.integer.value & yyvsp[-2].integer.value & yyvsp[0].integer.value) < 0))
    integer_overflow ();
       } ;
    break;}
case 13:
{ if (yyvsp[0].integer.value == 0)
       {
         if (!skip_evaluation)
    error ("division by zero in #if");
         yyvsp[0].integer.value = 1;
       }
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp;
     if (yyval.integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value / yyvsp[0].integer.value;
     else
       {
         yyval.integer.value = yyvsp[-2].integer.value / yyvsp[0].integer.value;
         if ((yyval.integer.value & yyvsp[-2].integer.value & yyvsp[0].integer.value) < 0)
    integer_overflow ();
       } ;
    break;}
case 14:
{ if (yyvsp[0].integer.value == 0)
       {
         if (!skip_evaluation)
    error ("division by zero in #if");
         yyvsp[0].integer.value = 1;
       }
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp;
     if (yyval.integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value % yyvsp[0].integer.value;
     else
       yyval.integer.value = yyvsp[-2].integer.value % yyvsp[0].integer.value; ;
    break;}
case 15:
{ yyval.integer.value = yyvsp[-2].integer.value + yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp;
     if (! yyval.integer.unsignedp
         && ! ((((yyvsp[-2].integer.value) ^ (yyvsp[0].integer.value)) | ~ ((yyvsp[-2].integer.value) ^ (yyval.integer.value))) < 0)
                                )
       integer_overflow (); ;
    break;}
case 16:
{ yyval.integer.value = yyvsp[-2].integer.value - yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp;
     if (! yyval.integer.unsignedp
         && ! ((((yyval.integer.value) ^ (yyvsp[0].integer.value)) | ~ ((yyval.integer.value) ^ (yyvsp[-2].integer.value))) < 0)
                                    )
       integer_overflow (); ;
    break;}
case 17:
{ yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp;
     if (yyvsp[0].integer.value < 0 && ! yyvsp[0].integer.unsignedp)
       yyval.integer.value = right_shift (&yyvsp[-2].integer, -yyvsp[0].integer.value);
     else
       yyval.integer.value = left_shift (&yyvsp[-2].integer, yyvsp[0].integer.value); ;
    break;}
case 18:
{ yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp;
     if (yyvsp[0].integer.value < 0 && ! yyvsp[0].integer.unsignedp)
       yyval.integer.value = left_shift (&yyvsp[-2].integer, -yyvsp[0].integer.value);
     else
       yyval.integer.value = right_shift (&yyvsp[-2].integer, yyvsp[0].integer.value); ;
    break;}
case 19:
{ yyval.integer.value = (yyvsp[-2].integer.value == yyvsp[0].integer.value);
     yyval.integer.unsignedp = 0; ;
    break;}
case 20:
{ yyval.integer.value = (yyvsp[-2].integer.value != yyvsp[0].integer.value);
     yyval.integer.unsignedp = 0; ;
    break;}
case 21:
{ yyval.integer.unsignedp = 0;
     if (yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value <= yyvsp[0].integer.value;
     else
       yyval.integer.value = yyvsp[-2].integer.value <= yyvsp[0].integer.value; ;
    break;}
case 22:
{ yyval.integer.unsignedp = 0;
     if (yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value >= yyvsp[0].integer.value;
     else
       yyval.integer.value = yyvsp[-2].integer.value >= yyvsp[0].integer.value; ;
    break;}
case 23:
{ yyval.integer.unsignedp = 0;
     if (yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value < yyvsp[0].integer.value;
     else
       yyval.integer.value = yyvsp[-2].integer.value < yyvsp[0].integer.value; ;
    break;}
case 24:
{ yyval.integer.unsignedp = 0;
     if (yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp)
       yyval.integer.value = (unsigned long) yyvsp[-2].integer.value > yyvsp[0].integer.value;
     else
       yyval.integer.value = yyvsp[-2].integer.value > yyvsp[0].integer.value; ;
    break;}
case 25:
{ yyval.integer.value = yyvsp[-2].integer.value & yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp; ;
    break;}
case 26:
{ yyval.integer.value = yyvsp[-2].integer.value ^ yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp; ;
    break;}
case 27:
{ yyval.integer.value = yyvsp[-2].integer.value | yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-2].integer.unsignedp || yyvsp[0].integer.unsignedp; ;
    break;}
case 28:
{ skip_evaluation += !yyvsp[-1].integer.value; ;
    break;}
case 29:
{ skip_evaluation -= !yyvsp[-3].integer.value;
     yyval.integer.value = (yyvsp[-3].integer.value && yyvsp[0].integer.value);
     yyval.integer.unsignedp = 0; ;
    break;}
case 30:
{ skip_evaluation += !!yyvsp[-1].integer.value; ;
    break;}
case 31:
{ skip_evaluation -= !!yyvsp[-3].integer.value;
     yyval.integer.value = (yyvsp[-3].integer.value || yyvsp[0].integer.value);
     yyval.integer.unsignedp = 0; ;
    break;}
case 32:
{ skip_evaluation += !yyvsp[-1].integer.value; ;
    break;}
case 33:
{ skip_evaluation += !!yyvsp[-4].integer.value - !yyvsp[-4].integer.value; ;
    break;}
case 34:
{ skip_evaluation -= !!yyvsp[-6].integer.value;
     yyval.integer.value = yyvsp[-6].integer.value ? yyvsp[-3].integer.value : yyvsp[0].integer.value;
     yyval.integer.unsignedp = yyvsp[-3].integer.unsignedp || yyvsp[0].integer.unsignedp; ;
    break;}
case 35:
{ yyval.integer = yylval.integer; ;
    break;}
case 36:
{ yyval.integer = yylval.integer; ;
    break;}
case 37:
{ yyval.integer.value = 0;
     yyval.integer.unsignedp = 0; ;
    break;}
case 38:
{ yyval.keywords = 0; ;
    break;}
case 39:
{ struct n64_tag_arglist *temp;
     yyval.keywords = (struct n64_tag_arglist *) xmalloc (sizeof (struct n64_tag_arglist));
     yyval.keywords->next = yyvsp[-2].keywords;
     yyval.keywords->name = (U_CHAR *) "(";
     yyval.keywords->length = 1;
     temp = yyval.keywords;
     while (temp != 0 && temp->next != 0)
       temp = temp->next;
     temp->next = (struct n64_tag_arglist *) xmalloc (sizeof (struct n64_tag_arglist));
     temp->next->next = yyvsp[0].keywords;
     temp->next->name = (U_CHAR *) ")";
     temp->next->length = 1; ;
    break;}
case 40:
{ yyval.keywords = (struct n64_tag_arglist *) xmalloc (sizeof (struct n64_tag_arglist));
     yyval.keywords->name = yyvsp[-1].name.address;
     yyval.keywords->length = yyvsp[-1].name.length;
     yyval.keywords->next = yyvsp[0].keywords; ;
    break;}
}

  yyvsp -= yylen;
  yyssp -= yylen;
  *++yyvsp = yyval;
  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - 34] + *yyssp;
  if (yystate >= 0 && yystate <= 189 && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - 34];

  goto yynewstate;

yyerrlab:

  if (! yyerrstatus)

    {
      ++yynerrs;
 yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:

  if (yyerrstatus == 3)
    {



      if (yychar == 0)
 return(1);






      yychar = -2;
    }




  yyerrstatus = 3;

  goto yyerrhandle;

yyerrdefault:
yyerrpop:

  if (yyssp == yyss) return(1);
  yyvsp--;
  yystate = *--yyssp;
yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yyerrdefault;

  yyn += 1;
  if (yyn < 0 || yyn > 189 || yycheck[yyn] != 1)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == 77)
    return(0);






  *++yyvsp = yylval;




  yystate = yyn;
  goto yynewstate;
}





static char *lexptr;







int
parse_number(int olen) asm("_parse_number");
int
parse_number(int olen)
{
  register char *p = lexptr;
  register int c;
  register unsigned long n = 0, nd, ULONG_MAX_over_base;
  register int base = 10;
  register int len = olen;
  register int overflow = 0;
  register int digit, largest_digit = 0;
  int spec_long = 0;

  for (c = 0; c < len; c++)
    if (p[c] == '.') {

      yyerror ("floating point numbers not allowed in #if expressions");
      return 261;
    }

  yylval.integer.unsignedp = 0;

  if (len >= 3 && (!strncmp (p, "0x", 2) || !strncmp (p, "0X", 2))) {
    p += 2;
    base = 16;
    len -= 2;
  }
  else if (*p == '0')
    base = 8;

  ULONG_MAX_over_base = (unsigned long) -1 / base;

  for (; len > 0; len--) {
    c = *p++;

    if (c >= '0' && c <= '9')
      digit = c - '0';
    else if (base == 16 && c >= 'a' && c <= 'f')
      digit = c - 'a' + 10;
    else if (base == 16 && c >= 'A' && c <= 'F')
      digit = c - 'A' + 10;
    else {

      while (1) {
 if (c == 'l' || c == 'L')
   {
     if (spec_long)
       yyerror ("two `l's in integer constant");
     spec_long = 1;
   }
 else if (c == 'u' || c == 'U')
   {
     if (yylval.integer.unsignedp)
       yyerror ("two `u's in integer constant");
     yylval.integer.unsignedp = 1;
   }
 else
   break;

 if (--len == 0)
   break;
 c = *p++;
      }

      break;
    }
    if (largest_digit < digit)
      largest_digit = digit;
    nd = n * base + digit;
    overflow |= ULONG_MAX_over_base < n | nd < n;
    n = nd;
  }

  if (len != 0) {
    yyerror ("Invalid number in #if expression");
    return 261;
  }

  if (base <= largest_digit)
    warning ("integer constant contains digits beyond the radix");

  if (overflow)
    warning ("integer constant out of range");


  if ((long) n < 0 && ! yylval.integer.unsignedp)
    {
      if (base == 10)
 warning ("integer constant is so large that it is unsigned");
      yylval.integer.unsignedp = 1;
    }

  lexptr = p;
  yylval.integer.value = n;
  return 258;
}

struct n64_tag_token {
  char *cxx_operator;
  int token;
};

static struct n64_tag_token tokentab2[] = {
  {"&&", 263},
  {"||", 262},
  {"<<", 268},
  {">>", 269},
  {"==", 264},
  {"!=", 265},
  {"<=", 266},
  {">=", 267},
  {"++", 261},
  {"--", 261},
  {
  ((void *)0)
      , 261}
};



int
yylex(void) asm("_yylex");
int
yylex(void)
{
  register int c;
  register int namelen;
  register unsigned char *tokstart;
  register struct n64_tag_token *toktab;
  int wide_flag;

 retry:

  tokstart = (unsigned char *) lexptr;
  c = *tokstart;

  if (! keyword_parsing)
    for (toktab = tokentab2; toktab->cxx_operator != 
                                                ((void *)0)
                                                    ; toktab++)
      if (c == *toktab->cxx_operator && tokstart[1] == toktab->cxx_operator[1]) {
 lexptr += 2;
 if (toktab->token == 261)
   {
     char *buf = (char *) 
                         __builtin_alloca((
                         40
                         ))
                                    ;
     sprintf (buf, "`%s' not allowed in operand of `#if'", toktab->cxx_operator);
     yyerror (buf);
   }
 return toktab->token;
      }

  switch (c) {
  case 0:
    return 0;

  case ' ':
  case '\t':
  case '\r':
  case '\n':
    lexptr++;
    goto retry;

  case 'L':

    if (lexptr[1] == '\'')
      {
 lexptr++;
 wide_flag = 1;
 goto char_constant;
      }
    if (lexptr[1] == '"')
      {
 lexptr++;
 wide_flag = 1;
 goto string_constant;
      }
    break;

  case '\'':
    wide_flag = 0;
  char_constant:
    lexptr++;
    if (keyword_parsing) {
      char *start_ptr = lexptr - 1;
      while (1) {
 c = *lexptr++;
 if (c == '\\')
   c = parse_escape (&lexptr);
 else if (c == '\'')
   break;
      }
      yylval.name.address = tokstart;
      yylval.name.length = lexptr - start_ptr;
      return 260;
    }




    {
      register int result = 0;
      register int num_chars = 0;
      unsigned width = 8;
      int max_chars;
      char *token_buffer;

      if (wide_flag)
 {
   width = 64;



   max_chars = 1;

 }
      else
 max_chars = 64 / width;

      token_buffer = (char *) 
                             __builtin_alloca((
                             max_chars + 1
                             ))
                                                   ;

      while (1)
 {
   c = *lexptr++;

   if (c == '\'' || c == 
                        (-1)
                           )
     break;

   if (c == '\\')
     {
       c = parse_escape (&lexptr);
       if (width < 32
    && (unsigned) c >= (1 << width))
  pedwarn ("escape sequence out of range for character");
     }

   num_chars++;


   if (num_chars < max_chars + 1)
     {
       if (width < 32)
  result = (result << width) | (c & ((1 << width) - 1));
       else
  result = c;
       token_buffer[num_chars - 1] = c;
     }
 }

      token_buffer[num_chars] = 0;

      if (c != '\'')
 error ("malformatted character constant");
      else if (num_chars == 0)
 error ("empty character constant");
      else if (num_chars > max_chars)
 {
   num_chars = max_chars;
   error ("character constant too long");
 }
      else if (num_chars != 1 && ! traditional)
 warning ("multi-character character constant");


      if (! wide_flag)
 {
   int num_bits = num_chars * width;

   if (lookup ("__CHAR_UNSIGNED__", sizeof ("__CHAR_UNSIGNED__")-1, -1)
       || ((result >> (num_bits - 1)) & 1) == 0)
     yylval.integer.value
       = result & ((unsigned long) ~0 >> (32 - num_bits));
   else
     yylval.integer.value
       = result | ~((unsigned long) ~0 >> (32 - num_bits));
 }
      else
 {
   yylval.integer.value = result;
 }
    }


    yylval.integer.unsignedp = 0;

    return 259;



  case '/':
  case '+':
  case '-':
  case '*':
  case '%':
  case '|':
  case '&':
  case '^':
  case '~':
  case '!':
  case '@':
  case '<':
  case '>':
  case '[':
  case ']':
  case '.':
  case '?':
  case ':':
  case '=':
  case '{':
  case '}':
  case ',':
  case '#':
    if (keyword_parsing)
      break;
  case '(':
  case ')':
    lexptr++;
    return c;

  case '"':
  string_constant:
    if (keyword_parsing) {
      char *start_ptr = lexptr;
      lexptr++;
      while (1) {
 c = *lexptr++;
 if (c == '\\')
   c = parse_escape (&lexptr);
 else if (c == '"')
   break;
      }
      yylval.name.address = tokstart;
      yylval.name.length = lexptr - start_ptr;
      return 260;
    }
    yyerror ("string constants not allowed in #if expressions");
    return 261;
  }

  if (c >= '0' && c <= '9' && !keyword_parsing) {

    for (namelen = 0;
  c = tokstart[namelen], is_idchar[c] || c == '.';
  namelen++)
      ;
    return parse_number (namelen);
  }



  if (keyword_parsing) {
    for (namelen = 0;; namelen++) {
      if (is_hor_space[tokstart[namelen]])
 break;
      if (tokstart[namelen] == '(' || tokstart[namelen] == ')')
 break;
      if (tokstart[namelen] == '"' || tokstart[namelen] == '\'')
 break;
    }
  } else {
    if (!is_idstart[c]) {
      yyerror ("Invalid token in expression");
      return 261;
    }

    for (namelen = 0; is_idchar[tokstart[namelen]]; namelen++)
      ;
  }

  lexptr += namelen;
  yylval.name.address = tokstart;
  yylval.name.length = namelen;
  return 260;
}
int
parse_escape(char **string_ptr) asm("_parse_escape");
int
parse_escape(char **string_ptr)
{
  register int c = *(*string_ptr)++;
  switch (c)
    {
    case 'a':
      return 007;
    case 'b':
      return 010;
    case 'e':
    case 'E':
      if (pedantic)
 pedwarn ("non-ANSI-standard escape sequence, `\\%c'", c);
      return 033;
    case 'f':
      return 014;
    case 'n':
      return 012;
    case 'r':
      return 015;
    case 't':
      return 011;
    case 'v':
      return 013;
    case '\n':
      return -2;
    case 0:
      (*string_ptr)--;
      return 0;

    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
      {
 register int i = c - '0';
 register int count = 0;
 while (++count < 3)
   {
     c = *(*string_ptr)++;
     if (c >= '0' && c <= '7')
       i = (i << 3) + c - '0';
     else
       {
  (*string_ptr)--;
  break;
       }
   }
 if ((i & ~((1 << 8) - 1)) != 0)
   {
     i &= (1 << 8) - 1;
     warning ("octal character constant does not fit in a byte");
   }
 return i;
      }
    case 'x':
      {
 register unsigned i = 0, overflow = 0, digits_found = 0, digit;
 for (;;)
   {
     c = *(*string_ptr)++;
     if (c >= '0' && c <= '9')
       digit = c - '0';
     else if (c >= 'a' && c <= 'f')
       digit = c - 'a' + 10;
     else if (c >= 'A' && c <= 'F')
       digit = c - 'A' + 10;
     else
       {
  (*string_ptr)--;
  break;
       }
     overflow |= i ^ (i << 4 >> 4);
     i = (i << 4) + digit;
     digits_found = 1;
   }
 if (!digits_found)
   yyerror ("\\x used with no following hex digits");
 if (overflow | (i & ~((1 << 8) - 1)))
   {
     i &= (1 << 8) - 1;
     warning ("hex character constant does not fit in a byte");
   }
 return i;
      }
    default:
      return c;
    }
}

void
yyerror(char *s) asm("_yyerror");
void
yyerror(char *s)
{
  error (s);
  skip_evaluation = 0;
  longjmp (parse_return_error, 1);
}

static void
integer_overflow(void) asm("_integer_overflow");
static void
integer_overflow(void)
{
  if (!skip_evaluation && pedantic)
    pedwarn ("integer overflow in preprocessor expression");
}

static long
left_shift(struct n64_tag_constant *a, long unsigned int b) asm("_left_shift");
static long
left_shift(struct n64_tag_constant *a, long unsigned int b)
{



  if (b >= 32)
    return 0;
  else if (a->unsignedp)
    return (unsigned long) a->value << b;
  else
    return a->value << b;
}

static long
right_shift(struct n64_tag_constant *a, long unsigned int b) asm("_right_shift");
static long
right_shift(struct n64_tag_constant *a, long unsigned int b)
{
  if (b >= 32)
    return a->unsignedp ? 0 : a->value >> (32 - 1);
  else if (a->unsignedp)
    return (unsigned long) a->value >> b;
  else
    return a->value >> b;
}
int
parse_c_expression(char *string) asm("_parse_c_expression");
int
parse_c_expression(char *string)
{
  lexptr = string;

  if (lexptr == 0 || *lexptr == 0) {
    error ("empty #if expression");
    return 0;
  }




  if (
     _setjmp3((
     parse_return_error
     ), ((void *)0))
                                )
    return 0;

  if (yyparse ())
    return 0;

  if (*lexptr)
    error ("Junk after end of expression.");

  return expression_value;
}

