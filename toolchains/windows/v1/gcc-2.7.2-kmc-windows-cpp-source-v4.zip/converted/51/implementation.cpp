// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/final.c
/* Convert RTL to assembler code and output it, for GNU compiler.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <ctype.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int strip_off_ending(...) asm("_strip_off_ending");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int dwarfout_end_function(...) asm("_dwarfout_end_function");
extern int dwarfout_end_epilogue(...) asm("_dwarfout_end_epilogue");
extern int init_recog(...) asm("_init_recog");
extern int dwarfout_begin_function(...) asm("_dwarfout_begin_function");
extern int dwarfout_begin_block(...) asm("_dwarfout_begin_block");
extern int dwarfout_end_block(...) asm("_dwarfout_end_block");
extern int dwarfout_label(...) asm("_dwarfout_label");
extern int constrain_operands(...) asm("_constrain_operands");
extern int dwarfout_line(...) asm("_dwarfout_line");
extern int error_for_asm(...) asm("_error_for_asm");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
struct n64_tag_bb_list;
struct n64_tag_bb_str;
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");






enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
int leaf_function;


static rtx debug_insn = 0;


static int last_linenum;


static int high_block_linenum;


static int high_function_linenum;


static char *last_filename;



static int count_basic_blocks;




static rtx this_is_asm_operands;


static int insn_noperands;



static rtx last_ignored_compare = 0;



static int new_block = 1;
int next_block_index;




static int insn_counter = 0;
char regs_ever_live[68];





int frame_pointer_needed;



int profile_label_no;



static int max_block_depth;






static int *pending_blocks;



static int block_depth;



static int app_on;




rtx final_sequence;
static char *line_note_exists;



struct n64_tag_bb_list {
  struct n64_tag_bb_list *next;
  int line_num;
  int file_label_num;
  int func_label_num;
};

static struct n64_tag_bb_list *bb_head = 0;
static struct n64_tag_bb_list **bb_tail = &bb_head;
static int bb_file_label_num = -1;
static int bb_func_label_num = -1;



struct n64_tag_bb_str {
  struct n64_tag_bb_str *next;
  char *string;
  int label_num;
  int length;
};

extern rtx peephole (rtx) asm("_peephole");

static struct n64_tag_bb_str *sbb_head = 0;
static struct n64_tag_bb_str **sbb_tail = &sbb_head;
static int sbb_label_num = 0;

static int asm_insn_count (rtx) asm("_asm_insn_count");
static void profile_function (FILE *) asm("_profile_function");
static void profile_after_prologue (FILE *) asm("_profile_after_prologue");
static void add_bb (FILE *) asm("_add_bb");
static int add_bb_string (char *, int) asm("_add_bb_string");
static void output_source_line (FILE *, rtx) asm("_output_source_line");
static rtx walk_alter_subreg (rtx) asm("_walk_alter_subreg");
static int alter_cond (rtx) asm("_alter_cond");
static void output_asm_name (void) asm("_output_asm_name");
static void output_operand (rtx, int) asm("_output_operand");
static void leaf_renumber_regs (rtx) asm("_leaf_renumber_regs");

extern char *getpwd(void) asm("_getpwd");



void
init_final(char *filename) asm("_init_final");
void
init_final(char *filename)
{
  next_block_index = 2;
  app_on = 0;
  max_block_depth = 20;
  pending_blocks = (int *) xmalloc (20 * sizeof *pending_blocks);
  final_sequence = 0;




}




void
end_final(char *filename) asm("_end_final");
void
end_final(char *filename)
{
  int i;

  if (profile_block_flag)
    {
      char name[20];
      int align = exact_log2_wide ((int) (64 / 8));
      int size = (((target_flags & 0x00000002) ? 64 : 32) / 8) * count_basic_blocks;
      int rounded = size;
      struct n64_tag_bb_list *ptr;
      struct n64_tag_bb_str *sptr;

      rounded += (64 / 8) - 1;
      rounded = (rounded / (64 / 8)
   * (64 / 8));

      data_section ();
      { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };

      do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 0); } while (0);

      assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);


      do { sprintf (name, "*.%s%d", "LPBX", 1); } while (0);
      assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);


      do { sprintf (name, "*.%s%d", "LPBX", 2); } while (0);
      assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);


      assemble_integer (gen_rtx (CONST_INT, VOIDmode, (int) (count_basic_blocks)), ((target_flags & 0x00002000) ? 8 : 4), 1);


      assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);


      do { sprintf (name, "*.%s%d", "LPBX", 3); } while (0);
      assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);


      assemble_integer (gen_rtx (CONST_INT, VOIDmode, (int) (10 * ((target_flags & 0x00002000) ? 8 : 4))), ((target_flags & 0x00002000) ? 8 : 4), 1);


      do { sprintf (name, "*.%s%d", "LPBX", 4); } while (0);
      assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);


      if (write_symbols != NO_DEBUG)
 {
   do { sprintf (name, "*.%s%d", "LPBX", 5); } while (0);
   assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);
   do { sprintf (name, "*.%s%d", "LPBX", 6); } while (0);
   assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);
 }
      else
 {
   assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);
   assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);
 }



      do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 1); } while (0);
      {
 char *cwd = getpwd ();
 int len = strlen (filename) + strlen (cwd) + 1;
 char *data_file = (char *) 
                           __builtin_alloca((
                           len + 4
                           ))
                                           ;

 strcpy (data_file, cwd);
 strcat (data_file, "/");
 strcat (data_file, filename);
 strip_off_ending (data_file, len);
 strcat (data_file, ".d");
 assemble_string (data_file, strlen (data_file) + 1);
      }


      if (flag_no_common || size == 0)
 {

   { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };
   do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 2); } while (0);
   if (size != 0)
     assemble_zeros (size);
 }
      else
 {
   do { sprintf (name, "*.%s%d", "LPBX", 2); } while (0);






     do { fprintf ((asm_out_file), "\t%s\t", ".local"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), "\n"); do { fprintf ((asm_out_file), "\t%s\t", ".comm"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), ",%u,%u\n", (size), (64) / 8); } while (0); } while (0)
                            ;



 }


      readonly_data_section ();
      if (sbb_head)
 {
   { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };
   for (sptr = sbb_head; sptr != 0; sptr = sptr->next)
     {
       do { fprintf (asm_out_file, ".%s%d:\n", "LPBC", sptr->label_num); } while (0);
       assemble_string (sptr->string, sptr->length);
     }
 }



      { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };
      do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 3); } while (0);
      for (i = 0; i < count_basic_blocks; i++)
 {
   do { sprintf (name, "*.%s%d", "LPB", i); } while (0);
   assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name),
       ((target_flags & 0x00002000) ? 8 : 4), 1);
 }


      do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 4); } while (0);
      for ((ptr = bb_head), (i = 0); ptr != 0; (ptr = ptr->next), i++)
 {
   if (ptr->func_label_num >= 0)
     {
       do { sprintf (name, "*.%s%d", "LPBC", ptr->func_label_num); } while (0);
       assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name),
    ((target_flags & 0x00002000) ? 8 : 4), 1);
     }
   else
     assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);
 }

      for ( ; i < count_basic_blocks; i++)
 assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);

      if (write_symbols != NO_DEBUG)
 {

   do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 5); } while (0);
   for ((ptr = bb_head), (i = 0); ptr != 0; (ptr = ptr->next), i++)
     assemble_integer (gen_rtx (CONST_INT, VOIDmode, (int) (ptr->line_num)), ((target_flags & 0x00002000) ? 8 : 4), 1);

   for ( ; i < count_basic_blocks; i++)
     assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);


   do { fprintf (asm_out_file, ".%s%d:\n", "LPBX", 6); } while (0);
   for ((ptr = bb_head), (i = 0); ptr != 0; (ptr = ptr->next), i++)
     {
       if (ptr->file_label_num >= 0)
  {
    do { sprintf (name, "*.%s%d", "LPBC", ptr->file_label_num); } while (0);
    assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name),
        ((target_flags & 0x00002000) ? 8 : 4), 1);
  }
       else
  assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);
     }

   for ( ; i < count_basic_blocks; i++)
     assemble_integer (const0_rtx, ((target_flags & 0x00002000) ? 8 : 4), 1);
 }



      do { sprintf (name, "*.%s%d", "LPBX", 3); } while (0);
      assemble_integer (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name), ((target_flags & 0x00002000) ? 8 : 4), 1);
    }
}




void
app_enable(void) asm("_app_enable");
void
app_enable(void)
{
  if (! app_on)
    {
      fprintf (asm_out_file, " #APP\n");
      app_on = 1;
    }
}




void
app_disable(void) asm("_app_disable");
void
app_disable(void)
{
  if (app_on)
    {
      fprintf (asm_out_file, " #NO_APP\n");
      app_on = 0;
    }
}






int
dbr_sequence_length(void) asm("_dbr_sequence_length");
int
dbr_sequence_length(void)
{
  if (final_sequence != 0)
    return ((final_sequence)->fld[0].rtvec->num_elem) - 1;
  else
    return 0;
}
static short *insn_lengths;
int *insn_addresses;


int insn_current_address;



void
init_insn_lengths(void) asm("_init_insn_lengths");
void
init_insn_lengths(void)
{
  insn_lengths = 0;
}




int
get_attr_length(rtx insn) asm("_get_attr_length");
int
get_attr_length(rtx insn)
{

  rtx body;
  int i;
  int length = 0;

  if (insn_lengths)
    return insn_lengths[((insn)->fld[0].rtint)];
  else
    switch (((insn)->code))
      {
      case NOTE:
      case BARRIER:
      case CODE_LABEL:
 return 0;

      case CALL_INSN:
 length = insn_default_length (insn);
 break;

      case JUMP_INSN:
 body = ((insn)->fld[3].rtx);
        if (((body)->code) == ADDR_VEC || ((body)->code) == ADDR_DIFF_VEC)
   {
     return 0;

   }
 else
   length = insn_default_length (insn);
 break;

      case INSN:
 body = ((insn)->fld[3].rtx);
 if (((body)->code) == USE || ((body)->code) == CLOBBER)
   return 0;

 else if (((body)->code) == ASM_INPUT || asm_noperands (body) >= 0)
   length = asm_insn_count (body) * insn_default_length (insn);
 else if (((body)->code) == SEQUENCE)
   for (i = 0; i < ((body)->fld[0].rtvec->num_elem); i++)
     length += get_attr_length (((body)->fld[0].rtvec->elem[i].rtx));
 else
   length = insn_default_length (insn);
      }




  return length;



}
void
shorten_branches(rtx first) asm("_shorten_branches");
void
shorten_branches(rtx first)
{

  rtx insn;
  int something_changed = 1;
  int max_uid = 0;
  char *varying_length;
  rtx body;
  int uid;


  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->fld[0].rtint) > max_uid)
      max_uid = ((insn)->fld[0].rtint);

  max_uid++;
  insn_lengths = (short *) oballoc (max_uid * sizeof (short));
  insn_addresses = (int *) oballoc (max_uid * sizeof (int));
  varying_length = (char *) oballoc (max_uid * sizeof (char));


  for (insn_current_address = 0, insn = first;
       insn != 0;
       insn_current_address += insn_lengths[uid], insn = ((insn)->fld[2].rtx))
    {
      uid = ((insn)->fld[0].rtint);
      insn_addresses[uid] = insn_current_address;
      insn_lengths[uid] = 0;
      varying_length[uid] = 0;

      if (((insn)->code) == NOTE || ((insn)->code) == BARRIER
   || ((insn)->code) == CODE_LABEL)
 continue;

      body = ((insn)->fld[3].rtx);
      if (((body)->code) == ADDR_VEC || ((body)->code) == ADDR_DIFF_VEC)
 {
   ;

 }
      else if (asm_noperands (body) >= 0)
 insn_lengths[uid] = asm_insn_count (body) * insn_default_length (insn);
      else if (((body)->code) == SEQUENCE)
 {
   int i;
   int const_delay_slots;

   const_delay_slots = const_num_delay_slots (((body)->fld[0].rtvec->elem[0].rtx));






   for (i = 0; i < ((body)->fld[0].rtvec->num_elem); i++)
     {
       rtx inner_insn = ((body)->fld[0].rtvec->elem[i].rtx);
       int inner_uid = ((inner_insn)->fld[0].rtint);
       int inner_length;

       if (asm_noperands (((((body)->fld[0].rtvec->elem[i].rtx))->fld[3].rtx)) >= 0)
  inner_length = (asm_insn_count (((inner_insn)->fld[3].rtx))
    * insn_default_length (inner_insn));
       else
  inner_length = insn_default_length (inner_insn);

       insn_lengths[inner_uid] = inner_length;
       if (const_delay_slots)
  {
    if ((varying_length[inner_uid]
         = insn_variable_length_p (inner_insn)) != 0)
      varying_length[uid] = 1;
    insn_addresses[inner_uid] = (insn_current_address +
            insn_lengths[uid]);
  }
       else
  varying_length[inner_uid] = 0;
       insn_lengths[uid] += inner_length;
     }
 }
      else if (((body)->code) != USE && ((body)->code) != CLOBBER)
 {
   insn_lengths[uid] = insn_default_length (insn);
   varying_length[uid] = insn_variable_length_p (insn);
 }





    }





  while (something_changed)
    {
      something_changed = 0;
      for (insn_current_address = 0, insn = first;
    insn != 0;
    insn = ((insn)->fld[2].rtx))
 {
   int new_length;
   int tmp_length;

   uid = ((insn)->fld[0].rtint);
   insn_addresses[uid] = insn_current_address;
   if (! varying_length[uid])
     {
       insn_current_address += insn_lengths[uid];
       continue;
     }
   if (((insn)->code) == INSN && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
     {
       int i;

       body = ((insn)->fld[3].rtx);
       new_length = 0;
       for (i = 0; i < ((body)->fld[0].rtvec->num_elem); i++)
  {
    rtx inner_insn = ((body)->fld[0].rtvec->elem[i].rtx);
    int inner_uid = ((inner_insn)->fld[0].rtint);
    int inner_length;

    insn_addresses[inner_uid] = insn_current_address;



    if (! varying_length[inner_uid])
      inner_length = insn_lengths[inner_uid];
    else
      inner_length = insn_current_length (inner_insn);

    if (inner_length != insn_lengths[inner_uid])
      {
        insn_lengths[inner_uid] = inner_length;
        something_changed = 1;
      }
    insn_current_address += insn_lengths[inner_uid];
    new_length += inner_length;
  }
     }
   else
     {
       new_length = insn_current_length (insn);
       insn_current_address += new_length;
     }
   if (new_length != insn_lengths[uid])
     {
       insn_lengths[uid] = new_length;
       something_changed = 1;
     }
 }

      if (!optimize)
 break;
    }

}






static int
asm_insn_count(rtx body) asm("_asm_insn_count");
static int
asm_insn_count(rtx body)
{
  char *cxx_template;
  int count = 1;

  if (((body)->code) == ASM_INPUT)
    cxx_template = ((body)->fld[0].rtstr);
  else
    cxx_template = decode_asm_operands (body, ((void *)0), ((void *)0),
        ((void *)0), ((void *)0));

  for ( ; *cxx_template; cxx_template++)
    if (((*cxx_template) == ';') || *cxx_template == '\n')
      count++;

  return count;
}
void
final_start_function(rtx first, FILE *file, int optimize) asm("_final_start_function");
void
final_start_function(rtx first, FILE *file, int optimize)
{
  block_depth = 0;

  this_is_asm_operands = 0;
  if (((first)->fld[4].rtint) != -1)
    last_linenum = high_block_linenum = high_function_linenum
      = ((first)->fld[4].rtint);
      if (((first)->fld[4].rtint) != -1)
 output_source_line (file, first);
  function_prologue(file, get_frame_size ());
  if (! 1)

    profile_after_prologue (file);

  profile_label_no++;



  if (profile_block_flag)
    {
      char *junk = "function";
      bb_func_label_num =
 add_bb_string ((*decl_printable_name) (current_function_decl, &junk), 0);
    }
}

static void
profile_after_prologue(FILE *file) asm("_profile_after_prologue");
static void
profile_after_prologue(FILE *file)
{
  if (profile_flag)
    profile_function (file);

}

static void
profile_function(FILE *file) asm("_profile_function");
static void
profile_function(FILE *file)
{
  int align = ((64) < (((target_flags & 0x00000002) ? 64 : 32)) ? (64) : (((target_flags & 0x00000002) ? 64 : 32)));
  int sval = current_function_returns_struct;
  int cxt = current_function_needs_context;

  data_section ();
  { int mask = (1 << (floor_log2_wide ((int) (align / 8)))) - 1; fprintf (file, "\t.align\t%d\n", (floor_log2_wide ((int) (align / 8)))); };
  do { fprintf (file, ".%s%d:\n", "LP", profile_label_no); } while (0);
  assemble_integer (const0_rtx, ((target_flags & 0x00000002) ? 64 : 32) / 8, 1);

  text_section ();
  { fprintf (file, "\t.set\tnoreorder\n"); fprintf (file, "\t.set\tnoat\n"); fprintf (file, "\tmove\t%s,%s\t\t# save current return address\n", reg_names[0 + 1], reg_names[0 + 31]); fprintf (file, "\tjal\t_mcount\n"); fprintf (file, "\t%s\t%s,%s,%d\t\t# _mcount pops 2 words from  stack\n", (target_flags & 0x00002000) ? "dsubu" : "subu", reg_names[(0 + 29)], reg_names[(0 + 29)], (target_flags & 0x00000002) ? 16 : 8); fprintf (file, "\t.set\treorder\n"); fprintf (file, "\t.set\tat\n"); };
}





void
final_end_function(rtx first, FILE *file, int optimize) asm("_final_end_function");
void
final_end_function(rtx first, FILE *file, int optimize)
{
  if (app_on)
    {
      fprintf (file, " #NO_APP\n");
      app_on = 0;
    }







  if (write_symbols == DWARF_DEBUG)
    dwarfout_end_function ();
  function_epilogue(file, get_frame_size ());
  if (write_symbols == DWARF_DEBUG)
    dwarfout_end_epilogue ();







  bb_func_label_num = -1;



}





static void
add_bb(FILE *file) asm("_add_bb");
static void
add_bb(FILE *file)
{
  struct n64_tag_bb_list *ptr = (struct n64_tag_bb_list *) permalloc (sizeof (struct n64_tag_bb_list));


  ptr->next = 0;
  ptr->line_num = last_linenum;
  ptr->file_label_num = bb_file_label_num;
  ptr->func_label_num = bb_func_label_num;
  *bb_tail = ptr;
  bb_tail = &ptr->next;



  do { fprintf (file, ".%s%d:\n", "LPB", count_basic_blocks); } while (0);
  new_block = 0;
  count_basic_blocks++;
}



static int
add_bb_string(char *string, int perm_p) asm("_add_bb_string");
static int
add_bb_string(char *string, int perm_p)
{
  int len;
  struct n64_tag_bb_str *ptr = 0;

  if (!string)
    {
      string = "<unknown>";
      perm_p = 1;
    }





  len = strlen (string) + 1;
  if (!perm_p)
    {
      char *p = (char *) permalloc (len);
      memcpy (p,string,len);
      string = p;
    }
  else
    for (ptr = sbb_head; ptr != (struct n64_tag_bb_str *)0; ptr = ptr->next)
      if (ptr->string == string)
 break;


  if (!ptr)
    {
      ptr = (struct n64_tag_bb_str *) permalloc (sizeof (*ptr));
      ptr->next = 0;
      ptr->length = len;
      ptr->label_num = sbb_label_num++;
      ptr->string = string;
      *sbb_tail = ptr;
      sbb_tail = &ptr->next;
    }

  return ptr->label_num;
}
void
final(rtx first, FILE *file, int optimize, int prescan) asm("_final");
void
final(rtx first, FILE *file, int optimize, int prescan)
{
  register rtx insn;
  int max_line = 0;

  last_ignored_compare = 0;
  new_block = 1;
    {
      for (insn = first; insn; insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) > max_line)
   max_line = ((insn)->fld[4].rtint);
    }

  line_note_exists = (char *) oballoc (max_line + 1);
  memset (line_note_exists,0,max_line + 1);

  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) > 0)
      line_note_exists[((insn)->fld[4].rtint)] = 1;

  init_recog ();

  ;


  for (insn = ((first)->fld[2].rtx); insn;)
    insn = final_scan_insn (insn, file, optimize, prescan, 0);



  if (profile_block_flag && new_block)
    add_bb (file);
}
rtx
final_scan_insn(rtx insn, FILE *file, int optimize, int prescan, int nopeepholes) asm("_final_scan_insn");
rtx
final_scan_insn(rtx insn, FILE *file, int optimize, int prescan, int nopeepholes)
{
  register int i;
  insn_counter++;



  if (((insn)->volatil))
    return ((insn)->fld[2].rtx);

  switch (((insn)->code))
    {
    case NOTE:
      if (prescan > 0)
 break;




      if (((insn)->fld[4].rtint) == -4 && optimize > 0)
 {







   break;
 }
      if (((insn)->fld[4].rtint) == -5)
 break;

      if (((insn)->fld[4].rtint) == -10)
 {



   profile_after_prologue (file);
   break;
 }
      if (write_symbols == NO_DEBUG)
 break;
      if (((insn)->fld[4].rtint) == -13)
 {
   if (write_symbols == DWARF_DEBUG)
     dwarfout_begin_function ();

   break;
 }
      if (((insn)->fld[4].rtint) == -1)
 break;
      if (app_on)
 {
   fprintf (file, " #NO_APP\n");
   app_on = 0;
 }
      if (((insn)->fld[4].rtint) == -2
   && (debug_info_level == DINFO_LEVEL_NORMAL
       || debug_info_level == DINFO_LEVEL_VERBOSE

       || write_symbols == DWARF_DEBUG

      )
  )
 {



   if (block_depth == max_block_depth)
     {

       max_block_depth *= 2;
       pending_blocks
  = (int *) xrealloc (pending_blocks,
        max_block_depth * sizeof (int));
     }
   pending_blocks[block_depth++] = next_block_index;

   high_block_linenum = last_linenum;
   if (write_symbols == DWARF_DEBUG && block_depth > 1)
     dwarfout_begin_block (next_block_index);


   next_block_index++;
 }
      else if (((insn)->fld[4].rtint) == -3
        && (debug_info_level == DINFO_LEVEL_NORMAL
     || debug_info_level == DINFO_LEVEL_VERBOSE

            || write_symbols == DWARF_DEBUG

           )
       )
 {



   --block_depth;
   if (write_symbols == DWARF_DEBUG && block_depth >= 1)
     dwarfout_end_block (pending_blocks[block_depth]);

 }
      else if (((insn)->fld[4].rtint) == -12
        && (debug_info_level == DINFO_LEVEL_NORMAL
     || debug_info_level == DINFO_LEVEL_VERBOSE))
 {

          if (write_symbols == DWARF_DEBUG)
            dwarfout_label (insn);

 }
      else if (((insn)->fld[4].rtint) > 0)

 {
   register rtx note;




   int note_after = 0;



   for (note = ((insn)->fld[2].rtx); note; note = ((note)->fld[2].rtx))
     {
       if (((note)->code) != NOTE && ((note)->code) != CODE_LABEL)
  break;


       else if (((note)->code) == NOTE
         && (((note)->fld[4].rtint) == -2
      || ((note)->fld[4].rtint) == -3
      || ((note)->fld[4].rtint) == -13))
    break;
       else if (((note)->code) == NOTE && ((note)->fld[4].rtint) > 0)
  {


    int num;
    for (num = ((insn)->fld[4].rtint) + 1;
         num < ((note)->fld[4].rtint);
         num++)
      if (line_note_exists[num])
        break;

    if (num >= ((note)->fld[4].rtint))
      note_after = 1;
    break;
  }
     }



   if (!note_after)
     output_source_line (file, insn);
 }
      break;

    case BARRIER:







      break;

    case CODE_LABEL:
      ;
      if (prescan > 0)
 break;
      new_block = 1;





      if (write_symbols == DWARF_DEBUG && ((insn)->fld[4].rtstr))
 dwarfout_label (insn);

      if (app_on)
 {
   fprintf (file, " #NO_APP\n");
   app_on = 0;
 }
      if (((insn)->fld[2].rtx) != 0
   && ((((insn)->fld[2].rtx))->code) == JUMP_INSN)
 {
   rtx nextbody = ((((insn)->fld[2].rtx))->fld[3].rtx);





   if (((nextbody)->code) == ADDR_VEC
       || ((nextbody)->code) == ADDR_DIFF_VEC)
     {

       readonly_data_section ();

       { int mask = (1 << (exact_log2_wide ((int) (64 / 8)))) - 1; fprintf (file, "\t.align\t%d\n", (exact_log2_wide ((int) (64 / 8)))); }

                          ;





       do { { int mask = (1 << (2)) - 1; fprintf ((file), "\t.align\t%d\n", (2)); }; do { fprintf (file, ".%s%d:\n", "L", ((insn)->fld[3].rtint)); } while (0); } while (0)
                          ;



       break;
     }
 }

      do { fprintf (file, ".%s%d:\n", "L", ((insn)->fld[3].rtint)); } while (0);
      break;

    default:
      {
 register rtx body = ((insn)->fld[3].rtx);
 int insn_code_number;
 char *cxx_template;
 rtx note;




 if (((body)->code) == USE
     || ((body)->code) == CLOBBER)
   break;
 if (((body)->code) == ADDR_VEC || ((body)->code) == ADDR_DIFF_VEC)
   {
     register int vlen, idx;

     if (prescan > 0)
       break;

     if (app_on)
       {
  fprintf (file, " #NO_APP\n");
  app_on = 0;
       }

     vlen = ((body)->fld[((body)->code) == ADDR_DIFF_VEC].rtvec->num_elem);
     for (idx = 0; idx < vlen; idx++)
       {
  if (((body)->code) == ADDR_VEC)
    {

      fprintf (file, "\t%s\t%sL%d\n", (target_flags & 0x00000002) ? ".dword" : ".word", ".", ((((((body)->fld[0].rtvec->elem[idx].rtx))->fld[0].rtx))->fld[3].rtint))
                                                                    ;



    }
  else
    {

      do { if ((target_flags & 0x00004000)) fprintf (file, "\t%s\t%sL%d-%sLS%d\n", (target_flags & 0x00000002) ? ".dword" : ".word", ".", ((((((body)->fld[1].rtvec->elem[idx].rtx))->fld[0].rtx))->fld[3].rtint), ".", ((((((body)->fld[0].rtx))->fld[0].rtx))->fld[3].rtint)); else if (! 0) fprintf (file, "\t%s\t%sL%d\n", (target_flags & 0x00000002) ? ".gpdword" : ".gpword", ".", ((((((body)->fld[1].rtvec->elem[idx].rtx))->fld[0].rtx))->fld[3].rtint)); else fprintf (file, "\t%s\t.L%d\n", (target_flags & 0x00000002) ? ".dword" : ".word", ((((((body)->fld[1].rtvec->elem[idx].rtx))->fld[0].rtx))->fld[3].rtint)); } while (0)


                                                      ;



    }
       }






     function_section (current_function_decl);

     break;
   }



 if (profile_block_flag && new_block)
   add_bb (file);

 if (((body)->code) == ASM_INPUT)
   {

     ;
     if (prescan > 0)
       break;
     if (! app_on)
       {
  fprintf (file, " #APP\n");
  app_on = 1;
       }
     fprintf (asm_out_file, "\t%s\n", ((body)->fld[0].rtstr));
     break;
   }


 if (asm_noperands (body) >= 0)
   {
     int noperands = asm_noperands (body);
     rtx *ops = (rtx *) 
                       __builtin_alloca((
                       noperands * sizeof (rtx)
                       ))
                                                        ;
     char *string;


     ;
     if (prescan > 0)
       break;

     if (! app_on)
       {
  fprintf (file, " #APP\n");
  app_on = 1;
       }


     string = decode_asm_operands (body, ops, ((void *)0),
       ((void *)0), ((void *)0));

     insn_noperands = noperands;
     this_is_asm_operands = insn;


     output_asm_insn (string, ops);
     this_is_asm_operands = 0;
     break;
   }

 if (prescan <= 0 && app_on)
   {
     fprintf (file, " #NO_APP\n");
     app_on = 0;
   }

 if (((body)->code) == SEQUENCE)
   {

     register int i;
     rtx next;

     if (prescan > 0)
       break;
     final_sequence = body;






     next = final_scan_insn (((body)->fld[0].rtvec->elem[0].rtx), file, 0, prescan, 1);
     if (next != ((body)->fld[0].rtvec->elem[1].rtx))
       {
  final_sequence = 0;
  return next;
       }

     for (i = 1; i < ((body)->fld[0].rtvec->num_elem); i++)
       {
  rtx insn = ((body)->fld[0].rtvec->elem[i].rtx);
  rtx next = ((insn)->fld[2].rtx);


  do
    insn = final_scan_insn (insn, file, 0, prescan, 1);
  while (insn != next);
       }

     do { if (set_nomacro > 0 && --set_nomacro == 0) fputs ("\t.set\tmacro\n", file); if (set_noreorder > 0 && --set_noreorder == 0) fputs ("\t.set\treorder\n", file); dslots_jump_filled++; fputs ("\n", file); } while (0);

     final_sequence = 0;






     if (((((body)->fld[0].rtvec->elem[0].rtx))->code) == CALL_INSN)
       ;



     if (profile_block_flag)
       {
  rtx insn = ((body)->fld[0].rtvec->elem[0].rtx);
  rtx body = ((insn)->fld[3].rtx);

  if ((((insn)->code) == JUMP_INSN && ((body)->code) == SET
       && ((((body)->fld[1].rtx))->code) != LABEL_REF)
      || (((insn)->code) == JUMP_INSN
   && ((body)->code) == PARALLEL
   && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == SET
   && ((((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) != LABEL_REF))
    new_block = 1;
       }
     break;
   }



 body = ((insn)->fld[3].rtx);
 if (profile_block_flag && final_sequence == 0
     && ((((insn)->code) == JUMP_INSN && ((body)->code) == SET
   && ((((body)->fld[1].rtx))->code) != LABEL_REF)
  || (((insn)->code) == JUMP_INSN && ((body)->code) == PARALLEL
      && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == SET
      && ((((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) != LABEL_REF)))
   new_block = 1;






 if (final_sequence == 0
     && prescan >= 0
     && ((insn)->code) == INSN && ((body)->code) == SET
     && ((((body)->fld[1].rtx))->code) == REG
     && ((((body)->fld[0].rtx))->code) == REG
     && ((((body)->fld[1].rtx))->fld[0].rtint) == ((((body)->fld[0].rtx))->fld[0].rtint))
   break;
 if (optimize && !flag_no_peephole && !nopeepholes)
   {
     rtx next = peephole (insn);


     if (next != 0 && next != ((insn)->fld[2].rtx))
       {
  rtx prev = ((insn)->fld[1].rtx);
  rtx note;

  for (note = ((insn)->fld[2].rtx); note != next;
       note = ((note)->fld[2].rtx))
    final_scan_insn (note, file, optimize, prescan, nopeepholes);



  note = ((insn)->fld[2].rtx);
  ((note)->fld[1].rtx) = prev;
  ((prev)->fld[2].rtx) = note;
  ((((next)->fld[1].rtx))->fld[2].rtx) = insn;
  ((insn)->fld[1].rtx) = ((next)->fld[1].rtx);
  ((insn)->fld[2].rtx) = next;
  ((next)->fld[1].rtx) = insn;
       }


     body = ((insn)->fld[3].rtx);
   }






 insn_code_number = recog_memoized (insn);
 insn_extract (insn);
 for (i = 0; i < insn_n_operands[insn_code_number]; i++)
   {
     if (((recog_operand[i])->code) == SUBREG)
       recog_operand[i] = alter_subreg (recog_operand[i]);
     else if (((recog_operand[i])->code) == PLUS
       || ((recog_operand[i])->code) == MULT)
       recog_operand[i] = walk_alter_subreg (recog_operand[i]);
   }

 for (i = 0; i < insn_n_dups[insn_code_number]; i++)
   {
     if (((*recog_dup_loc[i])->code) == SUBREG)
       *recog_dup_loc[i] = alter_subreg (*recog_dup_loc[i]);
     else if (((*recog_dup_loc[i])->code) == PLUS
       || ((*recog_dup_loc[i])->code) == MULT)
       *recog_dup_loc[i] = walk_alter_subreg (*recog_dup_loc[i]);
   }


 if (! constrain_operands (insn_code_number, 1))
   fatal_insn_not_found (insn);






 final_prescan_insn (insn, recog_operand, insn_n_operands[insn_code_number])
                                         ;
 debug_insn = insn;




 cxx_template = insn_template[insn_code_number];
 if (cxx_template == 0)
   {
     cxx_template = (*insn_outfun[insn_code_number]) (recog_operand, insn);




     if (cxx_template == 0)
       {
  if (prev_nonnote_insn (insn) != last_ignored_compare)
    abort ();
  new_block = 0;
  return prev_nonnote_insn (insn);
       }
   }



 if (cxx_template[0] == '#' && cxx_template[1] == '\0')
   {
     rtx cxx_new = try_split (body, insn, 0);


     if (cxx_new == insn && ((cxx_new)->fld[3].rtx) == body)
       abort ();

     new_block = 0;
     return cxx_new;
   }

 if (prescan > 0)
   break;



 output_asm_insn (cxx_template, recog_operand);
 debug_insn = 0;
      }
    }
  return ((insn)->fld[2].rtx);
}




static void
output_source_line(FILE *file, rtx insn) asm("_output_source_line");
static void
output_source_line(FILE *file, rtx insn)
{
  register char *filename = ((insn)->fld[3].rtstr);






  if (profile_block_flag && last_filename != filename)
    bb_file_label_num = add_bb_string (filename, 1);

  last_filename = filename;
  last_linenum = ((insn)->fld[4].rtint);
  high_block_linenum = ((last_linenum) > (high_block_linenum) ? (last_linenum) : (high_block_linenum));
  high_function_linenum = ((last_linenum) > (high_function_linenum) ? (last_linenum) : (high_function_linenum));

  if (write_symbols != NO_DEBUG)
    {
      if (write_symbols == DWARF_DEBUG)
 dwarfout_line (filename, ((insn)->fld[4].rtint));

    }
}




rtx
alter_subreg(register rtx x) asm("_alter_subreg");
rtx
alter_subreg(register rtx x)
{
  register rtx y = ((x)->fld[0].rtx);
  if (((y)->code) == SUBREG)
    y = alter_subreg (y);

  if (((y)->code) == REG)
    {

      ((x)->code = (REG));
      ((x)->fld[0].rtint) = ((y)->fld[0].rtint) + ((x)->fld[1].rtint);
    }
  else if (((y)->code) == MEM)
    {
      register int offset = ((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
      if (((target_flags & 0x00010000) != 0))
 offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((x)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((x)->mode))])))
     - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((y)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((y)->mode))]))));
      ((x)->code = (MEM));
      ((x)->volatil) = ((y)->volatil);
      ((x)->fld[0].rtx) = plus_constant_wide (((y)->fld[0].rtx), (int) (offset));
    }

  return x;
}



static rtx
walk_alter_subreg(rtx x) asm("_walk_alter_subreg");
static rtx
walk_alter_subreg(rtx x)
{
  switch (((x)->code))
    {
    case PLUS:
    case MULT:
      ((x)->fld[0].rtx) = walk_alter_subreg (((x)->fld[0].rtx));
      ((x)->fld[1].rtx) = walk_alter_subreg (((x)->fld[1].rtx));
      break;

    case MEM:
      ((x)->fld[0].rtx) = walk_alter_subreg (((x)->fld[0].rtx));
      break;

    case SUBREG:
      return alter_subreg (x);
    }

  return x;
}
void
output_operand_lossage(char *str) asm("_output_operand_lossage");
void
output_operand_lossage(char *str)
{
  if (this_is_asm_operands)
    error_for_asm (this_is_asm_operands, "invalid `asm': %s", str);
  else
    abort ();
}
static void
output_asm_name(void) asm("_output_asm_name");
static void
output_asm_name(void)
{
  if (flag_print_asm_name)
    {


      if (debug_insn)
 {
   register int num = ((debug_insn)->fld[4].rtint);
   fprintf (asm_out_file, " %s %d %s",
     "\t\t# ", ((debug_insn)->fld[0].rtint), insn_name[num]);
   if (insn_n_alternatives[num] > 1)
     fprintf (asm_out_file, "/%d", which_alternative + 1);



   debug_insn = 0;
 }
    }
}

void
output_asm_insn(char *cxx_template, rtx *operands) asm("_output_asm_insn");
void
output_asm_insn(char *cxx_template, rtx *operands)
{
  register char *p;
  register int c, i;



  if (*cxx_template == 0)
    return;

  p = cxx_template;
  putc ('\t', asm_out_file);





  while (c = *p++)
    switch (c)
      {
      case '\n':
 output_asm_name ();
 putc (c, asm_out_file);
 break;
      case '%':

 if (*p == '%')
   {
     p++;
     putc (c, asm_out_file);
   }



 else if (*p == '=')
   {
     p++;
     fprintf (asm_out_file, "%d", insn_counter);
   }





 else if ((*p >= 'a' && *p <= 'z')
   || (*p >= 'A' && *p <= 'Z'))
   {
     int letter = *p++;
     c = atoi (p);

     if (! (*p >= '0' && *p <= '9'))
       output_operand_lossage ("operand number missing after %-letter");
     else if (this_is_asm_operands && c >= (unsigned) insn_noperands)
       output_operand_lossage ("operand number out of range");
     else if (letter == 'l')
       output_asm_label (operands[c]);
     else if (letter == 'a')
       output_address (operands[c]);
     else if (letter == 'c')
       {
  if (((((operands[c])->code) == LABEL_REF || ((operands[c])->code) == SYMBOL_REF || ((operands[c])->code) == CONST_INT || ((operands[c])->code) == HIGH || (((operands[c])->code) == CONST && ! (flag_pic && pic_address_needs_scratch (operands[c])) && ! 0)) && (!0 || !0)))
    output_addr_const (asm_out_file, operands[c]);
  else
    output_operand (operands[c], 'c');
       }
     else if (letter == 'n')
       {
  if (((operands[c])->code) == CONST_INT)
    fprintf (asm_out_file,

      "%d",



      - ((operands[c])->fld[0].rtwint));
  else
    {
      putc ('-', asm_out_file);
      output_addr_const (asm_out_file, operands[c]);
    }
       }
     else
       output_operand (operands[c], letter);

     while ((c = *p) >= '0' && c <= '9') p++;
   }

 else if (*p >= '0' && *p <= '9')
   {
     c = atoi (p);
     if (this_is_asm_operands && c >= (unsigned) insn_noperands)
       output_operand_lossage ("operand number out of range");
     else
       output_operand (operands[c], 0);
     while ((c = *p) >= '0' && c <= '9') p++;
   }




 else if (mips_print_operand_punct[*p])
   output_operand ((rtx) 0, *p++);

 else
   output_operand_lossage ("invalid %%-code");
 break;

      default:
 putc (c, asm_out_file);
      }

  output_asm_name ();

  putc ('\n', asm_out_file);
}



void
output_asm_label(rtx x) asm("_output_asm_label");
void
output_asm_label(rtx x)
{
  char buf[256];

  if (((x)->code) == LABEL_REF)
    do { sprintf (buf, "*.%s%d", "L", ((((x)->fld[0].rtx))->fld[3].rtint)); } while (0);
  else if (((x)->code) == CODE_LABEL)
    do { sprintf (buf, "*.%s%d", "L", ((x)->fld[3].rtint)); } while (0);
  else
    output_operand_lossage ("`%l' operand isn't a label");

  assemble_name (asm_out_file, buf);
}
static void
output_operand(rtx x, int code) asm("_output_operand");
static void
output_operand(rtx x, int code)
{
  if (x && ((x)->code) == SUBREG)
    x = alter_subreg (x);




  if (x && ((x)->code) == REG && ((x)->fld[0].rtint) >= 68)
    abort ();

  print_operand (asm_out_file, x, code);
}





void
output_address(rtx x) asm("_output_address");
void
output_address(rtx x)
{
  walk_alter_subreg (x);
  print_operand_address (asm_out_file, x);
}





void
output_addr_const(FILE *file, rtx x) asm("_output_addr_const");
void
output_addr_const(FILE *file, rtx x)
{
  char buf[256];

 restart:
  switch (((x)->code))
    {
    case PC:
      if (flag_pic)
 putc ('.', file);
      else
 abort ();
      break;

    case SYMBOL_REF:
      assemble_name (file, ((x)->fld[0].rtstr));
      break;

    case LABEL_REF:
      do { sprintf (buf, "*.%s%d", "L", ((((x)->fld[0].rtx))->fld[3].rtint)); } while (0);
      assemble_name (file, buf);
      break;

    case CODE_LABEL:
      do { sprintf (buf, "*.%s%d", "L", ((x)->fld[3].rtint)); } while (0);
      assemble_name (file, buf);
      break;

    case CONST_INT:
      fprintf (file,

        "%d",



        ((x)->fld[0].rtwint));
      break;

    case CONST:


      output_addr_const (file, ((x)->fld[0].rtx));
      break;

    case CONST_DOUBLE:
      if (((x)->mode) == VOIDmode)
 {

   if (((x)->fld[3].rtwint))
     fprintf (file,
       "0x%x%08x",


       ((x)->fld[3].rtwint), ((x)->fld[2].rtwint));
   else if (((x)->fld[2].rtwint) < 0)
     fprintf (file,

       "0x%x",



       ((x)->fld[2].rtwint));
   else
     fprintf (file,

       "%d",



       ((x)->fld[2].rtwint));
 }
      else


 output_operand_lossage ("floating constant misused");
      break;

    case PLUS:

      if (((((x)->fld[0].rtx))->code) == CONST_INT)
 {
   output_addr_const (file, ((x)->fld[1].rtx));
   if (((((x)->fld[0].rtx))->fld[0].rtwint) >= 0)
     fprintf (file, "+");
   output_addr_const (file, ((x)->fld[0].rtx));
 }
      else
 {
   output_addr_const (file, ((x)->fld[0].rtx));
   if (((((x)->fld[1].rtx))->fld[0].rtwint) >= 0)
     fprintf (file, "+");
   output_addr_const (file, ((x)->fld[1].rtx));
 }
      break;

    case MINUS:


      x = simplify_subtraction (x);
      if (((x)->code) != MINUS)
 goto restart;

      output_addr_const (file, ((x)->fld[0].rtx));
      fprintf (file, "-");
      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 0)
 {
   fprintf (file, "(");
   output_addr_const (file, ((x)->fld[1].rtx));
   fprintf (file, ")");
 }
      else
 output_addr_const (file, ((x)->fld[1].rtx));
      break;

    case ZERO_EXTEND:
    case SIGN_EXTEND:
      output_addr_const (file, ((x)->fld[0].rtx));
      break;

    default:
      output_operand_lossage ("invalid expression as operand");
    }
}
void
asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf");
void
asm_fprintf (FILE *file, char *p, ...)
{




  va_list argptr;
  char buf[10];
  char *q, c;
  int i;

  
 __builtin_va_start(
 argptr
 ,
 p
 )
                     ;






  buf[0] = '%';

  while (c = *p++)
    switch (c)
      {
      case '%':
 c = *p++;
 q = &buf[1];
 while ((c >= '0' && c <= '9') || c == '.')
   {
     *q++ = c;
     c = *p++;
   }
 switch (c)
   {
   case '%':
     fprintf (file, "%%");
     break;

   case 'd': case 'i': case 'u':
   case 'x': case 'p': case 'X':
   case 'o':
     *q++ = c;
     *q = 0;
     fprintf (file, buf, 
                        __builtin_va_arg(
                        argptr
                        ,
                        int
                        )
                                            );
     break;

   case 'w':
     *q++ = *p++;
     *q = 0;
     fprintf (file, buf, 
                        __builtin_va_arg(
                        argptr
                        ,
                        int
                        )
                                                      );
     break;

   case 'l':
     *q++ = c;
     *q++ = *p++;
     *q = 0;
     fprintf (file, buf, 
                        __builtin_va_arg(
                        argptr
                        ,
                        long
                        )
                                             );
     break;

   case 'e':
   case 'f':
   case 'g':
     *q++ = c;
     *q = 0;
     fprintf (file, buf, 
                        __builtin_va_arg(
                        argptr
                        ,
                        double
                        )
                                               );
     break;

   case 's':
     *q++ = c;
     *q = 0;
     fprintf (file, buf, 
                        __builtin_va_arg(
                        argptr
                        ,
                        char *
                        )
                                               );
     break;

   case 'O':



     break;

   case 'R':



     break;

   case 'I':



     break;

   case 'L':

     fprintf (file, "%s", ".");

     break;

   case 'U':

     fprintf (file, "%s", "");

     break;

   default:
     abort ();
   }
 break;

      default:
 fputc (c, file);
      }
}






void
split_double(rtx value, rtx *first, rtx *second) asm("_split_double");
void
split_double(rtx value, rtx *first, rtx *second)
{
  if (((value)->code) == CONST_INT)
    {
      if (32 >= (2 * ((target_flags & 0x00002000) ? 64 : 32)))
 {


   rtx low, high;
   int word_mask;

   int shift_count = ((target_flags & 0x00002000) ? 64 : 32) - 1;

   word_mask = (int) 1 << shift_count;
   word_mask |= word_mask - 1;
   low = gen_rtx (CONST_INT, VOIDmode, (int) (((value)->fld[0].rtwint) & word_mask));
   high = gen_rtx (CONST_INT, VOIDmode, (int) ((((value)->fld[0].rtwint) >> (shift_count + 1)) & word_mask));
   if (((target_flags & 0x00010000) != 0))
     {
       *first = high;
       *second = low;
     }
   else
     {
       *first = low;
       *second = high;
     }
 }
      else
 {



   rtx high = (((value)->fld[0].rtwint) < 0 ? constm1_rtx : const0_rtx);
   if (((target_flags & 0x00010000) != 0))
     {
       *first = high;
       *second = value;
     }
   else
     {
       *first = value;
       *second = high;
     }
 }
    }
  else if (((value)->code) != CONST_DOUBLE)
    {
      if (((target_flags & 0x00010000) != 0))
 {
   *first = const0_rtx;
   *second = value;
 }
      else
 {
   *first = value;
   *second = const0_rtx;
 }
    }
  else if (((value)->mode) == VOIDmode

    || (mode_class[(int)(((value)->mode))]) == MODE_INT)
    {


      if (((target_flags & 0x00010000) != 0))
 {
   *first = gen_rtx (CONST_INT, VOIDmode, (int) (((value)->fld[3].rtwint)));
   *second = gen_rtx (CONST_INT, VOIDmode, (int) (((value)->fld[2].rtwint)));
 }
      else
 {
   *first = gen_rtx (CONST_INT, VOIDmode, (int) (((value)->fld[2].rtwint)));
   *second = gen_rtx (CONST_INT, VOIDmode, (int) (((value)->fld[3].rtwint)));
 }
    }
  else
    {

      double r; long l[2];
      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((value))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((value))->fld[3].rtwint),(sizeof u) / 2); r = u.d; } while (0);





      (etardouble ((r), (l)));

      *first = gen_rtx (CONST_INT, VOIDmode, (int) ((int) l[0]));
      *second = gen_rtx (CONST_INT, VOIDmode, (int) ((int) l[1]));
    }
}



int
leaf_function_p(void) asm("_leaf_function_p");
int
leaf_function_p(void)
{
  rtx insn;

  if (profile_flag || profile_block_flag)
    return 0;

  for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == CALL_INSN)
 return 0;
      if (((insn)->code) == INSN
   && ((((insn)->fld[3].rtx))->code) == SEQUENCE
   && ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == CALL_INSN)
 return 0;
    }
  for (insn = current_function_epilogue_delay_list; insn; insn = ((insn)->fld[1].rtx))
    {
      if (((((insn)->fld[0].rtx))->code) == CALL_INSN)
 return 0;
      if (((((insn)->fld[0].rtx))->code) == INSN
   && ((((((insn)->fld[0].rtx))->fld[3].rtx))->code) == SEQUENCE
   && ((((((((insn)->fld[0].rtx))->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == CALL_INSN)
 return 0;
    }

  return 1;
}

