// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/getopt.c
/* Getopt for GNU.
   NOTE: getopt is now part of the C library, so if you don't know what
   "Keep this file name-space clean" means, talk to roland@gnu.ai.mit.edu
   before changing it!

   Copyright (C) 1987, 88, 89, 90, 91, 92, 93, 94, 95
   	Free Software Foundation, Inc.

This file is part of the libiberty library.  This library is free
software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option)
any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

As a special exception, if you link this library with files
compiled with a GNU compiler to produce an executable, this does not cause
the resulting executable to be covered by the GNU General Public License.
This exception does not however invalidate any other reasons why
the executable file might be covered by the GNU General Public License. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_option;

extern char *optarg;
extern int optind;




extern int opterr;



extern int optopt;
struct n64_tag_option
{

  const char *name;





  int has_arg;
  int *flag;
  int val;
};
extern int getopt(...) asm("_getopt");

extern int getopt_long (int argc, char *const *argv, const char *shortopts,
          const struct n64_tag_option *longopts, int *longind) asm("_getopt_long");
extern int getopt_long_only (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind) asm("_getopt_long_only");


extern int _getopt_internal (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind,
        int long_only) asm("__getopt_internal");







char *optarg = 
              ((void *)0)
                  ;
int optind = 0;
static char *nextchar;




int opterr = 1;





int optopt = '?';
enum n64_cpp_enum_anonymous_0{
  REQUIRE_ORDER, PERMUTE, RETURN_IN_ORDER
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_0) n64_enum_anonymous_0;
static n64_enum_anonymous_0 ordering;
char *getenv(...) asm("_getenv");

static char *
my_index(const char *str, int chr) asm("_my_index");
static char *
my_index(const char *str, int chr)
{
  while (*str)
    {
      if (*str == chr)
 return (char *) str;
      str++;
    }
  return 0;
}
static int first_nonopt;
static int last_nonopt;
static void
exchange(char **argv) asm("_exchange");
static void
exchange(char **argv)
{
  int bottom = first_nonopt;
  int middle = last_nonopt;
  int top = optind;
  char *tem;






  while (top > middle && middle > bottom)
    {
      if (top - middle > middle - bottom)
 {

   int len = middle - bottom;
   register int i;


   for (i = 0; i < len; i++)
     {
       tem = argv[bottom + i];
       argv[bottom + i] = argv[top - (middle - bottom) + i];
       argv[top - (middle - bottom) + i] = tem;
     }

   top -= len;
 }
      else
 {

   int len = top - middle;
   register int i;


   for (i = 0; i < len; i++)
     {
       tem = argv[bottom + i];
       argv[bottom + i] = argv[middle + i];
       argv[middle + i] = tem;
     }

   bottom += len;
 }
    }



  first_nonopt += (optind - last_nonopt);
  last_nonopt = optind;
}



static const char *
_getopt_initialize(const char *optstring) asm("__getopt_initialize");
static const char *
_getopt_initialize(const char *optstring)
{




  first_nonopt = last_nonopt = optind = 1;

  nextchar = 
            ((void *)0)
                ;



  if (optstring[0] == '-')
    {
      ordering = RETURN_IN_ORDER;
      ++optstring;
    }
  else if (optstring[0] == '+')
    {
      ordering = REQUIRE_ORDER;
      ++optstring;
    }
  else if (getenv ("POSIXLY_CORRECT") != 
                                        ((void *)0)
                                            )
    ordering = REQUIRE_ORDER;
  else
    ordering = PERMUTE;

  return optstring;
}
int
_getopt_internal(int argc, char *const *argv, const char *optstring, const struct n64_tag_option *longopts, int *longind, int long_only) asm("__getopt_internal");
int
_getopt_internal(int argc, char *const *argv, const char *optstring, const struct n64_tag_option *longopts, int *longind, int long_only)
{
  optarg = 
          ((void *)0)
              ;

  if (optind == 0)
    optstring = _getopt_initialize (optstring);

  if (nextchar == 
                 ((void *)0) 
                      || *nextchar == '\0')
    {


      if (ordering == PERMUTE)
 {



   if (first_nonopt != last_nonopt && last_nonopt != optind)
     exchange ((char **) argv);
   else if (last_nonopt != optind)
     first_nonopt = optind;




   while (optind < argc
   && (argv[optind][0] != '-' || argv[optind][1] == '\0'))
     optind++;
   last_nonopt = optind;
 }






      if (optind != argc && !strcmp (argv[optind], "--"))
 {
   optind++;

   if (first_nonopt != last_nonopt && last_nonopt != optind)
     exchange ((char **) argv);
   else if (first_nonopt == last_nonopt)
     first_nonopt = optind;
   last_nonopt = argc;

   optind = argc;
 }




      if (optind == argc)
 {


   if (first_nonopt != last_nonopt)
     optind = first_nonopt;
   return 
         (-1)
            ;
 }




      if ((argv[optind][0] != '-' || argv[optind][1] == '\0'))
 {
   if (ordering == REQUIRE_ORDER)
     return 
           (-1)
              ;
   optarg = argv[optind++];
   return 1;
 }




      nextchar = (argv[optind] + 1
    + (longopts != 
                  ((void *)0) 
                       && argv[optind][1] == '-'));
    }
  if (longopts != 
                 ((void *)0)
      
     && (argv[optind][1] == '-'
   || (long_only && (argv[optind][2] || !my_index (optstring, argv[optind][1])))))
    {
      char *nameend;
      const struct n64_tag_option *p;
      const struct n64_tag_option *pfound = 
                                   ((void *)0)
                                       ;
      int exact = 0;
      int ambig = 0;
      int indfound;
      int option_index;

      for (nameend = nextchar; *nameend && *nameend != '='; nameend++)
                    ;



      for (p = longopts, option_index = 0; p->name; p++, option_index++)
 if (!strncmp (p->name, nextchar, nameend - nextchar))
   {
     if (nameend - nextchar == strlen (p->name))
       {

  pfound = p;
  indfound = option_index;
  exact = 1;
  break;
       }
     else if (pfound == 
                       ((void *)0)
                           )
       {

  pfound = p;
  indfound = option_index;
       }
     else

       ambig = 1;
   }

      if (ambig && !exact)
 {
   if (opterr)
     fprintf (
             (__acrt_iob_func(2))
                   , "%s: option `%s' is ambiguous\n",
       argv[0], argv[optind]);
   nextchar += strlen (nextchar);
   optind++;
   return '?';
 }

      if (pfound != 
                   ((void *)0)
                       )
 {
   option_index = indfound;
   optind++;
   if (*nameend)
     {


       if (pfound->has_arg)
  optarg = nameend + 1;
       else
  {
    if (opterr)
      {
        if (argv[optind - 1][1] == '-')

   fprintf (
           (__acrt_iob_func(2))
                 ,
     "%s: option `--%s' doesn't allow an argument\n",
     argv[0], pfound->name);
        else

   fprintf (
           (__acrt_iob_func(2))
                 ,
        "%s: option `%c%s' doesn't allow an argument\n",
        argv[0], argv[optind - 1][0], pfound->name);
      }
    nextchar += strlen (nextchar);
    return '?';
  }
     }
   else if (pfound->has_arg == 1)
     {
       if (optind < argc)
  optarg = argv[optind++];
       else
  {
    if (opterr)
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: option `%s' requires an argument\n",
        argv[0], argv[optind - 1]);
    nextchar += strlen (nextchar);
    return optstring[0] == ':' ? ':' : '?';
  }
     }
   nextchar += strlen (nextchar);
   if (longind != 
                 ((void *)0)
                     )
     *longind = option_index;
   if (pfound->flag)
     {
       *(pfound->flag) = pfound->val;
       return 0;
     }
   return pfound->val;
 }





      if (!long_only || argv[optind][1] == '-'
   || my_index (optstring, *nextchar) == 
                                        ((void *)0)
                                            )
 {
   if (opterr)
     {
       if (argv[optind][1] == '-')

  fprintf (
          (__acrt_iob_func(2))
                , "%s: unrecognized option `--%s'\n",
    argv[0], nextchar);
       else

  fprintf (
          (__acrt_iob_func(2))
                , "%s: unrecognized option `%c%s'\n",
    argv[0], argv[optind][0], nextchar);
     }
   nextchar = (char *) "";
   optind++;
   return '?';
 }
    }



  {
    char c = *nextchar++;
    char *temp = my_index (optstring, c);


    if (*nextchar == '\0')
      ++optind;

    if (temp == 
               ((void *)0) 
                    || c == ':')
      {
 if (opterr)
   {

     fprintf (
             (__acrt_iob_func(2))
                   , "%s: illegal option -- %c\n", argv[0], c);
   }
 optopt = c;
 return '?';
      }
    if (temp[1] == ':')
      {
 if (temp[2] == ':')
   {

     if (*nextchar != '\0')
       {
  optarg = nextchar;
  optind++;
       }
     else
       optarg = 
               ((void *)0)
                   ;
     nextchar = 
               ((void *)0)
                   ;
   }
 else
   {

     if (*nextchar != '\0')
       {
  optarg = nextchar;


  optind++;
       }
     else if (optind == argc)
       {
  if (opterr)
    {

      fprintf (
              (__acrt_iob_func(2))
                    , "%s: option requires an argument -- %c\n",
        argv[0], c);
    }
  optopt = c;
  if (optstring[0] == ':')
    c = ':';
  else
    c = '?';
       }
     else


       optarg = argv[optind++];
     nextchar = 
               ((void *)0)
                   ;
   }
      }
    return c;
  }
}

int
getopt(int argc, char *const *argv, const char *optstring) asm("_getopt");
int
getopt(int argc, char *const *argv, const char *optstring)
{
  return _getopt_internal (argc, argv, optstring,
      (const struct n64_tag_option *) 0,
      (int *) 0,
      0);
}

