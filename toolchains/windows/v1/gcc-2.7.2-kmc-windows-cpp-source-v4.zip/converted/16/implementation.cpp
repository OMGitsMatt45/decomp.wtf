// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/fold-const.c
/* Fold a constant sub-tree into a single node for C-compiler
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int target_isnan(...) asm("_target_isnan");
extern int set_float_handler(...) asm("_set_float_handler");
extern int warning(...) asm("_warning");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int simple_cst_equal(...) asm("_simple_cst_equal");
extern int target_negative(...) asm("_target_negative");
extern int real_onep(...) asm("_real_onep");
extern int real_twop(...) asm("_real_twop");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");


static jmp_buf float_error;

static void encode (int *, int, int) asm("_encode");
static void decode (int *, int *, int *) asm("_decode");
int div_and_round_double (n64_enum_tree_code, int, int, int, int, int, int *, int *, int *, int *) asm("_div_and_round_double")



                            ;
static int split_tree (tree, n64_enum_tree_code, tree *, tree *, int *) asm("_split_tree");
static tree const_binop (n64_enum_tree_code, tree, tree, int) asm("_const_binop");
static tree fold_convert (tree, tree) asm("_fold_convert");
static n64_enum_tree_code invert_tree_comparison (n64_enum_tree_code) asm("_invert_tree_comparison");
static n64_enum_tree_code swap_tree_comparison (n64_enum_tree_code) asm("_swap_tree_comparison");
static int truth_value_p (n64_enum_tree_code) asm("_truth_value_p");
static int operand_equal_for_comparison_p (tree, tree, tree) asm("_operand_equal_for_comparison_p");
static int twoval_comparison_p (tree, tree *, tree *, int *) asm("_twoval_comparison_p");
static tree eval_subst (tree, tree, tree, tree, tree) asm("_eval_subst");
static tree omit_one_operand (tree, tree, tree) asm("_omit_one_operand");
static tree pedantic_omit_one_operand (tree, tree, tree) asm("_pedantic_omit_one_operand");
static tree distribute_bit_expr (n64_enum_tree_code, tree, tree, tree) asm("_distribute_bit_expr");
static tree make_bit_field_ref (tree, tree, int, int, int) asm("_make_bit_field_ref");
static tree optimize_bit_field_compare (n64_enum_tree_code, tree, tree, tree) asm("_optimize_bit_field_compare")
                       ;
static tree decode_field_reference (tree, int *, int *, n64_enum_machine_mode *, int *, int *, tree *, tree *) asm("_decode_field_reference")

                              ;
static int all_ones_mask_p (tree, int) asm("_all_ones_mask_p");
static int simple_operand_p (tree) asm("_simple_operand_p");
static tree range_test (n64_enum_tree_code, tree, n64_enum_tree_code, n64_enum_tree_code, tree, tree, tree) asm("_range_test")
                                            ;
static tree unextend (tree, int, int, tree) asm("_unextend");
static tree fold_truthop (n64_enum_tree_code, tree, tree, tree) asm("_fold_truthop");
static tree strip_compound_expr (tree, tree) asm("_strip_compound_expr");
static void
encode(int *words, int low, int hi) asm("_encode");
static void
encode(int *words, int low, int hi)
{
  words[0] = ((low) & (((unsigned int) 1 << (32/2)) - 1));
  words[1] = ((unsigned int) (low) >> 32/2);
  words[2] = ((hi) & (((unsigned int) 1 << (32/2)) - 1));
  words[3] = ((unsigned int) (hi) >> 32/2);
}





static void
decode(int *words, int *low, int *hi) asm("_decode");
static void
decode(int *words, int *low, int *hi)
{
  *low = words[0] | words[1] * ((unsigned int) 1 << 32/2);
  *hi = words[2] | words[3] * ((unsigned int) 1 << 32/2);
}
int
force_fit_type(tree t, int overflow) asm("_force_fit_type");
int
force_fit_type(tree t, int overflow)
{
  int low, high;
  register int prec;

  if (((n64_enum_tree_code) (t)->common.code) == REAL_CST)
    {




      return overflow;
    }

  else if (((n64_enum_tree_code) (t)->common.code) != INTEGER_CST)
    return overflow;

  low = ((t)->int_cst.int_cst_low);
  high = ((t)->int_cst.int_cst_high);

  if (((n64_enum_tree_code) (((t)->common.type))->common.code) == POINTER_TYPE)
    prec = ((target_flags & 0x00000002) ? 64 : 32);
  else
    prec = ((((t)->common.type))->type.precision);



  if (prec == 2 * 32)
    ;
  else if (prec > 32)
    {
      ((t)->int_cst.int_cst_high)
 &= ~((int) (-1) << (prec - 32));
    }
  else
    {
      ((t)->int_cst.int_cst_high) = 0;
      if (prec < 32)
 ((t)->int_cst.int_cst_low) &= ~((int) (-1) << prec);
    }


  if (((((t)->common.type))->common.unsigned_flag))
    return overflow;


  if (prec != 2 * 32
      && (prec > 32
   ? (((t)->int_cst.int_cst_high)
      & ((int) 1 << (prec - 32 - 1)))
   : ((t)->int_cst.int_cst_low) & ((int) 1 << (prec - 1))))
    {


      if (prec > 32)
 {
   ((t)->int_cst.int_cst_high)
     |= ((int) (-1) << (prec - 32));
 }
      else
 {
   ((t)->int_cst.int_cst_high) = -1;
   if (prec < 32)
     ((t)->int_cst.int_cst_low) |= ((int) (-1) << prec);
 }
    }


  return
    ((overflow | (low ^ ((t)->int_cst.int_cst_low)) | (high ^ ((t)->int_cst.int_cst_high)))
     != 0);
}






int
add_double(int l1, int h1, int l2, int h2, int *lv, int *hv) asm("_add_double");
int
add_double(int l1, int h1, int l2, int h2, int *lv, int *hv)
{
  int l, h;

  l = l1 + l2;
  h = h1 + h2 + ((unsigned int) l < l1);

  *lv = l;
  *hv = h;
  return ((~((h1) ^ (h2)) & ((h1) ^ (h))) < 0);
}






int
neg_double(int l1, int h1, int *lv, int *hv) asm("_neg_double");
int
neg_double(int l1, int h1, int *lv, int *hv)
{
  if (l1 == 0)
    {
      *lv = 0;
      *hv = - h1;
      return (*hv & h1) < 0;
    }
  else
    {
      *lv = - l1;
      *hv = ~ h1;
      return 0;
    }
}







int
mul_double(int l1, int h1, int l2, int h2, int *lv, int *hv) asm("_mul_double");
int
mul_double(int l1, int h1, int l2, int h2, int *lv, int *hv)
{
  int arg1[4];
  int arg2[4];
  int prod[4 * 2];
  register unsigned int carry;
  register int i, j, k;
  int toplow, tophigh, neglow, neghigh;

  encode (arg1, l1, h1);
  encode (arg2, l2, h2);

  memset ((char *) prod,0,sizeof prod);

  for (i = 0; i < 4; i++)
    {
      carry = 0;
      for (j = 0; j < 4; j++)
 {
   k = i + j;

   carry += arg1[i] * arg2[j];

   carry += prod[k];
   prod[k] = ((carry) & (((unsigned int) 1 << (32/2)) - 1));
   carry = ((unsigned int) (carry) >> 32/2);
 }
      prod[i + 4] = carry;
    }

  decode (prod, lv, hv);



  decode (prod+4, &toplow, &tophigh);
  if (h1 < 0)
    {
      neg_double (l2, h2, &neglow, &neghigh);
      add_double (neglow, neghigh, toplow, tophigh, &toplow, &tophigh);
    }
  if (h2 < 0)
    {
      neg_double (l1, h1, &neglow, &neghigh);
      add_double (neglow, neghigh, toplow, tophigh, &toplow, &tophigh);
    }
  return (*hv < 0 ? ~(toplow & tophigh) : toplow | tophigh) != 0;
}







void
lshift_double(int l1, int h1, int count, int prec, int *lv, int *hv, int arith) asm("_lshift_double");
void
lshift_double(int l1, int h1, int count, int prec, int *lv, int *hv, int arith)
{
  if (count < 0)
    {
      rshift_double (l1, h1, - count, prec, lv, hv, arith);
      return;
    }


  if (1)
    count %= prec;


  if (count >= 32)
    {
      *hv = (unsigned int) l1 << count - 32;
      *lv = 0;
    }
  else
    {
      *hv = (((unsigned int) h1 << count)
      | ((unsigned int) l1 >> 32 - count - 1 >> 1));
      *lv = (unsigned int) l1 << count;
    }
}






void
rshift_double(int l1, int h1, int count, int prec, int *lv, int *hv, int arith) asm("_rshift_double");
void
rshift_double(int l1, int h1, int count, int prec, int *lv, int *hv, int arith)
{
  unsigned int signmask;
  signmask = (arith
       ? -((unsigned int) h1 >> (32 - 1))
       : 0);


  if (1)
    count %= prec;


  if (count >= 32)
    {
      *hv = signmask;
      *lv = ((signmask << 2 * 32 - count - 1 << 1)
      | ((unsigned int) h1 >> count - 32));
    }
  else
    {
      *lv = (((unsigned int) l1 >> count)
      | ((unsigned int) h1 << 32 - count - 1 << 1));
      *hv = ((signmask << 32 - count)
      | ((unsigned int) h1 >> count));
    }
}






void
lrotate_double(int l1, int h1, int count, int prec, int *lv, int *hv) asm("_lrotate_double");
void
lrotate_double(int l1, int h1, int count, int prec, int *lv, int *hv)
{
  int s1l, s1h, s2l, s2h;

  count %= prec;
  if (count < 0)
    count += prec;

  lshift_double (l1, h1, count, prec, &s1l, &s1h, 0);
  rshift_double (l1, h1, prec - count, prec, &s2l, &s2h, 0);
  *lv = s1l | s2l;
  *hv = s1h | s2h;
}





void
rrotate_double(int l1, int h1, int count, int prec, int *lv, int *hv) asm("_rrotate_double");
void
rrotate_double(int l1, int h1, int count, int prec, int *lv, int *hv)
{
  int s1l, s1h, s2l, s2h;

  count %= prec;
  if (count < 0)
    count += prec;

  rshift_double (l1, h1, count, prec, &s1l, &s1h, 0);
  lshift_double (l1, h1, prec - count, prec, &s2l, &s2h, 0);
  *lv = s1l | s2l;
  *hv = s1h | s2h;
}
int
div_and_round_double(n64_enum_tree_code code, int uns, int lnum_orig, int hnum_orig, int lden_orig, int hden_orig, int *lquo, int *hquo, int *lrem, int *hrem) asm("_div_and_round_double");
int
div_and_round_double(n64_enum_tree_code code, int uns, int lnum_orig, int hnum_orig, int lden_orig, int hden_orig, int *lquo, int *hquo, int *lrem, int *hrem)
{
  int quo_neg = 0;
  int num[4 + 1];
  int den[4], quo[4];
  register int i, j;
  unsigned int work;
  register unsigned int carry = 0;
  int lnum = lnum_orig;
  int hnum = hnum_orig;
  int lden = lden_orig;
  int hden = hden_orig;
  int overflow = 0;

  if ((hden == 0) && (lden == 0))
    abort ();


  if (!uns)
    {
      if (hnum < 0)
 {
   quo_neg = ~ quo_neg;

   if (neg_double (lnum, hnum, &lnum, &hnum) && (lden & hden) == -1)
     overflow = 1;
 }
      if (hden < 0)
 {
   quo_neg = ~ quo_neg;
   neg_double (lden, hden, &lden, &hden);
 }
    }

  if (hnum == 0 && hden == 0)
    {
      *hquo = *hrem = 0;

      *lquo = lnum / (unsigned int) lden;
      goto finish_up;
    }

  if (hnum == 0)
    {

      *hquo = *lquo = 0;
      *hrem = hnum;
      *lrem = lnum;
      goto finish_up;
    }

  memset ((char *) quo,0,sizeof quo);

  memset ((char *) num,0,sizeof num);
  memset ((char *) den,0,sizeof den);

  encode (num, lnum, hnum);
  encode (den, lden, hden);


  if (hden == 0 && lden < ((unsigned int) 1 << 32/2))
    {

      for (i = 4 - 1; i >= 0; i--)
 {
   work = num[i] + carry * ((unsigned int) 1 << 32/2);
   quo[i] = work / (unsigned int) lden;
   carry = work % (unsigned int) lden;
 }
    }
  else
    {


    int num_hi_sig, den_hi_sig;
    unsigned int quo_est, scale;


    for (i = 4 - 1; ; i--)
      if (den[i] != 0) {
 den_hi_sig = i;
 break;
      }




    scale = ((unsigned int) 1 << 32/2) / (den[den_hi_sig] + 1);
    if (scale > 1) {
      carry = 0;
      for (i = 0; i <= 4 - 1; i++) {
 work = (num[i] * scale) + carry;
 num[i] = ((work) & (((unsigned int) 1 << (32/2)) - 1));
 carry = ((unsigned int) (work) >> 32/2);
      } num[4] = carry;
      carry = 0;
      for (i = 0; i <= 4 - 1; i++) {
 work = (den[i] * scale) + carry;
 den[i] = ((work) & (((unsigned int) 1 << (32/2)) - 1));
 carry = ((unsigned int) (work) >> 32/2);
 if (den[i] != 0) den_hi_sig = i;
      }
    }

    num_hi_sig = 4;


    for (i = num_hi_sig - den_hi_sig - 1; i >= 0; i--) {



      unsigned int tmp;

      num_hi_sig = i + den_hi_sig + 1;
      work = num[num_hi_sig] * ((unsigned int) 1 << 32/2) + num[num_hi_sig - 1];
      if (num[num_hi_sig] != den[den_hi_sig])
 quo_est = work / den[den_hi_sig];
      else
 quo_est = ((unsigned int) 1 << 32/2) - 1;


      tmp = work - quo_est * den[den_hi_sig];
      if (tmp < ((unsigned int) 1 << 32/2)
   && den[den_hi_sig - 1] * quo_est > (tmp * ((unsigned int) 1 << 32/2) + num[num_hi_sig - 2]))
 quo_est--;





      carry = 0;
      for (j = 0; j <= den_hi_sig; j++)
 {
   work = quo_est * den[j] + carry;
   carry = ((unsigned int) (work) >> 32/2);
   work = num[i + j] - ((work) & (((unsigned int) 1 << (32/2)) - 1));
   num[i + j] = ((work) & (((unsigned int) 1 << (32/2)) - 1));
   carry += ((unsigned int) (work) >> 32/2) != 0;
 }




      if (num[num_hi_sig] < carry)
 {
   quo_est--;
   carry = 0;
   for (j = 0; j <= den_hi_sig; j++)
     {
       work = num[i + j] + den[j] + carry;
       carry = ((unsigned int) (work) >> 32/2);
       num[i + j] = ((work) & (((unsigned int) 1 << (32/2)) - 1));
     }
   num [num_hi_sig] += carry;
 }


      quo[i] = quo_est;
    }
  }

  decode (quo, lquo, hquo);

 finish_up:

  if (quo_neg)
    neg_double (*lquo, *hquo, lquo, hquo);


  mul_double (*lquo, *hquo, lden_orig, hden_orig, lrem, hrem);
  neg_double (*lrem, *hrem, lrem, hrem);
  add_double (lnum_orig, hnum_orig, *lrem, *hrem, lrem, hrem);

  switch (code)
    {
    case TRUNC_DIV_EXPR:
    case TRUNC_MOD_EXPR:
    case EXACT_DIV_EXPR:
      return overflow;

    case FLOOR_DIV_EXPR:
    case FLOOR_MOD_EXPR:
      if (quo_neg && (*lrem != 0 || *hrem != 0))
 {

   add_double (*lquo, *hquo, (int) -1, (int) -1,
        lquo, hquo);
 }
      else return overflow;
      break;

    case CEIL_DIV_EXPR:
    case CEIL_MOD_EXPR:
      if (!quo_neg && (*lrem != 0 || *hrem != 0))
 {
   add_double (*lquo, *hquo, (int) 1, (int) 0,
        lquo, hquo);
 }
      else return overflow;
      break;

    case ROUND_DIV_EXPR:
    case ROUND_MOD_EXPR:
      {
 int labs_rem = *lrem, habs_rem = *hrem;
 int labs_den = lden, habs_den = hden, ltwice, htwice;


 if (*hrem < 0) neg_double (*lrem, *hrem, &labs_rem, &habs_rem);
 if (hden < 0) neg_double (lden, hden, &labs_den, &habs_den);


 mul_double ((int) 2, (int) 0,
      labs_rem, habs_rem, &ltwice, &htwice);
 if (((unsigned int) habs_den
      < (unsigned int) htwice)
     || (((unsigned int) habs_den
   == (unsigned int) htwice)
  && ((int unsigned) labs_den
      < (unsigned int) ltwice)))
   {
     if (*hquo < 0)

       add_double (*lquo, *hquo,
     (int) -1, (int) -1, lquo, hquo);
     else

       add_double (*lquo, *hquo, (int) 1, (int) 0,
     lquo, hquo);
   }
 else return overflow;
      }
      break;

    default:
      abort ();
    }


  mul_double (*lquo, *hquo, lden_orig, hden_orig, lrem, hrem);
  neg_double (*lrem, *hrem, lrem, hrem);
  add_double (lnum_orig, hnum_orig, *lrem, *hrem, lrem, hrem);
  return overflow;
}
static int
split_tree(tree in, n64_enum_tree_code code, tree *varp, tree *conp, int *varsignp) asm("_split_tree");
static int
split_tree(tree in, n64_enum_tree_code code, tree *varp, tree *conp, int *varsignp)
{
  register tree outtype = ((in)->common.type);
  *varp = 0;
  *conp = 0;


  while ((((n64_enum_tree_code) (in)->common.code) == NOP_EXPR
   || ((n64_enum_tree_code) (in)->common.code) == CONVERT_EXPR)
  && (((((in)->common.type))->type.mode)
      == ((((((in)->exp.operands[0]))->common.type))->type.mode)))
    in = ((in)->exp.operands[0]);

  if (((n64_enum_tree_code) (in)->common.code) == code
      || (! (((n64_enum_tree_code) (((in)->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((in)->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((in)->common.type))->common.type))->common.code) == REAL_TYPE))




   && ((code == PLUS_EXPR && ((n64_enum_tree_code) (in)->common.code) == MINUS_EXPR)
       || (code == MINUS_EXPR && ((n64_enum_tree_code) (in)->common.code) == PLUS_EXPR))))
    {
      n64_enum_tree_code code = ((n64_enum_tree_code) (((in)->exp.operands[0]))->common.code);
      if (code == INTEGER_CST)
 {
   *conp = ((in)->exp.operands[0]);
   *varp = ((in)->exp.operands[1]);
   if (((((*varp)->common.type))->type.mode) != ((outtype)->type.mode)
       && ((*varp)->common.type) != outtype)
     *varp = convert (outtype, *varp);
   *varsignp = (((n64_enum_tree_code) (in)->common.code) == MINUS_EXPR) ? -1 : 1;
   return 1;
 }
      if (((((in)->exp.operands[1]))->common.constant_flag))
 {
   *conp = ((in)->exp.operands[1]);
   *varp = ((in)->exp.operands[0]);
   *varsignp = 1;
   if (((((*varp)->common.type))->type.mode) != ((outtype)->type.mode)
       && ((*varp)->common.type) != outtype)
     *varp = convert (outtype, *varp);
   if (((n64_enum_tree_code) (in)->common.code) == MINUS_EXPR)
     {





       if (((n64_enum_tree_code) (*conp)->common.code) == INTEGER_CST)

  *conp = fold (build1 (NEGATE_EXPR, ((*conp)->common.type), *conp));
       else
  return 0;
     }
   return 1;
 }
      if (((((in)->exp.operands[0]))->common.constant_flag))
 {
   *conp = ((in)->exp.operands[0]);
   *varp = ((in)->exp.operands[1]);
   if (((((*varp)->common.type))->type.mode) != ((outtype)->type.mode)
       && ((*varp)->common.type) != outtype)
     *varp = convert (outtype, *varp);
   *varsignp = (((n64_enum_tree_code) (in)->common.code) == MINUS_EXPR) ? -1 : 1;
   return 1;
 }
    }
  return 0;
}
static tree
const_binop(n64_enum_tree_code code, register tree arg1, register tree arg2, int notrunc) asm("_const_binop");
static tree
const_binop(n64_enum_tree_code code, register tree arg1, register tree arg2, int notrunc)
{
  if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
    {
      register int int1l = ((arg1)->int_cst.int_cst_low);
      register int int1h = ((arg1)->int_cst.int_cst_high);
      int int2l = ((arg2)->int_cst.int_cst_low);
      int int2h = ((arg2)->int_cst.int_cst_high);
      int low, hi;
      int garbagel, garbageh;
      register tree t;
      int uns = ((((arg1)->common.type))->common.unsigned_flag);
      int overflow = 0;

      switch (code)
 {
 case BIT_IOR_EXPR:
   t = build_int_2_wide ((int) (int1l | int2l), (int) (int1h | int2h));
   break;

 case BIT_XOR_EXPR:
   t = build_int_2_wide ((int) (int1l ^ int2l), (int) (int1h ^ int2h));
   break;

 case BIT_AND_EXPR:
   t = build_int_2_wide ((int) (int1l & int2l), (int) (int1h & int2h));
   break;

 case BIT_ANDTC_EXPR:
   t = build_int_2_wide ((int) (int1l & ~int2l), (int) (int1h & ~int2h));
   break;

 case RSHIFT_EXPR:
   int2l = - int2l;
 case LSHIFT_EXPR:



   lshift_double (int1l, int1h, int2l,
    ((((arg1)->common.type))->type.precision),
    &low, &hi,
    !uns);
   t = build_int_2_wide ((int) (low), (int) (hi));
   ((t)->common.type) = ((arg1)->common.type);
   if (!notrunc)
     force_fit_type (t, 0);
   ((t)->common.public_flag) = ((arg1)->common.public_flag) | ((arg2)->common.public_flag);
   ((t)->common.static_flag)
     = ((arg1)->common.static_flag) | ((arg2)->common.static_flag);
   return t;

 case RROTATE_EXPR:
   int2l = - int2l;
 case LROTATE_EXPR:
   lrotate_double (int1l, int1h, int2l,
     ((((arg1)->common.type))->type.precision),
     &low, &hi);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case PLUS_EXPR:
   if (int1h == 0)
     {
       int2l += int1l;
       if ((unsigned int) int2l < int1l)
  {
    hi = int2h++;
    overflow = int2h < hi;
  }
       t = build_int_2_wide ((int) (int2l), (int) (int2h));
       break;
     }
   if (int2h == 0)
     {
       int1l += int2l;
       if ((unsigned int) int1l < int2l)
  {
    hi = int1h++;
    overflow = int1h < hi;
  }
       t = build_int_2_wide ((int) (int1l), (int) (int1h));
       break;
     }
   overflow = add_double (int1l, int1h, int2l, int2h, &low, &hi);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case MINUS_EXPR:
   if (int2h == 0 && int2l == 0)
     {
       t = build_int_2_wide ((int) (int1l), (int) (int1h));
       break;
     }
   neg_double (int2l, int2h, &low, &hi);
   add_double (int1l, int1h, low, hi, &low, &hi);
   overflow = ((~((hi) ^ (int2h)) & ((hi) ^ (int1h))) < 0);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case MULT_EXPR:
   overflow = mul_double (int1l, int1h, int2l, int2h, &low, &hi);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case TRUNC_DIV_EXPR:
 case FLOOR_DIV_EXPR: case CEIL_DIV_EXPR:
 case EXACT_DIV_EXPR:



   if (int2h == 0 && int2l > 0
       && ((arg1)->common.type) == sizetype
       && int1h == 0 && int1l >= 0)
     {
       if (code == CEIL_DIV_EXPR)
  int1l += int2l-1;
       return size_int (int1l / int2l);
     }
 case ROUND_DIV_EXPR:
   if (int2h == 0 && int2l == 1)
     {
       t = build_int_2_wide ((int) (int1l), (int) (int1h));
       break;
     }
   if (int1l == int2l && int1h == int2h)
     {
       if ((int1l | int1h) == 0)
  abort ();
       t = build_int_2_wide ((int) (1), (int) (0));
       break;
     }
   overflow = div_and_round_double (code, uns,
        int1l, int1h, int2l, int2h,
        &low, &hi, &garbagel, &garbageh);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case TRUNC_MOD_EXPR: case ROUND_MOD_EXPR:
 case FLOOR_MOD_EXPR: case CEIL_MOD_EXPR:
   overflow = div_and_round_double (code, uns,
        int1l, int1h, int2l, int2h,
        &garbagel, &garbageh, &low, &hi);
   t = build_int_2_wide ((int) (low), (int) (hi));
   break;

 case MIN_EXPR:
 case MAX_EXPR:
   if (uns)
     {
       low = (((unsigned int) int1h
        < (unsigned int) int2h)
       || (((unsigned int) int1h
     == (unsigned int) int2h)
    && ((unsigned int) int1l
        < (unsigned int) int2l)));
     }
   else
     {
       low = ((int1h < int2h)
       || ((int1h == int2h)
    && ((unsigned int) int1l
        < (unsigned int) int2l)));
     }
   if (low == (code == MIN_EXPR))
     t = build_int_2_wide ((int) (int1l), (int) (int1h));
   else
     t = build_int_2_wide ((int) (int2l), (int) (int2h));
   break;

 default:
   abort ();
 }
    got_it:
      ((t)->common.type) = ((arg1)->common.type);
      ((t)->common.public_flag)
 = ((notrunc ? !uns && overflow : force_fit_type (t, overflow && !uns))
    | ((arg1)->common.public_flag)
    | ((arg2)->common.public_flag));
      ((t)->common.static_flag) = (((t)->common.public_flag)
        | ((arg1)->common.static_flag)
        | ((arg2)->common.static_flag));
      return t;
    }

  if (((n64_enum_tree_code) (arg1)->common.code) == REAL_CST)
    {
      double d1;
      double d2;
      int overflow = 0;
      double value;
      tree t;

      d1 = ((arg1)->real_cst.real_cst);
      d2 = ((arg2)->real_cst.real_cst);



      if ((target_isnan (d1)))
 return arg1;
      else if ((target_isnan (d2)))
 return arg2;
      else if (
              _setjmp3((
              float_error
              ), ((void *)0))
                                  )
 {
   t = copy_node (arg1);
   overflow = 1;
   goto got_float;
 }

      set_float_handler (float_error);


      earith (&(value), (code), &(d1), &(d2));
      t = build_real (((arg1)->common.type),
        real_value_truncate (((((arg1)->common.type))->type.mode), value));
    got_float:
      set_float_handler (((void *)0));

      ((t)->common.public_flag)
 = (force_fit_type (t, overflow)
    | ((arg1)->common.public_flag) | ((arg2)->common.public_flag));
      ((t)->common.static_flag)
 = ((t)->common.public_flag)
   | ((arg1)->common.static_flag)
   | ((arg2)->common.static_flag);
      return t;
    }

  if (((n64_enum_tree_code) (arg1)->common.code) == COMPLEX_CST)
    {
      register tree r1 = ((arg1)->complex.real);
      register tree i1 = ((arg1)->complex.imag);
      register tree r2 = ((arg2)->complex.real);
      register tree i2 = ((arg2)->complex.imag);
      register tree t;

      switch (code)
 {
 case PLUS_EXPR:
   t = build_complex (const_binop (PLUS_EXPR, r1, r2, notrunc),
        const_binop (PLUS_EXPR, i1, i2, notrunc));
   break;

 case MINUS_EXPR:
   t = build_complex (const_binop (MINUS_EXPR, r1, r2, notrunc),
        const_binop (MINUS_EXPR, i1, i2, notrunc));
   break;

 case MULT_EXPR:
   t = build_complex (const_binop (MINUS_EXPR,
       const_binop (MULT_EXPR,
             r1, r2, notrunc),
       const_binop (MULT_EXPR,
             i1, i2, notrunc),
       notrunc),
        const_binop (PLUS_EXPR,
       const_binop (MULT_EXPR,
             r1, i2, notrunc),
       const_binop (MULT_EXPR,
             i1, r2, notrunc),
       notrunc));
   break;

 case RDIV_EXPR:
   {
     register tree magsquared
       = const_binop (PLUS_EXPR,
        const_binop (MULT_EXPR, r2, r2, notrunc),
        const_binop (MULT_EXPR, i2, i2, notrunc),
        notrunc);

     t = build_complex
       (const_binop ((((n64_enum_tree_code) (((r1)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == CHAR_TYPE)
       ? TRUNC_DIV_EXPR : RDIV_EXPR,
       const_binop (PLUS_EXPR,
      const_binop (MULT_EXPR, r1, r2,
            notrunc),
      const_binop (MULT_EXPR, i1, i2,
            notrunc),
      notrunc),
       magsquared, notrunc),
        const_binop ((((n64_enum_tree_code) (((r1)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((r1)->common.type))->common.code) == CHAR_TYPE)
       ? TRUNC_DIV_EXPR : RDIV_EXPR,
       const_binop (MINUS_EXPR,
      const_binop (MULT_EXPR, i1, r2,
            notrunc),
      const_binop (MULT_EXPR, r1, i2,
            notrunc),
      notrunc),
       magsquared, notrunc));
   }
   break;

 default:
   abort ();
 }
      ((t)->common.type) = ((arg1)->common.type);
      return t;
    }
  return 0;
}



tree
size_int(unsigned int number) asm("_size_int");
tree
size_int(unsigned int number)
{
  register tree t;

  static tree size_table[2*32 + 1];

  if (number < 2*32 + 1
      && size_table[number] != 0)
    return size_table[number];
  if (number < 2*32 + 1)
    {
      push_obstacks_nochange ();

      end_temporary_allocation ();
      t = build_int_2_wide ((int) (number), (int) (0));
      ((t)->common.type) = sizetype;
      size_table[number] = t;
      pop_obstacks ();
    }
  else
    {
      t = build_int_2_wide ((int) (number), (int) (0));
      ((t)->common.type) = sizetype;
    }
  return t;
}





tree
size_binop(n64_enum_tree_code code, tree arg0, tree arg1) asm("_size_binop");
tree
size_binop(n64_enum_tree_code code, tree arg0, tree arg1)
{

  if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
    {

      if (code == PLUS_EXPR
   && ((arg0)->int_cst.int_cst_low) == 0
   && ((arg0)->int_cst.int_cst_high) == 0)
 return arg1;
      if (code == MINUS_EXPR
   && ((arg1)->int_cst.int_cst_low) == 0
   && ((arg1)->int_cst.int_cst_high) == 0)
 return arg0;
      if (code == MULT_EXPR
   && ((arg0)->int_cst.int_cst_low) == 1
   && ((arg0)->int_cst.int_cst_high) == 0)
 return arg1;

      return const_binop (code, arg0, arg1, 0);
    }

  if (arg0 == error_mark_node || arg1 == error_mark_node)
    return error_mark_node;

  return fold (build (code, sizetype, arg0, arg1));
}




static tree
fold_convert(register tree t, register tree arg1) asm("_fold_convert");
static tree
fold_convert(register tree t, register tree arg1)
{
  register tree type = ((t)->common.type);
  int overflow = 0;

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE || (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE))
    {
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
 {


   if (((type)->type.precision) > 2 * 32)
     return t;



   t = build_int_2_wide ((int) (((arg1)->int_cst.int_cst_low)), (int) (((arg1)->int_cst.int_cst_high)))
                               ;
   ((t)->common.type) = type;




   ((t)->common.public_flag)
     = (((arg1)->common.public_flag)
        | force_fit_type (t,
     (((arg1)->int_cst.int_cst_high) < 0
      & (((type)->common.unsigned_flag)
         < ((((arg1)->common.type))->common.unsigned_flag)))));
   ((t)->common.static_flag)
     = ((t)->common.public_flag) | ((arg1)->common.static_flag);
 }

      else if (((n64_enum_tree_code) (arg1)->common.code) == REAL_CST)
 {


   double x;
   double l;
   double u;

   x = ((arg1)->real_cst.real_cst);
   l = real_value_from_int_cst (((type)->type.minval));
   u = real_value_from_int_cst (((type)->type.maxval));




   earith (&(l), (MINUS_EXPR), &(l), &(dconst1));
   earith (&(u), (PLUS_EXPR), &(u), &(dconst1));






   if ((target_isnan (x)))
     overflow = 1, x = dconst0;
   else if (! ((ereal_cmp ((l), (x)) == -1) && (ereal_cmp ((x), (u)) == -1)))
     overflow = 1;
   {
     int low, high;
     ereal_to_int (&low, &high, x);
     t = build_int_2_wide ((int) (low), (int) (high));
   }

   ((t)->common.type) = type;
   ((t)->common.public_flag)
     = ((arg1)->common.public_flag) | force_fit_type (t, overflow);
   ((t)->common.static_flag)
     = ((t)->common.public_flag) | ((arg1)->common.static_flag);
 }

      ((t)->common.type) = type;
    }
  else if (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
    {

      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
 return build_real_from_int_cst (type, arg1);

      if (((n64_enum_tree_code) (arg1)->common.code) == REAL_CST)
 {
   if ((target_isnan (((arg1)->real_cst.real_cst))))
     return arg1;
   else if (
           _setjmp3((
           float_error
           ), ((void *)0))
                               )
     {
       overflow = 1;
       t = copy_node (arg1);
       goto got_it;
     }
   set_float_handler (float_error);

   t = build_real (type, real_value_truncate (((type)->type.mode),
           ((arg1)->real_cst.real_cst)));
   set_float_handler (((void *)0));

 got_it:
   ((t)->common.public_flag)
     = ((arg1)->common.public_flag) | force_fit_type (t, overflow);
   ((t)->common.static_flag)
     = ((t)->common.public_flag) | ((arg1)->common.static_flag);
   return t;
 }
    }
  ((t)->common.constant_flag) = 1;
  return t;
}




tree
non_lvalue(tree x) asm("_non_lvalue");
tree
non_lvalue(tree x)
{
  tree result;


  if (((n64_enum_tree_code) (x)->common.code) == NON_LVALUE_EXPR
      || ((n64_enum_tree_code) (x)->common.code) == INTEGER_CST
      || ((n64_enum_tree_code) (x)->common.code) == REAL_CST
      || ((n64_enum_tree_code) (x)->common.code) == STRING_CST
      || ((n64_enum_tree_code) (x)->common.code) == ADDR_EXPR)
    {
      if (((n64_enum_tree_code) (x)->common.code) == INTEGER_CST && integer_zerop (x))
 {



   result = build1 (NOP_EXPR, ((x)->common.type), x);
   ((result)->common.constant_flag) = ((x)->common.constant_flag);
   return result;
 }
      return x;
    }

  result = build1 (NON_LVALUE_EXPR, ((x)->common.type), x);
  ((result)->common.constant_flag) = ((x)->common.constant_flag);
  return result;
}




int pedantic_lvalues;




tree
pedantic_non_lvalue(tree x) asm("_pedantic_non_lvalue");
tree
pedantic_non_lvalue(tree x)
{
  if (pedantic_lvalues)
    return non_lvalue (x);
  else
    return x;
}





static n64_enum_tree_code
invert_tree_comparison(n64_enum_tree_code code) asm("_invert_tree_comparison");
static n64_enum_tree_code
invert_tree_comparison(n64_enum_tree_code code)
{
  switch (code)
    {
    case EQ_EXPR:
      return NE_EXPR;
    case NE_EXPR:
      return EQ_EXPR;
    case GT_EXPR:
      return LE_EXPR;
    case GE_EXPR:
      return LT_EXPR;
    case LT_EXPR:
      return GE_EXPR;
    case LE_EXPR:
      return GT_EXPR;
    default:
      abort ();
    }
}




static n64_enum_tree_code
swap_tree_comparison(n64_enum_tree_code code) asm("_swap_tree_comparison");
static n64_enum_tree_code
swap_tree_comparison(n64_enum_tree_code code)
{
  switch (code)
    {
    case EQ_EXPR:
    case NE_EXPR:
      return code;
    case GT_EXPR:
      return LT_EXPR;
    case GE_EXPR:
      return LE_EXPR;
    case LT_EXPR:
      return GT_EXPR;
    case LE_EXPR:
      return GE_EXPR;
    default:
      abort ();
    }
}



static int
truth_value_p(n64_enum_tree_code code) asm("_truth_value_p");
static int
truth_value_p(n64_enum_tree_code code)
{
  return ((*tree_code_type[(int) (code)]) == '<'
   || code == TRUTH_AND_EXPR || code == TRUTH_ANDIF_EXPR
   || code == TRUTH_OR_EXPR || code == TRUTH_ORIF_EXPR
   || code == TRUTH_XOR_EXPR || code == TRUTH_NOT_EXPR);
}
int
operand_equal_p(tree arg0, tree arg1, int only_const) asm("_operand_equal_p");
int
operand_equal_p(tree arg0, tree arg1, int only_const)
{



  if (((((arg0)->common.type))->common.unsigned_flag) != ((((arg1)->common.type))->common.unsigned_flag))
    return 0;

  while ((((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == NON_LVALUE_EXPR) && (((((arg0)->common.type))->type.mode) == ((((((arg0)->exp.operands[0]))->common.type))->type.mode))) (arg0) = ((arg0)->exp.operands[0]);;
  while ((((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == NON_LVALUE_EXPR) && (((((arg1)->common.type))->type.mode) == ((((((arg1)->exp.operands[0]))->common.type))->type.mode))) (arg1) = ((arg1)->exp.operands[0]);;




  if (((n64_enum_tree_code) (arg0)->common.code) == SAVE_EXPR && arg0 == arg1)
    return ! only_const;

  if (((arg0)->common.side_effects_flag) || ((arg1)->common.side_effects_flag))
    return 0;

  if (((n64_enum_tree_code) (arg0)->common.code) == ((n64_enum_tree_code) (arg1)->common.code)
      && ((n64_enum_tree_code) (arg0)->common.code) == ADDR_EXPR
      && ((arg0)->exp.operands[0]) == ((arg1)->exp.operands[0]))
    return 1;

  if (((n64_enum_tree_code) (arg0)->common.code) == ((n64_enum_tree_code) (arg1)->common.code)
      && ((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST
      && ((arg0)->int_cst.int_cst_low) == ((arg1)->int_cst.int_cst_low)
      && ((arg0)->int_cst.int_cst_high) == ((arg1)->int_cst.int_cst_high))
    return 1;


  if (((n64_enum_tree_code) (arg0)->common.code) == ((n64_enum_tree_code) (arg1)->common.code)
      && ((n64_enum_tree_code) (arg0)->common.code) == REAL_CST)
    return !memcmp ((char *) &((arg0)->real_cst.real_cst),(char *) &((arg1)->real_cst.real_cst),sizeof (double))

                             ;

  if (only_const)
    return 0;

  if (arg0 == arg1)
    return 1;

  if (((n64_enum_tree_code) (arg0)->common.code) != ((n64_enum_tree_code) (arg1)->common.code))
    return 0;


  if (((((arg0)->common.type))->type.mode) != ((((arg1)->common.type))->type.mode))
    return 0;

  switch ((*tree_code_type[(int) (((n64_enum_tree_code) (arg0)->common.code))]))
    {
    case '1':

      if ((((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == CONVERT_EXPR)
   && (((((arg0)->common.type))->common.unsigned_flag)
       != ((((arg1)->common.type))->common.unsigned_flag)))
 return 0;

      return operand_equal_p (((arg0)->exp.operands[0]),
         ((arg1)->exp.operands[0]), 0);

    case '<':
    case '2':
      return (operand_equal_p (((arg0)->exp.operands[0]),
          ((arg1)->exp.operands[0]), 0)
       && operand_equal_p (((arg0)->exp.operands[1]),
      ((arg1)->exp.operands[1]), 0));

    case 'r':
      switch (((n64_enum_tree_code) (arg0)->common.code))
 {
 case INDIRECT_REF:
   return operand_equal_p (((arg0)->exp.operands[0]),
      ((arg1)->exp.operands[0]), 0);

 case COMPONENT_REF:
 case ARRAY_REF:
   return (operand_equal_p (((arg0)->exp.operands[0]),
       ((arg1)->exp.operands[0]), 0)
    && operand_equal_p (((arg0)->exp.operands[1]),
          ((arg1)->exp.operands[1]), 0));

 case BIT_FIELD_REF:
   return (operand_equal_p (((arg0)->exp.operands[0]),
       ((arg1)->exp.operands[0]), 0)
    && operand_equal_p (((arg0)->exp.operands[1]),
          ((arg1)->exp.operands[1]), 0)
    && operand_equal_p (((arg0)->exp.operands[2]),
          ((arg1)->exp.operands[2]), 0));
 }
      break;
    }

  return 0;
}






static int
operand_equal_for_comparison_p(tree arg0, tree arg1, tree other) asm("_operand_equal_for_comparison_p");
static int
operand_equal_for_comparison_p(tree arg0, tree arg1, tree other)
{
  int unsignedp1, unsignedpo;
  tree primarg1, primother;
  unsigned correct_width;

  if (operand_equal_p (arg0, arg1, 0))
    return 1;

  if (! (((n64_enum_tree_code) (((arg0)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == CHAR_TYPE)
      || ! (((n64_enum_tree_code) (((arg1)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == CHAR_TYPE))
    return 0;







  primarg1 = get_narrower (arg1, &unsignedp1);
  primother = get_narrower (other, &unsignedpo);

  correct_width = ((((arg1)->common.type))->type.precision);
  if (unsignedp1 == unsignedpo
      && ((((primarg1)->common.type))->type.precision) < correct_width
      && ((((primother)->common.type))->type.precision) < correct_width)
    {
      tree type = ((arg0)->common.type);



      primarg1 = convert (signed_or_unsigned_type (unsignedp1,
        ((primarg1)->common.type)),
    primarg1);

      if (operand_equal_p (arg0, convert (type, primarg1), 0))
 return 1;
    }

  return 0;
}
static int
twoval_comparison_p(tree arg, tree *cval1, tree *cval2, int *save_p) asm("_twoval_comparison_p");
static int
twoval_comparison_p(tree arg, tree *cval1, tree *cval2, int *save_p)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (arg)->common.code);
  char cxx_class = (*tree_code_type[(int) (code)]);


  if (cxx_class == 'e' && code == TRUTH_NOT_EXPR)
    cxx_class = '1';
  else if (cxx_class == 'e'
    && (code == TRUTH_ANDIF_EXPR || code == TRUTH_ORIF_EXPR
        || code == COMPOUND_EXPR))
    cxx_class = '2';
  switch (cxx_class)
    {
    case '1':
      return twoval_comparison_p (((arg)->exp.operands[0]), cval1, cval2, save_p);

    case '2':
      return (twoval_comparison_p (((arg)->exp.operands[0]), cval1, cval2, save_p)
       && twoval_comparison_p (((arg)->exp.operands[1]),
          cval1, cval2, save_p));

    case 'c':
      return 1;

    case 'e':
      if (code == COND_EXPR)
 return (twoval_comparison_p (((arg)->exp.operands[0]),
         cval1, cval2, save_p)
  && twoval_comparison_p (((arg)->exp.operands[1]),
     cval1, cval2, save_p)
  && twoval_comparison_p (((arg)->exp.operands[2]),
     cval1, cval2, save_p));
      return 0;

    case '<':






      if (operand_equal_p (((arg)->exp.operands[0]),
      ((arg)->exp.operands[1]), 0))
 return 0;

      if (*cval1 == 0)
 *cval1 = ((arg)->exp.operands[0]);
      else if (operand_equal_p (*cval1, ((arg)->exp.operands[0]), 0))
 ;
      else if (*cval2 == 0)
 *cval2 = ((arg)->exp.operands[0]);
      else if (operand_equal_p (*cval2, ((arg)->exp.operands[0]), 0))
 ;
      else
 return 0;

      if (operand_equal_p (*cval1, ((arg)->exp.operands[1]), 0))
 ;
      else if (*cval2 == 0)
 *cval2 = ((arg)->exp.operands[1]);
      else if (operand_equal_p (*cval2, ((arg)->exp.operands[1]), 0))
 ;
      else
 return 0;

      return 1;
    }

  return 0;
}






static tree
eval_subst(tree arg, tree old0, tree new0, tree old1, tree new1) asm("_eval_subst");
static tree
eval_subst(tree arg, tree old0, tree new0, tree old1, tree new1)
{
  tree type = ((arg)->common.type);
  n64_enum_tree_code code = ((n64_enum_tree_code) (arg)->common.code);
  char cxx_class = (*tree_code_type[(int) (code)]);


  if (cxx_class == 'e' && code == TRUTH_NOT_EXPR)
    cxx_class = '1';
  else if (cxx_class == 'e'
    && (code == TRUTH_ANDIF_EXPR || code == TRUTH_ORIF_EXPR))
    cxx_class = '2';

  switch (cxx_class)
    {
    case '1':
      return fold (build1 (code, type,
      eval_subst (((arg)->exp.operands[0]),
           old0, new0, old1, new1)));

    case '2':
      return fold (build (code, type,
     eval_subst (((arg)->exp.operands[0]),
          old0, new0, old1, new1),
     eval_subst (((arg)->exp.operands[1]),
          old0, new0, old1, new1)));

    case 'e':
      switch (code)
 {
 case SAVE_EXPR:
   return eval_subst (((arg)->exp.operands[0]), old0, new0, old1, new1);

 case COMPOUND_EXPR:
   return eval_subst (((arg)->exp.operands[1]), old0, new0, old1, new1);

 case COND_EXPR:
   return fold (build (code, type,
         eval_subst (((arg)->exp.operands[0]),
       old0, new0, old1, new1),
         eval_subst (((arg)->exp.operands[1]),
       old0, new0, old1, new1),
         eval_subst (((arg)->exp.operands[2]),
       old0, new0, old1, new1)));
 }

    case '<':
      {
 tree arg0 = ((arg)->exp.operands[0]);
 tree arg1 = ((arg)->exp.operands[1]);





 if (arg0 == old0 || operand_equal_p (arg0, old0, 0))
   arg0 = new0;
 else if (arg0 == old1 || operand_equal_p (arg0, old1, 0))
   arg0 = new1;

 if (arg1 == old0 || operand_equal_p (arg1, old0, 0))
   arg1 = new0;
 else if (arg1 == old1 || operand_equal_p (arg1, old1, 0))
   arg1 = new1;

 return fold (build (code, type, arg0, arg1));
      }
    }

  return arg;
}
static tree
omit_one_operand(tree type, tree result, tree omitted) asm("_omit_one_operand");
static tree
omit_one_operand(tree type, tree result, tree omitted)
{
  tree t = convert (type, result);

  if (((omitted)->common.side_effects_flag))
    return build (COMPOUND_EXPR, type, omitted, t);

  return non_lvalue (t);
}



static tree
pedantic_omit_one_operand(tree type, tree result, tree omitted) asm("_pedantic_omit_one_operand");
static tree
pedantic_omit_one_operand(tree type, tree result, tree omitted)
{
  tree t = convert (type, result);

  if (((omitted)->common.side_effects_flag))
    return build (COMPOUND_EXPR, type, omitted, t);

  return pedantic_non_lvalue (t);
}







tree
invert_truthvalue(tree arg) asm("_invert_truthvalue");
tree
invert_truthvalue(tree arg)
{
  tree type = ((arg)->common.type);
  n64_enum_tree_code code = ((n64_enum_tree_code) (arg)->common.code);

  if (code == ERROR_MARK)
    return arg;





  if ((*tree_code_type[(int) (code)]) == '<')
    {
      if ((((n64_enum_tree_code) (((((arg)->exp.operands[0]))->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((((arg)->exp.operands[0]))->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((((arg)->exp.operands[0]))->common.type))->common.type))->common.code) == REAL_TYPE))
   && code != NE_EXPR && code != EQ_EXPR)
 return build1 (TRUTH_NOT_EXPR, type, arg);
      else
 return build (invert_tree_comparison (code), type,
        ((arg)->exp.operands[0]), ((arg)->exp.operands[1]));
    }

  switch (code)
    {
    case INTEGER_CST:
      return convert (type, build_int_2_wide ((int) (((arg)->int_cst.int_cst_low) == 0 && ((arg)->int_cst.int_cst_high) == 0), (int) (0))
                                         );

    case TRUTH_AND_EXPR:
      return build (TRUTH_OR_EXPR, type,
      invert_truthvalue (((arg)->exp.operands[0])),
      invert_truthvalue (((arg)->exp.operands[1])));

    case TRUTH_OR_EXPR:
      return build (TRUTH_AND_EXPR, type,
      invert_truthvalue (((arg)->exp.operands[0])),
      invert_truthvalue (((arg)->exp.operands[1])));

    case TRUTH_XOR_EXPR:





      if (((n64_enum_tree_code) (((arg)->exp.operands[1]))->common.code) == TRUTH_NOT_EXPR)
 return build (TRUTH_XOR_EXPR, type, ((arg)->exp.operands[0]),
        ((((arg)->exp.operands[1]))->exp.operands[0]));
      else
 return build (TRUTH_XOR_EXPR, type,
        invert_truthvalue (((arg)->exp.operands[0])),
        ((arg)->exp.operands[1]));

    case TRUTH_ANDIF_EXPR:
      return build (TRUTH_ORIF_EXPR, type,
      invert_truthvalue (((arg)->exp.operands[0])),
      invert_truthvalue (((arg)->exp.operands[1])));

    case TRUTH_ORIF_EXPR:
      return build (TRUTH_ANDIF_EXPR, type,
      invert_truthvalue (((arg)->exp.operands[0])),
      invert_truthvalue (((arg)->exp.operands[1])));

    case TRUTH_NOT_EXPR:
      return ((arg)->exp.operands[0]);

    case COND_EXPR:
      return build (COND_EXPR, type, ((arg)->exp.operands[0]),
      invert_truthvalue (((arg)->exp.operands[1])),
      invert_truthvalue (((arg)->exp.operands[2])));

    case COMPOUND_EXPR:
      return build (COMPOUND_EXPR, type, ((arg)->exp.operands[0]),
      invert_truthvalue (((arg)->exp.operands[1])));

    case NON_LVALUE_EXPR:
      return invert_truthvalue (((arg)->exp.operands[0]));

    case NOP_EXPR:
    case CONVERT_EXPR:
    case FLOAT_EXPR:
      return build1 (((n64_enum_tree_code) (arg)->common.code), type,
       invert_truthvalue (((arg)->exp.operands[0])));

    case BIT_AND_EXPR:
      if (!integer_onep (((arg)->exp.operands[1])))
 break;
      return build (EQ_EXPR, type, arg, convert (type, integer_zero_node));

    case SAVE_EXPR:
      return build1 (TRUTH_NOT_EXPR, type, arg);

    case CLEANUP_POINT_EXPR:
      return build1 (CLEANUP_POINT_EXPR, type,
       invert_truthvalue (((arg)->exp.operands[0])));
    }
  if (((n64_enum_tree_code) (((arg)->common.type))->common.code) != BOOLEAN_TYPE)
    abort ();
  return build1 (TRUTH_NOT_EXPR, type, arg);
}
static tree
distribute_bit_expr(n64_enum_tree_code code, tree type, tree arg0, tree arg1) asm("_distribute_bit_expr");
static tree
distribute_bit_expr(n64_enum_tree_code code, tree type, tree arg0, tree arg1)
{
  tree common;
  tree left, right;

  if (((n64_enum_tree_code) (arg0)->common.code) != ((n64_enum_tree_code) (arg1)->common.code)
      || ((n64_enum_tree_code) (arg0)->common.code) == code
      || (((n64_enum_tree_code) (arg0)->common.code) != BIT_AND_EXPR
   && ((n64_enum_tree_code) (arg0)->common.code) != BIT_IOR_EXPR))
    return 0;

  if (operand_equal_p (((arg0)->exp.operands[0]), ((arg1)->exp.operands[0]), 0))
    {
      common = ((arg0)->exp.operands[0]);
      left = ((arg0)->exp.operands[1]);
      right = ((arg1)->exp.operands[1]);
    }
  else if (operand_equal_p (((arg0)->exp.operands[0]), ((arg1)->exp.operands[1]), 0))
    {
      common = ((arg0)->exp.operands[0]);
      left = ((arg0)->exp.operands[1]);
      right = ((arg1)->exp.operands[0]);
    }
  else if (operand_equal_p (((arg0)->exp.operands[1]), ((arg1)->exp.operands[0]), 0))
    {
      common = ((arg0)->exp.operands[1]);
      left = ((arg0)->exp.operands[0]);
      right = ((arg1)->exp.operands[1]);
    }
  else if (operand_equal_p (((arg0)->exp.operands[1]), ((arg1)->exp.operands[1]), 0))
    {
      common = ((arg0)->exp.operands[1]);
      left = ((arg0)->exp.operands[0]);
      right = ((arg1)->exp.operands[0]);
    }
  else
    return 0;

  return fold (build (((n64_enum_tree_code) (arg0)->common.code), type, common,
        fold (build (code, type, left, right))));
}




static tree
make_bit_field_ref(tree inner, tree type, int bitsize, int bitpos, int unsignedp) asm("_make_bit_field_ref");
static tree
make_bit_field_ref(tree inner, tree type, int bitsize, int bitpos, int unsignedp)
{
  tree result = build (BIT_FIELD_REF, type, inner,
         size_int (bitsize), size_int (bitpos));

  ((result)->common.unsigned_flag) = unsignedp;

  return result;
}
static tree
optimize_bit_field_compare(n64_enum_tree_code code, tree compare_type, tree lhs, tree rhs) asm("_optimize_bit_field_compare");
static tree
optimize_bit_field_compare(n64_enum_tree_code code, tree compare_type, tree lhs, tree rhs)
{
  int lbitpos, lbitsize, rbitpos, rbitsize;
  int lnbitpos, lnbitsize, rnbitpos, rnbitsize;
  tree type = ((lhs)->common.type);
  tree signed_type, unsigned_type;
  int const_p = ((n64_enum_tree_code) (rhs)->common.code) == INTEGER_CST;
  n64_enum_machine_mode lmode, rmode, lnmode, rnmode;
  int lunsignedp, runsignedp;
  int lvolatilep = 0, rvolatilep = 0;
  tree linner, rinner;
  tree mask;
  tree offset;




  linner = get_inner_reference (lhs, &lbitsize, &lbitpos, &offset, &lmode,
    &lunsignedp, &lvolatilep);
  if (linner == lhs || lbitsize == (8 * mode_size[(int)(lmode)]) || lbitsize < 0
      || offset != 0)
    return 0;

 if (!const_p)
   {


     rinner = get_inner_reference (rhs, &rbitsize, &rbitpos, &offset,
       &rmode, &runsignedp, &rvolatilep);

     if (rinner == rhs || lbitpos != rbitpos || lbitsize != rbitsize
  || lunsignedp != runsignedp || offset != 0)
       return 0;
   }



  lnmode = get_best_mode (lbitsize, lbitpos,
     ((((linner)->common.type))->type.align), word_mode,
     lvolatilep);
  if (lnmode == VOIDmode)
    return 0;



  signed_type = type_for_mode (lnmode, 0);
  unsigned_type = type_for_mode (lnmode, 1);

  if (! const_p)
    {
      rnmode = get_best_mode (rbitsize, rbitpos,
         ((((rinner)->common.type))->type.align), word_mode,
         rvolatilep);
      if (rnmode == VOIDmode)
 return 0;
    }




  lnbitsize = (8 * mode_size[(int)(lnmode)]);
  lnbitpos = lbitpos & ~ (lnbitsize - 1);
  lbitpos -= lnbitpos;
  if (lnbitsize == lbitsize)
    return 0;

  if (! const_p)
    {
      rnbitsize = (8 * mode_size[(int)(rnmode)]);
      rnbitpos = rbitpos & ~ (rnbitsize - 1);
      rbitpos -= rnbitpos;
      if (rnbitsize == rbitsize)
 return 0;
    }

  if (((target_flags & 0x00010000) != 0))
    lbitpos = lnbitsize - lbitsize - lbitpos;


  mask = build_int_2_wide ((int) (~0), (int) (~0));
  ((mask)->common.type) = unsigned_type;
  force_fit_type (mask, 0);
  mask = convert (unsigned_type, mask);
  mask = const_binop (LSHIFT_EXPR, mask, size_int (lnbitsize - lbitsize), 0);
  mask = const_binop (RSHIFT_EXPR, mask,
        size_int (lnbitsize - lbitsize - lbitpos), 0);

  if (! const_p)


    return build (code, compare_type,
    build (BIT_AND_EXPR, unsigned_type,
    make_bit_field_ref (linner, unsigned_type,
          lnbitsize, lnbitpos, 1),
    mask),
    build (BIT_AND_EXPR, unsigned_type,
    make_bit_field_ref (rinner, unsigned_type,
          rnbitsize, rnbitpos, 1),
    mask));
  if (lunsignedp)
    {
      if (! integer_zerop (const_binop (RSHIFT_EXPR,
     convert (unsigned_type, rhs),
     size_int (lbitsize), 0)))
 {
   warning ("comparison is always %s due to width of bitfield",
     code == NE_EXPR ? "one" : "zero");
   return convert (compare_type,
     (code == NE_EXPR
      ? integer_one_node : integer_zero_node));
 }
    }
  else
    {
      tree tem = const_binop (RSHIFT_EXPR, convert (signed_type, rhs),
         size_int (lbitsize - 1), 0);
      if (! integer_zerop (tem) && ! integer_all_onesp (tem))
 {
   warning ("comparison is always %s due to width of bitfield",
     code == NE_EXPR ? "one" : "zero");
   return convert (compare_type,
     (code == NE_EXPR
      ? integer_one_node : integer_zero_node));
 }
    }


  if (lbitsize == 1 && ! integer_zerop (rhs))
    {
      code = code == EQ_EXPR ? NE_EXPR : EQ_EXPR;
      rhs = convert (type, integer_zero_node);
    }




  lhs = make_bit_field_ref (linner, unsigned_type, lnbitsize, lnbitpos, 1);
  if (lvolatilep)
    {
      ((lhs)->common.side_effects_flag) = 1;
      ((lhs)->common.volatile_flag) = 1;
    }

  rhs = fold (const_binop (BIT_AND_EXPR,
      const_binop (LSHIFT_EXPR,
     convert (unsigned_type, rhs),
     size_int (lbitpos), 0),
      mask, 0));

  return build (code, compare_type,
  build (BIT_AND_EXPR, unsigned_type, lhs, mask),
  rhs);
}
static tree
decode_field_reference(tree exp, int *pbitsize, int *pbitpos, n64_enum_machine_mode *pmode, int *punsignedp, int *pvolatilep, tree *pmask, tree *pand_mask) asm("_decode_field_reference");
static tree
decode_field_reference(tree exp, int *pbitsize, int *pbitpos, n64_enum_machine_mode *pmode, int *punsignedp, int *pvolatilep, tree *pmask, tree *pand_mask)
{
  tree and_mask = 0;
  tree mask, inner, offset;
  tree unsigned_type;
  int precision;




  if (! (((n64_enum_tree_code) (((exp)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == CHAR_TYPE))
    return 0;

  while ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR) && (((((exp)->common.type))->type.mode) == ((((((exp)->exp.operands[0]))->common.type))->type.mode))) (exp) = ((exp)->exp.operands[0]);;

  if (((n64_enum_tree_code) (exp)->common.code) == BIT_AND_EXPR)
    {
      and_mask = ((exp)->exp.operands[1]);
      exp = ((exp)->exp.operands[0]);
      while ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR) && (((((exp)->common.type))->type.mode) == ((((((exp)->exp.operands[0]))->common.type))->type.mode))) (exp) = ((exp)->exp.operands[0]);; while ((((n64_enum_tree_code) (and_mask)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (and_mask)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (and_mask)->common.code) == NON_LVALUE_EXPR) && (((((and_mask)->common.type))->type.mode) == ((((((and_mask)->exp.operands[0]))->common.type))->type.mode))) (and_mask) = ((and_mask)->exp.operands[0]);;
      if (((n64_enum_tree_code) (and_mask)->common.code) != INTEGER_CST)
 return 0;
    }


  inner = get_inner_reference (exp, pbitsize, pbitpos, &offset, pmode,
          punsignedp, pvolatilep);
  if ((inner == exp && and_mask == 0)
      || *pbitsize < 0 || offset != 0)
    return 0;


  unsigned_type = type_for_size (*pbitsize, 1);
  precision = ((unsigned_type)->type.precision);

  mask = build_int_2_wide ((int) (~0), (int) (~0));
  ((mask)->common.type) = unsigned_type;
  force_fit_type (mask, 0);
  mask = const_binop (LSHIFT_EXPR, mask, size_int (precision - *pbitsize), 0);
  mask = const_binop (RSHIFT_EXPR, mask, size_int (precision - *pbitsize), 0);


  if (and_mask != 0)
    mask = fold (build (BIT_AND_EXPR, unsigned_type,
   convert (unsigned_type, and_mask), mask));

  *pmask = mask;
  *pand_mask = and_mask;
  return inner;
}




static int
all_ones_mask_p(tree mask, int size) asm("_all_ones_mask_p");
static int
all_ones_mask_p(tree mask, int size)
{
  tree type = ((mask)->common.type);
  int precision = ((type)->type.precision);
  tree tmask;

  tmask = build_int_2_wide ((int) (~0), (int) (~0));
  ((tmask)->common.type) = signed_type (type);
  force_fit_type (tmask, 0);
  return
    tree_int_cst_equal (mask,
   const_binop (RSHIFT_EXPR,
         const_binop (LSHIFT_EXPR, tmask,
        size_int (precision - size),
        0),
         size_int (precision - size), 0));
}




static int
simple_operand_p(tree exp) asm("_simple_operand_p");
static int
simple_operand_p(tree exp)
{

  while ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
   || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR)
  && (((((exp)->common.type))->type.mode)
      == ((((((exp)->exp.operands[0]))->common.type))->type.mode)))
    exp = ((exp)->exp.operands[0]);

  return ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'c'
   || ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd'
       && ! ((exp)->common.addressable_flag)
       && ! ((exp)->common.volatile_flag)
       && ! ((exp)->decl.nonlocal_flag)



       && ! ((exp)->common.public_flag)
       && ! ((exp)->decl.external_flag)


       && (! ((exp)->common.static_flag) || ((exp)->decl.regdecl_flag))));
}
static tree
range_test(n64_enum_tree_code jcode, tree type, n64_enum_tree_code lo_code, n64_enum_tree_code hi_code, tree var, tree lo_cst, tree hi_cst) asm("_range_test");
static tree
range_test(n64_enum_tree_code jcode, tree type, n64_enum_tree_code lo_code, n64_enum_tree_code hi_code, tree var, tree lo_cst, tree hi_cst)
{
  tree utype;
  n64_enum_tree_code rcode;



  if (jcode == TRUTH_AND_EXPR)
    {
      switch (lo_code)
 {
 case NE_EXPR:

   if (! (hi_code == NE_EXPR
   && ((hi_cst)->int_cst.int_cst_low) - ((lo_cst)->int_cst.int_cst_low) == 1
   && tree_int_cst_equal (integer_one_node,
     const_binop (MINUS_EXPR,
           hi_cst, lo_cst, 0))))
     return 0;

   rcode = GT_EXPR;
   break;

 case GT_EXPR:
 case GE_EXPR:
   if (hi_code == LT_EXPR)
     hi_cst = const_binop (MINUS_EXPR, hi_cst, integer_one_node, 0);
   else if (hi_code != LE_EXPR)
     return 0;

   if (lo_code == GT_EXPR)
     lo_cst = const_binop (PLUS_EXPR, lo_cst, integer_one_node, 0);


   rcode = LE_EXPR;
   break;

 default:
   return 0;
 }
    }
  else
    {
      switch (lo_code)
 {
 case EQ_EXPR:

   if (! (hi_code == EQ_EXPR
   && ((hi_cst)->int_cst.int_cst_low) - ((lo_cst)->int_cst.int_cst_low) == 1
   && tree_int_cst_equal (integer_one_node,
     const_binop (MINUS_EXPR,
           hi_cst, lo_cst, 0))))
     return 0;

   rcode = LE_EXPR;
   break;

 case LE_EXPR:
 case LT_EXPR:
   if (hi_code == GE_EXPR)
     hi_cst = const_binop (MINUS_EXPR, hi_cst, integer_one_node, 0);
   else if (hi_code != GT_EXPR)
     return 0;

   if (lo_code == LE_EXPR)
     lo_cst = const_binop (PLUS_EXPR, lo_cst, integer_one_node, 0);


   rcode = GT_EXPR;
   break;

 default:
   return 0;
 }
    }



  if (tree_int_cst_lt (hi_cst, lo_cst))
    return 0;


  utype = ((var)->common.type);
  if (! (((n64_enum_tree_code) (utype)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (utype)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (utype)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (utype)->common.code) == CHAR_TYPE))
    return 0;



  if (! int_fits_type_p (hi_cst, ((var)->common.type))
      || ! int_fits_type_p (lo_cst, ((var)->common.type)))
    return 0;

  if (! ((utype)->common.unsigned_flag))
    {
      utype = unsigned_type (utype);
      var = convert (utype, var);
      lo_cst = convert (utype, lo_cst);
      hi_cst = convert (utype, hi_cst);
    }

  return fold (convert (type,
   build (rcode, utype,
          build (MINUS_EXPR, utype, var, lo_cst),
          const_binop (MINUS_EXPR, hi_cst, lo_cst, 0))));
}






static tree
unextend(tree c, int p, int unsignedp, tree mask) asm("_unextend");
static tree
unextend(tree c, int p, int unsignedp, tree mask)
{
  tree type = ((c)->common.type);
  int modesize = (8 * mode_size[(int)(((type)->type.mode))]);
  tree temp;

  if (p == modesize || unsignedp)
    return c;

  if (((type)->common.unsigned_flag))
    c = convert (signed_type (type), c);




  temp = const_binop (RSHIFT_EXPR, c, size_int (p - 1), 0);
  temp = const_binop (BIT_AND_EXPR, temp, size_int (1), 0);
  temp = const_binop (LSHIFT_EXPR, temp, size_int (modesize - 1), 0);
  temp = const_binop (RSHIFT_EXPR, temp, size_int (modesize - p - 1), 0);
  if (mask != 0)
    temp = const_binop (BIT_AND_EXPR, temp, convert (((c)->common.type), mask), 0);

  return convert (type, const_binop (BIT_XOR_EXPR, c, temp, 0));
}
static tree
fold_truthop(n64_enum_tree_code code, tree truth_type, tree lhs, tree rhs) asm("_fold_truthop");
static tree
fold_truthop(n64_enum_tree_code code, tree truth_type, tree lhs, tree rhs)
{
  n64_enum_tree_code wanted_code;
  n64_enum_tree_code lcode, rcode;
  tree ll_arg, lr_arg, rl_arg, rr_arg;
  tree ll_inner, lr_inner, rl_inner, rr_inner;
  int ll_bitsize, ll_bitpos, lr_bitsize, lr_bitpos;
  int rl_bitsize, rl_bitpos, rr_bitsize, rr_bitpos;
  int xll_bitpos, xlr_bitpos, xrl_bitpos, xrr_bitpos;
  int lnbitsize, lnbitpos, rnbitsize, rnbitpos;
  int ll_unsignedp, lr_unsignedp, rl_unsignedp, rr_unsignedp;
  n64_enum_machine_mode ll_mode, lr_mode, rl_mode, rr_mode;
  n64_enum_machine_mode lnmode, rnmode;
  tree ll_mask, lr_mask, rl_mask, rr_mask;
  tree ll_and_mask, lr_and_mask, rl_and_mask, rr_and_mask;
  tree l_const, r_const;
  tree type, result;
  int first_bit, end_bit;
  int volatilep;






  if (((lhs)->common.side_effects_flag)
      || ((rhs)->common.side_effects_flag))
    return 0;

  lcode = ((n64_enum_tree_code) (lhs)->common.code);
  rcode = ((n64_enum_tree_code) (rhs)->common.code);

  if (lcode == BIT_AND_EXPR && integer_onep (((lhs)->exp.operands[1])))
    lcode = NE_EXPR, lhs = build (NE_EXPR, truth_type, lhs, integer_zero_node);

  if (rcode == BIT_AND_EXPR && integer_onep (((rhs)->exp.operands[1])))
    rcode = NE_EXPR, rhs = build (NE_EXPR, truth_type, rhs, integer_zero_node);

  if ((*tree_code_type[(int) (lcode)]) != '<'
      || (*tree_code_type[(int) (rcode)]) != '<')
    return 0;

  code = ((code == TRUTH_AND_EXPR || code == TRUTH_ANDIF_EXPR)
   ? TRUTH_AND_EXPR : TRUTH_OR_EXPR);

  ll_arg = ((lhs)->exp.operands[0]);
  lr_arg = ((lhs)->exp.operands[1]);
  rl_arg = ((rhs)->exp.operands[0]);
  rr_arg = ((rhs)->exp.operands[1]);

  if (((n64_enum_tree_code) (lr_arg)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (rr_arg)->common.code) == INTEGER_CST
      && operand_equal_p (ll_arg, rl_arg, 0))
    {
      if (tree_int_cst_lt (lr_arg, rr_arg))
 result = range_test (code, truth_type, lcode, rcode,
        ll_arg, lr_arg, rr_arg);
      else
 result = range_test (code, truth_type, rcode, lcode,
        ll_arg, rr_arg, lr_arg);





      if (result == 0 && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2)
 {
   if (((n64_enum_tree_code) (ll_arg)->common.code) != VAR_DECL
       && ((n64_enum_tree_code) (ll_arg)->common.code) != PARM_DECL)
     {

       ll_arg = save_expr (ll_arg);
       lhs = build (lcode, ((lhs)->common.type), ll_arg, lr_arg);
       rhs = build (rcode, ((rhs)->common.type), ll_arg, rr_arg);
     }
   return build (code, truth_type, lhs, rhs);
 }
      return result;
    }
  if (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2
      && (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == CHAR_TYPE)
      && simple_operand_p (rl_arg)
      && simple_operand_p (rr_arg))
    return build (code, truth_type, lhs, rhs);




  if ((lcode != EQ_EXPR && lcode != NE_EXPR)
      || (rcode != EQ_EXPR && rcode != NE_EXPR))
    return 0;

  volatilep = 0;
  ll_inner = decode_field_reference (ll_arg,
         &ll_bitsize, &ll_bitpos, &ll_mode,
         &ll_unsignedp, &volatilep, &ll_mask,
         &ll_and_mask);
  lr_inner = decode_field_reference (lr_arg,
         &lr_bitsize, &lr_bitpos, &lr_mode,
         &lr_unsignedp, &volatilep, &lr_mask,
         &lr_and_mask);
  rl_inner = decode_field_reference (rl_arg,
         &rl_bitsize, &rl_bitpos, &rl_mode,
         &rl_unsignedp, &volatilep, &rl_mask,
         &rl_and_mask);
  rr_inner = decode_field_reference (rr_arg,
         &rr_bitsize, &rr_bitpos, &rr_mode,
         &rr_unsignedp, &volatilep, &rr_mask,
         &rr_and_mask);





  if (volatilep || ll_inner == 0 || rl_inner == 0
      || ! operand_equal_p (ll_inner, rl_inner, 0))
    return 0;

  if (((n64_enum_tree_code) (lr_arg)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (rr_arg)->common.code) == INTEGER_CST)
    l_const = lr_arg, r_const = rr_arg;
  else if (lr_inner == 0 || rr_inner == 0
    || ! operand_equal_p (lr_inner, rr_inner, 0))
    return 0;
  else
    l_const = r_const = 0;





  wanted_code = (code == TRUTH_AND_EXPR ? EQ_EXPR : NE_EXPR);
  if (lcode != wanted_code)
    {
      if (l_const && integer_zerop (l_const) && integer_pow2p (ll_mask))
 l_const = ll_mask;
      else
 return 0;
    }

  if (rcode != wanted_code)
    {
      if (r_const && integer_zerop (r_const) && integer_pow2p (rl_mask))
 r_const = rl_mask;
      else
 return 0;
    }




  first_bit = ((ll_bitpos) < (rl_bitpos) ? (ll_bitpos) : (rl_bitpos));
  end_bit = ((ll_bitpos + ll_bitsize) > (rl_bitpos + rl_bitsize) ? (ll_bitpos + ll_bitsize) : (rl_bitpos + rl_bitsize));
  lnmode = get_best_mode (end_bit - first_bit, first_bit,
     ((((ll_inner)->common.type))->type.align), word_mode,
     volatilep);
  if (lnmode == VOIDmode)
    return 0;

  lnbitsize = (8 * mode_size[(int)(lnmode)]);
  lnbitpos = first_bit & ~ (lnbitsize - 1);
  type = type_for_size (lnbitsize, 1);
  xll_bitpos = ll_bitpos - lnbitpos, xrl_bitpos = rl_bitpos - lnbitpos;

  if (((target_flags & 0x00010000) != 0))
    {
      xll_bitpos = lnbitsize - xll_bitpos - ll_bitsize;
      xrl_bitpos = lnbitsize - xrl_bitpos - rl_bitsize;
    }

  ll_mask = const_binop (LSHIFT_EXPR, convert (type, ll_mask),
    size_int (xll_bitpos), 0);
  rl_mask = const_binop (LSHIFT_EXPR, convert (type, rl_mask),
    size_int (xrl_bitpos), 0);

  if (l_const)
    {
      l_const = convert (type, l_const);
      l_const = unextend (l_const, ll_bitsize, ll_unsignedp, ll_and_mask);
      l_const = const_binop (LSHIFT_EXPR, l_const, size_int (xll_bitpos), 0);
      if (! integer_zerop (const_binop (BIT_AND_EXPR, l_const,
     fold (build1 (BIT_NOT_EXPR,
            type, ll_mask)),
     0)))
 {
   warning ("comparison is always %s",
     wanted_code == NE_EXPR ? "one" : "zero");

   return convert (truth_type,
     wanted_code == NE_EXPR
     ? integer_one_node : integer_zero_node);
 }
    }
  if (r_const)
    {
      r_const = convert (type, r_const);
      r_const = unextend (r_const, rl_bitsize, rl_unsignedp, rl_and_mask);
      r_const = const_binop (LSHIFT_EXPR, r_const, size_int (xrl_bitpos), 0);
      if (! integer_zerop (const_binop (BIT_AND_EXPR, r_const,
     fold (build1 (BIT_NOT_EXPR,
            type, rl_mask)),
     0)))
 {
   warning ("comparison is always %s",
     wanted_code == NE_EXPR ? "one" : "zero");

   return convert (truth_type,
     wanted_code == NE_EXPR
     ? integer_one_node : integer_zero_node);
 }
    }




  if (l_const == 0)
    {
      if (ll_bitsize != lr_bitsize || rl_bitsize != rr_bitsize
   || ll_unsignedp != lr_unsignedp || rl_unsignedp != rr_unsignedp


   || ll_bitpos - rl_bitpos != lr_bitpos - rr_bitpos)
 return 0;

      first_bit = ((lr_bitpos) < (rr_bitpos) ? (lr_bitpos) : (rr_bitpos));
      end_bit = ((lr_bitpos + lr_bitsize) > (rr_bitpos + rr_bitsize) ? (lr_bitpos + lr_bitsize) : (rr_bitpos + rr_bitsize));
      rnmode = get_best_mode (end_bit - first_bit, first_bit,
         ((((lr_inner)->common.type))->type.align), word_mode,
         volatilep);
      if (rnmode == VOIDmode)
 return 0;

      rnbitsize = (8 * mode_size[(int)(rnmode)]);
      rnbitpos = first_bit & ~ (rnbitsize - 1);
      xlr_bitpos = lr_bitpos - rnbitpos, xrr_bitpos = rr_bitpos - rnbitpos;

      if (((target_flags & 0x00010000) != 0))
 {
   xlr_bitpos = rnbitsize - xlr_bitpos - lr_bitsize;
   xrr_bitpos = rnbitsize - xrr_bitpos - rr_bitsize;
 }

      lr_mask = const_binop (LSHIFT_EXPR, convert (type, lr_mask),
        size_int (xlr_bitpos), 0);
      rr_mask = const_binop (LSHIFT_EXPR, convert (type, rr_mask),
        size_int (xrr_bitpos), 0);





      ll_mask = const_binop (BIT_IOR_EXPR, ll_mask, rl_mask, 0);
      lr_mask = const_binop (BIT_IOR_EXPR, lr_mask, rr_mask, 0);
      if (operand_equal_p (ll_mask, lr_mask, 0) && lnbitsize == rnbitsize)
 {
   lhs = make_bit_field_ref (ll_inner, type, lnbitsize, lnbitpos,
        ll_unsignedp || rl_unsignedp);
   rhs = make_bit_field_ref (lr_inner, type, rnbitsize, rnbitpos,
        lr_unsignedp || rr_unsignedp);
   if (! all_ones_mask_p (ll_mask, lnbitsize))
     {
       lhs = build (BIT_AND_EXPR, type, lhs, ll_mask);
       rhs = build (BIT_AND_EXPR, type, rhs, ll_mask);
     }
   return build (wanted_code, truth_type, lhs, rhs);
 }




      if ((ll_bitsize + ll_bitpos == rl_bitpos
    && lr_bitsize + lr_bitpos == rr_bitpos)
   || (ll_bitpos == rl_bitpos + rl_bitsize
       && lr_bitpos == rr_bitpos + rr_bitsize))
 return build (wanted_code, truth_type,
        make_bit_field_ref (ll_inner, type,
       ll_bitsize + rl_bitsize,
       ((ll_bitpos) < (rl_bitpos) ? (ll_bitpos) : (rl_bitpos)),
       ll_unsignedp),
        make_bit_field_ref (lr_inner, type,
       lr_bitsize + rr_bitsize,
       ((lr_bitpos) < (rr_bitpos) ? (lr_bitpos) : (rr_bitpos)),
       lr_unsignedp));

      return 0;
    }





  result = const_binop (BIT_AND_EXPR, ll_mask, rl_mask, 0);
  if (! integer_zerop (result)
      && simple_cst_equal (const_binop (BIT_AND_EXPR, result, l_const, 0),
      const_binop (BIT_AND_EXPR, result, r_const, 0)) != 1)
    {
      if (wanted_code == NE_EXPR)
 {
   warning ("`or' of unmatched not-equal tests is always 1");
   return convert (truth_type, integer_one_node);
 }
      else
 {
   warning ("`and' of mutually exclusive equal-tests is always zero");
   return convert (truth_type, integer_zero_node);
 }
    }





  result = make_bit_field_ref (ll_inner, type, lnbitsize, lnbitpos,
          ll_unsignedp || rl_unsignedp);

  ll_mask = const_binop (BIT_IOR_EXPR, ll_mask, rl_mask, 0);
  if (! all_ones_mask_p (ll_mask, lnbitsize))
    result = build (BIT_AND_EXPR, type, result, ll_mask);

  return build (wanted_code, truth_type, result,
  const_binop (BIT_IOR_EXPR, l_const, r_const, 0));
}





static tree
strip_compound_expr(tree t, tree s) asm("_strip_compound_expr");
static tree
strip_compound_expr(tree t, tree s)
{
  tree type = ((t)->common.type);
  n64_enum_tree_code code = ((n64_enum_tree_code) (t)->common.code);


  if (code == COMPOUND_EXPR && ((n64_enum_tree_code) (((t)->exp.operands[0]))->common.code) == CONVERT_EXPR
      && ((((t)->exp.operands[0]))->exp.operands[0]) == s)
    return ((t)->exp.operands[1]);



  else if (code == COND_EXPR)
    {
      ((t)->exp.operands[0]) = strip_compound_expr (((t)->exp.operands[0]), s);
      ((t)->exp.operands[1]) = strip_compound_expr (((t)->exp.operands[1]), s);
      ((t)->exp.operands[2]) = strip_compound_expr (((t)->exp.operands[2]), s);
    }
  else if ((*tree_code_type[(int) (code)]) == '1')
    ((t)->exp.operands[0]) = strip_compound_expr (((t)->exp.operands[0]), s);
  else if ((*tree_code_type[(int) (code)]) == '<'
    || (*tree_code_type[(int) (code)]) == '2')
    {
      ((t)->exp.operands[0]) = strip_compound_expr (((t)->exp.operands[0]), s);
      ((t)->exp.operands[1]) = strip_compound_expr (((t)->exp.operands[1]), s);
    }

  return t;
}
tree
fold(tree expr) asm("_fold");
tree
fold(tree expr)
{
  register tree t = expr;
  tree t1 = (tree) 
           ((void *)0)
                    ;
  tree tem;
  tree type = ((expr)->common.type);
  register tree arg0, arg1;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (t)->common.code);
  register int kind;
  int invert;




  int wins = 1;


  if (code == RTL_EXPR)
    return t;


  if (((t)->common.constant_flag))
    {
      if (code == CONST_DECL)
 return ((t)->decl.initial);
      return t;
    }

  kind = (*tree_code_type[(int) (code)]);
  if (code == NOP_EXPR || code == FLOAT_EXPR || code == CONVERT_EXPR)
    {
      tree subop;


      arg0 = ((t)->exp.operands[0]);


      if (arg0 != 0)
 while ((((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == NON_LVALUE_EXPR) && (((arg0)->common.type) == ((((arg0)->exp.operands[0]))->common.type))) (arg0) = ((arg0)->exp.operands[0]);;

      if (arg0 != 0 && ((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_CST)
 subop = ((arg0)->complex.real);
      else
 subop = arg0;

      if (subop != 0 && ((n64_enum_tree_code) (subop)->common.code) != INTEGER_CST

   && ((n64_enum_tree_code) (subop)->common.code) != REAL_CST

   )



 wins = 0;
    }
  else if (kind == 'e' || kind == '<'
    || kind == '1' || kind == '2' || kind == 'r')
    {
      register int len = tree_code_length[(int) code];
      register int i;
      for (i = 0; i < len; i++)
 {
   tree op = ((t)->exp.operands[i]);
   tree subop;

   if (op == 0)
     continue;

   if (kind == '<' || code == RSHIFT_EXPR)
     {


       while ((((n64_enum_tree_code) (op)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op)->common.code) == NON_LVALUE_EXPR) && (((op)->common.type) == ((((op)->exp.operands[0]))->common.type))) (op) = ((op)->exp.operands[0]);;
     }
   else
     {

       while ((((n64_enum_tree_code) (op)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op)->common.code) == NON_LVALUE_EXPR) && (((((op)->common.type))->type.mode) == ((((((op)->exp.operands[0]))->common.type))->type.mode))) (op) = ((op)->exp.operands[0]);;
     }

   if (((n64_enum_tree_code) (op)->common.code) == COMPLEX_CST)
     subop = ((op)->complex.real);
   else
     subop = op;

   if (((n64_enum_tree_code) (subop)->common.code) != INTEGER_CST

       && ((n64_enum_tree_code) (subop)->common.code) != REAL_CST

       )



     wins = 0;

   if (i == 0)
     arg0 = op;
   else if (i == 1)
     arg1 = op;
 }
    }



  if ((code == PLUS_EXPR || code == MULT_EXPR || code == MIN_EXPR
       || code == MAX_EXPR || code == BIT_IOR_EXPR || code == BIT_XOR_EXPR
       || code == BIT_AND_EXPR)
      && (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST || ((n64_enum_tree_code) (arg0)->common.code) == REAL_CST))
    {
      tem = arg0; arg0 = arg1; arg1 = tem;

      tem = ((t)->exp.operands[0]); ((t)->exp.operands[0]) = ((t)->exp.operands[1]);
      ((t)->exp.operands[1]) = tem;
    }
  if ((code == BIT_AND_EXPR || code == BIT_IOR_EXPR
       || code == EQ_EXPR || code == NE_EXPR)
      && ((truth_value_p (((n64_enum_tree_code) (arg0)->common.code))
    && (truth_value_p (((n64_enum_tree_code) (arg1)->common.code))
        || (((n64_enum_tree_code) (arg1)->common.code) == BIT_AND_EXPR
     && integer_onep (((arg1)->exp.operands[1])))))
   || (truth_value_p (((n64_enum_tree_code) (arg1)->common.code))
       && (truth_value_p (((n64_enum_tree_code) (arg0)->common.code))
    || (((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR
        && integer_onep (((arg0)->exp.operands[1])))))))
    {
      t = fold (build (code == BIT_AND_EXPR ? TRUTH_AND_EXPR
         : code == BIT_IOR_EXPR ? TRUTH_OR_EXPR
         : TRUTH_XOR_EXPR,
         type, arg0, arg1));

      if (code == EQ_EXPR)
 t = invert_truthvalue (t);

      return t;
    }

  if ((*tree_code_type[(int) (code)]) == '1')
    {
      if (((n64_enum_tree_code) (arg0)->common.code) == COMPOUND_EXPR)
 return build (COMPOUND_EXPR, type, ((arg0)->exp.operands[0]),
        fold (build1 (code, type, ((arg0)->exp.operands[1]))));
      else if (((n64_enum_tree_code) (arg0)->common.code) == COND_EXPR)
 {
   t = fold (build (COND_EXPR, type, ((arg0)->exp.operands[0]),
      fold (build1 (code, type, ((arg0)->exp.operands[1]))),
      fold (build1 (code, type, ((arg0)->exp.operands[2])))));
   if ((code == NOP_EXPR || code == CONVERT_EXPR
        || code == NON_LVALUE_EXPR)
       && ((n64_enum_tree_code) (t)->common.code) == COND_EXPR
       && ((n64_enum_tree_code) (((t)->exp.operands[1]))->common.code) == code
       && ((n64_enum_tree_code) (((t)->exp.operands[2]))->common.code) == code
       && (((((((t)->exp.operands[1]))->exp.operands[0]))->common.type)
    == ((((((t)->exp.operands[2]))->exp.operands[0]))->common.type))
       && ! ((((n64_enum_tree_code) (((t)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((t)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((t)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((t)->common.type))->common.code) == CHAR_TYPE)
      && (((n64_enum_tree_code) (((((((t)->exp.operands[1]))->exp.operands[0]))->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((((((t)->exp.operands[1]))->exp.operands[0]))->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((((((t)->exp.operands[1]))->exp.operands[0]))->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((((((t)->exp.operands[1]))->exp.operands[0]))->common.type))->common.code) == CHAR_TYPE)
      && ((((t)->common.type))->type.precision) <= ((target_flags & 0x00002000) ? 64 : 32)))
     t = build1 (code, type,
   build (COND_EXPR,
          ((((((t)->exp.operands[1]))->exp.operands[0]))->common.type),
          ((t)->exp.operands[0]),
          ((((t)->exp.operands[1]))->exp.operands[0]),
          ((((t)->exp.operands[2]))->exp.operands[0])));
   return t;
 }
      else if ((*tree_code_type[(int) (((n64_enum_tree_code) (arg0)->common.code))]) == '<')
 return fold (build (COND_EXPR, type, arg0,
       fold (build1 (code, type, integer_one_node)),
       fold (build1 (code, type, integer_zero_node))));
   }
  else if ((*tree_code_type[(int) (code)]) == '2'
    || (*tree_code_type[(int) (code)]) == '<')
    {
      if (((n64_enum_tree_code) (arg1)->common.code) == COMPOUND_EXPR)
 return build (COMPOUND_EXPR, type, ((arg1)->exp.operands[0]),
        fold (build (code, type,
       arg0, ((arg1)->exp.operands[1]))));
      else if (((n64_enum_tree_code) (arg1)->common.code) == COND_EXPR
        || (*tree_code_type[(int) (((n64_enum_tree_code) (arg1)->common.code))]) == '<')
 {
   tree test, true_value, false_value;

   if (((n64_enum_tree_code) (arg1)->common.code) == COND_EXPR)
     {
       test = ((arg1)->exp.operands[0]);
       true_value = ((arg1)->exp.operands[1]);
       false_value = ((arg1)->exp.operands[2]);
     }
   else
     {
       tree testtype = ((arg1)->common.type);
       test = arg1;
       true_value = convert (testtype, integer_one_node);
       false_value = convert (testtype, integer_zero_node);
     }
   if (((n64_enum_tree_code) (arg0)->common.code) != SAVE_EXPR
       && ((((n64_enum_tree_code) (arg0)->common.code) != VAR_DECL
     && ((n64_enum_tree_code) (arg0)->common.code) != PARM_DECL)
    || ((arg0)->common.side_effects_flag)))
     {
       tree lhs = fold (build (code, type, arg0, true_value));
       tree rhs = fold (build (code, type, arg0, false_value));

       if (((lhs)->common.constant_flag) || ((rhs)->common.constant_flag))
  return fold (build (COND_EXPR, type, test, lhs, rhs));

       arg0 = save_expr (arg0);
     }

   test = fold (build (COND_EXPR, type, test,
         fold (build (code, type, arg0, true_value)),
         fold (build (code, type, arg0, false_value))));
   if (((n64_enum_tree_code) (arg0)->common.code) == SAVE_EXPR)
     return build (COMPOUND_EXPR, type,
     convert (void_type_node, arg0),
     strip_compound_expr (test, arg0));
   else
     return convert (type, test);
 }

      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPOUND_EXPR)
 return build (COMPOUND_EXPR, type, ((arg0)->exp.operands[0]),
        fold (build (code, type, ((arg0)->exp.operands[1]), arg1)));
      else if (((n64_enum_tree_code) (arg0)->common.code) == COND_EXPR
        || (*tree_code_type[(int) (((n64_enum_tree_code) (arg0)->common.code))]) == '<')
 {
   tree test, true_value, false_value;

   if (((n64_enum_tree_code) (arg0)->common.code) == COND_EXPR)
     {
       test = ((arg0)->exp.operands[0]);
       true_value = ((arg0)->exp.operands[1]);
       false_value = ((arg0)->exp.operands[2]);
     }
   else
     {
       tree testtype = ((arg0)->common.type);
       test = arg0;
       true_value = convert (testtype, integer_one_node);
       false_value = convert (testtype, integer_zero_node);
     }

   if (((n64_enum_tree_code) (arg1)->common.code) != SAVE_EXPR
       && ((((n64_enum_tree_code) (arg1)->common.code) != VAR_DECL
     && ((n64_enum_tree_code) (arg1)->common.code) != PARM_DECL)
    || ((arg1)->common.side_effects_flag)))
     {
       tree lhs = fold (build (code, type, true_value, arg1));
       tree rhs = fold (build (code, type, false_value, arg1));

       if (((lhs)->common.constant_flag) || ((rhs)->common.constant_flag)
    || ((arg1)->common.constant_flag))
  return fold (build (COND_EXPR, type, test, lhs, rhs));

       arg1 = save_expr (arg1);
     }

   test = fold (build (COND_EXPR, type, test,
         fold (build (code, type, true_value, arg1)),
         fold (build (code, type, false_value, arg1))));
   if (((n64_enum_tree_code) (arg1)->common.code) == SAVE_EXPR)
     return build (COMPOUND_EXPR, type,
     convert (void_type_node, arg1),
     strip_compound_expr (test, arg1));
   else
     return convert (type, test);
 }
    }
  else if ((*tree_code_type[(int) (code)]) == '<'
    && ((n64_enum_tree_code) (arg0)->common.code) == COMPOUND_EXPR)
    return build (COMPOUND_EXPR, type, ((arg0)->exp.operands[0]),
    fold (build (code, type, ((arg0)->exp.operands[1]), arg1)));
  else if ((*tree_code_type[(int) (code)]) == '<'
    && ((n64_enum_tree_code) (arg1)->common.code) == COMPOUND_EXPR)
    return build (COMPOUND_EXPR, type, ((arg1)->exp.operands[0]),
    fold (build (code, type, arg0, ((arg1)->exp.operands[1]))));

  switch (code)
    {
    case INTEGER_CST:
    case REAL_CST:
    case STRING_CST:
    case COMPLEX_CST:
    case CONSTRUCTOR:
      return t;

    case CONST_DECL:
      return fold (((t)->decl.initial));

    case NOP_EXPR:
    case FLOAT_EXPR:
    case CONVERT_EXPR:
    case FIX_TRUNC_EXPR:


      if (((((t)->exp.operands[0]))->common.type) == ((t)->common.type))
 return ((t)->exp.operands[0]);


      if (((n64_enum_tree_code) (((t)->exp.operands[0]))->common.code) == NOP_EXPR
   || ((n64_enum_tree_code) (((t)->exp.operands[0]))->common.code) == CONVERT_EXPR)
 {
   tree inside_type = ((((((t)->exp.operands[0]))->exp.operands[0]))->common.type);
   tree inter_type = ((((t)->exp.operands[0]))->common.type);
   tree final_type = ((t)->common.type);
   int inside_int = (((n64_enum_tree_code) (inside_type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (inside_type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (inside_type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (inside_type)->common.code) == CHAR_TYPE);
   int inside_ptr = (((n64_enum_tree_code) (inside_type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (inside_type)->common.code) == REFERENCE_TYPE);
   int inside_float = (((n64_enum_tree_code) (inside_type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (inside_type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((inside_type)->common.type))->common.code) == REAL_TYPE));
   int inside_prec = ((inside_type)->type.precision);
   int inside_unsignedp = ((inside_type)->common.unsigned_flag);
   int inter_int = (((n64_enum_tree_code) (inter_type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (inter_type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (inter_type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (inter_type)->common.code) == CHAR_TYPE);
   int inter_ptr = (((n64_enum_tree_code) (inter_type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (inter_type)->common.code) == REFERENCE_TYPE);
   int inter_float = (((n64_enum_tree_code) (inter_type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (inter_type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((inter_type)->common.type))->common.code) == REAL_TYPE));
   int inter_prec = ((inter_type)->type.precision);
   int inter_unsignedp = ((inter_type)->common.unsigned_flag);
   int final_int = (((n64_enum_tree_code) (final_type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (final_type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (final_type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (final_type)->common.code) == CHAR_TYPE);
   int final_ptr = (((n64_enum_tree_code) (final_type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (final_type)->common.code) == REFERENCE_TYPE);
   int final_float = (((n64_enum_tree_code) (final_type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (final_type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((final_type)->common.type))->common.code) == REAL_TYPE));
   int final_prec = ((final_type)->type.precision);
   int final_unsignedp = ((final_type)->common.unsigned_flag);





   if (inside_type == final_type
       && ((inter_int && final_int) || (inter_float && final_float))
       && inter_prec >= final_prec)
     return ((((t)->exp.operands[0]))->exp.operands[0]);







   if ((((inter_int || inter_ptr) && (inside_int || inside_ptr))
        || (inter_float && inside_float))
       && inter_prec >= inside_prec
       && (inter_float || inter_unsignedp == inside_unsignedp)
       && ! (final_prec != (8 * mode_size[(int)(((final_type)->type.mode))])
      && ((final_type)->type.mode) == ((inter_type)->type.mode))
       && ! final_ptr)
     return convert (final_type, ((((t)->exp.operands[0]))->exp.operands[0]));
   if (! inside_float && ! inter_float && ! final_float
       && (inter_prec > inside_prec || inter_prec > final_prec)
       && ! (inside_int && inter_int
      && inter_unsignedp != inside_unsignedp
      && inter_prec < final_prec)
       && ((inter_unsignedp && inter_prec > inside_prec)
    == (final_unsignedp && final_prec > inter_prec))
       && ! (inside_ptr && inter_prec != final_prec)
       && ! (final_ptr && inside_prec != inter_prec)
       && ! (final_prec != (8 * mode_size[(int)(((final_type)->type.mode))])
      && ((final_type)->type.mode) == ((inter_type)->type.mode))
       && ! final_ptr)
     return convert (final_type, ((((t)->exp.operands[0]))->exp.operands[0]));
 }

      if (((n64_enum_tree_code) (((t)->exp.operands[0]))->common.code) == MODIFY_EXPR
   && ((((((t)->exp.operands[0]))->exp.operands[1]))->common.constant_flag)

   && !(((n64_enum_tree_code) (((((t)->exp.operands[0]))->exp.operands[0]))->common.code) == COMPONENT_REF
        && ((((((((t)->exp.operands[0]))->exp.operands[0]))->exp.operands[1]))->decl.bit_field_flag)))
 {


   tree prev = ((t)->exp.operands[0]);
   ((t)->exp.operands[0]) = ((prev)->exp.operands[1]);

   t = build (COMPOUND_EXPR, ((t)->common.type), prev, fold (t));
   ((t)->common.used_flag) = 1;
   return t;
 }
      if (!wins)
 {
   ((t)->common.constant_flag) = ((arg0)->common.constant_flag);
   return t;
 }
      return fold_convert (t, arg0);
    case COMPONENT_REF:
      if (((n64_enum_tree_code) (arg0)->common.code) == CONSTRUCTOR)
 {
   tree m = purpose_member (arg1, ((arg0)->exp.operands[1]));
   if (m)
     t = ((m)->list.value);
 }
      return t;

    case RANGE_EXPR:
      ((t)->common.constant_flag) = wins;
      return t;

    case NEGATE_EXPR:
      if (wins)
 {
   if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST)
     {
       int low, high;
       int overflow = neg_double (((arg0)->int_cst.int_cst_low),
      ((arg0)->int_cst.int_cst_high),
      &low, &high);
       t = build_int_2_wide ((int) (low), (int) (high));
       ((t)->common.type) = type;
       ((t)->common.public_flag)
  = (((arg0)->common.public_flag)
     | force_fit_type (t, overflow));
       ((t)->common.static_flag)
  = ((t)->common.public_flag) | ((arg0)->common.static_flag);
     }
   else if (((n64_enum_tree_code) (arg0)->common.code) == REAL_CST)
     t = build_real (type, ereal_negate (((arg0)->real_cst.real_cst)));
   ((t)->common.type) = type;
 }
      else if (((n64_enum_tree_code) (arg0)->common.code) == NEGATE_EXPR)
 return ((arg0)->exp.operands[0]);


      else if (((n64_enum_tree_code) (arg0)->common.code) == MINUS_EXPR && ! (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE)))
 return build (MINUS_EXPR, type, ((arg0)->exp.operands[1]),
        ((arg0)->exp.operands[0]));

      return t;

    case ABS_EXPR:
      if (wins)
 {
   if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST)
     {
       if (! ((type)->common.unsigned_flag)
    && ((arg0)->int_cst.int_cst_high) < 0)
  {
    int low, high;
    int overflow = neg_double (((arg0)->int_cst.int_cst_low),
          ((arg0)->int_cst.int_cst_high),
          &low, &high);
    t = build_int_2_wide ((int) (low), (int) (high));
    ((t)->common.type) = type;
    ((t)->common.public_flag)
      = (((arg0)->common.public_flag)
         | force_fit_type (t, overflow));
    ((t)->common.static_flag)
      = ((t)->common.public_flag) | ((arg0)->common.static_flag);
  }
     }
   else if (((n64_enum_tree_code) (arg0)->common.code) == REAL_CST)
     {
       if ((target_negative (((arg0)->real_cst.real_cst))))
  t = build_real (type,
    ereal_negate (((arg0)->real_cst.real_cst)));
     }
   ((t)->common.type) = type;
 }
      else if (((n64_enum_tree_code) (arg0)->common.code) == ABS_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == NEGATE_EXPR)
 return build1 (ABS_EXPR, type, ((arg0)->exp.operands[0]));
      return t;

    case CONJ_EXPR:
      if (((n64_enum_tree_code) (((arg0)->common.type))->common.code) != COMPLEX_TYPE)
 return arg0;
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_EXPR)
 return build (COMPLEX_EXPR, ((arg0)->common.type),
        ((arg0)->exp.operands[0]),
        fold (build1 (NEGATE_EXPR,
        ((((arg0)->common.type))->common.type),
        ((arg0)->exp.operands[1]))));
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_CST)
 return build_complex (((arg0)->exp.operands[0]),
         fold (build1 (NEGATE_EXPR,
         ((((arg0)->common.type))->common.type),
         ((arg0)->exp.operands[1]))));
      else if (((n64_enum_tree_code) (arg0)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == MINUS_EXPR)
 return fold (build (((n64_enum_tree_code) (arg0)->common.code), type,
       fold (build1 (CONJ_EXPR, type,
       ((arg0)->exp.operands[0]))),
       fold (build1 (CONJ_EXPR,
       type, ((arg0)->exp.operands[1])))));
      else if (((n64_enum_tree_code) (arg0)->common.code) == CONJ_EXPR)
 return ((arg0)->exp.operands[0]);
      return t;

    case BIT_NOT_EXPR:
      if (wins)
 {
   if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST)
     t = build_int_2_wide ((int) (~ ((arg0)->int_cst.int_cst_low)), (int) (~ ((arg0)->int_cst.int_cst_high)))
                                   ;
   ((t)->common.type) = type;
   force_fit_type (t, 0);
   ((t)->common.public_flag) = ((arg0)->common.public_flag);
   ((t)->common.static_flag) = ((arg0)->common.static_flag);
 }
      else if (((n64_enum_tree_code) (arg0)->common.code) == BIT_NOT_EXPR)
 return ((arg0)->exp.operands[0]);
      return t;

    case PLUS_EXPR:

      if (((n64_enum_tree_code) (arg1)->common.code) == NEGATE_EXPR)
 return fold (build (MINUS_EXPR, type, arg0, ((arg1)->exp.operands[0])));
      else if (! (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE)))
 {
   if (integer_zerop (arg1))
     return non_lvalue (convert (type, arg0));





   if (((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR
       && ((n64_enum_tree_code) (arg1)->common.code) == BIT_AND_EXPR
       && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST
       && ((n64_enum_tree_code) (((arg1)->exp.operands[1]))->common.code) == INTEGER_CST
       && integer_zerop (const_binop (BIT_AND_EXPR,
          ((arg0)->exp.operands[1]),
          ((arg1)->exp.operands[1]), 0)))
     {
       code = BIT_IOR_EXPR;
       goto bit_ior;
     }





   if (((n64_enum_tree_code) (arg0)->common.code) == MULT_EXPR && ((n64_enum_tree_code) (arg1)->common.code) == MULT_EXPR
       && operand_equal_p (((arg0)->exp.operands[1]),
      ((arg1)->exp.operands[1]), 0))
     return fold (build (MULT_EXPR, type,
    fold (build (PLUS_EXPR, type,
          ((arg0)->exp.operands[0]),
          ((arg1)->exp.operands[0]))),
    ((arg0)->exp.operands[1])));
 }

      else if ((1 != 1
  || flag_fast_math)
        && real_zerop (arg1))
 return non_lvalue (convert (type, arg0));
    associate:





      if ((((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE))
   && ! (flag_fast_math && code == MULT_EXPR))
 goto binary;




      if (!wins)
 {
   tree var, con;
   int varsign;

   if (split_tree (arg0, code, &var, &con, &varsign))
     {
       if (varsign == -1)
  {


    if (code == PLUS_EXPR && operand_equal_p (var, arg1, 0))
      return convert (((t)->common.type), con);




    if (((arg0)->common.constant_flag))
      return t;


    t = build (MINUS_EXPR, type,
        fold (build (code, type, con, arg1)), var);
  }
       else
  {


    if (code == MINUS_EXPR && operand_equal_p (var, arg1, 0))
      return convert (((t)->common.type), con);




    if (((arg0)->common.constant_flag))
      return t;


    tem = fold (build (code, type, arg1, con));
    t = build (code, type, var, tem);

    if (integer_zerop (tem)
        && (code == PLUS_EXPR || code == MINUS_EXPR))
      return convert (type, var);




    if (((n64_enum_tree_code) (tem)->common.code) == MINUS_EXPR
        && ((n64_enum_tree_code) (((tem)->exp.operands[0]))->common.code) == INTEGER_CST)
      {
        tree tem1 = ((tem)->exp.operands[1]);
        ((tem)->exp.operands[1]) = ((tem)->exp.operands[0]);
        ((tem)->exp.operands[0]) = tem1;
        ((t)->common.code = (int) ((code == PLUS_EXPR ? MINUS_EXPR : PLUS_EXPR)))
                                                      ;
      }
  }
       return t;
     }

   if (split_tree (arg1, code, &var, &con, &varsign))
     {
       if (((arg1)->common.constant_flag))
  return t;

       if (varsign == -1)
  ((t)->common.code = (int) ((code == PLUS_EXPR ? MINUS_EXPR : PLUS_EXPR)))
                                                       ;


       if (((n64_enum_tree_code) (t)->common.code) == MINUS_EXPR
    && operand_equal_p (var, arg0, 0))
  {

    if (code == PLUS_EXPR)
      return convert (((t)->common.type), con);
    return fold (build1 (NEGATE_EXPR, ((t)->common.type),
           convert (((t)->common.type), con)));
  }

       t = build (((n64_enum_tree_code) (t)->common.code), type,
    fold (build (code, ((t)->common.type), arg0, con)), var);

       if (integer_zerop (((t)->exp.operands[0]))
    && ((n64_enum_tree_code) (t)->common.code) == PLUS_EXPR)
  return convert (((t)->common.type), var);
       return t;
     }
 }
    binary:




      if (wins)
 t1 = const_binop (code, arg0, arg1, 0);
      if (t1 != (tree) 
               ((void *)0)
                        )
 {


   ((t1)->common.type) = ((t)->common.type);
   return t1;
 }
      return t;

    case MINUS_EXPR:
      if (! (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE)))
 {
   if (! wins && integer_zerop (arg0))
     return build1 (NEGATE_EXPR, type, arg1);
   if (integer_zerop (arg1))
     return non_lvalue (convert (type, arg0));





   if (((n64_enum_tree_code) (arg0)->common.code) == MULT_EXPR && ((n64_enum_tree_code) (arg1)->common.code) == MULT_EXPR
       && operand_equal_p (((arg0)->exp.operands[1]),
      ((arg1)->exp.operands[1]), 0))
     return fold (build (MULT_EXPR, type,
    fold (build (MINUS_EXPR, type,
          ((arg0)->exp.operands[0]),
          ((arg1)->exp.operands[0]))),
    ((arg0)->exp.operands[1])));
 }

      else if (((n64_enum_tree_code) (arg1)->common.code) == NEGATE_EXPR)
 return fold (build (PLUS_EXPR, type, arg0, ((arg1)->exp.operands[0])));

      else if (1 != 1
        || flag_fast_math)
 {

   if (! wins && real_zerop (arg0))
     return build1 (NEGATE_EXPR, type, arg1);

   if (real_zerop (arg1))
     return non_lvalue (convert (type, arg0));
 }







      if ((! (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE)) || flag_fast_math)
   && operand_equal_p (arg0, arg1, 0))
 return convert (type, integer_zero_node);

      goto associate;

    case MULT_EXPR:
      if (! (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((type)->common.type))->common.code) == REAL_TYPE)))
 {
   if (integer_zerop (arg1))
     return omit_one_operand (type, arg1, arg0);
   if (integer_onep (arg1))
     return non_lvalue (convert (type, arg0));





   if (((n64_enum_tree_code) (arg0)->common.code) == EXACT_DIV_EXPR
       && operand_equal_p (((arg0)->exp.operands[1]), arg1, 0))
     return ((arg0)->exp.operands[0]);


   if (((n64_enum_tree_code) (arg1)->common.code) == LSHIFT_EXPR
       && integer_onep (((arg1)->exp.operands[0])))
     return fold (build (LSHIFT_EXPR, type, arg0,
    ((arg1)->exp.operands[1])));
   if (((n64_enum_tree_code) (arg0)->common.code) == LSHIFT_EXPR
       && integer_onep (((arg0)->exp.operands[0])))
     return fold (build (LSHIFT_EXPR, type, arg1,
    ((arg0)->exp.operands[1])));
 }
      else
 {

   if ((1 != 1
        || flag_fast_math)
       && real_zerop (arg1))
     return omit_one_operand (type, arg1, arg0);



   if (real_onep (arg1))
     return non_lvalue (convert (type, arg0));

   if (! wins && real_twop (arg1))
     {
       tree arg = save_expr (arg0);
       return build (PLUS_EXPR, type, arg, arg);
     }
 }
      goto associate;

    case BIT_IOR_EXPR:
    bit_ior:
      if (integer_all_onesp (arg1))
 return omit_one_operand (type, arg1, arg0);
      if (integer_zerop (arg1))
 return non_lvalue (convert (type, arg0));
      t1 = distribute_bit_expr (code, type, arg0, arg1);
      if (t1 != (tree) 
               ((void *)0)
                        )
 return t1;




      if ((((n64_enum_tree_code) (arg0)->common.code) == RSHIFT_EXPR
    || ((n64_enum_tree_code) (arg0)->common.code) == LSHIFT_EXPR)
   && (((n64_enum_tree_code) (arg1)->common.code) == RSHIFT_EXPR
       || ((n64_enum_tree_code) (arg1)->common.code) == LSHIFT_EXPR)
   && ((n64_enum_tree_code) (arg0)->common.code) != ((n64_enum_tree_code) (arg1)->common.code)
   && operand_equal_p (((arg0)->exp.operands[0]), ((arg1)->exp.operands[0]), 0)
   && ((((((arg0)->exp.operands[0]))->common.type))->common.unsigned_flag)
   && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (((arg1)->exp.operands[1]))->common.code) == INTEGER_CST
   && ((((arg0)->exp.operands[1]))->int_cst.int_cst_high) == 0
   && ((((arg1)->exp.operands[1]))->int_cst.int_cst_high) == 0
   && ((((((arg0)->exp.operands[1]))->int_cst.int_cst_low)
        + ((((arg1)->exp.operands[1]))->int_cst.int_cst_low))
       == ((((((arg0)->exp.operands[0]))->common.type))->type.precision)))
 return build (LROTATE_EXPR, type, ((arg0)->exp.operands[0]),
        ((n64_enum_tree_code) (arg0)->common.code) == LSHIFT_EXPR
        ? ((arg0)->exp.operands[1]) : ((arg1)->exp.operands[1]));

      goto associate;

    case BIT_XOR_EXPR:
      if (integer_zerop (arg1))
 return non_lvalue (convert (type, arg0));
      if (integer_all_onesp (arg1))
 return fold (build1 (BIT_NOT_EXPR, type, arg0));
      goto associate;

    case BIT_AND_EXPR:
    bit_and:
      if (integer_all_onesp (arg1))
 return non_lvalue (convert (type, arg0));
      if (integer_zerop (arg1))
 return omit_one_operand (type, arg1, arg0);
      t1 = distribute_bit_expr (code, type, arg0, arg1);
      if (t1 != (tree) 
               ((void *)0)
                        )
 return t1;

      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && ((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR
   && ((((((arg1)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   int prec = ((((((arg1)->exp.operands[0]))->common.type))->type.precision);
   if (prec < ((target_flags & 0x00002000) ? 64 : 32) && prec < 32
       && (~((arg0)->int_cst.int_cst_low)
    & (((int) 1 << prec) - 1)) == 0)
     return build1 (NOP_EXPR, type, ((arg1)->exp.operands[0]));
 }
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && ((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR
   && ((((((arg0)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   int prec = ((((((arg0)->exp.operands[0]))->common.type))->type.precision);
   if (prec < ((target_flags & 0x00002000) ? 64 : 32) && prec < 32
       && (~((arg1)->int_cst.int_cst_low)
    & (((int) 1 << prec) - 1)) == 0)
     return build1 (NOP_EXPR, type, ((arg0)->exp.operands[0]));
 }
      goto associate;

    case BIT_ANDTC_EXPR:
      if (integer_all_onesp (arg0))
 return non_lvalue (convert (type, arg1));
      if (integer_zerop (arg0))
 return omit_one_operand (type, arg0, arg1);
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
 {
   arg1 = fold (build1 (BIT_NOT_EXPR, type, arg1));
   code = BIT_AND_EXPR;
   goto bit_and;
 }
      goto binary;

    case RDIV_EXPR:
      if (real_onep (arg1))
 return non_lvalue (convert (type, arg0));






      if (((n64_enum_tree_code) (arg1)->common.code) == REAL_CST && flag_fast_math
   && 0 != (tem = const_binop (code, build_real (type, dconst1),
          arg1, 0)))
 return fold (build (MULT_EXPR, type, arg0, tem));

      goto binary;

    case TRUNC_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case EXACT_DIV_EXPR:
      if (integer_onep (arg1))
 return non_lvalue (convert (type, arg0));
      if (integer_zerop (arg1))
 return t;



      if (((n64_enum_tree_code) (arg0)->common.code) == code && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST)
 {
   tree new_divisor;

   new_divisor = const_binop (MULT_EXPR, ((arg0)->exp.operands[1]), arg1, 0);
   tem = const_binop (FLOOR_DIV_EXPR, new_divisor, arg1, 0);

   if (((((arg0)->exp.operands[1]))->int_cst.int_cst_low) == ((tem)->int_cst.int_cst_low)
       && ((((arg0)->exp.operands[1]))->int_cst.int_cst_high) == ((tem)->int_cst.int_cst_high))
     {

       return fold (build (code, type, ((arg0)->exp.operands[0]), new_divisor));
     }
 }
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && tree_int_cst_sgn (arg1) >= 0)
 {
   int have_save_expr = 0;
   tree c2 = integer_zero_node;
   tree xarg0 = arg0;

   if (((n64_enum_tree_code) (xarg0)->common.code) == SAVE_EXPR)
     have_save_expr = 1, xarg0 = ((xarg0)->exp.operands[0]);

   while ((((n64_enum_tree_code) (xarg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == NON_LVALUE_EXPR) && (((((xarg0)->common.type))->type.mode) == ((((((xarg0)->exp.operands[0]))->common.type))->type.mode))) (xarg0) = ((xarg0)->exp.operands[0]);;

   if (((n64_enum_tree_code) (xarg0)->common.code) == PLUS_EXPR
       && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST)
     c2 = ((xarg0)->exp.operands[1]), xarg0 = ((xarg0)->exp.operands[0]);
   else if (((n64_enum_tree_code) (xarg0)->common.code) == MINUS_EXPR
     && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST


     && ! ((type)->common.unsigned_flag))
     {
       c2 = fold (build1 (NEGATE_EXPR, type, ((xarg0)->exp.operands[1])));
       xarg0 = ((xarg0)->exp.operands[0]);
     }

   if (((n64_enum_tree_code) (xarg0)->common.code) == SAVE_EXPR)
     have_save_expr = 1, xarg0 = ((xarg0)->exp.operands[0]);

   while ((((n64_enum_tree_code) (xarg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == NON_LVALUE_EXPR) && (((((xarg0)->common.type))->type.mode) == ((((((xarg0)->exp.operands[0]))->common.type))->type.mode))) (xarg0) = ((xarg0)->exp.operands[0]);;

   if (((n64_enum_tree_code) (xarg0)->common.code) == MULT_EXPR
       && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST
       && tree_int_cst_sgn (((xarg0)->exp.operands[1])) >= 0
       && (integer_zerop (const_binop (TRUNC_MOD_EXPR,
           ((xarg0)->exp.operands[1]), arg1, 1))
    || integer_zerop (const_binop (TRUNC_MOD_EXPR, arg1,
       ((xarg0)->exp.operands[1]), 1)))
       && (tree_int_cst_sgn (c2) >= 0
    || integer_zerop (const_binop (TRUNC_MOD_EXPR, c2,
       arg1, 1))))
     {
       tree outer_div = integer_one_node;
       tree c1 = ((xarg0)->exp.operands[1]);
       tree c3 = arg1;



       if (tree_int_cst_lt (c1, c3))
  outer_div = const_binop (code, c3, c1, 0), c3 = c1;


       t = fold (build (PLUS_EXPR, type,
          fold (build (MULT_EXPR, type,
         ((xarg0)->exp.operands[0]),
         const_binop (code, c1, c3, 1))),
          const_binop (code, c2, c3, 1)));

       if (! integer_onep (outer_div))
  t = fold (build (code, type, t, convert (type, outer_div)));

       if (have_save_expr)
  t = save_expr (t);

       return t;
     }
 }

      goto binary;

    case CEIL_MOD_EXPR:
    case FLOOR_MOD_EXPR:
    case ROUND_MOD_EXPR:
    case TRUNC_MOD_EXPR:
      if (integer_onep (arg1))
 return omit_one_operand (type, integer_zero_node, arg0);
      if (integer_zerop (arg1))
 return t;





      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && ! integer_zerop (arg1))
 {
   tree c2 = integer_zero_node;
   tree xarg0 = arg0;

   if (((n64_enum_tree_code) (xarg0)->common.code) == PLUS_EXPR
       && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST)
     c2 = ((xarg0)->exp.operands[1]), xarg0 = ((xarg0)->exp.operands[0]);
   else if (((n64_enum_tree_code) (xarg0)->common.code) == MINUS_EXPR
     && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST
     && ! ((type)->common.unsigned_flag))
     {
       c2 = fold (build1 (NEGATE_EXPR, type, ((xarg0)->exp.operands[1])));
       xarg0 = ((xarg0)->exp.operands[0]);
     }

   while ((((n64_enum_tree_code) (xarg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (xarg0)->common.code) == NON_LVALUE_EXPR) && (((((xarg0)->common.type))->type.mode) == ((((((xarg0)->exp.operands[0]))->common.type))->type.mode))) (xarg0) = ((xarg0)->exp.operands[0]);;

   if (((n64_enum_tree_code) (xarg0)->common.code) == MULT_EXPR
       && ((n64_enum_tree_code) (((xarg0)->exp.operands[1]))->common.code) == INTEGER_CST
       && integer_zerop (const_binop (TRUNC_MOD_EXPR,
          ((xarg0)->exp.operands[1]),
          arg1, 1))
       && tree_int_cst_sgn (c2) >= 0)

     return omit_one_operand (type, const_binop (code, c2, arg1, 1),
         ((xarg0)->exp.operands[0]));
 }

      goto binary;

    case LSHIFT_EXPR:
    case RSHIFT_EXPR:
    case LROTATE_EXPR:
    case RROTATE_EXPR:
      if (integer_zerop (arg1))
 return non_lvalue (convert (type, arg0));


      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && tree_int_cst_sgn (arg1) < 0)
 return t;


      if (code == LROTATE_EXPR && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
 {
   ((t)->common.code = (int) (RROTATE_EXPR));
   code = RROTATE_EXPR;
   ((t)->exp.operands[1]) = arg1
     = const_binop
       (MINUS_EXPR,
        convert (((arg1)->common.type),
   build_int_2_wide ((int) ((8 * mode_size[(int)(((type)->type.mode))])), (int) (0))),
        arg1, 0);
   if (tree_int_cst_sgn (arg1) < 0)
     return t;
 }




      if (code == RROTATE_EXPR && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && (((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == BIT_ANDTC_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == BIT_IOR_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == BIT_XOR_EXPR)
   && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST)
 return fold (build (((n64_enum_tree_code) (arg0)->common.code), type,
       fold (build (code, type,
      ((arg0)->exp.operands[0]), arg1)),
       fold (build (code, type,
      ((arg0)->exp.operands[1]), arg1))));



      if (code == RROTATE_EXPR && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (arg0)->common.code) == RROTATE_EXPR
   && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST
   && ((arg1)->int_cst.int_cst_high) == 0
   && ((((arg0)->exp.operands[1]))->int_cst.int_cst_high) == 0
   && ((((arg1)->int_cst.int_cst_low)
        + ((((arg0)->exp.operands[1]))->int_cst.int_cst_low))
       == (8 * mode_size[(int)(((type)->type.mode))])))
 return ((arg0)->exp.operands[0]);

      goto binary;

    case MIN_EXPR:
      if (operand_equal_p (arg0, arg1, 0))
 return arg0;
      if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE)
   && operand_equal_p (arg1, ((type)->type.minval), 1))
 return omit_one_operand (type, arg1, arg0);
      goto associate;

    case MAX_EXPR:
      if (operand_equal_p (arg0, arg1, 0))
 return arg0;
      if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE)
   && operand_equal_p (arg1, ((type)->type.maxval), 1))
 return omit_one_operand (type, arg1, arg0);
      goto associate;

    case TRUTH_NOT_EXPR:




      tem = invert_truthvalue (arg0);

      if (((n64_enum_tree_code) (tem)->common.code) == TRUTH_NOT_EXPR)
 return t;
      return convert (type, tem);

    case TRUTH_ANDIF_EXPR:




      if (integer_zerop (arg0))
 return arg0;
    case TRUTH_AND_EXPR:

      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && ! integer_zerop (arg0))
 return non_lvalue (arg1);
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && ! integer_zerop (arg1))
 return non_lvalue (arg0);


      if (integer_zerop (arg1))
 return omit_one_operand (type, arg1, arg0);

    truth_andor:

      if (!optimize)
 return t;






      if (((n64_enum_tree_code) (arg0)->common.code) == ((n64_enum_tree_code) (arg1)->common.code)
   && (((n64_enum_tree_code) (arg0)->common.code) == TRUTH_ANDIF_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == TRUTH_ORIF_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == TRUTH_AND_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == TRUTH_OR_EXPR))
 {
   tree a00 = ((arg0)->exp.operands[0]);
   tree a01 = ((arg0)->exp.operands[1]);
   tree a10 = ((arg1)->exp.operands[0]);
   tree a11 = ((arg1)->exp.operands[1]);
   int commutative = ((((n64_enum_tree_code) (arg0)->common.code) == TRUTH_OR_EXPR
         || ((n64_enum_tree_code) (arg0)->common.code) == TRUTH_AND_EXPR)
        && (code == TRUTH_AND_EXPR
     || code == TRUTH_OR_EXPR));

   if (operand_equal_p (a00, a10, 0))
     return fold (build (((n64_enum_tree_code) (arg0)->common.code), type, a00,
    fold (build (code, type, a01, a11))));
   else if (commutative && operand_equal_p (a00, a11, 0))
     return fold (build (((n64_enum_tree_code) (arg0)->common.code), type, a00,
    fold (build (code, type, a01, a10))));
   else if (commutative && operand_equal_p (a01, a10, 0))
     return fold (build (((n64_enum_tree_code) (arg0)->common.code), type, a01,
    fold (build (code, type, a00, a11))));




   else if ((commutative || ! ((a10)->common.side_effects_flag))
     && operand_equal_p (a01, a11, 0))
     return fold (build (((n64_enum_tree_code) (arg0)->common.code), type,
    fold (build (code, type, a00, a10)),
    a01));
 }




      if (((n64_enum_tree_code) (arg0)->common.code) == code
   && 0 != (tem = fold_truthop (code, type,
           ((arg0)->exp.operands[1]), arg1)))
 return fold (build (code, type, ((arg0)->exp.operands[0]), tem));

      if ((tem = fold_truthop (code, type, arg0, arg1)) != 0)
 return tem;

      return t;

    case TRUTH_ORIF_EXPR:




      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && ! integer_zerop (arg0))
 return arg0;
    case TRUTH_OR_EXPR:

      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && integer_zerop (arg0))
 return non_lvalue (arg1);
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && integer_zerop (arg1))
 return non_lvalue (arg0);


      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && ! integer_zerop (arg1))
 return omit_one_operand (type, arg1, arg0);
      goto truth_andor;

    case TRUTH_XOR_EXPR:

      if (integer_zerop (arg0))
 return non_lvalue (arg1);
      if (integer_zerop (arg1))
 return non_lvalue (arg0);

      if (integer_onep (arg0))
 return non_lvalue (invert_truthvalue (arg1));
      if (integer_onep (arg1))
 return non_lvalue (invert_truthvalue (arg0));
      return t;

    case EQ_EXPR:
    case NE_EXPR:
    case LT_EXPR:
    case GT_EXPR:
    case LE_EXPR:
    case GE_EXPR:

      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (arg1)->common.code) != INTEGER_CST)
 {
   ((t)->exp.operands[0]) = arg1;
   ((t)->exp.operands[1]) = arg0;
   arg0 = ((t)->exp.operands[0]);
   arg1 = ((t)->exp.operands[1]);
   code = swap_tree_comparison (code);
   ((t)->common.code = (int) (code));
 }




      {
 tree constop = 0, varop;
 int constopnum = -1;

 if (((arg1)->common.constant_flag))
   constopnum = 1, constop = arg1, varop = arg0;
 if (((arg0)->common.constant_flag))
   constopnum = 0, constop = arg0, varop = arg1;

 if (constop && ((n64_enum_tree_code) (varop)->common.code) == POSTINCREMENT_EXPR)
   {




     if (((n64_enum_tree_code) (((varop)->common.type))->common.code) == POINTER_TYPE
  || (! (((n64_enum_tree_code) (((varop)->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((varop)->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((varop)->common.type))->common.type))->common.code) == REAL_TYPE))
      && (code == EQ_EXPR || code == NE_EXPR)))
       {
  tree newconst
    = fold (build (PLUS_EXPR, ((varop)->common.type),
     constop, ((varop)->exp.operands[1])));
  ((varop)->common.code = (int) (PREINCREMENT_EXPR));

  t = build (code, type, ((t)->exp.operands[0]),
      ((t)->exp.operands[1]));
  ((t)->exp.operands[constopnum]) = newconst;
  return t;
       }
   }
 else if (constop && ((n64_enum_tree_code) (varop)->common.code) == POSTDECREMENT_EXPR)
   {
     if (((n64_enum_tree_code) (((varop)->common.type))->common.code) == POINTER_TYPE
  || (! (((n64_enum_tree_code) (((varop)->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((varop)->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((varop)->common.type))->common.type))->common.code) == REAL_TYPE))
      && (code == EQ_EXPR || code == NE_EXPR)))
       {
  tree newconst
    = fold (build (MINUS_EXPR, ((varop)->common.type),
     constop, ((varop)->exp.operands[1])));
  ((varop)->common.code = (int) (PREDECREMENT_EXPR));
  t = build (code, type, ((t)->exp.operands[0]),
      ((t)->exp.operands[1]));
  ((t)->exp.operands[constopnum]) = newconst;
  return t;
       }
   }
      }


      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (arg0)->common.code) != INTEGER_CST
   && tree_int_cst_sgn (arg1) > 0)
 {
   switch (((n64_enum_tree_code) (t)->common.code))
     {
     case GE_EXPR:
       code = GT_EXPR;
       arg1 = const_binop (MINUS_EXPR, arg1, integer_one_node, 0);
       t = build (code, type, ((t)->exp.operands[0]), arg1);
       break;

     case LT_EXPR:
       code = LE_EXPR;
       arg1 = const_binop (MINUS_EXPR, arg1, integer_one_node, 0);
       t = build (code, type, ((t)->exp.operands[0]), arg1);
       break;
     }
 }






      if (integer_zerop (arg1) && (code == EQ_EXPR || code == NE_EXPR)
   && ((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR)
 {
   if (((n64_enum_tree_code) (((arg0)->exp.operands[0]))->common.code) == LSHIFT_EXPR
       && integer_onep (((((arg0)->exp.operands[0]))->exp.operands[0])))
     return
       fold (build (code, type,
      build (BIT_AND_EXPR, ((arg0)->common.type),
      build (RSHIFT_EXPR,
      ((((arg0)->exp.operands[0]))->common.type),
      ((arg0)->exp.operands[1]),
      ((((arg0)->exp.operands[0]))->exp.operands[1])),
      convert (((arg0)->common.type),
        integer_one_node)),
      arg1));
   else if (((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == LSHIFT_EXPR
     && integer_onep (((((arg0)->exp.operands[1]))->exp.operands[0])))
     return
       fold (build (code, type,
      build (BIT_AND_EXPR, ((arg0)->common.type),
      build (RSHIFT_EXPR,
      ((((arg0)->exp.operands[1]))->common.type),
      ((arg0)->exp.operands[0]),
      ((((arg0)->exp.operands[1]))->exp.operands[1])),
      convert (((arg0)->common.type),
        integer_one_node)),
      arg1));
 }




      if ((code == NE_EXPR || code == EQ_EXPR)
   && integer_zerop (arg1)
   && ! ((((arg0)->common.type))->common.unsigned_flag)
   && (((n64_enum_tree_code) (arg0)->common.code) == TRUNC_MOD_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == CEIL_MOD_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == FLOOR_MOD_EXPR
       || ((n64_enum_tree_code) (arg0)->common.code) == ROUND_MOD_EXPR)
   && integer_pow2p (((arg0)->exp.operands[1])))
 {
   tree newtype = unsigned_type (((arg0)->common.type));
   tree newmod = build (((n64_enum_tree_code) (arg0)->common.code), newtype,
          convert (newtype, ((arg0)->exp.operands[0])),
          convert (newtype, ((arg0)->exp.operands[1])));

   return build (code, type, newmod, convert (newtype, arg1));
 }



      if (code == NE_EXPR && integer_zerop (arg1)
   && ((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR
   && integer_onep (((arg0)->exp.operands[1])))
 return convert (type, arg0);



      if ((code == EQ_EXPR || code == NE_EXPR)
   && ((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR
   && integer_pow2p (((arg0)->exp.operands[1]))
   && operand_equal_p (((arg0)->exp.operands[1]), arg1, 0))
 return build (code == EQ_EXPR ? NE_EXPR : EQ_EXPR, type,
        arg0, integer_zero_node);



      if ((code == LT_EXPR || code == GE_EXPR)
   && ((((arg0)->common.type))->common.unsigned_flag)
   && ((n64_enum_tree_code) (arg1)->common.code) == LSHIFT_EXPR
   && integer_onep (((arg1)->exp.operands[0])))
 return build (code == LT_EXPR ? EQ_EXPR : NE_EXPR, type,
        build (RSHIFT_EXPR, ((arg0)->common.type), arg0,
        ((arg1)->exp.operands[1])),
        convert (((arg0)->common.type), integer_zero_node));

      else if ((code == LT_EXPR || code == GE_EXPR)
        && ((((arg0)->common.type))->common.unsigned_flag)
        && (((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR)
        && ((n64_enum_tree_code) (((arg1)->exp.operands[0]))->common.code) == LSHIFT_EXPR
        && integer_onep (((((arg1)->exp.operands[0]))->exp.operands[0])))
 return
   build (code == LT_EXPR ? EQ_EXPR : NE_EXPR, type,
   convert (((arg0)->common.type),
     build (RSHIFT_EXPR, ((arg0)->common.type), arg0,
     ((((arg1)->exp.operands[0]))->exp.operands[1]))),
   convert (((arg0)->common.type), integer_zero_node));



      if (operand_equal_p (arg0, arg1, 0))
 {
   switch (code)
     {
     case EQ_EXPR:
     case GE_EXPR:
     case LE_EXPR:
       if ((((n64_enum_tree_code) (((arg0)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == CHAR_TYPE))
  {
    t = build_int_2_wide ((int) (1), (int) (0));
    ((t)->common.type) = type;
    return t;
  }
       code = EQ_EXPR;
       ((t)->common.code = (int) (code));
       break;

     case NE_EXPR:

       if (! (((n64_enum_tree_code) (((arg0)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == CHAR_TYPE))
  break;

     case GT_EXPR:
     case LT_EXPR:
       t = build_int_2_wide ((int) (0), (int) (0));
       ((t)->common.type) = type;
       return t;
     }
 }


      if (integer_zerop (arg1)
   && ((((n64_enum_tree_code) (((arg1)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == CHAR_TYPE)
       || ((n64_enum_tree_code) (((arg1)->common.type))->common.code) == POINTER_TYPE)
   && ((((arg1)->common.type))->common.unsigned_flag))
 {
   switch (((n64_enum_tree_code) (t)->common.code))
     {
     case GT_EXPR:
       code = NE_EXPR;
       ((t)->common.code = (int) (NE_EXPR));
       break;
     case LE_EXPR:
       code = EQ_EXPR;
       ((t)->common.code = (int) (EQ_EXPR));
       break;
     case GE_EXPR:
       return omit_one_operand (type,
           convert (type, integer_one_node),
           arg0);
     case LT_EXPR:
       return omit_one_operand (type,
           convert (type, integer_zero_node),
           arg0);
     }
 }
      if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST && ((n64_enum_tree_code) (arg0)->common.code) != INTEGER_CST)
 {
   tree cval1 = 0, cval2 = 0;
   int save_p = 0;

   if (twoval_comparison_p (arg0, &cval1, &cval2, &save_p)


       && cval1 != 0 && cval2 != 0
       && ! (((cval1)->common.constant_flag) && ((cval2)->common.constant_flag))
       && ((cval1)->common.type) == ((cval2)->common.type)
       && (((n64_enum_tree_code) (((cval1)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((cval1)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((cval1)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((cval1)->common.type))->common.code) == CHAR_TYPE)
       && ! operand_equal_p (((((cval1)->common.type))->type.minval),
        ((((cval2)->common.type))->type.maxval), 0))
     {
       tree maxval = ((((cval1)->common.type))->type.maxval);
       tree minval = ((((cval1)->common.type))->type.minval);




       tree high_result
  = fold (build (code, type,
          eval_subst (arg0, cval1, maxval, cval2, minval),
          arg1));
       tree equal_result
  = fold (build (code, type,
          eval_subst (arg0, cval1, maxval, cval2, maxval),
          arg1));
       tree low_result
  = fold (build (code, type,
          eval_subst (arg0, cval1, minval, cval2, maxval),
          arg1));





       if ((integer_zerop (high_result)
     || integer_onep (high_result))
    && (integer_zerop (equal_result)
        || integer_onep (equal_result))
    && (integer_zerop (low_result)
        || integer_onep (low_result)))
  {


    switch ((integer_onep (high_result) * 4)
     + (integer_onep (equal_result) * 2)
     + integer_onep (low_result))
      {
      case 0:

        return omit_one_operand (type, integer_zero_node, arg0);
      case 1:
        code = LT_EXPR;
        break;
      case 2:
        code = EQ_EXPR;
        break;
      case 3:
        code = LE_EXPR;
        break;
      case 4:
        code = GT_EXPR;
        break;
      case 5:
        code = NE_EXPR;
        break;
      case 6:
        code = GE_EXPR;
        break;
      case 7:

        return omit_one_operand (type, integer_one_node, arg0);
      }

    t = build (code, type, cval1, cval2);
    if (save_p)
      return save_expr (t);
    else
      return fold (t);
  }
     }
 }


      if ((((n64_enum_tree_code) (arg0)->common.code) == COMPONENT_REF
  || ((n64_enum_tree_code) (arg0)->common.code) == BIT_FIELD_REF)
        && (code == EQ_EXPR || code == NE_EXPR)


        && (optimize || ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST))
 {
   t1 = optimize_bit_field_compare (code, type, arg0, arg1);
   return t1 ? t1 : t;
 }





      if ((code == EQ_EXPR || code == NE_EXPR)
   && ((n64_enum_tree_code) (((arg0)->common.type))->common.code) == COMPLEX_TYPE
   && (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_EXPR
       || ((n64_enum_tree_code) (arg1)->common.code) == COMPLEX_EXPR))
 {
   tree subtype = ((((arg0)->common.type))->common.type);
   tree real0 = fold (build1 (REALPART_EXPR, subtype, arg0));
   tree imag0 = fold (build1 (IMAGPART_EXPR, subtype, arg0));
   tree real1 = fold (build1 (REALPART_EXPR, subtype, arg1));
   tree imag1 = fold (build1 (IMAGPART_EXPR, subtype, arg1));

   return fold (build ((code == EQ_EXPR ? TRUTH_ANDIF_EXPR
          : TRUTH_ORIF_EXPR),
         type,
         fold (build (code, type, real0, real1)),
         fold (build (code, type, imag0, imag1))));
 }
      if (code == LE_EXPR || code == GT_EXPR)
 {
   tem = arg0, arg0 = arg1, arg1 = tem;
   code = swap_tree_comparison (code);
 }




      invert = 0;
      if (code == NE_EXPR || code == GE_EXPR)
 {
   invert = 1;
   code = invert_tree_comparison (code);
 }



      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST && ((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST)
 {
   if (code == EQ_EXPR)
     t1 = build_int_2_wide ((int) ((((arg0)->int_cst.int_cst_low) == ((arg1)->int_cst.int_cst_low)) && (((arg0)->int_cst.int_cst_high) == ((arg1)->int_cst.int_cst_high))), (int) (0))



           ;
   else
     t1 = build_int_2_wide ((int) ((((((arg0)->common.type))->common.unsigned_flag) ? (((unsigned int) ((arg0)->int_cst.int_cst_high) < (unsigned int) ((arg1)->int_cst.int_cst_high)) || (((unsigned int) ((arg0)->int_cst.int_cst_high) == (unsigned int ) ((arg1)->int_cst.int_cst_high)) && (((unsigned int) ((arg0)->int_cst.int_cst_low) < (unsigned int) ((arg1)->int_cst.int_cst_low))))) : (((arg0)->int_cst.int_cst_high) < ((arg1)->int_cst.int_cst_high) || (((arg0)->int_cst.int_cst_high) == ((arg1)->int_cst.int_cst_high) && ((unsigned int) ((arg0)->int_cst.int_cst_low) < (unsigned int) ((arg1)->int_cst.int_cst_low)))))), (int) (0))


           ;
 }





      else if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
        && !integer_zerop (arg1)
        && ((arg0)->common.constant_flag)
        && ((n64_enum_tree_code) (arg0)->common.code) == ADDR_EXPR
        && code == EQ_EXPR)
 t1 = build_int_2_wide ((int) (0), (int) (0));


      else if (((n64_enum_tree_code) (arg0)->common.code) == REAL_CST && ((n64_enum_tree_code) (arg1)->common.code) == REAL_CST)
 {







   if ((target_isnan (((arg0)->real_cst.real_cst)))
       || (target_isnan (((arg1)->real_cst.real_cst))))
     t1 = build_int_2_wide ((int) (invert && code == LT_EXPR), (int) (0));

   else if (code == EQ_EXPR)
     t1 = build_int_2_wide ((int) ((ereal_cmp ((((arg0)->real_cst.real_cst)), (((arg1)->real_cst.real_cst))) == 0)), (int) (0))

           ;
   else
     t1 = build_int_2_wide ((int) ((ereal_cmp ((((arg0)->real_cst.real_cst)), (((arg1)->real_cst.real_cst))) == -1)), (int) (0))

           ;
 }

      if (t1 == (tree) 
               ((void *)0)
                        )
 return t;

      if (invert)
 ((t1)->int_cst.int_cst_low) ^= 1;

      ((t1)->common.type) = type;
      return t1;

    case COND_EXPR:


      if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST)
 return pedantic_non_lvalue
   (((t)->exp.operands[(integer_zerop (arg0) ? 2 : 1)]));
      else if (operand_equal_p (arg1, ((expr)->exp.operands[2]), 0))
 return pedantic_omit_one_operand (type, arg1, arg0);






      if (integer_zerop (arg1)
   || (((arg1)->common.constant_flag) && ! ((((t)->exp.operands[2]))->common.constant_flag))
   || ((*tree_code_type[(int) (((n64_enum_tree_code) (arg0)->common.code))]) == '<'
       && operand_equal_for_comparison_p (((arg0)->exp.operands[0]),
       ((t)->exp.operands[2]),
       ((arg0)->exp.operands[1]))))
 {



   tem = invert_truthvalue (arg0);

   if (((n64_enum_tree_code) (tem)->common.code) != TRUTH_NOT_EXPR)
     {
       t = build (code, type, tem,
    ((t)->exp.operands[2]), ((t)->exp.operands[1]));
       arg0 = tem;
       arg1 = ((t)->exp.operands[2]);
       while ((((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == NON_LVALUE_EXPR) && (((((arg1)->common.type))->type.mode) == ((((((arg1)->exp.operands[0]))->common.type))->type.mode))) (arg1) = ((arg1)->exp.operands[0]);;
     }
 }






      if ((*tree_code_type[(int) (((n64_enum_tree_code) (arg0)->common.code))]) == '<'
   && (1 != 1
       || ! (((n64_enum_tree_code) (((((arg0)->exp.operands[0]))->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((((arg0)->exp.operands[0]))->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((((arg0)->exp.operands[0]))->common.type))->common.type))->common.code) == REAL_TYPE))
       || flag_fast_math)
   && operand_equal_for_comparison_p (((arg0)->exp.operands[0]),
          arg1, ((arg0)->exp.operands[1])))
 {
   tree arg2 = ((t)->exp.operands[2]);
   n64_enum_tree_code comp_code = ((n64_enum_tree_code) (arg0)->common.code);

   while ((((n64_enum_tree_code) (arg2)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg2)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg2)->common.code) == NON_LVALUE_EXPR) && (((((arg2)->common.type))->type.mode) == ((((((arg2)->exp.operands[0]))->common.type))->type.mode))) (arg2) = ((arg2)->exp.operands[0]);;



   if (((((n64_enum_tree_code) (((((arg0)->exp.operands[1]))->common.type))->common.code) == REAL_TYPE || (((n64_enum_tree_code) (((((arg0)->exp.operands[1]))->common.type))->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((((((arg0)->exp.operands[1]))->common.type))->common.type))->common.code) == REAL_TYPE))
        ? real_zerop (((arg0)->exp.operands[1]))
        : integer_zerop (((arg0)->exp.operands[1])))
       && ((n64_enum_tree_code) (arg2)->common.code) == NEGATE_EXPR
       && operand_equal_p (((arg2)->exp.operands[0]), arg1, 0))
     switch (comp_code)
       {
       case EQ_EXPR:
  return pedantic_non_lvalue
    (fold (build1 (NEGATE_EXPR, type, arg1)));
       case NE_EXPR:
  return pedantic_non_lvalue (convert (type, arg1));
       case GE_EXPR:
       case GT_EXPR:
  return pedantic_non_lvalue
    (convert (type, fold (build1 (ABS_EXPR,
      ((arg1)->common.type), arg1))));
       case LE_EXPR:
       case LT_EXPR:
  return pedantic_non_lvalue
    (fold (build1 (NEGATE_EXPR, type,
     convert (type,
       fold (build1 (ABS_EXPR,
       ((arg1)->common.type),
       arg1))))));
       }




   if (integer_zerop (((arg0)->exp.operands[1])) && integer_zerop (arg2))
     {
       if (comp_code == NE_EXPR)
  return pedantic_non_lvalue (convert (type, arg1));
       else if (comp_code == EQ_EXPR)
  return pedantic_non_lvalue (convert (type, integer_zero_node));
     }




   if (operand_equal_for_comparison_p (((arg0)->exp.operands[1]),
           arg2, ((arg0)->exp.operands[0])))
     {
       tree comp_op0 = ((arg0)->exp.operands[0]);
       tree comp_op1 = ((arg0)->exp.operands[1]);
       tree comp_type = ((comp_op0)->common.type);

       switch (comp_code)
  {
  case EQ_EXPR:
    return pedantic_non_lvalue (convert (type, arg2));
  case NE_EXPR:
    return pedantic_non_lvalue (convert (type, arg1));
  case LE_EXPR:
  case LT_EXPR:
    return pedantic_non_lvalue
      (convert (type, (fold (build (MIN_EXPR, comp_type,
        comp_op0, comp_op1)))));
  case GE_EXPR:
  case GT_EXPR:
    return pedantic_non_lvalue
      (convert (type, fold (build (MAX_EXPR, comp_type,
       comp_op0, comp_op1))));
  }
     }







   if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE)
       && ((n64_enum_tree_code) (((arg0)->exp.operands[1]))->common.code) == INTEGER_CST
       && ((n64_enum_tree_code) (arg2)->common.code) == INTEGER_CST)
     switch (comp_code)
       {
       case EQ_EXPR:

  arg1 = convert (type, ((arg0)->exp.operands[1]));
  t = build (code, type, ((t)->exp.operands[0]), arg1,
      ((t)->exp.operands[2]));
  break;

       case LT_EXPR:

  if (! operand_equal_p (arg2, ((type)->type.maxval), 1)
      && operand_equal_p (((arg0)->exp.operands[1]),
     const_binop (PLUS_EXPR, arg2,
           integer_one_node, 0), 1))
    return pedantic_non_lvalue
      (fold (build (MIN_EXPR, type, arg1, arg2)));
  break;

       case LE_EXPR:

  if (! operand_equal_p (arg2, ((type)->type.minval), 1)
      && operand_equal_p (((arg0)->exp.operands[1]),
     const_binop (MINUS_EXPR, arg2,
           integer_one_node, 0), 1))
    return pedantic_non_lvalue
      (fold (build (MIN_EXPR, type, arg1, arg2)));
  break;

       case GT_EXPR:

  if (! operand_equal_p (arg2, ((type)->type.minval), 1)
      && operand_equal_p (((arg0)->exp.operands[1]),
     const_binop (MINUS_EXPR, arg2,
           integer_one_node, 0), 1))
    return pedantic_non_lvalue
      (fold (build (MAX_EXPR, type, arg1, arg2)));
  break;

       case GE_EXPR:

  if (! operand_equal_p (arg2, ((type)->type.maxval), 1)
      && operand_equal_p (((arg0)->exp.operands[1]),
     const_binop (PLUS_EXPR, arg2,
           integer_one_node, 0), 1))
    return pedantic_non_lvalue
      (fold (build (MAX_EXPR, type, arg1, arg2)));
  break;
       }
 }



      if ((((arg1)->common.constant_flag) || (*tree_code_type[(int) (((n64_enum_tree_code) (arg1)->common.code))]) == 'd'
    || ((n64_enum_tree_code) (arg1)->common.code) == SAVE_EXPR)
   && ! (((((t)->exp.operands[2]))->common.constant_flag)
  || (*tree_code_type[(int) (((n64_enum_tree_code) (((t)->exp.operands[2]))->common.code))]) == 'd'
  || ((n64_enum_tree_code) (((t)->exp.operands[2]))->common.code) == SAVE_EXPR))
 {



   tem = invert_truthvalue (arg0);

   if (((n64_enum_tree_code) (tem)->common.code) != TRUTH_NOT_EXPR)
     {
       t = build (code, type, tem,
    ((t)->exp.operands[2]), ((t)->exp.operands[1]));
       arg0 = tem;
       arg1 = ((t)->exp.operands[2]);
       while ((((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == NON_LVALUE_EXPR) && (((((arg1)->common.type))->type.mode) == ((((((arg1)->exp.operands[0]))->common.type))->type.mode))) (arg1) = ((arg1)->exp.operands[0]);;
     }
 }


      if (integer_onep (((t)->exp.operands[1]))
   && integer_zerop (((t)->exp.operands[2]))




   && type == ((arg0)->common.type))
 return pedantic_non_lvalue (arg0);




      if (integer_zerop (((t)->exp.operands[2]))
   && ((n64_enum_tree_code) (arg0)->common.code) == NE_EXPR
   && integer_zerop (((arg0)->exp.operands[1]))
   && integer_pow2p (arg1)
   && ((n64_enum_tree_code) (((arg0)->exp.operands[0]))->common.code) == BIT_AND_EXPR
   && operand_equal_p (((((arg0)->exp.operands[0]))->exp.operands[1]),
         arg1, 1))
 return pedantic_non_lvalue (convert (type, ((arg0)->exp.operands[0])));

      return t;

    case COMPOUND_EXPR:


      if (((arg0)->common.side_effects_flag) || pedantic)
 return t;

      if (integer_zerop (arg1))
 return non_lvalue (arg1);
      return arg1;

    case COMPLEX_EXPR:
      if (wins)
 return build_complex (arg0, arg1);
      return t;

    case REALPART_EXPR:
      if (((n64_enum_tree_code) (((arg0)->common.type))->common.code) != COMPLEX_TYPE)
 return t;
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_EXPR)
 return omit_one_operand (type, ((arg0)->exp.operands[0]),
     ((arg0)->exp.operands[1]));
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_CST)
 return ((arg0)->complex.real);
      else if (((n64_enum_tree_code) (arg0)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == MINUS_EXPR)
 return fold (build (((n64_enum_tree_code) (arg0)->common.code), type,
       fold (build1 (REALPART_EXPR, type,
       ((arg0)->exp.operands[0]))),
       fold (build1 (REALPART_EXPR,
       type, ((arg0)->exp.operands[1])))));
      return t;

    case IMAGPART_EXPR:
      if (((n64_enum_tree_code) (((arg0)->common.type))->common.code) != COMPLEX_TYPE)
 return convert (type, integer_zero_node);
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_EXPR)
 return omit_one_operand (type, ((arg0)->exp.operands[1]),
     ((arg0)->exp.operands[0]));
      else if (((n64_enum_tree_code) (arg0)->common.code) == COMPLEX_CST)
 return ((arg0)->complex.imag);
      else if (((n64_enum_tree_code) (arg0)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == MINUS_EXPR)
 return fold (build (((n64_enum_tree_code) (arg0)->common.code), type,
       fold (build1 (IMAGPART_EXPR, type,
       ((arg0)->exp.operands[0]))),
       fold (build1 (IMAGPART_EXPR, type,
       ((arg0)->exp.operands[1])))));
      return t;



    case CLEANUP_POINT_EXPR:
      if (! ((arg0)->common.side_effects_flag))
 return convert (type, arg0);

      {
 n64_enum_tree_code code0 = ((n64_enum_tree_code) (arg0)->common.code);
 int kind0 = (*tree_code_type[(int) (code0)]);
 tree arg00 = ((arg0)->exp.operands[0]);
 tree arg01;

 if (kind0 == '1' || code0 == TRUTH_NOT_EXPR)
   return fold (build1 (code0, type,
          fold (build1 (CLEANUP_POINT_EXPR,
          ((arg00)->common.type), arg00))));

 if (kind0 == '<' || kind0 == '2'
     || code0 == TRUTH_ANDIF_EXPR || code0 == TRUTH_ORIF_EXPR
     || code0 == TRUTH_AND_EXPR || code0 == TRUTH_OR_EXPR
     || code0 == TRUTH_XOR_EXPR)
   {
     arg01 = ((arg0)->exp.operands[1]);

     if (! ((arg00)->common.side_effects_flag))
       return fold (build (code0, type, arg00,
      fold (build1 (CLEANUP_POINT_EXPR,
      ((arg01)->common.type), arg01))));

     if (! ((arg01)->common.side_effects_flag))
       return fold (build (code0, type,
      fold (build1 (CLEANUP_POINT_EXPR,
      ((arg00)->common.type), arg00)),
      arg01));
   }

 return t;
      }

    default:
      return t;
    }
}

