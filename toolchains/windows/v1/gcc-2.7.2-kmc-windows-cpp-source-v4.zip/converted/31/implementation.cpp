// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/calls.c
/* Convert function calls to rtl insns, for GNU C compiler.
   Copyright (C) 1989, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int warning(...) asm("_warning");
extern int mark_addressable(...) asm("_mark_addressable");
extern int aggregate_value_p(...) asm("_aggregate_value_p");
extern int push_temp_slots(...) asm("_push_temp_slots");
extern int preserve_temp_slots(...) asm("_preserve_temp_slots");
extern int pop_temp_slots(...) asm("_pop_temp_slots");
extern int assemble_external(...) asm("_assemble_external");
extern int rtx_cost(...) asm("_rtx_cost");
extern int preserve_subexpressions_p(...) asm("_preserve_subexpressions_p");
extern int assemble_external_libcall(...) asm("_assemble_external_libcall");
extern int free_temp_slots(...) asm("_free_temp_slots");
struct n64_tag_arg;
struct n64_tag_arg_data;
struct n64_tag_args_size;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);




extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
struct n64_tag_arg_data
{

  tree tree_value;

  n64_enum_machine_mode mode;

  rtx value;

  rtx initial_value;



  rtx reg;


  int unsignedp;


  int partial;




  int pass_on_stack;

  struct n64_tag_args_size offset;


  struct n64_tag_args_size slot_offset;




  struct n64_tag_args_size size;


  rtx stack;



  rtx stack_slot;


  rtx save_area;






  rtx *aligned_regs;
  int n_aligned_regs;

};






static char *stack_usage_map;


static int highest_outgoing_arg_in_use;






int stack_arg_under_construction;


static int calls_function (tree, int) asm("_calls_function");
static int calls_function_1 (tree, int) asm("_calls_function_1");
static void emit_call_1 (rtx, tree, tree, int, int, rtx, rtx, int, rtx, int) asm("_emit_call_1")
                          ;
static void store_one_arg (struct n64_tag_arg_data *, rtx, int, int, tree, int) asm("_store_one_arg")
                ;
static tree calls_function_save_exprs;

static int
calls_function(tree exp, int which) asm("_calls_function");
static int
calls_function(tree exp, int which)
{
  int val;
  calls_function_save_exprs = 0;
  val = calls_function_1 (exp, which);
  calls_function_save_exprs = 0;
  return val;
}

static int
calls_function_1(tree exp, int which) asm("_calls_function_1");
static int
calls_function_1(tree exp, int which)
{
  register int i;
  n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);
  int type = (*tree_code_type[(int) (code)]);
  int length = tree_code_length[(int) code];


  if ((int) code >= ((int)LAST_AND_UNUSED_TREE_CODE))
    return 1;


  if (type != 'e' && type != '<' && type != '1' && type != '2' && type != 'r'
      && type != 'b')
    return 0;

  switch (code)
    {
    case CALL_EXPR:
      if (which == 0)
 return 1;
      else if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == ADDR_EXPR
        && (((n64_enum_tree_code) (((((exp)->exp.operands[0]))->exp.operands[0]))->common.code)
     == FUNCTION_DECL))
 {
   tree fndecl = ((((exp)->exp.operands[0]))->exp.operands[0]);

   if ((((fndecl)->decl.bit_field_flag)
        && ((fndecl)->decl.frame_size.f) == BUILT_IN_ALLOCA)
       || (((fndecl)->decl.saved_insns.r)
    && (((((fndecl)->decl.saved_insns.r))->fld[12].rtint)
        & 01)))
     return 1;
 }


      length = 2;
      break;

    case SAVE_EXPR:
      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) != 0)
 return 0;
      if (value_member (exp, calls_function_save_exprs))
 return 0;
      calls_function_save_exprs = tree_cons ((tree) 
                                            ((void *)0)
                                                     , exp,
          calls_function_save_exprs);
      return (((exp)->exp.operands[0]) != 0
       && calls_function_1 (((exp)->exp.operands[0]), which));

    case BLOCK:
      {
 register tree local;

 for (local = ((exp)->block.vars); local; local = ((local)->common.chain))
   if (((local)->decl.initial) != 0
       && calls_function_1 (((local)->decl.initial), which))
     return 1;
      }
      {
 register tree subblock;

 for (subblock = ((exp)->block.subblocks);
      subblock;
      subblock = ((subblock)->common.chain))
   if (calls_function_1 (subblock, which))
     return 1;
      }
      return 0;

    case METHOD_CALL_EXPR:
      length = 3;
      break;

    case WITH_CLEANUP_EXPR:
      length = 1;
      break;

    case RTL_EXPR:
      return 0;
    }

  for (i = 0; i < length; i++)
    if (((exp)->exp.operands[i]) != 0
 && calls_function_1 (((exp)->exp.operands[i]), which))
      return 1;

  return 0;
}
rtx
prepare_call_address(rtx funexp, tree fndecl, rtx *call_fusage, int reg_parm_seen) asm("_prepare_call_address");
rtx
prepare_call_address(rtx funexp, tree fndecl, rtx *call_fusage, int reg_parm_seen)
{
  rtx static_chain_value = 0;

  funexp = protect_from_queue (funexp, 0);

  if (fndecl != 0)

    static_chain_value = lookup_static_chain (fndecl);



  if (((funexp)->code) != SYMBOL_REF)
    funexp =






        memory_address (((target_flags & 0x00000002) ? DImode : SImode), funexp);
  else
    {







    }

  if (static_chain_value != 0)
    {
      emit_move_insn (static_chain_rtx, static_chain_value);

      if (((static_chain_rtx)->code) == REG)
 use_reg (call_fusage, static_chain_rtx);
    }

  return funexp;
}
static void
emit_call_1(rtx funexp, tree fndecl, tree funtype, int stack_size, int struct_value_size, rtx next_arg_reg, rtx valreg, int old_inhibit_defer_pop, rtx call_fusage, int is_const) asm("_emit_call_1");
static void
emit_call_1(rtx funexp, tree fndecl, tree funtype, int stack_size, int struct_value_size, rtx next_arg_reg, rtx valreg, int old_inhibit_defer_pop, rtx call_fusage, int is_const)
{
  rtx stack_size_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (stack_size));
  rtx struct_value_size_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (struct_value_size));
  rtx call_insn;
  int already_popped = 0;




  if (((funexp)->code) != SYMBOL_REF)
    funexp = memory_address (((target_flags & 0x00000002) ? DImode : SImode), funexp);
  if (1 && 1)
    {
      if (valreg)
 emit_call_insn (gen_call_value (valreg,
     gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), funexp),
     stack_size_rtx, next_arg_reg,
     (rtx) 0));
      else
 emit_call_insn (gen_call (gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), funexp),
      stack_size_rtx, next_arg_reg,
      struct_value_size_rtx));
    }
  else

    abort ();


  for (call_insn = get_last_insn ();
       call_insn && ((call_insn)->code) != CALL_INSN;
       call_insn = ((call_insn)->fld[1].rtx))
    ;

  if (! call_insn)
    abort ();



  if (((call_insn)->fld[7].rtx))
    {
      rtx link;

      for (link = ((call_insn)->fld[7].rtx); ((link)->fld[1].rtx) != 0;
    link = ((link)->fld[1].rtx))
 ;

      ((link)->fld[1].rtx) = call_fusage;
    }
  else
    ((call_insn)->fld[7].rtx) = call_fusage;


  if (is_const)
    ((call_insn)->unchanging) = 1;



  inhibit_defer_pop = old_inhibit_defer_pop;
}







rtx
expand_call(tree exp, rtx target, int ignore) asm("_expand_call");
rtx
expand_call(tree exp, rtx target, int ignore)
{

  tree actparms = ((exp)->exp.operands[1]);

  rtx funexp;

  tree funtree;

  tree funtype;


  tree fndecl = 0;
  char *name = 0;



  rtx valreg;


  rtx structure_value_addr = 0;



  int structure_value_addr_parm = 0;



  int struct_value_size = 0;


  int pcc_struct_value = 0;


  int num_actuals;


  int n_named_args;

  int argpos;




  struct n64_tag_arg_data *args;


  struct n64_tag_args_size args_size;

  struct n64_tag_args_size original_args_size;

  CUMULATIVE_ARGS args_so_far;

  int reg_parm_seen;

  int current_call_is_indirect = 0;
  int must_preallocate = 1;




  int reg_parm_stack_space = 0;


  int inc;


  rtx argblock = 0;


  int may_be_alloca;

  int returns_twice;

  int is_longjmp;

  int is_integrable = 0;


  int is_const = 0;

  int is_volatile = 0;



  int low_to_save = -1, high_to_save;
  rtx save_area = 0;



  int initial_highest_arg_in_use = highest_outgoing_arg_in_use;
  char *initial_stack_usage_map = stack_usage_map;


  rtx old_stack_level = 0;
  int old_pending_adj = 0;
  int old_stack_arg_under_construction;
  int old_inhibit_defer_pop = inhibit_defer_pop;
  tree old_cleanups = cleanups_this_call;
  rtx call_fusage = 0;
  register tree p;
  register int i, j;




  p = ((exp)->exp.operands[0]);
  if (((n64_enum_tree_code) (p)->common.code) == ADDR_EXPR)
    {
      fndecl = ((p)->exp.operands[0]);
      if (((n64_enum_tree_code) (fndecl)->common.code) != FUNCTION_DECL)
 fndecl = 0;
      else
 {
   if (!flag_no_inline
       && fndecl != current_function_decl
       && ((fndecl)->decl.inline_flag)
       && ((fndecl)->decl.saved_insns.r))
     is_integrable = 1;
   else if (! ((fndecl)->common.addressable_flag))
     {





       if (((fndecl)->decl.inline_flag) && warn_inline && !flag_no_inline)
  {
    warning_with_decl (fndecl, "can't inline call to `%s'");
    warning ("called from here");
  }
       mark_addressable (fndecl);
     }

   if (((fndecl)->common.readonly_flag) && ! ((fndecl)->common.volatile_flag)
       && ((((exp)->common.type))->type.mode) != VOIDmode)
     is_const = 1;

   if (((fndecl)->common.volatile_flag))
     is_volatile = 1;
 }
    }



  if (fndecl == 0)
    {
      is_const = ((((((p)->common.type))->common.type))->common.readonly_flag);
      is_volatile = ((((((p)->common.type))->common.type))->common.volatile_flag);
    }





  reg_parm_stack_space = ((4*((target_flags & 0x00002000) ? 8 : 4)) - 0);





  if (warn_aggregate_return && (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE))
    warning ("function call has aggregate value");




  if (aggregate_value_p (exp))
    {

      is_const = 0;
      {
 struct_value_size = int_size_in_bytes (((exp)->common.type));

 if (target && ((target)->code) == MEM)
   structure_value_addr = ((target)->fld[0].rtx);
 else
   {






     if (struct_value_size < 0)
       abort ();

     structure_value_addr
       = ((assign_stack_temp (BLKmode, struct_value_size, 1))->fld[0].rtx);
     ((structure_value_addr)->in_struct)
       = (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE);
     target = 0;
   }
      }

    }



  if (is_integrable)
    {
      rtx temp;
      rtx before_call = get_last_insn ();

      temp = expand_inline_function (fndecl, actparms, target,
         ignore, ((exp)->common.type),
         structure_value_addr);


      if ((int) temp != -1)
 {
   if (flag_short_temps)
     {






       expand_cleanups_to (old_cleanups);
     }






   for (i = reg_parm_stack_space - 1; i >= 0; i--)
     if (i < highest_outgoing_arg_in_use && stack_usage_map[i] != 0)
       break;

   if (stack_arg_under_construction || i >= 0)
     {
       rtx insn = ((before_call)->fld[2].rtx), seq;






       if (((((fndecl)->decl.saved_insns.r))->fld[13].rtint) == 0)
  for (; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == CALL_INSN)
      break;

       if (insn)
  {
    int adjust = ((((fndecl)->decl.saved_insns.r))->fld[13].rtint);







    adjust += reg_parm_stack_space;

    start_sequence ();
    emit_stack_save (SAVE_BLOCK, &old_stack_level, (rtx) 0);
    allocate_dynamic_stack_space (gen_rtx (CONST_INT, VOIDmode, (int) (adjust)),
      (rtx) 0, 8);
    seq = get_insns ();
    end_sequence ();
    emit_insns_before (seq, ((before_call)->fld[2].rtx));
    emit_stack_restore (SAVE_BLOCK, old_stack_level, (rtx) 0);
  }
     }





   if (temp != target && rtx_equal_p (temp, target))
     return target;
   return temp;
 }




      if (((fndecl)->decl.inline_flag) && warn_inline && !flag_no_inline
   && ! ((fndecl)->common.addressable_flag))
 {
   warning_with_decl (fndecl, "inlining failed in call to `%s'");
   warning ("called from here");
 }
      mark_addressable (fndecl);
    }



  if (is_const)
    (inhibit_defer_pop += 1);

  function_call_count++;

  if (fndecl && ((fndecl)->decl.name))
    name = ((((fndecl)->decl.name))->identifier.pointer);





  current_call_is_indirect = (fndecl == 0);
  may_be_alloca =
    (name && ((((((fndecl)->decl.name))->identifier.length) == 6
   && name[0] == 'a'
   && ! strcmp (name, "alloca"))
  || (((((fndecl)->decl.name))->identifier.length) == 16
      && name[0] == '_'
      && ! strcmp (name, "__builtin_alloca"))));





  returns_twice = 0;
  is_longjmp = 0;

  if (name != 0 && ((((fndecl)->decl.name))->identifier.length) <= 15)
    {
      char *tname = name;


      if (name[0] == '_')
 {
   if (name[1] == '_' && name[2] == 'x')
     tname += 3;
   else if (name[1] == '_')
     tname += 2;
   else
     tname += 1;
 }

      if (tname[0] == 's')
 {
   returns_twice
     = ((tname[1] == 'e'
  && (! strcmp (tname, "setjmp")
      || ! strcmp (tname, "setjmp_syscall")))
        || (tname[1] == 'i'
     && ! strcmp (tname, "sigsetjmp"))
        || (tname[1] == 'a'
     && ! strcmp (tname, "savectx")));
   if (tname[1] == 'i'
       && ! strcmp (tname, "siglongjmp"))
     is_longjmp = 1;
 }
      else if ((tname[0] == 'q' && tname[1] == 's'
  && ! strcmp (tname, "qsetjmp"))
        || (tname[0] == 'v' && tname[1] == 'f'
     && ! strcmp (tname, "vfork")))
 returns_twice = 1;

      else if (tname[0] == 'l' && tname[1] == 'o'
        && ! strcmp (tname, "longjmp"))
 is_longjmp = 1;
    }

  if (may_be_alloca)
    current_function_calls_alloca = 1;





  if (pending_stack_adjust >= 32
      || (pending_stack_adjust > 0 && may_be_alloca))
    do_pending_stack_adjust ();


  funtype = ((((exp)->exp.operands[0]))->common.type);
  if (((n64_enum_tree_code) (funtype)->common.code) != POINTER_TYPE)
    abort ();
  funtype = ((funtype)->common.type);



  push_temp_slots ();


  init_cumulative_args (&args_so_far, funtype, (rtx) 0);



  if (structure_value_addr && struct_value_rtx == 0)
    {





      rtx temp = (((structure_value_addr)->code) != REG

    || (stack_arg_under_construction
        && structure_value_addr == virtual_outgoing_args_rtx)

    ? copy_addr_to_reg (structure_value_addr)
    : structure_value_addr);

      actparms
 = tree_cons (error_mark_node,
       make_tree (build_pointer_type (((funtype)->common.type)),
    temp),
       actparms);
      structure_value_addr_parm = 1;
    }


  for (p = actparms, i = 0; p; p = ((p)->common.chain)) i++;
  num_actuals = i;
  if (((funtype)->type.values) != 0)
    n_named_args
      = (list_length (((funtype)->type.values))


  - 1


  + structure_value_addr_parm);
  else


    n_named_args = num_actuals;


  args = (struct n64_tag_arg_data *) 
                            __builtin_alloca((
                            num_actuals * sizeof (struct n64_tag_arg_data)
                            ))
                                                                           ;
  memset ((char *) args,0,num_actuals * sizeof (struct n64_tag_arg_data));

  args_size.constant = 0;
  args_size.var = 0;
  i = 0, inc = 1;



  for (p = actparms, argpos = 0; p; p = ((p)->common.chain), i += inc, argpos++)
    {
      tree type = ((((p)->list.value))->common.type);
      int unsignedp;
      n64_enum_machine_mode mode;

      args[i].tree_value = ((p)->list.value);


      if (type == error_mark_node || ((type)->type.size) == 0)
 args[i].tree_value = integer_zero_node, type = integer_type_node;




      if (((type)->type.transparent_union_flag))
 type = ((((type)->type.values))->common.type);
      if ((((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST
    && contains_placeholder_p (((type)->type.size)))
   || ((type)->common.addressable_flag)




   )
 {
     {


       rtx copy;

       if (((type)->type.size) == 0
    || ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
  {


    rtx size_rtx = expr_size (((p)->list.value));

    if (old_stack_level == 0)
      {
        emit_stack_save (SAVE_BLOCK, &old_stack_level, (rtx) 0);
        old_pending_adj = pending_stack_adjust;
        pending_stack_adjust = 0;
      }

    copy = gen_rtx (MEM, BLKmode,
      allocate_dynamic_stack_space (size_rtx,
        (rtx) 0,
        ((type)->type.align)));
  }
       else
  {
    int size = int_size_in_bytes (type);
    copy = assign_stack_temp (((type)->type.mode), size, 0);
  }

       ((copy)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);

       store_expr (args[i].tree_value, copy, 0);

       args[i].tree_value = build1 (ADDR_EXPR,
        build_pointer_type (type),
        make_tree (type, copy));
       type = build_pointer_type (type);
     }
 }

      mode = ((type)->type.mode);
      unsignedp = ((type)->common.unsigned_flag);





      args[i].unsignedp = unsignedp;
      args[i].mode = mode;
      args[i].reg = function_arg( &args_so_far, mode, type, argpos < n_named_args)
                            ;

      if (args[i].reg)
 args[i].partial
   = function_arg_partial_nregs (&args_so_far, mode, type, argpos < n_named_args)
                           ;


      args[i].pass_on_stack = ((type) != 0 && (((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST || ((type)->common.addressable_flag) || ((mode) == BLKmode && ! ((type) != 0 && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST && 0 == (int_size_in_bytes (type) % (((target_flags & 0x00002000) ? 64 : 32) / 8))) && ((! ((target_flags & 0x00010000) != 0) ? upward : (((mode) == BLKmode ? ((type) && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST && int_size_in_bytes (type) < (((target_flags & 0x00002000) ? 64 : 32) / 8)) : (8 * mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 64 : 32)) ? downward : upward)) == (((target_flags & 0x00010000) != 0) ? upward : downward)))));




      if (args[i].reg && ((args[i].reg)->code) == EXPR_LIST
   && ((args[i].reg)->fld[0].rtx) == 0)
 args[i].pass_on_stack = 1, args[i].reg = ((args[i].reg)->fld[1].rtx);






      if (((type)->common.addressable_flag)
   || (args[i].pass_on_stack && args[i].reg != 0))
 must_preallocate = 1;



      if (((type)->common.addressable_flag))
 is_const = 0;


      if (args[i].reg == 0 || args[i].partial != 0

   || reg_parm_stack_space > 0

   || args[i].pass_on_stack)
 locate_and_pad_parm (mode, type,



        args[i].reg != 0,

        fndecl, &args_size, &args[i].offset,
        &args[i].size);


      args[i].slot_offset = args_size;
      args_size.constant += args[i].size.constant;
      if (args[i].size.var)
 {
   { tree inc = (args[i].size.var); if (((n64_enum_tree_code) (inc)->common.code) == INTEGER_CST) (args_size).constant += ((inc)->int_cst.int_cst_low); else if ((args_size).var == 0) (args_size).var = inc; else (args_size).var = size_binop (PLUS_EXPR, (args_size).var, inc); };
 }
      function_arg_advance (&args_so_far, ((type)->type.mode), type, argpos < n_named_args)
                             ;
    }
  original_args_size = args_size;
  if (args_size.var)
    {





      is_const = 0;
      must_preallocate = 1;

      args_size.var = ((args_size).var == 0 ? size_int ((args_size).constant) : size_binop (PLUS_EXPR, (args_size).var, size_int ((args_size).constant)));
      args_size.constant = 0;


      if (64 != 8)
 args_size.var = round_up (args_size.var, (64 / 8));



      if (reg_parm_stack_space > 0)
 {
   args_size.var
     = size_binop (MAX_EXPR, args_size.var,
     size_int (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)));
 }

    }
  else
    {

      args_size.constant = (((args_size.constant + ((64 / 8) - 1))
        / (64 / 8)) * (64 / 8));



      args_size.constant = ((args_size.constant) > (reg_parm_stack_space) ? (args_size.constant) : (reg_parm_stack_space))
                         ;
    }
  if (! must_preallocate)
    {
      int partial_seen = 0;
      int copy_to_evaluate_size = 0;

      for (i = 0; i < num_actuals && ! must_preallocate; i++)
 {
   if (args[i].partial > 0 && ! args[i].pass_on_stack)
     partial_seen = 1;
   else if (partial_seen && args[i].reg == 0)
     must_preallocate = 1;

   if (((((args[i].tree_value)->common.type))->type.mode) == BLKmode
       && (((n64_enum_tree_code) (args[i].tree_value)->common.code) == CALL_EXPR
    || ((n64_enum_tree_code) (args[i].tree_value)->common.code) == TARGET_EXPR
    || ((n64_enum_tree_code) (args[i].tree_value)->common.code) == COND_EXPR
    || ((((args[i].tree_value)->common.type))->common.addressable_flag)))
     copy_to_evaluate_size
       += int_size_in_bytes (((args[i].tree_value)->common.type));
 }

      if (copy_to_evaluate_size * 2 >= args_size.constant
   && args_size.constant > 0)
 must_preallocate = 1;
    }





  if (structure_value_addr
      && (reg_mentioned_p (virtual_stack_dynamic_rtx, structure_value_addr)
       || reg_mentioned_p (virtual_outgoing_args_rtx, structure_value_addr))
      && (args_size.var



   ))
    structure_value_addr = copy_to_reg (structure_value_addr);
  for (i = 0; i < num_actuals; i++)
    if (is_const
 || ((args_size.var != 0 || args_size.constant != 0)
     && calls_function (args[i].tree_value, 1))
 || (must_preallocate && (args_size.var != 0 || args_size.constant != 0)
     && calls_function (args[i].tree_value, 0)))
      {

 if (((((args[i].tree_value)->common.type))->common.addressable_flag))
   abort ();

 push_temp_slots ();

 args[i].initial_value = args[i].value
   = expand_expr (args[i].tree_value, (rtx) 0, VOIDmode, 0);

 preserve_temp_slots (args[i].value);
 pop_temp_slots ();



 emit_queue ();

 args[i].initial_value = args[i].value
   = protect_from_queue (args[i].initial_value, 0);

 if (((((args[i].tree_value)->common.type))->type.mode) != args[i].mode)
   args[i].value
     = convert_modes (args[i].mode,
        ((((args[i].tree_value)->common.type))->type.mode),
        args[i].value, args[i].unsignedp);
      }



  if (is_const)
    start_sequence ();




  if (args_size.var != 0)
    {
      if (old_stack_level == 0)
 {
   emit_stack_save (SAVE_BLOCK, &old_stack_level, (rtx) 0);
   old_pending_adj = pending_stack_adjust;
   pending_stack_adjust = 0;




   old_stack_arg_under_construction = stack_arg_under_construction;
   stack_arg_under_construction = 0;

 }
      argblock = push_block (((args_size).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((args_size).constant)) : expand_expr (size_binop (PLUS_EXPR, (args_size).var, size_int ((args_size).constant)), (rtx) 0, VOIDmode, 0)), 0, 0);
    }
  else
    {





      int needed = args_size.constant;




      if (needed > current_function_outgoing_args_size)
 current_function_outgoing_args_size = needed;

      if (must_preallocate)
 {
   highest_outgoing_arg_in_use = ((initial_highest_arg_in_use) > (needed) ? (initial_highest_arg_in_use) : (needed))
                 ;

   stack_usage_map = (char *) 
                             __builtin_alloca((
                             highest_outgoing_arg_in_use
                             ))
                                                                 ;

   if (initial_highest_arg_in_use)
     memcpy (stack_usage_map,initial_stack_usage_map,initial_highest_arg_in_use)
                                ;

   if (initial_highest_arg_in_use != highest_outgoing_arg_in_use)
     memset (&stack_usage_map[initial_highest_arg_in_use],0,highest_outgoing_arg_in_use - initial_highest_arg_in_use)
                                                              ;
   needed = 0;






   argblock = virtual_outgoing_args_rtx;
 }
    }





  if (stack_arg_under_construction)
    {



      rtx push_size = gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant));

      if (old_stack_level == 0)
 {
   emit_stack_save (SAVE_BLOCK, &old_stack_level, (rtx) 0);
   old_pending_adj = pending_stack_adjust;
   pending_stack_adjust = 0;



   old_stack_arg_under_construction = stack_arg_under_construction;
   stack_arg_under_construction = 0;

   stack_usage_map = (char *)
                            __builtin_alloca((
                            highest_outgoing_arg_in_use
                            ))
                                                                ;
   memset (stack_usage_map,0,highest_outgoing_arg_in_use);
   highest_outgoing_arg_in_use = 0;
 }
      allocate_dynamic_stack_space (push_size, (rtx) 0, 8);
    }


  for (i = 0; i < num_actuals; i++)
    if (args[i].pass_on_stack)
      {
 argblock = copy_addr_to_reg (argblock);
 break;
      }






  if (argblock)
    {
      rtx arg_reg = argblock;
      int arg_offset = 0;

      if (((argblock)->code) == PLUS)
 arg_reg = ((argblock)->fld[0].rtx), arg_offset = ((((argblock)->fld[1].rtx))->fld[0].rtwint);

      for (i = 0; i < num_actuals; i++)
 {
   rtx offset = ((args[i].offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((args[i].offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (args[i].offset).var, size_int ((args[i].offset).constant)), (rtx) 0, VOIDmode, 0));
   rtx slot_offset = ((args[i].slot_offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((args[i].slot_offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (args[i].slot_offset).var, size_int ((args[i].slot_offset).constant)), (rtx) 0, VOIDmode, 0));
   rtx addr;


   if (! args[i].pass_on_stack && args[i].reg != 0)
     continue;

   if (((offset)->code) == CONST_INT)
     addr = plus_constant_wide (arg_reg, (int) (((offset)->fld[0].rtwint)));
   else
     addr = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), arg_reg, offset);

   addr = plus_constant_wide (addr, (int) (arg_offset));
   args[i].stack = gen_rtx (MEM, args[i].mode, addr);
   ((args[i].stack)->in_struct)
     = (((n64_enum_tree_code) (((args[i].tree_value)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((args[i].tree_value)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((args[i].tree_value)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((args[i].tree_value)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((args[i].tree_value)->common.type))->common.code) == SET_TYPE);

   if (((slot_offset)->code) == CONST_INT)
     addr = plus_constant_wide (arg_reg, (int) (((slot_offset)->fld[0].rtwint)));
   else
     addr = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), arg_reg, slot_offset);

   addr = plus_constant_wide (addr, (int) (arg_offset));
   args[i].stack_slot = gen_rtx (MEM, args[i].mode, addr);
 }
    }
  if (argblock)
    (inhibit_defer_pop += 1);


  if (fndecl)
    {


      if (! ((fndecl)->common.used_flag))
 {
   assemble_external (fndecl);
   ((fndecl)->common.used_flag) = 1;
 }


      funexp = ((((fndecl)->decl.rtl))->fld[0].rtx);
    }
  else

    {
      push_temp_slots ();
      funexp = expand_expr (((exp)->exp.operands[0]), (rtx) 0, VOIDmode, 0);
      pop_temp_slots ();
      emit_queue ();
    }


  valreg = 0;
  if (((((exp)->common.type))->type.mode) != VOIDmode
      && ! structure_value_addr)
    {
      if (pcc_struct_value)
 valreg = hard_function_value (build_pointer_type (((exp)->common.type)),
          fndecl);
      else
 valreg = hard_function_value (((exp)->common.type), fndecl);
    }



  reg_parm_seen = 0;
  for (i = 0; i < num_actuals; i++)
    if (args[i].reg != 0 && ! args[i].pass_on_stack)
      {
 reg_parm_seen = 1;

 if (args[i].value == 0)
   {
     push_temp_slots ();
     args[i].value = expand_expr (args[i].tree_value, (rtx) 0,
      VOIDmode, 0);
     preserve_temp_slots (args[i].value);
     pop_temp_slots ();



     emit_queue ();
   }




 if (args[i].mode != ((((args[i].tree_value)->common.type))->type.mode))
   args[i].value
     = convert_modes (args[i].mode,
        ((((args[i].tree_value)->common.type))->type.mode),
        args[i].value, args[i].unsignedp);
 if ((! (((args[i].value)->code) == REG
  || (((args[i].value)->code) == SUBREG
      && ((((args[i].value)->fld[0].rtx))->code) == REG)))
     && args[i].mode != BLKmode
     && rtx_cost (args[i].value, SET) > 2



     && preserve_subexpressions_p ()

     )
   args[i].value = copy_to_mode_reg (args[i].mode, args[i].value);
      }
  for (i = 0; i < reg_parm_stack_space; i++)

    {
      if (i >= highest_outgoing_arg_in_use
   || stack_usage_map[i] == 0)
 continue;

      if (low_to_save == -1)
 low_to_save = i;

      high_to_save = i;
    }

  if (low_to_save >= 0)
    {
      int num_to_save = high_to_save - low_to_save + 1;
      n64_enum_machine_mode save_mode
 = mode_for_size (num_to_save * 8, MODE_INT, 1);
      rtx stack_area;


      if ((low_to_save & ((((mode_size[(int)(save_mode)])) < (64 / ((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(save_mode)])) : (64 / ((target_flags & 0x00002000) ? 8 : 4)))
                                              - 1)))
 save_mode = BLKmode;

      stack_area = gen_rtx (MEM, save_mode,
       memory_address (save_mode,





         plus_constant_wide (argblock, (int) (low_to_save))


         ));
      if (save_mode == BLKmode)
 {
   save_area = assign_stack_temp (BLKmode, num_to_save, 0);
   ((save_area)->in_struct) = 0;
   emit_block_move (validize_mem (save_area), stack_area,
      gen_rtx (CONST_INT, VOIDmode, (int) (num_to_save)),
      ((target_flags & 0x00002000) ? 64 : 32) / 8);
 }
      else
 {
   save_area = gen_reg_rtx (save_mode);
   emit_move_insn (save_area, stack_area);
 }
    }
  for (i = 0; i < num_actuals; i++)
    if (args[i].reg == 0 || args[i].pass_on_stack)
      store_one_arg (&args[i], argblock, may_be_alloca,
       args_size.var != 0, fndecl, reg_parm_stack_space);







  for (i = 0; i < num_actuals; i++)
    if (args[i].reg != 0 && ! args[i].pass_on_stack
 && args[i].mode == BLKmode
 && (((((args[i].tree_value)->common.type))->type.align)
     < ((64) < (((target_flags & 0x00002000) ? 64 : 32)) ? (64) : (((target_flags & 0x00002000) ? 64 : 32)))))
      {
 int bytes = int_size_in_bytes (((args[i].tree_value)->common.type));
 int big_endian_correction = 0;

 args[i].n_aligned_regs
   = args[i].partial ? args[i].partial
     : (bytes + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4);

 args[i].aligned_regs = (rtx *) 
                               __builtin_alloca((
                               sizeof (rtx) * args[i].n_aligned_regs
                               ))
                                     
                                    ;





 if (((target_flags & 0x00010000) != 0) && bytes < ((target_flags & 0x00002000) ? 8 : 4))
   big_endian_correction = (((target_flags & 0x00002000) ? 64 : 32) - (bytes * 8));

 for (j = 0; j < args[i].n_aligned_regs; j++)
   {
     rtx reg = gen_reg_rtx (word_mode);
     rtx word = operand_subword_force (args[i].value, j, BLKmode);
     int bitsize = ((((args[i].tree_value)->common.type))->type.align);
     int bitpos;

     args[i].aligned_regs[j] = reg;






     emit_insn (gen_rtx (CLOBBER, VOIDmode, reg));

     for (bitpos = 0;
   bitpos < ((target_flags & 0x00002000) ? 64 : 32) && bytes > 0;
   bitpos += bitsize, bytes -= bitsize / 8)
       {
  int xbitpos = bitpos + big_endian_correction;

  store_bit_field (reg, bitsize, xbitpos, word_mode,
     extract_bit_field (word, bitsize, bitpos, 1,
          (rtx) 0, word_mode,
          word_mode,
          bitsize / 8,
          ((target_flags & 0x00002000) ? 64 : 32)),
     bitsize / 8, ((target_flags & 0x00002000) ? 64 : 32));
       }
   }
      }




  if (reg_parm_seen)
    for (i = 0; i < num_actuals; i++)
      if (args[i].partial != 0 && ! args[i].pass_on_stack)
 store_one_arg (&args[i], argblock, may_be_alloca,
         args_size.var != 0, fndecl, reg_parm_stack_space);





  if (argblock == 0)
    anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant - original_args_size.constant))
                                  );
  if (structure_value_addr && ! structure_value_addr_parm)
    {
      emit_move_insn (struct_value_rtx,
        force_reg (((target_flags & 0x00000002) ? DImode : SImode),
     force_operand (structure_value_addr,
      (rtx) 0)));
      if (((struct_value_rtx)->code) == REG)
   use_reg (&call_fusage, struct_value_rtx);
    }

  funexp = prepare_call_address (funexp, fndecl, &call_fusage, reg_parm_seen);
  for (i = 0; i < num_actuals; i++)
    {
      rtx list = args[i].reg;
      int partial = args[i].partial;

      while (list)
 {
   rtx reg;
   int nregs;


   if (((list)->code) == EXPR_LIST)
     reg = ((list)->fld[0].rtx), list = ((list)->fld[1].rtx);
   else
     reg = list, list = 0;





   nregs = (partial ? partial
     : (((((args[i].tree_value)->common.type))->type.mode) == BLKmode
        ? ((int_size_in_bytes (((args[i].tree_value)->common.type))
     + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))
        : -1));





   if (nregs == -1)
     emit_move_insn (reg, args[i].value);





   else if (args[i].n_aligned_regs != 0)
     for (j = 0; j < args[i].n_aligned_regs; j++)
       emit_move_insn (gen_rtx (REG, word_mode, ((reg)->fld[0].rtint) + j),
         args[i].aligned_regs[j]);


   else if (args[i].partial == 0 || args[i].pass_on_stack)
     move_block_to_reg (((reg)->fld[0].rtint),
          validize_mem (args[i].value), nregs,
          args[i].mode);

   if (nregs == -1)
     use_reg (&call_fusage, reg);
   else
     use_regs (&call_fusage, ((reg)->fld[0].rtint), nregs == 0 ? 1 : nregs);



   partial = 0;
 }
    }


  emit_queue ();




  emit_call_1 (funexp, fndecl, funtype, args_size.constant, struct_value_size,
        function_arg( &args_so_far, VOIDmode, void_type_node, 1),
        valreg, old_inhibit_defer_pop, call_fusage, is_const);




  if (is_const && valreg != 0)
    {
      rtx note = 0;
      rtx temp = gen_reg_rtx (((valreg)->mode));
      rtx insns;







      for (i = num_actuals - 1; i >= 0; i--)
 note = gen_rtx (EXPR_LIST, VOIDmode, args[i].initial_value, note);

      note = gen_rtx (EXPR_LIST, VOIDmode, funexp, note);

      insns = get_insns ();
      end_sequence ();

      emit_libcall_block (insns, temp, valreg, note);

      valreg = temp;
    }
  else if (is_const)
    {

      rtx insns = get_insns ();

      end_sequence ();
      emit_insns (insns);
    }




  if (returns_twice)
    {
      emit_note (name, -7);
      current_function_calls_setjmp = 1;
    }

  if (is_longjmp)
    current_function_calls_longjmp = 1;






  if (is_volatile || is_longjmp)
    emit_barrier ();




  if (cleanups_this_call != old_cleanups
      && target && (((target)->code) == REG)
      && ((target)->fld[0].rtint) < 68)
    target = 0;

  if (((((exp)->common.type))->type.mode) == VOIDmode
      || ignore)
    {
      target = const0_rtx;
    }
  else if (structure_value_addr)
    {
      if (target == 0 || ((target)->code) != MEM)
 {
   target = gen_rtx (MEM, ((((exp)->common.type))->type.mode),
       memory_address (((((exp)->common.type))->type.mode),
         structure_value_addr));
   ((target)->in_struct) = (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE);
 }
    }
  else if (pcc_struct_value)
    {
      if (target == 0)
 {






   if (((((exp)->common.type))->type.mode) == BLKmode)
     {
       target = assign_stack_temp (BLKmode,
       int_size_in_bytes (((exp)->common.type)),
       0);

       ((target)->in_struct) = (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE);


       preserve_temp_slots (target);
     }
   else
     target = gen_reg_rtx (((((exp)->common.type))->type.mode));
 }

      if (((((exp)->common.type))->type.mode) != BLKmode)
 emit_move_insn (target, gen_rtx (MEM, ((((exp)->common.type))->type.mode),
      copy_to_reg (valreg)));
      else
 emit_block_move (target, gen_rtx (MEM, BLKmode, copy_to_reg (valreg)),
    expr_size (exp),
    ((((exp)->common.type))->type.align) / 8);
    }
  else if (target && ((target)->mode) == ((((exp)->common.type))->type.mode)
    && ((target)->mode) == ((valreg)->mode))






    emit_move_insn (target, valreg);
  else if (((((exp)->common.type))->type.mode) == BLKmode)
    {





      int bytes = int_size_in_bytes (((exp)->common.type));
      int n_regs = (bytes + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4);
      int i;
      n64_enum_machine_mode tmpmode;
      rtx src, dst;
      int bitsize = ((((((exp)->common.type))->type.align)) < (((target_flags & 0x00002000) ? 64 : 32)) ? (((((exp)->common.type))->type.align)) : (((target_flags & 0x00002000) ? 64 : 32)));
      int bitpos, xbitpos, big_endian_correction = 0;

      if (target == 0)
 {
   target = assign_stack_temp (BLKmode, bytes, 0);
   ((target)->in_struct) = (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE);
   preserve_temp_slots (target);
 }



      if (((valreg)->mode) != BLKmode
   && (mode_size[(int)(((valreg)->mode))]) < ((target_flags & 0x00002000) ? 8 : 4))
 valreg = convert_to_mode (SImode, valreg,
      ((((exp)->common.type))->common.unsigned_flag));





      if (((target_flags & 0x00010000) != 0) && bytes % ((target_flags & 0x00002000) ? 8 : 4))
 big_endian_correction = (((target_flags & 0x00002000) ? 64 : 32) - ((bytes % ((target_flags & 0x00002000) ? 8 : 4))
        * 8));






      for (bitpos = 0, xbitpos = big_endian_correction;
    bitpos < bytes * 8;
    bitpos += bitsize, xbitpos += bitsize)
 {




   if (xbitpos % ((target_flags & 0x00002000) ? 64 : 32) == 0
       || xbitpos == big_endian_correction)
     src = operand_subword_force (valreg,
      xbitpos / ((target_flags & 0x00002000) ? 64 : 32),
      BLKmode);



   if (bitpos % ((target_flags & 0x00002000) ? 64 : 32) == 0)
     dst = operand_subword (target, bitpos / ((target_flags & 0x00002000) ? 64 : 32), 1, BLKmode);



   store_bit_field (dst, bitsize, bitpos % ((target_flags & 0x00002000) ? 64 : 32), word_mode,
      extract_bit_field (src, bitsize,
           xbitpos % ((target_flags & 0x00002000) ? 64 : 32), 1,
           (rtx) 0, word_mode,
           word_mode,
           bitsize / 8,
           ((target_flags & 0x00002000) ? 64 : 32)),
      bitsize / 8, ((target_flags & 0x00002000) ? 64 : 32));
 }
    }
  else
    target = copy_to_reg (valreg);
  if (flag_short_temps)
    {


      expand_cleanups_to (old_cleanups);
    }




  if (old_stack_level)
    {
      emit_stack_restore (SAVE_BLOCK, old_stack_level, (rtx) 0);
      pending_stack_adjust = old_pending_adj;

      stack_arg_under_construction = old_stack_arg_under_construction;
      highest_outgoing_arg_in_use = initial_highest_arg_in_use;
      stack_usage_map = initial_stack_usage_map;

    }

  else
    {

      if (save_area)
 {
   n64_enum_machine_mode save_mode = ((save_area)->mode);
   rtx stack_area
     = gen_rtx (MEM, save_mode,
         memory_address (save_mode,



           plus_constant_wide (argblock, (int) (low_to_save))

           ));

   if (save_mode != BLKmode)
     emit_move_insn (stack_area, save_area);
   else
     emit_block_move (stack_area, validize_mem (save_area),
        gen_rtx (CONST_INT, VOIDmode, (int) (high_to_save - low_to_save + 1)),
        ((target_flags & 0x00002000) ? 64 : 32) / 8);
 }



      for (i = 0; i < num_actuals; i++)
 if (args[i].save_area)
   {
     n64_enum_machine_mode save_mode = ((args[i].save_area)->mode);
     rtx stack_area
       = gen_rtx (MEM, save_mode,
    memory_address (save_mode,
      ((args[i].stack_slot)->fld[0].rtx)));

     if (save_mode != BLKmode)
       emit_move_insn (stack_area, args[i].save_area);
     else
       emit_block_move (stack_area, validize_mem (args[i].save_area),
          gen_rtx (CONST_INT, VOIDmode, (int) (args[i].size.constant)),
          ((target_flags & 0x00002000) ? 64 : 32) / 8);
   }

      highest_outgoing_arg_in_use = initial_highest_arg_in_use;
      stack_usage_map = initial_stack_usage_map;
    }






  if (may_be_alloca && nonlocal_goto_handler_slot != 0)
    emit_stack_save (SAVE_NONLOCAL, &nonlocal_goto_stack_level, (rtx) 0);

  pop_temp_slots ();

  return target;
}
void
emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call");
void
emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...)

{






  va_list p;

  struct n64_tag_args_size args_size;

  struct n64_tag_args_size original_args_size;
  register int argnum;
  rtx fun;
  int inc;
  int count;
  rtx argblock = 0;
  CUMULATIVE_ARGS args_so_far;
  struct n64_tag_arg { rtx value; n64_enum_machine_mode mode; rtx reg; int partial;
        struct n64_tag_args_size offset; struct n64_tag_args_size size; };
  struct n64_tag_arg *argvec;
  int old_inhibit_defer_pop = inhibit_defer_pop;
  rtx call_fusage = 0;

  int current_call_is_indirect = 0;

  
 __builtin_va_start(
 p
 ,
 nargs
 )
                    ;
  fun = orgfun;
  argvec = (struct n64_tag_arg *) 
                         __builtin_alloca((
                         nargs * sizeof (struct n64_tag_arg)
                         ))
                                                             ;

  init_cumulative_args (&args_so_far, (tree) 
 ((void *)0)
 , fun);

  args_size.constant = 0;
  args_size.var = 0;

  push_temp_slots ();

  for (count = 0; count < nargs; count++)
    {
      rtx val = 
               __builtin_va_arg(
               p
               ,
               rtx
               )
                              ;
      n64_enum_machine_mode mode = 
                              __builtin_va_arg(
                              p
                              ,
                              n64_enum_machine_mode
                              )
                                                           ;



      if (mode == BLKmode
   || (((val)->mode) != mode && ((val)->mode) != VOIDmode))
 abort ();
      if (((val)->code) != REG && ((val)->code) != MEM
   && ! ((((val)->code) == LABEL_REF || ((val)->code) == SYMBOL_REF || ((val)->code) == CONST_INT || ((val)->code) == CONST_DOUBLE || ((val)->code) == CONST || ((val)->code) == HIGH) && ((((val)->code) != CONST_DOUBLE || mips_const_double_ok (val, ((val)->mode))) && ! (((val)->code) == CONST && 0))))
 val = force_operand (val, (rtx) 0);
      argvec[count].value = val;
      argvec[count].mode = mode;

      argvec[count].reg = function_arg( &args_so_far, mode, (tree) 
                         ((void *)0)
                         , 1);
      if (argvec[count].reg && ((argvec[count].reg)->code) == EXPR_LIST)
 abort ();

      argvec[count].partial
 = function_arg_partial_nregs (&args_so_far, mode, (tree) 
  ((void *)0)
  , 1);




      locate_and_pad_parm (mode, (tree) 
                                ((void *)0)
                                         ,
      argvec[count].reg && argvec[count].partial == 0,
      (tree) 
     ((void *)0)
              , &args_size, &argvec[count].offset,
      &argvec[count].size);

      if (argvec[count].size.var)
 abort ();






      if (argvec[count].reg == 0 || argvec[count].partial != 0

   || 1

   )
 args_size.constant += argvec[count].size.constant;
      if (argvec[count].reg == 0 || argvec[count].partial != 0)
 abort ();


      function_arg_advance (&args_so_far, mode, (tree)0, 1);
    }
  
 __builtin_va_end(
 p
 )
           ;



  assemble_external_libcall (fun);

  original_args_size = args_size;

  args_size.constant = (((args_size.constant + ((64 / 8) - 1))
    / (64 / 8)) * (64 / 8));



  args_size.constant = ((args_size.constant) > (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)) ? (args_size.constant) : (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)))
                                        ;





  if (args_size.constant > current_function_outgoing_args_size)
    current_function_outgoing_args_size = args_size.constant;


  args_size.constant = 0;



  argblock = push_block (gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant)), 0, 0);
  inc = 1;
  argnum = 0;




  for (count = 0; count < nargs; count++, argnum += inc)
    {
      register n64_enum_machine_mode mode = argvec[argnum].mode;
      register rtx val = argvec[argnum].value;
      rtx reg = argvec[argnum].reg;
      int partial = argvec[argnum].partial;

      if (! (reg != 0 && partial == 0))
 emit_push_insn (val, mode, (tree) 
                           ((void *)0)
                                    , (rtx) 0, 0, partial, reg, 0,
   argblock, gen_rtx (CONST_INT, VOIDmode, (int) (argvec[count].offset.constant)));
      (inhibit_defer_pop += 1);
    }





  if (argblock == 0)
    anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant - original_args_size.constant))
                                  );






  argnum = 0;


  fun = prepare_call_address (fun, (tree) 
                                  ((void *)0)
                                           , &call_fusage, 0);



  for (count = 0; count < nargs; count++, argnum += inc)
    {
      register n64_enum_machine_mode mode = argvec[argnum].mode;
      register rtx val = argvec[argnum].value;
      rtx reg = argvec[argnum].reg;
      int partial = argvec[argnum].partial;

      if (reg != 0 && partial == 0)
 emit_move_insn (reg, val);
      (inhibit_defer_pop += 1);
    }


  if (! no_queue)
    emit_queue ();


  for (count = 0; count < nargs; count++)
    if (argvec[count].reg != 0)
       use_reg (&call_fusage, argvec[count].reg);



  (inhibit_defer_pop += 1);




  emit_call_1 (fun,
               get_identifier (((orgfun)->fld[0].rtstr)),
               get_identifier (((orgfun)->fld[0].rtstr)), args_size.constant, 0,
        function_arg( &args_so_far, VOIDmode, void_type_node, 1),
        outmode != VOIDmode ? hard_libcall_value (outmode) : (rtx) 0,
        old_inhibit_defer_pop + 1, call_fusage, no_queue);

  pop_temp_slots ();


  (inhibit_defer_pop -= 1);
}
rtx
emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value");
rtx
emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...)

{







  va_list p;

  struct n64_tag_args_size args_size;

  struct n64_tag_args_size original_args_size;
  register int argnum;
  rtx fun;
  int inc;
  int count;
  rtx argblock = 0;
  CUMULATIVE_ARGS args_so_far;
  struct n64_tag_arg { rtx value; n64_enum_machine_mode mode; rtx reg; int partial;
        struct n64_tag_args_size offset; struct n64_tag_args_size size; };
  struct n64_tag_arg *argvec;
  int old_inhibit_defer_pop = inhibit_defer_pop;
  rtx call_fusage = 0;
  rtx mem_value = 0;
  int pcc_struct_value = 0;
  int struct_value_size = 0;

  int current_call_is_indirect = 0;
  int is_const;

  
 __builtin_va_start(
 p
 ,
 nargs
 )
                    ;
  is_const = no_queue;
  fun = orgfun;



  if (aggregate_value_p (type_for_mode (outmode, 0)))
    {
      struct_value_size = (mode_size[(int)(outmode)]);
      if (value != 0 && ((value)->code) == MEM)
 mem_value = value;
      else
 mem_value = assign_stack_temp (outmode, (mode_size[(int)(outmode)]), 0);



      is_const = 0;
    }
  argvec = (struct n64_tag_arg *) 
                         __builtin_alloca((
                         (nargs + 1) * sizeof (struct n64_tag_arg)
                         ))
                                                                   ;

  init_cumulative_args (&args_so_far, (tree) 
 ((void *)0)
 , fun);

  args_size.constant = 0;
  args_size.var = 0;

  count = 0;

  push_temp_slots ();



  if (mem_value && struct_value_rtx == 0 && ! pcc_struct_value)
    {
      rtx addr = ((mem_value)->fld[0].rtx);
      nargs++;


      if (((addr)->code) != REG && ((addr)->code) != MEM
   && ! ((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == CONST_DOUBLE || ((addr)->code) == CONST || ((addr)->code) == HIGH) && ((((addr)->code) != CONST_DOUBLE || mips_const_double_ok (addr, ((addr)->mode))) && ! (((addr)->code) == CONST && 0))))
 addr = force_operand (addr, (rtx) 0);

      argvec[count].value = addr;
      argvec[count].mode = ((target_flags & 0x00000002) ? DImode : SImode);
      argvec[count].partial = 0;

      argvec[count].reg = function_arg( &args_so_far, ((target_flags & 0x00000002) ? DImode : SImode), (tree) 
                         ((void *)0)
                         , 1);

      if (function_arg_partial_nregs (&args_so_far, ((target_flags & 0x00000002) ? DImode : SImode), (tree) 
         ((void *)0)
         , 1))
 abort ();


      locate_and_pad_parm (((target_flags & 0x00000002) ? DImode : SImode), (tree) 
                                 ((void *)0)
                                          ,
      argvec[count].reg && argvec[count].partial == 0,
      (tree) 
     ((void *)0)
              , &args_size, &argvec[count].offset,
      &argvec[count].size);


      if (argvec[count].reg == 0 || argvec[count].partial != 0

   || 1

   )
 args_size.constant += argvec[count].size.constant;

      function_arg_advance (&args_so_far, ((target_flags & 0x00000002) ? DImode : SImode), (tree)0, 1);

      count++;
    }

  for (; count < nargs; count++)
    {
      rtx val = 
               __builtin_va_arg(
               p
               ,
               rtx
               )
                              ;
      n64_enum_machine_mode mode = 
                              __builtin_va_arg(
                              p
                              ,
                              n64_enum_machine_mode
                              )
                                                           ;



      if (mode == BLKmode
   || (((val)->mode) != mode && ((val)->mode) != VOIDmode))
 abort ();
      if (((val)->code) != REG && ((val)->code) != MEM
   && ! ((((val)->code) == LABEL_REF || ((val)->code) == SYMBOL_REF || ((val)->code) == CONST_INT || ((val)->code) == CONST_DOUBLE || ((val)->code) == CONST || ((val)->code) == HIGH) && ((((val)->code) != CONST_DOUBLE || mips_const_double_ok (val, ((val)->mode))) && ! (((val)->code) == CONST && 0))))
 val = force_operand (val, (rtx) 0);
      argvec[count].value = val;
      argvec[count].mode = mode;

      argvec[count].reg = function_arg( &args_so_far, mode, (tree) 
                         ((void *)0)
                         , 1);
      if (argvec[count].reg && ((argvec[count].reg)->code) == EXPR_LIST)
 abort ();

      argvec[count].partial
 = function_arg_partial_nregs (&args_so_far, mode, (tree) 
  ((void *)0)
  , 1);




      locate_and_pad_parm (mode, (tree) 
                                ((void *)0)
                                         ,
      argvec[count].reg && argvec[count].partial == 0,
      (tree) 
     ((void *)0)
              , &args_size, &argvec[count].offset,
      &argvec[count].size);

      if (argvec[count].size.var)
 abort ();






      if (argvec[count].reg == 0 || argvec[count].partial != 0

   || 1

   )
 args_size.constant += argvec[count].size.constant;
      if (argvec[count].reg == 0 || argvec[count].partial != 0)
 abort ();


      function_arg_advance (&args_so_far, mode, (tree)0, 1);
    }
  
 __builtin_va_end(
 p
 )
           ;



  assemble_external_libcall (fun);

  original_args_size = args_size;

  args_size.constant = (((args_size.constant + ((64 / 8) - 1))
    / (64 / 8)) * (64 / 8));



  args_size.constant = ((args_size.constant) > (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)) ? (args_size.constant) : (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)))
                                        ;





  if (args_size.constant > current_function_outgoing_args_size)
    current_function_outgoing_args_size = args_size.constant;


  args_size.constant = 0;



  argblock = push_block (gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant)), 0, 0);
  inc = 1;
  argnum = 0;




  for (count = 0; count < nargs; count++, argnum += inc)
    {
      register n64_enum_machine_mode mode = argvec[argnum].mode;
      register rtx val = argvec[argnum].value;
      rtx reg = argvec[argnum].reg;
      int partial = argvec[argnum].partial;

      if (! (reg != 0 && partial == 0))
 emit_push_insn (val, mode, (tree) 
                           ((void *)0)
                                    , (rtx) 0, 0, partial, reg, 0,
   argblock, gen_rtx (CONST_INT, VOIDmode, (int) (argvec[count].offset.constant)));
      (inhibit_defer_pop += 1);
    }





  if (argblock == 0)
    anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (args_size.constant - original_args_size.constant))
                                  );






  argnum = 0;


  fun = prepare_call_address (fun, (tree) 
                                  ((void *)0)
                                           , &call_fusage, 0);



  for (count = 0; count < nargs; count++, argnum += inc)
    {
      register n64_enum_machine_mode mode = argvec[argnum].mode;
      register rtx val = argvec[argnum].value;
      rtx reg = argvec[argnum].reg;
      int partial = argvec[argnum].partial;

      if (reg != 0 && partial == 0)
 emit_move_insn (reg, val);
      (inhibit_defer_pop += 1);
    }
  for (count = 0; count < nargs; count++)
    if (argvec[count].reg != 0)
       use_reg (&call_fusage, argvec[count].reg);


  if (mem_value != 0 && struct_value_rtx != 0 && ! pcc_struct_value)
    {
      emit_move_insn (struct_value_rtx,
        force_reg (((target_flags & 0x00000002) ? DImode : SImode),
     force_operand (((mem_value)->fld[0].rtx),
      (rtx) 0)));
      if (((struct_value_rtx)->code) == REG)
   use_reg (&call_fusage, struct_value_rtx);
    }



  (inhibit_defer_pop += 1);




  emit_call_1 (fun,
               get_identifier (((orgfun)->fld[0].rtstr)),
               get_identifier (((orgfun)->fld[0].rtstr)), args_size.constant,
        struct_value_size,
        function_arg( &args_so_far, VOIDmode, void_type_node, 1),
        (outmode != VOIDmode && mem_value == 0
  ? hard_libcall_value (outmode) : (rtx) 0),
        old_inhibit_defer_pop + 1, call_fusage, is_const);


  (inhibit_defer_pop -= 1);

  pop_temp_slots ();


  if (outmode != VOIDmode)
    {
      if (mem_value)
 {
   if (value == 0)
     value = mem_value;
   if (value != mem_value)
     emit_move_insn (value, mem_value);
 }
      else if (value != 0)
 emit_move_insn (value, hard_libcall_value (outmode));
      else
 value = hard_libcall_value (outmode);
    }

  return value;
}
static void
store_one_arg(struct n64_tag_arg_data *arg, rtx argblock, int may_be_alloca, int variable_size, tree fndecl, int reg_parm_stack_space) asm("_store_one_arg");
static void
store_one_arg(struct n64_tag_arg_data *arg, rtx argblock, int may_be_alloca, int variable_size, tree fndecl, int reg_parm_stack_space)
{
  register tree pval = arg->tree_value;
  rtx reg = 0;
  int partial = 0;
  int used = 0;
  int i, lower_bound, upper_bound;

  if (((n64_enum_tree_code) (pval)->common.code) == ERROR_MARK)
    return;



  push_temp_slots ();




  if (argblock && ! variable_size && arg->stack)
    {
      if (((((arg->stack_slot)->fld[0].rtx))->code) == PLUS)
 lower_bound = ((((((arg->stack_slot)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint);
      else
 lower_bound = 0;

      upper_bound = lower_bound + arg->size.constant;


      for (i = lower_bound; i < upper_bound; i++)
 if (stack_usage_map[i]



     && i > reg_parm_stack_space

     )
   break;

      if (i != upper_bound)
 {

   n64_enum_machine_mode save_mode
     = mode_for_size (arg->size.constant * 8, MODE_INT, 1);
   rtx stack_area
     = gen_rtx (MEM, save_mode,
         memory_address (save_mode, ((arg->stack_slot)->fld[0].rtx)));

   if (save_mode == BLKmode)
     {
       arg->save_area = assign_stack_temp (BLKmode,
        arg->size.constant, 0);
       ((arg->save_area)->in_struct)
  = (((n64_enum_tree_code) (((arg->tree_value)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((arg->tree_value)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((arg->tree_value)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((arg->tree_value)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((arg->tree_value)->common.type))->common.code) == SET_TYPE);
       preserve_temp_slots (arg->save_area);
       emit_block_move (validize_mem (arg->save_area), stack_area,
          gen_rtx (CONST_INT, VOIDmode, (int) (arg->size.constant)),
          ((target_flags & 0x00002000) ? 64 : 32) / 8);
     }
   else
     {
       arg->save_area = gen_reg_rtx (save_mode);
       emit_move_insn (arg->save_area, stack_area);
     }
 }
    }




  if (! arg->pass_on_stack)
    reg = arg->reg, partial = arg->partial;

  if (reg != 0 && partial == 0)


    abort ();




  if (arg->n_aligned_regs != 0)
    reg = 0;





  if (reg && ((reg)->code) == EXPR_LIST)
    reg = ((reg)->fld[0].rtx);



  if (arg->value == 0)
    {
      if (arg->pass_on_stack)
 stack_arg_under_construction++;

      arg->value = expand_expr (pval,
    (partial
     || ((((pval)->common.type))->type.mode) != arg->mode)
    ? (rtx) 0 : arg->stack,
    VOIDmode, 0);




      if (arg->mode != ((((pval)->common.type))->type.mode))
 arg->value = convert_modes (arg->mode, ((((pval)->common.type))->type.mode),
        arg->value, arg->unsignedp);


      if (arg->pass_on_stack)
 stack_arg_under_construction--;

    }



  if (may_be_alloca)
    do_pending_stack_adjust ();

  if (arg->value == arg->stack)

    ;
  else if (arg->mode != BLKmode)
    {
      register int size;
      size = (mode_size[(int)(arg->mode)]);






      used = size;



      if (none != (! ((target_flags & 0x00010000) != 0) ? upward : (((arg->mode) == BLKmode ? ((((pval)->common.type)) && ((n64_enum_tree_code) (((((pval)->common.type))->type.size))->common.code) == INTEGER_CST && int_size_in_bytes (((pval)->common.type)) < (((target_flags & 0x00002000) ? 64 : 32) / 8)) : (8 * mode_size[(int)(arg->mode)]) < ((target_flags & 0x00002000) ? 64 : 32)) ? downward : upward)))
 used = (((size + ((target_flags & 0x00002000) ? 64 : 32) / 8 - 1)
   / (((target_flags & 0x00002000) ? 64 : 32) / 8))
  * (((target_flags & 0x00002000) ? 64 : 32) / 8));



      emit_push_insn (arg->value, arg->mode, ((pval)->common.type), (rtx) 0,
        0, partial, reg, used - size,
        argblock, ((arg->offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((arg->offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (arg->offset).var, size_int ((arg->offset).constant)), (rtx) 0, VOIDmode, 0)));
    }
  else
    {


      register int excess;
      rtx size_rtx;
      if (arg->size.var != 0)
 {
   excess = 0;
   size_rtx = ((arg->size).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((arg->size).constant)) : expand_expr (size_binop (PLUS_EXPR, (arg->size).var, size_int ((arg->size).constant)), (rtx) 0, VOIDmode, 0));
 }
      else
 {


   excess = (arg->size.constant - int_size_in_bytes (((pval)->common.type))
      + partial * ((target_flags & 0x00002000) ? 8 : 4));
   size_rtx = expr_size (pval);
 }

      emit_push_insn (arg->value, arg->mode, ((pval)->common.type), size_rtx,
        ((((pval)->common.type))->type.align) / 8, partial,
        reg, excess, argblock, ((arg->offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((arg->offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (arg->offset).var, size_int ((arg->offset).constant)), (rtx) 0, VOIDmode, 0)));
    }
  if (partial == 0)
    arg->value = arg->stack_slot;



  (inhibit_defer_pop += 1);



  emit_queue ();




  preserve_temp_slots ((rtx) 0);
  free_temp_slots ();
  pop_temp_slots ();



  if (argblock && ! variable_size && arg->stack)
    for (i = lower_bound; i < upper_bound; i++)
      stack_usage_map[i] = 1;

}

