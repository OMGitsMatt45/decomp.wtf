// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/method.c
/* Handle the hair of processing (but not expanding) inline functions.
   Also manage function and variable name overloading.
   Copyright (C) 1987, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)

   This file is part of GNU CC.
   
GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int error(...) asm("_error");
extern int sorry(...) asm("_sorry");
extern int warning(...) asm("_warning");
extern int pedwarn(...) asm("_pedwarn");
extern int really_overloaded_fn(...) asm("_really_overloaded_fn");
extern int error_with_decl(...) asm("_error_with_decl");
extern int init_function_start(...) asm("_init_function_start");
extern int rtl_in_current_obstack(...) asm("_rtl_in_current_obstack");
extern int unshare_all_rtl(...) asm("_unshare_all_rtl");
extern int instantiate_virtual_regs(...) asm("_instantiate_virtual_regs");
extern int regclass_init(...) asm("_regclass_init");
extern int regclass(...) asm("_regclass");
extern int max_reg_num(...) asm("_max_reg_num");
extern int stupid_life_analysis(...) asm("_stupid_life_analysis");
extern int reload(...) asm("_reload");
extern int flow_analysis(...) asm("_flow_analysis");
extern int local_alloc(...) asm("_local_alloc");
extern int global_alloc(...) asm("_global_alloc");
extern int resume_temporary_allocation(...) asm("_resume_temporary_allocation");
extern int simple_cst_equal(...) asm("_simple_cst_equal");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_candidate;
struct n64_tag_harshness_code;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_optab;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct n64_tag_candidate *ansi_c_bullshit;

extern int rank_for_overload (struct n64_tag_candidate *, struct n64_tag_candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct n64_tag_candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct n64_tag_candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct n64_tag_candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct n64_tag_candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
struct n64_tag_harshness_code
{

  unsigned short code;


  short distance;
  unsigned short int_penalty;
};

struct n64_tag_candidate
{
  struct n64_tag_harshness_code h;

  int h_len;

  tree function;
  tree basetypes;
  tree arg;





  struct n64_tag_harshness_code *harshness;

  union
    {
      tree field;

      int bad_arg;







    } u;
};
int rank_for_overload(...) asm("_rank_for_overload");



extern int n_vtables;
extern int n_vtable_entries;
extern int n_vtable_searches;
extern int n_vtable_elems;
extern int n_convert_harshness;
extern int n_compute_conversion_costs;
extern int n_build_method_call;
extern int n_inner_fields_searched;
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");

enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;



struct n64_tag_pending_inline *pending_inlines;





static struct n64_tag_obstack scratch_obstack;
static char *scratch_firstobj;
void
init_method(void) asm("_init_method");
void
init_method(void)
{
  gcc_obstack_init (&scratch_obstack);
  scratch_firstobj = (char *)__extension__ ({ struct n64_tag_obstack *__h = (&scratch_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}



static char digit_buffer[128];







void
do_inline_function_hair(tree type, tree friend_list) asm("_do_inline_function_hair");
void
do_inline_function_hair(tree type, tree friend_list)
{
  tree method = ((type)->type.maxval);

  if (method && ((n64_enum_tree_code) (method)->common.code) == TREE_VEC)
    {
      if (((method)->vec.a[0]))
 method = ((method)->vec.a[0]);
      else
 method = ((method)->vec.a[1]);
    }

  while (method)
    {

      struct n64_tag_pending_inline *info = (((method)->decl.lang_specific)->pending_inline_info);
      if (info)
 {
   tree args;

   my_friendly_assert (info->fndecl == method, 238);
   args = ((method)->decl.arguments);
   while (args)
     {
       ((args)->decl.context) = method;
       args = ((args)->common.chain);
     }



   if (! current_function_decl)
     (((struct n64_tag_lang_identifier *)(((method)->decl.assembler_name)))->global_value) = method;
 }
      method = ((method)->common.chain);
    }
  while (friend_list)
    {
      tree fndecl = ((friend_list)->list.value);
      struct n64_tag_pending_inline *info = (((fndecl)->decl.lang_specific)->pending_inline_info);
      if (info)
 {
   tree args;

   my_friendly_assert (info->fndecl == fndecl, 239);
   args = ((fndecl)->decl.arguments);
   while (args)
     {
       ((args)->decl.context) = fndecl;
       args = ((args)->common.chain);
     }


   if (! current_function_decl)
     (((struct n64_tag_lang_identifier *)(((fndecl)->decl.assembler_name)))->global_value) = fndecl;
 }

      friend_list = ((friend_list)->common.chain);
    }
}



void
report_type_mismatch(struct n64_tag_candidate *cp, tree parmtypes, char *name_kind) asm("_report_type_mismatch");
void
report_type_mismatch(struct n64_tag_candidate *cp, tree parmtypes, char *name_kind)
{
  int i = cp->u.bad_arg;
  tree ttf, tta;
  char *tmp_firstobj;

  switch (i)
    {
    case -4:
      my_friendly_assert (((n64_enum_tree_code) (cp->function)->common.code) == TEMPLATE_DECL, 240);
      cp_error ("type unification failed for function template `%#D'",
  cp->function);
      return;

    case -2:
      cp_error ("too few arguments for %s `%#D'", name_kind, cp->function);
      return;
    case -1:
      cp_error ("too many arguments for %s `%#D'", name_kind, cp->function);
      return;
    case 0:
      if (((n64_enum_tree_code) (((cp->function)->common.type))->common.code) != METHOD_TYPE)
 break;
    case -3:

      my_friendly_assert (! ((((((parmtypes)->list.value))->common.type))->common.readonly_flag),
     241);
      cp_error ("call to non-const %s `%#D' with const object",
  name_kind, cp->function);
      return;
    }

  ttf = ((((cp->function)->common.type))->type.values);
  tta = parmtypes;

  while (i-- > 0)
    {
      ttf = ((ttf)->common.chain);
      tta = ((tta)->common.chain);
    }

  (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("bad argument ") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("bad argument ")),__len); __o->next_free += __len; } (void) 0; }));
  sprintf (digit_buffer, "%d", cp->u.bad_arg
    - (((n64_enum_tree_code) (((cp->function)->common.type))->common.code) == METHOD_TYPE)
    + 1);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (digit_buffer)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((digit_buffer)),__len); __o->next_free += __len; } (void) 0; }));

  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof (" for function `") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((" for function `")),__len); __o->next_free += __len; } (void) 0; }));
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (decl_as_string (cp->function, 1))); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((decl_as_string (cp->function, 1))),__len); __o->next_free += __len; } (void) 0; }));
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("' (type was ") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("' (type was ")),__len); __o->next_free += __len; } (void) 0; }));


  if (tta)
    {
      n64_enum_tree_code code = ((n64_enum_tree_code) (((((tta)->list.value))->common.type))->common.code);
      if (code == ERROR_MARK)
 (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("(failed type instantiation)") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("(failed type instantiation)")),__len); __o->next_free += __len; } (void) 0; }));
      else
 {
   i = (code == FUNCTION_TYPE || code == METHOD_TYPE);
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (type_as_string (((((tta)->list.value))->common.type), 1))); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((type_as_string (((((tta)->list.value))->common.type), 1))),__len); __o->next_free += __len; } (void) 0; }));
 }
    }
  else (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("void") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("void")),__len); __o->next_free += __len; } (void) 0; }));
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ((')')); (void) 0; }));
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; }));

  tmp_firstobj = (char *)
                        __builtin_alloca((
                        __extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); __o->alloc_failed ? 0 : (unsigned) (__o->next_free - __o->object_base); })
                        ))
                                                                       ;
  memcpy (tmp_firstobj,((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base),__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); __o->alloc_failed ? 0 : (unsigned) (__o->next_free - __o->object_base); }))
                                         ;
  error (tmp_firstobj);
}





static tree *typevec;


static int maxtype;


static int nrepeats;


static int nofold;
static



void
icat(int i) asm("_icat");
void
icat(int i)
{


  if (i == 1)
    {
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('1')); (void) 0; }));
      return;
    }

  if (i < 0)
    {
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('m')); (void) 0; }));
      i = -i;
    }
  if (i < 10)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('0' + i)); (void) 0; }));
  else
    {
      icat (i / 10);
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('0' + (i % 10))); (void) 0; }));
    }
}

static



void
flush_repeats(tree type) asm("_flush_repeats");
void
flush_repeats(tree type)
{
  int tindex = 0;

  while (typevec[tindex] != type)
    tindex++;

  if (nrepeats > 1)
    {
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('N')); (void) 0; }));
      icat (nrepeats);
      if (nrepeats > 9)
 (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
    }
  else
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('T')); (void) 0; }));
  nrepeats = 0;
  icat (tindex);
  if (tindex > 9)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
}

static int numeric_output_need_bar;
static void build_overload_identifier(...) asm("_build_overload_identifier");

static void
build_overload_nested_name(tree decl) asm("_build_overload_nested_name");
static void
build_overload_nested_name(tree decl)
{
  if (((decl)->decl.context))
    {
      tree context = ((decl)->decl.context);
      if ((*tree_code_type[(int) (((n64_enum_tree_code) (context)->common.code))]) == 't')
 context = (((context)->type.name));
      build_overload_nested_name (context);
    }

  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    {
      tree name = ((decl)->decl.assembler_name);
      char *label;
      extern int var_labelno;

      ( (label) = (char *) 
     __builtin_alloca((
     strlen ((((name)->identifier.pointer))) + 10
     ))
     , sprintf ((label), "%s.%d", (((name)->identifier.pointer)), (var_labelno)));
      var_labelno++;

      if (numeric_output_need_bar)
 {
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
   numeric_output_need_bar = 0;
 }
      icat (strlen (label));
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (label)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; } (void) 0; }));
    }
  else
    {
      tree name = ((decl)->decl.name);
      build_overload_identifier (name);
    }
}


static void
build_overload_int(tree value) asm("_build_overload_int");
static void
build_overload_int(tree value)
{
  my_friendly_assert (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST, 243);
  if (((value)->type.precision) == 2 * 32)
    {
      if (tree_int_cst_lt (value, integer_zero_node))
 {
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('m')); (void) 0; }));
   value = build_int_2_wide ((int) (~ ((value)->int_cst.int_cst_low)), (int) (- ((value)->int_cst.int_cst_high)))
                                      ;
 }
      if (((value)->int_cst.int_cst_high)
   != (((value)->int_cst.int_cst_low) >> (32 - 1)))
 {

   sorry ("conversion of long long as PT parameter");
 }

    }

  icat (((value)->int_cst.int_cst_low));
}

static void
build_overload_value(tree type, tree value) asm("_build_overload_value");
static void
build_overload_value(tree type, tree value)
{
  while (((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR
  || ((n64_enum_tree_code) (value)->common.code) == NOP_EXPR)
    value = ((value)->exp.operands[0]);
  my_friendly_assert (((n64_enum_tree_code) (type)->common.code) == PARM_DECL, 242);
  type = ((type)->common.type);

  if (numeric_output_need_bar)
    {
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
      numeric_output_need_bar = 0;
    }

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
      && ((n64_enum_tree_code) (((type)->common.type))->common.code) == OFFSET_TYPE)
    {


      type = integer_type_node;
      if (((n64_enum_tree_code) (value)->common.code) != INTEGER_CST)
 {
   sorry ("unknown pointer to member constant");
   return;
 }
    }

  if ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    type = (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

  switch (((n64_enum_tree_code) (type)->common.code))
    {
    case INTEGER_TYPE:
    case ENUMERAL_TYPE:
    case BOOLEAN_TYPE:
      {
 build_overload_int (value);
 numeric_output_need_bar = 1;
 return;
      }
    case POINTER_TYPE:
      if (((n64_enum_tree_code) (((type)->common.type))->common.code) == METHOD_TYPE
   && ((n64_enum_tree_code) (value)->common.code) != ADDR_EXPR)
 {
   if (((n64_enum_tree_code) (value)->common.code) == CONSTRUCTOR)
     {

       tree args = ((value)->exp.operands[1]);
       tree a1 = ((args)->list.value);
       tree a2 = ((((args)->common.chain))->list.value);
       tree a3 = ((((((((args)->common.chain))->common.chain))->list.value))->exp.operands[1]);
       a3 = ((a3)->list.value);
       while ((((n64_enum_tree_code) (a3)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (a3)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (a3)->common.code) == NON_LVALUE_EXPR) && (((((a3)->common.type))->type.mode) == ((((((a3)->exp.operands[0]))->common.type))->type.mode))) (a3) = ((a3)->exp.operands[0]);;
       if (((n64_enum_tree_code) (a1)->common.code) == INTEGER_CST
    && ((n64_enum_tree_code) (a2)->common.code) == INTEGER_CST)
  {
    build_overload_int (a1);
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
    build_overload_int (a2);
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
    if (((n64_enum_tree_code) (a3)->common.code) == ADDR_EXPR)
      {
        a3 = ((a3)->exp.operands[0]);
        if (((n64_enum_tree_code) (a3)->common.code) == FUNCTION_DECL)
   {
     numeric_output_need_bar = 0;
     build_overload_identifier (((a3)->decl.assembler_name));
     return;
   }
      }
    else if (((n64_enum_tree_code) (a3)->common.code) == INTEGER_CST)
      {
        (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('i')); (void) 0; }));
        build_overload_int (a3);
        numeric_output_need_bar = 1;
        return;
      }
  }
     }
   sorry ("template instantiation with pointer to method that is too complex");
   return;
 }
      if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST)
 {
   build_overload_int (value);
   numeric_output_need_bar = 1;
   return;
 }
      value = ((value)->exp.operands[0]);
      if (((n64_enum_tree_code) (value)->common.code) == VAR_DECL)
 {
   my_friendly_assert (((value)->decl.name) != 0, 245);
   build_overload_identifier (((value)->decl.name));
   return;
 }
      else if (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL)
 {
   my_friendly_assert (((value)->decl.name) != 0, 246);
   build_overload_identifier (((value)->decl.name));
   return;
 }
      else
 my_friendly_abort (71);
      break;

    default:
      sorry ("conversion of %s as template parameter",
      tree_code_name [(int) ((n64_enum_tree_code) (type)->common.code)]);
      my_friendly_abort (72);
    }
}

static void
build_overload_identifier(tree name) asm("_build_overload_identifier");
static void
build_overload_identifier(tree name)
{
  if ((((struct n64_tag_lang_identifier *)(name))->class_template_info))
    {
      tree cxx_template, parmlist, arglist, tname;
      int i, nparms;
      cxx_template = (((struct n64_tag_lang_identifier *)(name))->class_template_info);
      arglist = ((cxx_template)->list.value);
      cxx_template = ((cxx_template)->list.purpose);
      tname = ((cxx_template)->decl.name);
      parmlist = ((cxx_template)->decl.arguments);
      nparms = ((parmlist)->vec.length);
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('t')); (void) 0; }));
      icat (((tname)->identifier.length));
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (((tname)->identifier.length)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((tname)->identifier.pointer)),__len); __o->next_free += __len; } (void) 0; }));
      icat (nparms);
      for (i = 0; i < nparms; i++)
 {
   tree parm = ((((parmlist)->vec.a[i]))->list.value);
   tree arg = ((arglist)->vec.a[i]);
   if (((n64_enum_tree_code) (parm)->common.code) == TYPE_DECL)
     {

       (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('Z')); (void) 0; }));
       build_overload_name (arg, 0, 0);
     }
   else
     {
       parm = tsubst (parm, &((arglist)->vec.a[0]),
        ((arglist)->vec.length), (tree) 
                                  ((void *)0)
                                           );

       build_overload_name (((parm)->common.type), 0, 0);
       build_overload_value (parm, arg);
     }
 }
    }
  else
    {
      if (numeric_output_need_bar)
 {
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
   numeric_output_need_bar = 0;
 }
      icat (((name)->identifier.length));
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (((name)->identifier.length)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((name)->identifier.pointer)),__len); __o->next_free += __len; } (void) 0; }));
    }
}
char *
build_overload_name(tree parmtypes, int begin, int end) asm("_build_overload_name");
char *
build_overload_name(tree parmtypes, int begin, int end)
{
  int just_one;
  tree parmtype;

  if (begin) (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  numeric_output_need_bar = 0;

  if ((just_one = (((n64_enum_tree_code) (parmtypes)->common.code) != TREE_LIST)))
    {
      parmtype = parmtypes;
      goto only_one;
    }

  while (parmtypes)
    {
      parmtype = ((parmtypes)->list.value);

    only_one:

      if (! nofold && ! just_one)
 {

   typevec[maxtype++] = parmtype;

   if (((parmtype)->common.used_flag) && parmtype == typevec[maxtype-2])
     {
       nrepeats++;
       goto next;
     }

   if (nrepeats)
     flush_repeats (typevec[maxtype-2]);

   if (((parmtype)->common.used_flag))
     {
       flush_repeats (parmtype);
       goto next;
     }


   if (parmtype != ((parmtype)->type.main_variant)
       || (((n64_enum_tree_code) (parmtype)->common.code) != INTEGER_TYPE
    && ((n64_enum_tree_code) (parmtype)->common.code) != REAL_TYPE))
     ((parmtype)->common.used_flag) = 1;
 }

      if ((((n64_enum_tree_code) (parmtype)->common.code) == RECORD_TYPE && ((parmtype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
 parmtype = (((((((((((((parmtype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

      if (((parmtype)->common.readonly_flag))
 (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('C')); (void) 0; }));
      if (((n64_enum_tree_code) (parmtype)->common.code) == INTEGER_TYPE
   && ((parmtype)->type.main_variant) == unsigned_type (((parmtype)->type.main_variant)))
 (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('U')); (void) 0; }));
      if (((parmtype)->common.volatile_flag))
 (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('V')); (void) 0; }));

      switch (((n64_enum_tree_code) (parmtype)->common.code))
 {
 case OFFSET_TYPE:
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('O')); (void) 0; }));
   build_overload_name (((parmtype)->type.maxval), 0, 0);
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
   build_overload_name (((parmtype)->common.type), 0, 0);
   break;

 case REFERENCE_TYPE:
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('R')); (void) 0; }));
   goto more;

 case ARRAY_TYPE:

   {
     tree length;

     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('A')); (void) 0; }));
     if (((parmtype)->type.values) == (tree) 
                                  ((void *)0)
                                           )
       error ("pointer or reference to array of unknown bound in parm type");
     else
       {
  length = array_type_nelts (parmtype);
  if (((n64_enum_tree_code) (length)->common.code) == INTEGER_CST)
    icat (((length)->int_cst.int_cst_low) + 1);
       }
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
     goto more;
   }





 case POINTER_TYPE:
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('P')); (void) 0; }));
 more:
   build_overload_name (((parmtype)->common.type), 0, 0);
   break;

 case FUNCTION_TYPE:
 case METHOD_TYPE:
   {
     tree firstarg = ((parmtype)->type.values);


     int old_nofold = nofold;
     nofold = 1;

     if (nrepeats)
       flush_repeats (typevec[maxtype-1]);



     if (((n64_enum_tree_code) (parmtype)->common.code) == FUNCTION_TYPE)
       {
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('F')); (void) 0; }));
  if (firstarg == (tree) 
                 ((void *)0)
                          )
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('e')); (void) 0; }));
  else if (firstarg == void_list_node)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('v')); (void) 0; }));
  else
    build_overload_name (firstarg, 0, 0);
       }
     else
       {
  int constp = ((((((firstarg)->list.value))->common.type))->common.readonly_flag);
  int volatilep = ((((((firstarg)->list.value))->common.type))->common.volatile_flag);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('M')); (void) 0; }));
  firstarg = ((firstarg)->common.chain);

  build_overload_name (((parmtype)->type.maxval), 0, 0);
  if (constp)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('C')); (void) 0; }));
  if (volatilep)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('V')); (void) 0; }));


  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('F')); (void) 0; }));

  if (firstarg == (tree) 
                 ((void *)0)
                          )
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('e')); (void) 0; }));
  else if (firstarg == void_list_node)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('v')); (void) 0; }));
  else
    build_overload_name (firstarg, 0, 0);
       }


     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
     build_overload_name (((parmtype)->common.type), 0, 0);
     nofold = old_nofold;
     break;
   }

 case INTEGER_TYPE:
   parmtype = ((parmtype)->type.main_variant);
   if (parmtype == integer_type_node
       || parmtype == unsigned_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('i')); (void) 0; }));
   else if (parmtype == long_integer_type_node
     || parmtype == long_unsigned_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('l')); (void) 0; }));
   else if (parmtype == short_integer_type_node
     || parmtype == short_unsigned_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('s')); (void) 0; }));
   else if (parmtype == signed_char_type_node)
     {
       (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('S')); (void) 0; }));
       (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('c')); (void) 0; }));
     }
   else if (parmtype == char_type_node
     || parmtype == unsigned_char_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('c')); (void) 0; }));
   else if (parmtype == wchar_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('w')); (void) 0; }));
   else if (parmtype == long_long_integer_type_node
       || parmtype == long_long_unsigned_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('x')); (void) 0; }));







   else
     my_friendly_abort (73);
   break;

 case BOOLEAN_TYPE:
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('b')); (void) 0; }));
   break;

 case REAL_TYPE:
   parmtype = ((parmtype)->type.main_variant);
   if (parmtype == long_double_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('r')); (void) 0; }));
   else if (parmtype == double_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('d')); (void) 0; }));
   else if (parmtype == float_type_node)
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('f')); (void) 0; }));
   else my_friendly_abort (74);
   break;

 case VOID_TYPE:
   if (! just_one)
     {







       if (end) (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; }));
       return (char *)((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base);
     }
   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('v')); (void) 0; }));
   break;

 case ERROR_MARK:
   break;


 case UNION_TYPE:
 case RECORD_TYPE:
   if (! just_one)


     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('G')); (void) 0; }));
   goto common;
 case ENUMERAL_TYPE:
 common:
   {
     tree name = ((parmtype)->type.name);
     int i = 1;

     if (((n64_enum_tree_code) (name)->common.code) == TYPE_DECL)
       {
  tree context = name;


  if (((context)->decl.assembler_name) != ((context)->decl.name))
    {
      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (((((context)->decl.assembler_name))->identifier.length)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((((context)->decl.assembler_name))->identifier.pointer)),__len); __o->next_free += __len; } (void) 0; }));
      break;
    }
  while (((context)->decl.context))
    {
      i += 1;
      context = ((context)->decl.context);
      if ((*tree_code_type[(int) (((n64_enum_tree_code) (context)->common.code))]) == 't')
        context = ((context)->type.name);
    }
  name = ((name)->decl.name);
       }
     my_friendly_assert (((n64_enum_tree_code) (name)->common.code) == IDENTIFIER_NODE, 248);
     if (i > 1)
       {
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('Q')); (void) 0; }));
  if (i > 9)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
  icat (i);
  if (i > 9)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
  numeric_output_need_bar = 0;
  build_overload_nested_name ((((parmtype)->type.name)));
       }
     else
       build_overload_identifier (name);
     break;
   }

 case LANG_TYPE:

   (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('?')); (void) 0; }));
   break;

 case TEMPLATE_TYPE_PARM:
 case TEMPLATE_CONST_PARM:
        case UNINSTANTIATED_P_TYPE:



   {
     static int n;
     sprintf (digit_buffer, " *%d", n++);
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (digit_buffer)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((digit_buffer)),__len); __o->next_free += __len; } (void) 0; }));
   }
   break;

 default:
   my_friendly_abort (75);
 }

    next:
      if (just_one) break;
      parmtypes = ((parmtypes)->common.chain);
    }
  if (! just_one)
    {
      if (nrepeats)
 flush_repeats (typevec[maxtype-1]);


      (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('e')); (void) 0; }));
    }

  if (end) (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; }));
  return (char *)((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base);
}

tree
build_static_name(tree basetype, tree name) asm("_build_static_name");
tree
build_static_name(tree basetype, tree name)
{
  char *basename = build_overload_name (basetype, 1, 1);
  char *buf = (char *) 
                      __builtin_alloca((
                      ((name)->identifier.length) + sizeof ("_%s.%s") + strlen (basename)
                      ))

                              
                             ;
  sprintf (buf, "_%s.%s", basename, ((name)->identifier.pointer));
  return get_identifier (buf);
}







tree
cplus_exception_name(tree type) asm("_cplus_exception_name");
tree
cplus_exception_name(tree type)
{
  (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("__ex") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("__ex")),__len); __o->next_free += __len; } (void) 0; }));
  return get_identifier (build_overload_name (type, 0, 1));
}
tree
build_decl_overload(tree dname, tree parms, int for_method) asm("_build_decl_overload");
tree
build_decl_overload(tree dname, tree parms, int for_method)
{
  char *name = ((dname)->identifier.pointer);


  if (! for_method && parms != (tree) 
                              ((void *)0) 
                                        && ((n64_enum_tree_code) (parms)->common.code) == TREE_LIST)
    {
      if (dname == ansi_opname[(int) DELETE_EXPR])
 return get_identifier ("__builtin_delete");
      else if (dname == ansi_opname[(int) VEC_DELETE_EXPR])
 return get_identifier ("__builtin_vec_delete");
      else if (((parms)->common.chain) == void_list_node)
 {
   if (dname == ansi_opname[(int) NEW_EXPR])
     return get_identifier ("__builtin_new");
   else if (dname == ansi_opname[(int) VEC_NEW_EXPR])
     return get_identifier ("__builtin_vec_new");
 }
    }

  (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  if (for_method != 2)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (strlen (name)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((name)),__len); __o->next_free += __len; } (void) 0; }));



  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }), __extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('_')); (void) 0; }));
  if (for_method)
    {




      {
 tree this_type = ((parms)->list.value);

 if (((n64_enum_tree_code) (this_type)->common.code) == RECORD_TYPE)
   parms = temp_tree_cons ((tree) 
                          ((void *)0)
                                   , (((this_type)->type.lang_specific)->signature),
      ((parms)->common.chain));
 else
   parms = temp_tree_cons ((tree) 
                          ((void *)0)
                                   , ((this_type)->common.type),
      ((parms)->common.chain));
      }
    }
  else
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('F')); (void) 0; }));

  if (parms == (tree) 
              ((void *)0)
                       )
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('e')); (void) 0; }), __extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('\0')); (void) 0; }));
  else if (parms == void_list_node)
    (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('v')); (void) 0; }), __extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('\0')); (void) 0; }));
  else
    {
      do { maxtype = 0, nrepeats = 0; typevec = (tree *)
     __builtin_alloca((
     list_length (parms) * sizeof (tree)
     ))
     ; } while (0);
      nofold = 0;
      if (for_method)
 {
   build_overload_name (((parms)->list.value), 0, 0);

   typevec[maxtype++] = ((parms)->list.value);
   ((((parms)->list.value))->common.used_flag) = 1;

   if (((parms)->common.chain))
     build_overload_name (((parms)->common.chain), 0, 1);
   else
     (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('e')); (void) 0; }), __extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (('\0')); (void) 0; }));
 }
      else
 build_overload_name (parms, 0, 1);
      do { tree t = (parms); while (t) { ((((t)->list.value))->common.used_flag) = 0; t = ((t)->common.chain); } } while (0);
    }
  {
    tree n = get_identifier (((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base));
    if (((dname)->common.lang_flag_2))
      ((n)->common.lang_flag_2) = 1;
    return n;
  }
}


tree
build_typename_overload(tree type) asm("_build_typename_overload");
tree
build_typename_overload(tree type)
{
  tree id;

  (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (((ansi_opname[(int) TYPE_EXPR])->identifier.length)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((ansi_opname[(int) TYPE_EXPR])->identifier.pointer)),__len); __o->next_free += __len; } (void) 0; }));
  nofold = 1;
  build_overload_name (type, 0, 1);
  id = get_identifier (((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base));
  ((id)->common.lang_flag_2) = 1;



  ((id)->common.type) = type;
  return id;
}
tree
build_t_desc_overload(tree type) asm("_build_t_desc_overload");
tree
build_t_desc_overload(tree type)
{
  (scratch_firstobj ? (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); void *__obj = (scratch_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }), 0) : 0);
  (__extension__ ({ struct n64_tag_obstack *__o = (&scratch_obstack); int __len = (sizeof ("TD.") - 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (("TD.")),__len); __o->next_free += __len; } (void) 0; }));
  nofold = 1;
  build_overload_name (type, 0, 1);
  return get_identifier (((&scratch_obstack)->alloc_failed ? 0 : (&scratch_obstack)->object_base));
}





void
declare_overloaded(tree name) asm("_declare_overloaded");
void
declare_overloaded(tree name)
{
  if (current_lang_name == lang_name_cplusplus)
    {
      if (0)
 warning ("functions are implicitly overloaded in C++");
    }
  else if (current_lang_name == lang_name_c)
    error ("overloading function `%s' cannot be done in C language context");
  else
    my_friendly_abort (76);

}
tree
build_opfncall(n64_enum_tree_code code, int flags, tree xarg1, tree xarg2, tree arg3) asm("_build_opfncall");
tree
build_opfncall(n64_enum_tree_code code, int flags, tree xarg1, tree xarg2, tree arg3)
{
  tree rval = 0;
  tree arg1, arg2;
  tree type1, type2, fnname;
  tree fields1 = 0, parms = 0;
  tree global_fn;
  int try_second;
  int binary_is_unary;

  if (xarg1 == error_mark_node)
    return error_mark_node;

  if (code == COND_EXPR)
    {
      if (((n64_enum_tree_code) (xarg2)->common.code) == ERROR_MARK
   || ((n64_enum_tree_code) (arg3)->common.code) == ERROR_MARK)
 return error_mark_node;
    }
  if (code == COMPONENT_REF)
    if (((n64_enum_tree_code) (((xarg1)->common.type))->common.code) == POINTER_TYPE)
      return rval;


  type1 = ((xarg1)->common.type);



  switch (code)
    {
    case PREINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case POSTINCREMENT_EXPR:
    case POSTDECREMENT_EXPR:
    case COMPONENT_REF:
      binary_is_unary = 1;
      try_second = 0;
      break;



    case ARRAY_REF:
      if (xarg2 == error_mark_node)
 return error_mark_node;
    case CALL_EXPR:
      rval = error_mark_node;
      binary_is_unary = 0;
      try_second = 0;
      break;

    case VEC_NEW_EXPR:
    case NEW_EXPR:
      {
 tree args = tree_cons ((tree) 
                       ((void *)0)
                                , xarg2, arg3);
 fnname = ansi_opname[(int) code];
 if (flags & (16))
   return build_overload_call (fnname, args, flags & (2),
          (struct n64_tag_candidate *)0);

 rval = build_method_call
   (build_indirect_ref (build1 (NOP_EXPR, xarg1, error_mark_node),
          "new"),
    fnname, args, (tree) 
                 ((void *)0)
                          , flags);
 if (rval == error_mark_node)


   return rval;

 ((rval)->common.type) = xarg1;
 (((rval)->common.lang_flag_1)) = 1;
 return rval;
      }
      break;

    case VEC_DELETE_EXPR:
    case DELETE_EXPR:
      {
 fnname = ansi_opname[(int) code];
 if (flags & (16))
   return build_overload_call (fnname,
          build_tree_list ((tree) 
                          ((void *)0)
                                   , xarg1),
          flags & (2),
          (struct n64_tag_candidate *)0);

 rval = build_method_call
   (build_indirect_ref (build1 (NOP_EXPR, ((xarg1)->common.type),
           error_mark_node),
          ((void *)0)),
    fnname, tree_cons ((tree) 
                      ((void *)0)
                               , xarg1,
          build_tree_list ((tree) 
                          ((void *)0)
                                   , xarg2)),
    (tree) 
   ((void *)0)
            , flags);





 return rval;
      }
      break;

    default:
      binary_is_unary = 0;
      try_second = tree_code_length [(int) code] == 2;
      if (try_second && xarg2 == error_mark_node)
 return error_mark_node;
      break;
    }

  if (try_second && xarg2 == error_mark_node)
    return error_mark_node;


  if (type1 == (tree) 
              ((void *)0)
                       )
    return rval;

  if (((n64_enum_tree_code) (type1)->common.code) == OFFSET_TYPE)
    type1 = ((type1)->common.type);

  if (((n64_enum_tree_code) (type1)->common.code) == REFERENCE_TYPE)
    {
      arg1 = convert_from_reference (xarg1);
      type1 = ((arg1)->common.type);
    }
  else
    {
      arg1 = xarg1;
    }

  if (!(((type1)->type.lang_flag_5)) || (((n64_enum_tree_code) (type1)->common.code) == RECORD_TYPE && ((type1)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {

      if (! try_second)
 return rval;

      type2 = ((xarg2)->common.type);
      if (((n64_enum_tree_code) (type2)->common.code) == OFFSET_TYPE)
 type2 = ((type2)->common.type);
      if (((n64_enum_tree_code) (type2)->common.code) == REFERENCE_TYPE)
 {
   arg2 = convert_from_reference (xarg2);
   type2 = ((arg2)->common.type);
 }
      else
 {
   arg2 = xarg2;
 }

      if (!(((type2)->type.lang_flag_5)))
 return rval;
      try_second = 0;
    }

  if (try_second)
    {

      type2 = ((xarg2)->common.type);
      if (((n64_enum_tree_code) (type2)->common.code) == OFFSET_TYPE)
 type2 = ((type2)->common.type);
      if (((n64_enum_tree_code) (type2)->common.code) == REFERENCE_TYPE)
 {
   arg2 = convert_from_reference (xarg2);
   type2 = ((arg2)->common.type);
 }
      else
 {
   arg2 = xarg2;
 }

      if (! (((type2)->type.lang_flag_5)))
 try_second = 0;
    }

  if (type1 == unknown_type_node
      || (try_second && ((xarg2)->common.type) == unknown_type_node))
    {

      return rval;
    }

  if (code == MODIFY_EXPR)
    fnname = ansi_assopname[(int) ((n64_enum_tree_code) (arg3)->common.code)];
  else
    fnname = ansi_opname[(int) code];

  global_fn = lookup_name_nonclass (fnname);






  if ((((type1)->type.lang_flag_5)))
    {
      fields1 = lookup_fnfields (((type1)->type.binfo), fnname, 0);

      if (code == POSTINCREMENT_EXPR || code == POSTDECREMENT_EXPR)
 {
   xarg2 = integer_zero_node;
   binary_is_unary = 0;

   if (fields1)
     {
       tree t, t2;
       int have_postfix = 0;



       for (t = ((fields1)->list.value); t ; t = (((t)->decl.lang_specific)->chain))
  {
    t2 = ((((t)->common.type))->type.values);
    if (((t2)->common.chain) != (tree) 
                          ((void *)0)
        
       && ((((t2)->common.chain))->list.value) == integer_type_node)
      {
        have_postfix = 1;
        break;
      }
  }

       if (! have_postfix)
  {
    char *op = POSTINCREMENT_EXPR ? "++" : "--";



    if (! flag_traditional)
      pedwarn ("no `operator%s (int)' declared for postfix `%s', using prefix operator instead",
        op, op);
    xarg2 = (tree) 
           ((void *)0)
                    ;
    binary_is_unary = 1;
  }
     }
 }
    }

  if (fields1 == (tree) 
                ((void *)0) 
                          && global_fn == (tree) 
                                          ((void *)0)
                                                   )
    return rval;
  if (((n64_enum_tree_code) (xarg1)->common.code) == CP_OFFSET_REF
      && ((n64_enum_tree_code) (((xarg1)->exp.operands[1]))->common.code) == VAR_DECL)
    xarg1 = ((xarg1)->exp.operands[1]);
  if (try_second && xarg2 && ((n64_enum_tree_code) (xarg2)->common.code) == CP_OFFSET_REF
      && ((n64_enum_tree_code) (((xarg2)->exp.operands[1]))->common.code) == VAR_DECL)
    xarg2 = ((xarg2)->exp.operands[1]);

  if (global_fn)
    flags |= (16);

  if (code == CALL_EXPR)
    {

      return build_method_call (xarg1, fnname, xarg2,
    (tree) 
   ((void *)0)
            , (3));
    }
  else if (tree_code_length[(int) code] == 1 || binary_is_unary)
    {
      parms = (tree) 
             ((void *)0)
                      ;
      rval = build_method_call (xarg1, fnname, (tree) 
                                              ((void *)0)
                                                       , (tree) 
                                                         ((void *)0)
                                                                  , flags);
    }
  else if (code == COND_EXPR)
    {
      parms = tree_cons (0, xarg2, build_tree_list ((tree) 
                                                   ((void *)0)
                                                            , arg3));
      rval = build_method_call (xarg1, fnname, parms, (tree) 
                                                     ((void *)0)
                                                              , flags);
    }
  else if (code == METHOD_CALL_EXPR)
    {

      parms = tree_cons ((tree) 
                        ((void *)0)
                                 , xarg2, arg3);
      return build_method_call (xarg1, fnname, parms, (tree) 
                                                     ((void *)0)
                                                              ,
    (3));
    }
  else if (fields1)
    {
      parms = build_tree_list ((tree) 
                              ((void *)0)
                                       , xarg2);
      rval = build_method_call (xarg1, fnname, parms, (tree) 
                                                     ((void *)0)
                                                              , flags);
    }
  else
    {
      parms = tree_cons ((tree) 
                        ((void *)0)
                                 , xarg1,
    build_tree_list ((tree) 
                    ((void *)0)
                             , xarg2));
      rval = build_overload_call (fnname, parms, flags,
      (struct n64_tag_candidate *)0);
    }

  return rval;
}
tree
hack_identifier(tree value, tree name, int yychar) asm("_hack_identifier");
tree
hack_identifier(tree value, tree name, int yychar)
{
  tree type;

  if (((n64_enum_tree_code) (value)->common.code) == ERROR_MARK)
    {
      if (current_class_name)
 {
   tree fields = lookup_fnfields (((current_class_type)->type.binfo), name, 1);
   if (fields == error_mark_node)
     return error_mark_node;
   if (fields)
     {
       tree fndecl;

       fndecl = ((fields)->list.value);
       my_friendly_assert (((n64_enum_tree_code) (fndecl)->common.code) == FUNCTION_DECL, 251);
       if ((((fndecl)->decl.lang_specific)->chain) == (tree) 
                                 ((void *)0)
                                          )
  {
    warning ("methods cannot be converted to function pointers");
    return fndecl;
  }
       else
  {
    error ("ambiguous request for method pointer `%s'",
    ((name)->identifier.pointer));
    return error_mark_node;
  }
     }
 }
      if (flag_labels_ok && (((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->label_value : 0))
 {
   return (((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->label_value : 0);
 }
      return error_mark_node;
    }

  type = ((value)->common.type);
  if (((n64_enum_tree_code) (value)->common.code) == FIELD_DECL)
    {
      if (current_class_decl == (tree) 
                               ((void *)0)
                                        )
 {
   error ("request for member `%s' in static member function",
   ((((value)->decl.name))->identifier.pointer));
   return error_mark_node;
 }
      ((current_class_decl)->common.used_flag) = 1;




      ((value)->common.used_flag) = 1;
      return build_component_ref (C_C_D, name, 0, 1);
    }

  if (really_overloaded_fn (value))
    {
      tree t = get_first_fn (value);
      for (; t; t = (((t)->decl.lang_specific)->chain))
 {
   if (((n64_enum_tree_code) (t)->common.code) == TEMPLATE_DECL)
     continue;

   assemble_external (t);
   ((t)->common.used_flag) = 1;
 }
    }
  else if (((n64_enum_tree_code) (value)->common.code) == TREE_LIST)
    {
      tree t = value;
      while (t && ((n64_enum_tree_code) (t)->common.code) == TREE_LIST)
 {
   assemble_external (((t)->list.value));
   ((t)->common.used_flag) = 1;
   t = ((t)->common.chain);
 }
    }
  else
    {
      assemble_external (value);
      ((value)->common.used_flag) = 1;
    }

  if ((*tree_code_type[(int) (((n64_enum_tree_code) (value)->common.code))]) == 'd' && ((value)->decl.nonlocal_flag))
    {
      if (((value)->decl.lang_specific)
   && (((value)->decl.lang_specific)->decl_flags.context) != current_class_type)
 {
   tree path;
   n64_enum_access_type access;
   register tree context
     = (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL && ((value)->decl.virtual_flag))
       ? (((value)->decl.lang_specific)->decl_flags.context)
       : ((value)->decl.context);

   get_base_distance (context, current_class_type, 0, &path);
   if (path)
     {
       access = compute_access (path, value);
       if (access != access_public)
  {
    if (((n64_enum_tree_code) (value)->common.code) == VAR_DECL)
      error ("static member `%s' is %s",
      ((name)->identifier.pointer),
      ((value)->common.private_flag) ? "private" :
      "from a private base class");
    else
      error ("enum `%s' is from private base class",
      ((name)->identifier.pointer));
    return error_mark_node;
  }
     }
 }
      return value;
    }
  if (((n64_enum_tree_code) (value)->common.code) == TREE_LIST && (((value)->common.lang_flag_0)))
    {
      if (type == 0)
 {
   error ("request for member `%s' is ambiguous in multiple inheritance lattice",
   ((name)->identifier.pointer));
   return error_mark_node;
 }

      return value;
    }

  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    {
      my_friendly_assert (((n64_enum_tree_code) (value)->common.code) == VAR_DECL
     || ((n64_enum_tree_code) (value)->common.code) == PARM_DECL
     || ((n64_enum_tree_code) (value)->common.code) == RESULT_DECL, 252);
      return convert_from_reference (value);
    }
  return value;
}
static char *
thunk_printable_name(tree decl) asm("_thunk_printable_name");
static char *
thunk_printable_name(tree decl)
{
  return "<thunk function>";
}

tree
make_thunk(tree function, int delta) asm("_make_thunk");
tree
make_thunk(tree function, int delta)
{
  char buffer[250];
  tree thunk_fndecl, thunk_id;
  tree thunk;
  char *func_name;
  static int thunk_number = 0;
  tree func_decl;
  if (((n64_enum_tree_code) (function)->common.code) != ADDR_EXPR)
    abort ();
  func_decl = ((function)->exp.operands[0]);
  if (((n64_enum_tree_code) (func_decl)->common.code) != FUNCTION_DECL)
    abort ();
  func_name = ((((func_decl)->decl.assembler_name))->identifier.pointer);
  if (delta<=0)
    sprintf (buffer, "__thunk_%d_%s", -delta, func_name);
  else
    sprintf (buffer, "__thunk_n%d_%s", delta, func_name);
  thunk_id = get_identifier (buffer);
  thunk = (((struct n64_tag_lang_identifier *)(thunk_id))->global_value);
  if (thunk && ((n64_enum_tree_code) (thunk)->common.code) != THUNK_DECL)
    {
      error_with_decl ("implementation-reserved name `%s' used");
      (((struct n64_tag_lang_identifier *)(thunk_id))->global_value) = thunk = (tree) 
                                                  ((void *)0)
                                                           ;
    }
  if (thunk == (tree) 
              ((void *)0)
                       )
    {
      thunk = build_decl (THUNK_DECL, thunk_id, ((func_decl)->common.type));
      ((thunk)->decl.result)
 = build_decl (RESULT_DECL, 0, ((((vtable_entry_type)->common.type))->type.main_variant));
      ((thunk)->common.readonly_flag) = ((((vtable_entry_type)->common.type))->common.readonly_flag);
      ((thunk)->common.volatile_flag) = ((((vtable_entry_type)->common.type))->common.volatile_flag);
      make_function_rtl (thunk);
      ((thunk)->decl.initial) = function;
      ((thunk)->decl.frame_size.i) = delta;

      pushdecl_top_level (thunk);
    }
  return thunk;
}

void
emit_thunk(tree thunk_fndecl) asm("_emit_thunk");
void
emit_thunk(tree thunk_fndecl)
{
  rtx insns;
  char *fnname;
  char buffer[250];
  tree argp;
  struct n64_tag_args_size stack_args_size;
  tree function = ((((thunk_fndecl)->decl.initial))->exp.operands[0]);
  int delta = ((thunk_fndecl)->decl.frame_size.i);
  int tem;
  int failure = 0;
  int current_call_is_indirect = 0;


  rtx need_use[68];
  int need_use_count = 0;


  rtx this_rtx = 0, this_reg_rtx = 0, fixed_this_rtx;

  char *(*save_decl_printable_name)(...) = decl_printable_name;

  CUMULATIVE_ARGS args_so_far;

  if (((thunk_fndecl)->common.asm_written_flag))
    return;

  ((thunk_fndecl)->common.asm_written_flag) = 1;

  if (((function)->common.public_flag))
    {
      ((thunk_fndecl)->common.public_flag) = 1;
      if (((function)->decl.external_flag))
 {
   ((thunk_fndecl)->decl.external_flag) = 1;
   assemble_external (thunk_fndecl);
   return;
 }
    }

  decl_printable_name = thunk_printable_name;
  if (current_function_decl)
    abort ();
  current_function_decl = thunk_fndecl;
  init_function_start (thunk_fndecl, input_filename, lineno);
  pushlevel (0);
  expand_start_bindings (1);


  init_cumulative_args (&args_so_far, ((function)->common.type), (rtx) 0);
  stack_args_size.constant = 0;
  stack_args_size.var = 0;





  for (argp = ((((function)->common.type))->type.values);
       argp != (tree) 
              ((void *)0)
                       ;
       argp = ((argp)->common.chain))

    {
      tree passed_type = ((argp)->list.value);
      register rtx entry_parm;
      int named = 1;
      struct n64_tag_args_size stack_offset;
      struct n64_tag_args_size arg_size;

      if (passed_type == void_type_node)
 break;

      if ((((n64_enum_tree_code) (((passed_type)->type.size))->common.code) != INTEGER_CST
    && contains_placeholder_p (((passed_type)->type.size)))





   )
 passed_type = build_pointer_type (passed_type);

      entry_parm = function_arg( &args_so_far, ((passed_type)->type.mode), passed_type, named)


           ;
      if (entry_parm != 0)
 need_use[need_use_count++] = entry_parm;

      locate_and_pad_parm (((passed_type)->type.mode), passed_type,



      entry_parm != 0,

      thunk_fndecl,
      &stack_args_size, &stack_offset, &arg_size);


      if (this_rtx == 0)
 {
   this_reg_rtx = entry_parm;
   if (!entry_parm)
     {
       rtx offset_rtx = ((stack_offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((stack_offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (stack_offset).var, size_int ((stack_offset).constant)), (rtx) 0, VOIDmode, 0));

       rtx internal_arg_pointer, stack_parm;

       if ((0 == (0 + 29)
     || ! (fixed_regs[0]
    || 0 == (0 + 30))))
  internal_arg_pointer = copy_to_reg (virtual_incoming_args_rtx);
       else
  internal_arg_pointer = virtual_incoming_args_rtx;

       if (offset_rtx == const0_rtx)
  entry_parm = gen_rtx (MEM, ((passed_type)->type.mode),
          internal_arg_pointer);
       else
  entry_parm = gen_rtx (MEM, ((passed_type)->type.mode),
          gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode),
            internal_arg_pointer,
            offset_rtx));
     }

   this_rtx = entry_parm;
 }

      function_arg_advance (&args_so_far, ((passed_type)->type.mode), passed_type, named)


             ;
    }

  fixed_this_rtx = plus_constant_wide (this_rtx, (int) (delta));
  if (this_rtx != fixed_this_rtx)
    emit_move_insn (this_rtx, fixed_this_rtx);

  if (this_reg_rtx)
    emit_insn (gen_rtx (USE, VOIDmode, this_reg_rtx));

  emit_indirect_jump (((((function)->decl.rtl))->fld[0].rtx));

  while (need_use_count > 0)
    emit_insn (gen_rtx (USE, VOIDmode, need_use[--need_use_count]));

  expand_end_bindings (
                      ((void *)0)
                          , 1, 0);
  poplevel (0, 0, 1);






  rtl_in_current_obstack ();

  insns = get_insns ();



  unshare_all_rtl (insns);



  instantiate_virtual_regs (current_function_decl, get_insns ());



  cse_not_expected = 1;





  if (optimize > 0)
    obey_regdecls = 0;

  regclass_init ();

  regclass (insns, max_reg_num ());
  if (obey_regdecls)
    {
      stupid_life_analysis (insns, max_reg_num (), 
                                                  ((void *)0)
                                                      );
      failure = reload (insns, 0, 
                                 ((void *)0)
                                     );
    }
  else
    {



      flow_analysis (insns, max_reg_num (), 
                                           ((void *)0)
                                               );
      local_alloc ();
      failure = global_alloc (
                             ((void *)0)
                                 );
    }

  reload_completed = 1;
    {
      char *fnname = ((((((thunk_fndecl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr);
      assemble_start_function (thunk_fndecl, fnname);
      final (insns, asm_out_file, optimize, 0);
      assemble_end_function (thunk_fndecl, fnname);
    };

 exit_rest_of_compilation:

  reload_completed = 0;



  resume_temporary_allocation ();

  decl_printable_name = save_decl_printable_name;
  current_function_decl = 0;
}





static tree
largest_union_member(tree type) asm("_largest_union_member");
static tree
largest_union_member(tree type)
{
  tree f, type_size = ((type)->type.size);

  for (f = ((type)->type.values); f; f = ((f)->common.chain))
    if (simple_cst_equal (((f)->decl.size), type_size) == 1)
      return f;


  my_friendly_abort (323);
  return (tree) 
        ((void *)0)
                 ;
}


void
do_build_copy_constructor(tree fndecl) asm("_do_build_copy_constructor");
void
do_build_copy_constructor(tree fndecl)
{
  tree parm = ((((fndecl)->decl.arguments))->common.chain);
  tree t;

  clear_last_expr ();
  push_momentary ();

  if ((((current_class_type)->common.lang_flag_3)))
    parm = ((parm)->common.chain);
  parm = convert_from_reference (parm);

  if (((((current_class_type)->type.lang_specific)->type_flags.has_init_ref) && ! (((current_class_type)->type.lang_specific)->type_flags.has_complex_init_ref)))
    {
      t = build (INIT_EXPR, void_type_node, C_C_D, parm);
      ((t)->common.side_effects_flag) = 1;
      cplus_expand_expr_stmt (t);
    }
  else
    {
      tree fields = ((current_class_type)->type.values);
      int n_bases = (((((current_class_type)->type.binfo))->vec.a[4]) ? ((((((current_class_type)->type.binfo))->vec.a[4]))->vec.length) : 0);
      tree binfos = ((((current_class_type)->type.binfo))->vec.a[4]);
      int i;

      for (t = (((current_class_type)->type.lang_specific)->vbases); t;
    t = ((t)->common.chain))
 {
   tree basetype = ((t)->common.type);
   tree p = convert_to_reference
     (build_reference_type (basetype), parm,
      1|4, (2), (tree) 
                                                ((void *)0)
                                                         );
   p = convert_from_reference (p);
   current_base_init_list = tree_cons ((((((basetype)->type.name))->decl.arguments)),
           p, current_base_init_list);
 }

      for (i = 0; i < n_bases; ++i)
 {
   tree p, basetype = ((binfos)->vec.a[i]);
   if (((basetype)->common.static_flag))
     continue;

   basetype = ((basetype)->common.type);
   p = convert_to_reference
     (build_reference_type (basetype), parm,
      1|4, (2), (tree) 
                                                ((void *)0)
                                                         );
   p = convert_from_reference (p);
   current_base_init_list = tree_cons ((((((basetype)->type.name))->decl.arguments)),
           p, current_base_init_list);
 }
      for (; fields; fields = ((fields)->common.chain))
 {
   tree name, init, t;
   tree field = fields;

   if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
     continue;
   if (((field)->decl.name))
     {
       if ((!strncmp (((((field)->decl.name))->identifier.pointer), "_vptr.", sizeof("_vptr.")-1)))
  continue;
       if ((((((field)->decl.name))->identifier.pointer)[1] == 'v' && ((((field)->decl.name))->identifier.pointer)[2] == 'b' && ((((field)->decl.name))->identifier.pointer)[3] == '.'))
  continue;


       if ((((struct n64_tag_lang_identifier *)(((field)->decl.name)))->class_value) != field)
  continue;
     }
   else if ((t = ((field)->common.type)) != (tree) 
                                      ((void *)0)
     
    && ((n64_enum_tree_code) (t)->common.code) == UNION_TYPE
     && ((((((((t)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((t)->type.name))->decl.name)))->identifier.pointer)[1] == '_')
     && ((t)->type.values) != (tree) 
                          ((void *)0)
                                   )
     field = largest_union_member (t);
   else
     continue;

   init = build (COMPONENT_REF, ((field)->common.type), parm, field);
   init = build_tree_list ((tree) 
                          ((void *)0)
                                   , init);

   current_member_init_list
     = tree_cons (((field)->decl.name), init, current_member_init_list);
 }
      current_member_init_list = nreverse (current_member_init_list);
      current_base_init_list = nreverse (current_base_init_list);
      setup_vtbl_ptr ();
    }

  pop_momentary ();
}

void
do_build_assign_ref(tree fndecl) asm("_do_build_assign_ref");
void
do_build_assign_ref(tree fndecl)
{
  tree parm = ((((fndecl)->decl.arguments))->common.chain);

  clear_last_expr ();
  push_momentary ();

  parm = convert_from_reference (parm);

  if (((((current_class_type)->type.lang_specific)->type_flags.has_assign_ref) && ! (((current_class_type)->type.lang_specific)->type_flags.has_complex_assign_ref)))
    {
      tree t = build (MODIFY_EXPR, void_type_node, C_C_D, parm);
      ((t)->common.side_effects_flag) = 1;
      cplus_expand_expr_stmt (t);
    }
  else
    {
      tree fields = ((current_class_type)->type.values);
      int n_bases = (((((current_class_type)->type.binfo))->vec.a[4]) ? ((((((current_class_type)->type.binfo))->vec.a[4]))->vec.length) : 0);
      tree binfos = ((((current_class_type)->type.binfo))->vec.a[4]);
      int i;

      for (i = 0; i < n_bases; ++i)
 {
   tree basetype = ((((binfos)->vec.a[i]))->common.type);
   if ((((basetype)->type.lang_specific)->type_flags.has_assign_ref))
     {
       tree p = convert_to_reference
  (build_reference_type (basetype), parm,
   1|4, (2), (tree) 
                                             ((void *)0)
                                                      );
       p = convert_from_reference (p);
       p = build_member_call ((((((basetype)->type.name))->decl.arguments)),
         ansi_opname [MODIFY_EXPR],
         build_tree_list ((tree) 
                         ((void *)0)
                                  , p));
       expand_expr_stmt (p);
     }
 }
      for (; fields; fields = ((fields)->common.chain))
 {
   tree comp, init, t;
   tree field = fields;

   if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
     continue;
   if (((field)->decl.name))
     {
       if ((!strncmp (((((field)->decl.name))->identifier.pointer), "_vptr.", sizeof("_vptr.")-1)))
  continue;
       if ((((((field)->decl.name))->identifier.pointer)[1] == 'v' && ((((field)->decl.name))->identifier.pointer)[2] == 'b' && ((((field)->decl.name))->identifier.pointer)[3] == '.'))
  continue;


       if ((((struct n64_tag_lang_identifier *)(((field)->decl.name)))->class_value) != field)
  continue;
     }
   else if ((t = ((field)->common.type)) != (tree) 
                                      ((void *)0)
     
    && ((n64_enum_tree_code) (t)->common.code) == UNION_TYPE
     && ((((((((t)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((t)->type.name))->decl.name)))->identifier.pointer)[1] == '_')
     && ((t)->type.values) != (tree) 
                          ((void *)0)
                                   )
     field = largest_union_member (t);
   else
     continue;

   comp = build (COMPONENT_REF, ((field)->common.type), C_C_D, field);
   init = build (COMPONENT_REF, ((field)->common.type), parm, field);

   expand_expr_stmt (build_modify_expr (comp, NOP_EXPR, init));
 }
    }
  c_expand_return (C_C_D);
  pop_momentary ();
}

void push_cp_function_context(...) asm("_push_cp_function_context");
void pop_cp_function_context(...) asm("_pop_cp_function_context");

void
synthesize_method(tree fndecl) asm("_synthesize_method");
void
synthesize_method(tree fndecl)
{
  int nested = (current_function_decl != (tree) 
                                        ((void *)0)
                                                 );
  tree context = decl_function_context (fndecl);
  char *f = input_filename;
  tree base = (((fndecl)->decl.lang_specific)->decl_flags.context);

  if (nested)
    push_cp_function_context (context);

  input_filename = ((fndecl)->decl.filename);
  interface_unknown = (((base)->type.lang_specific)->type_flags.interface_unknown);
  interface_only = (((base)->type.lang_specific)->type_flags.interface_only);
  start_function ((tree) 
                 ((void *)0)
                          , fndecl, (tree) 
                                    ((void *)0)
                                             , (tree) 
                                               ((void *)0)
                                                        , 1);
  store_parm_decls ();

  if (((fndecl)->decl.name) == ansi_opname[MODIFY_EXPR])
    do_build_assign_ref (fndecl);
  else if ((((((fndecl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((fndecl)->decl.assembler_name))->identifier.pointer)[2] == '_'))
    ;
  else
    {
      tree arg_chain = (((((((fndecl)->common.type))->type.values))->common.chain));
      if ((((fndecl)->decl.lang_specific)->decl_flags.constructor_for_vbase_attr))
 arg_chain = ((arg_chain)->common.chain);
      if (arg_chain != void_list_node)
 do_build_copy_constructor (fndecl);
      else if (((current_class_type)->type.needs_constructing_flag))
 setup_vtbl_ptr ();
    }

  finish_function (lineno, 0, nested);


  if (((fndecl)->decl.inline_flag))
    {


      ((fndecl)->decl.inline_flag) = 0;
      if (function_cannot_inline_p (fndecl) == 0)
 ((fndecl)->decl.inline_flag) = 1;
    }

  input_filename = f;
  extract_interface_info ();
  if (nested)
    pop_cp_function_context (context);
}

