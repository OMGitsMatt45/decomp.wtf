// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/loop.c
/* Perform various loop optimizations, including strength reduction.
   Copyright (C) 1987, 88, 89, 91-4, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int rtx_cost(...) asm("_rtx_cost");
extern int obfree(...) asm("_obfree");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int init_recog_no_volatile(...) asm("_init_recog_no_volatile");
extern int init_alias_analysis(...) asm("_init_alias_analysis");
extern int max_reg_num(...) asm("_max_reg_num");
extern int get_max_uid(...) asm("_get_max_uid");
extern int reg_scan(...) asm("_reg_scan");
extern int simplejump_p(...) asm("_simplejump_p");
extern int may_trap_p(...) asm("_may_trap_p");
extern int side_effects_p(...) asm("_side_effects_p");
extern int modified_between_p(...) asm("_modified_between_p");
extern int no_labels_between_p(...) asm("_no_labels_between_p");
extern int validate_replace_rtx(...) asm("_validate_replace_rtx");
extern int reg_referenced_p(...) asm("_reg_referenced_p");
extern int remove_note(...) asm("_remove_note");
extern int replace_regs(...) asm("_replace_regs");
extern int volatile_refs_p(...) asm("_volatile_refs_p");
extern int note_stores(...) asm("_note_stores");
extern int condjump_p(...) asm("_condjump_p");
extern int invert_jump(...) asm("_invert_jump");
extern int reorder_insns(...) asm("_reorder_insns");
extern int true_dependence(...) asm("_true_dependence");
extern int reg_used_between_p(...) asm("_reg_used_between_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int print_rtl(...) asm("_print_rtl");
extern int reg_set_between_p(...) asm("_reg_set_between_p");
extern int reg_set_p(...) asm("_reg_set_p");
struct n64_tag__obstack_chunk;
struct n64_tag_induction;
struct n64_tag_iv_class;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_movable;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
enum n64_cpp_enum_g_types{ DEST_ADDR, DEST_REG };
typedef __underlying_type(enum n64_cpp_enum_g_types) n64_enum_g_types;





struct n64_tag_induction
{
  rtx insn;
  rtx new_reg;

  rtx src_reg;

  n64_enum_g_types giv_type;
  rtx dest_reg;



  rtx *location;

  n64_enum_machine_mode mode;
  n64_enum_machine_mode mem_mode;
  rtx mult_val;
  rtx add_val;
  int benefit;
  rtx final_value;



  unsigned replaceable : 1;




  unsigned not_replaceable : 1;





  unsigned ignore : 1;
  unsigned always_computable : 1;
  unsigned maybe_multiple : 1;


  unsigned cant_derive : 1;



  unsigned combined_with : 1;

  unsigned maybe_dead : 1;


  int lifetime;
  int times_used;
  rtx derive_adjustment;



  struct n64_tag_induction *next_iv;



  struct n64_tag_induction *same;


  int const_adjust;



  struct n64_tag_induction *same_insn;



};



struct n64_tag_iv_class {
  int regno;
  int biv_count;
  struct n64_tag_induction *biv;
  int giv_count;


  struct n64_tag_induction *giv;

  int total_benefit;
  rtx initial_value;
  rtx initial_test;
  struct n64_tag_iv_class *next;
  rtx init_insn;
  rtx init_set;
  unsigned incremented : 1;
  unsigned eliminable : 1;
  unsigned nonneg : 1;
  unsigned reversed : 1;

};


enum n64_cpp_enum_iv_mode{ UNKNOWN_INDUCT, BASIC_INDUCT, NOT_BASIC_INDUCT,
   GENERAL_INDUCT };
typedef __underlying_type(enum n64_cpp_enum_iv_mode) n64_enum_iv_mode;




extern int *uid_luid;
extern int max_uid_for_loop;
extern int *uid_loop_num;
extern int *loop_outer_loop;
extern rtx *loop_number_exit_labels;
extern int *loop_number_exit_count;
extern unsigned int loop_n_iterations;
extern int max_reg_before_loop;

extern FILE *loop_dump_stream;

extern n64_enum_iv_mode *reg_iv_type;
extern struct n64_tag_induction **reg_iv_info;
extern struct n64_tag_iv_class **reg_biv_class;
extern struct n64_tag_iv_class *loop_iv_list;



int invariant_p (rtx) asm("_invariant_p");
rtx get_condition_for_loop (rtx) asm("_get_condition_for_loop");
void emit_iv_add_mult (rtx, rtx, rtx, rtx, rtx) asm("_emit_iv_add_mult");


void find_loop_tree_blocks (void) asm("_find_loop_tree_blocks");
void unroll_block_trees (void) asm("_unroll_block_trees");

void unroll_loop (rtx, int, rtx, rtx, int) asm("_unroll_loop");
rtx biv_total_increment (struct n64_tag_iv_class *, rtx, rtx) asm("_biv_total_increment");
unsigned int loop_iterations (rtx, rtx) asm("_loop_iterations");
rtx final_biv_value (struct n64_tag_iv_class *, rtx, rtx) asm("_final_biv_value");
rtx final_giv_value (struct n64_tag_induction *, rtx, rtx) asm("_final_giv_value");
void emit_unrolled_add (rtx, rtx, rtx) asm("_emit_unrolled_add");
int back_branch_in_range_p (rtx, rtx, rtx) asm("_back_branch_in_range_p");





int *uid_luid;




int *uid_loop_num;



int max_uid_for_loop;



static int max_luid;




static int max_loop_num;



static rtx *loop_number_loop_starts, *loop_number_loop_ends;



int *loop_outer_loop;




static char *loop_invalid;
rtx *loop_number_exit_labels;




int *loop_number_exit_count;







unsigned int loop_n_iterations;




static int loop_has_call;




static int loop_has_volatile;





static rtx loop_continue;
static short *n_times_set;





static short *n_times_used;




static char *may_not_optimize;




static char *moved_once;





static rtx loop_store_mems[20];


static int loop_store_mems_idx;





static int unknown_address_altered;


static int num_movables;


static int num_mem_sets;


static int loops_enclosed;



int max_reg_before_loop;






static struct n64_tag_obstack temp_obstack;



extern struct n64_tag_obstack *rtl_obstack;




extern char *oballoc(...) asm("_oballoc");





struct n64_tag_movable
{
  rtx insn;
  rtx set_src;
  rtx set_dest;
  rtx dependencies;

  int consec;

  int regno;
  short lifetime;


  short savings;


  unsigned int cond : 1;
  unsigned int force : 1;
  unsigned int global : 1;



  unsigned int done : 1;

  unsigned int partial : 1;


  unsigned int move_insn : 1;

  unsigned int is_equiv : 1;
  n64_enum_machine_mode savemode;


  struct n64_tag_movable *match;
  struct n64_tag_movable *forces;
  struct n64_tag_movable *next;
};

FILE *loop_dump_stream;



static void find_and_verify_loops(...) asm("_find_and_verify_loops");
static void mark_loop_jump(...) asm("_mark_loop_jump");
static void prescan_loop(...) asm("_prescan_loop");
static int reg_in_basic_block_p(...) asm("_reg_in_basic_block_p");
static int consec_sets_invariant_p(...) asm("_consec_sets_invariant_p");
static rtx libcall_other_reg(...) asm("_libcall_other_reg");
static int labels_in_range_p(...) asm("_labels_in_range_p");
static void count_loop_regs_set(...) asm("_count_loop_regs_set");
static void note_addr_stored(...) asm("_note_addr_stored");
static int loop_reg_used_before_p(...) asm("_loop_reg_used_before_p");
static void scan_loop(...) asm("_scan_loop");
static void replace_call_address(...) asm("_replace_call_address");
static rtx skip_consec_insns(...) asm("_skip_consec_insns");
static int libcall_benefit(...) asm("_libcall_benefit");
static void ignore_some_movables(...) asm("_ignore_some_movables");
static void force_movables(...) asm("_force_movables");
static void combine_movables(...) asm("_combine_movables");
static int rtx_equal_for_loop_p(...) asm("_rtx_equal_for_loop_p");
static void move_movables(...) asm("_move_movables");
static void strength_reduce(...) asm("_strength_reduce");
static int valid_initial_value_p(...) asm("_valid_initial_value_p");
static void find_mem_givs(...) asm("_find_mem_givs");
static void record_biv(...) asm("_record_biv");
static void check_final_value(...) asm("_check_final_value");
static void record_giv(...) asm("_record_giv");
static void update_giv_derive(...) asm("_update_giv_derive");
static int basic_induction_var(...) asm("_basic_induction_var");
static rtx simplify_giv_expr(...) asm("_simplify_giv_expr");
static int general_induction_var(...) asm("_general_induction_var");
static int consec_sets_giv(...) asm("_consec_sets_giv");
static int check_dbra_loop(...) asm("_check_dbra_loop");
static rtx express_from(...) asm("_express_from");
static int combine_givs_p(...) asm("_combine_givs_p");
static void combine_givs(...) asm("_combine_givs");
static int product_cheap_p(...) asm("_product_cheap_p");
static int maybe_eliminate_biv(...) asm("_maybe_eliminate_biv");
static int maybe_eliminate_biv_1(...) asm("_maybe_eliminate_biv_1");
static int last_use_this_basic_block(...) asm("_last_use_this_basic_block");
static void record_initial(...) asm("_record_initial");
static void update_reg_last_use(...) asm("_update_reg_last_use");


int add_cost;







int copy_cost;

void
init_loop(void) asm("_init_loop");
void
init_loop(void)
{
  char *free_point = (char *) oballoc (1);
  rtx reg = gen_rtx (REG, word_mode, 0);

  add_cost = rtx_cost (gen_rtx (PLUS, word_mode, reg, reg), SET);





  copy_cost = 2 * 2;


  obfree (free_point);


  gcc_obstack_init (&temp_obstack);
}






void
loop_optimize(rtx f, FILE *dumpfile) asm("_loop_optimize");
void
loop_optimize(rtx f, FILE *dumpfile)
{
  register rtx insn;
  register int i;
  rtx last_insn;

  loop_dump_stream = dumpfile;

  init_recog_no_volatile ();
  init_alias_analysis ();

  max_reg_before_loop = max_reg_num ();

  moved_once = (char *) 
                       __builtin_alloca((
                       max_reg_before_loop
                       ))
                                                   ;
  memset (moved_once,0,max_reg_before_loop);

  regs_may_share = 0;



  max_loop_num = 0;
  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == NOTE
   && ((insn)->fld[4].rtint) == -4)
 max_loop_num++;
    }


  if (max_loop_num == 0)
    return;



  max_uid_for_loop = get_max_uid () + 1 + max_loop_num * 32;

  uid_luid = (int *) 
                    __builtin_alloca((
                    max_uid_for_loop * sizeof (int)
                    ))
                                                            ;
  uid_loop_num = (int *) 
                        __builtin_alloca((
                        max_uid_for_loop * sizeof (int)
                        ))
                                                                ;

  memset ((char *) uid_luid,0,max_uid_for_loop * sizeof (int));
  memset ((char *) uid_loop_num,0,max_uid_for_loop * sizeof (int));



  loop_number_loop_starts = (rtx *) 
                                   __builtin_alloca((
                                   max_loop_num * sizeof (rtx)
                                   ))
                                                                       ;
  loop_number_loop_ends = (rtx *) 
                                 __builtin_alloca((
                                 max_loop_num * sizeof (rtx)
                                 ))
                                                                     ;
  loop_outer_loop = (int *) 
                           __builtin_alloca((
                           max_loop_num * sizeof (int)
                           ))
                                                               ;
  loop_invalid = (char *) 
                         __builtin_alloca((
                         max_loop_num * sizeof (char)
                         ))
                                                              ;
  loop_number_exit_labels = (rtx *) 
                                   __builtin_alloca((
                                   max_loop_num * sizeof (rtx)
                                   ))
                                                                       ;
  loop_number_exit_count = (int *) 
                                  __builtin_alloca((
                                  max_loop_num * sizeof (int)
                                  ))
                                                                      ;



  find_and_verify_loops (f);




  reg_scan (f, max_reg_num (), 1);


  if (get_max_uid () > max_uid_for_loop)
    abort ();







  for (insn = f, i = 0; insn; insn = ((insn)->fld[2].rtx))
    {
      last_insn = insn;
      if (((insn)->code) != NOTE
   || ((insn)->fld[4].rtint) <= 0)
 uid_luid[((insn)->fld[0].rtint)] = ++i;
      else

 uid_luid[((insn)->fld[0].rtint)] = i;
    }

  max_luid = i + 1;






  for (i = 0; i < max_uid_for_loop; i++)
    {
      uid_luid[0] = uid_luid[i];
      if (uid_luid[0] != 0)
 break;
    }
  for (i = 0; i < max_uid_for_loop; i++)
    if (uid_luid[i] == 0)
      uid_luid[i] = uid_luid[i - 1];


  if (flag_unroll_loops && write_symbols != NO_DEBUG)
    find_loop_tree_blocks ();



  for (i = max_loop_num-1; i >= 0; i--)
    if (! loop_invalid[i] && loop_number_loop_ends[i])
      scan_loop (loop_number_loop_starts[i], loop_number_loop_ends[i],
   max_reg_num ());




  if (flag_unroll_loops && write_symbols != NO_DEBUG)
    unroll_block_trees ();
}
static void
scan_loop(rtx loop_start, rtx end, int nregs) asm("_scan_loop");
static void
scan_loop(rtx loop_start, rtx end, int nregs)
{
  register int i;
  register rtx p;

  int maybe_never = 0;


  int call_passed = 0;


  rtx loop_top = 0;

  rtx loop_entry_jump = 0;

  rtx scan_start;

  int insn_count;
  int in_libcall = 0;
  int tem;
  rtx temp;

  rtx set, set1;

  struct n64_tag_movable *movables = 0;

  struct n64_tag_movable *last_movable = 0;




  int threshold;



  rtx *reg_single_usage = 0;

  int loop_depth = 0;

  n_times_set = (short *) 
                         __builtin_alloca((
                         nregs * sizeof (short)
                         ))
                                                        ;
  n_times_used = (short *) 
                          __builtin_alloca((
                          nregs * sizeof (short)
                          ))
                                                         ;
  may_not_optimize = (char *) 
                             __builtin_alloca((
                             nregs
                             ))
                                           ;
  for (p = ((loop_start)->fld[2].rtx);
       p != end
  && ((p)->code) != CODE_LABEL && (rtx_class[(int)(((p)->code))]) != 'i'
  && (((p)->code) != NOTE
      || (((p)->fld[4].rtint) != -4
   && ((p)->fld[4].rtint) != -5));
       p = ((p)->fld[2].rtx))
    ;

  scan_start = p;


  prescan_loop (loop_start, end);
  threshold = (loop_has_call ? 1 : 2) * (1 + n_non_fixed_regs);






  if (((p)->code) == JUMP_INSN)
    {
      loop_entry_jump = p;


      if (simplejump_p (p)
   && ((p)->fld[7].rtx) != 0






   && ((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop
   && (((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) >= (((loop_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_start)->fld[0].rtint)] : (abort (), -1))
   && (((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) < (((end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((end)->fld[0].rtint)] : (abort (), -1)))
 {
   loop_top = next_label (scan_start);
   scan_start = ((p)->fld[7].rtx);
 }
    }
  if (((scan_start)->fld[0].rtint) >= max_uid_for_loop
      || ((scan_start)->code) != CODE_LABEL)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream, "\nLoop from %d to %d is phony.\n\n",
   ((loop_start)->fld[0].rtint), ((end)->fld[0].rtint));
      return;
    }






  memset ((char *) n_times_set,0,nregs * sizeof (short));
  memset (may_not_optimize,0,nregs);

  if (loop_has_call)
    {
      reg_single_usage = (rtx *) 
                                __builtin_alloca((
                                nregs * sizeof (rtx)
                                ))
                                                             ;
      memset ((char *) reg_single_usage,0,nregs * sizeof (rtx));
    }

  count_loop_regs_set (loop_top ? loop_top : loop_start, end,
         may_not_optimize, reg_single_usage, &insn_count, nregs);

  for (i = 0; i < 68; i++)
    may_not_optimize[i] = 1, n_times_set[i] = 1;
  memcpy ((char *) n_times_used,(char *) n_times_set,nregs * sizeof (short));

  if (loop_dump_stream)
    {
      fprintf (loop_dump_stream, "\nLoop from %d to %d: %d real insns.\n",
        ((loop_start)->fld[0].rtint), ((end)->fld[0].rtint), insn_count);
      if (loop_continue)
 fprintf (loop_dump_stream, "Continue at insn %d.\n",
   ((loop_continue)->fld[0].rtint));
    }
  p = scan_start;
  while (1)
    {
      p = ((p)->fld[2].rtx);


      if (p == scan_start)
 break;
      if (p == end)
 {
   if (loop_top != 0)
     p = loop_top;
   else
     break;
   if (p == scan_start)
     break;
 }

      if ((rtx_class[(int)(((p)->code))]) == 'i'
   && find_reg_note (p, REG_LIBCALL, (rtx) 0))
 in_libcall = 1;
      else if ((rtx_class[(int)(((p)->code))]) == 'i'
        && find_reg_note (p, REG_RETVAL, (rtx) 0))
 in_libcall = 0;

      if (((p)->code) == INSN
   && (set = single_set (p))
   && ((((set)->fld[0].rtx))->code) == REG
   && ! may_not_optimize[((((set)->fld[0].rtx))->fld[0].rtint)])
 {
   int tem1 = 0;
   int tem2 = 0;
   int move_insn = 0;
   rtx src = ((set)->fld[1].rtx);
   rtx dependencies = 0;
   temp = find_reg_note (p, REG_EQUIV, (rtx) 0);
   if (temp)
     src = ((temp)->fld[0].rtx), move_insn = 1;
   else
     {
       temp = find_reg_note (p, REG_EQUAL, (rtx) 0);
       if (temp && (((((temp)->fld[0].rtx))->code) == LABEL_REF || ((((temp)->fld[0].rtx))->code) == SYMBOL_REF || ((((temp)->fld[0].rtx))->code) == CONST_INT || ((((temp)->fld[0].rtx))->code) == CONST_DOUBLE || ((((temp)->fld[0].rtx))->code) == CONST || ((((temp)->fld[0].rtx))->code) == HIGH))
  src = ((temp)->fld[0].rtx), move_insn = 1;
       if (temp && find_reg_note (p, REG_RETVAL, (rtx) 0))
  {
    src = ((temp)->fld[0].rtx);



    dependencies = libcall_other_reg (p, src);
  }
     }




   if (((((set)->fld[0].rtx))->fld[0].rtint) >= max_reg_before_loop)
     ;







   else if (! ((! maybe_never
         && ! loop_reg_used_before_p (set, p, loop_start,
          scan_start, end))
        || (! ((((set)->fld[0].rtx))->volatil)
     && ! ((((set)->fld[0].rtx))->in_struct))
        || reg_in_basic_block_p (p, ((set)->fld[0].rtx))))
     ;
   else if ((tem = invariant_p (src))
     && (dependencies == 0
         || (tem2 = invariant_p (dependencies)) != 0)
     && (n_times_set[((((set)->fld[0].rtx))->fld[0].rtint)] == 1
         || (tem1
      = consec_sets_invariant_p (((set)->fld[0].rtx),
            n_times_set[((((set)->fld[0].rtx))->fld[0].rtint)],
            p)))





     && ! ((maybe_never || call_passed)
    && may_trap_p (src)))
     {
       register struct n64_tag_movable *m;
       register int regno = ((((set)->fld[0].rtx))->fld[0].rtint);
       if (reg_single_usage && reg_single_usage[regno] != 0
    && reg_single_usage[regno] != const0_rtx
    && regno_first_uid[regno] == ((p)->fld[0].rtint)
    && (regno_last_uid[regno]
        == ((reg_single_usage[regno])->fld[0].rtint))
    && n_times_set[((((set)->fld[0].rtx))->fld[0].rtint)] == 1
    && ! side_effects_p (((set)->fld[1].rtx))
    && ! find_reg_note (p, REG_RETVAL, (rtx) 0)







    && ! modified_between_p (((set)->fld[1].rtx), p,
        reg_single_usage[regno])
    && no_labels_between_p (p, reg_single_usage[regno])
    && validate_replace_rtx (((set)->fld[0].rtx), ((set)->fld[1].rtx),
        reg_single_usage[regno]))
  {



    ((reg_single_usage[regno])->fld[6].rtx)
      = replace_rtx (((reg_single_usage[regno])->fld[6].rtx),
       ((set)->fld[0].rtx), copy_rtx (((set)->fld[1].rtx)));

    ((p)->code = (NOTE));
    ((p)->fld[4].rtint) = -1;
    ((p)->fld[3].rtstr) = 0;
    n_times_set[regno] = 0;
    continue;
  }

       m = (struct n64_tag_movable *) 
                             __builtin_alloca((
                             sizeof (struct n64_tag_movable)
                             ))
                                                             ;
       m->next = 0;
       m->insn = p;
       m->set_src = src;
       m->dependencies = dependencies;
       m->set_dest = ((set)->fld[0].rtx);
       m->force = 0;
       m->consec = n_times_set[((((set)->fld[0].rtx))->fld[0].rtint)] - 1;
       m->done = 0;
       m->forces = 0;
       m->partial = 0;
       m->move_insn = move_insn;
       m->is_equiv = (find_reg_note (p, REG_EQUIV, (rtx) 0) != 0);
       m->savemode = VOIDmode;
       m->regno = regno;


       m->cond = ((tem | tem1 | tem2) > 1);
       m->global = (uid_luid[regno_last_uid[regno]] > (((end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((end)->fld[0].rtint)] : (abort (), -1))
      || uid_luid[regno_first_uid[regno]] < (((loop_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_start)->fld[0].rtint)] : (abort (), -1)));
       m->match = 0;
       m->lifetime = (uid_luid[regno_last_uid[regno]]
        - uid_luid[regno_first_uid[regno]]);
       m->savings = n_times_used[regno];
       if (find_reg_note (p, REG_RETVAL, (rtx) 0))
  m->savings += libcall_benefit (p);
       n_times_set[regno] = move_insn ? -2 : -1;

       if (movables == 0)
  movables = m;
       else
  last_movable->next = m;
       last_movable = m;

       if (m->consec > 0)
  {

    p = next_nonnote_insn (p);

    p = skip_consec_insns (p, m->consec);

    p = prev_nonnote_insn (p);




    temp = find_reg_note (p, REG_EQUIV, (rtx) 0);
    if (temp)
      m->set_src = ((temp)->fld[0].rtx), m->move_insn = 1;
    else
      {
        temp = find_reg_note (p, REG_EQUAL, (rtx) 0);
        if (temp && (((((temp)->fld[0].rtx))->code) == LABEL_REF || ((((temp)->fld[0].rtx))->code) == SYMBOL_REF || ((((temp)->fld[0].rtx))->code) == CONST_INT || ((((temp)->fld[0].rtx))->code) == CONST_DOUBLE || ((((temp)->fld[0].rtx))->code) == CONST || ((((temp)->fld[0].rtx))->code) == HIGH))
   m->set_src = ((temp)->fld[0].rtx), m->move_insn = 1;
        else
   m->move_insn = 0;

      }
    m->is_equiv = (find_reg_note (p, REG_EQUIV, (rtx) 0) != 0);
  }
     }







   else if (((set)->fld[1].rtx) == const0_rtx
     && ((((p)->fld[2].rtx))->code) == INSN
     && (set1 = single_set (((p)->fld[2].rtx)))
     && ((set1)->code) == SET
     && (((((set1)->fld[0].rtx))->code) == STRICT_LOW_PART)
     && (((((((set1)->fld[0].rtx))->fld[0].rtx))->code) == SUBREG)
     && (((((((set1)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx)
         == ((set)->fld[0].rtx))
     && !reg_mentioned_p (((set)->fld[0].rtx), ((set1)->fld[1].rtx)))
     {
       register int regno = ((((set)->fld[0].rtx))->fld[0].rtint);
       if (n_times_set[regno] == 2)
  {
    register struct n64_tag_movable *m;
    m = (struct n64_tag_movable *) 
                          __builtin_alloca((
                          sizeof (struct n64_tag_movable)
                          ))
                                                          ;
    m->next = 0;
    m->insn = p;
    m->set_dest = ((set)->fld[0].rtx);
    m->dependencies = 0;
    m->force = 0;
    m->consec = 0;
    m->done = 0;
    m->forces = 0;
    m->move_insn = 0;
    m->partial = 1;
    m->global = (((p)->fld[0].rtint) >= max_uid_for_loop
          || (uid_luid[regno_last_uid[regno]]
       > (((end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((end)->fld[0].rtint)] : (abort (), -1)))
          || (uid_luid[regno_first_uid[regno]]
       < (((p)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((p)->fld[0].rtint)] : (abort (), -1)))
          || (labels_in_range_p
       (p, uid_luid[regno_first_uid[regno]])));
    if (maybe_never && m->global)
      m->savemode = ((((set1)->fld[1].rtx))->mode);
    else
      m->savemode = VOIDmode;
    m->regno = regno;
    m->cond = 0;
    m->match = 0;
    m->lifetime = (uid_luid[regno_last_uid[regno]]
     - uid_luid[regno_first_uid[regno]]);
    m->savings = 1;
    n_times_set[regno] = -1;

    if (movables == 0)
      movables = m;
    else
      last_movable->next = m;
    last_movable = m;
  }
     }
 }




      else if (((p)->code) == CALL_INSN && ! in_libcall)
 call_passed = 1;







      else if ((((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN)





               && ! (((p)->code) == JUMP_INSN && ((p)->fld[7].rtx) == loop_top
       && ((((p)->fld[2].rtx))->fld[2].rtx) == end
       && simplejump_p (p)))
 maybe_never = 1;
      else if (((p)->code) == NOTE)
 {



   if (((p)->fld[4].rtint) == -9 && loop_depth == 0)
     maybe_never = call_passed = 0;
   else if (((p)->fld[4].rtint) == -4)
     loop_depth++;
   else if (((p)->fld[4].rtint) == -5)
     loop_depth--;
 }
    }



  ignore_some_movables (movables);






  force_movables (movables);






  combine_movables (movables, nregs);




  move_movables (movables, threshold,
   insn_count, loop_start, end, nregs);



  for (i = 0; i < nregs; i++)
    if (n_times_set[i] < 0)
      n_times_set[i] = n_times_used[i];

  if (flag_strength_reduce)
    strength_reduce (scan_start, end, loop_top,
       insn_count, loop_start, end);
}




void
record_excess_regs(rtx in_this, rtx not_in_this, rtx *output) asm("_record_excess_regs");
void
record_excess_regs(rtx in_this, rtx not_in_this, rtx *output)
{
  n64_enum_rtx_code code;
  char *fmt;
  int i;

  code = ((in_this)->code);

  switch (code)
    {
    case PC:
    case CC0:
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
      return;

    case REG:
      if (((in_this)->fld[0].rtint) >= 68
   && ! reg_mentioned_p (in_this, not_in_this))
 *output = gen_rtx (EXPR_LIST, VOIDmode, in_this, *output);
      return;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      int j;

      switch (fmt[i])
 {
 case 'E':
   for (j = 0; j < ((in_this)->fld[i].rtvec->num_elem); j++)
     record_excess_regs (((in_this)->fld[i].rtvec->elem[j].rtx), not_in_this, output);
   break;

 case 'e':
   record_excess_regs (((in_this)->fld[i].rtx), not_in_this, output);
   break;
 }
    }
}






static rtx
libcall_other_reg(rtx insn, rtx equiv) asm("_libcall_other_reg");
static rtx
libcall_other_reg(rtx insn, rtx equiv)
{
  rtx note = find_reg_note (insn, REG_RETVAL, (rtx) 0);
  rtx p = ((note)->fld[0].rtx);
  rtx output = 0;




  while (p != insn)
    {
      if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
   || ((p)->code) == CALL_INSN)
 record_excess_regs (((p)->fld[3].rtx), equiv, &output);
      p = ((p)->fld[2].rtx);
    }

  return output;
}




static int
reg_in_basic_block_p(rtx insn, rtx reg) asm("_reg_in_basic_block_p");
static int
reg_in_basic_block_p(rtx insn, rtx reg)
{
  int regno = ((reg)->fld[0].rtint);
  rtx p;

  if (regno_first_uid[regno] != ((insn)->fld[0].rtint))
    return 0;


  for (p = insn; p; p = ((p)->fld[2].rtx))
    {
      switch (((p)->code))
 {
 case NOTE:
   break;

 case INSN:
 case CALL_INSN:

   if (regno_last_uid[regno] == ((p)->fld[0].rtint))
     return 1;
   break;

 case JUMP_INSN:

   if (regno_last_uid[regno] == ((p)->fld[0].rtint))
     return 1;

   return 0;

 case CODE_LABEL:
 case BARRIER:

   return 0;
 }
    }


  abort ();
}





static int
libcall_benefit(rtx last) asm("_libcall_benefit");
static int
libcall_benefit(rtx last)
{
  rtx insn;
  int benefit = 0;

  for (insn = ((find_reg_note (last, REG_RETVAL, (rtx) 0))->fld[0].rtx);
       insn != last; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == CALL_INSN)
 benefit += 10;

      else if (((insn)->code) == INSN
        && ((((insn)->fld[3].rtx))->code) != USE
        && ((((insn)->fld[3].rtx))->code) != CLOBBER)
 benefit++;
    }

  return benefit;
}



static rtx
skip_consec_insns(rtx insn, int count) asm("_skip_consec_insns");
static rtx
skip_consec_insns(rtx insn, int count)
{
  for (; count > 0; count--)
    {
      rtx temp;




      if (((insn)->code) != NOTE
   && (temp = find_reg_note (insn, REG_LIBCALL, (rtx) 0)))
 insn = ((temp)->fld[0].rtx);

      do insn = ((insn)->fld[2].rtx);
      while (((insn)->code) == NOTE);
    }

  return insn;
}






static void
ignore_some_movables(struct n64_tag_movable *movables) asm("_ignore_some_movables");
static void
ignore_some_movables(struct n64_tag_movable *movables)
{
  register struct n64_tag_movable *m, *m1;

  for (m = movables; m; m = m->next)
    {

      rtx note = find_reg_note (m->insn, REG_RETVAL, (rtx) 0);
      if (note)
 {
   rtx insn;






   for (insn = ((note)->fld[0].rtx); insn != m->insn; insn = ((insn)->fld[2].rtx))
     for (m1 = movables; m1 != m; m1 = m1->next)
       if (m1->insn == insn)
  m1->done = 1;
 }
    }
}






static void
force_movables(struct n64_tag_movable *movables) asm("_force_movables");
static void
force_movables(struct n64_tag_movable *movables)
{
  register struct n64_tag_movable *m, *m1;
  for (m1 = movables; m1; m1 = m1->next)

    if (!m1->partial && !m1->done)
      {
 int regno = m1->regno;
 for (m = m1->next; m; m = m->next)






   if (((m->insn)->fld[0].rtint) == regno_last_uid[regno]
       && !m->done)
     break;
 if (m != 0 && m->set_src == m1->set_dest

     && m->consec == 0)
   m = 0;



 if (m != 0)
   {
     m->forces = m1;
     m1->lifetime += m->lifetime;
     m1->savings += m1->savings;
   }
      }
}




static void
combine_movables(struct n64_tag_movable *movables, int nregs) asm("_combine_movables");
static void
combine_movables(struct n64_tag_movable *movables, int nregs)
{
  register struct n64_tag_movable *m;
  char *matched_regs = (char *) 
                               __builtin_alloca((
                               nregs
                               ))
                                             ;
  n64_enum_machine_mode mode;





  for (m = movables; m; m = m->next)
    if (m->match == 0 && n_times_used[m->regno] == 1 && !m->partial)
      {
 register struct n64_tag_movable *m1;
 int regno = m->regno;

 memset (matched_regs,0,nregs);
 matched_regs[regno] = 1;

 for (m1 = movables; m1; m1 = m1->next)
   if (m != m1 && m1->match == 0 && n_times_used[m1->regno] == 1

       && !m1->global

       && !m1->partial
       && (matched_regs[m1->regno]
    ||
    (







     (((m->set_dest)->mode) == ((m1->set_dest)->mode)
      || ((mode_class[(int)(((m->set_dest)->mode))]) == MODE_INT
   && (mode_class[(int)(((m1->set_dest)->mode))]) == MODE_INT
   && ((8 * mode_size[(int)(((m->set_dest)->mode))])
       >= (8 * mode_size[(int)(((m1->set_dest)->mode))]))))

     && ((((m1->set_src)->code) == REG
   && matched_regs[((m1->set_src)->fld[0].rtint)])
         || rtx_equal_for_loop_p (m->set_src, m1->set_src,
      movables))))
       && ((m->dependencies == m1->dependencies)
    || rtx_equal_p (m->dependencies, m1->dependencies)))
     {
       m->lifetime += m1->lifetime;
       m->savings += m1->savings;
       m1->done = 1;
       m1->match = m;
       matched_regs[m1->regno] = 1;
     }
      }





  for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    {
      register struct n64_tag_movable *m0 = 0;



      for (m = movables; m; m = m->next)
 if (m->partial && ! m->global
     && mode == ((((((((m->insn)->fld[2].rtx))->fld[3].rtx))->fld[1].rtx))->mode))
   {
     register struct n64_tag_movable *m1;
     int first = uid_luid[regno_first_uid[m->regno]];
     int last = uid_luid[regno_last_uid[m->regno]];

     if (m0 == 0)
       {

  m0 = m;
    continue;
       }



     if (((m->set_dest)->mode) != ((m0->set_dest)->mode))
  continue;



     for (m1 = movables; m1 != m; m1 = m1->next)
       if (m1 == m0 || (m1->partial && m1->match == m0))
  if (! (uid_luid[regno_first_uid[m1->regno]] > last
         || uid_luid[regno_last_uid[m1->regno]] < first))
    goto overlap;


     m0->lifetime += m->lifetime;
     m0->savings += m->savings;
     m->done = 1;
     m->match = m0;

   overlap: ;
   }
    }
}



static int
regs_match_p(rtx x, rtx y, struct n64_tag_movable *movables) asm("_regs_match_p");
static int
regs_match_p(rtx x, rtx y, struct n64_tag_movable *movables)
{
  int xn = ((x)->fld[0].rtint);
  int yn = ((y)->fld[0].rtint);
  struct n64_tag_movable *mx, *my;

  for (mx = movables; mx; mx = mx->next)
    if (mx->regno == xn)
      break;

  for (my = movables; my; my = my->next)
    if (my->regno == yn)
      break;

  return (mx && my
   && ((mx->match == my->match && mx->match != 0)
       || mx->match == my
       || mx == my->match));
}







static int
rtx_equal_for_loop_p(rtx x, rtx y, struct n64_tag_movable *movables) asm("_rtx_equal_for_loop_p");
static int
rtx_equal_for_loop_p(rtx x, rtx y, struct n64_tag_movable *movables)
{
  register int i;
  register int j;
  register struct n64_tag_movable *m;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == y)
    return 1;
  if (x == 0 || y == 0)
    return 0;

  code = ((x)->code);



  if (((x)->code) == REG && n_times_set[((x)->fld[0].rtint)] == -2
      && (((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH))
    for (m = movables; m; m = m->next)
      if (m->move_insn && m->regno == ((x)->fld[0].rtint)
   && rtx_equal_p (m->set_src, y))
 return 1;

  else if (((y)->code) == REG && n_times_set[((y)->fld[0].rtint)] == -2
    && (((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    for (m = movables; m; m = m->next)
      if (m->move_insn && m->regno == ((y)->fld[0].rtint)
   && rtx_equal_p (m->set_src, x))
 return 1;


  if (code != ((y)->code))
    return 0;




  if (((x)->mode) != ((y)->mode))
    return 0;


  if (code == REG)
    return (((x)->fld[0].rtint) == ((y)->fld[0].rtint) || regs_match_p (x, y, movables));

  if (code == LABEL_REF)
    return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);
  if (code == SYMBOL_REF)
    return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'E':

   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;


   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (rtx_equal_for_loop_p (((x)->fld[i].rtvec->elem[j].rtx), ((y)->fld[i].rtvec->elem[j].rtx), movables) == 0)
       return 0;
   break;

 case 'e':
   if (rtx_equal_for_loop_p (((x)->fld[i].rtx), ((y)->fld[i].rtx), movables) == 0)
     return 0;
   break;

 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'u':

   break;

 case '0':
   break;




 default:
   abort ();
 }
    }
  return 1;
}




static void
add_label_notes(rtx x, rtx insns) asm("_add_label_notes");
static void
add_label_notes(rtx x, rtx insns)
{
  n64_enum_rtx_code code = ((x)->code);
  int i, j;
  char *fmt;
  rtx insn;

  if (code == LABEL_REF && !((x)->volatil))
    {
      rtx next = next_real_insn (((x)->fld[0].rtx));




      if (next == 0
   || ! (((next)->code) == JUMP_INSN
  && (((((next)->fld[3].rtx))->code) == ADDR_VEC
      || ((((next)->fld[3].rtx))->code) == ADDR_DIFF_VEC)))
 {
   for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
     if (reg_mentioned_p (((x)->fld[0].rtx), insn))
       ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_LABEL, ((x)->fld[0].rtx),
       ((insn)->fld[6].rtx));
 }
      return;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 add_label_notes (((x)->fld[i].rtx), insns);
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   add_label_notes (((x)->fld[i].rtvec->elem[j].rtx), insns);
    }
}





static void
move_movables(struct n64_tag_movable *movables, int threshold, int insn_count, rtx loop_start, rtx end, int nregs) asm("_move_movables");
static void
move_movables(struct n64_tag_movable *movables, int threshold, int insn_count, rtx loop_start, rtx end, int nregs)
{
  rtx new_start = 0;
  register struct n64_tag_movable *m;
  register rtx p;



  rtx *reg_map = (rtx *) 
                        __builtin_alloca((
                        nregs * sizeof (rtx)
                        ))
                                                     ;
  char *already_moved = (char *) 
                                __builtin_alloca((
                                nregs
                                ))
                                              ;

  memset (already_moved,0,nregs);
  memset ((char *) reg_map,0,nregs * sizeof (rtx));

  num_movables = 0;

  for (m = movables; m; m = m->next)
    {


      if (loop_dump_stream)
 {
   fprintf (loop_dump_stream, "Insn %d: regno %d (life %d), ",
     ((m->insn)->fld[0].rtint), m->regno, m->lifetime);
   if (m->consec > 0)
     fprintf (loop_dump_stream, "consec %d, ", m->consec);
   if (m->cond)
     fprintf (loop_dump_stream, "cond ");
   if (m->force)
     fprintf (loop_dump_stream, "force ");
   if (m->global)
     fprintf (loop_dump_stream, "global ");
   if (m->done)
     fprintf (loop_dump_stream, "done ");
   if (m->move_insn)
     fprintf (loop_dump_stream, "move-insn ");
   if (m->match)
     fprintf (loop_dump_stream, "matches %d ",
       ((m->match->insn)->fld[0].rtint));
   if (m->forces)
     fprintf (loop_dump_stream, "forces %d ",
       ((m->forces->insn)->fld[0].rtint));
 }


      num_movables++;




      if (!m->done
   && (! m->cond
       || (1 == invariant_p (m->set_src)
    && (m->dependencies == 0
        || 1 == invariant_p (m->dependencies))
    && (m->consec == 0
        || 1 == consec_sets_invariant_p (m->set_dest,
             m->consec + 1,
             m->insn))))
   && (! m->forces || m->forces->done))
 {
   register int regno;
   register rtx p;
   int savings = m->savings;




   p = m->insn;
   regno = m->regno;

   if (loop_dump_stream)
     fprintf (loop_dump_stream, "savings %d ", savings);

   if (moved_once[regno])
     {
       insn_count *= 2;

       if (loop_dump_stream)
  fprintf (loop_dump_stream, "halved since already moved ");
     }
   if (already_moved[regno]
       || (threshold * savings * m->lifetime) >= insn_count
       || (m->forces && m->forces->done
    && n_times_used[m->forces->regno] == 1))
     {
       int count;
       register struct n64_tag_movable *m1;
       rtx first;



       if (m->partial && m->match)
  {
    rtx newpat, i1;
    rtx r1, r2;




    for (m1 = m; m1->match; m1 = m1->match);
    newpat = gen_move_insn (((((m->insn)->fld[3].rtx))->fld[0].rtx),
       ((((m1->insn)->fld[3].rtx))->fld[0].rtx));
    i1 = emit_insn_before (newpat, loop_start);



    ((i1)->fld[6].rtx) = ((m->insn)->fld[6].rtx);
    r1 = ((((m->insn)->fld[3].rtx))->fld[0].rtx);
    r2 = ((((m1->insn)->fld[3].rtx))->fld[0].rtx);
    regs_may_share = gen_rtx (EXPR_LIST, VOIDmode, r1,
         gen_rtx (EXPR_LIST, VOIDmode, r2,
           regs_may_share));
    delete_insn (m->insn);

    if (new_start == 0)
      new_start = i1;

    if (loop_dump_stream)
      fprintf (loop_dump_stream, " moved to %d", ((i1)->fld[0].rtint));
  }



       else if (m->move_insn)
  {
    rtx i1, temp;

    for (count = m->consec; count >= 0; count--)
      {


        if (((p)->code) != NOTE
     && (temp = find_reg_note (p, REG_LIBCALL, (rtx) 0)))
   p = ((temp)->fld[0].rtx);




        if (((p)->code) != NOTE
     && (temp = find_reg_note (p, REG_RETVAL, (rtx) 0)))
   {
     temp = ((temp)->fld[0].rtx);
     while (temp != p)
       temp = delete_insn (temp);
   }

        p = delete_insn (p);
        while (p && ((p)->code) == NOTE)
   p = ((p)->fld[2].rtx);
      }

    start_sequence ();
    emit_move_insn (m->set_dest, m->set_src);
    temp = get_insns ();
    end_sequence ();

    add_label_notes (m->set_src, temp);

    i1 = emit_insns_before (temp, loop_start);
    if (! find_reg_note (i1, REG_EQUAL, (rtx) 0))
      ((i1)->fld[6].rtx)
        = gen_rtx (EXPR_LIST,
     m->is_equiv ? REG_EQUIV : REG_EQUAL,
     m->set_src, ((i1)->fld[6].rtx));

    if (loop_dump_stream)
      fprintf (loop_dump_stream, " moved to %d", ((i1)->fld[0].rtint));


    threshold -= 3;
  }
       else
  {
    for (count = m->consec; count >= 0; count--)
      {
        rtx i1, temp;




        if (((p)->code) != NOTE
     && (temp = find_reg_note (p, REG_LIBCALL, (rtx) 0)))
   p = ((temp)->fld[0].rtx);




        if (((p)->code) != NOTE
     && (temp = find_reg_note (p, REG_RETVAL, (rtx) 0)))
   {
     rtx fn_address = 0;
     rtx fn_reg = 0;
     rtx fn_address_insn = 0;

     first = 0;
     for (temp = ((temp)->fld[0].rtx); temp != p;
          temp = ((temp)->fld[2].rtx))
       {
         rtx body;
         rtx n;
         rtx next;

         if (((temp)->code) == NOTE)
    continue;

         body = ((temp)->fld[3].rtx);



         for (next = ((temp)->fld[2].rtx); next != p;
       next = ((next)->fld[2].rtx))
    if (! (((next)->code) == INSN
           && ((((next)->fld[3].rtx))->code) == USE)
        && ((next)->code) != NOTE)
      break;
         if (((next)->code) == CALL_INSN
      && ((body)->code) == SET
      && ((((body)->fld[0].rtx))->code) == REG
      && (n = find_reg_note (temp, REG_EQUAL,
        (rtx) 0)))
    {
      fn_reg = ((body)->fld[1].rtx);
      if (((fn_reg)->code) != REG)
        fn_reg = ((body)->fld[0].rtx);
      fn_address = ((n)->fld[0].rtx);
      fn_address_insn = temp;
    }



         if (((temp)->code) == CALL_INSN
      && fn_address != 0
      && reg_referenced_p (fn_reg, body))
    emit_insn_after (gen_move_insn (fn_reg,
        fn_address),
       fn_address_insn);

         if (((temp)->code) == CALL_INSN)
    {
      i1 = emit_call_insn_before (body, loop_start);



      if (((temp)->fld[7].rtx))
        ((i1)->fld[7].rtx) =
          copy_rtx (((temp)->fld[7].rtx));
    }
         else
    i1 = emit_insn_before (body, loop_start);
         if (first == 0)
    first = i1;
         if (temp == fn_address_insn)
    fn_address_insn = i1;
         ((i1)->fld[6].rtx) = ((temp)->fld[6].rtx);
         delete_insn (temp);
       }
   }
        if (m->savemode != VOIDmode)
   {



     rtx reg = m->set_dest;
     rtx sequence;
     rtx tem;

     start_sequence ();
     tem = expand_binop
       (((reg)->mode), and_optab, reg,
        gen_rtx (CONST_INT, VOIDmode, (int) ((((int) 1 << (8 * mode_size[(int)(m->savemode)]))) - 1))

              ,
        reg, 1, OPTAB_LIB_WIDEN);
     if (tem == 0)
       abort ();
     if (tem != reg)
       emit_move_insn (reg, tem);
     sequence = gen_sequence ();
     end_sequence ();
     i1 = emit_insn_before (sequence, loop_start);
   }
        else if (((p)->code) == CALL_INSN)
   {
     i1 = emit_call_insn_before (((p)->fld[3].rtx), loop_start);



     if (((p)->fld[7].rtx))
       ((i1)->fld[7].rtx) =
         copy_rtx (((p)->fld[7].rtx));
   }
        else
   i1 = emit_insn_before (((p)->fld[3].rtx), loop_start);

        ((i1)->fld[6].rtx) = ((p)->fld[6].rtx);







        if ((temp = find_reg_note (i1, REG_EQUAL, (rtx) 0))
     && ! invariant_p (((temp)->fld[0].rtx)))
   remove_note (i1, temp);

        if (new_start == 0)
   new_start = i1;

        if (loop_dump_stream)
   fprintf (loop_dump_stream, " moved to %d",
     ((i1)->fld[0].rtint));
        if (temp = find_reg_note (i1, REG_RETVAL, (rtx) 0))
   {
     ((temp)->fld[0].rtx) = first;
     temp = find_reg_note (first, REG_LIBCALL, (rtx) 0);
     ((temp)->fld[0].rtx) = i1;
   }

        delete_insn (p);
        do p = ((p)->fld[2].rtx);
        while (p && ((p)->code) == NOTE);
      }


    threshold -= 3;
  }



       already_moved[regno] = 1;


       moved_once[regno] = 1;


       if (! m->partial)
  n_times_set[regno] = 0;

       m->done = 1;





       if (uid_luid[regno_first_uid[regno]] > (((loop_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_start)->fld[0].rtint)] : (abort (), -1)))



  regno_first_uid[regno] = ((loop_start)->fld[0].rtint);
       if (uid_luid[regno_last_uid[regno]] < (((end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((end)->fld[0].rtint)] : (abort (), -1)))
  regno_last_uid[regno] = ((end)->fld[0].rtint);



       if (! m->partial)
  for (m1 = movables; m1; m1 = m1->next)
    if (m1->match == m)
      {
        rtx temp;





        if (((m->set_dest)->mode) == ((m1->set_dest)->mode))
   reg_map[m1->regno] = m->set_dest;
        else
   reg_map[m1->regno]
     = gen_lowpart_common (((m1->set_dest)->mode),
      m->set_dest);



        m1->done = 1;



        if (temp = find_reg_note (m1->insn, REG_RETVAL,
      (rtx) 0))
   {
     for (temp = ((temp)->fld[0].rtx); temp != m1->insn;
          temp = ((temp)->fld[2].rtx))
       delete_insn (temp);
   }
        delete_insn (m1->insn);



        already_moved[m1->regno] = 1;



        if (! m->partial)
   n_times_set[m1->regno] = 0;
      }
     }
   else if (loop_dump_stream)
     fprintf (loop_dump_stream, "not desirable");
 }
      else if (loop_dump_stream && !m->match)
 fprintf (loop_dump_stream, "not safe");

      if (loop_dump_stream)
 fprintf (loop_dump_stream, "\n");
    }

  if (new_start == 0)
    new_start = loop_start;



  for (p = new_start; p != end; p = ((p)->fld[2].rtx))
    if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
 || ((p)->code) == CALL_INSN)
      {
 replace_regs (((p)->fld[3].rtx), reg_map, nregs, 0);
 replace_regs (((p)->fld[6].rtx), reg_map, nregs, 0);
 ((p)->fld[4].rtint) = -1;
      }
}
static int
count_nonfixed_reads(rtx x) asm("_count_nonfixed_reads");
static int
count_nonfixed_reads(rtx x)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;
  int value;

  if (x == 0)
    return 0;

  code = ((x)->code);
  switch (code)
    {
    case PC:
    case CC0:
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
    case REG:
      return 0;

    case MEM:
      return ((invariant_p (((x)->fld[0].rtx)) != 1)
       + count_nonfixed_reads (((x)->fld[0].rtx)));
    }

  value = 0;
  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 value += count_nonfixed_reads (((x)->fld[i].rtx));
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     value += count_nonfixed_reads (((x)->fld[i].rtvec->elem[j].rtx));
 }
    }
  return value;
}
static void
prescan_loop(rtx start, rtx end) asm("_prescan_loop");
static void
prescan_loop(rtx start, rtx end)
{
  register int level = 1;
  register rtx insn;

  unknown_address_altered = 0;
  loop_has_call = 0;
  loop_has_volatile = 0;
  loop_store_mems_idx = 0;

  num_mem_sets = 0;
  loops_enclosed = 1;
  loop_continue = 0;

  for (insn = ((start)->fld[2].rtx); insn != ((end)->fld[2].rtx);
       insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == NOTE)
 {
   if (((insn)->fld[4].rtint) == -4)
     {
       ++level;

       loops_enclosed++;
     }
   else if (((insn)->fld[4].rtint) == -5)
     {
       --level;
       if (level == 0)
  {
    end = insn;
    break;
  }
     }
   else if (((insn)->fld[4].rtint) == -8)
     {
       if (level == 1)
  loop_continue = insn;
     }
 }
      else if (((insn)->code) == CALL_INSN)
 {
   unknown_address_altered = 1;
   loop_has_call = 1;
 }
      else
 {
   if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN)
     {
       if (volatile_refs_p (((insn)->fld[3].rtx)))
  loop_has_volatile = 1;

       note_stores (((insn)->fld[3].rtx), note_addr_stored);
     }
 }
    }
}





static void
find_and_verify_loops(rtx f) asm("_find_and_verify_loops");
static void
find_and_verify_loops(rtx f)
{
  rtx insn, label;
  int current_loop = -1;
  int next_loop = -1;
  int loop;




  uid_loop_num[0] = -1;




  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == NOTE)
 switch (((insn)->fld[4].rtint))
   {
   case -4:
     loop_number_loop_starts[++next_loop] = insn;
     loop_number_loop_ends[next_loop] = 0;
     loop_outer_loop[next_loop] = current_loop;
     loop_invalid[next_loop] = 0;
     loop_number_exit_labels[next_loop] = 0;
     loop_number_exit_count[next_loop] = 0;
     current_loop = next_loop;
     break;

   case -7:


     for (loop = current_loop; loop != -1; loop = loop_outer_loop[loop])
       {
  loop_invalid[loop] = 1;
  if (loop_dump_stream)
    fprintf (loop_dump_stream,
      "\nLoop at %d ignored due to setjmp.\n",
      ((loop_number_loop_starts[loop])->fld[0].rtint));
       }
     break;

   case -5:
     if (current_loop == -1)
       abort ();

     loop_number_loop_ends[current_loop] = insn;
     current_loop = loop_outer_loop[current_loop];
     break;

   }



      uid_loop_num[((insn)->fld[0].rtint)] = current_loop;
    }




  for (label = forced_labels; label; label = ((label)->fld[1].rtx))
    {
      int loop_num;

      for (loop_num = uid_loop_num[((((label)->fld[0].rtx))->fld[0].rtint)];
    loop_num != -1;
    loop_num = loop_outer_loop[loop_num])
 loop_invalid[loop_num] = 1;
    }
  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i')
      {
 int this_loop_num = uid_loop_num[((insn)->fld[0].rtint)];

 if (((insn)->code) == INSN || ((insn)->code) == CALL_INSN)
   {
     rtx note = find_reg_note (insn, REG_LABEL, (rtx) 0);
     if (note)
       {
  int loop_num;

  for (loop_num = uid_loop_num[((((note)->fld[0].rtx))->fld[0].rtint)];
       loop_num != -1;
       loop_num = loop_outer_loop[loop_num])
    loop_invalid[loop_num] = 1;
       }
   }

 if (((insn)->code) != JUMP_INSN)
   continue;

 mark_loop_jump (((insn)->fld[3].rtx), this_loop_num);


 if (this_loop_num != -1
     && (((((insn)->fld[3].rtx))->code) == RETURN
  || (simplejump_p (insn)
      && (uid_loop_num[((((insn)->fld[7].rtx))->fld[0].rtint)]
   != this_loop_num)))
     && get_max_uid () < max_uid_for_loop)
   {
     rtx p;
     rtx our_next = next_real_insn (insn);
     int dest_loop;
     int outer_loop = -1;



     for (p = ((insn)->fld[1].rtx);
   ((p)->code) != CODE_LABEL
   && ! (((p)->code) == NOTE
         && ((p)->fld[4].rtint) == -4)
   && ((p)->code) != JUMP_INSN;
   p = ((p)->fld[1].rtx))
       ;




     if (((insn)->fld[7].rtx))
       {
  dest_loop = uid_loop_num[((((insn)->fld[7].rtx))->fld[0].rtint)];
  if (dest_loop != -1)
    {
      for (outer_loop = dest_loop; outer_loop != -1;
    outer_loop = loop_outer_loop[outer_loop])
        if (outer_loop == this_loop_num)
   break;
    }
       }



     if (((p)->code) == JUMP_INSN && ((p)->fld[7].rtx)
  && uid_loop_num[((((p)->fld[7].rtx))->fld[0].rtint)] != this_loop_num)
       outer_loop = this_loop_num;
     if (outer_loop == -1
  && ((p)->code) == JUMP_INSN
  && ((p)->fld[7].rtx) != 0


  && ((((p)->fld[7].rtx))->fld[0].rtint) != 0
  && condjump_p (p)
  && ! simplejump_p (p)
  && next_real_insn (((p)->fld[7].rtx)) == our_next)
       {
  rtx target
    = ((insn)->fld[7].rtx) ? ((insn)->fld[7].rtx) : get_last_insn ();
  int target_loop_num = uid_loop_num[((target)->fld[0].rtint)];
  rtx loc;

  for (loc = target; loc; loc = ((loc)->fld[1].rtx))
    if (((loc)->code) == BARRIER
        && uid_loop_num[((loc)->fld[0].rtint)] == target_loop_num)
      break;

  if (loc == 0)
    for (loc = target; loc; loc = ((loc)->fld[2].rtx))
      if (((loc)->code) == BARRIER
   && uid_loop_num[((loc)->fld[0].rtint)] == target_loop_num)
        break;

  if (loc)
    {
      rtx cond_label = ((p)->fld[7].rtx);
      rtx new_label = get_label_after (p);


      ((cond_label)->fld[5].rtint)++;



     if (invert_jump (p, new_label))
       {
         rtx q, r;



         new_label = squeeze_notes (new_label, ((insn)->fld[2].rtx));
         reorder_insns (new_label, ((insn)->fld[2].rtx), loc);


         for (q = new_label; q != ((((insn)->fld[2].rtx))->fld[2].rtx);
       q = ((q)->fld[2].rtx))
    uid_loop_num[((q)->fld[0].rtint)] = target_loop_num;






         if (((insn)->fld[7].rtx))
    {
      int loop_num;

      for (q = 0,
    r = loop_number_exit_labels[this_loop_num];
    r; q = r, r = ((r)->fld[1].rtx))
        if (((r)->fld[0].rtx) == ((insn)->fld[7].rtx))
          {
     ((r)->in_struct) = 0;
     if (q)
       ((q)->fld[1].rtx) = ((r)->fld[1].rtx);
     else
       loop_number_exit_labels[this_loop_num]
         = ((r)->fld[1].rtx);
     break;
          }

      for (loop_num = this_loop_num;
    loop_num != -1 && loop_num != target_loop_num;
    loop_num = loop_outer_loop[loop_num])
        loop_number_exit_count[loop_num]--;


      if (! r)
        abort ();
    }





         mark_loop_jump (((p)->fld[3].rtx), this_loop_num);



         if (((insn)->fld[7].rtx) != 0
      && (next_real_insn (((insn)->fld[7].rtx))
          == next_real_insn (insn)))
    delete_insn (insn);
       }





      insn = ((cond_label)->fld[2].rtx);

      if (--((cond_label)->fld[5].rtint) == 0)
        delete_insn (cond_label);


      insn = ((insn)->fld[1].rtx);
    }
       }
   }
      }
}






static void
mark_loop_jump(rtx x, int loop_num) asm("_mark_loop_jump");
static void
mark_loop_jump(rtx x, int loop_num)
{
  int dest_loop;
  int outer_loop;
  int i;

  switch (((x)->code))
    {
    case PC:
    case USE:
    case CLOBBER:
    case REG:
    case MEM:
    case CONST_INT:
    case CONST_DOUBLE:
    case RETURN:
      return;

    case CONST:

      mark_loop_jump (((x)->fld[0].rtx), loop_num);
      return;

    case PLUS:
    case MINUS:
    case MULT:
      mark_loop_jump (((x)->fld[0].rtx), loop_num);
      mark_loop_jump (((x)->fld[1].rtx), loop_num);
      return;

    case SIGN_EXTEND:
    case ZERO_EXTEND:
      mark_loop_jump (((x)->fld[0].rtx), loop_num);
      return;

    case LABEL_REF:
      dest_loop = uid_loop_num[((((x)->fld[0].rtx))->fld[0].rtint)];
      if (dest_loop != -1)
 {
   for (outer_loop = dest_loop; outer_loop != -1;
        outer_loop = loop_outer_loop[outer_loop])
     if (outer_loop == loop_num)
       break;
 }
      else
 outer_loop = -1;

      if (loop_num != -1 && outer_loop == -1)
 {
   ((x)->in_struct) = 1;
   ((x)->fld[1].rtx) = loop_number_exit_labels[loop_num];
   loop_number_exit_labels[loop_num] = x;

   for (outer_loop = loop_num;
        outer_loop != -1 && outer_loop != dest_loop;
        outer_loop = loop_outer_loop[outer_loop])
     loop_number_exit_count[outer_loop]++;
 }




      if (dest_loop == -1)
 return;




      for (; dest_loop != -1; dest_loop = loop_outer_loop[dest_loop])
 {

   for (outer_loop = loop_num; outer_loop != -1;
        outer_loop = loop_outer_loop[outer_loop])
     if (dest_loop == outer_loop)
       return;


   if (loop_dump_stream && ! loop_invalid[dest_loop])
     fprintf (loop_dump_stream,
       "\nLoop at %d ignored due to multiple entry points.\n",
       ((loop_number_loop_starts[dest_loop])->fld[0].rtint));

   loop_invalid[dest_loop] = 1;
 }
      return;

    case SET:

      if (((x)->fld[0].rtx) == pc_rtx)
 mark_loop_jump (((x)->fld[1].rtx), loop_num);
      return;

    case IF_THEN_ELSE:
      mark_loop_jump (((x)->fld[1].rtx), loop_num);
      mark_loop_jump (((x)->fld[2].rtx), loop_num);
      return;

    case PARALLEL:
    case ADDR_VEC:
      for (i = 0; i < ((x)->fld[0].rtvec->num_elem); i++)
 mark_loop_jump (((x)->fld[0].rtvec->elem[i].rtx), loop_num);
      return;

    case ADDR_DIFF_VEC:
      for (i = 0; i < ((x)->fld[1].rtvec->num_elem); i++)
 mark_loop_jump (((x)->fld[1].rtvec->elem[i].rtx), loop_num);
      return;

    default:



      if (loop_num != -1)
 {
   loop_number_exit_labels[loop_num] = x;

   for (outer_loop = loop_num; outer_loop != -1;
        outer_loop = loop_outer_loop[outer_loop])
     loop_number_exit_count[outer_loop]++;
 }
      return;
    }
}






static int
labels_in_range_p(rtx insn, int end) asm("_labels_in_range_p");
static int
labels_in_range_p(rtx insn, int end)
{
  while (insn && (((insn)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((insn)->fld[0].rtint)] : (abort (), -1)) <= end)
    {
      if (((insn)->code) == CODE_LABEL)
 return 1;
      insn = ((insn)->fld[2].rtx);
    }

  return 0;
}



static void
note_addr_stored(rtx x) asm("_note_addr_stored");
static void
note_addr_stored(rtx x)
{
  register int i;

  if (x == 0 || ((x)->code) != MEM)
    return;



  num_mem_sets++;


  if (((x)->mode) == BLKmode)
    unknown_address_altered = 1;

  if (unknown_address_altered)
    return;

  for (i = 0; i < loop_store_mems_idx; i++)
    if (rtx_equal_p (((loop_store_mems[i])->fld[0].rtx), ((x)->fld[0].rtx))
 && ((x)->in_struct) == ((loop_store_mems[i])->in_struct))
      {


 if ((mode_size[(int)(((x)->mode))])
     > (mode_size[(int)(((loop_store_mems[i])->mode))]))
   loop_store_mems[i] = x;
 break;
      }

  if (i == 20)
    unknown_address_altered = 1;

  else if (i == loop_store_mems_idx)
    loop_store_mems[loop_store_mems_idx++] = x;
}
int
invariant_p(register rtx x) asm("_invariant_p");
int
invariant_p(register rtx x)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;
  int conditional = 0;

  if (x == 0)
    return 1;
  code = ((x)->code);
  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CONST:
      return 1;

    case LABEL_REF:
      if (flag_unroll_loops)
 return 0;
      else
 return 1;

    case PC:
    case CC0:
    case UNSPEC_VOLATILE:
      return 0;

    case REG:


      if (x == frame_pointer_rtx || x == hard_frame_pointer_rtx
   || x == arg_pointer_rtx)
 return 1;
      if (loop_has_call
   && ((x)->fld[0].rtint) < 68 && call_used_regs[((x)->fld[0].rtint)])
 return 0;
      if (n_times_set[((x)->fld[0].rtint)] < 0)
 return 2;
      return n_times_set[((x)->fld[0].rtint)] == 0;

    case MEM:



      if (((x)->volatil))
 return 0;



      if (((x)->unchanging))
 break;



      if (unknown_address_altered)
 return 0;


      for (i = loop_store_mems_idx - 1; i >= 0; i--)
 if (true_dependence (loop_store_mems[i], x))
   return 0;



      break;

    case ASM_OPERANDS:

      if (((x)->volatil))
 return 0;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   int tem = invariant_p (((x)->fld[i].rtx));
   if (tem == 0)
     return 0;
   if (tem == 2)
     conditional = 1;
 }
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     {
       int tem = invariant_p (((x)->fld[i].rtvec->elem[j].rtx));
       if (tem == 0)
  return 0;
       if (tem == 2)
  conditional = 1;
     }

 }
    }

  return 1 + conditional;
}
static int
consec_sets_invariant_p(rtx reg, int n_sets, rtx insn) asm("_consec_sets_invariant_p");
static int
consec_sets_invariant_p(rtx reg, int n_sets, rtx insn)
{
  register rtx p = insn;
  register int regno = ((reg)->fld[0].rtint);
  rtx temp;

  int count = n_sets - 1;
  int old = n_times_set[regno];
  int value = 0;
  int cxx_this;


  if (n_sets == 127)
    return 0;

  n_times_set[regno] = 0;

  while (count > 0)
    {
      register n64_enum_rtx_code code;
      rtx set;

      p = ((p)->fld[2].rtx);
      code = ((p)->code);


      if (code == INSN && (temp = find_reg_note (p, REG_LIBCALL, (rtx) 0)))
 p = ((temp)->fld[0].rtx);

      cxx_this = 0;
      if (code == INSN
   && (set = single_set (p))
   && ((((set)->fld[0].rtx))->code) == REG
   && ((((set)->fld[0].rtx))->fld[0].rtint) == regno)
 {
   cxx_this = invariant_p (((set)->fld[1].rtx));
   if (cxx_this != 0)
     value |= cxx_this;
   else if (temp = find_reg_note (p, REG_EQUAL, (rtx) 0))
     {



       cxx_this = ((((((temp)->fld[0].rtx))->code) == LABEL_REF || ((((temp)->fld[0].rtx))->code) == SYMBOL_REF || ((((temp)->fld[0].rtx))->code) == CONST_INT || ((((temp)->fld[0].rtx))->code) == CONST_DOUBLE || ((((temp)->fld[0].rtx))->code) == CONST || ((((temp)->fld[0].rtx))->code) == HIGH)
        || (find_reg_note (p, REG_RETVAL, (rtx) 0)
     && invariant_p (((temp)->fld[0].rtx))));
       if (cxx_this != 0)
  value |= cxx_this;
     }
 }
      if (cxx_this != 0)
 count--;
      else if (code != NOTE)
 {
   n_times_set[regno] = old;
   return 0;
 }
    }

  n_times_set[regno] = old;

  return 1 + (value & 2);
}
static void
find_single_use_in_loop(rtx insn, rtx x, rtx *usage) asm("_find_single_use_in_loop");
static void
find_single_use_in_loop(rtx insn, rtx x, rtx *usage)
{
  n64_enum_rtx_code code = ((x)->code);
  char *fmt = (rtx_format[(int)(code)]);
  int i, j;

  if (code == REG)
    usage[((x)->fld[0].rtint)]
      = (usage[((x)->fld[0].rtint)] != 0 && usage[((x)->fld[0].rtint)] != insn)
 ? const0_rtx : insn;

  else if (code == SET)
    {




      if (((((x)->fld[0].rtx))->code) != REG)
 find_single_use_in_loop (insn, ((x)->fld[0].rtx), usage);
      find_single_use_in_loop (insn, ((x)->fld[1].rtx), usage);
    }
  else
    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e' && ((x)->fld[i].rtx) != 0)
   find_single_use_in_loop (insn, ((x)->fld[i].rtx), usage);
 else if (fmt[i] == 'E')
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     find_single_use_in_loop (insn, ((x)->fld[i].rtvec->elem[j].rtx), usage);
      }
}
static void
count_loop_regs_set(register rtx from, register rtx to, char *may_not_move, rtx *single_usage, int *count_ptr, int nregs) asm("_count_loop_regs_set");
static void
count_loop_regs_set(register rtx from, register rtx to, char *may_not_move, rtx *single_usage, int *count_ptr, int nregs)
{
  register rtx *last_set = (rtx *) 
                                  __builtin_alloca((
                                  nregs * sizeof (rtx)
                                  ))
                                                               ;
  register rtx insn;
  register int count = 0;
  register rtx dest;

  memset ((char *) last_set,0,nregs * sizeof (rtx));
  for (insn = from; insn != to; insn = ((insn)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   ++count;


   if (single_usage)
     {
       find_single_use_in_loop (insn, ((insn)->fld[3].rtx), single_usage);


       if (((insn)->fld[6].rtx))
  find_single_use_in_loop (insn, ((insn)->fld[6].rtx), single_usage);
     }

   if (((((insn)->fld[3].rtx))->code) == CLOBBER
       && ((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == REG)


     may_not_move[((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtint)] = 1;

   if (((((insn)->fld[3].rtx))->code) == SET
       || ((((insn)->fld[3].rtx))->code) == CLOBBER)
     {
       dest = ((((insn)->fld[3].rtx))->fld[0].rtx);
       while (((dest)->code) == SUBREG
       || ((dest)->code) == ZERO_EXTRACT
       || ((dest)->code) == SIGN_EXTRACT
       || ((dest)->code) == STRICT_LOW_PART)
  dest = ((dest)->fld[0].rtx);
       if (((dest)->code) == REG)
  {
    register int regno = ((dest)->fld[0].rtint);




    if (n_times_set[regno] > 0 && last_set[regno] == 0)
      may_not_move[regno] = 1;



    if (last_set[regno] != 0
        && reg_used_between_p (dest, last_set[regno], insn))
      may_not_move[regno] = 1;
    if (n_times_set[regno] < 127)
      ++n_times_set[regno];
    last_set[regno] = insn;
  }
     }
   else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
     {
       register int i;
       for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
  {
    register rtx x = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
    if (((x)->code) == CLOBBER && ((((x)->fld[0].rtx))->code) == REG)


      may_not_move[((((x)->fld[0].rtx))->fld[0].rtint)] = 1;

    if (((x)->code) == SET || ((x)->code) == CLOBBER)
      {
        dest = ((x)->fld[0].rtx);
        while (((dest)->code) == SUBREG
        || ((dest)->code) == ZERO_EXTRACT
        || ((dest)->code) == SIGN_EXTRACT
        || ((dest)->code) == STRICT_LOW_PART)
   dest = ((dest)->fld[0].rtx);
        if (((dest)->code) == REG)
   {
     register int regno = ((dest)->fld[0].rtint);
     if (n_times_set[regno] > 0 && last_set[regno] == 0)
       may_not_move[regno] = 1;
     if (last_set[regno] != 0
         && reg_used_between_p (dest, last_set[regno], insn))
       may_not_move[regno] = 1;
     if (n_times_set[regno] < 127)
       ++n_times_set[regno];
     last_set[regno] = insn;
   }
      }
  }
     }
 }

      if (((insn)->code) == CODE_LABEL || ((insn)->code) == JUMP_INSN)
 memset ((char *) last_set,0,nregs * sizeof (rtx));
    }
  *count_ptr = count;
}
static int
loop_reg_used_before_p(rtx set, rtx insn, rtx loop_start, rtx scan_start, rtx loop_end) asm("_loop_reg_used_before_p");
static int
loop_reg_used_before_p(rtx set, rtx insn, rtx loop_start, rtx scan_start, rtx loop_end)
{
  rtx reg = ((set)->fld[0].rtx);
  rtx p;



  for (p = scan_start; p != insn; p = ((p)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((p)->code))]) == 'i'
   && reg_overlap_mentioned_p (reg, ((p)->fld[3].rtx)))
 return 1;

      if (p == loop_end)
 p = loop_start;
    }

  return 0;
}
n64_enum_iv_mode *reg_iv_type;





struct n64_tag_induction **reg_iv_info;






struct n64_tag_iv_class **reg_biv_class;




struct n64_tag_iv_class *loop_iv_list;



static rtx note_insn;



static rtx addr_placeholder;
static void
strength_reduce(rtx scan_start, rtx end, rtx loop_top, int insn_count, rtx loop_start, rtx loop_end) asm("_strength_reduce");
static void
strength_reduce(rtx scan_start, rtx end, rtx loop_top, int insn_count, rtx loop_start, rtx loop_end)
{
  rtx p;
  rtx set;
  rtx inc_val;
  rtx mult_val;
  rtx dest_reg;


  int not_every_iteration = 0;


  int maybe_multiple = 0;

  struct n64_tag_iv_class *bl, **backbl;





  int threshold = (loop_has_call ? 1 : 2) * (3 + n_non_fixed_regs);

  rtx *reg_map;
  int call_seen;
  rtx test;
  rtx end_insert_before;
  int loop_depth = 0;

  reg_iv_type = (n64_enum_iv_mode *) 
                                __builtin_alloca((
                                max_reg_before_loop * sizeof (n64_enum_iv_mode *)
                                ))
                                
                               ;
  memset ((char *) reg_iv_type,0,max_reg_before_loop * sizeof (n64_enum_iv_mode *));
  reg_iv_info = (struct n64_tag_induction **)
    
   __builtin_alloca((
   max_reg_before_loop * sizeof (struct n64_tag_induction *)
   ))
                                                             ;
  memset ((char *) reg_iv_info,0,(max_reg_before_loop * sizeof (struct n64_tag_induction *)))
                                   ;
  reg_biv_class = (struct n64_tag_iv_class **)
    
   __builtin_alloca((
   max_reg_before_loop * sizeof (struct n64_tag_iv_class *)
   ))
                                                            ;
  memset ((char *) reg_biv_class,0,(max_reg_before_loop * sizeof (struct n64_tag_iv_class *)))
                                    ;

  loop_iv_list = 0;
  addr_placeholder = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
  if (((loop_end)->fld[2].rtx) != 0)
    end_insert_before = ((loop_end)->fld[2].rtx);
  else
    end_insert_before = emit_note_after (-1, loop_end);



  p = scan_start;
  while (1)
    {
      p = ((p)->fld[2].rtx);


      if (p == scan_start)
 break;
      if (p == end)
 {
   if (loop_top != 0)
     p = loop_top;
   else
     break;
   if (p == scan_start)
     break;
 }

      if (((p)->code) == INSN
   && (set = single_set (p))
   && ((((set)->fld[0].rtx))->code) == REG)
 {
   dest_reg = ((set)->fld[0].rtx);
   if (((dest_reg)->fld[0].rtint) < max_reg_before_loop
       && ((dest_reg)->fld[0].rtint) >= 68
       && reg_iv_type[((dest_reg)->fld[0].rtint)] != NOT_BASIC_INDUCT)
     {
       if (basic_induction_var (((set)->fld[1].rtx), ((((set)->fld[1].rtx))->mode),
           dest_reg, p, &inc_val, &mult_val))
  {



    struct n64_tag_induction *v
      = (struct n64_tag_induction *) 
                            __builtin_alloca((
                            sizeof (struct n64_tag_induction)
                            ))
                                                              ;

    record_biv (v, p, dest_reg, inc_val, mult_val,
         not_every_iteration, maybe_multiple);
    reg_iv_type[((dest_reg)->fld[0].rtint)] = BASIC_INDUCT;
  }
       else if (((dest_reg)->fld[0].rtint) < max_reg_before_loop)
  reg_iv_type[((dest_reg)->fld[0].rtint)] = NOT_BASIC_INDUCT;
     }
 }






      if (((p)->code) == CODE_LABEL)
 {
   rtx insn = p;

   maybe_multiple = 0;

   while (1)
     {
       insn = ((insn)->fld[2].rtx);
       if (insn == scan_start)
  break;
       if (insn == end)
  {
    if (loop_top != 0)
      insn = loop_top;
    else
      break;
    if (insn == scan_start)
      break;
  }

       if (((insn)->code) == JUMP_INSN
    && ((((insn)->fld[3].rtx))->code) != RETURN
    && (! condjump_p (insn)
        || (((insn)->fld[7].rtx) != 0
     && (((((insn)->fld[7].rtx))->fld[0].rtint) >= max_uid_for_loop
         || ((insn)->fld[0].rtint) >= max_uid_for_loop
         || ((((((insn)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((insn)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1))
      < (((insn)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((insn)->fld[0].rtint)] : (abort (), -1)))))))
       {
  maybe_multiple = 1;
  break;
       }
     }
 }






      if ((((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN)




   && ! (((p)->code) == JUMP_INSN && ((p)->fld[7].rtx) == loop_top
  && ((((((p)->fld[2].rtx))->fld[2].rtx) == loop_end && simplejump_p (p))
      || (((p)->fld[2].rtx) == loop_end && condjump_p (p)))))
 not_every_iteration = 1;

      else if (((p)->code) == NOTE)
 {



   if (((p)->fld[4].rtint) == -9 && loop_depth == 0)
     not_every_iteration = 0;
   else if (((p)->fld[4].rtint) == -4)
     loop_depth++;
   else if (((p)->fld[4].rtint) == -5)
     loop_depth--;
 }
      if (not_every_iteration && ((p)->code) == CODE_LABEL
   && no_labels_between_p (p, loop_end))
 not_every_iteration = 0;
    }



  for (backbl = &loop_iv_list, bl = *backbl; bl; bl = bl->next)
    {
      if (reg_iv_type[bl->regno] != BASIC_INDUCT


   || n_times_set[bl->regno] != bl->biv_count


   || ! bl->incremented)
 {
   if (loop_dump_stream)
     fprintf (loop_dump_stream, "Reg %d: biv discarded, %s\n",
       bl->regno,
       (reg_iv_type[bl->regno] != BASIC_INDUCT
        ? "not induction variable"
        : (! bl->incremented ? "never incremented"
    : "count error")));

   reg_iv_type[bl->regno] = NOT_BASIC_INDUCT;
   *backbl = bl->next;
 }
      else
 {
   backbl = &bl->next;

   if (loop_dump_stream)
     fprintf (loop_dump_stream, "Reg %d: biv verified\n", bl->regno);
 }
    }


  if (! loop_iv_list)
    {


      if (flag_unroll_loops)
 unroll_loop (loop_end, insn_count, loop_start, end_insert_before, 0);

      return;
    }




  call_seen = 0;
  for (p = loop_start; p && ((p)->code) != CODE_LABEL; p = ((p)->fld[1].rtx))
    {
      note_insn = p;

      if (((p)->code) == CALL_INSN)
 call_seen = 1;

      if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
   || ((p)->code) == CALL_INSN)
 note_stores (((p)->fld[3].rtx), record_initial);




      if (((p)->code) == JUMP_INSN
   && ((p)->fld[7].rtx) != 0
   && next_real_insn (((p)->fld[7].rtx)) == next_real_insn (loop_end)
   && (test = get_condition_for_loop (p)) != 0
   && ((((test)->fld[0].rtx))->code) == REG
   && ((((test)->fld[0].rtx))->fld[0].rtint) < max_reg_before_loop
   && (bl = reg_biv_class[((((test)->fld[0].rtx))->fld[0].rtint)]) != 0
   && valid_initial_value_p (((test)->fld[1].rtx), p, call_seen, loop_start)
   && bl->init_insn == 0)
 {

   if (((test)->code) == NE)
     {
       bl->init_insn = p;
       bl->init_set = gen_rtx (SET, VOIDmode,
          ((test)->fld[0].rtx), ((test)->fld[1].rtx));
     }
   else
     bl->initial_test = test;
 }
    }




  for (bl = loop_iv_list; bl; bl = bl->next)
    {
      rtx src;

      if (! bl->init_insn)
 continue;

      src = ((bl->init_set)->fld[1].rtx);

      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Biv %d initialized at insn %d: initial value ",
   bl->regno, ((bl->init_insn)->fld[0].rtint));

      if ((((src)->mode) == ((regno_reg_rtx[bl->regno])->mode)
    || ((src)->mode) == VOIDmode)
   && valid_initial_value_p (src, bl->init_insn, call_seen, loop_start))
 {
   bl->initial_value = src;

   if (loop_dump_stream)
     {
       if (((src)->code) == CONST_INT)
  fprintf (loop_dump_stream, "%d\n", ((src)->fld[0].rtwint));
       else
  {
    print_rtl (loop_dump_stream, src);
    fprintf (loop_dump_stream, "\n");
  }
     }
 }
      else
 {



   if (loop_dump_stream)
     fprintf (loop_dump_stream, "is complex\n");
 }
    }






  not_every_iteration = 0;
  loop_depth = 0;
  p = scan_start;
  while (1)
    {
      p = ((p)->fld[2].rtx);


      if (p == scan_start)
 break;
      if (p == end)
 {
   if (loop_top != 0)
     p = loop_top;
   else
     break;
   if (p == scan_start)
     break;
 }


      if (((p)->code) == INSN
   && (set = single_set (p))
   && ((((set)->fld[0].rtx))->code) == REG
   && ! may_not_optimize[((((set)->fld[0].rtx))->fld[0].rtint)])
 {
   rtx src_reg;
   rtx add_val;
   rtx mult_val;
   int benefit;
   rtx regnote = 0;

   dest_reg = ((set)->fld[0].rtx);
   if (((dest_reg)->fld[0].rtint) < 68)
     continue;

   if (
       ((benefit = general_induction_var (((set)->fld[1].rtx),
       &src_reg, &add_val,
       &mult_val))

        || ((regnote = find_reg_note (p, REG_EQUAL, (rtx) 0))
     && (benefit = general_induction_var (((regnote)->fld[0].rtx),
       &src_reg,
       &add_val, &mult_val))))


       && ((dest_reg)->fld[0].rtint) < max_reg_before_loop

       && dest_reg != src_reg

       && (n_times_set[((dest_reg)->fld[0].rtint)] == 1

    || (benefit = consec_sets_giv (benefit, p,
       src_reg, dest_reg,
       &add_val, &mult_val))))
     {
       int count;
       struct n64_tag_induction *v
  = (struct n64_tag_induction *) 
                        __builtin_alloca((
                        sizeof (struct n64_tag_induction)
                        ))
                                                          ;
       rtx temp;


       if (find_reg_note (p, REG_RETVAL, (rtx) 0))
  benefit += libcall_benefit (p);


       for (count = n_times_set[((dest_reg)->fld[0].rtint)] - 1;
     count > 0; count--)
  {



    if (((p)->code) != NOTE
        && (temp = find_reg_note (p, REG_LIBCALL, (rtx) 0)))
      p = ((temp)->fld[0].rtx);

    do p = ((p)->fld[2].rtx);
    while (((p)->code) == NOTE);
  }

       record_giv (v, p, src_reg, dest_reg, mult_val, add_val, benefit,
     DEST_REG, not_every_iteration, ((void *)0), loop_start,
     loop_end);

     }
 }





      if (((p)->code) == INSN)
 find_mem_givs (((p)->fld[3].rtx), p, not_every_iteration, loop_start,
         loop_end);




      if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
 || ((p)->code) == CODE_LABEL)
 update_giv_derive (p);






      if ((((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN)




   && ! (((p)->code) == JUMP_INSN && ((p)->fld[7].rtx) == loop_top
  && ((((((p)->fld[2].rtx))->fld[2].rtx) == loop_end && simplejump_p (p))
      || (((p)->fld[2].rtx) == loop_end && condjump_p (p)))))
 not_every_iteration = 1;

      else if (((p)->code) == NOTE)
 {



   if (((p)->fld[4].rtint) == -9 && loop_depth == 0)
     not_every_iteration = 0;
   else if (((p)->fld[4].rtint) == -4)
     loop_depth++;
   else if (((p)->fld[4].rtint) == -5)
     loop_depth--;
 }
      if (not_every_iteration && ((p)->code) == CODE_LABEL
   && no_labels_between_p (p, loop_end))
 not_every_iteration = 0;
    }






  loop_n_iterations = loop_iterations (loop_start, loop_end);






  for (bl = loop_iv_list; bl; bl = bl->next)
    {
      struct n64_tag_induction *v;

      for (v = bl->giv; v; v = v->next_iv)
 if (! v->replaceable && ! v->not_replaceable)
   check_final_value (v, loop_start, loop_end);
    }




  check_dbra_loop (loop_end, insn_count, loop_start);


  reg_map = (rtx *) 
                   __builtin_alloca((
                   max_reg_before_loop * sizeof (rtx)
                   ))
                                                              ;
  memset ((char *) reg_map,0,max_reg_before_loop * sizeof (rtx));




  for (bl = loop_iv_list; bl; bl = bl->next)
    {
      struct n64_tag_induction *v;
      int benefit;
      int all_reduced;
      rtx final_value = 0;
      if ((uid_luid[regno_last_uid[bl->regno]] < (((loop_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_end)->fld[0].rtint)] : (abort (), -1))
    && bl->init_insn
    && ((bl->init_insn)->fld[0].rtint) < max_uid_for_loop
    && uid_luid[regno_first_uid[bl->regno]] >= (((bl->init_insn)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((bl->init_insn)->fld[0].rtint)] : (abort (), -1))



    && ! reg_mentioned_p (bl->biv->dest_reg, ((bl->init_set)->fld[1].rtx)))
   || ((final_value = final_biv_value (bl, loop_start, loop_end))



       ))
 bl->eliminable = maybe_eliminate_biv (bl, loop_start, end, 0,
           threshold, insn_count);
      else
 {
   if (loop_dump_stream)
     {
       fprintf (loop_dump_stream,
         "Cannot eliminate biv %d.\n",
         bl->regno);
       fprintf (loop_dump_stream,
         "First use: insn %d, last use: insn %d.\n",
         regno_first_uid[bl->regno],
         regno_last_uid[bl->regno]);
     }
 }


      combine_givs (bl);




      all_reduced = 1;



      for (v = bl->giv; v; v = v->next_iv)
 {
   struct n64_tag_induction *tv;

   if (v->ignore || v->same)
     continue;

   benefit = v->benefit;
   if (! v->replaceable && ! bl->eliminable
       && ((v->dest_reg)->volatil))
     benefit -= copy_cost;



   benefit -= add_cost * bl->biv_count;
   if (v->lifetime * threshold * benefit < insn_count
       && ! bl->reversed)
     {
       if (loop_dump_stream)
  fprintf (loop_dump_stream,
    "giv of insn %d not worth while, %d vs %d.\n",
    ((v->insn)->fld[0].rtint),
    v->lifetime * threshold * benefit, insn_count);
       v->ignore = 1;
       all_reduced = 0;
     }
   else
     {



       for (tv = bl->biv; tv; tv = tv->next_iv)
  if (tv->mult_val == const1_rtx
      && ! product_cheap_p (tv->add_val, v->mult_val))
    {
      if (loop_dump_stream)
        fprintf (loop_dump_stream,
          "giv of insn %d: would need a multiply.\n",
          ((v->insn)->fld[0].rtint));
      v->ignore = 1;
      all_reduced = 0;
      break;
    }
     }
 }



      for (v = bl->giv; v; v = v->next_iv)
 {
   struct n64_tag_induction *tv;
   if (! v->ignore && v->same == 0)
     {
       v->new_reg = gen_reg_rtx (v->mode);



       for (tv = bl->biv; tv; tv = tv->next_iv)
  {
    if (tv->mult_val == const1_rtx)
      emit_iv_add_mult (tv->add_val, v->mult_val,
          v->new_reg, v->new_reg, tv->insn);
    else


      emit_iv_add_mult (tv->add_val, v->mult_val,
          v->add_val, v->new_reg, tv->insn);
  }



       emit_iv_add_mult (bl->initial_value, v->mult_val,
    v->add_val, v->new_reg, loop_start);
     }
 }
      for (v = bl->giv; v; v = v->next_iv)
 {
   if (v->same && v->same->ignore)
     v->ignore = 1;

   if (v->ignore)
     continue;

   if (v->giv_type == DEST_REG
       && regno_first_uid[((v->dest_reg)->fld[0].rtint)] == ((v->insn)->fld[0].rtint))
     {
       struct n64_tag_induction *v1;

       for (v1 = bl->giv; v1; v1 = v1->next_iv)
  if (regno_last_uid[((v->dest_reg)->fld[0].rtint)] == ((v1->insn)->fld[0].rtint))
    v->maybe_dead = 1;
     }



   if (v->same)
     v->new_reg = replace_rtx (v->new_reg,
          v->same->dest_reg, v->same->new_reg);

   if (v->giv_type == DEST_ADDR)


     validate_change (v->insn, v->location, v->new_reg, 0);
   else if (v->replaceable)
     {
       reg_map[((v->dest_reg)->fld[0].rtint)] = v->new_reg;
     }
   else
     {


       emit_insn_after (gen_move_insn (v->dest_reg, v->new_reg),
          v->insn);
     }






   if (bl->reversed && ! v->replaceable)
     emit_iv_add_mult (bl->initial_value, v->mult_val,
         v->add_val, v->dest_reg, end_insert_before);
   else if (v->final_value)
     {
       rtx insert_before;





       if (loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]])
  insert_before = loop_start;
       else
  insert_before = end_insert_before;
       emit_insn_before (gen_move_insn (v->dest_reg, v->final_value),
    insert_before);
     }

   if (loop_dump_stream)
     {
       fprintf (loop_dump_stream, "giv at %d reduced to ",
         ((v->insn)->fld[0].rtint));
       print_rtl (loop_dump_stream, v->new_reg);
       fprintf (loop_dump_stream, "\n");
     }
 }
      for (v = bl->giv; v; v = v->next_iv)
 if (! v->maybe_dead && v->same)
   v->same->maybe_dead = 0;
      if (all_reduced == 1 && bl->eliminable
   && maybe_eliminate_biv (bl, loop_start, end, 1,
      threshold, insn_count))

 {
   if (final_value != 0 && ! bl->reversed)
     {
       rtx insert_before;





       if (loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]])
  insert_before = loop_start;
       else
  insert_before = end_insert_before;

       emit_insn_before (gen_move_insn (bl->biv->dest_reg, final_value),
    end_insert_before);
     }
   if (loop_dump_stream)
     fprintf (loop_dump_stream, "Reg %d: biv eliminated\n",
       bl->regno);
 }
    }




  for (p = loop_start; p != end; p = ((p)->fld[2].rtx))
    if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
  || ((p)->code) == CALL_INSN)
      {
 replace_regs (((p)->fld[3].rtx), reg_map, max_reg_before_loop, 0);
 replace_regs (((p)->fld[6].rtx), reg_map, max_reg_before_loop, 0);
 ((p)->fld[4].rtint) = -1;
      }





  if (flag_unroll_loops)
    unroll_loop (loop_end, insn_count, loop_start, end_insert_before, 1);

  if (loop_dump_stream)
    fprintf (loop_dump_stream, "\n");
}
static int
valid_initial_value_p(rtx x, rtx insn, int call_seen, rtx loop_start) asm("_valid_initial_value_p");
static int
valid_initial_value_p(rtx x, rtx insn, int call_seen, rtx loop_start)
{
  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    return 1;



  if (((x)->code) != REG
      || ((x)->fld[0].rtint) >= max_reg_before_loop)
    return 0;



  if (((x)->fld[0].rtint) < 68

      && call_used_regs[((x)->fld[0].rtint)] && call_seen

      )
    return 0;



  if (reg_set_between_p (x, insn, loop_start))
    return 0;

  return 1;
}






static void
find_mem_givs(rtx x, rtx insn, int not_every_iteration, rtx loop_start, rtx loop_end) asm("_find_mem_givs");
static void
find_mem_givs(rtx x, rtx insn, int not_every_iteration, rtx loop_start, rtx loop_end)
{
  register int i, j;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0)
    return;

  code = ((x)->code);
  switch (code)
    {
    case REG:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case PC:
    case CC0:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case USE:
    case CLOBBER:
      return;

    case MEM:
      {
 rtx src_reg;
 rtx add_val;
 rtx mult_val;
 int benefit;

 benefit = general_induction_var (((x)->fld[0].rtx),
      &src_reg, &add_val, &mult_val);



 if (benefit > 0 && (mult_val != const1_rtx || add_val != const0_rtx))
   {

     struct n64_tag_induction *v
       = (struct n64_tag_induction *) oballoc (sizeof (struct n64_tag_induction));

     record_giv (v, insn, src_reg, addr_placeholder, mult_val,
   add_val, benefit, DEST_ADDR, not_every_iteration,
   &((x)->fld[0].rtx), loop_start, loop_end);

     v->mem_mode = ((x)->mode);
   }
 return;
      }
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      find_mem_givs (((x)->fld[i].rtx), insn, not_every_iteration, loop_start,
       loop_end);
    else if (fmt[i] == 'E')
      for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
 find_mem_givs (((x)->fld[i].rtvec->elem[j].rtx), insn, not_every_iteration,
         loop_start, loop_end);
}
static void
record_biv(struct n64_tag_induction *v, rtx insn, rtx dest_reg, rtx inc_val, rtx mult_val, int not_every_iteration, int maybe_multiple) asm("_record_biv");
static void
record_biv(struct n64_tag_induction *v, rtx insn, rtx dest_reg, rtx inc_val, rtx mult_val, int not_every_iteration, int maybe_multiple)
{
  struct n64_tag_iv_class *bl;

  v->insn = insn;
  v->src_reg = dest_reg;
  v->dest_reg = dest_reg;
  v->mult_val = mult_val;
  v->add_val = inc_val;
  v->mode = ((dest_reg)->mode);
  v->always_computable = ! not_every_iteration;
  v->maybe_multiple = maybe_multiple;




  bl = reg_biv_class[((dest_reg)->fld[0].rtint)];
  if (bl == 0)
    {


      bl = (struct n64_tag_iv_class *) oballoc (sizeof (struct n64_tag_iv_class));

      bl->regno = ((dest_reg)->fld[0].rtint);
      bl->biv = 0;
      bl->giv = 0;
      bl->biv_count = 0;
      bl->giv_count = 0;


      bl->initial_value = dest_reg;

      bl->init_insn = 0;
      bl->init_set = 0;
      bl->initial_test = 0;
      bl->incremented = 0;
      bl->eliminable = 0;
      bl->nonneg = 0;
      bl->reversed = 0;
      bl->total_benefit = 0;


      bl->next = loop_iv_list;
      loop_iv_list = bl;


      reg_biv_class[((dest_reg)->fld[0].rtint)] = bl;
    }


  v->next_iv = bl->biv;
  bl->biv = v;
  bl->biv_count++;
  if (mult_val == const1_rtx)
    bl->incremented = 1;

  if (loop_dump_stream)
    {
      fprintf (loop_dump_stream,
        "Insn %d: possible biv, reg %d,",
        ((insn)->fld[0].rtint), ((dest_reg)->fld[0].rtint));
      if (((inc_val)->code) == CONST_INT)
 fprintf (loop_dump_stream, " const = %d\n",
   ((inc_val)->fld[0].rtwint));
      else
 {
   fprintf (loop_dump_stream, " const = ");
   print_rtl (loop_dump_stream, inc_val);
   fprintf (loop_dump_stream, "\n");
 }
    }
}
static void
record_giv(struct n64_tag_induction *v, rtx insn, rtx src_reg, rtx dest_reg, rtx mult_val, rtx add_val, int benefit, n64_enum_g_types type, int not_every_iteration, rtx *location, rtx loop_start, rtx loop_end) asm("_record_giv");
static void
record_giv(struct n64_tag_induction *v, rtx insn, rtx src_reg, rtx dest_reg, rtx mult_val, rtx add_val, int benefit, n64_enum_g_types type, int not_every_iteration, rtx *location, rtx loop_start, rtx loop_end)
{
  struct n64_tag_induction *b;
  struct n64_tag_iv_class *bl;
  rtx set = single_set (insn);
  rtx p;

  v->insn = insn;
  v->src_reg = src_reg;
  v->giv_type = type;
  v->dest_reg = dest_reg;
  v->mult_val = mult_val;
  v->add_val = add_val;
  v->benefit = benefit;
  v->location = location;
  v->cant_derive = 0;
  v->combined_with = 0;
  v->maybe_multiple = 0;
  v->maybe_dead = 0;
  v->derive_adjustment = 0;
  v->same = 0;
  v->ignore = 0;
  v->new_reg = 0;
  v->final_value = 0;
  v->same_insn = 0;
  if (type == DEST_ADDR)
    v->always_computable = 1;
  else
    v->always_computable = ! not_every_iteration;

  if (type == DEST_ADDR)
    {
      v->mode = ((*location)->mode);
      v->lifetime = 1;
      v->times_used = 1;
    }
  else
    {
      v->mode = ((((set)->fld[0].rtx))->mode);

      v->lifetime = (uid_luid[regno_last_uid[((dest_reg)->fld[0].rtint)]]
       - uid_luid[regno_first_uid[((dest_reg)->fld[0].rtint)]]);

      v->times_used = n_times_used[((dest_reg)->fld[0].rtint)];




      if (v->lifetime == 0)
 v->ignore = 1;

      reg_iv_type[((dest_reg)->fld[0].rtint)] = GENERAL_INDUCT;
      reg_iv_info[((dest_reg)->fld[0].rtint)] = v;
    }



  bl = reg_biv_class[((src_reg)->fld[0].rtint)];
  if (bl)
    {
      v->next_iv = bl->giv;
      bl->giv = v;


      if (type == DEST_REG)
 bl->giv_count++;
      bl->total_benefit += benefit;
    }
  else

    abort ();

  if (type == DEST_ADDR)
    v->replaceable = 1;
  else
    {
      if (regno_first_uid[((dest_reg)->fld[0].rtint)] == ((insn)->fld[0].rtint)

   && uid_luid[regno_last_uid[((dest_reg)->fld[0].rtint)]] < (((loop_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_end)->fld[0].rtint)] : (abort (), -1))
   && (! not_every_iteration
       || last_use_this_basic_block (dest_reg, insn)))
  {
   v->replaceable = 1;
   for (b = bl->biv; b; b = b->next_iv)
     {
       if (((b->insn)->fld[0].rtint) >= max_uid_for_loop
    || ((uid_luid[((b->insn)->fld[0].rtint)]
         >= uid_luid[regno_first_uid[((dest_reg)->fld[0].rtint)]])
        && (uid_luid[((b->insn)->fld[0].rtint)]
     <= uid_luid[regno_last_uid[((dest_reg)->fld[0].rtint)]])))
  {
    v->replaceable = 0;
    v->not_replaceable = 1;
    break;
   }
     }



   if (v->replaceable)
     for (b = bl->biv; b; b = b->next_iv)
       if (back_branch_in_range_p (b->insn, loop_start, loop_end))
  {
    v->replaceable = 0;
    v->not_replaceable = 1;
    break;
  }
 }
      else
 {


   v->replaceable = 0;
   v->not_replaceable = 0;
 }
    }

  if (loop_dump_stream)
    {
      if (type == DEST_REG)
  fprintf (loop_dump_stream, "Insn %d: giv reg %d",
   ((insn)->fld[0].rtint), ((dest_reg)->fld[0].rtint));
      else
  fprintf (loop_dump_stream, "Insn %d: dest address",
    ((insn)->fld[0].rtint));

      fprintf (loop_dump_stream, " src reg %d benefit %d",
        ((src_reg)->fld[0].rtint), v->benefit);
      fprintf (loop_dump_stream, " used %d lifetime %d",
        v->times_used, v->lifetime);

      if (v->replaceable)
  fprintf (loop_dump_stream, " replaceable");

      if (((mult_val)->code) == CONST_INT)
 fprintf (loop_dump_stream, " mult %d",
    ((mult_val)->fld[0].rtwint));
      else
 {
   fprintf (loop_dump_stream, " mult ");
   print_rtl (loop_dump_stream, mult_val);
 }

      if (((add_val)->code) == CONST_INT)
 fprintf (loop_dump_stream, " add %d",
   ((add_val)->fld[0].rtwint));
      else
 {
   fprintf (loop_dump_stream, " add ");
   print_rtl (loop_dump_stream, add_val);
 }
    }

  if (loop_dump_stream)
    fprintf (loop_dump_stream, "\n");

}
static void
check_final_value(struct n64_tag_induction *v, rtx loop_start, rtx loop_end) asm("_check_final_value");
static void
check_final_value(struct n64_tag_induction *v, rtx loop_start, rtx loop_end)
{
  struct n64_tag_iv_class *bl;
  rtx final_value = 0;

  bl = reg_biv_class[((v->src_reg)->fld[0].rtint)];
  if ((final_value = final_giv_value (v, loop_start, loop_end))
      && (v->always_computable || last_use_this_basic_block (v->dest_reg, v->insn)))
    {
      int biv_increment_seen = 0;
      rtx p = v->insn;
      rtx last_giv_use;

      v->replaceable = 1;
      last_giv_use = v->insn;

      while (1)
 {
   p = ((p)->fld[2].rtx);
   if (p == loop_end)
     p = ((loop_start)->fld[2].rtx);
   if (p == v->insn)
     break;

   if (((p)->code) == INSN || ((p)->code) == JUMP_INSN
       || ((p)->code) == CALL_INSN)
     {
       if (biv_increment_seen)
  {
    if (reg_mentioned_p (v->dest_reg, ((p)->fld[3].rtx)))
      {
        v->replaceable = 0;
        v->not_replaceable = 1;
        break;
      }
  }
       else if (((((p)->fld[3].rtx))->code) == SET
         && ((((p)->fld[3].rtx))->fld[0].rtx) == v->src_reg)
  biv_increment_seen = 1;
       else if (reg_mentioned_p (v->dest_reg, ((p)->fld[3].rtx)))
  last_giv_use = p;
     }
 }





      if (v->replaceable)
 {
   p = v->insn;
   while (1)
     {
       p = ((p)->fld[2].rtx);
       if (p == loop_end)
  p = ((loop_start)->fld[2].rtx);
       if (p == last_giv_use)
  break;

       if (((p)->code) == JUMP_INSN && ((p)->fld[7].rtx)
    && ((((p)->fld[7].rtx))->fld[4].rtstr)
    && (((((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) < (((v->insn)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((v->insn)->fld[0].rtint)] : (abort (), -1))
         && (((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) > (((loop_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_start)->fld[0].rtint)] : (abort (), -1)))
        || ((((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) > (((last_giv_use)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((last_giv_use)->fld[0].rtint)] : (abort (), -1))
     && (((((p)->fld[7].rtx))->fld[0].rtint) < max_uid_for_loop ? uid_luid[((((p)->fld[7].rtx))->fld[0].rtint)] : (abort (), -1)) < (((loop_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_end)->fld[0].rtint)] : (abort (), -1)))))
  {
    v->replaceable = 0;
    v->not_replaceable = 1;

    if (loop_dump_stream)
      fprintf (loop_dump_stream,
        "Found branch outside giv lifetime.\n");

    break;
  }
     }
 }


      if (v->replaceable)
 v->final_value = final_value;
    }

  if (loop_dump_stream && v->replaceable)
    fprintf (loop_dump_stream, "Insn %d: giv reg %d final_value replaceable\n",
      ((v->insn)->fld[0].rtint), ((v->dest_reg)->fld[0].rtint));
}
static void
update_giv_derive(rtx p) asm("_update_giv_derive");
static void
update_giv_derive(rtx p)
{
  struct n64_tag_iv_class *bl;
  struct n64_tag_induction *biv, *giv;
  rtx tem;
  int dummy;
  for (bl = loop_iv_list; bl; bl = bl->next)
    for (biv = bl->biv; biv; biv = biv->next_iv)
      if (((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN
   || biv->insn == p)
 {
   for (giv = bl->giv; giv; giv = giv->next_iv)
     {


       if (giv->cant_derive)
  continue;



       if (((p)->code) == CODE_LABEL && ! giv->always_computable)
  giv->cant_derive = 1;





       else if (giv->mult_val == const0_rtx || giv->replaceable)
  continue;





       else if (biv->insn == p)
  {
    tem = 0;

    if (biv->mult_val == const1_rtx)
      tem = simplify_giv_expr (gen_rtx (MULT, giv->mode,
            biv->add_val,
            giv->mult_val),
          &dummy);

    if (tem && giv->derive_adjustment)
      tem = simplify_giv_expr (gen_rtx (PLUS, giv->mode, tem,
            giv->derive_adjustment),
          &dummy);
    if (tem)
      giv->derive_adjustment = tem;
    else
      giv->cant_derive = 1;
  }
       else if ((((p)->code) == CODE_LABEL && ! biv->always_computable)
         || (((p)->code) == JUMP_INSN && biv->maybe_multiple))
  giv->cant_derive = 1;
     }
 }
}
static int
basic_induction_var(register rtx x, n64_enum_machine_mode mode, rtx dest_reg, rtx p, rtx *inc_val, rtx *mult_val) asm("_basic_induction_var");
static int
basic_induction_var(register rtx x, n64_enum_machine_mode mode, rtx dest_reg, rtx p, rtx *inc_val, rtx *mult_val)
{
  register n64_enum_rtx_code code;
  rtx arg;
  rtx insn, set = 0;

  code = ((x)->code);
  switch (code)
    {
    case PLUS:
      if (((x)->fld[0].rtx) == dest_reg
   || (((((x)->fld[0].rtx))->code) == SUBREG
       && ((((x)->fld[0].rtx))->in_struct)
       && ((((x)->fld[0].rtx))->fld[0].rtx) == dest_reg))
  arg = ((x)->fld[1].rtx);
      else if (((x)->fld[1].rtx) == dest_reg
        || (((((x)->fld[1].rtx))->code) == SUBREG
     && ((((x)->fld[1].rtx))->in_struct)
     && ((((x)->fld[1].rtx))->fld[0].rtx) == dest_reg))
 arg = ((x)->fld[0].rtx);
      else
  return 0;

      if (invariant_p (arg) != 1)
 return 0;

      *inc_val = convert_modes (((dest_reg)->mode), ((x)->mode), arg, 0);
      *mult_val = const1_rtx;
      return 1;

    case SUBREG:


      if (((x)->in_struct))
 return basic_induction_var (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode),
        dest_reg, p, inc_val, mult_val);

    case REG:



      for (insn = ((p)->fld[1].rtx);
    (insn && ((insn)->code) == NOTE
     && ((insn)->fld[4].rtint) != -4);
    insn = ((insn)->fld[1].rtx))
 ;

      if (insn)
 set = single_set (insn);

      if (set != 0
   && (((set)->fld[0].rtx) == x
       || (((((set)->fld[0].rtx))->code) == SUBREG
    && ((mode_size[(int)(((((set)->fld[0].rtx))->mode))])
        <= ((target_flags & 0x00002000) ? 8 : 4))
    && ((((set)->fld[0].rtx))->fld[0].rtx) == x)))
 return basic_induction_var (((set)->fld[1].rtx),
        (((((set)->fld[1].rtx))->mode) == VOIDmode
         ? ((x)->mode)
         : ((((set)->fld[1].rtx))->mode)),
        dest_reg, insn,
        inc_val, mult_val);






    case MEM:
      if (invariant_p (x) != 1)
 return 0;
    case CONST_INT:
    case SYMBOL_REF:
    case CONST:
      if (loops_enclosed == 1)
  {

   *inc_val = convert_modes (((dest_reg)->mode), mode, x, 0);
    *mult_val = const0_rtx;
    return 1;
  }
      else
  return 0;

    case SIGN_EXTEND:
      return basic_induction_var (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode),
      dest_reg, p, inc_val, mult_val);
    case ASHIFTRT:

      for (insn = ((p)->fld[1].rtx);
    (insn && ((insn)->code) == NOTE
     && ((insn)->fld[4].rtint) != -4);
    insn = ((insn)->fld[1].rtx))
 ;

      if (insn)
 set = single_set (insn);

      if (set && ((set)->fld[0].rtx) == ((x)->fld[0].rtx)
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((set)->fld[1].rtx))->code) == ASHIFT
   && ((x)->fld[1].rtx) == ((((set)->fld[1].rtx))->fld[1].rtx))
 return basic_induction_var (((((set)->fld[1].rtx))->fld[0].rtx),
        ((((x)->fld[0].rtx))->mode),
        dest_reg, insn, inc_val, mult_val);
      return 0;

    default:
      return 0;
    }
}
static int
general_induction_var(rtx x, rtx *src_reg, rtx *add_val, rtx *mult_val) asm("_general_induction_var");
static int
general_induction_var(rtx x, rtx *src_reg, rtx *add_val, rtx *mult_val)
{
  rtx orig_x = x;
  int benefit = 0;
  char *storage;


  if (invariant_p (x) == 1)
    return 0;



  storage = (char *) oballoc (0);
  x = simplify_giv_expr (x, &benefit);
  if (x == 0)
    {
      obfree (storage);
      return 0;
    }

  switch (((x)->code))
    {
    case USE:
    case CONST_INT:



      *src_reg = loop_iv_list->biv->dest_reg;
      *mult_val = const0_rtx;
      *add_val = x;
      break;

    case REG:

      *src_reg = x;
      *mult_val = const1_rtx;
      *add_val = const0_rtx;
      break;

    case PLUS:


      if (((((x)->fld[0].rtx))->code) == MULT)
 {
   *src_reg = ((((x)->fld[0].rtx))->fld[0].rtx);
   *mult_val = ((((x)->fld[0].rtx))->fld[1].rtx);
 }
      else
 {
   *src_reg = ((x)->fld[0].rtx);
   *mult_val = const1_rtx;
 }
      *add_val = ((x)->fld[1].rtx);
      break;

    case MULT:

      *src_reg = ((x)->fld[0].rtx);
      *mult_val = ((x)->fld[1].rtx);
      *add_val = const0_rtx;
      break;

    default:
      abort ();
    }



  if (((*add_val)->code) == USE)
    *add_val = ((*add_val)->fld[0].rtx);
  if (((*mult_val)->code) == USE)
    *mult_val = ((*mult_val)->fld[0].rtx);

  benefit += rtx_cost (orig_x, SET);




  return benefit == 0 ? 1 : benefit;
}
static rtx
simplify_giv_expr(rtx x, int *benefit) asm("_simplify_giv_expr");
static rtx
simplify_giv_expr(rtx x, int *benefit)
{
  n64_enum_machine_mode mode = ((x)->mode);
  rtx arg0, arg1;
  rtx tem;



  if (mode != VOIDmode
      && ((mode_class[(int)(mode)]) != MODE_INT
   || (8 * mode_size[(int)(mode)]) > 32))
    return 0;

  switch (((x)->code))
    {
    case PLUS:
      arg0 = simplify_giv_expr (((x)->fld[0].rtx), benefit);
      arg1 = simplify_giv_expr (((x)->fld[1].rtx), benefit);
      if (arg0 == 0 || arg1 == 0)
 return 0;


      if ((((arg0)->code) == USE
    || ((arg0)->code) == CONST_INT)
   && ((arg1)->code) != CONST_INT)
 tem = arg0, arg0 = arg1, arg1 = tem;


      if (arg1 == const0_rtx)
 return arg0;
      else if (((arg1)->code) == CONST_INT || ((arg1)->code) == USE)
 switch (((arg0)->code))
   {
   case CONST_INT:
   case USE:


     if (((arg0)->code) == USE)
       arg0 = ((arg0)->fld[0].rtx);

     tem = 0;
     if ((((arg0)->code) == LABEL_REF || ((arg0)->code) == SYMBOL_REF || ((arg0)->code) == CONST_INT || ((arg0)->code) == CONST_DOUBLE || ((arg0)->code) == CONST || ((arg0)->code) == HIGH) && ((arg1)->code) == CONST_INT)
       {
  tem = plus_constant_wide (arg0, (int) (((arg1)->fld[0].rtwint)));
  if (((tem)->code) != CONST_INT)
    tem = gen_rtx (USE, mode, tem);
       }

     return tem;

   case REG:
   case MULT:

     return gen_rtx (PLUS, mode, arg0, arg1);

   case PLUS:

     return simplify_giv_expr (gen_rtx (PLUS, mode,
            ((arg0)->fld[0].rtx),
            gen_rtx (PLUS, mode,
       ((arg0)->fld[1].rtx), arg1)),
          benefit);

   default:
     abort ();
   }



      if (((arg0)->code) == REG)
 arg0 = gen_rtx (MULT, mode, arg0, const1_rtx);
      if (((arg1)->code) == REG)
 arg1 = gen_rtx (MULT, mode, arg1, const1_rtx);




      if (((arg1)->code) == MULT)
 tem = arg0, arg0 = arg1, arg1 = tem;

      if (((arg1)->code) == PLUS)
   return simplify_giv_expr (gen_rtx (PLUS, mode,
          gen_rtx (PLUS, mode,
            arg0, ((arg1)->fld[0].rtx)),
          ((arg1)->fld[1].rtx)),
        benefit);


      if (((arg0)->code) != MULT || ((arg1)->code) != MULT)
 abort ();

      if (((arg0)->fld[0].rtx) != ((arg1)->fld[0].rtx))
 return 0;

      return simplify_giv_expr (gen_rtx (MULT, mode,
      ((arg0)->fld[0].rtx),
      gen_rtx (PLUS, mode,
        ((arg0)->fld[1].rtx),
        ((arg1)->fld[1].rtx))),
    benefit);

    case MINUS:

      return simplify_giv_expr (gen_rtx (PLUS, mode,
      ((x)->fld[0].rtx),
      gen_rtx (MULT, mode,
        ((x)->fld[1].rtx), constm1_rtx)),
    benefit);

    case MULT:
      arg0 = simplify_giv_expr (((x)->fld[0].rtx), benefit);
      arg1 = simplify_giv_expr (((x)->fld[1].rtx), benefit);
      if (arg0 == 0 || arg1 == 0)
 return 0;


      if ((((arg0)->code) == USE || ((arg0)->code) == CONST_INT)
   && ((arg1)->code) != CONST_INT)
 tem = arg0, arg0 = arg1, arg1 = tem;


      if (((arg1)->code) != USE && ((arg1)->code) != CONST_INT)
 return 0;


      if (arg1 == const0_rtx)
 return const0_rtx;

      else if (arg1 == const1_rtx)
 return arg0;

      switch (((arg0)->code))
 {
 case REG:

   return gen_rtx (MULT, mode, arg0, arg1);

 case CONST_INT:

   return gen_rtx (CONST_INT, VOIDmode, (int) (((arg0)->fld[0].rtwint) * ((arg1)->fld[0].rtwint)));

 case USE:

   return 0;

 case MULT:

   return simplify_giv_expr (gen_rtx (MULT, mode,
          ((arg0)->fld[0].rtx),
          gen_rtx (MULT, mode,
            ((arg0)->fld[1].rtx), arg1)),
        benefit);

 case PLUS:

   return simplify_giv_expr (gen_rtx (PLUS, mode,
          gen_rtx (MULT, mode,
            ((arg0)->fld[0].rtx), arg1),
          gen_rtx (MULT, mode,
            ((arg0)->fld[1].rtx), arg1)),
        benefit);

 default:
   abort ();
 }

    case ASHIFT:

      if (((((x)->fld[1].rtx))->code) != CONST_INT)
 return 0;

      return simplify_giv_expr (gen_rtx (MULT, mode,
      ((x)->fld[0].rtx),
      gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << ((((x)->fld[1].rtx))->fld[0].rtwint)))
                                ),
    benefit);

    case NEG:

      return simplify_giv_expr (gen_rtx (MULT, mode, ((x)->fld[0].rtx), constm1_rtx),
    benefit);

    case NOT:

      return simplify_giv_expr (gen_rtx (MINUS, mode,
      gen_rtx (NEG, mode, ((x)->fld[0].rtx)),
      const1_rtx),
    benefit);

    case USE:

      return x;

    case REG:

      if (((x)->fld[0].rtint) >= max_reg_before_loop)
 return 0;


      switch (reg_iv_type[((x)->fld[0].rtint)])
 {
 case BASIC_INDUCT:
   return x;
 case GENERAL_INDUCT:
   {
     struct n64_tag_induction *v = reg_iv_info[((x)->fld[0].rtint)];



     *benefit += v->benefit;
     if (v->cant_derive)
       return 0;

     tem = gen_rtx (PLUS, mode, gen_rtx (MULT, mode,
      v->src_reg, v->mult_val),
      v->add_val);
     if (v->derive_adjustment)
       tem = gen_rtx (MINUS, mode, tem, v->derive_adjustment);
     return simplify_giv_expr (tem, benefit);
   }
 }


    default:


      if (((x)->code) == USE)
 x = ((x)->fld[0].rtx);

      if (invariant_p (x) == 1)
 {
   if (((x)->code) == CONST_INT)
     return x;
   else
     return gen_rtx (USE, mode, x);
 }
      else
 return 0;
    }
}
static int
consec_sets_giv(int first_benefit, rtx p, rtx src_reg, rtx dest_reg, rtx *add_val, rtx *mult_val) asm("_consec_sets_giv");
static int
consec_sets_giv(int first_benefit, rtx p, rtx src_reg, rtx dest_reg, rtx *add_val, rtx *mult_val)
{
  int count;
  n64_enum_rtx_code code;
  int benefit;
  rtx temp;
  rtx set;
  struct n64_tag_induction *v
    = (struct n64_tag_induction *) 
                          __builtin_alloca((
                          sizeof (struct n64_tag_induction)
                          ))
                                                            ;
  v->src_reg = src_reg;
  v->mult_val = *mult_val;
  v->add_val = *add_val;
  v->benefit = first_benefit;
  v->cant_derive = 0;
  v->derive_adjustment = 0;

  reg_iv_type[((dest_reg)->fld[0].rtint)] = GENERAL_INDUCT;
  reg_iv_info[((dest_reg)->fld[0].rtint)] = v;

  count = n_times_set[((dest_reg)->fld[0].rtint)] - 1;

  while (count > 0)
    {
      p = ((p)->fld[2].rtx);
      code = ((p)->code);


      if (code == INSN && (temp = find_reg_note (p, REG_LIBCALL, (rtx) 0)))
 p = ((temp)->fld[0].rtx);

      if (code == INSN
   && (set = single_set (p))
   && ((((set)->fld[0].rtx))->code) == REG
   && ((set)->fld[0].rtx) == dest_reg
   && ((benefit = general_induction_var (((set)->fld[1].rtx), &src_reg,
      add_val, mult_val))

       || ((temp = find_reg_note (p, REG_EQUAL, (rtx) 0))
    && (benefit = general_induction_var (((temp)->fld[0].rtx), &src_reg,
             add_val, mult_val))))
   && src_reg == v->src_reg)
 {
   if (find_reg_note (p, REG_RETVAL, (rtx) 0))
     benefit += libcall_benefit (p);

   count--;
   v->mult_val = *mult_val;
   v->add_val = *add_val;
   v->benefit = benefit;
 }
      else if (code != NOTE)
 {



   if (code == INSN
       && (set = single_set (p))
       && ((set)->fld[0].rtx) != dest_reg
       && (((((set)->fld[1].rtx))->code) == LABEL_REF || ((((set)->fld[1].rtx))->code) == SYMBOL_REF || ((((set)->fld[1].rtx))->code) == CONST_INT || ((((set)->fld[1].rtx))->code) == CONST_DOUBLE || ((((set)->fld[1].rtx))->code) == CONST || ((((set)->fld[1].rtx))->code) == HIGH))
     continue;

   reg_iv_type[((dest_reg)->fld[0].rtint)] = UNKNOWN_INDUCT;
   return 0;
 }
    }

  return v->benefit;
}
static rtx
express_from(struct n64_tag_induction *g1, struct n64_tag_induction *g2) asm("_express_from");
static rtx
express_from(struct n64_tag_induction *g1, struct n64_tag_induction *g2)
{
  rtx mult, add;




  if (((g1->mult_val)->code) != CONST_INT
      || ((g2->mult_val)->code) != CONST_INT
      || ((g1->add_val)->code) != CONST_INT
      || g1->mult_val == const0_rtx
      || ((g2->mult_val)->fld[0].rtwint) % ((g1->mult_val)->fld[0].rtwint) != 0)
    return 0;

  mult = gen_rtx (CONST_INT, VOIDmode, (int) (((g2->mult_val)->fld[0].rtwint) / ((g1->mult_val)->fld[0].rtwint)));
  add = plus_constant_wide (g2->add_val, (int) (- ((g1->add_val)->fld[0].rtwint) * ((mult)->fld[0].rtwint)));


  if (mult == const0_rtx)
    return add;
  else if (mult == const1_rtx)
    mult = g1->dest_reg;
  else
    mult = gen_rtx (MULT, g2->mode, g1->dest_reg, mult);

  if (add == const0_rtx)
    return mult;
  else
    return gen_rtx (PLUS, g2->mode, mult, add);
}







static int
combine_givs_p(struct n64_tag_induction *g1, struct n64_tag_induction *g2) asm("_combine_givs_p");
static int
combine_givs_p(struct n64_tag_induction *g1, struct n64_tag_induction *g2)
{
  rtx tem;


  if (rtx_equal_p (g1->mult_val, g2->mult_val)
      && rtx_equal_p (g1->add_val, g2->add_val))
    {
      g2->new_reg = g1->dest_reg;
      return 1;
    }





  if (g2->giv_type == DEST_ADDR
      && (tem = express_from (g1, g2)) != 0
      && memory_address_p (g2->mem_mode, tem)
      && ((((tem)->code) == REG) ? 1 : mips_address_cost (tem)) <= ((((*g2->location)->code) == REG) ? 1 : mips_address_cost (*g2->location)))
    {
      g2->new_reg = tem;
      return 1;
    }


  return 0;
}






static void
combine_givs(struct n64_tag_iv_class *bl) asm("_combine_givs");
static void
combine_givs(struct n64_tag_iv_class *bl)
{
  struct n64_tag_induction *g1, *g2;
  int pass;

  for (g1 = bl->giv; g1; g1 = g1->next_iv)
    for (pass = 0; pass <= 1; pass++)
      for (g2 = bl->giv; g2; g2 = g2->next_iv)
 if (g1 != g2

     && (g1->replaceable || pass == 1)


     && ! g1->ignore && ! g2->ignore && ! g1->same && ! g2->same


     && ! g2->combined_with
     && combine_givs_p (g1, g2))
   {

     g2->same = g1;
     g1->combined_with = 1;
     g1->benefit += g2->benefit;



     if (! g2->replaceable && ((g2->dest_reg)->volatil))
       g1->benefit -= copy_cost;
     g1->lifetime += g2->lifetime;
     g1->times_used += g2->times_used;

     if (loop_dump_stream)
       fprintf (loop_dump_stream, "giv at %d combined with giv at %d\n",
         ((g2->insn)->fld[0].rtint), ((g1->insn)->fld[0].rtint));
   }
}



void
emit_iv_add_mult(rtx b, rtx m, rtx a, rtx reg, rtx insert_before) asm("_emit_iv_add_mult");
void
emit_iv_add_mult(rtx b, rtx m, rtx a, rtx reg, rtx insert_before)
{
  rtx seq;
  rtx result;


  a = copy_rtx (a);
  b = copy_rtx (b);


  update_reg_last_use (a, insert_before);
  update_reg_last_use (b, insert_before);
  update_reg_last_use (m, insert_before);

  start_sequence ();
  result = expand_mult_add (b, reg, m, a, ((reg)->mode), 0);
  if (reg != result)
    emit_move_insn (reg, result);
  seq = gen_sequence ();
  end_sequence ();

  emit_insn_before (seq, insert_before);
}




static int
product_cheap_p(rtx a, rtx b) asm("_product_cheap_p");
static int
product_cheap_p(rtx a, rtx b)
{
  int i;
  rtx tmp;
  struct n64_tag_obstack *old_rtl_obstack = rtl_obstack;
  char *storage = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&temp_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  int win = 1;


  if (((a)->code) == CONST_INT)
    tmp = a, a = b, b = tmp;


  if (((a)->code) == CONST_INT)
    return 1;


  if (((b)->code) != CONST_INT)
    return 0;





  rtl_obstack = &temp_obstack;
  start_sequence ();
  expand_mult (((a)->mode), a, b, (rtx) 0, 0);
  tmp = gen_sequence ();
  end_sequence ();

  if (((tmp)->code) == SEQUENCE)
    {
      if (((tmp)->fld[0].rtvec) == 0)
 win = 1;
      else if (((tmp)->fld[0].rtvec->num_elem) > 3)
 win = 0;
      else
 for (i = 0; i < ((tmp)->fld[0].rtvec->num_elem); i++)
   {
     rtx insn = ((tmp)->fld[0].rtvec->elem[i].rtx);

     if (((insn)->code) != INSN
  || (((((insn)->fld[3].rtx))->code) == SET
      && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == MULT)
  || (((((insn)->fld[3].rtx))->code) == PARALLEL
      && ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == SET
      && ((((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) == MULT))
       {
  win = 0;
  break;
       }
   }
    }
  else if (((tmp)->code) == SET
    && ((((tmp)->fld[1].rtx))->code) == MULT)
    win = 0;
  else if (((tmp)->code) == PARALLEL
    && ((((tmp)->fld[0].rtvec->elem[0].rtx))->code) == SET
    && ((((((tmp)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) == MULT)
    win = 0;



  __extension__ ({ struct n64_tag_obstack *__o = (&temp_obstack); void *__obj = (storage); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  rtl_obstack = old_rtl_obstack;

  return win;
}
static int
check_dbra_loop(rtx loop_end, int insn_count, rtx loop_start) asm("_check_dbra_loop");
static int
check_dbra_loop(rtx loop_end, int insn_count, rtx loop_start)
{
  struct n64_tag_iv_class *bl;
  rtx reg;
  rtx jump_label;
  rtx final_value;
  rtx start_value;
  rtx new_add_val;
  rtx comparison;
  rtx before_comparison;
  rtx p;




  comparison = get_condition_for_loop (((loop_end)->fld[1].rtx));
  if (comparison == 0)
    return 0;






  for (bl = loop_iv_list; bl; bl = bl->next)
    {
      if (bl->biv_count == 1
   && bl->biv->dest_reg == ((comparison)->fld[0].rtx)
   && ! reg_used_between_p (regno_reg_rtx[bl->regno], bl->biv->insn,
       ((((loop_end)->fld[1].rtx))->fld[1].rtx)))
 break;
    }

  if (! bl)
    return 0;






  if (((((comparison)->code) == GT
 && ((((comparison)->fld[1].rtx))->code) == CONST_INT
 && ((((comparison)->fld[1].rtx))->fld[0].rtwint) == -1)
       || (((comparison)->code) == NE && ((comparison)->fld[1].rtx) == const0_rtx))
      && ((bl->biv->add_val)->code) == CONST_INT
      && ((bl->biv->add_val)->fld[0].rtwint) < 0)
    {




      if (((bl->initial_value)->code) == CONST_INT
   && ((bl->initial_value)->fld[0].rtwint) > 0
   && (((bl->initial_value)->fld[0].rtwint) %
       (-((bl->biv->add_val)->fld[0].rtwint))) == 0)
 {

   ((((loop_end)->fld[1].rtx))->fld[6].rtx)
     = gen_rtx (EXPR_LIST, REG_NONNEG, (rtx) 0,
         ((((loop_end)->fld[1].rtx))->fld[6].rtx));
   bl->nonneg = 1;

   return 1;
 }



      for (p = loop_start; p; p = ((p)->fld[1].rtx))
 {
   if (((p)->code) == CODE_LABEL)
     break;
   if (((p)->code) != JUMP_INSN)
     continue;

   before_comparison = get_condition_for_loop (p);
   if (before_comparison
       && ((before_comparison)->fld[0].rtx) == bl->biv->dest_reg
       && ((before_comparison)->code) == LT
       && ((before_comparison)->fld[1].rtx) == const0_rtx
       && ! reg_set_between_p (bl->biv->dest_reg, p, loop_start)
       && ((bl->biv->add_val)->fld[0].rtwint) == -1)
     {
       ((((loop_end)->fld[1].rtx))->fld[6].rtx)
  = gen_rtx (EXPR_LIST, REG_NONNEG, (rtx) 0,
      ((((loop_end)->fld[1].rtx))->fld[6].rtx));
       bl->nonneg = 1;

       return 1;
     }
 }
    }
  else if (num_mem_sets <= 1)
    {
      int num_nonfixed_reads = 0;

      int no_use_except_counting = 0;


      int reversible_mem_store = 1;

      for (p = loop_start; p != loop_end; p = ((p)->fld[2].rtx))
 if ((rtx_class[(int)(((p)->code))]) == 'i')
   num_nonfixed_reads += count_nonfixed_reads (((p)->fld[3].rtx));

      if (bl->giv_count == 0
   && ! loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]])
 {
   rtx bivreg = regno_reg_rtx[bl->regno];




   no_use_except_counting = 1;
   for (p = loop_start; p != loop_end; p = ((p)->fld[2].rtx))
     if ((rtx_class[(int)(((p)->code))]) == 'i')
       {
  rtx set = single_set (p);

  if (set && ((((set)->fld[0].rtx))->code) == REG
      && ((((set)->fld[0].rtx))->fld[0].rtint) == bl->regno)

    ;
  else if (p == prev_nonnote_insn (prev_nonnote_insn (loop_end))
    || p == prev_nonnote_insn (loop_end))

    ;
  else if (reg_mentioned_p (bivreg, ((p)->fld[3].rtx)))

    {
      no_use_except_counting = 0;
      break;
    }
       }
 }







      if (num_mem_sets == 1)
 reversible_mem_store
   = (! unknown_address_altered
      && ! invariant_p (((loop_store_mems[0])->fld[0].rtx)));







      if (num_nonfixed_reads <= 1
   && !loop_has_call
   && !loop_has_volatile
   && reversible_mem_store
   && (no_use_except_counting
       || ((bl->giv_count + bl->biv_count + num_mem_sets
     + num_movables + 2 == insn_count)
    && (bl == loop_iv_list && bl->next == 0))))
 {
   rtx tem;


   if (loop_dump_stream)
     fprintf (loop_dump_stream, "Can reverse loop\n");
   if (comparison && bl->initial_value == const0_rtx
       && ((((comparison)->fld[1].rtx))->code) == CONST_INT

       && ((comparison)->code) == LT
       && (((((comparison)->fld[1].rtx))->fld[0].rtwint)
    % ((bl->biv->add_val)->fld[0].rtwint)) == 0)
     {




       reg = bl->biv->dest_reg;
       jump_label = ((((((((loop_end)->fld[1].rtx))->fld[3].rtx))->fld[1].rtx))->fld[1].rtx);
       new_add_val = gen_rtx (CONST_INT, VOIDmode, (int) (- ((bl->biv->add_val)->fld[0].rtwint)));

       final_value = ((comparison)->fld[1].rtx);
       start_value = gen_rtx (CONST_INT, VOIDmode, (int) (((((comparison)->fld[1].rtx))->fld[0].rtwint) - ((bl->biv->add_val)->fld[0].rtwint)))
                                     ;




       emit_insn_before (gen_move_insn (reg, start_value), loop_start);



       p = emit_insn_before (gen_add2_insn (reg, new_add_val),
        bl->biv->insn);
       delete_insn (bl->biv->insn);


       bl->biv->insn = p;
       bl->initial_value = start_value;
       bl->biv->add_val = new_add_val;



       ((((jump_label)->fld[0].rtx))->fld[5].rtint) ++;



       if ((regno_last_uid[bl->regno]
     != ((((((loop_end)->fld[1].rtx))->fld[1].rtx))->fld[0].rtint))
    || ! bl->init_insn
    || regno_first_uid[bl->regno] != ((bl->init_insn)->fld[0].rtint))
  emit_insn_after (gen_move_insn (reg, final_value),
     loop_end);


       delete_insn (((loop_end)->fld[1].rtx));
       delete_insn (((loop_end)->fld[1].rtx));


       start_sequence ();
       emit_cmp_insn (reg, const0_rtx, GE, (rtx) 0,
        ((reg)->mode), 0, 0);
       emit_jump_insn (gen_bge (((jump_label)->fld[0].rtx)));
       tem = gen_sequence ();
       end_sequence ();
       emit_jump_insn_before (tem, loop_end);

       for (tem = ((loop_end)->fld[1].rtx);
     tem && ((tem)->code) != JUMP_INSN; tem = ((tem)->fld[1].rtx))
  ;
       if (tem)
  {
    ((tem)->fld[7].rtx) = ((jump_label)->fld[0].rtx);




    ((tem)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_NONNEG, (rtx) 0,
          ((tem)->fld[6].rtx));
  }

       bl->nonneg = 1;





       bl->reversed = 1;

       if (loop_dump_stream)
  fprintf (loop_dump_stream,
    "Reversed loop and added reg_nonneg\n");

       return 1;
     }
 }
    }

  return 0;
}
static int
maybe_eliminate_biv(struct n64_tag_iv_class *bl, rtx loop_start, rtx end, int eliminate_p, int threshold, int insn_count) asm("_maybe_eliminate_biv");
static int
maybe_eliminate_biv(struct n64_tag_iv_class *bl, rtx loop_start, rtx end, int eliminate_p, int threshold, int insn_count)
{
  rtx reg = bl->biv->dest_reg;
  rtx p;




  for (p = loop_start; p != end; p = ((p)->fld[2].rtx))
    {
      n64_enum_rtx_code code = ((p)->code);
      rtx where = threshold >= insn_count ? loop_start : p;

      if ((code == INSN || code == JUMP_INSN || code == CALL_INSN)
   && reg_mentioned_p (reg, ((p)->fld[3].rtx))
   && ! maybe_eliminate_biv_1 (((p)->fld[3].rtx), p, bl, eliminate_p, where))
 {
   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Cannot eliminate biv %d: biv used in insn %d.\n",
       bl->regno, ((p)->fld[0].rtint));
   break;
 }
    }

  if (p == end)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream, "biv %d %s eliminated.\n",
   bl->regno, eliminate_p ? "was" : "can be");
      return 1;
    }

  return 0;
}
static int
maybe_eliminate_biv_1(rtx x, rtx insn, struct n64_tag_iv_class *bl, int eliminate_p, rtx where) asm("_maybe_eliminate_biv_1");
static int
maybe_eliminate_biv_1(rtx x, rtx insn, struct n64_tag_iv_class *bl, int eliminate_p, rtx where)
{
  n64_enum_rtx_code code = ((x)->code);
  rtx reg = bl->biv->dest_reg;
  n64_enum_machine_mode mode = ((reg)->mode);
  struct n64_tag_induction *v;
  rtx arg, cxx_new, tem;
  int arg_operand;
  char *fmt;
  int i, j;

  switch (code)
    {
    case REG:


      if (x == reg)
 return 0;
      return 1;

    case SET:

      if (((x)->fld[0].rtx) == reg)
 return 1;



      for (v = bl->giv; v; v = v->next_iv)
 if (v->giv_type == DEST_REG && ((x)->fld[0].rtx) == v->dest_reg)
   return 1;
      break;

    case COMPARE:
    case EQ: case NE:
    case GT: case GE: case GTU: case GEU:
    case LT: case LE: case LTU: case LEU:

      if (((x)->fld[0].rtx) == reg)
 arg = ((x)->fld[1].rtx), arg_operand = 1;
      else if (((x)->fld[1].rtx) == reg)
 arg = ((x)->fld[0].rtx), arg_operand = 0;
      else
 break;

      if ((((arg)->code) == LABEL_REF || ((arg)->code) == SYMBOL_REF || ((arg)->code) == CONST_INT || ((arg)->code) == CONST_DOUBLE || ((arg)->code) == CONST || ((arg)->code) == HIGH))
 {




   for (v = bl->giv; v; v = v->next_iv)
     if ((((v->mult_val)->code) == LABEL_REF || ((v->mult_val)->code) == SYMBOL_REF || ((v->mult_val)->code) == CONST_INT || ((v->mult_val)->code) == CONST_DOUBLE || ((v->mult_val)->code) == CONST || ((v->mult_val)->code) == HIGH) && ((v->mult_val)->fld[0].rtwint) > 0
  && (((v->add_val)->code) == LABEL_REF || ((v->add_val)->code) == SYMBOL_REF || ((v->add_val)->code) == CONST_INT || ((v->add_val)->code) == CONST_DOUBLE || ((v->add_val)->code) == CONST || ((v->add_val)->code) == HIGH)
  && ! v->ignore && ! v->maybe_dead && v->always_computable
  && v->mode == mode)
       {
  if (! eliminate_p)
    return 1;


  ((x)->fld[1-arg_operand].rtx) = v->new_reg;




  if (((arg)->code) == CONST_INT
      && ((v->mult_val)->code) == CONST_INT
      && ((v->add_val)->code) == CONST_INT
      && validate_change (insn, &((x)->fld[arg_operand].rtx),
     gen_rtx (CONST_INT, VOIDmode, (int) (((arg)->fld[0].rtwint) * ((v->mult_val)->fld[0].rtwint) + ((v->add_val)->fld[0].rtwint)))

                             , 0))
    return 1;


  tem = gen_reg_rtx (mode);
  emit_iv_add_mult (arg, v->mult_val, v->add_val, tem, where);
  if (validate_change (insn, &((x)->fld[arg_operand].rtx), tem, 0))
    return 1;


  ((x)->fld[1-arg_operand].rtx) = reg;
       }




   for (v = bl->giv; v; v = v->next_iv)
     if ((((v->mult_val)->code) == LABEL_REF || ((v->mult_val)->code) == SYMBOL_REF || ((v->mult_val)->code) == CONST_INT || ((v->mult_val)->code) == CONST_DOUBLE || ((v->mult_val)->code) == CONST || ((v->mult_val)->code) == HIGH) && ((v->mult_val)->fld[0].rtwint) > 0
  && ! v->ignore && ! v->maybe_dead && v->always_computable
  && v->mode == mode)
       {
  rtx tem;

  if (! eliminate_p)
    return 1;

  tem = gen_reg_rtx (mode);


  validate_change (insn, &((x)->fld[1 - arg_operand].rtx),
     v->new_reg, 1);


  emit_iv_add_mult (arg, v->mult_val, v->add_val, tem, where);

  validate_change (insn, &((x)->fld[arg_operand].rtx), tem, 1);
  if (apply_change_group ())
    return 1;
       }
 }
      else if (((arg)->code) == REG || ((arg)->code) == MEM)
 {
   if (invariant_p (arg) == 1)
     {



       for (v = bl->giv; v; v = v->next_iv)
  if ((((v->mult_val)->code) == LABEL_REF || ((v->mult_val)->code) == SYMBOL_REF || ((v->mult_val)->code) == CONST_INT || ((v->mult_val)->code) == CONST_DOUBLE || ((v->mult_val)->code) == CONST || ((v->mult_val)->code) == HIGH) && ((v->mult_val)->fld[0].rtwint) > 0
      && ! v->ignore && ! v->maybe_dead && v->always_computable
      && v->mode == mode)
    {
      rtx tem;

      if (! eliminate_p)
        return 1;

      tem = gen_reg_rtx (mode);


      validate_change (insn, &((x)->fld[1 - arg_operand].rtx),
         v->new_reg, 1);


      emit_iv_add_mult (arg, v->mult_val, v->add_val,
          tem, where);
      validate_change (insn, &((x)->fld[arg_operand].rtx), tem, 1);
      if (apply_change_group ())
        return 1;
    }
     }
 }


      return 0;

    case MEM:


      for (v = bl->giv; v; v = v->next_iv)
 if (v->giv_type == DEST_ADDR && v->location == &((x)->fld[0].rtx))
   return 1;
      break;
    }


  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'e':
   if (! maybe_eliminate_biv_1 (((x)->fld[i].rtx), insn, bl,
           eliminate_p, where))
     return 0;
   break;

 case 'E':
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (! maybe_eliminate_biv_1 (((x)->fld[i].rtvec->elem[j].rtx), insn, bl,
      eliminate_p, where))
       return 0;
   break;
 }
    }

  return 1;
}




static int
last_use_this_basic_block(rtx reg, rtx insn) asm("_last_use_this_basic_block");
static int
last_use_this_basic_block(rtx reg, rtx insn)
{
  rtx n;
  for (n = insn;
       n && ((n)->code) != CODE_LABEL && ((n)->code) != JUMP_INSN;
       n = ((n)->fld[2].rtx))
    {
      if (regno_last_uid[((reg)->fld[0].rtint)] == ((n)->fld[0].rtint))
 return 1;
    }
  return 0;
}




static void
record_initial(rtx dest, rtx set) asm("_record_initial");
static void
record_initial(rtx dest, rtx set)
{
  struct n64_tag_iv_class *bl;

  if (((dest)->code) != REG
      || ((dest)->fld[0].rtint) >= max_reg_before_loop
      || reg_iv_type[((dest)->fld[0].rtint)] != BASIC_INDUCT)
    return;

  bl = reg_biv_class[((dest)->fld[0].rtint)];


  if (bl->init_insn == 0)
    {
      bl->init_insn = note_insn;
      bl->init_set = set;
    }
}






static void
update_reg_last_use(rtx x, rtx insn) asm("_update_reg_last_use");
static void
update_reg_last_use(rtx x, rtx insn)
{




  if (((x)->code) == REG && ((x)->fld[0].rtint) < max_reg_before_loop
      && ((insn)->fld[0].rtint) < max_uid_for_loop
      && uid_luid[regno_last_uid[((x)->fld[0].rtint)]] < uid_luid[((insn)->fld[0].rtint)])
    regno_last_uid[((x)->fld[0].rtint)] = ((insn)->fld[0].rtint);
  else
    {
      register int i, j;
      register char *fmt = (rtx_format[(int)(((x)->code))]);
      for (i = (rtx_length[(int)(((x)->code))]) - 1; i >= 0; i--)
 {
   if (fmt[i] == 'e')
     update_reg_last_use (((x)->fld[i].rtx), insn);
   else if (fmt[i] == 'E')
     for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
       update_reg_last_use (((x)->fld[i].rtvec->elem[j].rtx), insn);
 }
    }
}
rtx
get_condition(rtx jump, rtx *earliest) asm("_get_condition");
rtx
get_condition(rtx jump, rtx *earliest)
{
  n64_enum_rtx_code code;
  rtx prev = jump;
  rtx set;
  rtx tem;
  rtx op0, op1;
  int reverse_code = 0;
  int did_reverse_condition = 0;


  if (((jump)->code) != JUMP_INSN
      || ! condjump_p (jump) || simplejump_p (jump))
    return 0;

  code = ((((((((jump)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->code);
  op0 = ((((((((jump)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[0].rtx);
  op1 = ((((((((jump)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx);

  if (earliest)
    *earliest = jump;



  if (((((((((jump)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->code) == LABEL_REF
      && ((((((((jump)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->fld[0].rtx) == ((jump)->fld[7].rtx))
    code = reverse_condition (code), did_reverse_condition ^= 1;






  while ((rtx_class[(int)(code)]) == '<' && op1 == (const_tiny_rtx[0][(int) (((op0)->mode))]))
    {

      rtx x = 0;
      if (((op0)->code) == COMPARE)
 {
   op1 = ((op0)->fld[1].rtx);
   op0 = ((op0)->fld[0].rtx);
   continue;
 }
      else if (((op0)->code) != REG)
 break;





      if ((prev = prev_nonnote_insn (prev)) == 0
   || ((prev)->code) != INSN
   || 0
   || (set = single_set (prev)) == 0)
 break;



      if (((set)->fld[0].rtx) == op0)
 {
   n64_enum_machine_mode inner_mode = ((((set)->fld[1].rtx))->mode);

   if ((((((set)->fld[1].rtx))->code) == COMPARE
        || (((code == NE
       || (code == LT
    && (mode_class[(int)(inner_mode)]) == MODE_INT
    && ((8 * mode_size[(int)(inner_mode)])
        <= 32)
    && (1
        & ((int) 1
    << ((8 * mode_size[(int)(inner_mode)]) - 1))))





       ))
     && (rtx_class[(int)(((((set)->fld[1].rtx))->code))]) == '<')))
     x = ((set)->fld[1].rtx);
   else if (((code == EQ
       || (code == GE
    && ((8 * mode_size[(int)(inner_mode)])
        <= 32)
    && (mode_class[(int)(inner_mode)]) == MODE_INT
    && (1
        & ((int) 1
    << ((8 * mode_size[(int)(inner_mode)]) - 1))))





       ))
     && (rtx_class[(int)(((((set)->fld[1].rtx))->code))]) == '<')
     {



       did_reverse_condition ^= 1;
       reverse_code = 1;
       x = ((set)->fld[1].rtx);
     }
   else
     break;
 }

      else if (reg_set_p (op0, prev))

 break;

      if (x)
 {
   if ((rtx_class[(int)(((x)->code))]) == '<')
     code = ((x)->code);
   if (reverse_code)
     {
       code = reverse_condition (code);
       did_reverse_condition ^= 1;
       reverse_code = 0;
     }

   op0 = ((x)->fld[0].rtx), op1 = ((x)->fld[1].rtx);
   if (earliest)
     *earliest = prev;
 }
    }


  if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
    code = swap_condition (code), tem = op0, op0 = op1, op1 = tem;



  if ((mode_class[(int)(((op0)->mode))]) == MODE_CC)
    return 0;





  if (((op1)->code) == CONST_INT
      && ((op0)->mode) != VOIDmode
      && (8 * mode_size[(int)(((op0)->mode))]) <= 32)
    {
      int const_val = ((op1)->fld[0].rtwint);
      unsigned int uconst_val = const_val;
      unsigned int max_val
 = (unsigned int) (((8 * mode_size[(int)(((op0)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((op0)->mode))])) - 1));

      switch (code)
 {
 case LE:
   if (const_val != max_val >> 1)
     code = LT, op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_val + 1));
   break;

 case GE:
   if (const_val
       != (((int) 1
     << ((8 * mode_size[(int)(((op0)->mode))]) - 1))))
     code = GT, op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_val - 1));
   break;

 case LEU:
   if (uconst_val != max_val)
     code = LTU, op1 = gen_rtx (CONST_INT, VOIDmode, (int) (uconst_val + 1));
   break;

 case GEU:
   if (uconst_val != 0)
     code = GTU, op1 = gen_rtx (CONST_INT, VOIDmode, (int) (uconst_val - 1));
   break;
 }
    }



  if (1 == 1
      && did_reverse_condition && code != NE && code != EQ
      && ! flag_fast_math
      && (mode_class[(int)(((op0)->mode))]) == MODE_FLOAT)
    return 0;







  return gen_rtx (code, VOIDmode, op0, op1);
}




rtx
get_condition_for_loop(rtx x) asm("_get_condition_for_loop");
rtx
get_condition_for_loop(rtx x)
{
  rtx comparison = get_condition (x, ((void *)0));

  if (comparison == 0
      || ! invariant_p (((comparison)->fld[0].rtx))
      || invariant_p (((comparison)->fld[1].rtx)))
    return comparison;

  return gen_rtx (swap_condition (((comparison)->code)), VOIDmode,
    ((comparison)->fld[1].rtx), ((comparison)->fld[0].rtx));
}

