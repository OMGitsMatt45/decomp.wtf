// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/read.c
/* read.c - read a source file -
   Copyright (C) 1986, 1987, 1990, 1991, 1993, 1994
   Free Software Foundation, Inc.

This file is part of GAS, the GNU Assembler.

GAS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GAS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GAS; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_FLONUM_STRUCT;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__pseudo_type;
struct n64_tag__symbol_info;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_bit_fix;
struct n64_tag_carsym;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_emulation;
struct n64_tag_expressionS;
struct n64_tag_fix;
struct n64_tag_format_ops;
struct n64_tag_frag;
struct n64_tag_frchain;
struct n64_tag_hash_control;
struct n64_tag_hash_entry;
struct n64_tag_le;
struct n64_tag_lineno_cache_entry;
struct n64_tag_mips_cl_insn;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relax_type;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sb;
struct n64_tag_sec;
struct n64_tag_symbol;
struct n64_tag_symbol_cache_entry;










extern char *strdup(...) asm("_strdup");


struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");



extern void * bfd_alloc_by_size_t (bfd *abfd, size_t sz) asm("_bfd_alloc_by_size_t");
extern char *strstr(...) asm("_strstr");

typedef unsigned short LITTLENUM_TYPE;







int bignum_copy (LITTLENUM_TYPE * in, int in_length, LITTLENUM_TYPE * out, int out_length) asm("_bignum_copy")
                                          ;
struct n64_tag_FLONUM_STRUCT
{
  LITTLENUM_TYPE *low;
  LITTLENUM_TYPE *high;
  LITTLENUM_TYPE *leader;

  long exponent;
  char sign;
};

typedef struct n64_tag_FLONUM_STRUCT FLONUM_TYPE;
extern const FLONUM_TYPE flonum_positive_powers_of_ten[];
extern const FLONUM_TYPE flonum_negative_powers_of_ten[];
extern const int table_size_of_flonum_powers_of_ten;
int atof_generic (char **address_of_string_pointer, const char *string_of_decimal_marks, const char *string_of_decimal_exponent_marks, FLONUM_TYPE * address_of_generic_floating_point_number) asm("_atof_generic")


                                                             ;

void flonum_copy (FLONUM_TYPE * in, FLONUM_TYPE * out) asm("_flonum_copy");
void flonum_multip (const FLONUM_TYPE * a, const FLONUM_TYPE * b, FLONUM_TYPE * product) asm("_flonum_multip")
                              ;




extern bfd *stdoutput;
typedef bfd_vma addressT;
typedef bfd_signed_vma offsetT;






typedef addressT valueT;
typedef asection *segT;





typedef int subsegT;


extern subsegT now_subseg;


extern segT now_seg;
extern segT reg_section, expr_section;

extern segT text_section, data_section, bss_section;
enum n64_cpp_enum__relax_state{



    rs_fill = 1,


    rs_align,



    rs_align_code,



    rs_org,



    rs_broken_word,



    rs_machine_dependent,





    rs_space
  };
typedef __underlying_type(enum n64_cpp_enum__relax_state) n64_enum__relax_state;


typedef n64_enum__relax_state relax_stateT;



typedef unsigned int relax_substateT;



typedef addressT relax_addressT;
struct n64_tag_frag
{

  addressT fr_address;

  struct n64_tag_frag *fr_next;


  offsetT fr_fix;

  offsetT fr_var;

  struct n64_tag_symbol *fr_symbol;

  offsetT fr_offset;

  char *fr_opcode;


  struct list_info_struct *line;



  relax_stateT fr_type;
  relax_substateT fr_subtype;



  unsigned short align_mask;
  unsigned short align_offset;
  char fr_pcrel_adjust, fr_bsr;


  char fr_literal[1];
};





typedef struct n64_tag_frag fragS;




extern fragS *frag_now;
extern int frag_now_fix(void) asm("_frag_now_fix");


extern fragS zero_address_frag;

extern fragS bss_address_frag;



extern unsigned char flag_no_comments;
extern unsigned char flag_debug;
extern unsigned char flag_signed_overflow_ok;

extern unsigned char flag_warn_displacement;



extern int flag_keep_locals;


extern int flag_mri;



extern unsigned char flag_readonly_data_in_text;


extern int flag_no_warnings;



extern unsigned char flag_always_generate_output;



extern unsigned char flag_print_statistics;


extern char *out_file_name;


extern int need_pass_2;



extern int linkrelax;


extern int listing;


extern int max_macro_nest;



extern int chunksize;

struct n64_tag__pseudo_type
  {

    const char *poc_name;

    void (*poc_handler) (int);

    int poc_val;
  };

typedef struct n64_tag__pseudo_type pseudo_typeS;
void as_bad (const char *format, ...) asm("_as_bad") __attribute__ ((format (printf, 1, 2)));
void as_fatal (const char *format, ...) asm("_as_fatal") __attribute__ ((format (printf, 1, 2)));
void as_tsktsk (const char *format, ...) asm("_as_tsktsk") __attribute__ ((format (printf, 1, 2)));
void as_warn (const char *format, ...) asm("_as_warn") __attribute__ ((format (printf, 1, 2)));
void as_bad_where (char *file, unsigned int line, const char *format, ...) asm("_as_bad_where") __attribute__ ((format (printf, 3, 4)));
void as_warn_where (char *file, unsigned int line, const char *format, ...) asm("_as_warn_where") __attribute__ ((format (printf, 3, 4)));
void as_assert (const char *, int, const char *) asm("_as_assert");
void as_abort (const char *, int, const char *) asm("_as_abort");

void fprint_value (FILE *file, addressT value) asm("_fprint_value");
void sprint_value (char *buf, addressT value) asm("_sprint_value");

int had_errors (void) asm("_had_errors");
int had_warnings (void) asm("_had_warnings");

void print_version_id (void) asm("_print_version_id");
char *app_push (void) asm("_app_push");
char *atof_ieee (char *str, int what_kind, LITTLENUM_TYPE * words) asm("_atof_ieee");
char *input_scrub_include_file (char *filename, char *position) asm("_input_scrub_include_file");
char *input_scrub_new_file (char *filename) asm("_input_scrub_new_file");
char *input_scrub_next_buffer (char **bufp) asm("_input_scrub_next_buffer");
void * xmalloc (unsigned long size) asm("_xmalloc");
void * xrealloc (void * ptr, unsigned long n) asm("_xrealloc");
int do_scrub_chars (int (*get) (char **), char *to, int tolen) asm("_do_scrub_chars");
int gen_to_words (LITTLENUM_TYPE * words, int precision, long exponent_bits) asm("_gen_to_words")
                         ;
int had_err (void) asm("_had_err");
int ignore_input (void) asm("_ignore_input");
int seen_at_least_1_file (void) asm("_seen_at_least_1_file");
void app_pop (char *arg) asm("_app_pop");
void as_howmuch (FILE * stream) asm("_as_howmuch");
void as_perror (const char *gripe, const char *filename) asm("_as_perror");
void as_where (char **namep, unsigned int *linep) asm("_as_where");
void bump_line_counters (void) asm("_bump_line_counters");
void do_scrub_begin (void) asm("_do_scrub_begin");
void input_scrub_begin (void) asm("_input_scrub_begin");
void input_scrub_close (void) asm("_input_scrub_close");
void input_scrub_end (void) asm("_input_scrub_end");
void new_logical_line (char *fname, int line_number) asm("_new_logical_line");
void subsegs_begin (void) asm("_subsegs_begin");
void subseg_change (segT seg, int subseg) asm("_subseg_change");
segT subseg_new (const char *name, subsegT subseg) asm("_subseg_new");
segT subseg_force_new (const char *name, subsegT subseg) asm("_subseg_force_new");
void subseg_set (segT seg, subsegT subseg) asm("_subseg_set");

segT subseg_get (const char *, int) asm("_subseg_get");


struct n64_tag_expressionS;
struct n64_tag_fix;
struct n64_tag_symbol;
struct n64_tag_relax_type;



valueT add_to_literal_pool (struct n64_tag_symbol *, valueT, segT, int) asm("_add_to_literal_pool");


enum n64_cpp_enum_anonymous_11{

  O_illegal,

  O_absent,

  O_constant,

  O_symbol,

  O_symbol_rva,

  O_register,




  O_big,

  O_uminus,

  O_bit_not,

  O_logical_not,

  O_multiply,

  O_divide,

  O_modulus,

  O_left_shift,

  O_right_shift,

  O_bit_inclusive_or,

  O_bit_or_not,

  O_bit_exclusive_or,

  O_bit_and,

  O_add,

  O_subtract,

  O_eq,

  O_ne,

  O_lt,

  O_le,

  O_ge,

  O_gt,

  O_logical_and,

  O_logical_or
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_11) n64_enum_anonymous_11;
typedef n64_enum_anonymous_11 operatorT;

typedef struct n64_tag_expressionS
{

  operatorT X_op;

  struct n64_tag_symbol *X_add_symbol;

  struct n64_tag_symbol *X_op_symbol;

  offsetT X_add_number;






  int X_unsigned;
} expressionS;







extern FLONUM_TYPE generic_floating_point_number;

extern LITTLENUM_TYPE generic_bignum[];



typedef char operator_rankT;

char get_symbol_end (void) asm("_get_symbol_end");
void expr_begin (void) asm("_expr_begin");
segT expr (int rank, expressionS * resultP) asm("_expr");
unsigned int get_single_number (void) asm("_get_single_number");
struct n64_tag_symbol *make_expr_symbol (expressionS * expressionP) asm("_make_expr_symbol");


typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");
extern int mips_local_label (const char *) asm("_mips_local_label");
extern const char *mips_target_format(void) asm("_mips_target_format");

struct n64_tag_mips_cl_insn {
    unsigned long insn_opcode;
    const struct mips_opcode *insn_mo;
};

extern int tc_get_register (int frame) asm("_tc_get_register");


extern int mips_parse_long_option (const char *) asm("_mips_parse_long_option");


extern void mips_define_label (struct n64_tag_symbol *) asm("_mips_define_label");


extern void cons_fix_new_mips(...) asm("_cons_fix_new_mips");




extern int mips_force_relocation(...) asm("_mips_force_relocation");






extern unsigned long mips_gprmask;
extern unsigned long mips_cprmask[4];




extern void mips_elf_final_processing (void) asm("_mips_elf_final_processing");
extern void md_mips_end (void) asm("_md_mips_end");





extern void mips_pop_insert (void) asm("_mips_pop_insert");


extern void mips_flush_pending_output (void) asm("_mips_flush_pending_output");


extern void mips_enable_auto_align (void) asm("_mips_enable_auto_align");


extern void mips_init_after_args (void) asm("_mips_init_after_args");
extern asection *gdb_section;



extern void elf_frob_file (void) asm("_elf_frob_file");
extern void elf_file_symbol (char *) asm("_elf_file_symbol");


extern void obj_elf_section (int) asm("_obj_elf_section");
extern void obj_elf_previous (int) asm("_obj_elf_previous");
extern void obj_elf_version (int) asm("_obj_elf_version");
extern void obj_elf_init_stab_section (segT) asm("_obj_elf_init_stab_section");
extern void elf_frob_symbol (struct n64_tag_symbol *, int *) asm("_elf_frob_symbol");


extern void elf_pop_insert (void) asm("_elf_pop_insert");

struct n64_tag_symbol
{
  asymbol *bsym;



  expressionS sy_value;


  struct n64_tag_symbol *sy_next;

  struct n64_tag_symbol *sy_previous;




  struct n64_tag_frag *sy_frag;

  unsigned int written : 1;


  unsigned int sy_resolved : 1;


  unsigned int sy_resolving : 1;



  unsigned int sy_used_in_reloc : 1;





  unsigned int sy_used : 1;





  unsigned int sy_mri_common : 1;


  expressionS * sy_obj;







  int local:1; unsigned long sy_name_offset;

};

typedef struct n64_tag_symbol symbolS;
extern const segT N_TYPE_seg[];


extern const short seg_N_TYPE[];



void symbol_clear_list_pointers (symbolS * symbolP) asm("_symbol_clear_list_pointers");



void symbol_insert (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_insert")
                                           ;
void symbol_remove (symbolS * symbolP, symbolS ** rootP, symbolS ** lastP) asm("_symbol_remove")
                         ;





void verify_symbol_chain (symbolS * rootP, symbolS * lastP) asm("_verify_symbol_chain");
void verify_symbol_chain_2 (symbolS * symP) asm("_verify_symbol_chain_2");

void symbol_append (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_append")
                                           ;
struct n64_tag_bit_fix
  {
    int fx_bit_size;
    int fx_bit_offset;
    long fx_bit_base;

    long fx_bit_base_adj;
    long fx_bit_max;
    long fx_bit_min;
    long fx_bit_add;
  };
typedef struct n64_tag_bit_fix bit_fixS;





struct n64_tag_fix
{




  char fx_pcrel_adjust;


  unsigned char fx_size;


  unsigned fx_pcrel : 1;






  unsigned fx_plt : 1;



  unsigned fx_im_disp : 2;



  unsigned fx_tcbit : 1;


  unsigned fx_done : 1;






  unsigned fx_no_overflow : 1;


  fragS *fx_frag;


  long fx_where;


  symbolS *fx_addsy;


  symbolS *fx_subsy;


  valueT fx_offset;


  struct n64_tag_fix *fx_next;




  bit_fixS *fx_bit_fixP;


  bfd_reloc_code_real_type fx_r_type;
  valueT fx_addnumber;



  char *fx_file;
  unsigned fx_line;






};

typedef struct n64_tag_fix fixS;
extern long string_byte_count;
extern int section_alignment[];

bit_fixS *bit_fix_new (int size, int offset, long base_type, long base_adj, long min, long max, long add) asm("_bit_fix_new")
                                                       ;
void append (char **charPP, char *fromP, unsigned long length) asm("_append");
void record_alignment (segT seg, int align) asm("_record_alignment");
void write_object_file (void) asm("_write_object_file");
void relax_segment (struct n64_tag_frag * seg_frag_root, segT seg_type) asm("_relax_segment");

void number_to_chars_littleendian (char *, valueT, int) asm("_number_to_chars_littleendian");
void number_to_chars_bigendian (char *, valueT, int) asm("_number_to_chars_bigendian");


fixS *fix_new (fragS * frag, int where, int size, symbolS * add_symbol, offsetT offset, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new")

                                          ;
fixS *fix_new_exp (fragS * frag, int where, int size, expressionS *exp, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new_exp")

                                       ;
extern void frag_append_1_char (int) asm("_frag_append_1_char");




void frag_init (void) asm("_frag_init");
void frag_grow (unsigned int nchars) asm("_frag_grow");
char *frag_more (int nchars) asm("_frag_more");
void frag_align (int alignment, int fill_character) asm("_frag_align");
void frag_align_pattern (int alignment, const char *fill_pattern, int n_fill) asm("_frag_align_pattern")

                 ;
void frag_new (int old_frags_var_max_size) asm("_frag_new");
void frag_wane (fragS * fragP) asm("_frag_wane");

char *frag_variant (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_variant")





                     ;

char *frag_var (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_var")





                 ;
struct n64_tag_hash_entry
{
  const char *hash_string;


  void * hash_value;
};



struct n64_tag_hash_control
{
  struct n64_tag_hash_entry *hash_where;
  int hash_sizelog;
  int hash_mask;
  int hash_full;

  struct n64_tag_hash_entry *hash_wall;

  int hash_stat[(6)];

};



struct n64_tag_hash_control *hash_new (void) asm("_hash_new");
void hash_die (struct n64_tag_hash_control *) asm("_hash_die");
void hash_say (struct n64_tag_hash_control *, int *buffer, int bufsiz) asm("_hash_say");

void * hash_delete (struct n64_tag_hash_control *, const char *str) asm("_hash_delete");

void * hash_replace (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_replace");

const char *hash_insert (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_insert")
              ;

char *hash_apply (struct n64_tag_hash_control *, char *(*fn) (const char *str, void * val)) asm("_hash_apply")
                                             ;

void * hash_find (struct n64_tag_hash_control *, const char *str) asm("_hash_find");

const char *hash_jam (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_jam")
                  ;
extern char *input_line_pointer;
extern char lex_type[];
extern char is_end_of_line[];

extern int target_big_endian;


extern const char comment_chars[];
extern const char line_comment_chars[];
extern const char line_separator_chars[];


extern int generate_asm_lineno;


extern addressT abs_section_offset;


extern symbolS *line_label;


extern symbolS *mri_common_symbol;

unsigned int get_stab_string_offset (const char *string, const char *stabstr_secname) asm("_get_stab_string_offset")
                                       ;

char *demand_copy_C_string (int *len_pointer) asm("_demand_copy_C_string");
char get_absolute_expression_and_terminator (long *val_pointer) asm("_get_absolute_expression_and_terminator");
offsetT get_absolute_expression (void) asm("_get_absolute_expression");
unsigned int next_char_of_string (void) asm("_next_char_of_string");
void s_mri_sect (char *) asm("_s_mri_sect");
char *mri_comment_field (char *) asm("_mri_comment_field");
void mri_comment_end (char *, int) asm("_mri_comment_end");
void add_include_dir (char *path) asm("_add_include_dir");
void cons (int nbytes) asm("_cons");
void demand_empty_rest_of_line (void) asm("_demand_empty_rest_of_line");
void emit_expr (expressionS *exp, unsigned int nbytes) asm("_emit_expr");
void equals (char *sym_name) asm("_equals");
void float_cons (int float_type) asm("_float_cons");
void ignore_rest_of_line (void) asm("_ignore_rest_of_line");
void pseudo_set (symbolS * symbolP) asm("_pseudo_set");
void read_a_source_file (char *name) asm("_read_a_source_file");
void read_begin (void) asm("_read_begin");
void s_abort (int) asm("_s_abort");
void s_align_bytes (int arg) asm("_s_align_bytes");
void s_align_ptwo (int) asm("_s_align_ptwo");
void s_app_file (int) asm("_s_app_file");
void s_app_line (int) asm("_s_app_line");
void s_comm (int) asm("_s_comm");
void s_data (int) asm("_s_data");
void s_desc (int) asm("_s_desc");
void s_else (int arg) asm("_s_else");
void s_end (int arg) asm("_s_end");
void s_endif (int arg) asm("_s_endif");
void s_err (int) asm("_s_err");
void s_fail (int) asm("_s_fail");
void s_fill (int) asm("_s_fill");
void s_float_space (int mult) asm("_s_float_space");
void s_globl (int arg) asm("_s_globl");
void s_if (int arg) asm("_s_if");
void s_ifc (int arg) asm("_s_ifc");
void s_ifdef (int arg) asm("_s_ifdef");
void s_ifeqs (int arg) asm("_s_ifeqs");
void s_ignore (int arg) asm("_s_ignore");
void s_include (int arg) asm("_s_include");
void s_irp (int arg) asm("_s_irp");
void s_lcomm (int needs_align) asm("_s_lcomm");
void s_lsym (int) asm("_s_lsym");
void s_macro (int) asm("_s_macro");
void s_mexit (int) asm("_s_mexit");
void s_mri_common (int) asm("_s_mri_common");
void s_org (int) asm("_s_org");
void s_print (int) asm("_s_print");
void s_purgem (int) asm("_s_purgem");
void s_rept (int) asm("_s_rept");
void s_set (int) asm("_s_set");
void s_space (int mult) asm("_s_space");
void s_stab (int what) asm("_s_stab");
void s_struct (int) asm("_s_struct");
void s_text (int) asm("_s_text");
void stringer (int append_zero) asm("_stringer");
void s_xstab (int what) asm("_s_xstab");
void s_rva (int) asm("_s_rva");
extern struct n64_tag_obstack notes;

extern struct n64_tag_obstack cond_obstack;


extern symbolS *symbol_rootP;
extern symbolS *symbol_lastP;

extern symbolS abs_symbol;

extern int symbol_table_frozen;



extern int symbols_case_sensitive;

char *decode_local_label_name (char *s) asm("_decode_local_label_name");
symbolS *symbol_find (const char *name) asm("_symbol_find");
symbolS *symbol_find_base (const char *name, int strip_underscore) asm("_symbol_find_base");
symbolS *symbol_find_or_make (const char *name) asm("_symbol_find_or_make");
symbolS *symbol_make (const char *name) asm("_symbol_make");
symbolS *symbol_new (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_new")
                      ;
symbolS *symbol_create (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_create")
                  ;
symbolS *colon (const char *sym_name) asm("_colon");
void local_colon (int n) asm("_local_colon");
void symbol_begin (void) asm("_symbol_begin");
void symbol_table_insert (symbolS * symbolP) asm("_symbol_table_insert");
void resolve_symbol_value (symbolS *) asm("_resolve_symbol_value");

int dollar_label_defined (long l) asm("_dollar_label_defined");
void dollar_label_clear (void) asm("_dollar_label_clear");
void define_dollar_label (long l) asm("_define_dollar_label");
char *dollar_label_name (long l, int augend) asm("_dollar_label_name");

void fb_label_instance_inc (long label) asm("_fb_label_instance_inc");
char *fb_label_name (long n, long augend) asm("_fb_label_name");

extern void copy_symbol_attributes (symbolS *, symbolS *) asm("_copy_symbol_attributes");


extern valueT S_GET_VALUE (symbolS *) asm("_S_GET_VALUE");
extern void S_SET_VALUE (symbolS *, valueT) asm("_S_SET_VALUE");


extern int S_IS_EXTERNAL (symbolS *) asm("_S_IS_EXTERNAL");
extern int S_IS_WEAK (symbolS *) asm("_S_IS_WEAK");
extern int S_IS_COMMON (symbolS *) asm("_S_IS_COMMON");
extern int S_IS_DEFINED (symbolS *) asm("_S_IS_DEFINED");
extern int S_IS_DEBUG (symbolS *) asm("_S_IS_DEBUG");
extern int S_IS_LOCAL (symbolS *) asm("_S_IS_LOCAL");
extern int S_IS_EXTERN (symbolS *) asm("_S_IS_EXTERN");
extern int S_IS_STABD (symbolS *) asm("_S_IS_STABD");
extern const char *S_GET_NAME (symbolS *) asm("_S_GET_NAME");
extern segT S_GET_SEGMENT (symbolS *) asm("_S_GET_SEGMENT");
extern void S_SET_SEGMENT (symbolS *, segT) asm("_S_SET_SEGMENT");
extern void S_SET_EXTERNAL (symbolS *) asm("_S_SET_EXTERNAL");
extern void S_SET_NAME (symbolS *, char *) asm("_S_SET_NAME");
extern void S_CLEAR_EXTERNAL (symbolS *) asm("_S_CLEAR_EXTERNAL");
extern void S_SET_WEAK (symbolS *) asm("_S_SET_WEAK");

extern const pseudo_typeS md_pseudo_table[];




struct n64_tag_relax_type
{

  long rlx_forward;

  long rlx_backward;


  unsigned char rlx_length;


  relax_substateT rlx_more;
};

typedef struct n64_tag_relax_type relax_typeS;

extern const int md_reloc_size;

char *md_atof (int what_statement_type, char *literalP, int *sizeP) asm("_md_atof");

int md_estimate_size_before_relax (fragS * fragP, segT segment) asm("_md_estimate_size_before_relax");

int md_parse_option (int c, char *arg) asm("_md_parse_option");
void md_show_usage (FILE *) asm("_md_show_usage");
long md_pcrel_from (fixS * fixP) asm("_md_pcrel_from");
short tc_coff_fix2rtype (fixS * fixP) asm("_tc_coff_fix2rtype");
void md_assemble (char *str) asm("_md_assemble");
void md_begin (void) asm("_md_begin");

void md_create_long_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_long_jump")

                           ;


void md_create_short_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_short_jump")

                            ;

void md_number_to_chars (char *buf, valueT val, int n) asm("_md_number_to_chars");
int md_apply_fix (fixS * fixP, valueT *val) asm("_md_apply_fix");

void md_convert_frag (bfd * headers, segT sec, fragS * fragP) asm("_md_convert_frag");


void tc_headers_hook (segT *, fixS *) asm("_tc_headers_hook");




extern arelent **tc_gen_reloc (asection *, fixS *) asm("_tc_gen_reloc");
valueT md_section_align (segT seg, valueT size) asm("_md_section_align");
char *obj_default_output_file_name (void) asm("_obj_default_output_file_name");
void obj_emit_relocations (char **where, fixS * fixP, relax_addressT segment_address_in_file) asm("_obj_emit_relocations")
                                               ;
void obj_emit_strings (char **where) asm("_obj_emit_strings");
void obj_emit_symbols (char **where, symbolS * symbols) asm("_obj_emit_symbols");

void obj_read_begin_hook (void) asm("_obj_read_begin_hook");
void obj_symbol_new_hook (symbolS * symbolP) asm("_obj_symbol_new_hook");


void obj_symbol_to_chars (char **where, symbolS * symbolP) asm("_obj_symbol_to_chars");

extern const pseudo_typeS obj_pseudo_table[];


struct n64_tag_format_ops {
  int flavor;
  unsigned dfl_leading_underscore : 1;
  unsigned emit_section_symbols : 1;
  void (*frob_symbol) (symbolS *, int *);
  void (*frob_file) (void);
  bfd_vma (*s_get_size) (symbolS *);
  void (*s_set_size) (symbolS *, bfd_vma);
  bfd_vma (*s_get_align) (symbolS *);
  void (*s_set_align) (symbolS *, bfd_vma);
  void (*copy_symbol_attributes) (symbolS *, symbolS *);
  void (*generate_asm_lineno) (const char *, int);
  void (*process_stab) (segT, int, const char *, int, int, int);
  int (*sec_sym_ok_for_reloc) (asection *);
  void (*pop_insert) (void);

  void (*ecoff_set_ext) (symbolS *, struct ecoff_extr *);

  void (*read_begin_hook) (void);
  void (*symbol_new_hook) (symbolS *);
};

extern const struct n64_tag_format_ops elf_format_ops;
extern const struct n64_tag_format_ops ecoff_format_ops;


extern const struct n64_tag_format_ops *this_format;





struct n64_tag_emulation {
  void (*match) (const char *);
  const char *name;
  void (*init)(...);
  const char *(*bfd_name)(...);
  unsigned local_labels_fb : 1;
  unsigned local_labels_dollar : 1;
  unsigned leading_underscore : 2;
  unsigned strip_underscore : 1;
  unsigned default_endian : 2;
  const char *fake_label_name;
  const struct n64_tag_format_ops *format;
};

extern struct n64_tag_emulation *this_emulation;

extern const char *default_emul_bfd_name(void) asm("_default_emul_bfd_name");
extern void common_emul_init(void) asm("_common_emul_init");

void listing_eject (int) asm("_listing_eject");
void listing_error (const char *message) asm("_listing_error");
void listing_file (const char *name) asm("_listing_file");
void listing_flags (int) asm("_listing_flags");
void listing_list (int on) asm("_listing_list");
void listing_newline (char *ps) asm("_listing_newline");
void listing_prev_line (void) asm("_listing_prev_line");
void listing_print (char *name) asm("_listing_print");
void listing_psize (int) asm("_listing_psize");
void listing_nopage (int) asm("_listing_nopage");
void listing_source_file (const char *) asm("_listing_source_file");
void listing_source_line (unsigned int) asm("_listing_source_line");
void listing_title (int depth) asm("_listing_title");
void listing_warning (const char *message) asm("_listing_warning");
void listing_width (unsigned int x) asm("_listing_width");
struct n64_tag_frchain
{
  struct n64_tag_frag *frch_root;
  struct n64_tag_frag *frch_last;
  struct n64_tag_frchain *frch_next;
  segT frch_seg;
  subsegT frch_subseg;

  fixS *fix_root;
  fixS *fix_tail;

  struct n64_tag_obstack frch_obstack;
  fragS *frch_frag_now;
};

typedef struct n64_tag_frchain frchainS;


extern frchainS *frchain_root;



extern frchainS *frchain_now;


typedef struct
{
  frchainS *frchainP;
  int hadone : 1;






  int bss : 1;

  int user_stuff;



  fixS *fix_root;
  fixS *fix_tail;




  symbolS *dot;

  struct lineno_list *lineno_list_head;
  struct lineno_list *lineno_list_tail;



  asection *bfd_section;



  symbolS *sym;


  union
    {

      unsigned long stab_string_size;

      char *p;
    }
  stabu;




} segment_info_type;



extern segment_info_type *seg_info (segT) asm("_seg_info");
extern symbolS *section_symbol (segT) asm("_section_symbol");
typedef struct n64_tag_sb
  {
    char *ptr;
    int len;
    int pot;
    struct n64_tag_le *item;
  }
sb;


typedef struct n64_tag_le
  {
    struct n64_tag_le *next;
    int size;
    char data[1];
  }
sb_element;


typedef struct
  {
    sb_element *size[30];
  } sb_list_vector;

extern int string_count[30];

extern void sb_build (sb *, int) asm("_sb_build");
extern void sb_new (sb *) asm("_sb_new");
extern void sb_kill (sb *) asm("_sb_kill");
extern void sb_add_sb (sb *, sb *) asm("_sb_add_sb");
extern void sb_reset (sb *) asm("_sb_reset");
extern void sb_add_char (sb *, int) asm("_sb_add_char");
extern void sb_add_string (sb *, const char *) asm("_sb_add_string");
extern void sb_add_buffer (sb *, const char *, int) asm("_sb_add_buffer");
extern void sb_print (FILE *, sb *) asm("_sb_print");
extern void sb_print_at (FILE *, int, sb *) asm("_sb_print_at");
extern char *sb_name (sb *) asm("_sb_name");
extern char *sb_terminate (sb *) asm("_sb_terminate");
extern int sb_skip_white (int, sb *) asm("_sb_skip_white");
extern int sb_skip_comma (int, sb *) asm("_sb_skip_comma");


extern void input_scrub_include_sb (sb *, char *) asm("_input_scrub_include_sb");
extern int macro_defined;

extern int buffer_and_nest
  (const char *, const char *, sb *, int (*) (sb *)) asm("_buffer_and_nest");
extern void macro_init
  (int alternate, int mri, int strip_at, int (*) (const char *, int, sb *, int *)) asm("_macro_init")
                                                       ;
extern const char *define_macro
  (int idx, sb *in, sb *label, int (*get_line) (sb *)) asm("_define_macro");
extern int check_macro (const char *, sb *, int, const char **) asm("_check_macro");
extern void delete_macro (const char *) asm("_delete_macro");
extern const char *expand_irp
  (int, int, sb *, sb *, int (*) (sb *), int) asm("_expand_irp");




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");
char *input_line_pointer;

int generate_asm_lineno = 0;
char lex_type[256] =
{
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 3,
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};







char is_end_of_line[256] =
{



  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), 99, (0), (0), (0), (0), (0),

  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),




  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), 99, (0), (0), (0), (0),

  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
  (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0),
};




static char *buffer;
static char *buffer_limit;
int target_big_endian = 1;




static char *old_buffer;
static char *old_input;
static char *old_limit;



char **include_dirs;

int include_dir_count;
int include_dir_maxlen = 1;
addressT abs_section_offset;



symbolS *line_label;




symbolS *mri_common_symbol;





static int mri_pending_align;

static int scrub_from_string (char **) asm("_scrub_from_string");
static void do_align (int, char *) asm("_do_align");
static int hex_float (int, char *) asm("_hex_float");
static void do_org (segT, expressionS *, int) asm("_do_org");
char *demand_copy_string (int *lenP) asm("_demand_copy_string");
int is_it_end_of_statement (void) asm("_is_it_end_of_statement");
static segT get_segmented_expression (expressionS *expP) asm("_get_segmented_expression");
static segT get_known_segmented_expression (expressionS * expP) asm("_get_known_segmented_expression");
static void pobegin (void) asm("_pobegin");
static int get_line_sb (sb *) asm("_get_line_sb");


void
read_begin(void) asm("_read_begin");
void
read_begin(void)
{
  const char *p;

  pobegin ();
  obj_read_begin_hook ();



  _obstack_begin ((&notes), (chunksize), 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);
  _obstack_begin ((&cond_obstack), (chunksize), 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);


  for (p = line_separator_chars; *p; p++)
    is_end_of_line[(unsigned char) *p] = 1;


  if (flag_mri)
    lex_type['?'] = 3;
}



static struct n64_tag_hash_control *po_hash;

static const pseudo_typeS potable[] =
{
  {"abort", s_abort, 0},
  {"align", s_align_ptwo, 0},
  {"ascii", stringer, 0},
  {"asciz", stringer, 1},
  {"balign", s_align_bytes, 0},

  {"byte", cons, 1},
  {"comm", s_comm, 0},
  {"common", s_mri_common, 0},
  {"common.s", s_mri_common, 1},
  {"data", s_data, 0},
  {"dc", cons, 2},
  {"dc.b", cons, 1},
  {"dc.d", float_cons, 'd'},
  {"dc.l", cons, 4},
  {"dc.s", float_cons, 'f'},
  {"dc.w", cons, 2},
  {"dc.x", float_cons, 'x'},
  {"dcb", s_space, 2},
  {"dcb.b", s_space, 1},
  {"dcb.d", s_float_space, 'd'},
  {"dcb.l", s_space, 4},
  {"dcb.s", s_float_space, 'f'},
  {"dcb.w", s_space, 2},
  {"dcb.x", s_float_space, 'x'},
  {"ds", s_space, 2},
  {"ds.b", s_space, 1},
  {"ds.d", s_space, 8},
  {"ds.l", s_space, 4},
  {"ds.p", s_space, 12},
  {"ds.s", s_space, 4},
  {"ds.w", s_space, 2},
  {"ds.x", s_space, 12},
  {"debug", s_ignore, 0},




  {"double", float_cons, 'd'},

  {"eject", listing_eject, 0},
  {"else", s_else, 0},
  {"elsec", s_else, 0},
  {"end", s_end, 0},
  {"endc", s_endif, 0},
  {"endif", s_endif, 0},

  {"equ", s_set, 0},
  {"err", s_err, 0},
  {"exitm", s_mexit, 0},

  {"extern", s_ignore, 0},
  {"appfile", s_app_file, 1},
  {"appline", s_app_line, 0},
  {"fail", s_fail, 0},
  {"file", s_app_file, 0},
  {"fill", s_fill, 0},
  {"float", float_cons, 'f'},
  {"format", s_ignore, 0},
  {"global", s_globl, 0},
  {"globl", s_globl, 0},
  {"hword", cons, 2},
  {"if", s_if, (int) O_ne},
  {"ifc", s_ifc, 0},
  {"ifdef", s_ifdef, 0},
  {"ifeq", s_if, (int) O_eq},
  {"ifeqs", s_ifeqs, 0},
  {"ifge", s_if, (int) O_ge},
  {"ifgt", s_if, (int) O_gt},
  {"ifle", s_if, (int) O_le},
  {"iflt", s_if, (int) O_lt},
  {"ifnc", s_ifc, 1},
  {"ifndef", s_ifdef, 1},
  {"ifne", s_if, (int) O_ne},
  {"ifnes", s_ifeqs, 1},
  {"ifnotdef", s_ifdef, 1},
  {"include", s_include, 0},
  {"int", cons, 4},
  {"irp", s_irp, 0},
  {"irep", s_irp, 0},
  {"irpc", s_irp, 1},
  {"irepc", s_irp, 1},
  {"lcomm", s_lcomm, 0},
  {"lflags", listing_flags, 0},
  {"list", listing_list, 1},
  {"llen", listing_psize, 1},
  {"long", cons, 4},
  {"lsym", s_lsym, 0},
  {"macro", s_macro, 0},
  {"mexit", s_mexit, 0},
  {"noformat", s_ignore, 0},
  {"nolist", listing_list, 0},
  {"nopage", listing_nopage, 0},
  {"octa", cons, 16},
  {"offset", s_struct, 0},
  {"org", s_org, 0},
  {"p2align", s_align_ptwo, 0},
  {"page", listing_eject, 0},
  {"plen", listing_psize, 0},
  {"print", s_print, 0},
  {"psize", listing_psize, 0},
  {"purgem", s_purgem, 0},
  {"quad", cons, 8},
  {"rep", s_rept, 0},
  {"rept", s_rept, 0},
  {"rva", s_rva, 4},
  {"sbttl", listing_title, 1},


  {"set", s_set, 0},
  {"short", cons, 2},
  {"single", float_cons, 'f'},

  {"space", s_space, 0},
  {"spc", s_ignore, 0},
  {"stabd", s_stab, 'd'},
  {"stabn", s_stab, 'n'},
  {"stabs", s_stab, 's'},
  {"string", stringer, 1},
  {"struct", s_struct, 0},

  {"text", s_text, 0},





  {"this_GCC_requires_the_GNU_assembler", s_ignore, 0},



  {"this_gcc_requires_the_gnu_assembler", s_ignore, 0},

  {"title", listing_title, 0},
  {"ttl", listing_title, 0},



  {"xcom", s_comm, 0},
  {"xdef", s_globl, 0},
  {"xref", s_ignore, 0},
  {"xstabs", s_xstab, 's'},
  {"word", cons, 2},
  {"zero", s_space, 0},
  {
  ((void *)0)
      }
};

static int pop_override_ok = 0;
static const char *pop_table_name;

void
pop_insert(const pseudo_typeS *table) asm("_pop_insert");
void
pop_insert(const pseudo_typeS *table)
{
  const char *errtxt;
  const pseudo_typeS *pop;
  for (pop = table; pop->poc_name; pop++)
    {
      errtxt = hash_insert (po_hash, pop->poc_name, (char *) pop);
      if (errtxt && (!pop_override_ok || strcmp (errtxt, "exists")))
 as_fatal ("error constructing %s pseudo-op table", pop_table_name);
    }
}
static void
pobegin(void) asm("_pobegin");
static void
pobegin(void)
{
  po_hash = hash_new ();


  pop_table_name = "md";
  mips_pop_insert();


  pop_table_name = "obj";
  pop_override_ok = 1;
  elf_pop_insert();


  pop_table_name = "standard";
  pop_insert (potable);
}
static char *scrub_string;
static char *scrub_string_end;

static int
scrub_from_string(char **from) asm("_scrub_from_string");
static int
scrub_from_string(char **from)
{
  int size;

  *from = scrub_string;
  size = scrub_string_end - scrub_string;
  scrub_string = scrub_string_end;
  return size;
}






void
read_a_source_file(char *name) asm("_read_a_source_file");
void
read_a_source_file(char *name)
{
  register char c;
  register char *s;
  register int temp;
  pseudo_typeS *pop;

  buffer = input_scrub_new_file (name);

  listing_file (name);
  listing_newline ("");

  while ((buffer_limit = input_scrub_next_buffer (&input_line_pointer)) != 0)
    {
      ;
    contin:


      while (input_line_pointer < buffer_limit)
 {







   if (is_end_of_line[(unsigned char) input_line_pointer[-1]])
     {




       if (input_line_pointer[-1] == '\n')
  bump_line_counters ();

       line_label = 
                   ((void *)0)
                       ;

       if (flag_mri



    )
  {


    if (( lex_type[(unsigned char) (*input_line_pointer)] & (2) ))
      {
        char *line_start = input_line_pointer;
        char c;

        if (ignore_input ()) { while (! is_end_of_line[(unsigned char) *input_line_pointer++]) if (input_line_pointer == buffer_limit) break; continue; };

        c = get_symbol_end ();



        if (flag_mri)
   {
     char *rest = input_line_pointer + 1;

     if (*rest == ':')
       ++rest;
     if (*rest == ' ' || *rest == '\t')
       ++rest;
     if ((strncasecmp (rest, "EQU", 3) == 0
          || strncasecmp (rest, "SET", 3) == 0)
         && (rest[3] == ' ' || rest[3] == '\t'))
       {
         input_line_pointer = rest + 3;
         equals (line_start);
         continue;
       }
   }

        line_label = colon (line_start);

        *input_line_pointer = c;
        if (c == ':')
   input_line_pointer++;
      }
  }
     }
   if ((c = *input_line_pointer++) == '\t'
       || c == ' '
       || c == '\f'
       || c == 0)
     {
       c = *input_line_pointer++;
     }
   ;
   { if (listing) listing_newline(input_line_pointer); };




   if (( lex_type[(unsigned char) (c)] & (2) ))
     {

       if (ignore_input ()) { while (! is_end_of_line[(unsigned char) *input_line_pointer++]) if (input_line_pointer == buffer_limit) break; continue; };

       s = --input_line_pointer;
       c = get_symbol_end ();







       if ((c==':'))
  {
    if (flag_mri)
      {
        char *rest = input_line_pointer + 1;



        if (*rest == ':')
   ++rest;
        if (*rest == ' ' || *rest == '\t')
   ++rest;
        if ((strncasecmp (rest, "EQU", 3) == 0
      || strncasecmp (rest, "SET", 3) == 0)
     && (rest[3] == ' ' || rest[3] == '\t'))
   {
     input_line_pointer = rest + 3;
     equals (s);
     continue;
   }
      }

    line_label = colon (s);
    *input_line_pointer++ = ':';

    {if (* input_line_pointer == ' ') ++ input_line_pointer;};


  }
       else if (c == '='
         || (input_line_pointer[1] == '='



      ))
  {
    equals (s);
    demand_empty_rest_of_line ();
  }
       else
  {
    pop = 
         ((void *)0)
             ;



    {
      char *s2 = s;
      while (*s2)
        {
   if (isupper (*s2))
     *s2 = tolower (*s2);
   s2++;
        }
    }






    if ((flag_mri && ! 0)



        )
      {


        pop = (pseudo_typeS *) hash_find (po_hash, s);
        if (pop != 
                  ((void *)0) 
                       && pop->poc_handler == 
                                              ((void *)0)
                                                  )
   pop = 
        ((void *)0)
            ;
      }

    if (pop != 
              ((void *)0)
        
       || ((! flag_mri || 0)
     && *s == '.'))
      {
        if (pop == 
                  ((void *)0)
                      )
   pop = (pseudo_typeS *) hash_find (po_hash, s + 1);




        if (mri_pending_align
     && (pop == 
               ((void *)0)
         
        || ! ((pop->poc_handler == cons
         && pop->poc_val == 1)
        || (pop->poc_handler == s_space
     && pop->poc_val == 1))))
   {
     do_align (1, (char *) 
                          ((void *)0)
                              );
     mri_pending_align = 0;
   }


        if (pop == 
                  ((void *)0)
                      )
   {
     as_bad ("Unknown pseudo-op:  `%s'", s);
     *input_line_pointer = c;
     s_ignore (0);
     continue;
   }


        *input_line_pointer = c;



        if (c == ' ' || c == '\t')
   input_line_pointer++;





        (*pop->poc_handler) (pop->poc_val);


        if (pop->poc_handler == s_end)
   goto quit;
      }
    else
      {
        int inquote = 0;

        if (mri_pending_align)
   {
     do_align (1, (char *) 
                          ((void *)0)
                              );
     mri_pending_align = 0;
   }



        *input_line_pointer = c;
        while (!is_end_of_line[(unsigned char) *input_line_pointer]
        || inquote



        )
   {
     if (flag_mri && *input_line_pointer == '\'')
       inquote = ! inquote;
     input_line_pointer++;
   }

        c = *input_line_pointer;
        *input_line_pointer = '\0';
        if (macro_defined)
   {
     sb out;
     const char *err;

     if (check_macro (s, &out, '\0', &err))
       {
         if (err != 
                   ((void *)0)
                       )
    as_bad (err);
         *input_line_pointer++ = c;
         input_scrub_include_sb (&out,
            input_line_pointer);
         sb_kill (&out);
         buffer_limit =
    input_scrub_next_buffer (&input_line_pointer);
         continue;
       }
   }

        md_assemble (s);

        *input_line_pointer++ = c;



      }
  }
       continue;
     }



   if (is_end_of_line[(unsigned char) c])
     continue;

   if ((1 || 1)
       && isdigit (c))
     {

       char *backup = input_line_pointer;

       if (ignore_input ()) { while (! is_end_of_line[(unsigned char) *input_line_pointer++]) if (input_line_pointer == buffer_limit) break; continue; };

       temp = c - '0';

       while (isdigit (*input_line_pointer))
  {
    temp = (temp * 10) + *input_line_pointer - '0';
    ++input_line_pointer;
  }

       if (1
    && *input_line_pointer == '$'
    && *(input_line_pointer + 1) == ':')
  {
    input_line_pointer += 2;

    if (dollar_label_defined (temp))
      {
        as_fatal ("label \"%d$\" redefined", temp);
      }

    define_dollar_label (temp);
    colon (dollar_label_name (temp, 0));
    continue;
  }

       if (1
    && *input_line_pointer++ == ':')
  {
    fb_label_instance_inc (temp);
    colon (fb_label_name (temp, 0));
    continue;
  }

       input_line_pointer = backup;
     }

   if (c && strchr (line_comment_chars, c))
     {
       char *ends;
       char *new_buf;
       char *new_tmp;
       unsigned int new_length;
       char *tmp_buf = 0;

       bump_line_counters ();
       s = input_line_pointer;
       if (strncmp (s, "APP\n", 4))
  continue;
       s += 4;

       ends = strstr (s, "#NO_APP\n");

       if (!ends)
  {
    unsigned int tmp_len;
    unsigned int num;





    tmp_len = buffer_limit - s;
    tmp_buf = xmalloc (tmp_len + 1);
    memcpy (tmp_buf, s, tmp_len);
    do
      {
        new_tmp = input_scrub_next_buffer (&buffer);
        if (!new_tmp)
   break;
        else
   buffer_limit = new_tmp;
        input_line_pointer = buffer;
        ends = strstr (buffer, "#NO_APP\n");
        if (ends)
   num = ends - buffer;
        else
   num = buffer_limit - buffer;

        tmp_buf = xrealloc (tmp_buf, tmp_len + num);
        memcpy (tmp_buf + tmp_len, buffer, num);
        tmp_len += num;
      }
    while (!ends);

    input_line_pointer = ends ? ends + 8 : 
                                          ((void *)0)
                                              ;

    s = tmp_buf;
    ends = s + tmp_len;

  }
       else
  {
    input_line_pointer = ends + 8;
  }

       scrub_string = s;
       scrub_string_end = ends;

       new_length = ends - s;
       new_buf = (char *) xmalloc (new_length);
       new_tmp = new_buf;
       for (;;)
  {
    int space;
    int size;

    space = (new_buf + new_length) - new_tmp;
    size = do_scrub_chars (scrub_from_string, new_tmp, space);

    if (size < space)
      {
        new_tmp += size;
        break;
      }

    new_buf = xrealloc (new_buf, new_length + 100);
    new_tmp = new_buf + new_length;
    new_length += 100;
  }

       if (tmp_buf)
  free (tmp_buf);
       old_buffer = buffer;
       old_input = input_line_pointer;
       old_limit = buffer_limit;
       buffer = new_buf;
       input_line_pointer = new_buf;
       buffer_limit = new_tmp;
       continue;
     }

   if (ignore_input ()) { while (! is_end_of_line[(unsigned char) *input_line_pointer++]) if (input_line_pointer == buffer_limit) break; continue; };


   input_line_pointer--;
   ignore_rest_of_line ();
 }





      if (old_buffer)
 {
   free (buffer);
   bump_line_counters ();
   if (old_input != 0)
     {
       buffer = old_buffer;
       input_line_pointer = old_input;
       buffer_limit = old_limit;
       old_buffer = 0;
       goto contin;
     }
 }
    }

 quit:
  input_scrub_close ();
}
char *
mri_comment_field(char *stopcp) asm("_mri_comment_field");
char *
mri_comment_field(char *stopcp)
{
  char *s;

  for (s = input_line_pointer; ! is_end_of_line[(unsigned char) *s]; s++)
    ;
  *stopcp = *s;
  *s = '\0';
  return s;



}



void
mri_comment_end(char *stop, int stopc) asm("_mri_comment_end");
void
mri_comment_end(char *stop, int stopc)
{
  ;

  input_line_pointer = stop;
  *stop = stopc;
  while (! is_end_of_line[(unsigned char) *input_line_pointer])
    ++input_line_pointer;
}

void
s_abort(int ignore) asm("_s_abort");
void
s_abort(int ignore)
{
  as_fatal (".abort detected.  Abandoning ship.");
}


static void
do_align(int n, char *fill) asm("_do_align");
static void
do_align(int n, char *fill)
{



  if (!fill)
    {

      static char zero;
      static char nop_opcode = 0x00;

      if (now_seg != data_section && now_seg != bss_section)
 {
   fill = &nop_opcode;
 }
      else
 {
   fill = &zero;
 }
    }

  if (n && !need_pass_2)
    frag_align (n, *fill);





  record_alignment (now_seg, n);
}


void
s_align_bytes(int arg) asm("_s_align_bytes");
void
s_align_bytes(int arg)
{
  register unsigned int temp;
  char temp_fill;
  unsigned int i = 0;
  unsigned long max_alignment = 1 << 15;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  if (is_end_of_line[(unsigned char) *input_line_pointer])
    temp = arg;
  else
    temp = get_absolute_expression ();

  if (temp > max_alignment)
    {
      as_bad ("Alignment too large: %d. assumed.", temp = max_alignment);
    }



  if (temp != 0)
    {
      for (i = 0; (temp & 1) == 0; temp >>= 1, ++i)
 ;
    }
  if (temp != 1)
    as_bad ("Alignment not a power of 2");

  temp = i;
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_fill = get_absolute_expression ();
      do_align (temp, &temp_fill);
    }
  else
    do_align (temp, (char *) 0);

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}


void
s_align_ptwo(int ignore) asm("_s_align_ptwo");
void
s_align_ptwo(int ignore)
{
  register int temp;
  char temp_fill;
  long max_alignment = 15;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  temp = get_absolute_expression ();
  if (temp > max_alignment)
    as_bad ("Alignment too large: %d. assumed.", temp = max_alignment);
  else if (temp < 0)
    {
      as_bad ("Alignment negative. 0 assumed.");
      temp = 0;
    }
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_fill = get_absolute_expression ();
      do_align (temp, &temp_fill);
    }
  else
    do_align (temp, (char *) 0);

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}

void
s_comm(int ignore) asm("_s_comm");
void
s_comm(int ignore)
{
  register char *name;
  register char c;
  register char *p;
  offsetT temp;
  register symbolS *symbolP;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  name = input_line_pointer;
  c = get_symbol_end ();

  p = input_line_pointer;
  *p = c;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer != ',')
    {
      as_bad ("Expected comma after symbol-name: rest of line ignored.");
      if (flag_mri)
 mri_comment_end (stop, stopc);
      ignore_rest_of_line ();
      return;
    }
  input_line_pointer++;
  if ((temp = get_absolute_expression ()) < 0)
    {
      as_warn (".COMMon length (%ld.) <0! Ignored.", (long) temp);
      if (flag_mri)
 mri_comment_end (stop, stopc);
      ignore_rest_of_line ();
      return;
    }
  *p = 0;
  symbolP = symbol_find_or_make (name);
  *p = c;
  if (S_IS_DEFINED (symbolP))
    {
      as_bad ("Ignoring attempt to re-define symbol `%s'.",
       S_GET_NAME (symbolP));
      if (flag_mri)
 mri_comment_end (stop, stopc);
      ignore_rest_of_line ();
      return;
    }
  if (S_GET_VALUE (symbolP))
    {
      if (S_GET_VALUE (symbolP) != (valueT) temp)
 as_bad ("Length of .comm \"%s\" is already %ld. Not changed to %ld.",
  S_GET_NAME (symbolP),
  (long) S_GET_VALUE (symbolP),
  (long) temp);
    }
  else
    {
      S_SET_VALUE (symbolP, (valueT) temp);
      S_SET_EXTERNAL (symbolP);
    }







  ;

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}





void
s_mri_common(int small) asm("_s_mri_common");
void
s_mri_common(int small)
{
  char *name;
  char c;
  char *alc = 
             ((void *)0)
                 ;
  symbolS *sym;
  offsetT align;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (! flag_mri)
    {
      s_comm (0);
      return;
    }

  stop = mri_comment_field (&stopc);

  {if (* input_line_pointer == ' ') ++ input_line_pointer;};

  name = input_line_pointer;
  if (! isdigit ((unsigned char) *name))
    c = get_symbol_end ();
  else
    {
      do
 {
   ++input_line_pointer;
 }
      while (isdigit ((unsigned char) *input_line_pointer));
      c = *input_line_pointer;
      *input_line_pointer = '\0';

      if (line_label != 
                       ((void *)0)
                           )
 {
   alc = (char *) xmalloc (strlen (S_GET_NAME (line_label))
      + (input_line_pointer - name)
      + 1);
   sprintf (alc, "%s%s", name, S_GET_NAME (line_label));
   name = alc;
 }
    }

  sym = symbol_find_or_make (name);
  *input_line_pointer = c;
  if (alc != 
            ((void *)0)
                )
    free (alc);

  if (*input_line_pointer != ',')
    align = 0;
  else
    {
      ++input_line_pointer;
      align = get_absolute_expression ();
    }

  if (S_IS_DEFINED (sym))
    {

      if (! S_IS_COMMON (sym))

 {
   as_bad ("attempt to re-define symbol `%s'", S_GET_NAME (sym));
   mri_comment_end (stop, stopc);
   ignore_rest_of_line ();
   return;
 }
    }

  S_SET_EXTERNAL (sym);
  mri_common_symbol = sym;


  if (align != 0)
    (((elf_symbol_type *)(&((sym)->bsym)->the_bfd))->internal_elf_sym.st_value = (align));


  if (line_label != 
                   ((void *)0)
                       )
    {
      line_label->sy_value.X_op = O_symbol;
      line_label->sy_value.X_add_symbol = sym;
      line_label->sy_value.X_add_number = S_GET_VALUE (sym);
      line_label->sy_frag = &zero_address_frag;
      S_SET_SEGMENT (line_label, expr_section);
    }





  if (*input_line_pointer == ',')
    input_line_pointer += 2;
  if (*input_line_pointer == ',')
    input_line_pointer += 2;

  mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}

void
s_data(int ignore) asm("_s_data");
void
s_data(int ignore)
{
  segT section;
  register int temp;

  temp = get_absolute_expression ();
  if (flag_readonly_data_in_text)
    {
      section = text_section;
      temp += 1000;
    }
  else
    section = data_section;

  subseg_set (section, (subsegT) temp);




  demand_empty_rest_of_line ();
}
void
s_app_file(int appfile) asm("_s_app_file");
void
s_app_file(int appfile)
{
  register char *s;
  int length;


  if ((s = demand_copy_string (&length)) != 0)
    {



      new_logical_line (s, appfile ? -2 : -1);
      demand_empty_rest_of_line ();




    }

  elf_file_symbol (s);

}






void
s_app_line(int ignore) asm("_s_app_line");
void
s_app_line(int ignore)
{
  int l;


  l = get_absolute_expression () - 1;
  if (l < 0)


    as_warn ("Line numbers must be positive; line number %d rejected.", l+1);
  else
    {
      new_logical_line ((char *) 
                                ((void *)0)
                                    , l);




    }
  demand_empty_rest_of_line ();
}




void
s_end(int ignore) asm("_s_end");
void
s_end(int ignore)
{
  if (flag_mri)
    {


      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      if (! is_end_of_line[(unsigned char) *input_line_pointer]
   && *input_line_pointer != '*'
   && *input_line_pointer != '!')
 as_warn ("start address not supported");
    }
}



void
s_err(int ignore) asm("_s_err");
void
s_err(int ignore)
{
  as_bad (".err encountered");
  demand_empty_rest_of_line ();
}



void
s_fail(int ignore) asm("_s_fail");
void
s_fail(int ignore)
{
  offsetT temp;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  temp = get_absolute_expression ();
  if (temp >= 500)
    as_warn (".fail %ld encountered", (long) temp);
  else
    as_bad (".fail %ld encountered", (long) temp);

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}

void
s_fill(int ignore) asm("_s_fill");
void
s_fill(int ignore)
{
  long temp_repeat = 0;
  long temp_size = 1;
  register long temp_fill = 0;
  char *p;


  temp_repeat = get_absolute_expression ();
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_size = get_absolute_expression ();
      if (*input_line_pointer == ',')
 {
   input_line_pointer++;
   temp_fill = get_absolute_expression ();
 }
    }


  if (temp_size > (8))
    {
      as_warn (".fill size clamped to %d.", (8));
      temp_size = (8);
    }
  if (temp_size < 0)
    {
      as_warn ("Size negative: .fill ignored.");
      temp_size = 0;
    }
  else if (temp_repeat <= 0)
    {
      as_warn ("Repeat < 0, .fill ignored");
      temp_size = 0;
    }

  if (temp_size && !need_pass_2)
    {
      p = frag_var (rs_fill, (int) temp_size, (int) temp_size, (relax_substateT) 0, (symbolS *) 0, temp_repeat, (char *) 0);
      memset (p, 0, (unsigned int) temp_size);






      md_number_to_chars (p, (valueT) temp_fill,
     (temp_size > (4)
      ? (4)
      : (int) temp_size));




    }
  demand_empty_rest_of_line ();
}

void
s_globl(int ignore) asm("_s_globl");
void
s_globl(int ignore)
{
  char *name;
  int c;
  symbolS *symbolP;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  do
    {
      name = input_line_pointer;
      c = get_symbol_end ();
      symbolP = symbol_find_or_make (name);
      *input_line_pointer = c;
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      S_SET_EXTERNAL (symbolP);
      if (c == ',')
 {
   input_line_pointer++;
   {if (* input_line_pointer == ' ') ++ input_line_pointer;};
   if (*input_line_pointer == '\n')
     c = '\n';
 }
    }
  while (c == ',');

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}



void
s_irp(int irpc) asm("_s_irp");
void
s_irp(int irpc)
{
  char *file;
  unsigned int line;
  sb s;
  const char *err;
  sb out;

  as_where (&file, &line);

  sb_new (&s);
  while (! is_end_of_line[(unsigned char) *input_line_pointer])
    sb_add_char (&s, *input_line_pointer++);

  sb_new (&out);

  err = expand_irp (irpc, 0, &s, &out, get_line_sb, '\0');
  if (err != 
            ((void *)0)
                )
    as_bad_where (file, line, "%s", err);

  sb_kill (&s);

  input_scrub_include_sb (&out, input_line_pointer);
  sb_kill (&out);
  buffer_limit = input_scrub_next_buffer (&input_line_pointer);
}

void
s_lcomm(int needs_align) asm("_s_lcomm");
void
s_lcomm(int needs_align)
{
  register char *name;
  register char c;
  register char *p;
  register int temp;
  register symbolS *symbolP;
  segT current_seg = now_seg;
  subsegT current_subseg = now_subseg;
  const int max_alignment = 15;
  int align = 0;
  segT bss_seg = bss_section;

  name = input_line_pointer;
  c = get_symbol_end ();
  p = input_line_pointer;
  *p = c;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};



  if (*input_line_pointer == ',')
    {
      ++input_line_pointer;
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
    }

  if (*input_line_pointer == '\n')
    {
      as_bad ("Missing size expression");
      return;
    }

  if ((temp = get_absolute_expression ()) < 0)
    {
      as_warn ("BSS length (%d.) <0! Ignored.", temp);
      ignore_rest_of_line ();
      return;
    }


  if (bfd_target_elf_flavour == bfd_target_ecoff_flavour
      || bfd_target_elf_flavour == bfd_target_elf_flavour)
    {

      if (temp <= bfd_get_gp_size (stdoutput))
 {
   bss_seg = subseg_new (".sbss", 1);
   seg_info (bss_seg)->bss = 1;
 }
    }

   if (!needs_align)
     {

       if (temp >= 8)
  align = 3;
       else if (temp >= 4)
  align = 2;
       else if (temp >= 2)
  align = 1;
       else
  align = 0;

       record_alignment(bss_seg, align);
     }

  if (needs_align)
    {
      align = 0;
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      if (*input_line_pointer != ',')
 {
   as_bad ("Expected comma after size");
   ignore_rest_of_line ();
   return;
 }
      input_line_pointer++;
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      if (*input_line_pointer == '\n')
 {
   as_bad ("Missing alignment");
   return;
 }
      align = get_absolute_expression ();
      if (align > max_alignment)
 {
   align = max_alignment;
   as_warn ("Alignment too large: %d. assumed.", align);
 }
      else if (align < 0)
 {
   align = 0;
   as_warn ("Alignment negative. 0 assumed.");
 }
      record_alignment (bss_seg, align);
    }
  else
    {
    }

  *p = 0;
  symbolP = symbol_find_or_make (name);
  *p = c;

  if (




       (S_GET_SEGMENT (symbolP) == bss_seg
 || (!S_IS_DEFINED (symbolP) && S_GET_VALUE (symbolP) == 0)))
    {
      char *pfrag;

      subseg_set (bss_seg, 1);

      if (align)
 frag_align (align, 0);

      if (S_GET_SEGMENT (symbolP) == bss_seg)
 symbolP->sy_frag->fr_symbol = 
                              ((void *)0)
                                  ;

      symbolP->sy_frag = frag_now;
      pfrag = frag_var (rs_org, 1, 1, (relax_substateT)0, symbolP,
   temp, (char *)0);
      *pfrag = 0;

      S_SET_SEGMENT (symbolP, bss_seg);
    }
  else
    as_bad ("Ignoring attempt to re-define symbol `%s'.",
     S_GET_NAME (symbolP));

  subseg_set (current_seg, current_subseg);

  demand_empty_rest_of_line ();
}

void
s_lsym(int ignore) asm("_s_lsym");
void
s_lsym(int ignore)
{
  register char *name;
  register char c;
  register char *p;
  expressionS exp;
  register symbolS *symbolP;


  name = input_line_pointer;
  c = get_symbol_end ();
  p = input_line_pointer;
  *p = c;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer != ',')
    {
      *p = 0;
      as_bad ("Expected comma after name \"%s\"", name);
      *p = c;
      ignore_rest_of_line ();
      return;
    }
  input_line_pointer++;
  expr (0, &exp);
  if (exp.X_op != O_constant
      && exp.X_op != O_register)
    {
      as_bad ("bad expression");
      ignore_rest_of_line ();
      return;
    }
  *p = 0;
  symbolP = symbol_find_or_make (name);
  if (S_GET_SEGMENT (symbolP) == ((asection *) &bfd_und_section)
      && S_GET_VALUE (symbolP) == 0)
    {


      S_SET_SEGMENT (symbolP,
       (exp.X_op == O_constant
        ? ((asection *) &bfd_abs_section)
        : reg_section));
      S_SET_VALUE (symbolP, (valueT) exp.X_add_number);
    }
  else
    {
      as_bad ("Symbol %s already defined", name);
    }
  *p = c;
  demand_empty_rest_of_line ();
}



static int
get_line_sb(sb *line) asm("_get_line_sb");
static int
get_line_sb(sb *line)
{
  if (input_line_pointer >= buffer_limit)
    {
      buffer_limit = input_scrub_next_buffer (&input_line_pointer);
      if (buffer_limit == 0)
 return 0;
    }

  while (! is_end_of_line[(unsigned char) *input_line_pointer])
    sb_add_char (line, *input_line_pointer++);
  while (input_line_pointer < buffer_limit
  && is_end_of_line[(unsigned char) *input_line_pointer])
    {
      if (*input_line_pointer == '\n')
 {
   bump_line_counters ();
   { if (listing) listing_newline(input_line_pointer); };
 }
      ++input_line_pointer;
    }
  return 1;
}




void
s_macro(int ignore) asm("_s_macro");
void
s_macro(int ignore)
{
  char *file;
  unsigned int line;
  sb s;
  sb label;
  const char *err;

  as_where (&file, &line);

  sb_new (&s);
  while (! is_end_of_line[(unsigned char) *input_line_pointer])
    sb_add_char (&s, *input_line_pointer++);

  sb_new (&label);
  if (line_label != 
                   ((void *)0)
                       )
    sb_add_string (&label, S_GET_NAME (line_label));

  demand_empty_rest_of_line ();

  err = define_macro (0, &s, &label, get_line_sb);
  if (err != 
            ((void *)0)
                )
    as_bad_where (file, line, "%s", err);
  else
    {
      if (line_label != 
                       ((void *)0)
                           )
 {
   S_SET_SEGMENT (line_label, ((asection *) &bfd_und_section));
   S_SET_VALUE (line_label, 0);
   line_label->sy_frag = &zero_address_frag;
 }
    }

  sb_kill (&s);
}




void
s_mexit(int ignore) asm("_s_mexit");
void
s_mexit(int ignore)
{
  buffer_limit = input_scrub_next_buffer (&input_line_pointer);
}



static void
do_org(segT segment, expressionS *exp, int fill) asm("_do_org");
static void
do_org(segT segment, expressionS *exp, int fill)
{
  if (segment != now_seg && segment != ((asection *) &bfd_abs_section))
    as_bad ("invalid segment \"%s\"; segment \"%s\" assumed",
     ((segment)->name + 0), ((now_seg)->name + 0));

  if (now_seg == ((asection *) &bfd_abs_section))
    {
      if (fill != 0)
 as_warn ("ignoring fill value in absolute section");
      if (exp->X_op != O_constant)
 {
   as_bad ("only constant offsets supported in absolute section");
   exp->X_add_number = 0;
 }
      abs_section_offset = exp->X_add_number;
    }
  else
    {
      char *p;

      p = frag_var (rs_org, 1, 1, (relax_substateT) 0, exp->X_add_symbol,
      exp->X_add_number, (char *) 
                                 ((void *)0)
                                     );
      *p = fill;
    }
}

void
s_org(int ignore) asm("_s_org");
void
s_org(int ignore)
{
  register segT segment;
  expressionS exp;
  register long temp_fill;
  segment = get_known_segmented_expression (&exp);
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_fill = get_absolute_expression ();
    }
  else
    temp_fill = 0;

  if (!need_pass_2)
    do_org (segment, &exp, temp_fill);

  demand_empty_rest_of_line ();
}
void
s_mri_sect(char *type) asm("_s_mri_sect");
void
s_mri_sect(char *type)
{
  as_abort ("read.c", 2162, ((char*)0));


}



void
s_print(int ignore) asm("_s_print");
void
s_print(int ignore)
{
  char *s;
  int len;

  s = demand_copy_C_string (&len);
  printf ("%s\n", s);
  demand_empty_rest_of_line ();
}



void
s_purgem(int ignore) asm("_s_purgem");
void
s_purgem(int ignore)
{
  if (is_it_end_of_statement ())
    {
      demand_empty_rest_of_line ();
      return;
    }

  do
    {
      char *name;
      char c;

      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      name = input_line_pointer;
      c = get_symbol_end ();
      delete_macro (name);
      *input_line_pointer = c;
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
    }
  while (*input_line_pointer++ == ',');

  --input_line_pointer;
  demand_empty_rest_of_line ();
}



void
s_rept(int ignore) asm("_s_rept");
void
s_rept(int ignore)
{
  int count;
  sb one;
  sb many;

  count = get_absolute_expression ();

  sb_new (&one);
  if (! buffer_and_nest ("REPT", "ENDR", &one, get_line_sb))
    {
      as_bad ("rept without endr");
      return;
    }

  sb_new (&many);
  while (count-- > 0)
    sb_add_sb (&many, &one);

  sb_kill (&one);

  input_scrub_include_sb (&many, input_line_pointer);
  sb_kill (&many);
  buffer_limit = input_scrub_next_buffer (&input_line_pointer);
}

void
s_set(int ignore) asm("_s_set");
void
s_set(int ignore)
{
  register char *name;
  register char delim;
  register char *end_name;
  register symbolS *symbolP;






  name = input_line_pointer;
  delim = get_symbol_end ();
  end_name = input_line_pointer;
  *end_name = delim;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};

  if (*input_line_pointer != ',')
    {
      *end_name = 0;
      as_bad ("Expected comma after name \"%s\"", name);
      *end_name = delim;
      ignore_rest_of_line ();
      return;
    }

  input_line_pointer++;
  *end_name = 0;

  if (name[0] == '.' && name[1] == '\0')
    {

      register segT segment;
      expressionS exp;

      segment = get_known_segmented_expression (&exp);

      if (!need_pass_2)
 do_org (segment, &exp, 0);

      *end_name = delim;
      return;
    }

  if ((symbolP = symbol_find (name)) == 
                                       ((void *)0)
      
     && (symbolP = (0)) == 
                                                  ((void *)0)
                                                      )
    {
      symbolP = symbol_new (name, ((asection *) &bfd_und_section), 0, &zero_address_frag);





    }

  symbol_table_insert (symbolP);

  *end_name = delim;
  pseudo_set (symbolP);
  demand_empty_rest_of_line ();
}

void
s_space(int mult) asm("_s_space");
void
s_space(int mult)
{
  expressionS exp;
  long temp_fill;
  char *p = 0;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;


  mips_flush_pending_output ();


  if (flag_mri)
    stop = mri_comment_field (&stopc);


  expr (0, &exp);
  if (exp.X_op == O_constant)
    {
      long repeat;

      repeat = exp.X_add_number;
      if (mult)
 repeat *= mult;
      if (repeat <= 0)
 {
   if (! flag_mri || repeat < 0)
     as_warn (".space repeat count is %s, ignored",
       repeat ? "negative" : "zero");
   goto getout;
 }


      if (now_seg == ((asection *) &bfd_abs_section))
 {
   abs_section_offset += repeat;
   goto getout;
 }



      if (mri_common_symbol != 
                              ((void *)0)
                                  )
 {
   S_SET_VALUE (mri_common_symbol,
         S_GET_VALUE (mri_common_symbol) + repeat);
   goto getout;
 }

      if (!need_pass_2)
 p = frag_var (rs_fill, 1, 1, (relax_substateT) 0, (symbolS *) 0,
        repeat, (char *) 0);
    }
  else
    {
      if (now_seg == ((asection *) &bfd_abs_section))
 {
   as_bad ("space allocation too complex in absolute section");
   subseg_set (text_section, 0);
 }
      if (mri_common_symbol != 
                              ((void *)0)
                                  )
 {
   as_bad ("space allocation too complex in common section");
   mri_common_symbol = 
                      ((void *)0)
                          ;
 }
      if (!need_pass_2)
 p = frag_var (rs_space, 1, 1, (relax_substateT) 0,
        make_expr_symbol (&exp), 0L, (char *) 0);
    }
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_fill = get_absolute_expression ();
    }
  else
    {
      temp_fill = 0;
    }
  if (p)
    {
      *p = temp_fill;
    }

 getout:
  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}





void
s_float_space(int float_type) asm("_s_float_space");
void
s_float_space(int float_type)
{
  offsetT count;
  int flen;
  char temp[(16)];
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  count = get_absolute_expression ();

  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer != ',')
    {
      as_bad ("missing value");
      if (flag_mri)
 mri_comment_end (stop, stopc);
      ignore_rest_of_line ();
      return;
    }

  ++input_line_pointer;

  {if (* input_line_pointer == ' ') ++ input_line_pointer;};



  if (input_line_pointer[0] == '0' && isalpha (input_line_pointer[1]))
    input_line_pointer += 2;



  if (input_line_pointer[0] == ':')
    {
      flen = hex_float (float_type, temp);
      if (flen < 0)
 {
   if (flag_mri)
     mri_comment_end (stop, stopc);
   ignore_rest_of_line ();
   return;
 }
    }
  else
    {
      char *err;

      err = md_atof (float_type, temp, &flen);
      ;
      ;
      if (err)
 {
   as_bad ("Bad floating literal: %s", err);
   if (flag_mri)
     mri_comment_end (stop, stopc);
   ignore_rest_of_line ();
   return;
 }
    }

  while (--count >= 0)
    {
      char *p;

      p = frag_more (flen);
      memcpy (p, temp, (unsigned int) flen);
    }

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}



void
s_struct(int ignore) asm("_s_struct");
void
s_struct(int ignore)
{
  char *stop = 
              ((void *)0)
                  ;
  char stopc;

  if (flag_mri)
    stop = mri_comment_field (&stopc);
  abs_section_offset = get_absolute_expression ();
  subseg_set (((asection *) &bfd_abs_section), 0);
  if (flag_mri)
    mri_comment_end (stop, stopc);
  demand_empty_rest_of_line ();
}

void
s_text(int ignore) asm("_s_text");
void
s_text(int ignore)
{
  register int temp;

  temp = get_absolute_expression ();
  subseg_set (text_section, (subsegT) temp);
  demand_empty_rest_of_line ();



}


void
demand_empty_rest_of_line(void) asm("_demand_empty_rest_of_line");
void
demand_empty_rest_of_line(void)
{
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (is_end_of_line[(unsigned char) *input_line_pointer])
    {
      input_line_pointer++;
    }
  else
    {
      ignore_rest_of_line ();
    }

}

void
ignore_rest_of_line(void) asm("_ignore_rest_of_line");
void
ignore_rest_of_line(void)
{
  if (!is_end_of_line[(unsigned char) *input_line_pointer])
    {
      if (isprint (*input_line_pointer))
 as_bad ("Rest of line ignored. First ignored character is `%c'.",
  *input_line_pointer);
      else
 as_bad ("Rest of line ignored. First ignored character valued 0x%x.",
  *input_line_pointer);
      while (input_line_pointer < buffer_limit
      && !is_end_of_line[(unsigned char) *input_line_pointer])
 {
   input_line_pointer++;
 }
    }
  input_line_pointer++;
  ;
}
void
pseudo_set(symbolS *symbolP) asm("_pseudo_set");
void
pseudo_set(symbolS *symbolP)
{
  expressionS exp;




  ;




  (void) expr (0, &exp);

  if (exp.X_op == O_illegal)
    as_bad ("illegal expression; zero assumed");
  else if (exp.X_op == O_absent)
    as_bad ("missing expression; zero assumed");
  else if (exp.X_op == O_big)
    as_bad ("%s number invalid; zero assumed",
     exp.X_add_number > 0 ? "bignum" : "floating point");
  else if (exp.X_op == O_subtract
    && (S_GET_SEGMENT (exp.X_add_symbol)
        == S_GET_SEGMENT (exp.X_op_symbol))
    && ((S_GET_SEGMENT (exp.X_add_symbol)) != ((asection *) &bfd_abs_section) && (S_GET_SEGMENT (exp.X_add_symbol)) != ((asection *) &bfd_und_section) && (S_GET_SEGMENT (exp.X_add_symbol)) != reg_section && (S_GET_SEGMENT (exp.X_add_symbol)) != expr_section)
    && exp.X_add_symbol->sy_frag == exp.X_op_symbol->sy_frag)
    {
      exp.X_op = O_constant;
      exp.X_add_number = (S_GET_VALUE (exp.X_add_symbol)
     - S_GET_VALUE (exp.X_op_symbol));
    }

  switch (exp.X_op)
    {
    case O_illegal:
    case O_absent:
    case O_big:
      exp.X_add_number = 0;

    case O_constant:
      S_SET_SEGMENT (symbolP, ((asection *) &bfd_abs_section));






      S_SET_VALUE (symbolP, (valueT) exp.X_add_number);
      symbolP->sy_frag = &zero_address_frag;
      break;

    case O_register:
      S_SET_SEGMENT (symbolP, reg_section);
      S_SET_VALUE (symbolP, (valueT) exp.X_add_number);
      symbolP->sy_frag = &zero_address_frag;
      break;

    case O_symbol:
      if (S_GET_SEGMENT (exp.X_add_symbol) == ((asection *) &bfd_und_section)
   || exp.X_add_number != 0)
 symbolP->sy_value = exp;
      else
 {
   symbolS *s = exp.X_add_symbol;

   S_SET_SEGMENT (symbolP, S_GET_SEGMENT (s));






   S_SET_VALUE (symbolP,
         exp.X_add_number + S_GET_VALUE (s));
   symbolP->sy_frag = s->sy_frag;
   copy_symbol_attributes (symbolP, s);
 }
      break;

    default:


      symbolP->sy_value = exp;
      break;
    }
}
static void
parse_mri_cons (expressionS *exp, unsigned int nbytes) asm("_parse_mri_cons");
static void
parse_repeat_cons (expressionS *exp, unsigned int nbytes) asm("_parse_repeat_cons");
static void
cons_worker(register int nbytes, int rva) asm("_cons_worker");
static void
cons_worker(register int nbytes, int rva)
{
  int c;
  expressionS exp;
  char *stop = 
              ((void *)0)
                  ;
  char stopc;


  mips_flush_pending_output ();


  if (flag_mri)
    stop = mri_comment_field (&stopc);

  if (is_it_end_of_statement ())
    {
      mri_comment_end (stop, stopc);
      demand_empty_rest_of_line ();
      return;
    }

  c = 0;
  do
    {
      if (flag_mri)
 parse_mri_cons (&exp, (unsigned int) nbytes);
      else
 parse_repeat_cons (&exp, (unsigned int) nbytes);

      if (rva)
 {
   if (exp.X_op == O_symbol)
     exp.X_op = O_symbol_rva;
   else
     as_fatal ("rva without symbol");
 }
      emit_expr (&exp, (unsigned int) nbytes);
      ++c;
    }
  while (*input_line_pointer++ == ',');




  if (flag_mri && nbytes == 1 && (c & 1) != 0)
    mri_pending_align = 1;

  input_line_pointer--;

  if (flag_mri)
    mri_comment_end (stop, stopc);

  demand_empty_rest_of_line ();
}


void
cons(int size) asm("_cons");
void
cons(int size)
{
  cons_worker (size, 0);
}

void
s_rva(int size) asm("_s_rva");
void
s_rva(int size)
{
  cons_worker (size, 1);
}





void
emit_expr(expressionS *exp, unsigned int nbytes) asm("_emit_expr");
void
emit_expr(expressionS *exp, unsigned int nbytes)
{
  operatorT op;
  register char *p;
  valueT extra_digit = 0;


  if (need_pass_2)
    return;

  op = exp->X_op;


  if (now_seg == ((asection *) &bfd_abs_section))
    {
      if (op != O_constant || exp->X_add_number != 0)
 as_bad ("attempt to store value in absolute section");
      abs_section_offset += nbytes;
      return;
    }


  if (op == O_uminus
      && exp->X_add_number == 0
      && exp->X_add_symbol->sy_value.X_op == O_big
      && exp->X_add_symbol->sy_value.X_add_number > 0)
    {
      int i;
      unsigned long carry;

      exp = &exp->X_add_symbol->sy_value;


      carry = 1;
      for (i = 0; i < exp->X_add_number; i++)
 {
   unsigned long next;

   next = (((~ (generic_bignum[i] & (0xFFFF)))
     & (0xFFFF))
    + carry);
   generic_bignum[i] = next & (0xFFFF);
   carry = next >> (16);
 }




      extra_digit = (valueT) -1;
      op = O_big;
    }

  if (op == O_absent || op == O_illegal)
    {
      as_warn ("zero assumed for missing expression");
      exp->X_add_number = 0;
      op = O_constant;
    }
  else if (op == O_big && exp->X_add_number <= 0)
    {
      as_bad ("floating point number invalid; zero assumed");
      exp->X_add_number = 0;
      op = O_constant;
    }
  else if (op == O_register)
    {
      as_warn ("register value used as expression");
      op = O_constant;
    }

  p = frag_more ((int) nbytes);
  if (op == O_constant && nbytes > sizeof (valueT))
    {
      valueT val;
      int gencnt;

      if (! exp->X_unsigned && exp->X_add_number < 0)
 extra_digit = (valueT) -1;
      val = (valueT) exp->X_add_number;
      gencnt = 0;
      do
 {
   generic_bignum[gencnt] = val & (0xFFFF);
   val >>= (16);
   ++gencnt;
 }
      while (val != 0);
      op = exp->X_op = O_big;
      exp->X_add_number = gencnt;
    }

  if (op == O_constant)
    {
      register valueT get;
      register valueT use;
      register valueT mask;
      register valueT unmask;



      if (nbytes >= sizeof (valueT))
 mask = 0;
      else
 mask = ~(valueT) 0 << ((8) * nbytes);

      unmask = ~mask;






      get = exp->X_add_number;
      use = get & unmask;
      if ((get & mask) != 0 && (get & mask) != mask)
 {
   as_warn ("Value 0x%lx truncated to 0x%lx.", get, use);
 }

      md_number_to_chars (p, use, (int) nbytes);
    }
  else if (op == O_big)
    {
      int size;
      LITTLENUM_TYPE *nums;

      ;

      size = exp->X_add_number * (1 << (1));
      if (nbytes < size)
 {
   as_warn ("Bignum truncated to %d bytes", nbytes);
   size = nbytes;
 }

      if (target_big_endian)
 {
   while (nbytes > size)
     {
       md_number_to_chars (p, extra_digit, (1 << (1)));
       nbytes -= (1 << (1));
       p += (1 << (1));
     }

   nums = generic_bignum + size / (1 << (1));
   while (size > 0)
     {
       --nums;
       md_number_to_chars (p, (valueT) *nums, (1 << (1)));
       size -= (1 << (1));
       p += (1 << (1));
     }
 }
      else
 {
   nums = generic_bignum;
   while (size > 0)
     {
       md_number_to_chars (p, (valueT) *nums, (1 << (1)));
       ++nums;
       size -= (1 << (1));
       p += (1 << (1));
       nbytes -= (1 << (1));
     }

   while (nbytes > 0)
     {
       md_number_to_chars (p, extra_digit, (1 << (1)));
       nbytes -= (1 << (1));
       p += (1 << (1));
     }
 }
    }
  else
    {
      memset (p, 0, nbytes);
      cons_fix_new_mips (frag_now, p - frag_now->fr_literal, nbytes, exp);
    }
}
static void
parse_mri_cons(expressionS *exp, unsigned int nbytes) asm("_parse_mri_cons");
static void
parse_mri_cons(expressionS *exp, unsigned int nbytes)
{
  if (*input_line_pointer != '\''
      && (input_line_pointer[1] != '\''
   || (*input_line_pointer != 'A'
       && *input_line_pointer != 'E')))
    parse_repeat_cons (exp, nbytes);
  else
    {
      int scan = 0;
      unsigned int result = 0;




      if (*input_line_pointer == 'A')
 ++input_line_pointer;
      else if (*input_line_pointer == 'E')
 {
   as_bad ("EBCDIC constants are not supported");
   ++input_line_pointer;
 }

      input_line_pointer++;
      for (scan = 0; scan < nbytes; scan++)
 {
   if (*input_line_pointer == '\'')
     {
       if (input_line_pointer[1] == '\'')
  {
    input_line_pointer++;
  }
       else
  break;
     }
   result = (result << 8) | (*input_line_pointer++);
 }


      while (scan < nbytes)
 {
   result <<= 8;
   scan++;
 }

      exp->X_op = O_constant;
      exp->X_add_number = result;

      if (input_line_pointer[0] != '\'' ||
   (input_line_pointer[0] == '\'' && input_line_pointer[1] == '\''))
 {
   input_line_pointer -= 2;
   input_line_pointer[0] = ',';
   input_line_pointer[1] = '\'';
 }
      else
 input_line_pointer++;
    }
}
static void
parse_repeat_cons(expressionS *exp, unsigned int nbytes) asm("_parse_repeat_cons");
static void
parse_repeat_cons(expressionS *exp, unsigned int nbytes)
{
  expressionS count;
  register int i;

  expr (0, exp);

  if (*input_line_pointer != ':')
    {

      return;
    }

  ++input_line_pointer;
  expr (0, &count);
  if (count.X_op != O_constant
      || count.X_add_number <= 0)
    {
      as_warn ("Unresolvable or nonpositive repeat count; using 1");
      return;
    }



  for (i = count.X_add_number - 1; i > 0; i--)
    emit_expr (exp, nbytes);
}







static int
hex_float(int float_type, char *bytes) asm("_hex_float");
static int
hex_float(int float_type, char *bytes)
{
  int length;
  int i;

  switch (float_type)
    {
    case 'f':
    case 'F':
    case 's':
    case 'S':
      length = 4;
      break;

    case 'd':
    case 'D':
    case 'r':
    case 'R':
      length = 8;
      break;

    case 'x':
    case 'X':
      length = 12;
      break;

    case 'p':
    case 'P':
      length = 12;
      break;

    default:
      as_bad ("Unknown floating type type '%c'", float_type);
      return -1;
    }




  i = 0;
  while (((_hex_value[(unsigned char) (*input_line_pointer)]) != 99) || *input_line_pointer == '_')
    {
      int d;



      if (*input_line_pointer == '_')
 {
   ++input_line_pointer;
   continue;
 }

      if (i >= length)
 {
   as_warn ("Floating point constant too large");
   return -1;
 }
      d = (_hex_value[(unsigned char) (*input_line_pointer)]) << 4;
      ++input_line_pointer;
      while (*input_line_pointer == '_')
 ++input_line_pointer;
      if (((_hex_value[(unsigned char) (*input_line_pointer)]) != 99))
 {
   d += (_hex_value[(unsigned char) (*input_line_pointer)]);
   ++input_line_pointer;
 }
      if (target_big_endian)
 bytes[i] = d;
      else
 bytes[length - i - 1] = d;
      ++i;
    }

  if (i < length)
    {
      if (target_big_endian)
 memset (bytes + i, 0, length - i);
      else
 memset (bytes, 0, length - i);
    }

  return length;
}
void
float_cons(register int float_type) asm("_float_cons");
void
float_cons(register int float_type)
{
  register char *p;
  int length;
  register char *err;
  char temp[(16)];

  if (is_it_end_of_statement ())
    {
      demand_empty_rest_of_line ();
      return;
    }

  do
    {

      {if (* input_line_pointer == ' ') ++ input_line_pointer;};






      if (input_line_pointer[0] == '0' && isalpha (input_line_pointer[1]))
 input_line_pointer += 2;



      if (input_line_pointer[0] == ':')
 {
   ++input_line_pointer;
   length = hex_float (float_type, temp);
   if (length < 0)
     {
       ignore_rest_of_line ();
       return;
     }
 }
      else
 {
   err = md_atof (float_type, temp, &length);
   ;
   ;
   if (err)
     {
       as_bad ("Bad floating literal: %s", err);
       ignore_rest_of_line ();
       return;
     }
 }

      if (!need_pass_2)
 {
   int count;

   count = 1;


   if (*input_line_pointer == ':')
     {
       expressionS count_exp;

       ++input_line_pointer;
       expr (0, &count_exp);
       if (count_exp.X_op != O_constant
    || count_exp.X_add_number <= 0)
  {
    as_warn ("unresolvable or nonpositive repeat count; using 1");
  }
       else
  count = count_exp.X_add_number;
     }


   while (--count >= 0)
     {
       p = frag_more (length);
       memcpy (p, temp, (unsigned int) length);
     }
 }
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
    }
  while (*input_line_pointer++ == ',');

  --input_line_pointer;
  demand_empty_rest_of_line ();
}
void
stringer(register int append_zero) asm("_stringer");
void
stringer(register int append_zero)
{
  register unsigned int c;


  mips_flush_pending_output ();
  if (is_it_end_of_statement ())
    {
      c = 0;
      ++input_line_pointer;
    }
  else
    {
      c = ',';
    }
  while (c == ',' || c == '<' || c == '"')
    {
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      switch (*input_line_pointer)
 {
 case '\"':
   ++input_line_pointer;
   while ((((unsigned)(c = next_char_of_string ())) <= (0xff)))
     {
       frag_append_1_char (c);
     }
   if (append_zero)
     {
       frag_append_1_char (0);
     }
   ;
   break;
 case '<':
   input_line_pointer++;
   c = get_single_number ();
   frag_append_1_char (c);
   if (*input_line_pointer != '>')
     {
       as_bad ("Expected <nn>");
     }
   input_line_pointer++;
   break;
 case ',':
   input_line_pointer++;
   break;
 }
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      c = *input_line_pointer;
    }

  demand_empty_rest_of_line ();
}






unsigned int
next_char_of_string(void) asm("_next_char_of_string");
unsigned int
next_char_of_string(void)
{
  register unsigned int c;

  c = *input_line_pointer++ & (0xff);
  switch (c)
    {
    case '\"':
      c = ((0xff)+1);
      break;


    case '\\':
      switch (c = *input_line_pointer++)
 {
 case 'b':
   c = '\b';
   break;

 case 'f':
   c = '\f';
   break;

 case 'n':
   c = '\n';
   break;

 case 'r':
   c = '\r';
   break;

 case 't':
   c = '\t';
   break;

 case 'v':
   c = '\013';
   break;

 case '\\':
 case '"':
   break;

 case '0':
 case '1':
 case '2':
 case '3':
 case '4':
 case '5':
 case '6':
 case '7':
 case '8':
 case '9':
   {
     long number;
     int i;

     for (i = 0, number = 0; isdigit (c) && i < 3; c = *input_line_pointer++, i++)
       {
  number = number * 8 + c - '0';
       }
     c = number & 0xff;
   }
   --input_line_pointer;
   break;

 case 'x':
 case 'X':
   {
     long number;

     number = 0;
     c = *input_line_pointer++;
     while (isxdigit (c))
       {
  if (isdigit (c))
    number = number * 16 + c - '0';
  else if (isupper (c))
    number = number * 16 + c - 'A' + 10;
  else
    number = number * 16 + c - 'a' + 10;
  c = *input_line_pointer++;
       }
     c = number & 0xff;
     --input_line_pointer;
   }
   break;

 case '\n':

   as_warn ("Unterminated string: Newline inserted.");
   c = '\n';
   break;

 default:


   as_bad ("Bad escaped character in string, '?' assumed");
   c = '?';


   break;
 }
      break;


    default:
      break;
    }
  return (c);
}

static segT
get_segmented_expression(register expressionS *expP) asm("_get_segmented_expression");
static segT
get_segmented_expression(register expressionS *expP)
{
  register segT retval;

  retval = expr (0, expP);
  if (expP->X_op == O_illegal
      || expP->X_op == O_absent
      || expP->X_op == O_big)
    {
      as_bad ("expected address expression; zero assumed");
      expP->X_op = O_constant;
      expP->X_add_number = 0;
      retval = ((asection *) &bfd_abs_section);
    }
  return retval;
}

static segT
get_known_segmented_expression(register expressionS *expP) asm("_get_known_segmented_expression");
static segT
get_known_segmented_expression(register expressionS *expP)
{
  register segT retval;

  if ((retval = get_segmented_expression (expP)) == ((asection *) &bfd_und_section))
    {


      if (expP->X_add_symbol != 
                               ((void *)0)
   
  && S_GET_SEGMENT (expP->X_add_symbol) != expr_section)
 as_warn ("symbol \"%s\" undefined; zero assumed",
   S_GET_NAME (expP->X_add_symbol));
      else
 as_warn ("some symbol undefined; zero assumed");
      retval = ((asection *) &bfd_abs_section);
      expP->X_op = O_constant;
      expP->X_add_number = 0;
    }
  ;
  return (retval);
}

offsetT
get_absolute_expression(void) asm("_get_absolute_expression");
offsetT
get_absolute_expression(void)
{
  expressionS exp;

  expr (0, &exp);
  if (exp.X_op != O_constant)
    {
      if (exp.X_op != O_absent)
 as_bad ("bad or irreducible absolute expression; zero assumed");
      exp.X_add_number = 0;
    }
  return exp.X_add_number;
}

char
get_absolute_expression_and_terminator(long int *val_pointer) asm("_get_absolute_expression_and_terminator");
char
get_absolute_expression_and_terminator(long int *val_pointer)
{

  *val_pointer = (long) get_absolute_expression ();
  return (*input_line_pointer++);
}







char *
demand_copy_C_string(int *len_pointer) asm("_demand_copy_C_string");
char *
demand_copy_C_string(int *len_pointer)
{
  register char *s;

  if ((s = demand_copy_string (len_pointer)) != 0)
    {
      register int len;

      for (len = *len_pointer;
    len > 0;
    len--)
 {
   if (*s == 0)
     {
       s = 0;
       len = 1;
       *len_pointer = 0;
       as_bad ("This string may not contain \'\\0\'");
     }
 }
    }
  return (s);
}







char *
demand_copy_string(int *lenP) asm("_demand_copy_string");
char *
demand_copy_string(int *lenP)
{
  register unsigned int c;
  register int len;
  char *retval;

  len = 0;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer == '\"')
    {
      input_line_pointer++;

      while ((((unsigned)(c = next_char_of_string ())) <= (0xff)))
 {
   __extension__ ({ struct n64_tag_obstack *__o = (&notes); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
   len++;
 }


      __extension__ ({ struct n64_tag_obstack *__o = (&notes); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; });
      retval = __extension__ ({ struct n64_tag_obstack *__o1 = (&notes); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
    }
  else
    {
      as_warn ("Missing string");
      retval = 
              ((void *)0)
                  ;
      ignore_rest_of_line ();
    }
  *lenP = len;
  return (retval);
}
int
is_it_end_of_statement(void) asm("_is_it_end_of_statement");
int
is_it_end_of_statement(void)
{
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  return (is_end_of_line[(unsigned char) *input_line_pointer]);
}

void
equals(char *sym_name) asm("_equals");
void
equals(char *sym_name)
{
  register symbolS *symbolP;
  char *stop;
  char stopc;

  input_line_pointer++;
  if (*input_line_pointer == '=')
    input_line_pointer++;

  while (*input_line_pointer == ' ' || *input_line_pointer == '\t')
    input_line_pointer++;

  if (flag_mri)
    stop = mri_comment_field (&stopc);

  if (sym_name[0] == '.' && sym_name[1] == '\0')
    {

      register segT segment;
      expressionS exp;

      segment = get_known_segmented_expression (&exp);
      if (!need_pass_2)
 do_org (segment, &exp, 0);
    }
  else
    {
      symbolP = symbol_find_or_make (sym_name);
      pseudo_set (symbolP);
    }

  if (flag_mri)
    mri_comment_end (stop, stopc);
}




void
s_include(int arg) asm("_s_include");
void
s_include(int arg)
{
  char *newbuf;
  char *filename;
  int i;
  FILE *cxx_try;
  char *path;

  if (! flag_mri)
    filename = demand_copy_string (&i);
  else
    {
      {if (* input_line_pointer == ' ') ++ input_line_pointer;};
      i = 0;
      while (! is_end_of_line[(unsigned char) *input_line_pointer]
      && *input_line_pointer != ' '
      && *input_line_pointer != '\t')
 {
   __extension__ ({ struct n64_tag_obstack *__o = (&notes); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (*input_line_pointer); (void) 0; });
   ++input_line_pointer;
   ++i;
 }
      __extension__ ({ struct n64_tag_obstack *__o = (&notes); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; });
      filename = __extension__ ({ struct n64_tag_obstack *__o1 = (&notes); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
      while (! is_end_of_line[(unsigned char) *input_line_pointer])
 ++input_line_pointer;
    }
  demand_empty_rest_of_line ();
  path = xmalloc ((unsigned long) i + include_dir_maxlen + 5 );
  for (i = 0; i < include_dir_count; i++)
    {
      strcpy (path, include_dirs[i]);
      strcat (path, "/");
      strcat (path, filename);
      if (0 != (cxx_try = fopen (path, "r")))
 {
   fclose (cxx_try);
   goto gotit;
 }
    }
  free (path);
  path = filename;
gotit:

  newbuf = input_scrub_include_file (path, input_line_pointer);
  buffer_limit = input_scrub_next_buffer (&input_line_pointer);
}

void
add_include_dir(char *path) asm("_add_include_dir");
void
add_include_dir(char *path)
{
  int i;

  if (include_dir_count == 0)
    {
      include_dirs = (char **) xmalloc (2 * sizeof (*include_dirs));
      include_dirs[0] = ".";
      include_dir_count = 2;
    }
  else
    {
      include_dir_count++;
      include_dirs = (char **) realloc (include_dirs,
    include_dir_count * sizeof (*include_dirs));
    }

  include_dirs[include_dir_count - 1] = path;

  i = strlen (path);
  if (i > include_dir_maxlen)
    include_dir_maxlen = i;
}

void
s_ignore(int arg) asm("_s_ignore");
void
s_ignore(int arg)
{
  while (!is_end_of_line[(unsigned char) *input_line_pointer])
    {
      ++input_line_pointer;
    }
  ++input_line_pointer;
}

