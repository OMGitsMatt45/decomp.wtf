// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/getopt1.c
/* getopt_long and getopt_long_only entry points for GNU getopt.
   Copyright (C) 1987, 88, 89, 90, 91, 92, 1993
	Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License
   as published by the Free Software Foundation; either version 2, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Library General Public License for more details.

   You should have received a copy of the GNU Library General Public License
   along with this program; if not, write to the Free Software
   Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_option;
extern char *optarg;
extern int optind;




extern int opterr;



extern int optopt;
struct n64_tag_option
{

  const char *name;





  int has_arg;
  int *flag;
  int val;
};
extern int getopt(...) asm("_getopt");

extern int getopt_long (int argc, char *const *argv, const char *shortopts,
          const struct n64_tag_option *longopts, int *longind) asm("_getopt_long");
extern int getopt_long_only (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind) asm("_getopt_long_only");


extern int _getopt_internal (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind,
        int long_only) asm("__getopt_internal");

char *getenv(...) asm("_getenv");






int
getopt_long(int argc, char *const *argv, const char *options, const struct n64_tag_option *long_options, int *opt_index) asm("_getopt_long");
int
getopt_long(int argc, char *const *argv, const char *options, const struct n64_tag_option *long_options, int *opt_index)
{
  return _getopt_internal (argc, argv, options, long_options, opt_index, 0);
}






int
getopt_long_only(int argc, char *const *argv, const char *options, const struct n64_tag_option *long_options, int *opt_index) asm("_getopt_long_only");
int
getopt_long_only(int argc, char *const *argv, const char *options, const struct n64_tag_option *long_options, int *opt_index)
{
  return _getopt_internal (argc, argv, options, long_options, opt_index, 1);
}

