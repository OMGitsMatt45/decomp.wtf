// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cccp.c
/* C Compatible Compiler Preprocessor (CCCP)
   Copyright (C) 1986, 87, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Written by Paul Rubin, June 1986
   Adapted to ANSI C, Richard Stallman, Jan 1987

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

 In other words, you are welcome to use, share and improve this program.
 You are forbidden to forbid anyone else to use, share and improve
 what you give them.   Help stamp out software-hoarding!  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <stdarg.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_argdata;
struct n64_tag_arglist;
struct n64_tag_assertion_hashnode;
struct n64_tag_default_include;
struct n64_tag_definition;
struct n64_tag_directive;
struct n64_tag_file_buf;
struct n64_tag_file_name_list;
struct n64_tag_file_name_map;
struct n64_tag_file_name_map_list;
struct n64_tag_hashnode;
union n64_tag_hashval;
struct n64_tag_if_stack;
struct n64_tag_import_file;
struct n64_tag_keydef;
struct n64_tag_macrodef;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_reflist;
struct n64_tag_stringdef;
struct n64_tag_tokenlist_list;
typedef unsigned char U_CHAR;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
typedef struct n64_tag_stringdef STRINGDEF;
struct n64_tag_stringdef
{
  U_CHAR *contents;
  int len;
  int writeflag;
  int lineno;
  U_CHAR *filename;
  STRINGDEF *chain;
  int output_mark;
};

typedef struct n64_tag_keydef KEYDEF;
struct n64_tag_keydef
{
  STRINGDEF *str;
  KEYDEF *chain;
};







char *getenv(...) asm("_getenv");
char *strchr(...) asm("_strchr");
char *strrchr(...) asm("_strrchr");
extern char *version_string;
char *strerror(...) asm("_strerror");




int parse_escape (char **) asm("_parse_escape");
int parse_c_expression (char *) asm("_parse_c_expression");







static char *progname;



static int cplusplus;



static int cplusplus_comments;



static int objc;




static int lang_asm;




static int max_include_len;



static int for_lint = 0;



static int put_out_comments = 0;



static int no_trigraphs = 0;





static int print_deps = 0;




static int print_deps_missing_files = 0;



static int print_include_names = 0;



static int no_line_directives;




static int output_conditionals;
enum n64_cpp_enum_anonymous_6{dump_none, dump_only, dump_names, dump_definitions};
typedef __underlying_type(enum n64_cpp_enum_anonymous_6) n64_enum_anonymous_6;
static n64_enum_anonymous_6
     dump_macros = dump_none;







static int debug_output = 0;
static FILE *pcp_outfile;




static int pcp_inside_if;




static int no_precomp = 1;



int pedantic;



static int pedantic_errors;



static int inhibit_warnings = 0;



static int warn_comments;




static int warn_stringify;



static int warn_trigraphs;



static int warn_import = 1;



static int warnings_are_errors;



int traditional;





static int no_output;




static int no_record_file;





static int done_initializing = 0;



static int multiline_string_line = 0;







static struct n64_tag_file_buf {
  char *fname;

  char *nominal_fname;


  struct n64_tag_file_name_list *dir;
  int lineno;
  int length;
  U_CHAR *buf;
  U_CHAR *bufp;



  struct n64_tag_hashnode *macro;


  struct n64_tag_if_stack *if_stack;

  U_CHAR *free_ptr;

  char system_header_p;
} instack[400];

static int last_error_tick;
static int input_file_stack_tick;



static int indepth = -1;
static int system_include_depth = 0;

typedef struct n64_tag_file_buf FILE_BUF;






static FILE_BUF outbuf;
struct n64_tag_file_name_list
  {
    struct n64_tag_file_name_list *next;
    char *fname;


    U_CHAR *control_macro;


    int c_system_include_path;

    struct n64_tag_file_name_map *name_map;

    int got_name_map;
  };





static struct n64_tag_default_include {
  char *fname;
  int cplusplus;
  int cxx_aware;


} include_defaults_array[]



  = {

    { "/opt/cross/lib/g++-include", 1, 1 },



    { "/opt/cross/lib/gcc-lib/mips-mips-gnu/2.7.2/include", 0, 0 },


    { "/opt/cross/lib/gcc-lib/mips-mips-gnu/2.7.2/sys-include", 0, 0 },

    { "/opt/cross/mips-mips-gnu/include", 0, 0 },
    { 0, 0, 0 }
    };





static struct n64_tag_default_include *include_defaults = include_defaults_array;

static struct n64_tag_file_name_list *include = 0;



static struct n64_tag_file_name_list *first_bracket_include = 0;


static struct n64_tag_file_name_list *first_system_include = 0;
static struct n64_tag_file_name_list *last_include = 0;


static struct n64_tag_file_name_list *after_include = 0;
static struct n64_tag_file_name_list *last_after_include = 0;


static struct n64_tag_file_name_list *before_system = 0;
static struct n64_tag_file_name_list *last_before_system = 0;


static struct n64_tag_file_name_list *dont_repeat_files = 0;




static struct n64_tag_file_name_list *all_include_files = 0;



static char *include_prefix;






static STRINGDEF *stringlist;
static STRINGDEF **stringlist_tailp = &stringlist;



typedef struct n64_tag_macrodef MACRODEF;
struct n64_tag_macrodef
{
  struct n64_tag_definition *defn;
  U_CHAR *symnam;
  int symlen;
};

enum n64_cpp_enum_sharp_token_type{
  NO_SHARP_TOKEN = 0,

  SHARP_TOKEN = '#',
  WHITE_SHARP_TOKEN,

  PERCENT_COLON_TOKEN = '%',
  WHITE_PERCENT_COLON_TOKEN
};
typedef __underlying_type(enum n64_cpp_enum_sharp_token_type) n64_enum_sharp_token_type;

typedef struct n64_tag_definition DEFINITION;
struct n64_tag_reflist {
    struct n64_tag_reflist *next;

    n64_enum_sharp_token_type stringify;
    n64_enum_sharp_token_type raw_before;
    n64_enum_sharp_token_type raw_after;

    char rest_args;
    int nchars;

    int argno;
  };
struct n64_tag_definition {
  int nargs;
  int length;
  int predefined;

  U_CHAR *expansion;
  int line;
  char *file;
  char rest_args;
  struct n64_tag_reflist *pattern;
  union {




    U_CHAR *argnames;
  } args;
};



union n64_tag_hashval {
  char *cpval;
  DEFINITION *defn;
  KEYDEF *keydef;
};
static char rest_extension[] = "...";
enum n64_cpp_enum_node_type{
 T_DEFINE = 1,
 T_INCLUDE,
 T_INCLUDE_NEXT,
 T_IMPORT,
 T_IFDEF,
 T_IFNDEF,
 T_IF,
 T_ELSE,
 T_PRAGMA,
 T_ELIF,
 T_UNDEF,
 T_LINE,
 T_ERROR,
 T_WARNING,
 T_ENDIF,
 T_SCCS,
 T_IDENT,
 T_ASSERT,
 T_UNASSERT,
 T_SPECLINE,
 T_DATE,
 T_FILE,
 T_BASE_FILE,
 T_INCLUDE_LEVEL,
 T_VERSION,
 T_SIZE_TYPE,
 T_PTRDIFF_TYPE,
 T_WCHAR_TYPE,
 T_USER_LABEL_PREFIX_TYPE,
 T_REGISTER_PREFIX_TYPE,
 T_IMMEDIATE_PREFIX_TYPE,
 T_TIME,
 T_CONST,
 T_MACRO,
 T_DISABLED,
 T_SPEC_DEFINED,
 T_PCSTRING,
 T_UNUSED
 };
typedef __underlying_type(enum n64_cpp_enum_node_type) n64_enum_node_type;


struct n64_tag_hashnode {
  struct n64_tag_hashnode *next;
  struct n64_tag_hashnode *prev;
  struct n64_tag_hashnode **bucket_hdr;


  n64_enum_node_type type;
  int length;
  U_CHAR *name;
  union n64_tag_hashval value;
};

typedef struct n64_tag_hashnode HASHNODE;
static HASHNODE *hashtab[1403];






static char *predefs = "-D" "mips" " -Acpu(" "mips" ") -Amachine(" "mips" ")" "-Dunix -Asystem(unix) -DMACH -Asystem(mach) -D__GNU__ -Asystem(gnu)" "-DMIPSEB -DR3000 -D_MIPSEB -D_R3000 -D_MIPS_SZINT=32 -D_MIPS_SZLONG=32 -D_MIPS_SZPTR=32";
char * wchar_type = "long int";
struct n64_tag_tokenlist_list {
  struct n64_tag_tokenlist_list *next;
  struct n64_tag_arglist *tokens;
};

struct n64_tag_assertion_hashnode {
  struct n64_tag_assertion_hashnode *next;
  struct n64_tag_assertion_hashnode *prev;



  struct n64_tag_assertion_hashnode **bucket_hdr;
  int length;
  U_CHAR *name;

  struct n64_tag_tokenlist_list *value;
};

typedef struct n64_tag_assertion_hashnode ASSERTION_HASHNODE;
static ASSERTION_HASHNODE *assertion_hashtab[37];



static int assertions_flag;





struct n64_tag_directive {
  int length;
  int (*func) (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *);
  char *name;
  n64_enum_node_type type;
  char angle_brackets;
  char traditional_comments;
  char pass_thru;
};





static int do_assert (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_assert");
static int do_define (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_define");
static int do_elif (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_elif");
static int do_else (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_else");
static int do_endif (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_endif");
static int do_error (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_error");
static int do_ident (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_ident");
static int do_if (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_if");
static int do_include (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_include");
static int do_line (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_line");
static int do_pragma (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_pragma");

static int do_sccs (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_sccs");

static int do_unassert (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_unassert");
static int do_undef (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_undef");
static int do_warning (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_warning");
static int do_xifdef (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_do_xifdef");



static struct n64_tag_directive directive_table[] = {
  { 6, do_define, "define", T_DEFINE, 0, 1},
  { 2, do_if, "if", T_IF},
  { 5, do_xifdef, "ifdef", T_IFDEF},
  { 6, do_xifdef, "ifndef", T_IFNDEF},
  { 5, do_endif, "endif", T_ENDIF},
  { 4, do_else, "else", T_ELSE},
  { 4, do_elif, "elif", T_ELIF},
  { 4, do_line, "line", T_LINE},
  { 7, do_include, "include", T_INCLUDE, 1},
  { 12, do_include, "include_next", T_INCLUDE_NEXT, 1},
  { 6, do_include, "import", T_IMPORT, 1},
  { 5, do_undef, "undef", T_UNDEF},
  { 5, do_error, "error", T_ERROR},
  { 7, do_warning, "warning", T_WARNING},

  { 4, do_sccs, "sccs", T_SCCS},

  { 6, do_pragma, "pragma", T_PRAGMA, 0, 0, 1},
  { 5, do_ident, "ident", T_IDENT},
  { 6, do_assert, "assert", T_ASSERT},
  { 8, do_unassert, "unassert", T_UNASSERT},
  { -1, 0, "", T_UNUSED},
};



U_CHAR *directive_start;


U_CHAR is_idchar[256];

U_CHAR is_idstart[256];

U_CHAR is_hor_space[256];

static U_CHAR is_space[256];

static char *char_name[256];




static int errors = 0;


static char *out_fname;
static int dollars_in_ident;
struct n64_tag_if_stack {
  struct n64_tag_if_stack *next;
  char *fname;
  int lineno;
  int if_succeeded;

  U_CHAR *control_macro;

  n64_enum_node_type type;
};
typedef struct n64_tag_if_stack IF_STACK_FRAME;
static IF_STACK_FRAME *if_stack = 
                                 ((void *)0)
                                     ;


static char *deps_buffer;


static int deps_allocated_size;


static int deps_size;


static int deps_column;



static int ignore_srcdir;

static int safe_read (int, char *, int) asm("_safe_read");
static void safe_write (int, char *, int) asm("_safe_write");

int main (int, char **) asm("_main");

static void path_include (char *) asm("_path_include");

static U_CHAR *index0 (U_CHAR *, int, size_t) asm("_index0");

static void trigraph_pcp (FILE_BUF *) asm("_trigraph_pcp");

static void newline_fix (U_CHAR *) asm("_newline_fix");
static void name_newline_fix (U_CHAR *) asm("_name_newline_fix");

static char *get_lintcmd (U_CHAR *, U_CHAR *, U_CHAR **, int *, int *) asm("_get_lintcmd");

static void rescan (FILE_BUF *, int) asm("_rescan");

static FILE_BUF expand_to_temp_buffer (U_CHAR *, U_CHAR *, int, int) asm("_expand_to_temp_buffer");

static int handle_directive (FILE_BUF *, FILE_BUF *) asm("_handle_directive");

static struct tm *timestamp (void) asm("_timestamp");
static void special_symbol (HASHNODE *, FILE_BUF *) asm("_special_symbol");

static int redundant_include_p (char *) asm("_redundant_include_p");
static int is_system_include (char *) asm("_is_system_include");
static char *skip_redundant_dir_prefix (char *) asm("_skip_redundant_dir_prefix");

static char *read_filename_string (int, FILE *) asm("_read_filename_string");
static struct n64_tag_file_name_map *read_name_map (char *) asm("_read_name_map");
static int open_include_file (char *, struct n64_tag_file_name_list *) asm("_open_include_file");

static void finclude (int, char *, FILE_BUF *, int, struct n64_tag_file_name_list *) asm("_finclude");
static void record_control_macro (char *, U_CHAR *) asm("_record_control_macro");

static int import_hash (char *) asm("_import_hash");
static int lookup_import (char *, struct n64_tag_file_name_list *) asm("_lookup_import");
static void add_import (int, char *) asm("_add_import");

static char *check_precompiled (int, char *, char **) asm("_check_precompiled");
static int check_preconditions (char *) asm("_check_preconditions");
static void pcfinclude (U_CHAR *, U_CHAR *, U_CHAR *, FILE_BUF *) asm("_pcfinclude");
static void pcstring_used (HASHNODE *) asm("_pcstring_used");
static void write_output (void) asm("_write_output");
static void pass_thru_directive (U_CHAR *, U_CHAR *, FILE_BUF *, struct n64_tag_directive *) asm("_pass_thru_directive");

static MACRODEF create_definition (U_CHAR *, U_CHAR *, FILE_BUF *) asm("_create_definition");

static int check_macro_name (U_CHAR *, char *) asm("_check_macro_name");
static int compare_defs (DEFINITION *, DEFINITION *) asm("_compare_defs");
static int comp_def_part (int, U_CHAR *, int, U_CHAR *, int, int) asm("_comp_def_part");

static DEFINITION *collect_expansion (U_CHAR *, U_CHAR *, int, struct n64_tag_arglist *) asm("_collect_expansion");

int check_assertion (U_CHAR *, int, int, struct n64_tag_arglist *) asm("_check_assertion");
static int compare_token_lists (struct n64_tag_arglist *, struct n64_tag_arglist *) asm("_compare_token_lists");

static struct n64_tag_arglist *read_token_list (U_CHAR **, U_CHAR *, int *) asm("_read_token_list");
static void free_token_list (struct n64_tag_arglist *) asm("_free_token_list");

static ASSERTION_HASHNODE *assertion_install (U_CHAR *, int, int) asm("_assertion_install");
static ASSERTION_HASHNODE *assertion_lookup (U_CHAR *, int, int) asm("_assertion_lookup");
static void delete_assertion (ASSERTION_HASHNODE *) asm("_delete_assertion");

static void do_once (void) asm("_do_once");

static int eval_if_expression (U_CHAR *, int) asm("_eval_if_expression");
static void conditional_skip (FILE_BUF *, int, n64_enum_node_type, U_CHAR *, FILE_BUF *) asm("_conditional_skip");
static void skip_if_group (FILE_BUF *, int, FILE_BUF *) asm("_skip_if_group");
static void validate_else (U_CHAR *) asm("_validate_else");

static U_CHAR *skip_to_end_of_comment (FILE_BUF *, int *, int) asm("_skip_to_end_of_comment");
static U_CHAR *skip_quoted_string (U_CHAR *, U_CHAR *, int, int *, int *, int *) asm("_skip_quoted_string");
static char *quote_string (char *, char *) asm("_quote_string");
static U_CHAR *skip_paren_group (FILE_BUF *) asm("_skip_paren_group");


enum n64_cpp_enum_file_change_code{same_file, enter_file, leave_file};
typedef __underlying_type(enum n64_cpp_enum_file_change_code) n64_enum_file_change_code;

static void output_line_directive (FILE_BUF *, FILE_BUF *, int, n64_enum_file_change_code) asm("_output_line_directive");

static void macroexpand (HASHNODE *, FILE_BUF *) asm("_macroexpand");

struct n64_tag_argdata;
static char *macarg (struct n64_tag_argdata *, int) asm("_macarg");

static U_CHAR *macarg1 (U_CHAR *, U_CHAR *, int *, int *, int *, int) asm("_macarg1");

static int discard_comments (U_CHAR *, int, int) asm("_discard_comments");

static int change_newlines (U_CHAR *, int) asm("_change_newlines");

char *my_strerror (int) asm("_my_strerror");
void error (char *, ...) asm("_error") __attribute__ ((format (printf, 1, 2)));
static void verror (char *, va_list) asm("_verror");
static void error_from_errno (char *) asm("_error_from_errno");
void warning (char *, ...) asm("_warning") __attribute__ ((format (printf, 1, 2)));
static void vwarning (char *, va_list) asm("_vwarning");
static void error_with_line (int, char *, ...) asm("_error_with_line") __attribute__ ((format (printf, 2, 3)));
static void verror_with_line (int, char *, va_list) asm("_verror_with_line");
static void vwarning_with_line (int, char *, va_list) asm("_vwarning_with_line");
static void warning_with_line (int, char *, ...) asm("_warning_with_line") __attribute__ ((format (printf, 2, 3)));
void pedwarn (char *, ...) asm("_pedwarn") __attribute__ ((format (printf, 1, 2)));
void pedwarn_with_line (int, char *, ...) asm("_pedwarn_with_line") __attribute__ ((format (printf, 2, 3)));
static void pedwarn_with_file_and_line (char *, int, char *, ...) asm("_pedwarn_with_file_and_line") __attribute__ ((format (printf, 3, 4)));

static void print_containing_files (void) asm("_print_containing_files");

static int line_for_error (int) asm("_line_for_error");
static int grow_outbuf (FILE_BUF *, int) asm("_grow_outbuf");

static HASHNODE *install (U_CHAR *, int, n64_enum_node_type, char *, int) asm("_install");
HASHNODE *lookup (U_CHAR *, int, int) asm("_lookup");
static void delete_macro (HASHNODE *) asm("_delete_macro");
static int hashf (U_CHAR *, int, int) asm("_hashf");

static void dump_single_macro (HASHNODE *, FILE *) asm("_dump_single_macro");
static void dump_all_macros (void) asm("_dump_all_macros");
static void dump_defn_1 (U_CHAR *, int, int, FILE *) asm("_dump_defn_1");
static void dump_arg_n (DEFINITION *, int, FILE *) asm("_dump_arg_n");

static void initialize_char_syntax (void) asm("_initialize_char_syntax");
static void initialize_builtins (FILE_BUF *, FILE_BUF *) asm("_initialize_builtins");

static void make_definition (char *, FILE_BUF *) asm("_make_definition");
static void make_undef (char *, FILE_BUF *) asm("_make_undef");

static void make_assertion (char *, char *) asm("_make_assertion");

static void append_include_chain (struct n64_tag_file_name_list *, struct n64_tag_file_name_list *) asm("_append_include_chain");

static void deps_output (char *, int) asm("_deps_output");

static void fatal (char *, ...) asm("_fatal") __attribute__ ((format (printf, 1, 2))) __attribute__ ((noreturn));
void fancy_abort (void) asm("_fancy_abort") __attribute__ ((noreturn));
static void perror_with_name (char *) asm("_perror_with_name");
static void pfatal_with_name (char *) asm("_pfatal_with_name") __attribute__ ((noreturn));
static void pipe_closed (int) asm("_pipe_closed") __attribute__ ((noreturn));

static void memory_full (void) asm("_memory_full") __attribute__ ((noreturn));
void * xmalloc (size_t) asm("_xmalloc");
static void * xrealloc (void *, size_t) asm("_xrealloc");
static void * xcalloc (size_t, size_t) asm("_xcalloc");
static char *savestring (char *) asm("_savestring");

static int file_size_and_mode (int, int *, long int *) asm("_file_size_and_mode");






static int
safe_read(int desc, char *ptr, int len) asm("_safe_read");
static int
safe_read(int desc, char *ptr, int len)
{
  int left = len;
  while (left > 0) {
    int nchars = read (desc, ptr, left);
    if (nchars < 0)
      {

 if (
    (*_errno()) 
          == 
             4
                  )
   continue;

 return nchars;
      }
    if (nchars == 0)
      break;
    ptr += nchars;
    left -= nchars;
  }
  return len - left;
}




static void
safe_write(int desc, char *ptr, int len) asm("_safe_write");
static void
safe_write(int desc, char *ptr, int len)
{
  while (len > 0) {
    int written = write (desc, ptr, len);
    if (written < 0)
      {

 if (
    (*_errno()) 
          == 
             4
                  )
   continue;

 pfatal_with_name (out_fname);
      }
    ptr += written;
    len -= written;
  }
}

int
main(int argc, char **argv) asm("_main");
int
main(int argc, char **argv)
{
  int st_mode;
  long st_size;
  char *in_fname;
  char *cp;
  int f, i;
  FILE_BUF *fp;
  char **pend_files = (char **) xmalloc (argc * sizeof (char *));
  char **pend_defs = (char **) xmalloc (argc * sizeof (char *));
  char **pend_undefs = (char **) xmalloc (argc * sizeof (char *));
  char **pend_assertions = (char **) xmalloc (argc * sizeof (char *));
  char **pend_includes = (char **) xmalloc (argc * sizeof (char *));




  char **pend_assertion_options = (char **) xmalloc (argc * sizeof (char *));
  int inhibit_predefs = 0;
  int no_standard_includes = 0;
  int no_standard_cplusplus_includes = 0;
  int missing_newline = 0;


  int inhibit_output = 0;

  int verbose = 0;



  char *deps_file = 0;

  char *deps_mode = "a";

  FILE *deps_stream = 0;

  char *deps_target = 0;
  cp = argv[0] + strlen (argv[0]);
  while (cp != argv[0] && cp[-1] != '/'

  && cp[-1] != '\\'

  )
    --cp;
  progname = cp;
  in_fname = 
            ((void *)0)
                ;
  out_fname = 
             ((void *)0)
                 ;


  dollars_in_ident = 1;
  initialize_char_syntax ();
  dollars_in_ident = 1 > 0;

  no_line_directives = 0;
  no_trigraphs = 1;
  dump_macros = dump_none;
  no_output = 0;
  cplusplus = 0;
  cplusplus_comments = 1;

  memset ((char *) pend_files,0,argc * sizeof (char *));
  memset ((char *) pend_defs,0,argc * sizeof (char *));
  memset ((char *) pend_undefs,0,argc * sizeof (char *));
  memset ((char *) pend_assertions,0,argc * sizeof (char *));
  memset ((char *) pend_includes,0,argc * sizeof (char *));



  for (i = 1; i < argc; i++) {
    if (argv[i][0] != '-') {
      if (out_fname != 
                      ((void *)0)
                          )
 fatal ("Usage: %s [switches] input output", argv[0]);
      else if (in_fname != 
                          ((void *)0)
                              )
 out_fname = argv[i];
      else
 in_fname = argv[i];
    } else {
      switch (argv[i][1]) {

      case 'i':
 if (!strcmp (argv[i], "-include")) {
   if (i + 1 == argc)
     fatal ("Filename missing after `-include' option");
   else
     pend_includes[i] = argv[i+1], i++;
 }
 if (!strcmp (argv[i], "-imacros")) {
   if (i + 1 == argc)
     fatal ("Filename missing after `-imacros' option");
   else
     pend_files[i] = argv[i+1], i++;
 }
 if (!strcmp (argv[i], "-iprefix")) {
   if (i + 1 == argc)
     fatal ("Filename missing after `-iprefix' option");
   else
     include_prefix = argv[++i];
 }
 if (!strcmp (argv[i], "-ifoutput")) {
   output_conditionals = 1;
 }
 if (!strcmp (argv[i], "-isystem")) {
   struct n64_tag_file_name_list *dirtmp;

   if (i + 1 == argc)
     fatal ("Filename missing after `-isystem' option");

   dirtmp = (struct n64_tag_file_name_list *)
     xmalloc (sizeof (struct n64_tag_file_name_list));
   dirtmp->next = 0;
   dirtmp->control_macro = 0;
   dirtmp->c_system_include_path = 1;
   dirtmp->fname = xmalloc (strlen (argv[i+1]) + 1);
   strcpy (dirtmp->fname, argv[++i]);
   dirtmp->got_name_map = 0;

   if (before_system == 0)
     before_system = dirtmp;
   else
     last_before_system->next = dirtmp;
   last_before_system = dirtmp;
 }


 if (!strcmp (argv[i], "-iwithprefix")) {
   struct n64_tag_file_name_list *dirtmp;
   char *prefix;

   if (include_prefix != 0)
     prefix = include_prefix;
   else {
     prefix = savestring ("/opt/cross/lib/gcc-lib/mips-mips-gnu/2.7.2/include");

     if (!strcmp (prefix + strlen (prefix) - 8, "/include"))
       prefix[strlen (prefix) - 7] = 0;
   }

   dirtmp = (struct n64_tag_file_name_list *)
     xmalloc (sizeof (struct n64_tag_file_name_list));
   dirtmp->next = 0;
   dirtmp->control_macro = 0;
   dirtmp->c_system_include_path = 0;
   if (i + 1 == argc)
     fatal ("Directory name missing after `-iwithprefix' option");

   dirtmp->fname = xmalloc (strlen (argv[i+1]) + strlen (prefix) + 1);
   strcpy (dirtmp->fname, prefix);
   strcat (dirtmp->fname, argv[++i]);
   dirtmp->got_name_map = 0;

   if (after_include == 0)
     after_include = dirtmp;
   else
     last_after_include->next = dirtmp;
   last_after_include = dirtmp;
 }


 if (!strcmp (argv[i], "-iwithprefixbefore")) {
   struct n64_tag_file_name_list *dirtmp;
   char *prefix;

   if (include_prefix != 0)
     prefix = include_prefix;
   else {
     prefix = savestring ("/opt/cross/lib/gcc-lib/mips-mips-gnu/2.7.2/include");

     if (!strcmp (prefix + strlen (prefix) - 8, "/include"))
       prefix[strlen (prefix) - 7] = 0;
   }

   dirtmp = (struct n64_tag_file_name_list *)
     xmalloc (sizeof (struct n64_tag_file_name_list));
   dirtmp->next = 0;
   dirtmp->control_macro = 0;
   dirtmp->c_system_include_path = 0;
   if (i + 1 == argc)
     fatal ("Directory name missing after `-iwithprefixbefore' option");

   dirtmp->fname = xmalloc (strlen (argv[i+1]) + strlen (prefix) + 1);
   strcpy (dirtmp->fname, prefix);
   strcat (dirtmp->fname, argv[++i]);
   dirtmp->got_name_map = 0;

   append_include_chain (dirtmp, dirtmp);
 }

 if (!strcmp (argv[i], "-idirafter")) {
   struct n64_tag_file_name_list *dirtmp;

   dirtmp = (struct n64_tag_file_name_list *)
     xmalloc (sizeof (struct n64_tag_file_name_list));
   dirtmp->next = 0;
   dirtmp->control_macro = 0;
   dirtmp->c_system_include_path = 0;
   if (i + 1 == argc)
     fatal ("Directory name missing after `-idirafter' option");
   else
     dirtmp->fname = argv[++i];
   dirtmp->got_name_map = 0;

   if (after_include == 0)
     after_include = dirtmp;
   else
     last_after_include->next = dirtmp;
   last_after_include = dirtmp;
 }
 break;

      case 'o':
 if (out_fname != 
                 ((void *)0)
                     )
   fatal ("Output filename specified twice");
 if (i + 1 == argc)
   fatal ("Filename missing after -o option");
 out_fname = argv[++i];
 if (!strcmp (out_fname, "-"))
   out_fname = "";
 break;

      case 'p':
 if (!strcmp (argv[i], "-pedantic"))
   pedantic = 1;
 else if (!strcmp (argv[i], "-pedantic-errors")) {
   pedantic = 1;
   pedantic_errors = 1;
 } else if (!strcmp (argv[i], "-pcp")) {
   char *pcp_fname;
   if (i + 1 == argc)
     fatal ("Filename missing after -pcp option");
   pcp_fname = argv[++i];
   pcp_outfile =
     ((pcp_fname[0] != '-' || pcp_fname[1] != '\0')
      ? fopen (pcp_fname, "w")
      : 
       (__acrt_iob_func(1))
             );
   if (pcp_outfile == 0)
     pfatal_with_name (pcp_fname);
   no_precomp = 1;
 }
 break;

      case 't':
 if (!strcmp (argv[i], "-traditional")) {
   traditional = 1;
   cplusplus_comments = 0;
   if (dollars_in_ident > 0)
     dollars_in_ident = 1;
 } else if (!strcmp (argv[i], "-trigraphs")) {
   no_trigraphs = 0;
 }
 break;

      case 'l':
 if (! strcmp (argv[i], "-lang-c"))
   cplusplus = 0, cplusplus_comments = 1, objc = 0;
 if (! strcmp (argv[i], "-lang-c89"))
   cplusplus = 0, cplusplus_comments = 0, objc = 0;
 if (! strcmp (argv[i], "-lang-c++"))
   cplusplus = 1, cplusplus_comments = 1, objc = 0;
 if (! strcmp (argv[i], "-lang-objc"))
   objc = 1, cplusplus = 0, cplusplus_comments = 1;
 if (! strcmp (argv[i], "-lang-objc++"))
   objc = 1, cplusplus = 1, cplusplus_comments = 1;
  if (! strcmp (argv[i], "-lang-asm"))
    lang_asm = 1;
  if (! strcmp (argv[i], "-lint"))
    for_lint = 1;
 break;

      case '+':
 cplusplus = 1, cplusplus_comments = 1;
 break;

      case 'w':
 inhibit_warnings = 1;
 break;

      case 'W':
 if (!strcmp (argv[i], "-Wtrigraphs"))
   warn_trigraphs = 1;
 else if (!strcmp (argv[i], "-Wno-trigraphs"))
   warn_trigraphs = 0;
 else if (!strcmp (argv[i], "-Wcomment"))
   warn_comments = 1;
 else if (!strcmp (argv[i], "-Wno-comment"))
   warn_comments = 0;
 else if (!strcmp (argv[i], "-Wcomments"))
   warn_comments = 1;
 else if (!strcmp (argv[i], "-Wno-comments"))
   warn_comments = 0;
 else if (!strcmp (argv[i], "-Wtraditional"))
   warn_stringify = 1;
 else if (!strcmp (argv[i], "-Wno-traditional"))
   warn_stringify = 0;
 else if (!strcmp (argv[i], "-Wimport"))
   warn_import = 1;
 else if (!strcmp (argv[i], "-Wno-import"))
   warn_import = 0;
 else if (!strcmp (argv[i], "-Werror"))
   warnings_are_errors = 1;
 else if (!strcmp (argv[i], "-Wno-error"))
   warnings_are_errors = 0;
 else if (!strcmp (argv[i], "-Wall"))
   {
     warn_trigraphs = 1;
     warn_comments = 1;
   }
 break;

      case 'M':
 if (!strcmp (argv[i], "-MG"))
   {
     print_deps_missing_files = 1;
     break;
   }
 if (!strcmp (argv[i], "-M"))
   print_deps = 2;
 else if (!strcmp (argv[i], "-MM"))
   print_deps = 1;
 else if (!strcmp (argv[i], "-MD"))
   print_deps = 2;
 else if (!strcmp (argv[i], "-MMD"))
   print_deps = 1;

 if (!strcmp (argv[i], "-MD")
     || !strcmp (argv[i], "-MMD")) {
   if (i + 1 == argc)
     fatal ("Filename missing after %s option", argv[i]);
   i++;
   deps_file = argv[i];
   deps_mode = "w";
 } else {


   deps_stream = 
                (__acrt_iob_func(1))
                      ;
   inhibit_output = 1;
 }
 break;

      case 'd':
 {
   char *p = argv[i] + 2;
   char c;
   while ((c = *p++)) {

     switch (c) {
     case 'M':
       dump_macros = dump_only;
       no_output = 1;
       break;
     case 'N':
       dump_macros = dump_names;
       break;
     case 'D':
       dump_macros = dump_definitions;
       break;
     }
   }
 }
 break;

      case 'g':
 if (argv[i][2] == '3')
   debug_output = 1;
 break;

      case 'v':
 fprintf (
         (__acrt_iob_func(2))
               , "GNU CPP version %s", version_string);

 fprintf (
(__acrt_iob_func(2))
, " (MIPS GNU/ELF)");;

 fprintf (
         (__acrt_iob_func(2))
               , "\n");
 verbose = 1;
 break;

      case 'H':
 print_include_names = 1;
 break;

      case 'D':
 if (argv[i][2] != 0)
   pend_defs[i] = argv[i] + 2;
 else if (i + 1 == argc)
   fatal ("Macro name missing after -D option");
 else
   i++, pend_defs[i] = argv[i];
 break;

      case 'A':
 {
   char *p;

   if (argv[i][2] != 0)
     p = argv[i] + 2;
   else if (i + 1 == argc)
     fatal ("Assertion missing after -A option");
   else
     p = argv[++i];

   if (!strcmp (p, "-")) {




     int j;
     inhibit_predefs = 1;
     for (j = 0; j < i; j++)
       pend_defs[j] = pend_assertions[j] = 0;
   } else {
     pend_assertions[i] = p;
     pend_assertion_options[i] = "-A";
   }
 }
 break;

      case 'U':
 if (argv[i][2] != 0)
   pend_undefs[i] = argv[i] + 2;
 else if (i + 1 == argc)
   fatal ("Macro name missing after -U option");
 else
   pend_undefs[i] = argv[i+1], i++;
 break;

      case 'C':
 put_out_comments = 1;
 break;

      case 'E':
 break;

      case 'P':
 no_line_directives = 1;
 break;

      case '$':
 dollars_in_ident = 0;
 break;

      case 'I':
 {
   struct n64_tag_file_name_list *dirtmp;

   if (! ignore_srcdir && !strcmp (argv[i] + 2, "-")) {
     ignore_srcdir = 1;

     first_bracket_include = 0;
   }
   else {
     dirtmp = (struct n64_tag_file_name_list *)
       xmalloc (sizeof (struct n64_tag_file_name_list));
     dirtmp->next = 0;
     dirtmp->control_macro = 0;
     dirtmp->c_system_include_path = 0;
     if (argv[i][2] != 0)
       dirtmp->fname = argv[i] + 2;
     else if (i + 1 == argc)
       fatal ("Directory name missing after -I option");
     else
       dirtmp->fname = argv[++i];
     dirtmp->got_name_map = 0;
     append_include_chain (dirtmp, dirtmp);
   }
 }
 break;

      case 'n':
 if (!strcmp (argv[i], "-nostdinc"))


   no_standard_includes = 1;
 else if (!strcmp (argv[i], "-nostdinc++"))

   no_standard_cplusplus_includes = 1;
 else if (!strcmp (argv[i], "-noprecomp"))
   no_precomp = 1;
 break;

      case 'u':


 inhibit_predefs = 1;
 break;

      case '\0':
 if (in_fname == 
                ((void *)0)
                    ) {
   in_fname = "";
   break;
 } else if (out_fname == 
                        ((void *)0)
                            ) {
   out_fname = "";
   break;
 }

      default:
 fatal ("Invalid option `%s'", argv[i]);
      }
    }
  }







  cp = getenv ("CPATH");
  if (cp && ! no_standard_includes)
    path_include (cp);


  initialize_char_syntax ();



  outbuf.buf = (U_CHAR *) xmalloc (10);
  outbuf.bufp = outbuf.buf;
  outbuf.length = 10;




  fp = &instack[++indepth];
  if (in_fname == 
                 ((void *)0)
                     )
    in_fname = "";
  fp->nominal_fname = fp->fname = in_fname;
  fp->lineno = 0;



  if (cplusplus)
    wchar_type = "__wchar_t";



  initialize_builtins (fp, &outbuf);




  if (!inhibit_predefs) {
    char *p = (char *) 
                      __builtin_alloca((
                      strlen (predefs) + 1
                      ))
                                                   ;
    strcpy (p, predefs);
    while (*p) {
      char *q;
      while (*p == ' ' || *p == '\t')
 p++;

      if (p[0] == '-' && p[1] == 'D') {
 q = &p[2];
 while (*p && *p != ' ' && *p != '\t')
   p++;
 if (*p != 0)
   *p++= 0;
 if (debug_output)
   output_line_directive (fp, &outbuf, 0, same_file);
 make_definition (q, &outbuf);
 while (*p == ' ' || *p == '\t')
   p++;
      } else if (p[0] == '-' && p[1] == 'A') {

 char *assertion;
 char *past_name;
 char *value;
 char *past_value;
 char *termination;
 int save_char;

 assertion = &p[2];
 past_name = assertion;

 while (*past_name && *past_name != ' '
        && *past_name != '\t' && *past_name != '(')
   past_name++;

 value = past_name;
 while (*value && (*value == ' ' || *value == '\t'))
   value++;
 if (*value++ != '(')
   abort ();
 while (*value && (*value == ' ' || *value == '\t'))
   value++;
 past_value = value;

 while (*past_value && *past_value != ' '
        && *past_value != '\t' && *past_value != ')')
   past_value++;
 termination = past_value;
 while (*termination && (*termination == ' ' || *termination == '\t'))
   termination++;
 if (*termination++ != ')')
   abort ();
 if (*termination && *termination != ' ' && *termination != '\t')
   abort ();

 save_char = *termination;
 *termination = '\0';

 make_assertion ("-A", assertion);
 *termination = (char) save_char;
 p = termination;
 while (*p == ' ' || *p == '\t')
   p++;
      } else {
 abort ();
      }
    }
  }




  for (i = 1; i < argc; i++) {
    if (pend_undefs[i]) {
      if (debug_output)
        output_line_directive (fp, &outbuf, 0, same_file);
      make_undef (pend_undefs[i], &outbuf);
    }
    if (pend_defs[i]) {
      if (debug_output)
        output_line_directive (fp, &outbuf, 0, same_file);
      make_definition (pend_defs[i], &outbuf);
    }
    if (pend_assertions[i])
      make_assertion (pend_assertion_options[i], pend_assertions[i]);
  }

  done_initializing = 1;

  {

    char *epath = 0;
    switch ((objc << 1) + cplusplus)
      {
      case 0:
 epath = getenv ("C_INCLUDE_PATH");
 break;
      case 1:
 epath = getenv ("CPLUS_INCLUDE_PATH");
 break;
      case 2:
 epath = getenv ("OBJC_INCLUDE_PATH");
 break;
      case 3:
 epath = getenv ("OBJCPLUS_INCLUDE_PATH");
 break;
      }


    if (epath) {
      char *nstore = (char *) 
                             __builtin_alloca((
                             strlen (epath) + 2
                             ))
                                                        ;
      int num_dirs;
      char *startp, *endp;

      for (num_dirs = 1, startp = epath; *startp; startp++)
 if (*startp == ';')
   num_dirs++;
      include_defaults
 = (struct n64_tag_default_include *) xmalloc ((num_dirs
            * sizeof (struct n64_tag_default_include))
           + sizeof (include_defaults_array));
      startp = endp = epath;
      num_dirs = 0;
      while (1) {

        if ((*endp == ';'





      )
            || *endp == 0) {
   strncpy (nstore, startp, endp-startp);
   if (endp == startp)
     strcpy (nstore, ".");
   else
     nstore[endp-startp] = '\0';

   include_defaults[num_dirs].fname = savestring (nstore);
   include_defaults[num_dirs].cplusplus = cplusplus;
   include_defaults[num_dirs].cxx_aware = 1;
   num_dirs++;
   if (*endp == '\0')
     break;
   endp = startp = endp + 1;
 } else
   endp++;
      }

      memcpy ((char *) &include_defaults[num_dirs],(char *) include_defaults_array,sizeof (include_defaults_array))

                                      ;
    }
  }

  append_include_chain (before_system, last_before_system);
  first_system_include = before_system;



  if (!no_standard_includes) {
    struct n64_tag_default_include *p = include_defaults;
    char *specd_prefix = include_prefix;
    char *default_prefix = savestring ("/opt/cross/lib/gcc-lib/mips-mips-gnu/2.7.2/include");
    int default_len = 0;

    if (!strcmp (default_prefix + strlen (default_prefix) - 8, "/include")) {
      default_len = strlen (default_prefix) - 7;
      default_prefix[default_len] = 0;
    }


    if (specd_prefix != 0 && default_len != 0)
      for (p = include_defaults; p->fname; p++) {

 if (!p->cplusplus || (cplusplus && !no_standard_cplusplus_includes)) {

   if (!strncmp (p->fname, default_prefix, default_len)) {

     struct n64_tag_file_name_list *cxx_new
       = (struct n64_tag_file_name_list *) xmalloc (sizeof (struct n64_tag_file_name_list));
     int this_len = strlen (specd_prefix) + strlen (p->fname) - default_len;
     char *str = xmalloc (this_len + 1);
     strcpy (str, specd_prefix);
     strcat (str, p->fname + default_len);
     cxx_new->fname = str;
     cxx_new->control_macro = 0;
     cxx_new->c_system_include_path = !p->cxx_aware;
     cxx_new->got_name_map = 0;
     append_include_chain (cxx_new, cxx_new);
     if (first_system_include == 0)
       first_system_include = cxx_new;
   }
 }
      }

    for (p = include_defaults; p->fname; p++) {

      if (!p->cplusplus || (cplusplus && !no_standard_cplusplus_includes)) {
 struct n64_tag_file_name_list *cxx_new
   = (struct n64_tag_file_name_list *) xmalloc (sizeof (struct n64_tag_file_name_list));
 cxx_new->control_macro = 0;
 cxx_new->c_system_include_path = !p->cxx_aware;
 cxx_new->fname = p->fname;
 cxx_new->got_name_map = 0;
 append_include_chain (cxx_new, cxx_new);
 if (first_system_include == 0)
   first_system_include = cxx_new;
      }
    }
  }


  append_include_chain (after_include, last_after_include);
  if (first_system_include == 0)
    first_system_include = after_include;


  if (verbose) {
    struct n64_tag_file_name_list *p;
    fprintf (
            (__acrt_iob_func(2))
                  , "#include \"...\" search starts here:\n");
    for (p = include; p; p = p->next) {
      if (p == first_bracket_include)
 fprintf (
         (__acrt_iob_func(2))
               , "#include <...> search starts here:\n");
      fprintf (
              (__acrt_iob_func(2))
                    , " %s\n", p->fname);
    }
    fprintf (
            (__acrt_iob_func(2))
                  , "End of search list.\n");
  }





  no_output++; no_record_file++;
  for (i = 1; i < argc; i++)
    if (pend_files[i]) {
      int fd = open (pend_files[i], 
                                   0x0000
                                           , 0666);
      if (fd < 0) {
 perror_with_name (pend_files[i]);
 return 33;
      }
      finclude (fd, pend_files[i], &outbuf, 0, ((void *)0));
    }
  no_output--; no_record_file--;





  if (in_fname == 
                 ((void *)0) 
                      || *in_fname == 0) {
    in_fname = "";
    f = 0;
  } else if ((f = open (in_fname, 
                                 0x0000
                                         , 0666)) < 0)
    goto perror;




  if (print_deps_missing_files && (print_deps == 0 || !inhibit_output))
    fatal ("-MG must be specified with one of -M or -MM");






  if (print_deps == 0
      && (getenv ("SUNPRO_DEPENDENCIES") != 0
   || getenv ("DEPENDENCIES_OUTPUT") != 0)) {
    char *spec = getenv ("DEPENDENCIES_OUTPUT");
    char *s;
    char *output_file;

    if (spec == 0) {
      spec = getenv ("SUNPRO_DEPENDENCIES");
      print_deps = 2;
    }
    else
      print_deps = 1;

    s = spec;


    while (*s != 0 && *s != ' ') s++;
    if (*s != 0) {
      deps_target = s + 1;
      output_file = xmalloc (s - spec + 1);
      memcpy (output_file,spec,s - spec);
      output_file[s - spec] = 0;
    }
    else {
      deps_target = 0;
      output_file = spec;
    }

    deps_file = output_file;
    deps_mode = "a";
  }



  if (print_deps) {
    deps_allocated_size = 200;
    deps_buffer = xmalloc (deps_allocated_size);
    deps_buffer[0] = 0;
    deps_size = 0;
    deps_column = 0;

    if (deps_target) {
      deps_output (deps_target, ':');
    } else if (*in_fname == 0) {
      deps_output ("-", ':');
    } else {
      char *p, *q;
      int len;


      if ((q = strrchr (in_fname, '/')) != 
                                         ((void *)0)

   
  && (q = strrchr (in_fname, '\\')) != 
                                               ((void *)0)

   
  )
 ++q;
      else
 q = in_fname;


      p = (char *) 
                  __builtin_alloca((
                  strlen(q) + 8
                  ))
                                        ;
      strcpy (p, q);


      len = strlen (p);
      q = p + len;
      if (len >= 2
   && p[len - 2] == '.'
   && strchr("cCsSm", p[len - 1]))
 q = p + (len - 2);
      else if (len >= 3
        && p[len - 3] == '.'
        && p[len - 2] == 'c'
        && p[len - 1] == 'c')
 q = p + (len - 3);
      else if (len >= 4
        && p[len - 4] == '.'
        && p[len - 3] == 'c'
        && p[len - 2] == 'x'
        && p[len - 1] == 'x')
 q = p + (len - 4);
      else if (len >= 4
        && p[len - 4] == '.'
        && p[len - 3] == 'c'
        && p[len - 2] == 'p'
        && p[len - 1] == 'p')
 q = p + (len - 4);



      strcpy (q, ".o");




      deps_output (p, ':');
      deps_output (in_fname, ' ');
    }
  }

  file_size_and_mode (f, &st_mode, &st_size);
  fp->nominal_fname = fp->fname = in_fname;
  fp->lineno = 1;
  fp->system_header_p = 0;

  if (! 
       (((
       st_mode
       ) & 0xF000) == 0x8000)
                        ) {



    int size;
    int bsize;
    int cnt;

    bsize = 2000;
    size = 0;
    fp->buf = (U_CHAR *) xmalloc (bsize + 2);
    for (;;) {
      cnt = safe_read (f, (char *) fp->buf + size, bsize - size);
      if (cnt < 0) goto perror;
      size += cnt;
      if (size != bsize) break;
      bsize *= 2;
      fp->buf = (U_CHAR *) xrealloc (fp->buf, bsize + 2);
    }
    fp->length = size;
  } else {


    fp->buf = (U_CHAR *) xmalloc (st_size + 2);
    fp->length = safe_read (f, (char *) fp->buf, st_size);
    if (fp->length < 0) goto perror;
  }
  fp->bufp = fp->buf;
  fp->if_stack = if_stack;



  if ((fp->length > 0 && fp->buf[fp->length - 1] != '\n')

      || (fp->length > 1 && fp->buf[fp->length - 2] == '\\')) {
    fp->buf[fp->length++] = '\n';
    missing_newline = 1;
  }
  fp->buf[fp->length] = '\0';



  if (!no_trigraphs)
    trigraph_pcp (fp);



  if (!out_fname || !strcmp (out_fname, ""))
    out_fname = "stdout";
  else if (! freopen (out_fname, "w", 
                                     (__acrt_iob_func(1))
                                           ))
    pfatal_with_name (out_fname);

  output_line_directive (fp, &outbuf, 0, same_file);



  no_record_file++;
  for (i = 1; i < argc; i++)
    if (pend_includes[i]) {
      int fd = open (pend_includes[i], 
                                      0x0000
                                              , 0666);
      if (fd < 0) {
 perror_with_name (pend_includes[i]);
 return 33;
      }
      finclude (fd, pend_includes[i], &outbuf, 0, ((void *)0));
    }
  no_record_file--;



  rescan (&outbuf, 0);

  if (missing_newline)
    fp->lineno--;

  if (pedantic && missing_newline)
    pedwarn ("file does not end in newline");




  if (dump_macros == dump_only)
    dump_all_macros ();
  else if (! inhibit_output) {
    write_output ();
  }

  if (print_deps) {

    if (errors == 0) {
      if (deps_file && ! (deps_stream = fopen (deps_file, deps_mode)))
 pfatal_with_name (deps_file);
      fputs (deps_buffer, deps_stream);
      putc ('\n', deps_stream);
      if (deps_file) {
 if (ferror (deps_stream) || fclose (deps_stream) != 0)
   fatal ("I/O error on output");
      }
    }
  }

  if (pcp_outfile && pcp_outfile != 
                                   (__acrt_iob_func(1))
      
     && (ferror (pcp_outfile) || fclose (pcp_outfile) != 0))
    fatal ("I/O error on `-pcp' output");

  if (ferror (
             (__acrt_iob_func(1))
                   ) || fclose (
                                (__acrt_iob_func(1))
                                      ) != 0)
    fatal ("I/O error on output");

  if (errors)
    exit (33);
  exit (0);

 perror:
  pfatal_with_name (in_fname);
  return 0;
}




static void
path_include(char *path) asm("_path_include");
static void
path_include(char *path)
{
  char *p;

  p = path;

  if (*p)
    while (1) {
      char *q = p;
      char *name;
      struct n64_tag_file_name_list *dirtmp;


      while (*q != 0 && *q != ';') q++;
      if (p == q) {

 name = xmalloc (2);
 name[0] = '.';
 name[1] = 0;
      } else {

 name = xmalloc (q - p + 1);
 memcpy (name,p,q - p);
 name[q - p] = 0;
      }

      dirtmp = (struct n64_tag_file_name_list *)
 xmalloc (sizeof (struct n64_tag_file_name_list));
      dirtmp->next = 0;
      dirtmp->control_macro = 0;
      dirtmp->c_system_include_path = 0;
      dirtmp->fname = name;
      dirtmp->got_name_map = 0;
      append_include_chain (dirtmp, dirtmp);


      p = q;
      if (*p == 0)
 break;

      p++;
    }
}







static U_CHAR *
index0(U_CHAR *s, int c, size_t n) asm("_index0");
static U_CHAR *
index0(U_CHAR *s, int c, size_t n)
{
  char *p = (char *) s;
  for (;;) {
    char *q = strchr (p, c);
    if (q)
      return (U_CHAR *) q;
    else {
      size_t l = strlen (p);
      if (l == n)
 return 0;
      l++;
      p += l;
      n -= l;
    }
  }
}
static void
trigraph_pcp(FILE_BUF *buf) asm("_trigraph_pcp");
static void
trigraph_pcp(FILE_BUF *buf)
{
  register U_CHAR c, *fptr, *bptr, *sptr, *lptr;
  int len;

  fptr = bptr = sptr = buf->buf;
  lptr = fptr + buf->length;
  while ((sptr = index0 (sptr, '?', (size_t) (lptr - sptr))) != 
                                                               ((void *)0)
                                                                   ) {
    if (*++sptr != '?')
      continue;
    switch (*++sptr) {
      case '=':
      c = '#';
      break;
    case '(':
      c = '[';
      break;
    case '/':
      c = '\\';
      break;
    case ')':
      c = ']';
      break;
    case '\'':
      c = '^';
      break;
    case '<':
      c = '{';
      break;
    case '!':
      c = '|';
      break;
    case '>':
      c = '}';
      break;
    case '-':
      c = '~';
      break;
    case '?':
      sptr--;
      continue;
    default:
      continue;
    }
    len = sptr - fptr - 2;



    if (bptr != fptr && len > 0)
      memcpy ((char *) bptr,(char *) fptr,len);

    bptr += len;
    *bptr++ = c;
    fptr = ++sptr;
  }
  len = buf->length - (fptr - buf->buf);
  if (bptr != fptr && len > 0)
    memcpy ((char *) bptr,(char *) fptr,len);
  buf->length -= fptr - bptr;
  buf->buf[buf->length] = '\0';
  if (warn_trigraphs && fptr != bptr)
    warning_with_line (0, "%d trigraph(s) encountered", (fptr - bptr) / 2);
}
static void
newline_fix(U_CHAR *bp) asm("_newline_fix");
static void
newline_fix(U_CHAR *bp)
{
  register U_CHAR *p = bp;



  while (p[0] == '\\' && p[1] == '\n')
    p += 2;



  if (*p != '/' && *p != '*')
    return;





  while (*p == '*' || *p == '/')
    *bp++ = *p++;


  while (bp < p) {
    *bp++ = '\\';
    *bp++ = '\n';
  }
}




static void
name_newline_fix(U_CHAR *bp) asm("_name_newline_fix");
static void
name_newline_fix(U_CHAR *bp)
{
  register U_CHAR *p = bp;


  while (p[0] == '\\' && p[1] == '\n')
    p += 2;



  if (!is_idchar[*p])
    return;





  while (is_idchar[*p])
    *bp++ = *p++;


  while (bp < p) {
    *bp++ = '\\';
    *bp++ = '\n';
  }
}
static char *
get_lintcmd(register U_CHAR *ibp, register U_CHAR *limit, U_CHAR **argstart, int *arglen, int *cmdlen) asm("_get_lintcmd");
static char *
get_lintcmd(register U_CHAR *ibp, register U_CHAR *limit, U_CHAR **argstart, int *arglen, int *cmdlen)
{
  long linsize;
  register U_CHAR *numptr;

  *arglen = 0;

  do { while (is_hor_space[*ibp]) ibp++; } while (0);

  if (ibp >= limit) return 
                          ((void *)0)
                              ;

  linsize = limit - ibp;


  if ((linsize >= 10) && !memcmp (ibp,"NOTREACHED",10)) {
    *cmdlen = 10;
    return "NOTREACHED";
  }
  if ((linsize >= 8) && !memcmp (ibp,"ARGSUSED",8)) {
    *cmdlen = 8;
    return "ARGSUSED";
  }
  if ((linsize >= 11) && !memcmp (ibp,"LINTLIBRARY",11)) {
    *cmdlen = 11;
    return "LINTLIBRARY";
  }
  if ((linsize >= 7) && !memcmp (ibp,"VARARGS",7)) {
    *cmdlen = 7;
    ibp += 7; linsize -= 7;
    if ((linsize == 0) || ! isdigit (*ibp)) return "VARARGS";


    for (numptr = *argstart = ibp; (numptr < limit) && isdigit (*numptr);
  numptr++);
    *arglen = numptr - *argstart;
    return "VARARGS";
  }
  return 
        ((void *)0)
            ;
}
static void
rescan(FILE_BUF *op, int output_marks) asm("_rescan");
static void
rescan(FILE_BUF *op, int output_marks)
{

  register U_CHAR c;


  register int ident_length = 0;


  register int hash = 0;


  FILE_BUF *ip;


  register U_CHAR *ibp;


  register U_CHAR *limit;


  register U_CHAR *obp;







  int redo_char = 0;



  int concatenated = 0;



  int start_line;


  U_CHAR *beg_of_line;
  if (no_output && instack[indepth].fname != 0)
    skip_if_group (&instack[indepth], 1, 
                                        ((void *)0)
                                            );

  obp = op->bufp;
  do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);

  beg_of_line = ibp;



  if (*limit != 0)
    abort ();

  while (1) {
    c = *ibp++;
    *obp++ = c;

    switch (c) {
    case '\\':
      if (*ibp == '\n' && !ip->macro) {



 ++ibp;
 ++ip->lineno;
 --obp;
 break;
      }

      if (!traditional)
 goto randomchar;



      if (ident_length > 0)
 goto specialchar;
      if (ibp < limit)
 *obp++ = *ibp++;
      break;

    case '%':
      if (ident_length || ip->macro || traditional)
 goto randomchar;
      while (*ibp == '\\' && ibp[1] == '\n') {
 ibp += 2;
 ++ip->lineno;
      }
      if (*ibp != ':')
 break;



    case '#':
      if (assertions_flag) {
 if (ident_length)
   goto specialchar;

 obp[-1] = '#';
 do { while (is_hor_space[*ibp]) ibp++; } while (0);
 while (is_idchar[*ibp])
   *obp++ = *ibp++;
 do { while (is_hor_space[*ibp]) ibp++; } while (0);
 if (*ibp == '(') {
   ip->bufp = ibp;
   skip_paren_group (ip);
   memcpy ((char *) obp,(char *) ibp,ip->bufp - ibp);
   obp += ip->bufp - ibp;
   ibp = ip->bufp;
 }
 break;
      }



      if (ip->macro != 0)
 goto randomchar;




      if (! ip->fname) {
 if (ip->buf != beg_of_line)
   warning ("preprocessing directive not recognized within macro arg");
 goto randomchar;
      }
      if (ident_length)
 goto specialchar;



      if (beg_of_line == 0)
 goto randomchar;
      {
 U_CHAR *bp;




 bp = beg_of_line;

 if (!traditional) {
   while (1) {
     if (is_hor_space[*bp])
       bp++;
     else if (*bp == '\\' && bp[1] == '\n')
       bp += 2;
     else if (*bp == '/' && bp[1] == '*') {
       bp += 2;
       while (!(*bp == '*' && bp[1] == '/'))
  bp++;
       bp += 2;
     }



     else break;
   }
   if (c == '%') {
     if (bp[0] != '%')
       break;
     while (bp[1] == '\\' && bp[2] == '\n')
       bp += 2;
     if (bp + 1 != ibp)
       break;

     bp++;
     ibp++;
   }
 }
 if (bp + 1 != ibp)
   goto randomchar;
      }



      --obp;

      ip->bufp = ibp;
      op->bufp = obp;
      if (! handle_directive (ip, op)) {





 if (no_output && instack[indepth].fname) {



   skip_if_group (&instack[indepth], 1, 0);
   do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
   beg_of_line = ibp;
   break;
 }
 *obp++ = '#';


 do { while (is_hor_space[*ibp]) ibp++; } while (0);
 if (is_idstart[*ibp])
   {
     *obp++ = *ibp++;
     while (is_idchar[*ibp])
       *obp++ = *ibp++;
   }
 goto randomchar;
      }






      if (no_output && instack[indepth].fname)
 skip_if_group (&instack[indepth], 1, 0);
      obp = op->bufp;
      do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
      beg_of_line = ibp;
      break;

    case '\"':
    case '\'':



      if (ident_length)
 goto specialchar;

      start_line = ip->lineno;



      while (1) {
 if (ibp >= limit) {
   if (ip->macro != 0) {



     do { ip->macro->type = T_MACRO; if (ip->free_ptr) free (ip->free_ptr); --indepth; } while (0);
     do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
     continue;
   }
   if (!traditional) {
     error_with_line (line_for_error (start_line),
        "unterminated string or character constant");
     error_with_line (multiline_string_line,
        "possible real start of unterminated constant");
     multiline_string_line = 0;
   }
   break;
 }
 *obp++ = *ibp;
 switch (*ibp++) {
 case '\n':
   ++ip->lineno;
   ++op->lineno;


   if (traditional) {
     beg_of_line = ibp;
     goto while2end;
   }
   if (c == '\'') {
     error_with_line (line_for_error (start_line),
        "unterminated character constant");
     goto while2end;
   }
   if (pedantic && multiline_string_line == 0) {
     pedwarn_with_line (line_for_error (start_line),
          "string constant runs past end of line");
   }
   if (multiline_string_line == 0)
     multiline_string_line = ip->lineno - 1;
   break;

 case '\\':
   if (ibp >= limit)
     break;
   if (*ibp == '\n') {


     --obp;
     ++ibp;
     ++ip->lineno;
   } else {


     while (*ibp == '\\' && ibp[1] == '\n') {
       ibp += 2;
       ++ip->lineno;
     }
     *obp++ = *ibp++;
   }
   break;

 case '\"':
 case '\'':
   if (ibp[-1] == c)
     goto while2end;
   break;
 }
      }
    while2end:
      break;

    case '/':
      if (*ibp == '\\' && ibp[1] == '\n')
 newline_fix (ibp);

      if (*ibp != '*'
   && !(cplusplus_comments && *ibp == '/'))
 goto randomchar;
      if (ip->macro != 0)
 goto randomchar;
      if (ident_length)
 goto specialchar;

      if (*ibp == '/') {

 start_line = ip->lineno;


 if (! put_out_comments)
   obp[-1] = ' ';

 {
   U_CHAR *before_bp = ibp;

   while (++ibp < limit) {
     if (*ibp == '\n') {
       if (ibp[-1] != '\\') {
  if (put_out_comments) {
    memcpy ((char *) obp,(char *) before_bp,ibp - before_bp);
    obp += ibp - before_bp;
  }
  break;
       }
       ++ip->lineno;



       if (!put_out_comments)
  *obp++ = '\n';
       ++op->lineno;
     }
   }
   break;
 }
      }



      start_line = ip->lineno;

      ++ibp;


      if (for_lint) {
 U_CHAR *argbp;
 int cmdlen, arglen;
 char *lintcmd = get_lintcmd (ibp, limit, &argbp, &arglen, &cmdlen);

 if (lintcmd != 
               ((void *)0)
                   ) {
   op->bufp = obp;
   (((op)->length - ((op)->bufp - (op)->buf) <= (cmdlen + arglen + 14)) ? grow_outbuf ((op), (cmdlen + arglen + 14)) : 0);
   obp = op->bufp;

   obp[-1] = '\n';
   memcpy ((char *) obp,"#pragma lint ",13);
   obp += 13;
   memcpy ((char *) obp,lintcmd,cmdlen);
   obp += cmdlen;

   if (arglen != 0) {
     *(obp++) = ' ';
     memcpy ((char *) obp,argbp,arglen);
     obp += arglen;
   }




   op->bufp = obp;
   output_line_directive (ip, op, 0, same_file);
   (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp + 2)) ? grow_outbuf ((op), (limit - ibp + 2)) : 0);
   obp = op->bufp;
   *(obp++) = '/';
 }
      }




      if (! put_out_comments) {
 if (traditional)
   obp--;
 else
   obp[-1] = ' ';
      }
      else
 *obp++ = '*';

      {
 U_CHAR *before_bp = ibp;

 while (ibp < limit) {
   switch (*ibp++) {
   case '/':
     if (warn_comments && *ibp == '*')
       warning ("`/*' within comment");
     break;
   case '*':
     if (*ibp == '\\' && ibp[1] == '\n')
       newline_fix (ibp);
     if (ibp >= limit || *ibp == '/')
       goto comment_end;
     break;
   case '\n':
     ++ip->lineno;



     if (!put_out_comments)
       *obp++ = '\n';
     ++op->lineno;
   }
 }
      comment_end:

 if (ibp >= limit)
   error_with_line (line_for_error (start_line),
      "unterminated comment");
 else {
   ibp++;
   if (put_out_comments) {
     memcpy ((char *) obp,(char *) before_bp,ibp - before_bp);
     obp += ibp - before_bp;
   }
 }
      }
      break;

    case '$':
      if (!dollars_in_ident)
 goto randomchar;
      goto letter;

    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':






      if (ident_length == 0) {
 for (;;) {
   while (ibp[0] == '\\' && ibp[1] == '\n') {
     ++ip->lineno;
     ibp += 2;
   }
   c = *ibp++;
   if (!is_idchar[c] && c != '.') {
     --ibp;
     break;
   }
   *obp++ = c;


   if (c == 'e' || c == 'E') {
     while (ibp[0] == '\\' && ibp[1] == '\n') {
       ++ip->lineno;
       ibp += 2;
     }
     if (*ibp == '+' || *ibp == '-') {
       *obp++ = *ibp++;

       if (traditional)
  break;
     }
   }
 }
 break;
      }


    case '_':
    case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
    case 'g': case 'h': case 'i': case 'j': case 'k': case 'l':
    case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
    case 's': case 't': case 'u': case 'v': case 'w': case 'x':
    case 'y': case 'z':
    case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
    case 'G': case 'H': case 'I': case 'J': case 'K': case 'L':
    case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R':
    case 'S': case 'T': case 'U': case 'V': case 'W': case 'X':
    case 'Y': case 'Z':
    letter:
      ident_length++;

      hash = ((hash << 2) + c);
      break;

    case '\n':
      if (ip->fname == 0 && *ibp == '-') {




 if (! concatenated) {
   ident_length = 0;
   hash = 0;
 }
 ibp++;
 if (!output_marks) {
   obp--;
 } else {

   *obp++ = '-';
 }
 break;
      }


      else if (ip->macro != 0) {






 if (is_space[*ibp]) {


   if (ident_length > 0)
     goto specialchar;


   if (!output_marks) {
     obp[-1] = *ibp++;

     if (obp[-1] == '\n')
       op->lineno++;
   } else {


     *obp++ = *ibp++;
   }
 } else abort ();
 break;
      }


      if (ident_length > 0)
 goto specialchar;

      beg_of_line = ibp;


      ++ip->lineno;
      ++op->lineno;
      if (ip->lineno != op->lineno) {
 op->bufp = obp;
 output_line_directive (ip, op, 1, same_file);
 (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0);
 obp = op->bufp;
      }
      break;



    case 0:
      if (ibp <= limit)

 goto randomchar;


      if (ip->macro != 0) {
 obp--;
 ibp--;


 if (traditional && ident_length
     && ! is_idchar[*instack[indepth - 1].bufp]) {
   redo_char = 1;
   goto randomchar;
 }
 do { ip->macro->type = T_MACRO; if (ip->free_ptr) free (ip->free_ptr); --indepth; } while (0);
 do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
 break;
      }



      if (ident_length == 0) {
 obp--;
 ibp--;
 op->bufp = obp;
 ip->bufp = ibp;
 goto ending;
      }







specialchar:






      ibp--;
      obp--;
      redo_char = 1;

    default:

randomchar:

      if (ident_length > 0) {
 register HASHNODE *hp;
 if (!pcp_outfile || pcp_inside_if) {
   for (hp = hashtab[(hash & 0x7fffffff) % 1403]; hp != 
                                                       ((void *)0)
                                                           ;
        hp = hp->next) {

     if (hp->length == ident_length) {
       int obufp_before_macroname;
       int op_lineno_before_macroname;
       register int i = ident_length;
       register U_CHAR *p = hp->name;
       register U_CHAR *q = obp - i;
       int disabled;

       if (! redo_char)
  q--;

       do {
  if (*p++ != *q++)
    goto hashcollision;
       } while (--i);





       if (! redo_char) {
  ibp--;
  obp--;
       }




       obufp_before_macroname = (obp - op->buf) - ident_length;
       op_lineno_before_macroname = op->lineno;

       if (hp->type == T_PCSTRING) {
  pcstring_used (hp);


  break;

       }


       disabled = hp->type == T_DISABLED;




       if (disabled) {
  if (output_marks) {
    (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp + 2)) ? grow_outbuf ((op), (limit - ibp + 2)) : 0);
    *obp++ = '\n';
    *obp++ = '-';
  }
  break;
       }





       if ((hp->type == T_MACRO || hp->type == T_DISABLED)
    && hp->value.defn->nargs >= 0)
  {
    U_CHAR *old_ibp = ibp;
    U_CHAR *old_obp = obp;
    int old_iln = ip->lineno;
    int old_oln = op->lineno;

    while (1) {

      if (ibp == limit && ip->macro != 0) {
        do { ip->macro->type = T_MACRO; if (ip->free_ptr) free (ip->free_ptr); --indepth; } while (0);
        do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
        old_ibp = ibp;
        old_obp = obp;
        old_iln = ip->lineno;
        old_oln = op->lineno;
      }

      else if (*ibp == '/' && ibp[1] == '*') {
        if (put_out_comments) {
   *obp++ = '/';
   *obp++ = '*';
        } else if (! traditional) {
   *obp++ = ' ';
        }
        ibp += 2;
        while (ibp + 1 != limit
        && !(ibp[0] == '*' && ibp[1] == '/')) {


   if (*ibp == '\n') {

     ++ip->lineno;
     ++op->lineno;
   }
   if (put_out_comments)
     *obp++ = *ibp++;
   else
     ibp++;
        }
        ibp += 2;
        if (put_out_comments) {
   *obp++ = '*';
   *obp++ = '/';
        }
      }
      else if (is_space[*ibp]) {
        *obp++ = *ibp++;
        if (ibp[-1] == '\n') {
   if (ip->macro == 0) {

     ++ip->lineno;
     ++op->lineno;
   } else if (!output_marks) {




     obp--;
     if (*ibp == '-')
       ibp++;
     else {
       if (*ibp == '\n')
         ++op->lineno;
       *obp++ = *ibp++;
     }
   } else {

     *obp++ = *ibp++;
   }
        }
      }
      else break;
    }
    if (*ibp != '(') {


      ibp = old_ibp;
      obp = old_obp;
      ip->lineno = old_iln;
      op->lineno = old_oln;

      break;
    }
  }






       obp = op->buf + obufp_before_macroname;
       if (output_marks)
  op->lineno = op_lineno_before_macroname;
       else {
  int newlines = op->lineno - op_lineno_before_macroname;
  while (0 < newlines--)
    *obp++ = '\n';
       }



       if (!traditional && obp != op->buf) {
  switch (obp[-1]) {
  case '!': case '%': case '&': case '*':
  case '+': case '-': case '/': case ':':
  case '<': case '=': case '>': case '^':
  case '|':



    if (output_marks)
      *obp++ = '\n';
    *obp++ = ' ';
  }
       }



       ip->bufp = ibp;
       op->bufp = obp;
       macroexpand (hp, op);



       obp = op->bufp;
       do { ip = &instack[indepth]; ibp = ip->bufp; limit = ip->buf + ip->length; op->bufp = obp; (((op)->length - ((op)->bufp - (op)->buf) <= (limit - ibp)) ? grow_outbuf ((op), (limit - ibp)) : 0); beg_of_line = 0; obp = op->bufp; } while (0);
       break;
     }
hashcollision:
     ;
   }
 }
 ident_length = hash = 0;
 redo_char = 0;
 concatenated = 0;
      }
    }
  }



 ending:
  if (if_stack != ip->if_stack)
    {
      char *str;

      switch (if_stack->type)
 {
 case T_IF:
   str = "if";
   break;
 case T_IFDEF:
   str = "ifdef";
   break;
 case T_IFNDEF:
   str = "ifndef";
   break;
 case T_ELSE:
   str = "else";
   break;
 case T_ELIF:
   str = "elif";
   break;
 default:
   abort ();
 }

      error_with_line (line_for_error (if_stack->lineno),
         "unterminated `#%s' conditional", str);
  }
  if_stack = ip->if_stack;
}
static FILE_BUF
expand_to_temp_buffer(U_CHAR *buf, U_CHAR *limit, int output_marks, int assertions) asm("_expand_to_temp_buffer");
static FILE_BUF
expand_to_temp_buffer(U_CHAR *buf, U_CHAR *limit, int output_marks, int assertions)
{
  register FILE_BUF *ip;
  FILE_BUF obuf;
  int length = limit - buf;
  U_CHAR *buf1;
  int odepth = indepth;
  int save_assertions_flag = assertions_flag;

  assertions_flag = assertions;

  if (length < 0)
    abort ();



  buf1 = (U_CHAR *) 
                   __builtin_alloca((
                   length + 1
                   ))
                                      ;
  {
    register U_CHAR *p1 = buf;
    register U_CHAR *p2 = buf1;

    while (p1 != limit)
      *p2++ = *p1++;
  }
  buf1[length] = 0;



  obuf.length = length * 2 + 100;
  obuf.bufp = obuf.buf = (U_CHAR *) xmalloc (obuf.length);
  obuf.fname = 0;
  obuf.macro = 0;
  obuf.free_ptr = 0;

  if (indepth >= (400 - 1)) { error_with_line (line_for_error (instack[indepth].lineno), "macro or `#include' recursion too deep"); {return obuf;}; };

  ++indepth;

  ip = &instack[indepth];
  ip->fname = 0;
  ip->nominal_fname = 0;
  ip->system_header_p = 0;
  ip->macro = 0;
  ip->free_ptr = 0;
  ip->length = length;
  ip->buf = ip->bufp = buf1;
  ip->if_stack = if_stack;

  ip->lineno = obuf.lineno = 1;


  rescan (&obuf, output_marks);


  --indepth;

  if (indepth != odepth)
    abort ();


  obuf.length = obuf.bufp - obuf.buf;

  assertions_flag = save_assertions_flag;
  return obuf;
}
static int
handle_directive(FILE_BUF *ip, FILE_BUF *op) asm("_handle_directive");
static int
handle_directive(FILE_BUF *ip, FILE_BUF *op)
{
  register U_CHAR *bp, *cp;
  register struct n64_tag_directive *kt;
  register int ident_length;
  U_CHAR *resume_p;



  int copy_directive = 0;

  U_CHAR *ident, *after_ident;

  bp = ip->bufp;


  directive_start = bp - 1;


  while (1) {
    if (is_hor_space[*bp]) {
      if (*bp != ' ' && *bp != '\t' && pedantic)
 pedwarn ("%s in preprocessing directive", char_name[*bp]);
      bp++;
    } else if (*bp == '/' && (bp[1] == '*'
         || (cplusplus_comments && bp[1] == '/'))) {
      ip->bufp = bp + 2;
      skip_to_end_of_comment (ip, &ip->lineno, 0);
      bp = ip->bufp;
    } else if (*bp == '\\' && bp[1] == '\n') {
      bp += 2; ip->lineno++;
    } else break;
  }





  cp = bp;
  while (1) {
    if (is_idchar[*cp])
      cp++;
    else {
      if (*cp == '\\' && cp[1] == '\n')
 name_newline_fix (cp);
      if (is_idchar[*cp])
 cp++;
      else break;
    }
  }
  ident_length = cp - bp;
  ident = bp;
  after_ident = cp;



  if (ident_length == 0 && *after_ident == '\n') {
    ip->bufp = after_ident;
    return 1;
  }

  if (ident_length == 0 || !is_idstart[*ident]) {
    U_CHAR *p = ident;
    while (is_idchar[*p]) {
      if (*p < '0' || *p > '9')
 break;
      p++;
    }

    if (p != ident && !is_idchar[*p]) {
      static struct n64_tag_directive line_directive_table[] = {
 { 4, do_line, "line", T_LINE},
      };
      if (pedantic)
 pedwarn ("`#' followed by integer");
      after_ident = ident;
      kt = line_directive_table;
      goto old_linenum;
    }


    if (p == ident) {
      while (*p == '#' || is_hor_space[*p]) p++;
      if (*p == '\n') {
 if (pedantic && !lang_asm)
   warning ("invalid preprocessing directive");
 return 0;
      }
    }

    if (!lang_asm)
      error ("invalid preprocessing directive name");

    return 0;
  }





  for (kt = directive_table; kt->length > 0; kt++) {
    if (kt->length == ident_length && !memcmp (kt->name,ident,ident_length)) {
      register U_CHAR *buf;
      register U_CHAR *limit;
      int unterminated;
      int junk;
      int *already_output;



      int keep_comments;

    old_linenum:

      limit = ip->buf + ip->length;
      unterminated = 0;
      already_output = 0;
      keep_comments = traditional && kt->traditional_comments;

      if (kt->type == T_IMPORT
   && !(objc || lookup ((U_CHAR *) "__NeXT__", -1, -1)))
 break;






      buf = bp = after_ident;
      while (bp < limit) {
 register U_CHAR c = *bp++;
 switch (c) {
 case '\\':
   if (bp < limit) {
     if (*bp == '\n') {
       ip->lineno++;
       copy_directive = 1;
       bp++;
     } else if (traditional)
       bp++;
   }
   break;

 case '\'':
 case '\"':
   bp = skip_quoted_string (bp - 1, limit, ip->lineno, &ip->lineno, &copy_directive, &unterminated);



   if (unterminated) {
     if (traditional) {

       ip->bufp = bp;
       goto endloop1;
     }
     ip->bufp = bp;
     return 1;
   }
   break;


 case '<':
   if (!kt->angle_brackets)
     break;
   while (bp < limit && *bp != '>' && *bp != '\n') {
     if (*bp == '\\' && bp[1] == '\n') {
       ip->lineno++;
       copy_directive = 1;
       bp++;
     }
     bp++;
   }
   break;

 case '/':
   if (*bp == '\\' && bp[1] == '\n')
     newline_fix (bp);
   if (*bp == '*'
       || (cplusplus_comments && *bp == '/')) {
     U_CHAR *obp = bp - 1;
     ip->bufp = bp + 1;
     skip_to_end_of_comment (ip, &ip->lineno, 0);
     bp = ip->bufp;


     if (bp == limit || *bp == '\n') {
       bp = obp;
       goto endloop1;
     }

     if (! keep_comments)
       copy_directive++;
   }
   break;

 case '\f':
 case '\r':
 case '\v':
   if (pedantic)
     pedwarn ("%s in preprocessing directive", char_name[c]);
   break;

 case '\n':
   --bp;
   ip->bufp = bp;
   goto endloop1;
 }
      }
      ip->bufp = bp;

    endloop1:
      resume_p = ip->bufp;






      if (!no_output && kt->pass_thru && put_out_comments) {
        int len;


        (((op)->length - ((op)->bufp - (op)->buf) <= (kt->length + 2)) ? grow_outbuf ((op), (kt->length + 2)) : 0);

 if (op->bufp > op->buf && op->bufp[-1] != '\n') {
   op->lineno++;
   *op->bufp++ = '\n';
 }
        *op->bufp++ = '#';
        memcpy (op->bufp,kt->name,kt->length);
        op->bufp += kt->length;


 len = (bp - buf);
 (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
 memcpy ((char *) op->bufp,buf,len);
 op->bufp += len;

 while (--len >= 0)
   if (buf[len] == '\n')
     op->lineno++;

 already_output = &junk;
      }

      if (copy_directive) {
 register U_CHAR *xp = buf;


 cp = (U_CHAR *) 
                __builtin_alloca((
                bp - buf + 5
                ))
                                     ;

 buf = cp;




 while (xp < bp) {
   register U_CHAR c = *xp++;
   *cp++ = c;

   switch (c) {
   case '\n':
     abort ();
     break;


   case '<':
     if (!kt->angle_brackets)
       break;
     while (xp < bp && c != '>') {
       c = *xp++;
       if (c == '\\' && xp < bp && *xp == '\n')
  xp++;
       else
  *cp++ = c;
     }
     break;

   case '\\':
     if (*xp == '\n') {
       xp++;
       cp--;
       if (cp != buf && is_hor_space[cp[-1]]) {
  while (cp - 1 != buf && is_hor_space[cp[-2]])
    cp--;
  do { while (is_hor_space[*xp]) xp++; } while (0);
       } else if (is_hor_space[*xp]) {
  *cp++ = *xp++;
  do { while (is_hor_space[*xp]) xp++; } while (0);
       }
     } else if (traditional && xp < bp) {
       *cp++ = *xp++;
     }
     break;

   case '\'':
   case '\"':
     {
       register U_CHAR *bp1
  = skip_quoted_string (xp - 1, bp, ip->lineno,
          ((void *)0), ((void *)0), ((void *)0));
       while (xp != bp1)
  if (*xp == '\\') {
    if (*++xp != '\n')
      *cp++ = '\\';
    else
      xp++;
  } else
    *cp++ = *xp++;
     }
     break;

   case '/':
     if (*xp == '*'
  || (cplusplus_comments && *xp == '/')) {
       ip->bufp = xp + 1;


       skip_to_end_of_comment (ip, already_output, 0);
       if (keep_comments)
  while (xp != ip->bufp)
    *cp++ = *xp++;

       else if (traditional)
  cp--;
       else
  cp[-1] = ' ';
       xp = ip->bufp;
     }
   }
 }



 *cp = 0;
      } else
 cp = bp;

      ip->bufp = resume_p;





      if (!no_output && already_output == 0
   && (kt->pass_thru
       || (kt->type == T_DEFINE
    && (dump_macros == dump_names
        || dump_macros == dump_definitions)))) {
        int len;


        (((op)->length - ((op)->bufp - (op)->buf) <= (kt->length + 1)) ? grow_outbuf ((op), (kt->length + 1)) : 0);
        *op->bufp++ = '#';
        memcpy ((char *) op->bufp,kt->name,kt->length);
        op->bufp += kt->length;

 if (kt->pass_thru || dump_macros == dump_definitions) {

   len = (cp - buf);
   (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
   memcpy ((char *) op->bufp,buf,len);
   op->bufp += len;
 } else if (kt->type == T_DEFINE && dump_macros == dump_names) {
   U_CHAR *xp = buf;
   U_CHAR *yp;
   do { while (is_hor_space[*xp]) xp++; } while (0);
   yp = xp;
   while (is_idchar[*xp]) xp++;
   len = (xp - yp);
   (((op)->length - ((op)->bufp - (op)->buf) <= (len + 1)) ? grow_outbuf ((op), (len + 1)) : 0);
   *op->bufp++ = ' ';
   memcpy (op->bufp,yp,len);
   op->bufp += len;
 }
      }






      (*kt->func) (buf, cp, op, kt);
      (((op)->length - ((op)->bufp - (op)->buf) <= (ip->length - (ip->bufp - ip->buf))) ? grow_outbuf ((op), (ip->length - (ip->bufp - ip->buf))) : 0);

      return 1;
    }
  }



  return 0;
}

static struct tm *
timestamp(void) asm("_timestamp");
static struct tm *
timestamp(void)
{
  static struct tm *timebuf;
  if (!timebuf) {
    time_t t = time ((time_t *)0);
    timebuf = localtime (&t);
  }
  return timebuf;
}

static char *monthnames[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
       };






static void
special_symbol(HASHNODE *hp, FILE_BUF *op) asm("_special_symbol");
static void
special_symbol(HASHNODE *hp, FILE_BUF *op)
{
  char *buf;
  int i, len;
  int true_indepth;
  FILE_BUF *ip = 
                ((void *)0)
                    ;
  struct tm *timebuf;

  int paren = 0;

  if (pcp_outfile && pcp_inside_if
      && hp->type != T_SPEC_DEFINED && hp->type != T_CONST)
    error ("Predefined macro `%s' used inside `#if' during precompilation",
    hp->name);

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }
  if (ip == 
           ((void *)0)
               ) {
    error ("cccp error: not in any file?!");
    return;
  }

  switch (hp->type) {
  case T_FILE:
  case T_BASE_FILE:
    {
      char *string;
      if (hp->type == T_FILE)
 string = ip->nominal_fname;
      else
 string = instack[0].nominal_fname;

      if (string)
 {
   buf = (char *) 
                 __builtin_alloca((
                 3 + 4 * strlen (string)
                 ))
                                                 ;
   quote_string (buf, string);
 }
      else
 buf = "\"\"";

      break;
    }

  case T_INCLUDE_LEVEL:
    true_indepth = 0;
    for (i = indepth; i >= 0; i--)
      if (instack[i].fname != 
                             ((void *)0)
                                 )
        true_indepth++;

    buf = (char *) 
                  __builtin_alloca((
                  8
                  ))
                            ;
    sprintf (buf, "%d", true_indepth - 1);
    break;

  case T_VERSION:
    buf = (char *) 
                  __builtin_alloca((
                  3 + strlen (version_string)
                  ))
                                                      ;
    sprintf (buf, "\"%s\"", version_string);
    break;
  case T_WCHAR_TYPE:
    buf = wchar_type;
    break;

  case T_USER_LABEL_PREFIX_TYPE:
    buf = "";
    break;

  case T_REGISTER_PREFIX_TYPE:
    buf = "";
    break;

  case T_IMMEDIATE_PREFIX_TYPE:
    buf = "";
    break;

  case T_CONST:
    buf = hp->value.cpval;
    if (pcp_inside_if && pcp_outfile)

      fprintf (pcp_outfile, "#define %s %s\n", hp->name, buf);
    break;

  case T_SPECLINE:
    buf = (char *) 
                  __builtin_alloca((
                  10
                  ))
                             ;
    sprintf (buf, "%d", ip->lineno);
    break;

  case T_DATE:
  case T_TIME:
    buf = (char *) 
                  __builtin_alloca((
                  20
                  ))
                             ;
    timebuf = timestamp ();
    if (hp->type == T_DATE)
      sprintf (buf, "\"%s %2d %4d\"", monthnames[timebuf->tm_mon],
       timebuf->tm_mday, timebuf->tm_year + 1900);
    else
      sprintf (buf, "\"%02d:%02d:%02d\"", timebuf->tm_hour, timebuf->tm_min,
       timebuf->tm_sec);
    break;

  case T_SPEC_DEFINED:
    buf = " 0 ";
    ip = &instack[indepth];
    do { while (is_hor_space[*ip->bufp]) ip->bufp++; } while (0);
    if (*ip->bufp == '(') {
      paren++;
      ip->bufp++;
      do { while (is_hor_space[*ip->bufp]) ip->bufp++; } while (0);
    }

    if (!is_idstart[*ip->bufp])
      goto oops;
    if ((hp = lookup (ip->bufp, -1, -1))) {
      if (pcp_outfile && pcp_inside_if
   && (hp->type == T_CONST
       || (hp->type == T_MACRO && hp->value.defn->predefined)))

 fprintf (pcp_outfile, "#define %s\n", hp->name);
      buf = " 1 ";
    }
    else
      if (pcp_outfile && pcp_inside_if) {

 U_CHAR *cp = ip->bufp;
 fprintf (pcp_outfile, "#undef ");
 while (is_idchar[*cp])
   fputc (*cp++, pcp_outfile);
 putc ('\n', pcp_outfile);
      }
    while (is_idchar[*ip->bufp])
      ++ip->bufp;
    do { while (is_hor_space[*ip->bufp]) ip->bufp++; } while (0);
    if (paren) {
      if (*ip->bufp != ')')
 goto oops;
      ++ip->bufp;
    }
    break;

oops:

    error ("`defined' without an identifier");
    break;

  default:
    error ("cccp error: invalid special hash type");
    abort ();
  }
  len = strlen (buf);
  (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
  memcpy ((char *) op->bufp,buf,len);
  op->bufp += len;

  return;
}







static int
do_include(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_include");
static int
do_include(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int importing = (keyword->type == T_IMPORT);
  int skip_dirs = (keyword->type == T_INCLUDE_NEXT);
  static int import_warning = 0;
  char *fname;
  char *pcftry;
  char *pcfname;
  U_CHAR *fbeg, *fend;

  struct n64_tag_file_name_list *search_start = include;
  struct n64_tag_file_name_list dsp[1];
  struct n64_tag_file_name_list *searchptr = 0;
  size_t flen;

  int f;

  int retried = 0;

  int angle_brackets = 0;
  int pcf = -1;
  char *pcfbuf;
  char *pcfbuflimit;
  int pcfnum;
  f= -1;

  if (importing && warn_import && !inhibit_warnings
      && !instack[indepth].system_header_p && !import_warning) {
    import_warning = 1;
    warning ("using `#import' is not recommended");
    fprintf (
            (__acrt_iob_func(2))
                  , "The fact that a certain header file need not be processed more than once\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "should be indicated in the header file, not where it is used.\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "The best way to do this is with a conditional of this form:\n\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "  #ifndef _FOO_H_INCLUDED\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "  #define _FOO_H_INCLUDED\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "  ... <real contents of file> ...\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "  #endif /* Not _FOO_H_INCLUDED */\n\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "Then users can use `#include' any number of times.\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "GNU C automatically avoids processing the file more than once\n");
    fprintf (
            (__acrt_iob_func(2))
                  , "when it is equipped with such a conditional.\n");
  }

get_filename:

  fbeg = buf;
  do { while (is_hor_space[*fbeg]) fbeg++; } while (0);


  while (limit != fbeg && is_hor_space[limit[-1]]) limit--;

  switch (*fbeg++) {
  case '\"':
    {
      FILE_BUF *fp;

      {
 U_CHAR *fin = fbeg;
 fbeg = (U_CHAR *) 
                  __builtin_alloca((
                  limit - fbeg + 1
                  ))
                                           ;
 fend = fbeg;
 while (fin != limit) {
   while (fin != limit && *fin != '\"')
     *fend++ = *fin++;
   fin++;
   if (fin == limit)
     break;


   while (fin != limit && is_hor_space[*fin]) fin++;
   if (fin != limit && *fin == '\"')
     fin++;
   else
     goto fail;
 }
      }
      *fend = 0;





      if (ignore_srcdir) break;

      for (fp = &instack[indepth]; fp >= instack; fp--)
 {
   int n;
   char *ep,*nam;

   if ((nam = fp->nominal_fname) != 
                                   ((void *)0)
                                       ) {


     dsp[0].next = search_start;
     search_start = dsp;

     ep = strrchr (nam, '/');

     if (ep == 
              ((void *)0)
                  ) ep = strrchr (nam, '\\');
     else {
       char *tmp = strrchr (nam, '\\');
       if (tmp != 
                 ((void *)0) 
                      && tmp > ep) ep = tmp;
     }







     if (ep != 
              ((void *)0)
                  ) {
       n = ep - nam;
       dsp[0].fname = (char *) 
                              __builtin_alloca((
                              n + 1
                              ))
                                            ;
       strncpy (dsp[0].fname, nam, n);
       dsp[0].fname[n] = '\0';
       if (n + 0 > max_include_len)
  max_include_len = n + 0;
     } else {
       dsp[0].fname = 0;
     }
     dsp[0].got_name_map = 0;
     break;
   }
 }
      break;
    }

  case '<':
    fend = fbeg;
    while (fend != limit && *fend != '>') fend++;
    if (*fend == '>' && fend + 1 == limit) {
      angle_brackets = 1;

      if (first_bracket_include)
 search_start = first_bracket_include;
      break;
    }
    goto fail;

  default:
  fail:
    if (retried) {
      error ("`#%s' expects \"FILENAME\" or <FILENAME>", keyword->name);
      return 0;
    } else {



      FILE_BUF trybuf;
      U_CHAR *src;
      trybuf = expand_to_temp_buffer (buf, limit, 1, 0);
      src = trybuf.buf;
      buf = (U_CHAR *) 
                      __builtin_alloca((
                      trybuf.bufp - trybuf.buf + 1
                      ))
                                                           ;
      limit = buf;
      while (src != trybuf.bufp) {
 switch ((*limit++ = *src++)) {
   case '\n':
     limit--;
     src++;
     break;

   case '\'':
   case '\"':
     {
       U_CHAR *src1 = skip_quoted_string (src - 1, trybuf.bufp, 0,
       ((void *)0), ((void *)0), ((void *)0));
       while (src != src1)
  *limit++ = *src++;
     }
     break;
 }
      }
      *limit = 0;
      free (trybuf.buf);
      retried++;
      goto get_filename;
    }
  }



  if (skip_dirs) {
    FILE_BUF *fp;
    for (fp = &instack[indepth]; fp >= instack; fp--)
      if (fp->fname != 
                      ((void *)0)
                          ) {


 if (fp->dir)
   search_start = fp->dir->next;
 break;
      }
  }

  flen = fend - fbeg;

  if (flen == 0)
    {
      error ("empty file name in `#%s'", keyword->name);
      return 0;
    }



  fname = xmalloc (max_include_len + flen + 4);





  if (*fbeg == '/'

      || *fbeg == '\\'

      ) {
    strncpy (fname, (char *) fbeg, flen);
    fname[flen] = 0;
    if (redundant_include_p (fname))
      return 0;
    if (importing)
      f = lookup_import (fname, ((void *)0));
    else
      f = open_include_file (fname, ((void *)0));
    if (f == -2)
      return 0;
  } else {



    for (searchptr = search_start; searchptr; searchptr = searchptr->next) {
      if (searchptr->fname) {



 if (searchptr->fname[0] == 0)
   continue;
 strcpy (fname, skip_redundant_dir_prefix (searchptr->fname));
 if (fname[0] && fname[strlen (fname) - 1] != '/')
   strcat (fname, "/");
      } else {
 fname[0] = 0;
      }
      strncat (fname, (char *) fbeg, flen);
      if (redundant_include_p (fname))
 return 0;
      if (importing)
 f = lookup_import (fname, searchptr);
      else
 f = open_include_file (fname, searchptr);
      if (f == -2)
 return 0;

      else if (f == -1 && 
                         (*_errno()) 
                               == 
                                  13
                                        )
 warning ("Header file %s exists, but is not readable", fname);

      if (f >= 0)
 break;
    }
  }

  if (f < 0) {


    strncpy (fname, (char *) fbeg, flen);
    fname[flen] = 0;




    if (print_deps_missing_files
 && print_deps > (angle_brackets || (system_include_depth > 0)))
      {


 if (angle_brackets)
   {
     for (searchptr = search_start; searchptr; searchptr = searchptr->next)
       {
  if (searchptr->fname)
    {
      char *p;

      if (searchptr->fname[0] == 0)
        continue;
      p = (char *) 
                  __builtin_alloca((
                  strlen (searchptr->fname) + strlen (fname) + 2
                  ))
                           
                          ;
      strcpy (p, skip_redundant_dir_prefix (searchptr->fname));
      if (p[0] && p[strlen (p) - 1] != '/')
        strcat (p, "/");
      strcat (p, fname);
      deps_output (p, ' ');
      break;
    }
       }
   }
 else
   {


     deps_output (fname, ' ');
   }
      }





    else if (print_deps
 && (print_deps <= (angle_brackets || (system_include_depth > 0))))
      warning ("No include path in which to find %s", fname);
    else if (search_start)
      error_from_errno (fname);
    else
      error ("No include path in which to find %s", fname);
  } else {



    struct n64_tag_file_name_list* ptr;

    for (ptr = dont_repeat_files; ptr; ptr = ptr->next) {
      if (!strcmp (ptr->fname, fname)) {
 close (f);
        return 0;
      }
    }

    for (ptr = all_include_files; ptr; ptr = ptr->next) {
      if (!strcmp (ptr->fname, fname))
        break;
    }

    if (ptr == 0) {



      ptr = (struct n64_tag_file_name_list *) xmalloc (sizeof (struct n64_tag_file_name_list));
      ptr->control_macro = 0;
      ptr->c_system_include_path = 0;
      ptr->next = all_include_files;
      all_include_files = ptr;
      ptr->fname = savestring (fname);
      ptr->got_name_map = 0;


      if (print_deps > (angle_brackets || (system_include_depth > 0)))
 deps_output (fname, ' ');
    }


    if (print_include_names)
      fprintf (
              (__acrt_iob_func(2))
                    , "%*s%s\n", indepth, "", fname);

    if (angle_brackets)
      system_include_depth++;


    add_import (f, fname);

    pcftry = (char *) 
                     __builtin_alloca((
                     strlen (fname) + 30
                     ))
                                                 ;
    pcfbuf = 0;
    pcfnum = 0;

    if (!no_precomp)
      {
 struct stat stat_f;

 fstat (f, &stat_f);

 do {
   sprintf (pcftry, "%s%d", fname, pcfnum++);

   pcf = open (pcftry, 
                      0x0000
                              , 0666);
   if (pcf != -1)
     {
       struct stat s;

       fstat (pcf, &s);
       if (memcmp ((char *) &stat_f.st_ino,(char *) &s.st_ino,sizeof (s.st_ino))

    || stat_f.st_dev != s.st_dev)
  {
    pcfbuf = check_precompiled (pcf, fname, &pcfbuflimit);

    close (pcf);
  }
       else
  {

    close (pcf);
    break;
  }
     }
 } while (pcf != -1 && !pcfbuf);
      }


    if (pcfbuf) {
      pcfname = xmalloc (strlen (pcftry) + 1);
      strcpy (pcfname, pcftry);
      pcfinclude ((U_CHAR *) pcfbuf, (U_CHAR *) pcfbuflimit,
    (U_CHAR *) fname, op);
    }
    else
      finclude (f, fname, op, is_system_include (fname), searchptr);

    if (angle_brackets)
      system_include_depth--;
  }
  return 0;
}





static int
redundant_include_p(char *name) asm("_redundant_include_p");
static int
redundant_include_p(char *name)
{
  struct n64_tag_file_name_list *l = all_include_files;
  for (; l; l = l->next)
    if (! strcmp (name, l->fname)
 && l->control_macro
 && lookup (l->control_macro, -1, -1))
      return 1;
  return 0;
}
static int
is_system_include(register char *filename) asm("_is_system_include");
static int
is_system_include(register char *filename)
{
  struct n64_tag_file_name_list *searchptr;

  for (searchptr = first_system_include; searchptr;
       searchptr = searchptr->next)
    if (searchptr->fname) {
      register char *sys_dir = skip_redundant_dir_prefix (searchptr->fname);
      register unsigned length = strlen (sys_dir);

      if (! strncmp (sys_dir, filename, length)
   && (filename[length] == '/'

       || filename[length] == '\\'

       )) {
 if (searchptr->c_system_include_path)
   return 2;
 else
   return 1;
      }
    }
  return 0;
}




static char *
skip_redundant_dir_prefix(char *dir) asm("_skip_redundant_dir_prefix");
static char *
skip_redundant_dir_prefix(char *dir)
{
  while (dir[0] == '.' && dir[1] == '/')
    for (dir += 2; *dir == '/'; dir++)
      continue;
  if (dir[0] == '.' && !dir[1])
    dir++;
  return dir;
}
struct n64_tag_file_name_map
{
  struct n64_tag_file_name_map *map_next;
  char *map_from;
  char *map_to;
};






static char *
read_filename_string(int ch, FILE *f) asm("_read_filename_string");
static char *
read_filename_string(int ch, FILE *f)
{
  char *alloc, *set;
  int len;

  len = 20;
  set = alloc = xmalloc (len + 1);
  if (! is_space[ch])
    {
      *set++ = ch;
      while ((ch = getc (f)) != 
                               (-1) 
                                   && ! is_space[ch])
 {
   if (set - alloc == len)
     {
       len *= 2;
       alloc = xrealloc (alloc, len + 1);
       set = alloc + len / 2;
     }
   *set++ = ch;
 }
    }
  *set = '\0';
  ungetc (ch, f);
  return alloc;
}



static struct n64_tag_file_name_map *
read_name_map(char *dirname) asm("_read_name_map");
static struct n64_tag_file_name_map *
read_name_map(char *dirname)
{


  struct n64_tag_file_name_map_list
    {
      struct n64_tag_file_name_map_list *map_list_next;
      char *map_list_name;
      struct n64_tag_file_name_map *map_list_map;
    };
  static struct n64_tag_file_name_map_list *map_list;
  register struct n64_tag_file_name_map_list *map_list_ptr;
  char *name;
  FILE *f;
  size_t dirlen;
  int separator_needed;

  dirname = skip_redundant_dir_prefix (dirname);

  for (map_list_ptr = map_list; map_list_ptr;
       map_list_ptr = map_list_ptr->map_list_next)
    if (! strcmp (map_list_ptr->map_list_name, dirname))
      return map_list_ptr->map_list_map;

  map_list_ptr = ((struct n64_tag_file_name_map_list *)
    xmalloc (sizeof (struct n64_tag_file_name_map_list)));
  map_list_ptr->map_list_name = savestring (dirname);
  map_list_ptr->map_list_map = 
                              ((void *)0)
                                  ;

  dirlen = strlen (dirname);
  separator_needed = dirlen != 0 && dirname[dirlen - 1] != '/';
  name = (char *) 
                 __builtin_alloca((
                 dirlen + strlen ("header.gcc") + 2
                 ))
                                                                  ;
  strcpy (name, dirname);
  name[dirlen] = '/';
  strcpy (name + dirlen + separator_needed, "header.gcc");
  f = fopen (name, "r");
  if (!f)
    map_list_ptr->map_list_map = 
                                ((void *)0)
                                    ;
  else
    {
      int ch;

      while ((ch = getc (f)) != 
                               (-1)
                                  )
 {
   char *from, *to;
   struct n64_tag_file_name_map *ptr;

   if (is_space[ch])
     continue;
   from = read_filename_string (ch, f);
   while ((ch = getc (f)) != 
                            (-1) 
                                && is_hor_space[ch])
     ;
   to = read_filename_string (ch, f);

   ptr = ((struct n64_tag_file_name_map *)
   xmalloc (sizeof (struct n64_tag_file_name_map)));
   ptr->map_from = from;


   if (*to == '/')
     ptr->map_to = to;
   else
     {
       ptr->map_to = xmalloc (dirlen + strlen (to) + 2);
       strcpy (ptr->map_to, dirname);
       ptr->map_to[dirlen] = '/';
       strcpy (ptr->map_to + dirlen + separator_needed, to);
       free (to);
     }

   ptr->map_next = map_list_ptr->map_list_map;
   map_list_ptr->map_list_map = ptr;

   while ((ch = getc (f)) != '\n')
     if (ch == 
              (-1)
                 )
       break;
 }
      fclose (f);
    }

  map_list_ptr->map_list_next = map_list;
  map_list = map_list_ptr;

  return map_list_ptr->map_list_map;
}






static int
open_include_file(char *filename, struct n64_tag_file_name_list *searchptr) asm("_open_include_file");
static int
open_include_file(char *filename, struct n64_tag_file_name_list *searchptr)
{
  register struct n64_tag_file_name_map *map;
  register char *from;
  char *p, *dir;

  if (searchptr && ! searchptr->got_name_map)
    {
      searchptr->name_map = read_name_map (searchptr->fname
        ? searchptr->fname : ".");
      searchptr->got_name_map = 1;
    }


  if (searchptr && searchptr->name_map)
    {
      from = filename;
      if (searchptr->fname)
 from += strlen (searchptr->fname) + 1;
      for (map = searchptr->name_map; map; map = map->map_next)
 {
   if (! strcmp (map->map_from, from))
     {

       return open (map->map_to, 
                                0x0000
                                        , 0666);
     }
 }
    }





  p = strrchr (filename, '/');

  if (! p) p = strrchr (filename, '\\');
  else {
    char *tmp = strrchr (filename, '\\');
    if (tmp != 
              ((void *)0) 
                   && tmp > p) p = tmp;
  }

  if (! p)
    p = filename;
  if (searchptr
      && searchptr->fname
      && strlen (searchptr->fname) == p - filename
      && ! strncmp (searchptr->fname, filename, p - filename))
    {

      return open (filename, 
                            0x0000
                                    , 0666);
    }

  if (p == filename)
    {
      dir = ".";
      from = filename;
    }
  else
    {
      dir = (char *) 
                    __builtin_alloca((
                    p - filename + 1
                    ))
                                             ;
      memcpy (dir,filename,p - filename);
      dir[p - filename] = '\0';
      from = p + 1;
    }
  for (map = read_name_map (dir); map; map = map->map_next)
    if (! strcmp (map->map_from, from))
      return open (map->map_to, 
                               0x0000
                                       , 0666);

  return open (filename, 
                        0x0000
                                , 0666);
}
static void
finclude(int f, char *fname, FILE_BUF *op, int system_header_p, struct n64_tag_file_name_list *dirptr) asm("_finclude");
static void
finclude(int f, char *fname, FILE_BUF *op, int system_header_p, struct n64_tag_file_name_list *dirptr)
{
  int st_mode;
  long st_size;
  long i;
  FILE_BUF *fp;
  int missing_newline = 0;

  if (indepth >= (400 - 1)) { error_with_line (line_for_error (instack[indepth].lineno), "macro or `#include' recursion too deep"); return;; };

  if (file_size_and_mode (f, &st_mode, &st_size) < 0)
    {
      perror_with_name (fname);
      close (f);
      return;
    }

  fp = &instack[indepth + 1];
  memset ((char *) fp,0,sizeof (FILE_BUF));
  fp->nominal_fname = fp->fname = fname;
  fp->length = 0;
  fp->lineno = 1;
  fp->if_stack = if_stack;
  fp->system_header_p = system_header_p;
  fp->dir = dirptr;

  if (
     (((
     st_mode
     ) & 0xF000) == 0x8000)
                      ) {
    fp->buf = (U_CHAR *) xmalloc (st_size + 2);
    fp->bufp = fp->buf;



    fp->length = safe_read (f, (char *) fp->buf, st_size);
    if (fp->length < 0) goto nope;
  }
  else if (
          (((
          st_mode
          ) & 0xF000) == 0x4000)
                           ) {
    error ("directory `%s' specified in #include", fname);
    close (f);
    return;
  } else {




    int bsize = 2000;

    st_size = 0;
    fp->buf = (U_CHAR *) xmalloc (bsize + 2);

    for (;;) {
      i = safe_read (f, (char *) fp->buf + st_size, bsize - st_size);
      if (i < 0)
 goto nope;
      st_size += i;
      if (st_size != bsize)
 break;
      bsize *= 2;
      fp->buf = (U_CHAR *) xrealloc (fp->buf, bsize + 2);
    }
    fp->bufp = fp->buf;
    fp->length = st_size;
  }

  if ((fp->length > 0 && fp->buf[fp->length - 1] != '\n')

      || (fp->length > 1 && fp->buf[fp->length - 2] == '\\')) {
    fp->buf[fp->length++] = '\n';
    missing_newline = 1;
  }
  fp->buf[fp->length] = '\0';


  close (f);




  indepth++;
  input_file_stack_tick++;

  if (!no_trigraphs)
    trigraph_pcp (fp);

  output_line_directive (fp, op, 0, enter_file);
  rescan (op, 0);

  if (missing_newline)
    fp->lineno--;

  if (pedantic && missing_newline)
    pedwarn ("file does not end in newline");

  indepth--;
  input_file_stack_tick++;
  output_line_directive (&instack[indepth], op, 0, leave_file);
  free (fp->buf);
  return;

 nope:

  perror_with_name (fname);
  close (f);
  free (fp->buf);
}






static void
record_control_macro(char *file, U_CHAR *macro_name) asm("_record_control_macro");
static void
record_control_macro(char *file, U_CHAR *macro_name)
{
  struct n64_tag_file_name_list *cxx_new;

  for (cxx_new = all_include_files; cxx_new; cxx_new = cxx_new->next) {
    if (!strcmp (cxx_new->fname, file)) {
      cxx_new->control_macro = macro_name;
      return;
    }
  }


  abort ();
}





struct n64_tag_import_file {
  char *name;
  ino_t inode;
  dev_t dev;
  struct n64_tag_import_file *next;
};



static struct n64_tag_import_file *import_hash_table[31];



static int
import_hash(char *f) asm("_import_hash");
static int
import_hash(char *f)
{
  int val = 0;

  while (*f) val += *f++;
  return (val%31);
}






static int
lookup_import(char *filename, struct n64_tag_file_name_list *searchptr) asm("_lookup_import");
static int
lookup_import(char *filename, struct n64_tag_file_name_list *searchptr)
{
  struct n64_tag_import_file *i;
  int h;
  int hashval;
  struct stat sb;
  int fd;

  hashval = import_hash (filename);


  i = import_hash_table[hashval];

  while (i) {
    if (!strcmp (filename, i->name))
      return -2;
    i = i->next;
  }

  fd = open_include_file (filename, searchptr);
  if (fd < 0)
    return fd;
  fstat (fd, &sb);
  for (h = 0; h < 31; h++) {
    i = import_hash_table[h];
    while (i) {


      if (!memcmp ((char *) &i->inode,(char *) &sb.st_ino,sizeof (sb.st_ino))
   && i->dev == sb.st_dev) {
        close (fd);
        return -2;
      }
      i = i->next;
    }
  }
  return fd;
}



static void
add_import(int fd, char *fname) asm("_add_import");
static void
add_import(int fd, char *fname)
{
  struct n64_tag_import_file *i;
  int hashval;
  struct stat sb;

  hashval = import_hash (fname);
  fstat (fd, &sb);
  i = (struct n64_tag_import_file *)xmalloc (sizeof (struct n64_tag_import_file));
  i->name = xmalloc (strlen (fname)+1);
  strcpy (i->name, fname);
  memcpy ((char *) &i->inode,(char *) &sb.st_ino,sizeof (sb.st_ino));
  i->dev = sb.st_dev;
  i->next = import_hash_table[hashval];
  import_hash_table[hashval] = i;
}
static char *
check_precompiled(int pcf, char *fname, char **limit) asm("_check_precompiled");
static char *
check_precompiled(int pcf, char *fname, char **limit)
{
  int st_mode;
  long st_size;
  int length = 0;
  char *buf;
  char *cp;

  if (pcp_outfile)
    return 0;

  if (file_size_and_mode (pcf, &st_mode, &st_size) < 0)
    return 0;

  if (
     (((
     st_mode
     ) & 0xF000) == 0x8000)
                      )
    {
      buf = xmalloc (st_size + 2);
      length = safe_read (pcf, buf, st_size);
      if (length < 0)
 goto nope;
    }
  else
    abort ();

  if (length > 0 && buf[length-1] != '\n')
    buf[length++] = '\n';
  buf[length] = '\0';

  *limit = buf + length;


  if (!check_preconditions (buf))
    goto nope;
  for (cp = buf; *cp; cp++)
    ;



  return cp + 1;

 nope:



  free (buf);
  return 0;
}





static int
check_preconditions(char *prec) asm("_check_preconditions");
static int
check_preconditions(char *prec)
{
  MACRODEF mdef;
  char *lineend;

  while (*prec) {
    lineend = strchr (prec, '\n');

    if (*prec++ != '#') {
      error ("Bad format encountered while reading precompiled file");
      return 0;
    }
    if (!strncmp (prec, "define", 6)) {
      HASHNODE *hp;

      prec += 6;
      mdef = create_definition ((U_CHAR *) prec, (U_CHAR *) lineend, ((void *)0));

      if (mdef.defn == 0)
 abort ();

      if ((hp = lookup (mdef.symnam, mdef.symlen, -1)) == 
                                                         ((void *)0)
   
  || (hp->type != T_MACRO && hp->type != T_CONST)
   || (hp->type == T_MACRO
       && !compare_defs (mdef.defn, hp->value.defn)
       && (mdef.defn->length != 2
    || mdef.defn->expansion[0] != '\n'
    || mdef.defn->expansion[1] != ' ')))
 return 0;
    } else if (!strncmp (prec, "undef", 5)) {
      char *name;
      int len;

      prec += 5;
      while (is_hor_space[(U_CHAR) *prec])
 prec++;
      name = prec;
      while (is_idchar[(U_CHAR) *prec])
 prec++;
      len = prec - name;

      if (lookup ((U_CHAR *) name, len, -1))
 return 0;
    } else {
      error ("Bad format encountered while reading precompiled file");
      return 0;
    }
    prec = lineend + 1;
  }

  return 1;
}





static void
pcfinclude(U_CHAR *buf, U_CHAR *limit, U_CHAR *name, FILE_BUF *op) asm("_pcfinclude");
static void
pcfinclude(U_CHAR *buf, U_CHAR *limit, U_CHAR *name, FILE_BUF *op)
{
  FILE_BUF tmpbuf;
  int nstrings;
  U_CHAR *cp = buf;



  nstrings = *cp++;
  nstrings = (nstrings << 8) | *cp++;
  nstrings = (nstrings << 8) | *cp++;
  nstrings = (nstrings << 8) | *cp++;


  while (nstrings--) {
    U_CHAR *string_start;
    U_CHAR *endofthiskey;
    STRINGDEF *str;
    int nkeys;
    if ((int) cp & 3)
      cp += 4 - ((int) cp & 3);


    str = (STRINGDEF *) (void *) cp;
    string_start = cp += sizeof (STRINGDEF);

    for (; *cp; cp++)
      ;





    tmpbuf = expand_to_temp_buffer (string_start, cp++, 0, 0);

    str->contents = tmpbuf.buf;
    str->len = tmpbuf.length;
    str->writeflag = 0;
    str->filename = name;
    str->output_mark = outbuf.bufp - outbuf.buf;

    str->chain = 0;
    *stringlist_tailp = str;
    stringlist_tailp = &str->chain;



    nkeys = *cp++;
    nkeys = (nkeys << 8) | *cp++;
    nkeys = (nkeys << 8) | *cp++;
    nkeys = (nkeys << 8) | *cp++;


    if (nkeys == -1)
      str->writeflag = 1;
    else

      for (; nkeys--; free (tmpbuf.buf), cp = endofthiskey + 1) {
 KEYDEF *kp = (KEYDEF *) (void *) cp;
 HASHNODE *hp;


 cp += sizeof (KEYDEF);



 endofthiskey = cp + strlen ((char *) cp);
 kp->str = str;


 tmpbuf = expand_to_temp_buffer (cp, endofthiskey, 0, 0);
 tmpbuf.bufp = tmpbuf.buf;

 while (is_hor_space[*tmpbuf.bufp])
   tmpbuf.bufp++;
 if (!is_idstart[*tmpbuf.bufp]
     || tmpbuf.bufp == tmpbuf.buf + tmpbuf.length) {
   str->writeflag = 1;
   continue;
 }

 hp = lookup (tmpbuf.bufp, -1, -1);
 if (hp == 
          ((void *)0)
              ) {
   kp->chain = 0;
   install (tmpbuf.bufp, -1, T_PCSTRING, (char *) kp, -1);
 }
 else if (hp->type == T_PCSTRING) {
   kp->chain = hp->value.keydef;
   hp->value.keydef = kp;
 }
 else
   str->writeflag = 1;
      }
  }



  output_line_directive (&instack[indepth], op, 0, enter_file);
}



static void
pcstring_used(HASHNODE *hp) asm("_pcstring_used");
static void
pcstring_used(HASHNODE *hp)
{
  KEYDEF *kp;

  for (kp = hp->value.keydef; kp; kp = kp->chain)
    kp->str->writeflag = 1;
  delete_macro (hp);
}



static void
write_output(void) asm("_write_output");
static void
write_output(void)
{
  STRINGDEF *next_string;
  U_CHAR *cur_buf_loc;
  int line_directive_len = 80;
  char *line_directive = xmalloc (line_directive_len);
  int len;





  cur_buf_loc = outbuf.buf;
  next_string = stringlist;

  while (cur_buf_loc < outbuf.bufp || next_string) {
    if (next_string
 && cur_buf_loc - outbuf.buf == next_string->output_mark) {
      if (next_string->writeflag) {
 len = 4 * strlen ((char *) next_string->filename) + 32;
 while (len > line_directive_len)
   line_directive = xrealloc (line_directive,
         line_directive_len *= 2);
 sprintf (line_directive, "\n# %d ", next_string->lineno);
 strcpy (quote_string (line_directive + strlen (line_directive),
         (char *) next_string->filename),
  "\n");
 safe_write (fileno (
                    (__acrt_iob_func(1))
                          ), line_directive, strlen (line_directive));
 safe_write (fileno (
                    (__acrt_iob_func(1))
                          ),
      (char *) next_string->contents, next_string->len);
      }
      next_string = next_string->chain;
    }
    else {
      len = (next_string
      ? (next_string->output_mark
  - (cur_buf_loc - outbuf.buf))
      : outbuf.bufp - cur_buf_loc);

      safe_write (fileno (
                         (__acrt_iob_func(1))
                               ), (char *) cur_buf_loc, len);
      cur_buf_loc += len;
    }
  }
  free (line_directive);
}






static void
pass_thru_directive(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_pass_thru_directive");
static void
pass_thru_directive(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  register unsigned keyword_length = keyword->length;

  (((op)->length - ((op)->bufp - (op)->buf) <= (1 + keyword_length + (limit - buf))) ? grow_outbuf ((op), (1 + keyword_length + (limit - buf))) : 0);
  *op->bufp++ = '#';
  memcpy ((char *) op->bufp,keyword->name,keyword_length);
  op->bufp += keyword_length;
  if (limit != buf && buf[0] != ' ')
    *op->bufp++ = ' ';
  memcpy ((char *) op->bufp,(char *) buf,limit - buf);
  op->bufp += (limit - buf);






}
struct n64_tag_arglist {
  struct n64_tag_arglist *next;
  U_CHAR *name;
  int length;
  int argno;
  char rest_args;
};



static MACRODEF
create_definition(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op) asm("_create_definition");
static MACRODEF
create_definition(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op)
{
  U_CHAR *bp;
  U_CHAR *symname;
  int sym_length;
  int line = instack[indepth].lineno;
  char *file = instack[indepth].nominal_fname;
  int rest_args = 0;

  DEFINITION *defn;
  int arglengths = 0;

  MACRODEF mdef;

  bp = buf;

  while (is_hor_space[*bp])
    bp++;

  symname = bp;
  sym_length = check_macro_name (bp, "macro");
  bp += sym_length;





  if (*bp == '(') {
    struct n64_tag_arglist *arg_ptrs = 
                              ((void *)0)
                                  ;
    int argno = 0;

    bp++;
    do { while (is_hor_space[*bp]) bp++; } while (0);


    while (*bp != ')') {
      struct n64_tag_arglist *temp;

      temp = (struct n64_tag_arglist *) 
                               __builtin_alloca((
                               sizeof (struct n64_tag_arglist)
                               ))
                                                               ;
      temp->name = bp;
      temp->next = arg_ptrs;
      temp->argno = argno++;
      temp->rest_args = 0;
      arg_ptrs = temp;

      if (rest_args)
 pedwarn ("another parameter follows `%s'",
   rest_extension);

      if (!is_idstart[*bp])
 pedwarn ("invalid character in macro parameter name");


      while (is_idchar[*bp]) {
 bp++;

 if (limit - bp > (sizeof (rest_extension) - 1) &&
     memcmp (rest_extension,bp,(sizeof (rest_extension) - 1)) == 0) {
   rest_args = 1;
   temp->rest_args = 1;
   break;
 }
      }
      temp->length = bp - temp->name;
      if (rest_args == 1)
 bp += (sizeof (rest_extension) - 1);
      arglengths += temp->length + 2;
      do { while (is_hor_space[*bp]) bp++; } while (0);
      if (temp->length == 0 || (*bp != ',' && *bp != ')')) {
 error ("badly punctuated parameter list in `#define'");
 goto nope;
      }
      if (*bp == ',') {
 bp++;
 do { while (is_hor_space[*bp]) bp++; } while (0);

 if (!is_idstart[*bp]) {
   error ("badly punctuated parameter list in `#define'");
   goto nope;
 }
      }
      if (bp >= limit) {
 error ("unterminated parameter list in `#define'");
 goto nope;
      }
      {
 struct n64_tag_arglist *otemp;

 for (otemp = temp->next; otemp != 
                                  ((void *)0)
                                      ; otemp = otemp->next)
   if (temp->length == otemp->length &&
       memcmp (temp->name,otemp->name,temp->length) == 0) {
       error ("duplicate argument name `%.*s' in `#define'",
       temp->length, temp->name);
       goto nope;
   }
      }
    }

    ++bp;
    do { while (is_hor_space[*bp]) bp++; } while (0);

    defn = collect_expansion (bp, limit, argno, arg_ptrs);
    defn->rest_args = rest_args;




    defn->args.argnames = (U_CHAR *) xmalloc (arglengths + 1);
    {
      struct n64_tag_arglist *temp;
      int i = 0;
      for (temp = arg_ptrs; temp; temp = temp->next) {
 memcpy (&defn->args.argnames[i],temp->name,temp->length);
 i += temp->length;
 if (temp->next != 0) {
   defn->args.argnames[i++] = ',';
   defn->args.argnames[i++] = ' ';
 }
      }
      defn->args.argnames[i] = 0;
    }
  } else {


    if (bp < limit)
      {
 if (is_hor_space[*bp]) {
   bp++;
   do { while (is_hor_space[*bp]) bp++; } while (0);
 } else {
   switch (*bp) {
     case '!': case '"': case '#': case '%': case '&': case '\'':
     case ')': case '*': case '+': case ',': case '-': case '.':
     case '/': case ':': case ';': case '<': case '=': case '>':
     case '?': case '[': case '\\': case ']': case '^': case '{':
     case '|': case '}': case '~':
       warning ("missing white space after `#define %.*s'",
         sym_length, symname);
       break;

     default:
       pedwarn ("missing white space after `#define %.*s'",
         sym_length, symname);
       break;
   }
 }
      }

    defn = collect_expansion (bp, limit, -1, ((void *)0));
    defn->args.argnames = (U_CHAR *) "";
  }

  defn->line = line;
  defn->file = file;


  defn->predefined = !op;
  mdef.defn = defn;
  mdef.symnam = symname;
  mdef.symlen = sym_length;

  return mdef;

 nope:
  mdef.defn = 0;
  return mdef;
}






static int
do_define(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_define");
static int
do_define(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int hashcode;
  MACRODEF mdef;


  if (pcp_outfile && op)
    pass_thru_directive (buf, limit, op, keyword);

  mdef = create_definition (buf, limit, op);
  if (mdef.defn == 0)
    goto nope;

  hashcode = hashf (mdef.symnam, mdef.symlen, 1403);

  {
    HASHNODE *hp;
    if ((hp = lookup (mdef.symnam, mdef.symlen, hashcode)) != 
                                                             ((void *)0)
                                                                 ) {
      int ok = 0;

      if (hp->type == T_PCSTRING)
 ok = 1;

      else if (hp->type == T_MACRO)
 ok = ! compare_defs (mdef.defn, hp->value.defn);

      else if (hp->type == T_CONST)
        ok = ! done_initializing;

      if (!ok) {


        if (debug_output && op)
   pass_thru_directive (buf, limit, op, keyword);

 pedwarn ("`%.*s' redefined", mdef.symlen, mdef.symnam);
 if (hp->type == T_MACRO)
   pedwarn_with_file_and_line (hp->value.defn->file, hp->value.defn->line,
          "this is the location of the previous definition");
      }

      hp->type = T_MACRO;
      hp->value.defn = mdef.defn;
    } else {


      if (debug_output && op)
 pass_thru_directive (buf, limit, op, keyword);
      install (mdef.symnam, mdef.symlen, T_MACRO,
        (char *) mdef.defn, hashcode);
    }
  }

  return 0;

nope:

  return 1;
}




static int
check_macro_name(U_CHAR *symname, char *usage) asm("_check_macro_name");
static int
check_macro_name(U_CHAR *symname, char *usage)
{
  U_CHAR *p;
  int sym_length;

  for (p = symname; is_idchar[*p]; p++)
    ;
  sym_length = p - symname;
  if (sym_length == 0)
    error ("invalid %s name", usage);
  else if (!is_idstart[*symname]
    || (sym_length == 7 && ! memcmp (symname,"defined",7)))
    error ("invalid %s name `%.*s'", usage, sym_length, symname);
  return sym_length;
}




static int
compare_defs(DEFINITION *d1, DEFINITION *d2) asm("_compare_defs");
static int
compare_defs(DEFINITION *d1, DEFINITION *d2)
{
  register struct n64_tag_reflist *a1, *a2;
  register U_CHAR *p1 = d1->expansion;
  register U_CHAR *p2 = d2->expansion;
  int first = 1;

  if (d1->nargs != d2->nargs)
    return 1;
  if (strcmp ((char *)d1->args.argnames, (char *)d2->args.argnames))
    return 1;
  for (a1 = d1->pattern, a2 = d2->pattern; a1 && a2;
       a1 = a1->next, a2 = a2->next) {
    if (!((a1->nchars == a2->nchars && ! memcmp (p1,p2,a1->nchars))
   || ! comp_def_part (first, p1, a1->nchars, p2, a2->nchars, 0))
 || a1->argno != a2->argno
 || a1->stringify != a2->stringify
 || a1->raw_before != a2->raw_before
 || a1->raw_after != a2->raw_after)
      return 1;
    first = 0;
    p1 += a1->nchars;
    p2 += a2->nchars;
  }
  if (a1 != a2)
    return 1;
  if (comp_def_part (first, p1, d1->length - (p1 - d1->expansion),
       p2, d2->length - (p2 - d2->expansion), 1))
    return 1;
  return 0;
}
static int
comp_def_part(int first, U_CHAR *beg1, int len1, U_CHAR *beg2, int len2, int last) asm("_comp_def_part");
static int
comp_def_part(int first, U_CHAR *beg1, int len1, U_CHAR *beg2, int len2, int last)
{
  register U_CHAR *end1 = beg1 + len1;
  register U_CHAR *end2 = beg2 + len2;
  if (first) {
    while (beg1 != end1 && is_space[*beg1]) beg1++;
    while (beg2 != end2 && is_space[*beg2]) beg2++;
  }
  if (last) {
    while (beg1 != end1 && is_space[end1[-1]]) end1--;
    while (beg2 != end2 && is_space[end2[-1]]) end2--;
  }
  while (beg1 != end1 && beg2 != end2) {
    if (is_space[*beg1] && is_space[*beg2]) {
      while (beg1 != end1 && is_space[*beg1]) beg1++;
      while (beg2 != end2 && is_space[*beg2]) beg2++;
    } else if (*beg1 == *beg2) {
      beg1++; beg2++;
    } else break;
  }
  return (beg1 != end1) || (beg2 != end2);
}
static DEFINITION *
collect_expansion(U_CHAR *buf, U_CHAR *end, int nargs, struct n64_tag_arglist *arglist) asm("_collect_expansion");
static DEFINITION *
collect_expansion(U_CHAR *buf, U_CHAR *end, int nargs, struct n64_tag_arglist *arglist)
{
  DEFINITION *defn;
  register U_CHAR *p, *limit, *lastp, *exp_p;
  struct n64_tag_reflist *endpat = 
                          ((void *)0)
                              ;

  U_CHAR *concat = 0;

  U_CHAR *stringify = 0;

  n64_enum_sharp_token_type concat_sharp_token_type = NO_SHARP_TOKEN;
  n64_enum_sharp_token_type stringify_sharp_token_type = NO_SHARP_TOKEN;
  int maxsize;
  int expected_delimiter = '\0';






  if (end < buf)
    abort ();


  limit = end;
  p = buf;
  while (p < limit && is_space[limit[-1]]) limit--;





  maxsize = (sizeof (DEFINITION)
      + (limit - p) + 3);
  defn = (DEFINITION *) xcalloc (1, maxsize);

  defn->nargs = nargs;
  exp_p = defn->expansion = (U_CHAR *) defn + sizeof (DEFINITION);
  lastp = exp_p;

  if (p[0] == '#'
      ? p[1] == '#'
      : p[0] == '%' && p[1] == ':' && p[2] == '%' && p[3] == ':') {
    error ("`##' at start of macro definition");
    p += p[0] == '#' ? 2 : 4;
  }


  while (p < limit) {
    int skipped_arg = 0;
    register U_CHAR c = *p++;

    *exp_p++ = c;

    if (!traditional) {
      switch (c) {
      case '\'':
      case '\"':
        if (expected_delimiter != '\0') {
          if (c == expected_delimiter)
            expected_delimiter = '\0';
        } else
          expected_delimiter = c;
 break;

      case '\\':
 if (p < limit && expected_delimiter) {


   *exp_p++ = *p++;
 }
 break;

      case '%':
 if (!expected_delimiter && *p == ':') {

   U_CHAR *p0 = p - 1;
   while (buf < p0 && p0[-1] == '<')
     p0--;
   if ((p - p0) & 1) {

     if (p[1] == '%' && p[2] == ':') {
       p += 2;
       goto sharp_sharp_token;
     }
     if (nargs >= 0) {
       p++;
       goto sharp_token;
     }
   }
 }
 break;

      case '#':

 if (expected_delimiter)
   break;
 if (*p == '#') {
 sharp_sharp_token:


   exp_p--;
   while (exp_p > lastp && is_hor_space[exp_p[-1]])
     --exp_p;

   p++;
   concat_sharp_token_type = c;
   if (is_hor_space[*p]) {
     concat_sharp_token_type = c + 1;
     p++;
     do { while (is_hor_space[*p]) p++; } while (0);
   }
   concat = p;
   if (p == limit)
     error ("`##' at end of macro definition");
 } else if (nargs >= 0) {


 sharp_token:
   exp_p--;
   stringify_sharp_token_type = c;
   if (is_hor_space[*p]) {
     stringify_sharp_token_type = c + 1;
     p++;
     do { while (is_hor_space[*p]) p++; } while (0);
   }
   if (! is_idstart[*p] || nargs == 0)
     error ("`#' operator is not followed by a macro argument name");
   else
     stringify = p;
 }
 break;
      }
    } else {




      switch (c) {
      case '\'':
      case '\"':
 if (expected_delimiter != '\0') {
   if (c == expected_delimiter)
     expected_delimiter = '\0';
 } else
   expected_delimiter = c;
 break;

      case '\\':

 if (expected_delimiter != 0 && p < limit
     && (*p == expected_delimiter || *p == '\\')) {
   *exp_p++ = *p++;
   continue;
 }
 break;

      case '/':
 if (expected_delimiter != '\0')
   break;
 if (*p == '*') {



   exp_p--;
   p += 1;
   while (p < limit && !(p[-2] == '*' && p[-1] == '/'))
     p++;




 }
 break;
      }
    }


    if (is_idchar[c] && nargs > 0) {
      U_CHAR *id_beg = p - 1;
      int id_len;

      --exp_p;
      while (p != limit && is_idchar[*p]) p++;
      id_len = p - id_beg;

      if (is_idstart[c]) {
 register struct n64_tag_arglist *arg;

 for (arg = arglist; arg != 
                           ((void *)0)
                               ; arg = arg->next) {
   struct n64_tag_reflist *tpat;

   if (arg->name[0] == c
       && arg->length == id_len
       && memcmp (arg->name,id_beg,id_len) == 0) {
     n64_enum_sharp_token_type tpat_stringify;
     if (expected_delimiter) {
       if (warn_stringify) {
  if (traditional) {
    warning ("macro argument `%.*s' is stringified.",
      id_len, arg->name);
  } else {
    warning ("macro arg `%.*s' would be stringified with -traditional.",
      id_len, arg->name);
  }
       }

       if (!traditional)
  break;
       tpat_stringify = SHARP_TOKEN;
     } else {
       tpat_stringify
  = (stringify == id_beg
     ? stringify_sharp_token_type : NO_SHARP_TOKEN);
     }


     tpat = (struct n64_tag_reflist *) xmalloc (sizeof (struct n64_tag_reflist));
     tpat->next = 
                 ((void *)0)
                     ;
     tpat->raw_before
       = concat == id_beg ? concat_sharp_token_type : NO_SHARP_TOKEN;
     tpat->raw_after = NO_SHARP_TOKEN;
     tpat->rest_args = arg->rest_args;
     tpat->stringify = tpat_stringify;

     if (endpat == 
                  ((void *)0)
                      )
       defn->pattern = tpat;
     else
       endpat->next = tpat;
     endpat = tpat;

     tpat->argno = arg->argno;
     tpat->nchars = exp_p - lastp;
     {
       register U_CHAR *p1 = p;
       do { while (is_hor_space[*p1]) p1++; } while (0);
       if (p1[0]=='#'
           ? p1[1]=='#'
    : p1[0]=='%' && p1[1]==':' && p1[2]=='%' && p1[3]==':')
  tpat->raw_after = p1[0] + (p != p1);
     }
     lastp = exp_p;
     skipped_arg = 1;
     break;
   }
 }
      }


      if (! skipped_arg) {
 register U_CHAR *lim1 = p;
 p = id_beg;
 while (p != lim1)
   *exp_p++ = *p++;
 if (stringify == id_beg)
   error ("`#' operator should be followed by a macro argument name");
      }
    }
  }

  if (!traditional && expected_delimiter == 0) {



    *exp_p++ = '\n';
    *exp_p++ = ' ';
  }

  *exp_p = '\0';

  defn->length = exp_p - defn->expansion;


  if (defn->length + 1 > maxsize)
    abort ();







  return defn;
}

static int
do_assert(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_assert");
static int
do_assert(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  U_CHAR *bp;
  U_CHAR *symname;
  int sym_length;
  struct n64_tag_arglist *tokens = 
                          ((void *)0)
                              ;

  if (pedantic && done_initializing && !instack[indepth].system_header_p)
    pedwarn ("ANSI C does not allow `#assert'");

  bp = buf;

  while (is_hor_space[*bp])
    bp++;

  symname = bp;
  sym_length = check_macro_name (bp, "assertion");
  bp += sym_length;

  do { while (is_hor_space[*bp]) bp++; } while (0);





  if (*bp != '(') {
    error ("missing token-sequence in `#assert'");
    return 1;
  }

  {
    int error_flag = 0;

    bp++;
    do { while (is_hor_space[*bp]) bp++; } while (0);

    tokens = read_token_list (&bp, limit, &error_flag);
    if (error_flag)
      return 1;
    if (tokens == 0) {
      error ("empty token-sequence in `#assert'");
      return 1;
    }

    ++bp;
    do { while (is_hor_space[*bp]) bp++; } while (0);
  }




  {
    ASSERTION_HASHNODE *hp;
    int hashcode = hashf (symname, sym_length, 37);
    struct n64_tag_tokenlist_list *value
      = (struct n64_tag_tokenlist_list *) xmalloc (sizeof (struct n64_tag_tokenlist_list));

    hp = assertion_lookup (symname, sym_length, hashcode);
    if (hp == 
             ((void *)0)
                 ) {
      if (sym_length == 7 && ! memcmp (symname,"defined",7))
 error ("`defined' redefined as assertion");
      hp = assertion_install (symname, sym_length, hashcode);
    }


    value->tokens = tokens;
    value->next = hp->value;
    hp->value = value;
  }

  return 0;
}

static int
do_unassert(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_unassert");
static int
do_unassert(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  U_CHAR *bp;
  U_CHAR *symname;
  int sym_length;

  struct n64_tag_arglist *tokens = 
                          ((void *)0)
                              ;
  int tokens_specified = 0;

  if (pedantic && done_initializing && !instack[indepth].system_header_p)
    pedwarn ("ANSI C does not allow `#unassert'");

  bp = buf;

  while (is_hor_space[*bp])
    bp++;

  symname = bp;
  sym_length = check_macro_name (bp, "assertion");
  bp += sym_length;

  do { while (is_hor_space[*bp]) bp++; } while (0);





  if (*bp == '(') {
    int error_flag = 0;

    bp++;
    do { while (is_hor_space[*bp]) bp++; } while (0);

    tokens = read_token_list (&bp, limit, &error_flag);
    if (error_flag)
      return 1;
    if (tokens == 0) {
      error ("empty token list in `#unassert'");
      return 1;
    }

    tokens_specified = 1;

    ++bp;
    do { while (is_hor_space[*bp]) bp++; } while (0);
  }

  {
    ASSERTION_HASHNODE *hp;
    int hashcode = hashf (symname, sym_length, 37);
    struct n64_tag_tokenlist_list *tail, *prev;

    hp = assertion_lookup (symname, sym_length, hashcode);
    if (hp == 
             ((void *)0)
                 )
      return 1;



    if (! tokens_specified) {
      struct n64_tag_tokenlist_list *next;
      for (tail = hp->value; tail; tail = next) {
 next = tail->next;
 free_token_list (tail->tokens);
 free (tail);
      }
      delete_assertion (hp);
    } else {


      tail = hp->value;
      prev = 0;
      while (tail) {
 struct n64_tag_tokenlist_list *next = tail->next;
 if (compare_token_lists (tail->tokens, tokens)) {
   if (prev)
     prev->next = next;
   else
     hp->value = tail->next;
   free_token_list (tail->tokens);
   free (tail);
 } else {
   prev = tail;
 }
 tail = next;
      }
    }
  }

  return 0;
}






int
check_assertion(U_CHAR *name, int sym_length, int tokens_specified, struct n64_tag_arglist *tokens) asm("_check_assertion");
int
check_assertion(U_CHAR *name, int sym_length, int tokens_specified, struct n64_tag_arglist *tokens)
{
  ASSERTION_HASHNODE *hp;
  int hashcode = hashf (name, sym_length, 37);

  if (pedantic && !instack[indepth].system_header_p)
    pedwarn ("ANSI C does not allow testing assertions");

  hp = assertion_lookup (name, sym_length, hashcode);
  if (hp == 
           ((void *)0)
               )

    return 0;


  if (! tokens_specified)
    return 1;

  {
    struct n64_tag_tokenlist_list *tail;

    tail = hp->value;




    while (tail) {
      if (compare_token_lists (tail->tokens, tokens))
 return 1;
      tail = tail->next;
    }


    return 0;
  }
}



static int
compare_token_lists(struct n64_tag_arglist *l1, struct n64_tag_arglist *l2) asm("_compare_token_lists");
static int
compare_token_lists(struct n64_tag_arglist *l1, struct n64_tag_arglist *l2)
{
  while (l1 && l2) {
    if (l1->length != l2->length)
      return 0;
    if (memcmp (l1->name,l2->name,l1->length))
      return 0;
    l1 = l1->next;
    l2 = l2->next;
  }


  return l1 == l2;
}







static struct n64_tag_arglist *
read_token_list(U_CHAR **bpp, U_CHAR *limit, int *error_flag) asm("_read_token_list");
static struct n64_tag_arglist *
read_token_list(U_CHAR **bpp, U_CHAR *limit, int *error_flag)
{
  struct n64_tag_arglist *token_ptrs = 0;
  U_CHAR *bp = *bpp;
  int depth = 1;

  *error_flag = 0;


  while (depth > 0) {
    struct n64_tag_arglist *temp;
    int eofp = 0;
    U_CHAR *beg = bp;


    if (*bp == '(') {
      bp++;
      depth++;
    } else if (*bp == ')') {
      depth--;
      if (depth == 0)
 break;
      bp++;
    } else if (*bp == '"' || *bp == '\'')
      bp = skip_quoted_string (bp, limit, 0, ((void *)0), ((void *)0), &eofp);
    else
      while (! is_hor_space[*bp] && *bp != '(' && *bp != ')'
      && *bp != '"' && *bp != '\'' && bp != limit)
 bp++;

    temp = (struct n64_tag_arglist *) xmalloc (sizeof (struct n64_tag_arglist));
    temp->name = (U_CHAR *) xmalloc (bp - beg + 1);
    memcpy ((char *) temp->name,(char *) beg,bp - beg);
    temp->name[bp - beg] = 0;
    temp->next = token_ptrs;
    token_ptrs = temp;
    temp->length = bp - beg;

    do { while (is_hor_space[*bp]) bp++; } while (0);

    if (bp >= limit) {
      error ("unterminated token sequence in `#assert' or `#unassert'");
      *error_flag = -1;
      return 0;
    }
  }
  *bpp = bp;



  {
    register struct n64_tag_arglist *prev = 0, *cxx_this, *next;
    for (cxx_this = token_ptrs; cxx_this; cxx_this = next) {
      next = cxx_this->next;
      cxx_this->next = prev;
      prev = cxx_this;
    }
    return prev;
  }
}

static void
free_token_list(struct n64_tag_arglist *tokens) asm("_free_token_list");
static void
free_token_list(struct n64_tag_arglist *tokens)
{
  while (tokens) {
    struct n64_tag_arglist *next = tokens->next;
    free (tokens->name);
    free (tokens);
    tokens = next;
  }
}
static ASSERTION_HASHNODE *
assertion_install(U_CHAR *name, int len, int hash) asm("_assertion_install");
static ASSERTION_HASHNODE *
assertion_install(U_CHAR *name, int len, int hash)
{
  register ASSERTION_HASHNODE *hp;
  register int i, bucket;
  register U_CHAR *p, *q;

  i = sizeof (ASSERTION_HASHNODE) + len + 1;
  hp = (ASSERTION_HASHNODE *) xmalloc (i);
  bucket = hash;
  hp->bucket_hdr = &assertion_hashtab[bucket];
  hp->next = assertion_hashtab[bucket];
  assertion_hashtab[bucket] = hp;
  hp->prev = 
            ((void *)0)
                ;
  if (hp->next != 
                 ((void *)0)
                     )
    hp->next->prev = hp;
  hp->length = len;
  hp->value = 0;
  hp->name = ((U_CHAR *) hp) + sizeof (ASSERTION_HASHNODE);
  p = hp->name;
  q = name;
  for (i = 0; i < len; i++)
    *p++ = *q++;
  hp->name[len] = 0;
  return hp;
}
static ASSERTION_HASHNODE *
assertion_lookup(U_CHAR *name, int len, int hash) asm("_assertion_lookup");
static ASSERTION_HASHNODE *
assertion_lookup(U_CHAR *name, int len, int hash)
{
  register ASSERTION_HASHNODE *bucket;

  bucket = assertion_hashtab[hash];
  while (bucket) {
    if (bucket->length == len && memcmp (bucket->name,name,len) == 0)
      return bucket;
    bucket = bucket->next;
  }
  return 
        ((void *)0)
            ;
}

static void
delete_assertion(ASSERTION_HASHNODE *hp) asm("_delete_assertion");
static void
delete_assertion(ASSERTION_HASHNODE *hp)
{

  if (hp->prev != 
                 ((void *)0)
                     )
    hp->prev->next = hp->next;
  if (hp->next != 
                 ((void *)0)
                     )
    hp->next->prev = hp->prev;



  if (hp == *hp->bucket_hdr)
    *hp->bucket_hdr = hp->next;

  free (hp);
}







static int
do_line(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_line");
static int
do_line(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  register U_CHAR *bp;
  FILE_BUF *ip = &instack[indepth];
  FILE_BUF tem;
  int new_lineno;
  n64_enum_file_change_code file_change = same_file;


  tem = expand_to_temp_buffer (buf, limit, 0, 0);


  bp = tem.buf;
  do { while (is_hor_space[*bp]) bp++; } while (0);

  if (!isdigit (*bp)) {
    error ("invalid format `#line' directive");
    return 0;
  }




  new_lineno = atoi ((char *) bp) - 1;


  if (pedantic && new_lineno < 0)
    pedwarn ("line number out of range in `#line' directive");


  while (isdigit (*bp))
    bp++;
  do { while (is_hor_space[*bp]) bp++; } while (0);

  if (*bp == '\"') {
    static HASHNODE *fname_table[37];
    HASHNODE *hp, **hash_bucket;
    U_CHAR *fname, *p;
    int fname_length;

    fname = ++bp;



    p = bp;
    for (;;)
      switch ((*p++ = *bp++)) {
      case '\0':
 error ("invalid format `#line' directive");
 return 0;

      case '\\':
 {
   char *bpc = (char *) bp;
   int c = parse_escape (&bpc);
   bp = (U_CHAR *) bpc;
   if (c < 0)
     p--;
   else
     p[-1] = c;
 }
 break;

      case '\"':
 p[-1] = 0;
 goto fname_done;
      }
  fname_done:
    fname_length = p - fname;

    do { while (is_hor_space[*bp]) bp++; } while (0);
    if (*bp) {
      if (pedantic)
 pedwarn ("garbage at end of `#line' directive");
      if (*bp == '1')
 file_change = enter_file;
      else if (*bp == '2')
 file_change = leave_file;
      else if (*bp == '3')
 ip->system_header_p = 1;
      else if (*bp == '4')
 ip->system_header_p = 2;
      else {
 error ("invalid format `#line' directive");
 return 0;
      }

      bp++;
      do { while (is_hor_space[*bp]) bp++; } while (0);
      if (*bp == '3') {
 ip->system_header_p = 1;
 bp++;
 do { while (is_hor_space[*bp]) bp++; } while (0);
      }
      if (*bp == '4') {
 ip->system_header_p = 2;
 bp++;
 do { while (is_hor_space[*bp]) bp++; } while (0);
      }
      if (*bp) {
 error ("invalid format `#line' directive");
 return 0;
      }
    }

    hash_bucket =
      &fname_table[hashf (fname, fname_length, 37)];
    for (hp = *hash_bucket; hp != 
                                 ((void *)0)
                                     ; hp = hp->next)
      if (hp->length == fname_length &&
   memcmp (hp->value.cpval,fname,fname_length) == 0) {
 ip->nominal_fname = hp->value.cpval;
 break;
      }
    if (hp == 0) {

      hp = (HASHNODE *) xcalloc (1, sizeof (HASHNODE) + fname_length + 1);
      hp->next = *hash_bucket;
      *hash_bucket = hp;

      hp->length = fname_length;
      ip->nominal_fname = hp->value.cpval = ((char *) hp) + sizeof (HASHNODE);
      memcpy (hp->value.cpval,fname,fname_length);
    }
  } else if (*bp) {
    error ("invalid format `#line' directive");
    return 0;
  }

  ip->lineno = new_lineno;
  output_line_directive (ip, op, 0, file_change);
  (((op)->length - ((op)->bufp - (op)->buf) <= (ip->length - (ip->bufp - ip->buf))) ? grow_outbuf ((op), (ip->length - (ip->bufp - ip->buf))) : 0);
  return 0;
}







static int
do_undef(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_undef");
static int
do_undef(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int sym_length;
  HASHNODE *hp;
  U_CHAR *orig_buf = buf;


  if (pcp_outfile && op)
    pass_thru_directive (buf, limit, op, keyword);

  do { while (is_hor_space[*buf]) buf++; } while (0);
  sym_length = check_macro_name (buf, "macro");

  while ((hp = lookup (buf, sym_length, -1)) != 
                                               ((void *)0)
                                                   ) {


    if (debug_output && op)
      pass_thru_directive (orig_buf, limit, op, keyword);
    if (hp->type != T_MACRO)
      warning ("undefining `%s'", hp->name);
    delete_macro (hp);
  }

  if (pedantic) {
    buf += sym_length;
    do { while (is_hor_space[*buf]) buf++; } while (0);
    if (buf != limit)
      pedwarn ("garbage after `#undef' directive");
  }
  return 0;
}







static int
do_error(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_error");
static int
do_error(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int length = limit - buf;
  U_CHAR *copy = (U_CHAR *) xmalloc (length + 1);
  memcpy ((char *) copy,(char *) buf,length);
  copy[length] = 0;
  do { while (is_hor_space[*copy]) copy++; } while (0);
  error ("#error %s", copy);
  return 0;
}







static int
do_warning(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_warning");
static int
do_warning(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int length = limit - buf;
  U_CHAR *copy = (U_CHAR *) xmalloc (length + 1);
  memcpy ((char *) copy,(char *) buf,length);
  copy[length] = 0;
  do { while (is_hor_space[*copy]) copy++; } while (0);
  warning ("#warning %s", copy);
  return 0;
}




static void
do_once(void) asm("_do_once");
static void
do_once(void)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               ) {
    struct n64_tag_file_name_list *cxx_new;

    cxx_new = (struct n64_tag_file_name_list *) xmalloc (sizeof (struct n64_tag_file_name_list));
    cxx_new->next = dont_repeat_files;
    dont_repeat_files = cxx_new;
    cxx_new->fname = savestring (ip->fname);
    cxx_new->control_macro = 0;
    cxx_new->got_name_map = 0;
    cxx_new->c_system_include_path = 0;
  }
}



static int
do_ident(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_ident");
static int
do_ident(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  FILE_BUF trybuf;
  int len;


  if (pedantic && !instack[indepth].system_header_p)
    pedwarn ("ANSI C does not allow `#ident'");

  trybuf = expand_to_temp_buffer (buf, limit, 0, 0);
  buf = (U_CHAR *) 
                  __builtin_alloca((
                  trybuf.bufp - trybuf.buf + 1
                  ))
                                                       ;
  memcpy ((char *) buf,(char *) trybuf.buf,trybuf.bufp - trybuf.buf);
  limit = buf + (trybuf.bufp - trybuf.buf);
  len = (limit - buf);
  free (trybuf.buf);


  (((op)->length - ((op)->bufp - (op)->buf) <= (7)) ? grow_outbuf ((op), (7)) : 0);
  memcpy ((char *) op->bufp,"#ident ",7);
  op->bufp += 7;


  (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
  memcpy ((char *) op->bufp,(char *) buf,len);
  op->bufp += len;

  return 0;
}




static int
do_pragma(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_pragma");
static int
do_pragma(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  do { while (is_hor_space[*buf]) buf++; } while (0);
  if (!strncmp ((char *) buf, "once", 4)) {


    if (!instack[indepth].system_header_p)
      warning ("`#pragma once' is obsolete");
    do_once ();
  }

  if (!strncmp ((char *) buf, "implementation", 14)) {


    struct n64_tag_file_name_list *ptr;
    U_CHAR *p = buf + 14, *fname, *inc_fname;
    do { while (is_hor_space[*p]) p++; } while (0);
    if (*p == '\n' || *p != '\"')
      return 0;

    fname = p + 1;
    if ((p = (U_CHAR *) strchr ((char *) fname, '\"')))
      *p = '\0';

    for (ptr = all_include_files; ptr; ptr = ptr->next) {
      inc_fname = (U_CHAR *) strrchr (ptr->fname, '/');
      inc_fname = inc_fname ? inc_fname + 1 : (U_CHAR *) ptr->fname;
      if (inc_fname && !strcmp ((char *) inc_fname, (char *) fname))
 warning ("`#pragma implementation' for `%s' appears after file is included",
   fname);
    }
  }

  return 0;
}
static int
do_sccs(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_sccs");
static int
do_sccs(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  if (pedantic)
    pedwarn ("ANSI C does not allow `#sccs'");
  return 0;
}
static int
do_if(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_if");
static int
do_if(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int value;
  FILE_BUF *ip = &instack[indepth];

  value = eval_if_expression (buf, limit - buf);
  conditional_skip (ip, value == 0, T_IF, ((void *)0), op);
  return 0;
}






static int
do_elif(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_elif");
static int
do_elif(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int value;
  FILE_BUF *ip = &instack[indepth];

  if (if_stack == instack[indepth].if_stack) {
    error ("`#elif' not within a conditional");
    return 0;
  } else {
    if (if_stack->type != T_IF && if_stack->type != T_ELIF) {
      error ("`#elif' after `#else'");
      fprintf (
              (__acrt_iob_func(2))
                    , " (matches line %d", if_stack->lineno);
      if (if_stack->fname != 
                            ((void *)0) 
                                 && ip->fname != 
                                                 ((void *)0) 
                                                      &&
   strcmp (if_stack->fname, ip->nominal_fname) != 0)
 fprintf (
         (__acrt_iob_func(2))
               , ", file %s", if_stack->fname);
      fprintf (
              (__acrt_iob_func(2))
                    , ")\n");
    }
    if_stack->type = T_ELIF;
  }

  if (if_stack->if_succeeded)
    skip_if_group (ip, 0, op);
  else {
    value = eval_if_expression (buf, limit - buf);
    if (value == 0)
      skip_if_group (ip, 0, op);
    else {
      ++if_stack->if_succeeded;
      output_line_directive (ip, op, 1, same_file);
    }
  }
  return 0;
}





static int
eval_if_expression(U_CHAR *buf, int length) asm("_eval_if_expression");
static int
eval_if_expression(U_CHAR *buf, int length)
{
  FILE_BUF temp_obuf;
  HASHNODE *save_defined;
  int value;

  save_defined = install ((U_CHAR *) "defined", -1, T_SPEC_DEFINED,
     ((void *)0), -1);
  pcp_inside_if = 1;
  temp_obuf = expand_to_temp_buffer (buf, buf + length, 0, 1);
  pcp_inside_if = 0;
  delete_macro (save_defined);

  value = parse_c_expression ((char *) temp_obuf.buf);

  free (temp_obuf.buf);

  return value;
}







static int
do_xifdef(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_xifdef");
static int
do_xifdef(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  int skip;
  FILE_BUF *ip = &instack[indepth];
  U_CHAR *end;
  int start_of_file = 0;
  U_CHAR *control_macro = 0;


  if (ip->fname != 0 && keyword->type == T_IFNDEF) {
    U_CHAR *p = ip->buf;
    while (p != directive_start) {
      U_CHAR c = *p++;
      if (is_space[c])
 ;



      else if (c == '/'
        && (*p == '*' || (cplusplus_comments && *p == '/'))) {

 int junk = 0;
 U_CHAR *save_bufp = ip->bufp;
 ip->bufp = p + 1;
 p = skip_to_end_of_comment (ip, &junk, 1);
 ip->bufp = save_bufp;
      } else {
 goto fail;
      }
    }

    start_of_file = 1;
  fail: ;
  }


  do { while (is_hor_space[*buf]) buf++; } while (0);
  while (limit != buf && is_hor_space[limit[-1]]) limit--;


  for (end = buf; is_idchar[*end]; end++);

  if (end == buf) {
    skip = (keyword->type == T_IFDEF);
    if (! traditional)
      pedwarn (end == limit ? "`#%s' with no argument"
        : "`#%s' argument starts with punctuation",
        keyword->name);
  } else {
    HASHNODE *hp;

    if (pedantic && buf[0] >= '0' && buf[0] <= '9')
      pedwarn ("`#%s' argument starts with a digit", keyword->name);
    else if (end != limit && !traditional)
      pedwarn ("garbage at end of `#%s' argument", keyword->name);

    hp = lookup (buf, end-buf, -1);

    if (pcp_outfile) {

      if (hp &&
   (hp->type == T_CONST
    || (hp->type == T_MACRO && hp->value.defn->predefined)))
 fprintf (pcp_outfile, "#define %s\n", hp->name);
      else {
 U_CHAR *cp = buf;
 fprintf (pcp_outfile, "#undef ");
 while (is_idchar[*cp])
   fputc (*cp++, pcp_outfile);
 putc ('\n', pcp_outfile);
      }
    }

    skip = (hp == 
                 ((void *)0)
                     ) ^ (keyword->type == T_IFNDEF);
    if (start_of_file && !skip) {
      control_macro = (U_CHAR *) xmalloc (end - buf + 1);
      memcpy ((char *) control_macro,(char *) buf,end - buf);
      control_macro[end - buf] = 0;
    }
  }

  conditional_skip (ip, skip, T_IF, control_macro, op);
  return 0;
}






static void
conditional_skip(FILE_BUF *ip, int skip, n64_enum_node_type type, U_CHAR *control_macro, FILE_BUF *op) asm("_conditional_skip");
static void
conditional_skip(FILE_BUF *ip, int skip, n64_enum_node_type type, U_CHAR *control_macro, FILE_BUF *op)
{
  IF_STACK_FRAME *temp;

  temp = (IF_STACK_FRAME *) xcalloc (1, sizeof (IF_STACK_FRAME));
  temp->fname = ip->nominal_fname;
  temp->lineno = ip->lineno;
  temp->next = if_stack;
  temp->control_macro = control_macro;
  if_stack = temp;

  if_stack->type = type;

  if (skip != 0) {
    skip_if_group (ip, 0, op);
    return;
  } else {
    ++if_stack->if_succeeded;
    output_line_directive (ip, &outbuf, 1, same_file);
  }
}






static void
skip_if_group(FILE_BUF *ip, int any, FILE_BUF *op) asm("_skip_if_group");
static void
skip_if_group(FILE_BUF *ip, int any, FILE_BUF *op)
{
  register U_CHAR *bp = ip->bufp, *cp;
  register U_CHAR *endb = ip->buf + ip->length;
  struct n64_tag_directive *kt;
  IF_STACK_FRAME *save_if_stack = if_stack;
  U_CHAR *beg_of_line = bp;
  register int ident_length;
  U_CHAR *ident, *after_ident;

  U_CHAR *beg_of_group = bp;
  int beg_lineno = ip->lineno;

  if (output_conditionals && op != 0) {
    char *ptr = "#failed\n";
    int len = strlen (ptr);

    if (op->bufp > op->buf && op->bufp[-1] != '\n')
      {
 *op->bufp++ = '\n';
 op->lineno++;
      }
    (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
    memcpy ((char *) op->bufp,ptr,len);
    op->bufp += len;
    op->lineno++;
    output_line_directive (ip, op, 1, 0);
  }

  while (bp < endb) {
    switch (*bp++) {
    case '/':
      if (*bp == '\\' && bp[1] == '\n')
 newline_fix (bp);
      if (*bp == '*'
   || (cplusplus_comments && *bp == '/')) {
 ip->bufp = ++bp;
 bp = skip_to_end_of_comment (ip, &ip->lineno, 0);
      }
      break;
    case '\"':
    case '\'':
      bp = skip_quoted_string (bp - 1, endb, ip->lineno, &ip->lineno,
          ((void *)0), ((void *)0));
      break;
    case '\\':

      if (bp < endb) {
 if (*bp == '\n')
   ++ip->lineno;
 bp++;
      }
      break;
    case '\n':
      ++ip->lineno;
      beg_of_line = bp;
      break;
    case '%':
      if (beg_of_line == 0 || traditional)
 break;
      ip->bufp = bp - 1;
      while (bp[0] == '\\' && bp[1] == '\n')
 bp += 2;
      if (*bp == ':')
 goto sharp_token;
      break;
    case '#':

      if (beg_of_line == 0)
 break;
      ip->bufp = bp - 1;
    sharp_token:



      bp = beg_of_line;

      if (!traditional) {
 while (1) {
   if (is_hor_space[*bp])
     bp++;
   else if (*bp == '\\' && bp[1] == '\n')
     bp += 2;
   else if (*bp == '/' && bp[1] == '*') {
     bp += 2;
     while (!(*bp == '*' && bp[1] == '/'))
       bp++;
     bp += 2;
   }



   else break;
 }
      }
      if (bp != ip->bufp) {
 bp = ip->bufp + 1;
 break;
      }

      bp = ip->bufp + 1;
      if (ip->bufp[0] == '%') {

 while (*bp == '\\') {
   ip->lineno++;
   bp += 2;
 }
 bp++;
      }


      while (1) {
 if (is_hor_space[*bp])
   bp++;
 else if (*bp == '\\' && bp[1] == '\n')
   bp += 2;
 else if (*bp == '/' && bp[1] == '*') {
   bp += 2;
   while (!(*bp == '*' && bp[1] == '/')) {
     if (*bp == '\n')
       ip->lineno++;
     bp++;
   }
   bp += 2;
 } else if (cplusplus_comments && *bp == '/' && bp[1] == '/') {
   bp += 2;
   while (bp[-1] == '\\' || *bp != '\n') {
     if (*bp == '\n')
       ip->lineno++;
     bp++;
   }
        }
 else break;
      }

      cp = bp;





      while (1) {
 if (is_idchar[*bp])
   bp++;
 else {
   if (*bp == '\\' && bp[1] == '\n')
     name_newline_fix (bp);
   if (is_idchar[*bp])
     bp++;
   else break;
 }
      }
      ident_length = bp - cp;
      ident = cp;
      after_ident = bp;



      if (ident_length == 0 && *after_ident == '\n') {
 continue;
      }

      if (ident_length == 0 || !is_idstart[*ident]) {
 U_CHAR *p = ident;
 while (is_idchar[*p]) {
   if (*p < '0' || *p > '9')
     break;
   p++;
 }

 if (p != ident && !is_idchar[*p]) {
   if (pedantic)
     pedwarn ("`#' followed by integer");
   continue;
 }


 if (p == ident) {
   while (*p == '#' || is_hor_space[*p]) p++;
   if (*p == '\n') {
     if (pedantic && !lang_asm)
       pedwarn ("invalid preprocessing directive");
     continue;
   }
 }

 if (!lang_asm && pedantic)
   pedwarn ("invalid preprocessing directive name");
 continue;
      }

      for (kt = directive_table; kt->length >= 0; kt++) {
 IF_STACK_FRAME *temp;
 if (ident_length == kt->length
     && memcmp (cp,kt->name,kt->length) == 0) {

   if (any)
     goto done;

   switch (kt->type) {
   case T_IF:
   case T_IFDEF:
   case T_IFNDEF:
     temp = (IF_STACK_FRAME *) xcalloc (1, sizeof (IF_STACK_FRAME));
     temp->next = if_stack;
     if_stack = temp;
     temp->lineno = ip->lineno;
     temp->fname = ip->nominal_fname;
     temp->type = kt->type;
     break;
   case T_ELSE:
   case T_ENDIF:
     if (pedantic && if_stack != save_if_stack)
       validate_else (bp);
   case T_ELIF:
     if (if_stack == instack[indepth].if_stack) {
       error ("`#%s' not within a conditional", kt->name);
       break;
     }
     else if (if_stack == save_if_stack)
       goto done;

     if (kt->type != T_ENDIF) {
       if (if_stack->type == T_ELSE)
  error ("`#else' or `#elif' after `#else'");
       if_stack->type = kt->type;
       break;
     }

     temp = if_stack;
     if_stack = if_stack->next;
     free (temp);
     break;

    default:
     break;
   }
   break;
 }
      }

      if (kt->length < 0 && !lang_asm && pedantic)
 pedwarn ("invalid preprocessing directive name");
    }
  }

  ip->bufp = bp;




 done:
  if (output_conditionals && op != 0) {
    char *ptr = "#endfailed\n";
    int len = strlen (ptr);

    if (op->bufp > op->buf && op->bufp[-1] != '\n')
      {
 *op->bufp++ = '\n';
 op->lineno++;
      }
    (((op)->length - ((op)->bufp - (op)->buf) <= (beg_of_line - beg_of_group)) ? grow_outbuf ((op), (beg_of_line - beg_of_group)) : 0);
    memcpy ((char *) op->bufp,(char *) beg_of_group,beg_of_line - beg_of_group)
                               ;
    op->bufp += beg_of_line - beg_of_group;
    op->lineno += ip->lineno - beg_lineno;
    (((op)->length - ((op)->bufp - (op)->buf) <= (len)) ? grow_outbuf ((op), (len)) : 0);
    memcpy ((char *) op->bufp,ptr,len);
    op->bufp += len;
    op->lineno++;
  }
}
static int
do_else(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_else");
static int
do_else(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  FILE_BUF *ip = &instack[indepth];

  if (pedantic) {
    do { while (is_hor_space[*buf]) buf++; } while (0);
    if (buf != limit)
      pedwarn ("text following `#else' violates ANSI standard");
  }

  if (if_stack == instack[indepth].if_stack) {
    error ("`#else' not within a conditional");
    return 0;
  } else {


    if_stack->control_macro = 0;

    if (if_stack->type != T_IF && if_stack->type != T_ELIF) {
      error ("`#else' after `#else'");
      fprintf (
              (__acrt_iob_func(2))
                    , " (matches line %d", if_stack->lineno);
      if (strcmp (if_stack->fname, ip->nominal_fname) != 0)
 fprintf (
         (__acrt_iob_func(2))
               , ", file %s", if_stack->fname);
      fprintf (
              (__acrt_iob_func(2))
                    , ")\n");
    }
    if_stack->type = T_ELSE;
  }

  if (if_stack->if_succeeded)
    skip_if_group (ip, 0, op);
  else {
    ++if_stack->if_succeeded;
    output_line_directive (ip, op, 1, same_file);
  }
  return 0;
}





static int
do_endif(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword) asm("_do_endif");
static int
do_endif(U_CHAR *buf, U_CHAR *limit, FILE_BUF *op, struct n64_tag_directive *keyword)
{
  if (pedantic) {
    do { while (is_hor_space[*buf]) buf++; } while (0);
    if (buf != limit)
      pedwarn ("text following `#endif' violates ANSI standard");
  }

  if (if_stack == instack[indepth].if_stack)
    error ("unbalanced `#endif'");
  else {
    IF_STACK_FRAME *temp = if_stack;
    if_stack = if_stack->next;
    if (temp->control_macro != 0) {


      FILE_BUF *ip = &instack[indepth];
      U_CHAR *p = ip->bufp;
      U_CHAR *ep = ip->buf + ip->length;

      while (p != ep) {
 U_CHAR c = *p++;
 if (!is_space[c]) {
   if (c == '/'
       && (*p == '*' || (cplusplus_comments && *p == '/'))) {

     int junk = 0;
     U_CHAR *save_bufp = ip->bufp;
     ip->bufp = p + 1;
     p = skip_to_end_of_comment (ip, &junk, 1);
     ip->bufp = save_bufp;
   } else
     goto fail;
 }
      }







      if (indepth != 0
   && ! (indepth == 1 && no_record_file)
   && ! (no_record_file && no_output))
 record_control_macro (ip->fname, temp->control_macro);
    fail: ;
    }
    free (temp);
    output_line_directive (&instack[indepth], op, 1, same_file);
  }
  return 0;
}





static void
validate_else(register U_CHAR *p) asm("_validate_else");
static void
validate_else(register U_CHAR *p)
{

  while (1) {
    if (*p == '\\' && p[1] == '\n')
      p += 2;
    if (is_hor_space[*p])
      p++;
    else if (*p == '/') {
      if (p[1] == '\\' && p[2] == '\n')
 newline_fix (p + 1);
      if (p[1] == '*') {
 p += 2;


 while (*p) {
   if (p[1] == '\\' && p[2] == '\n')
     newline_fix (p + 1);
   if (*p == '*' && p[1] == '/') {
     p += 2;
     break;
   }
   p++;
 }
      }
      else if (cplusplus_comments && p[1] == '/') {
 p += 2;
 while (*p && (*p != '\n' || p[-1] == '\\'))
   p++;
      }
    } else break;
  }
  if (*p && *p != '\n')
    pedwarn ("text following `#else' or `#endif' violates ANSI standard");
}
static U_CHAR *
skip_to_end_of_comment(register FILE_BUF *ip, int *line_counter, int nowarn) asm("_skip_to_end_of_comment");
static U_CHAR *
skip_to_end_of_comment(register FILE_BUF *ip, int *line_counter, int nowarn)
{
  register U_CHAR *limit = ip->buf + ip->length;
  register U_CHAR *bp = ip->bufp;
  FILE_BUF *op = &outbuf;
  int output = put_out_comments && !line_counter;
  int start_line = line_counter ? *line_counter : 0;




  if (output) {
    *op->bufp++ = '/';
    *op->bufp++ = '*';
  }
  if (cplusplus_comments && bp[-1] == '/') {
    if (output) {
      while (bp < limit) {
 *op->bufp++ = *bp;
 if (*bp == '\n' && bp[-1] != '\\')
   break;
 if (*bp == '\n') {
   ++*line_counter;
   ++op->lineno;
 }
 bp++;
      }
      op->bufp[-1] = '*';
      *op->bufp++ = '/';
      *op->bufp++ = '\n';
    } else {
      while (bp < limit) {
 if (bp[-1] != '\\' && *bp == '\n') {
   break;
 } else {
   if (*bp == '\n' && line_counter)
     ++*line_counter;
   bp++;
 }
      }
    }
    ip->bufp = bp;
    return bp;
  }
  while (bp < limit) {
    if (output)
      *op->bufp++ = *bp;
    switch (*bp++) {
    case '/':
      if (warn_comments && !nowarn && bp < limit && *bp == '*')
 warning ("`/*' within comment");
      break;
    case '\n':



      if (bp == limit)
 {
   --bp;
   --limit;
   break;
 }
      if (line_counter != 
                         ((void *)0)
                             )
 ++*line_counter;
      if (output)
 ++op->lineno;
      break;
    case '*':
      if (*bp == '\\' && bp[1] == '\n')
 newline_fix (bp);
      if (*bp == '/') {
        if (output)
   *op->bufp++ = '/';
 ip->bufp = ++bp;
 return bp;
      }
      break;
    }
  }

  if (!nowarn)
    error_with_line (line_for_error (start_line), "unterminated comment");
  ip->bufp = bp;
  return bp;
}
static U_CHAR *
skip_quoted_string(register U_CHAR *bp, register U_CHAR *limit, int start_line, int *count_newlines, int *backslash_newlines_p, int *eofp) asm("_skip_quoted_string");
static U_CHAR *
skip_quoted_string(register U_CHAR *bp, register U_CHAR *limit, int start_line, int *count_newlines, int *backslash_newlines_p, int *eofp)
{
  register U_CHAR c, match;

  match = *bp++;
  while (1) {
    if (bp >= limit) {
      error_with_line (line_for_error (start_line),
         "unterminated string or character constant");
      error_with_line (multiline_string_line,
         "possible real start of unterminated constant");
      multiline_string_line = 0;
      if (eofp)
 *eofp = 1;
      break;
    }
    c = *bp++;
    if (c == '\\') {
      while (*bp == '\\' && bp[1] == '\n') {
 if (backslash_newlines_p)
   *backslash_newlines_p = 1;
 if (count_newlines)
   ++*count_newlines;
 bp += 2;
      }
      if (*bp == '\n' && count_newlines) {
 if (backslash_newlines_p)
   *backslash_newlines_p = 1;
 ++*count_newlines;
      }
      bp++;
    } else if (c == '\n') {
      if (traditional) {

  bp--;
  if (eofp)
    *eofp = 1;
  break;
      }
      if (pedantic || match == '\'') {
 error_with_line (line_for_error (start_line),
    "unterminated string or character constant");
 bp--;
 if (eofp)
   *eofp = 1;
 break;
      }

      if (count_newlines)
 ++*count_newlines;
      if (multiline_string_line == 0)
 multiline_string_line = start_line;
    } else if (c == match)
      break;
  }
  return bp;
}



static char *
quote_string(char *dst, char *src) asm("_quote_string");
static char *
quote_string(char *dst, char *src)
{
  U_CHAR c;

  *dst++ = '\"';
  for (;;)
    switch ((c = *src++))
      {
      default:
        if (isprint (c))
   *dst++ = c;
 else
   {
     sprintf (dst, "\\%03o", c);
     dst += 4;
   }
 break;

      case '\"':
      case '\\':
 *dst++ = '\\';
 *dst++ = c;
 break;

      case '\0':
 *dst++ = '\"';
 *dst = '\0';
 return dst;
      }
}







static U_CHAR *
skip_paren_group(register FILE_BUF *ip) asm("_skip_paren_group");
static U_CHAR *
skip_paren_group(register FILE_BUF *ip)
{
  U_CHAR *limit = ip->buf + ip->length;
  U_CHAR *p = ip->bufp;
  int depth = 0;
  int lines_dummy = 0;

  while (p != limit) {
    int c = *p++;
    switch (c) {
    case '(':
      depth++;
      break;

    case ')':
      depth--;
      if (depth == 0)
 return ip->bufp = p;
      break;

    case '/':
      if (*p == '*') {
 ip->bufp = p;
 p = skip_to_end_of_comment (ip, &lines_dummy, 0);
 p = ip->bufp;
      }

    case '"':
    case '\'':
      {
 int eofp = 0;
 p = skip_quoted_string (p - 1, limit, 0, ((void *)0), ((void *)0), &eofp);
 if (eofp)
   return ip->bufp = p;
      }
      break;
    }
  }

  ip->bufp = p;
  return p;
}
static void
output_line_directive(FILE_BUF *ip, FILE_BUF *op, int conditional, n64_enum_file_change_code file_change) asm("_output_line_directive");
static void
output_line_directive(FILE_BUF *ip, FILE_BUF *op, int conditional, n64_enum_file_change_code file_change)
{
  int len;
  char *line_directive_buf, *line_end;

  if (no_line_directives
      || ip->fname == 
                     ((void *)0)
      
     || no_output) {
    op->lineno = ip->lineno;
    return;
  }

  if (conditional) {
    if (ip->lineno == op->lineno)
      return;



    if (ip->lineno > op->lineno && ip->lineno < op->lineno + 8) {
      (((op)->length - ((op)->bufp - (op)->buf) <= (10)) ? grow_outbuf ((op), (10)) : 0);
      while (ip->lineno > op->lineno) {
 *op->bufp++ = '\n';
 op->lineno++;
      }
      return;
    }
  }


  if (ip->lineno == 0 && ip->bufp - ip->buf < ip->length
      && *ip->bufp == '\n') {
    ip->lineno++;
    ip->bufp++;
  }

  line_directive_buf = (char *) 
                               __builtin_alloca((
                               4 * strlen (ip->nominal_fname) + 100
                               ))
                                                                            ;
  sprintf (line_directive_buf, "# %d ", ip->lineno);
  line_end = quote_string (line_directive_buf + strlen (line_directive_buf),
      ip->nominal_fname);
  if (file_change != same_file) {
    *line_end++ = ' ';
    *line_end++ = file_change == enter_file ? '1' : '2';
  }

  if (ip->system_header_p) {
    *line_end++ = ' ';
    *line_end++ = '3';
  }







  *line_end++ = '\n';
  len = line_end - line_directive_buf;
  (((op)->length - ((op)->bufp - (op)->buf) <= (len + 1)) ? grow_outbuf ((op), (len + 1)) : 0);
  if (op->bufp > op->buf && op->bufp[-1] != '\n')
    *op->bufp++ = '\n';
  memcpy ((char *) op->bufp,(char *) line_directive_buf,len);
  op->bufp += len;
  op->lineno = ip->lineno;
}
struct n64_tag_argdata {
  U_CHAR *raw, *expanded;
  int raw_length, expand_length;
  int stringified_length;
  U_CHAR *free1, *free2;
  char newlines;
  char use_count;
};
static void
macroexpand(HASHNODE *hp, FILE_BUF *op) asm("_macroexpand");
static void
macroexpand(HASHNODE *hp, FILE_BUF *op)
{
  int nargs;
  DEFINITION *defn = hp->value.defn;
  register U_CHAR *xbuf;
  int xbuf_len;
  int start_line = instack[indepth].lineno;
  int rest_args, rest_zero;

  if (indepth >= (400 - 1)) { error_with_line (line_for_error (instack[indepth].lineno), "macro or `#include' recursion too deep"); return;; };


  if (hp->type != T_MACRO) {
    special_symbol (hp, op);
    return;
  }



  if (pcp_inside_if && pcp_outfile && defn->predefined)
    dump_single_macro (hp, pcp_outfile);

  nargs = defn->nargs;

  if (nargs >= 0) {
    register int i;
    struct n64_tag_argdata *args;
    char *parse_error = 0;

    args = (struct n64_tag_argdata *) 
                             __builtin_alloca((
                             (nargs + 1) * sizeof (struct n64_tag_argdata)
                             ))
                                                                           ;

    for (i = 0; i < nargs; i++) {
      args[i].raw = (U_CHAR *) "";
      args[i].expanded = 0;
      args[i].raw_length = args[i].expand_length
 = args[i].stringified_length = 0;
      args[i].free1 = args[i].free2 = 0;
      args[i].use_count = 0;
    }






    i = 0;
    rest_args = 0;
    do {

      ++instack[indepth].bufp;
      if (rest_args)
 continue;
      if (i < nargs || (nargs == 0 && i == 0)) {

 if (i == nargs - 1 && defn->rest_args)
   rest_args = 1;
 parse_error = macarg (&args[i], rest_args);
      }
      else
 parse_error = macarg (((void *)0), 0);
      if (parse_error) {
 error_with_line (line_for_error (start_line), parse_error);
 break;
      }
      i++;
    } while (*instack[indepth].bufp != ')');


    if (i == 1) {
      register U_CHAR *bp = args[0].raw;
      register U_CHAR *lim = bp + args[0].raw_length;


      if (nargs == 0)
 while (bp != lim && is_space[*bp]) bp++;
      if (bp == lim)
 i = 0;
    }



    rest_zero = 0;
    if (nargs == 0 && i > 0) {
      if (! parse_error)
 error ("arguments given to macro `%s'", hp->name);
    } else if (i < nargs) {

      if (nargs == 1 && i == 0 && traditional)
 ;

      else if (i == nargs - 1 && defn->rest_args)
 rest_zero = 1;
      else if (parse_error)
 ;
      else if (i == 0)
 error ("macro `%s' used without args", hp->name);
      else if (i == 1)
 error ("macro `%s' used with just one arg", hp->name);
      else
 error ("macro `%s' used with only %d args", hp->name, i);
    } else if (i > nargs) {
      if (! parse_error)
 error ("macro `%s' used with too many (%d) args", hp->name, i);
    }


    ++instack[indepth].bufp;



    if (nargs == 0) {
      xbuf = defn->expansion;
      xbuf_len = defn->length;
    } else {
      register U_CHAR *exp = defn->expansion;
      register int offset;

      register int totlen;

      register struct n64_tag_reflist *ap, *last_ap;





      xbuf_len = defn->length;
      for (ap = defn->pattern; ap != 
                                    ((void *)0)
                                        ; ap = ap->next) {
 if (ap->stringify)
   xbuf_len += args[ap->argno].stringified_length;
 else if (ap->raw_before != 0 || ap->raw_after != 0 || traditional)


   xbuf_len += args[ap->argno].raw_length + 4;
 else {


   if (args[ap->argno].expanded == 0) {
     FILE_BUF obuf;
     obuf = expand_to_temp_buffer (args[ap->argno].raw,
       args[ap->argno].raw + args[ap->argno].raw_length,
       1, 0);

     args[ap->argno].expanded = obuf.buf;
     args[ap->argno].expand_length = obuf.length;
     args[ap->argno].free2 = obuf.buf;
   }



   xbuf_len += args[ap->argno].expand_length + 4;
 }
 if (args[ap->argno].use_count < 10)
   args[ap->argno].use_count++;
      }

      xbuf = (U_CHAR *) xmalloc (xbuf_len + 1);






      offset = totlen = 0;
      for (last_ap = 
                    ((void *)0)
                        , ap = defn->pattern; ap != 
                                                    ((void *)0)
                                                        ;
    last_ap = ap, ap = ap->next) {
 register struct n64_tag_argdata *arg = &args[ap->argno];
 int count_before = totlen;


 for (i = 0; i < ap->nchars; i++, offset++)
   xbuf[totlen++] = exp[offset];



 if (rest_zero && totlen > count_before
     && ((ap->rest_args && ap->raw_before != 0)
  || (last_ap != 
                ((void *)0) 
                     && last_ap->rest_args
      && last_ap->raw_after != 0))) {

   while (totlen > count_before && is_space[xbuf[totlen - 1]]) {
     totlen--;
   }


   while (totlen > count_before && ! is_space[xbuf[totlen - 1]]) {
     totlen--;
   }
 }

 if (ap->stringify != 0) {
   int arglen = arg->raw_length;
   int escaped = 0;
   int in_string = 0;
   int c;
   i = 0;
   while (i < arglen
   && (c = arg->raw[i], is_space[c]))
     i++;
   while (i < arglen
   && (c = arg->raw[arglen - 1], is_space[c]))
     arglen--;
   if (!traditional)
     xbuf[totlen++] = '\"';
   for (; i < arglen; i++) {
     c = arg->raw[i];



     if (c == '\n' && arg->raw[i+1] != '\n') {
       i++;
       continue;
     }



     if (! in_string
  && (c == '\n' ? arg->raw[i+1] == '\n' : is_space[c])) {
       while (1) {


  if (c == '\n' && is_space[arg->raw[i+1]])
    i += 2;
  else if (c != '\n' && is_space[c])
    i++;
  else break;
  c = arg->raw[i];
       }
       i--;
       c = ' ';
     }

     if (escaped)
       escaped = 0;
     else {
       if (c == '\\')
  escaped = 1;
       if (in_string) {
  if (c == in_string)
    in_string = 0;
       } else if (c == '\"' || c == '\'')
  in_string = c;
     }


     if (c == '\"' || (in_string && c == '\\'))
       xbuf[totlen++] = '\\';
     if (isprint (c))
       xbuf[totlen++] = c;
     else {
       sprintf ((char *) &xbuf[totlen], "\\%03o", (unsigned int) c);
       totlen += 4;
     }
   }
   if (!traditional)
     xbuf[totlen++] = '\"';
 } else if (ap->raw_before != 0 || ap->raw_after != 0 || traditional) {
   U_CHAR *p1 = arg->raw;
   U_CHAR *l1 = p1 + arg->raw_length;
   if (ap->raw_before != 0) {
     while (p1 != l1 && is_space[*p1]) p1++;
     while (p1 != l1 && is_idchar[*p1])
       xbuf[totlen++] = *p1++;



     if (p1[0] == '\n' && p1[1] == '-')
       p1 += 2;
   } else if (!traditional) {


     xbuf[totlen++] = '\n';
     xbuf[totlen++] = ' ';
   }
   if (ap->raw_after != 0) {


     while (p1 != l1) {
       if (is_space[l1[-1]]) l1--;
       else if (l1[-1] == '-') {
  U_CHAR *p2 = l1 - 1;


  while (p2 != p1 && p2[-1] == '\n') p2--;
  if ((l1 - 1 - p2) & 1) {
    l1 -= 2;
  }
  else break;
       }
       else break;
     }
   }

   memcpy ((char *) (xbuf + totlen),(char *) p1,l1 - p1);
   totlen += l1 - p1;
   if (!traditional && ap->raw_after == 0) {


     xbuf[totlen++] = '\n';
     xbuf[totlen++] = ' ';
   }
 } else {


   if (!traditional) {
     xbuf[totlen++] = '\n';
     xbuf[totlen++] = ' ';
   }
   memcpy ((char *) (xbuf + totlen),(char *) arg->expanded,arg->expand_length)
                      ;
   totlen += arg->expand_length;
   if (!traditional) {
     xbuf[totlen++] = '\n';
     xbuf[totlen++] = ' ';
   }




   if (arg->use_count > 1 && arg->newlines > 0) {


     arg->use_count = 1;
     arg->expand_length
       = change_newlines (arg->expanded, arg->expand_length);
   }
 }

 if (totlen > xbuf_len)
   abort ();
      }




      for (i = offset; i < defn->length; i++) {

 if (exp[i] == ')')
   rest_zero = 0;
 if (! (rest_zero && last_ap != 
                               ((void *)0) 
                                    && last_ap->rest_args
        && last_ap->raw_after != 0))
   xbuf[totlen++] = exp[i];
      }

      xbuf[totlen] = 0;
      xbuf_len = totlen;

      for (i = 0; i < nargs; i++) {
 if (args[i].free1 != 0)
   free (args[i].free1);
 if (args[i].free2 != 0)
   free (args[i].free2);
      }
    }
  } else {
    xbuf = defn->expansion;
    xbuf_len = defn->length;
  }



  {
    register FILE_BUF *ip2;

    ip2 = &instack[++indepth];

    ip2->fname = 0;
    ip2->nominal_fname = 0;


    ip2->lineno = start_line;
    ip2->buf = xbuf;
    ip2->length = xbuf_len;
    ip2->bufp = xbuf;
    ip2->free_ptr = (nargs > 0) ? xbuf : 0;
    ip2->macro = hp;
    ip2->if_stack = if_stack;
    ip2->system_header_p = 0;





    if (!traditional)
      hp->type = T_DISABLED;
  }
}







static char *
macarg(register struct n64_tag_argdata *argptr, int rest_args) asm("_macarg");
static char *
macarg(register struct n64_tag_argdata *argptr, int rest_args)
{
  FILE_BUF *ip = &instack[indepth];
  int paren = 0;
  int newlines = 0;
  int comments = 0;
  char *result = 0;



  U_CHAR *bp = macarg1 (ip->bufp, ip->buf + ip->length,
   &paren, &newlines, &comments, rest_args);



  if (!(ip->fname != 0 && (newlines != 0 || comments != 0))
      && bp != ip->buf + ip->length) {
    if (argptr != 0) {
      argptr->raw = ip->bufp;
      argptr->raw_length = bp - ip->bufp;
      argptr->newlines = newlines;
    }
    ip->bufp = bp;
  } else {




    int bufsize = bp - ip->bufp;
    int extra = newlines;
    U_CHAR *buffer = (U_CHAR *) xmalloc (bufsize + extra + 1);
    int final_start = 0;

    memcpy ((char *) buffer,(char *) ip->bufp,bufsize);
    ip->bufp = bp;
    ip->lineno += newlines;

    while (bp == ip->buf + ip->length) {
      if (instack[indepth].macro == 0) {
 result = "unterminated macro call";
 break;
      }
      ip->macro->type = T_MACRO;
      if (ip->free_ptr)
 free (ip->free_ptr);
      ip = &instack[--indepth];
      newlines = 0;
      comments = 0;
      bp = macarg1 (ip->bufp, ip->buf + ip->length, &paren,
      &newlines, &comments, rest_args);
      final_start = bufsize;
      bufsize += bp - ip->bufp;
      extra += newlines;
      buffer = (U_CHAR *) xrealloc (buffer, bufsize + extra + 1);
      memcpy ((char *) (buffer + bufsize - (bp - ip->bufp)),(char *) ip->bufp,bp - ip->bufp)
                    ;
      ip->bufp = bp;
      ip->lineno += newlines;
    }






    if (argptr != 0) {
      argptr->raw = buffer;
      argptr->raw_length = bufsize;
      argptr->free1 = buffer;
      argptr->newlines = newlines;
      if ((newlines || comments) && ip->fname != 0)
 argptr->raw_length
   = final_start +
     discard_comments (argptr->raw + final_start,
         argptr->raw_length - final_start,
         newlines);
      argptr->raw[argptr->raw_length] = 0;
      if (argptr->raw_length > bufsize + extra)
 abort ();
    }
  }





  if (argptr != 0) {
    register U_CHAR *buf, *lim;
    register int totlen;

    buf = argptr->raw;
    lim = buf + argptr->raw_length;

    while (buf != lim && is_space[*buf])
      buf++;
    while (buf != lim && is_space[lim[-1]])
      lim--;
    totlen = traditional ? 0 : 2;
    while (buf != lim) {
      register U_CHAR c = *buf++;
      totlen++;
      if (c == '\"' || c == '\\')
 totlen++;
      else if (!isprint (c))
 totlen += 3;
    }
    argptr->stringified_length = totlen;
  }
  return result;
}
static U_CHAR *
macarg1(U_CHAR *start, register U_CHAR *limit, int *depthptr, int *newlines, int *comments, int rest_args) asm("_macarg1");
static U_CHAR *
macarg1(U_CHAR *start, register U_CHAR *limit, int *depthptr, int *newlines, int *comments, int rest_args)
{
  register U_CHAR *bp = start;

  while (bp < limit) {
    switch (*bp) {
    case '(':
      (*depthptr)++;
      break;
    case ')':
      if (--(*depthptr) < 0)
 return bp;
      break;
    case '\\':

      if (bp + 1 < limit && traditional)
 {
   bp++;

   if (*bp == '\n')
     ++*newlines;
 }
      break;
    case '\n':
      ++*newlines;
      break;
    case '/':
      if (bp[1] == '\\' && bp[2] == '\n')
 newline_fix (bp + 1);
      if (cplusplus_comments && bp[1] == '/') {
 *comments = 1;
 bp += 2;
 while (bp < limit && (*bp != '\n' || bp[-1] == '\\')) {
   if (*bp == '\n') ++*newlines;
   bp++;
 }

 ++*newlines;
 break;
      }
      if (bp[1] != '*' || bp + 1 >= limit)
 break;
      *comments = 1;
      bp += 2;
      while (bp + 1 < limit) {
 if (bp[0] == '*'
     && bp[1] == '\\' && bp[2] == '\n')
   newline_fix (bp + 1);
 if (bp[0] == '*' && bp[1] == '/')
   break;
 if (*bp == '\n') ++*newlines;
 bp++;
      }
      break;
    case '\'':
    case '\"':
      {
 int quotec;
 for (quotec = *bp++; bp + 1 < limit && *bp != quotec; bp++) {
   if (*bp == '\\') {
     bp++;
     if (*bp == '\n')
       ++*newlines;
     while (*bp == '\\' && bp[1] == '\n') {
       bp += 2;
     }
   } else if (*bp == '\n') {
     ++*newlines;
     if (quotec == '\'')
       break;
   }
 }
      }
      break;
    case ',':

      if ((*depthptr) == 0 && rest_args == 0)
 return bp;
      break;
    }
    bp++;
  }

  return bp;
}
static int
discard_comments(U_CHAR *start, int length, int newlines) asm("_discard_comments");
static int
discard_comments(U_CHAR *start, int length, int newlines)
{
  register U_CHAR *ibp;
  register U_CHAR *obp;
  register U_CHAR *limit;
  register int c;
  if (newlines > 0) {
    ibp = start + length;
    obp = ibp + newlines;
    limit = start;
    while (limit != ibp)
      *--obp = *--ibp;
  }

  ibp = start + newlines;
  limit = start + length + newlines;
  obp = start;

  while (ibp < limit) {
    *obp++ = c = *ibp++;
    switch (c) {
    case '\n':

      *obp++ = '\n';
      break;

    case '\\':
      if (*ibp == '\n') {
 obp--;
 ibp++;
      }
      break;

    case '/':
      if (*ibp == '\\' && ibp[1] == '\n')
 newline_fix (ibp);

      if (cplusplus_comments && ibp[0] == '/') {

 obp[-1] = ' ';
 ibp++;
 while (ibp < limit && (*ibp != '\n' || ibp[-1] == '\\'))
   ibp++;
 break;
      }
      if (ibp[0] != '*' || ibp + 1 >= limit)
 break;


      if (traditional)
 obp--;
      else
 obp[-1] = ' ';
      ibp++;
      while (ibp + 1 < limit) {
 if (ibp[0] == '*'
     && ibp[1] == '\\' && ibp[2] == '\n')
   newline_fix (ibp + 1);
 if (ibp[0] == '*' && ibp[1] == '/')
   break;
 ibp++;
      }
      ibp += 2;
      break;

    case '\'':
    case '\"':



      {
 int quotec = c;
 while (ibp < limit) {
   *obp++ = c = *ibp++;
   if (c == quotec)
     break;
   if (c == '\n' && quotec == '\'')
     break;
   if (c == '\\' && ibp < limit) {
     while (*ibp == '\\' && ibp[1] == '\n')
       ibp += 2;
     *obp++ = *ibp++;
   }
 }
      }
      break;
    }
  }

  return obp - start;
}





static int
change_newlines(U_CHAR *start, int length) asm("_change_newlines");
static int
change_newlines(U_CHAR *start, int length)
{
  register U_CHAR *ibp;
  register U_CHAR *obp;
  register U_CHAR *limit;
  register int c;

  ibp = start;
  limit = start + length;
  obp = start;

  while (ibp < limit) {
    *obp++ = c = *ibp++;
    switch (c) {
    case '\n':



      if (*ibp == '\n')
 {
   ibp++;
   obp--;
   *obp++ = ' ';
 }
      break;

    case '\'':
    case '\"':

      {
 int quotec = c;
 while (ibp < limit) {
   *obp++ = c = *ibp++;
   if (c == quotec)
     break;
   if (c == '\n' && quotec == '\'')
     break;
 }
      }
      break;
    }
  }

  return obp - start;
}





char *
my_strerror(int errnum) asm("_my_strerror");
char *
my_strerror(int errnum)
{
  char *result;





  result = strerror (errnum);
  if (!result)
    result = "undocumented I/O error";

  return result;
}





void
error (char *msg, ...) asm("_error");
void
error (char *msg, ...)
    
{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  verror (msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}

static void
verror(char *msg, va_list args) asm("_verror");
static void
verror(char *msg, va_list args)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  print_containing_files ();

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", ip->nominal_fname, ip->lineno);
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  errors++;
}



static void
error_from_errno(char *name) asm("_error_from_errno");
static void
error_from_errno(char *name)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  print_containing_files ();

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", ip->nominal_fname, ip->lineno);

  fprintf (
          (__acrt_iob_func(2))
                , "%s: %s\n", name, my_strerror (
                                                 (*_errno())
                                                      ));

  errors++;
}



void
warning (char *msg, ...) asm("_warning");
void
warning (char *msg, ...)
    
{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  vwarning (msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}

static void
vwarning(char *msg, va_list args) asm("_vwarning");
static void
vwarning(char *msg, va_list args)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  if (inhibit_warnings)
    return;

  if (warnings_are_errors)
    errors++;

  print_containing_files ();

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", ip->nominal_fname, ip->lineno);
  fprintf (
          (__acrt_iob_func(2))
                , "warning: ");
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}

static void

error_with_line (int line, char *msg, ...) asm("_error_with_line");
static void

error_with_line (int line, char *msg, ...)





{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  verror_with_line (line, msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}

static void
verror_with_line(int line, char *msg, va_list args) asm("_verror_with_line");
static void
verror_with_line(int line, char *msg, va_list args)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  print_containing_files ();

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", ip->nominal_fname, line);
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  errors++;
}

static void

warning_with_line (int line, char *msg, ...) asm("_warning_with_line");
static void

warning_with_line (int line, char *msg, ...)





{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  vwarning_with_line (line, msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}

static void
vwarning_with_line(int line, char *msg, va_list args) asm("_vwarning_with_line");
static void
vwarning_with_line(int line, char *msg, va_list args)
{
  int i;
  FILE_BUF *ip = 
                ((void *)0)
                    ;

  if (inhibit_warnings)
    return;

  if (warnings_are_errors)
    errors++;

  print_containing_files ();

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }

  if (ip != 
           ((void *)0)
               )
    fprintf (
            (__acrt_iob_func(2))
                  , line ? "%s:%d: " : "%s: ", ip->nominal_fname, line);
  fprintf (
          (__acrt_iob_func(2))
                , "warning: ");
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}



void
pedwarn (char *msg, ...) asm("_pedwarn");
void
pedwarn (char *msg, ...)
    
{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  if (pedantic_errors)
    verror (msg, args);
  else
    vwarning (msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}

void

pedwarn_with_line (int line, char *msg, ...) asm("_pedwarn_with_line");
void

pedwarn_with_line (int line, char *msg, ...)





{
  va_list args;

  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  if (pedantic_errors)
    verror_with_line (line, msg, args);
  else
    vwarning_with_line (line, msg, args);
  
 __builtin_va_end(
 args
 )
              ;
}




static void

pedwarn_with_file_and_line (char *file, int line, char *msg, ...) asm("_pedwarn_with_file_and_line");
static void

pedwarn_with_file_and_line (char *file, int line, char *msg, ...)






{
  va_list args;

  if (!pedantic_errors && inhibit_warnings)
    return;
  if (file != 
             ((void *)0)
                 )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", file, line);
  if (pedantic_errors)
    errors++;
  if (!pedantic_errors)
    fprintf (
            (__acrt_iob_func(2))
                  , "warning: ");
  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  
 __builtin_va_end(
 args
 )
              ;
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}




static void
print_containing_files(void) asm("_print_containing_files");
static void
print_containing_files(void)
{
  FILE_BUF *ip = 
                ((void *)0)
                    ;
  int i;
  int first = 1;



  if (last_error_tick == input_file_stack_tick)
    return;

  for (i = indepth; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      break;
    }


  if (ip == 
           ((void *)0)
               )
    return;


  for (i--; i >= 0; i--)
    if (instack[i].fname != 
                           ((void *)0)
                               ) {
      ip = &instack[i];
      if (first) {
 first = 0;
 fprintf (
         (__acrt_iob_func(2))
               , "In file included");
      } else {
 fprintf (
         (__acrt_iob_func(2))
               , ",\n                ");
      }

      fprintf (
              (__acrt_iob_func(2))
                    , " from %s:%d", ip->nominal_fname, ip->lineno);
    }
  if (! first)
    fprintf (
            (__acrt_iob_func(2))
                  , ":\n");


  last_error_tick = input_file_stack_tick;
}
static int
line_for_error(int line) asm("_line_for_error");
static int
line_for_error(int line)
{
  int i;
  int line1 = line;

  for (i = indepth; i >= 0; ) {
    if (instack[i].fname != 0)
      return line1;
    i--;
    if (i < 0)
      return 0;
    line1 = instack[i].lineno;
  }
  abort ();

  return 0;
}
static int
grow_outbuf(register FILE_BUF *obuf, register int needed) asm("_grow_outbuf");
static int
grow_outbuf(register FILE_BUF *obuf, register int needed)
{
  register U_CHAR *p;
  int minsize;

  if (obuf->length - (obuf->bufp - obuf->buf) > needed)
    return 0;


  obuf->length *= 2;

  minsize = (3 * needed) / 2 + (obuf->bufp - obuf->buf);
  if (minsize > obuf->length)
    obuf->length = minsize;

  if ((p = (U_CHAR *) xrealloc (obuf->buf, obuf->length)) == 
                                                            ((void *)0)
                                                                )
    memory_full ();

  obuf->bufp = p + (obuf->bufp - obuf->buf);
  obuf->buf = p;

  return 0;
}
static HASHNODE *
install(U_CHAR *name, int len, n64_enum_node_type type, char *value, int hash) asm("_install");
static HASHNODE *
install(U_CHAR *name, int len, n64_enum_node_type type, char *value, int hash)
{
  register HASHNODE *hp;
  register int i, bucket;
  register U_CHAR *p, *q;

  if (len < 0) {
    p = name;
    while (is_idchar[*p])
      p++;
    len = p - name;
  }

  if (hash < 0)
    hash = hashf (name, len, 1403);

  i = sizeof (HASHNODE) + len + 1;
  hp = (HASHNODE *) xmalloc (i);
  bucket = hash;
  hp->bucket_hdr = &hashtab[bucket];
  hp->next = hashtab[bucket];
  hashtab[bucket] = hp;
  hp->prev = 
            ((void *)0)
                ;
  if (hp->next != 
                 ((void *)0)
                     )
    hp->next->prev = hp;
  hp->type = type;
  hp->length = len;
  hp->value.cpval = value;
  hp->name = ((U_CHAR *) hp) + sizeof (HASHNODE);
  p = hp->name;
  q = name;
  for (i = 0; i < len; i++)
    *p++ = *q++;
  hp->name[len] = 0;
  return hp;
}
HASHNODE *
lookup(U_CHAR *name, int len, int hash) asm("_lookup");
HASHNODE *
lookup(U_CHAR *name, int len, int hash)
{
  register U_CHAR *bp;
  register HASHNODE *bucket;

  if (len < 0) {
    for (bp = name; is_idchar[*bp]; bp++) ;
    len = bp - name;
  }

  if (hash < 0)
    hash = hashf (name, len, 1403);

  bucket = hashtab[hash];
  while (bucket) {
    if (bucket->length == len && memcmp (bucket->name,name,len) == 0)
      return bucket;
    bucket = bucket->next;
  }
  return 
        ((void *)0)
            ;
}
static void
delete_macro(HASHNODE *hp) asm("_delete_macro");
static void
delete_macro(HASHNODE *hp)
{

  if (hp->prev != 
                 ((void *)0)
                     )
    hp->prev->next = hp->next;
  if (hp->next != 
                 ((void *)0)
                     )
    hp->next->prev = hp->prev;



  if (hp == *hp->bucket_hdr)
    *hp->bucket_hdr = hp->next;
  free (hp);
}





static int
hashf(register U_CHAR *name, register int len, int hashsize) asm("_hashf");
static int
hashf(register U_CHAR *name, register int len, int hashsize)
{
  register int r = 0;

  while (len--)
    r = ((r << 2) + *name++);

  return (r & 0x7fffffff) % hashsize;
}



static void
dump_single_macro(register HASHNODE *hp, FILE *of) asm("_dump_single_macro");
static void
dump_single_macro(register HASHNODE *hp, FILE *of)
{
  register DEFINITION *defn = hp->value.defn;
  struct n64_tag_reflist *ap;
  int offset;
  int concat;




  fprintf (of, "#define %s", hp->name);

  if (defn->nargs >= 0) {
    int i;

    fprintf (of, "(");
    for (i = 0; i < defn->nargs; i++) {
      dump_arg_n (defn, i, of);
      if (i + 1 < defn->nargs)
 fprintf (of, ", ");
    }
    fprintf (of, ")");
  }

  fprintf (of, " ");

  offset = 0;
  concat = 0;
  for (ap = defn->pattern; ap != 
                                ((void *)0)
                                    ; ap = ap->next) {
    dump_defn_1 (defn->expansion, offset, ap->nchars, of);
    offset += ap->nchars;
    if (!traditional) {
      if (ap->nchars != 0)
 concat = 0;
      if (ap->stringify) {
 switch (ap->stringify) {
  case SHARP_TOKEN: fprintf (of, "#"); break;
  case WHITE_SHARP_TOKEN: fprintf (of, "# "); break;
  case PERCENT_COLON_TOKEN: fprintf (of, "%%:"); break;
  case WHITE_PERCENT_COLON_TOKEN: fprintf (of, "%%: "); break;
  default: abort ();
 }
      }
      if (ap->raw_before != 0) {
 if (concat) {
   switch (ap->raw_before) {
    case WHITE_SHARP_TOKEN:
    case WHITE_PERCENT_COLON_TOKEN:
     fprintf (of, " ");
     break;
    default:
     break;
   }
 } else {
   switch (ap->raw_before) {
    case SHARP_TOKEN: fprintf (of, "##"); break;
    case WHITE_SHARP_TOKEN: fprintf (of, "## "); break;
    case PERCENT_COLON_TOKEN: fprintf (of, "%%:%%:"); break;
    case WHITE_PERCENT_COLON_TOKEN: fprintf (of, "%%:%%: "); break;
    default: abort ();
   }
 }
      }
      concat = 0;
    }
    dump_arg_n (defn, ap->argno, of);
    if (!traditional && ap->raw_after != 0) {
      switch (ap->raw_after) {
       case SHARP_TOKEN: fprintf (of, "##"); break;
       case WHITE_SHARP_TOKEN: fprintf (of, " ##"); break;
       case PERCENT_COLON_TOKEN: fprintf (of, "%%:%%:"); break;
       case WHITE_PERCENT_COLON_TOKEN: fprintf (of, " %%:%%:"); break;
       default: abort ();
      }
      concat = 1;
    }
  }
  dump_defn_1 (defn->expansion, offset, defn->length - offset, of);
  fprintf (of, "\n");
}



static void
dump_all_macros(void) asm("_dump_all_macros");
static void
dump_all_macros(void)
{
  int bucket;

  for (bucket = 0; bucket < 1403; bucket++) {
    register HASHNODE *hp;

    for (hp = hashtab[bucket]; hp; hp= hp->next) {
      if (hp->type == T_MACRO)
 dump_single_macro (hp, 
                       (__acrt_iob_func(1))
                             );
    }
  }
}







static void
dump_defn_1(U_CHAR *base, int start, int length, FILE *of) asm("_dump_defn_1");
static void
dump_defn_1(U_CHAR *base, int start, int length, FILE *of)
{
  U_CHAR *p = base + start;
  U_CHAR *limit = base + start + length;

  if (traditional)
    fwrite (p, sizeof (*p), length, of);
  else {
    while (p < limit) {
      if (*p == '\"' || *p =='\'') {
 U_CHAR *p1 = skip_quoted_string (p, limit, 0, ((void *)0),
      ((void *)0), ((void *)0));
 fwrite (p, sizeof (*p), p1 - p, of);
 p = p1;
      } else {
 if (*p != '\n')
   putc (*p, of);
 p++;
      }
    }
  }
}






static void
dump_arg_n(DEFINITION *defn, int argnum, FILE *of) asm("_dump_arg_n");
static void
dump_arg_n(DEFINITION *defn, int argnum, FILE *of)
{
  register U_CHAR *p = defn->args.argnames;
  while (argnum + 1 < defn->nargs) {
    p = (U_CHAR *) strchr ((char *) p, ' ') + 1;
    argnum++;
  }

  while (*p && *p != ',') {
    putc (*p, of);
    p++;
  }
}



static void
initialize_char_syntax(void) asm("_initialize_char_syntax");
static void
initialize_char_syntax(void)
{
  register int i;







  for (i = 'a'; i <= 'z'; i++) {
    is_idchar[i - 'a' + 'A'] = 1;
    is_idchar[i] = 1;
    is_idstart[i - 'a' + 'A'] = 1;
    is_idstart[i] = 1;
  }
  for (i = '0'; i <= '9'; i++)
    is_idchar[i] = 1;
  is_idchar['_'] = 1;
  is_idstart['_'] = 1;
  is_idchar['$'] = dollars_in_ident;
  is_idstart['$'] = dollars_in_ident;


  is_hor_space[' '] = 1;
  is_hor_space['\t'] = 1;
  is_hor_space['\v'] = 1;
  is_hor_space['\f'] = 1;
  is_hor_space['\r'] = 1;

  is_space[' '] = 1;
  is_space['\t'] = 1;
  is_space['\v'] = 1;
  is_space['\f'] = 1;
  is_space['\n'] = 1;
  is_space['\r'] = 1;

  char_name['\v'] = "vertical tab";
  char_name['\f'] = "formfeed";
  char_name['\r'] = "carriage return";
}



static void
initialize_builtins(FILE_BUF *inp, FILE_BUF *outp) asm("_initialize_builtins");
static void
initialize_builtins(FILE_BUF *inp, FILE_BUF *outp)
{
  install ((U_CHAR *) "__LINE__", -1, T_SPECLINE, ((void *)0), -1);
  install ((U_CHAR *) "__DATE__", -1, T_DATE, ((void *)0), -1);
  install ((U_CHAR *) "__FILE__", -1, T_FILE, ((void *)0), -1);
  install ((U_CHAR *) "__BASE_FILE__", -1, T_BASE_FILE, ((void *)0), -1);
  install ((U_CHAR *) "__INCLUDE_LEVEL__", -1, T_INCLUDE_LEVEL, ((void *)0), -1);
  install ((U_CHAR *) "__VERSION__", -1, T_VERSION, ((void *)0), -1);






  install ((U_CHAR *) "__WCHAR_TYPE__", -1, T_WCHAR_TYPE, ((void *)0), -1);
  install ((U_CHAR *) "__USER_LABEL_PREFIX__", -1, T_USER_LABEL_PREFIX_TYPE,
    ((void *)0), -1);
  install ((U_CHAR *) "__REGISTER_PREFIX__", -1, T_REGISTER_PREFIX_TYPE,
    ((void *)0), -1);
  install ((U_CHAR *) "__IMMEDIATE_PREFIX__", -1, T_IMMEDIATE_PREFIX_TYPE,
    ((void *)0), -1);
  install ((U_CHAR *) "__TIME__", -1, T_TIME, ((void *)0), -1);
  if (!traditional) {
    install ((U_CHAR *) "__STDC__", -1, T_CONST, "1", -1);
    install ((U_CHAR *) "__STDC_VERSION__", -1, T_CONST, "199409L", -1);
  }
  if (objc)
    install ((U_CHAR *) "__OBJC__", -1, T_CONST, "1", -1);




  if (debug_output)
    {
      char directive[2048];
      U_CHAR *udirective = (U_CHAR *) directive;
      register struct n64_tag_directive *dp = &directive_table[0];
      struct tm *timebuf = timestamp ();

      sprintf (directive, " __BASE_FILE__ \"%s\"\n",
        instack[0].nominal_fname);
      output_line_directive (inp, outp, 0, same_file);
      pass_thru_directive (udirective, &udirective[strlen (directive)],
      outp, dp);

      sprintf (directive, " __VERSION__ \"%s\"\n", version_string);
      output_line_directive (inp, outp, 0, same_file);
      pass_thru_directive (udirective, &udirective[strlen (directive)],
      outp, dp);
      sprintf (directive, " __WCHAR_TYPE__ %s\n", wchar_type);
      output_line_directive (inp, outp, 0, same_file);
      pass_thru_directive (udirective, &udirective[strlen (directive)],
      outp, dp);

      sprintf (directive, " __DATE__ \"%s %2d %4d\"\n",
        monthnames[timebuf->tm_mon],
        timebuf->tm_mday, timebuf->tm_year + 1900);
      output_line_directive (inp, outp, 0, same_file);
      pass_thru_directive (udirective, &udirective[strlen (directive)],
      outp, dp);

      sprintf (directive, " __TIME__ \"%02d:%02d:%02d\"\n",
        timebuf->tm_hour, timebuf->tm_min, timebuf->tm_sec);
      output_line_directive (inp, outp, 0, same_file);
      pass_thru_directive (udirective, &udirective[strlen (directive)],
      outp, dp);

      if (!traditional)
 {
          sprintf (directive, " __STDC__ 1");
          output_line_directive (inp, outp, 0, same_file);
          pass_thru_directive (udirective, &udirective[strlen (directive)],
          outp, dp);
 }
      if (objc)
 {
          sprintf (directive, " __OBJC__ 1");
          output_line_directive (inp, outp, 0, same_file);
          pass_thru_directive (udirective, &udirective[strlen (directive)],
          outp, dp);
 }
    }
}
static void
make_definition(char *str, FILE_BUF *op) asm("_make_definition");
static void
make_definition(char *str, FILE_BUF *op)
{
  FILE_BUF *ip;
  struct n64_tag_directive *kt;
  U_CHAR *buf, *p;

  p = buf = (U_CHAR *) str;
  if (!is_idstart[*p]) {
    error ("malformed option `-D %s'", str);
    return;
  }
  while (is_idchar[*++p])
    ;
  if (*p == '(') {
    while (is_idchar[*++p] || *p == ',' || is_hor_space[*p])
      ;
    if (*p++ != ')')
      p = (U_CHAR *) str;
  }
  if (*p == 0) {
    buf = (U_CHAR *) 
                    __builtin_alloca((
                    p - buf + 4
                    ))
                                        ;
    strcpy ((char *)buf, str);
    strcat ((char *)buf, " 1");
  } else if (*p != '=') {
    error ("malformed option `-D %s'", str);
    return;
  } else {
    U_CHAR *q;

    buf = (U_CHAR *) 
                    __builtin_alloca((
                    2 * strlen (str) + 1
                    ))
                                                 ;
    strncpy ((char *) buf, str, p - (U_CHAR *) str);

    buf[p - (U_CHAR *) str] = ' ';

    p++;
    q = &buf[p - (U_CHAR *) str];
    while (*p) {
      if (*p == '\"' || *p == '\'') {
 int unterminated = 0;
 U_CHAR *p1 = skip_quoted_string (p, p + strlen ((char *) p), 0,
      ((void *)0), ((void *)0), &unterminated);
 if (unterminated)
   return;
 while (p != p1)
   if (*p == '\\' && p[1] == '\n')
     p += 2;
   else
     *q++ = *p++;
      } else if (*p == '\\' && p[1] == '\n')
 p += 2;

      else if (*p == '\n')
 {
   *q++ = '\n';
   *q++ = '\n';
   p++;
 }
      else
 *q++ = *p++;
    }
    *q = 0;
  }

  ip = &instack[++indepth];
  ip->nominal_fname = ip->fname = "*Initialization*";

  ip->buf = ip->bufp = buf;
  ip->length = strlen ((char *) buf);
  ip->lineno = 1;
  ip->macro = 0;
  ip->free_ptr = 0;
  ip->if_stack = if_stack;
  ip->system_header_p = 0;

  for (kt = directive_table; kt->type != T_DEFINE; kt++)
    ;


  do_define (buf, buf + strlen ((char *) buf), ((void *)0), kt);
  --indepth;
}



static void
make_undef(char *str, FILE_BUF *op) asm("_make_undef");
static void
make_undef(char *str, FILE_BUF *op)
{
  FILE_BUF *ip;
  struct n64_tag_directive *kt;

  ip = &instack[++indepth];
  ip->nominal_fname = ip->fname = "*undef*";

  ip->buf = ip->bufp = (U_CHAR *) str;
  ip->length = strlen (str);
  ip->lineno = 1;
  ip->macro = 0;
  ip->free_ptr = 0;
  ip->if_stack = if_stack;
  ip->system_header_p = 0;

  for (kt = directive_table; kt->type != T_UNDEF; kt++)
    ;

  do_undef ((U_CHAR *) str, (U_CHAR *) str + strlen (str), op, kt);
  --indepth;
}




static void
make_assertion(char *option, char *str) asm("_make_assertion");
static void
make_assertion(char *option, char *str)
{
  FILE_BUF *ip;
  struct n64_tag_directive *kt;
  U_CHAR *buf, *p, *q;


  buf = (U_CHAR *) 
                  __builtin_alloca((
                  strlen (str) + 1
                  ))
                                           ;
  strcpy ((char *) buf, str);

  p = q = buf;
  while (*p) {
    if (*p == '\\' && p[1] == '\n')
      p += 2;
    else
      *q++ = *p++;
  }
  *q = 0;

  p = buf;
  if (!is_idstart[*p]) {
    error ("malformed option `%s %s'", option, str);
    return;
  }
  while (is_idchar[*++p])
    ;
  do { while (is_hor_space[*p]) p++; } while (0);
  if (! (*p == 0 || *p == '(')) {
    error ("malformed option `%s %s'", option, str);
    return;
  }

  ip = &instack[++indepth];
  ip->nominal_fname = ip->fname = "*Initialization*";

  ip->buf = ip->bufp = buf;
  ip->length = strlen ((char *) buf);
  ip->lineno = 1;
  ip->macro = 0;
  ip->free_ptr = 0;
  ip->if_stack = if_stack;
  ip->system_header_p = 0;

  for (kt = directive_table; kt->type != T_ASSERT; kt++)
    ;



  do_assert (buf, buf + strlen ((char *) buf) , ((void *)0), kt);
  --indepth;
}





static void
append_include_chain(struct n64_tag_file_name_list *first, struct n64_tag_file_name_list *last) asm("_append_include_chain");
static void
append_include_chain(struct n64_tag_file_name_list *first, struct n64_tag_file_name_list *last)
{
  struct n64_tag_file_name_list *dir;

  if (!first || !last)
    return;

  if (include == 0)
    include = first;
  else
    last_include->next = first;

  if (first_bracket_include == 0)
    first_bracket_include = first;

  for (dir = first; ; dir = dir->next) {
    int len = strlen (dir->fname) + 0;
    if (len > max_include_len)
      max_include_len = len;
    if (dir == last)
      break;
  }

  last->next = 
              ((void *)0)
                  ;
  last_include = last;
}





static void
deps_output(char *string, int spacer) asm("_deps_output");
static void
deps_output(char *string, int spacer)
{
  int size = strlen (string);

  if (size == 0)
    return;




  if (72 - 1 - 2 < deps_column + size
      && 1 < deps_column) {
    memcpy (&deps_buffer[deps_size]," \\\n ",4);
    deps_size += 4;
    deps_column = 1;
    if (spacer == ' ')
      spacer = 0;
  }

  if (deps_size + size + 8 > deps_allocated_size) {
    deps_allocated_size = (deps_size + size + 50) * 2;
    deps_buffer = xrealloc (deps_buffer, deps_allocated_size);
  }
  if (spacer == ' ') {
    deps_buffer[deps_size++] = ' ';
    deps_column++;
  }
  memcpy (&deps_buffer[deps_size],string,size);
  deps_size += size;
  deps_column += size;
  if (spacer == ':') {
    deps_buffer[deps_size++] = ':';
    deps_column++;
  }
  deps_buffer[deps_size] = 0;
}

static void
fatal (char *msg, ...) asm("_fatal");
static void
fatal (char *msg, ...)
    
{
  va_list args;

  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", progname);
  
 __builtin_va_start(
 args
 ,
 msg
 )
                     ;
  vfprintf (
           (__acrt_iob_func(2))
                 , msg, args);
  
 __builtin_va_end(
 args
 )
              ;
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  exit (33);
}




void
fancy_abort(void) asm("_fancy_abort");
void
fancy_abort(void)
{
  fatal ("Internal gcc abort.");
}

static void
perror_with_name(char *name) asm("_perror_with_name");
static void
perror_with_name(char *name)
{
  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", progname);
  fprintf (
          (__acrt_iob_func(2))
                , "%s: %s\n", name, my_strerror (
                                                 (*_errno())
                                                      ));
  errors++;
}

static void
pfatal_with_name(char *name) asm("_pfatal_with_name");
static void
pfatal_with_name(char *name)
{
  perror_with_name (name);



  exit (33);

}



static void
pipe_closed(int signo) asm("_pipe_closed");
static void
pipe_closed(int signo)
{
  fatal ("output pipe has been closed");
}

static void
memory_full(void) asm("_memory_full");
static void
memory_full(void)
{
  fatal ("Memory exhausted.");
}


void *
xmalloc(size_t size) asm("_xmalloc");
void *
xmalloc(size_t size)
{
  register void * ptr = (void *) malloc (size);
  if (!ptr)
    memory_full ();
  return ptr;
}

static void *
xrealloc(void *old, size_t size) asm("_xrealloc");
static void *
xrealloc(void *old, size_t size)
{
  register void * ptr = (void *) realloc (old, size);
  if (!ptr)
    memory_full ();
  return ptr;
}

static void *
xcalloc(size_t number, size_t size) asm("_xcalloc");
static void *
xcalloc(size_t number, size_t size)
{
  register size_t total = number * size;
  register void * ptr = (void *) malloc (total);
  if (!ptr)
    memory_full ();
  memset (ptr,0,total);
  return ptr;
}

static char *
savestring(char *input) asm("_savestring");
static char *
savestring(char *input)
{
  size_t size = strlen (input);
  char *output = xmalloc (size + 1);
  strcpy (output, input);
  return output;
}




static int
file_size_and_mode(int fd, int *mode_pointer, long int *size_pointer) asm("_file_size_and_mode");
static int
file_size_and_mode(int fd, int *mode_pointer, long int *size_pointer)
{
  struct stat sbuf;

  if (fstat (fd, &sbuf) < 0) return (-1);
  if (mode_pointer) *mode_pointer = sbuf.st_mode;
  if (size_pointer) *size_pointer = sbuf.st_size;
  return 0;
}

