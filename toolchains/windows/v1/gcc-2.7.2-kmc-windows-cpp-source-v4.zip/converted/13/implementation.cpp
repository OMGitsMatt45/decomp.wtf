// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/tree.c
/* Language-independent node constructors for parse phase of GNU compiler.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int _obstack_allocated_p(...) asm("__obstack_allocated_p");
extern int warning(...) asm("_warning");
extern int set_float_handler(...) asm("_set_float_handler");
extern int incomplete_type_error(...) asm("_incomplete_type_error");
extern int type_list_equal(...) asm("_type_list_equal");
extern int simple_cst_equal(...) asm("_simple_cst_equal");
extern int error(...) asm("_error");
extern int print_lang_statistics(...) asm("_print_lang_statistics");
struct n64_tag__obstack_chunk;
struct n64_tag_function;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_momentary_level;
struct n64_tag_obstack;
struct n64_tag_obstack_stack;
union n64_tag_real_extract;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_type_hash;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
struct n64_tag_var_refs_queue
{
  int * modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  int * first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  int * nonlocal_goto_handler_slot;
  int * nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  int * arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  int * *parm_reg_stack_loc;
  int outgoing_args_size;
  int * return_rtx;
  int * cleanup_label;
  int * return_label;
  int * save_expr_regs;
  int * stack_slot_list;
  int * parm_birth_insn;
  int frame_offset;
  int * tail_recursion_label;
  int * tail_recursion_reentry;
  int * internal_arg_pointer;
  int * arg_pointer_save_area;
  tree rtl_expr_chain;
  int * last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  int * last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  int * saveregs_value;
  int * apply_args_value;
  int * forced_labels;


  int reg_rtx_no;
  int first_label_num;
  int * first_insn;
  int * last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  int * *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct n64_tag_momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  int * epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern int * return_label;



extern int * stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, int *) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");





struct n64_tag_obstack permanent_obstack;







struct n64_tag_obstack *function_maybepermanent_obstack;



struct n64_tag_obstack maybepermanent_obstack;




struct n64_tag_simple_obstack_stack *toplev_inline_obstacks;





struct n64_tag_simple_obstack_stack *inline_obstacks;






struct n64_tag_obstack *function_obstack;



struct n64_tag_obstack temporary_obstack;




struct n64_tag_obstack momentary_obstack;





static struct n64_tag_obstack temp_decl_obstack;




struct n64_tag_obstack *saveable_obstack;





struct n64_tag_obstack *rtl_obstack;



struct n64_tag_obstack *current_obstack;




struct n64_tag_obstack *expression_obstack;



struct n64_tag_obstack_stack
{
  struct n64_tag_obstack_stack *next;
  struct n64_tag_obstack *current;
  struct n64_tag_obstack *saveable;
  struct n64_tag_obstack *expression;
  struct n64_tag_obstack *rtl;
};

struct n64_tag_obstack_stack *obstack_stack;



static struct n64_tag_obstack obstack_stack_obstack;



char *maybepermanent_firstobj;
char *temporary_firstobj;
char *momentary_firstobj;
char *temp_decl_firstobj;



char *momentary_function_firstobj;



int all_types_permanent;



struct n64_tag_momentary_level
{

  struct n64_tag_momentary_level *prev;

  char *base;

  struct n64_tag_obstack *obstack;
};

struct n64_tag_momentary_level *momentary_stack;







char *standard_tree_code_type[] = {
"x",





"x",




"x",






"x",


"x",
"b",
"t",
"t",



"t",



"t",
"t",



"t",



"t",



"t",





"t",



"t",






"t",


"t",
"t",





"t",







"t",





"t",





"t",







"t",





"t",
"c",


"c",




"c",



"c",
"d",
"d",
"d",
"d",
"d",
"d",
"d",
"d",






"r",
"r",


"r",





"r",


"r",




"r",







"e",
"e",


"e",



"e",




"e",





"e",
"e",






"e",




"e",
"e",
"e",
"x",





"e",



"2",
"2",
"2",






"2",


"2",


"2",


"2",


"2",
"2",
"2",
"2",





"2",



"2",






"1",
"1",
"1",
"1",


"1",



"2",


"1",

"2",
"2",
"1",
"1",







"2",
"2",
"2",
"2",


"2",
"2",
"2",
"2",
"1",






"e",
"e",
"e",
"e",
"e",
"e",







"<",
"<",
"<",
"<",
"<",
"<",


"2",
"<",
"1",
"2",




"1",


"1",


"1",





"e",





"e",



"e",


"e",



"e",



"2",



"1",



"1",
"1",




"e",
"e",
"e",
"e",







"s",



"s",






"s",



"s",




"s",
};
int standard_tree_code_length[] = {
0,





-1,




2,






2,


2,
0,
0,
0,



0,



0,
0,



0,



0,



0,





0,



0,






0,


0,
0,





0,







0,





0,





0,







0,





0,
2,


3,




3,



3,
0,
0,
0,
0,
0,
0,
0,
0,






2,
3,


1,





2,


1,




2,







2,
2,


2,



2,




3,





3,
3,






3,




4,
3,
1,
0,





2,



2,
2,
2,






2,


2,


2,


2,


2,
2,
2,
2,





2,



2,






1,
1,
1,
1,


1,



2,


1,

2,
2,
1,
1,







2,
2,
2,
2,


2,
2,
2,
2,
1,






2,
2,
2,
2,
2,
1,







2,
2,
2,
2,
2,
2,


2,
2,
1,
2,




1,


1,


1,





3,





2,



1,


1,



1,



2,



1,



1,
1,




2,
2,
2,
2,







1,



1,






1,



1,




1,
};






char *standard_tree_code_name[] = {
"error_mark",





"identifier_node",




"op_identifier",






"tree_list",


"tree_vec",
"block",
"void_type",
"integer_type",



"real_type",



"complex_type",
"enumeral_type",



"boolean_type",



"char_type",



"pointer_type",





"offset_type",



"reference_type",






"method_type",


"file_type",
"array_type",





"set_type",







"record_type",





"union_type",





"qual_union_type",







"function_type",





"lang_type",
"integer_cst",


"real_cst",




"complex_cst",



"string_cst",
"function_decl",
"label_decl",
"const_decl",
"type_decl",
"var_decl",
"parm_decl",
"result_decl",
"field_decl",






"component_ref",
"bit_field_ref",


"indirect_ref",





"offset_ref",


"buffer_ref",




"array_ref",







"constructor",
"compound_expr",


"modify_expr",



"init_expr",




"target_expr",





"cond_expr",
"bind_expr",






"call_expr",




"method_call_expr",
"with_cleanup_expr",
"cleanup_point_expr",
"placeholder_expr",





"with_record_expr",



"plus_expr",
"minus_expr",
"mult_expr",






"trunc_div_expr",


"ceil_div_expr",


"floor_div_expr",


"round_div_expr",


"trunc_mod_expr",
"ceil_mod_expr",
"floor_mod_expr",
"round_mod_expr",





"rdiv_expr",



"exact_div_expr",






"fix_trunc_expr",
"fix_ceil_expr",
"fix_floor_expr",
"fix_round_expr",


"float_expr",



"expon_expr",


"negate_expr",

"min_expr",
"max_expr",
"abs_expr",
"ffs_expr",







"alshift_expr",
"arshift_expr",
"lrotate_expr",
"rrotate_expr",


"bit_ior_expr",
"bit_xor_expr",
"bit_and_expr",
"bit_andtc_expr",
"bit_not_expr",






"truth_andif_expr",
"truth_orif_expr",
"truth_and_expr",
"truth_or_expr",
"truth_xor_expr",
"truth_not_expr",







"lt_expr",
"le_expr",
"gt_expr",
"ge_expr",
"eq_expr",
"ne_expr",


"in_expr",
"set_le_expr",
"card_expr",
"range_expr",




"convert_expr",


"nop_expr",


"non_lvalue_expr",





"save_expr",





"rtl_expr",



"addr_expr",


"reference_expr",



"entry_value_expr",



"complex_expr",



"conj_expr",



"realpart_expr",
"imagpart_expr",




"predecrement_expr",
"preincrement_expr",
"postdecrement_expr",
"postincrement_expr",







"label_expr",



"goto_expr",






"return_expr",



"exit_expr",




"loop_expr",
};






char **tree_code_type;





int *tree_code_length;



char **tree_code_name;


enum n64_cpp_enum_anonymous_12{
  d_kind,
  t_kind,
  b_kind,
  s_kind,
  r_kind,
  e_kind,
  c_kind,
  id_kind,
  op_id_kind,
  perm_list_kind,
  temp_list_kind,
  vec_kind,
  x_kind,
  lang_decl,
  lang_type,
  all_kinds
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_12) n64_enum_anonymous_12;
typedef n64_enum_anonymous_12 tree_node_kind;

int tree_node_counts[(int)all_kinds];
int tree_node_sizes[(int)all_kinds];
int id_string_size = 0;

char *tree_node_kind_names[] = {
  "decls",
  "types",
  "blocks",
  "stmts",
  "refs",
  "exprs",
  "constants",
  "identifiers",
  "op_identifiers",
  "perm_tree_lists",
  "temp_tree_lists",
  "vecs",
  "random kinds",
  "lang_decl kinds",
  "lang_type kinds"
};




static tree hash_table[1009];


static int do_identifier_warnings;


static int next_decl_uid;

static int next_type_uid = 1;





extern char *mode_name[];

void gcc_obstack_init(...) asm("_gcc_obstack_init");



void
init_obstacks(void) asm("_init_obstacks");
void
init_obstacks(void)
{
  gcc_obstack_init (&obstack_stack_obstack);
  gcc_obstack_init (&permanent_obstack);

  gcc_obstack_init (&temporary_obstack);
  temporary_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&temporary_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  gcc_obstack_init (&momentary_obstack);
  momentary_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&momentary_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  momentary_function_firstobj = momentary_firstobj;
  gcc_obstack_init (&maybepermanent_obstack);
  maybepermanent_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&maybepermanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  gcc_obstack_init (&temp_decl_obstack);
  temp_decl_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&temp_decl_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  function_obstack = &temporary_obstack;
  function_maybepermanent_obstack = &maybepermanent_obstack;
  current_obstack = &permanent_obstack;
  expression_obstack = &permanent_obstack;
  rtl_obstack = saveable_obstack = &permanent_obstack;


  memset ((char *) hash_table,0,sizeof hash_table);
}

void
gcc_obstack_init(struct n64_tag_obstack *obstack) asm("_gcc_obstack_init");
void
gcc_obstack_init(struct n64_tag_obstack *obstack)
{
  _obstack_begin (obstack, 0, 0,
    (void *(*)(...)) xmalloc,
    (void (*)(...)) free);
}







void
save_tree_status(struct n64_tag_function *p, tree context) asm("_save_tree_status");
void
save_tree_status(struct n64_tag_function *p, tree context)
{
  p->all_types_permanent = all_types_permanent;
  p->momentary_stack = momentary_stack;
  p->maybepermanent_firstobj = maybepermanent_firstobj;
  p->momentary_firstobj = momentary_firstobj;
  p->momentary_function_firstobj = momentary_function_firstobj;
  p->function_obstack = function_obstack;
  p->function_maybepermanent_obstack = function_maybepermanent_obstack;
  p->current_obstack = current_obstack;
  p->expression_obstack = expression_obstack;
  p->saveable_obstack = saveable_obstack;
  p->rtl_obstack = rtl_obstack;
  p->inline_obstacks = inline_obstacks;

  if (context == current_function_decl)



    function_maybepermanent_obstack = function_obstack;
  else
    {



      struct n64_tag_simple_obstack_stack **head;
      struct n64_tag_simple_obstack_stack *current;

      if (context == (tree) 
                    ((void *)0)
                             )
 head = &toplev_inline_obstacks;
      else
 {
   struct n64_tag_function *f = find_function_data (context);
   head = &f->inline_obstacks;
 }

      current = ((struct n64_tag_simple_obstack_stack *)
   xmalloc (sizeof (struct n64_tag_simple_obstack_stack)));

      current->obstack = (struct n64_tag_obstack *) xmalloc (sizeof (struct n64_tag_obstack));
      function_maybepermanent_obstack = current->obstack;
      gcc_obstack_init (function_maybepermanent_obstack);

      current->next = *head;
      *head = current;
    }

  maybepermanent_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__o1 = (function_maybepermanent_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });

  function_obstack = (struct n64_tag_obstack *) xmalloc (sizeof (struct n64_tag_obstack));
  gcc_obstack_init (function_obstack);

  current_obstack = &permanent_obstack;
  expression_obstack = &permanent_obstack;
  rtl_obstack = saveable_obstack = &permanent_obstack;

  momentary_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__o1 = (&momentary_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
  momentary_function_firstobj = momentary_firstobj;
}




void
restore_tree_status(struct n64_tag_function *p) asm("_restore_tree_status");
void
restore_tree_status(struct n64_tag_function *p)
{
  all_types_permanent = p->all_types_permanent;
  momentary_stack = p->momentary_stack;

  __extension__ ({ struct n64_tag_obstack *__o = (&momentary_obstack); void *__obj = (momentary_function_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  __extension__ ({ struct n64_tag_obstack *__o = (function_maybepermanent_obstack); void *__obj = (maybepermanent_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  __extension__ ({ struct n64_tag_obstack *__o = (function_obstack); void *__obj = (0); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  free (function_obstack);

  momentary_firstobj = p->momentary_firstobj;
  momentary_function_firstobj = p->momentary_function_firstobj;
  maybepermanent_firstobj = p->maybepermanent_firstobj;
  function_obstack = p->function_obstack;
  function_maybepermanent_obstack = p->function_maybepermanent_obstack;
  current_obstack = p->current_obstack;
  expression_obstack = p->expression_obstack;
  saveable_obstack = p->saveable_obstack;
  rtl_obstack = p->rtl_obstack;
  inline_obstacks = p->inline_obstacks;
}






void
temporary_allocation(void) asm("_temporary_allocation");
void
temporary_allocation(void)
{


  current_obstack = function_obstack;
  expression_obstack = function_obstack;
  rtl_obstack = saveable_obstack = function_maybepermanent_obstack;
  momentary_stack = 0;
  inline_obstacks = 0;
}





void
end_temporary_allocation(void) asm("_end_temporary_allocation");
void
end_temporary_allocation(void)
{
  current_obstack = &permanent_obstack;
  expression_obstack = &permanent_obstack;
  rtl_obstack = saveable_obstack = &permanent_obstack;
}




void
resume_temporary_allocation(void) asm("_resume_temporary_allocation");
void
resume_temporary_allocation(void)
{
  current_obstack = function_obstack;
  expression_obstack = function_obstack;
  rtl_obstack = saveable_obstack = function_maybepermanent_obstack;
}






void
saveable_allocation(void) asm("_saveable_allocation");
void
saveable_allocation(void)
{


  expression_obstack = current_obstack = saveable_obstack;
}





void
push_obstacks(struct n64_tag_obstack *current, struct n64_tag_obstack *saveable) asm("_push_obstacks");
void
push_obstacks(struct n64_tag_obstack *current, struct n64_tag_obstack *saveable)
{
  struct n64_tag_obstack_stack *p
    = (struct n64_tag_obstack_stack *) __extension__ ({ struct n64_tag_obstack *__h = (&obstack_stack_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = (((sizeof (struct n64_tag_obstack_stack)))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                           ;

  p->current = current_obstack;
  p->saveable = saveable_obstack;
  p->expression = expression_obstack;
  p->rtl = rtl_obstack;
  p->next = obstack_stack;
  obstack_stack = p;

  current_obstack = current;
  expression_obstack = current;
  rtl_obstack = saveable_obstack = saveable;
}



void
push_obstacks_nochange(void) asm("_push_obstacks_nochange");
void
push_obstacks_nochange(void)
{
  struct n64_tag_obstack_stack *p
    = (struct n64_tag_obstack_stack *) __extension__ ({ struct n64_tag_obstack *__h = (&obstack_stack_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = (((sizeof (struct n64_tag_obstack_stack)))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                           ;

  p->current = current_obstack;
  p->saveable = saveable_obstack;
  p->expression = expression_obstack;
  p->rtl = rtl_obstack;
  p->next = obstack_stack;
  obstack_stack = p;
}



void
pop_obstacks(void) asm("_pop_obstacks");
void
pop_obstacks(void)
{
  struct n64_tag_obstack_stack *p = obstack_stack;
  obstack_stack = p->next;

  current_obstack = p->current;
  saveable_obstack = p->saveable;
  expression_obstack = p->expression;
  rtl_obstack = p->rtl;

  __extension__ ({ struct n64_tag_obstack *__o = (&obstack_stack_obstack); void *__obj = (p); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}




int
allocation_temporary_p(void) asm("_allocation_temporary_p");
int
allocation_temporary_p(void)
{
  return current_obstack != &permanent_obstack;
}
void
permanent_allocation(int function_end) asm("_permanent_allocation");
void
permanent_allocation(int function_end)
{

  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); void *__obj = (temporary_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  if (function_end)
    {
      __extension__ ({ struct n64_tag_obstack *__o = (&momentary_obstack); void *__obj = (momentary_function_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
      momentary_firstobj = momentary_function_firstobj;
    }
  else
    __extension__ ({ struct n64_tag_obstack *__o = (&momentary_obstack); void *__obj = (momentary_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  __extension__ ({ struct n64_tag_obstack *__o = (function_maybepermanent_obstack); void *__obj = (maybepermanent_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  __extension__ ({ struct n64_tag_obstack *__o = (&temp_decl_obstack); void *__obj = (temp_decl_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });



  while (inline_obstacks)
    {
      struct n64_tag_simple_obstack_stack *current = inline_obstacks;
      inline_obstacks = current->next;
      __extension__ ({ struct n64_tag_obstack *__o = (current->obstack); void *__obj = (0); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
      free (current->obstack);
      free (current);
    }

  current_obstack = &permanent_obstack;
  expression_obstack = &permanent_obstack;
  rtl_obstack = saveable_obstack = &permanent_obstack;
}



void
preserve_data(void) asm("_preserve_data");
void
preserve_data(void)
{
  maybepermanent_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (function_maybepermanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}

void
preserve_initializer(void) asm("_preserve_initializer");
void
preserve_initializer(void)
{
  struct n64_tag_momentary_level *tem;
  char *old_momentary;

  temporary_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&temporary_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  maybepermanent_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (function_maybepermanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  old_momentary = momentary_firstobj;
  momentary_firstobj
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&momentary_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  if (momentary_firstobj != old_momentary)
    for (tem = momentary_stack; tem; tem = tem->prev)
      tem->base = momentary_firstobj;
}





void
rtl_in_current_obstack(void) asm("_rtl_in_current_obstack");
void
rtl_in_current_obstack(void)
{
  rtl_obstack = current_obstack;
}




void
rtl_in_saveable_obstack(void) asm("_rtl_in_saveable_obstack");
void
rtl_in_saveable_obstack(void)
{
  rtl_obstack = saveable_obstack;
}





char *
oballoc(int size) asm("_oballoc");
char *
oballoc(int size)
{
  return (char *) __extension__ ({ struct n64_tag_obstack *__h = (current_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}





void
obfree(char *ptr) asm("_obfree");
void
obfree(char *ptr)
{
  __extension__ ({ struct n64_tag_obstack *__o = (current_obstack); void *__obj = (ptr); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}




char *
permalloc(int size) asm("_permalloc");
char *
permalloc(int size)
{
  return (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}





char *
perm_calloc(int nelem, long int size) asm("_perm_calloc");
char *
perm_calloc(int nelem, long int size)
{
  char *rval = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((nelem * size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  memset (rval,0,nelem * size);
  return rval;
}




char *
savealloc(int size) asm("_savealloc");
char *
savealloc(int size)
{
  return (char *) __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}



void
print_obstack_name(char *object, FILE *file, char *prefix) asm("_print_obstack_name");
void
print_obstack_name(char *object, FILE *file, char *prefix)
{
  struct n64_tag_obstack *obstack = 
                           ((void *)0)
                               ;
  char *obstack_name = 
                      ((void *)0)
                          ;
  struct n64_tag_function *p;

  for (p = outer_function_chain; p; p = p->next)
    {
      if (_obstack_allocated_p (p->function_obstack, object))
 {
   obstack = p->function_obstack;
   obstack_name = "containing function obstack";
 }
      if (_obstack_allocated_p (p->function_maybepermanent_obstack, object))
 {
   obstack = p->function_maybepermanent_obstack;
   obstack_name = "containing function maybepermanent obstack";
 }
    }

  if (_obstack_allocated_p (&obstack_stack_obstack, object))
    {
      obstack = &obstack_stack_obstack;
      obstack_name = "obstack_stack_obstack";
    }
  else if (_obstack_allocated_p (function_obstack, object))
    {
      obstack = function_obstack;
      obstack_name = "function obstack";
    }
  else if (_obstack_allocated_p (&permanent_obstack, object))
    {
      obstack = &permanent_obstack;
      obstack_name = "permanent_obstack";
    }
  else if (_obstack_allocated_p (&momentary_obstack, object))
    {
      obstack = &momentary_obstack;
      obstack_name = "momentary_obstack";
    }
  else if (_obstack_allocated_p (function_maybepermanent_obstack, object))
    {
      obstack = function_maybepermanent_obstack;
      obstack_name = "function maybepermanent obstack";
    }
  else if (_obstack_allocated_p (&temp_decl_obstack, object))
    {
      obstack = &temp_decl_obstack;
      obstack_name = "temp_decl_obstack";
    }


  if (obstack != 
                ((void *)0)
                    )
    {
      if (object >= obstack->next_free
   && object < obstack->chunk_limit)
 fprintf (file, "%s in free portion of obstack %s",
   prefix, obstack_name);
      else
 fprintf (file, "%s allocated from %s", prefix, obstack_name);
    }
  else
    fprintf (file, "%s not allocated from any obstack", prefix);
}

void
debug_obstack(char *object) asm("_debug_obstack");
void
debug_obstack(char *object)
{
  print_obstack_name (object, 
                             (__acrt_iob_func(2))
                                   , "object");
  fprintf (
          (__acrt_iob_func(2))
                , ".\n");
}





int
object_permanent_p(tree obj) asm("_object_permanent_p");
int
object_permanent_p(tree obj)
{
  return _obstack_allocated_p (&permanent_obstack, obj);
}






void
push_momentary(void) asm("_push_momentary");
void
push_momentary(void)
{
  struct n64_tag_momentary_level *tem
    = (struct n64_tag_momentary_level *) __extension__ ({ struct n64_tag_obstack *__h = (&momentary_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_momentary_level))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                      ;
  tem->prev = momentary_stack;
  tem->base = (char *) ((&momentary_obstack)->alloc_failed ? 0 : (&momentary_obstack)->object_base);
  tem->obstack = expression_obstack;
  momentary_stack = tem;
  expression_obstack = &momentary_obstack;
}




void
preserve_momentary(void) asm("_preserve_momentary");
void
preserve_momentary(void)
{
  momentary_stack->base = (char *) ((&momentary_obstack)->alloc_failed ? 0 : (&momentary_obstack)->object_base);
}




void
clear_momentary(void) asm("_clear_momentary");
void
clear_momentary(void)
{
  __extension__ ({ struct n64_tag_obstack *__o = (&momentary_obstack); void *__obj = (momentary_stack->base); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}






void
pop_momentary(void) asm("_pop_momentary");
void
pop_momentary(void)
{
  struct n64_tag_momentary_level *tem = momentary_stack;
  momentary_stack = tem->prev;
  expression_obstack = tem->obstack;



  __extension__ ({ struct n64_tag_obstack *__o = (&momentary_obstack); void *__obj = (tem->base); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}




void
pop_momentary_nofree(void) asm("_pop_momentary_nofree");
void
pop_momentary_nofree(void)
{
  struct n64_tag_momentary_level *tem = momentary_stack;
  momentary_stack = tem->prev;
  expression_obstack = tem->obstack;
}





int
suspend_momentary(void) asm("_suspend_momentary");
int
suspend_momentary(void)
{
  register int tem = expression_obstack == &momentary_obstack;
  expression_obstack = saveable_obstack;
  return tem;
}






void
resume_momentary(int yes) asm("_resume_momentary");
void
resume_momentary(int yes)
{
  if (yes)
    expression_obstack = &momentary_obstack;
}




void
init_tree_codes(void) asm("_init_tree_codes");
void
init_tree_codes(void)
{
  tree_code_type = (char **) xmalloc (sizeof (standard_tree_code_type));
  tree_code_length = (int *) xmalloc (sizeof (standard_tree_code_length));
  tree_code_name = (char **) xmalloc (sizeof (standard_tree_code_name));
  memcpy ((char *) tree_code_type,(char *) standard_tree_code_type,sizeof (standard_tree_code_type))
                                   ;
  memcpy ((char *) tree_code_length,(char *) standard_tree_code_length,sizeof (standard_tree_code_length))
                                     ;
  memcpy ((char *) tree_code_name,(char *) standard_tree_code_name,sizeof (standard_tree_code_name))
                                   ;
}
tree
make_node(n64_enum_tree_code code) asm("_make_node");
tree
make_node(n64_enum_tree_code code)
{
  register tree t;
  register int type = (*tree_code_type[(int) (code)]);
  register int length;
  register struct n64_tag_obstack *obstack = current_obstack;
  register int i;
  register tree_node_kind kind;

  switch (type)
    {
    case 'd':



      length = sizeof (struct n64_tag_tree_decl);

      if (obstack != &permanent_obstack)
 obstack = saveable_obstack;
      if (code == PARM_DECL && obstack != &permanent_obstack)
 {
   tree context = 0;
   if (current_function_decl)
     context = decl_function_context (current_function_decl);

   if (context)
     obstack
       = find_function_data (context)->function_maybepermanent_obstack;
 }
      break;

    case 't':



      length = sizeof (struct n64_tag_tree_type);

      if (obstack != &permanent_obstack)
 obstack = all_types_permanent ? &permanent_obstack : saveable_obstack;
      break;

    case 'b':



      length = sizeof (struct n64_tag_tree_block);

      if (obstack != &permanent_obstack)
 obstack = saveable_obstack;
      break;

    case 's':




    case 'r':




    case 'e':
    case '<':
    case '1':
    case '2':




      obstack = expression_obstack;

      if (code == BIND_EXPR && obstack != &permanent_obstack)
 obstack = saveable_obstack;
      length = sizeof (struct n64_tag_tree_exp)
 + (tree_code_length[(int) code] - 1) * sizeof (char *);
      break;

    case 'c':



      obstack = expression_obstack;







      if (code == INTEGER_CST)
 length = sizeof (struct n64_tag_tree_int_cst);
      else if (code == REAL_CST)
 length = sizeof (struct n64_tag_tree_real_cst);
      else
 length = sizeof (struct n64_tag_tree_common)
   + tree_code_length[(int) code] * sizeof (char *);
      break;

    case 'x':
      length = sizeof (struct n64_tag_tree_common)
 + tree_code_length[(int) code] * sizeof (char *);


      if (code == IDENTIFIER_NODE) obstack = &permanent_obstack;
      break;

    default:
      abort ();
    }

  t = (tree) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((length)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });







  for (i = (length / sizeof (int)) - 1; i >= 0; i--)
    ((int *) t)[i] = 0;

  for (i = length / sizeof (int) * sizeof (int); i < length; i++)
    ((char *) t)[i] = 0;

  ((t)->common.code = (int) (code));
  if (obstack == &permanent_obstack)
    ((t)->common.permanent_flag) = 1;

  switch (type)
    {
    case 's':
      ((t)->common.side_effects_flag) = 1;
      ((t)->common.type) = void_type_node;
      break;

    case 'd':
      if (code != FUNCTION_DECL)
 ((t)->decl.frame_size.u) = 1;
      ((t)->decl.in_system_header_flag)
 = in_system_header && (obstack == &permanent_obstack);
      ((t)->decl.linenum) = lineno;
      ((t)->decl.filename) = (input_filename) ? input_filename : "<built-in>";
      ((t)->decl.uid) = next_decl_uid++;
      break;

    case 't':
      ((t)->type.uid) = next_type_uid++;
      ((t)->type.align) = 1;
      ((t)->type.main_variant) = t;
      ((t)->type.obstack) = obstack;
      ((t)->type.attributes) = (tree) 
                           ((void *)0)
                                    ;



      break;

    case 'c':
      ((t)->common.constant_flag) = 1;
      break;
    }

  return t;
}




tree
copy_node(tree node) asm("_copy_node");
tree
copy_node(tree node)
{
  register tree t;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (node)->common.code);
  register int length;
  register int i;

  switch ((*tree_code_type[(int) (code)]))
    {
    case 'd':
      length = sizeof (struct n64_tag_tree_decl);
      break;

    case 't':
      length = sizeof (struct n64_tag_tree_type);
      break;

    case 'b':
      length = sizeof (struct n64_tag_tree_block);
      break;

    case 'r':
    case 'e':
    case 's':
    case '<':
    case '1':
    case '2':
      length = sizeof (struct n64_tag_tree_exp)
 + (tree_code_length[(int) code] - 1) * sizeof (char *);
      break;

    case 'c':





      if (code == INTEGER_CST)
        {
          length = sizeof (struct n64_tag_tree_int_cst);
          break;
        }
      else if (code == REAL_CST)
 {
   length = sizeof (struct n64_tag_tree_real_cst);
   break;
 }

    case 'x':
      length = sizeof (struct n64_tag_tree_common)
 + tree_code_length[(int) code] * sizeof (char *);
      if (code == TREE_VEC)
 length += (((node)->vec.length) - 1) * sizeof (char *);
    }

  t = (tree) __extension__ ({ struct n64_tag_obstack *__h = (current_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((length)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  for (i = (length / sizeof (int)) - 1; i >= 0; i--)
    ((int *) t)[i] = ((int *) node)[i];

  for (i = length / sizeof (int) * sizeof (int); i < length; i++)
    ((char *) t)[i] = ((char *) node)[i];

  ((t)->common.chain) = 0;

  if ((*tree_code_type[(int) (code)]) == 'd')
    ((t)->decl.uid) = next_decl_uid++;
  else if ((*tree_code_type[(int) (code)]) == 't')
    {
      ((t)->type.uid) = next_type_uid++;
      ((t)->type.obstack) = current_obstack;
    }

  ((t)->common.permanent_flag) = (current_obstack == &permanent_obstack);

  return t;
}




tree
copy_list(tree list) asm("_copy_list");
tree
copy_list(tree list)
{
  tree head;
  register tree prev, next;

  if (list == 0)
    return 0;

  head = prev = copy_node (list);
  next = ((list)->common.chain);
  while (next)
    {
      ((prev)->common.chain) = copy_node (next);
      prev = ((prev)->common.chain);
      next = ((next)->common.chain);
    }
  return head;
}







tree
get_identifier(register char *text) asm("_get_identifier");
tree
get_identifier(register char *text)
{
  register int hi;
  register int i;
  register tree idp;
  register int len, hash_len;


  for (len = 0; text[len]; len++);


  hash_len = len;
  if (warn_id_clash && len > id_clash_len)
    hash_len = id_clash_len;


  hi = hash_len * 613 + (unsigned)text[0];
  for (i = 1; i < hash_len; i += 2)
    hi = ((hi * 613) + (unsigned)(text[i]));

  hi &= (1 << 30) - 1;
  hi %= 1009;


  for (idp = hash_table[hi]; idp; idp = ((idp)->common.chain))
    if (((idp)->identifier.length) == len
 && ((idp)->identifier.pointer)[0] == text[0]
 && !memcmp (((idp)->identifier.pointer),text,len))
      return idp;


  if (warn_id_clash && do_identifier_warnings && len >= id_clash_len)
    for (idp = hash_table[hi]; idp; idp = ((idp)->common.chain))
      if (!strncmp (((idp)->identifier.pointer), text, id_clash_len))
 {
   warning ("`%s' and `%s' identical in first %d characters",
     ((idp)->identifier.pointer), text, id_clash_len);
   break;
 }

  if (tree_code_length[(int) IDENTIFIER_NODE] < 0)
    abort ();


  idp = make_node (IDENTIFIER_NODE);
  ((idp)->identifier.length) = len;




  ((idp)->identifier.pointer) = __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((len)); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((text)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  ((idp)->common.chain) = hash_table[hi];
  hash_table[hi] = idp;
  return idp;
}




void
start_identifier_warnings(void) asm("_start_identifier_warnings");
void
start_identifier_warnings(void)
{
  do_identifier_warnings = 1;
}






void
set_identifier_size(int size) asm("_set_identifier_size");
void
set_identifier_size(int size)
{
  tree_code_length[(int) IDENTIFIER_NODE]
    = (size - sizeof (struct n64_tag_tree_common)) / sizeof (tree);
}







tree
build_int_2_wide(int low, int hi) asm("_build_int_2_wide");
tree
build_int_2_wide(int low, int hi)
{
  register tree t = make_node (INTEGER_CST);
  ((t)->int_cst.int_cst_low) = low;
  ((t)->int_cst.int_cst_high) = hi;
  ((t)->common.type) = integer_type_node;
  return t;
}



tree
build_real(tree type, double d) asm("_build_real");
tree
build_real(tree type, double d)
{
  tree v;
  int overflow = 0;







  v = make_node (REAL_CST);
  ((v)->common.type) = type;
  ((v)->real_cst.real_cst) = d;
  ((v)->common.public_flag) = ((v)->common.static_flag) = overflow;
  return v;
}






double
real_value_from_int_cst(tree i) asm("_real_value_from_int_cst");
double
real_value_from_int_cst(tree i)
{
  double d;
  double e;




  if (! ((((i)->common.type))->common.unsigned_flag))
    ereal_from_int (&d, (int) (((i)->int_cst.int_cst_low)), (int) (((i)->int_cst.int_cst_high)));
  else
    (ereal_from_uint (&d, ((i)->int_cst.int_cst_low), ((i)->int_cst.int_cst_high)));
  return d;
}




tree
build_real_from_int_cst(tree type, tree i) asm("_build_real_from_int_cst");
tree
build_real_from_int_cst(tree type, tree i)
{
  tree v;
  int overflow = ((i)->common.public_flag);
  double d;
  jmp_buf float_error;

  v = make_node (REAL_CST);
  ((v)->common.type) = type;

  if (
     _setjmp3((
     float_error
     ), ((void *)0))
                         )
    {
      d = dconst0;
      overflow = 1;
      goto got_it;
    }

  set_float_handler (float_error);

  d = real_value_truncate (((type)->type.mode), real_value_from_int_cst (i));



 got_it:
  set_float_handler (((void *)0));





  ((v)->real_cst.real_cst) = d;
  ((v)->common.public_flag) = ((v)->common.static_flag) = overflow;
  return v;
}







tree
build_string(int len, char *str) asm("_build_string");
tree
build_string(int len, char *str)
{




  register tree s = make_node (STRING_CST);
  ((s)->string.length) = len;
  ((s)->string.pointer) = __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((len)); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((str)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  return s;
}






tree
build_complex(tree real, tree imag) asm("_build_complex");
tree
build_complex(tree real, tree imag)
{
  register tree t = make_node (COMPLEX_CST);

  ((t)->complex.real) = real;
  ((t)->complex.imag) = imag;
  ((t)->common.type) = build_complex_type (((real)->common.type));
  ((t)->common.public_flag) = ((real)->common.public_flag) | ((imag)->common.public_flag);
  ((t)->common.static_flag)
    = ((real)->common.static_flag) | ((imag)->common.static_flag);
  return t;
}


tree
make_tree_vec(int len) asm("_make_tree_vec");
tree
make_tree_vec(int len)
{
  register tree t;
  register int length = (len-1) * sizeof (tree) + sizeof (struct n64_tag_tree_vec);
  register struct n64_tag_obstack *obstack = current_obstack;
  register int i;






  t = (tree) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((length)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  for (i = (length / sizeof (int)) - 1; i >= 0; i--)
    ((int *) t)[i] = 0;

  ((t)->common.code = (int) (TREE_VEC));
  ((t)->vec.length) = len;
  if (obstack == &permanent_obstack)
    ((t)->common.permanent_flag) = 1;

  return t;
}




int
integer_zerop(tree expr) asm("_integer_zerop");
int
integer_zerop(tree expr)
{
  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  return ((((n64_enum_tree_code) (expr)->common.code) == INTEGER_CST
    && ((expr)->int_cst.int_cst_low) == 0
    && ((expr)->int_cst.int_cst_high) == 0)
   || (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
       && integer_zerop (((expr)->complex.real))
       && integer_zerop (((expr)->complex.imag))));
}




int
integer_onep(tree expr) asm("_integer_onep");
int
integer_onep(tree expr)
{
  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  return ((((n64_enum_tree_code) (expr)->common.code) == INTEGER_CST
    && ((expr)->int_cst.int_cst_low) == 1
    && ((expr)->int_cst.int_cst_high) == 0)
   || (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
       && integer_onep (((expr)->complex.real))
       && integer_zerop (((expr)->complex.imag))));
}




int
integer_all_onesp(tree expr) asm("_integer_all_onesp");
int
integer_all_onesp(tree expr)
{
  register int prec;
  register int uns;

  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  if (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
      && integer_all_onesp (((expr)->complex.real))
      && integer_zerop (((expr)->complex.imag)))
    return 1;

  else if (((n64_enum_tree_code) (expr)->common.code) != INTEGER_CST)
    return 0;

  uns = ((((expr)->common.type))->common.unsigned_flag);
  if (!uns)
    return ((expr)->int_cst.int_cst_low) == -1 && ((expr)->int_cst.int_cst_high) == -1;



  prec = (8 * mode_size[(int)(((((expr)->common.type))->type.mode))]);
  if (prec >= 32)
    {
      int high_value, shift_amount;

      shift_amount = prec - 32;

      if (shift_amount > 32)

 abort ();
      else if (shift_amount == 32)


 high_value = -1;
      else
 high_value = ((int) 1 << shift_amount) - 1;

      return ((expr)->int_cst.int_cst_low) == -1
 && ((expr)->int_cst.int_cst_high) == high_value;
    }
  else
    return ((expr)->int_cst.int_cst_low) == ((int) 1 << prec) - 1;
}




int
integer_pow2p(tree expr) asm("_integer_pow2p");
int
integer_pow2p(tree expr)
{
  int high, low;

  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  if (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
      && integer_pow2p (((expr)->complex.real))
      && integer_zerop (((expr)->complex.imag)))
    return 1;

  if (((n64_enum_tree_code) (expr)->common.code) != INTEGER_CST)
    return 0;

  high = ((expr)->int_cst.int_cst_high);
  low = ((expr)->int_cst.int_cst_low);

  if (high == 0 && low == 0)
    return 0;

  return ((high == 0 && (low & (low - 1)) == 0)
   || (low == 0 && (high & (high - 1)) == 0));
}



int
real_zerop(tree expr) asm("_real_zerop");
int
real_zerop(tree expr)
{
  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  return ((((n64_enum_tree_code) (expr)->common.code) == REAL_CST
    && (ereal_cmp ((((expr)->real_cst.real_cst)), (dconst0)) == 0))
   || (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
       && real_zerop (((expr)->complex.real))
       && real_zerop (((expr)->complex.imag))));
}



int
real_onep(tree expr) asm("_real_onep");
int
real_onep(tree expr)
{
  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  return ((((n64_enum_tree_code) (expr)->common.code) == REAL_CST
    && (ereal_cmp ((((expr)->real_cst.real_cst)), (dconst1)) == 0))
   || (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
       && real_onep (((expr)->complex.real))
       && real_zerop (((expr)->complex.imag))));
}



int
real_twop(tree expr) asm("_real_twop");
int
real_twop(tree expr)
{
  while ((((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (expr)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (expr)->common.code) == NON_LVALUE_EXPR) && (((((expr)->common.type))->type.mode) == ((((((expr)->exp.operands[0]))->common.type))->type.mode))) (expr) = ((expr)->exp.operands[0]);;

  return ((((n64_enum_tree_code) (expr)->common.code) == REAL_CST
    && (ereal_cmp ((((expr)->real_cst.real_cst)), (dconst2)) == 0))
   || (((n64_enum_tree_code) (expr)->common.code) == COMPLEX_CST
       && real_twop (((expr)->complex.real))
       && real_zerop (((expr)->complex.imag))));
}



int
really_constant_p(tree exp) asm("_really_constant_p");
int
really_constant_p(tree exp)
{

  while (((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
  || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR
  || ((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR)
    exp = ((exp)->exp.operands[0]);
  return ((exp)->common.constant_flag);
}




tree
value_member(tree elem, tree list) asm("_value_member");
tree
value_member(tree elem, tree list)
{
  while (list)
    {
      if (elem == ((list)->list.value))
 return list;
      list = ((list)->common.chain);
    }
  return (tree) 
        ((void *)0)
                 ;
}




tree
purpose_member(tree elem, tree list) asm("_purpose_member");
tree
purpose_member(tree elem, tree list)
{
  while (list)
    {
      if (elem == ((list)->list.purpose))
 return list;
      list = ((list)->common.chain);
    }
  return (tree) 
        ((void *)0)
                 ;
}




tree
binfo_member(tree elem, tree list) asm("_binfo_member");
tree
binfo_member(tree elem, tree list)
{
  while (list)
    {
      if (elem == ((list)->common.type))
 return list;
      list = ((list)->common.chain);
    }
  return (tree) 
        ((void *)0)
                 ;
}



int
chain_member(tree elem, tree chain) asm("_chain_member");
int
chain_member(tree elem, tree chain)
{
  while (chain)
    {
      if (elem == chain)
 return 1;
      chain = ((chain)->common.chain);
    }

  return 0;
}







int
chain_member_value(tree elem, tree chain) asm("_chain_member_value");
int
chain_member_value(tree elem, tree chain)
{
  while (chain)
    {
      if (elem == ((chain)->list.value))
 return 1;
      chain = ((chain)->common.chain);
    }

  return 0;
}







int
chain_member_purpose(tree elem, tree chain) asm("_chain_member_purpose");
int
chain_member_purpose(tree elem, tree chain)
{
  while (chain)
    {
      if (elem == ((chain)->list.purpose))
 return 1;
      chain = ((chain)->common.chain);
    }

  return 0;
}





int
list_length(tree t) asm("_list_length");
int
list_length(tree t)
{
  register tree tail;
  register int len = 0;

  for (tail = t; tail; tail = ((tail)->common.chain))
    len++;

  return len;
}





tree
chainon(tree op1, tree op2) asm("_chainon");
tree
chainon(tree op1, tree op2)
{

  if (op1)
    {
      register tree t1;
      register tree t2;

      for (t1 = op1; ((t1)->common.chain); t1 = ((t1)->common.chain))
 ;
      ((t1)->common.chain) = op2;
      for (t2 = op2; t2; t2 = ((t2)->common.chain))
        if (t2 == t1)
          abort ();
      return op1;
    }
  else return op2;
}



tree
tree_last(register tree chain) asm("_tree_last");
tree
tree_last(register tree chain)
{
  register tree next;
  if (chain)
    while (next = ((chain)->common.chain))
      chain = next;
  return chain;
}




tree
nreverse(tree t) asm("_nreverse");
tree
nreverse(tree t)
{
  register tree prev = 0, decl, next;
  for (decl = t; decl; decl = next)
    {
      next = ((decl)->common.chain);
      ((decl)->common.chain) = prev;
      prev = decl;
    }
  return prev;
}




tree
listify(tree chain) asm("_listify");
tree
listify(tree chain)
{
  tree result = (tree) 
               ((void *)0)
                        ;
  tree in_tail = chain;
  tree out_tail = (tree) 
                 ((void *)0)
                          ;

  while (in_tail)
    {
      tree next = tree_cons ((tree) 
                            ((void *)0)
                                     , in_tail, (tree) 
                                                ((void *)0)
                                                         );
      if (out_tail)
 ((out_tail)->common.chain) = next;
      else
 result = next;
      out_tail = next;
      in_tail = ((in_tail)->common.chain);
    }

  return result;
}




tree
build_tree_list(tree parm, tree value) asm("_build_tree_list");
tree
build_tree_list(tree parm, tree value)
{
  register tree t = make_node (TREE_LIST);
  ((t)->list.purpose) = parm;
  ((t)->list.value) = value;
  return t;
}



tree
build_decl_list(tree parm, tree value) asm("_build_decl_list");
tree
build_decl_list(tree parm, tree value)
{
  register tree node;
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = &temp_decl_obstack;
  node = build_tree_list (parm, value);
  current_obstack = ambient_obstack;
  return node;
}





tree
tree_cons(tree purpose, tree value, tree chain) asm("_tree_cons");
tree
tree_cons(tree purpose, tree value, tree chain)
{



  register int i;
  register tree node = (tree) __extension__ ({ struct n64_tag_obstack *__h = (current_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_tree_list))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });





  for (i = (sizeof (struct n64_tag_tree_common) / sizeof (int)) - 1; i >= 0; i--)
    ((int *) node)[i] = 0;

  ((node)->common.code = (int) (TREE_LIST));
  if (current_obstack == &permanent_obstack)
    ((node)->common.permanent_flag) = 1;


  ((node)->common.chain) = chain;
  ((node)->list.purpose) = purpose;
  ((node)->list.value) = value;
  return node;
}



tree
decl_tree_cons(tree purpose, tree value, tree chain) asm("_decl_tree_cons");
tree
decl_tree_cons(tree purpose, tree value, tree chain)
{
  register tree node;
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = &temp_decl_obstack;
  node = tree_cons (purpose, value, chain);
  current_obstack = ambient_obstack;
  return node;
}



tree
perm_tree_cons(tree purpose, tree value, tree chain) asm("_perm_tree_cons");
tree
perm_tree_cons(tree purpose, tree value, tree chain)
{
  register tree node;
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = &permanent_obstack;

  node = tree_cons (purpose, value, chain);
  current_obstack = ambient_obstack;
  return node;
}



tree
temp_tree_cons(tree purpose, tree value, tree chain) asm("_temp_tree_cons");
tree
temp_tree_cons(tree purpose, tree value, tree chain)
{
  register tree node;
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = &temporary_obstack;

  node = tree_cons (purpose, value, chain);
  current_obstack = ambient_obstack;
  return node;
}



tree
saveable_tree_cons(tree purpose, tree value, tree chain) asm("_saveable_tree_cons");
tree
saveable_tree_cons(tree purpose, tree value, tree chain)
{
  register tree node;
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = saveable_obstack;

  node = tree_cons (purpose, value, chain);
  current_obstack = ambient_obstack;
  return node;
}







tree
size_in_bytes(tree type) asm("_size_in_bytes");
tree
size_in_bytes(tree type)
{
  tree t;

  if (type == error_mark_node)
    return integer_zero_node;
  type = ((type)->type.main_variant);
  if (((type)->type.size) == 0)
    {
      incomplete_type_error ((tree) 
                            ((void *)0)
                                     , type);
      return integer_zero_node;
    }
  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
    size_int (8));
  if (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST)
    force_fit_type (t, 0);
  return t;
}




int
int_size_in_bytes(tree type) asm("_int_size_in_bytes");
int
int_size_in_bytes(tree type)
{
  unsigned int size;
  if (type == error_mark_node)
    return 0;
  type = ((type)->type.main_variant);
  if (((type)->type.size) == 0)
    return -1;
  if (((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
    return -1;
  if (((((type)->type.size))->int_cst.int_cst_high) != 0)
    {
      tree t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
      size_int (8));
      return ((t)->int_cst.int_cst_low);
    }
  size = ((((type)->type.size))->int_cst.int_cst_low);
  return (size + 8 - 1) / 8;
}




tree
array_type_nelts(tree type) asm("_array_type_nelts");
tree
array_type_nelts(tree type)
{
  tree index_type = ((type)->type.values);

  return (integer_zerop (((index_type)->type.minval))
   ? ((index_type)->type.maxval)
   : fold (build (MINUS_EXPR, ((((index_type)->type.maxval))->common.type),
    ((index_type)->type.maxval),
    ((index_type)->type.minval))));
}




int
staticp(tree arg) asm("_staticp");
int
staticp(tree arg)
{
  switch (((n64_enum_tree_code) (arg)->common.code))
    {
    case FUNCTION_DECL:


       return decl_function_context (arg) == 0;
    case VAR_DECL:
      return ((arg)->common.static_flag) || ((arg)->decl.external_flag);

    case CONSTRUCTOR:
      return ((arg)->common.static_flag);

    case STRING_CST:
      return 1;

    case COMPONENT_REF:
    case BIT_FIELD_REF:
      return staticp (((arg)->exp.operands[0]));
    case ARRAY_REF:
      if (((n64_enum_tree_code) (((((arg)->common.type))->type.size))->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (((arg)->exp.operands[1]))->common.code) == INTEGER_CST)
 return staticp (((arg)->exp.operands[0]));
    }

  return 0;
}
tree
save_expr(tree expr) asm("_save_expr");
tree
save_expr(tree expr)
{
  register tree t = fold (expr);



  while (((n64_enum_tree_code) (t)->common.code) == NON_LVALUE_EXPR)
    t = ((t)->exp.operands[0]);







  if (((t)->common.constant_flag) || (((t)->common.readonly_flag) && ! ((t)->common.side_effects_flag))
      || ((n64_enum_tree_code) (t)->common.code) == SAVE_EXPR || ((n64_enum_tree_code) (t)->common.code) == ERROR_MARK)
    return t;
  if (contains_placeholder_p (t))
    return t;

  t = build (SAVE_EXPR, ((expr)->common.type), t, current_function_decl, (tree) 
                                                                   ((void *)0)
                                                                            );




  ((t)->common.side_effects_flag) = 1;
  return t;
}







int
contains_placeholder_p(tree exp) asm("_contains_placeholder_p");
int
contains_placeholder_p(tree exp)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);
  tree inner;



  if (code == WITH_RECORD_EXPR)
    return 0;

  switch ((*tree_code_type[(int) (code)]))
    {
    case 'r':
      for (inner = ((exp)->exp.operands[0]);
    (*tree_code_type[(int) (((n64_enum_tree_code) (inner)->common.code))]) == 'r';
    inner = ((inner)->exp.operands[0]))
 ;
      return ((n64_enum_tree_code) (inner)->common.code) == PLACEHOLDER_EXPR;

    case '1':
    case '2': case '<':
    case 'e':
      switch (tree_code_length[(int) code])
 {
 case 1:
   return contains_placeholder_p (((exp)->exp.operands[0]));
 case 2:
   return (code != RTL_EXPR
    && code != CONSTRUCTOR
    && ! (code == SAVE_EXPR && (*(struct rtx_def **) &(exp)->exp.operands[2]) != 0)
    && code != WITH_RECORD_EXPR
    && (contains_placeholder_p (((exp)->exp.operands[0]))
        || contains_placeholder_p (((exp)->exp.operands[1]))));
 case 3:
   return (code == COND_EXPR
    && (contains_placeholder_p (((exp)->exp.operands[0]))
        || contains_placeholder_p (((exp)->exp.operands[1]))
        || contains_placeholder_p (((exp)->exp.operands[2]))));
 }
    }

  return 0;
}






tree
substitute_in_expr(tree exp, tree f, tree r) asm("_substitute_in_expr");
tree
substitute_in_expr(tree exp, tree f, tree r)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);
  tree cxx_new = 0;
  tree inner;

  switch ((*tree_code_type[(int) (code)]))
    {
    case 'c':
    case 'd':
      return exp;

    case 'x':
      if (code == PLACEHOLDER_EXPR)
 return exp;
      break;

    case '1':
    case '2':
    case '<':
    case 'e':
      switch (tree_code_length[(int) code])
 {
 case 1:
   cxx_new = fold (build1 (code, ((exp)->common.type),
         substitute_in_expr (((exp)->exp.operands[0]),
        f, r)));
   break;

 case 2:


   if (code == RTL_EXPR)
     return exp;
   else if (code == CONSTRUCTOR)
     abort ();

   cxx_new = fold (build (code, ((exp)->common.type),
        substitute_in_expr (((exp)->exp.operands[0]), f, r),
        substitute_in_expr (((exp)->exp.operands[1]),
       f, r)));
   break;

 case 3:


   if (code == SAVE_EXPR)
     return exp;

   if (code != COND_EXPR)
     abort ();

   cxx_new = fold (build (code, ((exp)->common.type),
        substitute_in_expr (((exp)->exp.operands[0]), f, r),
        substitute_in_expr (((exp)->exp.operands[1]), f, r),
        substitute_in_expr (((exp)->exp.operands[2]),
       f, r)));
 }

      break;

    case 'r':
      switch (code)
 {
 case COMPONENT_REF:


   for (inner = ((exp)->exp.operands[0]);
        (*tree_code_type[(int) (((n64_enum_tree_code) (inner)->common.code))]) == 'r';
        inner = ((inner)->exp.operands[0]))
     ;
   if (((n64_enum_tree_code) (inner)->common.code) == PLACEHOLDER_EXPR
       && ((exp)->exp.operands[1]) == f)
     return r;

   cxx_new = fold (build (code, ((exp)->common.type),
        substitute_in_expr (((exp)->exp.operands[0]), f, r),
        ((exp)->exp.operands[1])));
   break;

 case BIT_FIELD_REF:
   cxx_new = fold (build (code, ((exp)->common.type),
        substitute_in_expr (((exp)->exp.operands[0]), f, r),
        substitute_in_expr (((exp)->exp.operands[1]), f, r),
        substitute_in_expr (((exp)->exp.operands[2]), f, r)));
   break;

 case INDIRECT_REF:
 case BUFFER_REF:
   cxx_new = fold (build1 (code, ((exp)->common.type),
         substitute_in_expr (((exp)->exp.operands[0]),
        f, r)));
   break;

 case OFFSET_REF:
   cxx_new = fold (build (code, ((exp)->common.type),
        substitute_in_expr (((exp)->exp.operands[0]), f, r),
        substitute_in_expr (((exp)->exp.operands[1]), f, r)));
   break;
 }
    }


  if (cxx_new == 0)
    abort ();

  ((cxx_new)->common.readonly_flag) = ((exp)->common.readonly_flag);
  return cxx_new;
}





tree
substitute_in_type(tree t, tree f, tree r) asm("_substitute_in_type");
tree
substitute_in_type(tree t, tree f, tree r)
{
  switch (((n64_enum_tree_code) (t)->common.code))
    {
    case POINTER_TYPE:
    case VOID_TYPE:
      return t;
    case INTEGER_TYPE:
    case ENUMERAL_TYPE:
    case BOOLEAN_TYPE:
    case CHAR_TYPE:
      if ((((n64_enum_tree_code) (((t)->type.minval))->common.code) != INTEGER_CST
    && contains_placeholder_p (((t)->type.minval)))
   || (((n64_enum_tree_code) (((t)->type.maxval))->common.code) != INTEGER_CST
       && contains_placeholder_p (((t)->type.maxval))))
 return build_range_type (t,
     substitute_in_expr (((t)->type.minval), f, r),
     substitute_in_expr (((t)->type.maxval), f, r));
      return t;

    case REAL_TYPE:
      if ((((t)->type.minval) != 0
    && ((n64_enum_tree_code) (((t)->type.minval))->common.code) != REAL_CST
    && contains_placeholder_p (((t)->type.minval)))
   || (((t)->type.maxval) != 0
       && ((n64_enum_tree_code) (((t)->type.maxval))->common.code) != REAL_CST
       && contains_placeholder_p (((t)->type.maxval))))
 {
   t = build_type_copy (t);

   if (((t)->type.minval))
     ((t)->type.minval) = substitute_in_expr (((t)->type.minval), f, r);
   if (((t)->type.maxval))
     ((t)->type.maxval) = substitute_in_expr (((t)->type.maxval), f, r);
 }
      return t;

    case COMPLEX_TYPE:
      return build_complex_type (substitute_in_type (((t)->common.type), f, r));

    case OFFSET_TYPE:
    case METHOD_TYPE:
    case REFERENCE_TYPE:
    case FILE_TYPE:
    case SET_TYPE:
    case FUNCTION_TYPE:
    case LANG_TYPE:

      abort ();

    case ARRAY_TYPE:
      t = build_array_type (substitute_in_type (((t)->common.type), f, r),
       substitute_in_type (((t)->type.values), f, r));
      ((t)->type.size) = 0;
      layout_type (t);
      return t;

    case RECORD_TYPE:
    case UNION_TYPE:
    case QUAL_UNION_TYPE:
      {
 tree cxx_new = copy_node (t);
 tree field;
 tree last_field = 0;




 ((cxx_new)->type.values) = 0;
 ((cxx_new)->type.size) = 0;

 for (field = ((t)->type.values); field;
      field = ((field)->common.chain))
   {
     tree new_field = copy_node (field);

     ((new_field)->common.type)
       = substitute_in_type (((new_field)->common.type), f, r);





     if (((n64_enum_tree_code) (t)->common.code) != QUAL_UNION_TYPE && ((new_field)->decl.name) == 0
  && (((n64_enum_tree_code) (((new_field)->common.type))->common.code) == UNION_TYPE
      || ((n64_enum_tree_code) (((new_field)->common.type))->common.code) == RECORD_TYPE))
       {
  if (((((new_field)->common.type))->type.values) == 0)
    continue;

  if (((((((new_field)->common.type))->type.values))->common.chain) == 0)
    new_field = ((((new_field)->common.type))->type.values);
       }

     ((new_field)->decl.context) = cxx_new;
     ((new_field)->decl.size) = 0;

     if (((n64_enum_tree_code) (t)->common.code) == QUAL_UNION_TYPE)
       {


  ((new_field)->decl.initial)
    = substitute_in_expr (((field)->decl.initial), f, r);
  if (integer_zerop (((new_field)->decl.initial)))
    continue;
       }

     if (last_field == 0)
       ((cxx_new)->type.values) = new_field;
     else
       ((last_field)->common.chain) = new_field;

     last_field = new_field;



     if (((n64_enum_tree_code) (t)->common.code) == QUAL_UNION_TYPE
  && integer_onep (((new_field)->decl.initial)))
       break;
   }



 if (((n64_enum_tree_code) (cxx_new)->common.code) == QUAL_UNION_TYPE
     && (((cxx_new)->type.values) == 0
  || integer_onep (((((cxx_new)->type.values))->decl.initial))))
   ((cxx_new)->common.code = (int) (UNION_TYPE));

 layout_type (cxx_new);
 return cxx_new;
      }
    }
}
tree
stabilize_reference(tree ref) asm("_stabilize_reference");
tree
stabilize_reference(tree ref)
{
  register tree result;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (ref)->common.code);

  switch (code)
    {
    case VAR_DECL:
    case PARM_DECL:
    case RESULT_DECL:

      return ref;

    case NOP_EXPR:
    case CONVERT_EXPR:
    case FLOAT_EXPR:
    case FIX_TRUNC_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_ROUND_EXPR:
    case FIX_CEIL_EXPR:
      result = build_nt (code, stabilize_reference (((ref)->exp.operands[0])));
      break;

    case INDIRECT_REF:
      result = build_nt (INDIRECT_REF,
    stabilize_reference_1 (((ref)->exp.operands[0])));
      break;

    case COMPONENT_REF:
      result = build_nt (COMPONENT_REF,
    stabilize_reference (((ref)->exp.operands[0])),
    ((ref)->exp.operands[1]));
      break;

    case BIT_FIELD_REF:
      result = build_nt (BIT_FIELD_REF,
    stabilize_reference (((ref)->exp.operands[0])),
    stabilize_reference_1 (((ref)->exp.operands[1])),
    stabilize_reference_1 (((ref)->exp.operands[2])));
      break;

    case ARRAY_REF:
      result = build_nt (ARRAY_REF,
    stabilize_reference (((ref)->exp.operands[0])),
    stabilize_reference_1 (((ref)->exp.operands[1])));
      break;

    case COMPOUND_EXPR:
      result = build_nt (COMPOUND_EXPR,
    stabilize_reference_1 (((ref)->exp.operands[0])),
    stabilize_reference (((ref)->exp.operands[1])));
      break;

    case RTL_EXPR:
      result = build1 (INDIRECT_REF, ((ref)->common.type),
         save_expr (build1 (ADDR_EXPR,
       build_pointer_type (((ref)->common.type)),
       ref)));
      break;




    default:
      return ref;

    case ERROR_MARK:
      return error_mark_node;
    }

  ((result)->common.type) = ((ref)->common.type);
  ((result)->common.readonly_flag) = ((ref)->common.readonly_flag);
  ((result)->common.side_effects_flag) = ((ref)->common.side_effects_flag);
  ((result)->common.volatile_flag) = ((ref)->common.volatile_flag);
  ((result)->common.raises_flag) = ((ref)->common.raises_flag);

  return result;
}
tree
stabilize_reference_1(tree e) asm("_stabilize_reference_1");
tree
stabilize_reference_1(tree e)
{
  register tree result;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (e)->common.code);






  if (((e)->common.constant_flag) || code == SAVE_EXPR)
    return e;

  switch ((*tree_code_type[(int) (code)]))
    {
    case 'x':
    case 't':
    case 'd':
    case 'b':
    case '<':
    case 's':
    case 'e':
    case 'r':




      if (((e)->common.side_effects_flag))
 return save_expr (e);
      return e;

    case 'c':


      return e;

    case '2':



      if (code == TRUNC_DIV_EXPR || code == TRUNC_MOD_EXPR
   || code == FLOOR_DIV_EXPR || code == FLOOR_MOD_EXPR
   || code == CEIL_DIV_EXPR || code == CEIL_MOD_EXPR
   || code == ROUND_DIV_EXPR || code == ROUND_MOD_EXPR)
 return save_expr (e);

      result = build_nt (code, stabilize_reference_1 (((e)->exp.operands[0])),
    stabilize_reference_1 (((e)->exp.operands[1])));
      break;

    case '1':

      result = build_nt (code, stabilize_reference_1 (((e)->exp.operands[0])));
      break;

    default:
      abort ();
    }

  ((result)->common.type) = ((e)->common.type);
  ((result)->common.readonly_flag) = ((e)->common.readonly_flag);
  ((result)->common.side_effects_flag) = ((e)->common.side_effects_flag);
  ((result)->common.volatile_flag) = ((e)->common.volatile_flag);
  ((result)->common.raises_flag) = ((e)->common.raises_flag);

  return result;
}
tree
build (n64_enum_tree_code code, tree tt, ...) asm("_build");
tree
build (n64_enum_tree_code code, tree tt, ...)
{




  va_list p;
  register tree t;
  register int length;
  register int i;

  
 __builtin_va_start(
 p
 ,
 tt
 )
                 ;






  t = make_node (code);
  length = tree_code_length[(int) code];
  ((t)->common.type) = tt;

  if (length == 2)
    {

      register tree arg0 = 
                          __builtin_va_arg(
                          p
                          ,
                          tree
                          )
                                          ;
      register tree arg1 = 
                          __builtin_va_arg(
                          p
                          ,
                          tree
                          )
                                          ;
      ((t)->exp.operands[0]) = arg0;
      ((t)->exp.operands[1]) = arg1;
      if ((arg0 && ((arg0)->common.side_effects_flag))
   || (arg1 && ((arg1)->common.side_effects_flag)))
 ((t)->common.side_effects_flag) = 1;
      ((t)->common.raises_flag)
 = (arg0 && ((arg0)->common.raises_flag)) || (arg1 && ((arg1)->common.raises_flag));
    }
  else if (length == 1)
    {
      register tree arg0 = 
                          __builtin_va_arg(
                          p
                          ,
                          tree
                          )
                                          ;


      if ((*tree_code_type[(int) (code)]) != 's')
 abort ();
      ((t)->exp.operands[0]) = arg0;
      if (arg0 && ((arg0)->common.side_effects_flag))
 ((t)->common.side_effects_flag) = 1;
      ((t)->common.raises_flag) = (arg0 && ((arg0)->common.raises_flag));
    }
  else
    {
      for (i = 0; i < length; i++)
 {
   register tree operand = 
                          __builtin_va_arg(
                          p
                          ,
                          tree
                          )
                                          ;
   ((t)->exp.operands[i]) = operand;
   if (operand)
     {
       if (((operand)->common.side_effects_flag))
  ((t)->common.side_effects_flag) = 1;
       if (((operand)->common.raises_flag))
  ((t)->common.raises_flag) = 1;
     }
 }
    }
  
 __builtin_va_end(
 p
 )
           ;
  return t;
}




tree
build1(n64_enum_tree_code code, tree type, tree node) asm("_build1");
tree
build1(n64_enum_tree_code code, tree type, tree node)
{
  register struct n64_tag_obstack *obstack = current_obstack;
  register int i, length;
  register tree_node_kind kind;
  register tree t;
  obstack = expression_obstack;
  length = sizeof (struct n64_tag_tree_exp);

  t = (tree) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((length)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });






  for (i = (length / sizeof (int)) - 1; i >= 0; i--)
    ((int *) t)[i] = 0;

  ((t)->common.type) = type;
  ((t)->common.code = (int) (code));

  if (obstack == &permanent_obstack)
    ((t)->common.permanent_flag) = 1;

  ((t)->exp.operands[0]) = node;
  if (node)
    {
      if (((node)->common.side_effects_flag))
 ((t)->common.side_effects_flag) = 1;
      if (((node)->common.raises_flag))
 ((t)->common.raises_flag) = 1;
    }

  return t;
}






tree
build_nt (n64_enum_tree_code code, ...) asm("_build_nt");
tree
build_nt (n64_enum_tree_code code, ...)
{



  va_list p;
  register tree t;
  register int length;
  register int i;

  
 __builtin_va_start(
 p
 ,
 code
 )
                   ;





  t = make_node (code);
  length = tree_code_length[(int) code];

  for (i = 0; i < length; i++)
    ((t)->exp.operands[i]) = 
                         __builtin_va_arg(
                         p
                         ,
                         tree
                         )
                                         ;

  
 __builtin_va_end(
 p
 )
           ;
  return t;
}




tree
build_parse_node (n64_enum_tree_code code, ...) asm("_build_parse_node");
tree
build_parse_node (n64_enum_tree_code code, ...)
{



  register struct n64_tag_obstack *ambient_obstack = expression_obstack;
  va_list p;
  register tree t;
  register int length;
  register int i;

  
 __builtin_va_start(
 p
 ,
 code
 )
                   ;





  expression_obstack = &temp_decl_obstack;

  t = make_node (code);
  length = tree_code_length[(int) code];

  for (i = 0; i < length; i++)
    ((t)->exp.operands[i]) = 
                         __builtin_va_arg(
                         p
                         ,
                         tree
                         )
                                         ;

  
 __builtin_va_end(
 p
 )
           ;
  expression_obstack = ambient_obstack;
  return t;
}
tree
build_decl(n64_enum_tree_code code, tree name, tree type) asm("_build_decl");
tree
build_decl(n64_enum_tree_code code, tree name, tree type)
{
  register tree t;

  t = make_node (code);






  ((t)->decl.name) = name;
  ((t)->decl.assembler_name) = name;
  ((t)->common.type) = type;

  if (code == VAR_DECL || code == PARM_DECL || code == RESULT_DECL)
    layout_decl (t, 0);
  else if (code == FUNCTION_DECL)
    ((t)->decl.mode) = ((target_flags & 0x00000002) ? DImode : SImode);

  return t;
}





tree
build_block(tree vars, tree tags, tree subblocks, tree supercontext, tree chain) asm("_build_block");
tree
build_block(tree vars, tree tags, tree subblocks, tree supercontext, tree chain)
{
  register tree block = make_node (BLOCK);
  ((block)->block.vars) = vars;
  ((block)->block.type_tags) = tags;
  ((block)->block.subblocks) = subblocks;
  ((block)->block.supercontext) = supercontext;
  ((block)->common.chain) = chain;
  return block;
}




tree
build_decl_attribute_variant(tree ddecl, tree attribute) asm("_build_decl_attribute_variant");
tree
build_decl_attribute_variant(tree ddecl, tree attribute)
{
  ((ddecl)->decl.machine_attributes) = attribute;
  return ddecl;
}






tree
build_type_attribute_variant(tree ttype, tree attribute) asm("_build_type_attribute_variant");
tree
build_type_attribute_variant(tree ttype, tree attribute)
{
  if ( ! attribute_list_equal (((ttype)->type.attributes), attribute))
    {
      register int hashcode;
      register struct n64_tag_obstack *ambient_obstack = current_obstack;
      tree ntype;

      if (ambient_obstack != &permanent_obstack)
        current_obstack = ((ttype)->type.obstack);

      ntype = copy_node (ttype);
      current_obstack = ambient_obstack;

      ((ntype)->type.pointer_to) = 0;
      ((ntype)->type.reference_to) = 0;
      ((ntype)->type.attributes) = attribute;


      ((ntype)->type.main_variant) = ntype;
      ((ntype)->type.next_variant) = 0;
      ((ntype)->common.readonly_flag) = ((ntype)->common.volatile_flag) = 0;

      hashcode = ((int) (((n64_enum_tree_code) (ntype)->common.code)) & 0777777)
   + ((int) (((ntype)->common.type)) & 0777777)
   + attribute_hash_list (attribute);

      switch (((n64_enum_tree_code) (ntype)->common.code))
        {
   case FUNCTION_TYPE:
     hashcode += ((int) (((ntype)->type.values)) & 0777777);
     break;
   case ARRAY_TYPE:
     hashcode += ((int) (((ntype)->type.values)) & 0777777);
     break;
   case INTEGER_TYPE:
     hashcode += ((int) (((ntype)->type.maxval)) & 0777777);
     break;
   case REAL_TYPE:
     hashcode += ((int) (((ntype)->type.precision)) & 0777777);
     break;
        }

      ntype = type_hash_canon (hashcode, ntype);
      ttype = build_type_variant (ntype, ((ttype)->common.readonly_flag),
      ((ttype)->common.volatile_flag));
    }

  return ttype;
}





int
valid_machine_attribute(tree attr_name, tree attr_args, tree decl, tree type) asm("_valid_machine_attribute");
int
valid_machine_attribute(tree attr_name, tree attr_args, tree decl, tree type)
{
  int valid = 0;
  tree decl_attr_list = decl != 0 ? ((decl)->decl.machine_attributes) : 0;
  tree type_attr_list = ((type)->type.attributes);

  if (((n64_enum_tree_code) (attr_name)->common.code) != IDENTIFIER_NODE)
    abort ();
  return valid;
}
int
is_attribute_p(char *attr, tree ident) asm("_is_attribute_p");
int
is_attribute_p(char *attr, tree ident)
{
  int ident_len, attr_len;
  char *p;

  if (((n64_enum_tree_code) (ident)->common.code) != IDENTIFIER_NODE)
    return 0;

  if (strcmp (attr, ((ident)->identifier.pointer)) == 0)
    return 1;

  p = ((ident)->identifier.pointer);
  ident_len = strlen (p);
  attr_len = strlen (attr);


  if (attr[0] == '_')
    {
      if (attr[1] != '_'
   || attr[attr_len - 2] != '_'
   || attr[attr_len - 1] != '_')
 abort ();
      if (ident_len == attr_len - 4
   && strncmp (attr + 2, p, attr_len - 4) == 0)
 return 1;
    }
  else
    {
      if (ident_len == attr_len + 4
   && p[0] == '_' && p[1] == '_'
   && p[ident_len - 2] == '_' && p[ident_len - 1] == '_'
   && strncmp (attr, p + 2, attr_len) == 0)
 return 1;
    }

  return 0;
}





tree
lookup_attribute(char *attr_name, tree list) asm("_lookup_attribute");
tree
lookup_attribute(char *attr_name, tree list)
{
  tree l;

  for (l = list; l; l = ((l)->common.chain))
    {
      if (((n64_enum_tree_code) (((l)->list.purpose))->common.code) != IDENTIFIER_NODE)
 abort ();
      if (is_attribute_p (attr_name, ((l)->list.purpose)))
 return l;
    }

  return (tree) 
        ((void *)0)
                 ;
}
tree
build_type_variant(tree type, int constp, int volatilep) asm("_build_type_variant");
tree
build_type_variant(tree type, int constp, int volatilep)
{
  register tree t;


  constp = !!constp;
  volatilep = !!volatilep;





  for (t = ((type)->type.main_variant); t; t = ((t)->type.next_variant))
    if (constp == ((t)->common.readonly_flag) && volatilep == ((t)->common.volatile_flag)
 && ((t)->type.name) == ((type)->type.name))
      return t;



  t = build_type_copy (type);
  ((t)->common.readonly_flag) = constp;
  ((t)->common.volatile_flag) = volatilep;

  return t;
}





void
change_main_variant(tree type, tree new_main) asm("_change_main_variant");
void
change_main_variant(tree type, tree new_main)
{
  tree t;
  tree omain = ((type)->type.main_variant);


  if (((omain)->type.next_variant) == type)
    ((omain)->type.next_variant) = ((type)->type.next_variant);
  else
    for (t = ((omain)->type.next_variant); t && ((t)->type.next_variant);
  t = ((t)->type.next_variant))
      if (((t)->type.next_variant) == type)
 {
   ((t)->type.next_variant) = ((type)->type.next_variant);
   break;
 }

  ((type)->type.main_variant) = new_main;
  ((type)->type.next_variant) = ((new_main)->type.next_variant);
  ((new_main)->type.next_variant) = type;
}




tree
build_type_copy(tree type) asm("_build_type_copy");
tree
build_type_copy(tree type)
{
  register tree t, m = ((type)->type.main_variant);
  register struct n64_tag_obstack *ambient_obstack = current_obstack;

  current_obstack = ((type)->type.obstack);
  t = copy_node (type);
  current_obstack = ambient_obstack;

  ((t)->type.pointer_to) = 0;
  ((t)->type.reference_to) = 0;


  ((t)->type.next_variant) = ((m)->type.next_variant);
  ((m)->type.next_variant) = t;

  return t;
}







struct n64_tag_type_hash
{
  struct n64_tag_type_hash *next;
  int hashcode;
  tree type;
};
struct n64_tag_type_hash *type_hash_table[59];





int
type_hash_list(tree list) asm("_type_hash_list");
int
type_hash_list(tree list)
{
  register int hashcode;
  register tree tail;
  for (hashcode = 0, tail = list; tail; tail = ((tail)->common.chain))
    hashcode += ((int) (((tail)->list.value)) & 0777777);
  return hashcode;
}




tree
type_hash_lookup(int hashcode, tree type) asm("_type_hash_lookup");
tree
type_hash_lookup(int hashcode, tree type)
{
  register struct n64_tag_type_hash *h;
  for (h = type_hash_table[hashcode % 59]; h; h = h->next)
    if (h->hashcode == hashcode
 && ((n64_enum_tree_code) (h->type)->common.code) == ((n64_enum_tree_code) (type)->common.code)
 && ((h->type)->common.type) == ((type)->common.type)
        && attribute_list_equal (((h->type)->type.attributes),
       ((type)->type.attributes))
 && (((h->type)->type.maxval) == ((type)->type.maxval)
     || tree_int_cst_equal (((h->type)->type.maxval),
       ((type)->type.maxval)))
 && (((h->type)->type.minval) == ((type)->type.minval)
     || tree_int_cst_equal (((h->type)->type.minval),
       ((type)->type.minval)))

 && (((h->type)->type.values) == ((type)->type.values)
     || (((h->type)->type.values)
  && ((n64_enum_tree_code) (((h->type)->type.values))->common.code) == TREE_LIST
  && ((type)->type.values)
  && ((n64_enum_tree_code) (((type)->type.values))->common.code) == TREE_LIST
  && type_list_equal (((h->type)->type.values),
        ((type)->type.values)))))
      return h->type;
  return 0;
}




void
type_hash_add(int hashcode, tree type) asm("_type_hash_add");
void
type_hash_add(int hashcode, tree type)
{
  register struct n64_tag_type_hash *h;

  h = (struct n64_tag_type_hash *) oballoc (sizeof (struct n64_tag_type_hash));
  h->hashcode = hashcode;
  h->type = type;
  h->next = type_hash_table[hashcode % 59];
  type_hash_table[hashcode % 59] = h;
}
int debug_no_type_hash = 0;

tree
type_hash_canon(int hashcode, tree type) asm("_type_hash_canon");
tree
type_hash_canon(int hashcode, tree type)
{
  tree t1;

  if (debug_no_type_hash)
    return type;

  t1 = type_hash_lookup (hashcode, type);
  if (t1 != 0)
    {
      __extension__ ({ struct n64_tag_obstack *__o = (((type)->type.obstack)); void *__obj = (type); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });




      return t1;
    }


  if (((type)->common.permanent_flag))
    type_hash_add (hashcode, type);

  return type;
}





int
attribute_hash_list(tree list) asm("_attribute_hash_list");
int
attribute_hash_list(tree list)
{
  register int hashcode;
  register tree tail;
  for (hashcode = 0, tail = list; tail; tail = ((tail)->common.chain))

    hashcode += ((int) (((tail)->list.purpose)) & 0777777);
  return hashcode;
}




int
attribute_list_equal(tree l1, tree l2) asm("_attribute_list_equal");
int
attribute_list_equal(tree l1, tree l2)
{
   return attribute_list_contained (l1, l2)
   && attribute_list_contained (l2, l1);
}
int
attribute_list_contained(tree l1, tree l2) asm("_attribute_list_contained");
int
attribute_list_contained(tree l1, tree l2)
{
  register tree t1, t2;


  if (l1 == l2)
     return 1;


  for (t1 = l1, t2 = l2;
       t1 && t2
        && ((t1)->list.purpose) == ((t2)->list.purpose)
        && ((t1)->list.value) == ((t2)->list.value);
       t1 = ((t1)->common.chain), t2 = ((t2)->common.chain));


  if (t1 == 0 && t2 == 0)
     return 1;

  for (; t2; t2 = ((t2)->common.chain))
    {
      tree attr
 = lookup_attribute (((((t2)->list.purpose))->identifier.pointer), l1);

      if (attr == (tree) 
                 ((void *)0)
                          )
 return 0;
      if (simple_cst_equal (((t2)->list.value), ((attr)->list.value)) != 1)
 return 0;
    }

  return 1;
}






int
type_list_equal(tree l1, tree l2) asm("_type_list_equal");
int
type_list_equal(tree l1, tree l2)
{
  register tree t1, t2;

  for (t1 = l1, t2 = l2; t1 && t2; t1 = ((t1)->common.chain), t2 = ((t2)->common.chain))
    if (((t1)->list.value) != ((t2)->list.value)
 || (((t1)->list.purpose) != ((t2)->list.purpose)
     && ! (1 == simple_cst_equal (((t1)->list.purpose), ((t2)->list.purpose))
    && (((((t1)->list.purpose))->common.type)
        == ((((t2)->list.purpose))->common.type)))))
      return 0;

  return t1 == t2;
}




int
tree_int_cst_equal(tree t1, tree t2) asm("_tree_int_cst_equal");
int
tree_int_cst_equal(tree t1, tree t2)
{
  if (t1 == t2)
    return 1;
  if (t1 == 0 || t2 == 0)
    return 0;
  if (((n64_enum_tree_code) (t1)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (t2)->common.code) == INTEGER_CST
      && ((t1)->int_cst.int_cst_low) == ((t2)->int_cst.int_cst_low)
      && ((t1)->int_cst.int_cst_high) == ((t2)->int_cst.int_cst_high))
    return 1;
  return 0;
}




int
tree_int_cst_lt(tree t1, tree t2) asm("_tree_int_cst_lt");
int
tree_int_cst_lt(tree t1, tree t2)
{
  if (t1 == t2)
    return 0;

  if (!((((t1)->common.type))->common.unsigned_flag))
    return (((t1)->int_cst.int_cst_high) < ((t2)->int_cst.int_cst_high) || (((t1)->int_cst.int_cst_high) == ((t2)->int_cst.int_cst_high) && ((unsigned int) ((t1)->int_cst.int_cst_low) < (unsigned int) ((t2)->int_cst.int_cst_low))));
  return (((unsigned int) ((t1)->int_cst.int_cst_high) < (unsigned int) ((t2)->int_cst.int_cst_high)) || (((unsigned int) ((t1)->int_cst.int_cst_high) == (unsigned int ) ((t2)->int_cst.int_cst_high)) && (((unsigned int) ((t1)->int_cst.int_cst_low) < (unsigned int) ((t2)->int_cst.int_cst_low)))));
}





int
tree_int_cst_sgn(tree t) asm("_tree_int_cst_sgn");
int
tree_int_cst_sgn(tree t)
{
  if (((t)->int_cst.int_cst_low) == 0 && ((t)->int_cst.int_cst_high) == 0)
    return 0;
  else if (((((t)->common.type))->common.unsigned_flag))
    return 1;
  else if (((t)->int_cst.int_cst_high) < 0)
    return -1;
  else
    return 1;
}




int
simple_cst_list_equal(tree l1, tree l2) asm("_simple_cst_list_equal");
int
simple_cst_list_equal(tree l1, tree l2)
{
  while (l1 != (tree) 
              ((void *)0) 
                        && l2 != (tree) 
                                 ((void *)0)
                                          )
    {
      if (simple_cst_equal (((l1)->list.value), ((l2)->list.value)) != 1)
 return 0;

      l1 = ((l1)->common.chain);
      l2 = ((l2)->common.chain);
    }

  return (l1 == l2);
}







int
simple_cst_equal(tree t1, tree t2) asm("_simple_cst_equal");
int
simple_cst_equal(tree t1, tree t2)
{
  register n64_enum_tree_code code1, code2;
  int cmp;

  if (t1 == t2)
    return 1;
  if (t1 == 0 || t2 == 0)
    return 0;

  code1 = ((n64_enum_tree_code) (t1)->common.code);
  code2 = ((n64_enum_tree_code) (t2)->common.code);

  if (code1 == NOP_EXPR || code1 == CONVERT_EXPR || code1 == NON_LVALUE_EXPR)
    if (code2 == NOP_EXPR || code2 == CONVERT_EXPR || code2 == NON_LVALUE_EXPR)
      return simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));
    else
      return simple_cst_equal (((t1)->exp.operands[0]), t2);
  else if (code2 == NOP_EXPR || code2 == CONVERT_EXPR
    || code2 == NON_LVALUE_EXPR)
    return simple_cst_equal (t1, ((t2)->exp.operands[0]));

  if (code1 != code2)
    return 0;

  switch (code1)
    {
    case INTEGER_CST:
      return ((t1)->int_cst.int_cst_low) == ((t2)->int_cst.int_cst_low)
 && ((t1)->int_cst.int_cst_high) == ((t2)->int_cst.int_cst_high);

    case REAL_CST:
      return (ereal_cmp ((((t1)->real_cst.real_cst)), (((t2)->real_cst.real_cst))) == 0);

    case STRING_CST:
      return ((t1)->string.length) == ((t2)->string.length)
 && !memcmp (((t1)->string.pointer),((t2)->string.pointer),((t1)->string.length))
                            ;

    case CONSTRUCTOR:
      abort ();

    case SAVE_EXPR:
      return simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));

    case CALL_EXPR:
      cmp = simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));
      if (cmp <= 0)
 return cmp;
      return simple_cst_list_equal (((t1)->exp.operands[1]), ((t2)->exp.operands[1]));

    case TARGET_EXPR:




      if ((((n64_enum_tree_code) (((t1)->exp.operands[0]))->common.code) == VAR_DECL
    && ((((t1)->exp.operands[0]))->decl.name) == (tree) 
                                          ((void *)0)
    
   && ((((t1)->exp.operands[0]))->decl.rtl) == 0)
   || (((n64_enum_tree_code) (((t2)->exp.operands[0]))->common.code) == VAR_DECL
       && ((((t2)->exp.operands[0]))->decl.name) == (tree) 
                                             ((void *)0)
       
      && ((((t2)->exp.operands[0]))->decl.rtl) == 0))
 cmp = 1;
      else
 cmp = simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));
      if (cmp <= 0)
 return cmp;
      return simple_cst_equal (((t1)->exp.operands[1]), ((t2)->exp.operands[1]));

    case WITH_CLEANUP_EXPR:
      cmp = simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));
      if (cmp <= 0)
 return cmp;
      return simple_cst_equal (((t1)->exp.operands[2]), ((t1)->exp.operands[2]));

    case COMPONENT_REF:
      if (((t1)->exp.operands[1]) == ((t2)->exp.operands[1]))
 return simple_cst_equal (((t1)->exp.operands[0]), ((t2)->exp.operands[0]));
      return 0;

    case VAR_DECL:
    case PARM_DECL:
    case CONST_DECL:
    case FUNCTION_DECL:
      return 0;
    }





  if ((int) code1
      >= sizeof standard_tree_code_type / sizeof standard_tree_code_type[0])
    return -1;

  switch ((*tree_code_type[(int) (code1)]))
    {
      int i;
    case '1':
    case '2':
    case '<':
    case 'e':
    case 'r':
    case 's':
      cmp = 1;
      for (i=0; i<tree_code_length[(int) code1]; ++i)
 {
   cmp = simple_cst_equal (((t1)->exp.operands[i]), ((t2)->exp.operands[i]));
   if (cmp <= 0)
     return cmp;
 }
      return cmp;
    }

  return -1;
}
tree
build_pointer_type(tree to_type) asm("_build_pointer_type");
tree
build_pointer_type(tree to_type)
{
  register tree t = ((to_type)->type.pointer_to);



  if (t)
    return t;


  push_obstacks (((to_type)->type.obstack), ((to_type)->type.obstack));
  t = make_node (POINTER_TYPE);
  pop_obstacks ();

  ((t)->common.type) = to_type;


  ((to_type)->type.pointer_to) = t;




  layout_type (t);

  return t;
}





tree
build_index_type(tree maxval) asm("_build_index_type");
tree
build_index_type(tree maxval)
{
  register tree itype = make_node (INTEGER_TYPE);
  ((itype)->type.precision) = ((sizetype)->type.precision);
  ((itype)->type.minval) = build_int_2_wide ((int) (0), (int) (0));
  ((((itype)->type.minval))->common.type) = sizetype;
  ((itype)->type.maxval) = convert (sizetype, maxval);
  ((itype)->type.mode) = ((sizetype)->type.mode);
  ((itype)->type.size) = ((sizetype)->type.size);
  ((itype)->type.align) = ((sizetype)->type.align);
  if (((n64_enum_tree_code) (maxval)->common.code) == INTEGER_CST)
    {
      int maxint = (int) ((maxval)->int_cst.int_cst_low);


      if ((((maxval)->int_cst.int_cst_high) < ((integer_zero_node)->int_cst.int_cst_high) || (((maxval)->int_cst.int_cst_high) == ((integer_zero_node)->int_cst.int_cst_high) && ((unsigned int) ((maxval)->int_cst.int_cst_low) < (unsigned int) ((integer_zero_node)->int_cst.int_cst_low)))))
 {
   ((itype)->type.maxval) = build_int_2_wide ((int) (-1), (int) (-1));
   ((((itype)->type.maxval))->common.type) = sizetype;
 }
      return type_hash_canon (maxint < 0 ? ~maxint : maxint, itype);
    }
  else
    return itype;
}






tree
build_range_type(tree type, tree lowval, tree highval) asm("_build_range_type");
tree
build_range_type(tree type, tree lowval, tree highval)
{
  register tree itype = make_node (INTEGER_TYPE);
  ((itype)->common.type) = type;
  if (type == (tree) 
             ((void *)0)
                      )
    type = sizetype;
  ((itype)->type.precision) = ((type)->type.precision);
  ((itype)->type.minval) = convert (type, lowval);
  ((itype)->type.maxval) = convert (type, highval);
  ((itype)->type.mode) = ((type)->type.mode);
  ((itype)->type.size) = ((type)->type.size);
  ((itype)->type.align) = ((type)->type.align);
  if ((((n64_enum_tree_code) (lowval)->common.code) == INTEGER_CST)
      && (((n64_enum_tree_code) (highval)->common.code) == INTEGER_CST))
    {
      int highint = ((highval)->int_cst.int_cst_low);
      int lowint = ((lowval)->int_cst.int_cst_low);
      int maxint = (int) (highint - lowint);
      return type_hash_canon (maxint < 0 ? ~maxint : maxint, itype);
    }
  else
    return itype;
}




tree
build_index_2_type(tree lowval, tree highval) asm("_build_index_2_type");
tree
build_index_2_type(tree lowval, tree highval)
{
  return build_range_type ((tree) 
                          ((void *)0)
                                   , lowval, highval);
}






int
index_type_equal(tree itype1, tree itype2) asm("_index_type_equal");
int
index_type_equal(tree itype1, tree itype2)
{
  if (((n64_enum_tree_code) (itype1)->common.code) != ((n64_enum_tree_code) (itype2)->common.code))
    return 0;
  if (((n64_enum_tree_code) (itype1)->common.code) == INTEGER_TYPE)
    {
      if (((itype1)->type.precision) != ((itype2)->type.precision)
   || ((itype1)->type.mode) != ((itype2)->type.mode)
   || simple_cst_equal (((itype1)->type.size), ((itype2)->type.size)) != 1
   || ((itype1)->type.align) != ((itype2)->type.align))
 return 0;
      if (1 == simple_cst_equal (((itype1)->type.minval),
     ((itype2)->type.minval))
   && 1 == simple_cst_equal (((itype1)->type.maxval),
        ((itype2)->type.maxval)))
 return 1;
    }

  return 0;
}





tree
build_array_type(tree elt_type, tree index_type) asm("_build_array_type");
tree
build_array_type(tree elt_type, tree index_type)
{
  register tree t;
  int hashcode;

  if (((n64_enum_tree_code) (elt_type)->common.code) == FUNCTION_TYPE)
    {
      error ("arrays of functions are not meaningful");
      elt_type = integer_type_node;
    }


  build_pointer_type (elt_type);



  t = make_node (ARRAY_TYPE);
  ((t)->common.type) = elt_type;
  ((t)->type.values) = index_type;

  if (index_type == 0)
    {
      return t;
    }

  hashcode = ((int) (elt_type) & 0777777) + ((int) (index_type) & 0777777);
  t = type_hash_canon (hashcode, t);
  if (((t)->type.size) == 0)
    layout_type (t);
  return t;
}
tree
build_function_type(tree value_type, tree arg_types) asm("_build_function_type");
tree
build_function_type(tree value_type, tree arg_types)
{
  register tree t;
  int hashcode;

  if (((n64_enum_tree_code) (value_type)->common.code) == FUNCTION_TYPE)
    {
      error ("function return type cannot be function");
      value_type = integer_type_node;
    }


  t = make_node (FUNCTION_TYPE);
  ((t)->common.type) = value_type;
  ((t)->type.values) = arg_types;


  hashcode = ((int) (value_type) & 0777777) + type_hash_list (arg_types);
  t = type_hash_canon (hashcode, t);

  if (((t)->type.size) == 0)
    layout_type (t);
  return t;
}



tree
build_reference_type(tree to_type) asm("_build_reference_type");
tree
build_reference_type(tree to_type)
{
  register tree t = ((to_type)->type.reference_to);
  register struct n64_tag_obstack *ambient_obstack = current_obstack;
  register struct n64_tag_obstack *ambient_saveable_obstack = saveable_obstack;



  if (t)
    return t;


  if (((to_type)->common.permanent_flag))
    {
      current_obstack = &permanent_obstack;
      saveable_obstack = &permanent_obstack;
    }

  t = make_node (REFERENCE_TYPE);
  ((t)->common.type) = to_type;


  ((to_type)->type.reference_to) = t;

  layout_type (t);

  current_obstack = ambient_obstack;
  saveable_obstack = ambient_saveable_obstack;
  return t;
}






tree
build_method_type(tree basetype, tree type) asm("_build_method_type");
tree
build_method_type(tree basetype, tree type)
{
  register tree t;
  int hashcode;


  t = make_node (METHOD_TYPE);

  if (((n64_enum_tree_code) (type)->common.code) != FUNCTION_TYPE)
    abort ();

  ((t)->type.maxval) = ((basetype)->type.main_variant);
  ((t)->common.type) = ((type)->common.type);




  ((t)->type.values)
    = tree_cons ((tree) 
                ((void *)0)
                         ,
   build_pointer_type (basetype), ((type)->type.values));


  hashcode = ((int) (basetype) & 0777777) + ((int) (type) & 0777777);
  t = type_hash_canon (hashcode, t);

  if (((t)->type.size) == 0)
    layout_type (t);

  return t;
}





tree
build_offset_type(tree basetype, tree type) asm("_build_offset_type");
tree
build_offset_type(tree basetype, tree type)
{
  register tree t;
  int hashcode;


  t = make_node (OFFSET_TYPE);

  ((t)->type.maxval) = ((basetype)->type.main_variant);
  ((t)->common.type) = type;


  hashcode = ((int) (basetype) & 0777777) + ((int) (type) & 0777777);
  t = type_hash_canon (hashcode, t);

  if (((t)->type.size) == 0)
    layout_type (t);

  return t;
}



tree
build_complex_type(tree component_type) asm("_build_complex_type");
tree
build_complex_type(tree component_type)
{
  register tree t;
  int hashcode;


  t = make_node (COMPLEX_TYPE);

  ((t)->common.type) = ((component_type)->type.main_variant);
  ((t)->common.volatile_flag) = ((component_type)->common.volatile_flag);
  ((t)->common.readonly_flag) = ((component_type)->common.readonly_flag);


  hashcode = ((int) (component_type) & 0777777);
  t = type_hash_canon (hashcode, t);

  if (((t)->type.size) == 0)
    layout_type (t);

  return t;
}
tree
get_unwidened(register tree op, tree for_type) asm("_get_unwidened");
tree
get_unwidened(register tree op, tree for_type)
{



  register tree type = ((op)->common.type);
  register unsigned final_prec
    = ((for_type != 0 ? for_type : type)->type.precision);
  register int uns
    = (for_type != 0 && for_type != type
       && final_prec > ((type)->type.precision)
       && ((type)->common.unsigned_flag));
  register tree win = op;

  while (((n64_enum_tree_code) (op)->common.code) == NOP_EXPR)
    {
      register int bitschange
 = ((((op)->common.type))->type.precision)
   - ((((((op)->exp.operands[0]))->common.type))->type.precision);



      if (bitschange < 0
   && final_prec > ((((op)->common.type))->type.precision))
 break;



      op = ((op)->exp.operands[0]);
      if (bitschange > 0)
 {
   if (! uns || final_prec <= ((((op)->common.type))->type.precision))
     win = op;



   if ((uns || ((n64_enum_tree_code) (op)->common.code) == NOP_EXPR)
       && ((((op)->common.type))->common.unsigned_flag))
     {
       uns = 1;
       win = op;
     }
 }
    }

  if (((n64_enum_tree_code) (op)->common.code) == COMPONENT_REF

      && ((n64_enum_tree_code) (type)->common.code) != REAL_TYPE)
    {
      unsigned innerprec = ((((((op)->exp.operands[1]))->decl.size))->int_cst.int_cst_low);
      type = type_for_size (innerprec, ((((op)->exp.operands[1]))->common.unsigned_flag));







      if (innerprec < ((((op)->common.type))->type.precision)
   && (for_type || ! ((((op)->exp.operands[1]))->decl.bit_field_flag))
   && (! uns || final_prec <= innerprec
       || ((((op)->exp.operands[1]))->common.unsigned_flag))
   && type != 0)
 {
   win = build (COMPONENT_REF, type, ((op)->exp.operands[0]),
         ((op)->exp.operands[1]));
   ((win)->common.side_effects_flag) = ((op)->common.side_effects_flag);
   ((win)->common.volatile_flag) = ((op)->common.volatile_flag);
   ((win)->common.raises_flag) = ((op)->common.raises_flag);
 }
    }
  return win;
}






tree
get_narrower(register tree op, int *unsignedp_ptr) asm("_get_narrower");
tree
get_narrower(register tree op, int *unsignedp_ptr)
{
  register int uns = 0;
  int first = 1;
  register tree win = op;

  while (((n64_enum_tree_code) (op)->common.code) == NOP_EXPR)
    {
      register int bitschange
 = ((((op)->common.type))->type.precision)
   - ((((((op)->exp.operands[0]))->common.type))->type.precision);


      if (bitschange < 0)
 break;



      op = ((op)->exp.operands[0]);

      if (bitschange > 0)
 {


   if (first)
     uns = ((((op)->common.type))->common.unsigned_flag);



   else if (uns != ((((op)->common.type))->common.unsigned_flag))
     break;
   first = 0;
 }
      else
 {


   if (first)
     uns = ((((op)->common.type))->common.unsigned_flag);
   first = 0;
 }

      win = op;
    }

  if (((n64_enum_tree_code) (op)->common.code) == COMPONENT_REF

      && ((n64_enum_tree_code) (((op)->common.type))->common.code) != REAL_TYPE)
    {
      unsigned innerprec = ((((((op)->exp.operands[1]))->decl.size))->int_cst.int_cst_low);
      tree type = type_for_size (innerprec, ((op)->common.unsigned_flag));
      if (innerprec < ((((op)->common.type))->type.precision)
   && ! ((((op)->exp.operands[1]))->decl.bit_field_flag)
   && (first || uns == ((((op)->exp.operands[1]))->common.unsigned_flag))
   && type != 0)
 {
   if (first)
     uns = ((((op)->exp.operands[1]))->common.unsigned_flag);
   win = build (COMPONENT_REF, type, ((op)->exp.operands[0]),
         ((op)->exp.operands[1]));
   ((win)->common.side_effects_flag) = ((op)->common.side_effects_flag);
   ((win)->common.volatile_flag) = ((op)->common.volatile_flag);
   ((win)->common.raises_flag) = ((op)->common.raises_flag);
 }
    }
  *unsignedp_ptr = uns;
  return win;
}






int
type_precision(register tree type) asm("_type_precision");
int
type_precision(register tree type)
{
  return ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
    || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
    || ((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
   ? ((type)->type.precision) : ((target_flags & 0x00000002) ? 64 : 32));
}




int
int_fits_type_p(tree c, tree type) asm("_int_fits_type_p");
int
int_fits_type_p(tree c, tree type)
{
  if (((type)->common.unsigned_flag))
    return (! (((n64_enum_tree_code) (((type)->type.maxval))->common.code) == INTEGER_CST
        && (((unsigned int) ((((type)->type.maxval))->int_cst.int_cst_high) < (unsigned int) ((c)->int_cst.int_cst_high)) || (((unsigned int) ((((type)->type.maxval))->int_cst.int_cst_high) == (unsigned int ) ((c)->int_cst.int_cst_high)) && (((unsigned int) ((((type)->type.maxval))->int_cst.int_cst_low) < (unsigned int) ((c)->int_cst.int_cst_low))))))
     && ! (((n64_enum_tree_code) (((type)->type.minval))->common.code) == INTEGER_CST
    && (((unsigned int) ((c)->int_cst.int_cst_high) < (unsigned int) ((((type)->type.minval))->int_cst.int_cst_high)) || (((unsigned int) ((c)->int_cst.int_cst_high) == (unsigned int ) ((((type)->type.minval))->int_cst.int_cst_high)) && (((unsigned int) ((c)->int_cst.int_cst_low) < (unsigned int) ((((type)->type.minval))->int_cst.int_cst_low)))))));
  else
    return (! (((n64_enum_tree_code) (((type)->type.maxval))->common.code) == INTEGER_CST
        && (((((type)->type.maxval))->int_cst.int_cst_high) < ((c)->int_cst.int_cst_high) || (((((type)->type.maxval))->int_cst.int_cst_high) == ((c)->int_cst.int_cst_high) && ((unsigned int) ((((type)->type.maxval))->int_cst.int_cst_low) < (unsigned int) ((c)->int_cst.int_cst_low)))))
     && ! (((n64_enum_tree_code) (((type)->type.minval))->common.code) == INTEGER_CST
    && (((c)->int_cst.int_cst_high) < ((((type)->type.minval))->int_cst.int_cst_high) || (((c)->int_cst.int_cst_high) == ((((type)->type.minval))->int_cst.int_cst_high) && ((unsigned int) ((c)->int_cst.int_cst_low) < (unsigned int) ((((type)->type.minval))->int_cst.int_cst_low))))));
}




tree
decl_function_context(tree decl) asm("_decl_function_context");
tree
decl_function_context(tree decl)
{
  tree context;

  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return 0;

  if (((n64_enum_tree_code) (decl)->common.code) == SAVE_EXPR)
    context = ((decl)->exp.operands[1]);
  else
    context = ((decl)->decl.context);

  while (context && ((n64_enum_tree_code) (context)->common.code) != FUNCTION_DECL)
    {
      if (((n64_enum_tree_code) (context)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (context)->common.code) == UNION_TYPE)
 context = (tree) 
          ((void *)0)
                   ;
      else if (((n64_enum_tree_code) (context)->common.code) == TYPE_DECL)
 context = ((context)->decl.context);
      else if (((n64_enum_tree_code) (context)->common.code) == BLOCK)
 context = ((context)->block.supercontext);
      else

 abort ();
    }

  return context;
}





tree
decl_type_context(tree decl) asm("_decl_type_context");
tree
decl_type_context(tree decl)
{
  tree context = ((decl)->decl.context);

  while (context)
    {
      if (((n64_enum_tree_code) (context)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (context)->common.code) == UNION_TYPE
   || ((n64_enum_tree_code) (context)->common.code) == QUAL_UNION_TYPE)
 return context;
      if (((n64_enum_tree_code) (context)->common.code) == TYPE_DECL
   || ((n64_enum_tree_code) (context)->common.code) == FUNCTION_DECL)
 context = ((context)->decl.context);
      else if (((n64_enum_tree_code) (context)->common.code) == BLOCK)
 context = ((context)->block.supercontext);
      else

 abort ();
    }
  return (tree) 
        ((void *)0)
                 ;
}

void
print_obstack_statistics(char *str, struct n64_tag_obstack *o) asm("_print_obstack_statistics");
void
print_obstack_statistics(char *str, struct n64_tag_obstack *o)
{
  struct n64_tag__obstack_chunk *chunk = o->chunk;
  int n_chunks = 0;
  int n_alloc = 0;

  while (chunk)
    {
      n_chunks += 1;
      n_alloc += chunk->limit - &chunk->contents[0];
      chunk = chunk->prev;
    }
  fprintf (
          (__acrt_iob_func(2))
                , "obstack %s: %d bytes, %d chunks\n",
    str, n_alloc, n_chunks);
}
void
dump_tree_statistics(void) asm("_dump_tree_statistics");
void
dump_tree_statistics(void)
{
  int i;
  int total_nodes, total_bytes;

  fprintf (
          (__acrt_iob_func(2))
                , "\n??? tree nodes created\n\n");
  fprintf (
          (__acrt_iob_func(2))
                , "(No per-node statistics)\n");

  print_lang_statistics ();
}
extern char * first_global_object_name;




tree
get_file_function_name(int kind) asm("_get_file_function_name");
tree
get_file_function_name(int kind)
{
  char *buf;
  register char *p;

  if (first_global_object_name)
    p = first_global_object_name;
  else if (main_input_filename)
    p = main_input_filename;
  else
    p = input_filename;

  buf = (char *) 
                __builtin_alloca((
                sizeof ("_GLOBAL_.D.%s") + strlen (p)
                ))
                                                                   ;





  sprintf (buf, "_GLOBAL_.D.%s", p);


  if (p != first_global_object_name)
    {
      for (p = buf+11; *p; p++)
 if (! ((*p >= '0' && *p <= '9')
        || *p == '.'

        || (*p >= 'A' && *p <= 'Z')
        || (*p >= 'a' && *p <= 'z')))
   *p = '_';
    }

  buf[9] = kind;

  return get_identifier (buf);
}
tree
get_set_constructor_bits(tree init, char *buffer, int bit_size) asm("_get_set_constructor_bits");
tree
get_set_constructor_bits(tree init, char *buffer, int bit_size)
{
  int i;
  tree vals;
  int domain_min
    = ((((((((init)->common.type))->type.values))->type.minval))->int_cst.int_cst_low);
  tree non_const_bits = (tree) 
                       ((void *)0)
                                ;
  for (i = 0; i < bit_size; i++)
    buffer[i] = 0;

  for (vals = ((init)->exp.operands[1]);
       vals != (tree) 
              ((void *)0)
                       ; vals = ((vals)->common.chain))
    {
      if (((n64_enum_tree_code) (((vals)->list.value))->common.code) != INTEGER_CST
   || (((vals)->list.purpose) != (tree) 
                             ((void *)0)
       
      && ((n64_enum_tree_code) (((vals)->list.purpose))->common.code) != INTEGER_CST))
 non_const_bits =
   tree_cons (((vals)->list.purpose), ((vals)->list.value), non_const_bits);
      else if (((vals)->list.purpose) != (tree) 
                                     ((void *)0)
                                              )
 {

   int lo_index
     = ((((vals)->list.purpose))->int_cst.int_cst_low) - domain_min;
   int hi_index
     = ((((vals)->list.value))->int_cst.int_cst_low) - domain_min;
   if (lo_index < 0 || lo_index >= bit_size
     || hi_index < 0 || hi_index >= bit_size)
     abort ();
   for ( ; lo_index <= hi_index; lo_index++)
     buffer[lo_index] = 1;
 }
      else
 {

   int strchr
     = ((((vals)->list.value))->int_cst.int_cst_low) - domain_min;
   if (strchr < 0 || strchr >= bit_size)
     {
       error ("invalid initializer for bit string");
       return (tree) 
             ((void *)0)
                      ;
     }
   buffer[strchr] = 1;
 }
    }
  return non_const_bits;
}






tree
get_set_constructor_bytes(tree init, unsigned char *buffer, int wd_size) asm("_get_set_constructor_bytes");
tree
get_set_constructor_bytes(tree init, unsigned char *buffer, int wd_size)
{
  int i;
  tree vals = ((init)->exp.operands[1]);
  int set_word_size = 8;
  int bit_size = wd_size * set_word_size;
  int bit_pos = 0;
  unsigned char *bytep = buffer;
  char *bit_buffer = (char*)
                           __builtin_alloca((
                           bit_size
                           ))
                                           ;
  tree non_const_bits = get_set_constructor_bits (init, bit_buffer, bit_size);

  for (i = 0; i < wd_size; i++)
    buffer[i] = 0;

  for (i = 0; i < bit_size; i++)
    {
      if (bit_buffer[i])
 {
   if (((target_flags & 0x00010000) != 0))
     *bytep |= (1 << (set_word_size - 1 - bit_pos));
   else
     *bytep |= 1 << bit_pos;
 }
      bit_pos++;
      if (bit_pos >= set_word_size)
 bit_pos = 0, bytep++;
    }
  return non_const_bits;
}

