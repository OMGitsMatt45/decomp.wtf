// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/search.c
/* Breadth-first and depth-first routines for
   searching multiple-inheritance lattice for GNU C++.
   Copyright (C) 1987, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int error(...) asm("_error");
extern int sorry(...) asm("_sorry");
extern int warning(...) asm("_warning");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
struct n64_tag__obstack_chunk;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_memoized_entry;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_stack_level;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_type_level;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");

struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;




void init_search(...) asm("_init_search");
extern struct n64_tag_obstack *current_obstack;
extern tree abort_fndecl;

struct n64_tag_stack_level
{

  struct n64_tag_stack_level *prev;


  struct n64_tag_obstack *obstack;


  tree *first;



  int limit;
};

struct n64_tag_stack_level *push_stack_level (struct n64_tag_obstack *, char *, int) asm("_push_stack_level");
struct n64_tag_stack_level *pop_stack_level (struct n64_tag_stack_level *) asm("_pop_stack_level");


static struct n64_tag_obstack search_obstack;


struct n64_tag_stack_level *
push_stack_level(struct n64_tag_obstack *obstack, char *tp, int size) asm("_push_stack_level");
struct n64_tag_stack_level *
push_stack_level(struct n64_tag_obstack *obstack, char *tp, int size)
{
  struct n64_tag_stack_level *stack;
  __extension__ ({ struct n64_tag_obstack *__o = (obstack); int __len = (size); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (tp),__len); __o->next_free += __len; } (void) 0; });
  stack = (struct n64_tag_stack_level *) ((char*)((obstack)->alloc_failed ? 0 : (obstack)->next_free) - size);
  __extension__ ({ struct n64_tag_obstack *__o1 = (obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
  stack->obstack = obstack;
  stack->first = (tree *) ((obstack)->alloc_failed ? 0 : (obstack)->object_base);
  stack->limit = __extension__ ({ struct n64_tag_obstack *__o = (obstack); (unsigned) (__o->chunk_limit - __o->next_free); }) / sizeof (tree *);
  return stack;
}

struct n64_tag_stack_level *
pop_stack_level(struct n64_tag_stack_level *stack) asm("_pop_stack_level");
struct n64_tag_stack_level *
pop_stack_level(struct n64_tag_stack_level *stack)
{
  struct n64_tag_stack_level *tem = stack;
  struct n64_tag_obstack *obstack = tem->obstack;
  stack = tem->prev;
  __extension__ ({ struct n64_tag_obstack *__o = (obstack); void *__obj = (tem); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  return stack;
}


static struct n64_tag_stack_level *search_stack;

static tree lookup_field_1(...) asm("_lookup_field_1");
static int lookup_fnfields_1(...) asm("_lookup_fnfields_1");
static void dfs_walk(...) asm("_dfs_walk");
static int markedp(...) asm("_markedp");
static void dfs_unmark(...) asm("_dfs_unmark");
static void dfs_init_vbase_pointers(...) asm("_dfs_init_vbase_pointers");

static tree vbase_types;
static tree vbase_decl, vbase_decl_ptr;
static tree vbase_decl_ptr_intermediate;
static tree vbase_init_result;


static struct n64_tag_stack_level *
push_search_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack) asm("_push_search_level");
static struct n64_tag_stack_level *
push_search_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack)
{
  struct n64_tag_stack_level tem;

  tem.prev = stack;
  return push_stack_level (obstack, (char *)&tem, sizeof (tem));
}


static struct n64_tag_stack_level *
pop_search_level(struct n64_tag_stack_level *obstack) asm("_pop_search_level");
static struct n64_tag_stack_level *
pop_search_level(struct n64_tag_stack_level *obstack)
{
  register struct n64_tag_stack_level *stack = pop_stack_level (obstack);

  return stack;
}


struct n64_tag_type_level
{
  struct n64_tag_stack_level base;


  char *entries;


  int len;



  tree type;
};



static struct n64_tag_obstack type_obstack, type_obstack_entries;
static struct n64_tag_type_level *type_stack;
static tree _vptr_name;



static int my_tree_node_counter;
static tree my_tree_cons (...) asm("_my_tree_cons"), my_build_string (...) asm("_my_build_string");

extern int flag_memoize_lookups, flag_save_memoized_contexts;


static int my_memoized_entry_counter;
static int memoized_fast_finds[2], memoized_adds[2], memoized_fast_rejects[2];
static int memoized_fields_searched[2];
static int n_fields_searched;
static int n_calls_lookup_field, n_calls_lookup_field_1;
static int n_calls_lookup_fnfields, n_calls_lookup_fnfields_1;
static int n_calls_get_base_type;
static int n_outer_fields_searched;
static int n_contexts_saved;


static tree prev_type_memoized;
static struct n64_tag_type_level *prev_type_stack;



static tree closed_envelopes = (tree) 
                              ((void *)0)
                                       ;


static struct n64_tag_type_level *
push_type_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack) asm("_push_type_level");
static struct n64_tag_type_level *
push_type_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack)
{
  struct n64_tag_type_level tem;

  tem.base.prev = stack;

  __extension__ ({ struct n64_tag_obstack *__o1 = (&type_obstack_entries); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
  tem.entries = (char *) ((&type_obstack_entries)->alloc_failed ? 0 : (&type_obstack_entries)->object_base);
  tem.len = 0;
  tem.type = (tree) 
            ((void *)0)
                     ;

  return (struct n64_tag_type_level *)push_stack_level (obstack, (char *)&tem, sizeof (tem));
}



static struct n64_tag_type_level *
pop_type_level(struct n64_tag_type_level *stack) asm("_pop_type_level");
static struct n64_tag_type_level *
pop_type_level(struct n64_tag_type_level *stack)
{
  __extension__ ({ struct n64_tag_obstack *__o = (&type_obstack_entries); void *__obj = (stack->entries); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  return (struct n64_tag_type_level *)pop_stack_level ((struct n64_tag_stack_level *)stack);
}



static tree
my_tree_cons(tree purpose, tree value, tree chain) asm("_my_tree_cons");
static tree
my_tree_cons(tree purpose, tree value, tree chain)
{
  tree p = (tree)__extension__ ({ struct n64_tag_obstack *__h = (&type_obstack_entries); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_tree_list))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  ++my_tree_node_counter;
  ((p)->common.type) = (tree) 
                 ((void *)0)
                          ;
  ((int *)p)[3] = 0;
  ((p)->common.code = (int) (TREE_LIST));
  ((p)->list.purpose) = purpose;
  ((p)->list.value) = value;
  ((p)->common.chain) = chain;
  return p;
}

static tree
my_build_string(char *str) asm("_my_build_string");
static tree
my_build_string(char *str)
{
  tree p = (tree)__extension__ ({ struct n64_tag_obstack *__h = (&type_obstack_entries); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_tree_string))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  ++my_tree_node_counter;
  ((p)->common.type) = 0;
  ((int *)p)[3] = 0;
  ((p)->common.code = (int) (STRING_CST));
  ((p)->string.pointer) = str;
  ((p)->string.length) = strlen (str);
  return p;
}




typedef struct n64_tag_memoized_entry
{
  struct n64_tag_memoized_entry *chain;
  int uid;
  tree data_members[8];
  tree function_members[8];
} *ME;
static struct n64_tag_memoized_entry *
my_new_memoized_entry(struct n64_tag_memoized_entry *chain) asm("_my_new_memoized_entry");
static struct n64_tag_memoized_entry *
my_new_memoized_entry(struct n64_tag_memoized_entry *chain)
{
  struct n64_tag_memoized_entry *p =
    (struct n64_tag_memoized_entry *)__extension__ ({ struct n64_tag_obstack *__h = (&type_obstack_entries); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_memoized_entry))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                        ;
  memset ((char *) p,0,sizeof (struct n64_tag_memoized_entry));
  (((ME)p)->chain) = chain;
  (((ME)p)->uid) = ++my_memoized_entry_counter;
  return p;
}




tree
make_memoized_table_entry(tree type, tree name, int function_p) asm("_make_memoized_table_entry");
tree
make_memoized_table_entry(tree type, tree name, int function_p)
{
  int strchr = (((long)(name)>>4)&(8 - 1));
  tree entry, *prev_entry;

  memoized_adds[function_p] += 1;
  if ((((type)->type.lang_specific)->memoized_table_entry) == 0)
    {
      __extension__ ({ struct n64_tag_obstack *__o = (&type_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)type); __o->next_free += sizeof (void *); } (void) 0; });
      __extension__ ({ struct n64_tag_obstack *__o = (&type_obstack); int __len = (sizeof (struct n64_tag_memoized_entry *)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });
      (((type)->type.lang_specific)->memoized_table_entry) = (char *)my_new_memoized_entry ((struct n64_tag_memoized_entry *)0);
      type_stack->len++;
      if (type_stack->len * 2 >= type_stack->base.limit)
 my_friendly_abort (88);
    }
  if (function_p)
    prev_entry = &(((ME)(((type)->type.lang_specific)->memoized_table_entry))->function_members[strchr]);
  else
    prev_entry = &(((ME)(((type)->type.lang_specific)->memoized_table_entry))->data_members[strchr]);

  entry = my_tree_cons (name, (tree) 
                             ((void *)0)
                                      , *prev_entry);
  *prev_entry = entry;


  ((entry)->common.type) = error_mark_node;

  return entry;
}
void
push_memoized_context(tree type, int use_old) asm("_push_memoized_context");
void
push_memoized_context(tree type, int use_old)
{
  int len;
  tree *tem;

  if (prev_type_stack)
    {
      if (use_old && prev_type_memoized == type)
 {



   type_stack = prev_type_stack;
   prev_type_stack = 0;

   tem = &type_stack->base.first[0];
   len = type_stack->len;
   while (len--)
     (((tem[len*2])->type.lang_specific)->memoized_table_entry) = (char *)tem[len*2+1];
   return;
 }

      type_stack = pop_type_level (prev_type_stack);
      prev_type_memoized = 0;
      prev_type_stack = 0;
    }

  type_stack = push_type_level ((struct n64_tag_stack_level *)type_stack,
    &type_obstack);
  type_stack->type = type;
}






void
pop_memoized_context(int use_old) asm("_pop_memoized_context");
void
pop_memoized_context(int use_old)
{
  int len;
  tree *tem = &type_stack->base.first[0];

  if (! flag_save_memoized_contexts)
    use_old = 0;
  else if (use_old)
    {
      len = type_stack->len;
      while (len--)
 tem[len*2+1] = (tree)(((tem[len*2])->type.lang_specific)->memoized_table_entry);

      prev_type_stack = type_stack;
      prev_type_memoized = type_stack->type;
    }

  if (flag_memoize_lookups)
    {
      len = type_stack->len;
      while (len--)
 (((tem[len*2])->type.lang_specific)->memoized_table_entry)
   = (char *)(((ME)(((tem[len*2])->type.lang_specific)->memoized_table_entry))->chain);
    }
  if (! use_old)
    type_stack = pop_type_level (type_stack);
  else
    type_stack = (struct n64_tag_type_level *)type_stack->base.prev;
}





static tree
get_vbase(tree parent, tree binfo, unsigned int *depth) asm("_get_vbase");
static tree
get_vbase(tree parent, tree binfo, unsigned int *depth)
{
  tree binfos;
  int i, n_baselinks;
  tree rval = (tree) 
             ((void *)0)
                      ;

  if (depth == 0)
    {
      unsigned int d = (unsigned int)-1;
      return get_vbase (parent, binfo, &d);
    }

  if (((binfo)->common.type) == parent && ((binfo)->common.static_flag))
    {
      *depth = 0;
      return binfo;
    }

  *depth = *depth - 1;

  binfos = (((binfo))->vec.a[4]);
  n_baselinks = binfos ? ((binfos)->vec.length) : 0;


  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree nrval;

      if (*depth == 0)
 break;

      nrval = get_vbase (parent, base_binfo, depth);
      if (nrval)
 rval = nrval;
    }
  *depth = *depth+1;
  return rval;
}




tree
convert_pointer_to_vbase(tree type, tree expr) asm("_convert_pointer_to_vbase");
tree
convert_pointer_to_vbase(tree type, tree expr)
{
  tree vb = get_vbase (type, ((((((expr)->common.type))->common.type))->type.binfo), ((void *)0));
  return convert_pointer_to_real (vb, expr);
}
tree
get_binfo(register tree parent, register tree binfo, int protect) asm("_get_binfo");
tree
get_binfo(register tree parent, register tree binfo, int protect)
{
  tree type;
  int dist;
  tree rval = (tree) 
             ((void *)0)
                      ;

  if (((n64_enum_tree_code) (parent)->common.code) == TREE_VEC)
    parent = ((parent)->common.type);
  else if (! (((n64_enum_tree_code) (parent)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (parent)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (parent)->common.code) == UNINSTANTIATED_P_TYPE))
    my_friendly_abort (89);

  if (((n64_enum_tree_code) (binfo)->common.code) == TREE_VEC)
    type = ((binfo)->common.type);
  else if ((((n64_enum_tree_code) (binfo)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (binfo)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (binfo)->common.code) == UNINSTANTIATED_P_TYPE))
    type = binfo;
  else
    my_friendly_abort (90);

  dist = get_base_distance (parent, binfo, protect, &rval);

  if (dist == -3)
    {
      cp_error ("fields of `%T' are inaccessible in `%T' due to private inheritance",
  parent, type);
      return error_mark_node;
    }
  else if (dist == -2 && protect)
    {
      cp_error ("type `%T' is ambiguous base class for type `%T'", parent,
  type);
      return error_mark_node;
    }

  return rval;
}


static int
get_base_distance_recursive(tree binfo, int depth, int is_private, tree basetype_path, int rval, int *rval_private_ptr, tree *new_binfo_ptr, tree parent, tree *path_ptr, int protect, int *via_virtual_ptr, int via_virtual) asm("_get_base_distance_recursive");
static int
get_base_distance_recursive(tree binfo, int depth, int is_private, tree basetype_path, int rval, int *rval_private_ptr, tree *new_binfo_ptr, tree parent, tree *path_ptr, int protect, int *via_virtual_ptr, int via_virtual)
{
  tree binfos;
  int i, n_baselinks;

  if (((binfo)->common.type) == parent || binfo == parent)
    {
      if (rval == -1)
 {
   rval = depth;
   *rval_private_ptr = is_private;
   *new_binfo_ptr = binfo;
   *via_virtual_ptr = via_virtual;
 }
      else
 {
   int same_object = (tree_int_cst_equal ((((*new_binfo_ptr))->vec.a[1]),
       (((binfo))->vec.a[1]))
        && *via_virtual_ptr && via_virtual);

   if (*via_virtual_ptr && via_virtual==0)
     {
       *rval_private_ptr = is_private;
       *new_binfo_ptr = binfo;
       *via_virtual_ptr = via_virtual;
     }
   else if (same_object)
     {
       if (*rval_private_ptr && ! is_private)
  {
    *rval_private_ptr = is_private;
    *new_binfo_ptr = binfo;
    *via_virtual_ptr = via_virtual;
  }
       return rval;
     }

   rval = -2;
 }
      return rval;
    }

  binfos = (((binfo))->vec.a[4]);
  n_baselinks = binfos ? ((binfos)->vec.length) : 0;
  depth += 1;


  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);



      if ((((base_binfo)->common.static_flag)?(((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked):((base_binfo)->common.lang_flag_0)) == 0 || ((n64_enum_tree_code) (parent)->common.code) == TREE_VEC)
 {
   int via_private
     = (protect
        && (is_private
     || (!((base_binfo)->common.public_flag)
         && !is_friend (((binfo)->common.type), current_scope ()))));
   int this_virtual = via_virtual || ((base_binfo)->common.static_flag);
   int was;



   if (! this_virtual)
     (((base_binfo)->common.static_flag)?((((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((base_binfo)->common.lang_flag_0)=1));



   was = (rval == -1 ? 3 : *via_virtual_ptr);
   rval = get_base_distance_recursive (base_binfo, depth, via_private,
           binfo, rval, rval_private_ptr,
           new_binfo_ptr, parent, path_ptr,
           protect, via_virtual_ptr,
           this_virtual);

   if (path_ptr && (rval == -1 ? 3 : *via_virtual_ptr) != was)
     (((base_binfo))->vec.a[0]) = binfo;
   if (rval == -2 && *via_virtual_ptr == 0)
     return rval;



 }
    }

  return rval;
}
int
get_base_distance(register tree parent, register tree binfo, int protect, tree *path_ptr) asm("_get_base_distance");
int
get_base_distance(register tree parent, register tree binfo, int protect, tree *path_ptr)
{
  int rval;
  int rval_private = 0;
  tree type;
  tree new_binfo = (tree) 
                  ((void *)0)
                           ;
  int via_virtual;
  int watch_access = protect;

  if (((n64_enum_tree_code) (parent)->common.code) != TREE_VEC)
    parent = ((parent)->type.main_variant);

  if (((n64_enum_tree_code) (binfo)->common.code) == TREE_VEC)
    type = ((binfo)->common.type);
  else if ((((n64_enum_tree_code) (binfo)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (binfo)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (binfo)->common.code) == UNINSTANTIATED_P_TYPE))
    {
      type = binfo;
      binfo = ((type)->type.binfo);

      if (path_ptr)
 (((binfo))->vec.a[0]) = (tree) 
                                  ((void *)0)
                                           ;
    }
  else
    my_friendly_abort (92);

  if (parent == type || parent == binfo)
    {


      if (path_ptr)
 *path_ptr = binfo;
      return 0;
    }

  if (path_ptr)
    watch_access = 1;

  rval = get_base_distance_recursive (binfo, 0, 0, (tree) 
                                                  ((void *)0)
                                                           , -1,
          &rval_private, &new_binfo, parent,
          path_ptr, watch_access, &via_virtual, 0);

  dfs_walk (binfo, dfs_unmark, markedp);


  if (rval == -2 && protect >= 0)
    rval_private = 0;

  if (rval && protect && rval_private)
    return -3;


  if (rval == -1 && ((n64_enum_tree_code) (parent)->common.code) == TREE_VEC
      && parent == binfo_member (((parent)->common.type),
     (((type)->type.lang_specific)->vbases)))
    {
      (((parent))->vec.a[0]) = binfo;
      new_binfo = parent;
      rval = 1;
    }

  if (path_ptr)
    *path_ptr = new_binfo;
  return rval;
}
static tree
lookup_field_1(tree type, tree name) asm("_lookup_field_1");
static tree
lookup_field_1(tree type, tree name)
{
  register tree field = ((type)->type.values);




  while (field)
    {



      if (((field)->decl.name) == (tree) 
                              ((void *)0)
   
  && ((n64_enum_tree_code) (((field)->common.type))->common.code) == UNION_TYPE)
 {
   tree temp = lookup_field_1 (((field)->common.type), name);
   if (temp)
     return temp;
 }
      if (((field)->decl.name) == name)
 {
   if ((((n64_enum_tree_code) (field)->common.code) == VAR_DECL || ((n64_enum_tree_code) (field)->common.code) == CONST_DECL)
       && ((field)->decl.assembler_name) != 
                                        ((void *)0)
                                            )
     GNU_xref_ref(current_function_decl,
    ((((field)->decl.assembler_name))->identifier.pointer));
   return field;
 }
      field = ((field)->common.chain);
    }

  if (name == _vptr_name)
    {

      if ((((type)->common.lang_flag_2)))
 return ((type)->type.minval);
    }
  return (tree) 
        ((void *)0)
                 ;
}
tree
current_scope(void) asm("_current_scope");
tree
current_scope(void)
{
  if (current_function_decl == (tree) 
                              ((void *)0)
                                       )
    return current_class_type;
  if (current_class_type == (tree) 
                           ((void *)0)
                                    )
    return current_function_decl;
  if ((((current_function_decl)->decl.lang_specific)->decl_flags.context) == current_class_type)
    return current_function_decl;

  return current_class_type;
}
n64_enum_access_type
compute_access(tree basetype_path, tree field) asm("_compute_access");
n64_enum_access_type
compute_access(tree basetype_path, tree field)
{
  n64_enum_access_type access;
  tree types;
  tree context;
  int protected_ok, via_protected;
  extern int flag_access_control;


  tree previous_scope;

  int static_mem =
    ((((n64_enum_tree_code) (field)->common.code) == FUNCTION_DECL && (((field)->decl.lang_specific)->decl_flags.static_function))
     || (((n64_enum_tree_code) (field)->common.code) != FUNCTION_DECL && ((field)->common.static_flag)));

  if (! flag_access_control)
    return access_public;


  if (((basetype_path)->common.type) == current_class_type)
    return access_public;
  if (((n64_enum_tree_code) (field)->common.code) == TYPE_DECL)
    return access_public;

  previous_scope = current_scope ();

  context = (((field)->decl.lang_specific)->decl_flags.context);
  if (context == (tree) 
                ((void *)0)
                         )
    context = ((field)->decl.context);




  if (context && ((n64_enum_tree_code) (context)->common.code) == UNION_TYPE
      && ((((((((context)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((context)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
    context = ((field)->decl.context);



  if (((field)->decl.name) && (!strncmp (((((field)->decl.name))->identifier.pointer), "_vptr.", sizeof("_vptr.")-1)) == 1)
    return access_public;


  if ((((basetype_path))->vec.a[0]) == (tree) 
                                                ((void *)0)
                                                         )
    {


      if (is_friend (context, previous_scope))
 return access_public;


      if (((field)->common.private_flag))
 return access_private;






      else if (((field)->common.protected_flag))
 {
   if (current_class_type
       && static_mem
         && (get_base_distance (context, current_class_type, -1, (tree *)0) >= 0))
     return access_public;
   else
     return access_protected;
 }
      else
 return access_public;
    }


  basetype_path = reverse_path (basetype_path);
  types = basetype_path;
  via_protected = 0;
  access = access_default;
  protected_ok = static_mem && current_class_type
    && (get_base_distance (((types)->common.type), current_class_type, -1, (tree *)0) >= 0);

  while (1)
    {
      tree member;
      tree binfo = types;
      tree type = ((binfo)->common.type);
      int private_ok = 0;



      if (is_friend (type, previous_scope))
 {
   protected_ok = 1;
   private_ok = 1;
 }

      member = purpose_member (type, (((field)->decl.lang_specific)->decl_flags.access));
      if (member)
 {
   access = (n64_enum_access_type) ((member)->list.value);
   break;
 }

      types = (((types))->vec.a[0]);



      if (types)
 {
   if (((types)->common.protected_flag))
     via_protected = 1;
   else if (! ((types)->common.public_flag) && ! private_ok)
     {
       access = access_private;
       break;
     }
 }
      else
 break;
    }
  reverse_path (basetype_path);



  if (access == access_default)
    {
      if (is_friend (context, previous_scope))
 access = access_public;
      else if (((field)->common.private_flag))
 access = access_private;
      else if (((field)->common.protected_flag))
 access = access_protected;
      else
 access = access_public;
    }

  if (access == access_public && via_protected)
    access = access_protected;

  if (access == access_protected && protected_ok)
    access = access_public;
  return access;
}





static int
is_subobject_of_p(tree parent, tree binfo) asm("_is_subobject_of_p");
static int
is_subobject_of_p(tree parent, tree binfo)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

  if (parent == binfo)
    return 1;


  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      if (((base_binfo)->common.static_flag))
 base_binfo = ((((base_binfo)->common.type))->type.binfo);
      if (is_subobject_of_p (parent, base_binfo))
 return 1;
    }
  return 0;
}






static int
hides(tree hider_binfo, tree hidee_binfo) asm("_hides");
static int
hides(tree hider_binfo, tree hidee_binfo)
{






  return is_subobject_of_p (hidee_binfo, hider_binfo);
}




static int
lookup_fnfields_here(tree type, tree name) asm("_lookup_fnfields_here");
static int
lookup_fnfields_here(tree type, tree name)
{
  int strchr = lookup_fnfields_1 (type, name);
  tree fndecls;

  if (strchr <= 0)
    return strchr;
  fndecls = ((((type)->type.maxval))->vec.a[strchr]);
  while (fndecls)
    {
      if ((((((fndecls)->decl.lang_specific)->decl_flags.context))->type.main_variant)
   == ((type)->type.main_variant))
 return strchr;
      fndecls = ((fndecls)->common.chain);
    }
  return -1;
}
tree
lookup_field(register tree xbasetype, register tree name, int protect, int want_type) asm("_lookup_field");
tree
lookup_field(register tree xbasetype, register tree name, int protect, int want_type)
{
  int head = 0, tail = 0;
  tree rval, rval_binfo = (tree) 
                         ((void *)0)
                                  , rval_binfo_h;
  tree type, basetype_chain, basetype_path;
  n64_enum_access_type this_v = access_default;
  tree entry, binfo, binfo_h;
  n64_enum_access_type own_access = access_default;
  int vbase_name_p = (((name)->identifier.pointer)[1] == 'v' && ((name)->identifier.pointer)[2] == 'b' && ((name)->identifier.pointer)[3] == '.');
  char *errstr = 0;



  int strchr = (((long)(name)>>4)&(8 - 1));



  if ((((struct n64_tag_lang_identifier *)(name))->class_template_info))
    name = constructor_name (name);

  if (((n64_enum_tree_code) (xbasetype)->common.code) == TREE_VEC)
    {
      type = ((xbasetype)->common.type);
      basetype_path = xbasetype;
    }
  else if ((((n64_enum_tree_code) (xbasetype)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (xbasetype)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (xbasetype)->common.code) == UNINSTANTIATED_P_TYPE))
    {
      type = xbasetype;
      basetype_path = ((xbasetype)->type.binfo);
      ((basetype_path)->common.lang_flag_5) = 1;
      (((basetype_path))->vec.a[0]) = (tree) 
                                               ((void *)0)
                                                        ;
    }
  else my_friendly_abort (97);

  if ((((type)->type.lang_specific)->memoized_table_entry))
    {
      tree tem = (((ME)(((type)->type.lang_specific)->memoized_table_entry))->data_members[strchr]);

      while (tem && ((tem)->list.purpose) != name)
 {
   memoized_fields_searched[0]++;
   tem = ((tem)->common.chain);
 }
      if (tem)
 {
   if (protect && ((tem)->common.type))
     {
       error (((((tem)->common.type))->string.pointer),
       ((name)->identifier.pointer),
       ((((((((((((tem)->list.value))->decl.context))->type.name))->decl.name)))->identifier.pointer)));
       return error_mark_node;
     }
   if (((tem)->list.value) == (tree) 
                          ((void *)0)
                                   )
     memoized_fast_rejects[0] += 1;
   else
     memoized_fast_finds[0] += 1;
   return ((tem)->list.value);
 }
    }




  if (protect && flag_memoize_lookups && ! global_bindings_p ())
    entry = make_memoized_table_entry (type, name, 0);
  else
    entry = 0;

  rval = lookup_field_1 (type, name);

  if (rval || lookup_fnfields_here (type, name) >= 0)
    {
      if (rval)
 {
   if (want_type)
     {
       if (((n64_enum_tree_code) (rval)->common.code) != TYPE_DECL)
  {
    rval = purpose_member (name, (((type)->type.lang_specific)->tags));
    if (rval)
      rval = (((((rval)->list.value))->type.name));
  }
     }
   else
     {
       if (((n64_enum_tree_code) (rval)->common.code) == TYPE_DECL
    && lookup_fnfields_here (type, name) >= 0)
  rval = (tree) 
        ((void *)0)
                 ;
     }
 }

      if (protect && rval)
 {
   if (((rval)->common.private_flag) | ((rval)->common.protected_flag))
     this_v = compute_access (basetype_path, rval);
   if (((n64_enum_tree_code) (rval)->common.code) == CONST_DECL)
     {
       if (this_v == access_private)
  errstr = "enum `%D' is a private value of class `%T'";
       else if (this_v == access_protected)
  errstr = "enum `%D' is a protected value of class `%T'";
     }
   else
     {
       if (this_v == access_private)
  errstr = "member `%D' is a private member of class `%T'";
       else if (this_v == access_protected)
  errstr = "member `%D' is a protected member of class `%T'";
     }
 }

      if (entry)
 {
   if (errstr)
     {

       tree error_string = my_build_string (errstr);
       ((entry)->common.type) = error_string;
     }
   else
     {

       ((entry)->common.type) = (tree) 
                          ((void *)0)
                                   ;
     }
   ((entry)->list.value) = rval;
 }

      if (errstr && protect)
 {
   cp_error (errstr, name, type);
   return error_mark_node;
 }
      return rval;
    }

  basetype_chain = build_tree_list ((tree) 
                                   ((void *)0)
                                            , basetype_path);
  ((basetype_chain)->common.public_flag) = ((basetype_path)->common.public_flag);
  ((basetype_chain)->common.protected_flag) = ((basetype_path)->common.protected_flag);
  ((basetype_chain)->common.static_flag) = ((basetype_path)->common.static_flag);



  search_stack = push_search_level (search_stack, &search_obstack);
  binfo = basetype_path;
  binfo_h = binfo;

  while (1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;
      tree nval;


      for (i = 0; i < n_baselinks; i++)
 {
   tree base_binfo = ((binfos)->vec.a[i]);
   if ((((base_binfo)->common.static_flag)?(((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked2):((base_binfo)->common.lang_flag_2)) == 0)
     {
       tree btypes;

       (((base_binfo)->common.static_flag)?((((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked2) = 1):(((base_binfo)->common.lang_flag_2)=1));
       btypes = my_tree_cons ((tree) 
                             ((void *)0)
                                      , base_binfo, basetype_chain);
       ((btypes)->common.public_flag) = ((base_binfo)->common.public_flag);
       ((btypes)->common.protected_flag) = ((base_binfo)->common.protected_flag);
       ((btypes)->common.static_flag) = ((base_binfo)->common.static_flag);
       if (((base_binfo)->common.static_flag))
  btypes = tree_cons ((tree) 
                     ((void *)0)
                              ,
        (((((((((binfo_h))->vec.a[4]))->vec.a[i]))->common.type))->type.binfo),
        btypes);
       else
  btypes = tree_cons ((tree) 
                     ((void *)0)
                              ,
        (((((binfo_h))->vec.a[4]))->vec.a[i]),
        btypes);
       __extension__ ({ struct n64_tag_obstack *__o = (&search_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)btypes); __o->next_free += sizeof (void *); } (void) 0; });
       tail += 1;
       if (tail >= search_stack->limit)
  my_friendly_abort (98);
     }
 }


      if (head >= tail)
 break;

      basetype_chain = search_stack->first[head++];
      binfo_h = ((basetype_chain)->list.value);
      basetype_chain = ((basetype_chain)->common.chain);
      basetype_path = ((basetype_chain)->list.value);
      if (((basetype_chain)->common.chain))
 (((basetype_path))->vec.a[0]) = ((((basetype_chain)->common.chain))->list.value);
      else
 (((basetype_path))->vec.a[0]) = (tree) 
                                          ((void *)0)
                                                   ;

      binfo = basetype_path;
      type = ((binfo)->common.type);





      nval = lookup_field_1 (type, name);

      if (nval || lookup_fnfields_here (type, name)>=0)
 {
   if (nval && nval == rval && (((n64_enum_tree_code) (nval)->common.code) == VAR_DECL || ((n64_enum_tree_code) (nval)->common.code) == TYPE_DECL || ((n64_enum_tree_code) (nval)->common.code) == CONST_DECL))
     {

     }
   else if (rval_binfo && hides (rval_binfo_h, binfo_h))
     {


     }
   else if (rval_binfo==(tree) 
                       ((void *)0) 
                                 || hides (binfo_h, rval_binfo_h))
     {


       if (nval)
  {
    rval = nval;
    if (entry || protect)
      this_v = compute_access (basetype_path, rval);

    if (vbase_name_p)
      break;
  }
       else
  {

    rval = (tree) 
          ((void *)0)
                   ;
  }
       rval_binfo = binfo;
       rval_binfo_h = binfo_h;
     }
   else
     {

       errstr = "request for member `%D' is ambiguous";
       protect = 2;
       break;
     }
 }
    }
  {
    tree *tp = search_stack->first;
    tree *search_tail = tp + tail;

    if (entry)
      ((entry)->list.value) = rval;

    if (rval_binfo)
      {
 type = ((rval_binfo)->common.type);

 if (rval)
   {
     if (want_type)
       {
  if (((n64_enum_tree_code) (rval)->common.code) != TYPE_DECL)
    {
      rval = purpose_member (name, (((type)->type.lang_specific)->tags));
      if (rval)
        rval = (((((rval)->list.value))->type.name));
    }
       }
     else
       {
  if (((n64_enum_tree_code) (rval)->common.code) == TYPE_DECL
      && lookup_fnfields_here (type, name) >= 0)
    rval = (tree) 
          ((void *)0)
                   ;
       }
   }
      }

    if (rval == (tree) 
               ((void *)0)
                        )
      errstr = 0;


    if (rval && errstr == 0
 && ((protect&1) || entry)
 && ((rval)->decl.lang_specific)
 && (((rval)->decl.lang_specific)->decl_flags.access))
      {
 while (tp < search_tail)
   {



     n64_enum_access_type new_v;

     if (this_v != access_default)
       new_v = compute_access (((((*tp)->common.chain))->list.value), rval);
     if (this_v != access_default && new_v != this_v)
       {
  errstr = "conflicting access to member `%D'";
  this_v = access_default;
       }
     own_access = new_v;
     (((((((*tp)->common.chain))->list.value))->common.static_flag)?((((((((((*tp)->common.chain))->list.value))->common.type))->type.lang_specific)->type_flags.marked2) = 0):(((((((*tp)->common.chain))->list.value))->common.lang_flag_2)=0));
     tp += 1;
   }
      }
    else
      {
 while (tp < search_tail)
   {
     (((((((*tp)->common.chain))->list.value))->common.static_flag)?((((((((((*tp)->common.chain))->list.value))->common.type))->type.lang_specific)->type_flags.marked2) = 0):(((((((*tp)->common.chain))->list.value))->common.lang_flag_2)=0));
     tp += 1;
   }
      }
  }
  search_stack = pop_search_level (search_stack);

  if (errstr == 0)
    {
      if (own_access == access_private)
 errstr = "member `%D' declared private";
      else if (own_access == access_protected)
 errstr = "member `%D' declared protected";
      else if (this_v == access_private)
 errstr = ((rval)->common.private_flag)
   ? "member `%D' is private"
     : "member `%D' is from private base class";
      else if (this_v == access_protected)
 errstr = ((rval)->common.protected_flag)
   ? "member `%D' is protected"
     : "member `%D' is from protected base class";
    }

  if (entry)
    {
      if (errstr)
 {
   tree error_string = my_build_string (errstr);

   ((entry)->common.type) = error_string;
 }
      else
 {

   ((entry)->common.type) = (tree) 
                      ((void *)0)
                               ;
 }
    }

  if (errstr && protect)
    {
      cp_error (errstr, name, type);
      rval = error_mark_node;
    }
  return rval;
}


tree
lookup_nested_field(tree name, int complain) asm("_lookup_nested_field");
tree
lookup_nested_field(tree name, int complain)
{
  register tree t;

  tree id = (tree) 
           ((void *)0)
                    ;
  if (((current_class_type)->common.chain))
    {



      for (t = ((current_class_type)->common.chain);
    t && ((t)->decl.context);
    t = ((((t)->decl.context))->common.chain))
 {
   if (((n64_enum_tree_code) (((t)->decl.context))->common.code) != RECORD_TYPE)
     break;


   id = lookup_field (((t)->decl.context), name, complain, 0);
   if (id == error_mark_node)
     {
       id = (tree) 
           ((void *)0)
                    ;
       continue;
     }

   if (id != (tree) 
            ((void *)0)
                     )
     {
       if (((n64_enum_tree_code) (id)->common.code) == FIELD_DECL
    && ! ((id)->common.static_flag)
    && ((id)->common.type) != error_mark_node)
  {
    if (complain)
      {






        error ("assignment to non-static member `%s' of enclosing class `%s'",
        lang_printable_name (id),
        (((((((((t)->decl.context))->type.name))->decl.name)))->identifier.pointer)
                          );


        ((id)->common.type) = error_mark_node;
      }
    else
      {
        id = (tree) 
            ((void *)0)
                     ;
        continue;
      }
  }
       break;
     }
 }
    }

  return id;
}



static int
lookup_fnfields_1(tree type, tree name) asm("_lookup_fnfields_1");
static int
lookup_fnfields_1(tree type, tree name)
{
  register tree method_vec = ((type)->type.maxval);

  if (method_vec != 0)
    {
      register tree *methods = &((method_vec)->vec.a[0]);
      register tree *end = (&((method_vec)->vec.a[(method_vec)->vec.length]));




      if (*methods && name == constructor_name (type))
 return 0;

      while (++methods != end)
 {



   if (((*methods)->decl.name) == name)
     break;
 }
      if (methods != end)
 return methods - &((method_vec)->vec.a[0]);
    }

  return -1;
}
tree
lookup_fnfields(tree basetype_path, tree name, int complain) asm("_lookup_fnfields");
tree
lookup_fnfields(tree basetype_path, tree name, int complain)
{
  int head = 0, tail = 0;
  tree type, rval, rval_binfo = (tree) 
                               ((void *)0)
                                        , rvals = (tree) 
                                                  ((void *)0)
                                                           , rval_binfo_h;
  tree entry, binfo, basetype_chain, binfo_h;
  int find_all = 0;
  int protect = complain;

  char *errstr = 0;



  int strchr = (((long)(name)>>4)&(8 - 1));

  if (complain == -1)
    {
      find_all = 1;
      protect = complain = 0;
    }



  if ((((struct n64_tag_lang_identifier *)(name))->class_template_info))
    name = constructor_name (name);

  binfo = basetype_path;
  binfo_h = binfo;
  type = ((basetype_path)->common.type);


  if (!find_all && (((type)->type.lang_specific)->memoized_table_entry))
    {
      tree tem = (((ME)(((type)->type.lang_specific)->memoized_table_entry))->function_members[strchr]);

      while (tem && ((tem)->list.purpose) != name)
 {
   memoized_fields_searched[1]++;
   tem = ((tem)->common.chain);
 }
      if (tem)
 {
   if (protect && ((tem)->common.type))
     {
       error (((((tem)->common.type))->string.pointer),
       ((name)->identifier.pointer),
       (((((((((((((((tem)->list.value))->list.value))->decl.lang_specific)->decl_flags.context))->type.name))->decl.name)))->identifier.pointer)));
       return error_mark_node;
     }
   if (((tem)->list.value) == (tree) 
                          ((void *)0)
                                   )
     {
       memoized_fast_rejects[1] += 1;
       return (tree) 
             ((void *)0)
                      ;
     }
   else
     {


       tree baselink = ((tem)->list.value);
       tree memoized_basetypes = ((baselink)->list.purpose);
       tree these_basetypes = basetype_path;
       while (memoized_basetypes && these_basetypes)
  {
    memoized_fields_searched[1]++;
    if (((memoized_basetypes)->list.value) != these_basetypes)
      break;
    memoized_basetypes = ((memoized_basetypes)->common.chain);
    these_basetypes = (((these_basetypes))->vec.a[0]);
  }

       if (memoized_basetypes == these_basetypes)
  {
    memoized_fast_finds[1] += 1;
    return ((tem)->list.value);
  }

       baselink = tree_cons (basetype_path, ((baselink)->list.value), ((baselink)->common.chain));
       return baselink;
     }
 }
    }




  if (protect && flag_memoize_lookups && ! global_bindings_p ())
    entry = make_memoized_table_entry (type, name, 1);
  else
    entry = 0;

  strchr = lookup_fnfields_here (type, name);
  if (strchr >= 0 || lookup_field_1 (type, name))
    {
      rval_binfo = basetype_path;
      rval_binfo_h = rval_binfo;
    }

  if (strchr >= 0)
    {
      rval = ((((type)->type.maxval))->vec.a[strchr]);
      rvals = my_tree_cons (basetype_path, rval, rvals);
      if ((((binfo))->vec.a[4]) && (((type)->type.lang_specific)->baselink_vec))
 ((rvals)->common.type) = (((((type)->type.lang_specific)->baselink_vec))->vec.a[strchr]);

      if (entry)
 {
   ((entry)->list.value) = rvals;
   ((entry)->common.type) = (tree) 
                      ((void *)0)
                               ;
 }

      return rvals;
    }
  rval = (tree) 
        ((void *)0)
                 ;

  if (basetype_path == ((type)->type.binfo))
    {
      basetype_chain = (((type)->type.lang_specific)->binfo_as_list);
      ((basetype_chain)->common.public_flag) = 1;
      ((basetype_path)->common.lang_flag_5) = 1;
      (((basetype_path))->vec.a[0]) = (tree) 
                                               ((void *)0)
                                                        ;
    }
  else
    {
      basetype_chain = build_tree_list ((tree) 
                                       ((void *)0)
                                                , basetype_path);
      ((basetype_chain)->common.public_flag) = ((basetype_path)->common.public_flag);
      ((basetype_chain)->common.protected_flag) = ((basetype_path)->common.protected_flag);
      ((basetype_chain)->common.static_flag) = ((basetype_path)->common.static_flag);
    }



  search_stack = push_search_level (search_stack, &search_obstack);
  binfo = basetype_path;
  binfo_h = binfo;

  while (1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;
      int strchr;


      for (i = 0; i < n_baselinks; i++)
 {
   tree base_binfo = ((binfos)->vec.a[i]);
   if ((((base_binfo)->common.static_flag)?(((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked2):((base_binfo)->common.lang_flag_2)) == 0)
     {
       tree btypes;

       (((base_binfo)->common.static_flag)?((((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked2) = 1):(((base_binfo)->common.lang_flag_2)=1));
       btypes = my_tree_cons ((tree) 
                             ((void *)0)
                                      , base_binfo, basetype_chain);
       ((btypes)->common.public_flag) = ((base_binfo)->common.public_flag);
       ((btypes)->common.protected_flag) = ((base_binfo)->common.protected_flag);
       ((btypes)->common.static_flag) = ((base_binfo)->common.static_flag);
       if (((base_binfo)->common.static_flag))
  btypes = tree_cons ((tree) 
                     ((void *)0)
                              ,
        (((((((((binfo_h))->vec.a[4]))->vec.a[i]))->common.type))->type.binfo),
        btypes);
       else
  btypes = tree_cons ((tree) 
                     ((void *)0)
                              ,
        (((((binfo_h))->vec.a[4]))->vec.a[i]),
        btypes);
       __extension__ ({ struct n64_tag_obstack *__o = (&search_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)btypes); __o->next_free += sizeof (void *); } (void) 0; });
       tail += 1;
       if (tail >= search_stack->limit)
  my_friendly_abort (99);
     }
 }


      if (head >= tail)
 break;

      basetype_chain = search_stack->first[head++];
      binfo_h = ((basetype_chain)->list.value);
      basetype_chain = ((basetype_chain)->common.chain);
      basetype_path = ((basetype_chain)->list.value);
      if (((basetype_chain)->common.chain))
 (((basetype_path))->vec.a[0]) = ((((basetype_chain)->common.chain))->list.value);
      else
 (((basetype_path))->vec.a[0]) = (tree) 
                                          ((void *)0)
                                                   ;

      binfo = basetype_path;
      type = ((binfo)->common.type);





      strchr = lookup_fnfields_here (type, name);

      if (strchr >= 0 || (lookup_field_1 (type, name)!=(tree) 
                                                     ((void *)0) 
                                                               && !find_all))
 {
   if (rval_binfo && !find_all && hides (rval_binfo_h, binfo_h))
     {


     }
   else if (rval_binfo==(tree) 
                       ((void *)0) 
                                 || find_all || hides (binfo_h, rval_binfo_h))
     {


       if (strchr >= 0)
  {
    rval = ((((type)->type.maxval))->vec.a[strchr]);


    rvals = my_tree_cons (basetype_path, rval, rvals);
    if (((((type)->type.binfo))->vec.a[4])
        && (((type)->type.lang_specific)->baselink_vec))
      ((rvals)->common.type) = (((((type)->type.lang_specific)->baselink_vec))->vec.a[strchr]);
  }
       else
  {

    rval = (tree) 
          ((void *)0)
                   ;
    rvals = (tree) 
           ((void *)0)
                    ;
  }
       rval_binfo = binfo;
       rval_binfo_h = binfo_h;
     }
   else
     {

       errstr = "request for method `%D' is ambiguous";
       rvals = error_mark_node;
       break;
     }
 }
    }
  {
    tree *tp = search_stack->first;
    tree *search_tail = tp + tail;

    while (tp < search_tail)
      {
 (((((((*tp)->common.chain))->list.value))->common.static_flag)?((((((((((*tp)->common.chain))->list.value))->common.type))->type.lang_specific)->type_flags.marked2) = 0):(((((((*tp)->common.chain))->list.value))->common.lang_flag_2)=0));
 tp += 1;
      }
  }
  search_stack = pop_search_level (search_stack);

  if (entry)
    {
      if (errstr)
 {
   tree error_string = my_build_string (errstr);

   ((entry)->common.type) = error_string;
 }
      else
 {

   ((entry)->common.type) = (tree) 
                      ((void *)0)
                               ;
   ((entry)->list.value) = rvals;
 }
    }

  if (errstr && protect)
    {
      cp_error (errstr, name);
      rvals = error_mark_node;
    }

  return rvals;
}
int
breadth_first_search(tree binfo, int (*testfn) (...), int (*qfn) (...)) asm("_breadth_first_search");
int
breadth_first_search(tree binfo, int (*testfn) (...), int (*qfn) (...))
{
  int head = 0, tail = 0;
  int rval = 0;

  search_stack = push_search_level (search_stack, &search_obstack);

  while (1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      int n_baselinks = binfos ? ((binfos)->vec.length) : 0;
      int i;


      for (i = 0; i < n_baselinks; i++)
 {
   tree base_binfo = ((binfos)->vec.a[i]);

   if ((((base_binfo)->common.static_flag)?(((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked):((base_binfo)->common.lang_flag_0)) == 0
       && (qfn == 0 || (*qfn) (binfo, i)))
     {
       (((base_binfo)->common.static_flag)?((((((base_binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((base_binfo)->common.lang_flag_0)=1));
       __extension__ ({ struct n64_tag_obstack *__o = (&search_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)binfo); __o->next_free += sizeof (void *); } (void) 0; });
       __extension__ ({ struct n64_tag_obstack *__o = (&search_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)(int) i); __o->next_free += sizeof (void *); } (void) 0; });
       tail += 2;
       if (tail >= search_stack->limit)
  my_friendly_abort (100);
     }
 }

      if (head >= tail)
 {
   rval = 0;
   break;
 }

      binfo = search_stack->first[head++];
      i = (int) search_stack->first[head++];
      if (rval = (*testfn) (binfo, i))
 break;
      binfo = (((((binfo))->vec.a[4]))->vec.a[(i)]);
    }
  {
    tree *tp = search_stack->first;
    tree *search_tail = tp + tail;
    while (tp < search_tail)
      {
 tree binfo = *tp++;
 int i = (int)(*tp++);
 ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?(((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked) = 0):((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_0)=0));
      }
  }

  search_stack = pop_search_level (search_stack);
  return rval;
}


typedef tree (*pft)(...);
typedef int (*pfi)(...);

int tree_needs_constructor_p(tree binfo, int i) asm("_tree_needs_constructor_p");
int tree_needs_constructor_p(tree binfo, int i)
{
  tree basetype;
  my_friendly_assert (i != 0, 296);
  basetype = (((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type);
  return ((basetype)->type.needs_constructing_flag);
}

static tree declarator;

static tree
get_virtuals_named_this(tree binfo) asm("_get_virtuals_named_this");
static tree
get_virtuals_named_this(tree binfo)
{
  tree fields;

  fields = lookup_fnfields (binfo, declarator, -1);


  if (fields == 0)
    return 0;



  while (fields)
    {
      tree fndecl;

      for (fndecl = ((fields)->list.value); fndecl; fndecl = (((fndecl)->decl.lang_specific)->chain))
 if (((fndecl)->decl.vindex))
   return fields;
      fields = next_baselink (fields);
    }
  return (tree) 
        ((void *)0)
                 ;
}

static tree get_virtual_destructor(tree binfo, int i) asm("_get_virtual_destructor");
static tree get_virtual_destructor(tree binfo, int i)
{
  tree type = ((binfo)->common.type);
  if (i >= 0)
    type = (((((((binfo))->vec.a[4]))->vec.a[i]))->common.type);
  if ((((type)->type.lang_flag_2))
      && ((((((type)->type.maxval))->vec.a[0]))->decl.vindex))
    return ((((type)->type.maxval))->vec.a[0]);
  return 0;
}

int tree_has_any_destructor_p(tree binfo, int i) asm("_tree_has_any_destructor_p");
int tree_has_any_destructor_p(tree binfo, int i)
{
  tree type = ((binfo)->common.type);
  if (i >= 0)
    type = (((((((binfo))->vec.a[4]))->vec.a[i]))->common.type);
  return (((type)->type.lang_flag_4));
}







tree
get_matching_virtual(tree binfo, tree fndecl, int dtorp) asm("_get_matching_virtual");
tree
get_matching_virtual(tree binfo, tree fndecl, int dtorp)
{
  tree tmp = (tree) 
            ((void *)0)
                     ;



  if (dtorp)
    {
      if (tree_has_any_destructor_p (binfo, -1))
 tmp = get_virtual_destructor (binfo, -1);

      if (tmp)
 return tmp;

      tmp = (tree) breadth_first_search (binfo,
      (pfi) get_virtual_destructor,
      tree_has_any_destructor_p);
      return tmp;
    }
  else
    {
      tree drettype, dtypes, btypes, instptr_type;
      tree basetype = (((fndecl)->decl.lang_specific)->decl_flags.context);
      tree baselink, best = (tree) 
                           ((void *)0)
                                    ;
      tree name = ((fndecl)->decl.assembler_name);

      declarator = ((fndecl)->decl.name);
      if (((declarator)->common.lang_flag_1) == 0)
 return (tree) 
       ((void *)0)
                ;

      baselink = get_virtuals_named_this (binfo);
      if (baselink == (tree) 
                     ((void *)0)
                              )
 return (tree) 
       ((void *)0)
                ;

      drettype = ((((fndecl)->common.type))->common.type);
      dtypes = ((((fndecl)->common.type))->type.values);
      if ((((fndecl)->decl.lang_specific)->decl_flags.static_function))
 instptr_type = (tree) 
               ((void *)0)
                        ;
      else
 instptr_type = ((((dtypes)->list.value))->common.type);

      for (; baselink; baselink = next_baselink (baselink))
 {
   for (tmp = ((baselink)->list.value); tmp; tmp = (((tmp)->decl.lang_specific)->chain))
     {
       if (! ((tmp)->decl.vindex))
  continue;

       btypes = ((((tmp)->common.type))->type.values);
       if (instptr_type == (tree) 
                          ((void *)0)
                                   )
  {
    if (compparms (((btypes)->common.chain), dtypes, 3))

      return tmp;
    return (tree) 
          ((void *)0)
                   ;
  }

       if ((((((((btypes)->list.value))->common.type))->common.readonly_flag)
     == ((instptr_type)->common.readonly_flag))
    && compparms (((btypes)->common.chain), ((dtypes)->common.chain), 3))
  {
    tree brettype = ((((tmp)->common.type))->common.type);
    if (comptypes (brettype, drettype, 1))
              ;
    else if
      (((n64_enum_tree_code) (brettype)->common.code) == ((n64_enum_tree_code) (drettype)->common.code)
       && (((n64_enum_tree_code) (brettype)->common.code) == POINTER_TYPE
    || ((n64_enum_tree_code) (brettype)->common.code) == REFERENCE_TYPE)
       && comptypes (((((brettype)->common.type))->type.main_variant),
       ((((drettype)->common.type))->type.main_variant),
       0))

      {
        tree b = ((brettype)->common.type), d = ((drettype)->common.type);
        if (((b)->type.main_variant) != ((d)->type.main_variant))
   {
     tree binfo = get_binfo (b, d, 1);
     if (binfo != error_mark_node
         && ! ((((binfo))->vec.a[1]) == integer_zero_node))
       sorry ("adjusting pointers for covariant returns");
   }
        if (((d)->common.readonly_flag) > ((b)->common.readonly_flag))
   {
     cp_error ("return type of `%#D' adds const", fndecl);
     cp_error_at ("  overriding definition as `%#D'",
           tmp);
   }
        else if (((d)->common.volatile_flag) > ((b)->common.volatile_flag))
   {
     cp_error ("return type of `%#D' adds volatile",
        fndecl);
     cp_error_at ("  overriding definition as `%#D'",
           tmp);
   }
      }
    else if ((((n64_enum_tree_code) (brettype)->common.code) == ((n64_enum_tree_code) (drettype)->common.code) && (((brettype)->type.lang_flag_5))&(((drettype)->type.lang_flag_5)))
      && comptypes (brettype, drettype, 0))
      {
        error ("invalid covariant return type (must use pointer or reference)");
        cp_error_at ("  overriding `%#D'", tmp);
        cp_error ("  with `%#D'", fndecl);
      }
    else if ((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->error_locus : 0) == (tree) 
                                             ((void *)0)
                                                      )
      {
        cp_error ("conflicting return type specified for virtual function `%#D'", fndecl);
        cp_error_at ("  overriding definition as `%#D'", tmp);
        (((struct n64_tag_lang_identifier *)(name))->x == 0 ? ((struct n64_tag_lang_identifier *)(name))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(name))->x->error_locus = (basetype));
      }
    break;
  }
     }
   if (tmp)
     {
       best = tmp;
       break;
     }
 }
      if (best == (tree) 
                 ((void *)0) 
                           && warn_overloaded_virtual)
 cp_warning_at ("conflicting specification deriving virtual function `%D'", fndecl);

      return best;
    }
}




static tree
get_abstract_virtuals_1(tree binfo, int do_self, tree abstract_virtuals) asm("_get_abstract_virtuals_1");
static tree
get_abstract_virtuals_1(tree binfo, int do_self, tree abstract_virtuals)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((base_binfo)->common.static_flag))
 abstract_virtuals
   = get_abstract_virtuals_1 (base_binfo, is_not_base_vtable,
         abstract_virtuals);
    }

  if (do_self && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      tree virtuals = (((binfo))->vec.a[3]);

      skip_rtti_stuff (&virtuals);

      while (virtuals)
 {
   tree base_pfn = (!flag_vtable_thunks ? ((((((((((virtuals)->list.value))->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((((virtuals)->list.value)))->exp.operands[0]))->common.code) != THUNK_DECL ? (((virtuals)->list.value)) : (((((((virtuals)->list.value)))->exp.operands[0]))->decl.initial));
   tree base_fndecl = ((base_pfn)->exp.operands[0]);
   if ((((base_fndecl)->decl.lang_specific)->decl_flags.abstract_virtual))
     abstract_virtuals = tree_cons ((tree) 
                                   ((void *)0)
                                            , base_fndecl, abstract_virtuals);
   virtuals = ((virtuals)->common.chain);
 }
    }
  return abstract_virtuals;
}




tree
get_abstract_virtuals(tree type) asm("_get_abstract_virtuals");
tree
get_abstract_virtuals(tree type)
{
  tree vbases;
  tree abstract_virtuals = (((type)->type.lang_specific)->abstract_virtuals);


  abstract_virtuals
    = get_abstract_virtuals_1 (((type)->type.binfo), 1, abstract_virtuals);

  for (vbases = (((type)->type.lang_specific)->vbases); vbases; vbases = ((vbases)->common.chain))
    {
      tree virtuals = (((vbases))->vec.a[3]);

      skip_rtti_stuff (&virtuals);

      while (virtuals)
 {
   tree base_pfn = (!flag_vtable_thunks ? ((((((((((virtuals)->list.value))->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((((virtuals)->list.value)))->exp.operands[0]))->common.code) != THUNK_DECL ? (((virtuals)->list.value)) : (((((((virtuals)->list.value)))->exp.operands[0]))->decl.initial));
   tree base_fndecl = ((base_pfn)->exp.operands[0]);
   if ((((base_fndecl)->decl.lang_specific)->decl_flags.abstract_virtual))
     abstract_virtuals = tree_cons ((tree) 
                                   ((void *)0)
                                            , base_fndecl, abstract_virtuals);
   virtuals = ((virtuals)->common.chain);
 }
    }
  return nreverse (abstract_virtuals);
}
tree
get_baselinks(tree type_as_binfo_list, tree type, tree name) asm("_get_baselinks");
tree
get_baselinks(tree type_as_binfo_list, tree type, tree name)
{
  int head = 0, tail = 0, strchr;
  tree rval = 0, nval = 0;
  tree basetypes = type_as_binfo_list;
  tree binfo = ((type)->type.binfo);

  search_stack = push_search_level (search_stack, &search_obstack);

  while (1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;


      for (i = 0; i < n_baselinks; i++)
 {
   tree base_binfo = ((binfos)->vec.a[i]);
   tree btypes;

   btypes = hash_tree_cons (((base_binfo)->common.public_flag),
       ((base_binfo)->common.static_flag),
       ((base_binfo)->common.protected_flag),
       (tree) 
      ((void *)0)
               , base_binfo,
       basetypes);
   __extension__ ({ struct n64_tag_obstack *__o = (&search_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)btypes); __o->next_free += sizeof (void *); } (void) 0; });
   search_stack->first = (tree *)((&search_obstack)->alloc_failed ? 0 : (&search_obstack)->object_base);
   tail += 1;
 }

    dont_queue:

      if (head >= tail)
 break;

      basetypes = search_stack->first[head++];
      binfo = ((basetypes)->list.value);
      type = ((binfo)->common.type);
      strchr = lookup_fnfields_1 (type, name);
      if (strchr >= 0)
 {
   nval = ((((type)->type.maxval))->vec.a[strchr]);
   rval = hash_tree_cons (0, 0, 0, basetypes, nval, rval);
   if (((((type)->type.binfo))->vec.a[4]) == 0)
     goto dont_queue;
   else if (((((((type)->type.binfo))->vec.a[4]))->vec.length) == 1)
     {
       if ((((type)->type.lang_specific)->baselink_vec))
  ((rval)->common.type) = (((((type)->type.lang_specific)->baselink_vec))->vec.a[strchr]);
       goto dont_queue;
     }
 }
      nval = (tree) 
            ((void *)0)
                     ;
    }

  search_stack = pop_search_level (search_stack);
  return rval;
}

tree
next_baselink(tree baselink) asm("_next_baselink");
tree
next_baselink(tree baselink)
{
  tree tmp = ((baselink)->common.type);
  baselink = ((baselink)->common.chain);
  while (tmp)
    {

      baselink = tree_cons (((tmp)->list.purpose), ((tmp)->list.value),
       baselink);
      ((baselink)->common.type) = ((tmp)->common.type);
      tmp = ((tmp)->common.chain);
    }
  return baselink;
}







static int cid;



typedef char mi_boolean;
static mi_boolean *mi_matrix;


static tree mi_type;


static int mi_size;
static tree
convert_pointer_to_single_level(tree to_type, tree expr) asm("_convert_pointer_to_single_level");
static tree
convert_pointer_to_single_level(tree to_type, tree expr)
{
  tree binfo_of_derived;
  tree last;

  binfo_of_derived = ((((((expr)->common.type))->common.type))->type.binfo);
  last = get_binfo (to_type, ((((expr)->common.type))->common.type), 0);
  (((last))->vec.a[0]) = binfo_of_derived;
  (((binfo_of_derived))->vec.a[0]) = (tree) 
                                              ((void *)0)
                                                       ;
  return build_vbase_path (PLUS_EXPR, build_pointer_type (to_type), expr, last, 1);
}






static void
dfs_walk(tree binfo, void (*fn) (...), int (*qfn) (...)) asm("_dfs_walk");
static void
dfs_walk(tree binfo, void (*fn) (...), int (*qfn) (...))
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);

      if (qfn == 0 || (*qfn)(base_binfo))
 {
   if (fn == (void (*)(...))(void (*)(tree))dfs_init_vbase_pointers)
     {
       tree saved_vbase_decl_ptr_intermediate
  = vbase_decl_ptr_intermediate;

       if (((base_binfo)->common.static_flag))
  {


    vbase_decl_ptr_intermediate
      = (tree)(((((base_binfo)->common.type))->type.lang_specific)->search_slot);
  }
       else
  {
    vbase_decl_ptr_intermediate
      = convert_pointer_to_single_level (((base_binfo)->common.type),
             vbase_decl_ptr_intermediate);
  }

       dfs_walk (base_binfo, fn, qfn);

       vbase_decl_ptr_intermediate = saved_vbase_decl_ptr_intermediate;
     } else
       dfs_walk (base_binfo, fn, qfn);
 }
    }

  fn (binfo);
}


static int numberedp(tree binfo) asm("_numberedp");
static int numberedp(tree binfo)
{ return (((((binfo)->common.type))->type.lang_specific)->cid); }
static int unnumberedp(tree binfo) asm("_unnumberedp");
static int unnumberedp(tree binfo)
{ return (((((binfo)->common.type))->type.lang_specific)->cid) == 0; }

static int markedp(tree binfo) asm("_markedp");
static int markedp(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked):((binfo)->common.lang_flag_0)); }
static int bfs_markedp(tree binfo, int i) asm("_bfs_markedp");
static int bfs_markedp(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_0)); }
static int unmarkedp(tree binfo) asm("_unmarkedp");
static int unmarkedp(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked):((binfo)->common.lang_flag_0)) == 0; }
static int bfs_unmarkedp(tree binfo, int i) asm("_bfs_unmarkedp");
static int bfs_unmarkedp(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_0)) == 0; }
static int marked_vtable_pathp(tree binfo) asm("_marked_vtable_pathp");
static int marked_vtable_pathp(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked3):((binfo)->common.lang_flag_3)); }
static int bfs_marked_vtable_pathp(tree binfo, int i) asm("_bfs_marked_vtable_pathp");
static int bfs_marked_vtable_pathp(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked3):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_3)); }
static int unmarked_vtable_pathp(tree binfo) asm("_unmarked_vtable_pathp");
static int unmarked_vtable_pathp(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked3):((binfo)->common.lang_flag_3)) == 0; }
static int bfs_unmarked_vtable_pathp(tree binfo, int i) asm("_bfs_unmarked_vtable_pathp");
static int bfs_unmarked_vtable_pathp(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked3):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_3)) == 0; }
static int marked_new_vtablep(tree binfo) asm("_marked_new_vtablep");
static int marked_new_vtablep(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)); }
static int bfs_marked_new_vtablep(tree binfo, int i) asm("_bfs_marked_new_vtablep");
static int bfs_marked_new_vtablep(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked4):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_4)); }
static int unmarked_new_vtablep(tree binfo) asm("_unmarked_new_vtablep");
static int unmarked_new_vtablep(tree binfo)
{ return (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)) == 0; }
static int bfs_unmarked_new_vtablep(tree binfo, int i) asm("_bfs_unmarked_new_vtablep");
static int bfs_unmarked_new_vtablep(tree binfo, int i)
{ return ((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.static_flag)?((((((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.type))->type.lang_specific)->type_flags.marked4):(((((((binfo))->vec.a[4]))->vec.a[(i)]))->common.lang_flag_4)) == 0; }

static int dfs_search_slot_nonempty_p(tree binfo) asm("_dfs_search_slot_nonempty_p");
static int dfs_search_slot_nonempty_p(tree binfo)
{ return (((((binfo)->common.type))->type.lang_specific)->search_slot) != 0; }

static int dfs_debug_unmarkedp(tree binfo) asm("_dfs_debug_unmarkedp");
static int dfs_debug_unmarkedp(tree binfo)
{ return (((((binfo)->common.type))->type.lang_specific)->type_flags.debug_requested) == 0; }
static void
dfs_number(tree binfo) asm("_dfs_number");
static void
dfs_number(tree binfo)
{
  (((((binfo)->common.type))->type.lang_specific)->cid) = ++cid;
}

static void
dfs_unnumber(tree binfo) asm("_dfs_unnumber");
static void
dfs_unnumber(tree binfo)
{
  (((((binfo)->common.type))->type.lang_specific)->cid) = 0;
}

static void
dfs_mark(tree binfo) asm("_dfs_mark");
static void
dfs_mark(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((binfo)->common.lang_flag_0)=1)); }

static void
dfs_unmark(tree binfo) asm("_dfs_unmark");
static void
dfs_unmark(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 0):(((binfo)->common.lang_flag_0)=0)); }

static void
dfs_mark_vtable_path(tree binfo) asm("_dfs_mark_vtable_path");
static void
dfs_mark_vtable_path(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked3) = 1):(((binfo)->common.lang_flag_3)=1)); }

static void
dfs_unmark_vtable_path(tree binfo) asm("_dfs_unmark_vtable_path");
static void
dfs_unmark_vtable_path(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked3) = 0):(((binfo)->common.lang_flag_3)=0)); }

static void
dfs_mark_new_vtable(tree binfo) asm("_dfs_mark_new_vtable");
static void
dfs_mark_new_vtable(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 1):(((binfo)->common.lang_flag_4)=1)); }

static void
dfs_unmark_new_vtable(tree binfo) asm("_dfs_unmark_new_vtable");
static void
dfs_unmark_new_vtable(tree binfo)
{ (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 0):(((binfo)->common.lang_flag_4)=0)); }

static void
dfs_clear_search_slot(tree binfo) asm("_dfs_clear_search_slot");
static void
dfs_clear_search_slot(tree binfo)
{ (((((binfo)->common.type))->type.lang_specific)->search_slot) = 0; }

static void
dfs_debug_mark(tree binfo) asm("_dfs_debug_mark");
static void
dfs_debug_mark(tree binfo)
{
  tree t = ((binfo)->common.type);



  tree methods = ((t)->type.maxval);

  (((t)->type.lang_specific)->type_flags.debug_requested) = 1;


  if (methods == 0
      || (((t)->type.lang_specific)->type_flags.interface_unknown == 0)
      || (write_virtuals == 2 && (((t)->common.lang_flag_2))))
    return;




  if (current_function_decl == (tree) 
                              ((void *)0)
      
     || (((current_function_decl)->decl.lang_specific)->decl_flags.context) != t)
    {
      if (((methods)->vec.a[0]))
 methods = ((methods)->vec.a[0]);
      else
 methods = ((methods)->vec.a[1]);
      while (methods)
 {
   if (((methods)->decl.vindex)
       && (((methods)->decl.lang_specific)->decl_flags.declared_inline) == 0
       && (((methods)->decl.lang_specific)->decl_flags.abstract_virtual) == 0)
     {



       return;
     }
   methods = ((methods)->common.chain);
 }
    }


  ((((t)->type.name))->decl.external_flag) = 0;
  rest_of_type_compilation (t, global_bindings_p ());
}





static void
dfs_find_vbases(tree binfo) asm("_dfs_find_vbases");
static void
dfs_find_vbases(tree binfo)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

  for (i = n_baselinks-1; i >= 0; i--)
    {
      tree base_binfo = ((binfos)->vec.a[i]);

      if (((base_binfo)->common.static_flag)
   && (((((base_binfo)->common.type))->type.lang_specific)->search_slot) == 0)
 {
   tree vbase = ((base_binfo)->common.type);
   tree binfo = binfo_member (vbase, vbase_types);

   (((vbase)->type.lang_specific)->search_slot)
     = (char *) build (PLUS_EXPR, build_pointer_type (vbase),
         vbase_decl_ptr, (((binfo))->vec.a[1]));
 }
    }
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked3) = 1):(((binfo)->common.lang_flag_3)=1));
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 1):(((binfo)->common.lang_flag_4)=1));
}

static void
dfs_init_vbase_pointers(tree binfo) asm("_dfs_init_vbase_pointers");
static void
dfs_init_vbase_pointers(tree binfo)
{
  tree type = ((binfo)->common.type);
  tree fields = ((type)->type.values);
  tree this_vbase_ptr;

  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked3) = 0):(((binfo)->common.lang_flag_3)=0));




  if ((((type)->type.lang_specific)->rtti) && (!strncmp (((((fields)->decl.name))->identifier.pointer), "_vptr.", sizeof("_vptr.")-1)))

    fields = ((fields)->common.chain);

  if (fields == (tree) 
               ((void *)0)
      
     || ((fields)->decl.name) == (tree) 
                              ((void *)0)
      
     || ! (((((fields)->decl.name))->identifier.pointer)[1] == 'v' && ((((fields)->decl.name))->identifier.pointer)[2] == 'b' && ((((fields)->decl.name))->identifier.pointer)[3] == '.'))
    return;

  this_vbase_ptr = vbase_decl_ptr_intermediate;

  if (build_pointer_type (type) != ((((this_vbase_ptr)->common.type))->type.main_variant))
    my_friendly_abort (125);

  while (fields && ((fields)->decl.name)
  && (((((fields)->decl.name))->identifier.pointer)[1] == 'v' && ((((fields)->decl.name))->identifier.pointer)[2] == 'b' && ((((fields)->decl.name))->identifier.pointer)[3] == '.'))
    {
      tree ref = build (COMPONENT_REF, ((fields)->common.type),
   build_indirect_ref (this_vbase_ptr, ((void *)0)), fields);
      tree init = (tree)(((((((fields)->common.type))->common.type))->type.lang_specific)->search_slot);
      vbase_init_result = tree_cons (binfo_member (((((fields)->common.type))->common.type),
         vbase_types),
         build_modify_expr (ref, NOP_EXPR, init),
         vbase_init_result);
      fields = ((fields)->common.chain);
    }
}




static void
dfs_clear_vbase_slots(tree binfo) asm("_dfs_clear_vbase_slots");
static void
dfs_clear_vbase_slots(tree binfo)
{
  tree type = ((binfo)->common.type);
  (((type)->type.lang_specific)->search_slot) = 0;
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked3) = 0):(((binfo)->common.lang_flag_3)=0));
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 0):(((binfo)->common.lang_flag_4)=0));
}

tree
init_vbase_pointers(tree type, tree decl_ptr) asm("_init_vbase_pointers");
tree
init_vbase_pointers(tree type, tree decl_ptr)
{
  if ((((type)->common.lang_flag_3)))
    {
      int old_flag = flag_this_is_variable;
      tree binfo = ((type)->type.binfo);
      flag_this_is_variable = -2;
      vbase_types = (((type)->type.lang_specific)->vbases);
      vbase_decl_ptr = decl_ptr;
      vbase_decl = build_indirect_ref (decl_ptr, ((void *)0));
      vbase_decl_ptr_intermediate = vbase_decl_ptr;
      vbase_init_result = (tree) 
                         ((void *)0)
                                  ;
      dfs_walk (binfo, dfs_find_vbases, unmarked_vtable_pathp);
      dfs_walk (binfo, (void (*)(...))(void (*)(tree))dfs_init_vbase_pointers, marked_vtable_pathp);
      dfs_walk (binfo, dfs_clear_vbase_slots, marked_new_vtablep);
      flag_this_is_variable = old_flag;
      return vbase_init_result;
    }
  return 0;
}
static tree
virtual_context(tree fndecl, tree t, tree vbase) asm("_virtual_context");
static tree
virtual_context(tree fndecl, tree t, tree vbase)
{
  tree path;
  if (get_base_distance ((((fndecl)->decl.lang_specific)->decl_flags.context), t, 0, &path) < 0)
    {

      if (get_base_distance ((((fndecl)->decl.lang_specific)->decl_flags.context), vbase, 0, &path) >= 0)
 {
   while (path)
     {


       if (((path)->common.static_flag) || path == vbase)
  return binfo_member (((path)->common.type), (((t)->type.lang_specific)->vbases));
       path = (((path))->vec.a[0]);
     }
 }

      warning ("recoverable compiler error, fixups for virtual function");
      return vbase;
    }
  while (path)
    {
      if (((path)->common.static_flag))
 return binfo_member (((path)->common.type), (((t)->type.lang_specific)->vbases));
      path = (((path))->vec.a[0]);
    }
  return 0;
}
static void
expand_upcast_fixups(tree binfo, tree addr, tree orig_addr, tree vbase, tree t, tree *vbase_offsets) asm("_expand_upcast_fixups");
static void
expand_upcast_fixups(tree binfo, tree addr, tree orig_addr, tree vbase, tree t, tree *vbase_offsets)
{
  tree virtuals = (((binfo))->vec.a[3]);
  tree vc;
  tree delta;
  unsigned int n;

  delta = purpose_member (vbase, *vbase_offsets);
  if (! delta)
    {
      delta = (tree)(((((vbase)->common.type))->type.lang_specific)->search_slot);
      delta = build (MINUS_EXPR, ptrdiff_type_node, delta, addr);
      delta = save_expr (delta);
      delta = tree_cons (vbase, delta, *vbase_offsets);
      *vbase_offsets = delta;
    }

  n = skip_rtti_stuff (&virtuals);

  while (virtuals)
    {
      tree current_fndecl = ((virtuals)->list.value);
      current_fndecl = (!flag_vtable_thunks ? ((((((((current_fndecl)->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((current_fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? (current_fndecl) : (((((current_fndecl))->exp.operands[0]))->decl.initial));
      current_fndecl = ((current_fndecl)->exp.operands[0]);
      if (current_fndecl
   && current_fndecl != abort_fndecl
   && (vc=virtual_context (current_fndecl, t, vbase)) != vbase)
 {

   tree idx = ((current_fndecl)->decl.vindex);
   tree vtbl = (((binfo))->vec.a[2]);
   tree nvtbl = lookup_name (((vtbl)->decl.name), 0);
   tree aref, ref, naref;
   tree old_delta, new_delta;
   tree init;

   if (nvtbl == (tree) 
               ((void *)0)
       
      || nvtbl == (((struct n64_tag_lang_identifier *)(((vtbl)->decl.name)))->global_value))
     {

       nvtbl = build_decl (VAR_DECL,
      ((vtbl)->decl.name),
      (((((((binfo))->vec.a[2]))->common.type))->type.main_variant));
       ((nvtbl)->decl.frame_size.u) = ((((double_type_node)->type.align)) > (((nvtbl)->decl.frame_size.u)) ? (((double_type_node)->type.align)) : (((nvtbl)->decl.frame_size.u)))
                        ;
       ((nvtbl)->common.readonly_flag) = 0;
       nvtbl = pushdecl (nvtbl);
       init = (tree) 
             ((void *)0)
                      ;
       cp_finish_decl (nvtbl, init, (tree) 
                                   ((void *)0)
                                            , 0, (128));
       ((nvtbl)->decl.virtual_flag) = 1;
       ((nvtbl)->decl.context) = t;
       init = build (MODIFY_EXPR, ((nvtbl)->common.type),
       nvtbl, vtbl);
       ((init)->common.side_effects_flag) = 1;
       expand_expr_stmt (init);

       ref = build_vfield_ref (build_indirect_ref (addr, ((void *)0)), ((((((binfo)->common.type))->type.minval))->decl.context));
       expand_expr_stmt (build_modify_expr (ref, NOP_EXPR,
         build_unary_op (ADDR_EXPR, nvtbl, 0)));
     }
   assemble_external (vtbl);
   aref = build_array_ref (vtbl, idx);
   naref = build_array_ref (nvtbl, idx);
   old_delta = build_component_ref (aref, delta_identifier, 0, 0);
   new_delta = build_component_ref (naref, delta_identifier, 0, 0);
   old_delta = build_binary_op (PLUS_EXPR, old_delta,
           ((delta)->list.value), 0);
   if (vc)
     {


       tree vc_delta = purpose_member (vc, *vbase_offsets);
       if (! vc_delta)
  {
    tree vc_addr = convert_pointer_to_real (vc, orig_addr);
    vc_delta = (tree)(((((vc)->common.type))->type.lang_specific)->search_slot);
    vc_delta = build (MINUS_EXPR, ptrdiff_type_node,
        vc_addr, vc_delta);
    vc_delta = save_expr (vc_delta);
    *vbase_offsets = tree_cons (vc, vc_delta, *vbase_offsets);
  }
       else
  vc_delta = ((vc_delta)->list.value);

       old_delta = build_binary_op (PLUS_EXPR, old_delta, vc_delta, 0);
     }

   ((new_delta)->common.readonly_flag) = 0;
   expand_expr_stmt (build_modify_expr (new_delta, NOP_EXPR,
            old_delta));
 }
      ++n;
      virtuals = ((virtuals)->common.chain);
    }
}



static void
fixup_virtual_upcast_offsets(tree real_binfo, tree binfo, int init_self, int can_elide, tree addr, tree orig_addr, tree type, tree vbase, tree *vbase_offsets) asm("_fixup_virtual_upcast_offsets");
static void
fixup_virtual_upcast_offsets(tree real_binfo, tree binfo, int init_self, int can_elide, tree addr, tree orig_addr, tree type, tree vbase, tree *vbase_offsets)
{
  tree real_binfos = (((real_binfo))->vec.a[4]);
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = real_binfos ? ((real_binfos)->vec.length) : 0;

  for (i = 0; i < n_baselinks; i++)
    {
      tree real_base_binfo = ((real_binfos)->vec.a[i]);
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((real_binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((real_base_binfo)->common.static_flag))
 fixup_virtual_upcast_offsets (real_base_binfo, base_binfo,
          is_not_base_vtable, can_elide, addr,
          orig_addr, type, vbase, vbase_offsets);
    }






  if (init_self && (((((real_binfo)->common.type))->type.lang_specific)->vfields))
    {
      addr = convert_pointer_to_real (binfo, addr);
      expand_upcast_fixups (real_binfo, addr, orig_addr, vbase, type, vbase_offsets);
    }
}
void
expand_indirect_vtbls_init(tree binfo, tree true_exp, tree decl_ptr, int use_computed_offsets) asm("_expand_indirect_vtbls_init");
void
expand_indirect_vtbls_init(tree binfo, tree true_exp, tree decl_ptr, int use_computed_offsets)
{
  tree type = ((binfo)->common.type);
  if ((((type)->common.lang_flag_3)))
    {
      rtx fixup_insns = (rtx) 0;
      int old_flag = flag_this_is_variable;
      tree vbases = (((type)->type.lang_specific)->vbases);
      vbase_types = vbases;
      vbase_decl_ptr = true_exp ? build_unary_op (ADDR_EXPR, true_exp, 0) : decl_ptr;
      vbase_decl = true_exp ? true_exp : build_indirect_ref (decl_ptr, ((void *)0));

      if (use_computed_offsets)
 {

   flag_this_is_variable = -2;
 }

      dfs_walk (binfo, dfs_find_vbases, unmarked_new_vtablep);


      for (; vbases; vbases = ((vbases)->common.chain))
 {
   tree addr;
   if (use_computed_offsets)
     addr = (tree)(((((vbases)->common.type))->type.lang_specific)->search_slot);
   else
     {

       addr = convert_pointer_to_vbase (((vbases)->common.type), vbase_decl_ptr);
     }




   expand_direct_vtbls_init (vbases, ((((vbases)->common.type))->type.binfo),
        1, 0, addr);


   if (use_computed_offsets)
     continue;






   if (flag_vtable_thunks)
     {

     }
   else
     {
       tree vbase_offsets = (tree) 
                           ((void *)0)
                                    ;
       push_to_sequence (fixup_insns);
       fixup_virtual_upcast_offsets (vbases,
         ((((vbases)->common.type))->type.binfo),
         1, 0, addr, vbase_decl_ptr,
         type, vbases, &vbase_offsets);
       fixup_insns = get_insns ();
       end_sequence ();
     }
 }

      if (fixup_insns)
 {
   extern tree in_charge_identifier;
   tree in_charge_node = lookup_name (in_charge_identifier, 0);
   if (! in_charge_node)
     {
       warning ("recoverable internal compiler error, nobody's in charge!");
       in_charge_node = integer_zero_node;
     }
   in_charge_node = build_binary_op (EQ_EXPR, in_charge_node, integer_zero_node, 1);
   expand_start_cond (in_charge_node, 0);
   emit_insns (fixup_insns);
   expand_end_cond ();
 }

      dfs_walk (binfo, dfs_clear_vbase_slots, marked_new_vtablep);

      flag_this_is_variable = old_flag;
    }
}

void
clear_search_slots(tree type) asm("_clear_search_slots");
void
clear_search_slots(tree type)
{
  dfs_walk (((type)->type.binfo),
     dfs_clear_search_slot, dfs_search_slot_nonempty_p);
}





static void
dfs_get_vbase_types(tree binfo) asm("_dfs_get_vbase_types");
static void
dfs_get_vbase_types(tree binfo)
{
  if (((binfo)->common.static_flag) && ! (((((binfo)->common.type))->type.lang_specific)->type_flags.marked2))
    {
      vbase_types = make_binfo (integer_zero_node, binfo,
    (((binfo))->vec.a[2]),
    (((binfo))->vec.a[3]), vbase_types);
      ((vbase_types)->common.static_flag) = 1;
      ((((((binfo)->common.type))->type.lang_specific)->type_flags.marked2) = 1);
    }
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((binfo)->common.lang_flag_0)=1));
}


tree
get_vbase_types(tree type) asm("_get_vbase_types");
tree
get_vbase_types(tree type)
{
  tree vbases;
  tree binfo;

  if (((n64_enum_tree_code) (type)->common.code) == TREE_VEC)
    binfo = type;
  else
    binfo = ((type)->type.binfo);

  vbase_types = (tree) 
               ((void *)0)
                        ;
  dfs_walk (binfo, dfs_get_vbase_types, unmarkedp);
  dfs_walk (binfo, dfs_unmark, markedp);


  vbase_types = nreverse (vbase_types);


  for (vbases = vbase_types; vbases; vbases = ((vbases)->common.chain))
    ((((((vbases)->common.type))->type.lang_specific)->type_flags.marked2) = 0);

  return vbase_types;
}

static void
dfs_record_inheritance(tree binfo) asm("_dfs_record_inheritance");
static void
dfs_record_inheritance(tree binfo)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;
  mi_boolean *derived_row = (mi_matrix+((((((binfo)->common.type))->type.lang_specific)->cid)-1));

  for (i = n_baselinks-1; i >= 0; i--)
    {
      int j;
      tree base_binfo = ((binfos)->vec.a[i]);
      tree baseclass = ((base_binfo)->common.type);
      mi_boolean *base_row = (mi_matrix+((((((base_binfo)->common.type))->type.lang_specific)->cid)-1));



      if (((((baseclass)->type.binfo))->vec.a[4]) && mi_size > 0)
 for (j = mi_size*((((baseclass)->type.lang_specific)->cid)-1); j >= 0; j -= mi_size)
   derived_row[j] |= base_row[j];
      ((mi_matrix+mi_size*((((baseclass)->type.lang_specific)->cid)-1))[(((((binfo)->common.type))->type.lang_specific)->cid)-1]) = 1;
    }

  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((binfo)->common.lang_flag_0)=1));
}
void
build_mi_matrix(tree type) asm("_build_mi_matrix");
void
build_mi_matrix(tree type)
{
  tree binfo = ((type)->type.binfo);
  cid = 0;


  if ((((type)->type.lang_specific)->mi_matrix))
    {
      mi_size = (((type)->type.lang_specific)->n_ancestors) + (((type)->type.lang_specific)->type_flags.n_vancestors);
      mi_matrix = (((type)->type.lang_specific)->mi_matrix);
      mi_type = type;
      dfs_walk (binfo, dfs_number, unnumberedp);
      return;
    }


  mi_size = (((type)->type.lang_specific)->n_ancestors) + (((type)->type.lang_specific)->type_flags.n_vancestors);
  mi_matrix = (char *)xmalloc ((mi_size + 1) * (mi_size + 1));
  mi_type = type;
  memset (mi_matrix,0,(mi_size + 1) * (mi_size + 1));
  dfs_walk (binfo, dfs_number, unnumberedp);
  dfs_walk (binfo, dfs_record_inheritance, unmarkedp);
  dfs_walk (binfo, dfs_unmark, markedp);
}

void
free_mi_matrix(void) asm("_free_mi_matrix");
void
free_mi_matrix(void)
{
  dfs_walk (((mi_type)->type.binfo), dfs_unnumber, numberedp);


  (((mi_type)->type.lang_specific)->mi_matrix) = mi_matrix;





}






void
note_debug_info_needed(tree type) asm("_note_debug_info_needed");
void
note_debug_info_needed(tree type)
{
  tree field;
  dfs_walk (((type)->type.binfo), dfs_debug_mark, dfs_debug_unmarkedp);
  for (field = ((type)->type.values); field; field = ((field)->common.chain))
    {
      tree ttype;
      if (((n64_enum_tree_code) (field)->common.code) == FIELD_DECL
   && (((ttype = target_type (((field)->common.type)))->type.lang_flag_5))
   && dfs_debug_unmarkedp (((ttype)->type.binfo)))
 note_debug_info_needed (ttype);
    }
}




static void
envelope_add_decl(tree type, tree decl, tree *values) asm("_envelope_add_decl");
static void
envelope_add_decl(tree type, tree decl, tree *values)
{
  tree context, *tmp;
  tree name = ((decl)->decl.name);
  int dont_add = 0;


  if ((((name)->identifier.pointer)[1] == 'v' && ((name)->identifier.pointer)[2] == 'b' && ((name)->identifier.pointer)[3] == '.'))
    *values = (tree) 
             ((void *)0)
                      ;



  else if (*values && ((n64_enum_tree_code) (*values)->common.code) != TREE_LIST)
    {
      tree value = *values;

      if (warn_shadow && ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
   && ((((*values)->decl.lang_specific)
        && (((value)->decl.lang_specific)->decl_flags.context) == current_class_type)
       || ! ((value)->common.private_flag)))

 {
   cp_warning_at ("member `%#D' is shadowed", value);
   cp_warning_at ("by member function `%#D'", decl);
   warning ("in this context");
 }

      context = (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL
   && ((value)->decl.virtual_flag))
 ? (((value)->decl.lang_specific)->decl_flags.context)
   : ((value)->decl.context);

      if (context == type)
 {
   if (((n64_enum_tree_code) (value)->common.code) == TYPE_DECL
       && ((value)->decl.artificial_flag))
     *values = (tree) 
              ((void *)0)
                       ;
   else
     dont_add = 1;
 }
      else if (context && ((mi_matrix+mi_size*((((context)->type.lang_specific)->cid)-1))[(((type)->type.lang_specific)->cid)-1]))
 {

   *values = (tree) 
            ((void *)0)
                     ;
 }
      else
 *values = build_tree_list ((tree) 
                           ((void *)0)
                                    , value);
    }
  else
    for (tmp = values; *tmp;)
      {
 tree value = ((*tmp)->list.value);
 my_friendly_assert (((n64_enum_tree_code) (value)->common.code) != TREE_LIST, 999);
 context = (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL
     && ((value)->decl.virtual_flag))
   ? (((value)->decl.lang_specific)->decl_flags.context)
     : ((value)->decl.context);

 if (context && ((mi_matrix+mi_size*((((context)->type.lang_specific)->cid)-1))[(((type)->type.lang_specific)->cid)-1]))
   {

     *tmp = ((*tmp)->common.chain);
   }
 else
   tmp = &((*tmp)->common.chain);
      }

  if (! dont_add)
    {

      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 {
   *values = tree_cons (name, decl, *values);
   (((*values)->common.lang_flag_0)) = 1;
   ((*values)->common.type) = unknown_type_node;
 }
      else
 {
   if (*values)
     {
       *values = tree_cons ((tree) 
                           ((void *)0)
                                    , decl, *values);




       (((*values)->common.lang_flag_0)) = 1;
     }
   else
     *values = decl;
 }
    }
}
static void
dfs_pushdecls(tree binfo) asm("_dfs_pushdecls");
static void
dfs_pushdecls(tree binfo)
{
  tree type = ((binfo)->common.type);
  tree fields, *methods, *end;
  tree method_vec;

  for (fields = ((type)->type.values); fields; fields = ((fields)->common.chain))
    {



      if (((n64_enum_tree_code) (fields)->common.code) == FIELD_DECL)
 ((fields)->common.used_flag) = 0;


      if (((fields)->decl.name) == (tree) 
                               ((void *)0)
   
  && ((n64_enum_tree_code) (((fields)->common.type))->common.code) == UNION_TYPE)
 {
   dfs_pushdecls (((((fields)->common.type))->type.binfo));
   continue;
 }

      if (((fields)->decl.name))
 {
   tree name = ((fields)->decl.name);
   tree class_value = (((struct n64_tag_lang_identifier *)(name))->class_value);



   if (class_value == (tree) 
                     ((void *)0) 
                               || ((n64_enum_tree_code) (class_value)->common.code) != TREE_LIST
       || ((class_value)->list.purpose) == (tree) 
                                       ((void *)0)
       
      || ((n64_enum_tree_code) (((class_value)->list.purpose))->common.code) == IDENTIFIER_NODE)
     {

       closed_envelopes = tree_cons ((tree) 
                                    ((void *)0)
                                             , class_value,
         closed_envelopes);
       (((struct n64_tag_lang_identifier *)(name))->class_value) = closed_envelopes;
       class_value = (((struct n64_tag_lang_identifier *)(name))->class_value);
     }

   envelope_add_decl (type, fields, &((class_value)->list.purpose));
 }
    }

  method_vec = ((type)->type.maxval);
  if (method_vec != 0)
    {

      methods = &((method_vec)->vec.a[1]);
      end = (&((method_vec)->vec.a[(method_vec)->vec.length]));

      while (methods != end)
 {


   tree name = ((*methods)->decl.name);
   tree class_value = (((struct n64_tag_lang_identifier *)(name))->class_value);



   if (class_value == (tree) 
                     ((void *)0) 
                               || ((n64_enum_tree_code) (class_value)->common.code) != TREE_LIST
       || ((class_value)->list.purpose) == (tree) 
                                       ((void *)0)
       
      || ((n64_enum_tree_code) (((class_value)->list.purpose))->common.code) == IDENTIFIER_NODE)
     {

       closed_envelopes = tree_cons ((tree) 
                                    ((void *)0)
                                             , class_value,
         closed_envelopes);
       (((struct n64_tag_lang_identifier *)(name))->class_value) = closed_envelopes;
       class_value = (((struct n64_tag_lang_identifier *)(name))->class_value);
     }




   maybe_push_cache_obstack ();
   envelope_add_decl (type, *methods, &((class_value)->list.purpose));
   pop_obstacks ();

   methods++;
 }
    }
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 1):(((binfo)->common.lang_flag_0)=1));
}


static void
dfs_compress_decls(tree binfo) asm("_dfs_compress_decls");
static void
dfs_compress_decls(tree binfo)
{
  tree type = ((binfo)->common.type);
  tree method_vec = ((type)->type.maxval);

  if (method_vec != 0)
    {

      tree *methods = &((method_vec)->vec.a[1]);
      tree *end = (&((method_vec)->vec.a[(method_vec)->vec.length]));

      for (; methods != end; methods++)
 {


   tree class_value = (((struct n64_tag_lang_identifier *)(((*methods)->decl.name)))->class_value);
   tree tmp = ((class_value)->list.purpose);



   if (((n64_enum_tree_code) (tmp)->common.code) != TREE_LIST)
     continue;

   if (((tmp)->common.chain) == (tree) 
                          ((void *)0)
       
      && ((tmp)->list.value)
       && (((((tmp)->list.value))->decl.lang_specific)->chain) == (tree) 
                                          ((void *)0)
                                                   )
     {
       ((class_value)->list.purpose) = ((tmp)->list.value);
     }
 }
    }
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked) = 0):(((binfo)->common.lang_flag_0)=0));
}







void
push_class_decls(tree type) asm("_push_class_decls");
void
push_class_decls(tree type)
{
  tree id;
  struct n64_tag_obstack *ambient_obstack = current_obstack;

  search_stack = push_search_level (search_stack, &search_obstack);

  id = (((((type)->type.name))->decl.name));
  dfs_walk (((type)->type.binfo), dfs_pushdecls, unmarkedp);



  dfs_walk (((type)->type.binfo), (void (*)(...))(void (*)(tree))dfs_compress_decls, markedp);



  while (closed_envelopes)
    {
      tree cxx_new = ((closed_envelopes)->list.purpose);
      tree id;





      if (((n64_enum_tree_code) (cxx_new)->common.code) == TREE_LIST)
 {
   if (((cxx_new)->list.purpose) != (tree) 
                            ((void *)0)
                                     )
     id = ((cxx_new)->list.purpose);
   else
     {
       tree node = ((cxx_new)->list.value);

       while (((n64_enum_tree_code) (node)->common.code) == TREE_LIST)
  node = ((node)->list.value);
       id = ((node)->decl.name);
     }
 }
      else
 id = ((cxx_new)->decl.name);



      (((struct n64_tag_lang_identifier *)(id))->class_value) = ((closed_envelopes)->list.value);
      if (((n64_enum_tree_code) (cxx_new)->common.code) == TREE_LIST)
 push_class_level_binding (id, cxx_new);
      else
 pushdecl_class_level (cxx_new);
      closed_envelopes = ((closed_envelopes)->common.chain);
    }
  current_obstack = ambient_obstack;
}


static void
dfs_unuse_fields(tree binfo) asm("_dfs_unuse_fields");
static void
dfs_unuse_fields(tree binfo)
{
  tree type = ((binfo)->common.type);
  tree fields;

  for (fields = ((type)->type.values); fields; fields = ((fields)->common.chain))
    {
      if (((n64_enum_tree_code) (fields)->common.code) != FIELD_DECL)
 continue;

      ((fields)->common.used_flag) = 0;
      if (((fields)->decl.name) == (tree) 
                               ((void *)0)
   
  && ((n64_enum_tree_code) (((fields)->common.type))->common.code) == UNION_TYPE)
 unuse_fields (((fields)->common.type));
    }
}

void
unuse_fields(tree type) asm("_unuse_fields");
void
unuse_fields(tree type)
{
  dfs_walk (((type)->type.binfo), dfs_unuse_fields, unmarkedp);
}

void
pop_class_decls(tree type) asm("_pop_class_decls");
void
pop_class_decls(tree type)
{


  if (search_stack)
    search_stack = pop_search_level (search_stack);
}

void
print_search_statistics(void) asm("_print_search_statistics");
void
print_search_statistics(void)
{
  fprintf (
          (__acrt_iob_func(2))
                , "no search statistics\n");

}

void
init_search_processing(void) asm("_init_search_processing");
void
init_search_processing(void)
{
  gcc_obstack_init (&search_obstack);
  gcc_obstack_init (&type_obstack);
  gcc_obstack_init (&type_obstack_entries);



  type_stack = push_type_level (0, &type_obstack);
  _vptr_name = get_identifier ("_vptr");
}

void
reinit_search_statistics(void) asm("_reinit_search_statistics");
void
reinit_search_statistics(void)
{
  my_memoized_entry_counter = 0;
  memoized_fast_finds[0] = 0;
  memoized_fast_finds[1] = 0;
  memoized_adds[0] = 0;
  memoized_adds[1] = 0;
  memoized_fast_rejects[0] = 0;
  memoized_fast_rejects[1] = 0;
  memoized_fields_searched[0] = 0;
  memoized_fields_searched[1] = 0;
  n_fields_searched = 0;
  n_calls_lookup_field = 0, n_calls_lookup_field_1 = 0;
  n_calls_lookup_fnfields = 0, n_calls_lookup_fnfields_1 = 0;
  n_calls_get_base_type = 0;
  n_outer_fields_searched = 0;
  n_contexts_saved = 0;
}

static tree conversions;
static void
add_conversions(tree binfo) asm("_add_conversions");
static void
add_conversions(tree binfo)
{
  tree tmp = ((((((binfo)->common.type))->type.maxval))->vec.length) > 1 ? ((((((binfo)->common.type))->type.maxval))->vec.a[1]) : (tree) 
            ((void *)0)
            ;;
  for (; tmp && (! strncmp (((((tmp)->decl.name))->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.length)));
       tmp = ((tmp)->common.chain))
    conversions = tree_cons (((tmp)->decl.name), ((((tmp)->common.type))->common.type),
        conversions);
}

tree
lookup_conversions(tree type) asm("_lookup_conversions");
tree
lookup_conversions(tree type)
{
  conversions = (tree) 
               ((void *)0)
                        ;
  dfs_walk (((type)->type.binfo), add_conversions, 0);
  return conversions;
}

