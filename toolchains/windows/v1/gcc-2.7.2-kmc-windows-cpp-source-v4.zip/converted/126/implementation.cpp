// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/argv.c
/* Create and destroy argument vectors (argv's)
   Copyright (C) 1992 Free Software Foundation, Inc.
   Written by Fred Fish @ Cygnus Support

This file is part of the libiberty library.
Libiberty is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

Libiberty is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with libiberty; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");








extern void *memcpy (void *s1, const void *s2, size_t n) asm("_memcpy");
extern size_t strlen (const char *s) asm("_strlen");
extern void *malloc (size_t size) asm("_malloc");
extern void *realloc (void *ptr, size_t size) asm("_realloc");
extern void free (void *ptr) asm("_free");
extern char *strdup (const char *s) asm("_strdup");
void freeargv(char **vector) asm("_freeargv");
void freeargv(char **vector)
{
  register char **scan;

  if (vector != 
               ((void *)0)
                   )
    {
      for (scan = vector; *scan != 
                                  ((void *)0)
                                      ; scan++)
 {
   free (*scan);
 }
      free (vector);
    }
}
char **buildargv(char *input) asm("_buildargv");
char **buildargv(char *input)
{
  char *arg;
  char *copybuf;
  int squote = 0;
  int dquote = 0;
  int bsquote = 0;
  int argc = 0;
  int maxargc = 0;
  char **argv = 
               ((void *)0)
                   ;
  char **nargv;

  if (input != 
              ((void *)0)
                  )
    {
      copybuf = __builtin_alloca (strlen (input) + 1);


      do
 {

   while (((*input) == ' ' || (*input) == '\t'))
     {
       input++;
     }
   if ((maxargc == 0) || (argc >= (maxargc - 1)))
     {

       if (argv == 
                  ((void *)0)
                      )
  {
    maxargc = 8;
    nargv = (char **) malloc (maxargc * sizeof (char *));
  }
       else
  {
    maxargc *= 2;
    nargv = (char **) realloc (argv, maxargc * sizeof (char *));
  }
       if (nargv == 
                   ((void *)0)
                       )
  {
    if (argv != 
               ((void *)0)
                   )
      {
        freeargv (argv);
        argv = 
              ((void *)0)
                  ;
      }
    break;
  }
       argv = nargv;
       argv[argc] = 
                   ((void *)0)
                       ;
     }

   arg = copybuf;
   while (*input != '\0')
     {
       if (((*input) == ' ' || (*input) == '\t') && !squote && !dquote && !bsquote)
  {
    break;
  }
       else
  {
    if (bsquote)
      {
        bsquote = 0;
        *arg++ = *input;
      }
    else if (*input == '\\')
      {
        bsquote = 1;
      }
    else if (squote)
      {
        if (*input == '\'')
   {
     squote = 0;
   }
        else
   {
     *arg++ = *input;
   }
      }
    else if (dquote)
      {
        if (*input == '"')
   {
     dquote = 0;
   }
        else
   {
     *arg++ = *input;
   }
      }
    else
      {
        if (*input == '\'')
   {
     squote = 1;
   }
        else if (*input == '"')
   {
     dquote = 1;
   }
        else
   {
     *arg++ = *input;
   }
      }
    input++;
  }
     }
   *arg = '\0';
   argv[argc] = strdup (copybuf);
   if (argv[argc] == 
                    ((void *)0)
                        )
     {
       freeargv (argv);
       argv = 
             ((void *)0)
                 ;
       break;
     }
   argc++;
   argv[argc] = 
               ((void *)0)
                   ;

   while (((*input) == ' ' || (*input) == '\t'))
     {
       input++;
     }
 }
      while (*input != '\0');
    }
  return (argv);
}

