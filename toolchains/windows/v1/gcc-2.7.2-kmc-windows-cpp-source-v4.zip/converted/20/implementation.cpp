// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/real.c
/* real.c - implementation of REAL_ARITHMETIC, REAL_VALUE_ATOF,
   and support for XFmode IEEE extended real floating point arithmetic.
   Copyright (C) 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by Stephen L. Moshier (moshier@world.std.com).

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int warning(...) asm("_warning");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern int extra_warnings;
extern unsigned short ezero[], ehalf[], eone[], etwo[];
extern unsigned short elog2[], esqrt2[];

static void endian (unsigned short *, long *, n64_enum_machine_mode) asm("_endian")
                             ;
static void eclear (unsigned short *) asm("_eclear");
static void emov (unsigned short *, unsigned short *) asm("_emov");
static void eabs (unsigned short *) asm("_eabs");
static void eneg (unsigned short *) asm("_eneg");
static int eisneg (unsigned short *) asm("_eisneg");
static int eisinf (unsigned short *) asm("_eisinf");
static int eisnan (unsigned short *) asm("_eisnan");
static void einfin (unsigned short *) asm("_einfin");
static void enan (unsigned short *, int) asm("_enan");
static void emovi (unsigned short *, unsigned short *) asm("_emovi");
static void emovo (unsigned short *, unsigned short *) asm("_emovo");
static void ecleaz (unsigned short *) asm("_ecleaz");
static void ecleazs (unsigned short *) asm("_ecleazs");
static void emovz (unsigned short *, unsigned short *) asm("_emovz");
static void einan (unsigned short *) asm("_einan");
static int eiisnan (unsigned short *) asm("_eiisnan");
static int eiisneg (unsigned short *) asm("_eiisneg");
static void eiinfin (unsigned short *) asm("_eiinfin");
static int eiisinf (unsigned short *) asm("_eiisinf");
static int ecmpm (unsigned short *, unsigned short *) asm("_ecmpm");
static void eshdn1 (unsigned short *) asm("_eshdn1");
static void eshup1 (unsigned short *) asm("_eshup1");
static void eshdn8 (unsigned short *) asm("_eshdn8");
static void eshup8 (unsigned short *) asm("_eshup8");
static void eshup6 (unsigned short *) asm("_eshup6");
static void eshdn6 (unsigned short *) asm("_eshdn6");
static void eaddm (unsigned short *, unsigned short *) asm("_eaddm");
static void esubm (unsigned short *, unsigned short *) asm("_esubm");
static void m16m (unsigned int, unsigned short *, unsigned short *) asm("_m16m")
                            ;
static int edivm (unsigned short *, unsigned short *) asm("_edivm");
static int emulm (unsigned short *, unsigned short *) asm("_emulm");
static void emdnorm (unsigned short *, int, int, int, int) asm("_emdnorm");
static void esub (unsigned short *, unsigned short *, unsigned short *) asm("_esub")
                               ;
static void eadd (unsigned short *, unsigned short *, unsigned short *) asm("_eadd")
                               ;
static void eadd1 (unsigned short *, unsigned short *, unsigned short *) asm("_eadd1")
                               ;
static void ediv (unsigned short *, unsigned short *, unsigned short *) asm("_ediv")
                               ;
static void emul (unsigned short *, unsigned short *, unsigned short *) asm("_emul")
                               ;
static void e53toe (unsigned short *, unsigned short *) asm("_e53toe");
static void e64toe (unsigned short *, unsigned short *) asm("_e64toe");
static void e113toe (unsigned short *, unsigned short *) asm("_e113toe");
static void e24toe (unsigned short *, unsigned short *) asm("_e24toe");
static void etoe113 (unsigned short *, unsigned short *) asm("_etoe113");
static void toe113 (unsigned short *, unsigned short *) asm("_toe113");
static void etoe64 (unsigned short *, unsigned short *) asm("_etoe64");
static void toe64 (unsigned short *, unsigned short *) asm("_toe64");
static void etoe53 (unsigned short *, unsigned short *) asm("_etoe53");
static void toe53 (unsigned short *, unsigned short *) asm("_toe53");
static void etoe24 (unsigned short *, unsigned short *) asm("_etoe24");
static void toe24 (unsigned short *, unsigned short *) asm("_toe24");
static int ecmp (unsigned short *, unsigned short *) asm("_ecmp");
static void eround (unsigned short *, unsigned short *) asm("_eround");
static void ltoe (int *, unsigned short *) asm("_ltoe");
static void ultoe (unsigned int *, unsigned short *) asm("_ultoe");
static void eifrac (unsigned short *, int *, unsigned short *) asm("_eifrac")
                               ;
static void euifrac (unsigned short *, unsigned int *, unsigned short *) asm("_euifrac")
                               ;
static int eshift (unsigned short *, int) asm("_eshift");
static int enormlz (unsigned short *) asm("_enormlz");
static void e24toasc (unsigned short *, char *, int) asm("_e24toasc");
static void e53toasc (unsigned short *, char *, int) asm("_e53toasc");
static void e64toasc (unsigned short *, char *, int) asm("_e64toasc");
static void e113toasc (unsigned short *, char *, int) asm("_e113toasc");
static void etoasc (unsigned short *, char *, int) asm("_etoasc");
static void asctoe24 (char *, unsigned short *) asm("_asctoe24");
static void asctoe53 (char *, unsigned short *) asm("_asctoe53");
static void asctoe64 (char *, unsigned short *) asm("_asctoe64");
static void asctoe113 (char *, unsigned short *) asm("_asctoe113");
static void asctoe (char *, unsigned short *) asm("_asctoe");
static void asctoeg (char *, unsigned short *, int) asm("_asctoeg");
static void efloor (unsigned short *, unsigned short *) asm("_efloor");
static void efrexp (unsigned short *, int *, unsigned short *) asm("_efrexp")
                               ;
static void eldexp (unsigned short *, int, unsigned short *) asm("_eldexp");
static void eremain (unsigned short *, unsigned short *, unsigned short *) asm("_eremain")
                               ;
static void eiremain (unsigned short *, unsigned short *) asm("_eiremain");
static void mtherr (char *, int) asm("_mtherr");
static void dectoe (unsigned short *, unsigned short *) asm("_dectoe");
static void etodec (unsigned short *, unsigned short *) asm("_etodec");
static void todec (unsigned short *, unsigned short *) asm("_todec");
static void ibmtoe (unsigned short *, unsigned short *, n64_enum_machine_mode) asm("_ibmtoe")
                             ;
static void etoibm (unsigned short *, unsigned short *, n64_enum_machine_mode) asm("_etoibm")
                             ;
static void toibm (unsigned short *, unsigned short *, n64_enum_machine_mode) asm("_toibm")
                             ;
static void make_nan (unsigned short *, int, n64_enum_machine_mode) asm("_make_nan");
static void uditoe (unsigned short *, unsigned short *) asm("_uditoe");
static void ditoe (unsigned short *, unsigned short *) asm("_ditoe");
static void etoudi (unsigned short *, unsigned short *) asm("_etoudi");
static void etodi (unsigned short *, unsigned short *) asm("_etodi");
static void esqrt (unsigned short *, unsigned short *) asm("_esqrt");





static void
endian(short unsigned int *e, long int *x, n64_enum_machine_mode mode) asm("_endian");
static void
endian(short unsigned int *e, long int *x, n64_enum_machine_mode mode)
{
  unsigned long th, t;

  if (((target_flags & 0x00010000) != 0))
    {
      switch (mode)
 {

 case TFmode:

   th = (unsigned long) e[6] & 0xffff;
   t = (unsigned long) e[7] & 0xffff;
   t |= th << 16;
   x[3] = (long) t;

 case XFmode:


   th = (unsigned long) e[4] & 0xffff;
   t = (unsigned long) e[5] & 0xffff;
   t |= th << 16;
   x[2] = (long) t;


 case DFmode:


   th = (unsigned long) e[2] & 0xffff;
   t = (unsigned long) e[3] & 0xffff;
   t |= th << 16;
   x[1] = (long) t;


 case HFmode:
 case SFmode:


   th = (unsigned long) e[0] & 0xffff;
   t = (unsigned long) e[1] & 0xffff;
   t |= th << 16;
   x[0] = t;
   break;

 default:
   abort ();
 }
    }
  else
    {


      switch (mode)
 {

 case TFmode:


   th = (unsigned long) e[7] & 0xffff;
   t = (unsigned long) e[6] & 0xffff;
   t |= th << 16;
   x[3] = (long) t;

 case XFmode:




   th = (unsigned long) e[5] & 0xffff;
   t = (unsigned long) e[4] & 0xffff;
   t |= th << 16;
   x[2] = (long) t;


 case DFmode:


   th = (unsigned long) e[3] & 0xffff;
   t = (unsigned long) e[2] & 0xffff;
   t |= th << 16;
   x[1] = (long) t;


 case HFmode:
 case SFmode:


   th = (unsigned long) e[1] & 0xffff;
   t = (unsigned long) e[0] & 0xffff;
   t |= th << 16;
   x[0] = t;
   break;

 default:
   abort ();
 }
    }
}




void
earith(double *value, int icode, double *r1, double *r2) asm("_earith");
void
earith(double *value, int icode, double *r1, double *r2)
{
  unsigned short d1[6], d2[6], v[6];
  n64_enum_tree_code code;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (r1), (d1)); else { unsigned short w[4]; w[3] = ((short *) r1)[0]; w[2] = ((short *) r1)[1]; w[1] = ((short *) r1)[2]; w[0] = ((short *) r1)[3]; e53toe (w, (d1)); } } while (0);
  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (r2), (d2)); else { unsigned short w[4]; w[3] = ((short *) r2)[0]; w[2] = ((short *) r2)[1]; w[1] = ((short *) r2)[2]; w[0] = ((short *) r2)[3]; e53toe (w, (d2)); } } while (0);


  if (eisnan (d1))
    {
      do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((d1), (unsigned short *) (value)); else { unsigned short w[4]; etoe53 ((d1), w); *((short *) value) = w[3]; *((short *) value + 1) = w[2]; *((short *) value + 2) = w[1]; *((short *) value + 3) = w[0]; } } while (0);
      return;
    }
  if (eisnan (d2))
    {
      do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((d2), (unsigned short *) (value)); else { unsigned short w[4]; etoe53 ((d2), w); *((short *) value) = w[3]; *((short *) value + 1) = w[2]; *((short *) value + 2) = w[1]; *((short *) value + 3) = w[0]; } } while (0);
      return;
    }

  code = (n64_enum_tree_code) icode;
  switch (code)
    {
    case PLUS_EXPR:
      eadd (d2, d1, v);
      break;

    case MINUS_EXPR:
      esub (d2, d1, v);
      break;

    case MULT_EXPR:
      emul (d2, d1, v);
      break;

    case RDIV_EXPR:
      ediv (d2, d1, v);
      break;

    case MIN_EXPR:
      if (ecmp (d1, d2) < 0)
 emov (d1, v);
      else
 emov (d2, v);
      break;

    case MAX_EXPR:
      if (ecmp (d1, d2) > 0)
 emov (d1, v);
      else
 emov (d2, v);
      break;
    default:
      emov (ezero, v);
      break;
    }
do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((v), (unsigned short *) (value)); else { unsigned short w[4]; etoe53 ((v), w); *((short *) value) = w[3]; *((short *) value + 1) = w[2]; *((short *) value + 2) = w[1]; *((short *) value + 3) = w[0]; } } while (0);
}





double
etrunci(double x) asm("_etrunci");
double
etrunci(double x)
{
  unsigned short f[6], g[6];
  double r;
  int l;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (g)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (g)); } } while (0);

  if (eisnan (g))
    return (x);

  eifrac (g, &l, f);
  ltoe (&l, g);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((g), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((g), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}





double
etruncui(double x) asm("_etruncui");
double
etruncui(double x)
{
  unsigned short f[6], g[6];
  double r;
  unsigned int l;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (g)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (g)); } } while (0);

  if (eisnan (g))
    return (x);

  euifrac (g, &l, f);
  ultoe (&l, g);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((g), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((g), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}






double
ereal_atof(char *s, n64_enum_machine_mode t) asm("_ereal_atof");
double
ereal_atof(char *s, n64_enum_machine_mode t)
{
  unsigned short tem[6], e[6];
  double r;

  switch (t)
    {
    case HFmode:
    case SFmode:
      asctoe24 (s, tem);
      e24toe (tem, e);
      break;
    case DFmode:
      asctoe53 (s, tem);
      e53toe (tem, e);
      break;
    case XFmode:
      asctoe64 (s, tem);
      e64toe (tem, e);
      break;
    case TFmode:
      asctoe113 (s, tem);
      e113toe (tem, e);
      break;
    default:
      asctoe (s, e);
    }
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((e), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((e), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}




double
ereal_negate(double x) asm("_ereal_negate");
double
ereal_negate(double x)
{
  unsigned short e[6];
  double r;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (e)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (e)); } } while (0);
  eneg (e);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((e), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((e), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}





int
efixi(double x) asm("_efixi");
int
efixi(double x)
{
  unsigned short f[6], g[6];
  int l;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (f)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (f)); } } while (0);

  if (eisnan (f))
    {
      warning ("conversion from NaN to int");
      return (-1);
    }

  eifrac (f, &l, g);
  return l;
}





unsigned int
efixui(double x) asm("_efixui");
unsigned int
efixui(double x)
{
  unsigned short f[6], g[6];
  unsigned int l;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (f)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (f)); } } while (0);

  if (eisnan (f))
    {
      warning ("conversion from NaN to unsigned int");
      return (-1);
    }

  euifrac (f, &l, g);
  return l;
}




void
ereal_from_int(double *d, int i, int j) asm("_ereal_from_int");
void
ereal_from_int(double *d, int i, int j)
{
  unsigned short df[6], dg[6];
  int low, high;
  int sign;

  sign = 0;
  low = i;
  if ((high = j) < 0)
    {
      sign = 1;

      high = ~high;
      if (low)
 low = -low;
      else
 high += 1;
    }
  eldexp (eone, 32, df);
  ultoe ((unsigned int *) &high, dg);
  emul (dg, df, dg);
  ultoe ((unsigned int *) &low, df);
  eadd (df, dg, dg);
  if (sign)
    eneg (dg);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((dg), (unsigned short *) (d)); else { unsigned short w[4]; etoe53 ((dg), w); *((short *) d) = w[3]; *((short *) d + 1) = w[2]; *((short *) d + 2) = w[1]; *((short *) d + 3) = w[0]; } } while (0);
}




void
ereal_from_uint(double *d, unsigned int i, unsigned int j) asm("_ereal_from_uint");
void
ereal_from_uint(double *d, unsigned int i, unsigned int j)
{
  unsigned short df[6], dg[6];
  unsigned int low, high;

  low = i;
  high = j;
  eldexp (eone, 32, df);
  ultoe (&high, dg);
  emul (dg, df, dg);
  ultoe (&low, df);
  eadd (df, dg, dg);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((dg), (unsigned short *) (d)); else { unsigned short w[4]; etoe53 ((dg), w); *((short *) d) = w[3]; *((short *) d + 1) = w[2]; *((short *) d + 2) = w[1]; *((short *) d + 3) = w[0]; } } while (0);
}




void
ereal_to_int(int *low, int *high, double rr) asm("_ereal_to_int");
void
ereal_to_int(int *low, int *high, double rr)
{
  unsigned short d[6], df[6], dg[6], dh[6];
  int s;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&rr), (d)); else { unsigned short w[4]; w[3] = ((short *) &rr)[0]; w[2] = ((short *) &rr)[1]; w[1] = ((short *) &rr)[2]; w[0] = ((short *) &rr)[3]; e53toe (w, (d)); } } while (0);

  if (eisnan (d))
    {
      warning ("conversion from NaN to int");
      *low = -1;
      *high = -1;
      return;
    }


  s = 0;
  if (eisneg (d))
    {
      eneg (d);
      s = 1;
    }
  eldexp (eone, 32, df);
  ediv (df, d, dg);
  euifrac (dg, (unsigned int *) high, dh);
  emul (df, dh, dg);
  euifrac (dg, (unsigned int *)low, dh);
  if (s)
    {

      *high = ~(*high);
      if (*low)
 *low = -(*low);
      else
 *high += 1;
    }
}




double
ereal_ldexp(double x, int n) asm("_ereal_ldexp");
double
ereal_ldexp(double x, int n)
{
  unsigned short e[6], y[6];
  double r;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (e)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (e)); } } while (0);

  if (eisnan (e))
    return (x);

  eldexp (e, n, y);
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((y), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((y), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}
int
target_isinf(double x) asm("_target_isinf");
int
target_isinf(double x)
{
  unsigned short e[6];


  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (e)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (e)); } } while (0);
  return (eisinf (e));



}



int
target_isnan(double x) asm("_target_isnan");
int
target_isnan(double x)
{
  unsigned short e[6];


  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (e)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (e)); } } while (0);
  return (eisnan (e));



}





int
target_negative(double x) asm("_target_negative");
int
target_negative(double x)
{
  return ereal_isneg (x);
}




double
real_value_truncate(n64_enum_machine_mode mode, double arg) asm("_real_value_truncate");
double
real_value_truncate(n64_enum_machine_mode mode, double arg)
{
  unsigned short e[6], t[6];
  double r;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&arg), (e)); else { unsigned short w[4]; w[3] = ((short *) &arg)[0]; w[2] = ((short *) &arg)[1]; w[1] = ((short *) &arg)[2]; w[0] = ((short *) &arg)[3]; e53toe (w, (e)); } } while (0);

  if (eisnan (e))
    return (arg);

  eclear (t);
  switch (mode)
    {
    case TFmode:
      etoe113 (e, t);
      e113toe (t, t);
      break;

    case XFmode:
      etoe64 (e, t);
      e64toe (t, t);
      break;

    case DFmode:
      etoe53 (e, t);
      e53toe (t, t);
      break;

    case HFmode:
    case SFmode:
      etoe24 (e, t);
      e24toe (t, t);
      break;

    case SImode:
      r = etrunci (arg);
      return (r);





    default:
      return (arg);
    }
  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((t), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((t), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return (r);
}






void
debug_real(double r) asm("_debug_real");
void
debug_real(double r)
{
  char dstr[30];

  (ereal_to_decimal (r, dstr));
  fprintf (
          (__acrt_iob_func(2))
                , "%s", dstr);
}
void
etartdouble(double r, long int *l) asm("_etartdouble");
void
etartdouble(double r, long int *l)
{
  unsigned short e[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&r), (e)); else { unsigned short w[4]; w[3] = ((short *) &r)[0]; w[2] = ((short *) &r)[1]; w[1] = ((short *) &r)[2]; w[0] = ((short *) &r)[3]; e53toe (w, (e)); } } while (0);
  etoe113 (e, e);
  endian (e, l, TFmode);
}





void
etarldouble(double r, long int *l) asm("_etarldouble");
void
etarldouble(double r, long int *l)
{
  unsigned short e[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&r), (e)); else { unsigned short w[4]; w[3] = ((short *) &r)[0]; w[2] = ((short *) &r)[1]; w[1] = ((short *) &r)[2]; w[0] = ((short *) &r)[3]; e53toe (w, (e)); } } while (0);
  etoe64 (e, e);
  endian (e, l, XFmode);
}




void
etardouble(double r, long int *l) asm("_etardouble");
void
etardouble(double r, long int *l)
{
  unsigned short e[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&r), (e)); else { unsigned short w[4]; w[3] = ((short *) &r)[0]; w[2] = ((short *) &r)[1]; w[1] = ((short *) &r)[2]; w[0] = ((short *) &r)[3]; e53toe (w, (e)); } } while (0);
  etoe53 (e, e);
  endian (e, l, DFmode);
}




long
etarsingle(double r) asm("_etarsingle");
long
etarsingle(double r)
{
  unsigned short e[6];
  long l;

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&r), (e)); else { unsigned short w[4]; w[3] = ((short *) &r)[0]; w[2] = ((short *) &r)[1]; w[1] = ((short *) &r)[2]; w[0] = ((short *) &r)[3]; e53toe (w, (e)); } } while (0);
  etoe24 (e, e);
  endian (e, &l, SFmode);
  return ((long) l);
}






void
ereal_to_decimal(double x, char *s) asm("_ereal_to_decimal");
void
ereal_to_decimal(double x, char *s)
{
  unsigned short e[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (e)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (e)); } } while (0);
  etoasc (e, s, 20);
}




int
ereal_cmp(double x, double y) asm("_ereal_cmp");
int
ereal_cmp(double x, double y)
{
  unsigned short ex[6], ey[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (ex)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (ex)); } } while (0);
  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&y), (ey)); else { unsigned short w[4]; w[3] = ((short *) &y)[0]; w[2] = ((short *) &y)[1]; w[1] = ((short *) &y)[2]; w[0] = ((short *) &y)[3]; e53toe (w, (ey)); } } while (0);
  return (ecmp (ex, ey));
}



int
ereal_isneg(double x) asm("_ereal_isneg");
int
ereal_isneg(double x)
{
  unsigned short ex[6];

  do { if (0 == ((target_flags & 0x00010000) != 0)) e53toe ((unsigned short*) (&x), (ex)); else { unsigned short w[4]; w[3] = ((short *) &x)[0]; w[2] = ((short *) &x)[1]; w[1] = ((short *) &x)[2]; w[0] = ((short *) &x)[3]; e53toe (w, (ex)); } } while (0);
  return (eisneg (ex));
}
unsigned short ezero[6] =
 {0, 0000000, 0000000, 0000000, 0000000, 0000000,};
unsigned short ehalf[6] =
 {0, 0000000, 0000000, 0000000, 0100000, 0x3ffe,};
unsigned short eone[6] =
 {0, 0000000, 0000000, 0000000, 0100000, 0x3fff,};
unsigned short etwo[6] =
 {0, 0000000, 0000000, 0000000, 0100000, 0040000,};
unsigned short e32[6] =
 {0, 0000000, 0000000, 0000000, 0100000, 0040004,};
unsigned short elog2[6] =
 {0xc9e4, 0x79ab, 0150717, 0013767, 0130562, 0x3ffe,};
unsigned short esqrt2[6] =
 {0x597e, 0x6484, 0174736, 0171463, 0132404, 0x3fff,};
unsigned short epi[6] =
 {0xc4c6, 0xc234, 0020550, 0155242, 0144417, 0040000,};





int rndprc = (((6 +3)-4)*16);
extern int rndprc;



static void
eclear(register short unsigned int *x) asm("_eclear");
static void
eclear(register short unsigned int *x)
{
  register int i;

  for (i = 0; i < 6; i++)
    *x++ = 0;
}



static void
emov(register short unsigned int *a, register short unsigned int *b) asm("_emov");
static void
emov(register short unsigned int *a, register short unsigned int *b)
{
  register int i;

  for (i = 0; i < 6; i++)
    *b++ = *a++;
}




static void
eabs(short unsigned int *x) asm("_eabs");
static void
eabs(short unsigned int *x)
{

  x[6 - 1] &= 0x7fff;
}



static void
eneg(short unsigned int *x) asm("_eneg");
static void
eneg(short unsigned int *x)
{

  x[6 - 1] ^= 0x8000;
}



static int
eisneg(short unsigned int *x) asm("_eisneg");
static int
eisneg(short unsigned int *x)
{

  if (x[6 - 1] & 0x8000)
    return (1);
  else
    return (0);
}



static int
eisinf(short unsigned int *x) asm("_eisinf");
static int
eisinf(short unsigned int *x)
{


  if (eisnan (x))
    return (0);

  if ((x[6 - 1] & 0x7fff) == 0x7fff)
    return (1);
  else
    return (0);
}




static int
eisnan(short unsigned int *x) asm("_eisnan");
static int
eisnan(short unsigned int *x)
{

  int i;


  if ((x[6 - 1] & 0x7fff) != 0x7fff)
    return (0);

  for (i = 0; i < 6 - 1; i++)
    {
      if (*x++ != 0)
        return (1);
    }


  return (0);
}




static void
einfin(register short unsigned int *x) asm("_einfin");
static void
einfin(register short unsigned int *x)
{
  register int i;


  for (i = 0; i < 6 - 1; i++)
    *x++ = 0;
  *x |= 32767;
}





static void
enan(register short unsigned int *x, int sign) asm("_enan");
static void
enan(register short unsigned int *x, int sign)
{
  register int i;

  for (i = 0; i < 6 - 2; i++)
    *x++ = 0;
  *x++ = 0xc000;
  *x = (sign << 15) | 0x7fff;
}



static void
emovi(short unsigned int *a, short unsigned int *b) asm("_emovi");
static void
emovi(short unsigned int *a, short unsigned int *b)
{
  register unsigned short *p, *q;
  int i;

  q = b;
  p = a + (6 - 1);

  if (*p & 0x8000)
    *q++ = 0xffff;
  else
    *q++ = 0;

  *q = *p--;
  *q++ &= 0x7fff;

  if ((*(q - 1) & 0x7fff) == 0x7fff)
    {

      if (eisnan (a))
 {
   *q++ = 0;
   for (i = 3; i < (6 +3); i++)
     *q++ = *p--;
   return;
 }


      for (i = 2; i < (6 +3); i++)
 *q++ = 0;
      return;
    }



  *q++ = 0;

  for (i = 0; i < 6 - 1; i++)
    *q++ = *p--;

  *q = 0;
}



static void
emovo(short unsigned int *a, short unsigned int *b) asm("_emovo");
static void
emovo(short unsigned int *a, short unsigned int *b)
{
  register unsigned short *p, *q;
  unsigned short i;
  int j;

  p = a;
  q = b + (6 - 1);

  i = *p++;
  if (i)
    *q-- = *p++ | 0x8000;
  else
    *q-- = *p++;

  if (*(p - 1) == 0x7fff)
    {

      if (eiisnan (a))
 {
   enan (b, eiisneg (a));
   return;
 }

      einfin (b);
 return;
    }


  ++p;

  for (j = 0; j < 6 - 1; j++)
    *q-- = *p++;
}



static void
ecleaz(register short unsigned int *xi) asm("_ecleaz");
static void
ecleaz(register short unsigned int *xi)
{
  register int i;

  for (i = 0; i < (6 +3); i++)
    *xi++ = 0;
}



static void
ecleazs(register short unsigned int *xi) asm("_ecleazs");
static void
ecleazs(register short unsigned int *xi)
{
  register int i;

  ++xi;
  for (i = 0; i < (6 +3) - 1; i++)
    *xi++ = 0;
}



static void
emovz(register short unsigned int *a, register short unsigned int *b) asm("_emovz");
static void
emovz(register short unsigned int *a, register short unsigned int *b)
{
  register int i;

  for (i = 0; i < (6 +3) - 1; i++)
    *b++ = *a++;

  *b = 0;
}





static void
einan(short unsigned int *x) asm("_einan");
static void
einan(short unsigned int *x)
{

  ecleaz (x);
  x[1] = 0x7fff;
  x[2 + 1] = 0xc000;
}



static int
eiisnan(short unsigned int *x) asm("_eiisnan");
static int
eiisnan(short unsigned int *x)
{
  int i;

  if ((x[1] & 0x7fff) == 0x7fff)
    {
      for (i = 2 + 1; i < (6 +3); i++)
 {
   if (x[i] != 0)
     return (1);
 }
    }
  return (0);
}



static int
eiisneg(short unsigned int *x) asm("_eiisneg");
static int
eiisneg(short unsigned int *x)
{

  return x[0] != 0;
}




static void
eiinfin(short unsigned int *x) asm("_eiinfin");
static void
eiinfin(short unsigned int *x)
{

  ecleaz (x);
  x[1] = 0x7fff;
}



static int
eiisinf(short unsigned int *x) asm("_eiisinf");
static int
eiisinf(short unsigned int *x)
{


  if (eiisnan (x))
    return (0);

  if ((x[1] & 0x7fff) == 0x7fff)
    return (1);
  return (0);
}
static int
ecmpm(register short unsigned int *a, register short unsigned int *b) asm("_ecmpm");
static int
ecmpm(register short unsigned int *a, register short unsigned int *b)
{
  int i;

  a += 2;
  b += 2;
  for (i = 2; i < (6 +3); i++)
    {
      if (*a++ != *b++)
 goto difrnt;
    }
  return (0);

 difrnt:
  if (*(--a) > *(--b))
    return (1);
  else
    return (-1);
}



static void
eshdn1(register short unsigned int *x) asm("_eshdn1");
static void
eshdn1(register short unsigned int *x)
{
  register unsigned short bits;
  int i;

  x += 2;

  bits = 0;
  for (i = 2; i < (6 +3); i++)
    {
      if (*x & 1)
 bits |= 1;
      *x >>= 1;
      if (bits & 2)
 *x |= 0x8000;
      bits <<= 1;
      ++x;
    }
}



static void
eshup1(register short unsigned int *x) asm("_eshup1");
static void
eshup1(register short unsigned int *x)
{
  register unsigned short bits;
  int i;

  x += (6 +3) - 1;
  bits = 0;

  for (i = 2; i < (6 +3); i++)
    {
      if (*x & 0x8000)
 bits |= 1;
      *x <<= 1;
      if (bits & 2)
 *x |= 1;
      bits <<= 1;
      --x;
    }
}




static void
eshdn8(register short unsigned int *x) asm("_eshdn8");
static void
eshdn8(register short unsigned int *x)
{
  register unsigned short newbyt, oldbyt;
  int i;

  x += 2;
  oldbyt = 0;
  for (i = 2; i < (6 +3); i++)
    {
      newbyt = *x << 8;
      *x >>= 8;
      *x |= oldbyt;
      oldbyt = newbyt;
      ++x;
    }
}



static void
eshup8(register short unsigned int *x) asm("_eshup8");
static void
eshup8(register short unsigned int *x)
{
  int i;
  register unsigned short newbyt, oldbyt;

  x += (6 +3) - 1;
  oldbyt = 0;

  for (i = 2; i < (6 +3); i++)
    {
      newbyt = *x >> 8;
      *x <<= 8;
      *x |= oldbyt;
      oldbyt = newbyt;
      --x;
    }
}



static void
eshup6(register short unsigned int *x) asm("_eshup6");
static void
eshup6(register short unsigned int *x)
{
  int i;
  register unsigned short *p;

  p = x + 2;
  x += 2 + 1;

  for (i = 2; i < (6 +3) - 1; i++)
    *p++ = *x++;

  *p = 0;
}



static void
eshdn6(register short unsigned int *x) asm("_eshdn6");
static void
eshdn6(register short unsigned int *x)
{
  int i;
  register unsigned short *p;

  x += (6 +3) - 1;
  p = x + 1;

  for (i = 2; i < (6 +3) - 1; i++)
    *(--p) = *(--x);

  *(--p) = 0;
}



static void
eaddm(short unsigned int *x, short unsigned int *y) asm("_eaddm");
static void
eaddm(short unsigned int *x, short unsigned int *y)
{
  register unsigned int a;
  int i;
  unsigned int carry;

  x += (6 +3) - 1;
  y += (6 +3) - 1;
  carry = 0;
  for (i = 2; i < (6 +3); i++)
    {
      a = (unsigned int) (*x) + (unsigned int) (*y) + carry;
      if (a & 0x10000)
 carry = 1;
      else
 carry = 0;
      *y = (unsigned short) a;
      --x;
      --y;
    }
}



static void
esubm(short unsigned int *x, short unsigned int *y) asm("_esubm");
static void
esubm(short unsigned int *x, short unsigned int *y)
{
  unsigned int a;
  int i;
  unsigned int carry;

  x += (6 +3) - 1;
  y += (6 +3) - 1;
  carry = 0;
  for (i = 2; i < (6 +3); i++)
    {
      a = (unsigned int) (*y) - (unsigned int) (*x) - carry;
      if (a & 0x10000)
 carry = 1;
      else
 carry = 0;
      *y = (unsigned short) a;
      --x;
      --y;
    }
}


static unsigned short equot[(6 +3)];
static void
m16m(unsigned int a, short unsigned int *b, short unsigned int *c) asm("_m16m");
static void
m16m(unsigned int a, short unsigned int *b, short unsigned int *c)
{
  register unsigned short *pp;
  register unsigned int carry;
  unsigned short *ps;
  unsigned short p[(6 +3)];
  unsigned int aa, m;
  int i;

  aa = a;
  pp = &p[(6 +3)-2];
  *pp++ = 0;
  *pp = 0;
  ps = &b[(6 +3)-1];

  for (i=2 +1; i<(6 +3); i++)
    {
      if (*ps == 0)
 {
   --ps;
   --pp;
   *(pp-1) = 0;
 }
      else
 {
   m = (unsigned int) aa * *ps--;
   carry = (m & 0xffff) + *pp;
   *pp-- = (unsigned short)carry;
   carry = (carry >> 16) + (m >> 16) + *pp;
   *pp = (unsigned short)carry;
   *(pp-1) = carry >> 16;
 }
    }
  for (i=2; i<(6 +3); i++)
    c[i] = p[i];
}





static int
edivm(short unsigned int *den, short unsigned int *num) asm("_edivm");
static int
edivm(short unsigned int *den, short unsigned int *num)
{
  int i;
  register unsigned short *p;
  unsigned int tnum;
  unsigned short j, tdenm, tquot;
  unsigned short tprod[(6 +3)+1];

  p = &equot[0];
  *p++ = num[0];
  *p++ = num[1];

  for (i=2; i<(6 +3); i++)
    {
      *p++ = 0;
    }
  eshdn1 (num);
  tdenm = den[2 +1];
  for (i=2; i<(6 +3); i++)
    {

      tnum = (((unsigned int) num[2]) << 16) + num[2 +1];


      if ((tdenm * 0xffffL) < tnum)
 tquot = 0xffff;
      else
 tquot = tnum / tdenm;

      m16m ((unsigned int)tquot, den, tprod);

      if (ecmpm (tprod, num) > 0)
 {
   tquot -= 1;
   esubm (den, tprod);
   if (ecmpm (tprod, num) > 0)
     {
       tquot -= 1;
       esubm (den, tprod);
     }
 }
      esubm (tprod, num);
      equot[i] = tquot;
      eshup6(num);
    }

  p = &num[2];
  j = 0;
  for (i=2; i<(6 +3); i++)
    {
      j |= *p++;
    }
  if (j)
    j = 1;

  for (i=0; i<(6 +3); i++)
    num[i] = equot[i];

  return ((int)j);
}



static int
emulm(short unsigned int *a, short unsigned int *b) asm("_emulm");
static int
emulm(short unsigned int *a, short unsigned int *b)
{
  unsigned short *p, *q;
  unsigned short pprod[(6 +3)];
  unsigned short j;
  int i;

  equot[0] = b[0];
  equot[1] = b[1];
  for (i=2; i<(6 +3); i++)
    equot[i] = 0;

  j = 0;
  p = &a[(6 +3)-1];
  q = &equot[(6 +3)-1];
  for (i=2 +1; i<(6 +3); i++)
    {
      if (*p == 0)
 {
   --p;
 }
      else
 {
   m16m ((unsigned int) *p--, b, pprod);
   eaddm(pprod, equot);
 }
      j |= *q;
      eshdn6(equot);
    }

  for (i=0; i<(6 +3); i++)
    b[i] = equot[i];


  return ((int)j);
}
static int rlast = -1;
static int rw = 0;
static unsigned short rmsk = 0;
static unsigned short rmbit = 0;
static unsigned short rebit = 0;
static int re = 0;
static unsigned short rbit[(6 +3)];

static void
emdnorm(short unsigned int *s, int lost, int subflg, int exp, int rcntrl) asm("_emdnorm");
static void
emdnorm(short unsigned int *s, int lost, int subflg, int exp, int rcntrl)
{
  int i, j;
  unsigned short r;


  j = enormlz (s);
  exp -= j;




  if ((j > (((6 +3)-4)*16)) && (exp < 32767))
    {
      ecleazs (s);
      return;
    }

  if (exp < 0L)
    {
      if (exp > (int) (-(((6 +3)-4)*16) - 1))
 {
   j = (int) exp;
   i = eshift (s, j);
   if (i)
     lost = 1;
 }
      else
 {
   ecleazs (s);
   return;
 }
    }

  if (rcntrl == 0)
    goto mdfin;

  if (rndprc != rlast)
    {
      ecleaz (rbit);
      switch (rndprc)
 {
 default:
 case (((6 +3)-4)*16):
   rw = (6 +3) - 1;
   rmsk = 0xffff;
   rmbit = 0x8000;
   re = rw - 1;
   rebit = 1;
   break;
 case 113:
   rw = 10;
   rmsk = 0x7fff;
   rmbit = 0x4000;
   rebit = 0x8000;
   re = rw;
   break;
 case 64:
   rw = 7;
   rmsk = 0xffff;
   rmbit = 0x8000;
   re = rw - 1;
   rebit = 1;
   break;

 case 56:
   rw = 6;
   rmsk = 0xff;
   rmbit = 0x80;
   rebit = 0x100;
   re = rw;
   break;
 case 53:
   rw = 6;
   rmsk = 0x7ff;
   rmbit = 0x0400;
   rebit = 0x800;
   re = rw;
   break;
 case 24:
   rw = 4;
   rmsk = 0xff;
   rmbit = 0x80;
   rebit = 0x100;
   re = rw;
   break;
 }
      rbit[re] = rebit;
      rlast = rndprc;
    }




  if ((exp <= 0) && (rndprc != (((6 +3)-4)*16))
      && ((rndprc != 64) || ((rndprc == 64) && ! ((target_flags & 0x00010000) != 0))))
    {
      lost |= s[(6 +3) - 1] & 1;
      eshdn1 (s);
    }


  r = s[rw] & rmsk;
  if (rndprc < (((6 +3)-4)*16))
    {
      i = rw + 1;
      while (i < (6 +3))
 {
   if (s[i])
     r |= 1;
   s[i] = 0;
   ++i;
 }
    }
  s[rw] &= ~rmsk;
  if ((r & rmbit) != 0)
    {
      if (r == rmbit)
 {
   if (lost == 0)
     {
       if ((s[re] & rebit) == 0)
  goto mddone;
     }
   else
     {
       if (subflg != 0)
  goto mddone;
     }
 }
      eaddm (rbit, s);
    }
 mddone:

  if ((exp <= 0) && (rndprc != (((6 +3)-4)*16))
      && ((rndprc != 64) || ((rndprc == 64) && ! ((target_flags & 0x00010000) != 0))))
    {
      eshup1 (s);
    }
  if (s[2] != 0)
    {
      eshdn1 (s);
      exp += 1;
    }
 mdfin:
  s[(6 +3) - 1] = 0;
  if (exp >= 32767L)
    {




      s[1] = 32767;
      for (i = 2; i < (6 +3) - 1; i++)
 s[i] = 0;
      if (extra_warnings)
 warning ("floating point overflow");
      return;
    }
  if (exp < 0)
    s[1] = 0;
  else
    s[1] = (unsigned short) exp;
}



static int subflg = 0;

static void
esub(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_esub");
static void
esub(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{


  if (eisnan (a))
    {
      emov (a, c);
      return;
    }
  if (eisnan (b))
    {
      emov (b, c);
      return;
    }


  if (eisinf (a) && eisinf (b)
      && ((eisneg (a) ^ eisneg (b)) == 0))
    {
      mtherr ("esub", 7);
      enan (c, 0);
      return;
    }

  subflg = 1;
  eadd1 (a, b, c);
}



static void
eadd(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_eadd");
static void
eadd(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{



  if (eisnan (a))
    {
      emov (a, c);
      return;
    }
  if (eisnan (b))
    {
      emov (b, c);
      return;
    }


  if (eisinf (a) && eisinf (b)
      && ((eisneg (a) ^ eisneg (b)) != 0))
    {
      mtherr ("esub", 7);
      enan (c, 0);
      return;
    }

  subflg = 0;
  eadd1 (a, b, c);
}



static void
eadd1(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_eadd1");
static void
eadd1(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{
  unsigned short ai[(6 +3)], bi[(6 +3)], ci[(6 +3)];
  int i, lost, j, k;
  int lt, lta, ltb;


  if (eisinf (a))
    {
      emov (a, c);
      if (subflg)
 eneg (c);
      return;
    }
  if (eisinf (b))
    {
      emov (b, c);
      return;
    }

  emovi (a, ai);
  emovi (b, bi);
  if (subflg)
    ai[0] = ~ai[0];


  lta = ai[1];
  ltb = bi[1];
  lt = lta - ltb;
  if (lt > 0L)
    {
      emovz (bi, ci);
      emovz (ai, bi);
      emovz (ci, ai);
      ltb = bi[1];
      lt = -lt;
    }
  lost = 0;
  if (lt != 0L)
    {
      if (lt < (int) (-(((6 +3)-4)*16) - 1))
 goto done;
      k = (int) lt;
      lost = eshift (ai, k);
    }
  else
    {

      i = ecmpm (ai, bi);
      if (i == 0)
 {

   if (ai[0] != bi[0])
     {
       eclear (c);
       return;
     }


   if ((bi[1] == 0) && ((bi[3] & 0x8000) == 0))
     {
       eshup1 (bi);
       goto done;
     }

   for (j = 1; j < (6 +3) - 1; j++)
     {
       if (bi[j] != 0)
  {

    ltb += 1;
    break;
  }
     }
   bi[1] = (unsigned short) ltb;
   goto done;
 }
      if (i > 0)
 {
   emovz (bi, ci);
   emovz (ai, bi);
   emovz (ci, ai);
 }
    }
  if (ai[0] == bi[0])
    {
      eaddm (ai, bi);
      subflg = 0;
    }
  else
    {
      esubm (ai, bi);
      subflg = 1;
    }
  emdnorm (bi, lost, subflg, ltb, 64);

 done:
  emovo (bi, c);
}



static void
ediv(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_ediv");
static void
ediv(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{
  unsigned short ai[(6 +3)], bi[(6 +3)];
  int i, sign;
  int lt, lta, ltb;



  sign = eisneg(a) ^ eisneg(b);



  if (eisnan (a))
    {
    emov (a, c);
    return;
    }
  if (eisnan (b))
    {
    emov (b, c);
    return;
    }

  if (((ecmp (a, ezero) == 0) && (ecmp (b, ezero) == 0))
      || (eisinf (a) && eisinf (b)))
    {
    mtherr ("ediv", 7);
    enan (c, sign);
    return;
    }



  if (eisinf (b))
    {
      einfin (c);
      goto divsign;
    }

  if (eisinf (a))
    {
      eclear (c);
      goto divsign;
    }

  emovi (a, ai);
  emovi (b, bi);
  lta = ai[1];
  ltb = bi[1];
  if (bi[1] == 0)
    {
      for (i = 1; i < (6 +3) - 1; i++)
 {
   if (bi[i] != 0)
     {
       ltb -= enormlz (bi);
       goto dnzro1;
     }
 }
      eclear (c);
      goto divsign;
    }
 dnzro1:

  if (ai[1] == 0)
    {
      for (i = 1; i < (6 +3) - 1; i++)
 {
   if (ai[i] != 0)
     {
       lta -= enormlz (ai);
       goto dnzro2;
     }
 }


      einfin (c);
      mtherr ("ediv", 2);
      goto divsign;
    }
 dnzro2:

  i = edivm (ai, bi);

  lt = ltb - lta + (0x3fff);
  emdnorm (bi, i, 0, lt, 64);
  emovo (bi, c);

 divsign:

  if (sign



      )
     *(c+(6 -1)) |= 0x8000;
  else
     *(c+(6 -1)) &= ~0x8000;
}



static void
emul(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_emul");
static void
emul(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{
  unsigned short ai[(6 +3)], bi[(6 +3)];
  int i, j, sign;
  int lt, lta, ltb;



  sign = eisneg(a) ^ eisneg(b);



  if (eisnan (a))
    {
    emov (a, c);
    return;
    }
  if (eisnan (b))
    {
    emov (b, c);
    return;
    }

  if ((eisinf (a) && (ecmp (b, ezero) == 0))
      || (eisinf (b) && (ecmp (a, ezero) == 0)))
    {
    mtherr ("emul", 7);
    enan (c, sign);
    return;
    }



  if (eisinf (a) || eisinf (b))
    {
      einfin (c);
      goto mulsign;
    }

  emovi (a, ai);
  emovi (b, bi);
  lta = ai[1];
  ltb = bi[1];
  if (ai[1] == 0)
    {
      for (i = 1; i < (6 +3) - 1; i++)
 {
   if (ai[i] != 0)
     {
       lta -= enormlz (ai);
       goto mnzer1;
     }
 }
      eclear (c);
      goto mulsign;
    }
 mnzer1:

  if (bi[1] == 0)
    {
      for (i = 1; i < (6 +3) - 1; i++)
 {
   if (bi[i] != 0)
     {
       ltb -= enormlz (bi);
       goto mnzer2;
     }
 }
      eclear (c);
      goto mulsign;
    }
 mnzer2:


  j = emulm (ai, bi);

  lt = lta + ltb - ((0x3fff) - 1);
  emdnorm (bi, j, 0, lt, 64);
  emovo (bi, c);

 mulsign:

  if (sign



      )
     *(c+(6 -1)) |= 0x8000;
  else
     *(c+(6 -1)) &= ~0x8000;
}



static void
e53toe(short unsigned int *pe, short unsigned int *y) asm("_e53toe");
static void
e53toe(short unsigned int *pe, short unsigned int *y)
{
  register unsigned short r;
  register unsigned short *e, *p;
  unsigned short yy[(6 +3)];
  int denorm, k;

  e = pe;
  denorm = 0;
  ecleaz (yy);
  if (! ((target_flags & 0x00010000) != 0))
    e += 3;
  r = *e;
  yy[0] = 0;
  if (r & 0x8000)
    yy[0] = 0xffff;
  yy[2] = (r & 0x0f) | 0x10;
  r &= ~0x800f;

  if (r == 0x7ff0)
    {

      if (! ((target_flags & 0x00010000) != 0))
 {
   if (((pe[3] & 0xf) != 0) || (pe[2] != 0)
       || (pe[1] != 0) || (pe[0] != 0))
     {
       enan (y, yy[0] != 0);
       return;
     }
 }
      else
 {
   if (((pe[0] & 0xf) != 0) || (pe[1] != 0)
       || (pe[2] != 0) || (pe[3] != 0))
     {
       enan (y, yy[0] != 0);
       return;
     }
 }

      eclear (y);
      einfin (y);
      if (yy[0])
 eneg (y);
      return;
    }

  r >>= 4;



  if (r == 0)
    {
      denorm = 1;
      yy[2] &= ~0x10;
    }
  r += (0x3fff) - 01777;
  yy[1] = r;
  p = &yy[2 + 1];

  if (! ((target_flags & 0x00010000) != 0))
    {
      *p++ = *(--e);
      *p++ = *(--e);
      *p++ = *(--e);
    }
  else
    {
      ++e;
      *p++ = *e++;
      *p++ = *e++;
      *p++ = *e++;
    }

  eshift (yy, -5);
  if (denorm)
    {
      if ((k = enormlz (yy)) > (((6 +3)-4)*16))
 ecleazs (yy);
      else
 yy[1] -= (unsigned short) (k - 1);
    }
  emovo (yy, y);


}



static void
e64toe(short unsigned int *pe, short unsigned int *y) asm("_e64toe");
static void
e64toe(short unsigned int *pe, short unsigned int *y)
{
  unsigned short yy[(6 +3)];
  unsigned short *e, *p, *q;
  int i;

  e = pe;
  p = yy;
  for (i = 0; i < 6 - 5; i++)
    *p++ = 0;
  if (! ((target_flags & 0x00010000) != 0))
    {
      for (i = 0; i < 5; i++)
 *p++ = *e++;




      if((yy[6 -1] & 0x7fff) == 0 && (yy[6 -2] & 0x8000) == 0)
 {
   unsigned short temp[(6 +3)];

   emovi(yy, temp);
   eshup1(temp);
   emovo(temp,y);
   return;
 }
    }
  else
    {
      p = &yy[0] + (6 - 1);
      *p-- = *e++;
      ++e;
      for (i = 0; i < 4; i++)
 *p-- = *e++;
    }



  p = &yy[6 - 1];
  if (*p == 0x7fff)
    {

      if (! ((target_flags & 0x00010000) != 0))
 {
   for (i = 0; i < 4; i++)
     {
       if ((i != 3 && pe[i] != 0)

    || (i == 3 && pe[i] != 0x8000))
  {
    enan (y, (*p & 0x8000) != 0);
    return;
  }
     }
 }
      else
 {
   for (i = 1; i <= 4; i++)
     {
       if (pe[i] != 0)
  {
    enan (y, (*p & 0x8000) != 0);
    return;
  }
     }
 }

      eclear (y);
      einfin (y);
      if (*p & 0x8000)
 eneg (y);
      return;
    }

  p = yy;
  q = y;
  for (i = 0; i < 6; i++)
    *q++ = *p++;
}



static void
e113toe(short unsigned int *pe, short unsigned int *y) asm("_e113toe");
static void
e113toe(short unsigned int *pe, short unsigned int *y)
{
  register unsigned short r;
  unsigned short *e, *p;
  unsigned short yy[(6 +3)];
  int denorm, i;

  e = pe;
  denorm = 0;
  ecleaz (yy);

  if (! ((target_flags & 0x00010000) != 0))
    e += 7;

  r = *e;
  yy[0] = 0;
  if (r & 0x8000)
    yy[0] = 0xffff;
  r &= 0x7fff;

  if (r == 0x7fff)
    {

      if (! ((target_flags & 0x00010000) != 0))
 {
   for (i = 0; i < 7; i++)
     {
       if (pe[i] != 0)
  {
    enan (y, yy[0] != 0);
    return;
  }
     }
 }
      else
 {
   for (i = 1; i < 8; i++)
     {
       if (pe[i] != 0)
  {
    enan (y, yy[0] != 0);
    return;
  }
     }
 }

      eclear (y);
      einfin (y);
      if (yy[0])
 eneg (y);
      return;
    }

  yy[1] = r;
  p = &yy[2 + 1];

  if (! ((target_flags & 0x00010000) != 0))
    {
      for (i = 0; i < 7; i++)
 *p++ = *(--e);
    }
  else
    {
      ++e;
      for (i = 0; i < 7; i++)
 *p++ = *e++;
    }


  if (r == 0)
    {
      yy[2] = 0;
    }
  else
    {
      yy[2] = 1;
      eshift (yy, -1);
    }
  emovo (yy, y);
}



static void
e24toe(short unsigned int *pe, short unsigned int *y) asm("_e24toe");
static void
e24toe(short unsigned int *pe, short unsigned int *y)
{





  register unsigned short r;
  register unsigned short *e, *p;
  unsigned short yy[(6 +3)];
  int denorm, k;

  e = pe;
  denorm = 0;
  ecleaz (yy);

  if (! ((target_flags & 0x00010000) != 0))
    e += 1;




  r = *e;
  yy[0] = 0;
  if (r & 0x8000)
    yy[0] = 0xffff;
  yy[2] = (r & 0x7f) | 0200;
  r &= ~0x807f;

  if (r == 0x7f80)
    {

      if (((target_flags & 0x00010000) != 0))
 {
   if (((pe[0] & 0x7f) != 0) || (pe[1] != 0))
     {
       enan (y, yy[0] != 0);
       return;
     }
 }
      else
 {
   if (((pe[1] & 0x7f) != 0) || (pe[0] != 0))
     {
       enan (y, yy[0] != 0);
       return;
     }
 }

      eclear (y);
      einfin (y);
      if (yy[0])
 eneg (y);
      return;
    }

  r >>= 7;


  if (r == 0)
    {
      denorm = 1;
      yy[2] &= ~0200;
    }
  r += (0x3fff) - 0177;
  yy[1] = r;
  p = &yy[2 + 1];




  if (! ((target_flags & 0x00010000) != 0))
    *p++ = *(--e);
  else
    {
      ++e;
      *p++ = *e++;
    }

  eshift (yy, -8);
  if (denorm)
    {
      if ((k = enormlz (yy)) > (((6 +3)-4)*16))
 ecleazs (yy);
      else
 yy[1] -= (unsigned short) (k - 1);
    }
  emovo (yy, y);

}



static void
etoe113(short unsigned int *x, short unsigned int *e) asm("_etoe113");
static void
etoe113(short unsigned int *x, short unsigned int *e)
{
  unsigned short xi[(6 +3)];
  int exp;
  int rndsav;


  if (eisnan (x))
    {
      make_nan (e, eisneg (x), TFmode);
      return;
    }

  emovi (x, xi);
  exp = (int) xi[1];

  if (eisinf (x))
    goto nonorm;


  rndsav = rndprc;
  rndprc = 113;
  emdnorm (xi, 0, 0, exp, 64);
  rndprc = rndsav;
 nonorm:
  toe113 (xi, e);
}




static void
toe113(short unsigned int *a, short unsigned int *b) asm("_toe113");
static void
toe113(short unsigned int *a, short unsigned int *b)
{
  register unsigned short *p, *q;
  unsigned short i;


  if (eiisnan (a))
    {
      make_nan (b, eiisneg (a), TFmode);
      return;
    }

  p = a;
  if (((target_flags & 0x00010000) != 0))
    q = b;
  else
    q = b + 7;


  if (a[1] != 0)
    {
      eshup1 (a);
    }

  i = *p++;
  if (((target_flags & 0x00010000) != 0))
    {
      if (i)
 *q++ = *p++ | 0x8000;
      else
 *q++ = *p++;
    }
  else
    {
      if (i)
 *q-- = *p++ | 0x8000;
      else
 *q-- = *p++;
    }

  ++p;

  if (((target_flags & 0x00010000) != 0))
    {
      for (i = 0; i < 7; i++)
 *q++ = *p++;
    }
  else
    {
      for (i = 0; i < 7; i++)
 *q-- = *p++;
    }
}



static void
etoe64(short unsigned int *x, short unsigned int *e) asm("_etoe64");
static void
etoe64(short unsigned int *x, short unsigned int *e)
{
  unsigned short xi[(6 +3)];
  int exp;
  int rndsav;


  if (eisnan (x))
    {
      make_nan (e, eisneg (x), XFmode);
      return;
    }

  emovi (x, xi);

  exp = (int) xi[1];

  if (eisinf (x))
    goto nonorm;


  rndsav = rndprc;
  rndprc = 64;
  emdnorm (xi, 0, 0, exp, 64);
  rndprc = rndsav;
 nonorm:
  toe64 (xi, e);
}




static void
toe64(short unsigned int *a, short unsigned int *b) asm("_toe64");
static void
toe64(short unsigned int *a, short unsigned int *b)
{
  register unsigned short *p, *q;
  unsigned short i;


  if (eiisnan (a))
    {
      make_nan (b, eiisneg (a), XFmode);
      return;
    }


  if ((a[1] == 0) && ! ((target_flags & 0x00010000) != 0))
    eshdn1 (a);
  p = a;







  if (((target_flags & 0x00010000) != 0))
    q = b;
  else
    {
      q = b + 4;




    }



  i = *p++;
  if (((target_flags & 0x00010000) != 0))
    {
      if (i)
 *q++ = *p++ | 0x8000;
      else
 *q++ = *p++;
      *q++ = 0;
    }
  else
    {
      if (i)
 *q-- = *p++ | 0x8000;
      else
 *q-- = *p++;
    }


  ++p;
  if (((target_flags & 0x00010000) != 0))
    {
      for (i = 0; i < 4; i++)
 *q++ = *p++;
    }
  else
    {

      if (eiisinf (a))
 {

   *q-- = 0x8000;
   *q-- = 0;
   *q-- = 0;
   *q = 0;
   return;
 }

      for (i = 0; i < 4; i++)
 *q-- = *p++;
    }

}
static void
etoe53(short unsigned int *x, short unsigned int *e) asm("_etoe53");
static void
etoe53(short unsigned int *x, short unsigned int *e)
{
  unsigned short xi[(6 +3)];
  int exp;
  int rndsav;


  if (eisnan (x))
    {
      make_nan (e, eisneg (x), DFmode);
      return;
    }

  emovi (x, xi);

  exp = (int) xi[1] - ((0x3fff) - 0x3ff);

  if (eisinf (x))
    goto nonorm;


  rndsav = rndprc;
  rndprc = 53;
  emdnorm (xi, 0, 0, exp, 64);
  rndprc = rndsav;
 nonorm:
  toe53 (xi, e);
}




static void
toe53(short unsigned int *x, short unsigned int *y) asm("_toe53");
static void
toe53(short unsigned int *x, short unsigned int *y)
{
  unsigned short i;
  unsigned short *p;


  if (eiisnan (x))
    {
      make_nan (y, eiisneg (x), DFmode);
      return;
    }

  p = &x[0];

  if (! ((target_flags & 0x00010000) != 0))
    y += 3;

  *y = 0;
  if (*p++)
    *y = 0x8000;

  i = *p++;
  if (i >= (unsigned int) 2047)
    {

      *y |= 0x7ff0;
      if (! ((target_flags & 0x00010000) != 0))
 {
   *(--y) = 0;
   *(--y) = 0;
   *(--y) = 0;
 }
      else
 {
   ++y;
   *y++ = 0;
   *y++ = 0;
   *y++ = 0;
 }
      return;
    }
  if (i == 0)
    {
      eshift (x, 4);
    }
  else
    {
      i <<= 4;
      eshift (x, 5);
    }
  i |= *p++ & (unsigned short) 0x0f;
  *y |= (unsigned short) i;
  if (! ((target_flags & 0x00010000) != 0))
    {
      *(--y) = *p++;
      *(--y) = *p++;
      *(--y) = *p;
    }
  else
    {
      ++y;
      *y++ = *p++;
      *y++ = *p++;
      *y++ = *p++;
    }
}
static void
etoe24(short unsigned int *x, short unsigned int *e) asm("_etoe24");
static void
etoe24(short unsigned int *x, short unsigned int *e)
{
  int exp;
  unsigned short xi[(6 +3)];
  int rndsav;


  if (eisnan (x))
    {
      make_nan (e, eisneg (x), SFmode);
      return;
    }

  emovi (x, xi);

  exp = (int) xi[1] - ((0x3fff) - 0177);

  if (eisinf (x))
    goto nonorm;


  rndsav = rndprc;
  rndprc = 24;
  emdnorm (xi, 0, 0, exp, 64);
  rndprc = rndsav;
 nonorm:
  toe24 (xi, e);
}




static void
toe24(short unsigned int *x, short unsigned int *y) asm("_toe24");
static void
toe24(short unsigned int *x, short unsigned int *y)
{
  unsigned short i;
  unsigned short *p;


  if (eiisnan (x))
    {
      make_nan (y, eiisneg (x), SFmode);
      return;
    }

  p = &x[0];

  if (! ((target_flags & 0x00010000) != 0))
    y += 1;




  *y = 0;
  if (*p++)
    *y = 0x8000;

  i = *p++;

  if (i >= 255)
    {

      *y |= (unsigned short) 0x7f80;




      if (! ((target_flags & 0x00010000) != 0))
 *(--y) = 0;
      else
 {
   ++y;
   *y = 0;
 }
      return;
    }
  if (i == 0)
    {
      eshift (x, 7);
    }
  else
    {
      i <<= 7;
      eshift (x, 8);
    }
  i |= *p++ & (unsigned short) 0x7f;

  *y |= i;




  if (! ((target_flags & 0x00010000) != 0))
    *(--y) = *p;
  else
    {
      ++y;
      *y = *p;
    }

}
static int
ecmp(short unsigned int *a, short unsigned int *b) asm("_ecmp");
static int
ecmp(short unsigned int *a, short unsigned int *b)
{
  unsigned short ai[(6 +3)], bi[(6 +3)];
  register unsigned short *p, *q;
  register int i;
  int msign;


  if (eisnan (a) || eisnan (b))
      return (-2);

  emovi (a, ai);
  p = ai;
  emovi (b, bi);
  q = bi;

  if (*p != *q)
    {

      for (i = 1; i < (6 +3) - 1; i++)
 {
   if (ai[i] != 0)
     goto nzro;
   if (bi[i] != 0)
     goto nzro;
 }
      return (0);
    nzro:
      if (*p == 0)
 return (1);
      else
 return (-1);
    }

  if (*p == 0)
    msign = 1;
  else
    msign = -1;
  i = (6 +3) - 1;
  do
    {
      if (*p++ != *q++)
 {
   goto diff;
 }
    }
  while (--i > 0);

  return (0);

 diff:

  if (*(--p) > *(--q))
    return (msign);
  else
    return (-msign);
}



static void
eround(short unsigned int *x, short unsigned int *y) asm("_eround");
static void
eround(short unsigned int *x, short unsigned int *y)
{
  eadd (ehalf, x, y);
  efloor (y, y);
}



static void
ltoe(int *lp, short unsigned int *y) asm("_ltoe");
static void
ltoe(int *lp, short unsigned int *y)
{
  unsigned short yi[(6 +3)];
  unsigned int ll;
  int k;

  ecleaz (yi);
  if (*lp < 0)
    {

      ll = (unsigned int) (-(*lp));
      yi[0] = 0xffff;
    }
  else
    {
      ll = (unsigned int) (*lp);
    }
  yi[2] = (unsigned short) (ll >> 16);
  yi[2 + 1] = (unsigned short) ll;
  yi[1] = (0x3fff) + 15;


  if ((k = enormlz (yi)) > (((6 +3)-4)*16))
    ecleaz (yi);
  else
    yi[1] -= (unsigned short) k;
  emovo (yi, y);
}



static void
ultoe(unsigned int *lp, short unsigned int *y) asm("_ultoe");
static void
ultoe(unsigned int *lp, short unsigned int *y)
{
  unsigned short yi[(6 +3)];
  unsigned int ll;
  int k;

  ecleaz (yi);
  ll = *lp;
  yi[2] = (unsigned short) (ll >> 16);
  yi[2 + 1] = (unsigned short) ll;
  yi[1] = (0x3fff) + 15;


  if ((k = enormlz (yi)) > (((6 +3)-4)*16))
    ecleaz (yi);
  else
    yi[1] -= (unsigned short) k;
  emovo (yi, y);
}
static void
eifrac(short unsigned int *x, int *i, short unsigned int *frac) asm("_eifrac");
static void
eifrac(short unsigned int *x, int *i, short unsigned int *frac)
{
  unsigned short xi[(6 +3)];
  int j, k;
  unsigned int ll;

  emovi (x, xi);
  k = (int) xi[1] - ((0x3fff) - 1);
  if (k <= 0)
    {

      *i = 0L;
      emovo (xi, frac);
      return;
    }
  if (k > (32 - 1))
    {


      if (xi[0])
 *i = ((unsigned int) 1) << (32 - 1);
      else
 {







   *i = (((unsigned int) 1) << (32 - 1)) - 1;

 }
      eshift (xi, k);
      if (extra_warnings)
 warning ("overflow on truncation to integer");
    }
  else if (k > 16)
    {


      j = k - ((k >> 4) << 4);
      eshift (xi, j);
      ll = xi[2];
      k -= j;
      do
 {
   eshup6 (xi);
   ll = (ll << 16) | xi[2];
 }
      while ((k -= 16) > 0);
      *i = ll;
      if (xi[0])
 *i = -(*i);
    }
  else
      {

          eshift (xi, k);
        *i = (int) xi[2] & 0xffff;
        if (xi[0])
   *i = -(*i);
      }
  xi[0] = 0;
  xi[1] = (0x3fff) - 1;
  xi[2] = 0;
  if ((k = enormlz (xi)) > (((6 +3)-4)*16))
    ecleaz (xi);
  else
    xi[1] -= (unsigned short) k;

  emovo (xi, frac);
}






static void
euifrac(short unsigned int *x, unsigned int *i, short unsigned int *frac) asm("_euifrac");
static void
euifrac(short unsigned int *x, unsigned int *i, short unsigned int *frac)
{
  unsigned int ll;
  unsigned short xi[(6 +3)];
  int j, k;

  emovi (x, xi);
  k = (int) xi[1] - ((0x3fff) - 1);
  if (k <= 0)
    {

      *i = 0L;
      emovo (xi, frac);
      return;
    }
  if (k > 32)
    {




      *i = ~(0L);
      eshift (xi, k);
      if (extra_warnings)
 warning ("overflow on truncation to unsigned integer");
    }
  else if (k > 16)
    {


      j = k - ((k >> 4) << 4);
      eshift (xi, j);
      ll = xi[2];
      k -= j;
      do
 {
   eshup6 (xi);
   ll = (ll << 16) | xi[2];
 }
      while ((k -= 16) > 0);
      *i = ll;
    }
  else
    {

      eshift (xi, k);
      *i = (int) xi[2] & 0xffff;
    }

  if (xi[0])
    *i = 0L;

  xi[0] = 0;
  xi[1] = (0x3fff) - 1;
  xi[2] = 0;
  if ((k = enormlz (xi)) > (((6 +3)-4)*16))
    ecleaz (xi);
  else
    xi[1] -= (unsigned short) k;

  emovo (xi, frac);
}



static int
eshift(short unsigned int *x, int sc) asm("_eshift");
static int
eshift(short unsigned int *x, int sc)
{
  unsigned short lost;
  unsigned short *p;

  if (sc == 0)
    return (0);

  lost = 0;
  p = x + (6 +3) - 1;

  if (sc < 0)
    {
      sc = -sc;
      while (sc >= 16)
 {
   lost |= *p;
   eshdn6 (x);
   sc -= 16;
 }

      while (sc >= 8)
 {
   lost |= *p & 0xff;
   eshdn8 (x);
   sc -= 8;
 }

      while (sc > 0)
 {
   lost |= *p & 1;
   eshdn1 (x);
   sc -= 1;
 }
    }
  else
    {
      while (sc >= 16)
 {
   eshup6 (x);
   sc -= 16;
 }

      while (sc >= 8)
 {
   eshup8 (x);
   sc -= 8;
 }

      while (sc > 0)
 {
   eshup1 (x);
   sc -= 1;
 }
    }
  if (lost)
    lost = 1;
  return ((int) lost);
}




static int
enormlz(short unsigned int *x) asm("_enormlz");
static int
enormlz(short unsigned int *x)
{
  register unsigned short *p;
  int sc;

  sc = 0;
  p = &x[2];
  if (*p != 0)
    goto normdn;
  ++p;
  if (*p & 0x8000)
    return (0);
  while (*p == 0)
    {
      eshup6 (x);
      sc += 16;



      if (sc > (((6 +3)-4)*16))
 return (sc);
    }

  while ((*p & 0xff00) == 0)
    {
      eshup8 (x);
      sc += 8;
    }

  while ((*p & 0x8000) == 0)
    {
      eshup1 (x);
      sc += 1;
      if (sc > (((6 +3)-4)*16))
 {
   mtherr ("enormlz", 4);
   return (sc);
 }
    }
  return (sc);



 normdn:

  if (*p & 0xff00)
    {
      eshdn8 (x);
      sc -= 8;
    }
  while (*p != 0)
    {
      eshdn1 (x);
      sc -= 1;

      if (sc < -(((6 +3)-4)*16))
 {
   mtherr ("enormlz", 3);
   return (sc);
 }
    }
  return (sc);
}
static unsigned short etens[12 + 1][6] =
{
  {0xc94c, 0x979a, 0x8a20, 0x5202, 0xc460, 0x7525,},
  {0xa74d, 0x5de4, 0xc53d, 0x3b5d, 0x9e8b, 0x5a92,},
  {0x650d, 0x0c17, 0x8175, 0x7586, 0xc976, 0x4d48,},
  {0xcc65, 0x91c6, 0xa60e, 0xa0ae, 0xe319, 0x46a3,},
  {0xddbc, 0xde8d, 0x9df9, 0xebfb, 0xaa7e, 0x4351,},
  {0xc66f, 0x8cdf, 0x80e9, 0x47c9, 0x93ba, 0x41a8,},
  {0x3cbf, 0xa6d5, 0xffcf, 0x1f49, 0xc278, 0x40d3,},
  {0xf020, 0xb59d, 0x2b70, 0xada8, 0x9dc5, 0x4069,},
  {0x0000, 0x0000, 0x0400, 0xc9bf, 0x8e1b, 0x4034,},
  {0x0000, 0x0000, 0x0000, 0x2000, 0xbebc, 0x4019,},
  {0x0000, 0x0000, 0x0000, 0x0000, 0x9c40, 0x400c,},
  {0x0000, 0x0000, 0x0000, 0x0000, 0xc800, 0x4005,},
  {0x0000, 0x0000, 0x0000, 0x0000, 0xa000, 0x4002,},
};

static unsigned short emtens[12 + 1][6] =
{
  {0x2de4, 0x9fde, 0xd2ce, 0x04c8, 0xa6dd, 0x0ad8,},
  {0x4925, 0x2de4, 0x3436, 0x534f, 0xceae, 0x256b,},
  {0x87a6, 0xc0bd, 0xda57, 0x82a5, 0xa2a6, 0x32b5,},
  {0x7133, 0xd21c, 0xdb23, 0xee32, 0x9049, 0x395a,},
  {0xfa91, 0x1939, 0x637a, 0x4325, 0xc031, 0x3cac,},
  {0xac7d, 0xe4a0, 0x64bc, 0x467c, 0xddd0, 0x3e55,},
  {0x3f24, 0xe9a5, 0xa539, 0xea27, 0xa87f, 0x3f2a,},
  {0x67de, 0x94ba, 0x4539, 0x1ead, 0xcfb1, 0x3f94,},
  {0x4c2f, 0xe15b, 0xc44d, 0x94be, 0xe695, 0x3fc9,},
  {0xfdc2, 0xcefc, 0x8461, 0x7711, 0xabcc, 0x3fe4,},
  {0xd3c3, 0x652b, 0xe219, 0x1758, 0xd1b7, 0x3ff1,},
  {0x3d71, 0xd70a, 0x70a3, 0x0a3d, 0xa3d7, 0x3ff8,},
  {0xcccd, 0xcccc, 0xcccc, 0xcccc, 0xcccc, 0x3ffb,},
};





static void
e24toasc(short unsigned int *x, char *string, int ndigs) asm("_e24toasc");
static void
e24toasc(short unsigned int *x, char *string, int ndigs)
{
  unsigned short w[(6 +3)];

  e24toe (x, w);
  etoasc (w, string, ndigs);
}




static void
e53toasc(short unsigned int *x, char *string, int ndigs) asm("_e53toasc");
static void
e53toasc(short unsigned int *x, char *string, int ndigs)
{
  unsigned short w[(6 +3)];

  e53toe (x, w);
  etoasc (w, string, ndigs);
}




static void
e64toasc(short unsigned int *x, char *string, int ndigs) asm("_e64toasc");
static void
e64toasc(short unsigned int *x, char *string, int ndigs)
{
  unsigned short w[(6 +3)];

  e64toe (x, w);
  etoasc (w, string, ndigs);
}




static void
e113toasc(short unsigned int *x, char *string, int ndigs) asm("_e113toasc");
static void
e113toasc(short unsigned int *x, char *string, int ndigs)
{
  unsigned short w[(6 +3)];

  e113toe (x, w);
  etoasc (w, string, ndigs);
}




static char wstring[80];

static void
etoasc(short unsigned int *x, char *string, int ndigs) asm("_etoasc");
static void
etoasc(short unsigned int *x, char *string, int ndigs)
{
  short digit;
  unsigned short y[(6 +3)], t[(6 +3)], u[(6 +3)], w[(6 +3)];
  unsigned short *p, *r, *ten;
  unsigned short sign;
  int i, j, k, expon, rndsav;
  char *s, *ss;
  unsigned short m;


  rndsav = rndprc;
  ss = string;
  s = wstring;
  *ss = '\0';
  *s = '\0';

  if (eisnan (x))
    {
      sprintf (wstring, " NaN ");
      goto bxit;
    }

  rndprc = (((6 +3)-4)*16);
  emov (x, y);
  if (y[6 - 1] & 0x8000)
    {
      sign = 0xffff;
      y[6 - 1] &= 0x7fff;
    }
  else
    {
      sign = 0;
    }
  expon = 0;
  ten = &etens[12][0];
  emov (eone, t);

  if (y[6 - 1] == 0)
    {
      for (k = 0; k < 6 - 1; k++)
 {
   if (y[k] != 0)
     goto tnzro;
 }
      goto isone;
    }
 tnzro:


  if (y[6 - 1] == 0x7fff)
    {
      if (sign)
 sprintf (wstring, " -Infinity ");
      else
 sprintf (wstring, " Infinity ");
      goto bxit;
    }




  if ((y[6 - 1] != 0) && ((y[6 - 2] & 0x8000) == 0))
    {
      mtherr ("etoasc", 1);
      sprintf (wstring, "NaN");
      goto bxit;
    }


  i = ecmp (eone, y);
  if (i == 0)
    goto isone;

  if (i == -2)
    abort ();

  if (i < 0)
    {

      emov (y, u);
      u[6 - 1] = (0x3fff) + (((6 +3)-4)*16) - 1;

      p = &etens[12 - 4][0];
      m = 16;
      do
 {
   ediv (p, u, t);
   efloor (t, w);
   for (j = 0; j < 6 - 1; j++)
     {
       if (t[j] != w[j])
  goto noint;
     }
   emov (t, u);
   expon += (int) m;
 noint:
   p += 6;
   m >>= 1;
 }
      while (m != 0);


      u[6 - 1] += y[6 - 1] - (unsigned int) ((0x3fff) + (((6 +3)-4)*16) - 1);
      emov (u, y);

      emov (eone, t);
      m = 4096;
      p = &etens[0][0];

      while (ecmp (ten, u) <= 0)
 {
   if (ecmp (p, u) <= 0)
     {
       ediv (p, u, u);
       emul (p, t, t);
       expon += (int) m;
     }
   m >>= 1;
   if (m == 0)
     break;
   p += 6;
 }
    }
  else
    {

      if (y[6 - 1] == 0)
 {
   while ((y[6 - 2] & 0x8000) == 0)
     {
       emul (ten, y, y);
       expon -= 1;
     }
 }
      else
 {
   emovi (y, w);
   for (i = 0; i < ((((6 +3)-4)*16)*8/27) + 1; i++)
     {
       if ((w[(6 +3) - 1] & 0x7) != 0)
  break;

       emovz (w, u);
       eshdn1 (u);
       eshdn1 (u);
       eaddm (w, u);
       u[1] += 3;
       while (u[2] != 0)
  {
    eshdn1 (u);
    u[1] += 1;
  }
       if (u[(6 +3) - 1] != 0)
  break;
       if (eone[6 - 1] <= u[1])
  break;
       emovz (u, w);
       expon -= 1;
     }
   emovo (w, y);
 }
      k = -4096;
      p = &emtens[0][0];
      r = &etens[0][0];
      emov (y, w);
      emov (eone, t);
      while (ecmp (eone, w) > 0)
 {
   if (ecmp (p, w) >= 0)
     {
       emul (r, w, w);
       emul (r, t, t);
       expon += k;
     }
   k /= 2;
   if (k == 0)
     break;
   p += 6;
   r += 6;
 }
      ediv (t, eone, t);
    }
 isone:

  emovi (t, w);
  emovz (w, t);
  emovi (y, w);
  emovz (w, y);
  eiremain (t, y);
  digit = equot[(6 +3) - 1];
  while ((digit == 0) && (ecmp (y, ezero) != 0))
    {
      eshup1 (y);
      emovz (y, u);
      eshup1 (u);
      eshup1 (u);
      eaddm (u, y);
      eiremain (t, y);
      digit = equot[(6 +3) - 1];
      expon -= 1;
    }
  s = wstring;
  if (sign)
    *s++ = '-';
  else
    *s++ = ' ';

  if (ndigs < 0)
    ndigs = 0;
  if (ndigs > ((((6 +3)-4)*16)*8/27))
    ndigs = ((((6 +3)-4)*16)*8/27);
  if (digit == 10)
    {
      *s++ = '1';
      *s++ = '.';
      if (ndigs > 0)
 {
   *s++ = '0';
   ndigs -= 1;
 }
      expon += 1;
    }
  else
    {
      *s++ = (char)digit + '0';
      *s++ = '.';
    }

  for (k = 0; k <= ndigs; k++)
    {

      eshup1 (y);
      emovz (y, u);
      eshup1 (u);
      eshup1 (u);
      eaddm (u, y);
      eiremain (t, y);
      *s++ = (char) equot[(6 +3) - 1] + '0';
    }
  digit = equot[(6 +3) - 1];
  --s;
  ss = s;

  if (digit > 4)
    {

      if (digit == 5)
 {
   emovo (y, t);
   if (ecmp (t, ezero) != 0)
     goto roun;
   if ((*(s - 1) & 1) == 0)
     goto doexp;
 }

    roun:
      --s;
      k = *s & 0x7f;

      if (k == '.')
 {
   --s;
   k = *s;
   k += 1;
   *s = (char) k;

   if (k > '9')
     {
       expon += 1;
       *s = '1';
     }
   goto doexp;
 }

      k += 1;
      *s = (char) k;
      if (k > '9')
 {
   *s = '0';
   goto roun;
 }
    }
 doexp:






  sprintf (ss, "e%d", expon);
 bxit:
  rndprc = rndsav;

  s = string;
  ss = wstring;
  while (*ss == ' ')
    ++ss;
  while ((*s++ = *ss++) != '\0')
    ;
}
static void
asctoe24(char *s, short unsigned int *y) asm("_asctoe24");
static void
asctoe24(char *s, short unsigned int *y)
{
  asctoeg (s, y, 24);
}




static void
asctoe53(char *s, short unsigned int *y) asm("_asctoe53");
static void
asctoe53(char *s, short unsigned int *y)
{



  asctoeg (s, y, 53);

}




static void
asctoe64(char *s, short unsigned int *y) asm("_asctoe64");
static void
asctoe64(char *s, short unsigned int *y)
{
  asctoeg (s, y, 64);
}



static void
asctoe113(char *s, short unsigned int *y) asm("_asctoe113");
static void
asctoe113(char *s, short unsigned int *y)
{
  asctoeg (s, y, 113);
}



static void
asctoe(char *s, short unsigned int *y) asm("_asctoe");
static void
asctoe(char *s, short unsigned int *y)
{
  asctoeg (s, y, (((6 +3)-4)*16));
}




static void
asctoeg(char *ss, short unsigned int *y, int oprec) asm("_asctoeg");
static void
asctoeg(char *ss, short unsigned int *y, int oprec)
{
  unsigned short yy[(6 +3)], xt[(6 +3)], tt[(6 +3)];
  int esign, decflg, sgnflg, nexp, exp, prec, lost;
  int k, trail, c, rndsav;
  int lexp;
  unsigned short nsign, *p;
  char *sp, *s, *lstr;


  lstr = (char *) 
                 __builtin_alloca((
                 strlen (ss) + 1
                 ))
                                         ;
  s = ss;
  while (*s == ' ')
    ++s;
  sp = lstr;
  while ((*sp++ = *s++) != '\0')
    ;
  s = lstr;

  rndsav = rndprc;
  rndprc = (((6 +3)-4)*16);
  lost = 0;
  nsign = 0;
  decflg = 0;
  sgnflg = 0;
  nexp = 0;
  exp = 0;
  prec = 0;
  ecleaz (yy);
  trail = 0;

 nxtcom:
  k = *s - '0';
  if ((k >= 0) && (k <= 9))
    {

      if ((prec == 0) && (decflg == 0) && (k == 0))
 goto donchr;

      if ((trail == 0) && (decflg != 0))
 {
   sp = s;
   while ((*sp >= '0') && (*sp <= '9'))
     ++sp;

   c = *sp & 0x7f;
   if ((c != 'e') && (c != 'E') && (c != '\0')
       && (c != '\n') && (c != '\r') && (c != ' ')
       && (c != ','))
     goto error;
   --sp;
   while (*sp == '0')
     *sp-- = 'z';
   trail = 1;
   if (*s == 'z')
     goto donchr;
 }






      if (yy[2] == 0)
 {
   if (decflg)
     nexp += 1;
   eshup1 (yy);
   emovz (yy, xt);
   eshup1 (xt);
   eshup1 (xt);
   eaddm (xt, yy);
   ecleaz (xt);
   xt[(6 +3) - 2] = (unsigned short) k;
   eaddm (xt, yy);
 }
      else
 {

   lost |= k;

   if (decflg == 0)
     nexp -= 1;
 }
      prec += 1;
      goto donchr;
    }

  switch (*s)
    {
    case 'z':
      break;
    case 'E':
    case 'e':
      goto expnt;
    case '.':
      if (decflg)
 goto error;
      ++decflg;
      break;
    case '-':
      nsign = 0xffff;
      if (sgnflg)
 goto error;
      ++sgnflg;
      break;
    case '+':
      if (sgnflg)
 goto error;
      ++sgnflg;
      break;
    case ',':
    case ' ':
    case '\0':
    case '\n':
    case '\r':
      goto daldone;
    case 'i':
    case 'I':
      goto infinite;
    default:
    error:

      einan (yy);




      goto aexit;
    }
 donchr:
  ++s;
  goto nxtcom;


 expnt:

  esign = 1;
  exp = 0;
  ++s;

  if (*s == '-')
    {
      esign = -1;
      ++s;
    }
  if (*s == '+')
    ++s;
  while ((*s >= '0') && (*s <= '9'))
    {
      exp *= 10;
      exp += *s++ - '0';
      if (exp > -(-4956))
 {
   if (esign < 0)
     goto zero;
   else
     goto infinite;
 }
    }
  if (esign < 0)
    exp = -exp;
  if (exp > 4932)
    {
 infinite:
      ecleaz (yy);
      yy[1] = 0x7fff;
      goto aexit;
    }
  if (exp < -4956)
    {
 zero:
      ecleaz (yy);
      goto aexit;
    }

 daldone:
  nexp = exp - nexp;

  while ((nexp > 0) && (yy[2] == 0))
    {
      emovz (yy, xt);
      eshup1 (xt);
      eshup1 (xt);
      eaddm (yy, xt);
      eshup1 (xt);
      if (xt[2] != 0)
 break;
      nexp -= 1;
      emovz (xt, yy);
    }
  if ((k = enormlz (yy)) > (((6 +3)-4)*16))
    {
      ecleaz (yy);
      goto aexit;
    }
  lexp = ((0x3fff) - 1 + (((6 +3)-4)*16)) - k;
  emdnorm (yy, lost, 0, lexp, 64);
  lexp = yy[1];
  if (nexp == 0)
    {
      k = 0;
      goto expdon;
    }
  esign = 1;
  if (nexp < 0)
    {
      nexp = -nexp;
      esign = -1;
      if (nexp > 4096)
 {

   emovi (etens[0], tt);
   lexp -= tt[1];
   k = edivm (tt, yy);
   lexp += (0x3fff);
   nexp -= 4096;
 }
    }
  p = &etens[12][0];
  emov (eone, xt);
  exp = 1;
  do
    {
      if (exp & nexp)
 emul (p, xt, xt);
      p -= 6;
      exp = exp + exp;
    }
  while (exp <= 4096);

  emovi (xt, tt);
  if (esign < 0)
    {
      lexp -= tt[1];
      k = edivm (tt, yy);
      lexp += (0x3fff);
    }
  else
    {
      lexp += tt[1];
      k = emulm (tt, yy);
      lexp -= (0x3fff) - 1;
    }

 expdon:


  if (oprec == 53)
    lexp -= (0x3fff) - 0x3ff;




  else if (oprec == 24)
    lexp -= (0x3fff) - 0177;





  rndprc = oprec;
  emdnorm (yy, k, 0, lexp, 64);

 aexit:

  rndprc = rndsav;
  yy[0] = nsign;
  switch (oprec)
    {
    case 53:
      toe53 (yy, y);
      break;
    case 24:
      toe24 (yy, y);
      break;
    case 64:
      toe64 (yy, y);
      break;
    case 113:
      toe113 (yy, y);
      break;
    case (((6 +3)-4)*16):
      emovo (yy, y);
      break;
    }
}






static unsigned short bmask[] =
{
  0xffff,
  0xfffe,
  0xfffc,
  0xfff8,
  0xfff0,
  0xffe0,
  0xffc0,
  0xff80,
  0xff00,
  0xfe00,
  0xfc00,
  0xf800,
  0xf000,
  0xe000,
  0xc000,
  0x8000,
  0x0000,
};

static void
efloor(short unsigned int *x, short unsigned int *y) asm("_efloor");
static void
efloor(short unsigned int *x, short unsigned int *y)
{
  register unsigned short *p;
  int e, expon, i;
  unsigned short f[6];

  emov (x, f);
  expon = (int) f[6 - 1];
  e = (expon & 0x7fff) - ((0x3fff) - 1);
  if (e <= 0)
    {
      eclear (y);
      goto isitneg;
    }

  e = (((6 +3)-4)*16) - e;
  emov (f, y);
  if (e <= 0)
    return;

  p = &y[0];
  while (e >= 16)
    {
      *p++ = 0;
      e -= 16;
    }

  *p &= bmask[e];

 isitneg:

  if ((unsigned short) expon & (unsigned short) 0x8000)
    {
      for (i = 0; i < 6 - 1; i++)
 {
   if (f[i] != y[i])
     {
       esub (eone, y, y);
       break;
     }
 }
    }
}





static void
efrexp(short unsigned int *x, int *exp, short unsigned int *s) asm("_efrexp");
static void
efrexp(short unsigned int *x, int *exp, short unsigned int *s)
{
  unsigned short xi[(6 +3)];
  int li;

  emovi (x, xi);

  li = (int) ((short) xi[1]);

  if (li == 0)
    {
      li -= enormlz (xi);
    }
  xi[1] = 0x3ffe;
  emovo (xi, s);
  *exp = (int) (li - 0x3ffe);
}



static void
eldexp(short unsigned int *x, int pwr2, short unsigned int *y) asm("_eldexp");
static void
eldexp(short unsigned int *x, int pwr2, short unsigned int *y)
{
  unsigned short xi[(6 +3)];
  int li;
  int i;

  emovi (x, xi);
  li = xi[1];
  li += pwr2;
  i = 0;
  emdnorm (xi, i, i, li, 64);
  emovo (xi, y);
}





static void
eremain(short unsigned int *a, short unsigned int *b, short unsigned int *c) asm("_eremain");
static void
eremain(short unsigned int *a, short unsigned int *b, short unsigned int *c)
{
  unsigned short den[(6 +3)], num[(6 +3)];


  if (eisinf (b)
      || (ecmp (a, ezero) == 0)
      || eisnan (a)
      || eisnan (b))
    {
      enan (c, 0);
      return;
    }

  if (ecmp (a, ezero) == 0)
    {
      mtherr ("eremain", 2);
      eclear (c);
      return;
    }
  emovi (a, den);
  emovi (b, num);
  eiremain (den, num);

  if (a[0] == b[0])
    num[0] = 0;
  else
    num[0] = 0xffff;
  emovo (num, c);
}




static void
eiremain(short unsigned int *den, short unsigned int *num) asm("_eiremain");
static void
eiremain(short unsigned int *den, short unsigned int *num)
{
  int ld, ln;
  unsigned short j;

  ld = den[1];
  ld -= enormlz (den);
  ln = num[1];
  ln -= enormlz (num);
  ecleaz (equot);
  while (ln >= ld)
    {
      if (ecmpm (den, num) <= 0)
 {
   esubm (den, num);
   j = 1;
 }
      else
   j = 0;
      eshup1 (equot);
      equot[(6 +3) - 1] |= j;
      eshup1 (num);
      ln -= 1;
    }
  emdnorm (num, 0, 0, ln, 0);
}
static char *ermsg[8] =
{
  "unknown",
  "domain",
  "singularity",
  "overflow",
  "underflow",
  "total loss of precision",
  "partial loss of precision",
  "invalid operation"
};

int merror = 0;
extern int merror;

static void
mtherr(char *name, int code) asm("_mtherr");
static void
mtherr(char *name, int code)
{
  char errstr[80];





  if ((code <= 0) || (code >= 8))
    code = 0;
  sprintf (errstr, " %s %s error", name, ermsg[code]);
  if (extra_warnings)
    warning (errstr);

  merror = code + 1;
}
unsigned short TFbignan[8] =
 {0x7fff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff};
unsigned short TFlittlenan[8] = {0, 0, 0, 0, 0, 0, 0x8000, 0xffff};







unsigned short XFbignan[6] =
 {0x7fff, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff};
unsigned short XFlittlenan[6] = {0, 0, 0, 0xc000, 0xffff, 0};







unsigned short DFbignan[4] = {0x7fff, 0xffff, 0xffff, 0xffff};
unsigned short DFlittlenan[4] = {0, 0, 0, 0xfff8};







unsigned short SFbignan[2] = {0x7fff, 0xffff};
unsigned short SFlittlenan[2] = {0, 0xffc0};




static void
make_nan(short unsigned int *nan, int sign, n64_enum_machine_mode mode) asm("_make_nan");
static void
make_nan(short unsigned int *nan, int sign, n64_enum_machine_mode mode)
{
  int n;
  unsigned short *p;

  switch (mode)
    {



    case TFmode:
      n = 8;
      if (((target_flags & 0x00010000) != 0))
 p = TFbignan;
      else
 p = TFlittlenan;
      break;
    case XFmode:
      n = 6;
      if (((target_flags & 0x00010000) != 0))
 p = XFbignan;
      else
 p = XFlittlenan;
      break;
    case DFmode:
      n = 4;
      if (((target_flags & 0x00010000) != 0))
 p = DFbignan;
      else
 p = DFlittlenan;
      break;
    case HFmode:
    case SFmode:
      n = 2;
      if (((target_flags & 0x00010000) != 0))
 p = SFbignan;
      else
 p = SFlittlenan;
      break;

    default:
      abort ();
    }
  if (((target_flags & 0x00010000) != 0))
    *nan++ = (sign << 15) | *p++;
  while (--n != 0)
    *nan++ = *p++;
  if (! ((target_flags & 0x00010000) != 0))
    *nan = (sign << 15) | *p;
}





double
ereal_from_float(int f) asm("_ereal_from_float");
double
ereal_from_float(int f)
{
  double r;
  unsigned short s[2];
  unsigned short e[6];



  if (((target_flags & 0x00010000) != 0))
    {
      s[0] = (unsigned short) (f >> 16);
      s[1] = (unsigned short) f;
    }
  else
    {
      s[0] = (unsigned short) f;
      s[1] = (unsigned short) (f >> 16);
    }

  e24toe (s, e);

  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((e), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((e), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return r;
}
double
ereal_from_double(int *d) asm("_ereal_from_double");
double
ereal_from_double(int *d)
{
  double r;
  unsigned short s[4];
  unsigned short e[6];


  if (((target_flags & 0x00010000) != 0))
    {
      s[0] = (unsigned short) (d[0] >> 16);
      s[1] = (unsigned short) d[0];

      s[2] = (unsigned short) (d[1] >> 16);
      s[3] = (unsigned short) d[1];







    }
  else
    {

      s[0] = (unsigned short) d[0];
      s[1] = (unsigned short) (d[0] >> 16);

      s[2] = (unsigned short) d[1];
      s[3] = (unsigned short) (d[1] >> 16);




    }

  e53toe (s, e);

  do { if (0 == ((target_flags & 0x00010000) != 0)) etoe53 ((e), (unsigned short *) (&r)); else { unsigned short w[4]; etoe53 ((e), w); *((short *) &r) = w[3]; *((short *) &r + 1) = w[2]; *((short *) &r + 2) = w[1]; *((short *) &r + 3) = w[0]; } } while (0);
  return r;
}






static void
uditoe(short unsigned int *di, short unsigned int *e) asm("_uditoe");
static void
uditoe(short unsigned int *di, short unsigned int *e)
{
  unsigned short yi[(6 +3)];
  int k;

  ecleaz (yi);
  if (((target_flags & 0x00010000) != 0))
    {
      for (k = 2; k < 2 + 4; k++)
 yi[k] = *di++;
    }
  else
    {
      for (k = 2 + 3; k >= 2; k--)
 yi[k] = *di++;
    }
  yi[1] = (0x3fff) + 47;
  if ((k = enormlz (yi)) > (((6 +3)-4)*16))
    ecleaz (yi);
  else
    yi[1] -= (unsigned short) k;
  emovo (yi, e);
}



static void
ditoe(short unsigned int *di, short unsigned int *e) asm("_ditoe");
static void
ditoe(short unsigned int *di, short unsigned int *e)
{
  unsigned int acc;
  unsigned short yi[(6 +3)];
  unsigned short carry;
  int k, sign;

  ecleaz (yi);
  if (((target_flags & 0x00010000) != 0))
    {
      for (k = 2; k < 2 + 4; k++)
 yi[k] = *di++;
    }
  else
    {
      for (k = 2 + 3; k >= 2; k--)
 yi[k] = *di++;
    }

  sign = 0;
  if (yi[2] & 0x8000)
    {
      sign = 1;
      carry = 0;
      for (k = 2 + 3; k >= 2; k--)
 {
   acc = (unsigned int) (~yi[k] & 0xffff) + carry;
   yi[k] = acc;
   carry = 0;
   if (acc & 0x10000)
     carry = 1;
 }
    }
  yi[1] = (0x3fff) + 47;
  if ((k = enormlz (yi)) > (((6 +3)-4)*16))
    ecleaz (yi);
  else
    yi[1] -= (unsigned short) k;
  emovo (yi, e);
  if (sign)
 eneg (e);
}




static void
etoudi(short unsigned int *x, short unsigned int *i) asm("_etoudi");
static void
etoudi(short unsigned int *x, short unsigned int *i)
{
  unsigned short xi[(6 +3)];
  int j, k;

  emovi (x, xi);
  if (xi[0])
    {
      xi[2] = 0;
      goto noshift;
    }
  k = (int) xi[1] - ((0x3fff) - 1);
  if (k <= 0)
    {
      for (j = 0; j < 4; j++)
 *i++ = 0;
      return;
    }
  if (k > 64)
    {
      for (j = 0; j < 4; j++)
 *i++ = 0xffff;
      if (extra_warnings)
 warning ("overflow on truncation to integer");
      return;
    }
  if (k > 16)
    {


      j = k - ((k >> 4) << 4);
      if (j == 0)
 j = 16;
      eshift (xi, j);
      if (((target_flags & 0x00010000) != 0))
 *i++ = xi[2];
      else
 {
   i += 3;
   *i-- = xi[2];
 }
      k -= j;
      do
 {
   eshup6 (xi);
   if (((target_flags & 0x00010000) != 0))
     *i++ = xi[2];
   else
     *i-- = xi[2];
 }
      while ((k -= 16) > 0);
    }
  else
    {

      eshift (xi, k);

noshift:

      if (((target_flags & 0x00010000) != 0))
 {
   i += 3;
   *i-- = xi[2];
   *i-- = 0;
   *i-- = 0;
   *i = 0;
 }
      else
 {
   *i++ = xi[2];
   *i++ = 0;
   *i++ = 0;
   *i = 0;
 }
    }
}




static void
etodi(short unsigned int *x, short unsigned int *i) asm("_etodi");
static void
etodi(short unsigned int *x, short unsigned int *i)
{
  unsigned int acc;
  unsigned short xi[(6 +3)];
  unsigned short carry;
  unsigned short *isave;
  int j, k;

  emovi (x, xi);
  k = (int) xi[1] - ((0x3fff) - 1);
  if (k <= 0)
    {
      for (j = 0; j < 4; j++)
 *i++ = 0;
      return;
    }
  if (k > 64)
    {
      for (j = 0; j < 4; j++)
 *i++ = 0xffff;
      if (extra_warnings)
 warning ("overflow on truncation to integer");
      return;
    }
  isave = i;
  if (k > 16)
    {


      j = k - ((k >> 4) << 4);
      if (j == 0)
 j = 16;
      eshift (xi, j);
      if (((target_flags & 0x00010000) != 0))
 *i++ = xi[2];
      else
 {
   i += 3;
   *i-- = xi[2];
 }
      k -= j;
      do
 {
   eshup6 (xi);
   if (((target_flags & 0x00010000) != 0))
     *i++ = xi[2];
   else
     *i-- = xi[2];
 }
      while ((k -= 16) > 0);
    }
  else
    {

      eshift (xi, k);

      if (((target_flags & 0x00010000) != 0))
 {
   i += 3;
   *i = xi[2];
   *i-- = 0;
   *i-- = 0;
   *i = 0;
 }
      else
 {
   *i++ = xi[2];
   *i++ = 0;
   *i++ = 0;
   *i = 0;
 }
    }

  if (xi[0])
    {
      carry = 0;
      if (((target_flags & 0x00010000) != 0))
 isave += 3;
      for (k = 0; k < 4; k++)
 {
   acc = (unsigned int) (~(*isave) & 0xffff) + carry;
   if (((target_flags & 0x00010000) != 0))
     *isave-- = acc;
   else
     *isave++ = acc;
   carry = 0;
   if (acc & 0x10000)
     carry = 1;
 }
    }
}





static int esqinited = 0;
static unsigned short sqrndbit[(6 +3)];

static void
esqrt(short unsigned int *x, short unsigned int *y) asm("_esqrt");
static void
esqrt(short unsigned int *x, short unsigned int *y)
{
  unsigned short temp[(6 +3)], num[(6 +3)], sq[(6 +3)], xx[(6 +3)];
  int m, exp;
  int i, j, k, n, nlups;

  if (esqinited == 0)
    {
      ecleaz (sqrndbit);
      sqrndbit[(6 +3) - 2] = 1;
      esqinited = 1;
    }

  i = ecmp (x, ezero);
  if (i <= 0)
    {
      if (i == -1)
 {
   mtherr ("esqrt", 1);
   eclear (y);
 }
      else
 emov (x, y);
      return;
    }


  if (eisinf (x))
    {
      eclear (y);
      einfin (y);
      return;
    }


  emovi (x, xx);
  m = (int) xx[1];
  if (m == 0)
    m -= enormlz (xx);


  m -= 0x3ffe;
  exp = (unsigned short) ((m / 2) + 0x3ffe);


  if ((m & 1) != 0)
    {
      if (m > 0)
 exp += 1;
      eshdn1 (xx);
    }

  ecleaz (sq);
  ecleaz (num);
  n = 8;
  nlups = rndprc;
  j = 0;

  while (nlups > 0)
    {

      if (j < 6)
 num[(6 +3) - 1] = xx[j + 3];

      if (nlups <= 8)
 n = nlups + 1;
      for (i = 0; i < n; i++)
 {

   eshup1 (num);
   eshup1 (num);

   eshup1 (sq);

   for (k = 0; k < (6 +3); k++)
     temp[k] = sq[k];
   eshup1 (temp);
   eaddm (sqrndbit, temp);

   if (ecmpm (temp, num) <= 0)
     {
       esubm (temp, num);
       sq[(6 +3) - 2] |= 1;
     }
 }
      nlups -= n;
      j += 1;
    }


  exp += ((((6 +3)-4)*16) - 1) - rndprc;


  k = 0;
  for (i = 3; i < (6 +3); i++)
    k |= (int) num[i];


  emdnorm (sq, k, 0, exp, 64);
  emovo (sq, y);
}






int
significand_size(n64_enum_machine_mode mode) asm("_significand_size");
int
significand_size(n64_enum_machine_mode mode)
{

switch (mode)
  {
  case SFmode:
    return 24;

  case DFmode:

    return 53;
  case XFmode:
    return 64;
  case TFmode:
    return 113;

  default:
    abort ();
  }
}

