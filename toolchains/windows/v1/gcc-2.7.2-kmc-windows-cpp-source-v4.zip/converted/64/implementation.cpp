// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;




extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];


extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

static char *
output_5(rtx *operands, rtx insn) asm("_output_5");
static char *
output_5(rtx *operands, rtx insn)
{

{
  return (((operands[0])->fld[0].rtint) == ((operands[1])->fld[0].rtint)
   && ((operands[0])->fld[0].rtint) == ((operands[2])->fld[0].rtint))
    ? "srl\t%3,%L0,31\n\tsll\t%M0,%M0,1\n\tsll\t%L0,%L1,1\n\taddu\t%M0,%M0,%3"
    : "addu\t%L0,%L1,%L2\n\tsltu\t%3,%L0,%L2\n\taddu\t%M0,%M1,%M2\n\taddu\t%M0,%M0,%3";
}
}

static char *
output_8(rtx *operands, rtx insn) asm("_output_8");
static char *
output_8(rtx *operands, rtx insn)
{
  static char *const strings_8[] = {
    "addu\t%L0,%L1,%2\n\tsltu\t%3,%L0,%2\n\taddu\t%M0,%M1,%3",
    "move\t%L0,%L1\n\tmove\t%M0,%M1",
    "subu\t%L0,%L1,%n2\n\tsltu\t%3,%L0,%2\n\tsubu\t%M0,%M1,1\n\taddu\t%M0,%M0,%3",
  };
  return strings_8[which_alternative];
}

static char *
output_11(rtx *operands, rtx insn) asm("_output_11");
static char *
output_11(rtx *operands, rtx insn)
{

{
  return (((operands[2])->code) == CONST_INT && ((operands[2])->fld[0].rtwint) < 0)
    ? "dsubu\t%0,%z1,%n2"
    : "daddu\t%0,%z1,%2";
}
}

static char *
output_12(rtx *operands, rtx insn) asm("_output_12");
static char *
output_12(rtx *operands, rtx insn)
{

{
  return (((operands[2])->code) == CONST_INT && ((operands[2])->fld[0].rtwint) < 0)
    ? "subu\t%0,%z1,%n2"
    : "addu\t%0,%z1,%2";
}
}

static char *
output_21(rtx *operands, rtx insn) asm("_output_21");
static char *
output_21(rtx *operands, rtx insn)
{
  static char *const strings_21[] = {
    "sltu\t%3,%L1,%2\n\tsubu\t%L0,%L1,%2\n\tsubu\t%M0,%M1,%3",
    "move\t%L0,%L1\n\tmove\t%M0,%M1",
    "sltu\t%3,%L1,%2\n\tsubu\t%L0,%L1,%2\n\tsubu\t%M0,%M1,1\n\tsubu\t%M0,%M0,%3",
  };
  return strings_21[which_alternative];
}

static char *
output_24(rtx *operands, rtx insn) asm("_output_24");
static char *
output_24(rtx *operands, rtx insn)
{

{
  return (((operands[2])->code) == CONST_INT && ((operands[2])->fld[0].rtwint) < 0)
    ? "daddu\t%0,%z1,%n2"
    : "dsubu\t%0,%z1,%2";
}
}

static char *
output_25(rtx *operands, rtx insn) asm("_output_25");
static char *
output_25(rtx *operands, rtx insn)
{

{
  return (((operands[2])->code) == CONST_INT && ((operands[2])->fld[0].rtwint) < 0)
    ? "addu\t%0,%z1,%n2"
    : "subu\t%0,%z1,%2";
}
}

static char *
output_30(rtx *operands, rtx insn) asm("_output_30");
static char *
output_30(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  xoperands[0] = operands[0];
  xoperands[1] = gen_rtx (REG, SImode, (64 + 1));

  output_asm_insn ("mult\t%1,%2", operands);
  output_asm_insn (mips_move_1word (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_34(rtx *operands, rtx insn) asm("_output_34");
static char *
output_34(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  xoperands[0] = operands[0];
  xoperands[1] = gen_rtx (REG, DImode, (64 + 1));

  output_asm_insn ("dmult\t%1,%2", operands);
  output_asm_insn (mips_move_1word (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_60(rtx *operands, rtx insn) asm("_output_60");
static char *
output_60(rtx *operands, rtx insn)
{

{
  if (find_reg_note (insn, REG_UNUSED, operands[3]))
    return "div\t%0,%1,%2";

  if (find_reg_note (insn, REG_UNUSED, operands[0]))
    return "rem\t%3,%1,%2";

  return "div\t%0,%1,%2\n\tmfhi\t%3";
}
}

static char *
output_61(rtx *operands, rtx insn) asm("_output_61");
static char *
output_61(rtx *operands, rtx insn)
{

{
  if (find_reg_note (insn, REG_UNUSED, operands[3]))
    return "ddiv\t%0,%1,%2";

  if (find_reg_note (insn, REG_UNUSED, operands[0]))
    return "drem\t%3,%1,%2";

  return "ddiv\t%0,%1,%2\n\tmfhi\t%3";
}
}

static char *
output_62(rtx *operands, rtx insn) asm("_output_62");
static char *
output_62(rtx *operands, rtx insn)
{

{
  if (find_reg_note (insn, REG_UNUSED, operands[3]))
    return "divu\t%0,%1,%2";

  if (find_reg_note (insn, REG_UNUSED, operands[0]))
    return "remu\t%3,%1,%2";

  return "divu\t%0,%1,%2\n\tmfhi\t%3";
}
}

static char *
output_63(rtx *operands, rtx insn) asm("_output_63");
static char *
output_63(rtx *operands, rtx insn)
{

{
  if (find_reg_note (insn, REG_UNUSED, operands[3]))
    return "ddivu\t%0,%1,%2";

  if (find_reg_note (insn, REG_UNUSED, operands[0]))
    return "dremu\t%3,%1,%2";

  return "ddivu\t%0,%1,%2\n\tmfhi\t%3";
}
}

static char *
output_74(rtx *operands, rtx insn) asm("_output_74");
static char *
output_74(rtx *operands, rtx insn)
{

{
  dslots_jump_total++;
  dslots_jump_filled++;
  operands[2] = const0_rtx;

  if (((operands[0])->fld[0].rtint) == ((operands[1])->fld[0].rtint))
    {
      if (mips_isa >= 2)
 return "%(bltzl\t%1,1f\n\tsubu\t%0,%z2,%0\n1:%)";
      else
 return "bgez\t%1,1f%#\n\tsubu\t%0,%z2,%0\n1:";
    }
  else
    return "%(bgez\t%1,1f\n\tmove\t%0,%1\n\tsubu\t%0,%z2,%0\n1:%)";
}
}

static char *
output_75(rtx *operands, rtx insn) asm("_output_75");
static char *
output_75(rtx *operands, rtx insn)
{

{
  dslots_jump_total++;
  dslots_jump_filled++;
  operands[2] = const0_rtx;

  if (((operands[0])->fld[0].rtint) == ((operands[1])->fld[0].rtint))
    return "%(bltzl\t%1,1f\n\tdsubu\t%0,%z2,%0\n1:%)";
  else
    return "%(bgez\t%1,1f\n\tmove\t%0,%1\n\tdsubu\t%0,%z2,%0\n1:%)";
}
}

static char *
output_78(rtx *operands, rtx insn) asm("_output_78");
static char *
output_78(rtx *operands, rtx insn)
{

{
  dslots_jump_total += 2;
  dslots_jump_filled += 2;
  operands[4] = const0_rtx;

  if (optimize && find_reg_note (insn, REG_DEAD, operands[1]))
    return "%(move\t%0,%z4\n\tbeq\t%1,%z4,2f\n1:\tand\t%2,%1,0x0001\n\taddu\t%0,%0,1\n\tbeq\t%2,%z4,1b\n\tsrl\t%1,%1,1\n2:%)";
  return "%(move\t%0,%z4\n\tmove\t%3,%1\n\tbeq\t%3,%z4,2f\n1:\tand\t%2,%3,0x0001\n\taddu\t%0,%0,1\n\tbeq\t%2,%z4,1b\n\tsrl\t%3,%3,1\n2:%)";
}
}

static char *
output_79(rtx *operands, rtx insn) asm("_output_79");
static char *
output_79(rtx *operands, rtx insn)
{

{
  dslots_jump_total += 2;
  dslots_jump_filled += 2;
  operands[4] = const0_rtx;

  if (optimize && find_reg_note (insn, REG_DEAD, operands[1]))
    return "%(move\t%0,%z4\n\tbeq\t%1,%z4,2f\n1:\tand\t%2,%1,0x0001\n\tdaddu\t%0,%0,1\n\tbeq\t%2,%z4,1b\n\tdsrl\t%1,%1,1\n2:%)";
  return "%(move\t%0,%z4\n\tmove\t%3,%1\n\tbeq\t%3,%z4,2f\n1:\tand\t%2,%3,0x0001\n\tdaddu\t%0,%0,1\n\tbeq\t%2,%z4,1b\n\tdsrl\t%3,%3,1\n2:%)";
}
}

static char *
output_80(rtx *operands, rtx insn) asm("_output_80");
static char *
output_80(rtx *operands, rtx insn)
{

{
  operands[2] = const0_rtx;
  return "subu\t%0,%z2,%1";
}
}

static char *
output_82(rtx *operands, rtx insn) asm("_output_82");
static char *
output_82(rtx *operands, rtx insn)
{

{
  operands[3] = const0_rtx;
  return "subu\t%L0,%z3,%L1\n\tsubu\t%M0,%z3,%M1\n\tsltu\t%2,%z3,%L0\n\tsubu\t%M0,%M0,%2";
}
}

static char *
output_83(rtx *operands, rtx insn) asm("_output_83");
static char *
output_83(rtx *operands, rtx insn)
{

{
  operands[2] = const0_rtx;
  return "dsubu\t%0,%z2,%1";
}
}

static char *
output_86(rtx *operands, rtx insn) asm("_output_86");
static char *
output_86(rtx *operands, rtx insn)
{

{
  operands[2] = const0_rtx;
  return "nor\t%0,%z2,%1";
}
}

static char *
output_87(rtx *operands, rtx insn) asm("_output_87");
static char *
output_87(rtx *operands, rtx insn)
{

{
  operands[2] = const0_rtx;
  if ((target_flags & 0x00002000))
    return "nor\t%0,%z2,%1";
  return "nor\t%M0,%z2,%M1\n\tnor\t%L0,%z2,%L1";
}
}

static char *
output_90(rtx *operands, rtx insn) asm("_output_90");
static char *
output_90(rtx *operands, rtx insn)
{

{
  if ((target_flags & 0x00002000))
    return "nor\t%0,%z1,%z2";
  return "nor\t%M0,%M1,%M2\n\tnor\t%L0,%L1,%L2";
}
}

static char *
output_92(rtx *operands, rtx insn) asm("_output_92");
static char *
output_92(rtx *operands, rtx insn)
{
  static char *const strings_92[] = {
    "and\t%0,%1,%2",
    "andi\t%0,%1,%x2",
  };
  return strings_92[which_alternative];
}

static char *
output_93(rtx *operands, rtx insn) asm("_output_93");
static char *
output_93(rtx *operands, rtx insn)
{

{
  if ((target_flags & 0x00002000))
    return "and\t%0,%1,%2";
  return "and\t%M0,%M1,%M2\n\tand\t%L0,%L1,%L2";
}
}

static char *
output_95(rtx *operands, rtx insn) asm("_output_95");
static char *
output_95(rtx *operands, rtx insn)
{
  static char *const strings_95[] = {
    "and\t%0,%1,%2",
    "andi\t%0,%1,%x2",
  };
  return strings_95[which_alternative];
}

static char *
output_96(rtx *operands, rtx insn) asm("_output_96");
static char *
output_96(rtx *operands, rtx insn)
{
  static char *const strings_96[] = {
    "or\t%0,%1,%2",
    "ori\t%0,%1,%x2",
  };
  return strings_96[which_alternative];
}

static char *
output_97(rtx *operands, rtx insn) asm("_output_97");
static char *
output_97(rtx *operands, rtx insn)
{

{
  if ((target_flags & 0x00002000))
    return "or\t%0,%1,%2";
  return "or\t%M0,%M1,%M2\n\tor\t%L0,%L1,%L2";
}
}

static char *
output_99(rtx *operands, rtx insn) asm("_output_99");
static char *
output_99(rtx *operands, rtx insn)
{
  static char *const strings_99[] = {
    "xor\t%0,%1,%2",
    "xori\t%0,%1,%x2",
  };
  return strings_99[which_alternative];
}

static char *
output_100(rtx *operands, rtx insn) asm("_output_100");
static char *
output_100(rtx *operands, rtx insn)
{

{
  if ((target_flags & 0x00002000))
    return "xor\t%0,%1,%2";
  return "xor\t%M0,%M1,%M2\n\txor\t%L0,%L1,%L2";
}
}

static char *
output_107(rtx *operands, rtx insn) asm("_output_107");
static char *
output_107(rtx *operands, rtx insn)
{

{
  int shift_amt = ((operands[2])->fld[0].rtwint) & 0x3f;

  if (shift_amt < 32)
    {
      operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (32 - shift_amt));
      return "dsll\t%0,%1,%2\n\tdsra\t%0,%0,32";
    }
  else
    {
      operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (shift_amt));
      return "dsra\t%0,%1,%2";
    }
}
}

static char *
output_108(rtx *operands, rtx insn) asm("_output_108");
static char *
output_108(rtx *operands, rtx insn)
{

{
  int shift_amt = ((operands[2])->fld[0].rtwint) & 0x3f;

  if (shift_amt < 32)
    {
      operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (32 - shift_amt));
      return "dsll\t%0,%1,%2\n\tdsra\t%0,%0,32";
    }
  else if (shift_amt == 32)
    return "dsra\t%0,%1,32";
  else
    {
      operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (shift_amt));
      return "dsrl\t%0,%1,%2";
    }
}
}

static char *
output_109(rtx *operands, rtx insn) asm("_output_109");
static char *
output_109(rtx *operands, rtx insn)
{

{
  int shift_amt = ((operands[2])->fld[0].rtwint) & 0x3f;

  if (shift_amt < 32)
    {
      operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (32 + shift_amt));
      return "dsll\t%0,%1,%2\n\tdsra\t%0,%0,32";
    }
  else
    return "move\t%0,%.";
}
}

static char *
output_114(rtx *operands, rtx insn) asm("_output_114");
static char *
output_114(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 1);
}

static char *
output_115(rtx *operands, rtx insn) asm("_output_115");
static char *
output_115(rtx *operands, rtx insn)
{

{
  if (which_alternative == 0)
    return "andi\t%0,%1,0xffff";
  else
    return mips_move_1word (operands, insn, 1);
}
}

static char *
output_116(rtx *operands, rtx insn) asm("_output_116");
static char *
output_116(rtx *operands, rtx insn)
{

{
  if (which_alternative == 0)
    return "andi\t%0,%1,0xffff";
  else
    return mips_move_1word (operands, insn, 1);
}
}

static char *
output_117(rtx *operands, rtx insn) asm("_output_117");
static char *
output_117(rtx *operands, rtx insn)
{

{
  if (which_alternative == 0)
    return "andi\t%0,%1,0x00ff";
  else
    return mips_move_1word (operands, insn, 1);
}
}

static char *
output_118(rtx *operands, rtx insn) asm("_output_118");
static char *
output_118(rtx *operands, rtx insn)
{

{
  if (which_alternative == 0)
    return "andi\t%0,%1,0x00ff";
  else
    return mips_move_1word (operands, insn, 1);
}
}

static char *
output_119(rtx *operands, rtx insn) asm("_output_119");
static char *
output_119(rtx *operands, rtx insn)
{

{
  if (which_alternative == 0)
    return "andi\t%0,%1,0x00ff";
  else
    return mips_move_1word (operands, insn, 1);
}
}

static char *
output_121(rtx *operands, rtx insn) asm("_output_121");
static char *
output_121(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_123(rtx *operands, rtx insn) asm("_output_123");
static char *
output_123(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_125(rtx *operands, rtx insn) asm("_output_125");
static char *
output_125(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_127(rtx *operands, rtx insn) asm("_output_127");
static char *
output_127(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_129(rtx *operands, rtx insn) asm("_output_129");
static char *
output_129(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_131(rtx *operands, rtx insn) asm("_output_131");
static char *
output_131(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_133(rtx *operands, rtx insn) asm("_output_133");
static char *
output_133(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  if (which_alternative == 1)
    return "trunc.w.d %0,%1,%2";

  output_asm_insn ("trunc.w.d %3,%1,%2", operands);

  xoperands[0] = operands[0];
  xoperands[1] = operands[3];
  output_asm_insn (mips_move_1word (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_134(rtx *operands, rtx insn) asm("_output_134");
static char *
output_134(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  if (which_alternative == 1)
    return "trunc.w.s %0,%1,%2";

  output_asm_insn ("trunc.w.s %3,%1,%2", operands);

  xoperands[0] = operands[0];
  xoperands[1] = operands[3];
  output_asm_insn (mips_move_1word (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_135(rtx *operands, rtx insn) asm("_output_135");
static char *
output_135(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  if (which_alternative == 1)
    return "trunc.l.d %0,%1";

  output_asm_insn ("trunc.l.d %2,%1", operands);

  xoperands[0] = operands[0];
  xoperands[1] = operands[2];
  output_asm_insn (mips_move_2words (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_136(rtx *operands, rtx insn) asm("_output_136");
static char *
output_136(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];

  if (which_alternative == 1)
    return "trunc.l.s %0,%1";

  output_asm_insn ("trunc.l.s %2,%1", operands);

  xoperands[0] = operands[0];
  xoperands[1] = operands[2];
  output_asm_insn (mips_move_2words (xoperands, insn, 0), xoperands);
  return "";
}
}

static char *
output_137(rtx *operands, rtx insn) asm("_output_137");
static char *
output_137(rtx *operands, rtx insn)
{

{
  dslots_load_total++;
  if (((operands[1])->code) == MEM)
    return "l.s\t%0,%1%#\n\tcvt.d.w\t%0,%0";

  return "mtc1\t%1,%0%#\n\tcvt.d.w\t%0,%0";
}
}

static char *
output_138(rtx *operands, rtx insn) asm("_output_138");
static char *
output_138(rtx *operands, rtx insn)
{

{
  dslots_load_total++;
  if (((operands[1])->code) == MEM)
    return "l.d\t%0,%1%#\n\tcvt.d.l\t%0,%0";

  return "dmtc1\t%1,%0%#\n\tcvt.d.l\t%0,%0";
}
}

static char *
output_139(rtx *operands, rtx insn) asm("_output_139");
static char *
output_139(rtx *operands, rtx insn)
{

{
  dslots_load_total++;
  if (((operands[1])->code) == MEM)
    return "l.s\t%0,%1%#\n\tcvt.s.w\t%0,%0";

  return "mtc1\t%1,%0%#\n\tcvt.s.w\t%0,%0";
}
}

static char *
output_140(rtx *operands, rtx insn) asm("_output_140");
static char *
output_140(rtx *operands, rtx insn)
{

{
  dslots_load_total++;
  if (((operands[1])->code) == MEM)
    return "l.d\t%0,%1%#\n\tcvt.s.l\t%0,%0";

  return "dmtc1\t%1,%0%#\n\tcvt.s.l\t%0,%0";
}
}

static char *
output_148(rtx *operands, rtx insn) asm("_output_148");
static char *
output_148(rtx *operands, rtx insn)
{

{
  rtx offset = const0_rtx;
  rtx addr = ((operands[1])->fld[0].rtx);
  rtx mem_addr = eliminate_constant_term (addr, &offset);
  char *ret;

  if ((target_flags & 0x00000040))
    mips_count_memory_refs (operands[1], 2);




  if ((((offset)->fld[0].rtwint) & 3) == 0
      && (mem_addr == stack_pointer_rtx || mem_addr == frame_pointer_rtx))
    ret = "lw\t%0,%1";
  else
    ret = "ulw\t%0,%1";

  return mips_fill_delay_slot (ret, DELAY_LOAD, operands, insn);
}
}

static char *
output_149(rtx *operands, rtx insn) asm("_output_149");
static char *
output_149(rtx *operands, rtx insn)
{

{
  rtx offset = const0_rtx;
  rtx addr = ((operands[0])->fld[0].rtx);
  rtx mem_addr = eliminate_constant_term (addr, &offset);

  if ((target_flags & 0x00000040))
    mips_count_memory_refs (operands[0], 2);




  if ((((offset)->fld[0].rtwint) & 3) == 0
      && (mem_addr == stack_pointer_rtx || mem_addr == frame_pointer_rtx))
    return "sw\t%1,%0";

  return "usw\t%z1,%0";
}
}

static char *
output_151(rtx *operands, rtx insn) asm("_output_151");
static char *
output_151(rtx *operands, rtx insn)
{
 return mips_move_2words (operands, insn);
}

static char *
output_153(rtx *operands, rtx insn) asm("_output_153");
static char *
output_153(rtx *operands, rtx insn)
{
 return mips_move_2words (operands, insn);
}

static char *
output_158(rtx *operands, rtx insn) asm("_output_158");
static char *
output_158(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_159(rtx *operands, rtx insn) asm("_output_159");
static char *
output_159(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_162(rtx *operands, rtx insn) asm("_output_162");
static char *
output_162(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 1);
}

static char *
output_163(rtx *operands, rtx insn) asm("_output_163");
static char *
output_163(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 1);
}

static char *
output_165(rtx *operands, rtx insn) asm("_output_165");
static char *
output_165(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 1);
}

static char *
output_166(rtx *operands, rtx insn) asm("_output_166");
static char *
output_166(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 1);
}

static char *
output_168(rtx *operands, rtx insn) asm("_output_168");
static char *
output_168(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_169(rtx *operands, rtx insn) asm("_output_169");
static char *
output_169(rtx *operands, rtx insn)
{
 return mips_move_1word (operands, insn, 0);
}

static char *
output_171(rtx *operands, rtx insn) asm("_output_171");
static char *
output_171(rtx *operands, rtx insn)
{
 return mips_move_2words (operands, insn);
}

static char *
output_172(rtx *operands, rtx insn) asm("_output_172");
static char *
output_172(rtx *operands, rtx insn)
{
 return mips_move_2words (operands, insn);
}

static char *
output_173(rtx *operands, rtx insn) asm("_output_173");
static char *
output_173(rtx *operands, rtx insn)
{
 return mips_move_2words (operands, insn);
}

static char *
output_177(rtx *operands, rtx insn) asm("_output_177");
static char *
output_177(rtx *operands, rtx insn)
{
 return output_block_move (insn, operands, 4, BLOCK_MOVE_NORMAL);
}

static char *
output_179(rtx *operands, rtx insn) asm("_output_179");
static char *
output_179(rtx *operands, rtx insn)
{
 return output_block_move (insn, operands, 4, BLOCK_MOVE_NOT_LAST);
}

static char *
output_180(rtx *operands, rtx insn) asm("_output_180");
static char *
output_180(rtx *operands, rtx insn)
{
 return output_block_move (insn, operands, 4, BLOCK_MOVE_LAST);
}

static char *
output_181(rtx *operands, rtx insn) asm("_output_181");
static char *
output_181(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);

  return "sll\t%0,%1,%2";
}
}

static char *
output_183(rtx *operands, rtx insn) asm("_output_183");
static char *
output_183(rtx *operands, rtx insn)
{

{
  operands[4] = const0_rtx;
  dslots_jump_total += 3;
  dslots_jump_filled += 2;

  return "sll\t%3,%2,26\n\tbgez\t%3,1f\n\tsll\t%M0,%L1,%2\n\t%(b\t3f\n\tmove\t%L0,%z4%)\n\n1:\n\t%(beq\t%3,%z4,2f\n\tsll\t%M0,%M1,%2%)\n\n\tsubu\t%3,%z4,%2\n\tsrl\t%3,%L1,%3\n\tor\t%M0,%M0,%3\n2:\n\tsll\t%L0,%L1,%2\n3:";
}
}

static char *
output_184(rtx *operands, rtx insn) asm("_output_184");
static char *
output_184(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);
  operands[4] = const0_rtx;
  return "sll\t%M0,%L1,%2\n\tmove\t%L0,%z4";
}
}

static char *
output_187(rtx *operands, rtx insn) asm("_output_187");
static char *
output_187(rtx *operands, rtx insn)
{

{
  int amount = ((operands[2])->fld[0].rtwint);

  operands[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  operands[4] = const0_rtx;
  operands[5] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));

  return "sll\t%M0,%M1,%2\n\tsrl\t%3,%L1,%5\n\tor\t%M0,%M0,%3\n\tsll\t%L0,%L1,%2";
}
}

static char *
output_190(rtx *operands, rtx insn) asm("_output_190");
static char *
output_190(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (((operands[2])->fld[0].rtwint) & 0x3f));

  return "dsll\t%0,%1,%2";
}
}

static char *
output_191(rtx *operands, rtx insn) asm("_output_191");
static char *
output_191(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);

  return "sra\t%0,%1,%2";
}
}

static char *
output_193(rtx *operands, rtx insn) asm("_output_193");
static char *
output_193(rtx *operands, rtx insn)
{

{
  operands[4] = const0_rtx;
  dslots_jump_total += 3;
  dslots_jump_filled += 2;

  return "sll\t%3,%2,26\n\tbgez\t%3,1f\n\tsra\t%L0,%M1,%2\n\t%(b\t3f\n\tsra\t%M0,%M1,31%)\n\n1:\n\t%(beq\t%3,%z4,2f\n\tsrl\t%L0,%L1,%2%)\n\n\tsubu\t%3,%z4,%2\n\tsll\t%3,%M1,%3\n\tor\t%L0,%L0,%3\n2:\n\tsra\t%M0,%M1,%2\n3:";
}
}

static char *
output_194(rtx *operands, rtx insn) asm("_output_194");
static char *
output_194(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);
  return "sra\t%L0,%M1,%2\n\tsra\t%M0,%M1,31";
}
}

static char *
output_197(rtx *operands, rtx insn) asm("_output_197");
static char *
output_197(rtx *operands, rtx insn)
{

{
  int amount = ((operands[2])->fld[0].rtwint);

  operands[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  operands[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));

  return "srl\t%L0,%L1,%2\n\tsll\t%3,%M1,%4\n\tor\t%L0,%L0,%3\n\tsra\t%M0,%M1,%2";
}
}

static char *
output_200(rtx *operands, rtx insn) asm("_output_200");
static char *
output_200(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (((operands[2])->fld[0].rtwint) & 0x3f));

  return "dsra\t%0,%1,%2";
}
}

static char *
output_201(rtx *operands, rtx insn) asm("_output_201");
static char *
output_201(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);

  return "srl\t%0,%1,%2";
}
}

static char *
output_203(rtx *operands, rtx insn) asm("_output_203");
static char *
output_203(rtx *operands, rtx insn)
{

{
  operands[4] = const0_rtx;
  dslots_jump_total += 3;
  dslots_jump_filled += 2;

  return "sll\t%3,%2,26\n\tbgez\t%3,1f\n\tsrl\t%L0,%M1,%2\n\t%(b\t3f\n\tmove\t%M0,%z4%)\n\n1:\n\t%(beq\t%3,%z4,2f\n\tsrl\t%L0,%L1,%2%)\n\n\tsubu\t%3,%z4,%2\n\tsll\t%3,%M1,%3\n\tor\t%L0,%L0,%3\n2:\n\tsrl\t%M0,%M1,%2\n3:";
}
}

static char *
output_204(rtx *operands, rtx insn) asm("_output_204");
static char *
output_204(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint) & 0x1f);
  operands[4] = const0_rtx;
  return "srl\t%L0,%M1,%2\n\tmove\t%M0,%z4";
}
}

static char *
output_207(rtx *operands, rtx insn) asm("_output_207");
static char *
output_207(rtx *operands, rtx insn)
{

{
  int amount = ((operands[2])->fld[0].rtwint);

  operands[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  operands[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));

  return "srl\t%L0,%L1,%2\n\tsll\t%3,%M1,%4\n\tor\t%L0,%L0,%3\n\tsrl\t%M0,%M1,%2";
}
}

static char *
output_210(rtx *operands, rtx insn) asm("_output_210");
static char *
output_210(rtx *operands, rtx insn)
{

{
  if (((operands[2])->code) == CONST_INT)
    operands[2] = gen_rtx (CONST_INT, VOIDmode, (int) (((operands[2])->fld[0].rtwint) & 0x3f));

  return "dsrl\t%0,%1,%2";
}
}

static char *
output_217(rtx *operands, rtx insn) asm("_output_217");
static char *
output_217(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[0] != pc_rtx) ? "%*bc1t%?\t%0" : "%*bc1f%?\t%1";
}
}

static char *
output_218(rtx *operands, rtx insn) asm("_output_218");
static char *
output_218(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[0] != pc_rtx) ? "%*bc1f%?\t%0" : "%*bc1t%?\t%1";
}
}

static char *
output_219(rtx *operands, rtx insn) asm("_output_219");
static char *
output_219(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[0] != pc_rtx) ? "%*bc1f%?\t%0" : "%*bc1t%?\t%1";
}
}

static char *
output_220(rtx *operands, rtx insn) asm("_output_220");
static char *
output_220(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[0] != pc_rtx) ? "%*bc1t%?\t%0" : "%*bc1f%?\t%1";
}
}

static char *
output_221(rtx *operands, rtx insn) asm("_output_221");
static char *
output_221(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  if (operands[2] != pc_rtx)
    {
      switch (((operands[0])->code))
 {
 case EQ: return "%*beq%?\t%z1,%.,%2";
 case NE: return "%*bne%?\t%z1,%.,%2";
 case GTU: return "%*bne%?\t%z1,%.,%2";
 case LEU: return "%*beq%?\t%z1,%.,%2";
 case GEU: return "%*j\t%2";
 case LTU: return "%*bne%?\t%.,%.,%2";
 }

      return "%*b%C0z%?\t%z1,%2";
    }
  else
    {
      switch (((operands[0])->code))
 {
 case EQ: return "%*bne%?\t%z1,%.,%3";
 case NE: return "%*beq%?\t%z1,%.,%3";
 case GTU: return "%*beq%?\t%z1,%.,%3";
 case LEU: return "%*bne%?\t%z1,%.,%3";
 case GEU: return "%*beq%?\t%.,%.,%3";
 case LTU: return "%*j\t%3";
 }

      return "%*b%N0z%?\t%z1,%3";
    }
}
}

static char *
output_222(rtx *operands, rtx insn) asm("_output_222");
static char *
output_222(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  if (operands[2] != pc_rtx)
    {
      switch (((operands[0])->code))
 {
 case EQ: return "%*beq%?\t%z1,%.,%2";
 case NE: return "%*bne%?\t%z1,%.,%2";
 case GTU: return "%*bne%?\t%z1,%.,%2";
 case LEU: return "%*beq%?\t%z1,%.,%2";
 case GEU: return "%*j\t%2";
 case LTU: return "%*bne%?\t%.,%.,%2";
 }

      return "%*b%C0z%?\t%z1,%2";
    }
  else
    {
      switch (((operands[0])->code))
 {
 case EQ: return "%*bne%?\t%z1,%.,%3";
 case NE: return "%*beq%?\t%z1,%.,%3";
 case GTU: return "%*beq%?\t%z1,%.,%3";
 case LEU: return "%*bne%?\t%z1,%.,%3";
 case GEU: return "%*beq%?\t%.,%.,%3";
 case LTU: return "%*j\t%3";
 }

      return "%*b%N0z%?\t%z1,%3";
    }
}
}

static char *
output_223(rtx *operands, rtx insn) asm("_output_223");
static char *
output_223(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[3] != pc_rtx)
 ? "%*b%C0%?\t%z1,%z2,%3"
 : "%*b%N0%?\t%z1,%z2,%4";
}
}

static char *
output_224(rtx *operands, rtx insn) asm("_output_224");
static char *
output_224(rtx *operands, rtx insn)
{

{
  mips_branch_likely = (final_sequence && ((insn)->unchanging));
  return (operands[3] != pc_rtx)
 ? "%*b%C0%?\t%z1,%z2,%3"
 : "%*b%N0%?\t%z1,%z2,%4";
}
}

static char *
output_238(rtx *operands, rtx insn) asm("_output_238");
static char *
output_238(rtx *operands, rtx insn)
{
  static char *const strings_238[] = {
    "xor\t%0,%1,%2\n\tsltu\t%0,%0,1",
    "xori\t%0,%1,%2\n\tsltu\t%0,%0,1",
  };
  return strings_238[which_alternative];
}

static char *
output_240(rtx *operands, rtx insn) asm("_output_240");
static char *
output_240(rtx *operands, rtx insn)
{
  static char *const strings_240[] = {
    "xor\t%0,%1,%2\n\tsltu\t%0,%0,1",
    "xori\t%0,%1,%2\n\tsltu\t%0,%0,1",
  };
  return strings_240[which_alternative];
}

static char *
output_245(rtx *operands, rtx insn) asm("_output_245");
static char *
output_245(rtx *operands, rtx insn)
{
  static char *const strings_245[] = {
    "xor\t%0,%1,%2\n\tsltu\t%0,%.,%0",
    "xori\t%0,%1,%x2\n\tsltu\t%0,%.,%0",
  };
  return strings_245[which_alternative];
}

static char *
output_247(rtx *operands, rtx insn) asm("_output_247");
static char *
output_247(rtx *operands, rtx insn)
{
  static char *const strings_247[] = {
    "xor\t%0,%1,%2\n\tsltu\t%0,%.,%0",
    "xori\t%0,%1,%x2\n\tsltu\t%0,%.,%0",
  };
  return strings_247[which_alternative];
}

static char *
output_261(rtx *operands, rtx insn) asm("_output_261");
static char *
output_261(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint)+1);
  return "slt\t%0,%1,%2";
}
}

static char *
output_262(rtx *operands, rtx insn) asm("_output_262");
static char *
output_262(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint)+1);
  return "slt\t%0,%1,%2";
}
}

static char *
output_279(rtx *operands, rtx insn) asm("_output_279");
static char *
output_279(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint)+1);
  return "sltu\t%0,%1,%2";
}
}

static char *
output_280(rtx *operands, rtx insn) asm("_output_280");
static char *
output_280(rtx *operands, rtx insn)
{

{
  operands[2] = gen_rtx (CONST_INT, VOIDmode, ((operands[2])->fld[0].rtwint)+1);
  return "sltu\t%0,%1,%2";
}
}

static char *
output_285(rtx *operands, rtx insn) asm("_output_285");
static char *
output_285(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.eq.d\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_286(rtx *operands, rtx insn) asm("_output_286");
static char *
output_286(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.eq.d\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_287(rtx *operands, rtx insn) asm("_output_287");
static char *
output_287(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.lt.d\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_288(rtx *operands, rtx insn) asm("_output_288");
static char *
output_288(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.le.d\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_289(rtx *operands, rtx insn) asm("_output_289");
static char *
output_289(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.lt.d\t%1,%0", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_290(rtx *operands, rtx insn) asm("_output_290");
static char *
output_290(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.le.d\t%1,%0", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_291(rtx *operands, rtx insn) asm("_output_291");
static char *
output_291(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.eq.s\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_292(rtx *operands, rtx insn) asm("_output_292");
static char *
output_292(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.eq.s\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_293(rtx *operands, rtx insn) asm("_output_293");
static char *
output_293(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.lt.s\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_294(rtx *operands, rtx insn) asm("_output_294");
static char *
output_294(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.le.s\t%0,%1", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_295(rtx *operands, rtx insn) asm("_output_295");
static char *
output_295(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.lt.s\t%1,%0", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_296(rtx *operands, rtx insn) asm("_output_296");
static char *
output_296(rtx *operands, rtx insn)
{

{
  rtx xoperands[10];
  xoperands[0] = gen_rtx (REG, CC_FPmode, 67);
  xoperands[1] = operands[0];
  xoperands[2] = operands[1];

  return mips_fill_delay_slot ("c.le.s\t%1,%0", DELAY_FCMP, xoperands, insn);
}
}

static char *
output_297(rtx *operands, rtx insn) asm("_output_297");
static char *
output_297(rtx *operands, rtx insn)
{

{
  if (((operands[0])->code) == REG)
    return "%*j\t%0";



  else if (0 && mips_isa >= 3)
    return "%*b\t%l0";
  else
    return "%*j\t%l0";
}
}

static char *
output_302(rtx *operands, rtx insn) asm("_output_302");
static char *
output_302(rtx *operands, rtx insn)
{

{

  if ((target_flags & 0x00000400) && (! 0 || mips_isa < 3))
    output_asm_insn (".cpadd\t%0", operands);
  return "%*j\t%0";
}
}

static char *
output_303(rtx *operands, rtx insn) asm("_output_303");
static char *
output_303(rtx *operands, rtx insn)
{

{


  if ((target_flags & 0x00000400) && (! 0 || mips_isa < 3))
    output_asm_insn (".cpadd\t%0", operands);
  return "%*j\t%0";
}
}

static char *
output_307(rtx *operands, rtx insn) asm("_output_307");
static char *
output_307(rtx *operands, rtx insn)
{

{
  output_asm_insn ("%(bal\t%S1\n\tsll\t%0,2\n%S1:", operands);
  output_asm_insn ("addu\t%0,%0,$31%)", operands);
  output_asm_insn ("lw\t%0,%1-%S1(%0)\n\taddu\t%0,%0,$31", operands);
  return "j\t%0";
}
}

static char *
output_312(rtx *operands, rtx insn) asm("_output_312");
static char *
output_312(rtx *operands, rtx insn)
{

{
  register rtx target = ((operands[0])->fld[0].rtx);

  if (((target)->code) == SYMBOL_REF)
    return "%*jal\t%0";

  else if (((target)->code) == CONST_INT)
    {
      operands[0] = target;
      return "%[li\t%@,%0\n\t%*jal\t%2,%@%]";
    }

  else
    {
      operands[0] = target;
      return "%*jal\t%2,%0";
    }
}
}

static char *
output_313(rtx *operands, rtx insn) asm("_output_313");
static char *
output_313(rtx *operands, rtx insn)
{

{
  register rtx target = ((operands[0])->fld[0].rtx);

  if (((target)->code) == SYMBOL_REF)
    return "jal\t%0";

  else if (((target)->code) == CONST_INT)
    {
      operands[0] = target;
      return "li\t%^,%0\n\tjal\t%2,%^";
    }

  else
    {
      operands[0] = target;
      if (((target)->fld[0].rtint) != (0 + 25))
 return "move\t%^,%0\n\tjal\t%2,%^";
      else
 return "jal\t%2,%0";
    }
}
}

static char *
output_316(rtx *operands, rtx insn) asm("_output_316");
static char *
output_316(rtx *operands, rtx insn)
{

{
  if (((operands[0])->fld[0].rtint) != (0 + 25))
    return "move\t%^,%0\n\tjal\t%2,%^";
  else
    return "jal\t%2,%0";
}
}

static char *
output_317(rtx *operands, rtx insn) asm("_output_317");
static char *
output_317(rtx *operands, rtx insn)
{

{
  if (((operands[0])->fld[0].rtint) != (0 + 25))
    return "move\t%^,%0\n\tjal\t%2,%^";
  else
    return "jal\t%2,%0";
}
}

static char *
output_319(rtx *operands, rtx insn) asm("_output_319");
static char *
output_319(rtx *operands, rtx insn)
{

{
  register rtx target = ((operands[1])->fld[0].rtx);

  if (((target)->code) == SYMBOL_REF)
    return "%*jal\t%1";

  else if (((target)->code) == CONST_INT)
    {
      operands[1] = target;
      return "%[li\t%@,%1\n\t%*jal\t%3,%@%]";
    }

  else
    {
      operands[1] = target;
      return "%*jal\t%3,%1";
    }
}
}

static char *
output_320(rtx *operands, rtx insn) asm("_output_320");
static char *
output_320(rtx *operands, rtx insn)
{

{
  register rtx target = ((operands[1])->fld[0].rtx);

  if (((target)->code) == SYMBOL_REF)
    return "jal\t%1";

  else if (((target)->code) == CONST_INT)
    {
      operands[1] = target;
      return "li\t%^,%1\n\tjal\t%3,%^";
    }

  else
    {
      operands[1] = target;
      if (((target)->fld[0].rtint) != (0 + 25))
 return "move\t%^,%1\n\tjal\t%3,%^";
      else
 return "jal\t%3,%1";
    }
}
}

static char *
output_323(rtx *operands, rtx insn) asm("_output_323");
static char *
output_323(rtx *operands, rtx insn)
{

{
  if (((operands[1])->fld[0].rtint) != (0 + 25))
    return "move\t%^,%1\n\tjal\t%3,%^";
  else
    return "jal\t%3,%1";
}
}

static char *
output_324(rtx *operands, rtx insn) asm("_output_324");
static char *
output_324(rtx *operands, rtx insn)
{

{
  if (((operands[1])->fld[0].rtint) != (0 + 25))
    return "move\t%^,%1\n\tjal\t%3,%^";
  else
    return "jal\t%3,%1";
}
}

static char *
output_328(rtx *operands, rtx insn) asm("_output_328");
static char *
output_328(rtx *operands, rtx insn)
{
  static char *const strings_328[] = {
    "mov%B4\t%0,%z2,%1",
    "mov%b4\t%0,%z3,%1",
  };
  return strings_328[which_alternative];
}

static char *
output_329(rtx *operands, rtx insn) asm("_output_329");
static char *
output_329(rtx *operands, rtx insn)
{
  static char *const strings_329[] = {
    "mov%T3\t%0,%z1,$fcc0",
    "mov%t3\t%0,%z2,$fcc0",
  };
  return strings_329[which_alternative];
}

static char *
output_330(rtx *operands, rtx insn) asm("_output_330");
static char *
output_330(rtx *operands, rtx insn)
{
  static char *const strings_330[] = {
    "mov%B4\t%0,%z2,%1",
    "mov%b4\t%0,%z3,%1",
  };
  return strings_330[which_alternative];
}

static char *
output_331(rtx *operands, rtx insn) asm("_output_331");
static char *
output_331(rtx *operands, rtx insn)
{
  static char *const strings_331[] = {
    "mov%T3\t%0,%z1,$fcc0",
    "mov%t3\t%0,%z2,$fcc0",
  };
  return strings_331[which_alternative];
}

static char *
output_332(rtx *operands, rtx insn) asm("_output_332");
static char *
output_332(rtx *operands, rtx insn)
{
  static char *const strings_332[] = {
    "mov%B4.s\t%0,%2,%1",
    "mov%b4.s\t%0,%3,%1",
  };
  return strings_332[which_alternative];
}

static char *
output_333(rtx *operands, rtx insn) asm("_output_333");
static char *
output_333(rtx *operands, rtx insn)
{
  static char *const strings_333[] = {
    "mov%T3.s\t%0,%1,$fcc0",
    "mov%t3.s\t%0,%2,$fcc0",
  };
  return strings_333[which_alternative];
}

static char *
output_334(rtx *operands, rtx insn) asm("_output_334");
static char *
output_334(rtx *operands, rtx insn)
{
  static char *const strings_334[] = {
    "mov%B4.d\t%0,%2,%1",
    "mov%b4.d\t%0,%3,%1",
  };
  return strings_334[which_alternative];
}

static char *
output_335(rtx *operands, rtx insn) asm("_output_335");
static char *
output_335(rtx *operands, rtx insn)
{
  static char *const strings_335[] = {
    "mov%T3.d\t%0,%1,$fcc0",
    "mov%t3.d\t%0,%2,$fcc0",
  };
  return strings_335[which_alternative];
}

char * const insn_template[] =
  {
    "add.d\t%0,%1,%2",
    "add.s\t%0,%1,%2",
    0,
    "addu\t%0,%z1,%2",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "sub.d\t%0,%1,%2",
    "sub.s\t%0,%1,%2",
    0,
    "subu\t%0,%z1,%2",
    0,
    "sltu\t%3,%L1,%L2\n\tsubu\t%L0,%L1,%L2\n\tsubu\t%M0,%M1,%M2\n\tsubu\t%M0,%M0,%3",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "mul.d\t%0,%1,%2",
    "mul.s\t%0,%1,%2",
    0,
    "mult\t%1,%2",
    0,
    "mul\t%0,%1,%2",
    0,
    "dmult\t%1,%2",
    0,
    0,
    "mult\t%1,%2",
    "mult\t%1,%2",
    "mult\t%1,%2",
    0,
    "multu\t%1,%2",
    "multu\t%1,%2",
    "multu\t%1,%2",
    "dmult\t%1,%2",
    "dmultu\t%1,%2",
    "mad\t%1,%2",
    "mad\t%1,%2",
    "mad\t%1,%2",
    "madu\t%1,%2",
    "madu\t%1,%2",
    "madd.d\t%0,%3,%1,%2",
    "madd.s\t%0,%3,%1,%2",
    "msub.d\t%0,%3,%1,%2",
    "msub.s\t%0,%3,%1,%2",
    "nmadd.d\t%0,%3,%1,%2",
    "nmadd.s\t%0,%3,%1,%2",
    "nmsub.d\t%0,%1,%2,%3",
    "nmsub.s\t%0,%1,%2,%3",
    "div.d\t%0,%1,%2",
    "div.s\t%0,%1,%2",
    0,
    0,
    0,
    0,
    "div\t%0,%1,%2",
    "ddiv\t%0,%1,%2",
    "rem\t%0,%1,%2",
    "drem\t%0,%1,%2",
    "divu\t%0,%1,%2",
    "ddivu\t%0,%1,%2",
    "remu\t%0,%1,%2",
    "dremu\t%0,%1,%2",
    "sqrt.d\t%0,%1",
    "sqrt.s\t%0,%1",
    0,
    0,
    "abs.d\t%0,%1",
    "abs.s\t%0,%1",
    0,
    0,
    0,
    0,
    0,
    0,
    "neg.d\t%0,%1",
    "neg.s\t%0,%1",
    0,
    0,
    0,
    "nor\t%0,%z1,%z2",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "xori\t%0,%1,%x2",
    "cvt.s.d\t%0,%1",
    "dsll\t%0,%1,32\n\tdsra\t%0,%0,32",
    "andi\t%0,%1,0xffff",
    "andi\t%0,%1,0x00ff",
    0,
    0,
    0,
    "andi\t%0,%1,0xffff",
    "andi\t%0,%1,0xff",
    "andi\t%0,%1,0xff",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "cvt.d.s\t%0,%1",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "%[lui\t$1,%%hi(%%neg(%%gp_rel(%a0)))\n\taddiu\t$1,$1,%%lo(%%neg(%%gp_rel(%a0)))\n\tdaddu\t$gp,$1,$25%]",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "sltu\t%0,%1,1",
    "sltu\t%0,%1,1",
    0,
    0,
    0,
    0,
    0,
    "sltu\t%0,%.,%1",
    "sltu\t%0,%.,%1",
    0,
    0,
    0,
    0,
    0,
    "slt\t%0,%z2,%1",
    "slt\t%0,%z2,%1",
    0,
    "slt\t%0,%1,%2\n\txori\t%0,%0,0x0001",
    0,
    "slt\t%0,%1,%2\n\txori\t%0,%0,0x0001",
    0,
    0,
    "slt\t%0,%1,%2",
    "slt\t%0,%1,%2",
    0,
    0,
    0,
    "slt\t%0,%z2,%1\n\txori\t%0,%0,0x0001",
    0,
    "slt\t%0,%z2,%1\n\txori\t%0,%0,0x0001",
    0,
    0,
    "sltu\t%0,%z2,%1",
    "sltu\t%0,%z2,%1",
    0,
    "sltu\t%0,%1,%2\n\txori\t%0,%0,0x0001",
    0,
    "sltu\t%0,%1,%2\n\txori\t%0,%0,0x0001",
    0,
    0,
    "sltu\t%0,%1,%2",
    "sltu\t%0,%1,%2",
    0,
    0,
    0,
    "sltu\t%0,%z2,%1\n\txori\t%0,%0,0x0001",
    0,
    "sltu\t%0,%z2,%1\n\txori\t%0,%0,0x0001",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "%*j\t%0",
    "%*j\t%0",
    0,
    0,
    0,
    0,
    "%*j\t%0",
    0,
    0,
    0,
    "",
    "%($LF%= = . + 8\n\tbal\t$LF%=\n\tla\t%0,%1-$LF%=%)\n\taddu\t%0,%0,$31",
    0,
    0,
    0,
    "%*jal\t%2,%0",
    "%*jal\t%2,%0",
    0,
    0,
    0,
    0,
    0,
    "%*jal\t%3,%1",
    "%*jal\t%3,%1",
    0,
    0,
    0,
    "%(nop%)",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
  };

char *(*const insn_outfun[])(...) =
  {
    0,
    0,
    0,
    0,
    0,
    output_5,
    0,
    0,
    output_8,
    0,
    0,
    output_11,
    output_12,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_21,
    0,
    0,
    output_24,
    output_25,
    0,
    0,
    0,
    0,
    output_30,
    0,
    0,
    0,
    output_34,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_60,
    output_61,
    output_62,
    output_63,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_74,
    output_75,
    0,
    0,
    output_78,
    output_79,
    output_80,
    0,
    output_82,
    output_83,
    0,
    0,
    output_86,
    output_87,
    0,
    0,
    output_90,
    0,
    output_92,
    output_93,
    0,
    output_95,
    output_96,
    output_97,
    0,
    output_99,
    output_100,
    0,
    0,
    0,
    0,
    0,
    0,
    output_107,
    output_108,
    output_109,
    0,
    0,
    0,
    0,
    output_114,
    output_115,
    output_116,
    output_117,
    output_118,
    output_119,
    0,
    output_121,
    0,
    output_123,
    0,
    output_125,
    0,
    output_127,
    0,
    output_129,
    0,
    output_131,
    0,
    output_133,
    output_134,
    output_135,
    output_136,
    output_137,
    output_138,
    output_139,
    output_140,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_148,
    output_149,
    0,
    output_151,
    0,
    output_153,
    0,
    0,
    0,
    0,
    output_158,
    output_159,
    0,
    0,
    output_162,
    output_163,
    0,
    output_165,
    output_166,
    0,
    output_168,
    output_169,
    0,
    output_171,
    output_172,
    output_173,
    0,
    0,
    0,
    output_177,
    0,
    output_179,
    output_180,
    output_181,
    0,
    output_183,
    output_184,
    0,
    0,
    output_187,
    0,
    0,
    output_190,
    output_191,
    0,
    output_193,
    output_194,
    0,
    0,
    output_197,
    0,
    0,
    output_200,
    output_201,
    0,
    output_203,
    output_204,
    0,
    0,
    output_207,
    0,
    0,
    output_210,
    0,
    0,
    0,
    0,
    0,
    0,
    output_217,
    output_218,
    output_219,
    output_220,
    output_221,
    output_222,
    output_223,
    output_224,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_238,
    0,
    output_240,
    0,
    0,
    0,
    0,
    output_245,
    0,
    output_247,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_261,
    output_262,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    output_279,
    output_280,
    0,
    0,
    0,
    0,
    output_285,
    output_286,
    output_287,
    output_288,
    output_289,
    output_290,
    output_291,
    output_292,
    output_293,
    output_294,
    output_295,
    output_296,
    output_297,
    0,
    0,
    0,
    0,
    output_302,
    output_303,
    0,
    0,
    0,
    output_307,
    0,
    0,
    0,
    0,
    output_312,
    output_313,
    0,
    0,
    output_316,
    output_317,
    0,
    output_319,
    output_320,
    0,
    0,
    output_323,
    output_324,
    0,
    0,
    0,
    output_328,
    output_329,
    output_330,
    output_331,
    output_332,
    output_333,
    output_334,
    output_335,
    0,
  };

extern rtx (*const insn_gen_function[])(...) =
  {
    gen_adddf3,
    gen_addsf3,
    gen_addsi3,
    gen_addsi3_internal,
    gen_adddi3,
    gen_adddi3_internal_1,
    0,
    0,
    gen_adddi3_internal_2,
    0,
    0,
    gen_adddi3_internal_3,
    gen_addsi3_internal_2,
    gen_subdf3,
    gen_subsf3,
    gen_subsi3,
    gen_subsi3_internal,
    gen_subdi3,
    gen_subdi3_internal,
    0,
    0,
    gen_subdi3_internal_2,
    0,
    0,
    gen_subdi3_internal_3,
    gen_subsi3_internal_2,
    gen_muldf3,
    gen_mulsf3,
    gen_mulsi3,
    gen_mulsi3_internal,
    gen_mulsi3_r4000,
    gen_mulsi3_r4650,
    gen_muldi3,
    gen_muldi3_internal,
    gen_muldi3_r4000,
    gen_mulsidi3,
    gen_mulsidi3_internal,
    gen_mulsidi3_64bit,
    gen_smulsi3_highpart,
    gen_umulsidi3,
    gen_umulsidi3_internal,
    gen_umulsidi3_64bit,
    gen_umulsi3_highpart,
    gen_smuldi3_highpart,
    gen_umuldi3_highpart,
    gen_madsi,
    gen_maddi,
    gen_maddi_64bit,
    gen_umaddi,
    gen_umaddi_64bit,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    gen_divdf3,
    gen_divsf3,
    gen_divmodsi4,
    gen_divmoddi4,
    gen_udivmodsi4,
    gen_udivmoddi4,
    gen_divsi3,
    gen_divdi3,
    gen_modsi3,
    gen_moddi3,
    gen_udivsi3,
    gen_udivdi3,
    gen_umodsi3,
    gen_umoddi3,
    gen_sqrtdf2,
    gen_sqrtsf2,
    gen_abssi2,
    gen_absdi2,
    gen_absdf2,
    gen_abssf2,
    gen_ffssi2,
    gen_ffsdi2,
    gen_negsi2,
    gen_negdi2,
    gen_negdi2_internal,
    gen_negdi2_internal_2,
    gen_negdf2,
    gen_negsf2,
    gen_one_cmplsi2,
    gen_one_cmpldi2,
    0,
    gen_norsi3,
    gen_nordi3,
    0,
    gen_andsi3,
    gen_anddi3,
    0,
    gen_anddi3_internal1,
    gen_iorsi3,
    gen_iordi3,
    0,
    gen_xorsi3,
    gen_xordi3,
    0,
    gen_xordi3_immed,
    gen_truncdfsf2,
    gen_truncdisi2,
    gen_truncdihi2,
    gen_truncdiqi2,
    0,
    0,
    0,
    0,
    0,
    0,
    gen_zero_extendsidi2,
    gen_zero_extendsidi2_internal,
    gen_zero_extendhisi2,
    gen_zero_extendhidi2,
    gen_zero_extendqihi2,
    gen_zero_extendqisi2,
    gen_zero_extendqidi2,
    gen_extendsidi2,
    gen_extendsidi2_internal,
    gen_extendhidi2,
    gen_extendhidi2_internal,
    gen_extendhisi2,
    gen_extendhisi2_internal,
    gen_extendqihi2,
    gen_extendqihi2_internal,
    gen_extendqisi2,
    gen_extendqisi2_insn,
    gen_extendqidi2,
    gen_extendqidi2_insn,
    gen_extendsfdf2,
    gen_fix_truncdfsi2,
    gen_fix_truncsfsi2,
    gen_fix_truncdfdi2,
    gen_fix_truncsfdi2,
    gen_floatsidf2,
    gen_floatdidf2,
    gen_floatsisf2,
    gen_floatdisf2,
    gen_fixuns_truncdfsi2,
    gen_fixuns_truncdfdi2,
    gen_fixuns_truncsfsi2,
    gen_fixuns_truncsfdi2,
    gen_extv,
    gen_extzv,
    gen_insv,
    gen_movsi_ulw,
    gen_movsi_usw,
    gen_movdi,
    gen_movdi_internal,
    0,
    gen_movdi_internal2,
    gen_reload_indi,
    gen_reload_outdi,
    0,
    gen_movsi,
    gen_movsi_internal1,
    gen_movsi_internal2,
    gen_reload_outsi,
    gen_movhi,
    gen_movhi_internal1,
    gen_movhi_internal2,
    gen_movqi,
    gen_movqi_internal1,
    gen_movqi_internal2,
    gen_movsf,
    gen_movsf_internal1,
    gen_movsf_internal2,
    gen_movdf,
    gen_movdf_internal1,
    gen_movdf_internal1a,
    gen_movdf_internal2,
    0,
    gen_loadgp,
    gen_movstrsi,
    gen_movstrsi_internal,
    0,
    gen_movstrsi_internal2,
    gen_movstrsi_internal3,
    gen_ashlsi3,
    gen_ashldi3,
    gen_ashldi3_internal,
    gen_ashldi3_internal2,
    0,
    0,
    gen_ashldi3_internal3,
    0,
    0,
    gen_ashldi3_internal4,
    gen_ashrsi3,
    gen_ashrdi3,
    gen_ashrdi3_internal,
    gen_ashrdi3_internal2,
    0,
    0,
    gen_ashrdi3_internal3,
    0,
    0,
    gen_ashrdi3_internal4,
    gen_lshrsi3,
    gen_lshrdi3,
    gen_lshrdi3_internal,
    gen_lshrdi3_internal2,
    0,
    0,
    gen_lshrdi3_internal3,
    0,
    0,
    gen_lshrdi3_internal4,
    gen_cmpsi,
    gen_tstsi,
    gen_cmpdi,
    gen_tstdi,
    gen_cmpdf,
    gen_cmpsf,
    gen_branch_fp_ne,
    gen_branch_fp_ne_rev,
    gen_branch_fp_eq,
    gen_branch_fp_eq_rev,
    gen_branch_zero,
    gen_branch_zero_di,
    gen_branch_equality,
    gen_branch_equality_di,
    gen_beq,
    gen_bne,
    gen_bgt,
    gen_bge,
    gen_blt,
    gen_ble,
    gen_bgtu,
    gen_bgeu,
    gen_bltu,
    gen_bleu,
    gen_seq,
    gen_seq_si_zero,
    gen_seq_di_zero,
    gen_seq_si,
    0,
    gen_seq_di,
    0,
    gen_sne,
    gen_sne_si_zero,
    gen_sne_di_zero,
    gen_sne_si,
    0,
    gen_sne_di,
    0,
    gen_sgt,
    gen_sgt_si,
    gen_sgt_di,
    gen_sge,
    gen_sge_si,
    0,
    gen_sge_di,
    0,
    gen_slt,
    gen_slt_si,
    gen_slt_di,
    gen_sle,
    gen_sle_si_const,
    gen_sle_di_const,
    gen_sle_si_reg,
    0,
    gen_sle_di_reg,
    0,
    gen_sgtu,
    gen_sgtu_si,
    gen_sgtu_di,
    gen_sgeu,
    gen_sgeu_si,
    0,
    gen_sgeu_di,
    0,
    gen_sltu,
    gen_sltu_si,
    gen_sltu_di,
    gen_sleu,
    gen_sleu_si_const,
    gen_sleu_di_const,
    gen_sleu_si_reg,
    0,
    gen_sleu_di_reg,
    0,
    gen_seq_df,
    gen_sne_df,
    gen_slt_df,
    gen_sle_df,
    gen_sgt_df,
    gen_sge_df,
    gen_seq_sf,
    gen_sne_sf,
    gen_slt_sf,
    gen_sle_sf,
    gen_sgt_sf,
    gen_sge_sf,
    gen_jump,
    gen_indirect_jump,
    gen_indirect_jump_internal1,
    gen_indirect_jump_internal2,
    gen_tablejump,
    gen_tablejump_internal1,
    gen_tablejump_internal2,
    gen_return,
    gen_return_internal,
    gen_casesi,
    gen_casesi_internal,
    gen_prologue,
    gen_blockage,
    gen_get_fnaddr,
    gen_call,
    gen_call_internal1,
    gen_call_internal2,
    gen_call_internal3a,
    gen_call_internal3b,
    gen_call_internal4a,
    gen_call_internal4b,
    gen_call_value,
    gen_call_value_internal1,
    gen_call_value_internal2,
    gen_call_value_internal3a,
    gen_call_value_internal3b,
    gen_call_value_internal4a,
    gen_call_value_internal4b,
    gen_untyped_call,
    gen_nop,
    gen_probe,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    gen_movsicc,
  };

char *insn_name[] =
  {
    "adddf3",
    "addsf3",
    "addsi3",
    "addsi3_internal",
    "adddi3",
    "adddi3_internal_1",
    "adddi3_internal_1+1",
    "adddi3_internal_2-1",
    "adddi3_internal_2",
    "adddi3_internal_2+1",
    "adddi3_internal_3-1",
    "adddi3_internal_3",
    "addsi3_internal_2",
    "subdf3",
    "subsf3",
    "subsi3",
    "subsi3_internal",
    "subdi3",
    "subdi3_internal",
    "subdi3_internal+1",
    "subdi3_internal_2-1",
    "subdi3_internal_2",
    "subdi3_internal_2+1",
    "subdi3_internal_3-1",
    "subdi3_internal_3",
    "subsi3_internal_2",
    "muldf3",
    "mulsf3",
    "mulsi3",
    "mulsi3_internal",
    "mulsi3_r4000",
    "mulsi3_r4650",
    "muldi3",
    "muldi3_internal",
    "muldi3_r4000",
    "mulsidi3",
    "mulsidi3_internal",
    "mulsidi3_64bit",
    "smulsi3_highpart",
    "umulsidi3",
    "umulsidi3_internal",
    "umulsidi3_64bit",
    "umulsi3_highpart",
    "smuldi3_highpart",
    "umuldi3_highpart",
    "madsi",
    "maddi",
    "maddi_64bit",
    "umaddi",
    "umaddi_64bit",
    "umaddi_64bit+1",
    "umaddi_64bit+2",
    "umaddi_64bit+3",
    "umaddi_64bit+4",
    "divdf3-4",
    "divdf3-3",
    "divdf3-2",
    "divdf3-1",
    "divdf3",
    "divsf3",
    "divmodsi4",
    "divmoddi4",
    "udivmodsi4",
    "udivmoddi4",
    "divsi3",
    "divdi3",
    "modsi3",
    "moddi3",
    "udivsi3",
    "udivdi3",
    "umodsi3",
    "umoddi3",
    "sqrtdf2",
    "sqrtsf2",
    "abssi2",
    "absdi2",
    "absdf2",
    "abssf2",
    "ffssi2",
    "ffsdi2",
    "negsi2",
    "negdi2",
    "negdi2_internal",
    "negdi2_internal_2",
    "negdf2",
    "negsf2",
    "one_cmplsi2",
    "one_cmpldi2",
    "one_cmpldi2+1",
    "norsi3",
    "nordi3",
    "nordi3+1",
    "andsi3",
    "anddi3",
    "anddi3+1",
    "anddi3_internal1",
    "iorsi3",
    "iordi3",
    "iordi3+1",
    "xorsi3",
    "xordi3",
    "xordi3+1",
    "xordi3_immed",
    "truncdfsf2",
    "truncdisi2",
    "truncdihi2",
    "truncdiqi2",
    "truncdiqi2+1",
    "truncdiqi2+2",
    "truncdiqi2+3",
    "zero_extendsidi2-3",
    "zero_extendsidi2-2",
    "zero_extendsidi2-1",
    "zero_extendsidi2",
    "zero_extendsidi2_internal",
    "zero_extendhisi2",
    "zero_extendhidi2",
    "zero_extendqihi2",
    "zero_extendqisi2",
    "zero_extendqidi2",
    "extendsidi2",
    "extendsidi2_internal",
    "extendhidi2",
    "extendhidi2_internal",
    "extendhisi2",
    "extendhisi2_internal",
    "extendqihi2",
    "extendqihi2_internal",
    "extendqisi2",
    "extendqisi2_insn",
    "extendqidi2",
    "extendqidi2_insn",
    "extendsfdf2",
    "fix_truncdfsi2",
    "fix_truncsfsi2",
    "fix_truncdfdi2",
    "fix_truncsfdi2",
    "floatsidf2",
    "floatdidf2",
    "floatsisf2",
    "floatdisf2",
    "fixuns_truncdfsi2",
    "fixuns_truncdfdi2",
    "fixuns_truncsfsi2",
    "fixuns_truncsfdi2",
    "extv",
    "extzv",
    "insv",
    "movsi_ulw",
    "movsi_usw",
    "movdi",
    "movdi_internal",
    "movdi_internal+1",
    "movdi_internal2",
    "reload_indi",
    "reload_outdi",
    "reload_outdi+1",
    "movsi",
    "movsi_internal1",
    "movsi_internal2",
    "reload_outsi",
    "movhi",
    "movhi_internal1",
    "movhi_internal2",
    "movqi",
    "movqi_internal1",
    "movqi_internal2",
    "movsf",
    "movsf_internal1",
    "movsf_internal2",
    "movdf",
    "movdf_internal1",
    "movdf_internal1a",
    "movdf_internal2",
    "movdf_internal2+1",
    "loadgp",
    "movstrsi",
    "movstrsi_internal",
    "movstrsi_internal+1",
    "movstrsi_internal2",
    "movstrsi_internal3",
    "ashlsi3",
    "ashldi3",
    "ashldi3_internal",
    "ashldi3_internal2",
    "ashldi3_internal2+1",
    "ashldi3_internal3-1",
    "ashldi3_internal3",
    "ashldi3_internal3+1",
    "ashldi3_internal4-1",
    "ashldi3_internal4",
    "ashrsi3",
    "ashrdi3",
    "ashrdi3_internal",
    "ashrdi3_internal2",
    "ashrdi3_internal2+1",
    "ashrdi3_internal3-1",
    "ashrdi3_internal3",
    "ashrdi3_internal3+1",
    "ashrdi3_internal4-1",
    "ashrdi3_internal4",
    "lshrsi3",
    "lshrdi3",
    "lshrdi3_internal",
    "lshrdi3_internal2",
    "lshrdi3_internal2+1",
    "lshrdi3_internal3-1",
    "lshrdi3_internal3",
    "lshrdi3_internal3+1",
    "lshrdi3_internal4-1",
    "lshrdi3_internal4",
    "cmpsi",
    "tstsi",
    "cmpdi",
    "tstdi",
    "cmpdf",
    "cmpsf",
    "branch_fp_ne",
    "branch_fp_ne_rev",
    "branch_fp_eq",
    "branch_fp_eq_rev",
    "branch_zero",
    "branch_zero_di",
    "branch_equality",
    "branch_equality_di",
    "beq",
    "bne",
    "bgt",
    "bge",
    "blt",
    "ble",
    "bgtu",
    "bgeu",
    "bltu",
    "bleu",
    "seq",
    "seq_si_zero",
    "seq_di_zero",
    "seq_si",
    "seq_si+1",
    "seq_di",
    "seq_di+1",
    "sne",
    "sne_si_zero",
    "sne_di_zero",
    "sne_si",
    "sne_si+1",
    "sne_di",
    "sne_di+1",
    "sgt",
    "sgt_si",
    "sgt_di",
    "sge",
    "sge_si",
    "sge_si+1",
    "sge_di",
    "sge_di+1",
    "slt",
    "slt_si",
    "slt_di",
    "sle",
    "sle_si_const",
    "sle_di_const",
    "sle_si_reg",
    "sle_si_reg+1",
    "sle_di_reg",
    "sle_di_reg+1",
    "sgtu",
    "sgtu_si",
    "sgtu_di",
    "sgeu",
    "sgeu_si",
    "sgeu_si+1",
    "sgeu_di",
    "sgeu_di+1",
    "sltu",
    "sltu_si",
    "sltu_di",
    "sleu",
    "sleu_si_const",
    "sleu_di_const",
    "sleu_si_reg",
    "sleu_si_reg+1",
    "sleu_di_reg",
    "sleu_di_reg+1",
    "seq_df",
    "sne_df",
    "slt_df",
    "sle_df",
    "sgt_df",
    "sge_df",
    "seq_sf",
    "sne_sf",
    "slt_sf",
    "sle_sf",
    "sgt_sf",
    "sge_sf",
    "jump",
    "indirect_jump",
    "indirect_jump_internal1",
    "indirect_jump_internal2",
    "tablejump",
    "tablejump_internal1",
    "tablejump_internal2",
    "return",
    "return_internal",
    "casesi",
    "casesi_internal",
    "prologue",
    "blockage",
    "get_fnaddr",
    "call",
    "call_internal1",
    "call_internal2",
    "call_internal3a",
    "call_internal3b",
    "call_internal4a",
    "call_internal4b",
    "call_value",
    "call_value_internal1",
    "call_value_internal2",
    "call_value_internal3a",
    "call_value_internal3b",
    "call_value_internal4a",
    "call_value_internal4b",
    "untyped_call",
    "nop",
    "probe",
    "probe+1",
    "probe+2",
    "probe+3",
    "probe+4",
    "movsicc-4",
    "movsicc-3",
    "movsicc-2",
    "movsicc-1",
    "movsicc",
  };
char **insn_name_ptr = insn_name;

extern const int insn_n_operands[] =
  {
    3,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    3,
    3,
    3,
    5,
    5,
    6,
    6,
    5,
    5,
    6,
    3,
    4,
    5,
    5,
    3,
    4,
    5,
    5,
    5,
    5,
    5,
    4,
    5,
    4,
    5,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    3,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    7,
    2,
    2,
    2,
    2,
    2,
    2,
    4,
    4,
    2,
    2,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    4,
    4,
    3,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    4,
    4,
    4,
    2,
    2,
    2,
    2,
    2,
    2,
    3,
    3,
    2,
    2,
    2,
    2,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    1,
    4,
    8,
    8,
    8,
    8,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    2,
    1,
    2,
    1,
    2,
    2,
    2,
    2,
    2,
    2,
    4,
    4,
    5,
    5,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    2,
    2,
    3,
    3,
    3,
    3,
    1,
    2,
    2,
    3,
    3,
    3,
    3,
    1,
    3,
    3,
    1,
    3,
    3,
    3,
    3,
    1,
    3,
    3,
    1,
    3,
    3,
    3,
    3,
    3,
    3,
    1,
    3,
    3,
    1,
    3,
    3,
    3,
    3,
    1,
    3,
    3,
    1,
    3,
    3,
    3,
    3,
    3,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    7,
    3,
    0,
    0,
    2,
    4,
    3,
    3,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    3,
    0,
    0,
    5,
    4,
    5,
    4,
    5,
    4,
    5,
    4,
    4,
  };

extern const int insn_n_dups[] =
  {
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    2,
    2,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    3,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
  };

char *const insn_operand_constraint[][10] =
  {
    { "=f", "f", "f", },
    { "=f", "f", "f", },
    { "=d", "dJ", "dI", },
    { "=d", "dJ", "dI", },
    { "", "", "", },
    { "=d,&d", "0,d", "d,d", "=d,d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d,d,d", "%d,%d,%d", "P,J,N", "=d,d,d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "dJ", "dI", },
    { "=d", "dJ", "dI", },
    { "=f", "f", "f", },
    { "=f", "f", "f", },
    { "=d", "dJ", "dI", },
    { "=d", "dJ", "dI", },
    { "=d", "d", "d", },
    { "=d", "d", "d", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d,d,d", "d,d,d", "P,J,N", "=d,d,d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "dJ", "dI", },
    { "=d", "dJ", "dI", },
    { "=f", "f", "f", },
    { "=f", "f", "f", },
    { "=l", "d", "d", "=h", "=a", },
    { "=l", "d", "d", "=h", "=a", },
    { "=d", "d", "d", "=h", "=l", "=a", },
    { "=d", "d", "d", "=h", "=l", "=a", },
    { "=l", "d", "d", "=h", "=a", },
    { "=l", "d", "d", "=h", "=a", },
    { "=d", "d", "d", "=h", "=l", "=a", },
    { "=x", "d", "d", },
    { "=x", "d", "d", "=a", },
    { "=a", "d", "d", "=l", "=h", },
    { "=h", "d", "d", "=l", "=a", },
    { "=x", "d", "d", },
    { "=x", "d", "d", "=a", },
    { "=a", "d", "d", "=l", "=h", },
    { "=h", "d", "d", "=l", "=a", },
    { "=h", "d", "d", "=l", "=a", },
    { "=h", "d", "d", "=l", "=a", },
    { "+l", "d", "d", "=h", "=a", },
    { "+x", "d", "d", "=a", },
    { "+a", "d", "d", "=l", "=h", },
    { "+x", "d", "d", "=a", },
    { "+a", "d", "d", "=l", "=h", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", "f", },
    { "=f", "f", "f", },
    { "=f", "f", "f", },
    { "=d", "d", "d", "=d", "=l", "=h", "=a", },
    { "=d", "d", "d", "=d", "=l", "=h", "=a", },
    { "=d", "d", "d", "=d", "=l", "=h", "=a", },
    { "=d", "d", "d", "=d", "=l", "=h", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=d", "d", "di", "=l", "=h", "", "=a", },
    { "=f", "f", },
    { "=f", "f", },
    { "=d", "d", },
    { "=d", "d", },
    { "=f", "f", },
    { "=f", "f", },
    { "=&d", "d", "=&d", "=&d", },
    { "=&d", "d", "=&d", "=&d", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d", "d", "=d", },
    { "=d", "d", },
    { "=f", "f", },
    { "=f", "f", },
    { "=d", "d", },
    { "=d", "d", },
    { "", "", },
    { "=d", "dJ", "dJ", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d,d", "%d,d", "d,K", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d,d", "%d,d", "d,K", },
    { "=d,d", "%d,d", "d,K", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d,d", "%d,d", "d,K", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "d", "d", "K", },
    { "=f", "f", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d", "d", "I", },
    { "=d", "d", "I", },
    { "=d", "d", "I", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d", "d", },
    { "", "", },
    { "=d,d", "R,m", },
    { "=d,d,d", "d,R,m", },
    { "=d,d,d", "d,R,m", },
    { "=d,d,d", "d,R,m", },
    { "=d,d,d", "d,R,m", },
    { "=d,d,d", "d,R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "", "", },
    { "=d,d", "R,m", },
    { "=f", "f", },
    { "=d,*f,R,o", "f,*f,f,f", "=d,*d,&d,&d", "=f,*X,f,f", },
    { "=d,*f,R,o", "f,*f,f,f", "=d,*d,&d,&d", "=f,*X,f,f", },
    { "=d,*f,R,o", "f,*f,f,f", "=f,*X,f,f", },
    { "=d,*f,R,o", "f,*f,f,f", "=f,*X,f,f", },
    { "=f,f,f", "d,R,m", },
    { "=f,f,f", "d,R,m", },
    { "=f,f,f", "d,R,m", },
    { "=f,f,f", "d,R,m", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=&d,&d", "R,o", },
    { "=R,o", "dJ,dJ", },
    { "", "", },
    { "=d,d,d,d,R,o,*d,*x", "d,iF,R,o,d,d,*x,*d", },
    { "", "", },
    { "=d,d,d,d,d,d,R,m,*d,*x,*a", " d,S,IKL,Mnis,R,m,dJ,dJ,*x,*d,*I", },
    { "=b", "b", "=&d", },
    { "=b", "b", "=&d", },
    { "", "", },
    { "", "", },
    { "=d,d,d,d,d,d,R,m,*d,*f*z,*f,*f,*f,*R,*m,*x,*x,*d,*d", "d,S,IKL,Mnis,R,m,dJ,dJ,*f*z,*d,*f,*R,*m,*f,*f,I,*d,*x,*a", },
    { "=d,d,d,d,d,d,R,m,*d,*z,*x,*d,*x,*d", "d,S,IKL,Mnis,R,m,dJ,dJ,*z,*d,I,*x,*d,*a", },
    { "=b", "d", "=&d", },
    { "", "", },
    { "=d,d,d,d,R,m,*d,*f,*f*z,*x,*d", "d,IK,R,m,dJ,dJ,*f*z,*d,*f,*d,*x", },
    { "=d,d,d,d,R,m,*d,*z,*x,*d", "d,IK,R,m,dJ,dJ,*z,*d,*d,*x", },
    { "", "", },
    { "=d,d,d,d,R,m,*d,*f*z,*f,*x,*d", "d,IK,R,m,dJ,dJ,*f*z,*d,*f,*d,*x", },
    { "=d,d,d,d,R,m,*d,*z,*x,*d", "d,IK,R,m,dJ,dJ,*z,*d,*d,*x", },
    { "", "", },
    { "=f,f,f,f,R,m,*f,*d,*d,*d,*d,*R,*m", "f,G,R,Fm,fG,fG,*d,*f,*G*d,*R,*F*m,*d,*d", },
    { "=d,d,d,R,m", "      Gd,R,Fm,d,d", },
    { "", "", },
    { "=f,f,f,R,o,f,*f,*d,*d,*d,*d,*R,*o", "f,R,o,fG,fG,F,*d,*f,*d*G,*R,*o*F,*d,*d", },
    { "=f,f,R,R,o,o,f,*d,*d,*d,*o,*R", " f,o,f,G,f,G,F,*F,*o,*R,*d,*d", },
    { "=d,d,d,R,o", "dG,R,oF,d,d", },
    { "", "", },
    { "", },
    { "", "", "", "", },
    { "=Ro", "Ro", "I", "I", "=&d", "=&d", "=&d", "=&d", },
    { "", "", "", "", "", "", "", "", },
    { "=Ro", "Ro", "I", "I", "=&d", "=&d", "=&d", "=&d", },
    { "=Ro", "Ro", "I", "I", "=&d", "=&d", "=&d", "=&d", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=&d", "d", "d", "=d", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "dI", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=&d", "d", "d", "=d", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "dI", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=&d", "d", "d", "=d", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "IJK", "=d", },
    { "", "", "", "", },
    { "", "", "", "", },
    { "=d", "d", "dI", },
    { "", "", },
    { "", },
    { "", "", },
    { "", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "", },
    { "", "d", "", "", },
    { "", "d", "", "", },
    { "", "d", "d", "", "", },
    { "", "d", "d", "", "", },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { "=d", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d,d", "%d,d", "d,K", },
    { "", "", "", },
    { "=d,d", "%d,d", "d,K", },
    { "", "", "", },
    { "=d", },
    { "=d", "d", },
    { "=d", "d", },
    { "=d,d", "%d,d", "d,K", },
    { "", "", "", },
    { "=d,d", "%d,d", "d,K", },
    { "", "", "", },
    { "=d", },
    { "=d", "d", "dJ", },
    { "=d", "d", "dJ", },
    { "=d", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=d", },
    { "=d", "d", "dI", },
    { "=d", "d", "dI", },
    { "=d", },
    { "=d", "d", "I", },
    { "=d", "d", "I", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d", },
    { "=d", "d", "dJ", },
    { "=d", "d", "dJ", },
    { "=d", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=d", "d", "dI", },
    { "", "", "", },
    { "=d", },
    { "=d", "d", "dI", },
    { "=d", "d", "dI", },
    { "=d", },
    { "=d", "d", "I", },
    { "=d", "d", "I", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "=d", "d", "d", },
    { "", "", "", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { "f", "f", },
    { 0 },
    { "d", },
    { "d", },
    { "d", },
    { "d", },
    { "d", },
    { "d", },
    { 0 },
    { "d", },
    { "d", "dI", "", "", "", "", "", },
    { "d", "", "d", },
    { 0 },
    { 0 },
    { "=d", "", },
    { "m", "i", "", "", },
    { "m", "i", "=d", },
    { "m", "i", "=d", },
    { "r", "i", "=d", },
    { "r", "i", "=d", },
    { "r", "i", "=d", },
    { "r", "i", "=d", },
    { "=df", "m", "i", "", },
    { "=df", "m", "i", "=d", },
    { "=df", "m", "i", "=d", },
    { "=df", "r", "i", "=d", },
    { "=df", "r", "i", "=d", },
    { "=df", "r", "i", "=d", },
    { "=df", "r", "i", "=d", },
    { "", "", "", },
    { 0 },
    { 0 },
    { "=d,d", "d,d", "dJ,0", "0,dJ", "", },
    { "=d,d", "dJ,0", "0,dJ", "", },
    { "=d,d", "d,d", "dJ,0", "0,dJ", "", },
    { "=d,d", "dJ,0", "0,dJ", "", },
    { "=f,f", "d,d", "f,0", "0,f", "", },
    { "=f,f", "f,0", "0,f", "", },
    { "=f,f", "d,d", "f,0", "0,f", "", },
    { "=f,f", "f,0", "0,f", "", },
    { "", "", "", "", },
  };

extern const n64_enum_machine_mode insn_operand_mode[][10] =
  {
    { DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, },
    { SImode, SImode, SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { DImode, DImode, DImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { DImode, SImode, SImode, },
    { DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, },
    { SImode, SImode, SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { DImode, DImode, DImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { DImode, SImode, SImode, },
    { DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, },
    { SImode, SImode, SImode, SImode, SImode, },
    { SImode, SImode, SImode, SImode, SImode, },
    { SImode, SImode, SImode, SImode, SImode, SImode, },
    { SImode, SImode, SImode, SImode, SImode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, },
    { DImode, DImode, DImode, DImode, DImode, },
    { DImode, DImode, DImode, DImode, DImode, DImode, },
    { DImode, SImode, SImode, },
    { DImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, DImode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, },
    { DImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, DImode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, },
    { DImode, DImode, DImode, DImode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, DImode, DImode, },
    { DImode, SImode, SImode, SImode, },
    { DImode, SImode, SImode, DImode, DImode, },
    { DFmode, DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, SFmode, },
    { DFmode, DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, SFmode, },
    { DFmode, DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, SFmode, },
    { DFmode, DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, SFmode, },
    { DFmode, DFmode, DFmode, },
    { SFmode, SFmode, SFmode, },
    { SImode, SImode, SImode, SImode, SImode, SImode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, DImode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, SImode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, DImode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, VOIDmode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, VOIDmode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, VOIDmode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, VOIDmode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, VOIDmode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, VOIDmode, DImode, },
    { SImode, SImode, SImode, SImode, SImode, VOIDmode, SImode, },
    { DImode, DImode, DImode, DImode, DImode, VOIDmode, DImode, },
    { DFmode, DFmode, },
    { SFmode, SFmode, },
    { SImode, SImode, },
    { DImode, DImode, },
    { DFmode, DFmode, },
    { SFmode, SFmode, },
    { SImode, SImode, SImode, SImode, },
    { DImode, DImode, DImode, DImode, },
    { SImode, SImode, },
    { DImode, DImode, },
    { DImode, DImode, SImode, },
    { DImode, DImode, },
    { DFmode, DFmode, },
    { SFmode, SFmode, },
    { SImode, SImode, },
    { DImode, DImode, },
    { VOIDmode, VOIDmode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { SFmode, DFmode, },
    { SImode, DImode, },
    { HImode, DImode, },
    { QImode, DImode, },
    { SImode, DImode, DImode, },
    { SImode, DImode, DImode, },
    { SImode, DImode, DImode, },
    { SImode, DImode, },
    { SImode, DImode, },
    { HImode, DImode, },
    { DImode, SImode, },
    { DImode, SImode, },
    { SImode, HImode, },
    { DImode, HImode, },
    { HImode, QImode, },
    { SImode, QImode, },
    { DImode, QImode, },
    { DImode, SImode, },
    { DImode, SImode, },
    { DImode, HImode, },
    { DImode, HImode, },
    { SImode, HImode, },
    { SImode, HImode, },
    { HImode, QImode, },
    { HImode, QImode, },
    { SImode, QImode, },
    { SImode, QImode, },
    { DImode, QImode, },
    { DImode, QImode, },
    { DFmode, SFmode, },
    { SImode, DFmode, SImode, DFmode, },
    { SImode, SFmode, SImode, SFmode, },
    { DImode, DFmode, DFmode, },
    { DImode, SFmode, DFmode, },
    { DFmode, SImode, },
    { DFmode, DImode, },
    { SFmode, SImode, },
    { SFmode, DImode, },
    { SImode, DFmode, },
    { DImode, DFmode, },
    { SImode, SFmode, },
    { DImode, SFmode, },
    { SImode, QImode, SImode, SImode, },
    { SImode, QImode, SImode, SImode, },
    { QImode, SImode, SImode, SImode, },
    { SImode, QImode, },
    { QImode, SImode, },
    { DImode, DImode, },
    { DImode, DImode, },
    { VOIDmode, VOIDmode, },
    { DImode, DImode, },
    { DImode, DImode, TImode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, },
    { SImode, SImode, },
    { SImode, SImode, },
    { SImode, SImode, },
    { SImode, SImode, SImode, },
    { HImode, HImode, },
    { HImode, HImode, },
    { HImode, HImode, },
    { QImode, QImode, },
    { QImode, QImode, },
    { QImode, QImode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { VOIDmode, VOIDmode, },
    { DImode, },
    { BLKmode, BLKmode, SImode, SImode, },
    { BLKmode, BLKmode, SImode, SImode, SImode, SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { BLKmode, BLKmode, SImode, SImode, SImode, SImode, SImode, SImode, },
    { BLKmode, BLKmode, SImode, SImode, SImode, SImode, SImode, SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, SImode, },
    { SImode, SImode, },
    { SImode, },
    { DImode, DImode, },
    { DImode, },
    { DFmode, DFmode, },
    { SFmode, SFmode, },
    { VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, },
    { SImode, SImode, VOIDmode, VOIDmode, },
    { DImode, DImode, VOIDmode, VOIDmode, },
    { SImode, SImode, SImode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, VOIDmode, VOIDmode, },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode },
    { SImode, },
    { SImode, SImode, },
    { DImode, DImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, },
    { SImode, SImode, },
    { DImode, DImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, },
    { SImode, SImode, SImode, },
    { DImode, DImode, DImode, },
    { SImode, SImode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DImode, DImode, DImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { DFmode, DFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { SFmode, SFmode, },
    { VOIDmode },
    { VOIDmode, },
    { SImode, },
    { DImode, },
    { VOIDmode, },
    { SImode, },
    { DImode, },
    { VOIDmode },
    { SImode, },
    { SImode, SImode, SImode, VOIDmode, VOIDmode, VOIDmode, SImode, },
    { SImode, VOIDmode, SImode, },
    { VOIDmode },
    { VOIDmode },
    { VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, SImode, },
    { VOIDmode, VOIDmode, SImode, },
    { SImode, VOIDmode, SImode, },
    { DImode, VOIDmode, SImode, },
    { SImode, VOIDmode, SImode, },
    { DImode, VOIDmode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode, VOIDmode, VOIDmode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, SImode, },
    { VOIDmode, SImode, VOIDmode, SImode, },
    { VOIDmode, DImode, VOIDmode, SImode, },
    { VOIDmode, SImode, VOIDmode, SImode, },
    { VOIDmode, DImode, VOIDmode, SImode, },
    { VOIDmode, VOIDmode, VOIDmode, },
    { VOIDmode },
    { VOIDmode },
    { SImode, SImode, SImode, SImode, VOIDmode, },
    { SImode, SImode, SImode, VOIDmode, },
    { DImode, DImode, DImode, DImode, VOIDmode, },
    { DImode, DImode, DImode, VOIDmode, },
    { SFmode, SImode, SFmode, SFmode, VOIDmode, },
    { SFmode, SFmode, SFmode, VOIDmode, },
    { DFmode, SImode, DFmode, DFmode, VOIDmode, },
    { DFmode, DFmode, DFmode, VOIDmode, },
    { SImode, VOIDmode, SImode, SImode, },
  };

extern const char insn_operand_strict_low[][10] =
  {
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, },
    { 0, 0, },
    { 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0, 0, },
    { 0 },
    { 0, },
    { 0, },
    { 0, },
    { 0, },
    { 0, },
    { 0, },
    { 0 },
    { 0, },
    { 0, 0, 0, 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0 },
    { 0 },
    { 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, },
    { 0 },
    { 0 },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
  };

extern int register_operand(...) asm("_register_operand");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int small_int(...) asm("_small_int");
extern int scratch_operand(...) asm("_scratch_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int memory_operand(...) asm("_memory_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int address_operand(...) asm("_address_operand");
extern int arith32_operand(...) asm("_arith32_operand");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern int cmp_op(...) asm("_cmp_op");
extern int equality_op(...) asm("_equality_op");
extern int call_insn_operand(...) asm("_call_insn_operand");
extern int comparison_operator(...) asm("_comparison_operator");

int (*const insn_operand_predicate[][10])(...) =
  {
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, reg_or_0_operand, arith_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, register_operand, register_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, nonmemory_operand, scratch_operand, scratch_operand, 0, scratch_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { 0, 0, },
    { register_operand, reg_or_0_operand, reg_or_0_operand, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, uns_arith_operand, uns_arith_operand, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, uns_arith_operand, },
    { register_operand, uns_arith_operand, uns_arith_operand, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, uns_arith_operand, uns_arith_operand, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, uns_arith_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, memory_operand, },
    { register_operand, register_operand, },
    { general_operand, register_operand, scratch_operand, scratch_operand, },
    { general_operand, register_operand, scratch_operand, scratch_operand, },
    { general_operand, register_operand, scratch_operand, },
    { general_operand, register_operand, scratch_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, nonimmediate_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, memory_operand, immediate_operand, immediate_operand, },
    { register_operand, memory_operand, immediate_operand, immediate_operand, },
    { memory_operand, immediate_operand, immediate_operand, register_operand, },
    { register_operand, general_operand, },
    { memory_operand, reg_or_0_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { 0, 0, },
    { nonimmediate_operand, general_operand, },
    { register_operand, general_operand, register_operand, },
    { general_operand, register_operand, register_operand, },
    { 0, 0, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { general_operand, register_operand, register_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { nonimmediate_operand, general_operand, },
    { 0, 0, },
    { address_operand, },
    { general_operand, general_operand, arith32_operand, immediate_operand, },
    { memory_operand, memory_operand, small_int, small_int, scratch_operand, scratch_operand, scratch_operand, scratch_operand, },
    { 0, 0, 0, 0, 0, 0, 0, 0, },
    { memory_operand, memory_operand, small_int, small_int, scratch_operand, scratch_operand, scratch_operand, scratch_operand, },
    { memory_operand, memory_operand, small_int, small_int, scratch_operand, scratch_operand, scratch_operand, scratch_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, register_operand, register_operand, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, small_int, register_operand, },
    { 0, 0, 0, 0, },
    { 0, 0, 0, 0, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, arith_operand, },
    { register_operand, },
    { register_operand, arith_operand, },
    { register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { pc_or_label_operand, pc_or_label_operand, },
    { pc_or_label_operand, pc_or_label_operand, },
    { pc_or_label_operand, pc_or_label_operand, },
    { pc_or_label_operand, pc_or_label_operand, },
    { cmp_op, register_operand, pc_or_label_operand, pc_or_label_operand, },
    { cmp_op, register_operand, pc_or_label_operand, pc_or_label_operand, },
    { equality_op, register_operand, register_operand, pc_or_label_operand, pc_or_label_operand, },
    { equality_op, register_operand, register_operand, pc_or_label_operand, pc_or_label_operand, },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { 0 },
    { register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, uns_arith_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, uns_arith_operand, },
    { 0, 0, 0, },
    { register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, uns_arith_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, uns_arith_operand, },
    { 0, 0, 0, },
    { register_operand, },
    { register_operand, register_operand, reg_or_0_operand, },
    { register_operand, register_operand, reg_or_0_operand, },
    { register_operand, },
    { register_operand, register_operand, arith_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, arith_operand, },
    { 0, 0, 0, },
    { register_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, },
    { register_operand, register_operand, reg_or_0_operand, },
    { register_operand, register_operand, reg_or_0_operand, },
    { register_operand, },
    { register_operand, register_operand, arith_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, arith_operand, },
    { 0, 0, 0, },
    { register_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, register_operand, arith_operand, },
    { register_operand, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, small_int, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, register_operand, },
    { 0, 0, 0, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { register_operand, register_operand, },
    { 0 },
    { register_operand, },
    { register_operand, },
    { register_operand, },
    { register_operand, },
    { register_operand, },
    { register_operand, },
    { 0 },
    { register_operand, },
    { register_operand, arith_operand, arith_operand, 0, 0, 0, scratch_operand, },
    { register_operand, 0, register_operand, },
    { 0 },
    { 0 },
    { register_operand, 0, },
    { memory_operand, 0, 0, 0, },
    { call_insn_operand, 0, register_operand, },
    { call_insn_operand, 0, register_operand, },
    { register_operand, 0, register_operand, },
    { register_operand, 0, register_operand, },
    { register_operand, 0, register_operand, },
    { register_operand, 0, register_operand, },
    { register_operand, memory_operand, 0, 0, },
    { register_operand, call_insn_operand, 0, register_operand, },
    { register_operand, call_insn_operand, 0, register_operand, },
    { register_operand, register_operand, 0, register_operand, },
    { register_operand, register_operand, 0, register_operand, },
    { register_operand, register_operand, 0, register_operand, },
    { register_operand, register_operand, 0, register_operand, },
    { 0, 0, 0, },
    { 0 },
    { 0 },
    { register_operand, register_operand, reg_or_0_operand, reg_or_0_operand, equality_op, },
    { register_operand, reg_or_0_operand, reg_or_0_operand, equality_op, },
    { register_operand, register_operand, reg_or_0_operand, reg_or_0_operand, equality_op, },
    { register_operand, reg_or_0_operand, reg_or_0_operand, equality_op, },
    { register_operand, register_operand, register_operand, register_operand, equality_op, },
    { register_operand, register_operand, register_operand, equality_op, },
    { register_operand, register_operand, register_operand, register_operand, equality_op, },
    { register_operand, register_operand, register_operand, equality_op, },
    { register_operand, comparison_operator, reg_or_0_operand, reg_or_0_operand, },
  };

extern const int insn_n_alternatives[] =
  {
    1,
    1,
    1,
    1,
    0,
    2,
    0,
    0,
    3,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    3,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    1,
    0,
    2,
    1,
    0,
    2,
    2,
    1,
    0,
    2,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    2,
    3,
    3,
    3,
    3,
    3,
    0,
    2,
    0,
    2,
    0,
    2,
    0,
    2,
    0,
    2,
    0,
    2,
    1,
    4,
    4,
    4,
    4,
    3,
    3,
    3,
    3,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    2,
    0,
    8,
    0,
    11,
    1,
    1,
    0,
    0,
    19,
    14,
    1,
    0,
    11,
    10,
    0,
    11,
    10,
    0,
    13,
    5,
    0,
    13,
    12,
    5,
    0,
    0,
    0,
    1,
    0,
    1,
    1,
    1,
    0,
    1,
    1,
    0,
    0,
    1,
    0,
    0,
    1,
    1,
    0,
    1,
    1,
    0,
    0,
    1,
    0,
    0,
    1,
    1,
    0,
    1,
    1,
    0,
    0,
    1,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    2,
    0,
    2,
    0,
    1,
    1,
    1,
    2,
    0,
    2,
    0,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    1,
    1,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    0,
  };

