// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int emit(...) asm("_emit");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int call_insn_operand(...) asm("_call_insn_operand");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;




extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;

extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");



extern char *insn_operand_constraint[][10];

extern rtx recog_operand[];






rtx
gen_adddf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_adddf3");
rtx
gen_adddf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DFmode,
 operand1,
 operand2));
}

rtx
gen_addsf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_addsf3");
rtx
gen_addsf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, SFmode,
 operand1,
 operand2));
}

rtx
gen_addsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_addsi3");
rtx
gen_addsi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) == -32768)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_addsi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_addsi3_internal");
rtx
gen_addsi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, SImode,
 operand1,
 operand2));
}

rtx
gen_adddi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_adddi3");
rtx
gen_adddi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx operand3;
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) == -32768)
    emit_operand[2] = force_reg (DImode, emit_operand[2]);

  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_adddi3_internal_3 (emit_operand[0], emit_operand[1],
     emit_operand[2]));
      goto _done;
    }

  emit_operand[3] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_adddi3_internal_1(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_adddi3_internal_1");
rtx
gen_adddi3_internal_1(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_6(rtx *emit_operand) asm("_gen_split_6");
rtx
gen_split_6(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_7(rtx *emit_operand) asm("_gen_split_7");
rtx
gen_split_7(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_adddi3_internal_2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_adddi3_internal_2");
rtx
gen_adddi3_internal_2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_9(rtx *emit_operand) asm("_gen_split_9");
rtx
gen_split_9(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_10(rtx *emit_operand) asm("_gen_split_10");
rtx
gen_split_10(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (PLUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_adddi3_internal_3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_adddi3_internal_3");
rtx
gen_adddi3_internal_3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 operand1,
 operand2));
}

rtx
gen_addsi3_internal_2(rtx operand0, rtx operand1, rtx operand2) asm("_gen_addsi3_internal_2");
rtx
gen_addsi3_internal_2(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 gen_rtx (PLUS, SImode,
 operand1,
 operand2)));
}

rtx
gen_subdf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subdf3");
rtx
gen_subdf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, DFmode,
 operand1,
 operand2));
}

rtx
gen_subsf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subsf3");
rtx
gen_subsf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, SFmode,
 operand1,
 operand2));
}

rtx
gen_subsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subsi3");
rtx
gen_subsi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) == -32768)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_subsi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subsi3_internal");
rtx
gen_subsi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, SImode,
 operand1,
 operand2));
}

rtx
gen_subdi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subdi3");
rtx
gen_subdi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx operand3;
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_subdi3_internal_3 (emit_operand[0], emit_operand[1],
     emit_operand[2]));
      goto _done;
    }

  emit_operand[3] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_subdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_subdi3_internal");
rtx
gen_subdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_19(rtx *emit_operand) asm("_gen_split_19");
rtx
gen_split_19(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_20(rtx *emit_operand) asm("_gen_split_20");
rtx
gen_split_20(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_subdi3_internal_2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_subdi3_internal_2");
rtx
gen_subdi3_internal_2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_22(rtx *emit_operand) asm("_gen_split_22");
rtx
gen_split_22(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_23(rtx *emit_operand) asm("_gen_split_23");
rtx
gen_split_23(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LTU, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (MINUS, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_subdi3_internal_3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subdi3_internal_3");
rtx
gen_subdi3_internal_3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MINUS, DImode,
 operand1,
 operand2));
}

rtx
gen_subsi3_internal_2(rtx operand0, rtx operand1, rtx operand2) asm("_gen_subsi3_internal_2");
rtx
gen_subsi3_internal_2(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 gen_rtx (MINUS, SImode,
 operand1,
 operand2)));
}

rtx
gen_muldf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_muldf3");
rtx
gen_muldf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DFmode,
 operand1,
 operand2));
}

rtx
gen_mulsf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsf3");
rtx
gen_mulsf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, SFmode,
 operand1,
 operand2));
}

rtx
gen_mulsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsi3");
rtx
gen_mulsi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00040000))
    emit_insn (gen_mulsi3_r4650 (emit_operand[0], emit_operand[1], emit_operand[2]));
  else if (mips_cpu != PROCESSOR_R4000)
    emit_insn (gen_mulsi3_internal (emit_operand[0], emit_operand[1], emit_operand[2]));
  else
    emit_insn (gen_mulsi3_r4000 (emit_operand[0], emit_operand[1], emit_operand[2]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, SImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_mulsi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsi3_internal");
rtx
gen_mulsi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_mulsi3_r4000(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsi3_r4000");
rtx
gen_mulsi3_r4000(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_mulsi3_r4650(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsi3_r4650");
rtx
gen_mulsi3_r4650(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_muldi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_muldi3");
rtx
gen_muldi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (mips_cpu != PROCESSOR_R4000)
    emit_insn (gen_muldi3_internal (emit_operand[0], emit_operand[1], emit_operand[2]));
  else
    emit_insn (gen_muldi3_r4000 (emit_operand[0], emit_operand[1], emit_operand[2]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_muldi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_muldi3_internal");
rtx
gen_muldi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_muldi3_r4000(rtx operand0, rtx operand1, rtx operand2) asm("_gen_muldi3_r4000");
rtx
gen_muldi3_r4000(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_mulsidi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsidi3");
rtx
gen_mulsidi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    emit_insn (gen_mulsidi3_64bit (emit_operand[0], emit_operand[1], emit_operand[2]));
  else
    emit_insn (gen_mulsidi3_internal (emit_operand[0], emit_operand[1], emit_operand[2]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_mulsidi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsidi3_internal");
rtx
gen_mulsidi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_mulsidi3_64bit(rtx operand0, rtx operand1, rtx operand2) asm("_gen_mulsidi3_64bit");
rtx
gen_mulsidi3_64bit(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_smulsi3_highpart(rtx operand0, rtx operand1, rtx operand2) asm("_gen_smulsi3_highpart");
rtx
gen_smulsi3_highpart(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, SImode,
 gen_rtx (LSHIFTRT, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2)),
 gen_rtx (CONST_INT, VOIDmode, (int) (32))))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_umulsidi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umulsidi3");
rtx
gen_umulsidi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    emit_insn (gen_umulsidi3_64bit (emit_operand[0], emit_operand[1], emit_operand[2]));
  else
    emit_insn (gen_umulsidi3_internal (emit_operand[0], emit_operand[1], emit_operand[2]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_umulsidi3_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umulsidi3_internal");
rtx
gen_umulsidi3_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_umulsidi3_64bit(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umulsidi3_64bit");
rtx
gen_umulsidi3_64bit(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_umulsi3_highpart(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umulsi3_highpart");
rtx
gen_umulsi3_highpart(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, SImode,
 gen_rtx (LSHIFTRT, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2)),
 gen_rtx (CONST_INT, VOIDmode, (int) (32))))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_smuldi3_highpart(rtx operand0, rtx operand1, rtx operand2) asm("_gen_smuldi3_highpart");
rtx
gen_smuldi3_highpart(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, DImode,
 gen_rtx (LSHIFTRT, TImode,
 gen_rtx (MULT, TImode,
 gen_rtx (SIGN_EXTEND, TImode,
 operand1),
 gen_rtx (SIGN_EXTEND, TImode,
 operand2)),
 gen_rtx (CONST_INT, VOIDmode, (int) (64))))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_umuldi3_highpart(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umuldi3_highpart");
rtx
gen_umuldi3_highpart(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, DImode,
 gen_rtx (LSHIFTRT, TImode,
 gen_rtx (MULT, TImode,
 gen_rtx (ZERO_EXTEND, TImode,
 operand1),
 gen_rtx (ZERO_EXTEND, TImode,
 operand2)),
 gen_rtx (CONST_INT, VOIDmode, (int) (64))))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_madsi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_madsi");
rtx
gen_madsi(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, SImode,
 gen_rtx (MULT, SImode,
 operand1,
 operand2),
 operand0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_maddi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_maddi");
rtx
gen_maddi(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2)),
 operand0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_maddi_64bit(rtx operand0, rtx operand1, rtx operand2) asm("_gen_maddi_64bit");
rtx
gen_maddi_64bit(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1),
 gen_rtx (SIGN_EXTEND, DImode,
 operand2)),
 operand0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_umaddi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umaddi");
rtx
gen_umaddi(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2)),
 operand0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_umaddi_64bit(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umaddi_64bit");
rtx
gen_umaddi_64bit(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (PLUS, DImode,
 gen_rtx (MULT, DImode,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1),
 gen_rtx (ZERO_EXTEND, DImode,
 operand2)),
 operand0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_divdf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_divdf3");
rtx
gen_divdf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, DFmode,
 operand1,
 operand2));
}

rtx
gen_divsf3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_divsf3");
rtx
gen_divsf3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, SFmode,
 operand1,
 operand2));
}

rtx
gen_divmodsi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_divmodsi4");
rtx
gen_divmodsi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (5,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, SImode,
 operand1,
 operand2)),
  gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (MOD, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_divmoddi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_divmoddi4");
rtx
gen_divmoddi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (5,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, DImode,
 operand1,
 operand2)),
  gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (MOD, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_udivmodsi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_udivmodsi4");
rtx
gen_udivmodsi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (5,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UDIV, SImode,
 operand1,
 operand2)),
  gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (UMOD, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_udivmoddi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_udivmoddi4");
rtx
gen_udivmoddi4(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (5,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UDIV, DImode,
 operand1,
 operand2)),
  gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (UMOD, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_divsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_divsi3");
rtx
gen_divsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_divdi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_divdi3");
rtx
gen_divdi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (DIV, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_modsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_modsi3");
rtx
gen_modsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MOD, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_moddi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_moddi3");
rtx
gen_moddi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (MOD, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_udivsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_udivsi3");
rtx
gen_udivsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UDIV, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_udivdi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_udivdi3");
rtx
gen_udivdi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UDIV, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_umodsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umodsi3");
rtx
gen_umodsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UMOD, SImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_umoddi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_umoddi3");
rtx
gen_umoddi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (4,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UMOD, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_sqrtdf2(rtx operand0, rtx operand1) asm("_gen_sqrtdf2");
rtx
gen_sqrtdf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SQRT, DFmode,
 operand1));
}

rtx
gen_sqrtsf2(rtx operand0, rtx operand1) asm("_gen_sqrtsf2");
rtx
gen_sqrtsf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SQRT, SFmode,
 operand1));
}

rtx
gen_abssi2(rtx operand0, rtx operand1) asm("_gen_abssi2");
rtx
gen_abssi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ABS, SImode,
 operand1));
}

rtx
gen_absdi2(rtx operand0, rtx operand1) asm("_gen_absdi2");
rtx
gen_absdi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ABS, DImode,
 operand1));
}

rtx
gen_absdf2(rtx operand0, rtx operand1) asm("_gen_absdf2");
rtx
gen_absdf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ABS, DFmode,
 operand1));
}

rtx
gen_abssf2(rtx operand0, rtx operand1) asm("_gen_abssf2");
rtx
gen_abssf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ABS, SFmode,
 operand1));
}

rtx
gen_ffssi2(rtx operand0, rtx operand1) asm("_gen_ffssi2");
rtx
gen_ffssi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FFS, SImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0))));
}

rtx
gen_ffsdi2(rtx operand0, rtx operand1) asm("_gen_ffsdi2");
rtx
gen_ffsdi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FFS, DImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0))));
}

rtx
gen_negsi2(rtx operand0, rtx operand1) asm("_gen_negsi2");
rtx
gen_negsi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, SImode,
 operand1));
}

rtx
gen_negdi2(rtx operand0, rtx operand1) asm("_gen_negdi2");
rtx
gen_negdi2(rtx operand0, rtx operand1)
{
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_negdi2_internal_2 (emit_operand[0], emit_operand[1]));
      goto _done;
    }

  emit_operand[2] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, DImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 operand2))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_negdi2_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_negdi2_internal");
rtx
gen_negdi2_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, DImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_negdi2_internal_2(rtx operand0, rtx operand1) asm("_gen_negdi2_internal_2");
rtx
gen_negdi2_internal_2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, DImode,
 operand1));
}

rtx
gen_negdf2(rtx operand0, rtx operand1) asm("_gen_negdf2");
rtx
gen_negdf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, DFmode,
 operand1));
}

rtx
gen_negsf2(rtx operand0, rtx operand1) asm("_gen_negsf2");
rtx
gen_negsf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NEG, SFmode,
 operand1));
}

rtx
gen_one_cmplsi2(rtx operand0, rtx operand1) asm("_gen_one_cmplsi2");
rtx
gen_one_cmplsi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NOT, SImode,
 operand1));
}

rtx
gen_one_cmpldi2(rtx operand0, rtx operand1) asm("_gen_one_cmpldi2");
rtx
gen_one_cmpldi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NOT, DImode,
 operand1));
}

rtx
gen_split_88(rtx *emit_operand) asm("_gen_split_88");
rtx
gen_split_88(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (NOT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (NOT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_norsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_norsi3");
rtx
gen_norsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NOT, SImode,
 gen_rtx (IOR, SImode,
 operand1,
 operand2)));
}

rtx
gen_nordi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_nordi3");
rtx
gen_nordi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NOT, DImode,
 gen_rtx (IOR, DImode,
 operand1,
 operand2)));
}

rtx
gen_split_91(rtx *emit_operand) asm("_gen_split_91");
rtx
gen_split_91(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (NOT, SImode,
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0)))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (NOT, SImode,
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1)))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_andsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_andsi3");
rtx
gen_andsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (AND, SImode,
 operand1,
 operand2));
}

rtx
gen_anddi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_anddi3");
rtx
gen_anddi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (AND, DImode,
 operand1,
 operand2));
}

rtx
gen_split_94(rtx *emit_operand) asm("_gen_split_94");
rtx
gen_split_94(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (AND, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (AND, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_anddi3_internal1(rtx operand0, rtx operand1, rtx operand2) asm("_gen_anddi3_internal1");
rtx
gen_anddi3_internal1(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (AND, DImode,
 operand1,
 operand2));
}

rtx
gen_iorsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_iorsi3");
rtx
gen_iorsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (IOR, SImode,
 operand1,
 operand2));
}

rtx
gen_iordi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_iordi3");
rtx
gen_iordi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (IOR, DImode,
 operand1,
 operand2));
}

rtx
gen_split_98(rtx *emit_operand) asm("_gen_split_98");
rtx
gen_split_98(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_xorsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_xorsi3");
rtx
gen_xorsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand1,
 operand2));
}

rtx
gen_xordi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_xordi3");
rtx
gen_xordi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand1,
 operand2));
}

rtx
gen_split_101(rtx *emit_operand) asm("_gen_split_101");
rtx
gen_split_101(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (XOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (SUBREG, SImode,
 operand2,
 0))));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (XOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (SUBREG, SImode,
 operand2,
 1))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_xordi3_immed(rtx operand0, rtx operand1, rtx operand2) asm("_gen_xordi3_immed");
rtx
gen_xordi3_immed(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand1,
 operand2));
}

rtx
gen_truncdfsf2(rtx operand0, rtx operand1) asm("_gen_truncdfsf2");
rtx
gen_truncdfsf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT_TRUNCATE, SFmode,
 operand1));
}

rtx
gen_truncdisi2(rtx operand0, rtx operand1) asm("_gen_truncdisi2");
rtx
gen_truncdisi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, SImode,
 operand1));
}

rtx
gen_truncdihi2(rtx operand0, rtx operand1) asm("_gen_truncdihi2");
rtx
gen_truncdihi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, HImode,
 operand1));
}

rtx
gen_truncdiqi2(rtx operand0, rtx operand1) asm("_gen_truncdiqi2");
rtx
gen_truncdiqi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (TRUNCATE, QImode,
 operand1));
}

rtx
gen_zero_extendsidi2(rtx operand0, rtx operand1) asm("_gen_zero_extendsidi2");
rtx
gen_zero_extendsidi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (DImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (DImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 32);

      emit_insn (gen_ashldi3 (temp, op1, shift));
      emit_insn (gen_lshrdi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_zero_extendsidi2_internal(rtx operand0, rtx operand1) asm("_gen_zero_extendsidi2_internal");
rtx
gen_zero_extendsidi2_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1));
}

rtx
gen_zero_extendhisi2(rtx operand0, rtx operand1) asm("_gen_zero_extendhisi2");
rtx
gen_zero_extendhisi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, SImode,
 operand1));
}

rtx
gen_zero_extendhidi2(rtx operand0, rtx operand1) asm("_gen_zero_extendhidi2");
rtx
gen_zero_extendhidi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1));
}

rtx
gen_zero_extendqihi2(rtx operand0, rtx operand1) asm("_gen_zero_extendqihi2");
rtx
gen_zero_extendqihi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, HImode,
 operand1));
}

rtx
gen_zero_extendqisi2(rtx operand0, rtx operand1) asm("_gen_zero_extendqisi2");
rtx
gen_zero_extendqisi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, SImode,
 operand1));
}

rtx
gen_zero_extendqidi2(rtx operand0, rtx operand1) asm("_gen_zero_extendqidi2");
rtx
gen_zero_extendqidi2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTEND, DImode,
 operand1));
}

rtx
gen_extendsidi2(rtx operand0, rtx operand1) asm("_gen_extendsidi2");
rtx
gen_extendsidi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (DImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (DImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 32);

      emit_insn (gen_ashldi3 (temp, op1, shift));
      emit_insn (gen_ashrdi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendsidi2_internal(rtx operand0, rtx operand1) asm("_gen_extendsidi2_internal");
rtx
gen_extendsidi2_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1));
}

rtx
gen_extendhidi2(rtx operand0, rtx operand1) asm("_gen_extendhidi2");
rtx
gen_extendhidi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (DImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (DImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 48);

      emit_insn (gen_ashldi3 (temp, op1, shift));
      emit_insn (gen_ashrdi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendhidi2_internal(rtx operand0, rtx operand1) asm("_gen_extendhidi2_internal");
rtx
gen_extendhidi2_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1));
}

rtx
gen_extendhisi2(rtx operand0, rtx operand1) asm("_gen_extendhisi2");
rtx
gen_extendhisi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (SImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (SImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 16);

      emit_insn (gen_ashlsi3 (temp, op1, shift));
      emit_insn (gen_ashrsi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, SImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendhisi2_internal(rtx operand0, rtx operand1) asm("_gen_extendhisi2_internal");
rtx
gen_extendhisi2_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, SImode,
 operand1));
}

rtx
gen_extendqihi2(rtx operand0, rtx operand1) asm("_gen_extendqihi2");
rtx
gen_extendqihi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op0 = gen_lowpart (SImode, emit_operand[0]);
      rtx op1 = gen_lowpart (SImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (SImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 24);

      emit_insn (gen_ashlsi3 (temp, op1, shift));
      emit_insn (gen_ashrsi3 (op0, temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, HImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendqihi2_internal(rtx operand0, rtx operand1) asm("_gen_extendqihi2_internal");
rtx
gen_extendqihi2_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, HImode,
 operand1));
}

rtx
gen_extendqisi2(rtx operand0, rtx operand1) asm("_gen_extendqisi2");
rtx
gen_extendqisi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (SImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (SImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 24);

      emit_insn (gen_ashlsi3 (temp, op1, shift));
      emit_insn (gen_ashrsi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, SImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendqisi2_insn(rtx operand0, rtx operand1) asm("_gen_extendqisi2_insn");
rtx
gen_extendqisi2_insn(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, SImode,
 operand1));
}

rtx
gen_extendqidi2(rtx operand0, rtx operand1) asm("_gen_extendqidi2");
rtx
gen_extendqidi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (optimize && ((emit_operand[1])->code) == MEM)
    emit_operand[1] = force_not_mem (emit_operand[1]);

  if (((emit_operand[1])->code) != MEM)
    {
      rtx op1 = gen_lowpart (DImode, emit_operand[1]);
      rtx temp = gen_reg_rtx (DImode);
      rtx shift = gen_rtx (CONST_INT, VOIDmode, 56);

      emit_insn (gen_ashldi3 (temp, op1, shift));
      emit_insn (gen_ashrdi3 (emit_operand[0], temp, shift));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extendqidi2_insn(rtx operand0, rtx operand1) asm("_gen_extendqidi2_insn");
rtx
gen_extendqidi2_insn(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTEND, DImode,
 operand1));
}

rtx
gen_extendsfdf2(rtx operand0, rtx operand1) asm("_gen_extendsfdf2");
rtx
gen_extendsfdf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT_EXTEND, DFmode,
 operand1));
}

rtx
gen_fix_truncdfsi2(rtx operand0, rtx operand1) asm("_gen_fix_truncdfsi2");
rtx
gen_fix_truncdfsi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FIX, SImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DFmode, 0))));
}

rtx
gen_fix_truncsfsi2(rtx operand0, rtx operand1) asm("_gen_fix_truncsfsi2");
rtx
gen_fix_truncsfsi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FIX, SImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SFmode, 0))));
}

rtx
gen_fix_truncdfdi2(rtx operand0, rtx operand1) asm("_gen_fix_truncdfdi2");
rtx
gen_fix_truncdfdi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FIX, DImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DFmode, 0))));
}

rtx
gen_fix_truncsfdi2(rtx operand0, rtx operand1) asm("_gen_fix_truncsfdi2");
rtx
gen_fix_truncsfdi2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FIX, DImode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DFmode, 0))));
}

rtx
gen_floatsidf2(rtx operand0, rtx operand1) asm("_gen_floatsidf2");
rtx
gen_floatsidf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT, DFmode,
 operand1));
}

rtx
gen_floatdidf2(rtx operand0, rtx operand1) asm("_gen_floatdidf2");
rtx
gen_floatdidf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT, DFmode,
 operand1));
}

rtx
gen_floatsisf2(rtx operand0, rtx operand1) asm("_gen_floatsisf2");
rtx
gen_floatsisf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT, SFmode,
 operand1));
}

rtx
gen_floatdisf2(rtx operand0, rtx operand1) asm("_gen_floatdisf2");
rtx
gen_floatdisf2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (FLOAT, SFmode,
 operand1));
}

rtx
gen_fixuns_truncdfsi2(rtx operand0, rtx operand1) asm("_gen_fixuns_truncdfsi2");
rtx
gen_fixuns_truncdfsi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  rtx reg1 = gen_reg_rtx (DFmode);
  rtx reg2 = gen_reg_rtx (DFmode);
  rtx reg3 = gen_reg_rtx (SImode);
  rtx label1 = gen_label_rtx ();
  rtx label2 = gen_label_rtx ();
  double offset = ereal_ldexp (1.0, 31);

  if (reg1)
    {
      emit_move_insn (reg1, immed_real_const_1 (offset, DFmode));
      do_pending_stack_adjust ();

      emit_insn (gen_cmpdf (emit_operand[1], reg1));
      emit_jump_insn (gen_bge (label1));

      emit_insn (gen_fix_truncdfsi2 (emit_operand[0], emit_operand[1]));
      emit_jump_insn (gen_rtx (SET, VOIDmode, pc_rtx,
          gen_rtx (LABEL_REF, VOIDmode, label2)));
      emit_barrier ();

      emit_label (label1);
      emit_move_insn (reg2, gen_rtx (MINUS, DFmode, emit_operand[1], reg1));
      emit_move_insn (reg3, gen_rtx (CONST_INT, VOIDmode, 0x80000000));

      emit_insn (gen_fix_truncdfsi2 (emit_operand[0], reg2));
      emit_insn (gen_iorsi3 (emit_operand[0], emit_operand[0], reg3));

      emit_label (label2);



      emit_insn (gen_rtx (USE, VOIDmode, stack_pointer_rtx));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSIGNED_FIX, SImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_fixuns_truncdfdi2(rtx operand0, rtx operand1) asm("_gen_fixuns_truncdfdi2");
rtx
gen_fixuns_truncdfdi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  rtx reg1 = gen_reg_rtx (DFmode);
  rtx reg2 = gen_reg_rtx (DFmode);
  rtx reg3 = gen_reg_rtx (DImode);
  rtx label1 = gen_label_rtx ();
  rtx label2 = gen_label_rtx ();
  double offset = ereal_ldexp (1.0, 63);

  if (reg1)
    {
      emit_move_insn (reg1, immed_real_const_1 (offset, DFmode));
      do_pending_stack_adjust ();

      emit_insn (gen_cmpdf (emit_operand[1], reg1));
      emit_jump_insn (gen_bge (label1));

      emit_insn (gen_fix_truncdfdi2 (emit_operand[0], emit_operand[1]));
      emit_jump_insn (gen_rtx (SET, VOIDmode, pc_rtx,
          gen_rtx (LABEL_REF, VOIDmode, label2)));
      emit_barrier ();

      emit_label (label1);
      emit_move_insn (reg2, gen_rtx (MINUS, DFmode, emit_operand[1], reg1));
      emit_move_insn (reg3, gen_rtx (CONST_INT, VOIDmode, 0x80000000));
      emit_insn (gen_ashldi3 (reg3, reg3, gen_rtx (CONST_INT, VOIDmode, (int) (32))));

      emit_insn (gen_fix_truncdfdi2 (emit_operand[0], reg2));
      emit_insn (gen_iordi3 (emit_operand[0], emit_operand[0], reg3));

      emit_label (label2);



      emit_insn (gen_rtx (USE, VOIDmode, stack_pointer_rtx));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSIGNED_FIX, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_fixuns_truncsfsi2(rtx operand0, rtx operand1) asm("_gen_fixuns_truncsfsi2");
rtx
gen_fixuns_truncsfsi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  rtx reg1 = gen_reg_rtx (SFmode);
  rtx reg2 = gen_reg_rtx (SFmode);
  rtx reg3 = gen_reg_rtx (SImode);
  rtx label1 = gen_label_rtx ();
  rtx label2 = gen_label_rtx ();
  double offset = ereal_ldexp (1.0, 31);

  if (reg1)
    {
      emit_move_insn (reg1, immed_real_const_1 (offset, SFmode));
      do_pending_stack_adjust ();

      emit_insn (gen_cmpsf (emit_operand[1], reg1));
      emit_jump_insn (gen_bge (label1));

      emit_insn (gen_fix_truncsfsi2 (emit_operand[0], emit_operand[1]));
      emit_jump_insn (gen_rtx (SET, VOIDmode, pc_rtx,
          gen_rtx (LABEL_REF, VOIDmode, label2)));
      emit_barrier ();

      emit_label (label1);
      emit_move_insn (reg2, gen_rtx (MINUS, SFmode, emit_operand[1], reg1));
      emit_move_insn (reg3, gen_rtx (CONST_INT, VOIDmode, 0x80000000));

      emit_insn (gen_fix_truncsfsi2 (emit_operand[0], reg2));
      emit_insn (gen_iorsi3 (emit_operand[0], emit_operand[0], reg3));

      emit_label (label2);



      emit_insn (gen_rtx (USE, VOIDmode, stack_pointer_rtx));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSIGNED_FIX, SImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_fixuns_truncsfdi2(rtx operand0, rtx operand1) asm("_gen_fixuns_truncsfdi2");
rtx
gen_fixuns_truncsfdi2(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  rtx reg1 = gen_reg_rtx (SFmode);
  rtx reg2 = gen_reg_rtx (SFmode);
  rtx reg3 = gen_reg_rtx (DImode);
  rtx label1 = gen_label_rtx ();
  rtx label2 = gen_label_rtx ();
  double offset = ereal_ldexp (1.0, 63);

  if (reg1)
    {
      emit_move_insn (reg1, immed_real_const_1 (offset, SFmode));
      do_pending_stack_adjust ();

      emit_insn (gen_cmpsf (emit_operand[1], reg1));
      emit_jump_insn (gen_bge (label1));

      emit_insn (gen_fix_truncsfdi2 (emit_operand[0], emit_operand[1]));
      emit_jump_insn (gen_rtx (SET, VOIDmode, pc_rtx,
          gen_rtx (LABEL_REF, VOIDmode, label2)));
      emit_barrier ();

      emit_label (label1);
      emit_move_insn (reg2, gen_rtx (MINUS, SFmode, emit_operand[1], reg1));
      emit_move_insn (reg3, gen_rtx (CONST_INT, VOIDmode, 0x80000000));
      emit_insn (gen_ashldi3 (reg3, reg3, gen_rtx (CONST_INT, VOIDmode, (int) (32))));

      emit_insn (gen_fix_truncsfdi2 (emit_operand[0], reg2));
      emit_insn (gen_iordi3 (emit_operand[0], emit_operand[0], reg3));

      emit_label (label2);



      emit_insn (gen_rtx (USE, VOIDmode, stack_pointer_rtx));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSIGNED_FIX, DImode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extv(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_extv");
rtx
gen_extv(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{


  if (((emit_operand[2])->fld[0].rtwint) != 32 || (((emit_operand[3])->fld[0].rtwint) % 8) != 0)
    goto _fail;




  if (((emit_operand[1])->code) != MEM)
    goto _fail;


  emit_insn (gen_movsi_ulw (emit_operand[0], emit_operand[1]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (SIGN_EXTRACT, SImode,
 operand1,
 operand2,
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_extzv(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_extzv");
rtx
gen_extzv(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{


  if (((emit_operand[2])->fld[0].rtwint) != 32 || (((emit_operand[3])->fld[0].rtwint) % 8) != 0)
    goto _fail;




  if (((emit_operand[1])->code) != MEM)
    goto _fail;


  emit_insn (gen_movsi_ulw (emit_operand[0], emit_operand[1]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ZERO_EXTRACT, SImode,
 operand1,
 operand2,
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_insv(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_insv");
rtx
gen_insv(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{


  if (((emit_operand[1])->fld[0].rtwint) != 32 || (((emit_operand[2])->fld[0].rtwint) % 8) != 0)
    goto _fail;




  if (((emit_operand[0])->code) != MEM)
    goto _fail;


  emit_insn (gen_movsi_usw (emit_operand[0], emit_operand[3]));
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (ZERO_EXTRACT, SImode,
 operand0,
 operand1,
 operand2),
 operand3));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movsi_ulw(rtx operand0, rtx operand1) asm("_gen_movsi_ulw");
rtx
gen_movsi_ulw(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSPEC, VOIDmode,
 gen_rtvec (1,
  operand1),
 0));
}

rtx
gen_movsi_usw(rtx operand0, rtx operand1) asm("_gen_movsi_usw");
rtx
gen_movsi_usw(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSPEC, VOIDmode,
 gen_rtvec (1,
  operand1),
 1));
}

rtx
gen_movdi(rtx operand0, rtx operand1) asm("_gen_movdi");
rtx
gen_movdi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{



  if ((target_flags & 0x00004000)
      && (((emit_operand[1])->code) == LABEL_REF
   || (((emit_operand[1])->code) == SYMBOL_REF
       && ! ((emit_operand[1])->volatil))))
    {
      rtx temp;

      temp = embedded_pic_offset (emit_operand[1]);
      temp = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), embedded_pic_fnaddr_rtx,
        force_reg (DImode, temp));
      emit_move_insn (emit_operand[0], force_reg (DImode, temp));
      goto _done;
    }



  if (flag_pic && pic_address_needs_scratch (emit_operand[1]))
    {
      rtx temp = force_reg (DImode, ((((emit_operand[1])->fld[0].rtx))->fld[0].rtx));
      rtx temp2 = ((((emit_operand[1])->fld[0].rtx))->fld[1].rtx);

      if (! ((unsigned int) (((temp2)->fld[0].rtwint) + 0x8000) < 0x10000))
 temp2 = force_reg (DImode, temp2);

      emit_move_insn (emit_operand[0], gen_rtx (PLUS, DImode, temp, temp2));
      goto _done;
    }

  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], DImode)
      && !register_operand (emit_operand[1], DImode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0)
      && emit_operand[1] != (const_tiny_rtx[0][(int) (DImode)]))
    {
      rtx temp = force_reg (DImode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movdi_internal(rtx operand0, rtx operand1) asm("_gen_movdi_internal");
rtx
gen_movdi_internal(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_split_152(rtx *emit_operand) asm("_gen_split_152");
rtx
gen_split_152(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (SUBREG, SImode,
 operand1,
 0)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (SUBREG, SImode,
 operand1,
 1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movdi_internal2(rtx operand0, rtx operand1) asm("_gen_movdi_internal2");
rtx
gen_movdi_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_reload_indi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_reload_indi");
rtx
gen_reload_indi(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  rtx scratch = gen_rtx (REG, DImode,
    (((emit_operand[0])->fld[0].rtint) == ((emit_operand[2])->fld[0].rtint)
     ? ((emit_operand[2])->fld[0].rtint) + 1
     : ((emit_operand[2])->fld[0].rtint)));

  if (((emit_operand[0])->code) == REG && ((emit_operand[0])->fld[0].rtint) == (64 + 2))
    {
      if (((emit_operand[1])->code) == MEM)
 {
   rtx memword, offword, hiword, loword;

   scratch = gen_rtx (REG, SImode, ((scratch)->fld[0].rtint));
   memword = change_address (emit_operand[1], SImode, (rtx) 0);
   offword = change_address (adj_offsettable_operand (emit_operand[1], 4),
        SImode, (rtx) 0);
   if (((target_flags & 0x00010000) != 0))
     {
       hiword = memword;
       loword = offword;
     }
   else
     {
       hiword = offword;
       loword = memword;
     }
   emit_move_insn (scratch, hiword);
   emit_move_insn (gen_rtx (REG, SImode, 64), scratch);
   emit_move_insn (scratch, loword);
   emit_move_insn (gen_rtx (REG, SImode, 65), scratch);
 }
      else
 {
   emit_insn (gen_ashrdi3 (scratch, emit_operand[1], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_movdi (gen_rtx (REG, DImode, 64), scratch));
   emit_insn (gen_ashldi3 (scratch, emit_operand[1], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_ashrdi3 (scratch, scratch, gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_movdi (gen_rtx (REG, DImode, 65), scratch));
 }
      goto _done;
    }
  if (((emit_operand[1])->code) == REG && ((emit_operand[1])->fld[0].rtint) == (64 + 2))
    {
      emit_insn (gen_movdi (scratch, gen_rtx (REG, DImode, 65)));
      emit_insn (gen_ashldi3 (scratch, scratch, gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_lshrdi3 (scratch, scratch, gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_movdi (emit_operand[0], gen_rtx (REG, DImode, 64)));
      emit_insn (gen_ashldi3 (emit_operand[0], emit_operand[0], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_iordi3 (emit_operand[0], emit_operand[0], scratch));
      goto _done;
    }

  emit_move_insn (scratch, emit_operand[1]);
  emit_move_insn (emit_operand[0], scratch);
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 operand2));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_reload_outdi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_reload_outdi");
rtx
gen_reload_outdi(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (((emit_operand[0])->code) == REG && ((emit_operand[0])->fld[0].rtint) == (64 + 2))
    {
      emit_insn (gen_ashrdi3 (emit_operand[2], emit_operand[1], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_movdi (gen_rtx (REG, DImode, 64), emit_operand[2]));
      emit_insn (gen_ashldi3 (emit_operand[2], emit_operand[1], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_ashrdi3 (emit_operand[2], emit_operand[2], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
      emit_insn (gen_movdi (gen_rtx (REG, DImode, 65), emit_operand[2]));
      goto _done;
    }
  if (((emit_operand[1])->code) == REG && ((emit_operand[1])->fld[0].rtint) == (64 + 2))
    {
      if (((emit_operand[0])->code) == MEM)
 {
   rtx scratch, memword, offword, hiword, loword;

   scratch = gen_rtx (REG, SImode, ((emit_operand[2])->fld[0].rtint));
   memword = change_address (emit_operand[0], SImode, (rtx) 0);
   offword = change_address (adj_offsettable_operand (emit_operand[0], 4),
        SImode, (rtx) 0);
   if (((target_flags & 0x00010000) != 0))
     {
       hiword = memword;
       loword = offword;
     }
   else
     {
       hiword = offword;
       loword = memword;
     }
   emit_move_insn (scratch, gen_rtx (REG, SImode, 64));
   emit_move_insn (hiword, scratch);
   emit_move_insn (scratch, gen_rtx (REG, SImode, 65));
   emit_move_insn (loword, scratch);
 }
      else
 {
   emit_insn (gen_movdi (emit_operand[2], gen_rtx (REG, DImode, 65)));
   emit_insn (gen_ashldi3 (emit_operand[2], emit_operand[2], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_lshrdi3 (emit_operand[2], emit_operand[2], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_movdi (emit_operand[0], gen_rtx (REG, DImode, 64)));
   emit_insn (gen_ashldi3 (emit_operand[0], emit_operand[0], gen_rtx (CONST_INT, VOIDmode, (int) (32))));
   emit_insn (gen_iordi3 (emit_operand[0], emit_operand[0], emit_operand[2]));
 }
      goto _done;
    }

  emit_move_insn (emit_operand[2], emit_operand[1]);
  emit_move_insn (emit_operand[0], emit_operand[2]);
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 operand2));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_156(rtx *emit_operand) asm("_gen_split_156");
rtx
gen_split_156(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx _val = 0;
  start_sequence ();

{
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[1])->fld[0].rtwint) & 0xffff0000);
  emit_operand[3] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[1])->fld[0].rtwint) & 0x0000ffff);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand2));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (IOR, SImode,
 operand0,
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movsi(rtx operand0, rtx operand1) asm("_gen_movsi");
rtx
gen_movsi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{



  if ((target_flags & 0x00004000)
      && (((emit_operand[1])->code) == LABEL_REF
   || (((emit_operand[1])->code) == SYMBOL_REF
       && ! ((emit_operand[1])->volatil))))
    {
      rtx temp;

      temp = embedded_pic_offset (emit_operand[1]);
      temp = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), embedded_pic_fnaddr_rtx,
        force_reg (SImode, temp));
      emit_move_insn (emit_operand[0], force_reg (SImode, temp));
      goto _done;
    }



  if (flag_pic && pic_address_needs_scratch (emit_operand[1]))
    {
      rtx temp = force_reg (SImode, ((((emit_operand[1])->fld[0].rtx))->fld[0].rtx));
      rtx temp2 = ((((emit_operand[1])->fld[0].rtx))->fld[1].rtx);

      if (! ((unsigned int) (((temp2)->fld[0].rtwint) + 0x8000) < 0x10000))
 temp2 = force_reg (SImode, temp2);

      emit_move_insn (emit_operand[0], gen_rtx (PLUS, SImode, temp, temp2));
      goto _done;
    }

  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], SImode)
      && !register_operand (emit_operand[1], SImode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0))
    {
      rtx temp = force_reg (SImode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movsi_internal1(rtx operand0, rtx operand1) asm("_gen_movsi_internal1");
rtx
gen_movsi_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movsi_internal2(rtx operand0, rtx operand1) asm("_gen_movsi_internal2");
rtx
gen_movsi_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_reload_outsi(rtx operand0, rtx operand1, rtx operand2) asm("_gen_reload_outsi");
rtx
gen_reload_outsi(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (((emit_operand[0])->code) == REG && ((emit_operand[0])->fld[0].rtint) == (64 + 2))
    {
      emit_insn (gen_movsi (gen_rtx (REG, SImode, 65), emit_operand[1]));
      emit_insn (gen_ashrsi3 (emit_operand[2], emit_operand[1], gen_rtx (CONST_INT, VOIDmode, (int) (31))));
      emit_insn (gen_movsi (gen_rtx (REG, SImode, 64), emit_operand[2]));
      goto _done;
    }

  emit_move_insn (emit_operand[2], emit_operand[1]);
  emit_move_insn (emit_operand[0], emit_operand[2]);
  goto _done;
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
  emit_insn (gen_rtx (CLOBBER, VOIDmode,
 operand2));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movhi(rtx operand0, rtx operand1) asm("_gen_movhi");
rtx
gen_movhi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], HImode)
      && !register_operand (emit_operand[1], HImode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0))
    {
      rtx temp = force_reg (HImode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movhi_internal1(rtx operand0, rtx operand1) asm("_gen_movhi_internal1");
rtx
gen_movhi_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movhi_internal2(rtx operand0, rtx operand1) asm("_gen_movhi_internal2");
rtx
gen_movhi_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movqi(rtx operand0, rtx operand1) asm("_gen_movqi");
rtx
gen_movqi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], QImode)
      && !register_operand (emit_operand[1], QImode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0))
    {
      rtx temp = force_reg (QImode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movqi_internal1(rtx operand0, rtx operand1) asm("_gen_movqi_internal1");
rtx
gen_movqi_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movqi_internal2(rtx operand0, rtx operand1) asm("_gen_movqi_internal2");
rtx
gen_movqi_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movsf(rtx operand0, rtx operand1) asm("_gen_movsf");
rtx
gen_movsf(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], SFmode)
      && !register_operand (emit_operand[1], SFmode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0)
      && emit_operand[1] != (const_tiny_rtx[0][(int) (SFmode)]))
    {
      rtx temp = force_reg (SFmode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movsf_internal1(rtx operand0, rtx operand1) asm("_gen_movsf_internal1");
rtx
gen_movsf_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movsf_internal2(rtx operand0, rtx operand1) asm("_gen_movsf_internal2");
rtx
gen_movsf_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movdf(rtx operand0, rtx operand1) asm("_gen_movdf");
rtx
gen_movdf(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if ((reload_in_progress | reload_completed) == 0
      && !register_operand (emit_operand[0], DFmode)
      && !register_operand (emit_operand[1], DFmode)
      && (((emit_operand[1])->code) != CONST_INT || ((emit_operand[1])->fld[0].rtwint) != 0)
      && emit_operand[1] != (const_tiny_rtx[0][(int) (DFmode)]))
    {
      rtx temp = force_reg (DFmode, emit_operand[1]);
      emit_move_insn (emit_operand[0], temp);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movdf_internal1(rtx operand0, rtx operand1) asm("_gen_movdf_internal1");
rtx
gen_movdf_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movdf_internal1a(rtx operand0, rtx operand1) asm("_gen_movdf_internal1a");
rtx
gen_movdf_internal1a(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_movdf_internal2(rtx operand0, rtx operand1) asm("_gen_movdf_internal2");
rtx
gen_movdf_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 operand1);
}

rtx
gen_split_174(rtx *emit_operand) asm("_gen_split_174");
rtx
gen_split_174(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (SUBREG, SImode,
 operand1,
 0)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (SUBREG, SImode,
 operand1,
 1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_loadgp(rtx operand0) asm("_gen_loadgp");
rtx
gen_loadgp(rtx operand0)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 gen_rtx (REG, DImode,
 28),
 gen_rtx (UNSPEC_VOLATILE, VOIDmode,
 gen_rtvec (1,
  operand0),
 2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, DImode,
 1))));
}

rtx
gen_movstrsi(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_movstrsi");
rtx
gen_movstrsi(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{
  if (emit_operand[0])
    {
      expand_block_move (emit_operand);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 gen_rtx (MEM, BLKmode,
 operand0),
 gen_rtx (MEM, BLKmode,
 operand1)),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movstrsi_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_movstrsi_internal");
rtx
gen_movstrsi_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (8,
  gen_rtx (SET, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3),
  gen_rtx (USE, VOIDmode,
 const0_rtx)));
}

rtx
gen_split_178(rtx *emit_operand) asm("_gen_split_178");
rtx
gen_split_178(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx operand5;
  rtx operand6;
  rtx operand7;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  operand5 = emit_operand[5];
  operand6 = emit_operand[6];
  operand7 = emit_operand[7];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (8,
  gen_rtx (SET, VOIDmode,
 gen_rtx (MEM, BLKmode,
 operand0),
 gen_rtx (MEM, BLKmode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 operand4),
  gen_rtx (CLOBBER, VOIDmode,
 operand5),
  gen_rtx (CLOBBER, VOIDmode,
 operand6),
  gen_rtx (CLOBBER, VOIDmode,
 operand7),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3),
  gen_rtx (USE, VOIDmode,
 const1_rtx))));
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (8,
  gen_rtx (SET, VOIDmode,
 gen_rtx (MEM, BLKmode,
 operand0),
 gen_rtx (MEM, BLKmode,
 operand1)),
  gen_rtx (CLOBBER, VOIDmode,
 operand4),
  gen_rtx (CLOBBER, VOIDmode,
 operand5),
  gen_rtx (CLOBBER, VOIDmode,
 operand6),
  gen_rtx (CLOBBER, VOIDmode,
 operand7),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3),
  gen_rtx (USE, VOIDmode,
 gen_rtx (CONST_INT, VOIDmode, (int) (2))))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movstrsi_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_movstrsi_internal2");
rtx
gen_movstrsi_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (8,
  gen_rtx (SET, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3),
  gen_rtx (USE, VOIDmode,
 const1_rtx)));
}

rtx
gen_movstrsi_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_movstrsi_internal3");
rtx
gen_movstrsi_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (8,
  gen_rtx (SET, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3),
  gen_rtx (USE, VOIDmode,
 gen_rtx (CONST_INT, VOIDmode, (int) (2)))));
}

rtx
gen_ashlsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashlsi3");
rtx
gen_ashlsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, SImode,
 operand1,
 operand2));
}

rtx
gen_ashldi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashldi3");
rtx
gen_ashldi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx operand3;
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_ashldi3_internal4 (emit_operand[0], emit_operand[1],
     emit_operand[2]));
      goto _done;
    }

  emit_operand[3] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashldi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashldi3_internal");
rtx
gen_ashldi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_ashldi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashldi3_internal2");
rtx
gen_ashldi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_185(rtx *emit_operand) asm("_gen_split_185");
rtx
gen_split_185(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 const0_rtx));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_186(rtx *emit_operand) asm("_gen_split_186");
rtx
gen_split_186(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 const0_rtx));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashldi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashldi3_internal3");
rtx
gen_ashldi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_188(rtx *emit_operand) asm("_gen_split_188");
rtx
gen_split_188(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_189(rtx *emit_operand) asm("_gen_split_189");
rtx
gen_split_189(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashldi3_internal4(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashldi3_internal4");
rtx
gen_ashldi3_internal4(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFT, DImode,
 operand1,
 operand2));
}

rtx
gen_ashrsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashrsi3");
rtx
gen_ashrsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, SImode,
 operand1,
 operand2));
}

rtx
gen_ashrdi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashrdi3");
rtx
gen_ashrdi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx operand3;
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_ashrdi3_internal4 (emit_operand[0], emit_operand[1],
     emit_operand[2]));
      goto _done;
    }

  emit_operand[3] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashrdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashrdi3_internal");
rtx
gen_ashrdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_ashrdi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashrdi3_internal2");
rtx
gen_ashrdi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_195(rtx *emit_operand) asm("_gen_split_195");
rtx
gen_split_195(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 gen_rtx (CONST_INT, VOIDmode, (int) (31)))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_196(rtx *emit_operand) asm("_gen_split_196");
rtx
gen_split_196(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 gen_rtx (CONST_INT, VOIDmode, (int) (31)))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashrdi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_ashrdi3_internal3");
rtx
gen_ashrdi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_198(rtx *emit_operand) asm("_gen_split_198");
rtx
gen_split_198(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_199(rtx *emit_operand) asm("_gen_split_199");
rtx
gen_split_199(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (ASHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ashrdi3_internal4(rtx operand0, rtx operand1, rtx operand2) asm("_gen_ashrdi3_internal4");
rtx
gen_ashrdi3_internal4(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (ASHIFTRT, DImode,
 operand1,
 operand2));
}

rtx
gen_lshrsi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_lshrsi3");
rtx
gen_lshrsi3(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, SImode,
 operand1,
 operand2));
}

rtx
gen_lshrdi3(rtx operand0, rtx operand1, rtx operand2) asm("_gen_lshrdi3");
rtx
gen_lshrdi3(rtx operand0, rtx operand1, rtx operand2)
{
  rtx operand3;
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if ((target_flags & 0x00002000))
    {
      emit_insn (gen_lshrdi3_internal4 (emit_operand[0], emit_operand[1],
     emit_operand[2]));
      goto _done;
    }

  emit_operand[3] = gen_reg_rtx (SImode);
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_lshrdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_lshrdi3_internal");
rtx
gen_lshrdi3_internal(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_lshrdi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_lshrdi3_internal2");
rtx
gen_lshrdi3_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_205(rtx *emit_operand) asm("_gen_split_205");
rtx
gen_split_205(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 const0_rtx));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_206(rtx *emit_operand) asm("_gen_split_206");
rtx
gen_split_206(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();
emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, ((emit_operand[2])->fld[0].rtwint) & 0x1f);
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 const0_rtx));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_lshrdi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_lshrdi3_internal3");
rtx
gen_lshrdi3_internal3(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, DImode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_split_208(rtx *emit_operand) asm("_gen_split_208");
rtx
gen_split_208(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_split_209(rtx *emit_operand) asm("_gen_split_209");
rtx
gen_split_209(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx operand3;
  rtx operand4;
  rtx _val = 0;
  start_sequence ();

{
  int amount = ((emit_operand[2])->fld[0].rtwint);
  emit_operand[2] = gen_rtx (CONST_INT, VOIDmode, (amount & 31));
  emit_operand[4] = gen_rtx (CONST_INT, VOIDmode, ((-amount) & 31));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 1),
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand3,
 gen_rtx (ASHIFT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand4)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 gen_rtx (IOR, SImode,
 gen_rtx (SUBREG, SImode,
 operand0,
 1),
 operand3)));
  emit_insn (gen_rtx (SET, VOIDmode,
 gen_rtx (SUBREG, SImode,
 operand0,
 0),
 gen_rtx (LSHIFTRT, SImode,
 gen_rtx (SUBREG, SImode,
 operand1,
 0),
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_lshrdi3_internal4(rtx operand0, rtx operand1, rtx operand2) asm("_gen_lshrdi3_internal4");
rtx
gen_lshrdi3_internal4(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LSHIFTRT, DImode,
 operand1,
 operand2));
}

rtx
gen_cmpsi(rtx operand0, rtx operand1) asm("_gen_cmpsi");
rtx
gen_cmpsi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = emit_operand[1];
      branch_type = CMP_SI;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 gen_rtx (COMPARE, CCmode,
 operand0,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_tstsi(rtx operand0) asm("_gen_tstsi");
rtx
gen_tstsi(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = const0_rtx;
      branch_type = CMP_SI;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 operand0));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_cmpdi(rtx operand0, rtx operand1) asm("_gen_cmpdi");
rtx
gen_cmpdi(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = emit_operand[1];
      branch_type = CMP_DI;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 gen_rtx (COMPARE, CCmode,
 operand0,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_tstdi(rtx operand0) asm("_gen_tstdi");
rtx
gen_tstdi(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = const0_rtx;
      branch_type = CMP_DI;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 operand0));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_cmpdf(rtx operand0, rtx operand1) asm("_gen_cmpdf");
rtx
gen_cmpdf(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = emit_operand[1];
      branch_type = CMP_DF;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 gen_rtx (COMPARE, CC_FPmode,
 operand0,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_cmpsf(rtx operand0, rtx operand1) asm("_gen_cmpsf");
rtx
gen_cmpsf(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  if (emit_operand[0])
    {
      branch_cmp[0] = emit_operand[0];
      branch_cmp[1] = emit_operand[1];
      branch_type = CMP_SF;
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 gen_rtx (COMPARE, CC_FPmode,
 operand0,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_branch_fp_ne(rtx operand0, rtx operand1) asm("_gen_branch_fp_ne");
rtx
gen_branch_fp_ne(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (NE, CC_FPmode,
 gen_rtx (REG, CC_FPmode,
 67),
 const0_rtx),
 operand0,
 operand1));
}

rtx
gen_branch_fp_ne_rev(rtx operand0, rtx operand1) asm("_gen_branch_fp_ne_rev");
rtx
gen_branch_fp_ne_rev(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (NE, CC_REV_FPmode,
 gen_rtx (REG, CC_REV_FPmode,
 67),
 const0_rtx),
 operand0,
 operand1));
}

rtx
gen_branch_fp_eq(rtx operand0, rtx operand1) asm("_gen_branch_fp_eq");
rtx
gen_branch_fp_eq(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (EQ, CC_FPmode,
 gen_rtx (REG, CC_FPmode,
 67),
 const0_rtx),
 operand0,
 operand1));
}

rtx
gen_branch_fp_eq_rev(rtx operand0, rtx operand1) asm("_gen_branch_fp_eq_rev");
rtx
gen_branch_fp_eq_rev(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (EQ, CC_REV_FPmode,
 gen_rtx (REG, CC_REV_FPmode,
 67),
 const0_rtx),
 operand0,
 operand1));
}

rtx
gen_branch_zero(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_branch_zero");
rtx
gen_branch_zero(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (((operand0)->code), SImode,
  operand1,
  const0_rtx),
 operand2,
 operand3));
}

rtx
gen_branch_zero_di(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_branch_zero_di");
rtx
gen_branch_zero_di(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (((operand0)->code), DImode,
  operand1,
  const0_rtx),
 operand2,
 operand3));
}

rtx
gen_branch_equality(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4) asm("_gen_branch_equality");
rtx
gen_branch_equality(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (((operand0)->code), SImode,
  operand1,
  operand2),
 operand3,
 operand4));
}

rtx
gen_branch_equality_di(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4) asm("_gen_branch_equality_di");
rtx
gen_branch_equality_di(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (((operand0)->code), DImode,
  operand1,
  operand2),
 operand3,
 operand4));
}

rtx
gen_beq(rtx operand0) asm("_gen_beq");
rtx
gen_beq(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, EQ);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (EQ, CC_EQmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bne(rtx operand0) asm("_gen_bne");
rtx
gen_bne(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, NE);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (NE, CC_EQmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bgt(rtx operand0) asm("_gen_bgt");
rtx
gen_bgt(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, GT);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (GT, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bge(rtx operand0) asm("_gen_bge");
rtx
gen_bge(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, GE);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (GE, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_blt(rtx operand0) asm("_gen_blt");
rtx
gen_blt(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, LT);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (LT, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_ble(rtx operand0) asm("_gen_ble");
rtx
gen_ble(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, LE);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (LE, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bgtu(rtx operand0) asm("_gen_bgtu");
rtx
gen_bgtu(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, GTU);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (GTU, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bgeu(rtx operand0) asm("_gen_bgeu");
rtx
gen_bgeu(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, GEU);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (GEU, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bltu(rtx operand0) asm("_gen_bltu");
rtx
gen_bltu(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, LTU);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (LTU, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_bleu(rtx operand0) asm("_gen_bleu");
rtx
gen_bleu(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (emit_operand[0])
    {
      gen_conditional_branch (emit_operand, LEU);
      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (LEU, CCmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand0),
 pc_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_seq(rtx operand0) asm("_gen_seq");
rtx
gen_seq(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (EQ, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) < 0)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (EQ, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_seq_si_zero(rtx operand0, rtx operand1) asm("_gen_seq_si_zero");
rtx
gen_seq_si_zero(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (EQ, SImode,
 operand1,
 const0_rtx));
}

rtx
gen_seq_di_zero(rtx operand0, rtx operand1) asm("_gen_seq_di_zero");
rtx
gen_seq_di_zero(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (EQ, DImode,
 operand1,
 const0_rtx));
}

rtx
gen_seq_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_seq_si");
rtx
gen_seq_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (EQ, SImode,
 operand1,
 operand2));
}

rtx
gen_split_239(rtx *emit_operand) asm("_gen_split_239");
rtx
gen_split_239(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, SImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_seq_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_seq_di");
rtx
gen_seq_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (EQ, DImode,
 operand1,
 operand2));
}

rtx
gen_split_241(rtx *emit_operand) asm("_gen_split_241");
rtx
gen_split_241(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, DImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sne(rtx operand0) asm("_gen_sne");
rtx
gen_sne(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (NE, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) < 0)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NE, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sne_si_zero(rtx operand0, rtx operand1) asm("_gen_sne_si_zero");
rtx
gen_sne_si_zero(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NE, SImode,
 operand1,
 const0_rtx));
}

rtx
gen_sne_di_zero(rtx operand0, rtx operand1) asm("_gen_sne_di_zero");
rtx
gen_sne_di_zero(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NE, DImode,
 operand1,
 const0_rtx));
}

rtx
gen_sne_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sne_si");
rtx
gen_sne_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NE, SImode,
 operand1,
 operand2));
}

rtx
gen_split_246(rtx *emit_operand) asm("_gen_split_246");
rtx
gen_split_246(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GTU, SImode,
 operand0,
 const0_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sne_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sne_di");
rtx
gen_sne_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (NE, DImode,
 operand1,
 operand2));
}

rtx
gen_split_248(rtx *emit_operand) asm("_gen_split_248");
rtx
gen_split_248(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GTU, DImode,
 operand0,
 const0_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgt(rtx operand0) asm("_gen_sgt");
rtx
gen_sgt(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (GT, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) != 0)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GT, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgt_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgt_si");
rtx
gen_sgt_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GT, SImode,
 operand1,
 operand2));
}

rtx
gen_sgt_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgt_di");
rtx
gen_sgt_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GT, DImode,
 operand1,
 operand2));
}

rtx
gen_sge(rtx operand0) asm("_gen_sge");
rtx
gen_sge(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (GE, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GE, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sge_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sge_si");
rtx
gen_sge_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GE, SImode,
 operand1,
 operand2));
}

rtx
gen_split_254(rtx *emit_operand) asm("_gen_split_254");
rtx
gen_split_254(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, SImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sge_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sge_di");
rtx
gen_sge_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GE, DImode,
 operand1,
 operand2));
}

rtx
gen_split_256(rtx *emit_operand) asm("_gen_split_256");
rtx
gen_split_256(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, DImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_slt(rtx operand0) asm("_gen_slt");
rtx
gen_slt(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (LT, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_slt_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_slt_si");
rtx
gen_slt_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, SImode,
 operand1,
 operand2));
}

rtx
gen_slt_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_slt_di");
rtx
gen_slt_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, DImode,
 operand1,
 operand2));
}

rtx
gen_sle(rtx operand0) asm("_gen_sle");
rtx
gen_sle(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (LE, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) >= 32767)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LE, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sle_si_const(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sle_si_const");
rtx
gen_sle_si_const(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LE, SImode,
 operand1,
 operand2));
}

rtx
gen_sle_di_const(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sle_di_const");
rtx
gen_sle_di_const(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LE, DImode,
 operand1,
 operand2));
}

rtx
gen_sle_si_reg(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sle_si_reg");
rtx
gen_sle_si_reg(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LE, SImode,
 operand1,
 operand2));
}

rtx
gen_split_264(rtx *emit_operand) asm("_gen_split_264");
rtx
gen_split_264(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, SImode,
 operand2,
 operand1)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sle_di_reg(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sle_di_reg");
rtx
gen_sle_di_reg(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LE, DImode,
 operand1,
 operand2));
}

rtx
gen_split_266(rtx *emit_operand) asm("_gen_split_266");
rtx
gen_split_266(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LT, DImode,
 operand2,
 operand1)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgtu(rtx operand0) asm("_gen_sgtu");
rtx
gen_sgtu(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (GTU, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) != 0)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GTU, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgtu_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgtu_si");
rtx
gen_sgtu_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GTU, SImode,
 operand1,
 operand2));
}

rtx
gen_sgtu_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgtu_di");
rtx
gen_sgtu_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GTU, DImode,
 operand1,
 operand2));
}

rtx
gen_sgeu(rtx operand0) asm("_gen_sgeu");
rtx
gen_sgeu(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (GEU, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GEU, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgeu_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgeu_si");
rtx
gen_sgeu_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GEU, SImode,
 operand1,
 operand2));
}

rtx
gen_split_272(rtx *emit_operand) asm("_gen_split_272");
rtx
gen_split_272(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, SImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sgeu_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sgeu_di");
rtx
gen_sgeu_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (GEU, DImode,
 operand1,
 operand2));
}

rtx
gen_split_274(rtx *emit_operand) asm("_gen_split_274");
rtx
gen_split_274(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, DImode,
 operand1,
 operand2)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sltu(rtx operand0) asm("_gen_sltu");
rtx
gen_sltu(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (LTU, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sltu_si(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sltu_si");
rtx
gen_sltu_si(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, SImode,
 operand1,
 operand2));
}

rtx
gen_sltu_di(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sltu_di");
rtx
gen_sltu_di(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, DImode,
 operand1,
 operand2));
}

rtx
gen_sleu(rtx operand0) asm("_gen_sleu");
rtx
gen_sleu(rtx operand0)
{
  rtx operand1;
  rtx operand2;
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  if (branch_type != CMP_SI && (!(target_flags & 0x00002000) || branch_type != CMP_DI))
    goto _fail;


  emit_operand[1] = branch_cmp[0];
  emit_operand[2] = branch_cmp[1];

  if ((target_flags & 0x00002000) || !(target_flags & 0x08000000))
    {
      gen_int_relational (LEU, emit_operand[0], emit_operand[1], emit_operand[2], (int *)0);
      goto _done;
    }

  if (((emit_operand[2])->code) == CONST_INT && ((emit_operand[2])->fld[0].rtwint) >= 32767)
    emit_operand[2] = force_reg (SImode, emit_operand[2]);


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LEU, SImode,
 operand1,
 operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sleu_si_const(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sleu_si_const");
rtx
gen_sleu_si_const(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LEU, SImode,
 operand1,
 operand2));
}

rtx
gen_sleu_di_const(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sleu_di_const");
rtx
gen_sleu_di_const(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LEU, DImode,
 operand1,
 operand2));
}

rtx
gen_sleu_si_reg(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sleu_si_reg");
rtx
gen_sleu_si_reg(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LEU, SImode,
 operand1,
 operand2));
}

rtx
gen_split_282(rtx *emit_operand) asm("_gen_split_282");
rtx
gen_split_282(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, SImode,
 operand2,
 operand1)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, SImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_sleu_di_reg(rtx operand0, rtx operand1, rtx operand2) asm("_gen_sleu_di_reg");
rtx
gen_sleu_di_reg(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LEU, DImode,
 operand1,
 operand2));
}

rtx
gen_split_284(rtx *emit_operand) asm("_gen_split_284");
rtx
gen_split_284(rtx *emit_operand)
{
  rtx operand0;
  rtx operand1;
  rtx operand2;
  rtx _val = 0;
  start_sequence ();

  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (LTU, DImode,
 operand2,
 operand1)));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (XOR, DImode,
 operand0,
 const1_rtx)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_seq_df(rtx operand0, rtx operand1) asm("_gen_seq_df");
rtx
gen_seq_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (EQ, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sne_df(rtx operand0, rtx operand1) asm("_gen_sne_df");
rtx
gen_sne_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_REV_FPmode,
 67),
 gen_rtx (NE, CC_REV_FPmode,
 operand0,
 operand1));
}

rtx
gen_slt_df(rtx operand0, rtx operand1) asm("_gen_slt_df");
rtx
gen_slt_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (LT, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sle_df(rtx operand0, rtx operand1) asm("_gen_sle_df");
rtx
gen_sle_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (LE, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sgt_df(rtx operand0, rtx operand1) asm("_gen_sgt_df");
rtx
gen_sgt_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (GT, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sge_df(rtx operand0, rtx operand1) asm("_gen_sge_df");
rtx
gen_sge_df(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (GE, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_seq_sf(rtx operand0, rtx operand1) asm("_gen_seq_sf");
rtx
gen_seq_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (EQ, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sne_sf(rtx operand0, rtx operand1) asm("_gen_sne_sf");
rtx
gen_sne_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_REV_FPmode,
 67),
 gen_rtx (NE, CC_REV_FPmode,
 operand0,
 operand1));
}

rtx
gen_slt_sf(rtx operand0, rtx operand1) asm("_gen_slt_sf");
rtx
gen_slt_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (LT, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sle_sf(rtx operand0, rtx operand1) asm("_gen_sle_sf");
rtx
gen_sle_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (LE, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sgt_sf(rtx operand0, rtx operand1) asm("_gen_sgt_sf");
rtx
gen_sgt_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (GT, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_sge_sf(rtx operand0, rtx operand1) asm("_gen_sge_sf");
rtx
gen_sge_sf(rtx operand0, rtx operand1)
{
  return gen_rtx (SET, VOIDmode,
 gen_rtx (REG, CC_FPmode,
 67),
 gen_rtx (GE, CC_FPmode,
 operand0,
 operand1));
}

rtx
gen_jump(rtx operand0) asm("_gen_jump");
rtx
gen_jump(rtx operand0)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (LABEL_REF, VOIDmode,
 operand0));
}

rtx
gen_indirect_jump(rtx operand0) asm("_gen_indirect_jump");
rtx
gen_indirect_jump(rtx operand0)
{
  rtx emit_operand[1];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;

{
  rtx dest;

  if (emit_operand[0])
    {
      dest = emit_operand[0];
      if (((dest)->code) != REG || ((dest)->mode) != ((target_flags & 0x00000002) ? DImode : SImode))
 emit_operand[0] = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), dest);

      if (!(target_flags & 0x00000002))
 emit_jump_insn (gen_indirect_jump_internal1 (emit_operand[0]));
      else
 emit_jump_insn (gen_indirect_jump_internal2 (emit_operand[0]));

      goto _done;
    }
}
  operand0 = emit_operand[0];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_indirect_jump_internal1(rtx operand0) asm("_gen_indirect_jump_internal1");
rtx
gen_indirect_jump_internal1(rtx operand0)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0);
}

rtx
gen_indirect_jump_internal2(rtx operand0) asm("_gen_indirect_jump_internal2");
rtx
gen_indirect_jump_internal2(rtx operand0)
{
  return gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0);
}

rtx
gen_tablejump(rtx operand0, rtx operand1) asm("_gen_tablejump");
rtx
gen_tablejump(rtx operand0, rtx operand1)
{
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;

{
  rtx dest;

  if (emit_operand[0])
    {
      if (((emit_operand[0])->mode) != ((target_flags & 0x00000002) ? DImode : SImode))
 abort ();

      if (!(target_flags & 0x00000002))
 emit_jump_insn (gen_tablejump_internal1 (emit_operand[0], emit_operand[1]));
      else
 emit_jump_insn (gen_tablejump_internal2 (emit_operand[0], emit_operand[1]));

      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0));
  emit_insn (gen_rtx (USE, VOIDmode,
 gen_rtx (LABEL_REF, VOIDmode,
 operand1)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_tablejump_internal1(rtx operand0, rtx operand1) asm("_gen_tablejump_internal1");
rtx
gen_tablejump_internal1(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0),
  gen_rtx (USE, VOIDmode,
 gen_rtx (LABEL_REF, VOIDmode,
 operand1))));
}

rtx
gen_tablejump_internal2(rtx operand0, rtx operand1) asm("_gen_tablejump_internal2");
rtx
gen_tablejump_internal2(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 pc_rtx,
 operand0),
  gen_rtx (USE, VOIDmode,
 gen_rtx (LABEL_REF, VOIDmode,
 operand1))));
}

rtx
gen_return(void) asm("_gen_return");
rtx
gen_return(void)
{
  return gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (RETURN, VOIDmode),
  gen_rtx (USE, VOIDmode,
 gen_rtx (REG, SImode,
 31))));
}

rtx
gen_return_internal(rtx operand0) asm("_gen_return_internal");
rtx
gen_return_internal(rtx operand0)
{
  return gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (2,
  gen_rtx (RETURN, VOIDmode),
  gen_rtx (USE, VOIDmode,
 operand0)));
}

rtx
gen_casesi(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4) asm("_gen_casesi");
rtx
gen_casesi(rtx operand0, rtx operand1, rtx operand2, rtx operand3, rtx operand4)
{
  rtx operand5;
  rtx emit_operand[6];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;
  emit_operand[4] = operand4;

{

  if ((target_flags & 0x00000002))
    abort ();

  if (emit_operand[0])
    {
      rtx reg = gen_reg_rtx (SImode);


      emit_insn (gen_subsi3 (reg, emit_operand[0], emit_operand[1]));
      emit_insn (gen_cmpsi (reg, emit_operand[2]));
      emit_insn (gen_bgtu (emit_operand[4]));


      emit_insn (gen_casesi_internal (reg, emit_operand[3], gen_reg_rtx (SImode)));

      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  operand5 = emit_operand[5];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand5,
 gen_rtx (MINUS, SImode,
 operand0,
 operand1)));
  emit_insn (gen_rtx (SET, VOIDmode,
 cc0_rtx,
 gen_rtx (COMPARE, CCmode,
 operand5,
 operand2)));
  emit_jump_insn (gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (IF_THEN_ELSE, VOIDmode,
 gen_rtx (GTU, VOIDmode,
 cc0_rtx,
 const0_rtx),
 gen_rtx (LABEL_REF, VOIDmode,
 operand4),
 pc_rtx)));
  emit_jump_insn (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (MEM, SImode,
 gen_rtx (PLUS, SImode,
 gen_rtx (MULT, SImode,
 operand5,
 gen_rtx (CONST_INT, VOIDmode, (int) (4))),
 gen_rtx (LABEL_REF, VOIDmode,
 operand3)))),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31)))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_casesi_internal(rtx operand0, rtx operand1, rtx operand2) asm("_gen_casesi_internal");
rtx
gen_casesi_internal(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 pc_rtx,
 gen_rtx (MEM, SImode,
 gen_rtx (PLUS, SImode,
 gen_rtx (MULT, SImode,
 operand0,
 gen_rtx (CONST_INT, VOIDmode, (int) (4))),
 gen_rtx (LABEL_REF, VOIDmode,
 operand1)))),
  gen_rtx (CLOBBER, VOIDmode,
 operand2),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31))));
}

rtx
gen_prologue(void) asm("_gen_prologue");
rtx
gen_prologue(void)
{
  rtx _val = 0;
  start_sequence ();

{
  if (mips_isa >= 0)
    {
      mips_expand_prologue ();
      goto _done;
    }
}
  emit_insn (const1_rtx);
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_blockage(void) asm("_gen_blockage");
rtx
gen_blockage(void)
{
  return gen_rtx (UNSPEC_VOLATILE, VOIDmode,
 gen_rtvec (1,
  const0_rtx),
 0);
}

rtx
gen_get_fnaddr(rtx operand0, rtx operand1) asm("_gen_get_fnaddr");
rtx
gen_get_fnaddr(rtx operand0, rtx operand1)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (UNSPEC, VOIDmode,
 gen_rtvec (1,
  operand1),
 1)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31))));
}

rtx
gen_call(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call");
rtx
gen_call(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{
  rtx addr;

  if (emit_operand[0])
    {
      addr = ((emit_operand[0])->fld[0].rtx);
      if ((((addr)->code) != REG && (!((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == HIGH || (((addr)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (addr)) && ! 0)) && (!0 || !0)) || (target_flags & 0x00001000)))
   || ! call_insn_operand (emit_operand[0], VOIDmode))
 ((emit_operand[0])->fld[0].rtx) = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), addr);
      if (emit_operand[2] != (rtx)0 && ((emit_operand[2])->code) == PARALLEL)
 {
   rtvec adjust = ((emit_operand[2])->fld[0].rtvec);
   int num = ((adjust)->num_elem);
   int i;

   for (i = 0; i < num; i++)
     emit_insn (((adjust)->elem[(i)].rtx));
 }

      emit_call_insn (gen_call_internal1 (emit_operand[0], emit_operand[1],
       gen_rtx (REG, SImode, 0 + 31)));
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_call_insn (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (4,
  gen_rtx (CALL, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31)),
  gen_rtx (USE, VOIDmode,
 operand2),
  gen_rtx (USE, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_call_internal1(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal1");
rtx
gen_call_internal1(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_internal2(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal2");
rtx
gen_call_internal2(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 operand0,
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_internal3a(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal3a");
rtx
gen_call_internal3a(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, SImode,
 operand0),
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_internal3b(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal3b");
rtx
gen_call_internal3b(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, DImode,
 operand0),
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_internal4a(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal4a");
rtx
gen_call_internal4a(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, SImode,
 operand0),
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_internal4b(rtx operand0, rtx operand1, rtx operand2) asm("_gen_call_internal4b");
rtx
gen_call_internal4b(rtx operand0, rtx operand1, rtx operand2)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, DImode,
 operand0),
 operand1),
  gen_rtx (CLOBBER, VOIDmode,
 operand2)));
}

rtx
gen_call_value(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value");
rtx
gen_call_value(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx emit_operand[4];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{
  rtx addr;

  if (emit_operand[0])
    {
      addr = ((emit_operand[1])->fld[0].rtx);
      if ((((addr)->code) != REG && (!((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == HIGH || (((addr)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (addr)) && ! 0)) && (!0 || !0)) || (target_flags & 0x00001000)))
   || ! call_insn_operand (emit_operand[1], VOIDmode))
 ((emit_operand[1])->fld[0].rtx) = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), addr);
      if (emit_operand[3] != (rtx)0 && ((emit_operand[3])->code) == PARALLEL)
 {
   rtvec adjust = ((emit_operand[3])->fld[0].rtvec);
   int num = ((adjust)->num_elem);
   int i;

   for (i = 0; i < num; i++)
     emit_insn (((adjust)->elem[(i)].rtx));
 }

      emit_call_insn (gen_call_value_internal1 (emit_operand[0], emit_operand[1], emit_operand[2],
             gen_rtx (REG, SImode, 0 + 31)));

      goto _done;
    }

}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  emit_call_insn (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (3,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31)),
  gen_rtx (USE, VOIDmode,
 operand3))));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_call_value_internal1(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal1");
rtx
gen_call_value_internal1(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_call_value_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal2");
rtx
gen_call_value_internal2(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 operand1,
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_call_value_internal3a(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal3a");
rtx
gen_call_value_internal3a(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, SImode,
 operand1),
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_call_value_internal3b(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal3b");
rtx
gen_call_value_internal3b(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, DImode,
 operand1),
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_call_value_internal4a(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal4a");
rtx
gen_call_value_internal4a(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, SImode,
 operand1),
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_call_value_internal4b(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_call_value_internal4b");
rtx
gen_call_value_internal4b(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec (2,
  gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (CALL, VOIDmode,
 gen_rtx (MEM, DImode,
 operand1),
 operand2)),
  gen_rtx (CLOBBER, VOIDmode,
 operand3)));
}

rtx
gen_untyped_call(rtx operand0, rtx operand1, rtx operand2) asm("_gen_untyped_call");
rtx
gen_untyped_call(rtx operand0, rtx operand1, rtx operand2)
{
  rtx emit_operand[3];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;

{
  if (emit_operand[0])
    {
      int i;

      emit_call_insn (gen_call (emit_operand[0], const0_rtx, 
                                                        ((void *)0)
                                                            , const0_rtx));

      for (i = 0; i < ((emit_operand[2])->fld[0].rtvec->num_elem); i++)
 {
   rtx set = ((emit_operand[2])->fld[0].rtvec->elem[i].rtx);
   emit_move_insn (((set)->fld[0].rtx), ((set)->fld[1].rtx));
 }

      emit_insn (gen_blockage ());
      goto _done;
    }
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  emit_call_insn (gen_rtx (PARALLEL, VOIDmode,
 gen_rtvec (3,
  gen_rtx (CALL, VOIDmode,
 operand0,
 const0_rtx),
  operand1,
  operand2)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_nop(void) asm("_gen_nop");
rtx
gen_nop(void)
{
  return const0_rtx;
}

rtx
gen_probe(void) asm("_gen_probe");
rtx
gen_probe(void)
{
  rtx operand0;
  rtx operand1;
  rtx emit_operand[2];
  rtx _val = 0;
  start_sequence ();

{
  emit_operand[0] = gen_reg_rtx (SImode);
  emit_operand[1] = gen_rtx (MEM, SImode, stack_pointer_rtx);
  ((emit_operand[1])->volatil) = 1;


}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 operand1));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}

rtx
gen_movsicc(rtx operand0, rtx operand1, rtx operand2, rtx operand3) asm("_gen_movsicc");
rtx
gen_movsicc(rtx operand0, rtx operand1, rtx operand2, rtx operand3)
{
  rtx operand4;
  rtx operand5;
  rtx emit_operand[6];
  rtx _val = 0;
  start_sequence ();
  emit_operand[0] = operand0;
  emit_operand[1] = operand1;
  emit_operand[2] = operand2;
  emit_operand[3] = operand3;

{
  rtx op0 = branch_cmp[0];
  rtx op1 = branch_cmp[1];
  n64_enum_machine_mode mode = ((branch_cmp[0])->mode);
  n64_enum_rtx_code compare_code = ((emit_operand[1])->code);
  n64_enum_rtx_code move_code = NE;

  if ((mode_class[(int)(mode)]) != MODE_FLOAT)
    {
      switch (compare_code)
 {
 case EQ:
   compare_code = XOR;
   move_code = EQ;
   break;
 case NE:
   compare_code = XOR;
   break;
 case LT:
   break;
 case GE:
   compare_code = LT;
   move_code = EQ;
   break;
 case GT:
   compare_code = LT;
   op0 = force_reg (mode, branch_cmp[1]);
   op1 = branch_cmp[0];
   break;
 case LE:
   compare_code = LT;
   op0 = force_reg (mode, branch_cmp[1]);
   op1 = branch_cmp[0];
   move_code = EQ;
   break;
 case LTU:
   break;
 case GEU:
   compare_code = LTU;
   move_code = EQ;
   break;
 case GTU:
   compare_code = LTU;
   op0 = force_reg (mode, branch_cmp[1]);
   op1 = branch_cmp[0];
   break;
 case LEU:
   compare_code = LTU;
   op0 = force_reg (mode, branch_cmp[1]);
   op1 = branch_cmp[0];
   move_code = EQ;
   break;
 default:
   abort ();
 }
    }
  else
    {
      if (compare_code == NE)
 {

   compare_code = EQ;
   move_code = EQ;
 }
    }

  if (mode == SImode || mode == DImode)
    {
      emit_operand[1] = gen_rtx (compare_code, mode, op0, op1);
      emit_operand[4] = gen_reg_rtx (mode);
    }
  else if (mode == SFmode || mode == DFmode)
    {
      emit_operand[1] = gen_rtx (compare_code, CC_FPmode, op0, op1);
      emit_operand[4] = gen_rtx (REG, CC_FPmode, 67);
    }

  if (mode == DImode)
    emit_operand[5] = gen_rtx (move_code, VOIDmode,
      gen_lowpart (SImode, emit_operand[4]),
      (const_tiny_rtx[0][(int) (SImode)]));
  else
    emit_operand[5] = gen_rtx (move_code, VOIDmode, emit_operand[4],
      (const_tiny_rtx[0][(int) (SImode)]));
}
  operand0 = emit_operand[0];
  operand1 = emit_operand[1];
  operand2 = emit_operand[2];
  operand3 = emit_operand[3];
  operand4 = emit_operand[4];
  operand5 = emit_operand[5];
  emit_insn (gen_rtx (SET, VOIDmode,
 operand4,
 operand1));
  emit_insn (gen_rtx (SET, VOIDmode,
 operand0,
 gen_rtx (IF_THEN_ELSE, SImode,
 operand5,
 operand2,
 operand3)));
 _done:
  _val = gen_sequence ();
 _fail:
  end_sequence ();
  return _val;
}



void
add_clobbers(rtx pattern, int insn_code_number) asm("_add_clobbers");
void
add_clobbers(rtx pattern, int insn_code_number)
{
  int i;

  switch (insn_code_number)
    {
    case 310:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31));
      break;

    case 307:
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, SImode,
 31));
      break;

    case 175:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (REG, DImode,
 1));
      break;

    case 136:
    case 135:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DFmode, 0));
      break;

    case 134:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SFmode, 0));
      break;

    case 133:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DFmode, 0));
      break;

    case 63:
    case 61:
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      ((pattern)->fld[0].rtvec->elem[3].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      ((pattern)->fld[0].rtvec->elem[4].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      break;

    case 62:
    case 60:
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[3].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[4].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      break;

    case 48:
    case 46:
    case 40:
    case 36:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      break;

    case 71:
    case 69:
    case 67:
    case 65:
    case 34:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      ((pattern)->fld[0].rtvec->elem[3].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      break;

    case 79:
    case 49:
    case 47:
    case 44:
    case 43:
    case 41:
    case 37:
    case 33:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, DImode, 0));
      break;

    case 70:
    case 68:
    case 66:
    case 64:
    case 31:
    case 30:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[3].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      break;

    case 78:
    case 45:
    case 42:
    case 38:
    case 29:
      ((pattern)->fld[0].rtvec->elem[1].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      ((pattern)->fld[0].rtvec->elem[2].rtx) = gen_rtx (CLOBBER, VOIDmode,
 gen_rtx (SCRATCH, SImode, 0));
      break;

    default:
      abort ();
    }
}

void
init_mov_optab(void) asm("_init_mov_optab");
void
init_mov_optab(void)
{
}

