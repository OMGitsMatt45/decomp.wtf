// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/bc-optab.c
/* Bytecode conversion definitions for GNU C-compiler.
   Copyright (C) 1993, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int bc_emit_instruction(...) asm("_bc_emit_instruction");
extern int bc_init_mode_to_opcode_maps(...) asm("_bc_init_mode_to_opcode_maps");
struct n64_tag__obstack_chunk;
struct n64_tag_binary_operator;
struct n64_tag_conversion_info;
struct n64_tag_conversion_list;
struct n64_tag_conversion_recipe;
struct n64_tag_increment_operator;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
union n64_tag_real_extract;
struct n64_tag_rl;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_unary_operator;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");
enum n64_cpp_enum_typecode{

QIcode,
QUcode,
HIcode,
HUcode,
SIcode,
SUcode,
DIcode,
DUcode,
SFcode,
DFcode,
XFcode,
Pcode,
Tcode,


  LAST_AND_UNUSED_TYPECODE
};
typedef __underlying_type(enum n64_cpp_enum_typecode) n64_enum_typecode;




enum n64_cpp_enum_bytecode_opcode{ neverneverland,
  drop,
  duplicate,
  over,
  setstackSI,
  adjstackSI,
  constQI,
  constHI,
  constSI,
  constDI,
  constSF,
  constDF,
  constXF,
  constP,
  loadQI,
  loadHI,
  loadSI,
  loadDI,
  loadSF,
  loadDF,
  loadXF,
  loadP,
  storeQI,
  storeHI,
  storeSI,
  storeDI,
  storeSF,
  storeDF,
  storeXF,
  storeP,
  storeBLK,
  clearBLK,
  addconstPSI,
  newlocalSI,
  localP,
  argP,
  convertQIHI,
  convertHISI,
  convertSIDI,
  convertQISI,
  convertQUHU,
  convertHUSU,
  convertSUDU,
  convertQUSU,
  convertSFDF,
  convertDFXF,
  convertHIQI,
  convertSIHI,
  convertDISI,
  convertSIQI,
  convertSUQU,
  convertDFSF,
  convertXFDF,
  convertSISF,
  convertSIDF,
  convertSIXF,
  convertSUSF,
  convertSUDF,
  convertSUXF,
  convertDISF,
  convertDIDF,
  convertDIXF,
  convertDUSF,
  convertDUDF,
  convertDUXF,
  convertSFSI,
  convertDFSI,
  convertXFSI,
  convertSFSU,
  convertDFSU,
  convertXFSU,
  convertSFDI,
  convertDFDI,
  convertXFDI,
  convertSFDU,
  convertDFDU,
  convertXFDU,
  convertPSI,
  convertSIP,
  convertSIT,
  convertDIT,
  convertSFT,
  convertDFT,
  convertXFT,
  convertPT,
  zxloadBI,
  sxloadBI,
  sstoreBI,
  addSI,
  addDI,
  addSF,
  addDF,
  addXF,
  addPSI,
  subSI,
  subDI,
  subSF,
  subDF,
  subXF,
  subPP,
  mulSI,
  mulDI,
  mulSU,
  mulDU,
  mulSF,
  mulDF,
  mulXF,
  divSI,
  divDI,
  divSU,
  divDU,
  divSF,
  divDF,
  divXF,
  modSI,
  modDI,
  modSU,
  modDU,
  andSI,
  andDI,
  iorSI,
  iorDI,
  xorSI,
  xorDI,
  lshiftSI,
  lshiftSU,
  lshiftDI,
  lshiftDU,
  rshiftSI,
  rshiftSU,
  rshiftDI,
  rshiftDU,
  ltSI,
  ltSU,
  ltDI,
  ltDU,
  ltSF,
  ltDF,
  ltXF,
  ltP,
  leSI,
  leSU,
  leDI,
  leDU,
  leSF,
  leDF,
  leXF,
  leP,
  geSI,
  geSU,
  geDI,
  geDU,
  geSF,
  geDF,
  geXF,
  geP,
  gtSI,
  gtSU,
  gtDI,
  gtDU,
  gtSF,
  gtDF,
  gtXF,
  gtP,
  eqSI,
  eqDI,
  eqSF,
  eqDF,
  eqXF,
  eqP,
  neSI,
  neDI,
  neSF,
  neDF,
  neXF,
  neP,
  negSI,
  negDI,
  negSF,
  negDF,
  negXF,
  notSI,
  notDI,
  notT,
  predecQI,
  predecHI,
  predecSI,
  predecDI,
  predecP,
  predecSF,
  predecDF,
  predecXF,
  predecBI,
  preincQI,
  preincHI,
  preincSI,
  preincDI,
  preincP,
  preincSF,
  preincDF,
  preincXF,
  preincBI,
  postdecQI,
  postdecHI,
  postdecSI,
  postdecDI,
  postdecP,
  postdecSF,
  postdecDF,
  postdecXF,
  postdecBI,
  postincQI,
  postincHI,
  postincSI,
  postincDI,
  postincP,
  postincSF,
  postincDF,
  postincXF,
  postincBI,
  xjumpif,
  xjumpifnot,
  jump,
  jumpP,
  caseSI,
  caseSU,
  caseDI,
  caseDU,
  call,
  returnP,
  ret,
  linenote,
  LAST_AND_UNUSED_OPCODE
};
typedef __underlying_type(enum n64_cpp_enum_bytecode_opcode) n64_enum_bytecode_opcode;

extern void bc_expand_conversion(...) asm("_bc_expand_conversion");
extern void bc_expand_truth_conversion(...) asm("_bc_expand_truth_conversion");
extern void bc_expand_binary_operation(...) asm("_bc_expand_binary_operation");
extern void bc_expand_unary_operation(...) asm("_bc_expand_unary_operation");

struct n64_tag_binary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
  n64_enum_typecode arg1;
};

extern struct n64_tag_binary_operator optab_plus_expr[];
extern struct n64_tag_binary_operator optab_minus_expr[];
extern struct n64_tag_binary_operator optab_mult_expr[];
extern struct n64_tag_binary_operator optab_trunc_div_expr[];
extern struct n64_tag_binary_operator optab_trunc_mod_expr[];
extern struct n64_tag_binary_operator optab_rdiv_expr[];
extern struct n64_tag_binary_operator optab_bit_and_expr[];
extern struct n64_tag_binary_operator optab_bit_ior_expr[];
extern struct n64_tag_binary_operator optab_bit_xor_expr[];
extern struct n64_tag_binary_operator optab_lshift_expr[];
extern struct n64_tag_binary_operator optab_rshift_expr[];
extern struct n64_tag_binary_operator optab_truth_and_expr[];
extern struct n64_tag_binary_operator optab_truth_or_expr[];
extern struct n64_tag_binary_operator optab_lt_expr[];
extern struct n64_tag_binary_operator optab_le_expr[];
extern struct n64_tag_binary_operator optab_ge_expr[];
extern struct n64_tag_binary_operator optab_gt_expr[];
extern struct n64_tag_binary_operator optab_eq_expr[];
extern struct n64_tag_binary_operator optab_ne_expr[];

struct n64_tag_unary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
};

extern struct n64_tag_unary_operator optab_negate_expr[];
extern struct n64_tag_unary_operator optab_bit_not_expr[];
extern struct n64_tag_unary_operator optab_truth_not_expr[];

struct n64_tag_increment_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode arg;
};

extern struct n64_tag_increment_operator optab_predecrement_expr[];
extern struct n64_tag_increment_operator optab_preincrement_expr[];
extern struct n64_tag_increment_operator optab_postdecrement_expr[];
extern struct n64_tag_increment_operator optab_postincrement_expr[];




extern char *xmalloc(...) asm("_xmalloc");
extern void free(...) asm("_free");



n64_enum_machine_mode typecode_mode[] = {

QImode,
QImode,
HImode,
HImode,
SImode,
SImode,
DImode,
DImode,
SFmode,
DFmode,
XFmode,
PSImode,
SImode,

};


static n64_enum_typecode signed_mode_to_code_map[MAX_MACHINE_MODE+1];
static n64_enum_typecode unsigned_mode_to_code_map[MAX_MACHINE_MODE+1];







static struct n64_tag_conversion_recipe
{
  unsigned char *opcodes;
  int nopcodes;
  int cost;
} conversion_recipe[((int) LAST_AND_UNUSED_TYPECODE)][((int) LAST_AND_UNUSED_TYPECODE)];


struct n64_tag_binary_operator optab_plus_expr[] = {
  { addSI, SIcode, SIcode, SIcode },
  { addDI, DIcode, DIcode, DIcode },
  { addSF, SFcode, SFcode, SFcode },
  { addDF, DFcode, DFcode, DFcode },
  { addXF, XFcode, XFcode, XFcode },
  { addPSI, Pcode, Pcode, SIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_minus_expr[] = {
  { subSI, SIcode, SIcode, SIcode },
  { subDI, DIcode, DIcode, DIcode },
  { subSF, SFcode, SFcode, SFcode },
  { subDF, DFcode, DFcode, DFcode },
  { subXF, XFcode, XFcode, XFcode },
  { subPP, SIcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};





struct n64_tag_binary_operator optab_mult_expr[] = {
  { mulSU, SUcode, SUcode, SUcode },
  { mulDU, DUcode, DUcode, DUcode },
  { mulSI, SIcode, SIcode, SIcode },
  { mulDI, DIcode, DIcode, DIcode },
  { mulSF, SFcode, SFcode, SFcode },
  { mulDF, DFcode, DFcode, DFcode },
  { mulXF, XFcode, XFcode, XFcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_trunc_div_expr[] = {
  { divSU, SUcode, SUcode, SUcode },
  { divDU, DUcode, DUcode, DUcode },
  { divSI, SIcode, SIcode, SIcode },
  { divDI, DIcode, DIcode, DIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_trunc_mod_expr[] = {
  { modSU, SUcode, SUcode, SUcode },
  { modDU, DUcode, DUcode, DUcode },
  { modSI, SIcode, SIcode, SIcode },
  { modDI, DIcode, DIcode, DIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_rdiv_expr[] = {
  { divSF, SFcode, SFcode, SFcode },
  { divDF, DFcode, DFcode, DFcode },
  { divXF, XFcode, XFcode, XFcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_bit_and_expr[] = {
  { andSI, SIcode, SIcode, SIcode },
  { andDI, DIcode, DIcode, DIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_bit_ior_expr[] = {
  { iorSI, SIcode, SIcode, SIcode },
  { iorDI, DIcode, DIcode, DIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_bit_xor_expr[] = {
  { xorSI, SIcode, SIcode, SIcode },
  { xorDI, DIcode, DIcode, DIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_lshift_expr[] = {
  { lshiftSI, SIcode, SIcode, SIcode },
  { lshiftSU, SUcode, SUcode, SIcode },
  { lshiftDI, DIcode, DIcode, SIcode },
  { lshiftDU, DUcode, DUcode, SIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_rshift_expr[] = {
  { rshiftSI, SIcode, SIcode, SIcode },
  { rshiftSU, SUcode, SUcode, SIcode },
  { rshiftDI, DIcode, DIcode, SIcode },
  { rshiftDU, DUcode, DUcode, SIcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_truth_and_expr[] = {
  { andSI, SIcode, Tcode, Tcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_truth_or_expr[] = {
  { iorSI, SIcode, Tcode, Tcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_lt_expr[] = {
  { ltSI, Tcode, SIcode, SIcode },
  { ltSU, Tcode, SUcode, SUcode },
  { ltDI, Tcode, DIcode, DIcode },
  { ltDU, Tcode, DUcode, DUcode },
  { ltSF, Tcode, SFcode, SFcode },
  { ltDF, Tcode, DFcode, DFcode },
  { ltXF, Tcode, XFcode, XFcode },
  { ltP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_le_expr[] = {
  { leSI, Tcode, SIcode, SIcode },
  { leSU, Tcode, SUcode, SUcode },
  { leDI, Tcode, DIcode, DIcode },
  { leDU, Tcode, DUcode, DUcode },
  { leSF, Tcode, SFcode, SFcode },
  { leDF, Tcode, DFcode, DFcode },
  { leXF, Tcode, XFcode, XFcode },
  { leP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_ge_expr[] = {
  { geSI, Tcode, SIcode, SIcode },
  { geSU, Tcode, SUcode, SUcode },
  { geDI, Tcode, DIcode, DIcode },
  { geDU, Tcode, DUcode, DUcode },
  { geSF, Tcode, SFcode, SFcode },
  { geDF, Tcode, DFcode, DFcode },
  { geXF, Tcode, XFcode, XFcode },
  { geP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_gt_expr[] = {
  { gtSI, Tcode, SIcode, SIcode },
  { gtSU, Tcode, SUcode, SUcode },
  { gtDI, Tcode, DIcode, DIcode },
  { gtDU, Tcode, DUcode, DUcode },
  { gtSF, Tcode, SFcode, SFcode },
  { gtDF, Tcode, DFcode, DFcode },
  { gtXF, Tcode, XFcode, XFcode },
  { gtP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_eq_expr[] = {
  { eqSI, Tcode, SIcode, SIcode },
  { eqDI, Tcode, DIcode, DIcode },
  { eqSF, Tcode, SFcode, SFcode },
  { eqDF, Tcode, DFcode, DFcode },
  { eqXF, Tcode, XFcode, XFcode },
  { eqP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};

struct n64_tag_binary_operator optab_ne_expr[] = {
  { neSI, Tcode, SIcode, SIcode },
  { neDI, Tcode, DIcode, DIcode },
  { neSF, Tcode, SFcode, SFcode },
  { neDF, Tcode, DFcode, DFcode },
  { neXF, Tcode, XFcode, XFcode },
  { neP, Tcode, Pcode, Pcode },
  { -1, -1, -1, -1 },
};


struct n64_tag_unary_operator optab_negate_expr[] = {
  { negSI, SIcode, SIcode },
  { negDI, DIcode, DIcode },
  { negSF, SFcode, SFcode },
  { negDF, DFcode, DFcode },
  { negXF, XFcode, XFcode },
  { -1, -1, -1 },
};

struct n64_tag_unary_operator optab_bit_not_expr[] = {
  { notSI, SIcode, SIcode },
  { notDI, DIcode, DIcode },
  { -1, -1, -1 },
};

struct n64_tag_unary_operator optab_truth_not_expr[] = {
  { notT, SIcode, SIcode },
  { -1, -1, -1 },
};


struct n64_tag_increment_operator optab_predecrement_expr[] = {
  { predecQI, QIcode },
  { predecQI, QUcode },
  { predecHI, HIcode },
  { predecHI, HUcode },
  { predecSI, SIcode },
  { predecSI, SUcode },
  { predecDI, DIcode },
  { predecDI, DUcode },
  { predecP, Pcode },
  { predecSF, SFcode },
  { predecDF, DFcode },
  { predecXF, XFcode },
  { -1, -1 },
};

struct n64_tag_increment_operator optab_preincrement_expr[] = {
  { preincQI, QIcode },
  { preincQI, QUcode },
  { preincHI, HIcode },
  { preincHI, HUcode },
  { preincSI, SIcode },
  { preincSI, SUcode },
  { preincDI, DIcode },
  { preincDI, DUcode },
  { preincP, Pcode },
  { preincSF, SFcode },
  { preincDF, DFcode },
  { preincXF, XFcode },
  { -1, -1 },
};

struct n64_tag_increment_operator optab_postdecrement_expr[] = {
  { postdecQI, QIcode },
  { postdecQI, QUcode },
  { postdecHI, HIcode },
  { postdecHI, HUcode },
  { postdecSI, SIcode },
  { postdecSI, SUcode },
  { postdecDI, DIcode },
  { postdecDI, DUcode },
  { postdecP, Pcode },
  { postdecSF, SFcode },
  { postdecDF, DFcode },
  { postdecXF, XFcode },
  { -1, -1 },
};

struct n64_tag_increment_operator optab_postincrement_expr[] = {
  { postincQI, QIcode },
  { postincQI, QUcode },
  { postincHI, HIcode },
  { postincHI, HUcode },
  { postincSI, SIcode },
  { postincSI, SUcode },
  { postincDI, DIcode },
  { postincDI, DUcode },
  { postincP, Pcode },
  { postincSF, SFcode },
  { postincDF, DFcode },
  { postincXF, XFcode },
  { -1, -1 },
};


static struct n64_tag_conversion_info
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode from;
  n64_enum_typecode to;
  int cost;

} conversion_info[] = {
  { -1, QIcode, QUcode, 1 },
  { -1, HIcode, HUcode, 1 },
  { -1, SIcode, SUcode, 1 },
  { -1, DIcode, DUcode, 1 },
  { -1, QUcode, QIcode, 1 },
  { -1, HUcode, HIcode, 1 },
  { -1, SUcode, SIcode, 1 },
  { -1, DUcode, DIcode, 1 },
  { -1, Tcode, SIcode, 1 },
  { convertQIHI, QIcode, HIcode, 2 },
  { convertQUHU, QUcode, HUcode, 2 },
  { convertQUSU, QUcode, SUcode, 2 },
  { convertHISI, HIcode, SIcode, 2 },
  { convertHUSU, HUcode, SUcode, 2 },
  { convertSIDI, SIcode, DIcode, 2 },
  { convertSUDU, SUcode, DUcode, 2 },
  { convertSFDF, SFcode, DFcode, 2 },
  { convertDFXF, DFcode, XFcode, 2 },
  { convertHIQI, HIcode, QIcode, 8 },
  { convertSIQI, SIcode, QIcode, 8 },
  { convertSIHI, SIcode, HIcode, 8 },
  { convertSUQU, SUcode, QUcode, 8 },
  { convertDISI, DIcode, SIcode, 8 },
  { convertDFSF, DFcode, SFcode, 8 },
  { convertXFDF, XFcode, DFcode, 8 },
  { convertPSI, Pcode, SIcode, 2 },
  { convertSIP, SIcode, Pcode, 2 },
  { convertSIT, SIcode, Tcode, 2 },
  { convertDIT, DIcode, Tcode, 2 },
  { convertSFT, SFcode, Tcode, 2 },
  { convertDFT, DFcode, Tcode, 2 },
  { convertXFT, XFcode, Tcode, 2 },
  { convertQISI, QIcode, SIcode, 2 },
  { convertPT, Pcode, Tcode, 2 },
  { convertSISF, SIcode, SFcode, 4 },
  { convertSIDF, SIcode, DFcode, 4 },
  { convertSIXF, SIcode, XFcode, 4 },
  { convertSUSF, SUcode, SFcode, 4 },
  { convertSUDF, SUcode, DFcode, 4 },
  { convertSUXF, SUcode, XFcode, 4 },
  { convertDISF, DIcode, SFcode, 4 },
  { convertDIDF, DIcode, DFcode, 4 },
  { convertDIXF, DIcode, XFcode, 4 },
  { convertDUSF, DUcode, SFcode, 4 },
  { convertDUDF, DUcode, DFcode, 4 },
  { convertDUXF, DUcode, XFcode, 4 },
  { convertSFSI, SFcode, SIcode, 4 },
  { convertDFSI, DFcode, SIcode, 4 },
  { convertXFSI, XFcode, SIcode, 4 },
  { convertSFSU, SFcode, SUcode, 4 },
  { convertDFSU, DFcode, SUcode, 4 },
  { convertXFSU, XFcode, SUcode, 4 },
  { convertSFDI, SFcode, DIcode, 4 },
  { convertDFDI, DFcode, DIcode, 4 },
  { convertXFDI, XFcode, DIcode, 4 },
  { convertSFDU, SFcode, DUcode, 4 },
  { convertDFDU, DFcode, DUcode, 4 },
  { convertXFDU, XFcode, DUcode, 4 },
  { convertSIQI, SIcode, QIcode, 8 },
};




struct n64_tag_conversion_list
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode to;
  int cost;
  struct n64_tag_conversion_list *prev;
};
static int
conversion_reasonable_p(struct n64_tag_conversion_info *conversion, struct n64_tag_conversion_list *list) asm("_conversion_reasonable_p");
static int
conversion_reasonable_p(struct n64_tag_conversion_info *conversion, struct n64_tag_conversion_list *list)
{
  struct n64_tag_conversion_list *curr;
  int curr_size, prev_size;
  int has_int_float, has_float_int;
  int has_sign_extend, has_zero_extend;
  int has_signed_unsigned, has_unsigned_signed;

  has_int_float = 0;
  has_float_int = 0;
  has_sign_extend = 0;
  has_zero_extend = 0;
  has_signed_unsigned = 0;
  has_unsigned_signed = 0;



  for (curr = list; curr; curr = curr->prev)
    if (conversion->to == curr->to)
      return 0;


  if (((int) (conversion->from) < (int) SFcode)
      && ((int) (conversion->to) < (int) Pcode && !((int) (conversion->to) < (int) SFcode)))
    has_int_float = 1;
  if (((int) (conversion->from) < (int) Pcode && !((int) (conversion->from) < (int) SFcode))
      && ((int) (conversion->to) < (int) SFcode))
    has_float_int = 1;
  if ((((int) (conversion->from) < (int) SFcode) && !((int) (conversion->from) & 1))
      && (((int) (conversion->to) < (int) SFcode) && !((int) (conversion->to) & 1))
      && (mode_size[(int)((typecode_mode[((int) conversion->from)]))])
      < (mode_size[(int)((typecode_mode[((int) conversion->to)]))]))
    has_sign_extend = 1;
  if ((((int) (conversion->from) < (int) SFcode) && (int) (conversion->from) & 1)
      && (((int) (conversion->to) < (int) SFcode) && (int) (conversion->to) & 1)
      && (mode_size[(int)((typecode_mode[((int) conversion->from)]))])
      < (mode_size[(int)((typecode_mode[((int) conversion->to)]))]))
    has_zero_extend = 1;

  for (curr = list; curr && curr->prev; curr = curr->prev)
    {
      if (((int) (curr->prev->to) < (int) SFcode)
   && ((int) (curr->to) < (int) Pcode && !((int) (curr->to) < (int) SFcode)))
 has_int_float = 1;
      if (((int) (curr->prev->to) < (int) Pcode && !((int) (curr->prev->to) < (int) SFcode))
   && ((int) (curr->to) < (int) SFcode))
 has_float_int = 1;
      if ((((int) (curr->prev->to) < (int) SFcode) && !((int) (curr->prev->to) & 1))
   && (((int) (curr->to) < (int) SFcode) && !((int) (curr->to) & 1))
   && (mode_size[(int)((typecode_mode[((int) curr->prev->to)]))])
   < (mode_size[(int)((typecode_mode[((int) curr->to)]))]))
 has_sign_extend = 1;
      if ((((int) (curr->prev->to) < (int) SFcode) && (int) (curr->prev->to) & 1)
   && (((int) (curr->to) < (int) SFcode) && (int) (curr->to) & 1)
   && (mode_size[(int)((typecode_mode[((int) curr->prev->to)]))])
   < (mode_size[(int)((typecode_mode[((int) curr->to)]))]))
 has_zero_extend = 1;
      if ((((int) (curr->prev->to) < (int) SFcode) && !((int) (curr->prev->to) & 1))
   && (((int) (curr->to) < (int) SFcode) && (int) (curr->to) & 1))
 has_signed_unsigned = 1;
      if ((((int) (curr->prev->to) < (int) SFcode) && (int) (curr->prev->to) & 1)
   && (((int) (curr->to) < (int) SFcode) && !((int) (curr->to) & 1)))
 has_unsigned_signed = 1;
    }

  if (((int) (conversion->from) < (int) SFcode)
      && ((int) (conversion->to) < (int) SFcode)
      && (mode_size[(int)((typecode_mode[((int) conversion->to)]))])
      > (mode_size[(int)((typecode_mode[((int) conversion->from)]))])
      && (has_signed_unsigned || has_unsigned_signed))
    return 0;

  if (has_float_int && has_int_float || has_sign_extend && has_zero_extend)
    return 0;



  prev_size = (mode_size[(int)((typecode_mode[((int) conversion->to)]))]);
  for (curr = list; curr; curr = curr->prev)
    {
      curr_size = (mode_size[(int)((typecode_mode[((int) curr->to)]))]);
      if (curr_size != prev_size)
 break;
    }
  if (!curr)
    return 1;

  if (curr_size < prev_size)
    for (prev_size = curr_size; curr; curr = curr->prev)
      {
 curr_size = (mode_size[(int)((typecode_mode[((int) curr->to)]))]);
 if (curr_size > prev_size)
   return 0;
 prev_size = curr_size;
      }
  else
    for (prev_size = curr_size; curr; curr = curr->prev)
      {
 curr_size = (mode_size[(int)((typecode_mode[((int) curr->to)]))]);
 if (curr_size < prev_size)
   return 0;
 prev_size = curr_size;
      }
  return 1;
}




static struct n64_tag_conversion_recipe
deduce_conversion(n64_enum_typecode from, n64_enum_typecode to) asm("_deduce_conversion");
static struct n64_tag_conversion_recipe
deduce_conversion(n64_enum_typecode from, n64_enum_typecode to)
{
  struct n64_tag_rl
    {
      struct n64_tag_conversion_list *list;
      struct n64_tag_rl *next;
    } *prev, curr, *good, *temp;
  struct n64_tag_conversion_list *conv, *best;
  int i, cost, bestcost;
  struct n64_tag_conversion_recipe result;
  struct n64_tag_obstack recipe_obstack;


  _obstack_begin ((&recipe_obstack), 0, 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);
  curr.next = (struct n64_tag_rl *) __extension__ ({ struct n64_tag_obstack *__h = (&recipe_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_rl))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  curr.next->list =
    (struct n64_tag_conversion_list *) __extension__ ({ struct n64_tag_obstack *__h = (&recipe_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_conversion_list))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                           ;
  curr.next->list->opcode = -1;
  curr.next->list->to = from;
  curr.next->list->cost = 0;
  curr.next->list->prev = 0;
  curr.next->next = 0;
  good = 0;

  while (curr.next)
    {

      for (prev = &curr; prev; prev = prev->next)
 if (prev->next && prev->next->list->to == to)
   {
     temp = prev->next->next;
     prev->next->next = good;
     good = prev->next;
     prev->next = temp;
   }



      for (prev = curr.next, curr.next = 0; prev; prev = prev->next)
 for (i = 0; i < (sizeof conversion_info / sizeof (struct n64_tag_conversion_info)); ++i)
   if (conversion_info[i].from == prev->list->to
       && conversion_reasonable_p (&conversion_info[i], prev->list))
     {
       temp = (struct n64_tag_rl *) __extension__ ({ struct n64_tag_obstack *__h = (&recipe_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_rl))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                           ;
       temp->list = (struct n64_tag_conversion_list *)
  __extension__ ({ struct n64_tag_obstack *__h = (&recipe_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_conversion_list))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                          ;
       temp->list->opcode = conversion_info[i].opcode;
       temp->list->to = conversion_info[i].to;
       temp->list->cost = conversion_info[i].cost;
       temp->list->prev = prev->list;
       temp->next = curr.next;
       curr.next = temp;
     }
    }

  bestcost = 100000;
  best = 0;
  for (temp = good; temp; temp = temp->next)
    {
      for (conv = temp->list, cost = 0; conv; conv = conv->prev)
 cost += conv->cost;
      if (cost < bestcost)
 {
   bestcost = cost;
   best = temp->list;
 }
    }

  if (!best)
    abort ();

  for (i = 0, conv = best; conv; conv = conv->prev)
    if (conv->opcode != -1)
      ++i;

  result.opcodes = (unsigned char *) xmalloc (i);
  result.nopcodes = i;
  for (conv = best; conv; conv = conv->prev)
    if (conv->opcode != -1)
      result.opcodes[--i] = conv->opcode;
  result.cost = bestcost;
  __extension__ ({ struct n64_tag_obstack *__o = (&recipe_obstack); void *__obj = (0); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  return result;
}
void
emit_typecode_conversion(n64_enum_typecode from, n64_enum_typecode to) asm("_emit_typecode_conversion");
void
emit_typecode_conversion(n64_enum_typecode from, n64_enum_typecode to)
{
  int i;

  (conversion_recipe[(int) from][(int) to].opcodes ? 0 : (conversion_recipe[(int) from][(int) to] = deduce_conversion (from, to), 0));
  for (i = 0; i < conversion_recipe[(int) from][(int) to].nopcodes; ++i)
    bc_emit_instruction (conversion_recipe[(int) from][(int) to].opcodes[i]);
}



void
bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");
void
bc_init_mode_to_code_map(void)
{
  int mode;

  for (mode = 0; mode < MAX_MACHINE_MODE + 1; mode++)
    {
      signed_mode_to_code_map[mode] =
 unsigned_mode_to_code_map[mode] =
   LAST_AND_UNUSED_TYPECODE;
    }




{ signed_mode_to_code_map[(int) QImode] = QIcode; unsigned_mode_to_code_map[(int) QImode] = QUcode; }
{ signed_mode_to_code_map[(int) HImode] = HIcode; unsigned_mode_to_code_map[(int) HImode] = HUcode; }
{ signed_mode_to_code_map[(int) VOIDmode] = SIcode; unsigned_mode_to_code_map[(int) VOIDmode] = SUcode; }
{ signed_mode_to_code_map[(int) SImode] = SIcode; unsigned_mode_to_code_map[(int) SImode] = SUcode; }
{ signed_mode_to_code_map[(int) DImode] = DIcode; unsigned_mode_to_code_map[(int) DImode] = DUcode; }
{ signed_mode_to_code_map[(int) PSImode] = Pcode; unsigned_mode_to_code_map[(int) PSImode] = Pcode; }
{ signed_mode_to_code_map[(int) BLKmode] = Pcode; unsigned_mode_to_code_map[(int) BLKmode] = Pcode; }
{ signed_mode_to_code_map[(int) SFmode] = SFcode; unsigned_mode_to_code_map[(int) SFmode] = SFcode; }
{ signed_mode_to_code_map[(int) DFmode] = DFcode; unsigned_mode_to_code_map[(int) DFmode] = DFcode; }



  bc_init_mode_to_opcode_maps ();
}


n64_enum_typecode
preferred_typecode(n64_enum_machine_mode mode, int unsignedp) asm("_preferred_typecode");
n64_enum_typecode
preferred_typecode(n64_enum_machine_mode mode, int unsignedp)
{
  n64_enum_typecode code = (unsignedp
   ? unsigned_mode_to_code_map
   : signed_mode_to_code_map) [(((int) mode) < ((int) MAX_MACHINE_MODE) ? ((int) mode) : ((int) MAX_MACHINE_MODE))
                               ];

  if (code == LAST_AND_UNUSED_TYPECODE)
    abort ();

  return code;
}



void
bc_expand_conversion(tree from, tree to) asm("_bc_expand_conversion");
void
bc_expand_conversion(tree from, tree to)
{
  n64_enum_typecode fcode, tcode;

  fcode = preferred_typecode (((from)->type.mode), ((from)->common.unsigned_flag));
  tcode = preferred_typecode (((to)->type.mode), ((to)->common.unsigned_flag));

  emit_typecode_conversion (fcode, tcode);
}


void
bc_expand_truth_conversion(tree from) asm("_bc_expand_truth_conversion");
void
bc_expand_truth_conversion(tree from)
{
  n64_enum_typecode fcode;

  fcode = preferred_typecode (((from)->type.mode), ((from)->common.unsigned_flag));
  emit_typecode_conversion (fcode, Tcode);
}


void
bc_expand_binary_operation(struct n64_tag_binary_operator *optab, tree resulttype, tree arg0, tree arg1) asm("_bc_expand_binary_operation");
void
bc_expand_binary_operation(struct n64_tag_binary_operator *optab, tree resulttype, tree arg0, tree arg1)
{
  int i, besti, cost, bestcost;
  n64_enum_typecode resultcode, arg0code, arg1code;

  resultcode = preferred_typecode (((resulttype)->type.mode), ((resulttype)->common.unsigned_flag));
  arg0code = preferred_typecode (((((arg0)->common.type))->type.mode), ((resulttype)->common.unsigned_flag));
  arg1code = preferred_typecode (((((arg1)->common.type))->type.mode), ((resulttype)->common.unsigned_flag));

  besti = -1;
  bestcost = 100000;

  for (i = 0; optab[i].opcode != -1; ++i)
    {
      cost = 0;
      (conversion_recipe[(int) arg0code][(int) optab[i].arg0].opcodes ? 0 : (conversion_recipe[(int) arg0code][(int) optab[i].arg0] = deduce_conversion (arg0code, optab[i].arg0), 0));
      cost += conversion_recipe[(int) arg0code][(int) optab[i].arg0].cost;
      (conversion_recipe[(int) arg1code][(int) optab[i].arg1].opcodes ? 0 : (conversion_recipe[(int) arg1code][(int) optab[i].arg1] = deduce_conversion (arg1code, optab[i].arg1), 0));
      cost += conversion_recipe[(int) arg1code][(int) optab[i].arg1].cost;
      if (cost < bestcost)
 {
   besti = i;
   bestcost = cost;
 }
    }

  if (besti == -1)
    abort ();

  expand_expr (arg1, 0, VOIDmode, 0);
  emit_typecode_conversion (arg1code, optab[besti].arg1);
  expand_expr (arg0, 0, VOIDmode, 0);
  emit_typecode_conversion (arg0code, optab[besti].arg0);
  bc_emit_instruction (optab[besti].opcode);
  emit_typecode_conversion (optab[besti].result, resultcode);
}


void
bc_expand_unary_operation(struct n64_tag_unary_operator *optab, tree resulttype, tree arg0) asm("_bc_expand_unary_operation");
void
bc_expand_unary_operation(struct n64_tag_unary_operator *optab, tree resulttype, tree arg0)
{
  int i, besti, cost, bestcost;
  n64_enum_typecode resultcode, arg0code;

  resultcode = preferred_typecode (((resulttype)->type.mode), ((resulttype)->common.unsigned_flag));
  arg0code = preferred_typecode (((((arg0)->common.type))->type.mode), ((((arg0)->common.type))->common.unsigned_flag));

  besti = -1;
  bestcost = 100000;

  for (i = 0; optab[i].opcode != -1; ++i)
    {
      (conversion_recipe[(int) arg0code][(int) optab[i].arg0].opcodes ? 0 : (conversion_recipe[(int) arg0code][(int) optab[i].arg0] = deduce_conversion (arg0code, optab[i].arg0), 0));
      cost = conversion_recipe[(int) arg0code][(int) optab[i].arg0].cost;
      if (cost < bestcost)
 {
   besti = i;
   bestcost = cost;
 }
    }

  if (besti == -1)
    abort ();

  expand_expr (arg0, 0, VOIDmode, 0);
  emit_typecode_conversion (arg0code, optab[besti].arg0);
  bc_emit_instruction (optab[besti].opcode);
  emit_typecode_conversion (optab[besti].result, resultcode);
}



void
bc_expand_increment(struct n64_tag_increment_operator *optab, tree type) asm("_bc_expand_increment");
void
bc_expand_increment(struct n64_tag_increment_operator *optab, tree type)
{
  n64_enum_typecode code;
  int i;

  code = preferred_typecode (((type)->type.mode), ((type)->common.unsigned_flag));
  for (i = 0; (int) optab[i].opcode >= 0; ++i)
    if (code == optab[i].arg)
      {
 bc_emit_instruction (optab[i].opcode);
 return;
      }
  abort ();
}

