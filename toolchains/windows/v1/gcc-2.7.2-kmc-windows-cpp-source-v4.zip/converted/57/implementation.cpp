// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/toplev.c
/* Top level of GNU C compiler
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/types.h>
#include <ctype.h>
#include <sys/stat.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int clock(...) asm("_clock");
extern int init_emit_once(...) asm("_init_emit_once");
extern int init_expmed(...) asm("_init_expmed");
extern int init_expr_once(...) asm("_init_expr_once");
extern int init_loop(...) asm("_init_loop");
extern int init_reload(...) asm("_init_reload");
extern int init_caller_save(...) asm("_init_caller_save");
extern int dwarfout_init(...) asm("_dwarfout_init");
extern int global_bindings_p(...) asm("_global_bindings_p");
extern int temporary_allocation(...) asm("_temporary_allocation");
extern int output_inline_function(...) asm("_output_inline_function");
extern int dwarfout_file_scope_decl(...) asm("_dwarfout_file_scope_decl");
extern int weak_finish(...) asm("_weak_finish");
extern int dwarfout_finish(...) asm("_dwarfout_finish");
extern int dump_combine_total_stats(...) asm("_dump_combine_total_stats");
extern int print_rtl(...) asm("_print_rtl");
extern int set_decl_abstract_flags(...) asm("_set_decl_abstract_flags");
extern int save_for_inline_nocopy(...) asm("_save_for_inline_nocopy");
extern int save_for_inline_copying(...) asm("_save_for_inline_copying");
extern int rtl_in_current_obstack(...) asm("_rtl_in_current_obstack");
extern int unshare_all_rtl(...) asm("_unshare_all_rtl");
extern int instantiate_virtual_regs(...) asm("_instantiate_virtual_regs");
extern int reg_scan(...) asm("_reg_scan");
extern int max_reg_num(...) asm("_max_reg_num");
extern int jump_optimize(...) asm("_jump_optimize");
extern int thread_jumps(...) asm("_thread_jumps");
extern int cse_main(...) asm("_cse_main");
extern int delete_dead_from_cse(...) asm("_delete_dead_from_cse");
extern int loop_optimize(...) asm("_loop_optimize");
extern int regclass_init(...) asm("_regclass_init");
extern int regclass(...) asm("_regclass");
extern int stupid_life_analysis(...) asm("_stupid_life_analysis");
extern int flow_analysis(...) asm("_flow_analysis");
extern int uninitialized_vars_warning(...) asm("_uninitialized_vars_warning");
extern int setjmp_args_warning(...) asm("_setjmp_args_warning");
extern int combine_instructions(...) asm("_combine_instructions");
extern int dump_combine_stats(...) asm("_dump_combine_stats");
extern int schedule_insns(...) asm("_schedule_insns");
extern int local_alloc(...) asm("_local_alloc");
extern int global_alloc(...) asm("_global_alloc");
extern int reload(...) asm("_reload");
extern int dump_global_regs(...) asm("_dump_global_regs");
extern int thread_prologue_and_epilogue_insns(...) asm("_thread_prologue_and_epilogue_insns");
extern int dbr_schedule(...) asm("_dbr_schedule");
extern int resume_temporary_allocation(...) asm("_resume_temporary_allocation");
extern int set_yydebug(...) asm("_set_yydebug");
extern int fix_register(...) asm("_fix_register");
struct n64_tag_bc_label;
struct n64_tag_bc_labelref;
struct n64_tag_bc_seg;
struct n64_tag_bc_segreloc;
struct n64_tag_bc_segsym;
struct n64_tag_bc_sym;
struct n64_tag_file_stack;
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");





extern char *input_filename;


extern char *main_input_filename;


extern int lineno;


extern FILE *finput;

struct n64_tag_file_stack
  {
    char *name;
    struct n64_tag_file_stack *next;
    int line;
  };



extern struct n64_tag_file_stack *input_file_stack;


extern int input_file_stack_tick;
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");



struct n64_tag_bc_sym
{

  char *name;


  unsigned int defined:1;


  unsigned int global:1;


  unsigned int common:1;


  unsigned long int val;


  struct n64_tag_bc_sym *next;
};



struct n64_tag_bc_segsym
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *next;
};



struct n64_tag_bc_segreloc
{

  unsigned int offset;


  struct n64_tag_bc_sym *sym;

  struct n64_tag_bc_segreloc *next;
};



struct n64_tag_bc_seg
{

  unsigned int alloc;


  char *data;


  unsigned int size;


  struct n64_tag_bc_segsym *syms;


  struct n64_tag_bc_segreloc *relocs;
};



struct n64_tag_bc_label
{

  unsigned int offset;


  unsigned int defined:1;



  int uid;


  struct n64_tag_bc_label *next;
};






struct n64_tag_bc_labelref
{

  struct n64_tag_bc_label *label;


  unsigned int offset;


  struct n64_tag_bc_labelref *next;
};



extern void bc_initialize(void) asm("_bc_initialize");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern void bc_emit_bytecode(...) asm("_bc_emit_bytecode");
extern void bc_emit_bytecode_const(...) asm("_bc_emit_bytecode_const");
extern struct n64_tag_bc_label *bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
extern int bc_emit_bytecode_labeldef(...) asm("_bc_emit_bytecode_labeldef");
extern void bc_emit_bytecode_labelref(...) asm("_bc_emit_bytecode_labelref");
extern void bc_emit_code_labelref(...) asm("_bc_emit_code_labelref");
extern char *bc_end_function(void) asm("_bc_end_function");
extern void bc_align_const(...) asm("_bc_align_const");
extern void bc_emit_const(...) asm("_bc_emit_const");
extern void bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern void bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern void bc_align_data(...) asm("_bc_align_data");
extern void bc_emit_data(...) asm("_bc_emit_data");
extern void bc_emit_data_skip(...) asm("_bc_emit_data_skip");
extern int bc_emit_data_labeldef(...) asm("_bc_emit_data_labeldef");
extern void bc_emit_data_labelref(...) asm("_bc_emit_data_labelref");
extern int bc_define_pointer(...) asm("_bc_define_pointer");
extern int bc_emit_common(...) asm("_bc_emit_common");
extern void bc_globalize_label(...) asm("_bc_globalize_label");
extern void bc_text(void) asm("_bc_text");
extern void bc_data(void) asm("_bc_data");
extern void bc_align(...) asm("_bc_align");
extern void bc_emit(...) asm("_bc_emit");
extern void bc_emit_skip(...) asm("_bc_emit_skip");
extern int bc_emit_labeldef(...) asm("_bc_emit_labeldef");
extern void bc_emit_labelref(...) asm("_bc_emit_labelref");
extern void bc_write_file(...) asm("_bc_write_file");
extern int rtx_equal_function_value_matters;


extern char **
             (* _imp___environ)
                    ;

extern char *version_string, *language_string;




extern int size_directive_output;
extern tree last_assemble_variable_decl;

extern void init_lex(void) asm("_init_lex");
extern void init_decl_processing(void) asm("_init_decl_processing");
extern void init_obstacks(void) asm("_init_obstacks");
extern void init_tree_codes(void) asm("_init_tree_codes");
extern void init_rtl(void) asm("_init_rtl");
extern void init_regs(void) asm("_init_regs");
extern void init_optabs(void) asm("_init_optabs");
extern void init_stmt(void) asm("_init_stmt");
extern void init_reg_sets(void) asm("_init_reg_sets");
extern void dump_flow_info(...) asm("_dump_flow_info");
extern void dump_sched_info(...) asm("_dump_sched_info");
extern void dump_local_alloc(...) asm("_dump_local_alloc");

void rest_of_decl_compilation(...) asm("_rest_of_decl_compilation");
void error_with_file_and_line (char *file, int line, char *s, ...) asm("_error_with_file_and_line");
void error_with_decl (tree decl, char *s, ...) asm("_error_with_decl");
void error_for_asm (rtx insn, char *s, ...) asm("_error_for_asm");
void error (char *s, ...) asm("_error");
void fatal (char *s, ...) asm("_fatal");
void warning_with_file_and_line (char *file, int line, char *s, ...) asm("_warning_with_file_and_line");
void warning_with_decl (tree decl, char *s, ...) asm("_warning_with_decl");
void warning_for_asm (rtx insn, char *s, ...) asm("_warning_for_asm");
void warning (char *s, ...) asm("_warning");
void pedwarn (char *s, ...) asm("_pedwarn");
void pedwarn_with_decl (tree decl, char *s, ...) asm("_pedwarn_with_decl");
void pedwarn_with_file_and_line (char *file, int line, char *s, ...) asm("_pedwarn_with_file_and_line");
void sorry (char *s, ...) asm("_sorry");
void really_sorry (char *s, ...) asm("_really_sorry");
void fancy_abort(void) asm("_fancy_abort");

void abort(void) asm("_abort");

void set_target_switch(...) asm("_set_target_switch");
static void print_switch_values(void) asm("_print_switch_values");
static char *decl_name(...) asm("_decl_name");







char *progname;


int save_argc;
char **save_argv;




char *input_filename;





char *main_input_filename;



FILE *finput;



int lineno;



struct n64_tag_file_stack *input_file_stack;


int input_file_stack_tick;



extern tree current_function_decl;



char *dump_base_name;





extern int target_flags;



int rtl_dump = 0;
int rtl_dump_and_exit = 0;
int jump_opt_dump = 0;
int cse_dump = 0;
int loop_dump = 0;
int cse2_dump = 0;
int flow_dump = 0;
int combine_dump = 0;
int sched_dump = 0;
int local_reg_dump = 0;
int global_reg_dump = 0;
int sched2_dump = 0;
int jump2_opt_dump = 0;
int dbr_sched_dump = 0;
int flag_print_asm_name = 0;
int stack_reg_dump = 0;



char *asm_file_name;


int g_switch_value;
int g_switch_set;




n64_enum_debug_info_type write_symbols = NO_DEBUG;



n64_enum_debug_info_level debug_info_level = DINFO_LEVEL_NONE;





int use_gnu_debug_info_extensions = 0;
int optimize = 0;



int errorcount = 0;
int warningcount = 0;
int sorrycount = 0;


int output_bytecode = 0;



char *(*decl_printable_name)(...);



struct n64_tag_rtx_def *(*lang_expand_expr)(...);




void (*incomplete_decl_finalize_hook)(...) = 0;





void (*interim_eh_hook) (tree);



int profile_flag = 0;



int profile_block_flag;




int pedantic = 0;




int in_system_header = 0;




int obey_regdecls = 0;




int quiet_flag = 0;





int flag_signed_char;



int flag_short_enums;
int flag_caller_saves = 0;
int flag_pcc_struct_return = 1;




int flag_force_mem = 0;




int flag_force_addr = 0;




int flag_defer_pop = 0;




int flag_float_store = 0;




int flag_cse_follow_jumps;



int flag_cse_skip_blocks;



int flag_expensive_optimizations;




int flag_thread_jumps;



int flag_strength_reduce = 0;






int flag_unroll_loops;




int flag_unroll_all_loops;




int flag_writable_strings = 0;





int flag_no_function_cse = 0;




int flag_omit_frame_pointer = 0;



int flag_no_peephole = 0;






int flag_fast_math = 0;



int flag_volatile;



int flag_volatile_global;



int flag_syntax_only = 0;




static int flag_rerun_cse_after_loop;




int flag_inline_functions;





int flag_keep_inline_functions;



int flag_no_inline;



int flag_gen_aux_info = 0;



static char *aux_info_file_name;



int flag_shared_data;



int flag_delayed_branch;



int flag_short_temps;






int flag_pic;



int flag_no_common;





int flag_pretend_float;




int flag_pedantic_errors = 0;






int flag_schedule_insns = 0;
int flag_schedule_insns_after_reload = 0;





int flag_inhibit_size_directive = 0;






int flag_verbose_asm = 0;







int flag_gnu_linker = 1;



int flag_pack_struct = 0;







struct { char *string; int *variable; int on_value;} f_options[] =
{
  {"float-store", &flag_float_store, 1},
  {"volatile", &flag_volatile, 1},
  {"volatile-global", &flag_volatile_global, 1},
  {"defer-pop", &flag_defer_pop, 1},
  {"omit-frame-pointer", &flag_omit_frame_pointer, 1},
  {"cse-follow-jumps", &flag_cse_follow_jumps, 1},
  {"cse-skip-blocks", &flag_cse_skip_blocks, 1},
  {"expensive-optimizations", &flag_expensive_optimizations, 1},
  {"thread-jumps", &flag_thread_jumps, 1},
  {"strength-reduce", &flag_strength_reduce, 1},
  {"unroll-loops", &flag_unroll_loops, 1},
  {"unroll-all-loops", &flag_unroll_all_loops, 1},
  {"writable-strings", &flag_writable_strings, 1},
  {"peephole", &flag_no_peephole, 0},
  {"force-mem", &flag_force_mem, 1},
  {"force-addr", &flag_force_addr, 1},
  {"function-cse", &flag_no_function_cse, 0},
  {"inline-functions", &flag_inline_functions, 1},
  {"keep-inline-functions", &flag_keep_inline_functions, 1},
  {"inline", &flag_no_inline, 0},
  {"syntax-only", &flag_syntax_only, 1},
  {"shared-data", &flag_shared_data, 1},
  {"caller-saves", &flag_caller_saves, 1},
  {"pcc-struct-return", &flag_pcc_struct_return, 1},
  {"reg-struct-return", &flag_pcc_struct_return, 0},
  {"delayed-branch", &flag_delayed_branch, 1},
  {"rerun-cse-after-loop", &flag_rerun_cse_after_loop, 1},
  {"pretend-float", &flag_pretend_float, 1},
  {"schedule-insns", &flag_schedule_insns, 1},
  {"schedule-insns2", &flag_schedule_insns_after_reload, 1},
  {"pic", &flag_pic, 1},
  {"PIC", &flag_pic, 2},
  {"fast-math", &flag_fast_math, 1},
  {"common", &flag_no_common, 0},
  {"inhibit-size-directive", &flag_inhibit_size_directive, 1},
  {"verbose-asm", &flag_verbose_asm, 1},
  {"gnu-linker", &flag_gnu_linker, 1},
  {"pack-struct", &flag_pack_struct, 1},
  {"bytecode", &output_bytecode, 1}
};



char *lang_options[] =
{
  "-ansi",
  "-fallow-single-precision",

  "-fsigned-bitfields",
  "-funsigned-bitfields",
  "-fno-signed-bitfields",
  "-fno-unsigned-bitfields",
  "-fsigned-char",
  "-funsigned-char",
  "-fno-signed-char",
  "-fno-unsigned-char",

  "-ftraditional",
  "-traditional",
  "-fnotraditional",
  "-fno-traditional",

  "-fasm",
  "-fno-asm",
  "-fbuiltin",
  "-fno-builtin",
  "-fcond-mismatch",
  "-fno-cond-mismatch",
  "-fdollars-in-identifiers",
  "-fno-dollars-in-identifiers",
  "-fident",
  "-fno-ident",
  "-fshort-double",
  "-fno-short-double",
  "-fshort-enums",
  "-fno-short-enums",

  "-Wall",
  "-Wbad-function-cast",
  "-Wno-bad-function-cast",
  "-Wcast-qual",
  "-Wno-cast-qual",
  "-Wchar-subscripts",
  "-Wno-char-subscripts",
  "-Wcomment",
  "-Wno-comment",
  "-Wcomments",
  "-Wno-comments",
  "-Wconversion",
  "-Wno-conversion",
  "-Wformat",
  "-Wno-format",
  "-Wimport",
  "-Wno-import",
  "-Wimplicit",
  "-Wno-implicit",
  "-Wmissing-braces",
  "-Wno-missing-braces",
  "-Wmissing-declarations",
  "-Wno-missing-declarations",
  "-Wmissing-prototypes",
  "-Wno-missing-prototypes",
  "-Wnested-externs",
  "-Wno-nested-externs",
  "-Wparentheses",
  "-Wno-parentheses",
  "-Wpointer-arith",
  "-Wno-pointer-arith",
  "-Wredundant-decls",
  "-Wno-redundant-decls",
  "-Wstrict-prototypes",
  "-Wno-strict-prototypes",
  "-Wtraditional",
  "-Wno-traditional",
  "-Wtrigraphs",
  "-Wno-trigraphs",
  "-Wwrite-strings",
  "-Wno-write-strings",


  "-lang-objc",
  "-gen-decls",
  "-fgnu-runtime",
  "-fno-gnu-runtime",
  "-fnext-runtime",
  "-fno-next-runtime",
  "-Wselector",
  "-Wno-selector",
  "-Wprotocol",
  "-Wno-protocol",

  "-+e0",
  "-+e1",
  "-+e2",
  "-faccess-control",
  "-fno-access-control",
  "-fall-virtual",
  "-fno-all-virtual",
  "-falt-external-templates",
  "-fno-alt-external-templates",
  "-fansi-overloading",
  "-fno-ansi-overloading",
  "-fcadillac",
  "-fno-cadillac",
  "-fcheck-new",
  "-fno-check-new",
  "-fconserve-space",
  "-fno-conserve-space",
  "-fdefault-inline",
  "-fno-default-inline",
  "-frtti",
  "-fno-rtti",
  "-felide-constructors",
  "-fno-elide-constructors",
  "-fenum-int-equiv",
  "-fno-enum-int-equiv",
  "-fexternal-templates",
  "-fno-external-templates",
  "-ffor-scope",
  "-fno-for-scope",
  "-fgc",
  "-fno-gc",
  "-fgnu-keywords",
  "-fno-gnu-keywords",
  "-fhandle-exceptions",
  "-fno-handle-exceptions",
  "-fhandle-signatures",
  "-fno-handle-signatures",
  "-fhuge-objects",
  "-fno-huge-objects",
  "-fimplement-inlines",
  "-fno-implement-inlines",
  "-fimplicit-templates",
  "-fno-implicit-templates",
  "-flabels-ok",
  "-fno-labels-ok",
  "-fmemoize-lookups",
  "-fno-memoize-lookups",
  "-fnonnull-objects",
  "-fno-nonnull-objects",
  "-foperator-names",
  "-fno-operator-names",
  "-frepo",
  "-fno-repo",
  "-fsave-memoized",
  "-fno-save-memoized",
  "-fshort-temps",
  "-fno-short-temps",
  "-fstats",
  "-fno-stats",
  "-fstrict-prototype",
  "-fno-strict-prototype",
  "-fthis-is-variable",
  "-fno-this-is-variable",
  "-fvtable-thunks",
  "-fno-vtable-thunks",
  "-fxref",
  "-fno-xref",

  "-Wreturn-type",
  "-Wno-return-type",
  "-Woverloaded-virtual",
  "-Wno-overloaded-virtual",
  "-Wtemplate-debugging",
  "-Wno-template-debugging",
  "-Wctor-dtor-privacy",
  "-Wno-ctor-dtor-privacy",
  "-Wnon-virtual-dtor",
  "-Wno-non-virtual-dtor",
  "-Wextern-inline",
  "-Wno-extern-inline",
  "-Wreorder",
  "-Wno-reorder",
  "-Wsynth",
  "-Wno-synth",
  0
};





int inhibit_warnings = 0;



int extra_warnings = 0;



int warnings_are_errors = 0;



int warn_unused;



int warn_uninitialized;



int warn_shadow;



int warn_switch;




int warn_return_type;





int warn_cast_align;




int warn_id_clash;
unsigned id_clash_len;





int warn_larger_than;
unsigned larger_than_size;



int warn_inline;




int warn_aggregate_return;



struct { char *string; int *variable; int on_value;} W_options[] =
{
  {"unused", &warn_unused, 1},
  {"error", &warnings_are_errors, 1},
  {"shadow", &warn_shadow, 1},
  {"switch", &warn_switch, 1},
  {"aggregate-return", &warn_aggregate_return, 1},
  {"cast-align", &warn_cast_align, 1},
  {"uninitialized", &warn_uninitialized, 1},
  {"inline", &warn_inline, 1}
};




FILE *asm_out_file;
FILE *aux_info_file;
FILE *rtl_dump_file;
FILE *jump_opt_dump_file;
FILE *cse_dump_file;
FILE *loop_dump_file;
FILE *cse2_dump_file;
FILE *flow_dump_file;
FILE *combine_dump_file;
FILE *sched_dump_file;
FILE *local_reg_dump_file;
FILE *global_reg_dump_file;
FILE *sched2_dump_file;
FILE *jump2_opt_dump_file;
FILE *dbr_sched_dump_file;
FILE *stack_reg_dump_file;



int parse_time;
int varconst_time;
int integration_time;
int jump_time;
int cse_time;
int loop_time;
int cse2_time;
int flow_time;
int combine_time;
int sched_time;
int local_alloc_time;
int global_alloc_time;
int sched2_time;
int dbr_sched_time;
int shorten_branch_time;
int stack_reg_time;
int final_time;
int symout_time;
int dump_time;



int
get_run_time(void) asm("_get_run_time");
int
get_run_time(void)
{
  if (quiet_flag)
    return 0;

  if (clock() < 0)
    return 0;
  else
    return (clock() * 1000);
}




void
print_time(char *str, int total) asm("_print_time");
void
print_time(char *str, int total)
{
  fprintf (
          (__acrt_iob_func(2))
                ,
    "time in %s: %d.%06d\n",
    str, total / 1000000, total % 1000000);
}



int
count_error(int warningp) asm("_count_error");
int
count_error(int warningp)
{
  if (warningp && inhibit_warnings)
    return 0;

  if (warningp && !warnings_are_errors)
    warningcount++;
  else
    {
      static int warning_message = 0;

      if (warningp && !warning_message)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "%s: warnings being treated as errors\n", progname);
   warning_message = 1;
 }
      errorcount++;
    }

  return 1;
}




void
pfatal_with_name(char *name) asm("_pfatal_with_name");
void
pfatal_with_name(char *name)
{
  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", progname);
  perror (name);
  exit (33);
}

void
fatal_io_error(char *name) asm("_fatal_io_error");
void
fatal_io_error(char *name)
{
  fprintf (
          (__acrt_iob_func(2))
                , "%s: %s: I/O error\n", progname, name);
  exit (33);
}




void
fatal_insn(char *message, rtx insn) asm("_fatal_insn");
void
fatal_insn(char *message, rtx insn)
{
  if (!output_bytecode)
    {
      error (message);
      debug_rtx (insn);
    }
  if (asm_out_file)
    fflush (asm_out_file);
  if (aux_info_file)
    fflush (aux_info_file);
  if (rtl_dump_file)
    fflush (rtl_dump_file);
  if (jump_opt_dump_file)
    fflush (jump_opt_dump_file);
  if (cse_dump_file)
    fflush (cse_dump_file);
  if (loop_dump_file)
    fflush (loop_dump_file);
  if (cse2_dump_file)
    fflush (cse2_dump_file);
  if (flow_dump_file)
    fflush (flow_dump_file);
  if (combine_dump_file)
    fflush (combine_dump_file);
  if (sched_dump_file)
    fflush (sched_dump_file);
  if (local_reg_dump_file)
    fflush (local_reg_dump_file);
  if (global_reg_dump_file)
    fflush (global_reg_dump_file);
  if (sched2_dump_file)
    fflush (sched2_dump_file);
  if (jump2_opt_dump_file)
    fflush (jump2_opt_dump_file);
  if (dbr_sched_dump_file)
    fflush (dbr_sched_dump_file);
  if (stack_reg_dump_file)
    fflush (stack_reg_dump_file);
  abort ();
}





void
fatal_insn_not_found(rtx insn) asm("_fatal_insn_not_found");
void
fatal_insn_not_found(rtx insn)
{
  if (((insn)->fld[4].rtint) < 0)
    fatal_insn ("internal error--unrecognizable insn:", insn);
  else
    fatal_insn ("internal error--insn does not satisfy its constraints:", insn);
}



static char *
decl_name(tree decl, char **kind) asm("_decl_name");
static char *
decl_name(tree decl, char **kind)
{
  return ((((decl)->decl.name))->identifier.pointer);
}



void
interim_eh(tree finalization) asm("_interim_eh");
void
interim_eh(tree finalization)
{

}

static int need_error_newline;




static tree last_error_function = 
                                 ((void *)0)
                                     ;


static int last_error_tick;




void
announce_function(tree decl) asm("_announce_function");
void
announce_function(tree decl)
{
  if (! quiet_flag)
    {
      char *junk;
      if (rtl_dump_and_exit)
 fprintf (
         (__acrt_iob_func(2))
               , "%s ", ((((decl)->decl.name))->identifier.pointer));
      else
 fprintf (
         (__acrt_iob_func(2))
               , " %s", (*decl_printable_name) (decl, &junk));
      fflush (
             (__acrt_iob_func(2))
                   );
      need_error_newline = 1;
      last_error_function = current_function_decl;
    }
}




void
default_print_error_function(char *file) asm("_default_print_error_function");
void
default_print_error_function(char *file)
{
  if (last_error_function != current_function_decl)
    {
      char *kind = "function";
      if (current_function_decl != 0
   && ((n64_enum_tree_code) (((current_function_decl)->common.type))->common.code) == METHOD_TYPE)
 kind = "method";

      if (file)
 fprintf (
         (__acrt_iob_func(2))
               , "%s: ", file);

      if (current_function_decl == 
                                  ((void *)0)
                                      )
 fprintf (
         (__acrt_iob_func(2))
               , "At top level:\n");
      else
 {
   char *name = (*decl_printable_name) (current_function_decl, &kind);
   fprintf (
           (__acrt_iob_func(2))
                 , "In %s `%s':\n", kind, name);
 }

      last_error_function = current_function_decl;
    }
}




void (*print_error_function) (char*) = default_print_error_function;




void
report_error_function(char *file) asm("_report_error_function");
void
report_error_function(char *file)
{
  struct n64_tag_file_stack *p;

  if (need_error_newline)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
      need_error_newline = 0;
    }

  (*print_error_function) (file);

  if (input_file_stack && input_file_stack->next != 0
      && input_file_stack_tick != last_error_tick
      && file == input_filename)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "In file included");
      for (p = input_file_stack->next; p; p = p->next)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , " from %s:%d", p->name, p->line);
   if (p->next)
     fprintf (
             (__acrt_iob_func(2))
                   , ",\n                ");
 }
      fprintf (
              (__acrt_iob_func(2))
                    , ":\n");
      last_error_tick = input_file_stack_tick;
    }
}



static void
vmessage(char *prefix, char *s, va_list ap) asm("_vmessage");
static void
vmessage(char *prefix, char *s, va_list ap)
{
  if (prefix)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", prefix);


  vfprintf (
           (__acrt_iob_func(2))
                 , s, ap);
}



static void
v_message_with_file_and_line(char *file, int line, char *prefix, char *s, va_list ap) asm("_v_message_with_file_and_line");
static void
v_message_with_file_and_line(char *file, int line, char *prefix, char *s, va_list ap)
{
  if (file)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", file, line);
  else
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", progname);

  vmessage (prefix, s, ap);
  fputc ('\n', 
              (__acrt_iob_func(2))
                    );
}



static void
v_message_with_decl(tree decl, char *prefix, char *s, va_list ap) asm("_v_message_with_decl");
static void
v_message_with_decl(tree decl, char *prefix, char *s, va_list ap)
{
  char *n, *p, *junk;

  fprintf (
          (__acrt_iob_func(2))
                , "%s:%d: ",
    ((decl)->decl.filename), ((decl)->decl.linenum));

  if (prefix)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", prefix);





  for (p = s; *p; ++p)
    {
      if (*p == '%')
 {
   if (*(p + 1) == '%')
     ++p;
   else
     break;
 }
    }

  if (p > s)
    {
      char fmt[sizeof "%.255s"];
      long width = p - s;

      if (width > 255L) width = 255L;
      sprintf (fmt, "%%.%lds", width);
      fprintf (
              (__acrt_iob_func(2))
                    , fmt, s);
    }

  if (*p == '%')
    {
      char *n = (((decl)->decl.name)
   ? (*decl_printable_name) (decl, &junk)
   : "((anonymous))");
      fputs (n, 
               (__acrt_iob_func(2))
                     );
      while (*p)
 {
   ++p;
   if (isalpha (*(p - 1) & 0xFF))
     break;
 }
    }

  if (*p)
    vmessage ((char *)
                     ((void *)0)
                         , p, ap);

  fputc ('\n', 
              (__acrt_iob_func(2))
                    );
}



static void
file_and_line_for_asm(rtx insn, char **pfile, int *pline) asm("_file_and_line_for_asm");
static void
file_and_line_for_asm(rtx insn, char **pfile, int *pline)
{
  rtx body = ((insn)->fld[3].rtx);
  rtx asmop;


  if (((body)->code) == SET && ((((body)->fld[1].rtx))->code) == ASM_OPERANDS)
    asmop = ((body)->fld[1].rtx);
  else if (((body)->code) == ASM_OPERANDS)
    asmop = body;
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == SET)
    asmop = ((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx);
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == ASM_OPERANDS)
    asmop = ((body)->fld[0].rtvec->elem[0].rtx);
  else
    asmop = 
           ((void *)0)
               ;

  if (asmop)
    {
      *pfile = (((asmop))->fld[5].rtstr);
      *pline = (((asmop))->fld[6].rtint);
    }
  else
    {
      *pfile = input_filename;
      *pline = lineno;
    }
}



static void
v_error_with_file_and_line(char *file, int line, char *s, va_list ap) asm("_v_error_with_file_and_line");
static void
v_error_with_file_and_line(char *file, int line, char *s, va_list ap)
{
  count_error (0);
  report_error_function (file);
  v_message_with_file_and_line (file, line, (char *)
                                                   ((void *)0)
                                                       , s, ap);
}

void
error_with_file_and_line (char *file, int line, char *s, ...) asm("_error_with_file_and_line");
void
error_with_file_and_line (char *file, int line, char *s, ...)
{





  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;







  v_error_with_file_and_line (file, line, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}





static void
v_error_with_decl(tree decl, char *s, va_list ap) asm("_v_error_with_decl");
static void
v_error_with_decl(tree decl, char *s, va_list ap)
{
  count_error (0);
  report_error_function (((decl)->decl.filename));
  v_message_with_decl (decl, (char *)
                                    ((void *)0)
                                        , s, ap);
}

void
error_with_decl (tree decl, char *s, ...) asm("_error_with_decl");
void
error_with_decl (tree decl, char *s, ...)
{




  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;






  v_error_with_decl (decl, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}





static void
v_error_for_asm(rtx insn, char *s, va_list ap) asm("_v_error_for_asm");
static void
v_error_for_asm(rtx insn, char *s, va_list ap)
{
  char *file;
  int line;

  count_error (0);
  file_and_line_for_asm (insn, &file, &line);
  report_error_function (file);
  v_message_with_file_and_line (file, line, (char *)
                                                   ((void *)0)
                                                       , s, ap);
}

void
error_for_asm (rtx insn, char *s, ...) asm("_error_for_asm");
void
error_for_asm (rtx insn, char *s, ...)
{




  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;






  v_error_for_asm (insn, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
verror(char *s, va_list ap) asm("_verror");
static void
verror(char *s, va_list ap)
{
  v_error_with_file_and_line (input_filename, lineno, s, ap);
}

void
error (char *s, ...) asm("_error");
void
error (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  verror (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
vfatal(char *s, va_list ap) asm("_vfatal");
static void
vfatal(char *s, va_list ap)
{
  verror (s, ap);
  exit (33);
}

void
fatal (char *s, ...) asm("_fatal");
void
fatal (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  vfatal (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
v_warning_with_file_and_line(char *file, int line, char *s, va_list ap) asm("_v_warning_with_file_and_line");
static void
v_warning_with_file_and_line(char *file, int line, char *s, va_list ap)
{
  if (count_error (1))
    {
      report_error_function (file);
      v_message_with_file_and_line (file, line, "warning", s, ap);
    }
}

void
warning_with_file_and_line (char *file, int line, char *s, ...) asm("_warning_with_file_and_line");
void
warning_with_file_and_line (char *file, int line, char *s, ...)
{





  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;







  v_warning_with_file_and_line (file, line, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}





static void
v_warning_with_decl(tree decl, char *s, va_list ap) asm("_v_warning_with_decl");
static void
v_warning_with_decl(tree decl, char *s, va_list ap)
{
  if (count_error (1))
    {
      report_error_function (((decl)->decl.filename));
      v_message_with_decl (decl, "warning", s, ap);
    }
}

void
warning_with_decl (tree decl, char *s, ...) asm("_warning_with_decl");
void
warning_with_decl (tree decl, char *s, ...)
{




  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;






  v_warning_with_decl (decl, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}





static void
v_warning_for_asm(rtx insn, char *s, va_list ap) asm("_v_warning_for_asm");
static void
v_warning_for_asm(rtx insn, char *s, va_list ap)
{
  if (count_error (1))
    {
      char *file;
      int line;

      file_and_line_for_asm (insn, &file, &line);
      report_error_function (file);
      v_message_with_file_and_line (file, line, "warning", s, ap);
    }
}

void
warning_for_asm (rtx insn, char *s, ...) asm("_warning_for_asm");
void
warning_for_asm (rtx insn, char *s, ...)
{




  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;






  v_warning_for_asm (insn, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
vwarning(char *s, va_list ap) asm("_vwarning");
static void
vwarning(char *s, va_list ap)
{
  v_warning_with_file_and_line (input_filename, lineno, s, ap);
}

void
warning (char *s, ...) asm("_warning");
void
warning (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  vwarning (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}




static void
vpedwarn(char *s, va_list ap) asm("_vpedwarn");
static void
vpedwarn(char *s, va_list ap)
{
  if (flag_pedantic_errors)
    verror (s, ap);
  else
    vwarning (s, ap);
}

void
pedwarn (char *s, ...) asm("_pedwarn");
void
pedwarn (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  vpedwarn (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}

static void
v_pedwarn_with_decl(tree decl, char *s, va_list ap) asm("_v_pedwarn_with_decl");
static void
v_pedwarn_with_decl(tree decl, char *s, va_list ap)
{







  if (! ((decl)->decl.in_system_header_flag))
    {
      if (flag_pedantic_errors)
 v_error_with_decl (decl, s, ap);
      else
 v_warning_with_decl (decl, s, ap);
    }
}

void
pedwarn_with_decl (tree decl, char *s, ...) asm("_pedwarn_with_decl");
void
pedwarn_with_decl (tree decl, char *s, ...)
{




  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;






  v_pedwarn_with_decl (decl, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}

static void
v_pedwarn_with_file_and_line(char *file, int line, char *s, va_list ap) asm("_v_pedwarn_with_file_and_line");
static void
v_pedwarn_with_file_and_line(char *file, int line, char *s, va_list ap)
{
  if (flag_pedantic_errors)
    v_error_with_file_and_line (file, line, s, ap);
  else
    v_warning_with_file_and_line (file, line, s, ap);
}

void
pedwarn_with_file_and_line (char *file, int line, char *s, ...) asm("_pedwarn_with_file_and_line");
void
pedwarn_with_file_and_line (char *file, int line, char *s, ...)
{





  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;







  v_pedwarn_with_file_and_line (file, line, s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
vsorry(char *s, va_list ap) asm("_vsorry");
static void
vsorry(char *s, va_list ap)
{
  sorrycount++;
  if (input_filename)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", input_filename, lineno);
  else
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", progname);
  vmessage ("sorry, not implemented", s, ap);
  fputc ('\n', 
              (__acrt_iob_func(2))
                    );
}

void
sorry (char *s, ...) asm("_sorry");
void
sorry (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  vsorry (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}



static void
v_really_sorry(char *s, va_list ap) asm("_v_really_sorry");
static void
v_really_sorry(char *s, va_list ap)
{
  sorrycount++;
  if (input_filename)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ", input_filename, lineno);
  else
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", progname);
  vmessage ("sorry, not implemented", s, ap);
  fatal (" (fatal)\n");
}

void
really_sorry (char *s, ...) asm("_really_sorry");
void
really_sorry (char *s, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 s
 )
                 ;





  v_really_sorry (s, ap);
  
 __builtin_va_end(
 ap
 )
            ;
}
void
fancy_abort(void) asm("_fancy_abort");
void
fancy_abort(void)
{
  fatal ("internal gcc abort");
}




void
do_abort(void) asm("_do_abort");
void
do_abort(void)
{
  abort ();
}




void
botch(int s) asm("_botch");
void
botch(int s)
{
  abort ();
}



char *
xmalloc(unsigned int size) asm("_xmalloc");
char *
xmalloc(unsigned int size)
{
  register char *value = (char *) malloc (size);
  if (value == 0)
    fatal ("virtual memory exhausted");
  return value;
}



char *
xrealloc(char *ptr, int size) asm("_xrealloc");
char *
xrealloc(char *ptr, int size)
{
  char *result = (char *) realloc (ptr, size);
  if (!result)
    fatal ("virtual memory exhausted");
  return result;
}






int
exact_log2_wide(register unsigned int x) asm("_exact_log2_wide");
int
exact_log2_wide(register unsigned int x)
{
  register int log = 0;

  if (x == 0 || x != (x & -x))
    return -1;
  while ((x >>= 1) != 0)
    log++;
  return log;
}






int
floor_log2_wide(register unsigned int x) asm("_floor_log2_wide");
int
floor_log2_wide(register unsigned int x)
{
  register int log = -1;
  while (x != 0)
    log++,
    x >>= 1;
  return log;
}

int float_handled;
jmp_buf float_handler;




void
set_float_handler(int *handler) asm("_set_float_handler");
void
set_float_handler(int *handler)
{
  float_handled = (handler != 0);
  if (handler)
    memcpy ((char *) float_handler,(char *) handler,sizeof (float_handler));
}





int
push_float_handler(int *handler, int *old_handler) asm("_push_float_handler");
int
push_float_handler(int *handler, int *old_handler)
{
  int was_handled = float_handled;

  float_handled = 1;
  if (was_handled)
    memcpy ((char *) old_handler,(char *) float_handler,sizeof (float_handler))
                           ;

  memcpy ((char *) float_handler,(char *) handler,sizeof (float_handler));
  return was_handled;
}




void
pop_float_handler(int handled, int *handler) asm("_pop_float_handler");
void
pop_float_handler(int handled, int *handler)
{
  float_handled = handled;
  if (handled)
    memcpy ((char *) float_handler,(char *) handler,sizeof (float_handler));
}



static void
float_signal(int signo) asm("_float_signal");
static void
float_signal(int signo)
{
  if (float_handled == 0)
    abort ();

  signal (
         8
               , float_signal);

  float_handled = 0;
  signal (
         8
               , float_signal);
  longjmp (float_handler, 1);
}



static void
pipe_closed(int signo) asm("_pipe_closed");
static void
pipe_closed(int signo)
{
  fatal ("output pipe has been closed");
}






void
strip_off_ending(char *name, int len) asm("_strip_off_ending");
void
strip_off_ending(char *name, int len)
{
  if (len > 2 && name[len - 2] == '.')
    name[len - 2] = '\0';
  else if (len > 3 && name[len - 3] == '.')
    name[len - 3] = '\0';
  else if (len > 4 && name[len - 4] == '.')
    name[len - 4] = '\0';
}


void
output_quoted_string(FILE *asm_file, char *string) asm("_output_quoted_string");
void
output_quoted_string(FILE *asm_file, char *string)
{
  char c;

  putc ('\"', asm_file);
  while ((c = *string++) != 0)
    {
      if (c == '\"' || c == '\\')
 putc ('\\', asm_file);
      putc (c, asm_file);
    }
  putc ('\"', asm_file);
}



void
output_file_directive(FILE *asm_file, char *input_name) asm("_output_file_directive");
void
output_file_directive(FILE *asm_file, char *input_name)
{
  int len = strlen (input_name);
  char *na = input_name + len;


  while (na > input_name)
    {
      if (na[-1] == '/')
 break;
      na--;
    }





  mips_output_filename (asm_file, na);






}


static void
output_lang_identify(FILE *asm_out_file) asm("_output_lang_identify");
static void
output_lang_identify(FILE *asm_out_file)
{
  int len = strlen (lang_identify ()) + sizeof ("__gnu_compiled_") + 1;
  char *s = (char *) 
                    __builtin_alloca((
                    len
                    ))
                                ;
  sprintf (s, "__gnu_compiled_%s", lang_identify ());
  do { assemble_name (asm_out_file, s); fputs (":\n", asm_out_file); } while (0);
}


static FILE *
open_dump_file(char *base_name, char *suffix) asm("_open_dump_file");
static FILE *
open_dump_file(char *base_name, char *suffix)
{
  FILE *f;
  char *dumpname = (char *) 
                           __builtin_alloca((
                           strlen (base_name) + strlen (suffix) + 1
                           ))
                                                                            ;

  strcpy (dumpname, base_name);
  strcat (dumpname, suffix);
  f = fopen (dumpname, "w");
  if (f == 0)
    pfatal_with_name (dumpname);
  return f;
}




static void
compile_file(char *name) asm("_compile_file");
static void
compile_file(char *name)
{
  tree globals;
  int start_time;

  int name_specified = name != 0;

  if (dump_base_name == 0)
    dump_base_name = name ? name : "gccdump";

  parse_time = 0;
  varconst_time = 0;
  integration_time = 0;
  jump_time = 0;
  cse_time = 0;
  loop_time = 0;
  cse2_time = 0;
  flow_time = 0;
  combine_time = 0;
  sched_time = 0;
  local_alloc_time = 0;
  global_alloc_time = 0;
  sched2_time = 0;
  dbr_sched_time = 0;
  shorten_branch_time = 0;
  stack_reg_time = 0;
  final_time = 0;
  symout_time = 0;
  dump_time = 0;



  if (name == 0 || !strcmp (name, "-"))
    {
      finput = 
              (__acrt_iob_func(0))
                   ;
      name = "stdin";
    }
  else
    finput = fopen (name, "r");
  if (finput == 0)
    pfatal_with_name (name);







  init_obstacks ();
  init_tree_codes ();
  init_lex ();


  init_rtl ();
  init_emit_once (debug_info_level == DINFO_LEVEL_NORMAL
    || debug_info_level == DINFO_LEVEL_VERBOSE);
  init_regs ();
  init_decl_processing ();
  init_optabs ();
  init_stmt ();
  init_expmed ();
  init_expr_once ();
  init_loop ();
  init_reload ();

  if (flag_caller_saves)
    init_caller_save ();




  if (flag_gen_aux_info)
    {
      aux_info_file = fopen (aux_info_file_name, "w");
      if (aux_info_file == 0)
 pfatal_with_name (aux_info_file_name);
    }


  if (rtl_dump)
    rtl_dump_file = open_dump_file (dump_base_name, ".rtl");


  if (jump_opt_dump)
    jump_opt_dump_file = open_dump_file (dump_base_name, ".jump");


  if (cse_dump)
    cse_dump_file = open_dump_file (dump_base_name, ".cse");


  if (loop_dump)
    loop_dump_file = open_dump_file (dump_base_name, ".loop");


  if (cse2_dump)
    cse2_dump_file = open_dump_file (dump_base_name, ".cse2");


  if (flow_dump)
    flow_dump_file = open_dump_file (dump_base_name, ".flow");


  if (combine_dump)
    combine_dump_file = open_dump_file (dump_base_name, ".combine");


  if (sched_dump)
    sched_dump_file = open_dump_file (dump_base_name, ".sched");


  if (local_reg_dump)
    local_reg_dump_file = open_dump_file (dump_base_name, ".lreg");


  if (global_reg_dump)
    global_reg_dump_file = open_dump_file (dump_base_name, ".greg");


  if (sched2_dump)
    sched2_dump_file = open_dump_file (dump_base_name, ".sched2");


  if (jump2_opt_dump)
    jump2_opt_dump_file = open_dump_file (dump_base_name, ".jump2");


  if (dbr_sched_dump)
    dbr_sched_dump_file = open_dump_file (dump_base_name, ".dbr");
  if (! name_specified && asm_file_name == 0)
    asm_out_file = 
                  (__acrt_iob_func(1))
                        ;
  else
    {
      int len = strlen (dump_base_name);
      register char *dumpname = (char *) xmalloc (len + 6);
      strcpy (dumpname, dump_base_name);
      strip_off_ending (dumpname, len);
      strcat (dumpname, ".s");
      if (asm_file_name == 0)
 {
   asm_file_name = (char *) xmalloc (strlen (dumpname) + 1);
   strcpy (asm_file_name, dumpname);
 }
      if (!strcmp (asm_file_name, "-"))
 asm_out_file = 
               (__acrt_iob_func(1))
                     ;
      else
 asm_out_file = fopen (asm_file_name, "w");
      if (asm_out_file == 0)
 pfatal_with_name (asm_file_name);
    }






  input_filename = name;


  input_file_stack
    = (struct n64_tag_file_stack *) xmalloc (sizeof (struct n64_tag_file_stack));
  input_file_stack->next = 0;
  input_file_stack->name = input_filename;



  lang_init ();



  if (main_input_filename == 0)
    main_input_filename = name;

  if (!output_bytecode)
    {
      do { mips_asm_file_start (asm_out_file); fprintf (asm_out_file, "\t.version\t\"01.01\"\n"); } while (0);
    }



  if (output_bytecode)
    fprintf (asm_out_file, "bc_gcc2_compiled.:\n");
  else
    {



      do { if (write_symbols != DBX_DEBUG) fputs ("gcc2_compiled.:\n", asm_out_file); else fputs ("\t.stabs\t\"gcc2_compiled.\", 0x3c, 0, 0, 0\n", asm_out_file); } while (0);

    }






  if (output_bytecode)
    {
      if (profile_flag || profile_block_flag)
 error ("profiling not supported in bytecode compilation");
    }
  else
    {
      if (profile_flag || profile_block_flag)
 assemble_zeros (((target_flags & 0x00002000) ? 8 : 4));
    }
  if (write_symbols == DWARF_DEBUG)
    do { int otime = get_run_time (); dwarfout_init (asm_out_file, main_input_filename); symout_time += get_run_time () - otime; } while (0);




  if (!output_bytecode)
    init_final (main_input_filename);

  start_time = get_run_time ();




  if (yyparse () != 0)
    {
      if (errorcount == 0)
 fprintf (
         (__acrt_iob_func(2))
               , "Errors detected in input file (your bison.simple is out of date)");



      while (! global_bindings_p ())
 poplevel (0, 0, 0);
    }




  parse_time += get_run_time () - start_time;

  parse_time -= integration_time;
  parse_time -= varconst_time;

  globals = getdecls ();





  {
    int len = list_length (globals);
    tree *vec = (tree *) 
                        __builtin_alloca((
                        sizeof (tree) * len
                        ))
                                                    ;
    int i;
    tree decl;
    int reconsider = 1;




    for (i = 0, decl = globals; i < len; i++, decl = ((decl)->common.chain))
      vec[len - i - 1] = decl;

    for (i = 0; i < len; i++)
      {
 decl = vec[i];


 ((decl)->decl.defer_output) = 0;

 if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->decl.size) == 0
     && incomplete_decl_finalize_hook != 0)
   (*incomplete_decl_finalize_hook) (decl);
      }




    while (reconsider)
      {
 reconsider = 0;
 for (i = 0; i < len; i++)
   {
     decl = vec[i];

     if (((decl)->common.asm_written_flag) || ((decl)->decl.external_flag))
       continue;
     if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->common.static_flag)
  && (! ((decl)->common.readonly_flag)
      || ((decl)->common.public_flag)
      || !optimize
      || ((((decl)->decl.assembler_name))->common.static_flag)))
       {
  reconsider = 1;
  rest_of_decl_compilation (decl, ((void *)0), 1, 1);
       }

     if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
  && ((decl)->decl.initial) != 0
  && ((decl)->decl.saved_insns.r) != 0
  && (flag_keep_inline_functions
      || ((((decl)->decl.assembler_name))->common.static_flag)))
       {
  reconsider = 1;
  temporary_allocation ();
  output_inline_function (decl);
  permanent_allocation (1);
       }
   }
      }

    for (i = 0; i < len; i++)
      {
 decl = vec[i];

 if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->common.static_flag)
     && ! ((decl)->common.asm_written_flag))



   ((decl)->decl.rtl) = 
                    ((void *)0)
                        ;






 if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
     && (warn_unused
  || ((((decl)->decl.assembler_name))->common.static_flag))
     && ((decl)->decl.initial) == 0
     && ((decl)->decl.external_flag)
     && ! ((decl)->common.public_flag))
   {
     pedwarn_with_decl (decl,
          "`%s' declared `static' but never defined");

     ((decl)->common.public_flag) = 1;
     assemble_external (decl);
   }




 if (warn_unused
     && ((((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ! ((decl)->decl.inline_flag))
  || (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ! ((decl)->common.readonly_flag)))
     && ! ((decl)->decl.in_system_header_flag)
     && ! ((decl)->decl.external_flag)
     && ! ((decl)->common.public_flag)
     && ! ((decl)->common.used_flag)
     && ! ((decl)->decl.regdecl_flag)



     && ! ((((decl)->decl.name))->common.used_flag))
   warning_with_decl (decl, "`%s' defined but not used");
 if (write_symbols == DWARF_DEBUG
     && (((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL || !((decl)->decl.initial)))
   do { int otime = get_run_time (); dwarfout_file_scope_decl (decl, 1); symout_time += get_run_time () - otime; } while (0);

      }
  }



  weak_finish ();
  if (write_symbols == DWARF_DEBUG)
    do { int otime = get_run_time (); { dwarfout_finish (); }; symout_time += get_run_time () - otime; } while (0)


        ;




  if (!output_bytecode)
    {
      end_final (main_input_filename);


      do { mips_asm_file_end(asm_out_file); fprintf ((asm_out_file), "\t%s\t\"GCC: (GNU) %s\"\n", ".ident", version_string); } while (0);

    }



  lang_finish ();

  if (output_bytecode)
    bc_write_file (asm_out_file);



  if (flag_gen_aux_info)
    {
      fclose (aux_info_file);
      if (errorcount)
 unlink (aux_info_file_name);
    }

  if (rtl_dump)
    fclose (rtl_dump_file);

  if (jump_opt_dump)
    fclose (jump_opt_dump_file);

  if (cse_dump)
    fclose (cse_dump_file);

  if (loop_dump)
    fclose (loop_dump_file);

  if (cse2_dump)
    fclose (cse2_dump_file);

  if (flow_dump)
    fclose (flow_dump_file);

  if (combine_dump)
    {
      dump_combine_total_stats (combine_dump_file);
      fclose (combine_dump_file);
    }

  if (sched_dump)
    fclose (sched_dump_file);

  if (local_reg_dump)
    fclose (local_reg_dump_file);

  if (global_reg_dump)
    fclose (global_reg_dump_file);

  if (sched2_dump)
    fclose (sched2_dump_file);

  if (jump2_opt_dump)
    fclose (jump2_opt_dump_file);

  if (dbr_sched_dump)
    fclose (dbr_sched_dump_file);
  fclose (finput);
  if (ferror (asm_out_file) != 0 || fclose (asm_out_file) != 0)
    fatal_io_error (asm_file_name);



  if (! quiet_flag)
    {
      fprintf (
              (__acrt_iob_func(2))
                    ,"\n");
      print_time ("parse", parse_time);

      if (!output_bytecode)
 {
   print_time ("integration", integration_time);
   print_time ("jump", jump_time);
   print_time ("cse", cse_time);
   print_time ("loop", loop_time);
   print_time ("cse2", cse2_time);
   print_time ("flow", flow_time);
   print_time ("combine", combine_time);
   print_time ("sched", sched_time);
   print_time ("local-alloc", local_alloc_time);
   print_time ("global-alloc", global_alloc_time);
   print_time ("sched2", sched2_time);
   print_time ("dbranch", dbr_sched_time);
   print_time ("shorten-branch", shorten_branch_time);
   print_time ("stack-reg", stack_reg_time);
   print_time ("final", final_time);
   print_time ("varconst", varconst_time);
   print_time ("symout", symout_time);
   print_time ("dump", dump_time);
 }
    }
}
void
rest_of_decl_compilation(tree decl, char *asmspec, int top_level, int at_end) asm("_rest_of_decl_compilation");
void
rest_of_decl_compilation(tree decl, char *asmspec, int top_level, int at_end)
{
  if (((decl)->common.static_flag) || ((decl)->decl.external_flag)
      || ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    do { int otime = get_run_time (); { make_decl_rtl (decl, asmspec, top_level); if (! (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->decl.external_flag) && ((decl)->common.readonly_flag) && ((decl)->decl.initial) != 0 && ((decl)->decl.initial) != error_mark_node)) if (! (! at_end && top_level && (((decl)->decl.initial) == 0 || ((decl)->decl.initial) == error_mark_node))) assemble_variable (decl, top_level, at_end, 0); if (decl == last_assemble_variable_decl) { do { char *name = ((((((decl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr); if (!flag_inhibit_size_directive && ((decl)->decl.size) && ! at_end && top_level && ((decl)->decl.initial) == error_mark_node && !size_directive_output) { size_directive_output = 1; fprintf (asm_out_file, "\t%s\t ", ".size"); assemble_name (asm_out_file, name); fprintf (asm_out_file, ",%d\n", int_size_in_bytes (((decl)->common.type))); } } while (0); } }; varconst_time += get_run_time () - otime; } while (0)
        ;
  else if (((decl)->decl.regdecl_flag) && asmspec != 0)
    {
      if (decode_reg_name (asmspec) >= 0)
 {
   ((decl)->decl.rtl) = 0;
   make_decl_rtl (decl, asmspec, top_level);
 }
      else
 error ("invalid register name `%s' for register variable", asmspec);
    }
}



void
rest_of_type_compilation(tree type, int toplev) asm("_rest_of_type_compilation");
void
rest_of_type_compilation(tree type, int toplev)
{
}







void
rest_of_compilation(tree decl) asm("_rest_of_compilation");
void
rest_of_compilation(tree decl)
{
  register rtx insns;
  int start_time = get_run_time ();
  int tem;



  tree saved_block_tree = 0;

  tree saved_arguments = 0;
  int failure = 0;

  if (output_bytecode)
    return;




  if (((decl)->decl.saved_insns.r) == 0)
    {
      int specd = ((decl)->decl.inline_flag);
      char *lose;


      if (specd || flag_inline_functions)
 do { int otime = get_run_time (); { lose = function_cannot_inline_p (decl); if (lose || ! optimize) { if (warn_inline && specd) warning_with_decl (decl, lose); ((decl)->decl.inline_flag) = 0; ((decl)->decl.abstract_origin) = 0; if (((decl)->decl.external_flag)) { ((decl)->decl.initial) = 0; goto exit_rest_of_compilation; } } else ((decl)->decl.inline_flag) = 1; }; integration_time += get_run_time () - otime; } while (0)
     ;

      insns = get_insns ();



      if (rtl_dump)
 do { int otime = get_run_time (); { fprintf (rtl_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); if (((decl)->decl.saved_insns.r)) fprintf (rtl_dump_file, ";; (integrable)\n\n"); print_rtl (rtl_dump_file, insns); fflush (rtl_dump_file); }; dump_time += get_run_time () - otime; } while (0)







     ;







      if (((decl)->decl.defer_output)
   || ((specd || ((decl)->decl.inline_flag))
       && ((! ((decl)->common.public_flag) && ! ((decl)->common.addressable_flag)
     && ! flag_keep_inline_functions)
    || ((decl)->decl.external_flag))))
 {
   ((decl)->decl.defer_output) = 1;


   if (! warn_return_type)
     {




       if (write_symbols == DWARF_DEBUG)
  {
    set_decl_abstract_flags (decl, 1);
    do { int otime = get_run_time (); dwarfout_file_scope_decl (decl, 0); symout_time += get_run_time () - otime; } while (0);
    set_decl_abstract_flags (decl, 0);
  }

       do { int otime = get_run_time (); save_for_inline_nocopy (decl); integration_time += get_run_time () - otime; } while (0);
       goto exit_rest_of_compilation;
     }
 }



      if (((decl)->decl.inline_flag) || ((decl)->decl.defer_output))
 {





   if (write_symbols == DWARF_DEBUG)
     {
       set_decl_abstract_flags (decl, 1);
       do { int otime = get_run_time (); dwarfout_file_scope_decl (decl, 0); symout_time += get_run_time () - otime; } while (0);
       set_decl_abstract_flags (decl, 0);
     }

   saved_block_tree = ((decl)->decl.initial);
   saved_arguments = ((decl)->decl.arguments);
   do { int otime = get_run_time (); save_for_inline_copying (decl); integration_time += get_run_time () - otime; } while (0);
 }



      if (specd && ((decl)->decl.external_flag))
 goto exit_rest_of_compilation;
    }

  if (! ((decl)->decl.defer_output))
    ((decl)->common.asm_written_flag) = 1;




  rtx_equal_function_value_matters = 0;


  if ((rtl_dump_and_exit || flag_syntax_only) && !warn_return_type)
    {
      goto exit_rest_of_compilation;
    }






  rtl_in_current_obstack ();
  insns = get_insns ();



  unshare_all_rtl (insns);



  instantiate_virtual_regs (current_function_decl, get_insns ());
  if (optimize > 0 || extra_warnings || warn_return_type

      || ((decl)->common.volatile_flag))
    {
      do { int otime = get_run_time (); reg_scan (insns, max_reg_num (), 0); jump_time += get_run_time () - otime; } while (0);
      do { int otime = get_run_time (); jump_optimize (insns, 0, 0, 1); jump_time += get_run_time () - otime; } while (0);
    }


  if (rtl_dump_and_exit || flag_syntax_only || ((decl)->decl.defer_output))
    goto exit_rest_of_compilation;



  if (jump_opt_dump)
    do { int otime = get_run_time (); { fprintf (jump_opt_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); print_rtl (jump_opt_dump_file, insns); fflush (jump_opt_dump_file); }; dump_time += get_run_time () - otime; } while (0)





        ;






  if (cse_dump)
    do { int otime = get_run_time (); { fprintf (cse_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (optimize > 0)
    {
      do { int otime = get_run_time (); reg_scan (insns, max_reg_num (), 1); cse_time += get_run_time () - otime; } while (0);

      if (flag_thread_jumps)

 do { int otime = get_run_time (); thread_jumps (insns, max_reg_num (), 1); jump_time += get_run_time () - otime; } while (0);

      do { int otime = get_run_time (); tem = cse_main (insns, max_reg_num (), 0, cse_dump_file); cse_time += get_run_time () - otime; } while (0)
                        ;
      do { int otime = get_run_time (); delete_dead_from_cse (insns, max_reg_num ()); cse_time += get_run_time () - otime; } while (0);

      if (tem || optimize > 1)
 do { int otime = get_run_time (); jump_optimize (insns, 0, 0, 0); jump_time += get_run_time () - otime; } while (0);
    }



  if (cse_dump)
    do { int otime = get_run_time (); { print_rtl (cse_dump_file, insns); fflush (cse_dump_file); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (loop_dump)
    do { int otime = get_run_time (); { fprintf (loop_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



        ;



  if (optimize > 0)
    {
      do { int otime = get_run_time (); { loop_optimize (insns, loop_dump_file); }; loop_time += get_run_time () - otime; } while (0)


          ;
    }



  if (loop_dump)
    do { int otime = get_run_time (); { print_rtl (loop_dump_file, insns); fflush (loop_dump_file); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (cse2_dump)
    do { int otime = get_run_time (); { fprintf (cse2_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (optimize > 0 && flag_rerun_cse_after_loop)
    {





      do { int otime = get_run_time (); reg_scan (insns, max_reg_num (), 0); jump_time += get_run_time () - otime; } while (0);
      do { int otime = get_run_time (); jump_optimize (insns, 0, 0, 1); jump_time += get_run_time () - otime; } while (0);

      do { int otime = get_run_time (); reg_scan (insns, max_reg_num (), 0); cse2_time += get_run_time () - otime; } while (0);
      do { int otime = get_run_time (); tem = cse_main (insns, max_reg_num (), 1, cse2_dump_file); cse2_time += get_run_time () - otime; } while (0)
                          ;
      if (tem)
 do { int otime = get_run_time (); jump_optimize (insns, 0, 0, 0); jump_time += get_run_time () - otime; } while (0);
    }

  if (optimize > 0 && flag_thread_jumps)


    do { int otime = get_run_time (); thread_jumps (insns, max_reg_num (), 0); jump_time += get_run_time () - otime; } while (0);



  if (cse2_dump)
    do { int otime = get_run_time (); { print_rtl (cse2_dump_file, insns); fflush (cse2_dump_file); }; dump_time += get_run_time () - otime; } while (0)



        ;



  cse_not_expected = 1;





  if (optimize > 0)
    obey_regdecls = 0;

  regclass_init ();




  if (flow_dump)
    do { int otime = get_run_time (); { fprintf (flow_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (obey_regdecls)
    {
      do { int otime = get_run_time (); { regclass (insns, max_reg_num ()); stupid_life_analysis (insns, max_reg_num (), flow_dump_file); }; flow_time += get_run_time () - otime; } while (0)




          ;
    }
  else
    {



      do { int otime = get_run_time (); flow_analysis (insns, max_reg_num (), flow_dump_file); flow_time += get_run_time () - otime; } while (0)
                      ;
      if (warn_uninitialized)
 {
   uninitialized_vars_warning (((decl)->decl.initial));
   setjmp_args_warning ();
 }
    }



  if (flow_dump)
    do { int otime = get_run_time (); { print_rtl (flow_dump_file, insns); fflush (flow_dump_file); }; dump_time += get_run_time () - otime; } while (0)



        ;



  if (optimize > 0)
    do { int otime = get_run_time (); combine_instructions (insns, max_reg_num ()); combine_time += get_run_time () - otime; } while (0);



  if (combine_dump)
    do { int otime = get_run_time (); { fprintf (combine_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); dump_combine_stats (combine_dump_file); print_rtl (combine_dump_file, insns); fflush (combine_dump_file); }; dump_time += get_run_time () - otime; } while (0)






        ;




  if (sched_dump)
    do { int otime = get_run_time (); { fprintf (sched_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



        ;

  if (optimize > 0 && flag_schedule_insns)
    {



      do { int otime = get_run_time (); schedule_insns (sched_dump_file); sched_time += get_run_time () - otime; } while (0);
    }



  if (sched_dump)
    do { int otime = get_run_time (); { print_rtl (sched_dump_file, insns); fflush (sched_dump_file); }; dump_time += get_run_time () - otime; } while (0)



        ;




  if (!obey_regdecls)
    do { int otime = get_run_time (); { regclass (insns, max_reg_num ()); local_alloc (); }; local_alloc_time += get_run_time () - otime; } while (0)



        ;



  if (local_reg_dump)
    do { int otime = get_run_time (); { fprintf (local_reg_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); dump_flow_info (local_reg_dump_file); dump_local_alloc (local_reg_dump_file); print_rtl (local_reg_dump_file, insns); fflush (local_reg_dump_file); }; dump_time += get_run_time () - otime; } while (0)







        ;

  if (global_reg_dump)
    do { int otime = get_run_time (); fprintf (global_reg_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); dump_time += get_run_time () - otime; } while (0)

                                               ;





  do { int otime = get_run_time (); { if (!obey_regdecls) failure = global_alloc (global_reg_dump_file); else failure = reload (insns, 0, global_reg_dump_file); }; global_alloc_time += get_run_time () - otime; } while (0)





      ;

  if (global_reg_dump)
    do { int otime = get_run_time (); { dump_global_regs (global_reg_dump_file); print_rtl (global_reg_dump_file, insns); fflush (global_reg_dump_file); }; dump_time += get_run_time () - otime; } while (0)




        ;

  if (failure)
    goto exit_rest_of_compilation;

  reload_completed = 1;






  thread_prologue_and_epilogue_insns (insns);

  if (optimize > 0 && flag_schedule_insns_after_reload)
    {
      if (sched2_dump)
 do { int otime = get_run_time (); { fprintf (sched2_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); }; dump_time += get_run_time () - otime; } while (0)



     ;




      do { int otime = get_run_time (); schedule_insns (sched2_dump_file); sched2_time += get_run_time () - otime; } while (0);



      if (sched2_dump)
 do { int otime = get_run_time (); { print_rtl (sched2_dump_file, insns); fflush (sched2_dump_file); }; dump_time += get_run_time () - otime; } while (0)



     ;
    }
  if (optimize > 0)
    {
      do { int otime = get_run_time (); jump_optimize (insns, 1, 1, 0); jump_time += get_run_time () - otime; } while (0);
    }



  if (jump2_opt_dump)
    do { int otime = get_run_time (); { fprintf (jump2_opt_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); print_rtl (jump2_opt_dump_file, insns); fflush (jump2_opt_dump_file); }; dump_time += get_run_time () - otime; } while (0)





        ;
  if (optimize > 0 && flag_delayed_branch)
    {
      do { int otime = get_run_time (); dbr_schedule (insns, dbr_sched_dump_file); dbr_sched_time += get_run_time () - otime; } while (0);
      if (dbr_sched_dump)
 {
   do { int otime = get_run_time (); { fprintf (dbr_sched_dump_file, "\n;; Function %s\n\n", ((((decl)->decl.name))->identifier.pointer)); print_rtl (dbr_sched_dump_file, insns); fflush (dbr_sched_dump_file); }; dump_time += get_run_time () - otime; } while (0)





     ;
 }
    }



  do { int otime = get_run_time (); { shorten_branches (get_insns ()); }; shorten_branch_time += get_run_time () - otime; } while (0)


      ;
  do { int otime = get_run_time (); { rtx x; char *fnname; x = ((decl)->decl.rtl); if (((x)->code) != MEM) abort (); x = ((x)->fld[0].rtx); if (((x)->code) != SYMBOL_REF) abort (); fnname = ((x)->fld[0].rtstr); assemble_start_function (decl, fnname); final_start_function (insns, asm_out_file, optimize); final (insns, asm_out_file, optimize, 0); final_end_function (insns, asm_out_file, optimize); assemble_end_function (decl, fnname); fflush (asm_out_file); }; final_time += get_run_time () - otime; } while (0)
      ;
  if (write_symbols == DWARF_DEBUG)
    do { int otime = get_run_time (); dwarfout_file_scope_decl (decl, 0); symout_time += get_run_time () - otime; } while (0);


 exit_rest_of_compilation:
  if (saved_block_tree != 0)
    ((decl)->decl.initial) = saved_block_tree;
  if (saved_arguments != 0)
    ((decl)->decl.arguments) = saved_arguments;

  reload_completed = 0;


  init_insn_lengths ();




  clear_const_double_mem ();



  resume_temporary_allocation ();




  parse_time -= get_run_time () - start_time;
}





int
main(int argc, char **argv, char **envp) asm("_main");
int
main(int argc, char **argv, char **envp)
{
  register int i;
  char *filename = 0;
  int flag_print_mem = 0;
  int version_flag = 0;
  char *p;


  save_argc = argc;
  save_argv = argv;

  p = argv[0] + strlen (argv[0]);
  while (p != argv[0] && p[-1] != '/'

  && p[-1] != '\\'

  )
    --p;
  progname = p;
  signal (
         8
               , float_signal);





  decl_printable_name = decl_name;
  lang_expand_expr = (struct n64_tag_rtx_def *(*)(...)) do_abort;
  interim_eh_hook = interim_eh;


  flag_signed_char = 1;







  for (i = 1; i < argc; i++)
    {
      if (!strcmp (argv[i], "-O"))
 {
   optimize = 1;
 }
      else if (argv[i][0] == '-' && argv[i][1] == 'O')
 {

   char *p = &argv[i][2];
   int c;

   while (c = *p++)
     if (! (c >= '0' && c <= '9'))
       break;
   if (c == 0)
     optimize = atoi (&argv[i][2]);
 }
    }

  obey_regdecls = (optimize == 0);
  if (optimize == 0)
    {
      flag_no_inline = 1;
      warn_inline = 0;
    }

  if (optimize >= 1)
    {
      flag_defer_pop = 1;
      flag_thread_jumps = 1;

      flag_delayed_branch = 1;


      flag_omit_frame_pointer = 1;

    }

  if (optimize >= 2)
    {
      flag_cse_follow_jumps = 1;
      flag_cse_skip_blocks = 1;
      flag_expensive_optimizations = 1;
      flag_strength_reduce = 1;
      flag_rerun_cse_after_loop = 1;
      flag_caller_saves = 1;
      flag_force_mem = 1;

      flag_schedule_insns = 1;
      flag_schedule_insns_after_reload = 1;

    }

  if (optimize >= 3)
    {
      flag_inline_functions = 1;
    }







  init_reg_sets ();

  target_flags = 0;
  set_target_switch ("");

  for (i = 1; i < argc; i++)
    {
      int j;


      for (j = 0; lang_options[j] != 0; j++)
 if (!strncmp (argv[i], lang_options[j],
        strlen (lang_options[j])))
   break;
      if (lang_options[j] != 0)


 lang_decode_option (argv[i]);
      else if (argv[i][0] == '-' && argv[i][1] != 0)
 {
   register char *str = argv[i] + 1;
   if (str[0] == 'Y')
     str++;

   if (str[0] == 'm')
     set_target_switch (&str[1]);
   else if (!strcmp (str, "dumpbase"))
     {
       dump_base_name = argv[++i];
     }
   else if (str[0] == 'd')
     {
       register char *p = &str[1];
       while (*p)
  switch (*p++)
    {
     case 'a':
       combine_dump = 1;
       dbr_sched_dump = 1;
       flow_dump = 1;
       global_reg_dump = 1;
       jump_opt_dump = 1;
       jump2_opt_dump = 1;
       local_reg_dump = 1;
       loop_dump = 1;
       rtl_dump = 1;
       cse_dump = 1, cse2_dump = 1;
       sched_dump = 1;
       sched2_dump = 1;
      stack_reg_dump = 1;
      break;
    case 'k':
      stack_reg_dump = 1;
      break;
    case 'c':
      combine_dump = 1;
      break;
    case 'd':
      dbr_sched_dump = 1;
      break;
    case 'f':
      flow_dump = 1;
      break;
    case 'g':
      global_reg_dump = 1;
      break;
    case 'j':
      jump_opt_dump = 1;
      break;
    case 'J':
      jump2_opt_dump = 1;
      break;
    case 'l':
      local_reg_dump = 1;
      break;
    case 'L':
      loop_dump = 1;
      break;
    case 'm':
      flag_print_mem = 1;
      break;
    case 'p':
      flag_print_asm_name = 1;
      break;
    case 'r':
      rtl_dump = 1;
      break;
    case 's':
      cse_dump = 1;
      break;
    case 't':
      cse2_dump = 1;
      break;
    case 'S':
      sched_dump = 1;
      break;
    case 'R':
      sched2_dump = 1;
      break;
    case 'y':
      set_yydebug (1);
      break;

    case 'x':
      rtl_dump_and_exit = 1;
      break;
    }
     }
   else if (str[0] == 'f')
     {
       register char *p = &str[1];
       int found = 0;





       for (j = 0;
     !found && j < sizeof (f_options) / sizeof (f_options[0]);
     j++)
  {
    if (!strcmp (p, f_options[j].string))
      {
        *f_options[j].variable = f_options[j].on_value;


        found = 1;
      }
    if (p[0] == 'n' && p[1] == 'o' && p[2] == '-'
        && ! strcmp (p+3, f_options[j].string))
      {
        *f_options[j].variable = ! f_options[j].on_value;
        found = 1;
      }
  }

       if (found)
  ;
       else if (!strncmp (p, "fixed-", 6))
  fix_register (&p[6], 1, 1);
       else if (!strncmp (p, "call-used-", 10))
  fix_register (&p[10], 0, 1);
       else if (!strncmp (p, "call-saved-", 11))
  fix_register (&p[11], 0, 0);
       else
  error ("Invalid option `%s'", argv[i]);
     }
   else if (str[0] == 'O')
     {
       register char *p = str+1;
       while (*p && *p >= '0' && *p <= '9')
  p++;
       if (*p == '\0')
  ;
       else
  error ("Invalid option `%s'", argv[i]);
     }
   else if (!strcmp (str, "pedantic"))
     pedantic = 1;
   else if (!strcmp (str, "pedantic-errors"))
     flag_pedantic_errors = pedantic = 1;
   else if (!strcmp (str, "quiet"))
     quiet_flag = 1;
   else if (!strcmp (str, "version"))
     version_flag = 1;
   else if (!strcmp (str, "w"))
     inhibit_warnings = 1;
   else if (!strcmp (str, "W"))
     {
       extra_warnings = 1;



       if (warn_uninitialized != 1)
  warn_uninitialized = 2;
     }
   else if (str[0] == 'W')
     {
       register char *p = &str[1];
       int found = 0;





       for (j = 0;
     !found && j < sizeof (W_options) / sizeof (W_options[0]);
     j++)
  {
    if (!strcmp (p, W_options[j].string))
      {
        *W_options[j].variable = W_options[j].on_value;


        found = 1;
      }
    if (p[0] == 'n' && p[1] == 'o' && p[2] == '-'
        && ! strcmp (p+3, W_options[j].string))
      {
        *W_options[j].variable = ! W_options[j].on_value;
        found = 1;
      }
  }

       if (found)
  ;
       else if (!strncmp (p, "id-clash-", 9))
  {
    char *endp = p + 9;

    while (*endp)
      {
        if (*endp >= '0' && *endp <= '9')
   endp++;
        else
   {
     error ("Invalid option `%s'", argv[i]);
     goto id_clash_lose;
   }
      }
    warn_id_clash = 1;
    id_clash_len = atoi (str + 10);
  id_clash_lose: ;
  }
       else if (!strncmp (p, "larger-than-", 12))
  {
    char *endp = p + 12;

    while (*endp)
      {
        if (*endp >= '0' && *endp <= '9')
   endp++;
        else
   {
     error ("Invalid option `%s'", argv[i]);
     goto larger_than_lose;
   }
      }
    warn_larger_than = 1;
    larger_than_size = atoi (str + 13);
  larger_than_lose: ;
  }
       else
  error ("Invalid option `%s'", argv[i]);
     }
   else if (!strcmp (str, "p"))
     {
       if (!output_bytecode)
  profile_flag = 1;
       else
  error ("profiling not supported in bytecode compilation");
     }
   else if (!strcmp (str, "a"))
     {

       warning ("`-a' option (basic block profile) not supported");



     }
   else if (str[0] == 'g')
     {
       char *p = str + 1;
       char *q;
       unsigned len;
       unsigned level;

       while (*p && (*p < '0' || *p > '9'))
  p++;
       len = p - str;
       q = p;
       while (*q && (*q >= '0' && *q <= '9'))
  q++;
       if (*p)
  level = atoi (p);
       else
  level = 2;
       if (*q || level > 3)
  {
    warning ("invalid debug level specification in option: `-%s'",
      str);
    warning ("no debugging information will be generated");
    level = 0;
  }
       if (write_symbols != NO_DEBUG)
  ;
       else if (!strncmp (str, "g", len))
  write_symbols = DWARF_DEBUG;
       else if (!strncmp (str, "ggdb", len))
  write_symbols = DWARF_DEBUG;
       else if (!strncmp (str, "gdwarf", len))
  write_symbols = DWARF_DEBUG;




       if (write_symbols == DWARF_DEBUG && !strncmp (str, "ggdb", len)
    && len >= 2)
  use_gnu_debug_info_extensions = 1;
       else if (write_symbols == DWARF_DEBUG && !strcmp (str, "gdwarf+"))
  use_gnu_debug_info_extensions = 1;
       else if (write_symbols == DWARF_DEBUG
         && !strncmp (str, "gdwarf", len) && len >= 2)
  use_gnu_debug_info_extensions = 0;
       else
  use_gnu_debug_info_extensions = 1;
       if (write_symbols == NO_DEBUG)
  warning ("`-%s' not supported by this configuration of GCC",
    str);
       else if (level == 0)
  write_symbols = NO_DEBUG;
       else
  debug_info_level = (n64_enum_debug_info_level) level;
     }
   else if (!strcmp (str, "o"))
     {
       asm_file_name = argv[++i];
     }
   else if (str[0] == 'G')
     {
       g_switch_set = 1;
       g_switch_value = atoi ((str[1] != '\0') ? str+1 : argv[++i]);
     }
   else if (!strncmp (str, "aux-info", 8))
     {
       flag_gen_aux_info = 1;
       aux_info_file_name = (str[8] != '\0' ? str+8 : argv[++i]);
     }
   else
     error ("Invalid option `%s'", argv[i]);
 }
      else if (argv[i][0] == '+')
 error ("Invalid option `%s'", argv[i]);
      else
 filename = argv[i];
    }



  if (output_bytecode)
    {


      fatal ("-fbytecode not supporter for this target");



    }

  if (optimize == 0)
    {


      flag_no_inline = 1;
      warn_inline = 0;




      if (warn_uninitialized == 1)
 warning ("-Wuninitialized is not supported without -O");
    }


  if (write_symbols == DWARF_DEBUG
      && strcmp (language_string, "GNU C++") == 0)
    {
      warning ("-g option not supported for C++ on systems using the DWARF debugging format");
      write_symbols = NO_DEBUG;
    }




  override_options ();




  if (flag_unroll_all_loops)
    flag_unroll_loops = 1;




  if (flag_unroll_loops)
    {
      flag_strength_reduce = 1;
      flag_rerun_cse_after_loop = 1;
    }
  if (version_flag)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "%s version %s", language_string, version_string);

      fprintf (
     (__acrt_iob_func(2))
     , " (MIPS GNU/ELF)");;





      fprintf (
              (__acrt_iob_func(2))
                    , " compiled by GNU C version %s.\n", "14-posix");



      if (! quiet_flag)
 print_switch_values ();
    }

  compile_file (filename);
  if (errorcount)
    exit (33);
  if (sorrycount)
    exit (33);
  exit (0);
  return 0;
}
struct {char *name; int value;} target_switches []
  = { {"int64", 0x00000001 | 0x00000002}, {"long64", 0x00000002}, {"mips-as", -0x00000010}, {"gas", 0x00000010}, {"rnames", 0x00000020}, {"no-rnames", -0x00000020}, {"gpOPT", 0x00000008}, {"gpopt", 0x00000008}, {"no-gpOPT", -0x00000008}, {"no-gpopt", -0x00000008}, {"stats", 0x00000040}, {"no-stats", -0x00000040}, {"memcpy", 0x00000080}, {"no-memcpy", -0x00000080}, {"mips-tfile", 0x00000000}, {"no-mips-tfile", -0x00000000}, {"soft-float", 0x00000100}, {"hard-float", -0x00000100}, {"fp64", 0x00000200}, {"fp32", -0x00000200}, {"gp64", 0x00002000}, {"gp32", -0x00002000}, {"abicalls", 0x00000400}, {"no-abicalls", -0x00000400}, {"half-pic", 0x00000800}, {"no-half-pic", -0x00000800}, {"long-calls", 0x00001000}, {"no-long-calls", -0x00001000}, {"embedded-pic", 0x00004000}, {"no-embedded-pic", -0x00004000}, {"embedded-data", 0x00008000}, {"no-embedded-data", -0x00008000}, {"eb", 0x00010000}, {"el", -0x00010000}, {"single-float", 0x00020000}, {"double-float", -0x00020000}, {"mad", 0x00040000}, {"no-mad", -0x00040000}, {"4650", 0x00040000 | 0x00020000}, {"debug", 0x40000000}, {"debuga", 0x20000000}, {"debugb", 0x10000000}, {"debugc", 0x08000000}, {"debugd", 0x04000000}, {"debuge", 0x02000000}, {"debugf", 0x01000000}, {"debugg", 0x00800000}, {"debugh", 0x00400000}, {"debugi", 0x00200000}, {"debugj", 0x00100000}, {"", (0x00000010 | 16 | 0x00010000)} };




struct {char *prefix; char ** variable;} target_options []
  = { { "cpu=", &mips_cpu_string }, { "ips", &mips_isa_string }, { "abi=", &mips_abi_string } };




void
set_target_switch(char *name) asm("_set_target_switch");
void
set_target_switch(char *name)
{
  register int j;
  int valid = 0;

  for (j = 0; j < sizeof target_switches / sizeof target_switches[0]; j++)
    if (!strcmp (target_switches[j].name, name))
      {
 if (target_switches[j].value < 0)
   target_flags &= ~-target_switches[j].value;
 else
   target_flags |= target_switches[j].value;
 valid = 1;
      }


  if (!valid)
    for (j = 0; j < sizeof target_options / sizeof target_options[0]; j++)
      {
 int len = strlen (target_options[j].prefix);
 if (!strncmp (target_options[j].prefix, name, len))
   {
     *target_options[j].variable = name + len;
     valid = 1;
   }
      }


  if (!valid)
    error ("Invalid option `%s'", name);
}



static int line_position;



static void
print_single_switch(char *type, char *name) asm("_print_single_switch");
static void
print_single_switch(char *type, char *name)
{
  fprintf (
          (__acrt_iob_func(2))
                , " %s%s", type, name);

  line_position += strlen (type) + strlen (name) + 1;

  if (line_position > 65)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "\n\t");
      line_position = 8;
    }
}



static void
print_switch_values(void) asm("_print_switch_values");
static void
print_switch_values(void)
{
  register int j;

  fprintf (
          (__acrt_iob_func(2))
                , "enabled:");
  line_position = 8;

  for (j = 0; j < sizeof f_options / sizeof f_options[0]; j++)
    if (*f_options[j].variable == f_options[j].on_value)
      print_single_switch ("-f", f_options[j].string);

  for (j = 0; j < sizeof W_options / sizeof W_options[0]; j++)
    if (*W_options[j].variable == W_options[j].on_value)
      print_single_switch ("-W", W_options[j].string);

  for (j = 0; j < sizeof target_switches / sizeof target_switches[0]; j++)
    if (target_switches[j].name[0] != '\0'
 && target_switches[j].value > 0
 && ((target_switches[j].value & target_flags)
     == target_switches[j].value))
      print_single_switch ("-m", target_switches[j].name);

  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}

