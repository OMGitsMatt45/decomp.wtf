// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/macro.c
/* macro.c - macro support for gas and gasp
   Copyright (C) 1994, 1995 Free Software Foundation, Inc.

   Written by Steve and Judy Chamberlain of Cygnus Support,
      sac@cygnus.com

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GAS; see the file COPYING.  If not, write to the Free
   Software Foundation, 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_formal_struct;
struct n64_tag_hash_control;
struct n64_tag_hash_entry;
struct n64_tag_le;
struct n64_tag_macro_struct;
struct n64_tag_sb;











extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");
typedef struct n64_tag_sb
  {
    char *ptr;
    int len;
    int pot;
    struct n64_tag_le *item;
  }
sb;


typedef struct n64_tag_le
  {
    struct n64_tag_le *next;
    int size;
    char data[1];
  }
sb_element;


typedef struct
  {
    sb_element *size[30];
  } sb_list_vector;

extern int string_count[30];

extern void sb_build (sb *, int) asm("_sb_build");
extern void sb_new (sb *) asm("_sb_new");
extern void sb_kill (sb *) asm("_sb_kill");
extern void sb_add_sb (sb *, sb *) asm("_sb_add_sb");
extern void sb_reset (sb *) asm("_sb_reset");
extern void sb_add_char (sb *, int) asm("_sb_add_char");
extern void sb_add_string (sb *, const char *) asm("_sb_add_string");
extern void sb_add_buffer (sb *, const char *, int) asm("_sb_add_buffer");
extern void sb_print (FILE *, sb *) asm("_sb_print");
extern void sb_print_at (FILE *, int, sb *) asm("_sb_print_at");
extern char *sb_name (sb *) asm("_sb_name");
extern char *sb_terminate (sb *) asm("_sb_terminate");
extern int sb_skip_white (int, sb *) asm("_sb_skip_white");
extern int sb_skip_comma (int, sb *) asm("_sb_skip_comma");


extern void input_scrub_include_sb (sb *, char *) asm("_input_scrub_include_sb");
struct n64_tag_hash_entry
{
  const char *hash_string;


  void * hash_value;
};



struct n64_tag_hash_control
{
  struct n64_tag_hash_entry *hash_where;
  int hash_sizelog;
  int hash_mask;
  int hash_full;

  struct n64_tag_hash_entry *hash_wall;

  int hash_stat[(6)];

};



struct n64_tag_hash_control *hash_new (void) asm("_hash_new");
void hash_die (struct n64_tag_hash_control *) asm("_hash_die");
void hash_say (struct n64_tag_hash_control *, int *buffer, int bufsiz) asm("_hash_say");

void * hash_delete (struct n64_tag_hash_control *, const char *str) asm("_hash_delete");

void * hash_replace (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_replace");

const char *hash_insert (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_insert")
              ;

char *hash_apply (struct n64_tag_hash_control *, char *(*fn) (const char *str, void * val)) asm("_hash_apply")
                                             ;

void * hash_find (struct n64_tag_hash_control *, const char *str) asm("_hash_find");

const char *hash_jam (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_jam")
                  ;
extern int macro_defined;

extern int buffer_and_nest
  (const char *, const char *, sb *, int (*) (sb *)) asm("_buffer_and_nest");
extern void macro_init
  (int alternate, int mri, int strip_at, int (*) (const char *, int, sb *, int *)) asm("_macro_init")
                                                       ;
extern const char *define_macro
  (int idx, sb *in, sb *label, int (*get_line) (sb *)) asm("_define_macro");
extern int check_macro (const char *, sb *, int, const char **) asm("_check_macro");
extern void delete_macro (const char *) asm("_delete_macro");
extern const char *expand_irp
  (int, int, sb *, sb *, int (*) (sb *), int) asm("_expand_irp");
typedef struct n64_tag_formal_struct
  {
    struct n64_tag_formal_struct *next;
    sb name;
    sb def;
    sb actual;
    int index;
  }
formal_entry;
typedef struct n64_tag_macro_struct
  {
    sb sub;
    int formal_count;
    formal_entry *formals;
    struct n64_tag_hash_control *formal_hash;
  }
macro_entry;



static int get_token (int, sb *, sb *) asm("_get_token");
static int getstring (int, sb *, sb *) asm("_getstring");
static int get_any_string (int, sb *, sb *, int, int) asm("_get_any_string");
static int do_formals (macro_entry *, int, sb *) asm("_do_formals");
static int get_apost_token (int, sb *, sb *, int) asm("_get_apost_token");
static int sub_actual
  (int, sb *, sb *, struct n64_tag_hash_control *, int, sb *, int) asm("_sub_actual");
static const char *macro_expand_body
  (sb *, sb *, formal_entry *, struct n64_tag_hash_control *, int, int) asm("_macro_expand_body");
static const char *macro_expand (int, sb *, macro_entry *, sb *, int) asm("_macro_expand");
static struct n64_tag_hash_control *macro_hash;



int macro_defined;



static int macro_alternate;



static int macro_mri;



static int macro_strip_at;



static int (*macro_expr) (const char *, int, sb *, int *);



static int macro_number;



void
macro_init(int alternate, int mri, int strip_at, int (*expr) (const char *, int, sb *, int *)) asm("_macro_init");
void
macro_init(int alternate, int mri, int strip_at, int (*expr) (const char *, int, sb *, int *))
{
  macro_hash = hash_new ();
  macro_defined = 0;
  macro_alternate = alternate;
  macro_mri = mri;
  macro_strip_at = strip_at;
  macro_expr = expr;
}







int
buffer_and_nest(const char *from, const char *to, sb *ptr, int (*get_line) (sb *)) asm("_buffer_and_nest");
int
buffer_and_nest(const char *from, const char *to, sb *ptr, int (*get_line) (sb *))
{
  int from_len = strlen (from);
  int to_len = strlen (to);
  int depth = 1;
  int line_start = ptr->len;

  int more = get_line (ptr);

  while (more)
    {

      int i = line_start;

      if (! macro_alternate && ! macro_mri)
 {






   while (i < ptr->len && ((ptr->ptr[i]) == ' ' || (ptr->ptr[i]) == '\t'))
     i++;


   while (i < ptr->len
   && (isalnum ((unsigned char) ptr->ptr[i])
       || ptr->ptr[i] == '_'
       || ptr->ptr[i] == '$'))
     i++;


   if (i < ptr->len
       && ptr->ptr[i] == ':')
     i++;

 }

      while (i < ptr->len && ((ptr->ptr[i]) == ' ' || (ptr->ptr[i]) == '\t'))
 i++;

      if (i < ptr->len && (ptr->ptr[i] == '.'
      || macro_alternate
      || macro_mri))
 {
   if (ptr->ptr[i] == '.')
       i++;
   if (strncasecmp (ptr->ptr + i, from, from_len) == 0)
     depth++;
   if (strncasecmp (ptr->ptr + i, to, to_len) == 0)
     {
       depth--;
       if (depth == 0)
  {

    ptr->len = line_start;
    break;
  }
     }
 }


      sb_add_char (ptr, '\n');
      line_start = ptr->len;
      more = get_line (ptr);
    }


  return depth == 0;
}



static int
get_token(int idx, sb *in, sb *name) asm("_get_token");
static int
get_token(int idx, sb *in, sb *name)
{
  if (idx < in->len
      && (isalpha ((unsigned char) in->ptr[idx])
   || in->ptr[idx] == '_'
   || in->ptr[idx] == '$'))
    {
      sb_add_char (name, in->ptr[idx++]);
      while (idx < in->len
      && (isalnum ((unsigned char) in->ptr[idx])
   || in->ptr[idx] == '_'
   || in->ptr[idx] == '$'))
 {
   sb_add_char (name, in->ptr[idx++]);
 }
    }

  if (macro_alternate && idx < in->len && in->ptr[idx] == '&')
    idx++;
  return idx;
}



static int
getstring(int idx, sb *in, sb *acc) asm("_getstring");
static int
getstring(int idx, sb *in, sb *acc)
{
  idx = sb_skip_white (idx, in);

  while (idx < in->len
  && (in->ptr[idx] == '"'
      || in->ptr[idx] == '<'
      || (in->ptr[idx] == '\'' && macro_alternate)))
    {
      if (in->ptr[idx] == '<')
 {
   if (macro_alternate || macro_mri)
     {
       int nest = 0;
       idx++;
       while ((in->ptr[idx] != '>' || nest)
       && idx < in->len)
  {
    if (in->ptr[idx] == '!')
      {
        idx++ ;
        sb_add_char (acc, in->ptr[idx++]);
      }
    else
      {
        if (in->ptr[idx] == '>')
   nest--;
        if (in->ptr[idx] == '<')
   nest++;
        sb_add_char (acc, in->ptr[idx++]);
      }
  }
       idx++;
     }
   else
     {
       int code;
       idx++;
       idx = ((*macro_expr)
       ("character code in string must be absolute expression",
        idx, in, &code));
       sb_add_char (acc, code);





       idx++;
     }
 }
      else if (in->ptr[idx] == '"' || in->ptr[idx] == '\'')
 {
   char tchar = in->ptr[idx];
   idx++;
   while (idx < in->len)
     {
       if (macro_alternate && in->ptr[idx] == '!')
  {
    idx++ ;
    sb_add_char (acc, in->ptr[idx++]);
  }
       else
  {
    if (in->ptr[idx] == tchar)
      {
        idx++;
        if (idx >= in->len || in->ptr[idx] != tchar)
   break;
      }
    sb_add_char (acc, in->ptr[idx]);
    idx++;
  }
     }
 }
    }

  return idx;
}
static int
get_any_string(int idx, sb *in, sb *out, int expand, int pretend_quoted) asm("_get_any_string");
static int
get_any_string(int idx, sb *in, sb *out, int expand, int pretend_quoted)
{
  sb_reset (out);
  idx = sb_skip_white (idx, in);

  if (idx < in->len)
    {
      if (in->len > 2 && in->ptr[idx+1] == '\'' && ((in->ptr[idx]) == 'b' || (in->ptr[idx]) == 'B' || (in->ptr[idx]) == 'q' || (in->ptr[idx]) == 'Q' || (in->ptr[idx]) == 'h' || (in->ptr[idx]) == 'H' || (in->ptr[idx]) == 'd' || (in->ptr[idx]) == 'D'))
 {
   while (!((in->ptr[idx]) == ' ' || (in->ptr[idx]) == '\t' || (in->ptr[idx]) == ',' || (in->ptr[idx]) == '"' || (in->ptr[idx]) == ';' || (in->ptr[idx]) == '<' || (in->ptr[idx]) == '>' || (in->ptr[idx]) == ')' || (in->ptr[idx]) == '('))
     sb_add_char (out, in->ptr[idx++]);
 }
      else if (in->ptr[idx] == '%'
        && macro_alternate
        && expand)
 {
   int val;
   char buf[20];

   idx = (*macro_expr) ("% operator needs absolute expression",
          idx + 1,
          in,
          &val);
   sprintf(buf, "%d", val);
   sb_add_string (out, buf);
 }
      else if (in->ptr[idx] == '"'
        || in->ptr[idx] == '<'
        || (macro_alternate && in->ptr[idx] == '\''))
 {
   if (macro_alternate
       && ! macro_strip_at
       && expand)
     {

       sb_add_char (out, '\"');

       idx = getstring (idx, in, out);
       sb_add_char (out, '\"');
     }
   else
     {
       idx = getstring (idx, in, out);
     }
 }
      else
 {
   while (idx < in->len
   && (in->ptr[idx] == '"'
       || in->ptr[idx] == '\''
       || pretend_quoted
       || (in->ptr[idx] != ' '
    && in->ptr[idx] != '\t'
    && in->ptr[idx] != ','
    && in->ptr[idx] != '<')))
     {
       if (in->ptr[idx] == '"'
    || in->ptr[idx] == '\'')
  {
    char tchar = in->ptr[idx];
    sb_add_char (out, in->ptr[idx++]);
    while (idx < in->len
    && in->ptr[idx] != tchar)
      sb_add_char (out, in->ptr[idx++]);
    if (idx == in->len)
      return idx;
  }
       sb_add_char (out, in->ptr[idx++]);
     }
 }
    }

  return idx;
}



static int
do_formals(macro_entry *macro, int idx, sb *in) asm("_do_formals");
static int
do_formals(macro_entry *macro, int idx, sb *in)
{
  formal_entry **p = &macro->formals;

  macro->formal_count = 0;
  macro->formal_hash = hash_new ();
  while (idx < in->len)
    {
      formal_entry *formal;

      formal = (formal_entry *) xmalloc (sizeof (formal_entry));

      sb_new (&formal->name);
      sb_new (&formal->def);
      sb_new (&formal->actual);

      idx = sb_skip_white (idx, in);
      idx = get_token (idx, in, &formal->name);
      if (formal->name.len == 0)
 break;
      idx = sb_skip_white (idx, in);
      if (formal->name.len)
 {

   if (idx < in->len && in->ptr[idx] == '=')
     {

       idx = get_any_string (idx + 1, in, &formal->def, 1, 0);
     }
 }


      hash_jam (macro->formal_hash, sb_terminate (&formal->name), formal);

      formal->index = macro->formal_count;
      idx = sb_skip_comma (idx, in);
      macro->formal_count++;
      *p = formal;
      p = &formal->next;
      *p = 
          ((void *)0)
              ;
    }

  if (macro_mri)
    {
      formal_entry *formal;
      const char *name;



      formal = (formal_entry *) xmalloc (sizeof (formal_entry));

      sb_new (&formal->name);
      sb_new (&formal->def);
      sb_new (&formal->actual);



      if (macro_strip_at)
 name = "$NARG";
      else
 name = "NARG";

      sb_add_string (&formal->name, name);


      hash_jam (macro->formal_hash, name, formal);

      formal->index = (-2);
      *p = formal;
      formal->next = 
                    ((void *)0)
                        ;
    }

  return idx;
}




const char *
define_macro(int idx, sb *in, sb *label, int (*get_line) (sb *)) asm("_define_macro");
const char *
define_macro(int idx, sb *in, sb *label, int (*get_line) (sb *))
{
  macro_entry *macro;
  sb name;

  macro = (macro_entry *) xmalloc (sizeof (macro_entry));
  sb_new (&macro->sub);
  sb_new (&name);

  macro->formal_count = 0;
  macro->formals = 0;

  idx = sb_skip_white (idx, in);
  if (! buffer_and_nest ("MACRO", "ENDM", &macro->sub, get_line))
    return "unexpected end of file in macro definition";
  if (label != 
              ((void *)0) 
                   && label->len != 0)
    {
      sb_add_sb (&name, label);
      if (in->ptr[idx] == '(')
 {

   idx = do_formals (macro, idx + 1, in);
   if (in->ptr[idx] != ')')
     return "missing ) after formals";
 }
      else
 {

   idx = do_formals (macro, idx, in);
 }
    }
  else
    {
      idx = get_token (idx, in, &name);
      idx = sb_skip_comma (idx, in);
      idx = do_formals (macro, idx, in);
    }


  for (idx = 0; idx < name.len; idx++)
    if (isupper (name.ptr[idx]))
      name.ptr[idx] = tolower (name.ptr[idx]);
  hash_jam (macro_hash, sb_terminate (&name), (void *) macro);

  macro_defined = 1;

  return 
        ((void *)0)
            ;
}



static int
get_apost_token(int idx, sb *in, sb *name, int kind) asm("_get_apost_token");
static int
get_apost_token(int idx, sb *in, sb *name, int kind)
{
  idx = get_token (idx, in, name);
  if (idx < in->len
      && in->ptr[idx] == kind
      && (! macro_mri || macro_strip_at)
      && (! macro_strip_at || kind == '@'))
    idx++;
  return idx;
}



static int
sub_actual(int start, sb *in, sb *t, struct n64_tag_hash_control *formal_hash, int kind, sb *out, int copyifnotthere) asm("_sub_actual");
static int
sub_actual(int start, sb *in, sb *t, struct n64_tag_hash_control *formal_hash, int kind, sb *out, int copyifnotthere)
{
  int src;
  formal_entry *ptr;

  src = get_apost_token (start, in, t, kind);


  if (macro_strip_at
      && kind == '@'
      && (src == start || in->ptr[src - 1] != '@'))
    ptr = 
         ((void *)0)
             ;
  else
    ptr = (formal_entry *) hash_find (formal_hash, sb_terminate (t));
  if (ptr)
    {
      if (ptr->actual.len)
 {
   sb_add_sb (out, &ptr->actual);
 }
      else
 {
   sb_add_sb (out, &ptr->def);
 }
    }
  else if (copyifnotthere)
    {
      sb_add_sb (out, t);
    }
  else
    {
      sb_add_char (out, '\\');
      sb_add_sb (out, t);
    }
  return src;
}



static const char *
macro_expand_body(sb *in, sb *out, formal_entry *formals, struct n64_tag_hash_control *formal_hash, int comment_char, int locals) asm("_macro_expand_body");
static const char *
macro_expand_body(sb *in, sb *out, formal_entry *formals, struct n64_tag_hash_control *formal_hash, int comment_char, int locals)
{
  sb t;
  int src = 0;
  int inquote = 0;
  formal_entry *loclist = 
                         ((void *)0)
                             ;

  sb_new (&t);

  while (src < in->len)
    {
      if (in->ptr[src] == '&')
 {
   sb_reset (&t);
   if (macro_mri && src + 1 < in->len && in->ptr[src + 1] == '&')
     {
       src = sub_actual (src + 2, in, &t, formal_hash, '\'', out, 1);
     }
   else
     {
       src = sub_actual (src + 1, in, &t, formal_hash, '&', out, 0);
     }
 }
      else if (in->ptr[src] == '\\')
 {
   src++;
   if (in->ptr[src] == comment_char && comment_char != '\0')
     {

       while (src < in->len
       && in->ptr[src] != '\n')
  src++;
     }
   else if (in->ptr[src] == '(')
     {

       src++;
       while (src < in->len && in->ptr[src] != ')')
  {
    sb_add_char (out, in->ptr[src++]);
  }
       if (in->ptr[src] == ')')
  src++;
       else
  return "missplaced )";
     }
   else if (in->ptr[src] == '@')
     {


       char buffer[6];
       src++;
       sprintf (buffer, "%05d", macro_number);
       sb_add_string (out, buffer);
     }
   else if (in->ptr[src] == '&')
     {


       sb_add_char (out, '\\');
       sb_add_char (out, '&');
       src++;
     }
   else if (macro_mri
     && isalnum ((unsigned char) in->ptr[src]))
     {
       int ind;
       formal_entry *f;

       if (isdigit ((unsigned char) in->ptr[src]))
  ind = in->ptr[src] - '0';
       else if (isupper ((unsigned char) in->ptr[src]))
  ind = in->ptr[src] - 'A' + 10;
       else
  ind = in->ptr[src] - 'a' + 10;
       ++src;
       for (f = formals; f != 
                             ((void *)0)
                                 ; f = f->next)
  {
    if (f->index == ind - 1)
      {
        if (f->actual.len != 0)
   sb_add_sb (out, &f->actual);
        else
   sb_add_sb (out, &f->def);
        break;
      }
  }
     }
   else
     {
       sb_reset (&t);
       src = sub_actual (src, in, &t, formal_hash, '\'', out, 0);
     }
 }
      else if ((macro_alternate || macro_mri)
        && (isalpha ((unsigned char) in->ptr[src])
     || in->ptr[src] == '_'
     || in->ptr[src] == '$')
        && (! inquote
     || ! macro_strip_at
     || (src > 0 && in->ptr[src - 1] == '@')))
 {
   if (! locals
       || src + 5 >= in->len
       || strncasecmp (in->ptr + src, "LOCAL", 5) != 0
       || ! ((in->ptr[src + 5]) == ' ' || (in->ptr[src + 5]) == '\t'))
     {
       sb_reset (&t);
       src = sub_actual (src, in, &t, formal_hash,
    (macro_strip_at && inquote) ? '@' : '\'',
    out, 1);
     }
   else
     {
       formal_entry *f;

       src = sb_skip_white (src + 5, in);
       while (in->ptr[src] != '\n' && in->ptr[src] != comment_char)
  {
    static int loccnt;
    char buf[20];
    const char *err;

    f = (formal_entry *) xmalloc (sizeof (formal_entry));
    sb_new (&f->name);
    sb_new (&f->def);
    sb_new (&f->actual);
    f->index = (-3);
    f->next = loclist;
    loclist = f;

    src = get_token (src, in, &f->name);
    ++loccnt;
    sprintf (buf, "LL%04x", loccnt);
    sb_add_string (&f->actual, buf);

    err = hash_jam (formal_hash, sb_terminate (&f->name), f);
    if (err != 
              ((void *)0)
                  )
      return err;

    src = sb_skip_comma (src, in);
  }
     }
 }
      else if (comment_char != '\0'
        && in->ptr[src] == comment_char
        && src + 1 < in->len
        && in->ptr[src + 1] == comment_char
        && !inquote)
 {


   while (src < in->len && in->ptr[src] != '\n')
     src++;
 }
      else if (in->ptr[src] == '"'
        || (macro_mri && in->ptr[src] == '\''))
 {
   inquote = !inquote;
   sb_add_char (out, in->ptr[src++]);
 }
      else if (in->ptr[src] == '@' && macro_strip_at)
 {
   ++src;
   if (src < in->len
       && in->ptr[src] == '@')
     {
       sb_add_char (out, '@');
       ++src;
     }
 }
      else if (macro_mri
        && in->ptr[src] == '='
        && src + 1 < in->len
        && in->ptr[src + 1] == '=')
 {
   formal_entry *ptr;

   sb_reset (&t);
   src = get_token (src + 2, in, &t);
   ptr = (formal_entry *) hash_find (formal_hash, sb_terminate (&t));
   if (ptr == 
             ((void *)0)
                 )
     {
       sb_add_char (out, '=');
       sb_add_char (out, '=');
       sb_add_sb (out, &t);
     }
   else
     {
       if (ptr->actual.len)
  {
    sb_add_string (out, "-1");
  }
       else
  {
    sb_add_char (out, '0');
  }
     }
 }
      else
 {
   sb_add_char (out, in->ptr[src++]);
 }
    }

  sb_kill (&t);

  while (loclist != 
                   ((void *)0)
                       )
    {
      formal_entry *f;

      f = loclist->next;
      hash_delete (formal_hash, sb_terminate (&loclist->name));
      sb_kill (&loclist->name);
      sb_kill (&loclist->def);
      sb_kill (&loclist->actual);
      free (loclist);
      loclist = f;
    }

  return 
        ((void *)0)
            ;
}




static const char *
macro_expand(int idx, sb *in, macro_entry *m, sb *out, int comment_char) asm("_macro_expand");
static const char *
macro_expand(int idx, sb *in, macro_entry *m, sb *out, int comment_char)
{
  sb t;
  formal_entry *ptr;
  formal_entry *f;
  int is_positional = 0;
  int is_keyword = 0;
  int narg = 0;
  const char *err;

  sb_new (&t);


  for (f = m->formals; f; f = f->next)
      sb_reset (&f->actual);
  f = m->formals;
  while (f != 
             ((void *)0) 
                  && f->index < 0)
    f = f->next;

  if (macro_mri)
    {


      if (idx < in->len && in->ptr[idx] == '.')
 {
   formal_entry *n;

   n = (formal_entry *) xmalloc (sizeof (formal_entry));
   sb_new (&n->name);
   sb_new (&n->def);
   sb_new (&n->actual);
   n->index = (-1);

   n->next = m->formals;
   m->formals = n;

   idx = get_any_string (idx + 1, in, &n->actual, 1, 0);
 }
    }


  idx = sb_skip_white (idx, in);
  while (idx < in->len && in->ptr[idx] != comment_char)
    {
      int scan;


      scan = idx;
      while (scan < in->len
      && !((in->ptr[scan]) == ' ' || (in->ptr[scan]) == '\t' || (in->ptr[scan]) == ',' || (in->ptr[scan]) == '"' || (in->ptr[scan]) == ';' || (in->ptr[scan]) == '<' || (in->ptr[scan]) == '>' || (in->ptr[scan]) == ')' || (in->ptr[scan]) == '(')
      && (!macro_alternate && in->ptr[scan] != '='))
 scan++;
      if (scan < in->len && !macro_alternate && in->ptr[scan] == '=')
 {
   is_keyword = 1;
   if (is_positional)
     return "can't mix positional and keyword arguments";



   sb_reset (&t);
   idx = get_token (idx, in, &t);
   if (in->ptr[idx] != '=')
     return "confusion in formal parameters";


   ptr = (formal_entry *) hash_find (m->formal_hash, sb_terminate (&t));
   if (!ptr)
     return "macro formal argument does not exist";
   else
     {

       sb_reset (&ptr->actual);
       idx = get_any_string (idx + 1, in, &ptr->actual, 0, 0);
       if (ptr->actual.len > 0)
  ++narg;
     }
 }
      else
 {

   is_positional = 1;
   if (is_keyword)
     return "can't mix positional and keyword arguments";

   if (!f)
     {
       formal_entry **pf;
       int c;

       if (!macro_mri)
  return "too many positional arguments";

       f = (formal_entry *) xmalloc (sizeof (formal_entry));
       sb_new (&f->name);
       sb_new (&f->def);
       sb_new (&f->actual);
       f->next = 
                ((void *)0)
                    ;

       c = -1;
       for (pf = &m->formals; *pf != 
                                    ((void *)0)
                                        ; pf = &(*pf)->next)
  if ((*pf)->index >= c)
    c = (*pf)->index + 1;
       if (c == -1)
  c = 0;
       *pf = f;
       f->index = c;
     }

   sb_reset (&f->actual);
   idx = get_any_string (idx, in, &f->actual, 1, 0);
   if (f->actual.len > 0)
     ++narg;
   do
     {
       f = f->next;
     }
   while (f != 
              ((void *)0) 
                   && f->index < 0);
 }

      if (! macro_mri)
 idx = sb_skip_comma (idx, in);
      else
 {
   if (in->ptr[idx] == ',')
     ++idx;
   if (((in->ptr[idx]) == ' ' || (in->ptr[idx]) == '\t'))
     break;
 }
    }

  if (macro_mri)
    {
      char buffer[20];

      sb_reset (&t);
      sb_add_string (&t, macro_strip_at ? "$NARG" : "NARG");
      ptr = (formal_entry *) hash_find (m->formal_hash, sb_terminate (&t));
      sb_reset (&ptr->actual);
      sprintf (buffer, "%d", narg);
      sb_add_string (&ptr->actual, buffer);
    }

  err = macro_expand_body (&m->sub, out, m->formals, m->formal_hash,
      comment_char, 1);
  if (err != 
            ((void *)0)
                )
    return err;


  if (macro_mri)
    {
      formal_entry **pf;

      pf = &m->formals;
      while (*pf != 
                   ((void *)0)
                       )
 {
   if ((*pf)->name.len != 0)
     pf = &(*pf)->next;
   else
     {
       sb_kill (&(*pf)->name);
       sb_kill (&(*pf)->def);
       sb_kill (&(*pf)->actual);
       f = (*pf)->next;
       free (*pf);
       *pf = f;
     }
 }
    }

  sb_kill (&t);
  macro_number++;

  return 
        ((void *)0)
            ;
}





int
check_macro(const char *line, sb *expand, int comment_char, const char **error) asm("_check_macro");
int
check_macro(const char *line, sb *expand, int comment_char, const char **error)
{
  const char *s;
  char *copy, *cs;
  macro_entry *macro;
  sb line_sb;

  if (! isalpha ((unsigned char) *line)
      && *line != '_'
      && *line != '$'
      && (! macro_mri || *line != '.'))
    return 0;

  s = line + 1;
  while (isalnum ((unsigned char) *s)
  || *s == '_'
  || *s == '$')
    ++s;

  copy = (char *) xmalloc (s - line + 1);
  memcpy (copy, line, s - line);
  copy[s - line] = '\0';
  for (cs = copy; *cs != '\0'; cs++)
    if (isupper (*cs))
      *cs = tolower (*cs);

  macro = (macro_entry *) hash_find (macro_hash, copy);

  if (macro == 
              ((void *)0)
                  )
    return 0;


  sb_new (&line_sb);
  while (*s != '\0' && *s != '\n' && *s != '\r')
    sb_add_char (&line_sb, *s++);

  sb_new (expand);
  *error = macro_expand (0, &line_sb, macro, expand, comment_char);

  sb_kill (&line_sb);

  return 1;
}



void
delete_macro(const char *name) asm("_delete_macro");
void
delete_macro(const char *name)
{
  hash_delete (macro_hash, name);
}





const char *
expand_irp(int irpc, int idx, sb *in, sb *out, int (*get_line) (sb *), int comment_char) asm("_expand_irp");
const char *
expand_irp(int irpc, int idx, sb *in, sb *out, int (*get_line) (sb *), int comment_char)
{
  const char *mn;
  sb sub;
  formal_entry f;
  struct n64_tag_hash_control *h;
  const char *err;

  if (irpc)
    mn = "IRPC";
  else
    mn = "IRP";

  idx = sb_skip_white (idx, in);

  sb_new (&sub);
  if (! buffer_and_nest (mn, "ENDR", &sub, get_line))
    return "unexpected end of file in irp or irpc";

  sb_new (&f.name);
  sb_new (&f.def);
  sb_new (&f.actual);

  idx = get_token (idx, in, &f.name);
  if (f.name.len == 0)
    return "missing model parameter";

  h = hash_new ();
  err = hash_jam (h, sb_terminate (&f.name), &f);
  if (err != 
            ((void *)0)
                )
    return err;

  f.index = 1;
  f.next = 
          ((void *)0)
              ;

  sb_reset (out);

  idx = sb_skip_comma (idx, in);
  if (idx >= in->len || in->ptr[idx] == comment_char)
    {

      err = macro_expand_body (&sub, out, &f, h, comment_char, 0);
      if (err != 
                ((void *)0)
                    )
 return err;
    }
  else
    {
      if (irpc && in->ptr[idx] == '"')
 ++idx;
      while (idx < in->len && in->ptr[idx] != comment_char)
 {
   if (!irpc)
     idx = get_any_string (idx, in, &f.actual, 1, 0);
   else
     {
       if (in->ptr[idx] == '"')
  {
    int nxt;

    nxt = sb_skip_white (idx + 1, in);
    if (nxt >= in->len || in->ptr[nxt] == comment_char)
      {
        idx = nxt;
        break;
      }
  }
       sb_reset (&f.actual);
       sb_add_char (&f.actual, in->ptr[idx]);
       ++idx;
     }
   err = macro_expand_body (&sub, out, &f, h, comment_char, 0);
   if (err != 
             ((void *)0)
                 )
     return err;
   if (!irpc)
     idx = sb_skip_comma (idx, in);
   else
     idx = sb_skip_white (idx, in);
 }
    }

  hash_die (h);
  sb_kill (&sub);

  return 
        ((void *)0)
            ;
}

