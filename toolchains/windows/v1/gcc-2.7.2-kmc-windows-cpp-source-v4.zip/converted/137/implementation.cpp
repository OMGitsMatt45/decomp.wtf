// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <errno.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_error_info;








extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");


extern void *malloc (size_t size) asm("_malloc");
extern void *memset (void *s, int c, size_t n) asm("_memset");
struct n64_tag_error_info
{
  int value;
  const char *name;



};







static const struct n64_tag_error_info error_table[] =
{

  {
 1
 , "EPERM"},


  {
 2
 , "ENOENT"},


  {
 3
 , "ESRCH"},


  {
 4
 , "EINTR"},


  {
 5
 , "EIO"},


  {
 6
 , "ENXIO"},


  {
 7
 , "E2BIG"},


  {
 8
 , "ENOEXEC"},


  {
 9
 , "EBADF"},


  {
 10
 , "ECHILD"},


  {
 140
 , "EWOULDBLOCK"},


  {
 11
 , "EAGAIN"},


  {
 12
 , "ENOMEM"},


  {
 13
 , "EACCES"},


  {
 14
 , "EFAULT"},





  {
 16
 , "EBUSY"},


  {
 17
 , "EEXIST"},


  {
 18
 , "EXDEV"},


  {
 19
 , "ENODEV"},


  {
 20
 , "ENOTDIR"},


  {
 21
 , "EISDIR"},


  {
 22
 , "EINVAL"},


  {
 23
 , "ENFILE"},


  {
 24
 , "EMFILE"},


  {
 25
 , "ENOTTY"},


  {
 139
 , "ETXTBSY"},


  {
 27
 , "EFBIG"},


  {
 28
 , "ENOSPC"},


  {
 29
 , "ESPIPE"},


  {
 30
 , "EROFS"},


  {
 31
 , "EMLINK"},


  {
 32
 , "EPIPE"},


  {
 33
 , "EDOM"},


  {
 34
 , "ERANGE"},


  {
 122
 , "ENOMSG"},


  {
 111
 , "EIDRM"},
  {
 36
 , "EDEADLK"},


  {
 39
 , "ENOLCK"},
  {
 36
 , "EDEADLOCK"},





  {
 125
 , "ENOSTR"},


  {
 120
 , "ENODATA"},


  {
 137
 , "ETIME"},


  {
 124
 , "ENOSR"},
  {
 121
 , "ENOLINK"},
  {
 134
 , "EPROTO"},
  {
 104
 , "EBADMSG"},


  {
 38
 , "ENAMETOOLONG"},


  {
 132
 , "EOVERFLOW"},
  {
 42
 , "EILSEQ"},


  {
 40
 , "ENOSYS"},


  {
 114
 , "ELOOP"},
  {
 41
 , "ENOTEMPTY"},





  {
 128
 , "ENOTSOCK"},


  {
 109
 , "EDESTADDRREQ"},


  {
 115
 , "EMSGSIZE"},


  {
 136
 , "EPROTOTYPE"},


  {
 123
 , "ENOPROTOOPT"},


  {
 135
 , "EPROTONOSUPPORT"},





  {
 130
 , "EOPNOTSUPP"},





  {
 102
 , "EAFNOSUPPORT"},


  {
 100
 , "EADDRINUSE"},


  {
 101
 , "EADDRNOTAVAIL"},


  {
 116
 , "ENETDOWN"},


  {
 118
 , "ENETUNREACH"},


  {
 117
 , "ENETRESET"},


  {
 106
 , "ECONNABORTED"},


  {
 108
 , "ECONNRESET"},


  {
 119
 , "ENOBUFS"},


  {
 113
 , "EISCONN"},


  {
 126
 , "ENOTCONN"},
  {
 138
 , "ETIMEDOUT"},


  {
 107
 , "ECONNREFUSED"},





  {
 110
 , "EHOSTUNREACH"},


  {
 103
 , "EALREADY"},


  {
 112
 , "EINPROGRESS"},
  {0, 
 ((void *)0)
 }
};
static const char **error_names;
static int num_error_names = 0;
extern int sys_nerr;
extern char *sys_errlist[];
static void
init_error_tables(void) asm("_init_error_tables");
static void
init_error_tables(void)
{
  const struct n64_tag_error_info *eip;
  int nbytes;




  if (num_error_names == 0)
    {
      for (eip = error_table; eip -> name != 
                                            ((void *)0)
                                                ; eip++)
 {
   if (eip -> value >= num_error_names)
     {
       num_error_names = eip -> value + 1;
     }
 }
    }




  if (error_names == 
                    ((void *)0)
                        )
    {
      nbytes = num_error_names * sizeof (char *);
      if ((error_names = (const char **) malloc (nbytes)) != 
                                                            ((void *)0)
                                                                )
 {
   memset (error_names, 0, nbytes);
   for (eip = error_table; eip -> name != 
                                         ((void *)0)
                                             ; eip++)
     {
       error_names[eip -> value] = eip -> name;
     }
 }
    }
}
int
errno_max(void) asm("_errno_max");
int
errno_max(void)
{
  int maxsize;

  if (error_names == 
                    ((void *)0)
                        )
    {
      init_error_tables ();
    }
  maxsize = ((sys_nerr) > (num_error_names) ? (sys_nerr) : (num_error_names));
  return (maxsize - 1);
}
const char *
strerrno(int errnoval) asm("_strerrno");
const char *
strerrno(int errnoval)
{
  const char *name;
  static char buf[32];

  if (error_names == 
                    ((void *)0)
                        )
    {
      init_error_tables ();
    }

  if ((errnoval < 0) || (errnoval >= num_error_names))
    {






      name = 
            ((void *)0)
                ;
    }
  else if ((error_names == 
                          ((void *)0)
                              ) || (error_names[errnoval] == 
                                                             ((void *)0)
                                                                 ))
    {

      sprintf (buf, "Error %d", errnoval);
      name = (const char *) buf;
    }
  else
    {

      name = error_names[errnoval];
    }

  return (name);
}
int
strtoerrno(const char *name) asm("_strtoerrno");
int
strtoerrno(const char *name)
{
  int errnoval = 0;

  if (name != 
             ((void *)0)
                 )
    {
      if (error_names == 
                        ((void *)0)
                            )
 {
   init_error_tables ();
 }
      for (errnoval = 0; errnoval < num_error_names; errnoval++)
 {
   if ((error_names[errnoval] != 
                                ((void *)0)
                                    ) &&
       (strcmp (name, error_names[errnoval]) == 0))
     {
       break;
     }
 }
      if (errnoval == num_error_names)
 {





   errnoval = 0;
 }
    }
  return (errnoval);
}

