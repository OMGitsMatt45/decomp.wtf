// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/rtlanal.c
/* Analyze RTL for C-Compiler
   Copyright (C) 1987, 88, 91, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int side_effects_p(...) asm("_side_effects_p");
extern int dead_or_set_regno_p(...) asm("_dead_or_set_regno_p");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

void note_stores(...) asm("_note_stores");
int reg_set_p(...) asm("_reg_set_p");





int target_flags;






int
rtx_unstable_p(rtx x) asm("_rtx_unstable_p");
int
rtx_unstable_p(rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);
  register int i;
  register char *fmt;

  if (code == MEM)
    return ! ((x)->unchanging);

  if (code == QUEUED)
    return 1;

  if (code == CONST || code == CONST_INT)
    return 0;

  if (code == REG)
    return ! (((x)->fld[0].rtint) == (0 + 30)
       || ((x)->fld[0].rtint) == (0 + 30)
       || ((x)->fld[0].rtint) == 0
       || ((x)->unchanging));

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      if (rtx_unstable_p (((x)->fld[i].rtx)))
 return 1;
  return 0;
}






int
rtx_varies_p(rtx x) asm("_rtx_varies_p");
int
rtx_varies_p(rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);
  register int i;
  register char *fmt;

  switch (code)
    {
    case MEM:
    case QUEUED:
      return 1;

    case CONST:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
      return 0;

    case REG:




      return ! (x == frame_pointer_rtx || x == hard_frame_pointer_rtx
  || x == arg_pointer_rtx);

    case LO_SUM:


      return rtx_varies_p (((x)->fld[1].rtx));
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      if (rtx_varies_p (((x)->fld[i].rtx)))
 return 1;
  return 0;
}



int
rtx_addr_can_trap_p(register rtx x) asm("_rtx_addr_can_trap_p");
int
rtx_addr_can_trap_p(register rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case SYMBOL_REF:
    case LABEL_REF:




      return 0;

    case REG:

      return ! (x == frame_pointer_rtx || x == hard_frame_pointer_rtx
  || x == stack_pointer_rtx || x == arg_pointer_rtx);

    case CONST:
      return rtx_addr_can_trap_p (((x)->fld[0].rtx));

    case PLUS:


      return (rtx_addr_can_trap_p (((x)->fld[0].rtx))
       || ((((x)->fld[1].rtx))->code) != CONST_INT);

    case LO_SUM:
      return rtx_addr_can_trap_p (((x)->fld[1].rtx));
    }


  return 1;
}





int
rtx_addr_varies_p(rtx x) asm("_rtx_addr_varies_p");
int
rtx_addr_varies_p(rtx x)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;

  if (x == 0)
    return 0;

  code = ((x)->code);
  if (code == MEM)
    return ((x)->mode) == BLKmode || rtx_varies_p (((x)->fld[0].rtx));

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      if (rtx_addr_varies_p (((x)->fld[i].rtx)))
 return 1;
  return 0;
}






int
get_integer_term(rtx x) asm("_get_integer_term");
int
get_integer_term(rtx x)
{
  if (((x)->code) == CONST)
    x = ((x)->fld[0].rtx);

  if (((x)->code) == MINUS
      && ((((x)->fld[1].rtx))->code) == CONST_INT)
    return - ((((x)->fld[1].rtx))->fld[0].rtwint);
  if (((x)->code) == PLUS
      && ((((x)->fld[1].rtx))->code) == CONST_INT)
    return ((((x)->fld[1].rtx))->fld[0].rtwint);
  return 0;
}





rtx
get_related_value(rtx x) asm("_get_related_value");
rtx
get_related_value(rtx x)
{
  if (((x)->code) != CONST)
    return 0;
  x = ((x)->fld[0].rtx);
  if (((x)->code) == PLUS
      && ((((x)->fld[1].rtx))->code) == CONST_INT)
    return ((x)->fld[0].rtx);
  else if (((x)->code) == MINUS
    && ((((x)->fld[1].rtx))->code) == CONST_INT)
    return ((x)->fld[0].rtx);
  return 0;
}





int
reg_mentioned_p(register rtx reg, register rtx in) asm("_reg_mentioned_p");
int
reg_mentioned_p(register rtx reg, register rtx in)
{
  register char *fmt;
  register int i;
  register n64_enum_rtx_code code;

  if (in == 0)
    return 0;

  if (reg == in)
    return 1;

  if (((in)->code) == LABEL_REF)
    return reg == ((in)->fld[0].rtx);

  code = ((in)->code);

  switch (code)
    {

    case REG:
      return ((reg)->code) == REG && ((in)->fld[0].rtint) == ((reg)->fld[0].rtint);



    case SCRATCH:
    case CC0:
    case PC:
      return 0;

    case CONST_INT:
      return ((reg)->code) == CONST_INT && ((in)->fld[0].rtwint) == ((reg)->fld[0].rtwint);

    case CONST_DOUBLE:

      return 0;
    }

  if (((reg)->code) == code && rtx_equal_p (reg, in))
    return 1;

  fmt = (rtx_format[(int)(code)]);

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((in)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (reg_mentioned_p (reg, ((in)->fld[i].rtvec->elem[j].rtx)))
       return 1;
 }
      else if (fmt[i] == 'e'
        && reg_mentioned_p (reg, ((in)->fld[i].rtx)))
 return 1;
    }
  return 0;
}




int
no_labels_between_p(rtx beg, rtx end) asm("_no_labels_between_p");
int
no_labels_between_p(rtx beg, rtx end)
{
  register rtx p;
  for (p = ((beg)->fld[2].rtx); p != end; p = ((p)->fld[2].rtx))
    if (((p)->code) == CODE_LABEL)
      return 0;
  return 1;
}




int
reg_used_between_p(rtx reg, rtx from_insn, rtx to_insn) asm("_reg_used_between_p");
int
reg_used_between_p(rtx reg, rtx from_insn, rtx to_insn)
{
  register rtx insn;

  if (from_insn == to_insn)
    return 0;

  for (insn = ((from_insn)->fld[2].rtx); insn != to_insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && (reg_overlap_mentioned_p (reg, ((insn)->fld[3].rtx))
    || (((insn)->code) == CALL_INSN
       && (find_reg_fusage (insn, USE, reg)
    || find_reg_fusage (insn, CLOBBER, reg)))))
      return 1;
  return 0;
}





int
reg_referenced_p(rtx x, rtx body) asm("_reg_referenced_p");
int
reg_referenced_p(rtx x, rtx body)
{
  int i;

  switch (((body)->code))
    {
    case SET:
      if (reg_overlap_mentioned_p (x, ((body)->fld[1].rtx)))
 return 1;




      if (((((body)->fld[0].rtx))->code) != CC0
   && ((((body)->fld[0].rtx))->code) != PC
   && ((((body)->fld[0].rtx))->code) != REG
   && ! (((((body)->fld[0].rtx))->code) == SUBREG
  && ((((((body)->fld[0].rtx))->fld[0].rtx))->code) == REG
  && ((((mode_size[(int)(((((((body)->fld[0].rtx))->fld[0].rtx))->mode))])
        + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))
      == (((mode_size[(int)(((((body)->fld[0].rtx))->mode))])
    + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))))
   && reg_overlap_mentioned_p (x, ((body)->fld[0].rtx)))
 return 1;
      break;

    case ASM_OPERANDS:
      for (i = (((body))->fld[3].rtvec->num_elem) - 1; i >= 0; i--)
 if (reg_overlap_mentioned_p (x, (((body))->fld[3].rtvec->elem[(i)].rtx)))
   return 1;
      break;

    case CALL:
    case USE:
      return reg_overlap_mentioned_p (x, body);

    case TRAP_IF:
      return reg_overlap_mentioned_p (x, ((body)->fld[0].rtx));

    case UNSPEC:
    case UNSPEC_VOLATILE:
    case PARALLEL:
      for (i = ((body)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 if (reg_referenced_p (x, ((body)->fld[0].rtvec->elem[i].rtx)))
   return 1;
      break;
    }

  return 0;
}





int
reg_referenced_between_p(rtx reg, rtx from_insn, rtx to_insn) asm("_reg_referenced_between_p");
int
reg_referenced_between_p(rtx reg, rtx from_insn, rtx to_insn)
{
  register rtx insn;

  if (from_insn == to_insn)
    return 0;

  for (insn = ((from_insn)->fld[2].rtx); insn != to_insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && (reg_referenced_p (reg, ((insn)->fld[3].rtx))
    || (((insn)->code) == CALL_INSN
       && find_reg_fusage (insn, USE, reg))))
      return 1;
  return 0;
}




int
reg_set_between_p(rtx reg, rtx from_insn, rtx to_insn) asm("_reg_set_between_p");
int
reg_set_between_p(rtx reg, rtx from_insn, rtx to_insn)
{
  register rtx insn;

  if (from_insn == to_insn)
    return 0;

  for (insn = ((from_insn)->fld[2].rtx); insn != to_insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && reg_set_p (reg, insn))
      return 1;
  return 0;
}



static rtx reg_set_reg;
static int reg_set_flag;

static void
reg_set_p_1(rtx x, int pat) asm("_reg_set_p_1");
static void
reg_set_p_1(rtx x, int pat)
{



  if ((((x)->code) != MEM)
      && reg_overlap_mentioned_p (reg_set_reg, x))
    reg_set_flag = 1;
}

int
reg_set_p(rtx reg, rtx insn) asm("_reg_set_p");
int
reg_set_p(rtx reg, rtx insn)
{
  rtx body = insn;



  if ((rtx_class[(int)(((insn)->code))]) == 'i')
    {
      if (0
   || (((insn)->code) == CALL_INSN






       && ((((reg)->code) == REG
     && ((reg)->fld[0].rtint) < 68)
    || ((reg)->code) == MEM
    || find_reg_fusage (insn, CLOBBER, reg))))
 return 1;

      body = ((insn)->fld[3].rtx);
    }

  reg_set_reg = reg;
  reg_set_flag = 0;
  note_stores (body, reg_set_p_1);
  return reg_set_flag;
}





int
modified_between_p(rtx x, rtx start, rtx end) asm("_modified_between_p");
int
modified_between_p(rtx x, rtx start, rtx end)
{
  n64_enum_rtx_code code = ((x)->code);
  char *fmt;
  int i, j;

  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
      return 0;

    case PC:
    case CC0:
      return 1;

    case MEM:


      if (! ((x)->unchanging))
 return 1;
      break;

    case REG:
      return reg_set_between_p (x, start, end);
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e' && modified_between_p (((x)->fld[i].rtx), start, end))
 return 1;

      if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   if (modified_between_p (((x)->fld[i].rtvec->elem[j].rtx), start, end))
     return 1;
    }

  return 0;
}





int
modified_in_p(rtx x, rtx insn) asm("_modified_in_p");
int
modified_in_p(rtx x, rtx insn)
{
  n64_enum_rtx_code code = ((x)->code);
  char *fmt;
  int i, j;

  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
      return 0;

    case PC:
    case CC0:
      return 1;

    case MEM:


      if (! ((x)->unchanging))
 return 1;
      break;

    case REG:
      return reg_set_p (x, insn);
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e' && modified_in_p (((x)->fld[i].rtx), insn))
 return 1;

      if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   if (modified_in_p (((x)->fld[i].rtvec->elem[j].rtx), insn))
     return 1;
    }

  return 0;
}





rtx
single_set(rtx insn) asm("_single_set");
rtx
single_set(rtx insn)
{
  rtx set;
  int i;

  if ((rtx_class[(int)(((insn)->code))]) != 'i')
    return 0;

  if (((((insn)->fld[3].rtx))->code) == SET)
    return ((insn)->fld[3].rtx);

  else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
    {
      for (i = 0, set = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
 if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) == SET
     && (! find_reg_note (insn, REG_UNUSED,
     ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))
  || side_effects_p (((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))))
   {
     if (set)
       return 0;
     else
       set = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
   }
      return set;
    }

  return 0;
}






rtx
find_last_value(rtx x, rtx *pinsn, rtx valid_to) asm("_find_last_value");
rtx
find_last_value(rtx x, rtx *pinsn, rtx valid_to)
{
  rtx p;

  for (p = ((*pinsn)->fld[1].rtx); p && ((p)->code) != CODE_LABEL;
       p = ((p)->fld[1].rtx))
    if ((rtx_class[(int)(((p)->code))]) == 'i')
      {
 rtx set = single_set (p);
 rtx note = find_reg_note (p, REG_EQUAL, (rtx) 0);

 if (set && rtx_equal_p (x, ((set)->fld[0].rtx)))
   {
     rtx src = ((set)->fld[1].rtx);

     if (note && ((((note)->fld[0].rtx))->code) != EXPR_LIST)
       src = ((note)->fld[0].rtx);

     if (! modified_between_p (src, ((p)->fld[1].rtx), valid_to)


  && ! (((src)->code) == REG
        && ((src)->fld[0].rtint) < 68))
       {
  *pinsn = p;
  return src;
       }
   }


 if (reg_set_p (x, p))
   break;
      }

  return x;
}
int
refers_to_regno_p(int regno, int endregno, rtx x, rtx *loc) asm("_refers_to_regno_p");
int
refers_to_regno_p(int regno, int endregno, rtx x, rtx *loc)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

 repeat:


  if (x == 0)
    return 0;

  code = ((x)->code);

  switch (code)
    {
    case REG:
      i = ((x)->fld[0].rtint);




      if ((i == (0 + 29)

    || i == 0

    || i == (0 + 30))
   && regno >= (68) && regno <= (((68)) + 3))
 return 1;

      return (endregno > i
       && regno < i + (i < 68
         ? (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
         : 1));

    case SUBREG:


      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68)
 {
   int inner_regno = ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint);
   int inner_endregno
     = inner_regno + (inner_regno < 68
        ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

   return endregno > inner_regno && regno < inner_endregno;
 }
      break;

    case CLOBBER:
    case SET:
      if (&((x)->fld[0].rtx) != loc



   && ((((((x)->fld[0].rtx))->code) == SUBREG
        && loc != &((((x)->fld[0].rtx))->fld[0].rtx)
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint) >= 68
        && refers_to_regno_p (regno, endregno,
         ((((x)->fld[0].rtx))->fld[0].rtx), loc))
       || (((((x)->fld[0].rtx))->code) != REG
    && refers_to_regno_p (regno, endregno, ((x)->fld[0].rtx), loc))))
 return 1;

      if (code == CLOBBER || loc == &((x)->fld[1].rtx))
 return 0;
      x = ((x)->fld[1].rtx);
      goto repeat;
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e' && loc != &((x)->fld[i].rtx))
 {
   if (i == 0)
     {
       x = ((x)->fld[0].rtx);
       goto repeat;
     }
   else
     if (refers_to_regno_p (regno, endregno, ((x)->fld[i].rtx), loc))
       return 1;
 }
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >=0; j--)
     if (loc != &((x)->fld[i].rtvec->elem[j].rtx)
  && refers_to_regno_p (regno, endregno, ((x)->fld[i].rtvec->elem[j].rtx), loc))
       return 1;
 }
    }
  return 0;
}







int
reg_overlap_mentioned_p(rtx x, rtx in) asm("_reg_overlap_mentioned_p");
int
reg_overlap_mentioned_p(rtx x, rtx in)
{
  int regno, endregno;

  if (((x)->code) == SUBREG)
    {
      regno = ((((x)->fld[0].rtx))->fld[0].rtint);
      if (regno < 68)
 regno += ((x)->fld[1].rtint);
    }
  else if (((x)->code) == REG)
    regno = ((x)->fld[0].rtint);
  else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    return 0;
  else if (((x)->code) == MEM)
    {
      char *fmt;
      int i;

      if (((in)->code) == MEM)
 return 1;

      fmt = (rtx_format[(int)(((in)->code))]);

      for (i = (rtx_length[(int)(((in)->code))]) - 1; i >= 0; i--)
 if (fmt[i] == 'e' && reg_overlap_mentioned_p (x, ((in)->fld[i].rtx)))
   return 1;

      return 0;
    }
  else if (((x)->code) == SCRATCH || ((x)->code) == PC
    || ((x)->code) == CC0)
    return reg_mentioned_p (x, in);
  else
    abort ();

  endregno = regno + (regno < 68
        ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

  return refers_to_regno_p (regno, endregno, in, ((void *)0));
}



static int reg_set_last_unknown;
static rtx reg_set_last_value;
static int reg_set_last_first_regno, reg_set_last_last_regno;



static void
reg_set_last_1(rtx x, rtx pat) asm("_reg_set_last_1");
static void
reg_set_last_1(rtx x, rtx pat)
{
  int first, last;



  if (((x)->code) != REG)
    return;

  first = ((x)->fld[0].rtint);
  last = first + (first < 68
    ? (! ((unsigned) ((first) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

  if (first >= reg_set_last_last_regno
      || last <= reg_set_last_first_regno)
    return;



  if (((pat)->code) == CLOBBER || ((pat)->fld[0].rtx) != x
      || first != reg_set_last_first_regno
      || last != reg_set_last_last_regno)
    reg_set_last_unknown = 1;
  else
    reg_set_last_value = ((pat)->fld[1].rtx);
}







rtx
reg_set_last(rtx x, rtx insn) asm("_reg_set_last");
rtx
reg_set_last(rtx x, rtx insn)
{
  rtx orig_insn = insn;

  reg_set_last_first_regno = ((x)->fld[0].rtint);

  reg_set_last_last_regno
    = reg_set_last_first_regno
      + (reg_set_last_first_regno < 68
  ? (! ((unsigned) ((reg_set_last_first_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

  reg_set_last_unknown = 0;
  reg_set_last_value = 0;
  for (;
       insn && ((insn)->code) != CODE_LABEL
       && ! (((insn)->code) == CALL_INSN
      && reg_set_last_last_regno <= 68);
       insn = ((insn)->fld[1].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i')
      {
 note_stores (((insn)->fld[3].rtx), reg_set_last_1);
 if (reg_set_last_unknown)
   return 0;
 else if (reg_set_last_value)
   {
     if ((((reg_set_last_value)->code) == LABEL_REF || ((reg_set_last_value)->code) == SYMBOL_REF || ((reg_set_last_value)->code) == CONST_INT || ((reg_set_last_value)->code) == CONST_DOUBLE || ((reg_set_last_value)->code) == CONST || ((reg_set_last_value)->code) == HIGH)
  || ((((reg_set_last_value)->code) == REG
       || ((reg_set_last_value)->code) == SUBREG)
      && ! reg_set_between_p (reg_set_last_value,
         insn, orig_insn)))
       return reg_set_last_value;
     else
       return 0;
   }
      }

  return 0;
}


int rtx_equal_function_value_matters;




int
rtx_equal_p(rtx x, rtx y) asm("_rtx_equal_p");
int
rtx_equal_p(rtx x, rtx y)
{
  register int i;
  register int j;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == y)
    return 1;
  if (x == 0 || y == 0)
    return 0;

  code = ((x)->code);

  if (code != ((y)->code))
    return 0;




  if (((x)->mode) != ((y)->mode))
    return 0;



  if (code == REG)




    return (((x)->fld[0].rtint) == ((y)->fld[0].rtint)
     && (! rtx_equal_function_value_matters
  || ((x)->integrated) == ((y)->integrated)));
  else if (code == LABEL_REF)
    return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);
  else if (code == SYMBOL_REF)
    return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);
  else if (code == SCRATCH || code == CONST_DOUBLE)
    return 0;




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'n':
 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'V':
 case 'E':

   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;


   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (rtx_equal_p (((x)->fld[i].rtvec->elem[j].rtx), ((y)->fld[i].rtvec->elem[j].rtx)) == 0)
       return 0;
   break;

 case 'e':
   if (rtx_equal_p (((x)->fld[i].rtx), ((y)->fld[i].rtx)) == 0)
     return 0;
   break;

 case 'S':
 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'u':

   break;

 case '0':
   break;




 default:
   abort ();
 }
    }
  return 1;
}
void
note_stores(register rtx x, void (*fun) (...)) asm("_note_stores");
void
note_stores(register rtx x, void (*fun) (...))
{
  if ((((x)->code) == SET || ((x)->code) == CLOBBER))
    {
      register rtx dest = ((x)->fld[0].rtx);
      while ((((dest)->code) == SUBREG
       && (((((dest)->fld[0].rtx))->code) != REG
    || ((((dest)->fld[0].rtx))->fld[0].rtint) >= 68))
      || ((dest)->code) == ZERO_EXTRACT
      || ((dest)->code) == SIGN_EXTRACT
      || ((dest)->code) == STRICT_LOW_PART)
 dest = ((dest)->fld[0].rtx);
      (*fun) (dest, x);
    }
  else if (((x)->code) == PARALLEL)
    {
      register int i;
      for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   register rtx y = ((x)->fld[0].rtvec->elem[i].rtx);
   if (((y)->code) == SET || ((y)->code) == CLOBBER)
     {
       register rtx dest = ((y)->fld[0].rtx);
       while ((((dest)->code) == SUBREG
        && (((((dest)->fld[0].rtx))->code) != REG
     || (((((dest)->fld[0].rtx))->fld[0].rtint)
         >= 68)))
       || ((dest)->code) == ZERO_EXTRACT
       || ((dest)->code) == SIGN_EXTRACT
       || ((dest)->code) == STRICT_LOW_PART)
  dest = ((dest)->fld[0].rtx);
       (*fun) (dest, y);
     }
 }
    }
}
int
dead_or_set_p(rtx insn, rtx x) asm("_dead_or_set_p");
int
dead_or_set_p(rtx insn, rtx x)
{
  register int regno, last_regno;
  register int i;


  if (((x)->code) == CC0)
    return 1;

  if (((x)->code) != REG)
    abort ();

  regno = ((x)->fld[0].rtint);
  last_regno = (regno >= 68 ? regno
  : regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1);

  for (i = regno; i <= last_regno; i++)
    if (! dead_or_set_regno_p (insn, i))
      return 0;

  return 1;
}




int
dead_or_set_regno_p(rtx insn, int test_regno) asm("_dead_or_set_regno_p");
int
dead_or_set_regno_p(rtx insn, int test_regno)
{
  int regno, endregno;
  rtx link;


  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    {
      if (((n64_enum_reg_note) ((link)->mode)) != REG_DEAD || ((((link)->fld[0].rtx))->code) != REG)
 continue;

      regno = ((((link)->fld[0].rtx))->fld[0].rtint);
      endregno = (regno >= 68 ? regno + 1
    : regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                     );

      if (test_regno >= regno && test_regno < endregno)
 return 1;
    }

  if (((insn)->code) == CALL_INSN
      && find_regno_fusage (insn, CLOBBER, test_regno))
    return 1;

  if (((((insn)->fld[3].rtx))->code) == SET)
    {
      rtx dest = ((((insn)->fld[3].rtx))->fld[0].rtx);




     if (((dest)->code) == SUBREG
   && ((((mode_size[(int)(((dest)->mode))])
  + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))
       == (((mode_size[(int)(((((dest)->fld[0].rtx))->mode))])
     + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))))
 dest = ((dest)->fld[0].rtx);

      if (((dest)->code) != REG)
 return 0;

      regno = ((dest)->fld[0].rtint);
      endregno = (regno >= 68 ? regno + 1
    : regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))));

      return (test_regno >= regno && test_regno < endregno);
    }
  else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
    {
      register int i;

      for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   rtx body = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);

   if (((body)->code) == SET || ((body)->code) == CLOBBER)
     {
       rtx dest = ((body)->fld[0].rtx);

       if (((dest)->code) == SUBREG
    && ((((mode_size[(int)(((dest)->mode))])
   + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))
        == (((mode_size[(int)(((((dest)->fld[0].rtx))->mode))])
      + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))))
  dest = ((dest)->fld[0].rtx);

       if (((dest)->code) != REG)
  continue;

       regno = ((dest)->fld[0].rtint);
       endregno = (regno >= 68 ? regno + 1
     : regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))));

       if (test_regno >= regno && test_regno < endregno)
  return 1;
     }
 }
    }

  return 0;
}




rtx
find_reg_note(rtx insn, n64_enum_reg_note kind, rtx datum) asm("_find_reg_note");
rtx
find_reg_note(rtx insn, n64_enum_reg_note kind, rtx datum)
{
  register rtx link;

  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    if (((n64_enum_reg_note) ((link)->mode)) == kind
 && (datum == 0 || datum == ((link)->fld[0].rtx)))
      return link;
  return 0;
}






rtx
find_regno_note(rtx insn, n64_enum_reg_note kind, int regno) asm("_find_regno_note");
rtx
find_regno_note(rtx insn, n64_enum_reg_note kind, int regno)
{
  register rtx link;

  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    if (((n64_enum_reg_note) ((link)->mode)) == kind


 && ((((link)->fld[0].rtx))->code) == REG
 && ((((link)->fld[0].rtx))->fld[0].rtint) <= regno
 && ((((((link)->fld[0].rtx))->fld[0].rtint)
      + (((((link)->fld[0].rtx))->fld[0].rtint) >= 68 ? 1
  : (! ((unsigned) ((((((link)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                  ))
     > regno))
      return link;
  return 0;
}




int
find_reg_fusage(rtx insn, n64_enum_rtx_code code, rtx datum) asm("_find_reg_fusage");
int
find_reg_fusage(rtx insn, n64_enum_rtx_code code, rtx datum)
{


  if (((insn)->code) != CALL_INSN)
    return 0;

  if (! datum)
    abort();

  if (((datum)->code) != REG)
    {
      register rtx link;

      for (link = ((insn)->fld[7].rtx);
           link;
    link = ((link)->fld[1].rtx))
        if (((((link)->fld[0].rtx))->code) == code
     && rtx_equal_p (datum, ((((link)->fld[0].rtx))->fld[0].rtx)))
          return 1;
    }
  else
    {
      register int regno = ((datum)->fld[0].rtint);




      if (regno < 68)
        {
   int end_regno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((datum)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((datum)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   int i;

   for (i = regno; i < end_regno; i++)
     if (find_regno_fusage (insn, code, i))
       return 1;
        }
    }

  return 0;
}




int
find_regno_fusage(rtx insn, n64_enum_rtx_code code, int regno) asm("_find_regno_fusage");
int
find_regno_fusage(rtx insn, n64_enum_rtx_code code, int regno)
{
  register rtx link;




  if (regno >= 68
      || ((insn)->code) != CALL_INSN )
    return 0;

  for (link = ((insn)->fld[7].rtx); link; link = ((link)->fld[1].rtx))
   {
    register int regnote;
    register rtx op;

    if (((op = ((link)->fld[0].rtx))->code) == code
 && ((((op)->fld[0].rtx))->code) == REG
 && (regnote = ((((op)->fld[0].rtx))->fld[0].rtint)) <= regno
 && regnote
  + (! ((unsigned) ((regnote) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((op)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((op)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
     > regno)
      return 1;
   }

  return 0;
}



void
remove_note(register rtx insn, register rtx note) asm("_remove_note");
void
remove_note(register rtx insn, register rtx note)
{
  register rtx link;

  if (((insn)->fld[6].rtx) == note)
    {
      ((insn)->fld[6].rtx) = ((note)->fld[1].rtx);
      return;
    }

  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    if (((link)->fld[1].rtx) == note)
      {
 ((link)->fld[1].rtx) = ((note)->fld[1].rtx);
 return;
      }

  abort ();
}






int
volatile_insn_p(rtx x) asm("_volatile_insn_p");
int
volatile_insn_p(rtx x)
{
  register n64_enum_rtx_code code;

  code = ((x)->code);
  switch (code)
    {
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case CC0:
    case PC:
    case REG:
    case SCRATCH:
    case CLOBBER:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case CALL:
    case MEM:
      return 0;

    case UNSPEC_VOLATILE:

      return 1;

    case ASM_OPERANDS:
      if (((x)->volatil))
 return 1;
    }



  {
    register char *fmt = (rtx_format[(int)(code)]);
    register int i;

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e')
   {
     if (volatile_insn_p (((x)->fld[i].rtx)))
       return 1;
   }
 if (fmt[i] == 'E')
   {
     register int j;
     for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
       if (volatile_insn_p (((x)->fld[i].rtvec->elem[j].rtx)))
  return 1;
   }
      }
  }
  return 0;
}




int
volatile_refs_p(rtx x) asm("_volatile_refs_p");
int
volatile_refs_p(rtx x)
{
  register n64_enum_rtx_code code;

  code = ((x)->code);
  switch (code)
    {
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case CC0:
    case PC:
    case REG:
    case SCRATCH:
    case CLOBBER:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return 0;

    case CALL:
    case UNSPEC_VOLATILE:

      return 1;

    case MEM:
    case ASM_OPERANDS:
      if (((x)->volatil))
 return 1;
    }



  {
    register char *fmt = (rtx_format[(int)(code)]);
    register int i;

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e')
   {
     if (volatile_refs_p (((x)->fld[i].rtx)))
       return 1;
   }
 if (fmt[i] == 'E')
   {
     register int j;
     for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
       if (volatile_refs_p (((x)->fld[i].rtvec->elem[j].rtx)))
  return 1;
   }
      }
  }
  return 0;
}




int
side_effects_p(rtx x) asm("_side_effects_p");
int
side_effects_p(rtx x)
{
  register n64_enum_rtx_code code;

  code = ((x)->code);
  switch (code)
    {
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case CC0:
    case PC:
    case REG:
    case SCRATCH:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return 0;

    case CLOBBER:



      return (((x)->mode) != VOIDmode);

    case PRE_INC:
    case PRE_DEC:
    case POST_INC:
    case POST_DEC:
    case CALL:
    case UNSPEC_VOLATILE:

      return 1;

    case MEM:
    case ASM_OPERANDS:
      if (((x)->volatil))
 return 1;
    }



  {
    register char *fmt = (rtx_format[(int)(code)]);
    register int i;

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e')
   {
     if (side_effects_p (((x)->fld[i].rtx)))
       return 1;
   }
 if (fmt[i] == 'E')
   {
     register int j;
     for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
       if (side_effects_p (((x)->fld[i].rtvec->elem[j].rtx)))
  return 1;
   }
      }
  }
  return 0;
}



int
may_trap_p(rtx x) asm("_may_trap_p");
int
may_trap_p(rtx x)
{
  int i;
  n64_enum_rtx_code code;
  char *fmt;

  if (x == 0)
    return 0;
  code = ((x)->code);
  switch (code)
    {

    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case CONST:
    case PC:
    case CC0:
    case REG:
    case SCRATCH:
      return 0;


    case UNSPEC_VOLATILE:
    case TRAP_IF:
      return 1;


    case MEM:
      return rtx_addr_can_trap_p (((x)->fld[0].rtx));


    case DIV:
    case MOD:
    case UDIV:
    case UMOD:
      if (! (((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH))
 return 1;


      if (((((x)->fld[1].rtx))->code) == CONST_INT && ((((x)->fld[1].rtx))->fld[0].rtwint) == 0)
 return 1;
    case EXPR_LIST:


      return 1;
    default:

      if ((mode_class[(int)(((x)->mode))]) == MODE_FLOAT)
 return 1;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   if (may_trap_p (((x)->fld[i].rtx)))
     return 1;
 }
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (may_trap_p (((x)->fld[i].rtvec->elem[j].rtx)))
       return 1;
 }
    }
  return 0;
}




int
inequality_comparisons_p(rtx x) asm("_inequality_comparisons_p");
int
inequality_comparisons_p(rtx x)
{
  register char *fmt;
  register int len, i;
  register n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case REG:
    case SCRATCH:
    case PC:
    case CC0:
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case LABEL_REF:
    case SYMBOL_REF:
      return 0;

    case LT:
    case LTU:
    case GT:
    case GTU:
    case LE:
    case LEU:
    case GE:
    case GEU:
      return 1;
    }

  len = (rtx_length[(int)(code)]);
  fmt = (rtx_format[(int)(code)]);

  for (i = 0; i < len; i++)
    {
      if (fmt[i] == 'e')
 {
   if (inequality_comparisons_p (((x)->fld[i].rtx)))
     return 1;
 }
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (inequality_comparisons_p (((x)->fld[i].rtvec->elem[j].rtx)))
       return 1;
 }
    }

  return 0;
}






rtx
replace_rtx(rtx x, rtx from, rtx to) asm("_replace_rtx");
rtx
replace_rtx(rtx x, rtx from, rtx to)
{
  register int i, j;
  register char *fmt;

  if (x == from)
    return to;


  if (x == 0)
    return 0;

  fmt = (rtx_format[(int)(((x)->code))]);
  for (i = (rtx_length[(int)(((x)->code))]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = replace_rtx (((x)->fld[i].rtx), from, to);
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   ((x)->fld[i].rtvec->elem[j].rtx) = replace_rtx (((x)->fld[i].rtvec->elem[j].rtx), from, to);
    }

  return x;
}
rtx
replace_regs(rtx x, rtx *reg_map, int nregs, int replace_dest) asm("_replace_regs");
rtx
replace_regs(rtx x, rtx *reg_map, int nregs, int replace_dest)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;

  if (x == 0)
    return x;

  code = ((x)->code);
  switch (code)
    {
    case SCRATCH:
    case PC:
    case CC0:
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
      return x;

    case REG:

      if (((x)->fld[0].rtint) < nregs && reg_map[((x)->fld[0].rtint)] != 0)
 {



   if (((reg_map[((x)->fld[0].rtint)])->code) == SUBREG)
     return copy_rtx (reg_map[((x)->fld[0].rtint)]);
   return reg_map[((x)->fld[0].rtint)];
 }
      return x;

    case SUBREG:

      if (((((x)->fld[0].rtx))->code) == REG && ((((x)->fld[0].rtx))->fld[0].rtint) < nregs
   && reg_map[((((x)->fld[0].rtx))->fld[0].rtint)] != 0
   && ((reg_map[((((x)->fld[0].rtx))->fld[0].rtint)])->code) == SUBREG)
 {
   rtx map_val = reg_map[((((x)->fld[0].rtx))->fld[0].rtint)];
   rtx map_inner = ((map_val)->fld[0].rtx);

   if (((x)->mode) == ((map_inner)->mode))
     return map_inner;
   else
     {




       ((x)->fld[0].rtx) = map_inner;
       ((x)->fld[1].rtint) += ((map_val)->fld[1].rtint);
       return x;






     }
 }
      break;

    case SET:
      if (replace_dest)
 ((x)->fld[0].rtx) = replace_regs (((x)->fld[0].rtx), reg_map, nregs, 0);

      else if (((((x)->fld[0].rtx))->code) == MEM
        || ((((x)->fld[0].rtx))->code) == STRICT_LOW_PART)



 ((((x)->fld[0].rtx))->fld[0].rtx) = replace_regs (((((x)->fld[0].rtx))->fld[0].rtx),
            reg_map, nregs, 0);
      else if (((((x)->fld[0].rtx))->code) == ZERO_EXTRACT)

 break;

      ((x)->fld[1].rtx) = replace_regs (((x)->fld[1].rtx), reg_map, nregs, 0);
      return x;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = replace_regs (((x)->fld[i].rtx), reg_map, nregs, replace_dest);
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     ((x)->fld[i].rtvec->elem[j].rtx) = replace_regs (((x)->fld[i].rtvec->elem[j].rtx), reg_map,
           nregs, replace_dest);
 }
    }
  return x;
}

