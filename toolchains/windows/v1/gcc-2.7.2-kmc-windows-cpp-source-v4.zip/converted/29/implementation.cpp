// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/optabs.c
/* Expand the basic unary and binary arithmetic operations, for GNU compiler.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int reg_set_p(...) asm("_reg_set_p");
extern int preserve_subexpressions_p(...) asm("_preserve_subexpressions_p");
extern int rtx_cost(...) asm("_rtx_cost");
extern int delete_insns_since(...) asm("_delete_insns_since");
extern int do_jump_by_parts_greater_rtx(...) asm("_do_jump_by_parts_greater_rtx");
extern int add_insn(...) asm("_add_insn");
extern int reg_used_between_p(...) asm("_reg_used_between_p");
extern int modified_in_p(...) asm("_modified_in_p");
extern int modified_between_p(...) asm("_modified_between_p");
extern int init_all_optabs(...) asm("_init_all_optabs");
extern int init_mov_optab(...) asm("_init_mov_optab");
struct n64_tag_args_size;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;

typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern rtx reload_in[(2 * 10 * (1 + 1))];
extern rtx reload_out[(2 * 10 * (1 + 1))];
extern rtx reload_in_reg[(2 * 10 * (1 + 1))];
extern n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
extern char reload_optional[(2 * 10 * (1 + 1))];
extern int reload_inc[(2 * 10 * (1 + 1))];
extern int reload_opnum[(2 * 10 * (1 + 1))];
extern int reload_secondary_p[(2 * 10 * (1 + 1))];
extern int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
extern int reload_secondary_out_reload[(2 * 10 * (1 + 1))];

extern n64_enum_insn_code reload_secondary_in_icode[(2 * 10 * (1 + 1))];
extern n64_enum_insn_code reload_secondary_out_icode[(2 * 10 * (1 + 1))];

extern int n_reloads;

extern rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
enum n64_cpp_enum_reload_type{
  RELOAD_FOR_INPUT, RELOAD_FOR_OUTPUT, RELOAD_FOR_INSN,
  RELOAD_FOR_INPUT_ADDRESS, RELOAD_FOR_OUTPUT_ADDRESS,
  RELOAD_FOR_OPERAND_ADDRESS, RELOAD_FOR_OPADDR_ADDR,
  RELOAD_OTHER, RELOAD_FOR_OTHER_ADDRESS
};
typedef __underlying_type(enum n64_cpp_enum_reload_type) n64_enum_reload_type;


extern n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];

extern rtx *reg_equiv_constant;
extern rtx *reg_equiv_memory_loc;
extern rtx *reg_equiv_address;
extern rtx *reg_equiv_mem;



extern int n_earlyclobbers;
extern rtx reload_earlyclobbers[10];


extern int reload_n_operands;



extern int reload_first_uid;





extern char indirect_symref_ok;


extern char double_reg_address_ok;





extern n64_enum_insn_code reload_in_optab[];
extern n64_enum_insn_code reload_out_optab[];







extern rtx get_secondary_mem (rtx, n64_enum_machine_mode, int, n64_enum_reload_type) asm("_get_secondary_mem")
                               ;


extern void clear_secondary_mem (void) asm("_clear_secondary_mem");



extern void transfer_replacements (int, int) asm("_transfer_replacements");




extern int strict_memory_address_p (n64_enum_machine_mode, rtx) asm("_strict_memory_address_p");




extern int operands_match_p (rtx, rtx) asm("_operands_match_p");


extern int n_occurrences (int, char *) asm("_n_occurrences");


extern int safe_from_earlyclobber (rtx, rtx) asm("_safe_from_earlyclobber");




extern void find_reloads (rtx, int, int, int, short *) asm("_find_reloads");





extern rtx form_sum (rtx, rtx) asm("_form_sum");



extern void subst_reloads (void) asm("_subst_reloads");




extern void copy_replacements (rtx, rtx) asm("_copy_replacements");



extern rtx find_replacement (rtx *) asm("_find_replacement");




extern int refers_to_regno_for_reload_p (int, int, rtx, rtx *) asm("_refers_to_regno_for_reload_p");


extern int reg_overlap_mentioned_for_reload_p (rtx, rtx) asm("_reg_overlap_mentioned_for_reload_p");



extern int refers_to_mem_for_reload_p (rtx) asm("_refers_to_mem_for_reload_p");



extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg")
                             ;


extern int regno_clobbered_p (int, rtx) asm("_regno_clobbered_p");





extern void init_reload (void) asm("_init_reload");


extern int reload(...) asm("_reload");



extern void mark_home_live (int) asm("_mark_home_live");



extern rtx eliminate_regs (rtx, n64_enum_machine_mode, rtx) asm("_eliminate_regs");




extern rtx gen_reload (rtx, rtx, int, n64_enum_reload_type) asm("_gen_reload");




extern void init_caller_save (void) asm("_init_caller_save");


extern void init_save_areas (void) asm("_init_save_areas");


extern int setup_save_areas (int *) asm("_setup_save_areas");


extern void save_call_clobbered_regs (n64_enum_machine_mode) asm("_save_call_clobbered_regs");

optab add_optab;
optab sub_optab;
optab smul_optab;
optab smul_highpart_optab;
optab umul_highpart_optab;
optab smul_widen_optab;
optab umul_widen_optab;
optab sdiv_optab;
optab sdivmod_optab;
optab udiv_optab;
optab udivmod_optab;
optab smod_optab;
optab umod_optab;
optab flodiv_optab;
optab ftrunc_optab;
optab and_optab;
optab ior_optab;
optab xor_optab;
optab ashl_optab;
optab lshr_optab;
optab ashr_optab;
optab rotl_optab;
optab rotr_optab;
optab smin_optab;
optab smax_optab;
optab umin_optab;
optab umax_optab;

optab mov_optab;
optab movstrict_optab;

optab neg_optab;
optab abs_optab;
optab one_cmpl_optab;
optab ffs_optab;
optab sqrt_optab;
optab sin_optab;
optab cos_optab;

optab cmp_optab;
optab ucmp_optab;
optab tst_optab;

optab strlen_optab;


n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];




rtx extendsfdf2_libfunc;
rtx extendsfxf2_libfunc;
rtx extendsftf2_libfunc;
rtx extenddfxf2_libfunc;
rtx extenddftf2_libfunc;

rtx truncdfsf2_libfunc;
rtx truncxfsf2_libfunc;
rtx trunctfsf2_libfunc;
rtx truncxfdf2_libfunc;
rtx trunctfdf2_libfunc;

rtx memcpy_libfunc;
rtx bcopy_libfunc;
rtx memcmp_libfunc;
rtx bcmp_libfunc;
rtx memset_libfunc;
rtx bzero_libfunc;

rtx eqhf2_libfunc;
rtx nehf2_libfunc;
rtx gthf2_libfunc;
rtx gehf2_libfunc;
rtx lthf2_libfunc;
rtx lehf2_libfunc;

rtx eqsf2_libfunc;
rtx nesf2_libfunc;
rtx gtsf2_libfunc;
rtx gesf2_libfunc;
rtx ltsf2_libfunc;
rtx lesf2_libfunc;

rtx eqdf2_libfunc;
rtx nedf2_libfunc;
rtx gtdf2_libfunc;
rtx gedf2_libfunc;
rtx ltdf2_libfunc;
rtx ledf2_libfunc;

rtx eqxf2_libfunc;
rtx nexf2_libfunc;
rtx gtxf2_libfunc;
rtx gexf2_libfunc;
rtx ltxf2_libfunc;
rtx lexf2_libfunc;

rtx eqtf2_libfunc;
rtx netf2_libfunc;
rtx gttf2_libfunc;
rtx getf2_libfunc;
rtx lttf2_libfunc;
rtx letf2_libfunc;

rtx floatsisf_libfunc;
rtx floatdisf_libfunc;
rtx floattisf_libfunc;

rtx floatsidf_libfunc;
rtx floatdidf_libfunc;
rtx floattidf_libfunc;

rtx floatsixf_libfunc;
rtx floatdixf_libfunc;
rtx floattixf_libfunc;

rtx floatsitf_libfunc;
rtx floatditf_libfunc;
rtx floattitf_libfunc;

rtx fixsfsi_libfunc;
rtx fixsfdi_libfunc;
rtx fixsfti_libfunc;

rtx fixdfsi_libfunc;
rtx fixdfdi_libfunc;
rtx fixdfti_libfunc;

rtx fixxfsi_libfunc;
rtx fixxfdi_libfunc;
rtx fixxfti_libfunc;

rtx fixtfsi_libfunc;
rtx fixtfdi_libfunc;
rtx fixtfti_libfunc;

rtx fixunssfsi_libfunc;
rtx fixunssfdi_libfunc;
rtx fixunssfti_libfunc;

rtx fixunsdfsi_libfunc;
rtx fixunsdfdi_libfunc;
rtx fixunsdfti_libfunc;

rtx fixunsxfsi_libfunc;
rtx fixunsxfdi_libfunc;
rtx fixunsxfti_libfunc;

rtx fixunstfsi_libfunc;
rtx fixunstfdi_libfunc;
rtx fixunstfti_libfunc;




rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];







n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];


static int add_equal_note (rtx, rtx, n64_enum_rtx_code, rtx, rtx) asm("_add_equal_note");
static rtx widen_operand (rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_widen_operand")
                                        ;
static n64_enum_insn_code can_fix_p (n64_enum_machine_mode, n64_enum_machine_mode, int, int *) asm("_can_fix_p")
                       ;
static n64_enum_insn_code can_float_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_float_p")
           ;
static rtx ftruncify (rtx) asm("_ftruncify");
static optab init_optab (n64_enum_rtx_code) asm("_init_optab");
static void init_libfuncs (optab, int, int, char *, int) asm("_init_libfuncs");
static void init_integral_libfuncs (optab, char *, int) asm("_init_integral_libfuncs");
static void init_floating_libfuncs (optab, char *, int) asm("_init_floating_libfuncs");
static void init_complex_libfuncs (optab, char *, int) asm("_init_complex_libfuncs");
static int
add_equal_note(rtx seq, rtx target, n64_enum_rtx_code code, rtx op0, rtx op1) asm("_add_equal_note");
static int
add_equal_note(rtx seq, rtx target, n64_enum_rtx_code code, rtx op0, rtx op1)
{
  rtx set;
  int i;
  rtx note;

  if (((rtx_class[(int)(code)]) != '1' && (rtx_class[(int)(code)]) != '2'
       && (rtx_class[(int)(code)]) != 'c' && (rtx_class[(int)(code)]) != '<')
      || ((seq)->code) != SEQUENCE
      || (set = single_set (((seq)->fld[0].rtvec->elem[((seq)->fld[0].rtvec->num_elem) - 1].rtx))) == 0
      || ((target)->code) == ZERO_EXTRACT
      || (! rtx_equal_p (((set)->fld[0].rtx), target)


   && (((((set)->fld[0].rtx))->code) != STRICT_LOW_PART
       || ! rtx_equal_p (((((((set)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx),
    target))))
    return 1;



  if (reg_overlap_mentioned_p (target, op0)
      || (op1 && reg_overlap_mentioned_p (target, op1)))
    for (i = ((seq)->fld[0].rtvec->num_elem) - 2; i >= 0; i--)
      if (reg_set_p (target, ((seq)->fld[0].rtvec->elem[i].rtx)))
 return 0;

  if ((rtx_class[(int)(code)]) == '1')
    note = gen_rtx (code, ((target)->mode), copy_rtx (op0));
  else
    note = gen_rtx (code, ((target)->mode), copy_rtx (op0), copy_rtx (op1));

  ((((seq)->fld[0].rtvec->elem[((seq)->fld[0].rtvec->num_elem) - 1].rtx))->fld[6].rtx)
    = gen_rtx (EXPR_LIST, REG_EQUAL, note,
        ((((seq)->fld[0].rtvec->elem[((seq)->fld[0].rtvec->num_elem) - 1].rtx))->fld[6].rtx));

  return 1;
}







static rtx
widen_operand(rtx op, n64_enum_machine_mode mode, n64_enum_machine_mode oldmode, int unsignedp, int no_extend) asm("_widen_operand");
static rtx
widen_operand(rtx op, n64_enum_machine_mode mode, n64_enum_machine_mode oldmode, int unsignedp, int no_extend)
{
  rtx result;




  if (! no_extend
      || ((op)->mode) == VOIDmode
      || (((op)->code) == SUBREG && ((op)->in_struct)))
    return convert_modes (mode, oldmode, op, unsignedp);



  if ((mode_size[(int)(mode)]) <= ((target_flags & 0x00002000) ? 8 : 4))
    return gen_rtx (SUBREG, mode, force_reg (((op)->mode), op), 0);




  result = gen_reg_rtx (mode);
  emit_insn (gen_rtx (CLOBBER, VOIDmode, result));
  emit_move_insn (gen_lowpart (((op)->mode), result), op);
  return result;
}
rtx
expand_binop(n64_enum_machine_mode mode, optab binoptab, rtx op0, rtx op1, rtx target, int unsignedp, n64_enum_optab_methods methods) asm("_expand_binop");
rtx
expand_binop(n64_enum_machine_mode mode, optab binoptab, rtx op0, rtx op1, rtx target, int unsignedp, n64_enum_optab_methods methods)
{
  n64_enum_optab_methods next_methods
    = (methods == OPTAB_LIB || methods == OPTAB_LIB_WIDEN
       ? OPTAB_WIDEN : methods);
  n64_enum_mode_class cxx_class;
  n64_enum_machine_mode wider_mode;
  register rtx temp;
  int commutative_op = 0;
  int shift_op = (binoptab->code == ASHIFT
    || binoptab->code == ASHIFTRT
    || binoptab->code == LSHIFTRT
    || binoptab->code == ROTATE
    || binoptab->code == ROTATERT);
  rtx entry_last = get_last_insn ();
  rtx last;

  cxx_class = (mode_class[(int)(mode)]);

  op0 = protect_from_queue (op0, 0);
  op1 = protect_from_queue (op1, 0);
  if (target)
    target = protect_from_queue (target, 1);

  if (flag_force_mem)
    {
      op0 = force_not_mem (op0);
      op1 = force_not_mem (op1);
    }




  if (binoptab == sub_optab && ((op1)->code) == CONST_INT)
    {
      op1 = negate_rtx (mode, op1);
      binoptab = add_optab;
    }



  if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && preserve_subexpressions_p ()
      && rtx_cost (op0, binoptab->code) > 2)
    op0 = force_reg (mode, op0);

  if ((((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH) && preserve_subexpressions_p ()
      && ! shift_op && rtx_cost (op1, binoptab->code) > 2)
    op1 = force_reg (mode, op1);


  last = get_last_insn ();





  if ((rtx_class[(int)(binoptab->code)]) == 'c'
      || binoptab == smul_widen_optab
      || binoptab == umul_widen_optab
      || binoptab == smul_highpart_optab
      || binoptab == umul_highpart_optab)
    {
      commutative_op = 1;

      if (((target == 0 || ((target)->code) == REG)
    ? ((((op1)->code) == REG
        && ((op0)->code) != REG)
       || target == op1)
    : rtx_equal_p (op1, target))
   || ((op0)->code) == CONST_INT)
 {
   temp = op1;
   op1 = op0;
   op0 = temp;
 }
    }



  if (methods != OPTAB_MUST_WIDEN
      && binoptab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) binoptab->handlers[(int) mode].insn_code;
      n64_enum_machine_mode mode0 = insn_operand_mode[icode][1];
      n64_enum_machine_mode mode1 = insn_operand_mode[icode][2];
      rtx pat;
      rtx xop0 = op0, xop1 = op1;

      if (target)
 temp = target;
      else
 temp = gen_reg_rtx (mode);



      if (commutative_op)
 {
   if (((op0)->mode) != mode0 && ((op1)->mode) != mode1
       && ((op0)->mode) == mode1 && ((op1)->mode) == mode0)
     {
       register rtx tmp;

       tmp = op0; op0 = op1; op1 = tmp;
       tmp = xop0; xop0 = xop1; xop1 = tmp;
     }
 }




      if (((op0)->mode) != VOIDmode
   && ((op0)->mode) != mode0
   && mode0 != VOIDmode)
 xop0 = convert_to_mode (mode0, xop0, unsignedp);

      if (((xop1)->mode) != VOIDmode
   && ((xop1)->mode) != mode1
   && mode1 != VOIDmode)
 xop1 = convert_to_mode (mode1, xop1, unsignedp);




      if (! (*insn_operand_predicate[icode][1]) (xop0, mode0)
   && mode0 != VOIDmode)
 xop0 = copy_to_mode_reg (mode0, xop0);

      if (! (*insn_operand_predicate[icode][2]) (xop1, mode1)
   && mode1 != VOIDmode)
 xop1 = copy_to_mode_reg (mode1, xop1);

      if (! (*insn_operand_predicate[icode][0]) (temp, mode))
 temp = gen_reg_rtx (mode);

      pat = (*insn_gen_function[(int) (icode)]) (temp, xop0, xop1);
      if (pat)
 {



   if (((pat)->code) == SEQUENCE
       && ! add_equal_note (pat, temp, binoptab->code, xop0, xop1))
     {
       delete_insns_since (last);
       return expand_binop (mode, binoptab, op0, op1, (rtx) 0,
       unsignedp, methods);
     }

   emit_insn (pat);
   return temp;
 }
      else
 delete_insns_since (last);
    }




  if (binoptab == smul_optab && (mode_wider_mode[(int)(mode)]) != VOIDmode
      && (((unsignedp ? umul_widen_optab : smul_widen_optab)
    ->handlers[(int) (mode_wider_mode[(int)(mode)])].insn_code)
   != CODE_FOR_nothing))
    {
      temp = expand_binop ((mode_wider_mode[(int)(mode)]),
      unsignedp ? umul_widen_optab : smul_widen_optab,
      op0, op1, (rtx) 0, unsignedp, OPTAB_DIRECT);

      if (temp != 0)
 {
   if ((mode_class[(int)(mode)]) == MODE_INT)
     return gen_lowpart (mode, temp);
   else
     return convert_to_mode (mode, temp, unsignedp);
 }
    }





  if ((cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
      && methods != OPTAB_DIRECT && methods != OPTAB_LIB)
    for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
  wider_mode = (mode_wider_mode[(int)(wider_mode)]))
      {
 if (binoptab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing
     || (binoptab == smul_optab
  && (mode_wider_mode[(int)(wider_mode)]) != VOIDmode
  && (((unsignedp ? umul_widen_optab : smul_widen_optab)
       ->handlers[(int) (mode_wider_mode[(int)(wider_mode)])].insn_code)
      != CODE_FOR_nothing)))
   {
     rtx xop0 = op0, xop1 = op1;
     int no_extend = 0;





     if ((binoptab == ior_optab || binoptab == and_optab
   || binoptab == xor_optab
   || binoptab == add_optab || binoptab == sub_optab
   || binoptab == smul_optab || binoptab == ashl_optab)
  && cxx_class == MODE_INT)
       no_extend = 1;

     xop0 = widen_operand (xop0, wider_mode, mode, unsignedp, no_extend);


     xop1 = widen_operand (xop1, wider_mode, mode, unsignedp,
      no_extend && binoptab != ashl_optab);

     temp = expand_binop (wider_mode, binoptab, xop0, xop1, (rtx) 0,
     unsignedp, OPTAB_DIRECT);
     if (temp)
       {
  if (cxx_class != MODE_INT)
    {
      if (target == 0)
        target = gen_reg_rtx (mode);
      convert_move (target, temp, 0);
      return target;
    }
  else
    return gen_lowpart (mode, temp);
       }
     else
       delete_insns_since (last);
   }
      }


  if ((binoptab == and_optab || binoptab == ior_optab || binoptab == xor_optab)
      && cxx_class == MODE_INT
      && (mode_size[(int)(mode)]) > ((target_flags & 0x00002000) ? 8 : 4)
      && binoptab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing)
    {
      int i;
      rtx insns;
      rtx equiv_value;



      if (target == 0 || target == op0 || target == op1)
 target = gen_reg_rtx (mode);

      start_sequence ();


      for (i = 0; i < (8 * mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 64 : 32); i++)
 {
   rtx target_piece = operand_subword (target, i, 1, mode);
   rtx x = expand_binop (word_mode, binoptab,
    operand_subword_force (op0, i, mode),
    operand_subword_force (op1, i, mode),
    target_piece, unsignedp, next_methods);

   if (x == 0)
     break;

   if (target_piece != x)
     emit_move_insn (target_piece, x);
 }

      insns = get_insns ();
      end_sequence ();

      if (i == (8 * mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 64 : 32))
 {
   if (binoptab->code != UNKNOWN)
     equiv_value
       = gen_rtx (binoptab->code, mode, copy_rtx (op0), copy_rtx (op1));
   else
     equiv_value = 0;

   emit_no_conflict_block (insns, target, op0, op1, equiv_value);
   return target;
 }
    }


  if ((binoptab == lshr_optab || binoptab == ashl_optab
       || binoptab == ashr_optab)
      && cxx_class == MODE_INT
      && ((op1)->code) == CONST_INT
      && (mode_size[(int)(mode)]) == 2 * ((target_flags & 0x00002000) ? 8 : 4)
      && binoptab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing
      && ashl_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing
      && lshr_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing)
    {
      rtx insns, inter, equiv_value;
      rtx into_target, outof_target;
      rtx into_input, outof_input;
      int shift_count, left_shift, outof_word;



      if (target == 0 || target == op0 || target == op1)
 target = gen_reg_rtx (mode);

      start_sequence ();

      shift_count = ((op1)->fld[0].rtwint);






      left_shift = binoptab == ashl_optab;
      outof_word = left_shift ^ ! ((target_flags & 0x00010000) != 0);

      outof_target = operand_subword (target, outof_word, 1, mode);
      into_target = operand_subword (target, 1 - outof_word, 1, mode);

      outof_input = operand_subword_force (op0, outof_word, mode);
      into_input = operand_subword_force (op0, 1 - outof_word, mode);

      if (shift_count >= ((target_flags & 0x00002000) ? 64 : 32))
 {
   inter = expand_binop (word_mode, binoptab,
          outof_input,
          gen_rtx (CONST_INT, VOIDmode, (int) (shift_count - ((target_flags & 0x00002000) ? 64 : 32))),
          into_target, unsignedp, next_methods);

   if (inter != 0 && inter != into_target)
     emit_move_insn (into_target, inter);



   if (inter != 0 && binoptab != ashr_optab)
     inter = (const_tiny_rtx[0][(int) (word_mode)]);
   else if (inter != 0)
     inter = expand_binop (word_mode, binoptab,
      outof_input,
      gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 64 : 32) - 1)),
      outof_target, unsignedp, next_methods);

   if (inter != 0 && inter != outof_target)
     emit_move_insn (outof_target, inter);
 }
      else
 {
   rtx carries;
   optab reverse_unsigned_shift, unsigned_shift;





   reverse_unsigned_shift = (left_shift ? lshr_optab : ashl_optab);





   unsigned_shift = (left_shift ? ashl_optab : lshr_optab);

   carries = expand_binop (word_mode, reverse_unsigned_shift,
      outof_input,
      gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 64 : 32) - shift_count)),
      0, unsignedp, next_methods);

   if (carries == 0)
     inter = 0;
   else
     inter = expand_binop (word_mode, unsigned_shift, into_input,
      op1, 0, unsignedp, next_methods);

   if (inter != 0)
     inter = expand_binop (word_mode, ior_optab, carries, inter,
      into_target, unsignedp, next_methods);

   if (inter != 0 && inter != into_target)
     emit_move_insn (into_target, inter);

   if (inter != 0)
     inter = expand_binop (word_mode, binoptab, outof_input,
      op1, outof_target, unsignedp, next_methods);

   if (inter != 0 && inter != outof_target)
     emit_move_insn (outof_target, inter);
 }

      insns = get_insns ();
      end_sequence ();

      if (inter != 0)
 {
   if (binoptab->code != UNKNOWN)
     equiv_value = gen_rtx (binoptab->code, mode, op0, op1);
   else
     equiv_value = 0;

   emit_no_conflict_block (insns, target, op0, op1, equiv_value);
   return target;
 }
    }


  if ((binoptab == rotl_optab || binoptab == rotr_optab)
      && cxx_class == MODE_INT
      && ((op1)->code) == CONST_INT
      && (mode_size[(int)(mode)]) == 2 * ((target_flags & 0x00002000) ? 8 : 4)
      && ashl_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing
      && lshr_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing)
    {
      rtx insns, equiv_value;
      rtx into_target, outof_target;
      rtx into_input, outof_input;
      rtx inter;
      int shift_count, left_shift, outof_word;



      if (target == 0 || target == op0 || target == op1)
 target = gen_reg_rtx (mode);

      start_sequence ();

      shift_count = ((op1)->fld[0].rtwint);






      left_shift = (binoptab == rotl_optab);
      outof_word = left_shift ^ ! ((target_flags & 0x00010000) != 0);

      outof_target = operand_subword (target, outof_word, 1, mode);
      into_target = operand_subword (target, 1 - outof_word, 1, mode);

      outof_input = operand_subword_force (op0, outof_word, mode);
      into_input = operand_subword_force (op0, 1 - outof_word, mode);

      if (shift_count == ((target_flags & 0x00002000) ? 64 : 32))
 {

   emit_move_insn (outof_target, into_input);
   emit_move_insn (into_target, outof_input);
   inter = const0_rtx;
 }
      else
 {
   rtx into_temp1, into_temp2, outof_temp1, outof_temp2;
   rtx first_shift_count, second_shift_count;
   optab reverse_unsigned_shift, unsigned_shift;

   reverse_unsigned_shift = (left_shift ^ (shift_count < ((target_flags & 0x00002000) ? 64 : 32))
        ? lshr_optab : ashl_optab);

   unsigned_shift = (left_shift ^ (shift_count < ((target_flags & 0x00002000) ? 64 : 32))
       ? ashl_optab : lshr_optab);

   if (shift_count > ((target_flags & 0x00002000) ? 64 : 32))
     {
       first_shift_count = gen_rtx (CONST_INT, VOIDmode, (int) (shift_count - ((target_flags & 0x00002000) ? 64 : 32)));
       second_shift_count = gen_rtx (CONST_INT, VOIDmode, (int) (2*((target_flags & 0x00002000) ? 64 : 32) - shift_count));
     }
   else
     {
       first_shift_count = gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 64 : 32) - shift_count));
       second_shift_count = gen_rtx (CONST_INT, VOIDmode, (int) (shift_count));
     }

   into_temp1 = expand_binop (word_mode, unsigned_shift,
         outof_input, first_shift_count,
         (rtx) 0, unsignedp, next_methods);
   into_temp2 = expand_binop (word_mode, reverse_unsigned_shift,
         into_input, second_shift_count,
         into_target, unsignedp, next_methods);

   if (into_temp1 != 0 && into_temp2 != 0)
     inter = expand_binop (word_mode, ior_optab, into_temp1, into_temp2,
      into_target, unsignedp, next_methods);
   else
     inter = 0;

   if (inter != 0 && inter != into_target)
     emit_move_insn (into_target, inter);

   outof_temp1 = expand_binop (word_mode, unsigned_shift,
          into_input, first_shift_count,
          (rtx) 0, unsignedp, next_methods);
   outof_temp2 = expand_binop (word_mode, reverse_unsigned_shift,
          outof_input, second_shift_count,
          outof_target, unsignedp, next_methods);

   if (inter != 0 && outof_temp1 != 0 && outof_temp2 != 0)
     inter = expand_binop (word_mode, ior_optab,
      outof_temp1, outof_temp2,
      outof_target, unsignedp, next_methods);

   if (inter != 0 && inter != outof_target)
     emit_move_insn (outof_target, inter);
 }

      insns = get_insns ();
      end_sequence ();

      if (inter != 0)
 {
   if (binoptab->code != UNKNOWN)
     equiv_value = gen_rtx (binoptab->code, mode, op0, op1);
   else
     equiv_value = 0;




   if (shift_count != ((target_flags & 0x00002000) ? 64 : 32))
     emit_no_conflict_block (insns, target, op0, op1, equiv_value);
   else
     emit_insns (insns);


   return target;
 }
    }


  if ((binoptab == add_optab || binoptab == sub_optab)
      && cxx_class == MODE_INT
      && (mode_size[(int)(mode)]) >= 2 * ((target_flags & 0x00002000) ? 8 : 4)
      && binoptab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing)
    {
      int i;
      rtx carry_tmp = gen_reg_rtx (word_mode);
      optab otheroptab = binoptab == add_optab ? sub_optab : add_optab;
      int nwords = (8 * mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 64 : 32);
      rtx carry_in, carry_out;
      rtx xop0, xop1;





      int normalizep = 1;





      xop0 = force_reg (mode, op0);
      xop1 = force_reg (mode, op1);

      if (target == 0 || ((target)->code) != REG
   || target == xop0 || target == xop1)
 target = gen_reg_rtx (mode);


      if (((target)->code) == REG)
 emit_insn (gen_rtx (CLOBBER, VOIDmode, target));


      for (i = 0; i < nwords; i++)
 {
   int strchr = (((target_flags & 0x00010000) != 0) ? nwords - i - 1 : i);
   rtx target_piece = operand_subword (target, strchr, 1, mode);
   rtx op0_piece = operand_subword_force (xop0, strchr, mode);
   rtx op1_piece = operand_subword_force (xop1, strchr, mode);
   rtx x;


   x = expand_binop (word_mode, binoptab,
       op0_piece, op1_piece,
       target_piece, unsignedp, next_methods);
   if (x == 0)
     break;

   if (i + 1 < nwords)
     {

       carry_out = gen_reg_rtx (word_mode);
       carry_out = emit_store_flag (carry_out,
        binoptab == add_optab ? LTU : GTU,
        x, op0_piece,
        word_mode, 1, normalizep);
       if (carry_out == 0)
  break;
     }

   if (i > 0)
     {

       x = expand_binop (word_mode,
    normalizep == 1 ? binoptab : otheroptab,
    x, carry_in,
    target_piece, 1, next_methods);
       if (x == 0)
  break;
       else if (target_piece != x)
  emit_move_insn (target_piece, x);

       if (i + 1 < nwords)
  {


    carry_tmp = emit_store_flag (carry_tmp,
            binoptab == add_optab
              ? LTU : GTU,
            x, carry_in,
            word_mode, 1, normalizep);


    carry_out = expand_binop (word_mode, ior_optab,
         carry_out, carry_tmp,
         carry_out, 0, next_methods);
    if (carry_out == 0)
      break;
  }
     }

   carry_in = carry_out;
 }

      if (i == (8 * mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 64 : 32))
 {
   rtx temp = emit_move_insn (target, target);

   ((temp)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_EQUAL,
          gen_rtx (binoptab->code, mode,
            copy_rtx (xop0),
            copy_rtx (xop1)),
          ((temp)->fld[6].rtx));
   return target;
 }
      else
 delete_insns_since (last);
    }
  if (binoptab == smul_optab
      && cxx_class == MODE_INT
      && (mode_size[(int)(mode)]) == 2 * ((target_flags & 0x00002000) ? 8 : 4)
      && smul_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing
      && add_optab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing
      && ((umul_widen_optab->handlers[(int) mode].insn_code
    != CODE_FOR_nothing)
   || (smul_widen_optab->handlers[(int) mode].insn_code
       != CODE_FOR_nothing)))
    {
      int low = (((target_flags & 0x00010000) != 0) ? 1 : 0);
      int high = (((target_flags & 0x00010000) != 0) ? 0 : 1);
      rtx op0_high = operand_subword_force (op0, high, mode);
      rtx op0_low = operand_subword_force (op0, low, mode);
      rtx op1_high = operand_subword_force (op1, high, mode);
      rtx op1_low = operand_subword_force (op1, low, mode);
      rtx product = 0;
      rtx op0_xhigh;
      rtx op1_xhigh;



      if (target == op0 || target == op1
   || (target != 0 && ((target)->code) != REG))
 target = 0;





      if (umul_widen_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
 {
   product = expand_binop (mode, umul_widen_optab, op0_low, op1_low,
      target, 1, OPTAB_DIRECT);


   if (product == 0)
     delete_insns_since (last);
   else
     op0_xhigh = op0_high, op1_xhigh = op1_high;
 }

      if (product == 0
   && smul_widen_optab->handlers[(int) mode].insn_code
        != CODE_FOR_nothing)
 {
   rtx wordm1 = gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00002000) ? 64 : 32) - 1));
   product = expand_binop (mode, smul_widen_optab, op0_low, op1_low,
      target, 1, OPTAB_DIRECT);
   op0_xhigh = expand_binop (word_mode, lshr_optab, op0_low, wordm1,
        (rtx) 0, 1, next_methods);
   if (op0_xhigh)
     op0_xhigh = expand_binop (word_mode, add_optab, op0_high,
          op0_xhigh, op0_xhigh, 0, next_methods);
   else
     {
       op0_xhigh = expand_binop (word_mode, ashr_optab, op0_low, wordm1,
     (rtx) 0, 0, next_methods);
       if (op0_xhigh)
  op0_xhigh = expand_binop (word_mode, sub_optab, op0_high,
       op0_xhigh, op0_xhigh, 0,
       next_methods);
     }

   op1_xhigh = expand_binop (word_mode, lshr_optab, op1_low, wordm1,
        (rtx) 0, 1, next_methods);
   if (op1_xhigh)
     op1_xhigh = expand_binop (word_mode, add_optab, op1_high,
          op1_xhigh, op1_xhigh, 0, next_methods);
   else
     {
       op1_xhigh = expand_binop (word_mode, ashr_optab, op1_low, wordm1,
     (rtx) 0, 0, next_methods);
       if (op1_xhigh)
  op1_xhigh = expand_binop (word_mode, sub_optab, op1_high,
       op1_xhigh, op1_xhigh, 0,
       next_methods);
     }
 }
      if (product && op0_xhigh && op1_xhigh)
 {
   rtx product_high = operand_subword (product, high, 1, mode);
   rtx temp = expand_binop (word_mode, binoptab, op0_low, op1_xhigh,
       (rtx) 0, 0, OPTAB_DIRECT);

   if (temp != 0)
     temp = expand_binop (word_mode, add_optab, temp, product_high,
     product_high, 0, next_methods);

   if (temp != 0 && temp != product_high)
     emit_move_insn (product_high, temp);

   if (temp != 0)
     temp = expand_binop (word_mode, binoptab, op1_low, op0_xhigh,
     (rtx) 0, 0, OPTAB_DIRECT);

   if (temp != 0)
     temp = expand_binop (word_mode, add_optab, temp,
     product_high, product_high,
     0, next_methods);

   if (temp != 0 && temp != product_high)
     emit_move_insn (product_high, temp);

   if (temp != 0)
     {
       temp = emit_move_insn (product, product);
       ((temp)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_EQUAL,
       gen_rtx (MULT, mode, copy_rtx (op0),
         copy_rtx (op1)),
       ((temp)->fld[6].rtx));

       return product;
     }
 }





      delete_insns_since (last);
    }
  if (cxx_class == MODE_COMPLEX_FLOAT || cxx_class == MODE_COMPLEX_INT)
    {
      rtx real0 = 0, imag0 = 0;
      rtx real1 = 0, imag1 = 0;
      rtx realr, imagr, res;
      rtx seq;
      rtx equiv_value;
      int ok = 0;


      n64_enum_machine_mode submode
 = mode_for_size ((mode_unit_size[(int)(mode)]) * 8,
    cxx_class == MODE_COMPLEX_INT ? MODE_INT : MODE_FLOAT,
    0);

      if (submode == BLKmode)
 abort ();

      if (! target)
 target = gen_reg_rtx (mode);

      start_sequence ();

      realr = gen_realpart (submode, target);
      imagr = gen_imagpart (submode, target);

      if (((op0)->mode) == mode)
 {
   real0 = gen_realpart (submode, op0);
   imag0 = gen_imagpart (submode, op0);
 }
      else
 real0 = op0;

      if (((op1)->mode) == mode)
 {
   real1 = gen_realpart (submode, op1);
   imag1 = gen_imagpart (submode, op1);
 }
      else
 real1 = op1;

      if (real0 == 0 || real1 == 0 || ! (imag0 != 0|| imag1 != 0))
 abort ();

      switch (binoptab->code)
 {
 case PLUS:

 case MINUS:

   res = expand_binop (submode, binoptab, real0, real1,
         realr, unsignedp, methods);

   if (res == 0)
     break;
   else if (res != realr)
     emit_move_insn (realr, res);

   if (imag0 && imag1)
     res = expand_binop (submode, binoptab, imag0, imag1,
    imagr, unsignedp, methods);
   else if (imag0)
     res = imag0;
   else if (binoptab->code == MINUS)
     res = expand_unop (submode, neg_optab, imag1, imagr, unsignedp);
   else
     res = imag1;

   if (res == 0)
     break;
   else if (res != imagr)
     emit_move_insn (imagr, res);

   ok = 1;
   break;

 case MULT:


   if (imag0 && imag1)
     {
       rtx temp1, temp2;


       real0 = force_reg (submode, real0);
       real1 = force_reg (submode, real1);
       imag0 = force_reg (submode, imag0);
       imag1 = force_reg (submode, imag1);

       temp1 = expand_binop (submode, binoptab, real0, real1, (rtx) 0,
        unsignedp, methods);

       temp2 = expand_binop (submode, binoptab, imag0, imag1, (rtx) 0,
        unsignedp, methods);

       if (temp1 == 0 || temp2 == 0)
  break;

       res = expand_binop (submode, sub_optab, temp1, temp2,
      realr, unsignedp, methods);

       if (res == 0)
  break;
       else if (res != realr)
  emit_move_insn (realr, res);

       temp1 = expand_binop (submode, binoptab, real0, imag1,
        (rtx) 0, unsignedp, methods);

       temp2 = expand_binop (submode, binoptab, real1, imag0,
        (rtx) 0, unsignedp, methods);

       if (temp1 == 0 || temp2 == 0)
    break;

       res = expand_binop (submode, add_optab, temp1, temp2,
      imagr, unsignedp, methods);

       if (res == 0)
  break;
       else if (res != imagr)
  emit_move_insn (imagr, res);

       ok = 1;
     }
   else
     {

       real0 = force_reg (submode, real0);
       real1 = force_reg (submode, real1);

       res = expand_binop (submode, binoptab, real0, real1,
      realr, unsignedp, methods);
       if (res == 0)
  break;
       else if (res != realr)
  emit_move_insn (realr, res);

       if (imag0 != 0)
  res = expand_binop (submode, binoptab,
        real1, imag0, imagr, unsignedp, methods);
       else
  res = expand_binop (submode, binoptab,
        real0, imag1, imagr, unsignedp, methods);

       if (res == 0)
  break;
       else if (res != imagr)
  emit_move_insn (imagr, res);

       ok = 1;
     }
   break;

 case DIV:


   if (imag1 == 0)
     {



       real1 = force_reg (submode, real1);


       if (cxx_class == MODE_COMPLEX_FLOAT)
  res = expand_binop (submode, binoptab, real0, real1,
        realr, unsignedp, methods);
       else
  res = expand_divmod (0, TRUNC_DIV_EXPR, submode,
         real0, real1, realr, unsignedp);

       if (res == 0)
  break;
       else if (res != realr)
  emit_move_insn (realr, res);

       if (cxx_class == MODE_COMPLEX_FLOAT)
  res = expand_binop (submode, binoptab, imag0, real1,
        imagr, unsignedp, methods);
       else
  res = expand_divmod (0, TRUNC_DIV_EXPR, submode,
         imag0, real1, imagr, unsignedp);

       if (res == 0)
  break;
       else if (res != imagr)
  emit_move_insn (imagr, res);

       ok = 1;
     }
   else
     {


       rtx divisor;
       rtx real_t, imag_t;
       rtx lhs, rhs;
       rtx temp1, temp2;


       real0 = force_reg (submode, real0);
       real1 = force_reg (submode, real1);

       if (imag0 != 0)
  imag0 = force_reg (submode, imag0);

       imag1 = force_reg (submode, imag1);


       temp1 = expand_binop (submode, smul_optab, real1, real1,
        (rtx) 0, unsignedp, methods);

       temp2 = expand_binop (submode, smul_optab, imag1, imag1,
        (rtx) 0, unsignedp, methods);

       if (temp1 == 0 || temp2 == 0)
  break;

       divisor = expand_binop (submode, add_optab, temp1, temp2,
          (rtx) 0, unsignedp, methods);
       if (divisor == 0)
  break;

       if (imag0 == 0)
  {




    real_t = expand_binop (submode, smul_optab, real0, real1,
      (rtx) 0, unsignedp, methods);

    imag_t = expand_binop (submode, smul_optab, real0, imag1,
      (rtx) 0, unsignedp, methods);

    if (real_t == 0 || imag_t == 0)
      break;

    imag_t = expand_unop (submode, neg_optab, imag_t,
     (rtx) 0, unsignedp);
  }
       else
  {


    temp1 = expand_binop (submode, smul_optab, real0, real1,
     (rtx) 0, unsignedp, methods);

    temp2 = expand_binop (submode, smul_optab, imag0, imag1,
     (rtx) 0, unsignedp, methods);

    if (temp1 == 0 || temp2 == 0)
      break;

    real_t = expand_binop (submode, add_optab, temp1, temp2,
      (rtx) 0, unsignedp, methods);

    temp1 = expand_binop (submode, smul_optab, imag0, real1,
     (rtx) 0, unsignedp, methods);

    temp2 = expand_binop (submode, smul_optab, real0, imag1,
     (rtx) 0, unsignedp, methods);

    if (temp1 == 0 || temp2 == 0)
      break;

    imag_t = expand_binop (submode, sub_optab, temp1, temp2,
      (rtx) 0, unsignedp, methods);

    if (real_t == 0 || imag_t == 0)
      break;
  }

       if (cxx_class == MODE_COMPLEX_FLOAT)
  res = expand_binop (submode, binoptab, real_t, divisor,
        realr, unsignedp, methods);
       else
  res = expand_divmod (0, TRUNC_DIV_EXPR, submode,
         real_t, divisor, realr, unsignedp);

       if (res == 0)
  break;
       else if (res != realr)
  emit_move_insn (realr, res);

       if (cxx_class == MODE_COMPLEX_FLOAT)
  res = expand_binop (submode, binoptab, imag_t, divisor,
        imagr, unsignedp, methods);
       else
  res = expand_divmod (0, TRUNC_DIV_EXPR, submode,
         imag_t, divisor, imagr, unsignedp);

       if (res == 0)
  break;
       else if (res != imagr)
  emit_move_insn (imagr, res);

       ok = 1;
     }
   break;

 default:
   abort ();
 }

      seq = get_insns ();
      end_sequence ();

      if (ok)
 {
   if (binoptab->code != UNKNOWN)
     equiv_value
       = gen_rtx (binoptab->code, mode, copy_rtx (op0), copy_rtx (op1));
   else
     equiv_value = 0;

   emit_no_conflict_block (seq, target, op0, op1, equiv_value);

   return target;
 }
    }




  if (binoptab->handlers[(int) mode].libfunc
      && (methods == OPTAB_LIB || methods == OPTAB_LIB_WIDEN))
    {
      rtx insns;
      rtx funexp = binoptab->handlers[(int) mode].libfunc;
      rtx op1x = op1;
      n64_enum_machine_mode op1_mode = mode;
      rtx value;

      start_sequence ();

      if (shift_op)
 {
   op1_mode = word_mode;


   op1x = convert_to_mode (word_mode, op1, 1);
 }

      if (((op0)->mode) != VOIDmode
   && ((op0)->mode) != mode)
 op0 = convert_to_mode (mode, op0, unsignedp);



      value = emit_library_call_value (binoptab->handlers[(int) mode].libfunc,
           (rtx) 0, 1, mode, 2,
           op0, mode, op1x, op1_mode);

      insns = get_insns ();
      end_sequence ();

      target = gen_reg_rtx (mode);
      emit_libcall_block (insns, target, value,
     gen_rtx (binoptab->code, mode, op0, op1));

      return target;
    }

  delete_insns_since (last);



  if (! (methods == OPTAB_WIDEN || methods == OPTAB_LIB_WIDEN
  || methods == OPTAB_MUST_WIDEN))
    {

      delete_insns_since (entry_last);
      return 0;
    }




  methods = (methods == OPTAB_LIB_WIDEN ? OPTAB_LIB : OPTAB_DIRECT);




  if (cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
    {
      for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
    wider_mode = (mode_wider_mode[(int)(wider_mode)]))
 {
   if ((binoptab->handlers[(int) wider_mode].insn_code
        != CODE_FOR_nothing)
       || (methods == OPTAB_LIB
    && binoptab->handlers[(int) wider_mode].libfunc))
     {
       rtx xop0 = op0, xop1 = op1;
       int no_extend = 0;





       if ((binoptab == ior_optab || binoptab == and_optab
     || binoptab == xor_optab
     || binoptab == add_optab || binoptab == sub_optab
     || binoptab == smul_optab || binoptab == ashl_optab)
    && cxx_class == MODE_INT)
  no_extend = 1;

       xop0 = widen_operand (xop0, wider_mode, mode,
        unsignedp, no_extend);


       xop1 = widen_operand (xop1, wider_mode, mode, unsignedp,
        no_extend && binoptab != ashl_optab);

       temp = expand_binop (wider_mode, binoptab, xop0, xop1, (rtx) 0,
       unsignedp, methods);
       if (temp)
  {
    if (cxx_class != MODE_INT)
      {
        if (target == 0)
   target = gen_reg_rtx (mode);
        convert_move (target, temp, 0);
        return target;
      }
    else
      return gen_lowpart (mode, temp);
  }
       else
  delete_insns_since (last);
     }
 }
    }

  delete_insns_since (entry_last);
  return 0;
}
rtx
sign_expand_binop(n64_enum_machine_mode mode, optab uoptab, optab soptab, rtx op0, rtx op1, rtx target, int unsignedp, n64_enum_optab_methods methods) asm("_sign_expand_binop");
rtx
sign_expand_binop(n64_enum_machine_mode mode, optab uoptab, optab soptab, rtx op0, rtx op1, rtx target, int unsignedp, n64_enum_optab_methods methods)
{
  register rtx temp;
  optab direct_optab = unsignedp ? uoptab : soptab;
  struct n64_tag_optab wide_soptab;


  temp = expand_binop (mode, direct_optab, op0, op1, target,
         unsignedp, OPTAB_DIRECT);
  if (temp || methods == OPTAB_DIRECT)
    return temp;



  wide_soptab = *soptab;
  wide_soptab.handlers[(int) mode].insn_code = CODE_FOR_nothing;
  wide_soptab.handlers[(int) mode].libfunc = 0;

  temp = expand_binop (mode, &wide_soptab, op0, op1, target,
         unsignedp, OPTAB_WIDEN);


  if (temp == 0 && unsignedp)
    temp = expand_binop (mode, uoptab, op0, op1, target,
    unsignedp, OPTAB_WIDEN);
  if (temp || methods == OPTAB_WIDEN)
    return temp;


  temp = expand_binop (mode, direct_optab, op0, op1, target, unsignedp, OPTAB_LIB);
  if (temp || methods == OPTAB_LIB)
    return temp;


  temp = expand_binop (mode, &wide_soptab, op0, op1, target,
         unsignedp, methods);
  if (temp != 0)
    return temp;
  if (unsignedp)
    return expand_binop (mode, uoptab, op0, op1, target,
    unsignedp, methods);
  return 0;
}
int
expand_twoval_binop(optab binoptab, rtx op0, rtx op1, rtx targ0, rtx targ1, int unsignedp) asm("_expand_twoval_binop");
int
expand_twoval_binop(optab binoptab, rtx op0, rtx op1, rtx targ0, rtx targ1, int unsignedp)
{
  n64_enum_machine_mode mode = ((targ0 ? targ0 : targ1)->mode);
  n64_enum_mode_class cxx_class;
  n64_enum_machine_mode wider_mode;
  rtx entry_last = get_last_insn ();
  rtx last;

  cxx_class = (mode_class[(int)(mode)]);

  op0 = protect_from_queue (op0, 0);
  op1 = protect_from_queue (op1, 0);

  if (flag_force_mem)
    {
      op0 = force_not_mem (op0);
      op1 = force_not_mem (op1);
    }



  if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && preserve_subexpressions_p ()
      && rtx_cost (op0, binoptab->code) > 2)
    op0 = force_reg (mode, op0);

  if ((((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH) && preserve_subexpressions_p ()
      && rtx_cost (op1, binoptab->code) > 2)
    op1 = force_reg (mode, op1);

  if (targ0)
    targ0 = protect_from_queue (targ0, 1);
  else
    targ0 = gen_reg_rtx (mode);
  if (targ1)
    targ1 = protect_from_queue (targ1, 1);
  else
    targ1 = gen_reg_rtx (mode);


  last = get_last_insn ();

  if (binoptab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) binoptab->handlers[(int) mode].insn_code;
      n64_enum_machine_mode mode0 = insn_operand_mode[icode][1];
      n64_enum_machine_mode mode1 = insn_operand_mode[icode][2];
      rtx pat;
      rtx xop0 = op0, xop1 = op1;



      if (((op0)->mode) != VOIDmode && ((op0)->mode) != mode0)
 xop0 = convert_to_mode (mode0, xop0, unsignedp);

      if (((op1)->mode) != VOIDmode && ((op1)->mode) != mode1)
 xop1 = convert_to_mode (mode1, xop1, unsignedp);


      if (! (*insn_operand_predicate[icode][1]) (xop0, mode0))
 xop0 = copy_to_mode_reg (mode0, xop0);

      if (! (*insn_operand_predicate[icode][2]) (xop1, mode1))
 xop1 = copy_to_mode_reg (mode1, xop1);



      if (! (*insn_operand_predicate[icode][0]) (targ0, mode)
   || ! (*insn_operand_predicate[icode][3]) (targ1, mode))
 abort ();

      pat = (*insn_gen_function[(int) (icode)]) (targ0, xop0, xop1, targ1);
      if (pat)
 {
   emit_insn (pat);
   return 1;
 }
      else
 delete_insns_since (last);
    }



  if (cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
    {
      for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
    wider_mode = (mode_wider_mode[(int)(wider_mode)]))
 {
   if (binoptab->handlers[(int) wider_mode].insn_code
       != CODE_FOR_nothing)
     {
       register rtx t0 = gen_reg_rtx (wider_mode);
       register rtx t1 = gen_reg_rtx (wider_mode);

       if (expand_twoval_binop (binoptab,
           convert_modes (wider_mode, mode, op0,
            unsignedp),
           convert_modes (wider_mode, mode, op1,
            unsignedp),
           t0, t1, unsignedp))
  {
    convert_move (targ0, t0, unsignedp);
    convert_move (targ1, t1, unsignedp);
    return 1;
  }
       else
  delete_insns_since (last);
     }
 }
    }

  delete_insns_since (entry_last);
  return 0;
}
rtx
expand_unop(n64_enum_machine_mode mode, optab unoptab, rtx op0, rtx target, int unsignedp) asm("_expand_unop");
rtx
expand_unop(n64_enum_machine_mode mode, optab unoptab, rtx op0, rtx target, int unsignedp)
{
  n64_enum_mode_class cxx_class;
  n64_enum_machine_mode wider_mode;
  register rtx temp;
  rtx last = get_last_insn ();
  rtx pat;

  cxx_class = (mode_class[(int)(mode)]);

  op0 = protect_from_queue (op0, 0);

  if (flag_force_mem)
    {
      op0 = force_not_mem (op0);
    }

  if (target)
    target = protect_from_queue (target, 1);

  if (unoptab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) unoptab->handlers[(int) mode].insn_code;
      n64_enum_machine_mode mode0 = insn_operand_mode[icode][1];
      rtx xop0 = op0;

      if (target)
 temp = target;
      else
 temp = gen_reg_rtx (mode);

      if (((xop0)->mode) != VOIDmode
   && ((xop0)->mode) != mode0)
 xop0 = convert_to_mode (mode0, xop0, unsignedp);



      if (! (*insn_operand_predicate[icode][1]) (xop0, mode0))
 xop0 = copy_to_mode_reg (mode0, xop0);

      if (! (*insn_operand_predicate[icode][0]) (temp, mode))
 temp = gen_reg_rtx (mode);

      pat = (*insn_gen_function[(int) (icode)]) (temp, xop0);
      if (pat)
 {
   if (((pat)->code) == SEQUENCE
       && ! add_equal_note (pat, temp, unoptab->code, xop0, (rtx) 0))
     {
       delete_insns_since (last);
       return expand_unop (mode, unoptab, op0, (rtx) 0, unsignedp);
     }

   emit_insn (pat);

   return temp;
 }
      else
 delete_insns_since (last);
    }



  if (cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
    for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
  wider_mode = (mode_wider_mode[(int)(wider_mode)]))
      {
 if (unoptab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing)
   {
     rtx xop0 = op0;





     xop0 = widen_operand (xop0, wider_mode, mode, unsignedp,
      (unoptab == neg_optab
       || unoptab == one_cmpl_optab)
      && cxx_class == MODE_INT);

     temp = expand_unop (wider_mode, unoptab, xop0, (rtx) 0,
    unsignedp);

     if (temp)
       {
  if (cxx_class != MODE_INT)
    {
      if (target == 0)
        target = gen_reg_rtx (mode);
      convert_move (target, temp, 0);
      return target;
    }
  else
    return gen_lowpart (mode, temp);
       }
     else
       delete_insns_since (last);
   }
      }


  if (unoptab == one_cmpl_optab
      && cxx_class == MODE_INT
      && (mode_size[(int)(mode)]) > ((target_flags & 0x00002000) ? 8 : 4)
      && unoptab->handlers[(int) word_mode].insn_code != CODE_FOR_nothing)
    {
      int i;
      rtx insns;

      if (target == 0 || target == op0)
 target = gen_reg_rtx (mode);

      start_sequence ();


      for (i = 0; i < (8 * mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 64 : 32); i++)
 {
   rtx target_piece = operand_subword (target, i, 1, mode);
   rtx x = expand_unop (word_mode, unoptab,
          operand_subword_force (op0, i, mode),
          target_piece, unsignedp);
   if (target_piece != x)
     emit_move_insn (target_piece, x);
 }

      insns = get_insns ();
      end_sequence ();

      emit_no_conflict_block (insns, target, op0, (rtx) 0,
         gen_rtx (unoptab->code, mode, copy_rtx (op0)));
      return target;
    }


  else if (unoptab == neg_optab
    && (cxx_class == MODE_COMPLEX_FLOAT || cxx_class == MODE_COMPLEX_INT))
    {
      rtx target_piece;
      rtx x;
      rtx seq;


      n64_enum_machine_mode submode
 = mode_for_size ((mode_unit_size[(int)(mode)]) * 8,
    cxx_class == MODE_COMPLEX_INT ? MODE_INT : MODE_FLOAT,
    0);

      if (submode == BLKmode)
 abort ();

      if (target == 0)
 target = gen_reg_rtx (mode);

      start_sequence ();

      target_piece = gen_imagpart (submode, target);
      x = expand_unop (submode, unoptab,
         gen_imagpart (submode, op0),
         target_piece, unsignedp);
      if (target_piece != x)
 emit_move_insn (target_piece, x);

      target_piece = gen_realpart (submode, target);
      x = expand_unop (submode, unoptab,
         gen_realpart (submode, op0),
         target_piece, unsignedp);
      if (target_piece != x)
 emit_move_insn (target_piece, x);

      seq = get_insns ();
      end_sequence ();

      emit_no_conflict_block (seq, target, op0, 0,
         gen_rtx (unoptab->code, mode, copy_rtx (op0)));
      return target;
    }


  if (unoptab->handlers[(int) mode].libfunc)
    {
      rtx insns;
      rtx funexp = unoptab->handlers[(int) mode].libfunc;
      rtx value;

      start_sequence ();



      value = emit_library_call_value (unoptab->handlers[(int) mode].libfunc,
           (rtx) 0, 1, mode, 1, op0, mode);
      insns = get_insns ();
      end_sequence ();

      target = gen_reg_rtx (mode);
      emit_libcall_block (insns, target, value,
     gen_rtx (unoptab->code, mode, op0));

      return target;
    }



  if (cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
    {
      for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
    wider_mode = (mode_wider_mode[(int)(wider_mode)]))
 {
   if ((unoptab->handlers[(int) wider_mode].insn_code
        != CODE_FOR_nothing)
       || unoptab->handlers[(int) wider_mode].libfunc)
     {
       rtx xop0 = op0;





       xop0 = widen_operand (xop0, wider_mode, mode, unsignedp,
        (unoptab == neg_optab
         || unoptab == one_cmpl_optab)
        && cxx_class == MODE_INT);

       temp = expand_unop (wider_mode, unoptab, xop0, (rtx) 0,
      unsignedp);

       if (temp)
  {
    if (cxx_class != MODE_INT)
      {
        if (target == 0)
   target = gen_reg_rtx (mode);
        convert_move (target, temp, 0);
        return target;
      }
    else
      return gen_lowpart (mode, temp);
  }
       else
  delete_insns_since (last);
     }
 }
    }



  if (unoptab == neg_optab)
    {
      rtx temp;
      temp = expand_binop (mode, sub_optab, (const_tiny_rtx[0][(int) (mode)]), op0,
      target, unsignedp, OPTAB_LIB_WIDEN);
      if (temp)
 return temp;
    }

  return 0;
}
rtx
expand_abs(n64_enum_machine_mode mode, rtx op0, rtx target, int unsignedp, int safe) asm("_expand_abs");
rtx
expand_abs(n64_enum_machine_mode mode, rtx op0, rtx target, int unsignedp, int safe)
{
  rtx temp, op1;


  temp = expand_unop (mode, abs_optab, op0, target, 0);
  if (temp != 0)
    return temp;





  if ((mode_class[(int)(mode)]) == MODE_INT && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2)
    {
      rtx extended = expand_shift (RSHIFT_EXPR, mode, op0,
       size_int ((8 * mode_size[(int)(mode)]) - 1),
       (rtx) 0, 0);

      temp = expand_binop (mode, xor_optab, extended, op0, target, 0,
      OPTAB_LIB_WIDEN);
      if (temp != 0)
 temp = expand_binop (mode, sub_optab, temp, extended, target, 0,
        OPTAB_LIB_WIDEN);

      if (temp != 0)
 return temp;
    }


  op1 = gen_label_rtx ();
  if (target == 0 || ! safe
      || ((target)->mode) != mode
      || (((target)->code) == MEM && ((target)->volatil))
      || (((target)->code) == REG
   && ((target)->fld[0].rtint) < 68))
    target = gen_reg_rtx (mode);

  emit_move_insn (target, op0);
  (inhibit_defer_pop += 1);



  if ((mode_class[(int)(mode)]) == MODE_INT && ! can_compare_p (mode))
    do_jump_by_parts_greater_rtx (mode, 0, target, const0_rtx,
      (rtx) 0, op1);
  else
    {
      temp = compare_from_rtx (target, (const_tiny_rtx[0][(int) (mode)]), GE, 0, mode,
          (rtx) 0, 0);
      if (temp == const1_rtx)
 return target;
      else if (temp != const0_rtx)
 {
   if (bcc_gen_fctn[(int) ((temp)->code)] != 0)
     emit_jump_insn ((*bcc_gen_fctn[(int) ((temp)->code)]) (op1));
   else
     abort ();
 }
    }

  op0 = expand_unop (mode, neg_optab, target, target, 0);
  if (op0 != target)
    emit_move_insn (target, op0);
  emit_label (op1);
  (inhibit_defer_pop -= 1);
  return target;
}
rtx
expand_complex_abs(n64_enum_machine_mode mode, rtx op0, rtx target, int unsignedp) asm("_expand_complex_abs");
rtx
expand_complex_abs(n64_enum_machine_mode mode, rtx op0, rtx target, int unsignedp)
{
  n64_enum_mode_class cxx_class = (mode_class[(int)(mode)]);
  n64_enum_machine_mode wider_mode;
  register rtx temp;
  rtx entry_last = get_last_insn ();
  rtx last;
  rtx pat;


  n64_enum_machine_mode submode
    = mode_for_size ((mode_unit_size[(int)(mode)]) * 8,
       cxx_class == MODE_COMPLEX_INT ? MODE_INT : MODE_FLOAT,
       0);

  if (submode == BLKmode)
    abort ();

  op0 = protect_from_queue (op0, 0);

  if (flag_force_mem)
    {
      op0 = force_not_mem (op0);
    }

  last = get_last_insn ();

  if (target)
    target = protect_from_queue (target, 1);

  if (abs_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) abs_optab->handlers[(int) mode].insn_code;
      n64_enum_machine_mode mode0 = insn_operand_mode[icode][1];
      rtx xop0 = op0;

      if (target)
 temp = target;
      else
 temp = gen_reg_rtx (submode);

      if (((xop0)->mode) != VOIDmode
   && ((xop0)->mode) != mode0)
 xop0 = convert_to_mode (mode0, xop0, unsignedp);



      if (! (*insn_operand_predicate[icode][1]) (xop0, mode0))
 xop0 = copy_to_mode_reg (mode0, xop0);

      if (! (*insn_operand_predicate[icode][0]) (temp, submode))
 temp = gen_reg_rtx (submode);

      pat = (*insn_gen_function[(int) (icode)]) (temp, xop0);
      if (pat)
 {
   if (((pat)->code) == SEQUENCE
       && ! add_equal_note (pat, temp, abs_optab->code, xop0, (rtx) 0))
     {
       delete_insns_since (last);
       return expand_unop (mode, abs_optab, op0, (rtx) 0, unsignedp);
     }

   emit_insn (pat);

   return temp;
 }
      else
 delete_insns_since (last);
    }



  for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
       wider_mode = (mode_wider_mode[(int)(wider_mode)]))
    {
      if (abs_optab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing)
 {
   rtx xop0 = op0;

   xop0 = convert_modes (wider_mode, mode, xop0, unsignedp);
   temp = expand_complex_abs (wider_mode, xop0, (rtx) 0, unsignedp);

   if (temp)
     {
       if (cxx_class != MODE_COMPLEX_INT)
  {
    if (target == 0)
      target = gen_reg_rtx (submode);
    convert_move (target, temp, 0);
    return target;
  }
       else
  return gen_lowpart (submode, temp);
     }
   else
     delete_insns_since (last);
 }
    }



  if (sqrt_optab->handlers[(int) submode].insn_code != CODE_FOR_nothing)
    {
      rtx real, imag, total;

      real = gen_realpart (submode, op0);
      imag = gen_imagpart (submode, op0);


      real = expand_mult (submode, real, real, (rtx) 0, 0);
      imag = expand_mult (submode, imag, imag, (rtx) 0, 0);


      total = expand_binop (submode, add_optab, real, imag, (rtx) 0,
       0, OPTAB_LIB_WIDEN);


      target = expand_unop (submode, sqrt_optab, total, target, 0);
      if (target == 0)
 delete_insns_since (last);
      else
 return target;
    }


  if (abs_optab->handlers[(int) mode].libfunc)
    {
      rtx insns;
      rtx funexp = abs_optab->handlers[(int) mode].libfunc;
      rtx value;

      start_sequence ();



      value = emit_library_call_value (abs_optab->handlers[(int) mode].libfunc,
           (rtx) 0, 1, submode, 1, op0, mode);
      insns = get_insns ();
      end_sequence ();

      target = gen_reg_rtx (submode);
      emit_libcall_block (insns, target, value,
     gen_rtx (abs_optab->code, mode, op0));

      return target;
    }



  for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
       wider_mode = (mode_wider_mode[(int)(wider_mode)]))
    {
      if ((abs_optab->handlers[(int) wider_mode].insn_code
    != CODE_FOR_nothing)
   || abs_optab->handlers[(int) wider_mode].libfunc)
 {
   rtx xop0 = op0;

   xop0 = convert_modes (wider_mode, mode, xop0, unsignedp);

   temp = expand_complex_abs (wider_mode, xop0, (rtx) 0, unsignedp);

   if (temp)
     {
       if (cxx_class != MODE_COMPLEX_INT)
  {
    if (target == 0)
      target = gen_reg_rtx (submode);
    convert_move (target, temp, 0);
    return target;
  }
       else
  return gen_lowpart (submode, temp);
     }
   else
     delete_insns_since (last);
 }
    }

  delete_insns_since (entry_last);
  return 0;
}







void
emit_unop_insn(int icode, rtx target, rtx op0, n64_enum_rtx_code code) asm("_emit_unop_insn");
void
emit_unop_insn(int icode, rtx target, rtx op0, n64_enum_rtx_code code)
{
  register rtx temp;
  n64_enum_machine_mode mode0 = insn_operand_mode[icode][1];
  rtx pat;

  temp = target = protect_from_queue (target, 1);

  op0 = protect_from_queue (op0, 0);

  if (flag_force_mem)
    op0 = force_not_mem (op0);



  if (! (*insn_operand_predicate[icode][1]) (op0, mode0))
    op0 = copy_to_mode_reg (mode0, op0);

  if (! (*insn_operand_predicate[icode][0]) (temp, ((temp)->mode))
      || (flag_force_mem && ((temp)->code) == MEM))
    temp = gen_reg_rtx (((temp)->mode));

  pat = (*insn_gen_function[(int) (icode)]) (temp, op0);

  if (((pat)->code) == SEQUENCE && code != UNKNOWN)
    add_equal_note (pat, temp, code, op0, (rtx) 0);

  emit_insn (pat);

  if (temp != target)
    emit_move_insn (target, temp);
}
rtx
emit_no_conflict_block(rtx insns, rtx target, rtx op0, rtx op1, rtx equiv) asm("_emit_no_conflict_block");
rtx
emit_no_conflict_block(rtx insns, rtx target, rtx op0, rtx op1, rtx equiv)
{
  rtx prev, next, first, last, insn;

  if (((target)->code) != REG || reload_in_progress)
    return emit_insns (insns);
  else
    for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
      if (((insn)->code) != INSN
   || find_reg_note (insn, REG_LIBCALL, (rtx) 0))
 return emit_insns (insns);



  for (insn = insns; insn; insn = next)
    {
      rtx set = 0;
      int i;

      next = ((insn)->fld[2].rtx);

      if (((((insn)->fld[3].rtx))->code) == SET)
 set = ((insn)->fld[3].rtx);
      else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
 {
   for (i = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
     if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) == SET)
       {
  set = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
  break;
       }
 }

      if (set == 0)
 abort ();

      if (! reg_overlap_mentioned_p (target, ((set)->fld[0].rtx)))
 {
   if (((insn)->fld[1].rtx))
     ((((insn)->fld[1].rtx))->fld[2].rtx) = next;
   else
     insns = next;

   if (next)
     ((next)->fld[1].rtx) = ((insn)->fld[1].rtx);

   add_insn (insn);
 }
    }

  prev = get_last_insn ();



  if (target != op0 && target != op1)
    emit_insn (gen_rtx (CLOBBER, VOIDmode, target));

  for (insn = insns; insn; insn = next)
    {
      next = ((insn)->fld[2].rtx);
      add_insn (insn);

      if (op1 && ((op1)->code) == REG)
 ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_NO_CONFLICT, op1,
        ((insn)->fld[6].rtx));

      if (op0 && ((op0)->code) == REG)
 ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_NO_CONFLICT, op0,
        ((insn)->fld[6].rtx));
    }

  if (mov_optab->handlers[(int) ((target)->mode)].insn_code
      != CODE_FOR_nothing)
    {
      last = emit_move_insn (target, target);
      if (equiv)
 ((last)->fld[6].rtx)
   = gen_rtx (EXPR_LIST, REG_EQUAL, equiv, ((last)->fld[6].rtx));
    }
  else
    last = get_last_insn ();

  if (prev == 0)
    first = get_insns ();
  else
    first = ((prev)->fld[2].rtx);


  ((first)->fld[6].rtx) = gen_rtx (INSN_LIST, REG_LIBCALL, last,
          ((first)->fld[6].rtx));
  ((last)->fld[6].rtx) = gen_rtx (INSN_LIST, REG_RETVAL, first, ((last)->fld[6].rtx));

  return last;
}
void
emit_libcall_block(rtx insns, rtx target, rtx result, rtx equiv) asm("_emit_libcall_block");
void
emit_libcall_block(rtx insns, rtx target, rtx result, rtx equiv)
{
  rtx prev, next, first, last, insn;







  for (insn = insns; insn; insn = next)
    {
      rtx set = single_set (insn);

      next = ((insn)->fld[2].rtx);

      if (set != 0 && ((((set)->fld[0].rtx))->code) == REG
   && ((((set)->fld[0].rtx))->fld[0].rtint) >= 68
   && (insn == insns
       || (! reg_mentioned_p (((set)->fld[0].rtx), ((insns)->fld[3].rtx))
    && ! reg_used_between_p (((set)->fld[0].rtx), insns, insn)
    && ! modified_in_p (((set)->fld[1].rtx), insns)
    && ! modified_between_p (((set)->fld[1].rtx), insns, insn))))
 {
   if (((insn)->fld[1].rtx))
     ((((insn)->fld[1].rtx))->fld[2].rtx) = next;
   else
     insns = next;

   if (next)
     ((next)->fld[1].rtx) = ((insn)->fld[1].rtx);

   add_insn (insn);
 }
    }

  prev = get_last_insn ();



  for (insn = insns; insn; insn = next)
    {
      next = ((insn)->fld[2].rtx);

      add_insn (insn);
    }

  last = emit_move_insn (target, result);
  ((last)->fld[6].rtx) = gen_rtx (EXPR_LIST,
         REG_EQUAL, copy_rtx (equiv), ((last)->fld[6].rtx));

  if (prev == 0)
    first = get_insns ();
  else
    first = ((prev)->fld[2].rtx);


  ((first)->fld[6].rtx) = gen_rtx (INSN_LIST, REG_LIBCALL, last,
          ((first)->fld[6].rtx));
  ((last)->fld[6].rtx) = gen_rtx (INSN_LIST, REG_RETVAL, first, ((last)->fld[6].rtx));
}



void
emit_clr_insn(rtx x) asm("_emit_clr_insn");
void
emit_clr_insn(rtx x)
{
  emit_move_insn (x, const0_rtx);
}




void
emit_0_to_1_insn(rtx x) asm("_emit_0_to_1_insn");
void
emit_0_to_1_insn(rtx x)
{
  emit_move_insn (x, const1_rtx);
}
void
emit_cmp_insn(rtx x, rtx y, n64_enum_rtx_code comparison, rtx size, n64_enum_machine_mode mode, int unsignedp, int align) asm("_emit_cmp_insn");
void
emit_cmp_insn(rtx x, rtx y, n64_enum_rtx_code comparison, rtx size, n64_enum_machine_mode mode, int unsignedp, int align)
{
  n64_enum_mode_class cxx_class;
  n64_enum_machine_mode wider_mode;

  cxx_class = (mode_class[(int)(mode)]);






  if (mode != BLKmode && flag_force_mem)
    {
      x = force_not_mem (x);
      y = force_not_mem (y);
    }



  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH) && preserve_subexpressions_p () && rtx_cost (x, COMPARE) > 2)
    x = force_reg (mode, x);

  if ((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH) && preserve_subexpressions_p () && rtx_cost (y, COMPARE) > 2)
    y = force_reg (mode, y);


  if (((x)->mode) == VOIDmode && ((y)->mode) == VOIDmode)
    x = force_reg (mode, x);



  if (mode == BLKmode)
    {
      emit_queue ();
      x = protect_from_queue (x, 0);
      y = protect_from_queue (y, 0);

      if (size == 0)
 abort ();
 {

   emit_library_call (memcmp_libfunc, 0,
        ((integer_type_node)->type.mode), 3,
        ((x)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode), ((y)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
        size, ((target_flags & 0x00000002) ? DImode : SImode));






   emit_cmp_insn (hard_libcall_value (((integer_type_node)->type.mode)),
    const0_rtx, comparison, (rtx) 0,
    ((integer_type_node)->type.mode), 0, 0);
 }
      return;
    }



  if (y == (const_tiny_rtx[0][(int) (mode)])
      && tst_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) tst_optab->handlers[(int) mode].insn_code;

      emit_queue ();
      x = protect_from_queue (x, 0);
      y = protect_from_queue (y, 0);


      if (! (*insn_operand_predicate[icode][0])
   (x, insn_operand_mode[icode][0]))
 x = copy_to_mode_reg (insn_operand_mode[icode][0], x);

      emit_insn ((*insn_gen_function[(int) (icode)]) (x));
      return;
    }



  if (cmp_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    {
      int icode = (int) cmp_optab->handlers[(int) mode].insn_code;

      emit_queue ();
      x = protect_from_queue (x, 0);
      y = protect_from_queue (y, 0);


      if (! (*insn_operand_predicate[icode][0])
   (x, insn_operand_mode[icode][0]))
 x = copy_to_mode_reg (insn_operand_mode[icode][0], x);

      if (! (*insn_operand_predicate[icode][1])
   (y, insn_operand_mode[icode][1]))
 y = copy_to_mode_reg (insn_operand_mode[icode][1], y);

      emit_insn ((*insn_gen_function[(int) (icode)]) (x, y));
      return;
    }



  if (cxx_class == MODE_INT || cxx_class == MODE_FLOAT || cxx_class == MODE_COMPLEX_FLOAT)
    {
      for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
    wider_mode = (mode_wider_mode[(int)(wider_mode)]))
 {
   if (cmp_optab->handlers[(int) wider_mode].insn_code
       != CODE_FOR_nothing)
     {
       x = protect_from_queue (x, 0);
       y = protect_from_queue (y, 0);
       x = convert_modes (wider_mode, mode, x, unsignedp);
       y = convert_modes (wider_mode, mode, y, unsignedp);
       emit_cmp_insn (x, y, comparison, (rtx) 0,
        wider_mode, unsignedp, align);
       return;
     }
 }
    }



  if (cmp_optab->handlers[(int) mode].libfunc
      && cxx_class != MODE_FLOAT)
    {
      rtx libfunc = cmp_optab->handlers[(int) mode].libfunc;


      if (unsignedp && ucmp_optab->handlers[(int) mode].libfunc)
 libfunc = ucmp_optab->handlers[(int) mode].libfunc;

      emit_library_call (libfunc, 1,
    word_mode, 2, x, mode, y, mode);





      emit_cmp_insn (hard_libcall_value (word_mode), const1_rtx,
       comparison, (rtx) 0, word_mode, unsignedp, 0);
      return;
    }

  if (cxx_class == MODE_FLOAT)
    emit_float_lib_cmp (x, y, comparison);

  else
    abort ();
}




int
can_compare_p(n64_enum_machine_mode mode) asm("_can_compare_p");
int
can_compare_p(n64_enum_machine_mode mode)
{
  do
    {
      if (cmp_optab->handlers[(int)mode].insn_code != CODE_FOR_nothing)
 return 1;
      mode = (mode_wider_mode[(int)(mode)]);
    } while (mode != VOIDmode);

  return 0;
}




void
emit_float_lib_cmp(rtx x, rtx y, n64_enum_rtx_code comparison) asm("_emit_float_lib_cmp");
void
emit_float_lib_cmp(rtx x, rtx y, n64_enum_rtx_code comparison)
{
  n64_enum_machine_mode mode = ((x)->mode);
  rtx libfunc = 0;

  if (mode == HFmode)
    switch (comparison)
      {
      case EQ:
 libfunc = eqhf2_libfunc;
 break;

      case NE:
 libfunc = nehf2_libfunc;
 break;

      case GT:
 libfunc = gthf2_libfunc;
 break;

      case GE:
 libfunc = gehf2_libfunc;
 break;

      case LT:
 libfunc = lthf2_libfunc;
 break;

      case LE:
 libfunc = lehf2_libfunc;
 break;
      }
  else if (mode == SFmode)
    switch (comparison)
      {
      case EQ:
 libfunc = eqsf2_libfunc;
 break;

      case NE:
 libfunc = nesf2_libfunc;
 break;

      case GT:
 libfunc = gtsf2_libfunc;
 break;

      case GE:
 libfunc = gesf2_libfunc;
 break;

      case LT:
 libfunc = ltsf2_libfunc;
 break;

      case LE:
 libfunc = lesf2_libfunc;
 break;
      }
  else if (mode == DFmode)
    switch (comparison)
      {
      case EQ:
 libfunc = eqdf2_libfunc;
 break;

      case NE:
 libfunc = nedf2_libfunc;
 break;

      case GT:
 libfunc = gtdf2_libfunc;
 break;

      case GE:
 libfunc = gedf2_libfunc;
 break;

      case LT:
 libfunc = ltdf2_libfunc;
 break;

      case LE:
 libfunc = ledf2_libfunc;
 break;
      }
  else if (mode == XFmode)
    switch (comparison)
      {
      case EQ:
 libfunc = eqxf2_libfunc;
 break;

      case NE:
 libfunc = nexf2_libfunc;
 break;

      case GT:
 libfunc = gtxf2_libfunc;
 break;

      case GE:
 libfunc = gexf2_libfunc;
 break;

      case LT:
 libfunc = ltxf2_libfunc;
 break;

      case LE:
 libfunc = lexf2_libfunc;
 break;
      }
  else if (mode == TFmode)
    switch (comparison)
      {
      case EQ:
 libfunc = eqtf2_libfunc;
 break;

      case NE:
 libfunc = netf2_libfunc;
 break;

      case GT:
 libfunc = gttf2_libfunc;
 break;

      case GE:
 libfunc = getf2_libfunc;
 break;

      case LT:
 libfunc = lttf2_libfunc;
 break;

      case LE:
 libfunc = letf2_libfunc;
 break;
      }
  else
    {
      n64_enum_machine_mode wider_mode;

      for (wider_mode = (mode_wider_mode[(int)(mode)]); wider_mode != VOIDmode;
    wider_mode = (mode_wider_mode[(int)(wider_mode)]))
 {
   if ((cmp_optab->handlers[(int) wider_mode].insn_code
        != CODE_FOR_nothing)
       || (cmp_optab->handlers[(int) wider_mode].libfunc != 0))
     {
       x = protect_from_queue (x, 0);
       y = protect_from_queue (y, 0);
       x = convert_to_mode (wider_mode, x, 0);
       y = convert_to_mode (wider_mode, y, 0);
       emit_float_lib_cmp (x, y, comparison);
       return;
     }
 }
      abort ();
    }

  if (libfunc == 0)
    abort ();

  emit_library_call (libfunc, 1,
       word_mode, 2, x, mode, y, mode);

  emit_cmp_insn (hard_libcall_value (word_mode), const0_rtx, comparison,
   (rtx) 0, word_mode, 0, 0);
}



void
emit_indirect_jump(rtx loc) asm("_emit_indirect_jump");
void
emit_indirect_jump(rtx loc)
{
  if (! ((*insn_operand_predicate[(int)CODE_FOR_indirect_jump][0])
  (loc, ((target_flags & 0x00000002) ? DImode : SImode))))
    loc = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), loc);

  emit_jump_insn (gen_indirect_jump (loc));
  emit_barrier ();
}
rtx
emit_conditional_move(rtx target, n64_enum_rtx_code code, rtx op0, rtx op1, n64_enum_machine_mode cmode, rtx op2, rtx op3, n64_enum_machine_mode mode, int unsignedp) asm("_emit_conditional_move");
rtx
emit_conditional_move(rtx target, n64_enum_rtx_code code, rtx op0, rtx op1, n64_enum_machine_mode cmode, rtx op2, rtx op3, n64_enum_machine_mode mode, int unsignedp)
{
  rtx tem, subtarget, comparison, insn;
  n64_enum_insn_code icode;




  if (((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ! (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH))
      || (((op0)->code) == CONST_INT && ((op1)->code) != CONST_INT))
    {
      tem = op0;
      op0 = op1;
      op1 = tem;
      code = swap_condition (code);
    }

  if (cmode == VOIDmode)
    cmode = ((op0)->mode);

  if (((((op2)->code) == LABEL_REF || ((op2)->code) == SYMBOL_REF || ((op2)->code) == CONST_INT || ((op2)->code) == CONST_DOUBLE || ((op2)->code) == CONST || ((op2)->code) == HIGH) && ! (((op3)->code) == LABEL_REF || ((op3)->code) == SYMBOL_REF || ((op3)->code) == CONST_INT || ((op3)->code) == CONST_DOUBLE || ((op3)->code) == CONST || ((op3)->code) == HIGH))
      || (((op2)->code) == CONST_INT && ((op3)->code) != CONST_INT))
    {
      tem = op2;
      op2 = op3;
      op3 = tem;



      code = reverse_condition (code);
    }

  if (mode == VOIDmode)
    mode = ((op2)->mode);

  icode = movcc_gen_code[mode];

  if (icode == CODE_FOR_nothing)
    return 0;

  if (flag_force_mem)
    {
      op2 = force_not_mem (op2);
      op3 = force_not_mem (op3);
    }

  if (target)
    target = protect_from_queue (target, 1);
  else
    target = gen_reg_rtx (mode);

  subtarget = target;

  emit_queue ();

  op2 = protect_from_queue (op2, 0);
  op3 = protect_from_queue (op3, 0);



  if (! (*insn_operand_predicate[icode][0])
      (subtarget, insn_operand_mode[icode][0]))
    subtarget = gen_reg_rtx (insn_operand_mode[icode][0]);

  if (! (*insn_operand_predicate[icode][2])
      (op2, insn_operand_mode[icode][2]))
    op2 = copy_to_mode_reg (insn_operand_mode[icode][2], op2);

  if (! (*insn_operand_predicate[icode][3])
      (op3, insn_operand_mode[icode][3]))
    op3 = copy_to_mode_reg (insn_operand_mode[icode][3], op3);




  comparison
    = compare_from_rtx (op0, op1, code, unsignedp, cmode, (rtx) 0, 0);


  if (((comparison)->code) != code)

    abort ();

  insn = (*insn_gen_function[(int) (icode)]) (subtarget, comparison, op2, op3);


  if (insn == 0)
    return 0;

  emit_insn (insn);

  if (subtarget != target)
    convert_move (target, subtarget, 0);

  return target;
}
int
can_conditionally_move_p(n64_enum_machine_mode mode) asm("_can_conditionally_move_p");
int
can_conditionally_move_p(n64_enum_machine_mode mode)
{
  if (movcc_gen_code[mode] != CODE_FOR_nothing)
    return 1;

  return 0;
}
rtx
gen_add2_insn(rtx x, rtx y) asm("_gen_add2_insn");
rtx
gen_add2_insn(rtx x, rtx y)
{
  int icode = (int) add_optab->handlers[(int) ((x)->mode)].insn_code;

  if (! (*insn_operand_predicate[icode][0]) (x, insn_operand_mode[icode][0])
      || ! (*insn_operand_predicate[icode][1]) (x, insn_operand_mode[icode][1])
      || ! (*insn_operand_predicate[icode][2]) (y, insn_operand_mode[icode][2]))
    abort ();

  return ((*insn_gen_function[(int) (icode)]) (x, x, y));
}

int
have_add2_insn(n64_enum_machine_mode mode) asm("_have_add2_insn");
int
have_add2_insn(n64_enum_machine_mode mode)
{
  return add_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing;
}



rtx
gen_sub2_insn(rtx x, rtx y) asm("_gen_sub2_insn");
rtx
gen_sub2_insn(rtx x, rtx y)
{
  int icode = (int) sub_optab->handlers[(int) ((x)->mode)].insn_code;

  if (! (*insn_operand_predicate[icode][0]) (x, insn_operand_mode[icode][0])
      || ! (*insn_operand_predicate[icode][1]) (x, insn_operand_mode[icode][1])
      || ! (*insn_operand_predicate[icode][2]) (y, insn_operand_mode[icode][2]))
    abort ();

  return ((*insn_gen_function[(int) (icode)]) (x, x, y));
}

int
have_sub2_insn(n64_enum_machine_mode mode) asm("_have_sub2_insn");
int
have_sub2_insn(n64_enum_machine_mode mode)
{
  return sub_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing;
}




rtx
gen_move_insn(rtx x, rtx y) asm("_gen_move_insn");
rtx
gen_move_insn(rtx x, rtx y)
{
  register n64_enum_machine_mode mode = ((x)->mode);
  n64_enum_insn_code insn_code;
  rtx seq;

  if (mode == VOIDmode)
    mode = ((y)->mode);

  insn_code = mov_optab->handlers[(int) mode].insn_code;





  if ((mode_class[(int)(mode)]) == MODE_CC && insn_code == CODE_FOR_nothing)
    {
      n64_enum_machine_mode tmode = VOIDmode;
      rtx x1 = x, y1 = y;

      if (mode != CCmode
   && mov_optab->handlers[(int) CCmode].insn_code != CODE_FOR_nothing)
 tmode = CCmode;
      else
 for (tmode = QImode; tmode != VOIDmode;
      tmode = (mode_wider_mode[(int)(tmode)]))
   if ((mode_size[(int)(tmode)]) == (mode_size[(int)(mode)]))
     break;

      if (tmode == VOIDmode)
 abort ();
      if (reload_in_progress)
 {
   x = gen_lowpart_common (tmode, x1);
   if (x == 0 && ((x1)->code) == MEM)
     {
       x = gen_rtx (MEM, tmode, ((x1)->fld[0].rtx));
       ((x)->unchanging) = ((x1)->unchanging);
       ((x)->in_struct) = ((x1)->in_struct);
       ((x)->volatil) = ((x1)->volatil);
       copy_replacements (x1, x);
     }

   y = gen_lowpart_common (tmode, y1);
   if (y == 0 && ((y1)->code) == MEM)
     {
       y = gen_rtx (MEM, tmode, ((y1)->fld[0].rtx));
       ((y)->unchanging) = ((y1)->unchanging);
       ((y)->in_struct) = ((y1)->in_struct);
       ((y)->volatil) = ((y1)->volatil);
       copy_replacements (y1, y);
     }
 }
      else
 {
   x = gen_lowpart (tmode, x);
   y = gen_lowpart (tmode, y);
 }

      insn_code = mov_optab->handlers[(int) tmode].insn_code;
      return ((*insn_gen_function[(int) (insn_code)]) (x, y));
    }

  start_sequence ();
  emit_move_insn_1 (x, y);
  seq = gen_sequence ();
  end_sequence ();
  return seq;
}





n64_enum_insn_code
can_extend_p(n64_enum_machine_mode to_mode, n64_enum_machine_mode from_mode, int unsignedp) asm("_can_extend_p");
n64_enum_insn_code
can_extend_p(n64_enum_machine_mode to_mode, n64_enum_machine_mode from_mode, int unsignedp)
{
  return extendtab[(int) to_mode][(int) from_mode][unsignedp];
}




rtx
gen_extend_insn(rtx x, rtx y, n64_enum_machine_mode mto, n64_enum_machine_mode mfrom, int unsignedp) asm("_gen_extend_insn");
rtx
gen_extend_insn(rtx x, rtx y, n64_enum_machine_mode mto, n64_enum_machine_mode mfrom, int unsignedp)
{
  return ((*insn_gen_function[(int) (extendtab[(int) mto][(int) mfrom][unsignedp])]) (x, y));
}
static n64_enum_insn_code
can_fix_p(n64_enum_machine_mode fixmode, n64_enum_machine_mode fltmode, int unsignedp, int *truncp_ptr) asm("_can_fix_p");
static n64_enum_insn_code
can_fix_p(n64_enum_machine_mode fixmode, n64_enum_machine_mode fltmode, int unsignedp, int *truncp_ptr)
{
  *truncp_ptr = 0;
  if (fixtrunctab[(int) fltmode][(int) fixmode][unsignedp] != CODE_FOR_nothing)
    return fixtrunctab[(int) fltmode][(int) fixmode][unsignedp];

  if (ftrunc_optab->handlers[(int) fltmode].insn_code != CODE_FOR_nothing)
    {
      *truncp_ptr = 1;
      return fixtab[(int) fltmode][(int) fixmode][unsignedp];
    }
  return CODE_FOR_nothing;
}

static n64_enum_insn_code
can_float_p(n64_enum_machine_mode fltmode, n64_enum_machine_mode fixmode, int unsignedp) asm("_can_float_p");
static n64_enum_insn_code
can_float_p(n64_enum_machine_mode fltmode, n64_enum_machine_mode fixmode, int unsignedp)
{
  return floattab[(int) fltmode][(int) fixmode][unsignedp];
}







void
expand_float(rtx to, rtx from, int unsignedp) asm("_expand_float");
void
expand_float(rtx to, rtx from, int unsignedp)
{
  n64_enum_insn_code icode;
  register rtx target = to;
  n64_enum_machine_mode fmode, imode;


  if (((from)->mode) == VOIDmode)
    abort ();






  for (imode = ((from)->mode); imode != VOIDmode;
       imode = (mode_wider_mode[(int)(imode)]))
    for (fmode = ((to)->mode); fmode != VOIDmode;
  fmode = (mode_wider_mode[(int)(fmode)]))
      {
 int doing_unsigned = unsignedp;

 icode = can_float_p (fmode, imode, unsignedp);
 if (icode == CODE_FOR_nothing && imode != ((from)->mode) && unsignedp)
   icode = can_float_p (fmode, imode, 0), doing_unsigned = 0;

 if (icode != CODE_FOR_nothing)
   {
     to = protect_from_queue (to, 1);
     from = protect_from_queue (from, 0);

     if (imode != ((from)->mode))
       from = convert_to_mode (imode, from, unsignedp);

     if (fmode != ((to)->mode))
       target = gen_reg_rtx (fmode);

     emit_unop_insn (icode, target, from,
       doing_unsigned ? UNSIGNED_FLOAT : FLOAT);

     if (target != to)
       convert_move (to, target, 0);
     return;
   }
    }





  if (unsignedp)
    {
      rtx label = gen_label_rtx ();
      rtx temp;
      double offset;

      emit_queue ();

      to = protect_from_queue (to, 1);
      from = protect_from_queue (from, 0);

      if (flag_force_mem)
 from = force_not_mem (from);





      for (fmode = ((to)->mode); fmode != VOIDmode;
    fmode = (mode_wider_mode[(int)(fmode)]))
 if ((8 * mode_size[(int)(((from)->mode))]) < (8 * mode_size[(int)(fmode)])
     && can_float_p (fmode, ((from)->mode), 0) != CODE_FOR_nothing)
   break;

      if (fmode == VOIDmode)
 {

   fmode = ((to)->mode);


   if ((significand_size (fmode) + 1)
       < (8 * mode_size[(int)(((from)->mode))]))
     {
       rtx temp1;
       rtx neglabel = gen_label_rtx ();



       if (((target)->code) != REG
    || ((target)->fld[0].rtint) < 68
    || ((target)->mode) != fmode)
  target = gen_reg_rtx (fmode);

       imode = ((from)->mode);
       do_pending_stack_adjust ();


       emit_cmp_insn (from, const0_rtx, GE, (rtx) 0, imode, 0, 0);
       emit_jump_insn (gen_blt (neglabel));


       expand_float (target, from, 0);
       emit_jump_insn (gen_jump (label));
       emit_barrier ();






       emit_label (neglabel);
       temp = expand_binop (imode, and_optab, from, const1_rtx,
       (rtx) 0, 1, OPTAB_LIB_WIDEN);
       temp1 = expand_shift (RSHIFT_EXPR, imode, from, integer_one_node,
        (rtx) 0, 1);
       temp = expand_binop (imode, ior_optab, temp, temp1, temp, 1,
       OPTAB_LIB_WIDEN);
       expand_float (target, temp, 0);


       temp = expand_binop (fmode, add_optab, target, target,
         target, 0, OPTAB_LIB_WIDEN);
       if (temp != target)
  emit_move_insn (target, temp);

       do_pending_stack_adjust ();
       emit_label (label);
       goto done;
     }
 }




      if (((to)->mode) != fmode
   || ((to)->code) != REG || ((to)->fld[0].rtint) < 68)
 target = gen_reg_rtx (fmode);


      expand_float (target, from, 0);




      do_pending_stack_adjust ();
      emit_cmp_insn (from, const0_rtx, GE, (rtx) 0, ((from)->mode), 0, 0);
      emit_jump_insn (gen_bge (label));




      offset = ereal_ldexp (dconst1, (8 * mode_size[(int)(((from)->mode))]));
      temp = expand_binop (fmode, add_optab, target,
      immed_real_const_1 (offset, fmode),
      target, 0, OPTAB_LIB_WIDEN);
      if (temp != target)
 emit_move_insn (target, temp);

      do_pending_stack_adjust ();
      emit_label (label);
      goto done;
    }




    {
      rtx libfcn;
      rtx insns;
      rtx value;

      to = protect_from_queue (to, 1);
      from = protect_from_queue (from, 0);

      if ((mode_size[(int)(((from)->mode))]) < (mode_size[(int)(SImode)]))
 from = convert_to_mode (SImode, from, unsignedp);

      if (flag_force_mem)
 from = force_not_mem (from);

      if (((to)->mode) == SFmode)
 {
   if (((from)->mode) == SImode)
     libfcn = floatsisf_libfunc;
   else if (((from)->mode) == DImode)
     libfcn = floatdisf_libfunc;
   else if (((from)->mode) == TImode)
     libfcn = floattisf_libfunc;
   else
     abort ();
 }
      else if (((to)->mode) == DFmode)
 {
   if (((from)->mode) == SImode)
     libfcn = floatsidf_libfunc;
   else if (((from)->mode) == DImode)
     libfcn = floatdidf_libfunc;
   else if (((from)->mode) == TImode)
     libfcn = floattidf_libfunc;
   else
     abort ();
 }
      else if (((to)->mode) == XFmode)
 {
   if (((from)->mode) == SImode)
     libfcn = floatsixf_libfunc;
   else if (((from)->mode) == DImode)
     libfcn = floatdixf_libfunc;
   else if (((from)->mode) == TImode)
     libfcn = floattixf_libfunc;
   else
     abort ();
 }
      else if (((to)->mode) == TFmode)
 {
   if (((from)->mode) == SImode)
     libfcn = floatsitf_libfunc;
   else if (((from)->mode) == DImode)
     libfcn = floatditf_libfunc;
   else if (((from)->mode) == TImode)
     libfcn = floattitf_libfunc;
   else
     abort ();
 }
      else
 abort ();

      start_sequence ();

      value = emit_library_call_value (libfcn, (rtx) 0, 1,
           ((to)->mode),
           1, from, ((from)->mode));
      insns = get_insns ();
      end_sequence ();

      emit_libcall_block (insns, target, value,
     gen_rtx (FLOAT, ((to)->mode), from));
    }

 done:




  if (target != to)
    {
      if (((target)->mode) == ((to)->mode))
 emit_move_insn (to, target);
      else
 convert_move (to, target, 0);
    }
}




static rtx
ftruncify(rtx x) asm("_ftruncify");
static rtx
ftruncify(rtx x)
{
  rtx temp = gen_reg_rtx (((x)->mode));
  return expand_unop (((x)->mode), ftrunc_optab, x, temp, 0);
}

void
expand_fix(register rtx to, register rtx from, int unsignedp) asm("_expand_fix");
void
expand_fix(register rtx to, register rtx from, int unsignedp)
{
  n64_enum_insn_code icode;
  register rtx target = to;
  n64_enum_machine_mode fmode, imode;
  int must_trunc = 0;
  rtx libfcn = 0;






  for (imode = ((to)->mode); imode != VOIDmode;
       imode = (mode_wider_mode[(int)(imode)]))
    for (fmode = ((from)->mode); fmode != VOIDmode;
  fmode = (mode_wider_mode[(int)(fmode)]))
      {
 int doing_unsigned = unsignedp;

 icode = can_fix_p (imode, fmode, unsignedp, &must_trunc);
 if (icode == CODE_FOR_nothing && imode != ((to)->mode) && unsignedp)
   icode = can_fix_p (imode, fmode, 0, &must_trunc), doing_unsigned = 0;

 if (icode != CODE_FOR_nothing)
   {
     to = protect_from_queue (to, 1);
     from = protect_from_queue (from, 0);

     if (fmode != ((from)->mode))
       from = convert_to_mode (fmode, from, 0);

     if (must_trunc)
       from = ftruncify (from);

     if (imode != ((to)->mode))
       target = gen_reg_rtx (imode);

     emit_unop_insn (icode, target, from,
       doing_unsigned ? UNSIGNED_FIX : FIX);
     if (target != to)
       convert_move (to, target, unsignedp);
     return;
   }
      }
  if (unsignedp && (8 * mode_size[(int)(((to)->mode))]) <= 32)
    for (fmode = ((from)->mode); fmode != VOIDmode;
  fmode = (mode_wider_mode[(int)(fmode)]))

      if ((8 * mode_size[(int)(fmode)]) > (8 * mode_size[(int)(((to)->mode))])
   && CODE_FOR_nothing != can_fix_p (((to)->mode), fmode, 0,
         &must_trunc))
 {
   int bitsize;
   double offset;
   rtx limit, lab1, lab2, insn;

   bitsize = (8 * mode_size[(int)(((to)->mode))]);
   offset = ereal_ldexp (dconst1, bitsize - 1);
   limit = immed_real_const_1 (offset, fmode);
   lab1 = gen_label_rtx ();
   lab2 = gen_label_rtx ();

   emit_queue ();
   to = protect_from_queue (to, 1);
   from = protect_from_queue (from, 0);

   if (flag_force_mem)
     from = force_not_mem (from);

   if (fmode != ((from)->mode))
     from = convert_to_mode (fmode, from, 0);


   do_pending_stack_adjust ();
   emit_cmp_insn (from, limit, GE, (rtx) 0, ((from)->mode), 0, 0);
   emit_jump_insn (gen_bge (lab1));


   expand_fix (to, from, 0);
   emit_jump_insn (gen_jump (lab2));
   emit_barrier ();




   emit_label (lab1);
   target = expand_binop (((from)->mode), sub_optab, from, limit,
     (rtx) 0, 0, OPTAB_LIB_WIDEN);
   expand_fix (to, target, 0);
   target = expand_binop (((to)->mode), xor_optab, to,
     gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << (bitsize - 1))),
     to, 1, OPTAB_LIB_WIDEN);

   if (target != to)
     emit_move_insn (to, target);

   emit_label (lab2);


   insn = emit_move_insn (to, to);
   ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_EQUAL,
          gen_rtx (UNSIGNED_FIX, ((to)->mode),
            copy_rtx (from)),
          ((insn)->fld[6].rtx));

   return;
 }






  if ((mode_size[(int)(((to)->mode))]) < (mode_size[(int)(SImode)]))
    {
      target = gen_reg_rtx (SImode);

      expand_fix (target, from, unsignedp);
    }
  else if (((from)->mode) == SFmode)
    {
      if (((to)->mode) == SImode)
 libfcn = unsignedp ? fixunssfsi_libfunc : fixsfsi_libfunc;
      else if (((to)->mode) == DImode)
 libfcn = unsignedp ? fixunssfdi_libfunc : fixsfdi_libfunc;
      else if (((to)->mode) == TImode)
 libfcn = unsignedp ? fixunssfti_libfunc : fixsfti_libfunc;
      else
 abort ();
    }
  else if (((from)->mode) == DFmode)
    {
      if (((to)->mode) == SImode)
 libfcn = unsignedp ? fixunsdfsi_libfunc : fixdfsi_libfunc;
      else if (((to)->mode) == DImode)
 libfcn = unsignedp ? fixunsdfdi_libfunc : fixdfdi_libfunc;
      else if (((to)->mode) == TImode)
 libfcn = unsignedp ? fixunsdfti_libfunc : fixdfti_libfunc;
      else
 abort ();
    }
  else if (((from)->mode) == XFmode)
    {
      if (((to)->mode) == SImode)
 libfcn = unsignedp ? fixunsxfsi_libfunc : fixxfsi_libfunc;
      else if (((to)->mode) == DImode)
 libfcn = unsignedp ? fixunsxfdi_libfunc : fixxfdi_libfunc;
      else if (((to)->mode) == TImode)
 libfcn = unsignedp ? fixunsxfti_libfunc : fixxfti_libfunc;
      else
 abort ();
    }
  else if (((from)->mode) == TFmode)
    {
      if (((to)->mode) == SImode)
 libfcn = unsignedp ? fixunstfsi_libfunc : fixtfsi_libfunc;
      else if (((to)->mode) == DImode)
 libfcn = unsignedp ? fixunstfdi_libfunc : fixtfdi_libfunc;
      else if (((to)->mode) == TImode)
 libfcn = unsignedp ? fixunstfti_libfunc : fixtfti_libfunc;
      else
 abort ();
    }
  else
    abort ();

  if (libfcn)
    {
      rtx insns;
      rtx value;

      to = protect_from_queue (to, 1);
      from = protect_from_queue (from, 0);

      if (flag_force_mem)
 from = force_not_mem (from);

      start_sequence ();

      value = emit_library_call_value (libfcn, (rtx) 0, 1, ((to)->mode),

           1, from, ((from)->mode));
      insns = get_insns ();
      end_sequence ();

      emit_libcall_block (insns, target, value,
     gen_rtx (unsignedp ? UNSIGNED_FIX : FIX,
       ((to)->mode), from));
    }

  if (((to)->mode) == ((target)->mode))
    emit_move_insn (to, target);
  else
    convert_move (to, target, 0);
}

static optab
init_optab(n64_enum_rtx_code code) asm("_init_optab");
static optab
init_optab(n64_enum_rtx_code code)
{
  int i;
  optab op = (optab) xmalloc (sizeof (struct n64_tag_optab));
  op->code = code;
  for (i = 0; i < (int) MAX_MACHINE_MODE; i++)
    {
      op->handlers[i].insn_code = CODE_FOR_nothing;
      op->handlers[i].libfunc = 0;
    }

  if (code != UNKNOWN)
    code_to_optab[(int) code] = op;

  return op;
}
static void
init_libfuncs(register optab optable, register int first_mode, register int last_mode, register char *opname, register int suffix) asm("_init_libfuncs");
static void
init_libfuncs(register optab optable, register int first_mode, register int last_mode, register char *opname, register int suffix)
{
  register int mode;
  register unsigned opname_len = strlen (opname);

  for (mode = first_mode; (int) mode <= (int) last_mode;
       mode = (n64_enum_machine_mode) ((int) mode + 1))
    {
      register char *mname = mode_name[(int) mode];
      register unsigned mname_len = strlen (mname);
      register char *libfunc_name
 = (char *) xmalloc (2 + opname_len + mname_len + 1 + 1);
      register char *p;
      register char *q;

      p = libfunc_name;
      *p++ = '_';
      *p++ = '_';
      for (q = opname; *q; )
 *p++ = *q++;
      for (q = mname; *q; q++)
 *p++ = tolower (*q);
      *p++ = suffix;
      *p++ = '\0';
      optable->handlers[(int) mode].libfunc
 = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), libfunc_name);
    }
}






static void
init_integral_libfuncs(register optab optable, register char *opname, register int suffix) asm("_init_integral_libfuncs");
static void
init_integral_libfuncs(register optab optable, register char *opname, register int suffix)
{
  init_libfuncs (optable, SImode, TImode, opname, suffix);
}






static void
init_floating_libfuncs(register optab optable, register char *opname, register int suffix) asm("_init_floating_libfuncs");
static void
init_floating_libfuncs(register optab optable, register char *opname, register int suffix)
{
  init_libfuncs (optable, SFmode, TFmode, opname, suffix);
}






static void
init_complex_libfuncs(register optab optable, register char *opname, register int suffix) asm("_init_complex_libfuncs");
static void
init_complex_libfuncs(register optab optable, register char *opname, register int suffix)
{
  init_libfuncs (optable, SCmode, TCmode, opname, suffix);
}




void
init_optabs(void) asm("_init_optabs");
void
init_optabs(void)
{
  int i, j;
  n64_enum_insn_code *p;



  for (p = fixtab[0][0];
       p < fixtab[0][0] + sizeof fixtab / sizeof (fixtab[0][0][0]);
       p++)
    *p = CODE_FOR_nothing;

  for (p = fixtrunctab[0][0];
       p < fixtrunctab[0][0] + sizeof fixtrunctab / sizeof (fixtrunctab[0][0][0]);
       p++)
    *p = CODE_FOR_nothing;

  for (p = floattab[0][0];
       p < floattab[0][0] + sizeof floattab / sizeof (floattab[0][0][0]);
       p++)
    *p = CODE_FOR_nothing;

  for (p = extendtab[0][0];
       p < extendtab[0][0] + sizeof extendtab / sizeof extendtab[0][0][0];
       p++)
    *p = CODE_FOR_nothing;

  for (i = 0; i < ((int)LAST_AND_UNUSED_RTX_CODE); i++)
    setcc_gen_code[i] = CODE_FOR_nothing;


  for (i = 0; i < (int) MAX_MACHINE_MODE; i++)
    movcc_gen_code[i] = CODE_FOR_nothing;


  add_optab = init_optab (PLUS);
  sub_optab = init_optab (MINUS);
  smul_optab = init_optab (MULT);
  smul_highpart_optab = init_optab (UNKNOWN);
  umul_highpart_optab = init_optab (UNKNOWN);
  smul_widen_optab = init_optab (UNKNOWN);
  umul_widen_optab = init_optab (UNKNOWN);
  sdiv_optab = init_optab (DIV);
  sdivmod_optab = init_optab (UNKNOWN);
  udiv_optab = init_optab (UDIV);
  udivmod_optab = init_optab (UNKNOWN);
  smod_optab = init_optab (MOD);
  umod_optab = init_optab (UMOD);
  flodiv_optab = init_optab (DIV);
  ftrunc_optab = init_optab (UNKNOWN);
  and_optab = init_optab (AND);
  ior_optab = init_optab (IOR);
  xor_optab = init_optab (XOR);
  ashl_optab = init_optab (ASHIFT);
  ashr_optab = init_optab (ASHIFTRT);
  lshr_optab = init_optab (LSHIFTRT);
  rotl_optab = init_optab (ROTATE);
  rotr_optab = init_optab (ROTATERT);
  smin_optab = init_optab (SMIN);
  smax_optab = init_optab (SMAX);
  umin_optab = init_optab (UMIN);
  umax_optab = init_optab (UMAX);
  mov_optab = init_optab (UNKNOWN);
  movstrict_optab = init_optab (UNKNOWN);
  cmp_optab = init_optab (UNKNOWN);
  ucmp_optab = init_optab (UNKNOWN);
  tst_optab = init_optab (UNKNOWN);
  neg_optab = init_optab (NEG);
  abs_optab = init_optab (ABS);
  one_cmpl_optab = init_optab (NOT);
  ffs_optab = init_optab (FFS);
  sqrt_optab = init_optab (SQRT);
  sin_optab = init_optab (UNKNOWN);
  cos_optab = init_optab (UNKNOWN);
  strlen_optab = init_optab (UNKNOWN);

  for (i = 0; i < (int) MAX_MACHINE_MODE; i++)
    {
      movstr_optab[i] = CODE_FOR_nothing;


      reload_in_optab[i] = reload_out_optab[i] = CODE_FOR_nothing;

    }


  init_all_optabs ();
  init_mov_optab ();



  init_integral_libfuncs (add_optab, "add", '3');
  init_floating_libfuncs (add_optab, "add", '3');
  init_integral_libfuncs (sub_optab, "sub", '3');
  init_floating_libfuncs (sub_optab, "sub", '3');
  init_integral_libfuncs (smul_optab, "mul", '3');
  init_floating_libfuncs (smul_optab, "mul", '3');
  init_integral_libfuncs (sdiv_optab, "div", '3');
  init_integral_libfuncs (udiv_optab, "udiv", '3');
  init_integral_libfuncs (sdivmod_optab, "divmod", '4');
  init_integral_libfuncs (udivmod_optab, "udivmod", '4');
  init_integral_libfuncs (smod_optab, "mod", '3');
  init_integral_libfuncs (umod_optab, "umod", '3');
  init_floating_libfuncs (flodiv_optab, "div", '3');
  init_floating_libfuncs (ftrunc_optab, "ftrunc", '2');
  init_integral_libfuncs (and_optab, "and", '3');
  init_integral_libfuncs (ior_optab, "ior", '3');
  init_integral_libfuncs (xor_optab, "xor", '3');
  init_integral_libfuncs (ashl_optab, "ashl", '3');
  init_integral_libfuncs (ashr_optab, "ashr", '3');
  init_integral_libfuncs (lshr_optab, "lshr", '3');
  init_integral_libfuncs (smin_optab, "min", '3');
  init_floating_libfuncs (smin_optab, "min", '3');
  init_integral_libfuncs (smax_optab, "max", '3');
  init_floating_libfuncs (smax_optab, "max", '3');
  init_integral_libfuncs (umin_optab, "umin", '3');
  init_integral_libfuncs (umax_optab, "umax", '3');
  init_integral_libfuncs (neg_optab, "neg", '2');
  init_floating_libfuncs (neg_optab, "neg", '2');
  init_integral_libfuncs (one_cmpl_optab, "one_cmpl", '2');
  init_integral_libfuncs (ffs_optab, "ffs", '2');


  init_integral_libfuncs (cmp_optab, "cmp", '2');
  init_integral_libfuncs (ucmp_optab, "ucmp", '2');
  init_floating_libfuncs (cmp_optab, "cmp", '2');
  abs_optab->handlers[(int) DCmode].libfunc
    = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "cabs");





  ffs_optab->handlers[(int) mode_for_size (((target_flags & 0x00000001) ? 64 : 32), MODE_INT, 0)] .libfunc
    = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "ffs");

  extendsfdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__extendsfdf2");
  extendsfxf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__extendsfxf2");
  extendsftf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__extendsftf2");
  extenddfxf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__extenddfxf2");
  extenddftf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__extenddftf2");

  truncdfsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__truncdfsf2");
  truncxfsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__truncxfsf2");
  trunctfsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__trunctfsf2");
  truncxfdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__truncxfdf2");
  trunctfdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__trunctfdf2");

  memcpy_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "memcpy");
  bcopy_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "bcopy");
  memcmp_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "memcmp");
  bcmp_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gcc_bcmp");
  memset_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "memset");
  bzero_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "bzero");

  eqhf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__eqhf2");
  nehf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__nehf2");
  gthf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gthf2");
  gehf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gehf2");
  lthf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__lthf2");
  lehf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__lehf2");

  eqsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__eqsf2");
  nesf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__nesf2");
  gtsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gtsf2");
  gesf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gesf2");
  ltsf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__ltsf2");
  lesf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__lesf2");

  eqdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__eqdf2");
  nedf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__nedf2");
  gtdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gtdf2");
  gedf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gedf2");
  ltdf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__ltdf2");
  ledf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__ledf2");

  eqxf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__eqxf2");
  nexf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__nexf2");
  gtxf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gtxf2");
  gexf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gexf2");
  ltxf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__ltxf2");
  lexf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__lexf2");

  eqtf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__eqtf2");
  netf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__netf2");
  gttf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__gttf2");
  getf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__getf2");
  lttf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__lttf2");
  letf2_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__letf2");

  floatsisf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatsisf");
  floatdisf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatdisf");
  floattisf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floattisf");

  floatsidf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatsidf");
  floatdidf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatdidf");
  floattidf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floattidf");

  floatsixf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatsixf");
  floatdixf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatdixf");
  floattixf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floattixf");

  floatsitf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatsitf");
  floatditf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floatditf");
  floattitf_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__floattitf");

  fixsfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixsfsi");
  fixsfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixsfdi");
  fixsfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixsfti");

  fixdfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixdfsi");
  fixdfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixdfdi");
  fixdfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixdfti");

  fixxfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixxfsi");
  fixxfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixxfdi");
  fixxfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixxfti");

  fixtfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixtfsi");
  fixtfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixtfdi");
  fixtfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixtfti");

  fixunssfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunssfsi");
  fixunssfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunssfdi");
  fixunssfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunssfti");

  fixunsdfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsdfsi");
  fixunsdfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsdfdi");
  fixunsdfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsdfti");

  fixunsxfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsxfsi");
  fixunsxfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsxfdi");
  fixunsxfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunsxfti");

  fixunstfsi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunstfsi");
  fixunstfdi_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunstfdi");
  fixunstfti_libfunc = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__fixunstfti");





}

