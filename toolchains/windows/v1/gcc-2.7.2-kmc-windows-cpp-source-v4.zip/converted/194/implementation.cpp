// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);

int prepends_underscore = 0;

