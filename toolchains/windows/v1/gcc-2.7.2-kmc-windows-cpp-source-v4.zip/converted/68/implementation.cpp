// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int constrain_operands(...) asm("_constrain_operands");
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;




extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];



int
insn_current_length(rtx insn) asm("_insn_current_length");
int
insn_current_length(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

int
insn_variable_length_p(rtx insn) asm("_insn_variable_length_p");
int
insn_variable_length_p(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

int
insn_default_length(rtx insn) asm("_insn_default_length");
int
insn_default_length(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 173:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
   return 2;
        }
      else if (which_alternative == 2)
        {
   return 4;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else
        {
   return 4;
        }

    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return 1;
        }
      else if ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8)))))
        {
   return 2;
        }
      else if (which_alternative == 9)
        {
   return 1;
        }
      else if (which_alternative == 10)
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else if (which_alternative == 2)
        {
   return 4;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return 4;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))
        {
   return 2;
        }
      else if (which_alternative == 10)
        {
   return 4;
        }
      else if (which_alternative == 11)
        {
   return 2;
        }
      else
        {
   return 4;
        }

    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
   return 1;
        }
      else if (which_alternative == 2)
        {
   return 2;
        }
      else if (which_alternative == 3)
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))
        {
   return 1;
        }
      else if (which_alternative == 10)
        {
   return 2;
        }
      else if (which_alternative == 11)
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 166:
    case 163:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8)))
        {
   return 1;
        }
      else
        {
   return 1;
        }

    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))
        {
   return 1;
        }
      else
        {
   return 1;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else if (which_alternative == 2)
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if (which_alternative == 6)
        {
   return 1;
        }
      else if (which_alternative == 7)
        {
   return 2;
        }
      else if ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || (which_alternative == 12)))))
        {
   return 1;
        }
      else
        {
   return 1;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else if (which_alternative == 2)
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if (which_alternative == 6)
        {
   return 1;
        }
      else if (which_alternative == 7)
        {
   return 2;
        }
      else if ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || (which_alternative == 11))))
        {
   return 1;
        }
      else if (which_alternative == 12)
        {
   return 2;
        }
      else if (which_alternative == 13)
        {
   return 1;
        }
      else if (which_alternative == 14)
        {
   return 2;
        }
      else if ((which_alternative == 15) || ((which_alternative == 16) || (which_alternative == 17)))
        {
   return 1;
        }
      else
        {
   return 1;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else if (which_alternative == 2)
        {
   return 1;
        }
      else if (which_alternative == 3)
        {
   return 2;
        }
      else if (which_alternative == 4)
        {
   return 1;
        }
      else if (which_alternative == 5)
        {
   return 2;
        }
      else if (which_alternative == 6)
        {
   return 1;
        }
      else if (which_alternative == 7)
        {
   return 2;
        }
      else if ((which_alternative == 8) || (which_alternative == 9))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative != 2)
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 324:
    case 323:
    case 320:
    case 317:
    case 316:
    case 313:
    case 283:
    case 281:
    case 273:
    case 271:
    case 265:
    case 263:
    case 255:
    case 253:
    case 247:
    case 245:
    case 240:
    case 238:
    case 204:
    case 194:
    case 184:
    case 109:
    case 108:
    case 107:
    case 104:
      return 2;

    case 310:
    case 207:
    case 197:
    case 187:
    case 82:
    case 18:
    case 5:
      return 4;

    case 309:
      return 0;

    case 307:
    case 79:
    case 78:
      return 6;

    case 303:
    case 302:
      if ((! ((((n64_enum_attr_abicalls)mips_abicalls)) == (ABICALLS_NO))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 203:
    case 193:
    case 183:
      return 12 ;

    case 179:
    case 177:
      return 20 ;

    case 175:
    case 75:
    case 74:
    case 34:
    case 30:
      return 3;

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 2;
        }
      else if (which_alternative == 1)
        {
   return 4;
        }
      else if (which_alternative == 2)
        {
   return 2;
        }
      else if (which_alternative == 3)
        {
   return 4;
        }
      else if (which_alternative == 4)
        {
   return 2;
        }
      else if (which_alternative == 5)
        {
   return 4;
        }
      else if (which_alternative == 6)
        {
   return 2;
        }
      else
        {
   return 2;
        }

    case 149:
    case 148:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 2;
        }
      else
        {
   return 4;
        }

    case 140:
    case 139:
    case 138:
    case 137:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 3;
        }
      else if (which_alternative == 1)
        {
   return 4;
        }
      else
        {
   return 3;
        }

    case 136:
    case 135:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 2;
        }
      else if (which_alternative == 1)
        {
   return 1;
        }
      else if (which_alternative == 2)
        {
   return 2;
        }
      else
        {
   return 3;
        }

    case 134:
    case 133:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 11 ;
        }
      else if (which_alternative == 1)
        {
   return 9;
        }
      else if (which_alternative == 2)
        {
   return 10 ;
        }
      else
        {
   return 11 ;
        }

    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 100:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((mips_isa) >= (3))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 97:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((mips_isa) >= (3))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 93:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((mips_isa) >= (3))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 90:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((mips_isa) >= (3))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 87:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((mips_isa) >= (3))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 71:
    case 70:
    case 69:
    case 68:
      return 7;

    case 67:
    case 65:
    case 60:
      return 14 ;

    case 66:
    case 64:
      return 13 ;

    case 63:
    case 62:
      return 8;

    case 61:
      return 15 ;

    case 21:
    case 8:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return 3;
        }
      else if (which_alternative == 1)
        {
   return 2;
        }
      else
        {
   return 4;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

int
result_ready_cost(rtx insn) asm("_result_ready_cost");
int
result_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 291:
    case 290:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || ((which_alternative == 6) || (which_alternative == 7)))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || (which_alternative == 2)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if (((which_alternative == 1) || (which_alternative == 2)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || ((which_alternative == 1) || ((which_alternative == 6) || (which_alternative == 7))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 166:
    case 165:
    case 163:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((((which_alternative == 2) || (which_alternative == 3)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || ((which_alternative == 6) || (which_alternative == 7)))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || ((which_alternative == 8) || (which_alternative == 9)))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || ((which_alternative == 8) || (which_alternative == 9)))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if (((which_alternative == 2) || (which_alternative == 3)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative != 0) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 3;
        }
      else if ((which_alternative != 0) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 85:
    case 84:
    case 77:
    case 76:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   return 2;
        }
      else
        {
   return 1;
        }

    case 73:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 54 ;
        }
      else
        {
   return 31 ;
        }

    case 72:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 112 ;
        }
      else
        {
   return 60 ;
        }

    case 71:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 65:
    case 64:
    case 63:
    case 62:
    case 61:
    case 60:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))
        {
   return 69 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))
        {
   return 42 ;
        }
      else if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 38 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   return 36 ;
        }
      else
        {
   return 35 ;
        }

    case 59:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))
        {
   return 32 ;
        }
      else if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 23 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 15 ;
        }
      else
        {
   return 12 ;
        }

    case 58:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))
        {
   return 61 ;
        }
      else if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 36 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 19 ;
        }
      else
        {
   return 16 ;
        }

    case 49:
    case 48:
    case 47:
    case 46:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 31:
    case 30:
    case 29:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 17 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 12 ;
        }
      else if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 10 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   return 4;
        }
      else
        {
   return 1;
        }

    case 27:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))
        {
   return 8;
        }
      else if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 7;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 5;
        }
      else
        {
   return 4;
        }

    case 26:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 8;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 6;
        }
      else
        {
   return 5;
        }

    case 14:
    case 13:
    case 1:
    case 0:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   return 4;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

int
divide_unit_ready_cost(rtx insn) asm("_divide_unit_ready_cost");
int
divide_unit_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 73:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 31 ;
        }
      else
        {
   return 54 ;
        }

    case 72:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 60 ;
        }
      else
        {
   return 112 ;
        }

    case 59:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 32 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 15 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 12 ;
        }
      else
        {
   return 23 ;
        }

    case 58:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 61 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 16 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 19 ;
        }
      else
        {
   return 36 ;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 112 ;

    }
}

unsigned int
divide_unit_blockage_range(rtx insn) asm("_divide_unit_blockage_range");
unsigned int
divide_unit_blockage_range(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 786544 ;

    }
}

int
mult_unit_ready_cost(rtx insn) asm("_mult_unit_ready_cost");
int
mult_unit_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 27:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 5;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 4;
        }
      else if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))
        {
   return 7;
        }
      else
        {
   return 8;
        }

    case 26:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 6;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 5;
        }
      else
        {
   return 8;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 8;

    }
}

unsigned int
mult_unit_blockage_range(rtx insn) asm("_mult_unit_blockage_range");
unsigned int
mult_unit_blockage_range(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 262152 ;

    }
}

int
adder_unit_ready_cost(rtx insn) asm("_adder_unit_ready_cost");
int
adder_unit_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 291:
    case 290:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))
        {
   return 2;
        }
      else
        {
   return 3;
        }

    case 85:
    case 84:
    case 77:
    case 76:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 2;
        }
      else if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 14:
    case 13:
    case 1:
    case 0:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   return 3;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 2;
        }
      else
        {
   return 4;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 4;

    }
}

unsigned int
adder_unit_blockage_range(rtx insn) asm("_adder_unit_blockage_range");
unsigned int
adder_unit_blockage_range(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65540 ;

    }
}

int
imuldiv_unit_ready_cost(rtx insn) asm("_imuldiv_unit_ready_cost");
int
imuldiv_unit_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8)))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8)))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8)))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8)))))))))) || (((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8))))))))))))))
        {
   return 1;
        }
      else
        {
   return 69 ;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))))))) || (((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))))))))))))
        {
   return 1;
        }
      else
        {
   return 69 ;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14)))))))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14)))))))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14)))))))))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14)))))))))))))))) || (((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14))))))))))))))))))))
        {
   return 1;
        }
      else
        {
   return 69 ;
        }

    case 166:
    case 163:
    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7))))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7))))))))) || (((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7)))))))))))))
        {
   return 1;
        }
      else
        {
   return 69 ;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5))))))) || (((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) && ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5)))))))))))
        {
   return 1;
        }
      else
        {
   return 69 ;
        }

    case 71:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 65:
    case 64:
    case 63:
    case 62:
    case 61:
    case 60:
      if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))
        {
   return 42 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   return 36 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 35 ;
        }
      else if (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))
        {
   return 38 ;
        }
      else
        {
   return 69 ;
        }

    case 49:
    case 48:
    case 47:
    case 46:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 31:
    case 30:
    case 29:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   return 10 ;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   return 4;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   return 12 ;
        }
      else
        {
   return 17 ;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 69 ;

    }
}

unsigned int
imuldiv_unit_blockage_range(rtx insn) asm("_imuldiv_unit_blockage_range");
unsigned int
imuldiv_unit_blockage_range(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 196677 ;

    }
}

int
memory_unit_ready_cost(rtx insn) asm("_memory_unit_ready_cost");
int
memory_unit_ready_cost(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 9) && (which_alternative != 10))))) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || (which_alternative == 2)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && (((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 166:
    case 165:
    case 163:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative != 4) && (which_alternative != 5)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative != 6) && (which_alternative != 7)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 13) || (which_alternative == 14)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 13) && (which_alternative != 14)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative != 6) && (which_alternative != 7))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))))))
        {
   return 3;
        }
      else if (((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 1;
        }
      else if ((((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative != 4) && (which_alternative != 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 180:
    case 149:
      return 1;

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative != 0) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))) || ((which_alternative == 0) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 3;

    }
}

unsigned int
memory_unit_blockage_range(rtx insn) asm("_memory_unit_blockage_range");
unsigned int
memory_unit_blockage_range(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else
        {
   return 65539 ;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65539 ;
        }

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || (which_alternative == 2)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || (which_alternative == 2)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else
        {
   return 65539 ;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 6) || (which_alternative == 7))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65539 ;
        }

    case 166:
    case 165:
    case 163:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65539 ;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else if (((which_alternative == 8) || (which_alternative == 9)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65539 ;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else if (((which_alternative == 8) || (which_alternative == 9)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65539 ;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else
        {
   return 65539 ;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else
        {
   return 65539 ;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative != 0) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else if ((which_alternative != 0) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   return 65537 ;
        }
      else
        {
   return 65539 ;
        }

    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   return 65538 ;
        }
      else
        {
   return 65537 ;
        }

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65539 ;

    }
}

int
function_units_used(rtx insn) asm("_function_units_used");
int
function_units_used(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 173:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 1) || (which_alternative == 2)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return 0;
        }
      else if ((((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return 0;
        }
      else if ((((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 6) || (which_alternative == 7)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return 0;
        }
      else if ((((which_alternative != 6) && (which_alternative != 7)) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 9) && (which_alternative != 10))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || (((which_alternative == 1) || (which_alternative == 2)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 0;
        }
      else if ((((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 1) || ((which_alternative == 6) || (which_alternative == 7))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return 0;
        }
      else if ((((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7))) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 166:
    case 163:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 6) || (which_alternative == 7)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || ((((which_alternative == 4) || (which_alternative == 5)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7)))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 6) && (which_alternative != 7)) && (((which_alternative != 4) && (which_alternative != 5)) && (((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7))))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 6) || (which_alternative == 7)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || ((((which_alternative == 4) || (which_alternative == 5)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 6) && (which_alternative != 7)) && (((which_alternative != 4) && (which_alternative != 5)) && (((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8)))))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 8) || (which_alternative == 9)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || ((((which_alternative == 6) || (which_alternative == 7)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 8) && (which_alternative != 9)) && (((which_alternative != 6) && (which_alternative != 7)) && (((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 8) || (which_alternative == 9)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))) || ((((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 13) || (which_alternative == 14)))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14))))))))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 8) && (which_alternative != 9)) && (((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 13) && (which_alternative != 14)))) && (((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 12) || ((which_alternative == 13) || (which_alternative == 14)))))))))))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 6) || (which_alternative == 7)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7)))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 6) && (which_alternative != 7)) && (((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7)))))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((((which_alternative == 4) || (which_alternative == 5)) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))) || (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))))
        {
   return 0;
        }
      else if (((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5)))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return 1;
        }
      else if ((((which_alternative != 4) && (which_alternative != 5)) && (((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || (which_alternative == 5)))))))) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative != 0) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))
        {
   return 0;
        }
      else if ((which_alternative == 0) && ((((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))))) || (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    case 180:
    case 149:
    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 0;
        }
      else
        {
   return 2;
        }

    case 73:
    case 72:
    case 59:
    case 58:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 4;
        }
      else
        {
   return 2;
        }

    case 71:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 65:
    case 64:
    case 63:
    case 62:
    case 61:
    case 60:
    case 49:
    case 48:
    case 47:
    case 46:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 31:
    case 30:
    case 29:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 1;
        }
      else
        {
   return 2;
        }

    case 27:
    case 26:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return 3;
        }
      else
        {
   return 2;
        }

    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 291:
    case 290:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 85:
    case 84:
    case 77:
    case 76:
    case 14:
    case 13:
    case 1:
    case 0:
      return 2;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && (! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))) || (((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT)))))))))
        {
   return -1 ;
        }
      else
        {
   return 2;
        }

    }
}

int
num_delay_slots(rtx insn) asm("_num_delay_slots");
int
num_delay_slots(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 319:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 310:
      if (((((n64_enum_attr_abicalls)mips_abicalls)) == (ABICALLS_NO)))
        {
   return 1;
        }
      else
        {
   return 0;
        }

    case 307:
    case 305:
    case 303:
    case 302:
    case 300:
    case 299:
    case 297:
    case 224:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
      return 1;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

n64_enum_attr_abicalls
get_attr_abicalls(void) asm("_get_attr_abicalls");
n64_enum_attr_abicalls
get_attr_abicalls(void)
{
}

n64_enum_attr_branch_likely
get_attr_branch_likely(void) asm("_get_attr_branch_likely");
n64_enum_attr_branch_likely
get_attr_branch_likely(void)
{
}

n64_enum_attr_cpu
get_attr_cpu(void) asm("_get_attr_cpu");
n64_enum_attr_cpu
get_attr_cpu(void)
{
}

n64_enum_attr_dslot
get_attr_dslot(rtx insn) asm("_get_attr_dslot");
n64_enum_attr_dslot
get_attr_dslot(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) || ((which_alternative == 6) || (which_alternative == 7)))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((which_alternative == 1) || (which_alternative == 2))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) || ((which_alternative == 1) || ((which_alternative == 6) || (which_alternative == 7))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 166:
    case 163:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) || (((which_alternative == 6) || (which_alternative == 7)) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7))))))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) || (((which_alternative == 6) || (which_alternative == 7)) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && (which_alternative != 8)))))))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) || (((which_alternative == 8) || (which_alternative == 9)) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) || (((which_alternative == 8) || (which_alternative == 9)) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && ((which_alternative != 10) && ((which_alternative != 11) && ((which_alternative != 12) && ((which_alternative != 13) && (which_alternative != 14)))))))))))))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && (which_alternative != 7)))))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 4) && (which_alternative != 5)))))))
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative != 0)
        {
   return DSLOT_YES;
        }
      else
        {
   return DSLOT_NO;
        }

    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 319:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 310:
    case 307:
    case 305:
    case 303:
    case 302:
    case 300:
    case 299:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 291:
    case 290:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 224:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      return DSLOT_YES;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      return DSLOT_NO;

    }
}

n64_enum_attr_mode
get_attr_mode(rtx insn) asm("_get_attr_mode");
n64_enum_attr_mode
get_attr_mode(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 285:
    case 286:
    case 287:
    case 288:
    case 289:
    case 290:
    case 291:
    case 292:
    case 293:
    case 294:
    case 295:
    case 296:
      return MODE_FPSW;

    case 0:
    case 13:
    case 26:
    case 50:
    case 52:
    case 54:
    case 56:
    case 58:
    case 72:
    case 76:
    case 84:
    case 132:
    case 133:
    case 135:
    case 137:
    case 138:
    case 171:
    case 172:
    case 173:
    case 334:
    case 335:
      return MODE_DF;

    case 1:
    case 14:
    case 27:
    case 51:
    case 53:
    case 55:
    case 57:
    case 59:
    case 73:
    case 77:
    case 85:
    case 103:
    case 134:
    case 136:
    case 139:
    case 140:
    case 168:
    case 169:
    case 332:
    case 333:
      return MODE_SF;

    case 5:
    case 8:
    case 11:
    case 18:
    case 21:
    case 24:
    case 25:
    case 33:
    case 34:
    case 43:
    case 44:
    case 61:
    case 63:
    case 65:
    case 67:
    case 69:
    case 71:
    case 75:
    case 79:
    case 82:
    case 83:
    case 87:
    case 90:
    case 93:
    case 95:
    case 97:
    case 100:
    case 102:
    case 114:
    case 116:
    case 119:
    case 121:
    case 123:
    case 131:
    case 151:
    case 153:
    case 175:
    case 184:
    case 187:
    case 190:
    case 193:
    case 194:
    case 197:
    case 200:
    case 203:
    case 204:
    case 207:
    case 210:
    case 237:
    case 240:
    case 244:
    case 247:
    case 251:
    case 255:
    case 259:
    case 262:
    case 265:
    case 269:
    case 273:
    case 277:
    case 280:
    case 283:
    case 330:
    case 331:
      return MODE_DI;

    case 105:
    case 112:
    case 117:
    case 162:
    case 163:
      return MODE_HI;

    case 106:
    case 165:
    case 166:
      return MODE_QI;

    case 177:
    case 179:
    case 180:
    case 217:
    case 218:
    case 219:
    case 220:
    case 221:
    case 222:
    case 223:
    case 224:
    case 297:
    case 299:
    case 300:
    case 302:
    case 303:
    case 305:
    case 307:
    case 309:
    case 310:
    case 312:
    case 313:
    case 314:
    case 315:
    case 316:
    case 317:
    case 319:
    case 320:
    case 321:
    case 322:
    case 323:
    case 324:
    case 326:
      return MODE_NONE;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
      return MODE_UNKNOWN;

    default:
      return MODE_SI;

    }
}

n64_enum_attr_type
get_attr_type(rtx insn) asm("_get_attr_type");
n64_enum_attr_type
get_attr_type(rtx insn)
{
  switch (recog_memoized (insn))
    {
    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || (which_alternative == 5))))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))
        {
   return TYPE_LOAD;
        }
      else if (which_alternative == 10)
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_STORE;
        }

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if ((which_alternative == 1) || (which_alternative == 2))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 3) || (which_alternative == 4))
        {
   return TYPE_STORE;
        }
      else if (which_alternative == 5)
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_XFER;
        }
      else if (which_alternative == 8)
        {
   return TYPE_MOVE;
        }
      else if ((which_alternative == 9) || (which_alternative == 10))
        {
   return TYPE_LOAD;
        }
      else if (which_alternative == 11)
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_STORE;
        }

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if ((which_alternative == 1) || (which_alternative == 2))
        {
   return TYPE_LOAD;
        }
      else if (which_alternative == 3)
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_STORE;
        }

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_XFER;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_XFER;
        }
      else if (which_alternative == 8)
        {
   return TYPE_MOVE;
        }
      else if ((which_alternative == 9) || (which_alternative == 10))
        {
   return TYPE_LOAD;
        }
      else if (which_alternative == 11)
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_STORE;
        }

    case 166:
    case 163:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_XFER;
        }
      else
        {
   return TYPE_HILO;
        }

    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_XFER;
        }
      else if (which_alternative == 8)
        {
   return TYPE_MOVE;
        }
      else
        {
   return TYPE_HILO;
        }

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 8) || (which_alternative == 9))
        {
   return TYPE_XFER;
        }
      else
        {
   return TYPE_HILO;
        }

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_STORE;
        }
      else if ((which_alternative == 8) || (which_alternative == 9))
        {
   return TYPE_XFER;
        }
      else if (which_alternative == 10)
        {
   return TYPE_MOVE;
        }
      else if ((which_alternative == 11) || (which_alternative == 12))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 13) || (which_alternative == 14))
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_HILO;
        }

    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_HILO;
        }

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
   return TYPE_ARITH;
        }
      else if ((which_alternative == 2) || (which_alternative == 3))
        {
   return TYPE_LOAD;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   return TYPE_STORE;
        }
      else
        {
   return TYPE_HILO;
        }

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (which_alternative == 0)
        {
   return TYPE_ARITH;
        }
      else
        {
   return TYPE_LOAD;
        }

    case 326:
      return TYPE_NOP;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    case 74:
    case 75:
    case 78:
    case 79:
    case 177:
    case 179:
      return TYPE_MULTI;

    case 72:
    case 73:
      return TYPE_FSQRT;

    case 103:
    case 132:
    case 133:
    case 134:
    case 135:
    case 136:
    case 137:
    case 138:
    case 139:
    case 140:
      return TYPE_FCVT;

    case 285:
    case 286:
    case 287:
    case 288:
    case 289:
    case 290:
    case 291:
    case 292:
    case 293:
    case 294:
    case 295:
    case 296:
      return TYPE_FCMP;

    case 84:
    case 85:
      return TYPE_FNEG;

    case 76:
    case 77:
      return TYPE_FABS;

    case 58:
    case 59:
      return TYPE_FDIV;

    case 50:
    case 51:
    case 52:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
      return TYPE_FMADD;

    case 26:
    case 27:
      return TYPE_FMUL;

    case 0:
    case 1:
    case 13:
    case 14:
      return TYPE_FADD;

    case 60:
    case 61:
    case 62:
    case 63:
    case 64:
    case 65:
    case 66:
    case 67:
    case 68:
    case 69:
    case 70:
    case 71:
      return TYPE_IDIV;

    case 29:
    case 30:
    case 31:
    case 33:
    case 34:
    case 36:
    case 37:
    case 38:
    case 40:
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
    case 48:
    case 49:
      return TYPE_IMUL;

    case 5:
    case 8:
    case 11:
    case 18:
    case 21:
    case 24:
    case 82:
    case 87:
    case 90:
    case 93:
    case 97:
    case 100:
    case 104:
    case 105:
    case 106:
    case 107:
    case 108:
    case 109:
    case 110:
    case 111:
    case 112:
    case 183:
    case 184:
    case 187:
    case 193:
    case 194:
    case 197:
    case 203:
    case 204:
    case 207:
      return TYPE_DARITH;

    case 175:
    case 328:
    case 329:
    case 330:
    case 331:
    case 332:
    case 333:
    case 334:
    case 335:
      return TYPE_MOVE;

    case 149:
    case 180:
      return TYPE_STORE;

    case 114:
    case 121:
    case 123:
    case 125:
    case 127:
    case 129:
    case 131:
    case 148:
      return TYPE_LOAD;

    case 310:
    case 312:
    case 313:
    case 314:
    case 315:
    case 316:
    case 317:
    case 319:
    case 320:
    case 321:
    case 322:
    case 323:
    case 324:
      return TYPE_CALL;

    case 297:
    case 299:
    case 300:
    case 302:
    case 303:
    case 305:
    case 307:
      return TYPE_JUMP;

    case 217:
    case 218:
    case 219:
    case 220:
    case 221:
    case 222:
    case 223:
    case 224:
      return TYPE_BRANCH;

    case 309:
      return TYPE_UNKNOWN;

    default:
      return TYPE_ARITH;

    }
}

int
eligible_for_delay(rtx delay_insn, int slot, rtx candidate_insn, int flags) asm("_eligible_for_delay");
int
eligible_for_delay(rtx delay_insn, int slot, rtx candidate_insn, int flags)
{
  rtx insn;

  if (slot >= 1)
    abort ();

  insn = delay_insn;
  switch (recog_memoized (insn))
    {
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 319:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 310:
      if (((((n64_enum_attr_abicalls)mips_abicalls)) == (ABICALLS_NO)))
        {
   slot += 3 * 1;
      break;
        }
      else
        {
   slot += 0 * 1;
      break;
        }
      break;

    case 307:
    case 305:
    case 303:
    case 302:
    case 300:
    case 299:
    case 297:
      slot += 2 * 1;
      break;
      break;

    case 224:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
      slot += 1 * 1;
      break;
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      slot += 0 * 1;
      break;
      break;

    }

  if (slot < 1)
    abort ();

  insn = candidate_insn;
  switch (slot)
    {
    case 3:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 10))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 3))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7)))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 11))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 166:
        case 163:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7)))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 165:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8))))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))))) && ((which_alternative != 1) && ((which_alternative != 3) && ((which_alternative != 5) && (which_alternative != 7)))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 12) || ((which_alternative == 13) || (which_alternative == 14))))))))))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 13) || ((which_alternative == 15) || ((which_alternative == 16) || ((which_alternative == 17) || (which_alternative == 18))))))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || (which_alternative == 9)))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 136:
        case 135:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 1)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 171:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 0)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 100:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 97:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 93:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 90:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 87:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        case 335:
        case 334:
        case 333:
        case 332:
        case 331:
        case 330:
        case 329:
        case 328:
        case 326:
        case 280:
        case 279:
        case 277:
        case 276:
        case 269:
        case 268:
        case 262:
        case 261:
        case 259:
        case 258:
        case 251:
        case 250:
        case 244:
        case 243:
        case 237:
        case 236:
        case 210:
        case 201:
        case 200:
        case 191:
        case 190:
        case 181:
        case 180:
        case 132:
        case 112:
        case 111:
        case 110:
        case 106:
        case 105:
        case 103:
        case 102:
        case 99:
        case 96:
        case 95:
        case 92:
        case 89:
        case 86:
        case 85:
        case 84:
        case 83:
        case 80:
        case 77:
        case 76:
        case 73:
        case 72:
        case 59:
        case 58:
        case 57:
        case 56:
        case 55:
        case 54:
        case 53:
        case 52:
        case 51:
        case 50:
        case 49:
        case 48:
        case 47:
        case 46:
        case 45:
        case 44:
        case 43:
        case 42:
        case 41:
        case 40:
        case 38:
        case 37:
        case 36:
        case 33:
        case 31:
        case 29:
        case 27:
        case 26:
        case 25:
        case 24:
        case 16:
        case 14:
        case 13:
        case 12:
        case 11:
        case 3:
        case 1:
        case 0:
   return 1;

        default:
   return 0;

      }
    case 2:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 10))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 3))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7)))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 11))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 166:
        case 163:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7)))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 165:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8))))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))))) && ((which_alternative != 1) && ((which_alternative != 3) && ((which_alternative != 5) && (which_alternative != 7)))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 12) || ((which_alternative == 13) || (which_alternative == 14))))))))))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 13) || ((which_alternative == 15) || ((which_alternative == 16) || ((which_alternative == 17) || (which_alternative == 18))))))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || (which_alternative == 9)))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 136:
        case 135:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 1)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 171:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 0)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 100:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 97:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 93:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 90:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 87:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        case 335:
        case 334:
        case 333:
        case 332:
        case 331:
        case 330:
        case 329:
        case 328:
        case 326:
        case 280:
        case 279:
        case 277:
        case 276:
        case 269:
        case 268:
        case 262:
        case 261:
        case 259:
        case 258:
        case 251:
        case 250:
        case 244:
        case 243:
        case 237:
        case 236:
        case 210:
        case 201:
        case 200:
        case 191:
        case 190:
        case 181:
        case 180:
        case 132:
        case 112:
        case 111:
        case 110:
        case 106:
        case 105:
        case 103:
        case 102:
        case 99:
        case 96:
        case 95:
        case 92:
        case 89:
        case 86:
        case 85:
        case 84:
        case 83:
        case 80:
        case 77:
        case 76:
        case 73:
        case 72:
        case 59:
        case 58:
        case 57:
        case 56:
        case 55:
        case 54:
        case 53:
        case 52:
        case 51:
        case 50:
        case 49:
        case 48:
        case 47:
        case 46:
        case 45:
        case 44:
        case 43:
        case 42:
        case 41:
        case 40:
        case 38:
        case 37:
        case 36:
        case 33:
        case 31:
        case 29:
        case 27:
        case 26:
        case 25:
        case 24:
        case 16:
        case 14:
        case 13:
        case 12:
        case 11:
        case 3:
        case 1:
        case 0:
   return 1;

        default:
   return 0;

      }
    case 1:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 10))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 3))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7)))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 11))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 166:
        case 163:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7)))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 165:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8))))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))))) && ((which_alternative != 1) && ((which_alternative != 3) && ((which_alternative != 5) && (which_alternative != 7)))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 12) || ((which_alternative == 13) || (which_alternative == 14))))))))))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 13) || ((which_alternative == 15) || ((which_alternative == 16) || ((which_alternative == 17) || (which_alternative == 18))))))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || (which_alternative == 9)))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 136:
        case 135:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 1)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 171:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (which_alternative == 0)
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 100:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 97:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 93:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 90:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 87:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((mips_isa) >= (3))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        case 335:
        case 334:
        case 333:
        case 332:
        case 331:
        case 330:
        case 329:
        case 328:
        case 326:
        case 280:
        case 279:
        case 277:
        case 276:
        case 269:
        case 268:
        case 262:
        case 261:
        case 259:
        case 258:
        case 251:
        case 250:
        case 244:
        case 243:
        case 237:
        case 236:
        case 210:
        case 201:
        case 200:
        case 191:
        case 190:
        case 181:
        case 180:
        case 132:
        case 112:
        case 111:
        case 110:
        case 106:
        case 105:
        case 103:
        case 102:
        case 99:
        case 96:
        case 95:
        case 92:
        case 89:
        case 86:
        case 85:
        case 84:
        case 83:
        case 80:
        case 77:
        case 76:
        case 73:
        case 72:
        case 59:
        case 58:
        case 57:
        case 56:
        case 55:
        case 54:
        case 53:
        case 52:
        case 51:
        case 50:
        case 49:
        case 48:
        case 47:
        case 46:
        case 45:
        case 44:
        case 43:
        case 42:
        case 41:
        case 40:
        case 38:
        case 37:
        case 36:
        case 33:
        case 31:
        case 29:
        case 27:
        case 26:
        case 25:
        case 24:
        case 16:
        case 14:
        case 13:
        case 12:
        case 11:
        case 3:
        case 1:
        case 0:
   return 1;

        default:
   return 0;

      }
    default:
      abort ();
    }
}

int
eligible_for_annul_false(rtx delay_insn, int slot, rtx candidate_insn, int flags) asm("_eligible_for_annul_false");
int
eligible_for_annul_false(rtx delay_insn, int slot, rtx candidate_insn, int flags)
{
  rtx insn;

  if (slot >= 1)
    abort ();

  insn = delay_insn;
  switch (recog_memoized (insn))
    {
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 319:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 310:
      if (((((n64_enum_attr_abicalls)mips_abicalls)) == (ABICALLS_NO)))
        {
   slot += 3 * 1;
      break;
        }
      else
        {
   slot += 0 * 1;
      break;
        }
      break;

    case 307:
    case 305:
    case 303:
    case 302:
    case 300:
    case 299:
    case 297:
      slot += 2 * 1;
      break;
      break;

    case 224:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
      slot += 1 * 1;
      break;
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      slot += 0 * 1;
      break;
      break;

    }

  if (slot < 1)
    abort ();

  insn = candidate_insn;
  switch (slot)
    {
    case 3:
      switch (recog_memoized (insn))
 {
        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        default:
   return 0;

      }
    case 2:
      switch (recog_memoized (insn))
 {
        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        default:
   return 0;

      }
    case 1:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && (((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 10)))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && (((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 3)))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7)))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 11)))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 166:
        case 163:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7)))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 165:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || (which_alternative == 8))))))))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10)))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9)))))))))))) && ((which_alternative != 1) && ((which_alternative != 3) && ((which_alternative != 5) && (which_alternative != 7))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 8) && (which_alternative != 9)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 12) || ((which_alternative == 13) || (which_alternative == 14))))))))))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || ((which_alternative == 9) || ((which_alternative == 10) || ((which_alternative == 11) || ((which_alternative == 13) || ((which_alternative == 15) || ((which_alternative == 16) || ((which_alternative == 17) || (which_alternative == 18)))))))))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 6) || (which_alternative == 7))))))))) && ((which_alternative == 0) || ((which_alternative == 2) || ((which_alternative == 4) || ((which_alternative == 6) || ((which_alternative == 8) || (which_alternative == 9))))))))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 136:
        case 135:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && (which_alternative == 1))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 171:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && (which_alternative == 0))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 100:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((mips_isa) >= (3)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 97:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((mips_isa) >= (3)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 93:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((mips_isa) >= (3)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 90:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((mips_isa) >= (3)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case 87:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((mips_isa) >= (2))) && ((mips_isa) >= (3)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        case 335:
        case 334:
        case 333:
        case 332:
        case 331:
        case 330:
        case 329:
        case 328:
        case 326:
        case 280:
        case 279:
        case 277:
        case 276:
        case 269:
        case 268:
        case 262:
        case 261:
        case 259:
        case 258:
        case 251:
        case 250:
        case 244:
        case 243:
        case 237:
        case 236:
        case 210:
        case 201:
        case 200:
        case 191:
        case 190:
        case 181:
        case 180:
        case 132:
        case 112:
        case 111:
        case 110:
        case 106:
        case 105:
        case 103:
        case 102:
        case 99:
        case 96:
        case 95:
        case 92:
        case 89:
        case 86:
        case 85:
        case 84:
        case 83:
        case 80:
        case 77:
        case 76:
        case 73:
        case 72:
        case 59:
        case 58:
        case 57:
        case 56:
        case 55:
        case 54:
        case 53:
        case 52:
        case 51:
        case 50:
        case 49:
        case 48:
        case 47:
        case 46:
        case 45:
        case 44:
        case 43:
        case 42:
        case 41:
        case 40:
        case 38:
        case 37:
        case 36:
        case 33:
        case 31:
        case 29:
        case 27:
        case 26:
        case 25:
        case 24:
        case 16:
        case 14:
        case 13:
        case 12:
        case 11:
        case 3:
        case 1:
        case 0:
   if (((mips_isa) >= (2)))
     {
       return 1;
     }
   else
     {
       return 0;
     }

        default:
   return 0;

      }
    default:
      abort ();
    }
}

static int
divide_unit_blockage(rtx executing_insn, rtx candidate_insn) asm("_divide_unit_blockage");
static int
divide_unit_blockage(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 73:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   casenum = 8;
        }
      else
        {
   casenum = 9;
        }
      break;

    case 72:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
        {
   casenum = 10 ;
        }
      else
        {
   casenum = 11 ;
        }
      break;

    case 59:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 1;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 58:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 4;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 5;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   casenum = 6;
        }
      else
        {
   casenum = 7;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 11 ;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 23 ;

    case 1:
      return 12 ;

    case 2:
      return 15 ;

    case 3:
      return 32 ;

    case 4:
      return 36 ;

    case 5:
      return 19 ;

    case 6:
      return 16 ;

    case 7:
      return 61 ;

    case 8:
      return 54 ;

    case 9:
      return 31 ;

    case 10:
      return 112 ;

    case 11:
      return 60 ;

    }
}

static int
mult_unit_blockage(rtx executing_insn, rtx candidate_insn) asm("_mult_unit_blockage");
static int
mult_unit_blockage(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 27:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 1;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 26:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   casenum = 4;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 5;
        }
      else
        {
   casenum = 6;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 6;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 7;

    case 1:
      return 4;

    case 2:
      return 5;

    case 3:
      return 8;

    case 4:
      return 8;

    case 5:
      return 5;

    case 6:
      return 6;

    }
}

static int
adder_unit_blockage(rtx executing_insn, rtx candidate_insn) asm("_adder_unit_blockage");
static int
adder_unit_blockage(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 291:
    case 290:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   casenum = 0;
        }
      else
        {
   casenum = 1;
        }
      break;

    case 85:
    case 84:
    case 77:
    case 76:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 5;
        }
      else
        {
   casenum = 6;
        }
      break;

    case 14:
    case 13:
    case 1:
    case 0:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000)))))))
        {
   casenum = 2;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 3;
        }
      else
        {
   casenum = 4;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 6;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 4;

    case 3:
      return 2;

    case 4:
      return 3;

    case 5:
      return 2;

    case 6:
      return 1;

    }
}

static int
imuldiv_unit_blockage(rtx executing_insn, rtx candidate_insn) asm("_imuldiv_unit_blockage");
static int
imuldiv_unit_blockage(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 166:
    case 163:
    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 71:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 65:
    case 64:
    case 63:
    case 62:
    case 61:
    case 60:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 5;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 6;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))
        {
   casenum = 7;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   casenum = 8;
        }
      else
        {
   casenum = 9;
        }
      break;

    case 49:
    case 48:
    case 47:
    case 46:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 31:
    case 30:
    case 29:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 1;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 2;
        }
      else if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   casenum = 3;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   casenum = 4;
        }
      else
        {
   casenum = 9;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 9;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 17 ;

    case 2:
      return 12 ;

    case 3:
      return 10 ;

    case 4:
      return 4;

    case 5:
      return 38 ;

    case 6:
      return 35 ;

    case 7:
      return 42 ;

    case 8:
      return 36 ;

    case 9:
      return 69 ;

    }
}

static int
imuldiv_unit_conflict_cost(rtx executing_insn, rtx candidate_insn) asm("_imuldiv_unit_conflict_cost");
static int
imuldiv_unit_conflict_cost(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 165:
    case 162:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 159:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 166:
    case 163:
    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      casenum = 0;
      break;

    case 71:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 65:
    case 64:
    case 63:
    case 62:
    case 61:
    case 60:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 5;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 6;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))
        {
   casenum = 7;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   casenum = 8;
        }
      else
        {
   casenum = 9;
        }
      break;

    case 49:
    case 48:
    case 47:
    case 46:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 31:
    case 30:
    case 29:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 1;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))
        {
   casenum = 2;
        }
      else if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000)))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))
        {
   casenum = 3;
        }
      else if (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))
        {
   casenum = 4;
        }
      else
        {
   casenum = 9;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 9;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 17 ;

    case 2:
      return 12 ;

    case 3:
      return 10 ;

    case 4:
      return 4;

    case 5:
      return 38 ;

    case 6:
      return 35 ;

    case 7:
      return 42 ;

    case 8:
      return 36 ;

    case 9:
      return 69 ;

    }
}

static int
memory_unit_blockage(rtx executing_insn, rtx candidate_insn) asm("_memory_unit_blockage");
static int
memory_unit_blockage(rtx executing_insn, rtx candidate_insn)
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 172:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 171:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10)))))))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 173:
    case 169:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || (which_alternative == 2)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 1) || (which_alternative == 2)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 168:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10)))))))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 158:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 13) || (which_alternative == 14))))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 159:
    case 153:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative == 6) || (which_alternative == 7))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 166:
    case 165:
    case 163:
    case 162:
    case 151:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
        {
   casenum = 0;
        }
      else if (((which_alternative == 2) || (which_alternative == 3)) && ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 1;
        }
      else if ((which_alternative == 4) || (which_alternative == 5))
        {
   casenum = 2;
        }
      else
        {
   casenum = 3;
        }
      break;

    case 180:
    case 149:
      casenum = 2;
      break;

    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
      insn_extract (insn);
      if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
        fatal_insn_not_found (insn);
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 0;
        }
      else
        {
   casenum = 1;
        }
      break;

    case 148:
    case 131:
    case 129:
    case 127:
    case 125:
    case 123:
    case 121:
    case 114:
      if ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))))
        {
   casenum = 0;
        }
      else
        {
   casenum = 1;
        }
      break;

    case -1:
      if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
          && asm_noperands (((insn)->fld[3].rtx)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else
     {
       return 3;
     }

        case 171:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 9) || (which_alternative == 10))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
     {
       return 2;
     }
   else
     {
       return 3;
     }

        case 173:
        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || (which_alternative == 2)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || (which_alternative == 2)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else
     {
       return 3;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 9) || (which_alternative == 10)))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else if (((which_alternative == 1) || ((which_alternative == 6) || (which_alternative == 7))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
     {
       return 2;
     }
   else
     {
       return 3;
     }

        case 166:
        case 165:
        case 163:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else if (((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
     {
       return 2;
     }
   else
     {
       return 3;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else if (((which_alternative == 8) || (which_alternative == 9)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
     {
       return 2;
     }
   else
     {
       return 3;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || ((which_alternative == 4) || ((which_alternative == 5) || ((which_alternative == 11) || (which_alternative == 12))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else if (((which_alternative == 8) || (which_alternative == 9)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))))))
     {
       return 2;
     }
   else
     {
       return 3;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 1) || ((which_alternative == 4) || (which_alternative == 5))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else
     {
       return 3;
     }

        case 151:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((which_alternative == 2) || (which_alternative == 3)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else if (((which_alternative == 2) || (which_alternative == 3)) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))))
     {
       return 1;
     }
   else
     {
       return 3;
     }

        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650)))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 148:
        case 131:
        case 129:
        case 127:
        case 125:
        case 123:
        case 121:
        case 114:
   if ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || ((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4650))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        default:
   return 3;

      }

    case 1:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 171:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 9) && (which_alternative != 10))))) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 6) && (which_alternative != 7)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 173:
        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 166:
        case 165:
        case 163:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 4) && (which_alternative != 5)) && ((which_alternative != 6) && (which_alternative != 7)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative != 8) && (which_alternative != 9)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 13) || (which_alternative == 14)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 13) && (which_alternative != 14)))) && ((which_alternative != 8) && (which_alternative != 9)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative != 6) && (which_alternative != 7))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 151:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative != 4) && (which_alternative != 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   return 1;

        case 148:
        case 131:
        case 129:
        case 127:
        case 125:
        case 123:
        case 121:
        case 114:
   return 1;

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        default:
   return 2;

      }

    case 2:
      return 1;

    case 3:
      switch (recog_memoized (insn))
 {
        case 172:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9)))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && (which_alternative != 9))))) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || (which_alternative == 9))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 171:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 5) && ((which_alternative != 9) && (which_alternative != 10))))) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 5) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 6) && (which_alternative != 7)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 173:
        case 169:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && (which_alternative != 2)) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 168:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 8) && ((which_alternative != 9) && (which_alternative != 10))))))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && ((which_alternative != 3) && ((which_alternative != 9) && (which_alternative != 10)))) && (((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((which_alternative == 3) || ((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 8) || ((which_alternative == 9) || (which_alternative == 10))))))))) && ((which_alternative != 1) && ((which_alternative != 6) && (which_alternative != 7))))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 166:
        case 165:
        case 163:
        case 162:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && (which_alternative != 3)) && (((which_alternative != 4) && (which_alternative != 5)) && ((which_alternative != 6) && (which_alternative != 7)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 159:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && (((which_alternative != 6) && (which_alternative != 7)) && ((which_alternative != 8) && (which_alternative != 9)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 158:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || ((which_alternative == 7) || ((which_alternative == 13) || (which_alternative == 14)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && ((which_alternative != 5) && ((which_alternative != 11) && (which_alternative != 12))))) && (((which_alternative != 6) && ((which_alternative != 7) && ((which_alternative != 13) && (which_alternative != 14)))) && ((which_alternative != 8) && (which_alternative != 9)))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 153:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 6) || (which_alternative == 7)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 1) && ((which_alternative != 4) && (which_alternative != 5))) && ((which_alternative != 6) && (which_alternative != 7))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 151:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   if ((((which_alternative == 4) || (which_alternative == 5)) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))) || ((((which_alternative != 2) && (which_alternative != 3)) && ((which_alternative != 4) && (which_alternative != 5))) && (((((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000)))) || (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600)))))))) || ((! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))))) && (! (((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_DEFAULT))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R3000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R6000))) && ((! ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4000))) && ((((n64_enum_attr_cpu)mips_cpu)) == (CPU_R4600))))))))))))
     {
       return 2;
     }
   else
     {
       return 1;
     }

        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
   insn_extract (insn);
   if (! constrain_operands (((insn)->fld[4].rtint), reload_completed))
     fatal_insn_not_found (insn);
   return 1;

        case 148:
        case 131:
        case 129:
        case 127:
        case 125:
        case 123:
        case 121:
        case 114:
   return 1;

        case -1:
   if (((((insn)->fld[3].rtx))->code) != ASM_INPUT
       && asm_noperands (((insn)->fld[3].rtx)) < 0)
     fatal_insn_not_found (insn);
        default:
   return 2;

      }

    }
}

struct n64_tag_function_unit_desc function_units[] = {
  {"memory", 1, 1, 0, 1, 1, memory_unit_ready_cost, 0, 3, memory_unit_blockage_range, memory_unit_blockage},
  {"imuldiv", 2, 1, 0, 0, 69, imuldiv_unit_ready_cost, imuldiv_unit_conflict_cost, 69, imuldiv_unit_blockage_range, imuldiv_unit_blockage},
  {"adder", 4, 1, 1, 1, 1, adder_unit_ready_cost, 0, 4, adder_unit_blockage_range, adder_unit_blockage},
  {"mult", 8, 1, 1, 1, 1, mult_unit_ready_cost, 0, 8, mult_unit_blockage_range, mult_unit_blockage},
  {"divide", 16, 1, 1, 1, 1, divide_unit_ready_cost, 0, 112, divide_unit_blockage_range, divide_unit_blockage},
};

int
const_num_delay_slots(rtx insn) asm("_const_num_delay_slots");
int
const_num_delay_slots(rtx insn)
{
  switch (recog_memoized (insn))
    {
    default:
      return 1;
    }
}

