// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/sb.c
/* sb.c - string buffer manipulation routines
   Copyright (C) 1994, 1995 Free Software Foundation, Inc.

   Written by Steve and Judy Chamberlain of Cygnus Support,
      sac@cygnus.com

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GAS; see the file COPYING.  If not, write to the Free
   Software Foundation, 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_le;
struct n64_tag_sb;









extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");
typedef struct n64_tag_sb
  {
    char *ptr;
    int len;
    int pot;
    struct n64_tag_le *item;
  }
sb;


typedef struct n64_tag_le
  {
    struct n64_tag_le *next;
    int size;
    char data[1];
  }
sb_element;


typedef struct
  {
    sb_element *size[30];
  } sb_list_vector;

extern int string_count[30];

extern void sb_build (sb *, int) asm("_sb_build");
extern void sb_new (sb *) asm("_sb_new");
extern void sb_kill (sb *) asm("_sb_kill");
extern void sb_add_sb (sb *, sb *) asm("_sb_add_sb");
extern void sb_reset (sb *) asm("_sb_reset");
extern void sb_add_char (sb *, int) asm("_sb_add_char");
extern void sb_add_string (sb *, const char *) asm("_sb_add_string");
extern void sb_add_buffer (sb *, const char *, int) asm("_sb_add_buffer");
extern void sb_print (FILE *, sb *) asm("_sb_print");
extern void sb_print_at (FILE *, int, sb *) asm("_sb_print_at");
extern char *sb_name (sb *) asm("_sb_name");
extern char *sb_terminate (sb *) asm("_sb_terminate");
extern int sb_skip_white (int, sb *) asm("_sb_skip_white");
extern int sb_skip_comma (int, sb *) asm("_sb_skip_comma");


extern void input_scrub_include_sb (sb *, char *) asm("_input_scrub_include_sb");
static void sb_check (sb *, int) asm("_sb_check");



int string_count[30];



static sb_list_vector free_list;



void
sb_build(sb *ptr, int size) asm("_sb_build");
void
sb_build(sb *ptr, int size)
{

  sb_element *e;

  if (size > 30)
    abort ();

  e = free_list.size[size];
  if (!e)
    {

      e = (sb_element *) xmalloc (sizeof (sb_element) + (1 << size));
      e->next = free_list.size[size];
      e->size = 1 << size;
      free_list.size[size] = e;
      string_count[size]++;
    }



  free_list.size[size] = e->next;


  ptr->ptr = e->data;
  ptr->pot = size;
  ptr->len = 0;
  ptr->item = e;
}


void
sb_new(sb *ptr) asm("_sb_new");
void
sb_new(sb *ptr)
{
  sb_build (ptr, 5);
}



void
sb_kill(sb *ptr) asm("_sb_kill");
void
sb_kill(sb *ptr)
{

  ptr->item->next = free_list.size[ptr->pot];
  free_list.size[ptr->pot] = ptr->item;
}



void
sb_add_sb(sb *ptr, sb *s) asm("_sb_add_sb");
void
sb_add_sb(sb *ptr, sb *s)
{
  sb_check (ptr, s->len);
  memcpy (ptr->ptr + ptr->len, s->ptr, s->len);
  ptr->len += s->len;
}




static void
sb_check(sb *ptr, int len) asm("_sb_check");
static void
sb_check(sb *ptr, int len)
{
  if (ptr->len + len >= 1 << ptr->pot)
    {
      sb tmp;
      int pot = ptr->pot;
      while (ptr->len + len >= 1 << pot)
 pot++;
      sb_build (&tmp, pot);
      sb_add_sb (&tmp, ptr);
      sb_kill (ptr);
      *ptr = tmp;
    }
}



void
sb_reset(sb *ptr) asm("_sb_reset");
void
sb_reset(sb *ptr)
{
  ptr->len = 0;
}



void
sb_add_char(sb *ptr, int c) asm("_sb_add_char");
void
sb_add_char(sb *ptr, int c)
{
  sb_check (ptr, 1);
  ptr->ptr[ptr->len++] = c;
}



void
sb_add_string(sb *ptr, const char *s) asm("_sb_add_string");
void
sb_add_string(sb *ptr, const char *s)
{
  int len = strlen (s);
  sb_check (ptr, len);
  memcpy (ptr->ptr + ptr->len, s, len);
  ptr->len += len;
}



void
sb_add_buffer(sb *ptr, const char *s, int len) asm("_sb_add_buffer");
void
sb_add_buffer(sb *ptr, const char *s, int len)
{
  sb_check (ptr, len);
  memcpy (ptr->ptr + ptr->len, s, len);
  ptr->len += len;
}



void
sb_print(FILE *outfile, sb *ptr) asm("_sb_print");
void
sb_print(FILE *outfile, sb *ptr)
{
  int i;
  int nc = 0;

  for (i = 0; i < ptr->len; i++)
    {
      if (nc)
 {
   fprintf (outfile, ",");
 }
      fprintf (outfile, "%d", ptr->ptr[i]);
      nc = 1;
    }
}

void
sb_print_at(FILE *outfile, int idx, sb *ptr) asm("_sb_print_at");
void
sb_print_at(FILE *outfile, int idx, sb *ptr)
{
  int i;
  for (i = idx; i < ptr->len; i++)
    putc (ptr->ptr[i], outfile);
}




char *
sb_name(sb *in) asm("_sb_name");
char *
sb_name(sb *in)
{

  sb_add_char (in, 0);
  return in->ptr;
}



char *
sb_terminate(sb *in) asm("_sb_terminate");
char *
sb_terminate(sb *in)
{
  sb_add_char (in, 0);
  --in->len;
  return in->ptr;
}




int
sb_skip_white(int idx, sb *ptr) asm("_sb_skip_white");
int
sb_skip_white(int idx, sb *ptr)
{
  while (idx < ptr->len
  && (ptr->ptr[idx] == ' '
      || ptr->ptr[idx] == '\t'))
    idx++;
  return idx;
}





int
sb_skip_comma(int idx, sb *ptr) asm("_sb_skip_comma");
int
sb_skip_comma(int idx, sb *ptr)
{
  while (idx < ptr->len
  && (ptr->ptr[idx] == ' '
      || ptr->ptr[idx] == '\t'))
    idx++;

  if (idx < ptr->len
      && ptr->ptr[idx] == ',')
    idx++;

  while (idx < ptr->len
  && (ptr->ptr[idx] == ' '
      || ptr->ptr[idx] == '\t'))
    idx++;

  return idx;
}

