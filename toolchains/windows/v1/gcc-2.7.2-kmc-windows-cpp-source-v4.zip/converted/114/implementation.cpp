// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/tekhex.c
/* BFD backend for Extended Tektronix Hex Format  objects.
   Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.

   Written by Steve Chamberlain of Cygnus Support <sac@cygnus.com>.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_areltdata;
struct n64_tag_artdata;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_data_struct;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;
struct n64_tag_tekhex_data_list_struct;
struct n64_tag_tekhex_data_struct;
struct n64_tag_tekhex_symbol_struct;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct bfd_link_info;
struct bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct bfd_link_order *link_order_head;
   struct bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct n64_tag_tekhex_data_struct *tekhex_data;
      struct elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct bfd_link_info *, struct bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct bfd_link_info *, struct bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct bfd_link_info *, boolean *again)
                                                            ;



  struct bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct bfd_link_info *, boolean (*checkfn) (bfd *, struct bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct bfd_link_info *, asection *, struct bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct bfd_link_info *, asection *, struct bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct ecoff_debug_info * const, const struct ecoff_debug_swap * const, struct ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct bfd_link_info *link_info, struct bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");

typedef struct
  {
    bfd_vma low;
    bfd_vma high;
  } addr_range_type;

typedef struct n64_tag_tekhex_symbol_struct
  {

    asymbol symbol;
    struct n64_tag_tekhex_symbol_struct *prev;

  } tekhex_symbol_type;

static const char digs[] = "0123456789ABCDEF";

static char sum_block[256];
static void
tekhex_init(void) asm("_tekhex_init");
static void
tekhex_init(void)
{
  unsigned int i;
  static boolean inited = cxx_false;
  int val;

  if (inited == cxx_false)
    {
      inited = cxx_true;
      hex_init ();
      val = 0;
      for (i = 0; i < 10; i++)
 {
   sum_block[i + '0'] = val++;
 }
      for (i = 'A'; i <= 'Z'; i++)
 {
   sum_block[i] = val++;
 }
      sum_block['$'] = val++;
      sum_block['%'] = val++;
      sum_block['.'] = val++;
      sum_block['_'] = val++;
      for (i = 'a'; i <= 'z'; i++)
 {
   sum_block[i] = val++;
 }
    }
}
struct n64_tag_tekhex_data_list_struct
{
  unsigned char *data;
  bfd_vma where;
  bfd_size_type size;
  struct n64_tag_tekhex_data_list_struct *next;

};
typedef struct n64_tag_tekhex_data_list_struct tekhex_data_list_type;



struct n64_tag_data_struct
  {
    char chunk_data[0x1fff + 1];
    char chunk_init[0x1fff + 1];
    bfd_vma vma;
    struct n64_tag_data_struct *next;
  };

typedef struct n64_tag_tekhex_data_struct
{
  tekhex_data_list_type *head;
  unsigned int type;
  struct n64_tag_tekhex_symbol_struct *symbols;
  struct n64_tag_data_struct *data;
} tdata_type;



static bfd_vma
getvalue(char **srcp) asm("_getvalue");
static bfd_vma
getvalue(char **srcp)
{
  char *src = *srcp;
  bfd_vma value = 0;
  unsigned int len = (_hex_value[(unsigned char) (*src++)]);

  if (len == 0)
    len = 16;
  while (len--)
    {
      value = value << 4 | (_hex_value[(unsigned char) (*src++)]);
    }
  *srcp = src;
  return value;
}

static unsigned int
getsym(char *dstp, char **srcp) asm("_getsym");
static unsigned int
getsym(char *dstp, char **srcp)
{
  char *src = *srcp;
  unsigned int i;
  unsigned int len = (_hex_value[(unsigned char) (*src++)]);

  if (len == 0)
    len = 16;
  for (i = 0; i < len; i++)
    dstp[i] = src[i];
  dstp[i] = 0;
  *srcp = src + i;
  return len;
}

struct n64_tag_data_struct *
find_chunk(bfd *abfd, bfd_vma vma) asm("_find_chunk");
struct n64_tag_data_struct *
find_chunk(bfd *abfd, bfd_vma vma)
{
  struct n64_tag_data_struct *d = abfd->tdata.tekhex_data->data;

  vma &= ~0x1fff;
  while (d && (d->vma) != vma)
    {
      d = d->next;
    }
  if (!d)
    {
      char *sname = bfd_alloc (abfd, 12);


      d = (struct n64_tag_data_struct *)
 bfd_alloc (abfd, sizeof (struct n64_tag_data_struct));

      if (!sname || !d)
 {
   bfd_set_error (bfd_error_no_memory);
   return 
         ((void *)0)
             ;
 }

      memset (d->chunk_init, 0, 0x1fff + 1);
      memset (d->chunk_data, 0, 0x1fff + 1);
      d->next = abfd->tdata.tekhex_data->data;
      d->vma = vma;
      abfd->tdata.tekhex_data->data = d;
    }
  return d;
}

static void
insert_byte(bfd *abfd, int value, bfd_vma addr) asm("_insert_byte");
static void
insert_byte(bfd *abfd, int value, bfd_vma addr)
{

  struct n64_tag_data_struct *d = find_chunk (abfd, addr);

  d->chunk_data[addr & 0x1fff] = value;
  d->chunk_init[addr & 0x1fff] = 1;
}



static void
first_phase(bfd *abfd, char type, char *src) asm("_first_phase");
static void
first_phase(bfd *abfd, char type, char *src)
{
  asection *section = ((asection *) &bfd_abs_section);
  int len;
  char sym[17];

  switch (type)
    {
    case '6':

      {
 bfd_vma addr = getvalue (&src);

 while (*src)
   {
     insert_byte (abfd, (((_hex_value[(unsigned char) ((src)[0])])<<4) + (_hex_value[(unsigned char) ((src)[1])])), addr);
     src += 2;
     addr++;
   }
      }

      return;
    case '3':

      len = getsym (sym, &src);
      section = bfd_get_section_by_name (abfd, sym);
      if (section == (asection *) 
                                 ((void *)0)
                                     )
 {
   char *n = bfd_alloc (abfd, len + 1);

   if (!n)
     {
       bfd_set_error (bfd_error_no_memory);
       abort();
     }
   memcpy (n, sym, len + 1);
   section = bfd_make_section (abfd, n);
 }
      while (*src)
 {
   switch (*src)
     {
     case '1':
       src++;
       section->vma = getvalue (&src);
       section->_raw_size = getvalue (&src) - section->vma;
       section->flags = 0x200 | 0x002 | 0x001;
       break;
     case '0':
     case '2':
     case '3':
     case '4':
     case '6':
     case '7':
     case '8':

       {
  tekhex_symbol_type *cxx_new =
  (tekhex_symbol_type *) bfd_alloc (abfd,
            sizeof (tekhex_symbol_type));
  char type = (*src);

  if (!cxx_new)
    {
      bfd_set_error (bfd_error_no_memory);
      abort();
    }
  cxx_new->symbol.the_bfd = abfd;
  src++;
  abfd->symcount++;
  abfd->flags |= 0x10;
  cxx_new->prev = abfd->tdata.tekhex_data->symbols;
  abfd->tdata.tekhex_data->symbols = cxx_new;
  len = getsym (sym, &src);
  cxx_new->symbol.name = bfd_alloc (abfd, len + 1);
  if (!cxx_new->symbol.name)
    {
      bfd_set_error (bfd_error_no_memory);
      abort();
    }
  memcpy ((char *) (cxx_new->symbol.name), sym, len + 1);
  cxx_new->symbol.section = section;
  if (type <= '4')
    cxx_new->symbol.flags = (0x02 | 0x02);
  else
    cxx_new->symbol.flags = 0x01;
  cxx_new->symbol.value = getvalue (&src) - section->vma;
       }
     }
 }
    }
}




static void
 pass_over(bfd *abfd, void (*func) (...)) asm("_pass_over");
static void
 pass_over(bfd *abfd, void (*func) (...))
{
  unsigned int chars_on_line;
  boolean eof = cxx_false;


  if (bfd_seek (abfd, (file_ptr) 0, 
                                   0
                                           ) != 0)
    abort ();
  while (eof == cxx_false)
    {
      char buffer[0xff];
      char *src = buffer;
      char type;


      eof = (boolean) (bfd_read (src, 1, 1, abfd) != 1);
      while (*src != '%' && !eof)
 {
   eof = (boolean) (bfd_read (src, 1, 1, abfd) != 1);
 }
      if (eof)
 break;
      src++;


      if (bfd_read (src, 1, 5, abfd) != 5)
 abort ();

      type = src[2];

      if (!((_hex_value[(unsigned char) (src[0])]) != 99) || !((_hex_value[(unsigned char) (src[1])]) != 99))
 break;

      chars_on_line = (((_hex_value[(unsigned char) ((src)[0])])<<4) + (_hex_value[(unsigned char) ((src)[1])])) - 5;

      if (bfd_read (src, 1, chars_on_line, abfd) != chars_on_line)
 abort ();
      src[chars_on_line] = 0;

      func (abfd, type, src);
    }

}

long
tekhex_get_symtab(bfd *abfd, asymbol **table) asm("_tekhex_get_symtab");
long
tekhex_get_symtab(bfd *abfd, asymbol **table)
{
  tekhex_symbol_type *p = abfd->tdata.tekhex_data->symbols;
  unsigned int c = ((abfd)->symcount);

  table[c] = 0;
  while (p)
    {
      table[--c] = &(p->symbol);
      p = p->prev;
    }

  return ((abfd)->symcount);
}

long
tekhex_get_symtab_upper_bound(bfd *abfd) asm("_tekhex_get_symtab_upper_bound");
long
tekhex_get_symtab_upper_bound(bfd *abfd)
{
  return (abfd->symcount + 1) * (sizeof (struct tekhex_asymbol_struct *));

}

static boolean
tekhex_mkobject(bfd *abfd) asm("_tekhex_mkobject");
static boolean
tekhex_mkobject(bfd *abfd)
{
  tdata_type *tdata = (tdata_type *) bfd_alloc (abfd, sizeof (tdata_type));

  if (!tdata)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  abfd->tdata.tekhex_data = tdata;
  tdata->type = 1;
  tdata->head = (tekhex_data_list_type *) 
                                         ((void *)0)
                                             ;
  tdata->symbols = (struct n64_tag_tekhex_symbol_struct *) 
                                                  ((void *)0)
                                                      ;
  tdata->data = (struct n64_tag_data_struct *) 
                                      ((void *)0)
                                          ;
  return cxx_true;
}





static const bfd_target *
tekhex_object_p(bfd *abfd) asm("_tekhex_object_p");
static const bfd_target *
tekhex_object_p(bfd *abfd)
{
  char b[4];

  tekhex_init ();

  if (bfd_seek (abfd, (file_ptr) 0, 
                                   0
                                           ) != 0
      || bfd_read (b, 1, 4, abfd) != 4)
    return 
          ((void *)0)
              ;

  if (b[0] != '%' || !((_hex_value[(unsigned char) (b[1])]) != 99) || !((_hex_value[(unsigned char) (b[2])]) != 99) || !((_hex_value[(unsigned char) (b[3])]) != 99))
    return (const bfd_target *) 
                               ((void *)0)
                                   ;

  tekhex_mkobject (abfd);

  pass_over (abfd, first_phase);
  return abfd->xvec;
}

static void
move_section_contents(bfd *abfd, asection *section, void *locationp, file_ptr offset, bfd_size_type count, boolean get) asm("_move_section_contents");
static void
move_section_contents(bfd *abfd, asection *section, void *locationp, file_ptr offset, bfd_size_type count, boolean get)
{
  bfd_vma addr;
  char *location = (char *) locationp;
  bfd_vma prev_number = 1;
  struct n64_tag_data_struct *d = (struct n64_tag_data_struct *) 
                                                ((void *)0)
                                                    ;

  for (addr = section->vma; count != 0; count--, addr++)
    {

      bfd_vma chunk_number = addr & ~0x1fff;
      bfd_vma low_bits = addr & 0x1fff;

      if (chunk_number != prev_number)
 {

   d = find_chunk (abfd, chunk_number);
 }

      if (get)
 {
   if (d->chunk_init[low_bits])
     {
       *location = d->chunk_data[low_bits];
     }
   else
     {
       *location = 0;
     }
 }
      else
 {
   d->chunk_data[low_bits] = *location;
   d->chunk_init[low_bits] = (*location != 0);
 }

      location++;

    }

}
static boolean
tekhex_get_section_contents(bfd *abfd, asection *section, void *locationp, file_ptr offset, bfd_size_type count) asm("_tekhex_get_section_contents");
static boolean
tekhex_get_section_contents(bfd *abfd, asection *section, void *locationp, file_ptr offset, bfd_size_type count)
{
  if (section->flags & (0x002 | 0x001))
    {
      move_section_contents (abfd, section, locationp, offset, count, cxx_true);
      return cxx_true;
    }
  else
    return cxx_false;
}

boolean
tekhex_set_arch_mach(bfd *abfd, n64_enum_bfd_architecture arch, long unsigned int machine) asm("_tekhex_set_arch_mach");
boolean
tekhex_set_arch_mach(bfd *abfd, n64_enum_bfd_architecture arch, long unsigned int machine)
{
  return bfd_default_set_arch_mach (abfd, arch, machine);
}




static boolean
tekhex_set_section_contents(bfd *abfd, sec_ptr section, void *locationp, file_ptr offset, bfd_size_type bytes_to_do) asm("_tekhex_set_section_contents");
static boolean
tekhex_set_section_contents(bfd *abfd, sec_ptr section, void *locationp, file_ptr offset, bfd_size_type bytes_to_do)
{

  if (abfd->output_has_begun == cxx_false)
    {

      asection *s = abfd->sections;
      bfd_vma vma;

      for (s = abfd->sections; s; s = s->next)
 {
   if (s->flags & 0x002)
     {
       for (vma = s->vma & ~0x1fff;
     vma < s->vma + s->_raw_size;
     vma += 0x1fff)
  find_chunk (abfd, vma);
     }
 }

    }
  if (section->flags & (0x002 | 0x001))
    {
      move_section_contents (abfd, section, locationp, offset, bytes_to_do, cxx_false);
      return cxx_true;
    }
  else
    return cxx_false;

}

static void
writevalue(char **dst, bfd_vma value) asm("_writevalue");
static void
writevalue(char **dst, bfd_vma value)
{
  char *p = *dst;
  int len;
  int shift;

  for (len = 8, shift = 28; shift; shift -= 4, len--)
    {
      if ((value >> shift) & 0xf)
 {
   *p++ = len + '0';
   while (len)
     {
       *p++ = digs[(value >> shift) & 0xf];
       shift -= 4;
       len--;
     }
   *dst = p;
   return;

 }
    }
  *p++ = '1';
  *p++ = '0';
  *dst = p;
}

static void
writesym(char **dst, const char *sym) asm("_writesym");
static void
writesym(char **dst, const char *sym)
{
  char *p = *dst;
  int len = (sym ? strlen (sym) : 0);

  if (len >= 16)
    {
      *p++ = '0';
      len = 16;
    }

  else
    {
      if (len == 0)
 {
   *p++ = '1';
   sym = "$";
   len = 1;
 }
      else
 {
   *p++ = digs[len];
 }
    }

  while (len--)
    {
      *p++ = *sym++;
    }
  *dst = p;
}

static void
out(bfd *abfd, char type, char *start, char *end) asm("_out");
static void
out(bfd *abfd, char type, char *start, char *end)
{
  int sum = 0;
  char *s;
  char front[6];
  bfd_size_type wrlen;

  front[0] = '%';
  (front + 1)[1] = digs[(end - start + 5) & 0xf]; (front + 1)[0] = digs[((end - start + 5)>>4)&0xf];;
  front[3] = type;

  for (s = start; s < end; s++)
    {
      sum += sum_block[(unsigned char) *s];
    }

  sum += sum_block[(unsigned char) front[1]];
  sum += sum_block[(unsigned char) front[2]];
  sum += sum_block[(unsigned char) front[3]];
  (front + 4)[1] = digs[(sum) & 0xf]; (front + 4)[0] = digs[((sum)>>4)&0xf];;
  if (bfd_write (front, 1, 6, abfd) != 6)
    abort ();
  end[0] = '\n';
  wrlen = end - start + 1;
  if (bfd_write (start, 1, wrlen, abfd) != wrlen)
    abort ();
}

static boolean
tekhex_write_object_contents(bfd *abfd) asm("_tekhex_write_object_contents");
static boolean
tekhex_write_object_contents(bfd *abfd)
{
  int bytes_written;
  char buffer[100];
  asymbol **p;
  asection *s;
  struct n64_tag_data_struct *d;

  bytes_written = 0;


  for (d = abfd->tdata.tekhex_data->data;
       d != (struct n64_tag_data_struct *) 
                                  ((void *)0)
                                      ;
       d = d->next)
    {
      int low;

      const int span = 32;
      int addr;



      for (addr = 0; addr < 0x1fff + 1; addr += span)
 {
   int need = 0;


   for (low = 0; !need && low < span; low++)
     {
       if (d->chunk_init[addr + low])
  need = 1;
     }
   if (need)
     {
       char *dst = buffer;

       writevalue (&dst, addr + d->vma);
       for (low = 0; low < span; low++)
  {
    (dst)[1] = digs[(d->chunk_data[addr + low]) & 0xf]; (dst)[0] = digs[((d->chunk_data[addr + low])>>4)&0xf];;
    dst += 2;
  }
       out (abfd, '6', buffer, dst);
     }
 }
    }

  for (s = abfd->sections; s != (asection *) 
                                            ((void *)0)
                                                ; s = s->next)
    {
      char *dst = buffer;

      writesym (&dst, s->name);
      *dst++ = '1';
      writevalue (&dst, s->vma);
      writevalue (&dst, s->vma + s->_raw_size);
      out (abfd, '3', buffer, dst);
    }


  for (p = abfd->outsymbols; *p; p++)
    {
      int section_code = bfd_decode_symclass (*p);

      if (section_code != '?')
 {
   asymbol *s = *p;
   char *dst = buffer;

   writesym (&dst, s->section->name);

   switch (section_code)
     {
     case 'A':
       *dst++ = '2';
       break;
     case 'a':
       *dst++ = '6';
       break;
     case 'D':
     case 'B':
     case 'O':
       *dst++ = '4';
       break;
     case 'd':
     case 'b':
     case 'o':
       *dst++ = '8';
       break;
     case 'T':
       *dst++ = '3';
       break;
     case 't':
       *dst++ = '7';
       break;
     case 'C':
     case 'U':
       bfd_set_error (bfd_error_wrong_format);
       return cxx_false;
     }

   writesym (&dst, s->name);
   writevalue (&dst, s->value + s->section->vma);
   out (abfd, '3', buffer, dst);
 }
    }


  if (bfd_write ("%0781010\n", 1, 9, abfd) != 9)
    abort ();
  return cxx_true;
}

static int
  tekhex_sizeof_headers(bfd *abfd, boolean exec) asm("_tekhex_sizeof_headers");
static int
  tekhex_sizeof_headers(bfd *abfd, boolean exec)
{
  return 0;
}

static asymbol *
tekhex_make_empty_symbol(bfd *abfd) asm("_tekhex_make_empty_symbol");
static asymbol *
tekhex_make_empty_symbol(bfd *abfd)
{
  tekhex_symbol_type *cxx_new =
  (tekhex_symbol_type *) bfd_zalloc (abfd, sizeof (struct n64_tag_tekhex_symbol_struct));

  if (!cxx_new)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  cxx_new->symbol.the_bfd = abfd;
  cxx_new->prev = (struct n64_tag_tekhex_symbol_struct *) 
                                             ((void *)0)
                                                 ;
  return &(cxx_new->symbol);
}

static void
tekhex_get_symbol_info(bfd *ignore_abfd, asymbol *symbol, symbol_info *ret) asm("_tekhex_get_symbol_info");
static void
tekhex_get_symbol_info(bfd *ignore_abfd, asymbol *symbol, symbol_info *ret)
{
  bfd_symbol_info (symbol, ret);
}

static void
tekhex_print_symbol(bfd *ignore_abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how) asm("_tekhex_print_symbol");
static void
tekhex_print_symbol(bfd *ignore_abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how)
{
  FILE *file = (FILE *) filep;

  switch (how)
    {
    case bfd_print_symbol_name:
      fprintf (file, "%s", symbol->name);
      break;
    case bfd_print_symbol_more:
      break;

    case bfd_print_symbol_all:
      {
 const char *section_name = symbol->section->name;

 bfd_print_symbol_vandf ((void *) file, symbol);

 fprintf (file, " %-5s %s",
   section_name,
   symbol->name);
      }
    }
}
extern const bfd_target tekhex_vec =
{
  "tekhex",
  bfd_target_tekhex_flavour,
  cxx_true,
  cxx_true,
  (0x02 |
   0x10 | 0x04 | 0x08 | 0x01 | 0x20 |
   0x80 | 0x100),
  (0x020 | 0x040 | 0x080 | 0x200
   | 0x001 | 0x002 | 0x004),
  0,
  ' ',
  16,
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,

  {
    _bfd_dummy_target,
    tekhex_object_p,
    _bfd_dummy_target,
    _bfd_dummy_target,
  },
  {
    bfd_false,
    tekhex_mkobject,
    _bfd_generic_mkarchive,
    bfd_false,
  },
  {
    bfd_false,
    tekhex_write_object_contents,
    _bfd_write_archive_contents,
    bfd_false,
  },

  bfd_true,bfd_true,((boolean (*) (bfd *, asection *)) bfd_true),tekhex_get_section_contents,_bfd_generic_get_section_contents_in_window,
  ((boolean (*) (bfd *, bfd *)) bfd_true),((boolean (*) (bfd *, bfd *)) bfd_true),((boolean (*) (bfd *, asection *, bfd *, asection *)) bfd_true),((boolean (*) (bfd *, asymbol *, bfd *, asymbol *)) bfd_true),((boolean (*) (bfd *, flagword)) bfd_true),((boolean (*) (bfd *, void *)) bfd_true),
  _bfd_nocore_core_file_failing_command,_bfd_nocore_core_file_failing_signal,_bfd_nocore_core_file_matches_executable_p,
  bfd_false,bfd_false,((boolean (*) (bfd *, char **, bfd_size_type *, const char **)) bfd_false),((void (*) (bfd *, const char *, char *)) bfd_void),((boolean (*) (bfd *, unsigned int, struct n64_tag_orl *, unsigned int, int)) bfd_false),bfd_nullvoidptr,((bfd *(*) (bfd *, bfd *)) bfd_nullvoidptr),bfd_generic_stat_arch_elt,bfd_false,
  tekhex_get_symtab_upper_bound,tekhex_get_symtab,tekhex_make_empty_symbol,tekhex_print_symbol,tekhex_get_symbol_info,bfd_generic_is_local_label,((alent *(*) (bfd *, asymbol *)) bfd_nullvoidptr),((boolean (*) (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *)) bfd_false),((asymbol *(*) (bfd *, void *, unsigned long)) bfd_nullvoidptr),_bfd_generic_read_minisymbols,_bfd_generic_minisymbol_to_symbol,
  ((long (*) (bfd *, asection *)) _bfd_n1),((long (*) (bfd *, asection *, arelent **, asymbol **)) _bfd_n1),((reloc_howto_type *(*) (bfd *, bfd_reloc_code_real_type)) bfd_nullvoidptr),
  tekhex_set_arch_mach,tekhex_set_section_contents,
  tekhex_sizeof_headers,bfd_generic_get_relocated_section_contents,bfd_generic_relax_section,_bfd_generic_link_hash_table_create,_bfd_generic_link_add_symbols,_bfd_generic_final_link,_bfd_generic_link_split_section,
  _bfd_n1,((long (*) (bfd *, asymbol **)) _bfd_n1),_bfd_n1,((long (*) (bfd *, arelent **, asymbol **)) _bfd_n1),

  (void *) 0
};

