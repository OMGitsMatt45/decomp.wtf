// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/obstack.c
/* obstack.c - subroutines used implicitly by object stack macros
   Copyright (C) 1988, 89, 90, 91, 92, 93, 94 Free Software Foundation, Inc.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__obstack_chunk;
struct n64_tag_fooalign;
union n64_tag_fooround;
struct n64_tag_obstack;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");

struct n64_tag_fooalign {char x; double d;};





union n64_tag_fooround {long x; double d;};
struct n64_tag_obstack *_obstack;
int
_obstack_begin(struct n64_tag_obstack *h, int size, int alignment, void *(*chunkfun) (...), void (*freefun) (...)) asm("__obstack_begin");
int
_obstack_begin(struct n64_tag_obstack *h, int size, int alignment, void *(*chunkfun) (...), void (*freefun) (...))
{
  register struct n64_tag__obstack_chunk* chunk;

  if (alignment == 0)
    alignment = ((ptrdiff_t) ((char *)&((struct n64_tag_fooalign *) 0)->d - (char *)0));
  if (size == 0)

    {
      int extra = ((((12 + (sizeof (union n64_tag_fooround)) - 1) & ~((sizeof (union n64_tag_fooround)) - 1))
      + 4 + (sizeof (union n64_tag_fooround)) - 1)
     & ~((sizeof (union n64_tag_fooround)) - 1));
      size = 4096 - extra;
    }

  h->chunkfun = (struct n64_tag__obstack_chunk * (*)(...)) chunkfun;
  h->freefun = freefun;
  h->chunk_size = size;
  h->alignment_mask = alignment - 1;
  h->use_extra_arg = 0;

  chunk = h->chunk = (((h) -> use_extra_arg) ? (*(h)->chunkfun) ((h)->extra_arg, (h -> chunk_size)) : (*(h)->chunkfun) ((h -> chunk_size)));
  if (!chunk)
    {
      h->alloc_failed = 1;
      return 0;
    }
  h->alloc_failed = 0;
  h->next_free = h->object_base = chunk->contents;
  h->chunk_limit = chunk->limit
    = (char *) chunk + h->chunk_size;
  chunk->prev = 0;

  h->maybe_empty_object = 0;
  return 1;
}

int
_obstack_begin_1(struct n64_tag_obstack *h, int size, int alignment, void *(*chunkfun) (...), void (*freefun) (...), void *arg) asm("__obstack_begin_1");
int
_obstack_begin_1(struct n64_tag_obstack *h, int size, int alignment, void *(*chunkfun) (...), void (*freefun) (...), void *arg)
{
  register struct n64_tag__obstack_chunk* chunk;

  if (alignment == 0)
    alignment = ((ptrdiff_t) ((char *)&((struct n64_tag_fooalign *) 0)->d - (char *)0));
  if (size == 0)

    {
      int extra = ((((12 + (sizeof (union n64_tag_fooround)) - 1) & ~((sizeof (union n64_tag_fooround)) - 1))
      + 4 + (sizeof (union n64_tag_fooround)) - 1)
     & ~((sizeof (union n64_tag_fooround)) - 1));
      size = 4096 - extra;
    }

  h->chunkfun = (struct n64_tag__obstack_chunk * (*)(...)) chunkfun;
  h->freefun = freefun;
  h->chunk_size = size;
  h->alignment_mask = alignment - 1;
  h->extra_arg = arg;
  h->use_extra_arg = 1;

  chunk = h->chunk = (((h) -> use_extra_arg) ? (*(h)->chunkfun) ((h)->extra_arg, (h -> chunk_size)) : (*(h)->chunkfun) ((h -> chunk_size)));
  if (!chunk)
    {
      h->alloc_failed = 1;
      return 0;
    }
  h->alloc_failed = 0;
  h->next_free = h->object_base = chunk->contents;
  h->chunk_limit = chunk->limit
    = (char *) chunk + h->chunk_size;
  chunk->prev = 0;

  h->maybe_empty_object = 0;
  return 1;
}







void
_obstack_newchunk(struct n64_tag_obstack *h, int length) asm("__obstack_newchunk");
void
_obstack_newchunk(struct n64_tag_obstack *h, int length)
{
  register struct n64_tag__obstack_chunk* old_chunk = h->chunk;
  register struct n64_tag__obstack_chunk* new_chunk;
  register long new_size;
  register int obj_size = h->next_free - h->object_base;
  register int i;
  int already;


  new_size = (obj_size + length) + (obj_size >> 3) + 100;
  if (new_size < h->chunk_size)
    new_size = h->chunk_size;


  new_chunk = (((h) -> use_extra_arg) ? (*(h)->chunkfun) ((h)->extra_arg, (new_size)) : (*(h)->chunkfun) ((new_size)));
  if (!new_chunk)
    {
      h->alloc_failed = 1;
      return;
    }
  h->alloc_failed = 0;
  h->chunk = new_chunk;
  new_chunk->prev = old_chunk;
  new_chunk->limit = h->chunk_limit = (char *) new_chunk + new_size;




  if (h->alignment_mask + 1 >= ((ptrdiff_t) ((char *)&((struct n64_tag_fooalign *) 0)->d - (char *)0)))
    {
      for (i = obj_size / sizeof (int) - 1;
    i >= 0; i--)
 ((int *)new_chunk->contents)[i]
   = ((int *)h->object_base)[i];



      already = obj_size / sizeof (int) * sizeof (int);
    }
  else
    already = 0;

  for (i = already; i < obj_size; i++)
    new_chunk->contents[i] = h->object_base[i];




  if (h->object_base == old_chunk->contents && ! h->maybe_empty_object)
    {
      new_chunk->prev = old_chunk->prev;
      do { if ((h) -> use_extra_arg) (*(h)->freefun) ((h)->extra_arg, (old_chunk)); else (*(h)->freefun) ((old_chunk)); } while (0);
    }

  h->object_base = new_chunk->contents;
  h->next_free = h->object_base + obj_size;

  h->maybe_empty_object = 0;
}
int _obstack_allocated_p (struct n64_tag_obstack *h, void * obj) asm("__obstack_allocated_p");


int
_obstack_allocated_p(struct n64_tag_obstack *h, void *obj) asm("__obstack_allocated_p");
int
_obstack_allocated_p(struct n64_tag_obstack *h, void *obj)
{
  register struct n64_tag__obstack_chunk* lp;
  register struct n64_tag__obstack_chunk* plp;

  lp = (h)->chunk;



  while (lp != 0 && ((void *)lp >= obj || (void *)(lp)->limit < obj))
    {
      plp = lp->prev;
      lp = plp;
    }
  return lp != 0;
}
void
_obstack_free(struct n64_tag_obstack *h, void *obj) asm("__obstack_free");
void
_obstack_free(struct n64_tag_obstack *h, void *obj)
{
  register struct n64_tag__obstack_chunk* lp;
  register struct n64_tag__obstack_chunk* plp;

  lp = h->chunk;



  while (lp != 0 && ((void *)lp >= obj || (void *)(lp)->limit < obj))
    {
      plp = lp->prev;
      do { if ((h) -> use_extra_arg) (*(h)->freefun) ((h)->extra_arg, (lp)); else (*(h)->freefun) ((lp)); } while (0);
      lp = plp;


      h->maybe_empty_object = 1;
    }
  if (lp)
    {
      h->object_base = h->next_free = (char *)(obj);
      h->chunk_limit = lp->limit;
      h->chunk = lp;
    }
  else if (obj != 0)

    abort ();
}



void
obstack_free(struct n64_tag_obstack *h, void *obj) asm("_obstack_free");
void
obstack_free(struct n64_tag_obstack *h, void *obj)
{
  register struct n64_tag__obstack_chunk* lp;
  register struct n64_tag__obstack_chunk* plp;

  lp = h->chunk;



  while (lp != 0 && ((void *)lp >= obj || (void *)(lp)->limit < obj))
    {
      plp = lp->prev;
      do { if ((h) -> use_extra_arg) (*(h)->freefun) ((h)->extra_arg, (lp)); else (*(h)->freefun) ((lp)); } while (0);
      lp = plp;


      h->maybe_empty_object = 1;
    }
  if (lp)
    {
      h->object_base = h->next_free = (char *)(obj);
      h->chunk_limit = lp->limit;
      h->chunk = lp;
    }
  else if (obj != 0)

    abort ();
}

