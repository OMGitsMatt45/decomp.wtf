// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/cvt.c
/* Language-level data type conversion for GNU C++.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Hacked by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int sorry(...) asm("_sorry");
extern int error(...) asm("_error");
extern int type_precision(...) asm("_type_precision");
extern int put_var_into_stack(...) asm("_put_var_into_stack");
extern int compiler_error(...) asm("_compiler_error");
extern int real_lvalue_p(...) asm("_real_lvalue_p");
extern int make_decl_rtl(...) asm("_make_decl_rtl");
extern int warning(...) asm("_warning");
extern int can_convert(...) asm("_can_convert");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
struct n64_tag_candidate;
struct n64_tag_harshness_code;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct n64_tag_candidate *ansi_c_bullshit;

extern int rank_for_overload (struct n64_tag_candidate *, struct n64_tag_candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct n64_tag_candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct n64_tag_candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct n64_tag_candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct n64_tag_candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct rtx_def *, struct rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
struct n64_tag_harshness_code
{

  unsigned short code;


  short distance;
  unsigned short int_penalty;
};

struct n64_tag_candidate
{
  struct n64_tag_harshness_code h;

  int h_len;

  tree function;
  tree basetypes;
  tree arg;





  struct n64_tag_harshness_code *harshness;

  union
    {
      tree field;

      int bad_arg;







    } u;
};
int rank_for_overload(...) asm("_rank_for_overload");



extern int n_vtables;
extern int n_vtable_entries;
extern int n_vtable_searches;
extern int n_vtable_elems;
extern int n_convert_harshness;
extern int n_compute_conversion_costs;
extern int n_build_method_call;
extern int n_inner_fields_searched;
extern tree convert_to_integer (tree, tree) asm("_convert_to_integer");
extern tree convert_to_pointer (tree, tree) asm("_convert_to_pointer");
extern tree convert_to_real (tree, tree) asm("_convert_to_real");
extern tree convert_to_complex (tree, tree) asm("_convert_to_complex");
static tree
build_thunk(tree offset, tree real_addr) asm("_build_thunk");
static tree
build_thunk(tree offset, tree real_addr)
{
  if (((n64_enum_tree_code) (real_addr)->common.code) != ADDR_EXPR
      || ((n64_enum_tree_code) (((real_addr)->exp.operands[0]))->common.code) != FUNCTION_DECL)
    {
      sorry ("MI pointer to member conversion too complex");
      return error_mark_node;
    }
  sorry ("MI pointer to member conversion too complex");
  return error_mark_node;
}




static tree
convert_fn_ptr(tree type, tree expr) asm("_convert_fn_ptr");
static tree
convert_fn_ptr(tree type, tree expr)
{
  if (flag_vtable_thunks)
    {
      tree intype = ((expr)->common.type);
      tree binfo = get_binfo (((((intype)->common.type))->type.maxval),
         ((((type)->common.type))->type.maxval), 1);
      if (binfo == error_mark_node)
 {
   error ("  in pointer to member conversion");
   return error_mark_node;
 }
      if (binfo == (tree) (char *)0)
 {

   error ("invalid pointer to member conversion");
   return error_mark_node;
 }

      if (((((binfo))->vec.a[1]) == integer_zero_node))
 return build1 (NOP_EXPR, type, expr);
      return build1 (NOP_EXPR, type, build_thunk ((((binfo))->vec.a[1]), expr));
    }
  else
    return build_ptrmemfunc (type, expr, 1);
}







static tree
cp_convert_to_pointer(tree type, tree expr) asm("_cp_convert_to_pointer");
static tree
cp_convert_to_pointer(tree type, tree expr)
{
  register tree intype = ((expr)->common.type);
  register n64_enum_tree_code form;

  if ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    type = (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
  if ((((n64_enum_tree_code) (intype)->common.code) == RECORD_TYPE && ((intype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    intype = (((((((((((((intype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

  form = ((n64_enum_tree_code) (intype)->common.code);

  if (form == POINTER_TYPE || form == REFERENCE_TYPE)
    {
      intype = ((intype)->type.main_variant);

      if (((type)->type.main_variant) != intype
   && ((n64_enum_tree_code) (((type)->common.type))->common.code) == RECORD_TYPE
   && ((n64_enum_tree_code) (((intype)->common.type))->common.code) == RECORD_TYPE)
 {
   n64_enum_tree_code code = PLUS_EXPR;
   tree binfo = get_binfo (((type)->common.type), ((intype)->common.type), 1);
   if (binfo == error_mark_node)
     return error_mark_node;
   if (binfo == (tree) (char *)0)
     {
       binfo = get_binfo (((intype)->common.type), ((type)->common.type), 1);
       if (binfo == error_mark_node)
  return error_mark_node;
       code = MINUS_EXPR;
     }
   if (binfo)
     {
       if ((((((type)->common.type))->common.lang_flag_3))
    || (((((intype)->common.type))->common.lang_flag_3))
    || ! ((((binfo))->vec.a[1]) == integer_zero_node))
  {

    tree path;

    if (code == PLUS_EXPR)
      get_base_distance (((type)->common.type), ((intype)->common.type), 0, &path);
    else
      get_base_distance (((intype)->common.type), ((type)->common.type), 0, &path);
    return build_vbase_path (code, type, expr, path, 0);
  }
     }
 }
      if (((n64_enum_tree_code) (((intype)->common.type))->common.code) == METHOD_TYPE
   && ((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (((type)->common.type))->common.code) == METHOD_TYPE)
 return convert_fn_ptr (type, expr);

      if (((n64_enum_tree_code) (((type)->common.type))->common.code) == OFFSET_TYPE
   && ((n64_enum_tree_code) (((intype)->common.type))->common.code) == OFFSET_TYPE)
 {
   tree b1 = ((((type)->common.type))->type.maxval);
   tree b2 = ((((intype)->common.type))->type.maxval);
   tree binfo = get_binfo (b1, b2, 1);
   if (binfo == (tree) (char *)0)
     binfo = get_binfo (b2, b1, 1);
   if (binfo == error_mark_node)
     return error_mark_node;
 }

      if (((n64_enum_tree_code) (((intype)->common.type))->common.code) == METHOD_TYPE
   || (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
       && ((n64_enum_tree_code) (((type)->common.type))->common.code) == METHOD_TYPE))
 {
   cp_error ("cannot convert `%E' from type `%T' to type `%T'",
      expr, intype, type);
   return error_mark_node;
 }

      return build1 (NOP_EXPR, type, expr);
    }

  my_friendly_assert (form != OFFSET_TYPE, 186);

  if (((intype)->type.lang_specific)
      && ((((intype)->type.lang_specific)->type_flags.is_signature_pointer) || (((intype)->type.lang_specific)->type_flags.is_signature_reference)))
    return convert_to_pointer (type, build_optr_ref (expr));

  if ((((intype)->type.lang_flag_5)))
    {
      tree rval;
      rval = build_type_conversion (CONVERT_EXPR, type, expr, 1);
      if (rval)
 {
   if (rval == error_mark_node)
     cp_error ("conversion of `%E' from `%T' to `%T' is ambiguous",
        expr, intype, type);
   return rval;
 }
    }

  if (integer_zerop (expr))
    {
      if (type == ((null_pointer_node)->common.type))
 return null_pointer_node;
      expr = build_int_2_wide ((int) (0), (int) (0));
      ((expr)->common.type) = type;
      return expr;
    }

  if ((form == INTEGER_TYPE || form == ENUMERAL_TYPE || form == BOOLEAN_TYPE))
    {
      if (type_precision (intype) == ((target_flags & 0x00000002) ? 64 : 32))
 return build1 (CONVERT_EXPR, type, expr);
      expr = convert (type_for_size (((target_flags & 0x00000002) ? 64 : 32), 0), expr);

      if ((mode_size[(int)(((((expr)->common.type))->type.mode))])
   != (mode_size[(int)(((type)->type.mode))]))


 abort ();
      return convert_to_pointer (type, expr);
    }

  cp_error ("cannot convert `%E' from type `%T' to type `%T'",
     expr, intype, type);
  return error_mark_node;
}




static tree
convert_to_pointer_force(tree type, tree expr) asm("_convert_to_pointer_force");
static tree
convert_to_pointer_force(tree type, tree expr)
{
  register tree intype = ((expr)->common.type);
  register n64_enum_tree_code form = ((n64_enum_tree_code) (intype)->common.code);

  if (integer_zerop (expr))
    {
      if (type == ((null_pointer_node)->common.type))
 return null_pointer_node;
      expr = build_int_2_wide ((int) (0), (int) (0));
      ((expr)->common.type) = type;
      return expr;
    }


  if (form == RECORD_TYPE
      && ((((intype)->type.lang_specific)->type_flags.is_signature_pointer) || (((intype)->type.lang_specific)->type_flags.is_signature_reference)))
    {
      expr = build_optr_ref (expr);
      intype = ((expr)->common.type);
      form = ((n64_enum_tree_code) (intype)->common.code);
    }

  if (form == POINTER_TYPE)
    {
      intype = ((intype)->type.main_variant);

      if (((type)->type.main_variant) != intype
   && ((n64_enum_tree_code) (((type)->common.type))->common.code) == RECORD_TYPE
   && ((n64_enum_tree_code) (((intype)->common.type))->common.code) == RECORD_TYPE)
 {
   n64_enum_tree_code code = PLUS_EXPR;
   tree path;
   int distance = get_base_distance (((type)->common.type),
         ((intype)->common.type), 0, &path);
   if (distance == -2)
     {
     ambig:
       cp_error ("type `%T' is ambiguous baseclass of `%s'", ((type)->common.type),
        ((((((((((intype)->common.type))->type.name))->decl.name)))->identifier.pointer)));
       return error_mark_node;
     }
   if (distance == -1)
     {
       distance = get_base_distance (((intype)->common.type),
         ((type)->common.type), 0, &path);
       if (distance == -2)
  goto ambig;
       if (distance < 0)

  return build1 (NOP_EXPR, type, expr);

       code = MINUS_EXPR;
     }
   return build_vbase_path (code, type, expr, path, 0);
 }
      return build1 (NOP_EXPR, type, expr);
    }

  return cp_convert_to_pointer (type, expr);
}







static tree
build_up_reference(tree type, tree arg, int flags, int checkconst) asm("_build_up_reference");
static tree
build_up_reference(tree type, tree arg, int flags, int checkconst)
{
  tree rval, targ;
  int literal_flag = 0;
  tree argtype = ((arg)->common.type);
  tree target_type = ((type)->common.type);
  tree binfo = (tree) (char *)0;

  my_friendly_assert (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE, 187);
  if ((flags & (1))
      && ((argtype)->type.main_variant) != ((target_type)->type.main_variant)
      && (((argtype)->type.lang_flag_5))
      && (((target_type)->type.lang_flag_5)))
    {
      binfo = get_binfo (target_type, argtype, 1);
      if (binfo == error_mark_node)
 return error_mark_node;
      if (binfo == (tree) (char *)0)
 return error_not_base_type (target_type, argtype);
    }


  if (((type)->common.readonly_flag) || ((type)->common.volatile_flag))
    target_type = cp_build_type_variant (target_type, ((type)->common.readonly_flag),
     ((type)->common.volatile_flag));
  targ = arg;
  if (((n64_enum_tree_code) (targ)->common.code) == SAVE_EXPR)
    targ = ((targ)->exp.operands[0]);
  while (((n64_enum_tree_code) (targ)->common.code) == NOP_EXPR
  && (((argtype)->type.main_variant)
      == ((((((targ)->exp.operands[0]))->common.type))->type.main_variant)))
    targ = ((targ)->exp.operands[0]);

  switch (((n64_enum_tree_code) (targ)->common.code))
    {
    case INDIRECT_REF:


      if ((((targ)->common.lang_flag_4)))
 {
   tree temp = build_cplus_new (argtype, ((targ)->exp.operands[0]), 1);
   (((targ)->common.lang_flag_4)) = 0;
   return build_up_reference (type, temp, flags, 1);
 }


      arg = ((targ)->exp.operands[0]);
      if (((n64_enum_tree_code) (arg)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg)->common.code) == NON_LVALUE_EXPR
   || (((n64_enum_tree_code) (arg)->common.code) == CONVERT_EXPR && (((arg)->common.lang_flag_3))))
 arg = ((arg)->exp.operands[0]);




      if (((arg)->common.readonly_flag))
 {
   arg = copy_node (arg);
   ((arg)->common.readonly_flag) = 0;
 }

      rval = build1 (CONVERT_EXPR, type, arg);
      (((rval)->common.lang_flag_3)) = 1;
      if (((targ)->common.readonly_flag) && !((arg)->common.readonly_flag)
   && (((n64_enum_tree_code) (arg)->common.code) == PARM_DECL || ((n64_enum_tree_code) (arg)->common.code) == VAR_DECL)
   && ((n64_enum_tree_code) (((arg)->common.type))->common.code) == REFERENCE_TYPE
   && (((target_type)->common.readonly_flag) && checkconst))
 {
   arg = copy_node (arg);
   ((arg)->common.readonly_flag) = ((targ)->common.readonly_flag);
 }
      literal_flag = ((arg)->common.constant_flag);

      goto done;




    case ARRAY_REF:
      if (mark_addressable (((targ)->exp.operands[0])) == 0)
 return error_mark_node;
      rval = build_binary_op (PLUS_EXPR, ((targ)->exp.operands[0]),
         ((targ)->exp.operands[1]), 1);
      ((rval)->common.type) = type;
      if (((((targ)->exp.operands[1]))->common.constant_flag)
   && staticp (((targ)->exp.operands[0])))
 ((rval)->common.constant_flag) = 1;
      goto done;

    case SCOPE_REF:

      {
 tree field = ((targ)->exp.operands[1]);
 if (((field)->common.static_flag))
   {
     rval = build1 (ADDR_EXPR, type, field);
     literal_flag = 1;
     goto done;
   }
      }


      my_friendly_abort (188);

    case COMPONENT_REF:
      rval = build_component_addr (targ, build_pointer_type (argtype),
       "attempt to make a reference to bit-field structure member `%s'");
      ((rval)->common.type) = type;
      literal_flag = staticp (((targ)->exp.operands[0]));

      goto done;







    case RESULT_DECL:
      if (staticp (targ))
 literal_flag = 1;
      ((targ)->common.addressable_flag) = 1;
      put_var_into_stack (targ);
      break;

    case PARM_DECL:
    case VAR_DECL:
    case CONST_DECL:
      if (((targ)->decl.regdecl_flag) && !((targ)->common.addressable_flag)
   && !((targ)->decl.artificial_flag))
 cp_warning ("address needed to build reference for `%D', which is declared `register'",
      targ);
      else if (staticp (targ))
 literal_flag = 1;

      ((targ)->common.addressable_flag) = 1;
      put_var_into_stack (targ);
      break;

    case COMPOUND_EXPR:
      {
 tree real_reference = build_up_reference (type, ((targ)->exp.operands[1]),
        (1), checkconst);
 rval = build (COMPOUND_EXPR, type, ((targ)->exp.operands[0]), real_reference);
 ((rval)->common.constant_flag) = staticp (((targ)->exp.operands[1]));
 return rval;
      }

    case PREINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case MODIFY_EXPR:
    case INIT_EXPR:
      {
 tree real_reference = build_up_reference (type, ((targ)->exp.operands[0]),
        (1), checkconst);
 rval = build (COMPOUND_EXPR, type, arg, real_reference);
 ((rval)->common.constant_flag) = staticp (((targ)->exp.operands[0]));
 return rval;
      }

    case COND_EXPR:
      return build (COND_EXPR, type,
      ((targ)->exp.operands[0]),
      build_up_reference (type, ((targ)->exp.operands[1]),
     (1), checkconst),
      build_up_reference (type, ((targ)->exp.operands[2]),
     (1), checkconst));


    case MIN_EXPR:
    case MAX_EXPR:
      return build (COND_EXPR, type,
      build (((n64_enum_tree_code) (targ)->common.code) == MIN_EXPR ? LT_EXPR : GT_EXPR,
      boolean_type_node, ((targ)->exp.operands[0]),
      ((targ)->exp.operands[1])),
      build_up_reference (type, ((targ)->exp.operands[0]),
     (1), checkconst),
      build_up_reference (type, ((targ)->exp.operands[1]),
     (1), checkconst));

    case WITH_CLEANUP_EXPR:
      return build (WITH_CLEANUP_EXPR, type,
      build_up_reference (type, ((targ)->exp.operands[0]),
     (1), checkconst),
      0, ((targ)->exp.operands[2]));

    case BIND_EXPR:
      arg = ((targ)->exp.operands[1]);
      if (arg == (tree) (char *)0)
 {
   compiler_error ("({ ... }) expression not expanded when needed for reference");
   return error_mark_node;
 }
      rval = build1 (ADDR_EXPR, type, arg);
      (((rval)->common.lang_flag_3)) = 1;
      return rval;

    default:
      break;
    }

  if (((targ)->common.addressable_flag) == 0)
    {
      tree temp;

      if (((n64_enum_tree_code) (targ)->common.code) == CALL_EXPR && (((argtype)->type.lang_flag_5)))
 {
   temp = build_cplus_new (argtype, targ, 1);
   if (((n64_enum_tree_code) (temp)->common.code) == WITH_CLEANUP_EXPR)
     rval = build (WITH_CLEANUP_EXPR, type,
     build1 (ADDR_EXPR, type, ((temp)->exp.operands[0])),
     0, ((temp)->exp.operands[2]));
   else
     rval = build1 (ADDR_EXPR, type, temp);
   goto done;
 }
      else
 {
   temp = get_temp_name (argtype, 0);
   if (toplevel_bindings_p ())
     {

       ((temp)->decl.initial) = targ;
       ((temp)->common.static_flag) = 1;
       cp_finish_decl (temp, targ, (tree) (char *)0, 0, (128));

       rval = build_unary_op (ADDR_EXPR, temp, 0);
       ((rval)->common.type) = type;
       literal_flag = ((rval)->common.constant_flag);
       goto done;
     }
   else
     {
       rval = build_unary_op (ADDR_EXPR, temp, 0);
       if (binfo && !((((binfo))->vec.a[1]) == integer_zero_node))
  rval = convert_pointer_to (target_type, rval);
       else
  ((rval)->common.type) = type;

       temp = build (MODIFY_EXPR, argtype, temp, arg);
       ((temp)->common.side_effects_flag) = 1;
       return build (COMPOUND_EXPR, type, temp, rval);
     }
 }
    }
  else
    rval = build1 (ADDR_EXPR, type, arg);

 done:
  if ((((argtype)->common.lang_flag_1))
      || (((target_type)->common.lang_flag_1)))
    {
      ((rval)->common.type) = build_pointer_type (argtype);
      if (flags & (1))
 rval = convert_pointer_to (target_type, rval);
      else
 rval
   = convert_to_pointer_force (build_pointer_type (target_type), rval);
      ((rval)->common.type) = type;
      if (((n64_enum_tree_code) (rval)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (rval)->common.code) == MINUS_EXPR)
 ((((rval)->exp.operands[0]))->common.type)
   = ((((rval)->exp.operands[1]))->common.type) = type;
    }
  ((rval)->common.constant_flag) = literal_flag;
  return rval;
}
tree
convert_to_reference(tree reftype, tree expr, int convtype, int flags, tree decl) asm("_convert_to_reference");
tree
convert_to_reference(tree reftype, tree expr, int convtype, int flags, tree decl)
{
  register tree type = ((((reftype)->common.type))->type.main_variant);
  register tree intype = ((expr)->common.type);
  tree rval = (tree) (char *)0;
  tree rval_as_conversion = (tree) (char *)0;
  int i;

  if (((n64_enum_tree_code) (intype)->common.code) == REFERENCE_TYPE)
    my_friendly_abort (364);

  intype = ((intype)->type.main_variant);

  i = comp_target_types (type, intype, 0);

  if (i <= 0 && (convtype & 1) && (((intype)->type.lang_flag_5))
      && ! (flags & (512)))
    {


      rval_as_conversion = build_type_conversion (CONVERT_EXPR, type, expr, 1);

      if (rval_as_conversion && rval_as_conversion != error_mark_node
   && real_lvalue_p (rval_as_conversion))
 {
   expr = rval_as_conversion;
   rval_as_conversion = (tree) (char *)0;
   intype = type;
   i = 1;
 }
    }

  if (((convtype & 2) && i == -1)
      || ((convtype & 1) && i == 1))
    {
      if (flags & (2))
 {
   tree ttl = ((reftype)->common.type);
   tree ttr;

   {
     int r = ((expr)->common.readonly_flag);
     int v = ((expr)->common.volatile_flag);
     ttr = cp_build_type_variant (((expr)->common.type), r, v);
   }

   if (! real_lvalue_p (expr) &&
       (decl == (tree) (char *)0 || ! ((ttl)->common.readonly_flag)))
     {
       if (decl)

  cp_pedwarn ("initialization of non-const `%T' from rvalue `%T'",
       reftype, intype);
       else
  cp_pedwarn ("conversion to `%T' from rvalue `%T'",
       reftype, intype);
     }
   else if (! (convtype & 4))
     {
       if (! ((ttl)->common.readonly_flag) && ((ttr)->common.readonly_flag))
  cp_pedwarn ("conversion from `%T' to `%T' discards const",
       ttr, reftype);
       else if (! ((ttl)->common.volatile_flag) && ((ttr)->common.volatile_flag))
  cp_pedwarn ("conversion from `%T' to `%T' discards volatile",
       ttr, reftype);
     }
 }

      return build_up_reference (reftype, expr, flags,
     ! (convtype & 4));
    }
  else if ((convtype & 8) && lvalue_p (expr))
    {







      if (((n64_enum_tree_code) (intype)->common.code) == POINTER_TYPE
   && (comptypes (((intype)->common.type), type, -1)))
 cp_warning ("casting `%T' to `%T' does not dereference pointer",
      intype, reftype);

      rval = build_unary_op (ADDR_EXPR, expr, 0);
      if (rval != error_mark_node)
 rval = convert_force (build_pointer_type (((reftype)->common.type)), rval, 0);
      if (rval != error_mark_node)
 rval = build1 (NOP_EXPR, reftype, rval);
    }
  else if (decl)
    {
      tree rval_as_ctor = (tree) (char *)0;

      if (rval_as_conversion)
 {
   if (rval_as_conversion == error_mark_node)
     {
       cp_error ("conversion from `%T' to `%T' is ambiguous",
   intype, reftype);
       return error_mark_node;
     }
   rval_as_conversion = build_up_reference (reftype, rval_as_conversion,
         flags, 1);
 }


      if ((((type)->type.lang_flag_1))
   && ! (((type)->type.lang_specific)->abstract_virtuals)
   && (rval = build_method_call
       ((tree) (char *)0, constructor_name_full (type),
        build_tree_list ((tree) (char *)0, expr), ((type)->type.binfo),
        (512)|(64)
        | (128))))
 {
   tree init;

   if (toplevel_bindings_p ())
     {
       extern tree static_aggregates;
       tree t = get_temp_name (type, toplevel_bindings_p ());
       init = build_method_call (t, constructor_name_full (type),
     build_tree_list ((tree) (char *)0, expr),
     ((type)->type.binfo),
     (3)|(512)
     | (128));

       if (init == error_mark_node)
  return error_mark_node;

       make_decl_rtl (t, ((void *)0), 1);
       static_aggregates = perm_tree_cons (expr, t, static_aggregates);
       rval = build_unary_op (ADDR_EXPR, t, 0);
     }
   else
     {
       init = build_method_call ((tree) (char *)0, constructor_name_full (type),
     build_tree_list ((tree) (char *)0, expr),
     ((type)->type.binfo),
     (3)|(512)
     |(128));

       if (init == error_mark_node)
  return error_mark_node;

       rval = build_cplus_new (type, init, 1);
       rval = build_up_reference (reftype, rval, flags, 1);
     }
   rval_as_ctor = rval;
 }

      if (rval_as_ctor && rval_as_conversion)
 {
   cp_error ("ambiguous conversion from `%T' to `%T'; both user-defined conversion and constructor apply",
      intype, reftype);
   return error_mark_node;
 }
      else if (rval_as_ctor)
 rval = rval_as_ctor;
      else if (rval_as_conversion)
 rval = rval_as_conversion;
      else if (! (((type)->type.lang_flag_5)) && ! (((intype)->type.lang_flag_5)))
 {
   rval = convert (type, expr);
   if (rval == error_mark_node)
     return error_mark_node;

   rval = build_up_reference (reftype, rval, flags, 1);
 }

      if (rval && ! ((((reftype)->common.type))->common.readonly_flag))
 cp_pedwarn ("initializing non-const `%T' with `%T' will use a temporary",
      reftype, intype);
    }

  if (rval)
    {

      return rval;
    }

  my_friendly_assert (((n64_enum_tree_code) (intype)->common.code) != OFFSET_TYPE, 189);

  if (flags & (2))
    cp_error ("cannot convert type `%T' to type `%T'", intype, reftype);

  if (flags & (64))
    return (tree) (char *)0;

  return error_mark_node;
}



tree
convert_from_reference(tree val) asm("_convert_from_reference");
tree
convert_from_reference(tree val)
{
  tree type = ((val)->common.type);

  if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
    type = ((type)->common.type);
  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    return build_indirect_ref (val, ((void *)0));
  return val;
}
tree
convert_to_aggr(tree type, tree expr, char **msgp, int protect) asm("_convert_to_aggr");
tree
convert_to_aggr(tree type, tree expr, char **msgp, int protect)
{
  tree basetype = type;
  tree name = (((((basetype)->type.name))->decl.name));
  tree function, fndecl, fntype, parmtypes, parmlist, result;
  tree method_name;
  n64_enum_access_type access;
  int can_be_private, can_be_protected;

  if (! (((basetype)->type.lang_flag_1)))
    {
      if (msgp)
 *msgp = "type `%s' does not have a constructor";
      return error_mark_node;
    }

  access = access_public;
  can_be_private = 0;
  can_be_protected = (((struct n64_tag_lang_identifier *)(name))->class_value) || name == current_class_name;

  parmlist = build_tree_list ((tree) (char *)0, expr);
  parmtypes = tree_cons ((tree) (char *)0, ((expr)->common.type), void_list_node);

  if ((((basetype)->common.lang_flag_3)))
    {
      parmtypes = tree_cons ((tree) (char *)0, integer_type_node, parmtypes);
      parmlist = tree_cons ((tree) (char *)0, integer_one_node, parmlist);
    }


  parmlist = tree_cons ((tree) (char *)0, integer_zero_node, parmlist);
  parmtypes = tree_cons ((tree) (char *)0, build_pointer_type (basetype), parmtypes);
  fndecl = ((((basetype)->type.maxval))->vec.a[0]);
  if ((((basetype)->type.lang_flag_2)))
    fndecl = (((fndecl)->decl.lang_specific)->chain);

  {
    int saw_private = 0;
    int saw_protected = 0;
    struct n64_tag_candidate *candidates =
      (struct n64_tag_candidate *) 
                          __builtin_alloca((
                          (decl_list_length (fndecl)+1) * sizeof (struct n64_tag_candidate)
                          ))
                                                                                            ;
    struct n64_tag_candidate *cp = candidates;

    while (fndecl)
      {
 function = fndecl;
 cp->h_len = 2;
 cp->harshness = (struct n64_tag_harshness_code *)
   
  __builtin_alloca((
  3 * sizeof (struct n64_tag_harshness_code)
  ))
                                             ;

 compute_conversion_costs (fndecl, parmlist, cp, 2);
 if ((cp->h.code & (1<<7)) == 0)
   {
     cp->u.field = fndecl;
     if (protect)
       {
  if (((fndecl)->common.private_flag))
    access = access_private;
  else if (((fndecl)->common.protected_flag))
    access = access_protected;
  else
    access = access_public;
       }
     else
       access = access_public;

     if (access == access_private
  ? (basetype == current_class_type
     || is_friend (basetype, cp->function)
     || purpose_member (basetype, (((fndecl)->decl.lang_specific)->decl_flags.access)))
  : access == access_protected
  ? (can_be_protected
     || purpose_member (basetype, (((fndecl)->decl.lang_specific)->decl_flags.access)))
  : 1)
       {
  if (cp->h.code <= (1<<0))
    goto found_and_ok;
  cp++;
       }
     else
       {
  if (access == access_private)
    saw_private = 1;
  else
    saw_protected = 1;
       }
   }
 fndecl = (((fndecl)->decl.lang_specific)->chain);
      }
    if (cp - candidates)
      {





 if (cp - candidates > 1)
   qsort (candidates,
   cp - candidates,
   sizeof (struct n64_tag_candidate),
   (int (*)(const void*, const void*))(int (*)(struct n64_tag_candidate*, struct n64_tag_candidate*))rank_for_overload);

 --cp;
 if (cp->h.code & (1<<7))
   {
     if (msgp)
       *msgp = "ambiguous type conversion possible for `%s'";
     return error_mark_node;
   }

 function = cp->function;
 fndecl = cp->u.field;
 goto found_and_ok;
      }
    else if (msgp)
      {
 if (saw_private)
   if (saw_protected)
     *msgp = "only private and protected conversions apply";
   else
     *msgp = "only private conversions apply";
 else if (saw_protected)
   *msgp = "only protected conversions apply";
 else
   *msgp = "no appropriate conversion to type `%s'";
      }
    return error_mark_node;
  }


 found:
  if (access == access_private)
    if (! can_be_private)
      {
 if (msgp)
   *msgp = ((fndecl)->common.private_flag)
     ? "conversion to type `%s' is private"
     : "conversion to type `%s' is from private base class";
 return error_mark_node;
      }
  if (access == access_protected)
    if (! can_be_protected)
      {
 if (msgp)
   *msgp = ((fndecl)->common.private_flag)
     ? "conversion to type `%s' is protected"
     : "conversion to type `%s' is from protected base class";
 return error_mark_node;
      }
  function = fndecl;
 found_and_ok:


  if (msgp == 0)
    return (tree) (char *)0;

  fntype = ((function)->common.type);
  function = default_conversion (function);

  result = build_nt (CALL_EXPR, function,
       convert_arguments ((tree) (char *)0, ((fntype)->type.values),
     parmlist, (tree) (char *)0, (3)),
       (tree) (char *)0);
  ((result)->common.type) = ((fntype)->common.type);
  ((result)->common.side_effects_flag) = 1;
  return result;
}







tree
convert_pointer_to_real(tree binfo, tree expr) asm("_convert_pointer_to_real");
tree
convert_pointer_to_real(tree binfo, tree expr)
{
  register tree intype = ((expr)->common.type);
  tree ptr_type;
  tree type, rval;

  if (((n64_enum_tree_code) (binfo)->common.code) == TREE_VEC)
    type = ((binfo)->common.type);
  else if ((((binfo)->type.lang_flag_5)))
    {
      type = binfo;
    }
  else
    {
      type = binfo;
      binfo = (tree) (char *)0;
    }

  ptr_type = build_pointer_type (type);
  if (ptr_type == ((intype)->type.main_variant))
    return expr;

  if (intype == error_mark_node)
    return error_mark_node;

  my_friendly_assert (!integer_zerop (expr), 191);

  if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
      && ((n64_enum_tree_code) (((intype)->common.type))->common.code) == RECORD_TYPE
      && type != ((((intype)->common.type))->type.main_variant))
    {
      tree path;
      int distance
 = get_base_distance (binfo, ((((intype)->common.type))->type.main_variant),
        0, &path);



      if (distance < 0)
 {
   cp_error ("cannot convert a pointer of type `%T' to a pointer of type `%T'",
      ((intype)->common.type), type);

   if (distance == -2)
     cp_error ("because `%T' is an ambiguous base class", type);
   return error_mark_node;
 }

      return build_vbase_path (PLUS_EXPR, ptr_type, expr, path, 1);
    }
  rval = build1 (NOP_EXPR, ptr_type,
   ((n64_enum_tree_code) (expr)->common.code) == NOP_EXPR ? ((expr)->exp.operands[0]) : expr);
  ((rval)->common.constant_flag) = ((expr)->common.constant_flag);
  return rval;
}







tree
convert_pointer_to(tree binfo, tree expr) asm("_convert_pointer_to");
tree
convert_pointer_to(tree binfo, tree expr)
{
  tree type;

  if (((n64_enum_tree_code) (binfo)->common.code) == TREE_VEC)
    type = ((binfo)->common.type);
  else if ((((binfo)->type.lang_flag_5)))
      type = binfo;
  else
      type = binfo;
  return convert_pointer_to_real (type, expr);
}





tree
cp_convert(tree type, tree expr, int convtype, int flags) asm("_cp_convert");
tree
cp_convert(tree type, tree expr, int convtype, int flags)
{
  register tree e = expr;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);

  if (((n64_enum_tree_code) (e)->common.code) == ERROR_MARK
      || ((n64_enum_tree_code) (((e)->common.type))->common.code) == ERROR_MARK)
    return error_mark_node;

  if ((((type)->type.lang_flag_5)) && (convtype & 64))
                                                             ;
  else if (((type)->type.main_variant) == ((((e)->common.type))->type.main_variant))

    return fold (build1 (NOP_EXPR, type, e));

  if (code == VOID_TYPE && (convtype & 2))
    return build1 (CONVERT_EXPR, type, e);
  if (code == OFFSET_TYPE)
    {
      type = ((type)->common.type);
      code = ((n64_enum_tree_code) (type)->common.code);
    }
  if (((n64_enum_tree_code) (e)->common.code) == CP_OFFSET_REF)
    e = resolve_offset_ref (e);

  if ((((e)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (e)->common.code))]) == 'd'))
    e = decl_constant_value (e);

  if ((code == INTEGER_TYPE || code == ENUMERAL_TYPE || code == BOOLEAN_TYPE))
    {
      tree intype = ((e)->common.type);
      n64_enum_tree_code form = ((n64_enum_tree_code) (intype)->common.code);

      if (flag_int_enum_equivalence == 0
   && ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
   && ((((n64_enum_tree_code) (intype)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (intype)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (intype)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (intype)->common.code) == CHAR_TYPE) || (((n64_enum_tree_code) (intype)->common.code) == REAL_TYPE || (((n64_enum_tree_code) (intype)->common.code) == COMPLEX_TYPE && ((n64_enum_tree_code) (((intype)->common.type))->common.code) == REAL_TYPE)))
   && ! (convtype & 2))
 {
   cp_pedwarn ("conversion from `%#T' to `%#T'", intype, type);

   if (flag_pedantic_errors)
     return error_mark_node;
 }
      if ((((intype)->type.lang_flag_5)))
 {
   tree rval;
   rval = build_type_conversion (CONVERT_EXPR, type, e, 1);
   if (rval)
     return rval;
   if (flags & (2))
     cp_error ("`%#T' used where a `%T' was expected", intype, type);
   if (flags & (64))
     return (tree) (char *)0;
   return error_mark_node;
 }
      if (code == BOOLEAN_TYPE)
 return truthvalue_conversion (e);
      return fold (convert_to_integer (type, e));
    }
  if (code == POINTER_TYPE || code == REFERENCE_TYPE
      || (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    return fold (cp_convert_to_pointer (type, e));
  if (code == REAL_TYPE)
    {
      if ((((((e)->common.type))->type.lang_flag_5)))
 {
   tree rval;
   rval = build_type_conversion (CONVERT_EXPR, type, e, 1);
   if (rval)
     return rval;
   else
     if (flags & (2))
       cp_error ("`%#T' used where a floating point value was expected",
   ((e)->common.type));
 }
      return fold (convert_to_real (type, e));
    }




  if ((code == RECORD_TYPE || code == UNION_TYPE || code == UNINSTANTIATED_P_TYPE))
    {
      tree dtype = ((e)->common.type);
      tree ctor = (tree) (char *)0;
      tree conversion = (tree) (char *)0;

      dtype = ((dtype)->type.main_variant);




      if (((type)->type.lang_specific)
   && ((((type)->type.lang_specific)->type_flags.is_signature_pointer) || (((type)->type.lang_specific)->type_flags.is_signature_reference)))
 {
   tree constructor = build_signature_pointer_constructor (type, expr);
   tree sig_ty = (((type)->type.lang_specific)->signature);
   tree sig_ptr;

   if (constructor == error_mark_node)
     return error_mark_node;

   sig_ptr = get_temp_name (type, 1);
   ((sig_ptr)->decl.initial) = constructor;
   (((sig_ty)->type.lang_specific)->type_flags.is_signature=0);
   cp_finish_decl (sig_ptr, constructor, (tree) (char *)0, 0, 0);
   (((sig_ty)->type.lang_specific)->type_flags.is_signature=1);
   ((sig_ptr)->common.readonly_flag) = 1;

   return sig_ptr;
 }
      if ((((dtype)->type.lang_flag_5)) && ! (get_base_distance (type, dtype, 0, (tree *)0) != -1)
   && (((dtype)->type.lang_specific)->type_flags.has_type_conversion))
 conversion = build_type_conversion (CONVERT_EXPR, type, e, 1);

      if (conversion == error_mark_node)
 {
   if (flags & (2))
     error ("ambiguous pointer conversion");
   return conversion;
 }

      if ((((type)->type.lang_flag_1)))
 ctor = build_method_call ((tree) (char *)0, constructor_name_full (type),
      build_tree_list ((tree) (char *)0, e),
      ((type)->type.binfo),
      (flags & (3)) | (64)
      | (convtype&32 ? 0 : (128))
      | (conversion ? (512) : 0));

      if (ctor == error_mark_node)
 {
   if (flags & (2))
     cp_error ("in conversion to type `%T'", type);
   if (flags & (64))
     return (tree) (char *)0;
   return error_mark_node;
 }

      if (conversion && ctor)
 {
   if (flags & (2))
     error ("both constructor and type conversion operator apply");
   if (flags & (64))
     return (tree) (char *)0;
   return error_mark_node;
 }
      else if (conversion)
 return conversion;
      else if (ctor)
 {
   ctor = build_cplus_new (type, ctor, 0);
   return ctor;
 }
    }




  if (code == ARRAY_TYPE
      && ((((e)->common.type))->common.type) == ((type)->common.type)
      && index_type_equal (((((e)->common.type))->type.values), ((type)->type.values)))
    return e;

  if (flags & (2))
    cp_error ("conversion from `%T' to non-scalar type `%T' requested",
       ((expr)->common.type), type);
  if (flags & (64))
    return (tree) (char *)0;
  return error_mark_node;
}







tree
convert(tree type, tree expr) asm("_convert");
tree
convert(tree type, tree expr)
{
  return cp_convert (type, expr, (1 | 2 | 4 | 8), (3));
}




tree
convert_force(tree type, tree expr, int convtype) asm("_convert_force");
tree
convert_force(tree type, tree expr, int convtype)
{
  register tree e = expr;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);

  if (code == REFERENCE_TYPE)
    return fold (convert_to_reference (type, e, (1 | 2 | 4 | 8 | 16 | 64), (2),
           (tree) (char *)0));
  else if (((n64_enum_tree_code) (((e)->common.type))->common.code) == REFERENCE_TYPE)
    e = convert_from_reference (e);

  if (code == POINTER_TYPE)
    return fold (convert_to_pointer_force (type, e));


  if (((((n64_enum_tree_code) (((e)->common.type))->common.code) == POINTER_TYPE && ((n64_enum_tree_code) (e)->common.code) == ADDR_EXPR
 && ((n64_enum_tree_code) (((e)->common.type))->common.code) == POINTER_TYPE
 && ((n64_enum_tree_code) (((((e)->common.type))->common.type))->common.code) == METHOD_TYPE)
       || integer_zerop (e)
       || (((n64_enum_tree_code) (((e)->common.type))->common.code) == RECORD_TYPE && ((((e)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
      && (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {

      return build_ptrmemfunc ((((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)), e, 1);
    }

  return cp_convert (type, e, (1 | 2 | 4 | 8 | 16 | 64)|convtype, (3));
}


static tree
build_type_conversion_1(tree xtype, tree basetype, tree expr, tree cxx_typename, int for_sure) asm("_build_type_conversion_1");
static tree
build_type_conversion_1(tree xtype, tree basetype, tree expr, tree cxx_typename, int for_sure)
{
  tree rval;
  int flags;

  if (for_sure == 0)
    flags = (1)|(128);
  else
    flags = (3)|(128);

  rval = build_method_call (expr, cxx_typename, (tree) (char *)0, (tree) (char *)0, flags);
  if (rval == error_mark_node)
    {
      if (for_sure == 0)
 return (tree) (char *)0;
      return error_mark_node;
    }

  if ((((((rval)->common.type))->type.lang_flag_5)))
    return rval;

  if (warn_cast_qual
      && ((xtype)->common.type)
      && (((((((rval)->common.type))->common.type))->common.readonly_flag)
   > ((((xtype)->common.type))->common.readonly_flag)))
    warning ("user-defined conversion casting away `const'");
  return convert (xtype, rval);
}
tree
build_type_conversion(n64_enum_tree_code code, tree xtype, tree expr, int for_sure) asm("_build_type_conversion");
tree
build_type_conversion(n64_enum_tree_code code, tree xtype, tree expr, int for_sure)
{


  tree basetype;
  tree conv;
  tree winner = (tree) (char *)0;

  if (expr == error_mark_node)
    return error_mark_node;

  basetype = ((expr)->common.type);
  if (((n64_enum_tree_code) (basetype)->common.code) == REFERENCE_TYPE)
    basetype = ((basetype)->common.type);

  basetype = ((basetype)->type.main_variant);
  if (! ((basetype)->type.lang_specific) || ! (((basetype)->type.lang_specific)->type_flags.has_type_conversion))
    return (tree) (char *)0;


  {
    tree cxx_typename = build_typename_overload (xtype);
    if (lookup_fnfields (((basetype)->type.binfo), cxx_typename, 0))
      return build_type_conversion_1 (xtype, basetype, expr, cxx_typename,
          for_sure);
  }


  for (conv = lookup_conversions (basetype); conv; conv = ((conv)->common.chain))
    {
      if (winner && ((winner)->list.purpose) == ((conv)->list.purpose))
 continue;

      if (can_convert (xtype, ((conv)->list.value)))
 {
   if (winner)
     {
       if (for_sure)
  {
    cp_error ("ambiguous conversion from `%T' to `%T'", basetype,
       xtype);
    cp_error ("  candidate conversions include `%T' and `%T'",
       ((winner)->list.value), ((conv)->list.value));
  }
       return (tree) (char *)0;
     }
   else
     winner = conv;
 }
    }

  if (winner)
    return build_type_conversion_1 (xtype, basetype, expr,
        ((winner)->list.purpose), for_sure);

  return (tree) (char *)0;
}






tree
build_expr_type_conversion(int desires, tree expr, int complain) asm("_build_expr_type_conversion");
tree
build_expr_type_conversion(int desires, tree expr, int complain)
{
  tree basetype = ((expr)->common.type);
  tree conv;
  tree winner = (tree) (char *)0;

  if (((n64_enum_tree_code) (basetype)->common.code) == OFFSET_TYPE)
    expr = resolve_offset_ref (expr);
  expr = convert_from_reference (expr);
  basetype = ((expr)->common.type);

  if (! (((basetype)->type.lang_flag_5)))
    switch (((n64_enum_tree_code) (basetype)->common.code))
      {
      case INTEGER_TYPE:
 if ((desires & 16) && ((n64_enum_tree_code) (expr)->common.code) == INTEGER_CST
     && integer_zerop (expr))
   return expr;


      case BOOLEAN_TYPE:
 return (desires & 1) ? expr : (tree) (char *)0;
      case ENUMERAL_TYPE:
 return (desires & 4) ? expr : (tree) (char *)0;
      case REAL_TYPE:
 return (desires & 2) ? expr : (tree) (char *)0;
      case POINTER_TYPE:
 return (desires & 8) ? expr : (tree) (char *)0;

      case FUNCTION_TYPE:
      case ARRAY_TYPE:
 return (desires & 8) ? default_conversion (expr)
                                      : (tree) (char *)0;
      default:
 return (tree) (char *)0;
      }

  if (! (((basetype)->type.lang_specific)->type_flags.has_type_conversion))
    return (tree) (char *)0;

  for (conv = lookup_conversions (basetype); conv; conv = ((conv)->common.chain))
    {
      int win = 0;
      tree candidate;

      if (winner && ((winner)->list.purpose) == ((conv)->list.purpose))
 continue;

      candidate = ((conv)->list.value);
      if (((n64_enum_tree_code) (candidate)->common.code) == REFERENCE_TYPE)
 candidate = ((candidate)->common.type);

      switch (((n64_enum_tree_code) (candidate)->common.code))
 {
 case BOOLEAN_TYPE:
 case INTEGER_TYPE:
   win = (desires & 1); break;
 case ENUMERAL_TYPE:
   win = (desires & 4); break;
 case REAL_TYPE:
   win = (desires & 2); break;
 case POINTER_TYPE:
   win = (desires & 8); break;
 }

      if (win)
 {
   if (winner)
     {
       if (complain)
  {
    cp_error ("ambiguous default type conversion from `%T'",
       basetype);
    cp_error ("  candidate conversions include `%T' and `%T'",
       ((winner)->list.value), ((conv)->list.value));
  }
       return error_mark_node;
     }
   else
     winner = conv;
 }
    }

  if (winner)
    return build_type_conversion_1 (((winner)->list.value), basetype, expr,
        ((winner)->list.purpose), 1);

  return (tree) (char *)0;
}







int
build_default_binary_type_conversion(n64_enum_tree_code code, tree *arg1, tree *arg2) asm("_build_default_binary_type_conversion");
int
build_default_binary_type_conversion(n64_enum_tree_code code, tree *arg1, tree *arg2)
{
  switch (code)
    {
    case MULT_EXPR:
    case TRUNC_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case EXACT_DIV_EXPR:
      *arg1 = build_expr_type_conversion ((1 | 2) | 4, *arg1, 0);
      *arg2 = build_expr_type_conversion ((1 | 2) | 4, *arg2, 0);
      break;

    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
    case LSHIFT_EXPR:
    case RSHIFT_EXPR:
    case BIT_AND_EXPR:
    case BIT_XOR_EXPR:
    case BIT_IOR_EXPR:
      *arg1 = build_expr_type_conversion (1 | 4, *arg1, 0);
      *arg2 = build_expr_type_conversion (1 | 4, *arg2, 0);
      break;

    case PLUS_EXPR:
      {
 tree a1, a2, p1, p2;
 int wins;

 a1 = build_expr_type_conversion ((1 | 2) | 4, *arg1, 0);
 a2 = build_expr_type_conversion ((1 | 2) | 4, *arg2, 0);
 p1 = build_expr_type_conversion (8, *arg1, 0);
 p2 = build_expr_type_conversion (8, *arg2, 0);

 wins = (a1 && a2) + (a1 && p2) + (p1 && a2);

 if (wins > 1)
   error ("ambiguous default type conversion for `operator +'");

 if (a1 && a2)
   *arg1 = a1, *arg2 = a2;
 else if (a1 && p2)
   *arg1 = a1, *arg2 = p2;
 else
   *arg1 = p1, *arg2 = a2;
 break;
      }

    case MINUS_EXPR:
      {
 tree a1, a2, p1, p2;
 int wins;

 a1 = build_expr_type_conversion ((1 | 2) | 4, *arg1, 0);
 a2 = build_expr_type_conversion ((1 | 2) | 4, *arg2, 0);
 p1 = build_expr_type_conversion (8, *arg1, 0);
 p2 = build_expr_type_conversion (8, *arg2, 0);

 wins = (a1 && a2) + (p1 && p2) + (p1 && a2);

 if (wins > 1)
   error ("ambiguous default type conversion for `operator -'");

 if (a1 && a2)
   *arg1 = a1, *arg2 = a2;
 else if (p1 && p2)
   *arg1 = p1, *arg2 = p2;
 else
   *arg1 = p1, *arg2 = a2;
 break;
      }

    case GT_EXPR:
    case LT_EXPR:
    case GE_EXPR:
    case LE_EXPR:
    case EQ_EXPR:
    case NE_EXPR:
      {
 tree a1, a2, p1, p2;
 int wins;

 a1 = build_expr_type_conversion ((1 | 2) | 4, *arg1, 0);
 a2 = build_expr_type_conversion ((1 | 2) | 4, *arg2, 0);
 p1 = build_expr_type_conversion (8 | 16, *arg1, 0);
 p2 = build_expr_type_conversion (8 | 16, *arg2, 0);

 wins = (a1 && a2) + (p1 && p2);

 if (wins > 1)
   cp_error ("ambiguous default type conversion for `%O'", code);

 if (a1 && a2)
   *arg1 = a1, *arg2 = a2;
 else
   *arg1 = p1, *arg2 = p2;
 break;
      }

    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
      *arg1 = convert (boolean_type_node, *arg1);
      *arg2 = convert (boolean_type_node, *arg2);
      break;

    default:
      *arg1 = (tree) (char *)0;
      *arg2 = (tree) (char *)0;
    }

  if (*arg1 == error_mark_node || *arg2 == error_mark_node)
    cp_error ("ambiguous default type conversion for `%O'", code);

  if (*arg1 && *arg2)
    return 1;

  return 0;
}


tree
type_promotes_to(tree type) asm("_type_promotes_to");
tree
type_promotes_to(tree type)
{
  int constp, volatilep;

  if (type == error_mark_node)
    return error_mark_node;

  constp = ((type)->common.readonly_flag);
  volatilep = ((type)->common.volatile_flag);
  type = ((type)->type.main_variant);



  if (type == boolean_type_node)
    type = integer_type_node;



  else if (((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
    || type == wchar_type_node)
    {
      int precision = ((((type)->type.precision)) > (((integer_type_node)->type.precision)) ? (((type)->type.precision)) : (((integer_type_node)->type.precision)))
                                         ;
      tree totype = type_for_size (precision, 0);
      if (((type)->common.unsigned_flag)
   && ! int_fits_type_p (((type)->type.maxval), totype))
 type = type_for_size (precision, 1);
      else
 type = totype;
    }
  else if ((((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
    {


      if (((type)->common.unsigned_flag)
   && (flag_traditional
       || ((type)->type.precision) == ((integer_type_node)->type.precision)))
 type = unsigned_type_node;
      else
 type = integer_type_node;
    }
  else if (type == float_type_node)
    type = double_type_node;

  return cp_build_type_variant (type, constp, volatilep);
}

