// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/random.c
/*
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Berkeley.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);

long int random (void) asm("_random");
static int degrees[5] = { 0, 7, 15, 31, 63 };
static int seps[5] = { 0, 3, 1, 3, 1 };
static long int randtbl[31 + 1] =
  { 3,
      0x9a319039, 0x32d9c024, 0x9b663182, 0x5da1f342,
      0xde3b81e0, 0xdf0a6fb5, 0xf103bc02, 0x48f340fb,
      0x7449e56b, 0xbeb1dbb0, 0xab5c5918, 0x946554fd,
      0x8c2e680f, 0xeb3d799f, 0xb11ee0b7, 0x2d436b86,
      0xda672e2a, 0x1588ca88, 0xe369735d, 0x904f35f7,
      0xd7158fd6, 0x6fa6f051, 0x616e6b96, 0xac94efdc,
      0x36413f93, 0xc622c298, 0xf5a42ab8, 0x8a88d77b,
      0xf5ad9d0e, 0x8999220b, 0x27fb47b9
    };
static long int *fptr = &randtbl[3 + 1];
static long int *rptr = &randtbl[1];
static long int *state = &randtbl[1];

static int rand_type = 3;
static int rand_deg = 31;
static int rand_sep = 3;

static long int *end_ptr = &randtbl[sizeof(randtbl) / sizeof(randtbl[0])];
void
srandom(unsigned int x) asm("_srandom");
void
srandom(unsigned int x)
{
  state[0] = x;
  if (rand_type != 0)
    {
      register long int i;
      for (i = 1; i < rand_deg; ++i)
 state[i] = (1103515145 * state[i - 1]) + 12345;
      fptr = &state[rand_sep];
      rptr = &state[0];
      for (i = 0; i < 10 * rand_deg; ++i)
 random();
    }
}
void *
initstate(unsigned int seed, void *arg_state, long unsigned int n) asm("_initstate");
void *
initstate(unsigned int seed, void *arg_state, long unsigned int n)
{
  void * ostate = (void *) &state[-1];

  if (rand_type == 0)
    state[-1] = rand_type;
  else
    state[-1] = (5 * (rptr - state)) + rand_type;
  if (n < 32)
    {
      if (n < 8)
 {
   
  (*_errno()) 
        = 
          22
                ;
   return (void *) 0;
 }
      rand_type = 0;
      rand_deg = 0;
      rand_sep = 0;
    }
  else if (n < 64)
    {
      rand_type = 1;
      rand_deg = 7;
      rand_sep = 3;
    }
  else if (n < 128)
    {
      rand_type = 2;
      rand_deg = 15;
      rand_sep = 1;
    }
  else if (n < 256)
    {
      rand_type = 3;
      rand_deg = 31;
      rand_sep = 3;
    }
  else
    {
      rand_type = 4;
      rand_deg = 63;
      rand_sep = 1;
    }

  state = &((long int *) arg_state)[1];

  end_ptr = &state[rand_deg];
  srandom(seed);
  if (rand_type == 0)
    state[-1] = rand_type;
  else
    state[-1] = (5 * (rptr - state)) + rand_type;

  return ostate;
}
void *
setstate(void *arg_state) asm("_setstate");
void *
setstate(void *arg_state)
{
  register long int *new_state = (long int *) arg_state;
  register int type = new_state[0] % 5;
  register int rear = new_state[0] / 5;
  void * ostate = (void *) &state[-1];

  if (rand_type == 0)
    state[-1] = rand_type;
  else
    state[-1] = (5 * (rptr - state)) + rand_type;

  switch (type)
    {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
      rand_type = type;
      rand_deg = degrees[type];
      rand_sep = seps[type];
      break;
    default:

      
     (*_errno()) 
           = 
             22
                   ;
      return (void *) 0;
    }

  state = &new_state[1];
  if (rand_type != 0)
    {
      rptr = &state[rear];
      fptr = &state[(rear + rand_sep) % rand_deg];
    }

  end_ptr = &state[rand_deg];

  return ostate;
}
long int
random(void) asm("_random");
long int
random(void)
{
  if (rand_type == 0)
    {
      state[0] = ((state[0] * 1103515245) + 12345) & ((long)(((unsigned long)(~0L)) >> 1));
      return state[0];
    }
  else
    {
      long int i;
      *fptr += *rptr;

      i = (*fptr >> 1) & ((long)(((unsigned long)(~0L)) >> 1));
      ++fptr;
      if (fptr >= end_ptr)
 {
   fptr = state;
   ++rptr;
 }
      else
 {
   ++rptr;
   if (rptr >= end_ptr)
     rptr = state;
 }
      return i;
    }
}

