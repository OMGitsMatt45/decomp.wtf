// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/class.c
/* Functions related to building classes and their related objects.
   Copyright (C) 1987, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int sorry(...) asm("_sorry");
extern int import_export_vtable(...) asm("_import_export_vtable");
extern int push_obstacks(...) asm("_push_obstacks");
extern int error(...) asm("_error");
extern int copy_assignment_arg_p(...) asm("_copy_assignment_arg_p");
extern int pedwarn(...) asm("_pedwarn");
extern int min_precision(...) asm("_min_precision");
extern int signature_error(...) asm("_signature_error");
extern int chain_member(...) asm("_chain_member");
extern int cadillac_finish_struct(...) asm("_cadillac_finish_struct");
extern int append_signature_fields(...) asm("_append_signature_fields");
extern int id_in_current_class(...) asm("_id_in_current_class");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int cadillac_push_class(...) asm("_cadillac_push_class");
extern int cadillac_pop_class(...) asm("_cadillac_pop_class");
extern int cadillac_push_lang(...) asm("_cadillac_push_lang");
extern int cadillac_pop_lang(...) asm("_cadillac_pop_lang");
struct n64_tag__obstack_chunk;
struct n64_tag_base_info;
struct n64_tag_class_level;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");

struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");



extern struct n64_tag_obstack permanent_obstack;





extern void set_class_shadows (tree) asm("_set_class_shadows");


static tree *current_class_base, *current_class_stack;
static int current_class_stacksize;
int current_class_depth;

struct n64_tag_class_level
{

  struct n64_tag_class_level *level_chain;


  tree decl;

  tree object;


  tree vtable_decl;


  tree name;

  tree type;


  int this_is_variable;
  int memoized_lookups;
  int save_memoized;
  int unused;
};

tree current_class_decl, C_C_D;


tree current_class_name;
tree current_class_type;
tree previous_class_type;
tree previous_class_values;

static tree get_vfield_name (tree) asm("_get_vfield_name");
tree the_null_vtable_entry;


tree *current_lang_base, *current_lang_stack;
int current_lang_stacksize;


tree lang_name_c, lang_name_cplusplus;
tree current_lang_name;

char *dont_allow_type_definitions;




static tree base_layout_decl;



int n_vtables = 0;
int n_vtable_entries = 0;
int n_vtable_searches = 0;
int n_vtable_elems = 0;
int n_convert_harshness = 0;
int n_compute_conversion_costs = 0;
int n_build_method_call = 0;
int n_inner_fields_searched = 0;


tree
build_vbase_pointer(tree exp, tree type) asm("_build_vbase_pointer");
tree
build_vbase_pointer(tree exp, tree type)
{
  char *name;

  name = (char *) 
                 __builtin_alloca((
                 ((((((((type)->type.name))->decl.name)))->identifier.length)) + sizeof ("_vb.") + 1
                 ))
                                                                           ;
  sprintf (name, "_vb.%s", ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
  return build_component_ref (exp, get_identifier (name), 0, 0);
}



int
complete_type_p(tree expr) asm("_complete_type_p");
int
complete_type_p(tree expr)
{
  tree type = ((((expr)->common.type))->type.main_variant);
  while (1)
    {
      switch (((n64_enum_tree_code) (expr)->common.code))
 {
 case SAVE_EXPR:
 case INDIRECT_REF:
 case ADDR_EXPR:
 case NOP_EXPR:
 case CONVERT_EXPR:
   expr = ((expr)->exp.operands[0]);
   continue;

 case CALL_EXPR:
   if (! (((expr)->common.lang_flag_4)))
     break;

 case VAR_DECL:
 case FIELD_DECL:
   if (((n64_enum_tree_code) (((expr)->common.type))->common.code) == ARRAY_TYPE
       && (((((((expr)->common.type))->common.type))->type.lang_flag_5))
       && ((((expr)->common.type))->type.main_variant) == type)
     return 1;

 case TARGET_EXPR:
 case PARM_DECL:
   if ((((((expr)->common.type))->type.lang_flag_5))
       && ((((expr)->common.type))->type.main_variant) == type)
     return 1;

 case PLUS_EXPR:
 default:
   break;
 }
      break;
    }
  return 0;
}
tree
build_vbase_path(n64_enum_tree_code code, tree type, tree expr, tree path, int alias_this) asm("_build_vbase_path");
tree
build_vbase_path(n64_enum_tree_code code, tree type, tree expr, tree path, int alias_this)
{
  register int changed = 0;
  tree last = (tree) 
             ((void *)0)
                      , last_virtual = (tree) 
                                       ((void *)0)
                                                ;
  int nonnull = 0;
  int fixed_type_p = resolves_to_fixed_type_p (expr, &nonnull);
  tree null_expr = 0, nonnull_expr;
  tree basetype;
  tree offset = integer_zero_node;

  if (nonnull == 0 && (alias_this && flag_this_is_variable <= 0))
    nonnull = 1;







  fixed_type_p = complete_type_p (expr);

  if (!fixed_type_p && ((expr)->common.side_effects_flag))
    expr = save_expr (expr);
  nonnull_expr = expr;

  if ((((path))->vec.a[0]))
    {
      tree reverse_path = (tree) 
                         ((void *)0)
                                  ;

      while (path)
 {
   tree r = copy_node (path);
   (((r))->vec.a[0]) = reverse_path;
   reverse_path = r;
   path = (((path))->vec.a[0]);
 }
      path = reverse_path;
    }

  basetype = ((path)->common.type);

  while (path)
    {
      if (((path)->common.static_flag))
 {
   last_virtual = ((path)->common.type);
   if (code == PLUS_EXPR)
     {
       changed = ! fixed_type_p;

       if (changed)
  {
    extern int flag_assume_nonnull_objects;
    tree ind;



    if (last)
      {
        tree binfo = get_binfo (last, ((((((nonnull_expr)->common.type))->common.type))->type.main_variant), 0);
        nonnull_expr = convert_pointer_to_real (binfo, nonnull_expr);
      }
    ind = build_indirect_ref (nonnull_expr, ((void *)0));
    nonnull_expr = build_vbase_pointer (ind, last_virtual);
    if (nonnull == 0
        && (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
     || !flag_assume_nonnull_objects)
        && null_expr == (tree) 
                       ((void *)0)
                                )
      {
        null_expr = build1 (NOP_EXPR, build_pointer_type (last_virtual), integer_zero_node);
        expr = build (COND_EXPR, build_pointer_type (last_virtual),
        build (EQ_EXPR, boolean_type_node, expr,
        integer_zero_node),
        null_expr, nonnull_expr);
      }
  }



       if (nonnull_expr == error_mark_node)
  return error_mark_node;
     }
   else
     {
       cp_error ("cannot cast up from virtual baseclass `%T'",
     last_virtual);
       return error_mark_node;
     }
 }
      last = path;
      path = (((path))->vec.a[0]);
    }





  if (null_expr)
    {
      ((expr)->exp.operands[2]) = nonnull_expr;
      ((((expr)->exp.operands[1]))->common.type) = ((nonnull_expr)->common.type);
    }
  else
    expr = nonnull_expr;




  if (changed)
    {
      tree intype = ((((expr)->common.type))->common.type);
      if (((intype)->type.main_variant) != ((last)->common.type))
 {
   tree binfo = get_binfo (last, ((intype)->type.main_variant), 0);
   offset = (((binfo))->vec.a[1]);
 }
    }
  else
    {
      if (last_virtual)
 {
   offset = (((binfo_member (last_virtual, (((basetype)->type.lang_specific)->vbases))))->vec.a[1])
                                               ;
   offset = size_binop (PLUS_EXPR, offset, (((last))->vec.a[1]));
 }
      else
 offset = (((last))->vec.a[1]);
    }

  if (((offset)->int_cst.int_cst_low))
    {

      offset = convert (type, offset);
      expr = build1 (NOP_EXPR, type, expr);







      if (nonnull == 0)
 {
   if (null_expr)
     ((null_expr)->common.type) = type;
   else
     null_expr = build1 (NOP_EXPR, type, integer_zero_node);
   if (((expr)->common.side_effects_flag))
     expr = save_expr (expr);

   return build (COND_EXPR, type,
   build (EQ_EXPR, boolean_type_node, expr, integer_zero_node),
   null_expr,
   build (code, type, expr, offset));
 }
      else return build (code, type, expr, offset);
    }



  if (null_expr)
    {
      ((expr)->common.type) = type;
      return expr;
    }
  else
    return build1 (NOP_EXPR, type, expr);
}






static tree pending_hard_virtuals;
static int doing_hard_virtuals;






tree
build_vtable_entry(tree delta, tree pfn) asm("_build_vtable_entry");
tree
build_vtable_entry(tree delta, tree pfn)
{

  if (flag_vtable_thunks)
    {
      int idelta = ((delta)->int_cst.int_cst_low);
      extern tree make_thunk(...) asm("_make_thunk");
      if (idelta)
 {
   pfn = build1 (ADDR_EXPR, vtable_entry_type,
   make_thunk (pfn, idelta));
   ((pfn)->common.readonly_flag) = 1;
   ((pfn)->common.constant_flag) = 1;
 }



      return pfn;
    }
  else
    {
      extern int flag_huge_objects;
      tree elems = tree_cons ((tree) 
                             ((void *)0)
                                      , delta,
         tree_cons ((tree) 
                   ((void *)0)
                            , integer_zero_node,
      build_tree_list ((tree) 
                      ((void *)0)
                               , pfn)));
      tree entry = build (CONSTRUCTOR, vtable_entry_type, (tree) 
                                                         ((void *)0)
                                                                  , elems);






      if ((((((delta_type_node)->type.maxval))->int_cst.int_cst_low)
    < ((delta)->int_cst.int_cst_low))
   || (((delta)->int_cst.int_cst_low)
       < ((((delta_type_node)->type.minval))->int_cst.int_cst_low)))
 if (flag_huge_objects)
   sorry ("object size exceeds built-in limit for virtual function table implementation");
 else
   sorry ("object size exceeds normal limit for virtual function table implementation, recompile all source and use -fhuge-objects");

      ((entry)->common.constant_flag) = 1;
      ((entry)->common.static_flag) = 1;
      ((entry)->common.readonly_flag) = 1;





      return entry;
    }
}





tree
build_vfn_ref(tree *ptr_to_instptr, tree instance, tree idx) asm("_build_vfn_ref");
tree
build_vfn_ref(tree *ptr_to_instptr, tree instance, tree idx)
{
  extern int building_cleanup;
  tree vtbl, aref;
  tree basetype = ((instance)->common.type);

  if (((n64_enum_tree_code) (basetype)->common.code) == REFERENCE_TYPE)
    basetype = ((basetype)->common.type);

  if (instance == C_C_D)
    vtbl = build_indirect_ref (build_vfield_ref (instance, basetype),
          ((void *)0));
  else
    {
      if (optimize)
 {


   tree ref = (tree) 
             ((void *)0)
                      ;

   if (((n64_enum_tree_code) (instance)->common.code) == INDIRECT_REF
       && ((n64_enum_tree_code) (((((instance)->exp.operands[0]))->common.type))->common.code) == REFERENCE_TYPE)
     ref = ((instance)->exp.operands[0]);
   else if (((n64_enum_tree_code) (((instance)->common.type))->common.code) == REFERENCE_TYPE)
     ref = instance;

   if (ref && ((n64_enum_tree_code) (ref)->common.code) == VAR_DECL
       && ((ref)->decl.initial))
     {
       tree init = ((ref)->decl.initial);

       while (((n64_enum_tree_code) (init)->common.code) == NOP_EXPR
       || ((n64_enum_tree_code) (init)->common.code) == NON_LVALUE_EXPR)
  init = ((init)->exp.operands[0]);
       if (((n64_enum_tree_code) (init)->common.code) == ADDR_EXPR)
  {
    init = ((init)->exp.operands[0]);
    if ((((((init)->common.type))->type.lang_flag_5))
        && (((n64_enum_tree_code) (init)->common.code) == PARM_DECL
     || ((n64_enum_tree_code) (init)->common.code) == VAR_DECL))
      instance = init;
  }
     }
 }

      if ((((((instance)->common.type))->type.lang_flag_5))
   && (((n64_enum_tree_code) (instance)->common.code) == RESULT_DECL
       || ((n64_enum_tree_code) (instance)->common.code) == PARM_DECL
       || ((n64_enum_tree_code) (instance)->common.code) == VAR_DECL))
 vtbl = (((((basetype)->type.binfo)))->vec.a[2]);
      else
 vtbl = build_indirect_ref (build_vfield_ref (instance, basetype),
       ((void *)0));
    }
  assemble_external (vtbl);
  aref = build_array_ref (vtbl, idx);



  if (!building_cleanup && ((n64_enum_tree_code) (aref)->common.code) == INDIRECT_REF)
    ((aref)->exp.operands[0]) = save_expr (((aref)->exp.operands[0]));

  if (flag_vtable_thunks)
    return aref;
  else
    {
      if (ptr_to_instptr)
 *ptr_to_instptr
   = build (PLUS_EXPR, ((*ptr_to_instptr)->common.type),
     *ptr_to_instptr,
     convert (ptrdiff_type_node,
       build_component_ref (aref, delta_identifier, 0, 0)));
      return build_component_ref (aref, pfn_identifier, 0, 0);
    }
}



static tree
get_vtable_name(tree type) asm("_get_vtable_name");
static tree
get_vtable_name(tree type)
{
  tree type_id = build_typename_overload (type);
  char *buf = (char *)
                     __builtin_alloca((
                     strlen ((flag_vtable_thunks ? "__vt_%s" : "_vt.%s")) + ((type_id)->identifier.length) + 2
                     ))
                                           
                                          ;
  char *ptr = ((type_id)->identifier.pointer);
  int i;
  for (i = 0; ptr[i] == "__op"[i]; i++) ;
  sprintf (buf, (flag_vtable_thunks ? "__vt_%s" : "_vt.%s"), ptr+i);
  return get_identifier (buf);
}





static tree
build_vtable(tree binfo, tree type) asm("_build_vtable");
static tree
build_vtable(tree binfo, tree type)
{
  tree name = get_vtable_name (type);
  tree virtuals, decl;

  if (binfo)
    {
      virtuals = copy_list ((((binfo))->vec.a[3]));
      decl = build_decl (VAR_DECL, name, (((((binfo))->vec.a[2]))->common.type));
    }
  else
    {
      virtuals = (tree) 
                ((void *)0)
                         ;
      decl = build_decl (VAR_DECL, name, void_type_node);
    }







  import_export_vtable (decl, type, 0);

  (((struct n64_tag_lang_identifier *)(name))->global_value) = decl = pushdecl_top_level (decl);


  (((((type)->type.binfo)))->vec.a[2]) = decl;
  (((((type)->type.binfo)))->vec.a[3]) = virtuals;

  ((decl)->common.static_flag) = 1;


  ((decl)->common.readonly_flag) = 1;



  ((decl)->decl.frame_size.u) = ((((double_type_node)->type.align)) > (((decl)->decl.frame_size.u)) ? (((double_type_node)->type.align)) : (((decl)->decl.frame_size.u)))
                        ;


  if (binfo && write_virtuals >= 0)
    ((decl)->decl.virtual_flag) = 1;
  ((decl)->decl.context) = type;

  binfo = ((type)->type.binfo);
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 1):(((binfo)->common.lang_flag_4)=1));
  return decl;
}
static tree
build_type_pathname(char *format, tree parent, tree type) asm("_build_type_pathname");
static tree
build_type_pathname(char *format, tree parent, tree type)
{
  extern struct n64_tag_obstack temporary_obstack;
  char *first, *base, *name;
  int i;
  tree id;

  parent = ((parent)->type.main_variant);


  first = ((&temporary_obstack)->alloc_failed ? 0 : (&temporary_obstack)->object_base);


  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); int __len = ((((((((type)->type.name))->decl.assembler_name))->identifier.length))); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((((((((type)->type.name))->decl.assembler_name))->identifier.pointer))),__len); __o->next_free += __len; } (void) 0; })

                                    ;

  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('.'); (void) 0; });



  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); int __len = ((((((((parent)->type.name))->decl.assembler_name))->identifier.length))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((((((((parent)->type.name))->decl.assembler_name))->identifier.pointer))),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; })

                                       ;
  i = __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); __o->alloc_failed ? 0 : (unsigned) (__o->next_free - __o->object_base); });
  base = ((&temporary_obstack)->alloc_failed ? 0 : (&temporary_obstack)->object_base);
  __extension__ ({ struct n64_tag_obstack *__o1 = (&temporary_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });


  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); int __len = (strlen (format) + i + 1); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });
  name = ((&temporary_obstack)->alloc_failed ? 0 : (&temporary_obstack)->object_base);
  sprintf (name, format, base);
  id = get_identifier (name);
  __extension__ ({ struct n64_tag_obstack *__o = (&temporary_obstack); void *__obj = (first); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  return id;
}


static void
set_rtti_entry(tree virtuals, tree offset, tree type) asm("_set_rtti_entry");
static void
set_rtti_entry(tree virtuals, tree offset, tree type)
{
  if (! flag_vtable_thunks)
    ((virtuals)->list.value)
      = build_vtable_entry (offset,
       (flag_rtti
        ? build_t_desc (type, 0)
        : integer_zero_node));
  else
    {
      tree vfn = build1 (NOP_EXPR, (flag_vtable_thunks ? vtable_entry_type : ptr_type_node), offset);
      ((vfn)->common.constant_flag) = 1;

      ((virtuals)->list.value)
 = build_vtable_entry (integer_zero_node, vfn);

      vfn = flag_rtti
      ? build_t_desc (type, 0)
      : integer_zero_node;
      vfn = build1 (NOP_EXPR, (flag_vtable_thunks ? vtable_entry_type : ptr_type_node), vfn);
      ((vfn)->common.constant_flag) = 1;

      ((((virtuals)->common.chain))->list.value)
 = build_vtable_entry (integer_zero_node, vfn);
    }
}
static void
prepare_fresh_vtable(tree binfo, tree for_type) asm("_prepare_fresh_vtable");
static void
prepare_fresh_vtable(tree binfo, tree for_type)
{
  tree basetype = ((binfo)->common.type);
  tree orig_decl = (((binfo))->vec.a[2]);


  tree name = build_type_pathname ((flag_vtable_thunks ? "__vt_%s" : "_vt.%s"), basetype, for_type);
  tree new_decl = build_decl (VAR_DECL, name, ((orig_decl)->common.type));
  tree path, offset;
  int result;


  ((new_decl)->decl.context) = for_type;

  ((new_decl)->common.static_flag) = 1;
  (((binfo))->vec.a[2]) = pushdecl_top_level (new_decl);
  ((new_decl)->decl.virtual_flag) = 1;


  ((new_decl)->common.readonly_flag) = 1;

  ((new_decl)->decl.frame_size.u) = ((orig_decl)->decl.frame_size.u);


  (((binfo))->vec.a[3]) = copy_list ((((binfo))->vec.a[3]));

  if (((binfo)->common.static_flag))
    offset = (((binfo_member (((binfo)->common.type), (((for_type)->type.lang_specific)->vbases))))->vec.a[1])
                                          ;
  else
    offset = (((binfo))->vec.a[1]);

  set_rtti_entry ((((binfo))->vec.a[3]),
    size_binop (MINUS_EXPR, integer_zero_node, offset),
    for_type);







  import_export_vtable (new_decl, for_type, 0);

  if (((binfo)->common.static_flag))
    my_friendly_assert (binfo == binfo_member (((binfo)->common.type),
       (((current_class_type)->type.lang_specific)->vbases)),
   170);
  (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 1):(((binfo)->common.lang_flag_4)=1));
}





static tree
get_vtable_entry(tree virtuals, tree base_fndecl) asm("_get_vtable_entry");
static tree
get_vtable_entry(tree virtuals, tree base_fndecl)
{
  unsigned int n = (32 >= ((target_flags & 0x00002000) ? 64 : 32)
    ? (((((base_fndecl)->decl.vindex))->int_cst.int_cst_low)
       & (((unsigned int)1<<(((target_flags & 0x00002000) ? 64 : 32)-1))-1))
    : ((((base_fndecl)->decl.vindex))->int_cst.int_cst_low));





  while (n > 0 && virtuals)
    {
      --n;
      virtuals = ((virtuals)->common.chain);
    }
  return virtuals;
}






static void
modify_vtable_entry(tree old_entry_in_list, tree new_entry, tree fndecl) asm("_modify_vtable_entry");
static void
modify_vtable_entry(tree old_entry_in_list, tree new_entry, tree fndecl)
{
  tree base_fndecl = (((!flag_vtable_thunks ? ((((((((((old_entry_in_list)->list.value))->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((((old_entry_in_list)->list.value)))->exp.operands[0]))->common.code) != THUNK_DECL ? (((old_entry_in_list)->list.value)) : (((((((old_entry_in_list)->list.value)))->exp.operands[0]))->decl.initial)))->exp.operands[0]);





  ((old_entry_in_list)->list.value) = new_entry;



  if (((n64_enum_tree_code) (((fndecl)->decl.vindex))->common.code) != INTEGER_CST)
    {
      ((fndecl)->decl.vindex) = ((base_fndecl)->decl.vindex);
      ((fndecl)->decl.context) = ((base_fndecl)->decl.context);
    }
}



static tree
get_vtable_entry_n(tree virtuals, unsigned int n) asm("_get_vtable_entry_n");
static tree
get_vtable_entry_n(tree virtuals, unsigned int n)
{
  while (n > 0)
    {
      --n;
      virtuals = ((virtuals)->common.chain);
    }
  return virtuals;
}
static tree
add_virtual_function(tree pending_virtuals, int *has_virtual, tree fndecl, tree t) asm("_add_virtual_function");
static tree
add_virtual_function(tree pending_virtuals, int *has_virtual, tree fndecl, tree t)
{


  tree vfn = build1 (ADDR_EXPR, (flag_vtable_thunks ? vtable_entry_type : ptr_type_node), fndecl);
  ((vfn)->common.constant_flag) = 1;


  if (current_class_type == 0)
    cp_warning ("internal problem, current_class_type is zero when adding `%D', please report",
  fndecl);
  if (current_class_type && t != current_class_type)
    cp_warning ("internal problem, current_class_type differs when adding `%D', please report",
  fndecl);






  if (((fndecl)->decl.vindex) == error_mark_node)
    {
      tree entry;

      if (flag_rtti && *has_virtual == 0)
 {

   (((t)->type.lang_specific)->rtti) = integer_one_node;
        }



      if (*has_virtual == 0 && flag_vtable_thunks)
 {
   *has_virtual = 1;
 }


      {
 static tree index_table[256];
 tree strchr;

 int i = ++(*has_virtual);

 if (i >= 256 || index_table[i] == 0)
   {
     strchr = build_int_2_wide ((int) (i), (int) (0));
     if (i < 256)
       index_table[i] = strchr;
   }
 else
   strchr = index_table[i];


 ((fndecl)->decl.vindex) = strchr;
 ((fndecl)->decl.context) = t;
      }
      entry = build_vtable_entry (integer_zero_node, vfn);
      pending_virtuals = tree_cons (((fndecl)->decl.vindex), entry, pending_virtuals);
    }


  else if (((n64_enum_tree_code) (((fndecl)->decl.vindex))->common.code) != INTEGER_CST)
    {


      pending_hard_virtuals = temp_tree_cons (fndecl, vfn, pending_hard_virtuals);
    }
  return pending_virtuals;
}


struct n64_tag_obstack class_obstack;
extern struct n64_tag_obstack *current_obstack;







void
add_method(tree type, tree *fields, tree method) asm("_add_method");
void
add_method(tree type, tree *fields, tree method)
{


  tree decl;

  push_obstacks (&permanent_obstack, &permanent_obstack);
  {
    decl = copy_node (method);
    if (((decl)->decl.rtl) == 0
        && (!processing_template_decl
            || !uses_template_parms (decl)))
      {
 make_function_rtl (decl);
 ((method)->decl.rtl) = ((decl)->decl.rtl);
      }
  }

  if (fields && *fields)
    {

      (((decl)->decl.lang_specific)->chain) = (((*fields)->decl.lang_specific)->chain);
      (((*fields)->decl.lang_specific)->chain) = decl;
    }
  else if (((type)->type.maxval) == 0)
    {
      tree method_vec = make_node (TREE_VEC);
      if ((((((type)->type.name))->decl.name)) == ((decl)->decl.name))
 {
   ((method_vec)->vec.a[0]) = decl;
   ((method_vec)->vec.length) = 1;
 }
      else
 {



   __extension__ ({ struct n64_tag_obstack *__o = (current_obstack); void *__obj = (method_vec); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
   __extension__ ({ struct n64_tag_obstack *__o = (current_obstack); int __len = (sizeof (struct n64_tag_tree_vec) + sizeof (tree *)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });
   ((method_vec)->vec.a[1]) = decl;
   ((method_vec)->vec.length) = 2;
   __extension__ ({ struct n64_tag_obstack *__o1 = (current_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
 }
      ((type)->type.maxval) = method_vec;
    }
  else
    {
      tree method_vec = ((type)->type.maxval);
      int len = ((method_vec)->vec.length);



      if ((((((type)->type.name))->decl.name)) == ((decl)->decl.name))
 {

   if (decl != ((method_vec)->vec.a[0]))
     {
       (((decl)->decl.lang_specific)->chain) = ((method_vec)->vec.a[0]);
       ((method_vec)->vec.a[0]) = decl;
     }
 }
      else
 {



   struct n64_tag_obstack *ob = &class_obstack;
   tree *end = (tree *)((ob)->alloc_failed ? 0 : (ob)->next_free);

   if (end != (&((method_vec)->vec.a[(method_vec)->vec.length])))
     {
       ob = current_obstack;
       ((method_vec)->vec.length) += 1;
       ((method_vec)->vec.a[len]) = (tree) 
                                       ((void *)0)
                                                ;
       method_vec = copy_node (method_vec);
       ((method_vec)->vec.length) -= 1;
     }
   else
     {
       tree tmp_vec = (tree) ((ob)->alloc_failed ? 0 : (ob)->object_base);
       if (__extension__ ({ struct n64_tag_obstack *__o = (ob); (unsigned) (__o->chunk_limit - __o->next_free); }) < sizeof (tree))
  {
    __extension__ ({ struct n64_tag_obstack *__o = (ob); int __len = (sizeof (struct n64_tag_tree_common) + tree_code_length[(int) TREE_VEC] * sizeof (char *) + len * sizeof (tree)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; })


                           ;
    tmp_vec = (tree) ((ob)->alloc_failed ? 0 : (ob)->object_base);
    memcpy ((char *) tmp_vec,(char *) method_vec,(sizeof (struct n64_tag_tree_common) + tree_code_length[(int) TREE_VEC] * sizeof (char *) + (len-1) * sizeof (tree)))


                                ;
    method_vec = tmp_vec;
  }
       else
  __extension__ ({ struct n64_tag_obstack *__o = (ob); int __len = (sizeof (tree)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });
     }

   __extension__ ({ struct n64_tag_obstack *__o1 = (ob); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
   ((method_vec)->vec.a[len]) = decl;
   ((method_vec)->vec.length) = len + 1;
   ((type)->type.maxval) = method_vec;

   if (((((type)->type.binfo))->vec.a[4]) && (((type)->type.lang_specific)->baselink_vec))
     {

       tree baselink_vec = (((type)->type.lang_specific)->baselink_vec);

       ((baselink_vec)->vec.length) += 1;
       (((type)->type.lang_specific)->baselink_vec) = copy_node (baselink_vec);
       ((baselink_vec)->vec.length) -= 1;

       (((((type)->type.lang_specific)->baselink_vec))->vec.a[len]) = 0;
     }
 }
    }
  ((decl)->decl.context) = type;
  (((decl)->decl.lang_specific)->decl_flags.context) = type;

  pop_obstacks ();
}
static tree
delete_duplicate_fields_1(tree field, tree fields) asm("_delete_duplicate_fields_1");
static tree
delete_duplicate_fields_1(tree field, tree fields)
{
  tree x;
  tree prev = 0;
  if (((field)->decl.name) == 0)
    {
      if (((n64_enum_tree_code) (((field)->common.type))->common.code) != UNION_TYPE)
 return fields;

      for (x = ((((field)->common.type))->type.values); x; x = ((x)->common.chain))
 fields = delete_duplicate_fields_1 (x, fields);
      return fields;
    }
  else
    {
      for (x = fields; x; prev = x, x = ((x)->common.chain))
 {
   if (((x)->decl.name) == 0)
     {
       if (((n64_enum_tree_code) (((x)->common.type))->common.code) != UNION_TYPE)
  continue;
       ((((x)->common.type))->type.values)
  = delete_duplicate_fields_1 (field, ((((x)->common.type))->type.values));
       if (((((x)->common.type))->type.values) == 0)
  {
    if (prev == 0)
      fields = ((fields)->common.chain);
    else
      ((prev)->common.chain) = ((x)->common.chain);
  }
     }
   else
     {
       if (((field)->decl.name) == ((x)->decl.name))
  {
    if (((n64_enum_tree_code) (field)->common.code) == CONST_DECL
        && ((n64_enum_tree_code) (x)->common.code) == CONST_DECL)
      cp_error_at ("duplicate enum value `%D'", x);
    else if (((n64_enum_tree_code) (field)->common.code) == CONST_DECL
      || ((n64_enum_tree_code) (x)->common.code) == CONST_DECL)
      cp_error_at ("duplicate field `%D' (as enum and non-enum)",
    x);
    else if (((n64_enum_tree_code) (field)->common.code) == TYPE_DECL
      && ((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
      cp_error_at ("duplicate nested type `%D'", x);
    else if (((n64_enum_tree_code) (field)->common.code) == TYPE_DECL
      || ((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
      cp_error_at ("duplicate field `%D' (as type and non-type)",
    x);
    else
      cp_error_at ("duplicate member `%D'", x);
    if (prev == 0)
      fields = ((fields)->common.chain);
    else
      ((prev)->common.chain) = ((x)->common.chain);
  }
     }
 }
    }
  return fields;
}

static void
delete_duplicate_fields(tree fields) asm("_delete_duplicate_fields");
static void
delete_duplicate_fields(tree fields)
{
  tree x;
  for (x = fields; x && ((x)->common.chain); x = ((x)->common.chain))
    ((x)->common.chain) = delete_duplicate_fields_1 (x, ((x)->common.chain));
}



static int
alter_access(tree t, tree fdecl, n64_enum_access_type access) asm("_alter_access");
static int
alter_access(tree t, tree fdecl, n64_enum_access_type access)
{
  tree elem = purpose_member (t, (((fdecl)->decl.lang_specific)->decl_flags.access));
  if (elem && ((elem)->list.value) != (tree)access)
    {
      if (((n64_enum_tree_code) (((fdecl)->common.type))->common.code) == FUNCTION_DECL)
 {
   cp_error_at ("conflicting access specifications for method `%D', ignored", ((fdecl)->common.type));
 }
      else
 error ("conflicting access specifications for field `%s', ignored",
        ((((fdecl)->decl.name))->identifier.pointer));
    }
  else if (((fdecl)->common.private_flag))
    {
      if (access != access_private)
 cp_error_at ("cannot make private `%D' non-private", fdecl);
      goto alter;
    }
  else if (((fdecl)->common.protected_flag))
    {
      if (access != access_protected)
 cp_error_at ("cannot make protected `%D' non-protected", fdecl);
      goto alter;
    }


  else if (access != access_public)
    cp_error_at ("cannot reduce access of public member `%D'", fdecl);
  else if (elem == (tree) 
                  ((void *)0)
                           )
    {
    alter:
      (((fdecl)->decl.lang_specific)->decl_flags.access) = tree_cons (t, (tree)access,
        (((fdecl)->decl.lang_specific)->decl_flags.access));
      return 1;
    }
  return 0;
}


tree
get_vfield_offset(tree binfo) asm("_get_vfield_offset");
tree
get_vfield_offset(tree binfo)
{
  return size_binop (PLUS_EXPR,
       size_binop (FLOOR_DIV_EXPR,
     ((((((binfo)->common.type))->type.minval))->decl.arguments),
     size_int (8)),
       (((binfo))->vec.a[1]));
}






static tree
get_derived_offset(tree binfo, tree type) asm("_get_derived_offset");
static tree
get_derived_offset(tree binfo, tree type)
{
  tree offset1 = get_vfield_offset (((((binfo)->common.type))->type.binfo));
  tree offset2;
  int i;
  while ((((binfo))->vec.a[4])
  && (i=(((((binfo)->common.type))->type.lang_specific)->vfield_parent)) != -1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      if (((binfo)->common.type) == type)
 break;
      binfo = ((binfos)->vec.a[i]);
    }
  offset2 = get_vfield_offset (((((binfo)->common.type))->type.binfo));
  return size_binop (MINUS_EXPR, offset1, offset2);
}





static tree
maybe_fixup_vptrs(tree for_type, tree binfo, tree base_init_list) asm("_maybe_fixup_vptrs");
static tree
maybe_fixup_vptrs(tree for_type, tree binfo, tree base_init_list)
{


  tree vfields = (((((binfo)->common.type))->type.lang_specific)->vfields);
  while (vfields)
    {
      tree basetype = ((vfields)->common.type)
 ? ((((vfields)->common.type))->type.main_variant)
   : ((vfields)->list.value);

      tree base_binfo = get_binfo (basetype, for_type, 0);

      if (1 )
 {
   tree base_offset = get_vfield_offset (base_binfo);
   if (! tree_int_cst_equal (base_offset, get_vfield_offset (((for_type)->type.binfo)))
       && ! tree_int_cst_equal (base_offset, get_vfield_offset (binfo)))
     base_init_list = tree_cons (error_mark_node, base_binfo,
     base_init_list);
 }
      vfields = ((vfields)->common.chain);
    }
  return base_init_list;
}
static void
build_class_init_list(tree type) asm("_build_class_init_list");
static void
build_class_init_list(tree type)
{
  tree base_init_list = (tree) 
                       ((void *)0)
                                ;
  tree member_init_list = (tree) 
                         ((void *)0)
                                  ;



  tree x;
  tree binfos = (((((type)->type.binfo)))->vec.a[4]);
  int i, n_baseclasses = binfos ? ((binfos)->vec.length) : 0;

  for (x = ((type)->type.values); x; x = ((x)->common.chain))
    {
      if (((n64_enum_tree_code) (x)->common.code) != FIELD_DECL)
 continue;

      if (((((x)->common.type))->type.needs_constructing_flag)
   || ((x)->decl.initial) != (tree) 
                         ((void *)0)
                                  )
 member_init_list = tree_cons (x, type, member_init_list);
    }
  member_init_list = nreverse (member_init_list);



  if ((((type)->common.lang_flag_2)))
    {
      base_init_list = build_tree_list (error_mark_node, ((type)->type.binfo));
      if ((((type)->type.lang_specific)->type_flags.needs_virtual_reinit) == 0)
 ((base_init_list)->list.value) = (tree) 
                              ((void *)0)
                                       ;
      ((base_init_list)->common.addressable_flag) = 1;
    }



  for (i = n_baseclasses-1; i >= 0; i--)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree blist;


      if (((base_binfo)->common.static_flag))
 continue;

      if ((((((base_binfo)->common.type))->type.lang_flag_1)))
 {

   base_init_list = maybe_fixup_vptrs (type, base_binfo, base_init_list);
   base_init_list = tree_cons ((tree) 
                              ((void *)0)
                                       , base_binfo, base_init_list);
   continue;
 }

      if ((blist = (((((base_binfo)->common.type))->type.lang_specific)->base_init_list)) == (tree) 
                                                                         ((void *)0)
                                                                                  )

 continue;


      base_init_list = maybe_fixup_vptrs (type, base_binfo, base_init_list);





      if (((blist)->list.value)
   && ((n64_enum_tree_code) (((blist)->list.value))->common.code) == TREE_VEC
   && tree_int_cst_equal ((((base_binfo))->vec.a[1]),
     (((((blist)->list.value)))->vec.a[1])))
 {
   if (base_init_list)
     {


       if (! ((blist)->common.addressable_flag))
  base_init_list = build_tree_list (blist, base_init_list);


       else if (((base_init_list)->common.addressable_flag)
         && ((base_init_list)->list.value) == 0)
  base_init_list = blist;

       else if (! (((type)->type.lang_specific)->type_flags.needs_virtual_reinit))
  {
    tree last = tree_last (base_init_list);
    while (((last)->list.value)
    && ((n64_enum_tree_code) (((last)->list.value))->common.code) == TREE_LIST)
      last = tree_last (((last)->list.value));
    if (((last)->list.value) == 0)
      base_init_list = build_tree_list (blist, base_init_list);
  }
     }
   else
     base_init_list = blist;
 }
      else
 {



   if (base_init_list)
     base_init_list = tree_cons ((tree) 
                                ((void *)0)
                                         , base_binfo, base_init_list);
   else
     base_init_list = (((((base_binfo)->common.type))->type.lang_specific)->binfo_as_list);
 }
    }

  if (base_init_list)
    if (member_init_list)
      (((type)->type.lang_specific)->base_init_list) = build_tree_list (base_init_list, member_init_list);
    else
      (((type)->type.lang_specific)->base_init_list) = base_init_list;
  else if (member_init_list)
    (((type)->type.lang_specific)->base_init_list) = member_init_list;
}

struct n64_tag_base_info
{
  int has_virtual;
  int max_has_virtual;
  int n_ancestors;
  tree vfield;
  tree vfields;
  char cant_have_default_ctor;
  char cant_have_const_ctor;
  char cant_synth_copy_ctor;
  char cant_synth_asn_ref;
  char no_const_asn_ref;
  char needs_virtual_dtor;
};
static int
finish_base_struct(tree t, struct n64_tag_base_info *b, tree t_binfo) asm("_finish_base_struct");
static int
finish_base_struct(tree t, struct n64_tag_base_info *b, tree t_binfo)
{
  tree binfos = (((t_binfo))->vec.a[4]);
  int i, n_baseclasses = binfos ? ((binfos)->vec.length) : 0;
  int first_vfn_base_index = -1;
  memset ((char *) b,0,sizeof (struct n64_tag_base_info));

  for (i = 0; i < n_baseclasses; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree basetype = ((base_binfo)->common.type);




      if (((basetype)->type.size) == 0)
 {
   int j;



   if (i == n_baseclasses-1)
     ((binfos)->vec.a[i]) = (tree) 
                               ((void *)0)
                                        ;
   ((binfos)->vec.length) -= 1;
   n_baseclasses -= 1;
   for (j = i; j+1 < n_baseclasses; j++)
     ((binfos)->vec.a[j]) = ((binfos)->vec.a[j+1]);
 }

      if ((((basetype)->type.lang_specific)->type_flags.has_init_ref)
   && !(((basetype)->type.lang_specific)->type_flags.has_const_init_ref))
 b->cant_have_const_ctor = 1;
      if (! (((basetype)->type.lang_specific)->type_flags.has_init_ref)
   || ((((basetype)->type.lang_specific)->type_flags.has_nonpublic_ctor) == 2
       && ! is_friend_type (t, basetype)))
 b->cant_synth_copy_ctor = 1;

      if ((((basetype)->type.lang_flag_1))
   && ! (((basetype)->type.lang_specific)->type_flags.has_default_ctor))
 {
   b->cant_have_default_ctor = 1;
   if (! (((t)->type.lang_flag_1)))
     {
       cp_pedwarn ("base `%T' with only non-default constructor",
     basetype);
       cp_pedwarn ("in class without a constructor");
     }
 }

      if ((((basetype)->type.lang_specific)->type_flags.has_assign_ref)
   && !(((basetype)->type.lang_specific)->type_flags.has_const_assign_ref))
 b->no_const_asn_ref = 1;
      if (! (((basetype)->type.lang_specific)->type_flags.has_assign_ref)
   || (((basetype)->type.lang_specific)->type_flags.has_abstract_assign_ref)
   || ((((basetype)->type.lang_specific)->type_flags.has_nonpublic_assign_ref) == 2
       && ! is_friend_type (t, basetype)))
 b->cant_synth_asn_ref = 1;

      b->n_ancestors += (((basetype)->type.lang_specific)->n_ancestors);
      ((t)->type.needs_constructing_flag) |= ((basetype)->type.needs_constructing_flag);
      (((t)->type.lang_flag_4)) |= (((basetype)->type.lang_flag_4));
      (((t)->type.lang_specific)->type_flags.has_complex_assign_ref) |= (((basetype)->type.lang_specific)->type_flags.has_complex_assign_ref);
      (((t)->type.lang_specific)->type_flags.has_complex_init_ref) |= (((basetype)->type.lang_specific)->type_flags.has_complex_init_ref);

      (((t)->type.lang_specific)->type_flags.has_call_overloaded) |= (((basetype)->type.lang_specific)->type_flags.has_call_overloaded);
      (((t)->type.lang_specific)->type_flags.has_array_ref_overloaded) |= (((basetype)->type.lang_specific)->type_flags.has_array_ref_overloaded);
      (((t)->type.lang_specific)->type_flags.has_arrow_overloaded) |= (((basetype)->type.lang_specific)->type_flags.has_arrow_overloaded);

      if (! ((base_binfo)->common.static_flag)
   && (((base_binfo))->vec.a[4]))
 {
   tree base_binfos = (((base_binfo))->vec.a[4]);
   tree chain = (tree) 
               ((void *)0)
                        ;
   int j;


   for (j = ((base_binfos)->vec.length)-1;
        j >= 0; j--)
     {
       tree base_base_binfo = ((base_binfos)->vec.a[j]);
       if (! ((base_base_binfo)->common.static_flag))
  ((base_binfos)->vec.a[j])
    = make_binfo ((((base_base_binfo))->vec.a[1]),
    base_base_binfo,
    (((base_base_binfo))->vec.a[2]),
    (((base_base_binfo))->vec.a[3]),
    chain);
       chain = ((base_binfos)->vec.a[j]);
       ((chain)->common.public_flag) = ((base_base_binfo)->common.public_flag);
       ((chain)->common.protected_flag) = ((base_base_binfo)->common.protected_flag);
       (((chain))->vec.a[0]) = base_binfo;
     }



   propagate_binfo_offsets (base_binfo, (((base_binfo))->vec.a[1]));
 }

      if (! ((base_binfo)->common.static_flag))
 (((t)->type.lang_specific)->n_ancestors) += 1;

      if ((((basetype)->common.lang_flag_2)))
 {


   b->needs_virtual_dtor = 1;


   if (((base_binfo)->common.static_flag))
     continue;

   if (first_vfn_base_index < 0)
     {
       tree vfields;
       first_vfn_base_index = i;




       (((t_binfo))->vec.a[2]) = (((((basetype)->type.binfo)))->vec.a[2]);
       (((t_binfo))->vec.a[3]) = (((((basetype)->type.binfo)))->vec.a[3]);
       b->has_virtual = (((basetype)->type.lang_specific)->vsize);
       b->vfield = ((basetype)->type.minval);
       b->vfields = copy_list ((((basetype)->type.lang_specific)->vfields));
       vfields = b->vfields;
       while (vfields)
  {
    if (((vfields)->list.purpose) == (tree) 
                                   ((void *)0)
        
       || ! ((((vfields)->list.purpose))->common.static_flag))
      {
        tree value = ((vfields)->list.value);
        if (((((value)->type.minval))->decl.name)
     == ((((basetype)->type.minval))->decl.name))
   ((b->vfields)->common.type) = basetype;
        else
   ((b->vfields)->common.type) = ((vfields)->common.type);
      }
    vfields = ((vfields)->common.chain);
  }
       ((t)->type.minval) = b->vfield;
     }
   else
     {

       tree vfields = (((basetype)->type.lang_specific)->vfields);
       while (vfields)
  {
    if (((vfields)->list.purpose) == (tree) 
                                   ((void *)0)
        
       || ! ((((vfields)->list.purpose))->common.static_flag))
      {
        tree value = ((vfields)->list.value);
        b->vfields = tree_cons (base_binfo, value, b->vfields);
        if (((((value)->type.minval))->decl.name)
     == ((((basetype)->type.minval))->decl.name))
   ((b->vfields)->common.type) = basetype;
        else
   ((b->vfields)->common.type) = ((vfields)->common.type);
      }
    vfields = ((vfields)->common.chain);
  }

       if (b->has_virtual == 0)
  {
    first_vfn_base_index = i;




    (((t_binfo))->vec.a[2]) = (((((basetype)->type.binfo)))->vec.a[2]);
    (((t_binfo))->vec.a[3]) = (((((basetype)->type.binfo)))->vec.a[3]);
    b->has_virtual = (((basetype)->type.lang_specific)->vsize);
    b->vfield = ((basetype)->type.minval);
    ((t)->type.minval) = b->vfield;




    vfields = b->vfields;
    while (vfields)
      {
        if (((((t)->type.minval))->decl.name)
     == ((((basetype)->type.minval))->decl.name))
   {
     ((vfields)->common.type) = t;


     break;
   }
        vfields = ((vfields)->common.chain);
      }
  }
     }
 }
    }


  for (i = 0; i < n_baseclasses; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree basetype = ((base_binfo)->common.type);

      if (get_base_distance (basetype, t_binfo, 0, (tree*)0) == -2)
 {
   cp_warning ("direct base `%T' inaccessible in `%T' due to ambiguity",
        basetype, t);
   b->cant_synth_asn_ref = 1;
   b->cant_synth_copy_ctor = 1;
 }
    }
  {
    tree v = get_vbase_types (t_binfo);

    for (; v; v = ((v)->common.chain))
      {
 tree basetype = ((v)->common.type);
 if (get_base_distance (basetype, t_binfo, 0, (tree*)0) == -2)
   {
     if (extra_warnings)
       cp_warning ("virtual base `%T' inaccessible in `%T' due to ambiguity",
     basetype, t);
     b->cant_synth_asn_ref = 1;
     b->cant_synth_copy_ctor = 1;
   }
      }
  }

  {
    tree vfields;

    for (vfields = b->vfields; vfields; vfields = ((vfields)->common.chain))
      {
 if ((((((vfields)->list.value))->type.lang_specific)->vsize) > b->max_has_virtual)
   b->max_has_virtual = (((((vfields)->list.value))->type.lang_specific)->vsize);
 if ((((vfields)->list.purpose) ? ((((vfields)->list.purpose))->common.type) : (tree) 
    ((void *)0)
    )
     && ((((((vfields)->list.purpose) ? ((((vfields)->list.purpose))->common.type) : (tree) 
       ((void *)0)
       ))->type.lang_specific)->vsize) > b->max_has_virtual)
   b->max_has_virtual = ((((((vfields)->list.purpose) ? ((((vfields)->list.purpose))->common.type) : (tree) 
                       ((void *)0)
                       ))->type.lang_specific)->vsize);
      }
  }

  if (b->vfield == 0)

    return -1;
  return first_vfn_base_index;
}

static int
typecode_p(tree type, n64_enum_tree_code code) asm("_typecode_p");
static int
typecode_p(tree type, n64_enum_tree_code code)
{
  return (((n64_enum_tree_code) (type)->common.code) == code
   || (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE
       && ((n64_enum_tree_code) (((type)->common.type))->common.code) == code));
}



static void
finish_struct_bits(tree t, int max_has_virtual) asm("_finish_struct_bits");
static void
finish_struct_bits(tree t, int max_has_virtual)
{
  int i, n_baseclasses = (((((t)->type.binfo))->vec.a[4]) ? ((((((t)->type.binfo))->vec.a[4]))->vec.length) : 0);
  tree method_vec = ((t)->type.maxval);


  tree variants = ((t)->type.next_variant);
  while (variants)
    {


      (((variants)->type.lang_flag_1)) = (((t)->type.lang_flag_1));
      (((variants)->type.lang_flag_2)) = (((t)->type.lang_flag_2));
      ((variants)->type.needs_constructing_flag) = ((t)->type.needs_constructing_flag);
      (((variants)->type.lang_flag_4)) = (((t)->type.lang_flag_4));

      (((variants)->common.lang_flag_1)) = (((t)->common.lang_flag_1));
      (((variants)->common.lang_flag_2)) = (((t)->common.lang_flag_2));
      (((variants)->common.lang_flag_3)) = (((t)->common.lang_flag_3));

      ((variants)->type.minval) = ((t)->type.minval);
      ((variants)->type.maxval) = ((t)->type.maxval);
      variants = ((variants)->type.next_variant);
    }

  if (n_baseclasses && max_has_virtual)
    {

      int might_have_abstract_virtuals = (((t)->type.lang_specific)->abstract_virtuals) != 0;
      tree binfos = ((((t)->type.binfo))->vec.a[4]);
      for (i = n_baseclasses-1; i >= 0; i--)
 {
   might_have_abstract_virtuals
     |= ((((((((binfos)->vec.a[i]))->common.type))->type.lang_specific)->abstract_virtuals) != 0);
   if (might_have_abstract_virtuals)
     break;
 }
      if (might_have_abstract_virtuals)
 {


   if ((((t)->type.lang_specific)->abstract_virtuals) == error_mark_node)
     (((t)->type.lang_specific)->abstract_virtuals) = (tree) 
                                      ((void *)0)
                                               ;
   (((t)->type.lang_specific)->abstract_virtuals) = get_abstract_virtuals (t);
 }
    }

  if (n_baseclasses)
    {

      tree binfo = ((t)->type.binfo);
      tree binfos = (((binfo))->vec.a[4]);
      tree basetype;

      for (i = n_baseclasses-1; i >= 0; i--)
 {
   basetype = ((((binfos)->vec.a[i]))->common.type);

   if ((((basetype)->type.lang_specific)->type_flags.has_type_conversion))
     {
       (((t)->type.lang_specific)->type_flags.has_type_conversion) = 1;
       (((t)->type.lang_specific)->type_flags.has_int_conversion) |= (((basetype)->type.lang_specific)->type_flags.has_int_conversion);
       (((t)->type.lang_specific)->type_flags.has_float_conversion) |= (((basetype)->type.lang_specific)->type_flags.has_float_conversion);
     }
   if ((((basetype)->type.lang_specific)->max_depth) >= (((t)->type.lang_specific)->max_depth))
     (((t)->type.lang_specific)->max_depth) = (((basetype)->type.lang_specific)->max_depth) + 1;
 }
    }





  if (! ((((t)->type.lang_specific)->type_flags.has_init_ref) && ! (((t)->type.lang_specific)->type_flags.has_complex_init_ref)))
    {
      tree variants;
      if (((n64_enum_tree_code) (((t)->type.name))->common.code) == TYPE_DECL)
 ((((t)->type.name))->decl.mode) = BLKmode;
      for (variants = t; variants; variants = ((variants)->type.next_variant))
 {
   ((variants)->type.mode) = BLKmode;
   ((variants)->common.addressable_flag) = 1;
 }
    }
}



static void
grow_method(tree fn, tree *method_vec_ptr) asm("_grow_method");
static void
grow_method(tree fn, tree *method_vec_ptr)
{
  tree method_vec = (tree)((&class_obstack)->alloc_failed ? 0 : (&class_obstack)->object_base);
  tree *testp = &((method_vec)->vec.a[0]);
  if (*testp == (tree) 
               ((void *)0)
                        )
    testp++;
  while (((int) testp
   < (int) ((&class_obstack)->alloc_failed ? 0 : (&class_obstack)->next_free))
  && ((*testp)->decl.name) != ((fn)->decl.name))
    testp++;
  if ((int) testp
      < (int) ((&class_obstack)->alloc_failed ? 0 : (&class_obstack)->next_free))
    {
      tree x, prev_x;

      for (x = *testp; x; x = (((x)->decl.lang_specific)->chain))
 {
   if (((fn)->decl.name) == ansi_opname[(int) DELETE_EXPR]
       || ((fn)->decl.name) == ansi_opname[(int) VEC_DELETE_EXPR])
     {

       cp_error_at ("`%D' overloaded", fn);
       cp_error_at ("previous declaration as `%D' here", x);
     }
   if (((fn)->decl.assembler_name)==((x)->decl.assembler_name))
     {



       if (!(((((fn)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((fn)->decl.assembler_name))->identifier.pointer)[2] == '_'))
  cp_error_at ("ambiguous method `%#D' in structure", fn);
       break;
     }
   prev_x = x;
 }
      if (x == 0)
 {
   if (*testp)
     (((prev_x)->decl.lang_specific)->chain) = fn;
   else
     *testp = fn;
 }
    }
  else
    {
      __extension__ ({ struct n64_tag_obstack *__o = (&class_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)fn); __o->next_free += sizeof (void *); } (void) 0; });
      *method_vec_ptr = (tree)((&class_obstack)->alloc_failed ? 0 : (&class_obstack)->object_base);
    }
}
static tree
finish_struct_methods(tree t, tree fn_fields, int nonprivate_method) asm("_finish_struct_methods");
static tree
finish_struct_methods(tree t, tree fn_fields, int nonprivate_method)
{
  tree method_vec;
  tree save_fn_fields = tree_cons ((tree) 
                                  ((void *)0)
                                           , (tree) 
                                             ((void *)0)
                                                      , fn_fields);
  tree lastp;
  tree name = constructor_name (t);
  int i, n_baseclasses = (((((t)->type.binfo))->vec.a[4]) ? ((((((t)->type.binfo))->vec.a[4]))->vec.length) : 0);


  struct n64_tag_obstack *ambient_obstack = current_obstack;
  current_obstack = &class_obstack;
  method_vec = make_node (TREE_VEC);

  current_obstack = ambient_obstack;

  __extension__ ({ struct n64_tag_obstack *__o = (&class_obstack); void *__obj = (method_vec); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  __extension__ ({ struct n64_tag_obstack *__o = (&class_obstack); int __len = (sizeof (struct n64_tag_tree_vec)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });




  for (lastp = save_fn_fields; fn_fields; fn_fields = ((lastp)->common.chain))
    {
      tree fn_name = ((fn_fields)->decl.name);
      if (fn_name == (tree) 
                    ((void *)0)
                             )
 fn_name = name;





      (((fn_fields)->decl.lang_flag_3)) = 0;




      if (fn_name == name)
  {
    tree parmtypes = (((((((fn_fields)->common.type))->type.values))->common.chain));
    tree parmtype = parmtypes ? ((parmtypes)->list.value) : void_type_node;

    if (((n64_enum_tree_code) (parmtype)->common.code) == REFERENCE_TYPE
        && ((((parmtype)->common.type))->type.main_variant) == t)
      {
        if (((parmtypes)->common.chain) == (tree) 
                                     ((void *)0)
     
    || ((parmtypes)->common.chain) == void_list_node
     || ((((parmtypes)->common.chain))->list.purpose))
   {
     if (((fn_fields)->common.protected_flag))
       (((t)->type.lang_specific)->type_flags.has_nonpublic_ctor) = 1;
     else if (((fn_fields)->common.private_flag))
       (((t)->type.lang_specific)->type_flags.has_nonpublic_ctor) = 2;
   }
      }

   (((fn_fields)->decl.lang_specific)->chain) = ((method_vec)->vec.a[0]);
   ((method_vec)->vec.a[0]) = fn_fields;
  }
      else if ((! strncmp (((fn_name)->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.length))))
 {
   tree return_type = ((((fn_fields)->common.type))->common.type);

   if (typecode_p (return_type, INTEGER_TYPE)
       || typecode_p (return_type, BOOLEAN_TYPE)
       || typecode_p (return_type, ENUMERAL_TYPE))
     (((t)->type.lang_specific)->type_flags.has_int_conversion) = 1;
   else if (typecode_p (return_type, REAL_TYPE))
     (((t)->type.lang_specific)->type_flags.has_float_conversion) = 1;

   grow_method (fn_fields, &method_vec);
 }
      else
 {
   lastp = fn_fields;
   continue;
 }

      ((lastp)->common.chain) = ((fn_fields)->common.chain);
      ((fn_fields)->common.chain) = (tree) 
                              ((void *)0)
                                       ;
    }

  fn_fields = ((save_fn_fields)->common.chain);
  while (fn_fields)
    {
      tree nextp;
      tree fn_name = ((fn_fields)->decl.name);
      if (fn_name == (tree) 
                    ((void *)0)
                             )
 fn_name = name;

      nextp = ((fn_fields)->common.chain);
      ((fn_fields)->common.chain) = (tree) 
                              ((void *)0)
                                       ;

      if (fn_name == ansi_opname[(int) MODIFY_EXPR])
 {
   tree parmtype = (((((((((fn_fields)->common.type))->type.values))->common.chain)))->list.value);

   if (copy_assignment_arg_p (parmtype, ((fn_fields)->decl.virtual_flag)))
     {
       if (((fn_fields)->common.protected_flag))
  (((t)->type.lang_specific)->type_flags.has_nonpublic_assign_ref) = 1;
       else if (((fn_fields)->common.private_flag))
  (((t)->type.lang_specific)->type_flags.has_nonpublic_assign_ref) = 2;
     }
 }

      grow_method (fn_fields, &method_vec);
      fn_fields = nextp;
    }

  ((method_vec)->vec.length) = (tree *)((&class_obstack)->alloc_failed ? 0 : (&class_obstack)->next_free)
    - (&((method_vec)->vec.a[0]));
  __extension__ ({ struct n64_tag_obstack *__o1 = (&class_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
  ((t)->type.maxval) = method_vec;

  if (nonprivate_method == 0
      && (((t)->type.lang_specific)->friend_classes) == (tree) 
                                        ((void *)0)
      
     && (((((t)->type.name))->decl.initial)) == (tree) 
                                           ((void *)0)
                                                    )
    {
      tree binfos = (((((t)->type.binfo)))->vec.a[4]);
      for (i = 0; i < n_baseclasses; i++)
 if (((((binfos)->vec.a[i]))->common.public_flag)
     || ((((binfos)->vec.a[i]))->common.protected_flag))
   {
     nonprivate_method = 1;
     break;
   }
      if (nonprivate_method == 0)
 cp_warning ("all member functions in class `%T' are private", t);
    }





  if ((((t)->type.lang_flag_2)))
    {
      tree dtor, prev;

      for (dtor = ((method_vec)->vec.a[0]);
    dtor;
    prev = dtor, dtor = (((dtor)->decl.lang_specific)->chain))
 {
   if ((((((dtor)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((dtor)->decl.assembler_name))->identifier.pointer)[2] == '_'))
     {
       if (((dtor)->common.private_flag)
    && (((t)->type.lang_specific)->friend_classes) == (tree) 
                                      ((void *)0)
    
   && (((((t)->type.name))->decl.initial)) == (tree) 
                                         ((void *)0)
    
   && warn_ctor_dtor_privacy)
  cp_warning ("`%#T' only defines a private destructor and has no friends",
       t);
       break;
     }
 }


      if (dtor == (tree) 
                 ((void *)0)
                          )
 (((t)->type.lang_flag_2)) = 0;
      else if (dtor != ((method_vec)->vec.a[0]))
 {
   (((prev)->decl.lang_specific)->chain) = (((dtor)->decl.lang_specific)->chain);
   (((dtor)->decl.lang_specific)->chain) = ((method_vec)->vec.a[0]);
   ((method_vec)->vec.a[0]) = dtor;
 }
    }




  if (n_baseclasses != 0
      && ((method_vec)->vec.length) > 1)
    {
      int len = ((method_vec)->vec.length);
      tree baselink_vec = make_tree_vec (len);
      int any_links = 0;
      tree baselink_binfo = build_tree_list ((tree) 
                                            ((void *)0)
                                                     , ((t)->type.binfo));

      for (i = 1; i < len; i++)
 {
   ((baselink_vec)->vec.a[i])
     = get_baselinks (baselink_binfo, t, ((((method_vec)->vec.a[i]))->decl.name));
   if (((baselink_vec)->vec.a[i]) != 0)
     any_links = 1;
 }
      if (any_links != 0)
 (((t)->type.lang_specific)->baselink_vec) = baselink_vec;
      else
 __extension__ ({ struct n64_tag_obstack *__o = (current_obstack); void *__obj = (baselink_vec); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
    }


  {
    tree x, last_x = (tree) 
                    ((void *)0)
                             ;
    int limit = ((method_vec)->vec.length);

    for (i = 1; i < limit; i++)
      {
 for (x = ((method_vec)->vec.a[i]); x; x = (((x)->decl.lang_specific)->chain))
   {
     if (last_x != (tree) 
                  ((void *)0)
                           )
       ((last_x)->common.chain) = x;
     last_x = x;
   }
      }


    x = ((method_vec)->vec.a[0]);
    if (x)
      {
 while ((((x)->decl.lang_specific)->chain))
   {

     if (x == (((x)->decl.lang_specific)->chain))
       break;
     ((x)->common.chain) = (((x)->decl.lang_specific)->chain);
     x = (((x)->decl.lang_specific)->chain);
   }
 if (((method_vec)->vec.length) > 1)
   ((x)->common.chain) = ((method_vec)->vec.a[1]);
 else
   ((x)->common.chain) = (tree) 
                   ((void *)0)
                            ;
      }
  }

  ((t)->type.maxval) = method_vec;

  return method_vec;
}



void
duplicate_tag_error(tree t) asm("_duplicate_tag_error");
void
duplicate_tag_error(tree t)
{
  cp_error ("redefinition of `%#T'", t);
  cp_error_at ("previous definition here", t);
  if (((t)->type.maxval))
    {
      tree tv = ((t)->type.maxval);
      int i, len = ((tv)->vec.length);
      for (i = 0; i < len; i++)
 {
   tree unchain = ((tv)->vec.a[i]);
   while (unchain != (tree) 
                    ((void *)0)
                             )
     {
       ((unchain)->common.chain) = (tree) 
                             ((void *)0)
                                      ;
       unchain = (((unchain)->decl.lang_specific)->chain);
     }
 }
    }

  if (((t)->type.lang_specific))
    {
      tree as_list = (((t)->type.lang_specific)->as_list);
      tree binfo = ((t)->type.binfo);
      tree binfo_as_list = (((t)->type.lang_specific)->binfo_as_list);
      int interface_only = (((t)->type.lang_specific)->type_flags.interface_only);
      int interface_unknown = (((t)->type.lang_specific)->type_flags.interface_unknown);

      memset ((char *) ((t)->type.lang_specific),0,sizeof (struct n64_tag_lang_type));
      (((binfo))->vec.a[4]) = (tree) 
                              ((void *)0)
                                       ;

      (((t)->type.lang_specific)->as_list) = as_list;
      ((t)->type.binfo) = binfo;
      (((t)->type.lang_specific)->binfo_as_list) = binfo_as_list;
      (((t)->type.lang_specific)->type_flags.interface_only) = interface_only;
      (((t)->type.lang_specific)->type_flags.interface_unknown = !!(interface_unknown));
      (((t)->type.lang_specific)->vbase_size) = integer_zero_node;
      (((t)->type.lang_specific)->type_flags.redefined) = 1;
    }
  ((t)->type.size) = (tree) 
                 ((void *)0)
                          ;
  ((t)->type.mode) = VOIDmode;
  ((t)->type.values) = (tree) 
                   ((void *)0)
                            ;
  ((t)->type.maxval) = (tree) 
                    ((void *)0)
                             ;
  ((t)->type.minval) = (tree) 
                   ((void *)0)
                            ;
  ((t)->type.context) = (tree) 
                    ((void *)0)
                             ;
}


static void
finish_vtbls(tree binfo, int do_self, tree t) asm("_finish_vtbls");
static void
finish_vtbls(tree binfo, int do_self, tree t)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;


  if (do_self && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      if ((((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
 {
   tree decl, context;

   decl = (((binfo))->vec.a[2]);
   context = ((decl)->decl.context);
   ((decl)->decl.context) = 0;
   if (write_virtuals >= 0
       && ((decl)->decl.initial) != (((binfo))->vec.a[3]))
     ((decl)->decl.initial) = build_nt (CONSTRUCTOR, (tree) 
                                                 ((void *)0)
                                                          ,
         (((binfo))->vec.a[3]));
   cp_finish_decl (decl, ((decl)->decl.initial), (tree) 
                                             ((void *)0)
                                                      , 0, 0);
   ((decl)->decl.context) = context;
 }
      (((binfo)->common.static_flag)?((((((binfo)->common.type))->type.lang_specific)->type_flags.marked4) = 0):(((binfo)->common.lang_flag_4)=0));
    }

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (((base_binfo)->common.static_flag))
 {
   base_binfo = binfo_member (((base_binfo)->common.type), (((t)->type.lang_specific)->vbases));
 }
      finish_vtbls (base_binfo, is_not_base_vtable, t);
    }
}



static int
overrides(tree fndecl, tree base_fndecl) asm("_overrides");
static int
overrides(tree fndecl, tree base_fndecl)
{

  if ((((((base_fndecl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((base_fndecl)->decl.assembler_name))->identifier.pointer)[2] == '_') &&
      (((((fndecl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((fndecl)->decl.assembler_name))->identifier.pointer)[2] == '_'))
    return 1;
  if ((((((base_fndecl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((base_fndecl)->decl.assembler_name))->identifier.pointer)[2] == '_') ||
      (((((fndecl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((fndecl)->decl.assembler_name))->identifier.pointer)[2] == '_'))
    return 0;
  if (((fndecl)->decl.name) == ((base_fndecl)->decl.name))
    {
      tree rettype, base_rettype, types, base_types;




      types = ((((fndecl)->common.type))->type.values);
      base_types = ((((base_fndecl)->common.type))->type.values);
      if ((((((((base_types)->list.value))->common.type))->common.readonly_flag)
    == ((((((types)->list.value))->common.type))->common.readonly_flag))
   && compparms (((base_types)->common.chain), ((types)->common.chain), 3))
 return 1;
    }
  return 0;
}

static tree
get_class_offset_1(tree parent, tree binfo, tree context, tree t, tree fndecl) asm("_get_class_offset_1");
static tree
get_class_offset_1(tree parent, tree binfo, tree context, tree t, tree fndecl)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;
  tree rval = (tree) 
             ((void *)0)
                      ;

  if (binfo == parent)
    return error_mark_node;

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree nrval;

      if (((base_binfo)->common.static_flag))
 base_binfo = binfo_member (((base_binfo)->common.type),
       (((t)->type.lang_specific)->vbases));
      nrval = get_class_offset_1 (parent, base_binfo, context, t, fndecl);

      if (nrval && (nrval != error_mark_node || rval==0))
 {

   if (rval && rval != error_mark_node
       && ! tree_int_cst_equal (nrval, rval))
     {

       error ("every virtual function must have a unique final overrider");
       cp_error ("  found two (or more) `%T' class subobjects in `%T'", context, t);
       cp_error ("  with virtual `%D' from virtual base class", fndecl);
       return rval;
     }
   rval = nrval;
 }

      if (rval && ((binfo)->common.type) == context)
 {
   my_friendly_assert (rval == error_mark_node
         || tree_int_cst_equal (rval, (((binfo))->vec.a[1])), 999);
   rval = (((binfo))->vec.a[1]);
 }
    }
  return rval;
}



static tree
get_class_offset(tree context, tree t, tree binfo, tree fndecl) asm("_get_class_offset");
static tree
get_class_offset(tree context, tree t, tree binfo, tree fndecl)
{
  tree first_binfo = binfo;
  tree offset;
  int i;

  if (context == t)
    return integer_zero_node;

  if (((binfo)->common.type) == context)
    return (((binfo))->vec.a[1]);


  while ((((binfo))->vec.a[4])
  && (i=(((((binfo)->common.type))->type.lang_specific)->vfield_parent)) != -1)
    {
      tree binfos = (((binfo))->vec.a[4]);
      binfo = ((binfos)->vec.a[i]);
      if (((binfo)->common.type) == context)
 return (((binfo))->vec.a[1]);
    }



  offset = get_class_offset_1 (first_binfo, ((t)->type.binfo), context, t, fndecl);
  if (offset==0 || ((n64_enum_tree_code) (offset)->common.code) != INTEGER_CST)
    my_friendly_abort (999);
  return offset;
}


unsigned int
skip_rtti_stuff(tree *virtuals) asm("_skip_rtti_stuff");
unsigned int
skip_rtti_stuff(tree *virtuals)
{
  int n;

  n = 0;
  if (*virtuals)
    {

      ++n;
      *virtuals = ((*virtuals)->common.chain);
    }
  if (flag_vtable_thunks && *virtuals)
    {


      ++n;
      *virtuals = ((*virtuals)->common.chain);
    }
  return n;
}

static void
modify_one_vtable(tree binfo, tree t, tree fndecl, tree pfn) asm("_modify_one_vtable");
static void
modify_one_vtable(tree binfo, tree t, tree fndecl, tree pfn)
{
  tree virtuals = (((binfo))->vec.a[3]);
  tree old_rtti;
  unsigned int n;


  if (flag_rtti)
    {
      if (binfo == ((t)->type.binfo))
 {
   if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
     build_vtable (((((((t)->type.minval))->decl.context))->type.binfo), t);
 }
      else
 {
   if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
     prepare_fresh_vtable (binfo, t);
 }
    }
  if (fndecl == (tree) 
               ((void *)0)
                        )
    return;

  n = skip_rtti_stuff (&virtuals);

  while (virtuals)
    {
      tree current_fndecl = ((virtuals)->list.value);
      current_fndecl = (!flag_vtable_thunks ? ((((((((current_fndecl)->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((current_fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? (current_fndecl) : (((((current_fndecl))->exp.operands[0]))->decl.initial));
      current_fndecl = ((current_fndecl)->exp.operands[0]);
      if (current_fndecl && overrides (fndecl, current_fndecl))
 {
   tree base_offset, offset;
   tree context = (((fndecl)->decl.lang_specific)->decl_flags.context);
   tree vfield = ((t)->type.minval);
   tree this_offset;

   offset = get_class_offset (context, t, binfo, fndecl);
   base_offset = size_binop (PLUS_EXPR,
        get_derived_offset (binfo, ((current_fndecl)->decl.context)),
        (((binfo))->vec.a[1]));
   this_offset = size_binop (MINUS_EXPR, offset, base_offset);


   if (((binfo)->common.used_flag))
     my_friendly_assert (0, 999);

   if (binfo == ((t)->type.binfo))
     {



       if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
  build_vtable (((((vfield)->decl.context))->type.binfo), t);
     }
   else
     {




       if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
  prepare_fresh_vtable (binfo, t);
     }




   modify_vtable_entry (get_vtable_entry_n ((((binfo))->vec.a[3]), n),
          build_vtable_entry (this_offset, pfn),
          fndecl);
 }
      ++n;
      virtuals = ((virtuals)->common.chain);
    }
}


static void
modify_all_direct_vtables(tree binfo, int do_self, tree t, tree fndecl, tree pfn) asm("_modify_all_direct_vtables");
static void
modify_all_direct_vtables(tree binfo, int do_self, tree t, tree fndecl, tree pfn)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;


  if (do_self && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      modify_one_vtable (binfo, t, fndecl, pfn);
    }

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((base_binfo)->common.static_flag))
 modify_all_direct_vtables (base_binfo, is_not_base_vtable, t, fndecl, pfn);
    }
}


static void
fixup_vtable_deltas1(tree binfo, tree t) asm("_fixup_vtable_deltas1");
static void
fixup_vtable_deltas1(tree binfo, tree t)
{
  tree virtuals = (((binfo))->vec.a[3]);
  unsigned int n;

  n = skip_rtti_stuff (&virtuals);

  while (virtuals)
    {
      tree fndecl = ((virtuals)->list.value);
      tree pfn = (!flag_vtable_thunks ? ((((((((fndecl)->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? (fndecl) : (((((fndecl))->exp.operands[0]))->decl.initial));
      tree delta = (!flag_vtable_thunks ? ((((fndecl)->exp.operands[1]))->list.value) : ((n64_enum_tree_code) ((((fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? integer_zero_node : build_int_2_wide ((int) ((((((fndecl))->exp.operands[0]))->decl.frame_size.i)), (int) (0)));
      fndecl = ((pfn)->exp.operands[0]);
      if (fndecl)
 {
   tree base_offset, offset;
   tree context = (((fndecl)->decl.lang_specific)->decl_flags.context);
   tree vfield = ((t)->type.minval);
   tree this_offset;

   offset = get_class_offset (context, t, binfo, fndecl);
   base_offset = size_binop (PLUS_EXPR,
        get_derived_offset (binfo, ((fndecl)->decl.context)),
        (((binfo))->vec.a[1]));
   this_offset = size_binop (MINUS_EXPR, offset, base_offset);

   if (! tree_int_cst_equal (this_offset, delta))
     {

       if (((binfo)->common.used_flag))
  my_friendly_assert (0, 999);

       if (binfo == ((t)->type.binfo))
  {



    if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
      build_vtable (((((vfield)->decl.context))->type.binfo), t);
  }
       else
  {




    if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
      prepare_fresh_vtable (binfo, t);
  }

       modify_vtable_entry (get_vtable_entry_n ((((binfo))->vec.a[3]), n),
       build_vtable_entry (this_offset, pfn),
       fndecl);
     }
 }
      ++n;
      virtuals = ((virtuals)->common.chain);
    }
}





static void
fixup_vtable_deltas(tree binfo, int init_self, tree t) asm("_fixup_vtable_deltas");
static void
fixup_vtable_deltas(tree binfo, int init_self, tree t)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((base_binfo)->common.static_flag))
 fixup_vtable_deltas (base_binfo, is_not_base_vtable, t);
    }

  if (init_self && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      fixup_vtable_deltas1 (binfo, t);
    }
}


static void
modify_all_indirect_vtables(tree binfo, int do_self, int via_virtual, tree t, tree fndecl, tree pfn) asm("_modify_all_indirect_vtables");
static void
modify_all_indirect_vtables(tree binfo, int do_self, int via_virtual, tree t, tree fndecl, tree pfn)
{
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;


  if (do_self && via_virtual && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      modify_one_vtable (binfo, t, fndecl, pfn);
    }

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (((base_binfo)->common.static_flag))
 {
   via_virtual = 1;
   base_binfo = binfo_member (((base_binfo)->common.type), (((t)->type.lang_specific)->vbases));
 }
      modify_all_indirect_vtables (base_binfo, is_not_base_vtable, via_virtual, t, fndecl, pfn);
    }
}

static void
modify_all_vtables(tree t, tree fndecl, tree vfn) asm("_modify_all_vtables");
static void
modify_all_vtables(tree t, tree fndecl, tree vfn)
{


  modify_all_direct_vtables (((t)->type.binfo), 1, t, fndecl, vfn);
  if ((((t)->common.lang_flag_3)))
    modify_all_indirect_vtables (((t)->type.binfo), 1, 0, t, fndecl, vfn);
}



static int
strictly_overrides(tree fndecl1, tree fndecl2) asm("_strictly_overrides");
static int
strictly_overrides(tree fndecl1, tree fndecl2)
{
  int distance = get_base_distance ((((fndecl2)->decl.lang_specific)->decl_flags.context),
        (((fndecl1)->decl.lang_specific)->decl_flags.context),
        0, (tree *)0);
  if (distance == -2 || distance > 0)
    return 1;
  return 0;
}
static void
override_one_vtable(tree binfo, tree old, tree t) asm("_override_one_vtable");
static void
override_one_vtable(tree binfo, tree old, tree t)
{
  tree virtuals = (((binfo))->vec.a[3]);
  tree old_virtuals = (((old))->vec.a[3]);
  enum n64_cpp_enum_anonymous_19{ REUSE_NEW, REUSE_OLD, UNDECIDED, NEITHER };
typedef __underlying_type(enum n64_cpp_enum_anonymous_19) n64_enum_anonymous_19;
n64_enum_anonymous_19 choose = UNDECIDED;



  if ((((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
    choose = NEITHER;

  skip_rtti_stuff (&virtuals);
  skip_rtti_stuff (&old_virtuals);

  while (virtuals)
    {
      tree fndecl = ((virtuals)->list.value);
      tree old_fndecl = ((old_virtuals)->list.value);
      fndecl = (!flag_vtable_thunks ? ((((((((fndecl)->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? (fndecl) : (((((fndecl))->exp.operands[0]))->decl.initial));
      old_fndecl = (!flag_vtable_thunks ? ((((((((old_fndecl)->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((old_fndecl))->exp.operands[0]))->common.code) != THUNK_DECL ? (old_fndecl) : (((((old_fndecl))->exp.operands[0]))->decl.initial));
      fndecl = ((fndecl)->exp.operands[0]);
      old_fndecl = ((old_fndecl)->exp.operands[0]);

      if (((fndecl)->decl.assembler_name) == ((old_fndecl)->decl.assembler_name))
 {

 }
      else if (strictly_overrides (fndecl, old_fndecl))
 {
   if (choose == UNDECIDED)
     choose = REUSE_NEW;
   else if (choose == REUSE_OLD)
     {
       choose = NEITHER;
       if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
  {
    prepare_fresh_vtable (binfo, t);
    override_one_vtable (binfo, old, t);
    return;
  }
     }
 }
      else if (strictly_overrides (old_fndecl, fndecl))
 {
   if (choose == UNDECIDED)
     choose = REUSE_OLD;
   else if (choose == REUSE_NEW)
     {
       choose = NEITHER;
       if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
  {
    prepare_fresh_vtable (binfo, t);
    override_one_vtable (binfo, old, t);
    return;
  }
       ((virtuals)->list.value) = ((old_virtuals)->list.value);
     }
   else if (choose == NEITHER)
     {
       ((virtuals)->list.value) = ((old_virtuals)->list.value);
     }
 }
      else
 {
   choose = NEITHER;
   if (! (((binfo)->common.static_flag)?(((((binfo)->common.type))->type.lang_specific)->type_flags.marked4):((binfo)->common.lang_flag_4)))
     {
       prepare_fresh_vtable (binfo, t);
       override_one_vtable (binfo, old, t);
       return;
     }
   {


     tree fndecl = (((!flag_vtable_thunks ? ((((((((((virtuals)->list.value))->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((((virtuals)->list.value)))->exp.operands[0]))->common.code) != THUNK_DECL ? (((virtuals)->list.value)) : (((((((virtuals)->list.value)))->exp.operands[0]))->decl.initial)))->exp.operands[0]);
     tree vfn;

     fndecl = copy_node (fndecl);
     copy_lang_decl (fndecl);
     (((fndecl)->decl.lang_specific)->decl_flags.abstract_virtual) = 1;

     if (! (((t)->type.lang_specific)->abstract_virtuals))
       (((t)->type.lang_specific)->abstract_virtuals) = error_mark_node;

     vfn = build1 (ADDR_EXPR, (flag_vtable_thunks ? vtable_entry_type : ptr_type_node), fndecl);
     ((vfn)->common.constant_flag) = 1;



     ((virtuals)->list.value) = build_vtable_entry (integer_zero_node, vfn);
   }
 }
      virtuals = ((virtuals)->common.chain);
      old_virtuals = ((old_virtuals)->common.chain);
    }


  if (choose == REUSE_OLD)
    {
      (((binfo))->vec.a[2]) = (((old))->vec.a[2]);
      (((binfo))->vec.a[3]) = (((old))->vec.a[3]);
    }
}




static void
merge_overrides(tree binfo, tree old, int do_self, tree t) asm("_merge_overrides");
static void
merge_overrides(tree binfo, tree old, int do_self, tree t)
{
  tree binfos = (((binfo))->vec.a[4]);
  tree old_binfos = (((old))->vec.a[4]);
  int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;


  if (do_self && (((((binfo)->common.type))->type.lang_specific)->vfields))
    {
      override_one_vtable (binfo, old, t);
    }

  for (i = 0; i < n_baselinks; i++)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      tree old_base_binfo = ((old_binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((base_binfo)->common.static_flag))
 merge_overrides (base_binfo, old_base_binfo, is_not_base_vtable, t);
    }
}

extern int interface_only, interface_unknown;
tree
finish_struct_1(tree t, int warn_anon) asm("_finish_struct_1");
tree
finish_struct_1(tree t, int warn_anon)
{
  int old;
  int round_up_size = 1;

  tree name = (((((t)->type.name))->decl.name));
  n64_enum_tree_code code = ((n64_enum_tree_code) (t)->common.code);
  tree fields = ((t)->type.values);
  tree fn_fields = (((t)->type.lang_specific)->methods);
  tree x, last_x, method_vec;
  int needs_virtual_dtor;
  int all_virtual;
  int has_virtual;
  int max_has_virtual;
  tree pending_virtuals = (tree) 
                         ((void *)0)
                                  ;
  tree abstract_virtuals = (tree) 
                          ((void *)0)
                                   ;
  tree vfield;
  tree vfields;
  int cant_have_default_ctor;
  int cant_have_const_ctor;
  int cant_synth_copy_ctor;
  int cant_synth_asn_ref;
  int no_const_asn_ref;



  int first_vfn_base_index;

  int n_baseclasses;
  int any_default_members = 0;
  int const_sans_init = 0;
  int ref_sans_init = 0;
  int nonprivate_method = 0;
  tree t_binfo = ((t)->type.binfo);
  tree access_decls = (tree) 
                     ((void *)0)
                              ;
  int aggregate = 1;

  if (warn_anon && code != UNION_TYPE && ((((((((t)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((t)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
    pedwarn ("anonymous class type not used to declare any objects");

  if (((t)->type.size))
    {
      if ((((t)->type.lang_flag_5)))
 cp_error ("redefinition of `%#T'", t);
      else
 my_friendly_abort (172);
      popclass (0);
      return t;
    }

  if (dont_allow_type_definitions)
    {
      pedwarn ("types cannot be defined %s",
        dont_allow_type_definitions);
    }

  GNU_xref_decl (current_function_decl, t);




  ((t)->type.size) = (tree) 
                 ((void *)0)
                          ;
  (((t)->type.lang_specific)->type_flags.got_semicolon) = 0;
  ((t)->type.binfo) = (tree) 
                  ((void *)0)
                           ;

  old = suspend_momentary ();
  if (t_binfo && (((t_binfo))->vec.a[4]))
    n_baseclasses = (((((t_binfo))->vec.a[4]))->vec.length);
  else
    n_baseclasses = 0;

  if (n_baseclasses > 0)
    {
      struct n64_tag_base_info base_info;



      tree vf = layout_basetypes (t, (((t_binfo))->vec.a[4]));
      last_x = tree_last (vf);
      fields = chainon (vf, fields);

      first_vfn_base_index = finish_base_struct (t, &base_info, t_binfo);

      (((t)->type.lang_specific)->vfield_parent) = first_vfn_base_index;
      has_virtual = base_info.has_virtual;
      max_has_virtual = base_info.max_has_virtual;
      (((t)->type.lang_specific)->n_ancestors) += base_info.n_ancestors;
      vfield = base_info.vfield;
      vfields = base_info.vfields;
      cant_have_default_ctor = base_info.cant_have_default_ctor;
      cant_have_const_ctor = base_info.cant_have_const_ctor;
      cant_synth_copy_ctor = base_info.cant_synth_copy_ctor;
      cant_synth_asn_ref = base_info.cant_synth_asn_ref;
      no_const_asn_ref = base_info.no_const_asn_ref;
      needs_virtual_dtor = base_info.needs_virtual_dtor;
      n_baseclasses = (((((t_binfo))->vec.a[4]))->vec.length);
      aggregate = 0;
    }
  else
    {
      first_vfn_base_index = -1;
      has_virtual = 0;
      max_has_virtual = has_virtual;
      vfield = (tree) 
              ((void *)0)
                       ;
      vfields = (tree) 
               ((void *)0)
                        ;
      last_x = (tree) 
              ((void *)0)
                       ;
      cant_have_default_ctor = 0;
      cant_have_const_ctor = 0;
      cant_synth_copy_ctor = 0;
      cant_synth_asn_ref = 0;
      no_const_asn_ref = 0;
      needs_virtual_dtor = 0;
    }
  ((t_binfo)->common.chain) = ((t)->type.binfo);
  ((t)->type.binfo) = t_binfo;
  (((t)->type.lang_specific)->vfields) = vfields;
  ((t)->type.minval) = vfield;

  if ((((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    all_virtual = 0;
  else if (flag_all_virtual == 1 && (((t)->type.lang_specific)->type_flags.has_method_call_overloaded))
    all_virtual = 1;
  else
    all_virtual = 0;

  for (x = (((t)->type.lang_specific)->methods); x; x = ((x)->common.chain))
    {
      GNU_xref_member (current_class_name, x);

      nonprivate_method |= ! ((x)->common.private_flag);


      if ((((struct n64_tag_lang_identifier *)(((x)->decl.assembler_name)))->x ? ((struct n64_tag_lang_identifier *)(((x)->decl.assembler_name)))->x->error_locus : 0))
 continue;

      (((x)->decl.lang_specific)->decl_flags.context) = t;





      ((x)->decl.saved_insns.r) = (rtx) 0;
      ((x)->decl.saved_insns.i) = 0;



      if (((x)->decl.vindex)
   || (all_virtual == 1 && ! (((x)->decl.lang_specific)->decl_flags.constructor_attr)))
 {
   pending_virtuals = add_virtual_function (pending_virtuals,
         &has_virtual, x, t);
   if ((((x)->decl.lang_specific)->decl_flags.abstract_virtual))
     abstract_virtuals = tree_cons ((tree) 
                                   ((void *)0)
                                            , x, abstract_virtuals);
   else
     ((x)->common.used_flag) = 1;
 }
    }

  for (x = ((t)->type.values); x; x = ((x)->common.chain))
    {
      GNU_xref_member (current_class_name, x);


      if (((x)->decl.name) && ((n64_enum_tree_code) (((x)->decl.name))->common.code) == SCOPE_REF)
 {
   tree fdecl = ((((x)->decl.name))->exp.operands[1]);
   n64_enum_access_type access
     = ((x)->common.private_flag) ? access_private :
       ((x)->common.protected_flag) ? access_protected : access_public;

   if (last_x)
     ((last_x)->common.chain) = ((x)->common.chain);
   else
     fields = ((x)->common.chain);

   access_decls = tree_cons ((tree) access, fdecl, access_decls);
   continue;
 }

      last_x = x;

      if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
 continue;




      ((x)->decl.context) = t;


      if (current_function_decl && ((x)->common.static_flag))
 cp_error_at ("field `%D' in local class cannot be static", x);



      if (((n64_enum_tree_code) (((x)->common.type))->common.code) == FUNCTION_TYPE)
 {
   cp_error_at ("field `%D' invalidly declared function type",
         x);
   ((x)->common.type) = build_pointer_type (((x)->common.type));
 }
      else if (((n64_enum_tree_code) (((x)->common.type))->common.code) == METHOD_TYPE)
 {
   cp_error_at ("field `%D' invalidly declared method type", x);
   ((x)->common.type) = build_pointer_type (((x)->common.type));
 }
      else if (((n64_enum_tree_code) (((x)->common.type))->common.code) == OFFSET_TYPE)
 {
   cp_error_at ("field `%D' invalidly declared offset type", x);
   ((x)->common.type) = build_pointer_type (((x)->common.type));
 }






      if (((x)->common.type) == error_mark_node)
 continue;

      ((x)->decl.saved_insns.r) = (rtx) 0;
      ((x)->decl.saved_insns.i) = 0;


      ((x)->decl.nonlocal_flag) = 1;

      if (((n64_enum_tree_code) (x)->common.code) == CONST_DECL)
 continue;

      if (((n64_enum_tree_code) (x)->common.code) == VAR_DECL)
 {
   if (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE)

     cp_error_at ("field `%D' declared static in union", x);

   continue;
 }



      if (((x)->common.private_flag) || ((x)->common.protected_flag))
 aggregate = 0;



      if (((n64_enum_tree_code) (((x)->common.type))->common.code) == REFERENCE_TYPE)
  {
   if (((x)->decl.initial) == (tree) 
                          ((void *)0)
                                   )
     ref_sans_init = 1;





   cant_synth_asn_ref = 1;
   cant_have_default_ctor = 1;

   if (! (((t)->type.lang_flag_1)) && extra_warnings)
     {
       if (((x)->decl.name))
  cp_warning_at ("non-static reference `%#D' in class without a constructor", x);
       else
  cp_warning_at ("non-static reference in class without a constructor", x);
     }
 }


      if (((x)->common.readonly_flag))
 {
   ((t)->type.lang_flag_0) = 1;
   if (((x)->decl.initial) == (tree) 
                          ((void *)0)
                                   )
     const_sans_init = 1;





   cant_synth_asn_ref = 1;
   cant_have_default_ctor = 1;

   if (! (((t)->type.lang_flag_1)) && !(((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0)
       && extra_warnings)
     {
       if (((x)->decl.name))
  cp_warning_at ("non-static const member `%#D' in class without a constructor", x);
       else
  cp_warning_at ("non-static const member in class without a constructor", x);
     }
 }
      else
 {


   tree t1 = ((x)->common.type);
   while (((n64_enum_tree_code) (t1)->common.code) == ARRAY_TYPE)
     t1 = ((t1)->common.type);
   if ((((t1)->type.lang_flag_5)))
     {
       if (((t1)->type.lang_flag_0))
  ((t)->type.lang_flag_0) = 1;
       if ((((t1)->type.lang_specific)->type_flags.const_needs_init))
  const_sans_init = 1;
     }
 }




      if (((x)->decl.bit_field_flag))
 {
   ((x)->decl.bit_field_flag) = 0;


   if (((x)->decl.initial)
       && ! (((n64_enum_tree_code) (((x)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((x)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((x)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((x)->common.type))->common.code) == CHAR_TYPE))
     {
       cp_error_at ("bit-field `%#D' with non-integral type", x);
       ((x)->decl.initial) = 
                         ((void *)0)
                             ;
     }


   if (((x)->decl.initial))
     {
       register int width = ((((x)->decl.initial))->int_cst.int_cst_low);

       if (width < 0)
  {
    ((x)->decl.initial) = 
                      ((void *)0)
                          ;
    cp_error_at ("negative width in bit-field `%D'", x);
  }
       else if (width == 0 && ((x)->decl.name) != 0)
  {
    ((x)->decl.initial) = 
                      ((void *)0)
                          ;
    cp_error_at ("zero width for bit-field `%D'", x);
  }
       else if (width
         > ((long_long_unsigned_type_node)->type.precision))
  {


    ((x)->decl.initial) = 
                      ((void *)0)
                          ;
    sorry ("bit-fields larger than %d bits",
    ((long_long_unsigned_type_node)->type.precision));
    cp_error_at ("  in declaration of `%D'", x);
  }
       else if (width > ((((x)->common.type))->type.precision)
         && ((n64_enum_tree_code) (((x)->common.type))->common.code) != ENUMERAL_TYPE)
  {
    cp_warning_at ("width of `%D' exceeds its type", x);
  }
       else if (((n64_enum_tree_code) (((x)->common.type))->common.code) == ENUMERAL_TYPE
         && ((min_precision (((((x)->common.type))->type.minval),
        ((((x)->common.type))->common.unsigned_flag)) > width)
      || (min_precision (((((x)->common.type))->type.maxval),
           ((((x)->common.type))->common.unsigned_flag)) > width)))
  {
    cp_warning_at ("`%D' is too small to hold all values of `%#T'",
     x, ((x)->common.type));
  }
     }


   if (((x)->decl.initial))
     {
       register int width = ((((x)->decl.initial))->int_cst.int_cst_low);

       if (width == 0)
  {


    if (((x)->common.chain))
      ((((x)->common.chain))->decl.frame_size.u)
        = ((((((x)->common.chain))->decl.frame_size.u)) > (((target_flags & 0x00000002) ? 64 : 32)) ? (((((x)->common.chain))->decl.frame_size.u)) : (((target_flags & 0x00000002) ? 64 : 32)));

    else
      round_up_size = ((target_flags & 0x00000002) ? 64 : 32);


    ((x)->decl.frame_size.u) = ((((x)->decl.frame_size.u)) > (((((x)->common.type))->type.align)) ? (((x)->decl.frame_size.u)) : (((((x)->common.type))->type.align)))
                                ;

  }
       else
  {
    ((x)->decl.initial) = (tree) 
                      ((void *)0)
                               ;
    ((x)->decl.saved_insns.i) = width;
    ((x)->decl.bit_field_flag) = 1;


    if (flag_traditional
        && ((n64_enum_tree_code) (((x)->common.type))->common.code) == INTEGER_TYPE)
      ((x)->common.type) = unsigned_type_node;
  }
     }
   else

     ((x)->decl.frame_size.u) = ((((x)->decl.frame_size.u)) > (((((x)->common.type))->type.align)) ? (((x)->decl.frame_size.u)) : (((((x)->common.type))->type.align)));
 }
      else
 {
   tree type = ((x)->common.type);

   if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
     type = ((type)->common.type);

   if (((type)->type.lang_specific) && ! (((x)->decl.name) == 0)
       && ! (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
     {


       if ((((type)->type.lang_specific)->abstract_virtuals))
  abstract_virtuals_error (x, type);


       if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
  signature_error (x, type);

       if (code == UNION_TYPE)
  {
    char *fie = 
               ((void *)0)
                   ;
    if (((type)->type.needs_constructing_flag))
      fie = "constructor";
    else if ((((type)->type.lang_flag_4)))
      fie = "destructor";
    else if ((((type)->type.lang_specific)->type_flags.has_real_assignment))
      fie = "assignment operator";
    if (fie)
      cp_error_at ("member `%#D' with %s not allowed in union", x,
     fie);
  }
       else
  {
    ((t)->type.needs_constructing_flag) |= ((type)->type.needs_constructing_flag);
    (((t)->type.lang_flag_4)) |= (((type)->type.lang_flag_4));
    (((t)->type.lang_specific)->type_flags.has_complex_assign_ref) |= (((type)->type.lang_specific)->type_flags.has_complex_assign_ref);
    (((t)->type.lang_specific)->type_flags.has_complex_init_ref) |= (((type)->type.lang_specific)->type_flags.has_complex_init_ref);
  }

       if (! (((type)->type.lang_specific)->type_flags.has_init_ref)
    || ((((type)->type.lang_specific)->type_flags.has_nonpublic_ctor)
        && ! is_friend (t, type)))
  cant_synth_copy_ctor = 1;
       else if (!(((type)->type.lang_specific)->type_flags.has_const_init_ref))
  cant_have_const_ctor = 1;

       if (! (((type)->type.lang_specific)->type_flags.has_assign_ref)
    || ((((type)->type.lang_specific)->type_flags.has_nonpublic_assign_ref)
        && ! is_friend (t, type)))
  cant_synth_asn_ref = 1;
       else if (!(((type)->type.lang_specific)->type_flags.has_const_assign_ref))
  no_const_asn_ref = 1;

       if ((((type)->type.lang_flag_1))
    && ! (((type)->type.lang_specific)->type_flags.has_default_ctor))
  {
    cant_have_default_ctor = 1;
  }
     }
   if (((x)->decl.initial) != (tree) 
                          ((void *)0)
                                   )
     {


       if (code == UNION_TYPE && any_default_members != 0)
  cp_error_at ("multiple fields in union `%T' initialized");
       any_default_members = 1;
     }
 }
    }





  (((t)->type.lang_specific)->type_flags.const_needs_init) = const_sans_init;
  (((t)->type.lang_specific)->type_flags.ref_needs_init) = ref_sans_init;
  (((t)->type.lang_specific)->abstract_virtuals) = abstract_virtuals;




  if (! fn_fields)
    nonprivate_method = 1;

  if ((((t)->type.lang_flag_4)) && !(((t)->type.lang_flag_2))
      && !(((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    {

      tree dtor = cons_up_default_function (t, name, needs_virtual_dtor != 0);


      if (dtor == void_type_node)
 (((t)->type.lang_flag_4)) = 0;
      else
 {


   ((dtor)->common.chain) = fn_fields;
   fn_fields = dtor;

   if (((dtor)->decl.vindex) == (tree) 
                            ((void *)0)
       
      && (needs_virtual_dtor
    || pending_virtuals != (tree) 
                          ((void *)0)
    
   || pending_hard_virtuals != (tree) 
                               ((void *)0)
                                        ))
     ((dtor)->decl.vindex) = error_mark_node;
   if (((dtor)->decl.vindex))
     pending_virtuals = add_virtual_function (pending_virtuals,
           &has_virtual, dtor, t);
   nonprivate_method = 1;
 }
    }

  (((t)->type.lang_flag_4)) |= (((t)->type.lang_flag_2));
  if (flag_rtti && (max_has_virtual > 0 || needs_virtual_dtor) &&
 has_virtual == 0)
    has_virtual = 1;

  (((t)->type.lang_specific)->type_flags.has_complex_init_ref)
    |= ((((t)->type.lang_specific)->type_flags.has_init_ref) || (((t)->common.lang_flag_3))
 || any_default_members);
  ((t)->type.needs_constructing_flag)
    |= ((((t)->type.lang_flag_1)) || (((t)->common.lang_flag_3))
 || has_virtual || any_default_members || first_vfn_base_index >= 0);
  if (! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    (((t)->type.lang_specific)->type_flags.non_aggregate)
      = ! aggregate || has_virtual || (((t)->type.lang_flag_1));





  if (! (((t)->type.lang_flag_1)) && ! cant_have_default_ctor
      && ! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    {
      tree default_fn = cons_up_default_function (t, name, 2);
      ((default_fn)->common.chain) = fn_fields;
      fn_fields = default_fn;
    }


  if (! (((t)->type.lang_specific)->type_flags.has_init_ref) && ! cant_synth_copy_ctor
      && ! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    {


      tree default_fn = cons_up_default_function (t, name,
        3 + cant_have_const_ctor);
      ((default_fn)->common.chain) = fn_fields;
      fn_fields = default_fn;
    }

  (((t)->type.lang_specific)->type_flags.has_real_assignment) |= (((t)->type.lang_specific)->type_flags.has_assignment);
  (((t)->type.lang_specific)->type_flags.has_real_assign_ref) |= (((t)->type.lang_specific)->type_flags.has_assign_ref);
  (((t)->type.lang_specific)->type_flags.has_complex_assign_ref)
    |= (((t)->type.lang_specific)->type_flags.has_assign_ref) || (((t)->common.lang_flag_3));

  if (! (((t)->type.lang_specific)->type_flags.has_assign_ref) && ! cant_synth_asn_ref
      && ! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    {
      tree default_fn = cons_up_default_function (t, name,
        5 + no_const_asn_ref);
      ((default_fn)->common.chain) = fn_fields;
      fn_fields = default_fn;
    }

  if (fn_fields)
    {
      method_vec = finish_struct_methods (t, fn_fields, nonprivate_method);

      if ((((t)->type.lang_flag_1))
   && (((t)->type.lang_specific)->friend_classes) == (tree) 
                                     ((void *)0)
   
  && (((((t)->type.name))->decl.initial)) == (tree) 
                                        ((void *)0)
                                                 )
 {
   int nonprivate_ctor = 0;
   tree ctor;

   for (ctor = ((method_vec)->vec.a[0]);
        ctor;
        ctor = (((ctor)->decl.lang_specific)->chain))
     if (! ((ctor)->common.private_flag))
       {
  nonprivate_ctor = 1;
  break;
       }

   if (nonprivate_ctor == 0 && warn_ctor_dtor_privacy)
     cp_warning ("`%#T' only defines private constructors and has no friends",
   t);
 }
    }
  else
    {
      method_vec = 0;



      (((t)->type.lang_flag_1)) = 0;
      (((t)->type.lang_flag_2)) = 0;
    }

  {
    int n_methods = method_vec ? ((method_vec)->vec.length) : 0;

    for (access_decls = nreverse (access_decls); access_decls;
  access_decls = ((access_decls)->common.chain))
      {
 tree fdecl = ((access_decls)->list.value);
 tree flist = (tree) 
             ((void *)0)
                      ;
 tree name;
 n64_enum_access_type access = (n64_enum_access_type)((access_decls)->list.purpose);
 int i = ((method_vec)->vec.a[0]) ? 0 : 1;
 tree tmp;

 if (((n64_enum_tree_code) (fdecl)->common.code) == TREE_LIST)
   {
     flist = fdecl;
     fdecl = ((flist)->list.value);
   }

 name = ((fdecl)->decl.name);

 for (; i < n_methods; i++)
   if (((((method_vec)->vec.a[i]))->decl.name) == name)
     {
       cp_error ("cannot adjust access to `%#D' in `%#T'", fdecl, t);
       cp_error_at ("  because of local method `%#D' with same name",
      ((method_vec)->vec.a[i]));
       fdecl = (tree) 
              ((void *)0)
                       ;
       break;
     }

 if (! fdecl)
   continue;

 for (tmp = fields; tmp; tmp = ((tmp)->common.chain))
   if (((tmp)->decl.name) == name)
     {
       cp_error ("cannot adjust access to `%#D' in `%#T'", fdecl, t);
       cp_error_at ("  because of local field `%#D' with same name", tmp);
       fdecl = (tree) 
              ((void *)0)
                       ;
       break;
     }

 if (!fdecl)
   continue;


 if (flist)
   {
     fdecl = ((flist)->list.value);
     while (fdecl)
       {
  if (alter_access (t, fdecl, access) == 0)
    break;
  fdecl = (((fdecl)->decl.lang_specific)->chain);
       }
   }
 else
   alter_access (t, fdecl, access);
      }

  }

  if (vfield == (tree) 
               ((void *)0) 
                         && has_virtual)
    {


      vfield = build_lang_field_decl (FIELD_DECL, get_vfield_name (t),
          ptr_type_node);



      ((vfield)->decl.assembler_name) = get_identifier (".vf");
      ((t)->type.minval) = vfield;
      ((vfield)->decl.virtual_flag) = 1;
      ((vfield)->decl.context) = t;
      (((vfield)->decl.lang_specific)->decl_flags.context) = t;
      ((vfield)->decl.vindex) = t;
      ((vfield)->decl.saved_insns.r) = (rtx) 0;
      ((vfield)->decl.saved_insns.i) = 0;
      ((vfield)->decl.frame_size.u) = ((ptr_type_node)->type.align);
      if ((((t)->type.lang_specific)->rtti))
 {

   ((vfield)->common.chain) = fields;
   fields = vfield;
 }
      else if (last_x)
 {
   my_friendly_assert (((last_x)->common.chain) == (tree) 
                                             ((void *)0)
                                                      , 175);
   ((last_x)->common.chain) = vfield;
   last_x = vfield;
 }
      else
 fields = vfield;
      vfields = chainon (vfields, (((t)->type.lang_specific)->as_list));
    }







  while (fields && ((fields)->decl.bit_field_flag)
  && ((fields)->decl.initial))
    fields = ((fields)->common.chain);

  for (x = fields; x;)
    {
      if (((x)->common.chain) && ((((x)->common.chain))->decl.bit_field_flag)
   && ((((x)->common.chain))->decl.initial))
 ((x)->common.chain) = ((((x)->common.chain))->common.chain);
      else
 x = ((x)->common.chain);
    }

  delete_duplicate_fields (fields);




  if (! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    {
      int n_methods = method_vec ? ((method_vec)->vec.length) : 0;
      for (x = fields; x; x = ((x)->common.chain))
 {
   tree name = ((x)->decl.name);
   int i = 1;
   for (; i < n_methods; ++i)
     if (((((method_vec)->vec.a[i]))->decl.name) == name)
       {
  cp_error_at ("data member `%#D' conflicts with", x);
  cp_error_at ("function member `%#D'",
        ((method_vec)->vec.a[i]));
  break;
       }
 }
    }




  ((t)->type.values) = fields;



  ((t)->type.align) = round_up_size;


  if (n_baseclasses)
    {
      tree pseudo_basetype = ((base_layout_decl)->common.type);

      ((base_layout_decl)->common.chain) = ((t)->type.values);
      ((t)->type.values) = base_layout_decl;

      ((pseudo_basetype)->type.size) = (((t)->type.lang_specific)->size);
      ((pseudo_basetype)->type.mode) = ((t)->type.mode);
      ((pseudo_basetype)->type.align) = (((t)->type.lang_specific)->align);
      ((base_layout_decl)->decl.frame_size.u) = ((pseudo_basetype)->type.align);

      ((base_layout_decl)->decl.size) = (tree) 
                                    ((void *)0)
                                             ;
    }

  layout_type (t);

  {
    tree field;
    for (field = ((t)->type.values); field; field = ((field)->common.chain))
      {
 if (((field)->common.static_flag))
   continue;
 if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
   continue;
 if (((field)->decl.name) == (tree) 
                         ((void *)0)
     
    && ((n64_enum_tree_code) (((field)->common.type))->common.code) == UNION_TYPE)
   {
     tree uelt = ((((field)->common.type))->type.values);
     for (; uelt; uelt = ((uelt)->common.chain))
       {
  if (((n64_enum_tree_code) (uelt)->common.code) != FIELD_DECL)
    continue;

  if (((uelt)->common.private_flag))
    cp_pedwarn_at ("private member `%#D' in anonymous union",
     uelt);
  else if (((uelt)->common.protected_flag))
    cp_pedwarn_at ("protected member `%#D' in anonymous union",
     uelt);

  ((uelt)->decl.context) = ((field)->decl.context);
  ((uelt)->decl.arguments) = ((field)->decl.arguments);
       }

     ((field)->decl.arguments) = integer_zero_node;
   }
      }
  }

  if (n_baseclasses)
    ((t)->type.values) = ((((t)->type.values))->common.chain);


  if (integer_zerop (((t)->type.size)))
    ((t)->type.size) = ((char_type_node)->type.size);





  if (((n64_enum_tree_code) (((t)->type.name))->common.code) == TYPE_DECL)
    layout_decl (((t)->type.name), 0);




  doing_hard_virtuals = 1;
  pending_hard_virtuals = nreverse (pending_hard_virtuals);

  if ((((t)->common.lang_flag_3)))
    {
      tree vbases;

      max_has_virtual = layout_vbasetypes (t, max_has_virtual);
      vbases = (((t)->type.lang_specific)->vbases);
      (((t)->type.lang_specific)->type_flags.n_vancestors) = list_length (vbases);
      {


 tree binfos = (((((t)->type.binfo)))->vec.a[4]);
 int i, n_baseclasses = binfos ? ((binfos)->vec.length) : 0;

 for (i = 0; i < n_baseclasses; i++)
   {
     tree base_binfo = ((binfos)->vec.a[i]);
     tree basetype = ((base_binfo)->common.type);
     tree vbases;

     vbases = (((basetype)->type.lang_specific)->vbases);
     while (vbases)
       {
  merge_overrides (binfo_member (((vbases)->common.type),
            (((t)->type.lang_specific)->vbases)),
     vbases, 1, t);
  vbases = ((vbases)->common.chain);
       }
   }
 }



      vbases = (((t)->type.lang_specific)->vbases);
      while (vbases)
 {




   fixup_vtable_deltas (vbases, 1, t);
   vbases = ((vbases)->common.chain);
 }
    }




  if (vfield != (tree) 
               ((void *)0)
      
     && ((vfield)->decl.context) != t)
    {
      tree binfo = get_binfo (((vfield)->decl.context), t, 0);
      tree offset = (((binfo))->vec.a[1]);

      vfield = copy_node (vfield);
      copy_lang_decl (vfield);

      if (! integer_zerop (offset))
 offset = size_binop (MULT_EXPR, offset, size_int (8));
      ((vfield)->decl.context) = t;
      (((vfield)->decl.lang_specific)->decl_flags.context) = t;
      ((vfield)->decl.arguments)
 = size_binop (PLUS_EXPR, offset, ((vfield)->decl.arguments));
      ((t)->type.minval) = vfield;
    }





  if (has_virtual > max_has_virtual)
    max_has_virtual = has_virtual;
  if (max_has_virtual > 0)
    (((t)->common.lang_flag_2)) = 1;

  if (flag_rtti && (((t)->common.lang_flag_2)) && !pending_hard_virtuals)
    modify_all_vtables (t, (tree) 
                          ((void *)0)
                                   , (tree) 
                                     ((void *)0)
                                              );

  while (pending_hard_virtuals)
    {
      modify_all_vtables (t,
     ((pending_hard_virtuals)->list.purpose),
     ((pending_hard_virtuals)->list.value));
      pending_hard_virtuals = ((pending_hard_virtuals)->common.chain);
    }
  doing_hard_virtuals = 0;



  if (pending_virtuals || (flag_rtti && (((t)->common.lang_flag_2))))
    {
      pending_virtuals = nreverse (pending_virtuals);

      if (first_vfn_base_index < 0)
 {

   pending_virtuals = tree_cons ((tree) 
                                ((void *)0)
                                         , (tree) 
                                           ((void *)0)
                                                    , pending_virtuals);


   if (flag_vtable_thunks)
     pending_virtuals = tree_cons ((tree) 
                                  ((void *)0)
                                           , (tree) 
                                             ((void *)0)
                                                      , pending_virtuals);

   set_rtti_entry (pending_virtuals, integer_zero_node, t);
   build_vtable ((tree) 
                ((void *)0)
                         , t);
 }
      else
 {
   tree offset;



   if (! (((((t)->type.binfo))->common.static_flag)?(((((((t)->type.binfo))->common.type))->type.lang_specific)->type_flags.marked4):((((t)->type.binfo))->common.lang_flag_4)))
     build_vtable (((((((t)->type.binfo))->vec.a[4]))->vec.a[first_vfn_base_index]), t);

   offset = get_derived_offset (((t)->type.binfo), (tree) 
                                               ((void *)0)
                                                        );
   offset = size_binop (MINUS_EXPR, integer_zero_node, offset);
   set_rtti_entry ((((((t)->type.binfo)))->vec.a[3]), offset, t);
 }






      (((t)->type.lang_specific)->type_flags.needs_virtual_reinit) = 1;
    }
  else if (first_vfn_base_index >= 0)
    {
      tree binfo = ((((((t)->type.binfo))->vec.a[4]))->vec.a[first_vfn_base_index]);







      if ((((((t)->type.binfo)))->vec.a[2]) == (tree) 
                                  ((void *)0)
                                           )
 (((((t)->type.binfo)))->vec.a[2]) = (((binfo))->vec.a[2]);
      if ((((((t)->type.binfo)))->vec.a[3]) == (tree) 
                                    ((void *)0)
                                             )
 (((((t)->type.binfo)))->vec.a[3]) = (((binfo))->vec.a[3]);
      if ((((((t)->type.binfo)))->vec.a[2]) != (((binfo))->vec.a[2]))
 (((t)->type.lang_specific)->type_flags.needs_virtual_reinit) = 1;
    }

  if (max_has_virtual || first_vfn_base_index >= 0)
    {
      (((t)->type.lang_specific)->vsize) = has_virtual;
      if (first_vfn_base_index >= 0)
 {
   if (pending_virtuals)
     (((((t)->type.binfo)))->vec.a[3]) = chainon ((((((t)->type.binfo)))->vec.a[3]),
      pending_virtuals);
 }
      else if (has_virtual)
 {
   (((((t)->type.binfo)))->vec.a[3]) = pending_virtuals;
   if (write_virtuals >= 0)
     (((((((t)->type.binfo)))->vec.a[2]))->decl.virtual_flag) = 1;
 }
    }


  if (has_virtual)
    {
      tree atype, itype;

      if (((vfield)->common.type) == ptr_type_node)
 {





   itype = build_index_type (size_int (has_virtual));
   atype = build_array_type (vtable_entry_type, itype);
   layout_type (atype);
   ((vfield)->common.type) = build_pointer_type (atype);
 }
      else
 {
   atype = ((((vfield)->common.type))->common.type);

   if (has_virtual != ((((((atype)->type.values))->type.maxval))->int_cst.int_cst_low))
     {



       itype = build_index_type (size_int (has_virtual));
       atype = build_array_type (vtable_entry_type, itype);
       layout_type (atype);
       vfield = copy_node (vfield);
       ((vfield)->common.type) = build_pointer_type (atype);
     }
 }

      ((t)->type.minval) = vfield;
      if ((((((((t)->type.binfo)))->vec.a[2]))->common.type) != atype)
 {
   (((((((t)->type.binfo)))->vec.a[2]))->common.type) = atype;
   (((((((t)->type.binfo)))->vec.a[2]))->decl.size) = 0;
   layout_decl ((((((t)->type.binfo)))->vec.a[2]), 0);


   (((((((t)->type.binfo)))->vec.a[2]))->decl.frame_size.u)
     = ((((double_type_node)->type.align)) > ((((((((t)->type.binfo)))->vec.a[2]))->decl.frame_size.u)) ? (((double_type_node)->type.align)) : ((((((((t)->type.binfo)))->vec.a[2]))->decl.frame_size.u)))
                                        ;
 }
    }
  else if (first_vfn_base_index >= 0)
    ((t)->type.minval) = vfield;
  (((t)->type.lang_specific)->vfields) = vfields;

  finish_struct_bits (t, max_has_virtual);



  for (x = fields; x; x = ((x)->common.chain))
    {
      if (((n64_enum_tree_code) (x)->common.code) == VAR_DECL && ((x)->common.static_flag)
   && ((x)->common.type) == t)
 {
   ((x)->decl.mode) = ((t)->type.mode);
   make_decl_rtl (x, 
                    ((void *)0)
                        , 0);
 }
    }



  if ((((t)->type.lang_specific)->tags))
    {
      x = (((t)->type.lang_specific)->tags);
      last_x = tree_last (((t)->type.values));
      while (x)
 {
   tree tag = ((((x)->list.value))->type.name);



   if (chain_member (tag, ((t)->type.values)))
       {
  x = ((x)->common.chain);
  continue;
       }


   if (write_symbols == DWARF_DEBUG)
     {


       ((tag)->decl.ignored_flag) = 1;
     }


   (((((x)->list.value))->common.lang_flag_0)) = 0;
   x = ((x)->common.chain);
   last_x = chainon (last_x, tag);
 }
      if (((t)->type.values) == (tree) 
                            ((void *)0)
                                     )
 ((t)->type.values) = last_x;
      (((t)->type.lang_specific)->type_flags.local_typedecls) = 1;
    }

  if ((((t)->type.lang_flag_1)))
    {
      tree vfields = (((t)->type.lang_specific)->vfields);

      while (vfields)
 {



   if ((((vfields)->list.purpose) ? ((((vfields)->list.purpose))->common.type) : (tree) 
      ((void *)0)
      ))
     ((vfields)->common.addressable_flag) = 1;
   vfields = ((vfields)->common.chain);
 }
      if (any_default_members != 0)
 build_class_init_list (t);
    }
  else if (((t)->type.needs_constructing_flag))
    build_class_init_list (t);

  if (! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    embrace_waiting_friends (t);


  do_inline_function_hair (t, (((t)->type.noncopied_parts)));
  (((t)->type.noncopied_parts)) = 0;

  if ((((t)->type.lang_specific)->vsize) != 0)
    {
      ((t)->type.noncopied_parts) = build_tree_list (default_conversion ((((((t)->type.binfo)))->vec.a[2])), vfield);

      if (warn_nonvdtor && (((t)->type.lang_flag_2))
   && ((((method_vec)->vec.a[0]))->decl.vindex) == (tree) 
                                                   ((void *)0)
                                                            )
 cp_warning ("`%#T' has virtual functions but non-virtual destructor",
      t);
    }



  finish_vtbls (((t)->type.binfo), 1, t);
  (((t)->type.lang_specific)->type_flags.being_defined) = 0;
  hack_incomplete_structures (t);





  if (current_class_type)
    popclass (0);
  else
    error ("trying to finish struct, but kicked out due to previous parse errors.");

  resume_momentary (old);

  if (flag_cadillac)
    cadillac_finish_struct (t);
  if (write_symbols != DWARF_DEBUG)
    {







      if (((t)->type.maxval))
 {
   extern tree pending_vtables;



   if ((((t)->common.lang_flag_2)) && write_virtuals == 2)
     ((((t)->type.name))->decl.external_flag)
       = (value_member ((((((t)->type.name))->decl.name)), pending_vtables) == 0);
   else if ((((t)->type.lang_specific)->type_flags.interface_only))
     ((((t)->type.name))->decl.external_flag) = 1;
   else if ((((t)->type.lang_specific)->type_flags.interface_unknown))

     ((((t)->type.name))->decl.external_flag) = 1;
 }
      else if ((((t)->type.lang_specific)->type_flags.interface_only))
 ((((t)->type.name))->decl.external_flag) = 1;
    }


  rest_of_type_compilation (t, toplevel_bindings_p ());

  return t;
}

tree
finish_struct(tree t, tree list_of_fieldlists, int warn_anon) asm("_finish_struct");
tree
finish_struct(tree t, tree list_of_fieldlists, int warn_anon)
{
  tree fields = (tree) 
               ((void *)0)
                        , fn_fields, *tail;
  tree *tail_user_methods = &(((t)->type.lang_specific)->methods);
  tree name = ((t)->type.name);
  tree x, last_x = (tree) 
                  ((void *)0)
                           ;
  n64_enum_access_type access;

  if (((n64_enum_tree_code) (name)->common.code) == TYPE_DECL)
    {
      extern int lineno;

      ((name)->decl.filename) = input_filename;





      if (((name)->decl.linenum))
 ((name)->decl.linenum) = lineno;
      (((t)->type.lang_specific)->linenum) = lineno;
      name = ((name)->decl.name);
    }


  if ((((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
    append_signature_fields (list_of_fieldlists);

  tail = &fn_fields;
  if (last_x && list_of_fieldlists)
    ((last_x)->common.chain) = ((list_of_fieldlists)->list.value);



  if ((((t)->type.lang_specific)->type_flags.declared_class) == 0)
    {
      if (list_of_fieldlists
   && ((list_of_fieldlists)->list.purpose) == (tree)access_default)
 ((list_of_fieldlists)->list.purpose) = (tree)access_public;
    }
  else if (list_of_fieldlists
    && ((list_of_fieldlists)->list.purpose) == (tree)access_default)
    ((list_of_fieldlists)->list.purpose) = (tree)access_private;

  while (list_of_fieldlists)
    {
      access = (n64_enum_access_type)((list_of_fieldlists)->list.purpose);

      for (x = ((list_of_fieldlists)->list.value); x; x = ((x)->common.chain))
 {
   ((x)->common.private_flag) = access == access_private;
   ((x)->common.protected_flag) = access == access_protected;



   if (((n64_enum_tree_code) (x)->common.code) != TYPE_DECL
       && ((n64_enum_tree_code) (x)->common.code) != CONST_DECL && ((n64_enum_tree_code) (x)->common.code) != VAR_DECL)
     {
       tree name = ((x)->decl.name);
       tree icv;


       if (name && ((n64_enum_tree_code) (name)->common.code) == IDENTIFIER_NODE)
  icv = (((struct n64_tag_lang_identifier *)(name))->class_value);
       else
  icv = (tree) 
       ((void *)0)
                ;

       if (icv

    && name != constructor_name (current_class_type)

    && id_in_current_class (name)

    && !(((n64_enum_tree_code) (icv)->common.code) == TYPE_DECL
         && ((icv)->decl.context) == t))
  {
    cp_error_at ("declaration of identifier `%D' as `%+#D'",
          name, x);
    cp_error_at ("conflicts with other use in class as `%#D'",
          icv);
  }
     }

   if (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL)
     {
       if (last_x)
  ((last_x)->common.chain) = ((x)->common.chain);

       *tail = x;
       tail = &((x)->common.chain);
       *tail_user_methods = x;
       tail_user_methods = &(((x)->decl.lang_specific)->next_method);
       continue;
     }
   if (! fields)
     fields = x;
   last_x = x;
 }
      list_of_fieldlists = ((list_of_fieldlists)->common.chain);

      if (last_x)
 {
   ((last_x)->common.chain) = (tree) 
                        ((void *)0)
                                 ;

   if (list_of_fieldlists
       && ((list_of_fieldlists)->list.value)
       && ((n64_enum_tree_code) (((list_of_fieldlists)->list.value))->common.code) != FUNCTION_DECL)
     ((last_x)->common.chain) = ((list_of_fieldlists)->list.value);
 }
    }

  *tail = (tree) 
         ((void *)0)
                  ;
  *tail_user_methods = (tree) 
                      ((void *)0)
                               ;
  ((t)->type.values) = fields;

  if (0 && processing_template_defn)
    {
      ((t)->type.maxval) = finish_struct_methods (t, fn_fields, 1);
      return t;
    }
  else
    return finish_struct_1 (t, warn_anon);
}







int
resolves_to_fixed_type_p(tree instance, int *nonnull) asm("_resolves_to_fixed_type_p");
int
resolves_to_fixed_type_p(tree instance, int *nonnull)
{
  switch (((n64_enum_tree_code) (instance)->common.code))
    {
    case INDIRECT_REF:

      if (((instance)->common.type)
   == ((((((instance)->exp.operands[0]))->common.type))->common.type))
 instance = ((instance)->exp.operands[0]);

    case CALL_EXPR:

      if ((((instance)->common.lang_flag_4)))
 {
   if (nonnull)
     *nonnull = 1;
   return 1;
 }
      return 0;

    case SAVE_EXPR:

      if ((((instance)->common.lang_flag_4)))
 {
   if (nonnull)
     *nonnull = 1;
   return 1;
 }
      return resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);

    case RTL_EXPR:

      if ((((instance)->common.lang_flag_1)))
 {
   if (nonnull)
     *nonnull = 1;
   return 1;
 }
      return 0;

    case PLUS_EXPR:
    case MINUS_EXPR:
      if (((n64_enum_tree_code) (((instance)->exp.operands[1]))->common.code) == INTEGER_CST)

 resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);
      if (((n64_enum_tree_code) (((instance)->exp.operands[0]))->common.code) == ADDR_EXPR)
 return resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);
      return 0;

    case NOP_EXPR:
    case CONVERT_EXPR:
      return resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);

    case ADDR_EXPR:
      if (nonnull)
 *nonnull = 1;
      return resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);

    case COMPONENT_REF:
      return resolves_to_fixed_type_p (((instance)->exp.operands[1]), nonnull);

    case WITH_CLEANUP_EXPR:
      if (((n64_enum_tree_code) (((instance)->exp.operands[0]))->common.code) == ADDR_EXPR)
 return resolves_to_fixed_type_p (((instance)->exp.operands[0]), nonnull);

    case VAR_DECL:
    case FIELD_DECL:
      if (((n64_enum_tree_code) (((instance)->common.type))->common.code) == ARRAY_TYPE
   && (((((((instance)->common.type))->common.type))->type.lang_flag_5)))
 {
   if (nonnull)
     *nonnull = 1;
   return 1;
 }

    case TARGET_EXPR:
    case PARM_DECL:
      if ((((((instance)->common.type))->type.lang_flag_5)))
 {
   if (nonnull)
     *nonnull = 1;
   return 1;
 }
      else if (nonnull)
 {
   if (instance == current_class_decl
       && flag_this_is_variable <= 0)
     {

       *nonnull = ! (((((current_function_decl)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((current_function_decl)->decl.assembler_name))->identifier.pointer)[2] == '_');

       if (flag_this_is_variable < 0)
  return 1;
     }
   else if (((n64_enum_tree_code) (((instance)->common.type))->common.code) == REFERENCE_TYPE)

     *nonnull = 1;
 }
      return 0;

    default:
      return 0;
    }
}

void
init_class_processing(void) asm("_init_class_processing");
void
init_class_processing(void)
{
  current_class_depth = 0;
  current_class_stacksize = 10;
  current_class_base = (tree *)xmalloc(current_class_stacksize * sizeof (tree));
  current_class_stack = current_class_base;

  current_lang_stacksize = 10;
  current_lang_base = (tree *)xmalloc(current_lang_stacksize * sizeof (tree));
  current_lang_stack = current_lang_base;


  the_null_vtable_entry = build_vtable_entry (integer_zero_node, integer_zero_node);
  base_layout_decl = build_lang_field_decl (FIELD_DECL, (tree) 
                                                       ((void *)0)
                                                                , error_mark_node);
  ((base_layout_decl)->common.type) = make_node (RECORD_TYPE);

  gcc_obstack_init (&class_obstack);
}
void
pushclass(tree type, int modify) asm("_pushclass");
void
pushclass(tree type, int modify)
{
  push_memoized_context (type, modify);

  current_class_depth++;
  *current_class_stack++ = current_class_name;
  *current_class_stack++ = current_class_type;
  if (current_class_stack >= current_class_base + current_class_stacksize)
    {
      current_class_base =
 (tree *)xrealloc (current_class_base,
     sizeof (tree) * (current_class_stacksize + 10));
      current_class_stack = current_class_base + current_class_stacksize;
      current_class_stacksize += 10;
    }

  current_class_name = ((type)->type.name);
  if (((n64_enum_tree_code) (current_class_name)->common.code) == TYPE_DECL)
    current_class_name = ((current_class_name)->decl.name);
  current_class_type = type;

  if (previous_class_type != (tree) 
                            ((void *)0)
      
     && (type != previous_class_type || ((previous_class_type)->type.size) == (tree) 
                                                                           ((void *)0)
                                                                                    )
      && current_class_depth == 1)
    {

      popclass (-1);
      previous_class_type = (tree) 
                           ((void *)0)
                                    ;
    }

  pushlevel_class ();

  if (modify)
    {
      tree tags;
      tree this_fndecl = current_function_decl;

      if (current_function_decl
   && ((current_function_decl)->decl.context)
   && ((n64_enum_tree_code) (((current_function_decl)->decl.context))->common.code) == FUNCTION_DECL)
 current_function_decl = ((current_function_decl)->decl.context);
      else
 current_function_decl = (tree) 
                        ((void *)0)
                                 ;

      if (((n64_enum_tree_code) (type)->common.code) == UNINSTANTIATED_P_TYPE)
 declare_uninstantiated_type_level ();
      else if (type != previous_class_type || current_class_depth > 1)
 {
   build_mi_matrix (type);
   push_class_decls (type);
   free_mi_matrix ();
   if (current_class_depth == 1)
     previous_class_type = type;
 }
      else
 {
   tree item;




   set_class_shadows (previous_class_values);
   for (item = previous_class_values; item; item = ((item)->common.chain))
     {
       tree id = ((item)->list.purpose);
       tree decl = (((struct n64_tag_lang_identifier *)(id))->class_value);

       if (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL)
  set_identifier_type_value (id, ((decl)->common.type));
     }
   unuse_fields (type);
 }

      if ((((struct n64_tag_lang_identifier *)((((((type)->type.name))->decl.name))))->class_template_info))
 overload_template_name (current_class_name, 0);

      for (tags = (((type)->type.lang_specific)->tags); tags; tags = ((tags)->common.chain))
 {
   (((((tags)->list.value))->common.lang_flag_0)) = 1;
   if (! ((tags)->list.purpose))
     continue;
   pushtag (((tags)->list.purpose), ((tags)->list.value), 0);
 }

      current_function_decl = this_fndecl;
    }

  if (flag_cadillac)
    cadillac_push_class (type);
}





void
popclass(int modify) asm("_popclass");
void
popclass(int modify)
{
  if (flag_cadillac)
    cadillac_pop_class ();

  if (modify < 0)
    {

      tree tags = (((previous_class_type)->type.lang_specific)->tags);
      tree t;




      for (t = previous_class_values; t; t = ((t)->common.chain))
 (((struct n64_tag_lang_identifier *)(((t)->list.purpose)))->class_value) = (tree) 
                                            ((void *)0)
                                                     ;
      while (tags)
 {
   (((((tags)->list.value))->common.lang_flag_0)) = 0;
   tags = ((tags)->common.chain);
 }
      goto ret;
    }

  if (modify)
    {


      tree tags = (((current_class_type)->type.lang_specific)->tags);

      while (tags)
 {
   (((((tags)->list.value))->common.lang_flag_0)) = 0;
   tags = ((tags)->common.chain);
 }
      if ((((struct n64_tag_lang_identifier *)((((((current_class_type)->type.name))->decl.name))))->class_template_info))
 undo_template_name_overload (current_class_name, 0);
    }



  poplevel_class (! modify);




  if (modify)
    pop_class_decls (current_class_type);

  current_class_depth--;
  current_class_type = *--current_class_stack;
  current_class_name = *--current_class_stack;

  pop_memoized_context (modify);

 ret:
  ;
}
void
push_nested_class(tree type, int modify) asm("_push_nested_class");
void
push_nested_class(tree type, int modify)
{
  tree context;

  if (type == (tree) 
             ((void *)0) 
                       || type == error_mark_node || ! (((type)->type.lang_flag_5)))
    return;

  context = ((((type)->type.name))->decl.context);

  if (context && ((n64_enum_tree_code) (context)->common.code) == RECORD_TYPE)
    push_nested_class (context, 2);
  pushclass (type, modify);
}



void
pop_nested_class(int modify) asm("_pop_nested_class");
void
pop_nested_class(int modify)
{
  tree context = ((((current_class_type)->type.name))->decl.context);

  popclass (modify);
  if (context && ((n64_enum_tree_code) (context)->common.code) == RECORD_TYPE)
    pop_nested_class (modify);
}




void
push_lang_context(tree name) asm("_push_lang_context");
void
push_lang_context(tree name)
{
  *current_lang_stack++ = current_lang_name;
  if (current_lang_stack >= current_lang_base + current_lang_stacksize)
    {
      current_lang_base =
 (tree *)xrealloc (current_lang_base,
     sizeof (tree) * (current_lang_stacksize + 10));
      current_lang_stack = current_lang_base + current_lang_stacksize;
      current_lang_stacksize += 10;
    }

  if (name == lang_name_cplusplus)
    {
      strict_prototype = strict_prototypes_lang_cplusplus;
      current_lang_name = name;
    }
  else if (name == lang_name_c)
    {
      strict_prototype = strict_prototypes_lang_c;
      current_lang_name = name;
    }
  else
    error ("language string `\"%s\"' not recognized", ((name)->identifier.pointer));

  if (flag_cadillac)
    cadillac_push_lang (name);
}


void
pop_lang_context(void) asm("_pop_lang_context");
void
pop_lang_context(void)
{
  if (flag_cadillac)
    cadillac_pop_lang ();

  current_lang_name = *--current_lang_stack;
  if (current_lang_name == lang_name_cplusplus)
    strict_prototype = strict_prototypes_lang_cplusplus;
  else if (current_lang_name == lang_name_c)
    strict_prototype = strict_prototypes_lang_c;
}

int
root_lang_context_p(void) asm("_root_lang_context_p");
int
root_lang_context_p(void)
{
  return current_lang_stack == current_lang_base;
}
tree
instantiate_type(tree lhstype, tree rhs, int complain) asm("_instantiate_type");
tree
instantiate_type(tree lhstype, tree rhs, int complain)
{
  if (((n64_enum_tree_code) (lhstype)->common.code) == LANG_TYPE)
    {
      if (complain)
 error ("not enough type information");
      return error_mark_node;
    }

  if (((rhs)->common.type) != (tree) 
                        ((void *)0) 
                                  && ! (type_unknown_p (rhs)))
    return rhs;






  switch (((n64_enum_tree_code) (rhs)->common.code))
    {
    case TYPE_EXPR:
    case CONVERT_EXPR:
    case SAVE_EXPR:
    case CONSTRUCTOR:
    case BUFFER_REF:
      my_friendly_abort (177);
      return error_mark_node;

    case INDIRECT_REF:
    case ARRAY_REF:
      ((rhs)->common.type) = lhstype;
      lhstype = build_pointer_type (lhstype);
      ((rhs)->exp.operands[0])
 = instantiate_type (lhstype, ((rhs)->exp.operands[0]), complain);
      if (((rhs)->exp.operands[0]) == error_mark_node)
 return error_mark_node;

      return rhs;

    case NOP_EXPR:
      rhs = copy_node (((rhs)->exp.operands[0]));
      ((rhs)->common.type) = unknown_type_node;
      return instantiate_type (lhstype, rhs, complain);

    case COMPONENT_REF:
      {
 tree field = ((rhs)->exp.operands[1]);
 if (((n64_enum_tree_code) (field)->common.code) == TREE_LIST)
   {
     tree function = instantiate_type (lhstype, field, complain);
     if (function == error_mark_node)
       return error_mark_node;
     my_friendly_assert (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL, 185);
     if (((function)->decl.vindex))
       {
  tree base = ((rhs)->exp.operands[0]);
  tree base_ptr = build_unary_op (ADDR_EXPR, base, 0);
  if (base_ptr == error_mark_node)
    return error_mark_node;
  base_ptr = convert_pointer_to (((function)->decl.context), base_ptr);
  if (base_ptr == error_mark_node)
    return error_mark_node;
  return build_vfn_ref (&base_ptr, base, ((function)->decl.vindex));
       }
     return function;
   }

 my_friendly_assert (((n64_enum_tree_code) (field)->common.code) == FIELD_DECL, 178);
 my_friendly_assert (!(((n64_enum_tree_code) (((field)->common.type))->common.code) == FUNCTION_TYPE
         || ((n64_enum_tree_code) (((field)->common.type))->common.code) == METHOD_TYPE),
       179);

 ((rhs)->common.type) = lhstype;


 while (field && ((field)->common.type) != lhstype)
   field = (((field)->decl.lang_specific)->chain);
 if (field)
   {
     ((rhs)->exp.operands[1]) = field;
     return rhs;
   }


 field = ((rhs)->exp.operands[1]);
 while (field && ! comptypes (lhstype, ((field)->common.type), 0))
   field = (((field)->decl.lang_specific)->chain);
 if (field)
   {
     ((rhs)->exp.operands[1]) = field;
     field = (((field)->decl.lang_specific)->chain);
     while (field && ! comptypes (lhstype, ((field)->common.type), 0))
       field = (((field)->decl.lang_specific)->chain);
     if (field)
       {
  if (complain)
    error ("ambiguous overload for COMPONENT_REF requested");
  return error_mark_node;
       }
   }
 else
   {
     if (complain)
       error ("no appropriate overload exists for COMPONENT_REF");
     return error_mark_node;
   }
 return rhs;
      }

    case TREE_LIST:
      {
 tree elem, baselink, name;
 int globals = overloaded_globals_p (rhs);
 if ((((n64_enum_tree_code) (lhstype)->common.code) == RECORD_TYPE && ((lhstype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
   lhstype = (((((((((((((lhstype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

 if (((n64_enum_tree_code) (lhstype)->common.code) == POINTER_TYPE)
   if (((n64_enum_tree_code) (((lhstype)->common.type))->common.code) == FUNCTION_TYPE
       || ((n64_enum_tree_code) (((lhstype)->common.type))->common.code) == METHOD_TYPE)
     lhstype = ((lhstype)->common.type);
   else
     {
       if (complain)
  error ("invalid type combination for overload");
       return error_mark_node;
     }

 if (((n64_enum_tree_code) (lhstype)->common.code) != FUNCTION_TYPE && globals > 0)
   {
     if (complain)
       cp_error ("cannot resolve overloaded function `%D' based on non-function type",
       ((rhs)->list.purpose));
     return error_mark_node;
   }

 if (globals > 0)
   {
     elem = get_first_fn (rhs);
     while (elem)
       if (! comptypes (lhstype, ((elem)->common.type), 1))
  elem = (((elem)->decl.lang_specific)->chain);
       else
  return elem;


     {
       tree save_elem = 0;
       for (elem = get_first_fn (rhs); elem; elem = (((elem)->decl.lang_specific)->chain))
  if (((n64_enum_tree_code) (elem)->common.code) == TEMPLATE_DECL)
    {
      int n = ((((elem)->decl.arguments))->vec.length);
      tree *t = (tree *) 
                        __builtin_alloca((
                        sizeof (tree) * n
                        ))
                                                  ;
      int i, d = 0;
      i = type_unification (((elem)->decl.arguments), t,
       ((((elem)->common.type))->type.values),
       ((lhstype)->type.values), &d, 0);
      if (i == 0)
        {
   if (save_elem)
     {
       cp_error ("ambiguous template instantiation converting to `%#T'", lhstype);
       return error_mark_node;
     }
   save_elem = instantiate_template (elem, t);

   if (! comptypes (((lhstype)->common.type),
      ((((save_elem)->common.type))->common.type), 1))
     save_elem = 0;
        }
    }
       if (save_elem)
  return save_elem;
     }


     elem = get_first_fn (rhs);
     while (elem && comp_target_types (lhstype,
           ((elem)->common.type), 1) <= 0)
       elem = (((elem)->decl.lang_specific)->chain);
     if (elem)
       {
  tree save_elem = elem;
  elem = (((elem)->decl.lang_specific)->chain);
  while (elem && comp_target_types (lhstype,
        ((elem)->common.type), 0) <= 0)
    elem = (((elem)->decl.lang_specific)->chain);
  if (elem)
    {
      if (complain)
        {
   cp_error ("cannot resolve overload to target type `%#T'",
      lhstype);
   cp_error_at ("  ambiguity between `%#D'", save_elem);
   cp_error_at ("  and `%#D', at least", elem);
        }
      return error_mark_node;
    }
  return save_elem;
       }
     if (complain)
       {
  cp_error ("cannot resolve overload to target type `%#T'",
     lhstype);
  cp_error ("  because no suitable overload of function `%D' exists",
     ((rhs)->list.purpose));
       }
     return error_mark_node;
   }

 if ((((rhs)->common.lang_flag_0)))
   {

     rhs = lookup_fnfields (((current_class_type)->type.binfo),
       ((rhs)->list.purpose), 0);
   }
 else
   {
     my_friendly_assert (((rhs)->common.chain) == (tree) 
                                            ((void *)0)
                                                     , 181);
     if (((n64_enum_tree_code) (((rhs)->list.value))->common.code) == TREE_LIST)
       rhs = ((rhs)->list.value);
     my_friendly_assert (((n64_enum_tree_code) (((rhs)->list.value))->common.code) == FUNCTION_DECL,
    182);
   }

 for (baselink = rhs; baselink;
      baselink = next_baselink (baselink))
   {
     elem = ((baselink)->list.value);
     while (elem)
       if (comptypes (lhstype, ((elem)->common.type), 1))
  return elem;
       else
  elem = (((elem)->decl.lang_specific)->chain);
   }


 for (baselink = rhs; baselink;
      baselink = next_baselink (baselink))
   {
     elem = ((baselink)->list.value);
     while (elem && comp_target_types (lhstype,
           ((elem)->common.type), 1) <= 0)
       elem = (((elem)->decl.lang_specific)->chain);
     if (elem)
       {
  tree save_elem = elem;
  elem = (((elem)->decl.lang_specific)->chain);
  while (elem && comp_target_types (lhstype,
        ((elem)->common.type), 0) <= 0)
    elem = (((elem)->decl.lang_specific)->chain);
  if (elem)
    {
      if (complain)
        error ("ambiguous overload for overloaded method requested");
      return error_mark_node;
    }
  return save_elem;
       }
     name = ((((rhs)->list.value))->decl.name);
   }
 if (complain)
   cp_error ("no compatible member functions named `%D'", name);
 return error_mark_node;
      }

    case CALL_EXPR:

      my_friendly_abort (183);
      return error_mark_node;

    case PLUS_EXPR:
    case MINUS_EXPR:
    case COMPOUND_EXPR:
      ((rhs)->exp.operands[0])
 = instantiate_type (lhstype, ((rhs)->exp.operands[0]), complain);
      if (((rhs)->exp.operands[0]) == error_mark_node)
 return error_mark_node;
      ((rhs)->exp.operands[1])
 = instantiate_type (lhstype, ((rhs)->exp.operands[1]), complain);
      if (((rhs)->exp.operands[1]) == error_mark_node)
 return error_mark_node;

      ((rhs)->common.type) = lhstype;
      return rhs;

    case MULT_EXPR:
    case TRUNC_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case RDIV_EXPR:
    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
    case CEIL_MOD_EXPR:
    case ROUND_MOD_EXPR:
    case FIX_ROUND_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_CEIL_EXPR:
    case FIX_TRUNC_EXPR:
    case FLOAT_EXPR:
    case NEGATE_EXPR:
    case ABS_EXPR:
    case MAX_EXPR:
    case MIN_EXPR:
    case FFS_EXPR:

    case BIT_AND_EXPR:
    case BIT_IOR_EXPR:
    case BIT_XOR_EXPR:
    case LSHIFT_EXPR:
    case RSHIFT_EXPR:
    case LROTATE_EXPR:
    case RROTATE_EXPR:

    case PREINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case POSTINCREMENT_EXPR:
    case POSTDECREMENT_EXPR:
      if (complain)
 error ("invalid operation on uninstantiated type");
      return error_mark_node;

    case TRUTH_AND_EXPR:
    case TRUTH_OR_EXPR:
    case TRUTH_XOR_EXPR:
    case LT_EXPR:
    case LE_EXPR:
    case GT_EXPR:
    case GE_EXPR:
    case EQ_EXPR:
    case NE_EXPR:
    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
    case TRUTH_NOT_EXPR:
      if (complain)
 error ("not enough type information");
      return error_mark_node;

    case COND_EXPR:
      if (type_unknown_p (((rhs)->exp.operands[0])))
 {
   if (complain)
     error ("not enough type information");
   return error_mark_node;
 }
      ((rhs)->exp.operands[1])
 = instantiate_type (lhstype, ((rhs)->exp.operands[1]), complain);
      if (((rhs)->exp.operands[1]) == error_mark_node)
 return error_mark_node;
      ((rhs)->exp.operands[2])
 = instantiate_type (lhstype, ((rhs)->exp.operands[2]), complain);
      if (((rhs)->exp.operands[2]) == error_mark_node)
 return error_mark_node;

      ((rhs)->common.type) = lhstype;
      return rhs;

    case MODIFY_EXPR:
      ((rhs)->exp.operands[1])
 = instantiate_type (lhstype, ((rhs)->exp.operands[1]), complain);
      if (((rhs)->exp.operands[1]) == error_mark_node)
 return error_mark_node;

      ((rhs)->common.type) = lhstype;
      return rhs;

    case ADDR_EXPR:
      if ((((n64_enum_tree_code) (lhstype)->common.code) == RECORD_TYPE && ((lhstype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
 lhstype = (((((((((((((lhstype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      else if (((n64_enum_tree_code) (lhstype)->common.code) != POINTER_TYPE)
 {
   if (complain)
     error ("type for resolving address of overloaded function must be pointer type");
   return error_mark_node;
 }
      ((rhs)->common.type) = lhstype;
      lhstype = ((lhstype)->common.type);
      {
 tree fn = instantiate_type (lhstype, ((rhs)->exp.operands[0]), complain);
 if (fn == error_mark_node)
   return error_mark_node;
 mark_addressable (fn);
 ((rhs)->exp.operands[0]) = fn;
 ((rhs)->common.constant_flag) = staticp (fn);
      }
      return rhs;

    case ENTRY_VALUE_EXPR:
      my_friendly_abort (184);
      return error_mark_node;

    case ERROR_MARK:
      return error_mark_node;

    default:
      my_friendly_abort (185);
      return error_mark_node;
    }
}






static tree
get_vfield_name(tree type) asm("_get_vfield_name");
static tree
get_vfield_name(tree type)
{
  tree binfo = ((type)->type.binfo);
  char *buf;

  while ((((binfo))->vec.a[4])
  && ((((((((((binfo))->vec.a[4]))->vec.a[(0)]))->common.type))->common.lang_flag_2))
  && ! (((((((binfo))->vec.a[4]))->vec.a[(0)]))->common.static_flag))
    binfo = (((((binfo))->vec.a[4]))->vec.a[(0)]);

  type = ((binfo)->common.type);
  buf = (char *)
               __builtin_alloca((
               sizeof ("_vptr.%s") + ((((((((type)->type.name))->decl.name)))->identifier.length)) + 2
               ))
                                 
                                ;
  sprintf (buf, "_vptr.%s", ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
  return get_identifier (buf);
}

void
print_class_statistics(void) asm("_print_class_statistics");
void
print_class_statistics(void)
{
}





void
maybe_push_cache_obstack(void) asm("_maybe_push_cache_obstack");
void
maybe_push_cache_obstack(void)
{
  push_obstacks_nochange ();
  if (current_class_depth == 1)
    current_obstack = &permanent_obstack;
}

