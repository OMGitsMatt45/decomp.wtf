// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/function.c
/* Expands front end tree to back end RTL for GNU C-Compiler
   Copyright (C) 1987, 88, 89, 91-94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int save_tree_status(...) asm("_save_tree_status");
extern int save_storage_status(...) asm("_save_storage_status");
extern int save_emit_status(...) asm("_save_emit_status");
extern int init_emit(...) asm("_init_emit");
extern int save_expr_status(...) asm("_save_expr_status");
extern int save_stmt_status(...) asm("_save_stmt_status");
extern int restore_tree_status(...) asm("_restore_tree_status");
extern int restore_storage_status(...) asm("_restore_storage_status");
extern int restore_expr_status(...) asm("_restore_expr_status");
extern int restore_emit_status(...) asm("_restore_emit_status");
extern int restore_stmt_status(...) asm("_restore_stmt_status");
extern int push_obstacks(...) asm("_push_obstacks");
extern int rtx_free(...) asm("_rtx_free");
extern int remove_note(...) asm("_remove_note");
extern int mode_dependent_address_p(...) asm("_mode_dependent_address_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int init_recog(...) asm("_init_recog");
extern int resume_temporary_allocation(...) asm("_resume_temporary_allocation");
extern int preserve_data(...) asm("_preserve_data");
extern int rtl_in_current_obstack(...) asm("_rtl_in_current_obstack");
extern int validate_replace_rtx(...) asm("_validate_replace_rtx");
extern int reg_referenced_p(...) asm("_reg_referenced_p");
extern int mark_reg_pointer(...) asm("_mark_reg_pointer");
extern int max_reg_num(...) asm("_max_reg_num");
extern int regno_uninitialized(...) asm("_regno_uninitialized");
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int regno_clobbered_at_setjmp(...) asm("_regno_clobbered_at_setjmp");
extern int init_stmt_for_function(...) asm("_init_stmt_for_function");
extern int warning(...) asm("_warning");
extern int bc_globalize_label(...) asm("_bc_globalize_label");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern int bc_xstrdup(...) asm("_bc_xstrdup");
extern int bc_align_const(...) asm("_bc_align_const");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern int bc_emit_const(...) asm("_bc_emit_const");
extern int bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern int init_recog_no_volatile(...) asm("_init_recog_no_volatile");
extern int force_next_line_note(...) asm("_force_next_line_note");
extern int in_sequence_p(...) asm("_in_sequence_p");
extern int add_insn_after(...) asm("_add_insn_after");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_fixup_replacement;
struct n64_tag_function;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_temp_slot;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");



enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct n64_tag_temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);

extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");
int current_function_pops_args;




int current_function_returns_struct;




int current_function_returns_pcc_struct;



int current_function_needs_context;



int current_function_calls_setjmp;



int current_function_calls_longjmp;




int current_function_has_nonlocal_label;




int current_function_has_nonlocal_goto;



int current_function_contains_functions;




int current_function_calls_alloca;



int current_function_returns_pointer;




rtx current_function_epilogue_delay_list;





int current_function_args_size;




int current_function_pretend_args_size;




int current_function_outgoing_args_size;




rtx current_function_arg_offset_rtx;




int current_function_varargs;




int current_function_stdarg;




CUMULATIVE_ARGS current_function_args_info;



char *current_function_name;






rtx current_function_return_rtx;



int current_function_uses_const_pool;


int current_function_uses_pic_offset_table;


rtx current_function_internal_arg_pointer;


tree inline_function_decl;



int function_call_count;





tree nonlocal_labels;




rtx nonlocal_goto_handler_slot;





rtx nonlocal_goto_stack_level;





rtx cleanup_label;





rtx return_label;



rtx save_expr_regs;



rtx stack_slot_list;


tree rtl_expr_chain;



rtx tail_recursion_label;


rtx tail_recursion_reentry;






rtx arg_pointer_save_area;




int frame_offset;




static tree context_display;







static tree trampoline_list;


static rtx parm_birth_insn;
static rtx last_parm_insn;



static int max_parm_reg;




static rtx *parm_reg_stack_loc;
static int virtuals_instantiated;




void (*save_machine_status)(...);
void (*restore_machine_status)(...);





extern int rtx_equal_function_value_matters;
extern tree sequence_rtl_expr;
extern tree bc_runtime_type_code(...) asm("_bc_runtime_type_code");
extern rtx bc_build_calldesc(...) asm("_bc_build_calldesc");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern char *bc_end_function(void) asm("_bc_end_function");
struct n64_tag_temp_slot
{

  struct n64_tag_temp_slot *next;

  rtx slot;


  rtx address;

  int size;

  tree rtl_expr;

  char in_use;

  char addr_taken;

  int level;

  int keep;


  int base_offset;


  int full_size;
};



struct n64_tag_temp_slot *temp_slots;



int temp_slot_level;


static tree this_function_decl;


static rtx this_function_callinfo;



static char *this_function_bytecode;


static rtx this_function_calldesc;


int local_vars_size;


int stack_depth;


int max_stack_depth;


static int stmt_expr_depth;






struct n64_tag_fixup_replacement
{
  rtx old;
  rtx cxx_new;
  struct n64_tag_fixup_replacement *next;
};



static struct n64_tag_temp_slot *find_temp_slot_from_address (rtx) asm("_find_temp_slot_from_address");
static void put_reg_into_stack (struct n64_tag_function *, rtx, tree, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_put_reg_into_stack")

                ;
static void fixup_var_refs (rtx, n64_enum_machine_mode, int) asm("_fixup_var_refs");
static struct n64_tag_fixup_replacement
  *find_fixup_replacement (struct n64_tag_fixup_replacement **, rtx);
static void fixup_var_refs_insns (rtx, n64_enum_machine_mode, int, rtx, int) asm("_fixup_var_refs_insns")
               ;
static void fixup_var_refs_1 (rtx, n64_enum_machine_mode, rtx *, rtx, struct n64_tag_fixup_replacement **) asm("_fixup_var_refs_1")
                                        ;
static rtx fixup_memory_subreg (rtx, rtx, int) asm("_fixup_memory_subreg");
static rtx walk_fixup_memory_subreg (rtx, rtx, int) asm("_walk_fixup_memory_subreg");
static rtx fixup_stack_1 (rtx, rtx) asm("_fixup_stack_1");
static void optimize_bit_field (rtx, rtx, rtx *) asm("_optimize_bit_field");
static void instantiate_decls (tree, int) asm("_instantiate_decls");
static void instantiate_decls_1 (tree, int) asm("_instantiate_decls_1");
static void instantiate_decl (rtx, int, int) asm("_instantiate_decl");
static int instantiate_virtual_regs_1 (rtx *, rtx, int) asm("_instantiate_virtual_regs_1");
static void delete_handlers (void) asm("_delete_handlers");
static void pad_to_arg_alignment (struct n64_tag_args_size *, int) asm("_pad_to_arg_alignment");
static void pad_below (struct n64_tag_args_size *, n64_enum_machine_mode, tree) asm("_pad_below")
                 ;
static tree round_down (tree, int) asm("_round_down");
static rtx round_trampoline_addr (rtx) asm("_round_trampoline_addr");
static tree blocks_nreverse (tree) asm("_blocks_nreverse");
static int all_blocks (tree, tree *) asm("_all_blocks");
static int *record_insns (rtx) asm("_record_insns");
static int contains (rtx, int *) asm("_contains");


struct n64_tag_function *outer_function_chain;




struct n64_tag_function *
find_function_data(tree decl) asm("_find_function_data");
struct n64_tag_function *
find_function_data(tree decl)
{
  struct n64_tag_function *p;
  for (p = outer_function_chain; p; p = p->next)
    if (p->decl == decl)
      return p;
  abort ();
}






void
push_function_context_to(tree context) asm("_push_function_context_to");
void
push_function_context_to(tree context)
{
  struct n64_tag_function *p = (struct n64_tag_function *) xmalloc (sizeof (struct n64_tag_function));

  p->next = outer_function_chain;
  outer_function_chain = p;

  p->name = current_function_name;
  p->decl = current_function_decl;
  p->pops_args = current_function_pops_args;
  p->returns_struct = current_function_returns_struct;
  p->returns_pcc_struct = current_function_returns_pcc_struct;
  p->needs_context = current_function_needs_context;
  p->calls_setjmp = current_function_calls_setjmp;
  p->calls_longjmp = current_function_calls_longjmp;
  p->calls_alloca = current_function_calls_alloca;
  p->has_nonlocal_label = current_function_has_nonlocal_label;
  p->has_nonlocal_goto = current_function_has_nonlocal_goto;
  p->contains_functions = current_function_contains_functions;
  p->args_size = current_function_args_size;
  p->pretend_args_size = current_function_pretend_args_size;
  p->arg_offset_rtx = current_function_arg_offset_rtx;
  p->varargs = current_function_varargs;
  p->stdarg = current_function_stdarg;
  p->uses_const_pool = current_function_uses_const_pool;
  p->uses_pic_offset_table = current_function_uses_pic_offset_table;
  p->internal_arg_pointer = current_function_internal_arg_pointer;
  p->max_parm_reg = max_parm_reg;
  p->parm_reg_stack_loc = parm_reg_stack_loc;
  p->outgoing_args_size = current_function_outgoing_args_size;
  p->return_rtx = current_function_return_rtx;
  p->nonlocal_goto_handler_slot = nonlocal_goto_handler_slot;
  p->nonlocal_goto_stack_level = nonlocal_goto_stack_level;
  p->nonlocal_labels = nonlocal_labels;
  p->cleanup_label = cleanup_label;
  p->return_label = return_label;
  p->save_expr_regs = save_expr_regs;
  p->stack_slot_list = stack_slot_list;
  p->parm_birth_insn = parm_birth_insn;
  p->frame_offset = frame_offset;
  p->tail_recursion_label = tail_recursion_label;
  p->tail_recursion_reentry = tail_recursion_reentry;
  p->arg_pointer_save_area = arg_pointer_save_area;
  p->rtl_expr_chain = rtl_expr_chain;
  p->last_parm_insn = last_parm_insn;
  p->context_display = context_display;
  p->trampoline_list = trampoline_list;
  p->function_call_count = function_call_count;
  p->temp_slots = temp_slots;
  p->temp_slot_level = temp_slot_level;
  p->fixup_var_refs_queue = 0;
  p->epilogue_delay_list = current_function_epilogue_delay_list;

  save_tree_status (p, context);
  save_storage_status (p);
  save_emit_status (p);
  init_emit ();
  save_expr_status (p);
  save_stmt_status (p);
  save_varasm_status (p);

  if (save_machine_status)
    (*save_machine_status) (p);
}

void
push_function_context(void) asm("_push_function_context");
void
push_function_context(void)
{
  push_function_context_to (current_function_decl);
}




void
pop_function_context_from(tree context) asm("_pop_function_context_from");
void
pop_function_context_from(tree context)
{
  struct n64_tag_function *p = outer_function_chain;

  outer_function_chain = p->next;

  current_function_contains_functions
    = p->contains_functions || p->inline_obstacks
      || context == current_function_decl;
  current_function_name = p->name;
  current_function_decl = p->decl;
  current_function_pops_args = p->pops_args;
  current_function_returns_struct = p->returns_struct;
  current_function_returns_pcc_struct = p->returns_pcc_struct;
  current_function_needs_context = p->needs_context;
  current_function_calls_setjmp = p->calls_setjmp;
  current_function_calls_longjmp = p->calls_longjmp;
  current_function_calls_alloca = p->calls_alloca;
  current_function_has_nonlocal_label = p->has_nonlocal_label;
  current_function_has_nonlocal_goto = p->has_nonlocal_goto;
  current_function_args_size = p->args_size;
  current_function_pretend_args_size = p->pretend_args_size;
  current_function_arg_offset_rtx = p->arg_offset_rtx;
  current_function_varargs = p->varargs;
  current_function_stdarg = p->stdarg;
  current_function_uses_const_pool = p->uses_const_pool;
  current_function_uses_pic_offset_table = p->uses_pic_offset_table;
  current_function_internal_arg_pointer = p->internal_arg_pointer;
  max_parm_reg = p->max_parm_reg;
  parm_reg_stack_loc = p->parm_reg_stack_loc;
  current_function_outgoing_args_size = p->outgoing_args_size;
  current_function_return_rtx = p->return_rtx;
  nonlocal_goto_handler_slot = p->nonlocal_goto_handler_slot;
  nonlocal_goto_stack_level = p->nonlocal_goto_stack_level;
  nonlocal_labels = p->nonlocal_labels;
  cleanup_label = p->cleanup_label;
  return_label = p->return_label;
  save_expr_regs = p->save_expr_regs;
  stack_slot_list = p->stack_slot_list;
  parm_birth_insn = p->parm_birth_insn;
  frame_offset = p->frame_offset;
  tail_recursion_label = p->tail_recursion_label;
  tail_recursion_reentry = p->tail_recursion_reentry;
  arg_pointer_save_area = p->arg_pointer_save_area;
  rtl_expr_chain = p->rtl_expr_chain;
  last_parm_insn = p->last_parm_insn;
  context_display = p->context_display;
  trampoline_list = p->trampoline_list;
  function_call_count = p->function_call_count;
  temp_slots = p->temp_slots;
  temp_slot_level = p->temp_slot_level;
  current_function_epilogue_delay_list = p->epilogue_delay_list;
  reg_renumber = 0;

  restore_tree_status (p);
  restore_storage_status (p);
  restore_expr_status (p);
  restore_emit_status (p);
  restore_stmt_status (p);
  restore_varasm_status (p);

  if (restore_machine_status)
    (*restore_machine_status) (p);



  {
    struct n64_tag_var_refs_queue *queue = p->fixup_var_refs_queue;
    for (; queue; queue = queue->next)
      fixup_var_refs (queue->modified, queue->promoted_mode, queue->unsignedp);
  }

  free (p);


  rtx_equal_function_value_matters = 1;
  virtuals_instantiated = 0;
}

void pop_function_context(void) asm("_pop_function_context");
void pop_function_context(void)
{
  pop_function_context_from (current_function_decl);
}







int
get_frame_size(void) asm("_get_frame_size");
int
get_frame_size(void)
{



  return frame_offset;

}
rtx
assign_stack_local(n64_enum_machine_mode mode, int size, int align) asm("_assign_stack_local");
rtx
assign_stack_local(n64_enum_machine_mode mode, int size, int align)
{
  register rtx x, addr;
  int bigend_correction = 0;
  int alignment;

  if (align == 0)
    {
      alignment = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
      if (mode == BLKmode)
 alignment = 64 / 8;
    }
  else if (align == -1)
    {
      alignment = 64 / 8;
      size = (((size) + (alignment) - 1) & ~((alignment)- 1));
    }
  else
    alignment = align / 8;
  frame_offset = (((frame_offset) + (alignment) - 1) & ~((alignment)- 1));




  if (((target_flags & 0x00010000) != 0) && mode != BLKmode)
    bigend_correction = size - (mode_size[(int)(mode)]);







  if (virtuals_instantiated)
    addr = plus_constant_wide (frame_pointer_rtx, (int) ((frame_offset + bigend_correction + (current_function_outgoing_args_size + ((target_flags & 0x00000400) ? (((((target_flags & 0x00002000) ? 8 : 4))+7) & ~7) : 0)))))

                               ;
  else
    addr = plus_constant_wide (virtual_stack_vars_rtx, (int) (frame_offset + bigend_correction))
                                      ;


  frame_offset += size;


  x = gen_rtx (MEM, mode, addr);

  stack_slot_list = gen_rtx (EXPR_LIST, VOIDmode, x, stack_slot_list);

  return x;
}





rtx
assign_outer_stack_local(n64_enum_machine_mode mode, int size, int align, struct n64_tag_function *function) asm("_assign_outer_stack_local");
rtx
assign_outer_stack_local(n64_enum_machine_mode mode, int size, int align, struct n64_tag_function *function)
{
  register rtx x, addr;
  int bigend_correction = 0;
  int alignment;



  push_obstacks (function->function_obstack,
   function->function_maybepermanent_obstack);

  if (align == 0)
    {
      alignment = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
      if (mode == BLKmode)
 alignment = 64 / 8;
    }
  else if (align == -1)
    {
      alignment = 64 / 8;
      size = (((size) + (alignment) - 1) & ~((alignment)- 1));
    }
  else
    alignment = align / 8;





  function->frame_offset = (((function->frame_offset) + (alignment) - 1) & ~((alignment)- 1));




  if (((target_flags & 0x00010000) != 0) && mode != BLKmode)
    bigend_correction = size - (mode_size[(int)(mode)]);




  addr = plus_constant_wide (virtual_stack_vars_rtx, (int) (function->frame_offset + bigend_correction))
                                              ;

  function->frame_offset += size;


  x = gen_rtx (MEM, mode, addr);

  function->stack_slot_list
    = gen_rtx (EXPR_LIST, VOIDmode, x, function->stack_slot_list);

  pop_obstacks ();

  return x;
}
rtx
assign_stack_temp(n64_enum_machine_mode mode, int size, int keep) asm("_assign_stack_temp");
rtx
assign_stack_temp(n64_enum_machine_mode mode, int size, int keep)
{
  struct n64_tag_temp_slot *p, *best_p = 0;



  if (size == -1)
    abort ();



  for (p = temp_slots; p; p = p->next)
    if (p->size == size && ((p->slot)->mode) == mode && ! p->in_use)
      break;



  if (p == 0)
    for (p = temp_slots; p; p = p->next)
      if (p->size > size && ((p->slot)->mode) == mode && ! p->in_use
   && (best_p == 0 || best_p->size > p->size))
 best_p = p;


  if (best_p)
    {



      if (((best_p->slot)->mode) == BLKmode)
 {
   int alignment = 64 / 8;
   int rounded_size = (((size) + (alignment) - 1) & ~((alignment)- 1));

   if (best_p->size - rounded_size >= alignment)
     {
       p = (struct n64_tag_temp_slot *) oballoc (sizeof (struct n64_tag_temp_slot));
       p->in_use = p->addr_taken = 0;
       p->size = best_p->size - rounded_size;
       p->base_offset = best_p->base_offset + rounded_size;
       p->full_size = best_p->full_size - rounded_size;
       p->slot = gen_rtx (MEM, BLKmode,
     plus_constant_wide (((best_p->slot)->fld[0].rtx), (int) (rounded_size))
                   );
       p->address = 0;
       p->rtl_expr = 0;
       p->next = temp_slots;
       temp_slots = p;

       stack_slot_list = gen_rtx (EXPR_LIST, VOIDmode, p->slot,
      stack_slot_list);

       best_p->size = rounded_size;
       best_p->full_size = rounded_size;
     }
 }

      p = best_p;
    }


  if (p == 0)
    {
      int frame_offset_old = frame_offset;
      p = (struct n64_tag_temp_slot *) oballoc (sizeof (struct n64_tag_temp_slot));


      p->slot = assign_stack_local (mode, size, mode == BLKmode ? -1 : 0);
      p->size = size;






      p->base_offset = frame_offset_old;
      p->full_size = frame_offset - frame_offset_old;

      p->address = 0;
      p->next = temp_slots;
      temp_slots = p;
    }

  p->in_use = 1;
  p->addr_taken = 0;
  p->rtl_expr = sequence_rtl_expr;

  if (keep == 2)
    {
      p->level = target_temp_slot_level;
      p->keep = 0;
    }
  else
    {
      p->level = temp_slot_level;
      p->keep = keep;
    }
  return p->slot;
}







void
combine_temp_slots(void) asm("_combine_temp_slots");
void
combine_temp_slots(void)
{
  struct n64_tag_temp_slot *p, *q;
  struct n64_tag_temp_slot *prev_p, *prev_q;

  rtx free_pointer = rtx_alloc (CONST_INT);

  for (p = temp_slots, prev_p = 0; p; p = prev_p ? prev_p->next : temp_slots)
    {
      int delete_p = 0;
      if (! p->in_use && ((p->slot)->mode) == BLKmode)
 for (q = p->next, prev_q = p; q; q = prev_q->next)
   {
     int delete_q = 0;
     if (! q->in_use && ((q->slot)->mode) == BLKmode)
       {
  if (p->base_offset + p->full_size == q->base_offset)
    {

      p->size += q->size;
      p->full_size += q->full_size;
      delete_q = 1;
    }
  else if (q->base_offset + q->full_size == p->base_offset)
    {

      q->size += p->size;
      q->full_size += p->full_size;
      delete_p = 1;
      break;
    }
       }

     if (delete_q)
       prev_q->next = q->next;
     else
       prev_q = q;
   }

      if (delete_p)
 {
   if (prev_p)
     prev_p->next = p->next;
   else
     temp_slots = p->next;
 }
      else
 prev_p = p;
    }


  rtx_free (free_pointer);
}



static struct n64_tag_temp_slot *
find_temp_slot_from_address(rtx x) asm("_find_temp_slot_from_address");
static struct n64_tag_temp_slot *
find_temp_slot_from_address(rtx x)
{
  struct n64_tag_temp_slot *p;
  rtx next;

  for (p = temp_slots; p; p = p->next)
    {
      if (! p->in_use)
 continue;
      else if (((p->slot)->fld[0].rtx) == x
        || p->address == x)
 return p;

      else if (p->address != 0 && ((p->address)->code) == EXPR_LIST)
 for (next = p->address; next; next = ((next)->fld[1].rtx))
   if (((next)->fld[0].rtx) == x)
     return p;
    }

  return 0;
}




void
update_temp_slot_address(rtx old, rtx cxx_new) asm("_update_temp_slot_address");
void
update_temp_slot_address(rtx old, rtx cxx_new)
{
  struct n64_tag_temp_slot *p = find_temp_slot_from_address (old);


  if (p == 0)
    return;
  else if (p->address == 0)
    p->address = cxx_new;
  else
    {
      if (((p->address)->code) != EXPR_LIST)
 p->address = gen_rtx (EXPR_LIST, VOIDmode, p->address, (rtx) 0);

      p->address = gen_rtx (EXPR_LIST, VOIDmode, cxx_new, p->address);
    }
}




void
mark_temp_addr_taken(rtx x) asm("_mark_temp_addr_taken");
void
mark_temp_addr_taken(rtx x)
{
  struct n64_tag_temp_slot *p;

  if (x == 0)
    return;



  if (((x)->code) != MEM || (((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH))
    return;

  p = find_temp_slot_from_address (((x)->fld[0].rtx));
  if (p != 0)
    p->addr_taken = 1;
}
void
preserve_temp_slots(rtx x) asm("_preserve_temp_slots");
void
preserve_temp_slots(rtx x)
{
  struct n64_tag_temp_slot *p = 0;



  if (x == 0)
    {
      for (p = temp_slots; p; p = p->next)
 if (p->in_use && p->level == temp_slot_level && p->addr_taken)
   p->level--;

      return;
    }





  if (((x)->code) == REG && regno_pointer_flag[((x)->fld[0].rtint)])
    p = find_temp_slot_from_address (x);




  if (p == 0 && (((x)->code) != MEM || (((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH)))
    {
      for (p = temp_slots; p; p = p->next)
 if (p->in_use && p->level == temp_slot_level && p->addr_taken)
   p->level--;

      return;
    }


  if (p == 0)
    p = find_temp_slot_from_address (((x)->fld[0].rtx));

  if (p != 0)
    {


      struct n64_tag_temp_slot *q;

      for (q = temp_slots; q; q = q->next)
 if (q != p && q->addr_taken && q->level == p->level)
   q->level--;

      p->level--;
      p->addr_taken = 0;
      return;
    }


  for (p = temp_slots; p; p = p->next)
    if (p->in_use && p->level == temp_slot_level && ! p->keep)
      p->level--;
}






void
preserve_rtl_expr_result(rtx x) asm("_preserve_rtl_expr_result");
void
preserve_rtl_expr_result(rtx x)
{
  struct n64_tag_temp_slot *p;



  if (x == 0 || ((x)->code) != MEM || (((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH))
    return;



  p = find_temp_slot_from_address (((x)->fld[0].rtx));
  if (p != 0)
    {
      p->level = ((p->level) < (temp_slot_level) ? (p->level) : (temp_slot_level));
      p->rtl_expr = 0;
    }

  return;
}
void
free_temp_slots(void) asm("_free_temp_slots");
void
free_temp_slots(void)
{
  struct n64_tag_temp_slot *p;

  for (p = temp_slots; p; p = p->next)
    if (p->in_use && p->level == temp_slot_level && ! p->keep
 && p->rtl_expr == 0)
      p->in_use = 0;

  combine_temp_slots ();
}



void
free_temps_for_rtl_expr(tree t) asm("_free_temps_for_rtl_expr");
void
free_temps_for_rtl_expr(tree t)
{
  struct n64_tag_temp_slot *p;

  for (p = temp_slots; p; p = p->next)
    if (p->rtl_expr == t)
      p->in_use = 0;

  combine_temp_slots ();
}



void
push_temp_slots(void) asm("_push_temp_slots");
void
push_temp_slots(void)
{
  temp_slot_level++;
}




void
pop_temp_slots(void) asm("_pop_temp_slots");
void
pop_temp_slots(void)
{
  struct n64_tag_temp_slot *p;

  for (p = temp_slots; p; p = p->next)
    if (p->in_use && p->level == temp_slot_level && p->rtl_expr == 0)
      p->in_use = 0;

  combine_temp_slots ();

  temp_slot_level--;
}




void
put_var_into_stack(tree decl) asm("_put_var_into_stack");
void
put_var_into_stack(tree decl)
{
  register rtx reg;
  n64_enum_machine_mode promoted_mode, decl_mode;
  struct n64_tag_function *function = 0;
  tree context;

  if (output_bytecode)
    return;

  context = decl_function_context (decl);


  reg = ((n64_enum_tree_code) (decl)->common.code) == SAVE_EXPR ? (*(struct n64_tag_rtx_def **) &(decl)->exp.operands[2]) : ((decl)->decl.rtl);




  if (reg == 0)
    return;


  decl_mode = (((n64_enum_tree_code) (decl)->common.code) == SAVE_EXPR ? ((((decl)->common.type))->type.mode)
        : ((decl)->decl.mode));

  promoted_mode = ((reg)->mode);



  if (context != current_function_decl)
    for (function = outer_function_chain; function; function = function->next)
      if (function->decl == context)
 break;



  if (((decl)->decl.nonlocal_flag)
      && ((reg)->code) == MEM
      && ((((reg)->fld[0].rtx))->code) == REG
      && ((((reg)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3))
    {
      reg = ((reg)->fld[0].rtx);
      decl_mode = promoted_mode = ((reg)->mode);
    }



  if (((reg)->code) == REG)
    put_reg_into_stack (function, reg, ((decl)->common.type),
   promoted_mode, decl_mode, ((decl)->common.side_effects_flag));
  else if (((reg)->code) == CONCAT)
    {


      n64_enum_machine_mode part_mode = ((((reg)->fld[0].rtx))->mode);
      tree part_type = ((((decl)->common.type))->common.type);







      put_reg_into_stack (function, ((reg)->fld[0].rtx), part_type, part_mode,
     part_mode, ((decl)->common.side_effects_flag));
      put_reg_into_stack (function, ((reg)->fld[1].rtx), part_type, part_mode,
     part_mode, ((decl)->common.side_effects_flag));



      ((reg)->code = (MEM));
      ((reg)->volatil) = ((((reg)->fld[0].rtx))->volatil);



      ((reg)->fld[0].rtx) = ((((reg)->fld[0].rtx))->fld[0].rtx);

      if (((((reg)->fld[0].rtx))->code) == PLUS)
 ((reg)->fld[0].rtx) = copy_rtx (((reg)->fld[0].rtx));
    }
}







static void
put_reg_into_stack(struct n64_tag_function *function, rtx reg, tree type, n64_enum_machine_mode promoted_mode, n64_enum_machine_mode decl_mode, int volatile_p) asm("_put_reg_into_stack");
static void
put_reg_into_stack(struct n64_tag_function *function, rtx reg, tree type, n64_enum_machine_mode promoted_mode, n64_enum_machine_mode decl_mode, int volatile_p)
{
  rtx cxx_new = 0;

  if (function)
    {
      if (((reg)->fld[0].rtint) < function->max_parm_reg)
 cxx_new = function->parm_reg_stack_loc[((reg)->fld[0].rtint)];
      if (cxx_new == 0)
 cxx_new = assign_outer_stack_local (decl_mode, (mode_size[(int)(decl_mode)]),
     0, function);
    }
  else
    {
      if (((reg)->fld[0].rtint) < max_parm_reg)
 cxx_new = parm_reg_stack_loc[((reg)->fld[0].rtint)];
      if (cxx_new == 0)
 cxx_new = assign_stack_local (decl_mode, (mode_size[(int)(decl_mode)]), 0);
    }

  ((reg)->mode = (decl_mode));
  ((reg)->fld[0].rtx) = ((cxx_new)->fld[0].rtx);

  ((reg)->volatil) = volatile_p;
  ((reg)->code = (MEM));



  ((reg)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);



  if (function)
    {
      struct n64_tag_var_refs_queue *temp;


      push_obstacks (function->function_obstack,
       function->function_maybepermanent_obstack);



      temp
 = (struct n64_tag_var_refs_queue *) savealloc (sizeof (struct n64_tag_var_refs_queue));
      temp->modified = reg;
      temp->promoted_mode = promoted_mode;
      temp->unsignedp = ((type)->common.unsigned_flag);
      temp->next = function->fixup_var_refs_queue;
      function->fixup_var_refs_queue = temp;
      pop_obstacks ();
    }
  else

    fixup_var_refs (reg, promoted_mode, ((type)->common.unsigned_flag));
}

static void
fixup_var_refs(rtx var, n64_enum_machine_mode promoted_mode, int unsignedp) asm("_fixup_var_refs");
static void
fixup_var_refs(rtx var, n64_enum_machine_mode promoted_mode, int unsignedp)
{
  tree pending;
  rtx first_insn = get_insns ();
  struct n64_tag_sequence_stack *stack = sequence_stack;
  tree rtl_exps = rtl_expr_chain;


  fixup_var_refs_insns (var, promoted_mode, unsignedp, first_insn, stack == 0);


  for (; stack; stack = stack->next)
    {
      push_to_sequence (stack->first);
      fixup_var_refs_insns (var, promoted_mode, unsignedp,
       stack->first, stack->next != 0);


      stack->last = get_last_insn ();
      end_sequence ();
    }


  for (pending = rtl_exps; pending; pending = ((pending)->common.chain))
    {
      rtx seq = (*(struct n64_tag_rtx_def **) &(((pending)->list.value))->exp.operands[0]);
      if (seq != const0_rtx && seq != 0)
 {
   push_to_sequence (seq);
   fixup_var_refs_insns (var, promoted_mode, unsignedp, seq, 0);
   end_sequence ();
 }
    }
}





static struct n64_tag_fixup_replacement *
find_fixup_replacement(struct n64_tag_fixup_replacement **replacements, rtx x) asm("_find_fixup_replacement");
static struct n64_tag_fixup_replacement *
find_fixup_replacement(struct n64_tag_fixup_replacement **replacements, rtx x)
{
  struct n64_tag_fixup_replacement *p;


  for (p = *replacements; p && p->old != x; p = p->next)
    ;

  if (p == 0)
    {
      p = (struct n64_tag_fixup_replacement *) oballoc (sizeof (struct n64_tag_fixup_replacement));
      p->old = x;
      p->cxx_new = 0;
      p->next = *replacements;
      *replacements = p;
    }

  return p;
}





static void
fixup_var_refs_insns(rtx var, n64_enum_machine_mode promoted_mode, int unsignedp, rtx insn, int toplevel) asm("_fixup_var_refs_insns");
static void
fixup_var_refs_insns(rtx var, n64_enum_machine_mode promoted_mode, int unsignedp, rtx insn, int toplevel)
{
  rtx call_dest = 0;

  while (insn)
    {
      rtx next = ((insn)->fld[2].rtx);
      rtx note;
      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {




    if (((((insn)->fld[3].rtx))->code) == CLOBBER
       && ((((insn)->fld[3].rtx))->fld[0].rtx) == var)
     {
       if ((note = find_reg_note (insn, REG_LIBCALL, (rtx) 0)) != 0)



  remove_note (((note)->fld[0].rtx),
        find_reg_note (((note)->fld[0].rtx), REG_RETVAL,
         (rtx) 0));



       ((insn)->code = (NOTE));
       ((insn)->fld[4].rtint) = -1;
       ((insn)->fld[3].rtstr) = 0;
     }



   else if (toplevel
     && ((((insn)->fld[3].rtx))->code) == SET
     && ((((insn)->fld[3].rtx))->fld[0].rtx) == var


     && find_reg_note (insn, REG_RETVAL, (rtx) 0) == 0
     && rtx_equal_p (((((insn)->fld[3].rtx))->fld[1].rtx), var))
     {


       ((insn)->code = (NOTE));
       ((insn)->fld[4].rtint) = -1;
       ((insn)->fld[3].rtstr) = 0;
       if (insn == last_parm_insn)
  last_parm_insn = ((next)->fld[1].rtx);
     }
   else
     {
       struct n64_tag_fixup_replacement *replacements = 0;
       rtx next_insn = ((insn)->fld[2].rtx);
       fixup_var_refs_1 (var, promoted_mode, &((insn)->fld[3].rtx), insn,
    &replacements);




       if (insn == last_parm_insn)
  last_parm_insn = ((next_insn)->fld[1].rtx);

       while (replacements)
  {
    if (((replacements->cxx_new)->code) == REG)
      {
        rtx insert_before;
        rtx seq;


        if (((replacements->old)->code) == SUBREG)
   replacements->old
     = fixup_memory_subreg (replacements->old, insn, 0);
        else
   replacements->old
     = fixup_stack_1 (replacements->old, insn);

        insert_before = insn;





        if (((replacements->cxx_new)->mode)
     != ((replacements->old)->mode))
   {
     start_sequence ();
     convert_move (replacements->cxx_new,
     replacements->old, unsignedp);
     seq = gen_sequence ();
     end_sequence ();
   }
        else
   seq = gen_move_insn (replacements->cxx_new,
          replacements->old);

        emit_insn_before (seq, insert_before);
      }

    replacements = replacements->next;
  }
     }




   for (note = ((insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
     if (((note)->code) != INSN_LIST)
       ((note)->fld[0].rtx)
  = walk_fixup_memory_subreg (((note)->fld[0].rtx), insn, 1);
 }
      insn = next;
    }
}
static void
fixup_var_refs_1(register rtx var, n64_enum_machine_mode promoted_mode, register rtx *loc, rtx insn, struct n64_tag_fixup_replacement **replacements) asm("_fixup_var_refs_1");
static void
fixup_var_refs_1(register rtx var, n64_enum_machine_mode promoted_mode, register rtx *loc, rtx insn, struct n64_tag_fixup_replacement **replacements)
{
  register int i;
  register rtx x = *loc;
  n64_enum_rtx_code code = ((x)->code);
  register char *fmt;
  register rtx tem, tem1;
  struct n64_tag_fixup_replacement *replacement;

  switch (code)
    {
    case MEM:
      if (var == x)
 {



   replacement = find_fixup_replacement (replacements, var);
   if (replacement->cxx_new)
     {
       *loc = replacement->cxx_new;
       return;
     }

   *loc = replacement->cxx_new = x = fixup_stack_1 (x, insn);




   ((insn)->fld[4].rtint) = -1;
   if (! flag_force_mem && ((x)->mode) == promoted_mode
       && recog_memoized (insn) >= 0)
     return;

   *loc = replacement->cxx_new = gen_reg_rtx (promoted_mode);
   return;
 }






      if (reg_mentioned_p (var, x))
 {
   replacement = find_fixup_replacement (replacements, x);
   if (replacement->cxx_new == 0)
     replacement->cxx_new = copy_most_rtx (x, var);

   *loc = x = replacement->cxx_new;
 }
      break;

    case REG:
    case CC0:
    case PC:
    case CONST_INT:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
    case CONST_DOUBLE:
      return;

    case SIGN_EXTRACT:
    case ZERO_EXTRACT:


      if (((x)->fld[0].rtx) == var
   || (((((x)->fld[0].rtx))->code) == SUBREG
       && ((((x)->fld[0].rtx))->fld[0].rtx) == var))
 {





   tem = ((x)->fld[0].rtx);
   if (((tem)->code) == SUBREG)
     tem = fixup_memory_subreg (tem, insn, 1);
   tem = fixup_stack_1 (tem, insn);





   if (! flag_force_mem && ((((x)->fld[1].rtx))->code) == CONST_INT
       && ((((x)->fld[2].rtx))->code) == CONST_INT
       && ! mode_dependent_address_p (((tem)->fld[0].rtx))
       && ! ((tem)->volatil))
     {
       n64_enum_machine_mode wanted_mode = VOIDmode;
       n64_enum_machine_mode is_mode = ((tem)->mode);
       int width = ((((x)->fld[1].rtx))->fld[0].rtwint);
       int pos = ((((x)->fld[2].rtx))->fld[0].rtwint);


       if (((x)->code) == ZERO_EXTRACT)
  wanted_mode = insn_operand_mode[(int) CODE_FOR_extzv][1];


       if (((x)->code) == SIGN_EXTRACT)
  wanted_mode = insn_operand_mode[(int) CODE_FOR_extv][1];


       if (wanted_mode != VOIDmode
    && (mode_size[(int)(wanted_mode)]) < (mode_size[(int)(is_mode)]))
  {
    int offset = pos / 8;
    rtx old_pos = ((x)->fld[2].rtx);
    rtx newmem;



    if (((target_flags & 0x00010000) != 0) != 0)
      offset = ((mode_size[(int)(is_mode)])
         - (mode_size[(int)(wanted_mode)]) - offset);

    pos %= (8 * mode_size[(int)(wanted_mode)]);

    newmem = gen_rtx (MEM, wanted_mode,
        plus_constant_wide (((tem)->fld[0].rtx), (int) (offset)));
    ((newmem)->unchanging) = ((tem)->unchanging);
    ((newmem)->volatil) = ((tem)->volatil);
    ((newmem)->in_struct) = ((tem)->in_struct);


    ((insn)->fld[4].rtint) = -1;
    ((x)->fld[0].rtx) = newmem;
    ((x)->fld[2].rtx) = gen_rtx (CONST_INT, VOIDmode, (int) (pos));

    if (recog_memoized (insn) >= 0)
      return;



    ((x)->fld[2].rtx) = old_pos;
  }
     }




   tem1 = gen_reg_rtx (((tem)->mode));
   emit_insn_before (gen_move_insn (tem1, tem), insn);
   ((x)->fld[0].rtx) = tem1;
   return;
 }
      break;

    case SUBREG:
      if (((x)->fld[0].rtx) == var)
 {





   if (((x)->in_struct))
     {
       *loc = var;
       fixup_var_refs_1 (var, ((var)->mode), loc, insn, replacements);
       return;
     }





   if ((mode_size[(int)(((x)->mode))]) > (mode_size[(int)(((var)->mode))]))
     {
       replacement = find_fixup_replacement (replacements, var);
       if (replacement->cxx_new == 0)
  replacement->cxx_new = gen_reg_rtx (((var)->mode));
       ((x)->fld[0].rtx) = replacement->cxx_new;
       return;
     }





   replacement = find_fixup_replacement (replacements, x);
   if (replacement->cxx_new)
     {
       *loc = replacement->cxx_new;
       return;
     }

   replacement->cxx_new = *loc = fixup_memory_subreg (x, insn, 0);

   ((insn)->fld[4].rtint) = -1;
   if (! flag_force_mem && recog_memoized (insn) >= 0)
     return;

   *loc = replacement->cxx_new = gen_reg_rtx (((x)->mode));
   return;
 }
      break;

    case SET:

      if (((((x)->fld[0].rtx))->code) == SIGN_EXTRACT
   || ((((x)->fld[0].rtx))->code) == ZERO_EXTRACT)
 optimize_bit_field (x, insn, 0);
      if (((((x)->fld[1].rtx))->code) == SIGN_EXTRACT
   || ((((x)->fld[1].rtx))->code) == ZERO_EXTRACT)
 optimize_bit_field (x, insn, ((void *)0));



      if (((((x)->fld[0].rtx))->code) == SUBREG
   && ((((x)->fld[0].rtx))->fld[0].rtx) == var
   && ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])
       > (mode_size[(int)(((var)->mode))])))
 {
   ((x)->fld[0].rtx) = tem = gen_reg_rtx (((((x)->fld[0].rtx))->mode));
   emit_insn_after (gen_move_insn (var, gen_lowpart (((var)->mode),
           tem)),
      insn);
   break;
 }

      {
 rtx dest = ((x)->fld[0].rtx);
 rtx src = ((x)->fld[1].rtx);
 rtx outerdest = dest;

 while (((dest)->code) == SUBREG || ((dest)->code) == STRICT_LOW_PART
        || ((dest)->code) == SIGN_EXTRACT
        || ((dest)->code) == ZERO_EXTRACT)
   dest = ((dest)->fld[0].rtx);

 if (((src)->code) == SUBREG)
   src = ((src)->fld[0].rtx);




        if (src != var && dest != var)
   break;


 ((insn)->fld[4].rtint) = -1;


 if (((outerdest)->code) == ZERO_EXTRACT && dest == var)
   {


     fixup_var_refs_1 (var, promoted_mode, &((outerdest)->fld[1].rtx),
         insn, replacements);
     fixup_var_refs_1 (var, promoted_mode, &((outerdest)->fld[2].rtx),
         insn, replacements);
     fixup_var_refs_1 (var, promoted_mode, &((x)->fld[1].rtx),
         insn, replacements);

     tem = ((outerdest)->fld[0].rtx);




     if (((tem)->code) == SUBREG
  && ((tem)->fld[0].rtx) == var)
       tem = fixup_memory_subreg (tem, insn, 1);
     else
       tem = fixup_stack_1 (tem, insn);

     if (((((outerdest)->fld[1].rtx))->code) == CONST_INT
  && ((((outerdest)->fld[2].rtx))->code) == CONST_INT
  && ! mode_dependent_address_p (((tem)->fld[0].rtx))
  && ! ((tem)->volatil))
       {
  n64_enum_machine_mode wanted_mode
    = insn_operand_mode[(int) CODE_FOR_insv][0];
  n64_enum_machine_mode is_mode = ((tem)->mode);
  int width = ((((outerdest)->fld[1].rtx))->fld[0].rtwint);
  int pos = ((((outerdest)->fld[2].rtx))->fld[0].rtwint);


  if ((mode_size[(int)(wanted_mode)]) < (mode_size[(int)(is_mode)]))
    {
      int offset = pos / 8;
      rtx old_pos = ((outerdest)->fld[2].rtx);
      rtx newmem;

      if (((target_flags & 0x00010000) != 0) != 0)
        offset = ((mode_size[(int)(is_mode)])
    - (mode_size[(int)(wanted_mode)]) - offset);

      pos %= (8 * mode_size[(int)(wanted_mode)]);

      newmem = gen_rtx (MEM, wanted_mode,
          plus_constant_wide (((tem)->fld[0].rtx), (int) (offset)));
      ((newmem)->unchanging) = ((tem)->unchanging);
      ((newmem)->volatil) = ((tem)->volatil);
      ((newmem)->in_struct) = ((tem)->in_struct);


      ((insn)->fld[4].rtint) = -1;
      ((outerdest)->fld[0].rtx) = newmem;
      ((outerdest)->fld[2].rtx) = gen_rtx (CONST_INT, VOIDmode, (int) (pos));

      if (recog_memoized (insn) >= 0)
        return;



      ((outerdest)->fld[2].rtx) = old_pos;
    }
       }





     tem1 = gen_reg_rtx (((tem)->mode));
     emit_insn_before (gen_move_insn (tem1, tem), insn);
     emit_insn_after (gen_move_insn (tem, tem1), insn);
     ((outerdest)->fld[0].rtx) = tem1;
     return;
   }






 if (dest == var && ((((x)->fld[0].rtx))->code) == STRICT_LOW_PART)
   ((x)->fld[0].rtx) = ((((x)->fld[0].rtx))->fld[0].rtx);
 if ((((x)->fld[1].rtx) == var
      || (((((x)->fld[1].rtx))->code) == SUBREG
   && ((((x)->fld[1].rtx))->fld[0].rtx) == var))
     && (((((x)->fld[0].rtx))->code) == REG
  || (((((x)->fld[0].rtx))->code) == SUBREG
      && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG))
     && x == single_set (((insn)->fld[3].rtx)))
   {
     rtx pat;

     replacement = find_fixup_replacement (replacements, ((x)->fld[1].rtx));
     if (replacement->cxx_new)
       ((x)->fld[1].rtx) = replacement->cxx_new;
     else if (((((x)->fld[1].rtx))->code) == SUBREG)
       ((x)->fld[1].rtx) = replacement->cxx_new
  = fixup_memory_subreg (((x)->fld[1].rtx), insn, 0);
     else
       ((x)->fld[1].rtx) = replacement->cxx_new
  = fixup_stack_1 (((x)->fld[1].rtx), insn);

     if (recog_memoized (insn) >= 0)
       return;
     pat = gen_move_insn (((x)->fld[0].rtx), ((x)->fld[1].rtx));
     if (((pat)->code) == SEQUENCE)
       {
  emit_insn_after (pat, insn);
  ((insn)->code = (NOTE));
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[3].rtstr) = 0;
       }
     else
       ((insn)->fld[3].rtx) = pat;

     return;
   }

 if ((((x)->fld[0].rtx) == var
      || (((((x)->fld[0].rtx))->code) == SUBREG
   && ((((x)->fld[0].rtx))->fld[0].rtx) == var))
     && (((((x)->fld[1].rtx))->code) == REG
  || (((((x)->fld[1].rtx))->code) == SUBREG
      && ((((((x)->fld[1].rtx))->fld[0].rtx))->code) == REG))
     && x == single_set (((insn)->fld[3].rtx)))
   {
     rtx pat;

     if (((((x)->fld[0].rtx))->code) == SUBREG)
       ((x)->fld[0].rtx) = fixup_memory_subreg (((x)->fld[0].rtx), insn, 0);
     else
       ((x)->fld[0].rtx) = fixup_stack_1 (((x)->fld[0].rtx), insn);

     if (recog_memoized (insn) >= 0)
       return;

     pat = gen_move_insn (((x)->fld[0].rtx), ((x)->fld[1].rtx));
     if (((pat)->code) == SEQUENCE)
       {
  emit_insn_after (pat, insn);
  ((insn)->code = (NOTE));
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[3].rtstr) = 0;
       }
     else
       ((insn)->fld[3].rtx) = pat;

     return;
   }
 if (dest == var)
   {
     rtx temp;
     rtx fixeddest = ((x)->fld[0].rtx);


     if (((fixeddest)->code) == STRICT_LOW_PART)
       fixeddest = ((fixeddest)->fld[0].rtx);

     if (((fixeddest)->code) == SUBREG)
       {
  fixeddest = fixup_memory_subreg (fixeddest, insn, 0);
  promoted_mode = ((fixeddest)->mode);
       }
     else
       fixeddest = fixup_stack_1 (fixeddest, insn);

     temp = gen_reg_rtx (promoted_mode);

     emit_insn_after (gen_move_insn (fixeddest,
         gen_lowpart (((fixeddest)->mode),
        temp)),
        insn);

     ((x)->fld[0].rtx) = temp;
   }
      }
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 fixup_var_refs_1 (var, promoted_mode, &((x)->fld[i].rtx), insn, replacements);
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     fixup_var_refs_1 (var, promoted_mode, &((x)->fld[i].rtvec->elem[j].rtx),
         insn, replacements);
 }
    }
}
static rtx
fixup_memory_subreg(rtx x, rtx insn, int uncritical) asm("_fixup_memory_subreg");
static rtx
fixup_memory_subreg(rtx x, rtx insn, int uncritical)
{
  int offset = ((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
  rtx addr = ((((x)->fld[0].rtx))->fld[0].rtx);
  n64_enum_machine_mode mode = ((x)->mode);
  rtx saved, result;


  if ((mode_size[(int)(mode)]) > (mode_size[(int)(((((x)->fld[0].rtx))->mode))])
      && ! uncritical)
    abort ();

  if (((target_flags & 0x00010000) != 0))
    offset += (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])))
        - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)]))));
  addr = plus_constant_wide (addr, (int) (offset));
  if (!flag_force_addr && memory_address_p (mode, addr))

    return change_address (((x)->fld[0].rtx), mode, addr);
  start_sequence ();
  result = change_address (((x)->fld[0].rtx), mode, addr);
  emit_insn_before (gen_sequence (), insn);
  end_sequence ();
  return result;
}
static rtx
walk_fixup_memory_subreg(register rtx x, rtx insn, int uncritical) asm("_walk_fixup_memory_subreg");
static rtx
walk_fixup_memory_subreg(register rtx x, rtx insn, int uncritical)
{
  register n64_enum_rtx_code code;
  register char *fmt;
  register int i;

  if (x == 0)
    return 0;

  code = ((x)->code);

  if (code == SUBREG && ((((x)->fld[0].rtx))->code) == MEM)
    return fixup_memory_subreg (x, insn, uncritical);



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = walk_fixup_memory_subreg (((x)->fld[i].rtx), insn, uncritical);
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     ((x)->fld[i].rtvec->elem[j].rtx)
       = walk_fixup_memory_subreg (((x)->fld[i].rtvec->elem[j].rtx), insn, uncritical);
 }
    }
  return x;
}







static rtx
fixup_stack_1(rtx x, rtx insn) asm("_fixup_stack_1");
static rtx
fixup_stack_1(rtx x, rtx insn)
{
  register int i;
  register n64_enum_rtx_code code = ((x)->code);
  register char *fmt;

  if (code == MEM)
    {
      register rtx ad = ((x)->fld[0].rtx);


      if (((ad)->code) == PLUS
   && ((((ad)->fld[0].rtx))->code) == REG
   && ((((((ad)->fld[0].rtx))->fld[0].rtint) >= (68)
        && ((((ad)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3))
       || ((ad)->fld[0].rtx) == current_function_internal_arg_pointer)
   && ((((ad)->fld[1].rtx))->code) == CONST_INT)
 {
   rtx temp, seq;
   if (memory_address_p (((x)->mode), ad))
     return x;

   start_sequence ();
   temp = copy_to_reg (ad);
   seq = gen_sequence ();
   end_sequence ();
   emit_insn_before (seq, insn);
   return change_address (x, VOIDmode, temp);
 }
      return x;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = fixup_stack_1 (((x)->fld[i].rtx), insn);
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     ((x)->fld[i].rtvec->elem[j].rtx) = fixup_stack_1 (((x)->fld[i].rtvec->elem[j].rtx), insn);
 }
    }
  return x;
}
static void
optimize_bit_field(rtx body, rtx insn, rtx *equiv_mem) asm("_optimize_bit_field");
static void
optimize_bit_field(rtx body, rtx insn, rtx *equiv_mem)
{
  register rtx bitfield;
  int destflag;
  rtx seq = 0;
  n64_enum_machine_mode mode;

  if (((((body)->fld[0].rtx))->code) == SIGN_EXTRACT
      || ((((body)->fld[0].rtx))->code) == ZERO_EXTRACT)
    bitfield = ((body)->fld[0].rtx), destflag = 1;
  else
    bitfield = ((body)->fld[1].rtx), destflag = 0;




  if (((((bitfield)->fld[1].rtx))->code) == CONST_INT
      && ((((bitfield)->fld[2].rtx))->code) == CONST_INT
      && ((mode = mode_for_size (((((bitfield)->fld[1].rtx))->fld[0].rtwint), MODE_INT, 1))
   != BLKmode)
      && ((((bitfield)->fld[2].rtx))->fld[0].rtwint) % ((((bitfield)->fld[1].rtx))->fld[0].rtwint) == 0)
    {
      register rtx memref = 0;




      if (((((bitfield)->fld[0].rtx))->code) == MEM)
 memref = ((bitfield)->fld[0].rtx);
      else if (((((bitfield)->fld[0].rtx))->code) == REG
        && equiv_mem != 0)
 memref = equiv_mem[((((bitfield)->fld[0].rtx))->fld[0].rtint)];
      else if (((((bitfield)->fld[0].rtx))->code) == SUBREG
        && ((((((bitfield)->fld[0].rtx))->fld[0].rtx))->code) == MEM)
 memref = ((((bitfield)->fld[0].rtx))->fld[0].rtx);
      else if (((((bitfield)->fld[0].rtx))->code) == SUBREG
        && equiv_mem != 0
        && ((((((bitfield)->fld[0].rtx))->fld[0].rtx))->code) == REG)
 memref = equiv_mem[((((((bitfield)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)];

      if (memref
   && ! mode_dependent_address_p (((memref)->fld[0].rtx))
   && ! ((memref)->volatil))
 {




   register int offset = ((((bitfield)->fld[2].rtx))->fld[0].rtwint);
   rtx insns;


   if (0 != ((target_flags & 0x00010000) != 0))
     offset = ((8 * mode_size[(int)(((((bitfield)->fld[0].rtx))->mode))])
        - offset - ((((bitfield)->fld[1].rtx))->fld[0].rtwint));


   offset /= 8;
   if (((((bitfield)->fld[0].rtx))->code) == SUBREG)
     {
       offset += ((((bitfield)->fld[0].rtx))->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
       if (((target_flags & 0x00010000) != 0))
  offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((((bitfield)->fld[0].rtx))->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((((bitfield)->fld[0].rtx))->mode))])))

      - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((memref)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((memref)->mode))])))
                                        );
     }

   start_sequence ();
   memref = change_address (memref, mode,
       plus_constant_wide (((memref)->fld[0].rtx), (int) (offset)));
   insns = get_insns ();
   end_sequence ();
   emit_insns_before (insns, insn);




   if (destflag)
     {
       validate_change (insn, &((body)->fld[0].rtx), memref, 1);
       if (! ((((((body)->fld[1].rtx))->code) == LABEL_REF || ((((body)->fld[1].rtx))->code) == SYMBOL_REF || ((((body)->fld[1].rtx))->code) == CONST_INT || ((((body)->fld[1].rtx))->code) == HIGH || (((((body)->fld[1].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((body)->fld[1].rtx))) && ! 0)) && (!0 || !0)))
  {
    rtx src = ((body)->fld[1].rtx);
    while (((src)->code) == SUBREG
    && ((src)->fld[1].rtint) == 0)
      src = ((src)->fld[0].rtx);
    if (((src)->mode) != ((memref)->mode))
      src = gen_lowpart (((memref)->mode), ((body)->fld[1].rtx));
    validate_change (insn, &((body)->fld[1].rtx), src, 1);
  }
       else if (((((body)->fld[1].rtx))->mode) != VOIDmode
         && ((((body)->fld[1].rtx))->mode) != ((memref)->mode))






  abort ();
     }
   else
     {
       rtx dest = ((body)->fld[0].rtx);

       while (((dest)->code) == SUBREG
       && ((dest)->fld[1].rtint) == 0
       && ((mode_class[(int)(((dest)->mode))])
    == (mode_class[(int)(((((dest)->fld[0].rtx))->mode))])))
  dest = ((dest)->fld[0].rtx);

       validate_change (insn, &((body)->fld[0].rtx), dest, 1);

       if (((dest)->mode) == ((memref)->mode))
  validate_change (insn, &((body)->fld[1].rtx), memref, 1);
       else
  {

    rtx newreg = gen_reg_rtx (((dest)->mode));

    start_sequence ();
    convert_move (newreg, memref,
    ((((body)->fld[1].rtx))->code) == ZERO_EXTRACT);
    seq = get_insns ();
    end_sequence ();

    validate_change (insn, &((body)->fld[1].rtx), newreg, 1);
  }
     }
   if (apply_change_group () && seq)
     emit_insns_before (seq, insn);
 }
    }
}
static int in_arg_offset;
static int var_offset;
static int dynamic_offset;
static int out_arg_offset;
void
instantiate_virtual_regs(tree fndecl, rtx insns) asm("_instantiate_virtual_regs");
void
instantiate_virtual_regs(tree fndecl, rtx insns)
{
  rtx insn;


  in_arg_offset = 0;
  var_offset = (current_function_outgoing_args_size + ((target_flags & 0x00000400) ? (((((target_flags & 0x00002000) ? 8 : 4))+7) & ~7) : 0));
  dynamic_offset = (current_function_outgoing_args_size + (0));
  out_arg_offset = 0;





  instantiate_decls (fndecl, 1);


  init_recog ();



  for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN
 || ((insn)->code) == CALL_INSN)
      {
 instantiate_virtual_regs_1 (&((insn)->fld[3].rtx), insn, 1);
 instantiate_virtual_regs_1 (&((insn)->fld[6].rtx), (rtx) 0, 0);
      }



  instantiate_decls (fndecl, 0);



  virtuals_instantiated = 1;
}







static void
instantiate_decls(tree fndecl, int valid_only) asm("_instantiate_decls");
static void
instantiate_decls(tree fndecl, int valid_only)
{
  tree decl;

  if (((fndecl)->decl.inline_flag) || ((fndecl)->decl.defer_output))




    resume_temporary_allocation ();


  for (decl = ((fndecl)->decl.arguments); decl; decl = ((decl)->common.chain))
    {
      instantiate_decl (((decl)->decl.rtl), int_size_in_bytes (((decl)->common.type)),
   valid_only);
      instantiate_decl (((decl)->decl.saved_insns.r),
   int_size_in_bytes (((decl)->common.type)), valid_only);
    }


  instantiate_decls_1 (((fndecl)->decl.initial), valid_only);

  if (((fndecl)->decl.inline_flag) || ((fndecl)->decl.defer_output))
    {


      preserve_data ();

      rtl_in_current_obstack ();
    }
}




static void
instantiate_decls_1(tree let, int valid_only) asm("_instantiate_decls_1");
static void
instantiate_decls_1(tree let, int valid_only)
{
  tree t;

  for (t = ((let)->block.vars); t; t = ((t)->common.chain))
    instantiate_decl (((t)->decl.rtl), int_size_in_bytes (((t)->common.type)),
        valid_only);


  for (t = ((let)->block.subblocks); t; t = ((t)->common.chain))
    instantiate_decls_1 (t, valid_only);
}







static void
instantiate_decl(rtx x, int size, int valid_only) asm("_instantiate_decl");
static void
instantiate_decl(rtx x, int size, int valid_only)
{
  n64_enum_machine_mode mode;
  rtx addr;




  if (x == 0 || ((x)->code) != MEM)
    return;

  addr = ((x)->fld[0].rtx);
  if ((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == CONST_DOUBLE || ((addr)->code) == CONST || ((addr)->code) == HIGH)
      || (((addr)->code) == REG
   && (((addr)->fld[0].rtint) < (68)
       || ((addr)->fld[0].rtint) > (((68)) + 3))))
    return;






  if (valid_only)
    addr = copy_rtx (addr);

  instantiate_virtual_regs_1 (&addr, (rtx) 0, 0);

  if (! valid_only)
    return;






  for (mode = class_narrowest_mode[(int)(MODE_INT)];
       mode != VOIDmode && (mode_size[(int)(mode)]) <= size;
       mode = (mode_wider_mode[(int)(mode)]))
    if (! memory_address_p (mode, addr))
      return;

  for (mode = class_narrowest_mode[(int)(MODE_FLOAT)];
       mode != VOIDmode && (mode_size[(int)(mode)]) <= size;
       mode = (mode_wider_mode[(int)(mode)]))
    if (! memory_address_p (mode, addr))
      return;




  ((x)->fld[0].rtx) = addr;
}
static int
instantiate_virtual_regs_1(rtx *loc, rtx object, int extra_insns) asm("_instantiate_virtual_regs_1");
static int
instantiate_virtual_regs_1(rtx *loc, rtx object, int extra_insns)
{
  rtx x;
  n64_enum_rtx_code code;
  rtx cxx_new = 0;
  int offset;
  rtx temp;
  rtx seq;
  int i, j;
  char *fmt;


 restart:

  x = *loc;
  if (x == 0)
    return 1;

  code = ((x)->code);


  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case RETURN:
      return 1;

    case SET:




      if (((x)->fld[0].rtx) == virtual_incoming_args_rtx)
 cxx_new = arg_pointer_rtx, offset = - in_arg_offset;
      else if (((x)->fld[0].rtx) == virtual_stack_vars_rtx)
 cxx_new = frame_pointer_rtx, offset = - var_offset;
      else if (((x)->fld[0].rtx) == virtual_stack_dynamic_rtx)
 cxx_new = stack_pointer_rtx, offset = - dynamic_offset;
      else if (((x)->fld[0].rtx) == virtual_outgoing_args_rtx)
 cxx_new = stack_pointer_rtx, offset = - out_arg_offset;

      if (cxx_new)
 {


   if (((((x)->fld[1].rtx))->code) != REG
       && ((((x)->fld[1].rtx))->code) != PLUS)
     abort ();

   start_sequence ();
   if (((((x)->fld[1].rtx))->code) != REG)
     temp = force_operand (((x)->fld[1].rtx), (rtx) 0);
   else
     temp = ((x)->fld[1].rtx);
   temp = force_operand (plus_constant_wide (temp, (int) (offset)), (rtx) 0);
   seq = get_insns ();
   end_sequence ();

   emit_insns_before (seq, object);
   ((x)->fld[0].rtx) = cxx_new;

   if (!validate_change (object, &((x)->fld[1].rtx), temp, 0)
       || ! extra_insns)
     abort ();

   return 1;
 }

      instantiate_virtual_regs_1 (&((x)->fld[0].rtx), object, extra_insns);
      loc = &((x)->fld[1].rtx);
      goto restart;

    case PLUS:

      if ((((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH))
 {
   rtx old, new_offset;


   if (((((x)->fld[0].rtx))->code) == PLUS)
     {
       rtx inner = ((((x)->fld[0].rtx))->fld[0].rtx);

       if (inner == virtual_incoming_args_rtx)
  cxx_new = arg_pointer_rtx, offset = in_arg_offset;
       else if (inner == virtual_stack_vars_rtx)
  cxx_new = frame_pointer_rtx, offset = var_offset;
       else if (inner == virtual_stack_dynamic_rtx)
  cxx_new = stack_pointer_rtx, offset = dynamic_offset;
       else if (inner == virtual_outgoing_args_rtx)
  cxx_new = stack_pointer_rtx, offset = out_arg_offset;
       else
  {
    loc = &((x)->fld[0].rtx);
    goto restart;
  }

       instantiate_virtual_regs_1 (&((((x)->fld[0].rtx))->fld[1].rtx), object,
       extra_insns);
       cxx_new = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), cxx_new, ((((x)->fld[0].rtx))->fld[1].rtx));
     }

   else if (((x)->fld[0].rtx) == virtual_incoming_args_rtx)
     cxx_new = arg_pointer_rtx, offset = in_arg_offset;
   else if (((x)->fld[0].rtx) == virtual_stack_vars_rtx)
     cxx_new = frame_pointer_rtx, offset = var_offset;
   else if (((x)->fld[0].rtx) == virtual_stack_dynamic_rtx)
     cxx_new = stack_pointer_rtx, offset = dynamic_offset;
   else if (((x)->fld[0].rtx) == virtual_outgoing_args_rtx)
     cxx_new = stack_pointer_rtx, offset = out_arg_offset;
   else
     {



       if (((((x)->fld[0].rtx))->code) != REG)
  {
    loc = &((x)->fld[0].rtx);
    goto restart;
  }
       return 1;
     }

   new_offset = plus_constant_wide (((x)->fld[1].rtx), (int) (offset));



   if (new_offset == const0_rtx
       && validate_change (object, loc, cxx_new, 0))
     return 1;
   old = ((x)->fld[0].rtx);
   if (offset == 0
       ? ! validate_change (object, &((x)->fld[0].rtx), cxx_new, 0)
       : (((x)->fld[0].rtx) = cxx_new,
   ! validate_change (object, &((x)->fld[1].rtx), new_offset, 0)))
     {
       if (! extra_insns)
  {
    ((x)->fld[0].rtx) = old;
    return 0;
  }



       temp = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
       ((x)->fld[0].rtx) = cxx_new;
       if (validate_change (object, &((x)->fld[1].rtx), temp, 0))
  emit_insn_before (gen_move_insn (temp, new_offset), object);
       else
  {



    ((x)->fld[0].rtx) = old;
    cxx_new = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), cxx_new, new_offset);

    start_sequence ();
    temp = force_operand (cxx_new, (rtx) 0);
    seq = get_insns ();
    end_sequence ();

    emit_insns_before (seq, object);
    if (! validate_change (object, loc, temp, 0)
        && ! validate_replace_rtx (x, temp, object))
      abort ();
  }
     }

   return 1;
 }


    case EXPR_LIST:
    case CALL:
    case COMPARE:
    case MINUS:
    case MULT:
    case DIV: case UDIV:
    case MOD: case UMOD:
    case AND: case IOR: case XOR:
    case ROTATERT: case ROTATE:
    case ASHIFTRT: case LSHIFTRT: case ASHIFT:
    case NE: case EQ:
    case GE: case GT: case GEU: case GTU:
    case LE: case LT: case LEU: case LTU:
      if (((x)->fld[1].rtx) && ! (((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH))
 instantiate_virtual_regs_1 (&((x)->fld[1].rtx), object, extra_insns);
      loc = &((x)->fld[0].rtx);
      goto restart;

    case MEM:
      temp = ((x)->fld[0].rtx);
      if (((((temp)->code) == LABEL_REF || ((temp)->code) == SYMBOL_REF || ((temp)->code) == CONST_INT || ((temp)->code) == HIGH || (((temp)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (temp)) && ! 0)) && (!0 || !0))

   || temp == arg_pointer_rtx




   || temp == frame_pointer_rtx)
 return 1;

      if (((temp)->code) == PLUS
   && ((((((temp)->fld[1].rtx))->code) == LABEL_REF || ((((temp)->fld[1].rtx))->code) == SYMBOL_REF || ((((temp)->fld[1].rtx))->code) == CONST_INT || ((((temp)->fld[1].rtx))->code) == HIGH || (((((temp)->fld[1].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((temp)->fld[1].rtx))) && ! 0)) && (!0 || !0))
   && (((temp)->fld[0].rtx) == frame_pointer_rtx




       || ((temp)->fld[0].rtx) == arg_pointer_rtx

       ))
 return 1;

      if (temp == virtual_stack_vars_rtx
   || temp == virtual_incoming_args_rtx
   || (((temp)->code) == PLUS
       && ((((((temp)->fld[1].rtx))->code) == LABEL_REF || ((((temp)->fld[1].rtx))->code) == SYMBOL_REF || ((((temp)->fld[1].rtx))->code) == CONST_INT || ((((temp)->fld[1].rtx))->code) == HIGH || (((((temp)->fld[1].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((temp)->fld[1].rtx))) && ! 0)) && (!0 || !0))
       && (((temp)->fld[0].rtx) == virtual_stack_vars_rtx
    || ((temp)->fld[0].rtx) == virtual_incoming_args_rtx)))
 {
   if (instantiate_virtual_regs_1 (&((x)->fld[0].rtx),
       object ? object : x, 0))
     return 1;




   *loc = x = copy_rtx (x);
 }


    case USE:
    case CLOBBER:
    case SUBREG:
    case STRICT_LOW_PART:
    case NEG: case NOT:
    case PRE_DEC: case PRE_INC: case POST_DEC: case POST_INC:
    case SIGN_EXTEND: case ZERO_EXTEND:
    case TRUNCATE: case FLOAT_EXTEND: case FLOAT_TRUNCATE:
    case FLOAT: case FIX:
    case UNSIGNED_FIX: case UNSIGNED_FLOAT:
    case ABS:
    case SQRT:
    case FFS:


      loc = &((x)->fld[0].rtx);
      goto restart;

    case REG:


      if (x == virtual_incoming_args_rtx)
 cxx_new = arg_pointer_rtx, offset = in_arg_offset;
      else if (x == virtual_stack_vars_rtx)
 cxx_new = frame_pointer_rtx, offset = var_offset;
      else if (x == virtual_stack_dynamic_rtx)
 cxx_new = stack_pointer_rtx, offset = dynamic_offset;
      else if (x == virtual_outgoing_args_rtx)
 cxx_new = stack_pointer_rtx, offset = out_arg_offset;

      if (cxx_new)
 {
   temp = plus_constant_wide (cxx_new, (int) (offset));
   if (!validate_change (object, loc, temp, 0))
     {
       if (! extra_insns)
  return 0;

       start_sequence ();
       temp = force_operand (temp, (rtx) 0);
       seq = get_insns ();
       end_sequence ();

       emit_insns_before (seq, object);
       if (! validate_change (object, loc, temp, 0)
    && ! validate_replace_rtx (x, temp, object))
  abort ();
     }
 }

      return 1;
    }


  fmt = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++, fmt++)
    if (*fmt == 'e')
      {
 if (!instantiate_virtual_regs_1 (&((x)->fld[i].rtx), object, extra_insns))
   return 0;
      }
    else if (*fmt == 'E')
      for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
 if (! instantiate_virtual_regs_1 (&((x)->fld[i].rtvec->elem[j].rtx), object,
       extra_insns))
   return 0;

  return 1;
}





static void
delete_handlers(void) asm("_delete_handlers");
static void
delete_handlers(void)
{
  rtx insn;
  for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
    {




      if (((insn)->code) == CODE_LABEL)
 {
   tree t, last_t;

   ((insn)->in_struct) = 0;



   for (t = nonlocal_labels, last_t = 0; t;
        last_t = t, t = ((t)->common.chain))
     if (((((t)->list.value))->decl.rtl) == insn)
       break;
   if (t)
     {
       if (! last_t)
  nonlocal_labels = ((nonlocal_labels)->common.chain);
       else
  ((last_t)->common.chain) = ((t)->common.chain);
     }
 }
      if (((insn)->code) == INSN
   && ((nonlocal_goto_handler_slot != 0
        && reg_mentioned_p (nonlocal_goto_handler_slot, ((insn)->fld[3].rtx)))
       || (nonlocal_goto_stack_level != 0
    && reg_mentioned_p (nonlocal_goto_stack_level,
          ((insn)->fld[3].rtx)))))
 delete_insn (insn);
    }
}




rtx
nonlocal_label_rtx_list(void) asm("_nonlocal_label_rtx_list");
rtx
nonlocal_label_rtx_list(void)
{
  tree t;
  rtx x = 0;

  for (t = nonlocal_labels; t; t = ((t)->common.chain))
    x = gen_rtx (EXPR_LIST, VOIDmode, label_rtx (((t)->list.value)), x);

  return x;
}





void
use_variable(rtx rtl) asm("_use_variable");
void
use_variable(rtx rtl)
{
  if (((rtl)->code) == REG)

    emit_insn (gen_rtx (USE, VOIDmode, rtl));
  else if (((rtl)->code) == MEM
    && ((((rtl)->fld[0].rtx))->code) == REG
    && (((((rtl)->fld[0].rtx))->fld[0].rtint) < (68)
        || ((((rtl)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3))
    && ((rtl)->fld[0].rtx) != current_function_internal_arg_pointer)

    emit_insn (gen_rtx (USE, VOIDmode, ((rtl)->fld[0].rtx)));
}




void
use_variable_after(rtx rtl, rtx insn) asm("_use_variable_after");
void
use_variable_after(rtx rtl, rtx insn)
{
  if (((rtl)->code) == REG)

    emit_insn_after (gen_rtx (USE, VOIDmode, rtl), insn);
  else if (((rtl)->code) == MEM
    && ((((rtl)->fld[0].rtx))->code) == REG
    && (((((rtl)->fld[0].rtx))->fld[0].rtint) < (68)
        || ((((rtl)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3))
    && ((rtl)->fld[0].rtx) != current_function_internal_arg_pointer)

    emit_insn_after (gen_rtx (USE, VOIDmode, ((rtl)->fld[0].rtx)), insn);
}

int
max_parm_reg_num(void) asm("_max_parm_reg_num");
int
max_parm_reg_num(void)
{
  return max_parm_reg;
}



rtx
get_first_nonparm_insn(void) asm("_get_first_nonparm_insn");
rtx
get_first_nonparm_insn(void)
{
  if (last_parm_insn)
    return ((last_parm_insn)->fld[2].rtx);
  return get_insns ();
}




rtx
get_first_block_beg(void) asm("_get_first_block_beg");
rtx
get_first_block_beg(void)
{
  register rtx searcher;
  register rtx insn = get_first_nonparm_insn ();

  for (searcher = insn; searcher; searcher = ((searcher)->fld[2].rtx))
    if (((searcher)->code) == NOTE
 && ((searcher)->fld[4].rtint) == -2)
      return searcher;

  abort ();
  return (rtx) 0;
}






int
aggregate_value_p(tree exp) asm("_aggregate_value_p");
int
aggregate_value_p(tree exp)
{
  int i, regno, nregs;
  rtx reg;
  tree type;
  if ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 't')
    type = exp;
  else
    type = ((exp)->common.type);

  if ((((type)->type.mode) == BLKmode))
    return 1;
  if (flag_pcc_struct_return && (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE))
    return 1;


  reg = hard_function_value (type, 0);
  regno = ((reg)->fld[0].rtint);
  nregs = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((type)->type.mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((type)->type.mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  for (i = 0; i < nregs; i++)
    if (! call_used_regs[regno + i])
      return 1;
  return 0;
}
void
assign_parms(tree fndecl, int second_time) asm("_assign_parms");
void
assign_parms(tree fndecl, int second_time)
{
  register tree parm;
  register rtx entry_parm = 0;
  register rtx stack_parm = 0;
  CUMULATIVE_ARGS args_so_far;
  n64_enum_machine_mode promoted_mode, passed_mode;
  n64_enum_machine_mode nominal_mode, promoted_nominal_mode;
  int unsignedp;


  struct n64_tag_args_size stack_args_size;
  tree fntype = ((fndecl)->common.type);
  tree fnargs = ((fndecl)->decl.arguments);

  rtx internal_arg_pointer;


  tree function_result_decl = 0;
  int nparmregs = list_length (fnargs) + (((68)) + 3) + 1;
  int varargs_setup = 0;
  rtx conversion_insns = 0;


  int current_call_is_indirect = 0;




  int hide_last_arg
    = (current_function_varargs
       && fnargs
       && (parm = tree_last (fnargs)) != 0
       && ((parm)->decl.name)
       && (! strcmp (((((parm)->decl.name))->identifier.pointer),
       "__builtin_va_alist")));




  int stdarg
    = (((fntype)->type.values) != 0
       && (((tree_last (((fntype)->type.values)))->list.value)
    != void_type_node));

  current_function_stdarg = stdarg;
  if ((0 == (0 + 29)
       || ! (fixed_regs[0]
      || 0 == (0 + 30)))
      && ! second_time)
    internal_arg_pointer = copy_to_reg (virtual_incoming_args_rtx);
  else
    internal_arg_pointer = virtual_incoming_args_rtx;
  current_function_internal_arg_pointer = internal_arg_pointer;

  stack_args_size.constant = 0;
  stack_args_size.var = 0;


  if (aggregate_value_p (((fndecl)->decl.result))
      && ! current_function_returns_pcc_struct
      && struct_value_incoming_rtx == 0)
    {
      tree type = build_pointer_type (fntype);

      function_result_decl = build_decl (PARM_DECL, (tree) 
                                                   ((void *)0)
                                                            , type);

      ((function_result_decl)->decl.initial) = type;
      ((function_result_decl)->common.chain) = fnargs;
      fnargs = function_result_decl;
    }

  parm_reg_stack_loc = (rtx *) oballoc (nparmregs * sizeof (rtx));
  memset ((char *) parm_reg_stack_loc,0,nparmregs * sizeof (rtx));




  init_cumulative_args (&args_so_far, fntype, (rtx) 0);




  current_function_pretend_args_size = 0;

  for (parm = fnargs; parm; parm = ((parm)->common.chain))
    {
      int aggregate = (((n64_enum_tree_code) (((parm)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((parm)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((parm)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((parm)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((parm)->common.type))->common.code) == SET_TYPE);
      struct n64_tag_args_size stack_offset;
      struct n64_tag_args_size arg_size;
      int passed_pointer = 0;
      int did_conversion = 0;
      tree passed_type = ((parm)->decl.initial);
      tree nominal_type = ((parm)->common.type);



      int last_named = ((((parm)->common.chain) == 0
    || ((((parm)->common.chain))->decl.name) == 0)
   && (stdarg || current_function_varargs));

      if (((parm)->common.type) == error_mark_node


   || ((n64_enum_tree_code) (parm)->common.code) != PARM_DECL
   || passed_type == 
                    ((void *)0)
                        )
 {
   ((parm)->decl.saved_insns.r) = ((parm)->decl.rtl) = gen_rtx (MEM, BLKmode,
        const0_rtx);
   ((parm)->common.used_flag) = 1;
   continue;
 }



      if (hide_last_arg && last_named)
 current_function_args_info = args_so_far;



      passed_mode = ((passed_type)->type.mode);
      nominal_mode = ((nominal_type)->type.mode);



      if (nominal_mode == VOIDmode)
 {
   ((parm)->decl.saved_insns.r) = ((parm)->decl.rtl) = const0_rtx;
   continue;
 }




      if (((parm)->decl.transparent_union)
   || ((passed_type)->type.transparent_union_flag))
 passed_type = ((((passed_type)->type.values))->common.type);






      if ((((n64_enum_tree_code) (((passed_type)->type.size))->common.code) != INTEGER_CST
    && contains_placeholder_p (((passed_type)->type.size)))
   || ((passed_type)->common.addressable_flag)




   )
 {
   passed_type = nominal_type = build_pointer_type (passed_type);
   passed_pointer = 1;
   passed_mode = nominal_mode = ((target_flags & 0x00000002) ? DImode : SImode);
 }

      promoted_mode = passed_mode;
      entry_parm = function_arg( &args_so_far, promoted_mode, passed_type, ! last_named)
                               ;


      if (entry_parm == 0)
 promoted_mode = passed_mode;
      locate_and_pad_parm (promoted_mode, passed_type,
      function_arg( &args_so_far, promoted_mode, passed_type, ! last_named || varargs_setup)

                                     != 0,


      fndecl, &stack_args_size, &stack_offset, &arg_size);

      if (! second_time)
 {
   rtx offset_rtx = ((stack_offset).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((stack_offset).constant)) : expand_expr (size_binop (PLUS_EXPR, (stack_offset).var, size_int ((stack_offset).constant)), (rtx) 0, VOIDmode, 0));

   if (offset_rtx == const0_rtx)
     stack_parm = gen_rtx (MEM, promoted_mode, internal_arg_pointer);
   else
     stack_parm = gen_rtx (MEM, promoted_mode,
      gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode),
        internal_arg_pointer, offset_rtx));



   ((stack_parm)->in_struct) = aggregate;
 }



      if (((passed_type) != 0 && (((n64_enum_tree_code) (((passed_type)->type.size))->common.code) != INTEGER_CST || ((passed_type)->common.addressable_flag) || ((promoted_mode) == BLKmode && ! ((passed_type) != 0 && ((n64_enum_tree_code) (((passed_type)->type.size))->common.code) == INTEGER_CST && 0 == (int_size_in_bytes (passed_type) % (((target_flags & 0x00002000) ? 64 : 32) / 8))) && ((! ((target_flags & 0x00010000) != 0) ? upward : (((promoted_mode) == BLKmode ? ((passed_type) && ((n64_enum_tree_code) (((passed_type)->type.size))->common.code) == INTEGER_CST && int_size_in_bytes (passed_type) < (((target_flags & 0x00002000) ? 64 : 32) / 8)) : (8 * mode_size[(int)(promoted_mode)]) < ((target_flags & 0x00002000) ? 64 : 32)) ? downward : upward)) == (((target_flags & 0x00010000) != 0) ? upward : downward))))))
 entry_parm = 0;
      if (entry_parm)
 {
   int nregs = function_arg_partial_nregs (&args_so_far, promoted_mode, passed_type, ! last_named)
                                  ;

   if (nregs > 0)
     {
       current_function_pretend_args_size
  = (((nregs * ((target_flags & 0x00002000) ? 8 : 4)) + (((target_flags & 0x00002000) ? 64 : 32) / 8) - 1)
     / (((target_flags & 0x00002000) ? 64 : 32) / 8)
     * (((target_flags & 0x00002000) ? 64 : 32) / 8));

       if (! second_time)
  move_block_from_reg (((entry_parm)->fld[0].rtint),
         validize_mem (stack_parm), nregs,
         int_size_in_bytes (((parm)->common.type)));
       entry_parm = stack_parm;
     }
 }




      if (entry_parm == 0)
 entry_parm = stack_parm;


      if (! second_time)
 ((parm)->decl.saved_insns.r) = entry_parm;





      if (entry_parm == stack_parm
   || ((4*((target_flags & 0x00002000) ? 8 : 4)) - 0) > 0

   )
 {
   stack_args_size.constant += arg_size.constant;
   if (arg_size.var)
     { tree inc = (arg_size.var); if (((n64_enum_tree_code) (inc)->common.code) == INTEGER_CST) (stack_args_size).constant += ((inc)->int_cst.int_cst_low); else if ((stack_args_size).var == 0) (stack_args_size).var = inc; else (stack_args_size).var = size_binop (PLUS_EXPR, (stack_args_size).var, inc); };
 }
      else

 stack_parm = 0;



      function_arg_advance (&args_so_far, promoted_mode, passed_type, ! last_named)
                                 ;


      if (second_time)
 continue;




      {
 int thisparm_boundary
   = (((passed_type) != 0) ? ((((passed_type)->type.align) <= ((target_flags & 0x00002000) ? 64 : 32)) ? ((target_flags & 0x00002000) ? 64 : 32) : ((passed_type)->type.align)) : ((((64) < (((1) > (((mode_unit_size[(int)(promoted_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(promoted_mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(promoted_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(promoted_mode)]) * 8))))) <= ((target_flags & 0x00002000) ? 64 : 32)) ? ((target_flags & 0x00002000) ? 64 : 32) : ((64) < (((1) > (((mode_unit_size[(int)(promoted_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(promoted_mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(promoted_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(promoted_mode)]) * 8)))))));

 if (((64) < (((1) > (((mode_unit_size[(int)(nominal_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(nominal_mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(nominal_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(nominal_mode)]) * 8))))) > thisparm_boundary)
   stack_parm = 0;
      }



      if (entry_parm != 0
   && nominal_mode != BLKmode && nominal_mode != passed_mode)
 stack_parm = 0;
      if (nominal_mode == BLKmode)
 {

   if (((entry_parm)->code) == REG)
     {
       int size_stored
  = (((int_size_in_bytes (((parm)->common.type))) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) & ~((((target_flags & 0x00002000) ? 8 : 4))- 1))
                        ;
       if (stack_parm == 0)
  {
    stack_parm
      = assign_stack_local (((entry_parm)->mode),
       size_stored, 0);



    ((stack_parm)->in_struct) = aggregate;
  }

       else if (((target_flags & 0x00002000) ? 64 : 32) % ((target_flags & 0x00002000) ? 64 : 32) != 0)
  abort ();

       if (((parm)->common.readonly_flag))
  ((stack_parm)->unchanging) = 1;

       move_block_from_reg (((entry_parm)->fld[0].rtint),
       validize_mem (stack_parm),
       size_stored / ((target_flags & 0x00002000) ? 8 : 4),
       int_size_in_bytes (((parm)->common.type)));
     }
   ((parm)->decl.rtl) = stack_parm;
 }
      else if (! ((obey_regdecls && ! ((parm)->decl.regdecl_flag)
     && ! ((fndecl)->decl.inline_flag))

    || ((parm)->common.addressable_flag)
    || ((parm)->common.side_effects_flag)


    || (flag_float_store
        && ((n64_enum_tree_code) (((parm)->common.type))->common.code) == REAL_TYPE))


        || passed_pointer || parm == function_result_decl)
 {



   register rtx parmreg;
   int regno, regnoi, regnor;

   unsignedp = ((((parm)->common.type))->common.unsigned_flag);

   promoted_nominal_mode
     = promote_mode (((parm)->common.type), nominal_mode, &unsignedp, 0);

   parmreg = gen_reg_rtx (promoted_nominal_mode);
   ((parmreg)->volatil) = 1;



   if (passed_pointer)
     {
       ((parm)->decl.rtl)
  = gen_rtx (MEM, ((((passed_type)->common.type))->type.mode), parmreg);
       ((((parm)->decl.rtl))->in_struct) = aggregate;
     }
   else
     ((parm)->decl.rtl) = parmreg;


   if (nominal_mode != passed_mode
       || promoted_nominal_mode != promoted_mode)
     {
       rtx tempreg = gen_reg_rtx (((entry_parm)->mode));

       emit_move_insn (tempreg, validize_mem (entry_parm));

       push_to_sequence (conversion_insns);
       tempreg = convert_to_mode (nominal_mode, tempreg, unsignedp);

       expand_assignment (parm,
     make_tree (nominal_type, tempreg), 0, 0);
       conversion_insns = get_insns ();
       did_conversion = 1;
       end_sequence ();
     }
   else
     emit_move_insn (parmreg, validize_mem (entry_parm));



   if (passed_pointer && ((((parm)->common.type))->type.mode) != BLKmode
       && ! ((obey_regdecls && ! ((parm)->decl.regdecl_flag)
       && ! ((fndecl)->decl.inline_flag))

      || ((parm)->common.addressable_flag)
      || ((parm)->common.side_effects_flag)


      || (flag_float_store
   && ((n64_enum_tree_code) (((parm)->common.type))->common.code) == REAL_TYPE)))
     {


       parmreg = gen_reg_rtx (((((parm)->common.type))->type.mode));
       ((parmreg)->volatil) = 1;
       emit_move_insn (parmreg, ((parm)->decl.rtl));
       ((parm)->decl.rtl) = parmreg;


       stack_parm = 0;
     }
   if (((parmreg)->code) == CONCAT)
     regno = ((((((parmreg)->fld[0].rtx))->fld[0].rtint)) > (((((parmreg)->fld[1].rtx))->fld[0].rtint)) ? (((((parmreg)->fld[0].rtx))->fld[0].rtint)) : (((((parmreg)->fld[1].rtx))->fld[0].rtint)));
   else
     regno = ((parmreg)->fld[0].rtint);

   if (regno >= nparmregs)
     {
       rtx *cxx_new;
       int old_nparmregs = nparmregs;

       nparmregs = regno + 5;
       cxx_new = (rtx *) oballoc (nparmregs * sizeof (rtx));
       memcpy ((char *) cxx_new,(char *) parm_reg_stack_loc,old_nparmregs * sizeof (rtx))
                                    ;
       memset ((char *) (cxx_new + old_nparmregs),0,(nparmregs - old_nparmregs) * sizeof (rtx))
                                                  ;
       parm_reg_stack_loc = cxx_new;
     }

   if (((parmreg)->code) == CONCAT)
     {
       n64_enum_machine_mode submode = ((((parmreg)->fld[0].rtx))->mode);

       regnor = ((gen_realpart (submode, parmreg))->fld[0].rtint);
       regnoi = ((gen_imagpart (submode, parmreg))->fld[0].rtint);

       if (stack_parm != 0)
  {
    parm_reg_stack_loc[regnor]
      = gen_realpart (submode, stack_parm);
    parm_reg_stack_loc[regnoi]
      = gen_imagpart (submode, stack_parm);
  }
       else
  {
    parm_reg_stack_loc[regnor] = 0;
    parm_reg_stack_loc[regnoi] = 0;
  }
     }
   else
     parm_reg_stack_loc[((parmreg)->fld[0].rtint)] = stack_parm;







   if (nominal_mode == passed_mode
       && ! did_conversion
       && ((entry_parm)->code) == MEM
       && entry_parm == stack_parm
       && stack_offset.var == 0
       && reg_mentioned_p (virtual_incoming_args_rtx,
      ((entry_parm)->fld[0].rtx)))
     {
       rtx linsn = get_last_insn ();


       if (((parmreg)->code) == CONCAT)
         {
           ((linsn)->fld[6].rtx)
               = gen_rtx (EXPR_LIST, REG_EQUIV,
     parm_reg_stack_loc[regnoi], ((linsn)->fld[6].rtx));


    for (; linsn != 0
         && ! reg_referenced_p (parm_reg_stack_loc[regnor],
           ((linsn)->fld[3].rtx));
         linsn = prev_nonnote_insn (linsn))
      ;

           ((linsn)->fld[6].rtx)
               = gen_rtx (EXPR_LIST, REG_EQUIV,
     parm_reg_stack_loc[regnor], ((linsn)->fld[6].rtx));
  }
       else
         ((linsn)->fld[6].rtx)
          = gen_rtx (EXPR_LIST, REG_EQUIV,
       entry_parm, ((linsn)->fld[6].rtx));
     }


   if (((n64_enum_tree_code) (((parm)->common.type))->common.code) == POINTER_TYPE)
     mark_reg_pointer (parmreg);
 }
      else
 {



   if (promoted_mode != nominal_mode)
     {

       rtx tempreg = gen_reg_rtx (((entry_parm)->mode));

       emit_move_insn (tempreg, validize_mem (entry_parm));

       push_to_sequence (conversion_insns);
       entry_parm = convert_to_mode (nominal_mode, tempreg,
         ((((parm)->common.type))->common.unsigned_flag));
       conversion_insns = get_insns ();
       did_conversion = 1;
       end_sequence ();
     }

   if (entry_parm != stack_parm)
     {
       if (stack_parm == 0)
  {
    stack_parm
      = assign_stack_local (((entry_parm)->mode),
       (mode_size[(int)(((entry_parm)->mode))]), 0);


    ((stack_parm)->in_struct) = aggregate;
  }

       if (promoted_mode != nominal_mode)
  {
    push_to_sequence (conversion_insns);
    emit_move_insn (validize_mem (stack_parm),
      validize_mem (entry_parm));
    conversion_insns = get_insns ();
    end_sequence ();
  }
       else
  emit_move_insn (validize_mem (stack_parm),
    validize_mem (entry_parm));
     }

   ((parm)->decl.rtl) = stack_parm;
 }



      if (parm == function_result_decl)
 {
   tree result = ((fndecl)->decl.result);
   tree restype = ((result)->common.type);

   ((result)->decl.rtl)
     = gen_rtx (MEM, ((result)->decl.mode), ((parm)->decl.rtl));

   ((((result)->decl.rtl))->in_struct) = (((n64_enum_tree_code) (restype)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (restype)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (restype)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (restype)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (restype)->common.code) == SET_TYPE);
 }

      if (((parm)->common.volatile_flag))
 ((((parm)->decl.rtl))->volatil) = 1;
      if (((parm)->common.readonly_flag))
 ((((parm)->decl.rtl))->unchanging) = 1;
    }



  emit_insns (conversion_insns);

  max_parm_reg = max_reg_num ();
  last_parm_insn = get_last_insn ();

  current_function_args_size = stack_args_size.constant;






  current_function_args_size = ((current_function_args_size) > (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)) ? (current_function_args_size) : (((4*((target_flags & 0x00002000) ? 8 : 4)) - 0)))
                                      ;






  current_function_args_size
    = ((current_function_args_size + (64 / 8) - 1)
       / (64 / 8)) * (64 / 8);
  current_function_arg_offset_rtx = ((stack_args_size).var == 0 ? gen_rtx (CONST_INT, VOIDmode, (int) ((stack_args_size).constant)) : expand_expr (size_binop (PLUS_EXPR, (stack_args_size).var, size_int ((stack_args_size).constant)), (rtx) 0, VOIDmode, 0));





  current_function_pops_args = 0
                                  ;




  if (!hide_last_arg)
    current_function_args_info = args_so_far;






  current_function_return_rtx = ((((fndecl)->decl.result))->decl.rtl);
}
void
locate_and_pad_parm(n64_enum_machine_mode passed_mode, tree type, int in_regs, tree fndecl, struct n64_tag_args_size *initial_offset_ptr, struct n64_tag_args_size *offset_ptr, struct n64_tag_args_size *arg_size_ptr) asm("_locate_and_pad_parm");
void
locate_and_pad_parm(n64_enum_machine_mode passed_mode, tree type, int in_regs, tree fndecl, struct n64_tag_args_size *initial_offset_ptr, struct n64_tag_args_size *offset_ptr, struct n64_tag_args_size *arg_size_ptr)
{
  tree sizetree
    = type ? size_in_bytes (type) : size_int ((mode_size[(int)(passed_mode)]));
  n64_enum_direction where_pad = (! ((target_flags & 0x00010000) != 0) ? upward : (((passed_mode) == BLKmode ? ((type) && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST && int_size_in_bytes (type) < (((target_flags & 0x00002000) ? 64 : 32) / 8)) : (8 * mode_size[(int)(passed_mode)]) < ((target_flags & 0x00002000) ? 64 : 32)) ? downward : upward));
  int boundary = (((type) != 0) ? ((((type)->type.align) <= ((target_flags & 0x00002000) ? 64 : 32)) ? ((target_flags & 0x00002000) ? 64 : 32) : ((type)->type.align)) : ((((64) < (((1) > (((mode_unit_size[(int)(passed_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(passed_mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(passed_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(passed_mode)]) * 8))))) <= ((target_flags & 0x00002000) ? 64 : 32)) ? ((target_flags & 0x00002000) ? 64 : 32) : ((64) < (((1) > (((mode_unit_size[(int)(passed_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(passed_mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(passed_mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(passed_mode)]) * 8)))))));
  int boundary_in_bytes = boundary / 8;
  int reg_parm_stack_space = 0;




  if (! in_regs)
    {



      reg_parm_stack_space = ((4*((target_flags & 0x00002000) ? 8 : 4)) - 0);

      if (reg_parm_stack_space > 0)
 {
   if (initial_offset_ptr->var)
     {
       initial_offset_ptr->var
  = size_binop (MAX_EXPR, ((*initial_offset_ptr).var == 0 ? size_int ((*initial_offset_ptr).constant) : size_binop (PLUS_EXPR, (*initial_offset_ptr).var, size_int ((*initial_offset_ptr).constant))),
         size_int (reg_parm_stack_space));
       initial_offset_ptr->constant = 0;
     }
   else if (initial_offset_ptr->constant < reg_parm_stack_space)
     initial_offset_ptr->constant = reg_parm_stack_space;
 }
    }


  arg_size_ptr->var = 0;
  arg_size_ptr->constant = 0;
  pad_to_arg_alignment (initial_offset_ptr, boundary);
  *offset_ptr = *initial_offset_ptr;
  if (where_pad == downward


      && !(in_regs && passed_mode == BLKmode))
    pad_below (offset_ptr, passed_mode, sizetree);

  if (where_pad != none
      && (((n64_enum_tree_code) (sizetree)->common.code) != INTEGER_CST
   || ((((sizetree)->int_cst.int_cst_low) * 8) % ((target_flags & 0x00002000) ? 64 : 32))))
    sizetree = round_up (sizetree, ((target_flags & 0x00002000) ? 64 : 32) / 8);

  { tree inc = (sizetree); if (((n64_enum_tree_code) (inc)->common.code) == INTEGER_CST) (*arg_size_ptr).constant += ((inc)->int_cst.int_cst_low); else if ((*arg_size_ptr).var == 0) (*arg_size_ptr).var = inc; else (*arg_size_ptr).var = size_binop (PLUS_EXPR, (*arg_size_ptr).var, inc); };

}




static void
pad_to_arg_alignment(struct n64_tag_args_size *offset_ptr, int boundary) asm("_pad_to_arg_alignment");
static void
pad_to_arg_alignment(struct n64_tag_args_size *offset_ptr, int boundary)
{
  int boundary_in_bytes = boundary / 8;

  if (boundary > 8)
    {
      if (offset_ptr->var)
 {
   offset_ptr->var =



     round_up

       (((*offset_ptr).var == 0 ? size_int ((*offset_ptr).constant) : size_binop (PLUS_EXPR, (*offset_ptr).var, size_int ((*offset_ptr).constant))),
        boundary / 8);
   offset_ptr->constant = 0;
 }
      else
 offset_ptr->constant =



   (((offset_ptr->constant) + (boundary_in_bytes) - 1) & ~((boundary_in_bytes)- 1));

    }
}

static void
pad_below(struct n64_tag_args_size *offset_ptr, n64_enum_machine_mode passed_mode, tree sizetree) asm("_pad_below");
static void
pad_below(struct n64_tag_args_size *offset_ptr, n64_enum_machine_mode passed_mode, tree sizetree)
{
  if (passed_mode != BLKmode)
    {
      if ((8 * mode_size[(int)(passed_mode)]) % ((target_flags & 0x00002000) ? 64 : 32))
 offset_ptr->constant
   += ((((8 * mode_size[(int)(passed_mode)]) + ((target_flags & 0x00002000) ? 64 : 32) - 1)
        / ((target_flags & 0x00002000) ? 64 : 32) * ((target_flags & 0x00002000) ? 64 : 32) / 8)
       - (mode_size[(int)(passed_mode)]));
    }
  else
    {
      if (((n64_enum_tree_code) (sizetree)->common.code) != INTEGER_CST
   || (((sizetree)->int_cst.int_cst_low) * 8) % ((target_flags & 0x00002000) ? 64 : 32))
 {

   tree s2 = round_up (sizetree, ((target_flags & 0x00002000) ? 64 : 32) / 8);

   { tree inc = (s2); if (((n64_enum_tree_code) (inc)->common.code) == INTEGER_CST) (*offset_ptr).constant += ((inc)->int_cst.int_cst_low); else if ((*offset_ptr).var == 0) (*offset_ptr).var = inc; else (*offset_ptr).var = size_binop (PLUS_EXPR, (*offset_ptr).var, inc); };
   { tree dec = (sizetree); if (((n64_enum_tree_code) (dec)->common.code) == INTEGER_CST) (*offset_ptr).constant -= ((dec)->int_cst.int_cst_low); else if ((*offset_ptr).var == 0) (*offset_ptr).var = size_binop (MINUS_EXPR, integer_zero_node, dec); else (*offset_ptr).var = size_binop (MINUS_EXPR, (*offset_ptr).var, dec); };
 }
    }
}

static tree
round_down(tree value, int divisor) asm("_round_down");
static tree
round_down(tree value, int divisor)
{
  return size_binop (MULT_EXPR,
       size_binop (FLOOR_DIV_EXPR, value, size_int (divisor)),
       size_int (divisor));
}






void
uninitialized_vars_warning(tree block) asm("_uninitialized_vars_warning");
void
uninitialized_vars_warning(tree block)
{
  register tree decl, sub;
  for (decl = ((block)->block.vars); decl; decl = ((decl)->common.chain))
    {
      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL




   && ! (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == SET_TYPE)
   && ((decl)->decl.rtl) != 0
   && ((((decl)->decl.rtl))->code) == REG
   && regno_uninitialized (((((decl)->decl.rtl))->fld[0].rtint)))
 warning_with_decl (decl,
      "`%s' might be used uninitialized in this function");
      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
   && ((decl)->decl.rtl) != 0
   && ((((decl)->decl.rtl))->code) == REG
   && regno_clobbered_at_setjmp (((((decl)->decl.rtl))->fld[0].rtint)))
 warning_with_decl (decl,
      "variable `%s' might be clobbered by `longjmp' or `vfork'");
    }
  for (sub = ((block)->block.subblocks); sub; sub = ((sub)->common.chain))
    uninitialized_vars_warning (sub);
}




void
setjmp_args_warning(void) asm("_setjmp_args_warning");
void
setjmp_args_warning(void)
{
  register tree decl;
  for (decl = ((current_function_decl)->decl.arguments);
       decl; decl = ((decl)->common.chain))
    if (((decl)->decl.rtl) != 0
 && ((((decl)->decl.rtl))->code) == REG
 && regno_clobbered_at_setjmp (((((decl)->decl.rtl))->fld[0].rtint)))
      warning_with_decl (decl, "argument `%s' might be clobbered by `longjmp' or `vfork'");
}




void
setjmp_protect(tree block) asm("_setjmp_protect");
void
setjmp_protect(tree block)
{
  register tree decl, sub;
  for (decl = ((block)->block.vars); decl; decl = ((decl)->common.chain))
    if ((((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
  || ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
 && ((decl)->decl.rtl) != 0
 && ((((decl)->decl.rtl))->code) == REG





 && ! (((decl)->decl.abstract_origin) != (tree) 0)
 && (






     ! ((decl)->decl.regdecl_flag)))
      put_var_into_stack (decl);
  for (sub = ((block)->block.subblocks); sub; sub = ((sub)->common.chain))
    setjmp_protect (sub);
}



void
setjmp_protect_args(void) asm("_setjmp_protect_args");
void
setjmp_protect_args(void)
{
  register tree decl, sub;
  for (decl = ((current_function_decl)->decl.arguments);
       decl; decl = ((decl)->common.chain))
    if ((((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
  || ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
 && ((decl)->decl.rtl) != 0
 && ((((decl)->decl.rtl))->code) == REG
 && (






     ! ((decl)->decl.regdecl_flag)))
      put_var_into_stack (decl);
}




rtx
lookup_static_chain(tree decl) asm("_lookup_static_chain");
rtx
lookup_static_chain(tree decl)
{
  tree context = decl_function_context (decl);
  tree link;

  if (context == 0)
    return 0;





  if (context == current_function_decl || context == inline_function_decl)
    return virtual_stack_vars_rtx;

  for (link = context_display; link; link = ((link)->common.chain))
    if (((link)->list.purpose) == context)
      return (*(struct n64_tag_rtx_def **) &(((link)->list.value))->exp.operands[1]);

  abort ();
}





rtx
fix_lexical_addr(rtx addr, tree var) asm("_fix_lexical_addr");
rtx
fix_lexical_addr(rtx addr, tree var)
{
  rtx basereg;
  int displacement;
  tree context = decl_function_context (var);
  struct n64_tag_function *fp;
  rtx base = 0;


  if (context == current_function_decl || context == inline_function_decl)
    return addr;

  for (fp = outer_function_chain; fp; fp = fp->next)
    if (fp->decl == context)
      break;

  if (fp == 0)
    abort ();


  if (((addr)->code) == REG)
    basereg = addr, displacement = 0;
  else if (((addr)->code) == PLUS && ((((addr)->fld[1].rtx))->code) == CONST_INT)
    basereg = ((addr)->fld[0].rtx), displacement = ((((addr)->fld[1].rtx))->fld[0].rtwint);
  else
    abort ();



  if (basereg == fp->internal_arg_pointer)
    {
      rtx addr;

      if (fp->arg_pointer_save_area == 0)
 fp->arg_pointer_save_area
   = assign_outer_stack_local (((target_flags & 0x00000002) ? DImode : SImode), (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]), 0, fp);

      addr = fix_lexical_addr (((fp->arg_pointer_save_area)->fld[0].rtx), var);
      addr = memory_address (((target_flags & 0x00000002) ? DImode : SImode), addr);

      base = copy_to_reg (gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), addr));




    }

  else if (basereg == virtual_stack_vars_rtx)
    {


      tree link;

      for (link = context_display; link; link = ((link)->common.chain))
 if (((link)->list.purpose) == context)
   {
     base = (*(struct n64_tag_rtx_def **) &(((link)->list.value))->exp.operands[1]);
     break;
   }
    }

  if (base == 0)
    abort ();



  return plus_constant_wide (base, (int) (displacement));
}





rtx
trampoline_address(tree function) asm("_trampoline_address");
rtx
trampoline_address(tree function)
{
  tree link;
  tree rtlexp;
  rtx tramp;
  struct n64_tag_function *fp;
  tree fn_context;


  for (link = trampoline_list; link; link = ((link)->common.chain))
    if (((link)->list.purpose) == function)
      return
 round_trampoline_addr ((((*(struct n64_tag_rtx_def **) &(((link)->list.value))->exp.operands[1]))->fld[0].rtx));

  for (fp = outer_function_chain; fp; fp = fp->next)
    for (link = fp->trampoline_list; link; link = ((link)->common.chain))
      if (((link)->list.purpose) == function)
 {
   tramp = fix_lexical_addr ((((*(struct n64_tag_rtx_def **) &(((link)->list.value))->exp.operands[1]))->fld[0].rtx),
        function);
   return round_trampoline_addr (tramp);
 }




  fp = 0;
  fn_context = decl_function_context (function);
  if (fn_context != current_function_decl)
    for (fp = outer_function_chain; fp; fp = fp->next)
      if (fp->decl == fn_context)
 break;
  if (fp != 0)
    tramp = assign_outer_stack_local (BLKmode, ((32 + ((target_flags & 0x00000002) ? 16 : 8)) + ((target_flags & 0x00000002) ? 64 : 32) - 1), 0, fp);
  else
    tramp = assign_stack_local (BLKmode, ((32 + ((target_flags & 0x00000002) ? 16 : 8)) + ((target_flags & 0x00000002) ? 64 : 32) - 1), 0);




  if (fp != 0)
    {
      push_obstacks (fp->function_maybepermanent_obstack,
       fp->function_maybepermanent_obstack);
      rtlexp = make_node (RTL_EXPR);
      (*(struct n64_tag_rtx_def **) &(rtlexp)->exp.operands[1]) = tramp;
      fp->trampoline_list = tree_cons (function, rtlexp, fp->trampoline_list);
      pop_obstacks ();
    }
  else
    {


      int momentary = suspend_momentary ();
      rtlexp = make_node (RTL_EXPR);
      resume_momentary (momentary);

      (*(struct n64_tag_rtx_def **) &(rtlexp)->exp.operands[1]) = tramp;
      trampoline_list = tree_cons (function, rtlexp, trampoline_list);
    }

  tramp = fix_lexical_addr (((tramp)->fld[0].rtx), function);
  return round_trampoline_addr (tramp);
}




static rtx
round_trampoline_addr(rtx tramp) asm("_round_trampoline_addr");
static rtx
round_trampoline_addr(rtx tramp)
{


  rtx temp = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
  temp = expand_binop (((target_flags & 0x00000002) ? DImode : SImode), add_optab, tramp,
         gen_rtx (CONST_INT, VOIDmode, (int) (((target_flags & 0x00000002) ? 64 : 32) - 1)),
         temp, 0, OPTAB_LIB_WIDEN);
  tramp = expand_binop (((target_flags & 0x00000002) ? DImode : SImode), and_optab, temp,
   gen_rtx (CONST_INT, VOIDmode, (int) (- ((target_flags & 0x00000002) ? 64 : 32))),
   temp, 0, OPTAB_LIB_WIDEN);

  return tramp;
}
tree *
identify_blocks(tree top_block, rtx insns) asm("_identify_blocks");
tree *
identify_blocks(tree top_block, rtx insns)
{
  int n_blocks;
  tree *block_vector;
  int *block_stack;
  int depth = 0;
  int next_block_number = 0;
  int current_block_number = 0;
  rtx insn;

  if (top_block == 0)
    return 0;

  n_blocks = all_blocks (top_block, 0);
  block_vector = (tree *) xmalloc (n_blocks * sizeof (tree));
  block_stack = (int *) 
                       __builtin_alloca((
                       n_blocks * sizeof (int)
                       ))
                                                       ;

  all_blocks (top_block, block_vector);

  for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == NOTE)
      {
 if (((insn)->fld[4].rtint) == -2)
   {
     block_stack[depth++] = current_block_number;
     current_block_number = next_block_number;
     ((insn)->fld[3].rtint) = next_block_number++;
   }
 if (((insn)->fld[4].rtint) == -3)
   {
     current_block_number = block_stack[--depth];
     ((insn)->fld[3].rtint) = current_block_number;
   }
      }

  return block_vector;
}







tree
reorder_blocks(tree *block_vector, tree top_block, rtx insns) asm("_reorder_blocks");
tree
reorder_blocks(tree *block_vector, tree top_block, rtx insns)
{
  tree current_block = top_block;
  rtx insn;

  if (block_vector == 0)
    return top_block;


  ((current_block)->block.subblocks) = 0;

  for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == NOTE)
      {
 if (((insn)->fld[4].rtint) == -2)
   {
     tree block = block_vector[((insn)->fld[3].rtint)];

     if (((block)->common.asm_written_flag))
       block = copy_node (block);
     ((block)->block.subblocks) = 0;
     ((block)->common.asm_written_flag) = 1;
     ((block)->block.supercontext) = current_block;
     ((block)->common.chain) = ((current_block)->block.subblocks);
     ((current_block)->block.subblocks) = block;
     current_block = block;
     ((insn)->fld[3].rtstr) = 0;
   }
 if (((insn)->fld[4].rtint) == -3)
   {
     ((current_block)->block.subblocks)
       = blocks_nreverse (((current_block)->block.subblocks));
     current_block = ((current_block)->block.supercontext);
     ((insn)->fld[3].rtstr) = 0;
   }
      }

  return current_block;
}




static tree
blocks_nreverse(tree t) asm("_blocks_nreverse");
static tree
blocks_nreverse(tree t)
{
  register tree prev = 0, decl, next;
  for (decl = t; decl; decl = next)
    {
      next = ((decl)->common.chain);
      ((decl)->common.chain) = prev;
      prev = decl;
    }
  return prev;
}




static int
all_blocks(tree block, tree *vector) asm("_all_blocks");
static int
all_blocks(tree block, tree *vector)
{
  int n_blocks = 1;
  tree subblocks;

  ((block)->common.asm_written_flag) = 0;

  if (vector)
    vector[0] = block;


  for (subblocks = ((block)->block.subblocks);
       subblocks; subblocks = ((subblocks)->common.chain))
    n_blocks += all_blocks (subblocks, vector ? vector + n_blocks : 0);

  return n_blocks;
}



rtx
bc_build_calldesc(tree subr) asm("_bc_build_calldesc");
rtx
bc_build_calldesc(tree subr)
{
  tree calldesc = 0, arg;
  int nargs = 0;


  ((subr)->decl.arguments) = nreverse (((subr)->decl.arguments));
  nargs = 0;

  for (arg = ((subr)->decl.arguments); arg; arg = ((arg)->common.chain))
    {
      ++nargs;

      calldesc = tree_cons ((tree) 0, size_in_bytes (((arg)->common.type)), calldesc);
      calldesc = tree_cons ((tree) 0, bc_runtime_type_code (((arg)->common.type)), calldesc);
    }

  ((subr)->decl.arguments) = nreverse (((subr)->decl.arguments));


  calldesc = tree_cons ((tree) 0,
   size_in_bytes (((((subr)->common.type))->common.type)),
   calldesc);

  calldesc = tree_cons ((tree) 0,
   bc_runtime_type_code (((((subr)->common.type))->common.type)),
   calldesc);


  calldesc = tree_cons ((tree) 0, build_int_2_wide ((int) (nargs), (int) (0)), calldesc);


  calldesc = build_nt (CONSTRUCTOR, (tree) 0, calldesc);
  ((calldesc)->common.type) = build_array_type (integer_type_node,
        build_index_type (build_int_2_wide ((int) (nargs * 2), (int) (0))));

  return output_constant_def (calldesc);
}






void
init_function_start(tree subr, char *filename, int line) asm("_init_function_start");
void
init_function_start(tree subr, char *filename, int line)
{
  char *junk;

  if (output_bytecode)
    {
      this_function_decl = subr;
      this_function_calldesc = bc_build_calldesc (subr);
      local_vars_size = 0;
      stack_depth = 0;
      max_stack_depth = 0;
      stmt_expr_depth = 0;
      return;
    }

  init_stmt_for_function ();

  cse_not_expected = ! optimize;


  caller_save_needed = 0;


  stack_slot_list = 0;


  nonlocal_goto_handler_slot = 0;
  nonlocal_goto_stack_level = 0;


  nonlocal_labels = 0;


  function_call_count = 0;



  max_parm_reg = (((68)) + 3) + 1;


  init_emit ();



  init_expr ();


  reg_renumber = 0;

  init_const_rtx_hash_table ();

  current_function_name = (*decl_printable_name) (subr, &junk);



  current_function_needs_context
    = (decl_function_context (current_function_decl) != 0);


  current_function_calls_setjmp = 0;


  current_function_calls_longjmp = 0;

  current_function_calls_alloca = 0;
  current_function_has_nonlocal_label = 0;
  current_function_has_nonlocal_goto = 0;
  current_function_contains_functions = 0;

  current_function_returns_pcc_struct = 0;
  current_function_returns_struct = 0;
  current_function_epilogue_delay_list = 0;
  current_function_uses_const_pool = 0;
  current_function_uses_pic_offset_table = 0;


  tail_recursion_label = 0;



  arg_pointer_save_area = 0;


  frame_offset = 0;


  save_expr_regs = 0;


  rtl_expr_chain = 0;


  temp_slots = 0;
  temp_slot_level = 0;
  target_temp_slot_level = 0;


  immediate_size_expand++;


  trampoline_list = 0;

  init_pending_stack_adjust ();
  inhibit_defer_pop = 0;

  current_function_outgoing_args_size = 0;



  emit_line_note (filename, line);




  emit_note (((void *)0), -1);


  if (aggregate_value_p (((subr)->decl.result)))
    {



      current_function_returns_struct = 1;
    }



  if (warn_aggregate_return
      && (((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == SET_TYPE))
    warning ("function returns an aggregate");

  current_function_returns_pointer
    = (((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == REFERENCE_TYPE);



  rtx_equal_function_value_matters = 1;


  virtuals_instantiated = 0;


  frame_pointer_needed = 0;


  current_function_varargs = 0;
  current_function_stdarg = 0;
}




void
mark_varargs(void) asm("_mark_varargs");
void
mark_varargs(void)
{
  current_function_varargs = 1;
}
void
expand_main_function(void) asm("_expand_main_function");
void
expand_main_function(void)
{
  if (!output_bytecode)
    {

      0;




    }
}

extern struct n64_tag_obstack permanent_obstack;




void
bc_expand_function_start(tree subr, int parms_have_cleanups) asm("_bc_expand_function_start");
void
bc_expand_function_start(tree subr, int parms_have_cleanups)
{
  char label[20], *name;
  static int nlab;
  tree thisarg;
  int argsz;

  if (((subr)->common.public_flag))
    bc_globalize_label (((((subr)->decl.name))->identifier.pointer));





  for (argsz = 0, thisarg = ((subr)->decl.arguments); thisarg; thisarg = ((thisarg)->common.chain))
    {
      if (((thisarg)->decl.rtl))
 abort ();
      else if (((((thisarg)->decl.size))->common.constant_flag))
 {
   ((thisarg)->decl.rtl) = bc_gen_rtx ((char *) 0, argsz, (struct bc_label *) 0);
   argsz += ((((thisarg)->decl.size))->int_cst.int_cst_low);
 }
      else
 {

   ((thisarg)->decl.rtl) = bc_gen_rtx ((char *) 0, argsz, (struct bc_label *) 0);
   argsz += ((target_flags & 0x00000002) ? 64 : 32);
 }
    }

  bc_begin_function (bc_xstrdup (((((subr)->decl.name))->identifier.pointer)));

  do { sprintf (label, "*.%s%d", "LX", nlab); } while (0);

  ++nlab;
  name = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  this_function_callinfo = bc_gen_rtx (name, 0, (struct bc_label *) 0);
  this_function_bytecode =
    bc_emit_trampoline (((((this_function_callinfo))->fld[0].rtx)));
}





void
bc_expand_function_end(void) asm("_bc_expand_function_end");
void
bc_expand_function_end(void)
{
  char *ptrconsts;

  expand_null_return ();





  expand_fixups ((rtx) 0);

  ptrconsts = bc_end_function ();

  bc_align_const (2 );



  bc_emit_const_labeldef (((((this_function_callinfo))->fld[0].rtx)));
  bc_emit_const ((char *) &max_stack_depth, sizeof max_stack_depth);
  bc_emit_const ((char *) &local_vars_size, sizeof local_vars_size);
  bc_emit_const_labelref (this_function_bytecode, 0);
  bc_emit_const_labelref (ptrconsts, 0);
  bc_emit_const_labelref (((((this_function_calldesc))->fld[0].rtx)), 0);
}
void
expand_function_start(tree subr, int parms_have_cleanups) asm("_expand_function_start");
void
expand_function_start(tree subr, int parms_have_cleanups)
{
  register int i;
  tree tem;
  rtx last_ptr;

  if (output_bytecode)
    {
      bc_expand_function_start (subr, parms_have_cleanups);
      return;
    }



  init_recog_no_volatile ();



  if (current_function_needs_context)
    {
      last_ptr = assign_stack_local (((target_flags & 0x00000002) ? DImode : SImode), (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]), 0);






        emit_move_insn (last_ptr, static_chain_incoming_rtx);
    }




  if (parms_have_cleanups)
    cleanup_label = gen_label_rtx ();
  else
    cleanup_label = 0;





  if (cleanup_label == 0 && (simple_epilogue_p ())
      && ! current_function_returns_pcc_struct
      && ! (current_function_returns_struct && ! optimize))
    return_label = 0;
  else
    return_label = gen_label_rtx ();
  if (aggregate_value_p (((subr)->decl.result)))
    {

      register rtx value_address = 0;
 {



   if (struct_value_incoming_rtx)
     {
       value_address = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
       emit_move_insn (value_address, struct_value_incoming_rtx);
     }
 }
      if (value_address)
 {
   ((((subr)->decl.result))->decl.rtl)
     = gen_rtx (MEM, ((((subr)->decl.result))->decl.mode), value_address);
   ((((((subr)->decl.result))->decl.rtl))->in_struct)
     = (((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((((subr)->decl.result))->common.type))->common.code) == SET_TYPE);
 }
    }
  else if (((((subr)->decl.result))->decl.mode) == VOIDmode)

    ((((subr)->decl.result))->decl.rtl) = 0;
  else if (parms_have_cleanups)
    {





      n64_enum_machine_mode mode = ((((subr)->decl.result))->decl.mode);
      ((((subr)->decl.result))->decl.rtl) = gen_reg_rtx (mode);
    }
  else

    {




      ((((subr)->decl.result))->decl.rtl)
 = gen_rtx (REG, ((((((subr)->decl.result))->common.type))->type.mode), (((mode_class[(int)(((((((subr)->decl.result))->common.type))->type.mode))]) == MODE_FLOAT && (! (target_flags & 0x00020000) || (mode_size[(int)(((((((subr)->decl.result))->common.type))->type.mode))]) <= 4)) ? (((target_flags & 0x00000100)) ? (0 + 2) : (32 + 0)) : (0 + 2)));



      if (((((((subr)->decl.result))->decl.rtl))->code) == REG)
 {
   ((((((subr)->decl.result))->decl.rtl))->integrated) = 1;


   ((((subr)->decl.result))->decl.regdecl_flag) = 1;
 }
    }




  assign_parms (subr, 0);
  emit_note (((void *)0), -13);



  if (((get_last_insn ())->code) != NOTE)
    emit_note (((void *)0), -1);
  parm_birth_insn = get_last_insn ();

  if (obey_regdecls)
    {
      for (i = (((68)) + 3) + 1; i < max_parm_reg; i++)
 use_variable (regno_reg_rtx[i]);

      if (current_function_internal_arg_pointer != virtual_incoming_args_rtx)
 use_variable (current_function_internal_arg_pointer);
    }


  tem = decl_function_context (current_function_decl);




  if (tem && ! obey_regdecls)
    {
      last_ptr = copy_to_reg (static_chain_incoming_rtx);
    }

  context_display = 0;
  while (tem)
    {
      tree rtlexp = make_node (RTL_EXPR);

      (*(struct n64_tag_rtx_def **) &(rtlexp)->exp.operands[1]) = last_ptr;
      context_display = tree_cons (tem, rtlexp, context_display);
      tem = decl_function_context (tem);
      if (tem == 0)
 break;





      last_ptr = copy_to_reg (gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode),
           memory_address (((target_flags & 0x00000002) ? DImode : SImode), last_ptr)));



      if (! optimize)
 save_expr_regs = gen_rtx (EXPR_LIST, VOIDmode, last_ptr,
      save_expr_regs);
    }




  tail_recursion_reentry = emit_note (((void *)0), -1);


  for (tem = nreverse (get_pending_sizes ()); tem; tem = ((tem)->common.chain))
    expand_expr (((tem)->list.value), const0_rtx, VOIDmode, 0);


  force_next_line_note ();
}







void
expand_function_end(char *filename, int line, int end_bindings) asm("_expand_function_end");
void
expand_function_end(char *filename, int line, int end_bindings)
{
  register int i;
  tree link;

  static rtx initial_trampoline;

  if (output_bytecode)
    {
      bc_expand_function_end ();
      return;
    }
  if (arg_pointer_save_area)
    {
      rtx x = gen_move_insn (arg_pointer_save_area, virtual_incoming_args_rtx);
      emit_insn_before (x, tail_recursion_reentry);
    }


  for (link = trampoline_list; link; link = ((link)->common.chain))
    {
      tree function = ((link)->list.purpose);
      rtx context = lookup_static_chain (function);
      rtx tramp = (*(struct n64_tag_rtx_def **) &(((link)->list.value))->exp.operands[1]);
      rtx seq;



      if (initial_trampoline == 0)
 {
   end_temporary_allocation ();
   initial_trampoline
     = gen_rtx (MEM, BLKmode, assemble_trampoline_template ());
   resume_temporary_allocation ();
 }


      start_sequence ();
      tramp = change_address (initial_trampoline, BLKmode,
         round_trampoline_addr (((tramp)->fld[0].rtx)));
      emit_block_move (tramp, initial_trampoline, gen_rtx (CONST_INT, VOIDmode, (int) ((32 + ((target_flags & 0x00000002) ? 16 : 8)))),
         32 / 8);
      { rtx addr = ((tramp)->fld[0].rtx); if ((target_flags & 0x00000002)) { emit_move_insn (gen_rtx (MEM, DImode, plus_constant_wide (addr, (int) (32))), ((((function)->decl.rtl))->fld[0].rtx)); emit_move_insn (gen_rtx (MEM, DImode, plus_constant_wide (addr, (int) (40))), context); } else { emit_move_insn (gen_rtx (MEM, SImode, plus_constant_wide (addr, (int) (32))), ((((function)->decl.rtl))->fld[0].rtx)); emit_move_insn (gen_rtx (MEM, SImode, plus_constant_wide (addr, (int) (36))), context); } emit_library_call (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "cacheflush"), 0, VOIDmode, 3, addr, ((target_flags & 0x00000002) ? DImode : SImode), gen_rtx (CONST_INT, VOIDmode, (int) ((32 + ((target_flags & 0x00000002) ? 16 : 8)))), SImode, gen_rtx (CONST_INT, VOIDmode, (int) (1)), SImode); }
                                               ;
      seq = get_insns ();
      end_sequence ();


      emit_insns_before (seq, tail_recursion_reentry);
    }


  if (warn_unused && extra_warnings)
    {
      tree decl;

      for (decl = ((current_function_decl)->decl.arguments);
    decl; decl = ((decl)->common.chain))
 if (! ((decl)->common.used_flag) && ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL
     && ((decl)->decl.name) && ! ((decl)->decl.artificial_flag))
   warning_with_decl (decl, "unused parameter `%s'");
    }


  if (nonlocal_goto_handler_slot != 0 && !current_function_has_nonlocal_label)
    delete_handlers ();


  while (in_sequence_p ())
    end_sequence ();



  immediate_size_expand--;




  if (obey_regdecls)
    {
      rtx tem;
      for (i = (((68)) + 3) + 1; i < max_parm_reg; i++)
 use_variable (regno_reg_rtx[i]);



      for (tem = save_expr_regs; tem; tem = ((tem)->fld[1].rtx))
 {
   use_variable (((tem)->fld[0].rtx));
   use_variable_after (((tem)->fld[0].rtx), parm_birth_insn);
 }

      if (current_function_internal_arg_pointer != virtual_incoming_args_rtx)
 use_variable (current_function_internal_arg_pointer);
    }

  clear_pending_stack_adjust ();
  do_pending_stack_adjust ();




  emit_note (((void *)0), -6);



  emit_line_note_force (filename, line);







  if (return_label)
    emit_label (return_label);


  if (end_bindings)
    expand_end_bindings (0, 0, 0);





  if (! 1)

    if (current_function_calls_alloca)
      {
 rtx tem = 0;

 emit_stack_save (SAVE_FUNCTION, &tem, parm_birth_insn);
 emit_stack_restore (SAVE_FUNCTION, tem, (rtx) 0);
      }



  if (((((current_function_decl)->decl.result))->decl.rtl) != 0
      && ((((((current_function_decl)->decl.result))->decl.rtl))->code) == REG
      && (((((((current_function_decl)->decl.result))->decl.rtl))->fld[0].rtint)
   >= 68))
    {
      rtx real_decl_result;






      real_decl_result
 = gen_rtx (REG, ((((((current_function_decl)->decl.result))->common.type))->type.mode), (((mode_class[(int)(((((((current_function_decl)->decl.result))->common.type))->type.mode))]) == MODE_FLOAT && (! (target_flags & 0x00020000) || (mode_size[(int)(((((((current_function_decl)->decl.result))->common.type))->type.mode))]) <= 4)) ? (((target_flags & 0x00000100)) ? (0 + 2) : (32 + 0)) : (0 + 2)))
                           ;

      ((real_decl_result)->integrated) = 1;
      emit_move_insn (real_decl_result,
        ((((current_function_decl)->decl.result))->decl.rtl));
      emit_insn (gen_rtx (USE, VOIDmode, real_decl_result));
    }







  if (current_function_returns_struct
      || current_function_returns_pcc_struct)
    {
      rtx value_address = ((((((current_function_decl)->decl.result))->decl.rtl))->fld[0].rtx);
      tree type = ((((current_function_decl)->decl.result))->common.type);





      rtx outgoing
 = gen_rtx (REG, ((build_pointer_type (type))->type.mode), (((mode_class[(int)(((build_pointer_type (type))->type.mode))]) == MODE_FLOAT && (! (target_flags & 0x00020000) || (mode_size[(int)(((build_pointer_type (type))->type.mode))]) <= 4)) ? (((target_flags & 0x00000100)) ? (0 + 2) : (32 + 0)) : (0 + 2)))
                           ;




      ((outgoing)->integrated) = 1;

      emit_move_insn (outgoing, value_address);
      use_variable (outgoing);
    }






  if ((simple_epilogue_p ()))
    {
      emit_jump_insn (gen_return ());
      emit_barrier ();
    }
  expand_fixups (get_insns ());
}



static int *prologue;
static int *epilogue;




static int *
record_insns(rtx insns) asm("_record_insns");
static int *
record_insns(rtx insns)
{
  int *vec;

  if (((insns)->code) == SEQUENCE)
    {
      int len = ((insns)->fld[0].rtvec->num_elem);
      vec = (int *) oballoc ((len + 1) * sizeof (int));
      vec[len] = 0;
      while (--len >= 0)
 vec[len] = ((((insns)->fld[0].rtvec->elem[len].rtx))->fld[0].rtint);
    }
  else
    {
      vec = (int *) oballoc (2 * sizeof (int));
      vec[0] = ((insns)->fld[0].rtint);
      vec[1] = 0;
    }
  return vec;
}



static int
contains(rtx insn, int *vec) asm("_contains");
static int
contains(rtx insn, int *vec)
{
  register int i, j;

  if (((insn)->code) == INSN
      && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
    {
      int count = 0;
      for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 for (j = 0; vec[j]; j++)
   if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtint) == vec[j])
     count++;
      return count;
    }
  else
    {
      for (j = 0; vec[j]; j++)
 if (((insn)->fld[0].rtint) == vec[j])
   return 1;
    }
  return 0;
}





void
thread_prologue_and_epilogue_insns(rtx f) asm("_thread_prologue_and_epilogue_insns");
void
thread_prologue_and_epilogue_insns(rtx f)
{

  if (1)
    {
      rtx head, seq, insn;



      emit_note_after (-10, f);
      seq = gen_prologue ();
      head = emit_insn_after (seq, f);



      if (basic_block_head && n_basic_blocks
   && ((basic_block_head[0])->code) != CODE_LABEL)
 basic_block_head[0] = ((f)->fld[2].rtx);


      prologue = record_insns (((seq)->code) == SEQUENCE ? seq : head);
    }
  else

    prologue = 0;
  epilogue = 0;
}




void
reposition_prologue_and_epilogue_notes(rtx f) asm("_reposition_prologue_and_epilogue_notes");
void
reposition_prologue_and_epilogue_notes(rtx f)
{


  if (n_basic_blocks)
    {
      rtx next, prev;
      int len;

      if (prologue)
 {
   register rtx insn, note = 0;




   for (len = 0; prologue[len]; len++)
     ;
   for (insn = f; len && insn; insn = ((insn)->fld[2].rtx))
     {
       if (((insn)->code) == NOTE)
  {
    if (((insn)->fld[4].rtint) == -10)
      note = insn;
  }
       else if ((len -= contains (insn, prologue)) == 0)
  {


    if (note == 0)
      {
        for (note = insn; note = ((note)->fld[2].rtx);)
   if (((note)->code) == NOTE
       && ((note)->fld[4].rtint) == -10)
     break;
      }
    next = ((note)->fld[2].rtx);
    prev = ((note)->fld[1].rtx);
    if (prev)
      ((prev)->fld[2].rtx) = next;
    if (next)
      ((next)->fld[1].rtx) = prev;
    add_insn_after (note, insn);
  }
     }
 }

      if (epilogue)
 {
   register rtx insn, note = 0;




   for (len = 0; epilogue[len]; len++)
     ;
   for (insn = get_last_insn (); len && insn; insn = ((insn)->fld[1].rtx))
     {
       if (((insn)->code) == NOTE)
  {
    if (((insn)->fld[4].rtint) == -11)
      note = insn;
  }
       else if ((len -= contains (insn, epilogue)) == 0)
  {


    if (note == 0)
      {
        for (note = insn; note = ((note)->fld[1].rtx);)
   if (((note)->code) == NOTE
       && ((note)->fld[4].rtint) == -11)
     break;
      }
    next = ((note)->fld[2].rtx);
    prev = ((note)->fld[1].rtx);
    if (prev)
      ((prev)->fld[2].rtx) = next;
    if (next)
      ((next)->fld[1].rtx) = prev;
    add_insn_after (note, ((insn)->fld[1].rtx));
  }
     }
 }
    }

}

