// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/rtl.c
/* Allocate and read RTL for GNU C Compiler.
   Copyright (C) 1987, 1988, 1991, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__obstack_chunk;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_rtx_list;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");

enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern struct n64_tag_obstack *rtl_obstack;
int rtx_length[((int)LAST_AND_UNUSED_RTX_CODE) + 1];





char *rtx_name[] = {
"UnKnown" ,



"nil" ,






"expr_list" ,



"insn_list" ,
"match_operand" ,






"match_scratch" ,




"match_dup" ,







"match_operator" ,
"match_parallel" ,




"match_op_dup" ,




"match_par_dup" ,
"define_insn" ,







"define_peephole" ,
"define_split" ,



"define_combine" ,
"define_expand" ,
"define_delay" ,
"define_function_unit" ,


"define_asm_attributes" ,





"sequence" ,





"address" ,
"define_attr" ,


"attr" ,







"set_attr" ,
"set_attr_alternative" ,




"eq_attr" ,
"attr_flag" ,
"insn" ,



"jump_insn" ,






"call_insn" ,


"barrier" ,







"code_label" ,
"note" ,





"inline_header" ,






"parallel" ,







"asm_input" ,
"asm_operands" ,
"unspec" ,


"unspec_volatile" ,



"addr_vec" ,





"addr_diff_vec" ,
"set" ,




"use" ,




"clobber" ,





"call" ,



"return" ,





"trap_if" ,






"const_int" ,
"const_double" ,


"const_string" ,





"const" ,



"pc" ,




"reg" ,






"scratch" ,
"subreg" ,
"strict_low_part" ,





"concat" ,



"mem" ,





"label_ref" ,





"symbol_ref" ,






"cc0" ,
"queued" ,
"if_then_else" ,
"cond" ,


"compare" ,


"plus" ,


"minus" ,


"neg" ,

"mult" ,


"div" ,

"mod" ,


"udiv" ,
"umod" ,


"and" ,

"ior" ,

"xor" ,

"not" ,




"ashift" ,
"rotate" ,




"ashiftrt" ,
"lshiftrt" ,
"rotatert" ,





"smin" ,
"smax" ,
"umin" ,
"umax" ,
"pre_dec" ,
"pre_inc" ,
"post_dec" ,
"post_inc" ,



"ne" ,
"eq" ,
"ge" ,
"gt" ,
"le" ,
"lt" ,
"geu" ,
"gtu" ,
"leu" ,
"ltu" ,




"sign_extend" ,


"zero_extend" ,


"truncate" ,


"float_extend" ,
"float_truncate" ,


"float" ,







"fix" ,


"unsigned_float" ,




"unsigned_fix" ,


"abs" ,


"sqrt" ,




"ffs" ,
"sign_extract" ,


"zero_extract" ,




"high" ,



"lo_sum" ,
};
char *mode_name[(int) MAX_MACHINE_MODE] = {
"VOID",

"QI",
"HI",



"PSI",
"SI",
"PDI",
"DI",
"TI",
"OI",

"QF",
"HF",
"TQF",
"SF",
"DF",
"XF",
"TF",


"SC",
"DC",
"XC",
"TC",

"CQI",
"CHI",
"CSI",
"CDI",
"CTI",
"COI",



"BLK",







"CC",


  "CC_EQ", "CC_FP", "CC_0", "CC_REV_FP"


};
n64_enum_mode_class mode_class[(int) MAX_MACHINE_MODE] = {
MODE_RANDOM,

MODE_INT,
MODE_INT,



MODE_PARTIAL_INT,
MODE_INT,
MODE_PARTIAL_INT,
MODE_INT,
MODE_INT,
MODE_INT,

MODE_FLOAT,
MODE_FLOAT,
MODE_FLOAT,
MODE_FLOAT,
MODE_FLOAT,
MODE_FLOAT,
MODE_FLOAT,


MODE_COMPLEX_FLOAT,
MODE_COMPLEX_FLOAT,
MODE_COMPLEX_FLOAT,
MODE_COMPLEX_FLOAT,

MODE_COMPLEX_INT,
MODE_COMPLEX_INT,
MODE_COMPLEX_INT,
MODE_COMPLEX_INT,
MODE_COMPLEX_INT,
MODE_COMPLEX_INT,



MODE_RANDOM,







MODE_CC,
};
int mode_size[(int) MAX_MACHINE_MODE] = {
0,

1,
2,



4,
4,
8,
8,
16,
32,

1,
2,
3,
4,
8,
12,
16,


8,
16,
24,
32,

2,
4,
8,
16,
32,
64,



0,







4,
};
int mode_unit_size[(int) MAX_MACHINE_MODE] = {
0,

1,
2,



4,
4,
8,
8,
16,
32,

1,
2,
3,
4,
8,
12,
16,


4,
8,
12,
16,

1,
2,
4,
8,
16,
32,



0,







4,
};
n64_enum_machine_mode mode_wider_mode[(int) MAX_MACHINE_MODE] = {
(n64_enum_machine_mode) VOIDmode,

(n64_enum_machine_mode) HImode,
(n64_enum_machine_mode) SImode,



(n64_enum_machine_mode) PDImode,
(n64_enum_machine_mode) DImode,
(n64_enum_machine_mode) VOIDmode,
(n64_enum_machine_mode) TImode,
(n64_enum_machine_mode) OImode,
(n64_enum_machine_mode) VOIDmode,

(n64_enum_machine_mode) HFmode,
(n64_enum_machine_mode) TQFmode,
(n64_enum_machine_mode) SFmode,
(n64_enum_machine_mode) DFmode,
(n64_enum_machine_mode) XFmode,
(n64_enum_machine_mode) TFmode,
(n64_enum_machine_mode) VOIDmode,


(n64_enum_machine_mode) DCmode,
(n64_enum_machine_mode) XCmode,
(n64_enum_machine_mode) TCmode,
(n64_enum_machine_mode) VOIDmode,

(n64_enum_machine_mode) CHImode,
(n64_enum_machine_mode) CSImode,
(n64_enum_machine_mode) CDImode,
(n64_enum_machine_mode) CTImode,
(n64_enum_machine_mode) COImode,
(n64_enum_machine_mode) VOIDmode,



(n64_enum_machine_mode) VOIDmode,







(n64_enum_machine_mode) VOIDmode,
};





n64_enum_machine_mode class_narrowest_mode[(int) MAX_MODE_CLASS];





char *rtx_format[] = {
"*" ,



"*" ,






"ee" ,



"ue" ,
"iss" ,






"is" ,




"i" ,







"isE" ,
"isE" ,




"iE" ,




"iE" ,
"sEssV" ,







"EssV" ,
"EsES" ,



"Ess" ,
"sEss" ,
"eE" ,
"siieiiV" ,


"V" ,





"E" ,





"e" ,
"sse" ,


"s" ,







"ss" ,
"sE" ,




"ss" ,
"s" ,
"iuueiee" ,



"iuueiee0" ,






"iuueieee" ,


"iuu" ,







"iuuis0" ,
"iuusn" ,





"iuuuiiiiiieeiiEe" ,






"E" ,







"s" ,
"ssiEEsi" ,
"Ei" ,


"Ei" ,



"E" ,





"eE" ,
"ee" ,




"e" ,




"e" ,





"ee" ,



"" ,





"ei" ,






"w" ,
"e0ww" ,


"s" ,





"e" ,



"" ,




"i" ,






"0" ,
"ei" ,
"e" ,





"ee" ,



"e" ,





"u00" ,





"s" ,






"" ,
"eeeee" ,
"eee" ,
"Ee" ,


"ee" ,


"ee" ,


"ee" ,


"e" ,

"ee" ,


"ee" ,

"ee" ,


"ee" ,
"ee" ,


"ee" ,

"ee" ,

"ee" ,

"e" ,




"ee" ,
"ee" ,




"ee" ,
"ee" ,
"ee" ,





"ee" ,
"ee" ,
"ee" ,
"ee" ,
"e" ,
"e" ,
"e" ,
"e" ,



"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,
"ee" ,




"e" ,


"e" ,


"e" ,


"e" ,
"e" ,


"e" ,







"e" ,


"e" ,




"e" ,


"e" ,


"e" ,




"e" ,
"eee" ,


"eee" ,




"e" ,



"ee" ,

};




char rtx_class[] = {

'x',



'x',






'x',



'x',
'm',






'm',




'm',







'm',
'm',




'm',




'm',
'x',







'x',
'x',



'x',
'x',
'x',
'x',


'x',





'x',





'm',
'x',


'x',







'x',
'x',




'x',
'x',
'i',



'i',






'i',


'x',







'x',
'x',





'x',






'x',







'x',
'x',
'x',


'x',



'x',





'x',
'x',




'x',




'x',





'x',



'x',





'x',






'o',
'o',


'o',





'o',



'o',




'o',






'o',
'x',
'x',





'o',



'o',





'o',





'o',






'o',
'x',
'3',
'x',


'2',


'c',


'2',


'1',

'c',


'2',

'2',


'2',
'2',


'c',

'c',

'c',

'1',




'2',
'2',




'2',
'2',
'2',





'c',
'c',
'c',
'c',
'x',
'x',
'x',
'x',



'<',
'<',
'<',
'<',
'<',
'<',
'<',
'<',
'<',
'<',




'1',


'1',


'1',


'1',
'1',


'1',







'1',


'1',




'1',


'1',


'1',




'1',
'b',


'b',




'o',



'o',

};



char *note_insn_name[] = { 0 , "NOTE_INSN_DELETED",
      "NOTE_INSN_BLOCK_BEG", "NOTE_INSN_BLOCK_END",
      "NOTE_INSN_LOOP_BEG", "NOTE_INSN_LOOP_END",
      "NOTE_INSN_FUNCTION_END", "NOTE_INSN_SETJMP",
      "NOTE_INSN_LOOP_CONT", "NOTE_INSN_LOOP_VTOP",
      "NOTE_INSN_PROLOGUE_END", "NOTE_INSN_EPILOGUE_BEG",
      "NOTE_INSN_DELETED_LABEL", "NOTE_INSN_FUNCTION_BEG"};

char *reg_note_name[] = { "", "REG_DEAD", "REG_INC", "REG_EQUIV", "REG_WAS_0",
     "REG_EQUAL", "REG_RETVAL", "REG_LIBCALL",
     "REG_NONNEG", "REG_NO_CONFLICT", "REG_UNUSED",
     "REG_CC_SETTER", "REG_CC_USER", "REG_LABEL",
     "REG_DEP_ANTI", "REG_DEP_OUTPUT" };




rtvec
rtvec_alloc(int n) asm("_rtvec_alloc");
rtvec
rtvec_alloc(int n)
{
  rtvec rt;
  int i;

  rt = (rtvec) __extension__ ({ struct n64_tag_obstack *__h = (rtl_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_rtvec_def) + (( n - 1) * sizeof (rtunion)))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })

                                         ;


  ((rt)->num_elem = (unsigned) n);
  for (i=0; i < n; i++)
    rt->elem[i].rtvec = 
                       ((void *)0)
                           ;

  return rt;
}




rtx
rtx_alloc(n64_enum_rtx_code code) asm("_rtx_alloc");
rtx
rtx_alloc(n64_enum_rtx_code code)
{
  rtx rt;
  register struct n64_tag_obstack *ob = rtl_obstack;
  register int nelts = (rtx_length[(int)(code)]);
  register int length = sizeof (struct n64_tag_rtx_def)
    + (nelts - 1) * sizeof (rtunion);
  length = (length + ob->alignment_mask) & ~ ob->alignment_mask;

  if (ob->chunk_limit - ob->next_free < length)
    _obstack_newchunk (ob, length);
  rt = (rtx)ob->object_base;
  ob->next_free += length;
  ob->object_base = ob->next_free;





  length = (sizeof (struct n64_tag_rtx_def) - sizeof (rtunion) - 1) / sizeof (int);
  for (; length >= 0; length--)
    ((int *) rt)[length] = 0;

  ((rt)->code = (code));

  return rt;
}



void
rtx_free(rtx x) asm("_rtx_free");
void
rtx_free(rtx x)
{
  __extension__ ({ struct n64_tag_obstack *__o = (rtl_obstack); void *__obj = (x); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}





rtx
copy_rtx(register rtx orig) asm("_copy_rtx");
rtx
copy_rtx(register rtx orig)
{
  register rtx copy;
  register int i, j;
  register n64_enum_rtx_code code;
  register char *format_ptr;

  code = ((orig)->code);

  switch (code)
    {
    case REG:
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
    case SCRATCH:

      return orig;

    case CONST:


      if (((((orig)->fld[0].rtx))->code) == PLUS
   && ((((((orig)->fld[0].rtx))->fld[0].rtx))->code) == SYMBOL_REF
   && ((((((orig)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT)
 return orig;
      break;





    }

  copy = rtx_alloc (code);
  ((copy)->mode = (((orig)->mode)));
  copy->in_struct = orig->in_struct;
  copy->volatil = orig->volatil;
  copy->unchanging = orig->unchanging;
  copy->integrated = orig->integrated;

  format_ptr = (rtx_format[(int)(((copy)->code))]);

  for (i = 0; i < (rtx_length[(int)(((copy)->code))]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   ((copy)->fld[i].rtx) = ((orig)->fld[i].rtx);
   if (((orig)->fld[i].rtx) != 
                        ((void *)0)
                            )
     ((copy)->fld[i].rtx) = copy_rtx (((orig)->fld[i].rtx));
   break;

 case '0':
 case 'u':
   ((copy)->fld[i].rtx) = ((orig)->fld[i].rtx);
   break;

 case 'E':
 case 'V':
   ((copy)->fld[i].rtvec) = ((orig)->fld[i].rtvec);
   if (((orig)->fld[i].rtvec) != 
                        ((void *)0)
                            )
     {
       ((copy)->fld[i].rtvec) = rtvec_alloc (((orig)->fld[i].rtvec->num_elem));
       for (j = 0; j < ((copy)->fld[i].rtvec->num_elem); j++)
  ((copy)->fld[i].rtvec->elem[j].rtx) = copy_rtx (((orig)->fld[i].rtvec->elem[j].rtx));
     }
   break;

 case 'w':
   ((copy)->fld[i].rtwint) = ((orig)->fld[i].rtwint);
   break;

 case 'i':
   ((copy)->fld[i].rtint) = ((orig)->fld[i].rtint);
   break;

 case 's':
 case 'S':
   ((copy)->fld[i].rtstr) = ((orig)->fld[i].rtstr);
   break;

 default:
   abort ();
 }
    }
  return copy;
}




rtx
copy_most_rtx(register rtx orig, register rtx may_share) asm("_copy_most_rtx");
rtx
copy_most_rtx(register rtx orig, register rtx may_share)
{
  register rtx copy;
  register int i, j;
  register n64_enum_rtx_code code;
  register char *format_ptr;

  if (orig == may_share)
    return orig;

  code = ((orig)->code);

  switch (code)
    {
    case REG:
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
      return orig;
    }

  copy = rtx_alloc (code);
  ((copy)->mode = (((orig)->mode)));
  copy->in_struct = orig->in_struct;
  copy->volatil = orig->volatil;
  copy->unchanging = orig->unchanging;
  copy->integrated = orig->integrated;

  format_ptr = (rtx_format[(int)(((copy)->code))]);

  for (i = 0; i < (rtx_length[(int)(((copy)->code))]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   ((copy)->fld[i].rtx) = ((orig)->fld[i].rtx);
   if (((orig)->fld[i].rtx) != 
                        ((void *)0) 
                             && ((orig)->fld[i].rtx) != may_share)
     ((copy)->fld[i].rtx) = copy_most_rtx (((orig)->fld[i].rtx), may_share);
   break;

 case '0':
 case 'u':
   ((copy)->fld[i].rtx) = ((orig)->fld[i].rtx);
   break;

 case 'E':
 case 'V':
   ((copy)->fld[i].rtvec) = ((orig)->fld[i].rtvec);
   if (((orig)->fld[i].rtvec) != 
                        ((void *)0)
                            )
     {
       ((copy)->fld[i].rtvec) = rtvec_alloc (((orig)->fld[i].rtvec->num_elem));
       for (j = 0; j < ((copy)->fld[i].rtvec->num_elem); j++)
  ((copy)->fld[i].rtvec->elem[j].rtx)
    = copy_most_rtx (((orig)->fld[i].rtvec->elem[j].rtx), may_share);
     }
   break;

 case 'w':
   ((copy)->fld[i].rtwint) = ((orig)->fld[i].rtwint);
   break;

 case 'n':
 case 'i':
   ((copy)->fld[i].rtint) = ((orig)->fld[i].rtint);
   break;

 case 's':
 case 'S':
   ((copy)->fld[i].rtstr) = ((orig)->fld[i].rtstr);
   break;

 default:
   abort ();
 }
    }
  return copy;
}






static void
dump_and_abort(int expected_c, int actual_c, FILE *infile) asm("_dump_and_abort");
static void
dump_and_abort(int expected_c, int actual_c, FILE *infile)
{
  int c, i;

  if (expected_c >= 0)
    fprintf (
            (__acrt_iob_func(2))
                  ,
      "Expected character %c.  Found character %c.",
      expected_c, actual_c);
  fprintf (
          (__acrt_iob_func(2))
                , "  At file position: %ld\n", ftell (infile));
  fprintf (
          (__acrt_iob_func(2))
                , "Following characters are:\n\t");
  for (i = 0; i < 200; i++)
    {
      c = getc (infile);
      if (
         (-1) 
             == c) break;
      putc (c, 
              (__acrt_iob_func(2))
                    );
    }
  fprintf (
          (__acrt_iob_func(2))
                , "Aborting.\n");
  abort ();
}






int
read_skip_spaces(FILE *infile) asm("_read_skip_spaces");
int
read_skip_spaces(FILE *infile)
{
  register int c;
  while (c = getc (infile))
    {
      if (c == ' ' || c == '\n' || c == '\t' || c == '\f')
 ;
      else if (c == ';')
 {
   while ((c = getc (infile)) && c != '\n') ;
 }
      else if (c == '/')
 {
   register int prevc;
   c = getc (infile);
   if (c != '*')
     dump_and_abort ('*', c, infile);

   prevc = 0;
   while (c = getc (infile))
     {
       if (prevc == '*' && c == '/')
  break;
       prevc = c;
     }
 }
      else break;
    }
  return c;
}




static void
read_name(char *str, FILE *infile) asm("_read_name");
static void
read_name(char *str, FILE *infile)
{
  register char *p;
  register int c;

  c = read_skip_spaces(infile);

  p = str;
  while (1)
    {
      if (c == ' ' || c == '\n' || c == '\t' || c == '\f')
 break;
      if (c == ':' || c == ')' || c == ']' || c == '"' || c == '/'
   || c == '(' || c == '[')
 {
   ungetc (c, infile);
   break;
 }
      *p++ = c;
      c = getc (infile);
    }
  if (p == str)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "missing name or number");
      dump_and_abort (-1, -1, infile);
    }

  *p = 0;
}






rtx
read_rtx(FILE *infile) asm("_read_rtx");
rtx
read_rtx(FILE *infile)
{
  register int i, j, list_counter;
  n64_enum_rtx_code tmp_code;
  register char *format_ptr;



  char tmp_char[256];
  rtx return_rtx;
  register int c;
  int tmp_int;
  int tmp_wide;


  struct n64_tag_rtx_list
    {
      struct n64_tag_rtx_list *next;
      rtx value;
    };

  c = read_skip_spaces (infile);
  if (c != '(')
    dump_and_abort ('(', c, infile);

  read_name (tmp_char, infile);

  tmp_code = UNKNOWN;

  for (i=0; i < ((int)LAST_AND_UNUSED_RTX_CODE); i++)
    {
      if (!(strcmp (tmp_char, (rtx_name[(int)(i)]))))
 {
   tmp_code = (n64_enum_rtx_code) i;
   break;
 }
    }
  if (tmp_code == UNKNOWN)
    {
      fprintf (
              (__acrt_iob_func(2))
                    ,
        "Unknown rtx read in rtl.read_rtx(). Code name was %s .",
        tmp_char);
    }

  if (tmp_code == NIL)
    {

      while ((c = getc (infile)) && c != ')');
      return 0;
    }

  return_rtx = rtx_alloc (tmp_code);

  format_ptr = (rtx_format[(int)(((return_rtx)->code))]);




  i = read_skip_spaces (infile);
  if (i == ':')
    {
      register int k;
      read_name (tmp_char, infile);
      for (k = 0; k < (int) MAX_MACHINE_MODE; k++)
 if (!strcmp ((mode_name[(int)(k)]), tmp_char))
   break;

      ((return_rtx)->mode = ((n64_enum_machine_mode) k));
    }
  else
    ungetc (i, infile);

  for (i = 0; i < (rtx_length[(int)(((return_rtx)->code))]); i++)
    switch (*format_ptr++)
      {


      case '0':
 break;

      case 'e':
      case 'u':
 ((return_rtx)->fld[i].rtx) = read_rtx (infile);
 break;

      case 'V':


 c = read_skip_spaces (infile);
 ungetc (c, infile);
 if (c == ')')
   {
     ((return_rtx)->fld[i].rtvec) = 0;
     break;
    }


      case 'E':
 {
   register struct n64_tag_rtx_list *next_rtx, *rtx_list_link;
   struct n64_tag_rtx_list *list_rtx;

   c = read_skip_spaces (infile);
   if (c != '[')
     dump_and_abort ('[', c, infile);


   next_rtx = 
             ((void *)0)
                 ;
   list_counter = 0;
   while ((c = read_skip_spaces (infile)) && c != ']')
     {
       ungetc (c, infile);
       list_counter++;
       rtx_list_link = (struct n64_tag_rtx_list *)
  
 __builtin_alloca((
 sizeof (struct n64_tag_rtx_list)
 ))
                                  ;
       rtx_list_link->value = read_rtx (infile);
       if (next_rtx == 0)
  list_rtx = rtx_list_link;
       else
  next_rtx->next = rtx_list_link;
       next_rtx = rtx_list_link;
       rtx_list_link->next = 0;
     }

   ((return_rtx)->fld[i].rtvec) = (list_counter
      ? rtvec_alloc (list_counter) : (rtvec) 0);
   if (list_counter > 0)
     {
       next_rtx = list_rtx;
       for (j = 0; j < list_counter; j++,
     next_rtx = next_rtx->next)
  ((return_rtx)->fld[i].rtvec->elem[j].rtx) = next_rtx->value;
     }

 }
 break;

      case 'S':


 c = read_skip_spaces (infile);
 ungetc (c, infile);
 if (c == ')')
   {
     ((return_rtx)->fld[i].rtstr) = 0;
     break;
   }

      case 's':
 {
   int saw_paren = 0;
   register char *stringbuf;

   c = read_skip_spaces (infile);
   if (c == '(')
     {
       saw_paren = 1;
       c = read_skip_spaces (infile);
     }
   if (c != '"')
     dump_and_abort ('"', c, infile);

   while (1)
     {
       c = getc (infile);
       if (c == '\\')
  {
    c = getc (infile);


    if (c == ';')
      {
        __extension__ ({ struct n64_tag_obstack *__o = (rtl_obstack); int __len = (4); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("\\n\\t"),__len); __o->next_free += __len; } (void) 0; });
        continue;
      }
  }
       else if (c == '"')
  break;

       __extension__ ({ struct n64_tag_obstack *__o = (rtl_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
     }

   __extension__ ({ struct n64_tag_obstack *__o = (rtl_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (0); (void) 0; });
   stringbuf = (char *) __extension__ ({ struct n64_tag_obstack *__o1 = (rtl_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });

   if (saw_paren)
     {
       c = read_skip_spaces (infile);
       if (c != ')')
  dump_and_abort (')', c, infile);
     }
   ((return_rtx)->fld[i].rtstr) = stringbuf;
 }
 break;

      case 'w':
 read_name (tmp_char, infile);

 tmp_wide = atoi (tmp_char);



 ((return_rtx)->fld[i].rtwint) = tmp_wide;
 break;

      case 'i':
      case 'n':
 read_name (tmp_char, infile);
 tmp_int = atoi (tmp_char);
 ((return_rtx)->fld[i].rtint) = tmp_int;
 break;

      default:
 fprintf (
         (__acrt_iob_func(2))
               ,
   "switch format wrong in rtl.read_rtx(). format was: %c.\n",
   format_ptr[-1]);
 fprintf (
         (__acrt_iob_func(2))
               , "\tfile position: %ld\n", ftell (infile));
 abort ();
      }

  c = read_skip_spaces (infile);
  if (c != ')')
    dump_and_abort (')', c, infile);

  return return_rtx;
}





void
init_rtl(void) asm("_init_rtl");
void
init_rtl(void)
{
  int min_class_size[(int) MAX_MODE_CLASS];
  n64_enum_machine_mode mode;
  int i;

  for (i = 0; i < ((int)LAST_AND_UNUSED_RTX_CODE); i++)
    rtx_length[i] = strlen (rtx_format[i]);







  i = sizeof (double) / sizeof (rtunion) + 2;
  if (rtx_length[(int) CONST_DOUBLE] < i)
    {
      char *s = (char *) xmalloc (i + 1);
      rtx_length[(int) CONST_DOUBLE] = i;
      rtx_format[(int) CONST_DOUBLE] = s;
      *s++ = 'e';
      *s++ = '0';



      for (i = 2; i < rtx_length[(int) CONST_DOUBLE]; i++)
 *s++ = 'w';
      *s++ = 0;
    }



  for (i = (int) CCmode + 1; i < (int) MAX_MACHINE_MODE; i++)
    {
      mode_class[i] = MODE_CC;
      mode_size[i] = mode_size[(int) CCmode];
      mode_unit_size[i] = mode_unit_size[(int) CCmode];
      mode_wider_mode[i - 1] = (n64_enum_machine_mode) i;
      mode_wider_mode[i] = VOIDmode;
    }




  for (i = 0; i < (int) MAX_MODE_CLASS; i++)
    min_class_size[i] = 1000;

  for (mode = VOIDmode; (int) mode < (int) MAX_MACHINE_MODE;
       mode = (n64_enum_machine_mode) ((int) mode + 1))
    {
      if ((mode_size[(int)(mode)]) < min_class_size[(int) (mode_class[(int)(mode)])])
 {
   class_narrowest_mode[(int) (mode_class[(int)(mode)])] = mode;
   min_class_size[(int) (mode_class[(int)(mode)])] = (mode_size[(int)(mode)]);
 }
    }
}

