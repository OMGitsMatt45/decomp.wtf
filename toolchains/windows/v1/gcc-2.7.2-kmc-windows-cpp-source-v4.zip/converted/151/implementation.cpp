// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int wait(...) asm("_wait");
int
waitpid(int pid, int *stat_loc, int options) asm("_waitpid");
int
waitpid(int pid, int *stat_loc, int options)
{
  for (;;)
    {
      int wpid = wait(stat_loc);
      if (wpid == pid || wpid == -1)
 return wpid;
    }
}

