// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/dwarfout.c
/* Output Dwarf format symbol table information from the GNU C compiler.
   Copyright (C) 1992, 1993, 1995 Free Software Foundation, Inc.

   Written by Ron Guilmette (rfg@netcom.com) for
   Network Computing Devices, August, September, October, November 1990.
   Generously contributed by NCD to the Free Software Foundation.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int pfatal_with_name(...) asm("_pfatal_with_name");
struct n64_tag_filename_entry;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");



enum n64_cpp_enum_dwarf_tag{
    TAG_padding = 0x0000,
    TAG_array_type = 0x0001,
    TAG_class_type = 0x0002,
    TAG_entry_point = 0x0003,
    TAG_enumeration_type = 0x0004,
    TAG_formal_parameter = 0x0005,
    TAG_global_subroutine = 0x0006,
    TAG_global_variable = 0x0007,


    TAG_label = 0x000a,
    TAG_lexical_block = 0x000b,
    TAG_local_variable = 0x000c,
    TAG_member = 0x000d,

    TAG_pointer_type = 0x000f,
    TAG_reference_type = 0x0010,
    TAG_compile_unit = 0x0011,
    TAG_string_type = 0x0012,
    TAG_structure_type = 0x0013,
    TAG_subroutine = 0x0014,
    TAG_subroutine_type = 0x0015,
    TAG_typedef = 0x0016,
    TAG_union_type = 0x0017,
    TAG_unspecified_parameters = 0x0018,
    TAG_variant = 0x0019,
    TAG_common_block = 0x001a,
    TAG_common_inclusion = 0x001b,
    TAG_inheritance = 0x001c,
    TAG_inlined_subroutine = 0x001d,
    TAG_module = 0x001e,
    TAG_ptr_to_member_type = 0x001f,
    TAG_set_type = 0x0020,
    TAG_subrange_type = 0x0021,
    TAG_with_stmt = 0x0022,



    TAG_format_label = 0x8000,
    TAG_namelist = 0x8001,
    TAG_function_template = 0x8002,
    TAG_class_template = 0x8003
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_tag) n64_enum_dwarf_tag;








enum n64_cpp_enum_dwarf_form{
    FORM_ADDR = 0x1,
    FORM_REF = 0x2,
    FORM_BLOCK2 = 0x3,
    FORM_BLOCK4 = 0x4,
    FORM_DATA2 = 0x5,
    FORM_DATA4 = 0x6,
    FORM_DATA8 = 0x7,
    FORM_STRING = 0x8
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_form) n64_enum_dwarf_form;




enum n64_cpp_enum_dwarf_attribute{
    AT_sibling = (0x0010|FORM_REF),
    AT_location = (0x0020|FORM_BLOCK2),
    AT_name = (0x0030|FORM_STRING),
    AT_fund_type = (0x0050|FORM_DATA2),
    AT_mod_fund_type = (0x0060|FORM_BLOCK2),
    AT_user_def_type = (0x0070|FORM_REF),
    AT_mod_u_d_type = (0x0080|FORM_BLOCK2),
    AT_ordering = (0x0090|FORM_DATA2),
    AT_subscr_data = (0x00a0|FORM_BLOCK2),
    AT_byte_size = (0x00b0|FORM_DATA4),
    AT_bit_offset = (0x00c0|FORM_DATA2),
    AT_bit_size = (0x00d0|FORM_DATA4),

    AT_element_list = (0x00f0|FORM_BLOCK4),
    AT_stmt_list = (0x0100|FORM_DATA4),
    AT_low_pc = (0x0110|FORM_ADDR),
    AT_high_pc = (0x0120|FORM_ADDR),
    AT_language = (0x0130|FORM_DATA4),
    AT_member = (0x0140|FORM_REF),
    AT_discr = (0x0150|FORM_REF),
    AT_discr_value = (0x0160|FORM_BLOCK2),


    AT_string_length = (0x0190|FORM_BLOCK2),
    AT_common_reference = (0x01a0|FORM_REF),
    AT_comp_dir = (0x01b0|FORM_STRING),
        AT_const_value_string = (0x01c0|FORM_STRING),
        AT_const_value_data2 = (0x01c0|FORM_DATA2),
        AT_const_value_data4 = (0x01c0|FORM_DATA4),
        AT_const_value_data8 = (0x01c0|FORM_DATA8),
        AT_const_value_block2 = (0x01c0|FORM_BLOCK2),
        AT_const_value_block4 = (0x01c0|FORM_BLOCK4),
    AT_containing_type = (0x01d0|FORM_REF),
        AT_default_value_addr = (0x01e0|FORM_ADDR),
        AT_default_value_data2 = (0x01e0|FORM_DATA2),
        AT_default_value_data4 = (0x01e0|FORM_DATA4),
        AT_default_value_data8 = (0x01e0|FORM_DATA8),
        AT_default_value_string = (0x01e0|FORM_STRING),
    AT_friends = (0x01f0|FORM_BLOCK2),
    AT_inline = (0x0200|FORM_STRING),
    AT_is_optional = (0x0210|FORM_STRING),
        AT_lower_bound_ref = (0x0220|FORM_REF),
        AT_lower_bound_data2 = (0x0220|FORM_DATA2),
        AT_lower_bound_data4 = (0x0220|FORM_DATA4),
        AT_lower_bound_data8 = (0x0220|FORM_DATA8),
    AT_private = (0x0240|FORM_STRING),
    AT_producer = (0x0250|FORM_STRING),
    AT_program = (0x0230|FORM_STRING),
    AT_protected = (0x0260|FORM_STRING),
    AT_prototyped = (0x0270|FORM_STRING),
    AT_public = (0x0280|FORM_STRING),
    AT_pure_virtual = (0x0290|FORM_STRING),
    AT_return_addr = (0x02a0|FORM_BLOCK2),
    AT_abstract_origin = (0x02b0|FORM_REF),
    AT_start_scope = (0x02c0|FORM_DATA4),
    AT_stride_size = (0x02e0|FORM_DATA4),
        AT_upper_bound_ref = (0x02f0|FORM_REF),
        AT_upper_bound_data2 = (0x02f0|FORM_DATA2),
        AT_upper_bound_data4 = (0x02f0|FORM_DATA4),
        AT_upper_bound_data8 = (0x02f0|FORM_DATA8),
    AT_virtual = (0x0300|FORM_STRING),



    AT_sf_names = (0x8000|FORM_DATA4),
    AT_src_info = (0x8010|FORM_DATA4),
    AT_mac_info = (0x8020|FORM_DATA4),
    AT_src_coords = (0x8030|FORM_DATA4),
    AT_body_begin = (0x8040|FORM_ADDR),
    AT_body_end = (0x8050|FORM_ADDR)
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_attribute) n64_enum_dwarf_attribute;







enum n64_cpp_enum_dwarf_location_atom{
    OP_REG = 0x01,
    OP_BASEREG = 0x02,
    OP_ADDR = 0x03,
    OP_CONST = 0x04,
    OP_DEREF2 = 0x05,
    OP_DEREF4 = 0x06,
    OP_ADD = 0x07
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_location_atom) n64_enum_dwarf_location_atom;







enum n64_cpp_enum_dwarf_fundamental_type{
    FT_char = 0x0001,
    FT_signed_char = 0x0002,
    FT_unsigned_char = 0x0003,
    FT_short = 0x0004,
    FT_signed_short = 0x0005,
    FT_unsigned_short = 0x0006,
    FT_integer = 0x0007,
    FT_signed_integer = 0x0008,
    FT_unsigned_integer = 0x0009,
    FT_long = 0x000a,
    FT_signed_long = 0x000b,
    FT_unsigned_long = 0x000c,
    FT_pointer = 0x000d,
    FT_float = 0x000e,
    FT_dbl_prec_float = 0x000f,
    FT_ext_prec_float = 0x0010,
    FT_complex = 0x0011,
    FT_dbl_prec_complex = 0x0012,

    FT_void = 0x0014,
    FT_boolean = 0x0015,
    FT_ext_prec_complex = 0x0016,
    FT_label = 0x0017,





    FT_long_long = 0x8008,
    FT_signed_long_long = 0x8108,
    FT_unsigned_long_long = 0x8208,

    FT_int8 = 0x9001,
    FT_signed_int8 = 0x9101,
    FT_unsigned_int8 = 0x9201,
    FT_int16 = 0x9302,
    FT_signed_int16 = 0x9402,
    FT_unsigned_int16 = 0x9502,
    FT_int32 = 0x9604,
    FT_signed_int32 = 0x9704,
    FT_unsigned_int32 = 0x9804,
    FT_int64 = 0x9908,
    FT_signed_int64 = 0x9a08,
    FT_unsigned_int64 = 0x9b08,

    FT_real32 = 0xa004,
    FT_real64 = 0xa108,
    FT_real96 = 0xa20c,
    FT_real128 = 0xa310
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_fundamental_type) n64_enum_dwarf_fundamental_type;







enum n64_cpp_enum_dwarf_type_modifier{
    MOD_pointer_to = 0x01,
    MOD_reference_to = 0x02,
    MOD_const = 0x03,
    MOD_volatile = 0x04
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_type_modifier) n64_enum_dwarf_type_modifier;







enum n64_cpp_enum_dwarf_array_dim_ordering{
    ORD_row_major = 0,
    ORD_col_major = 1
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_array_dim_ordering) n64_enum_dwarf_array_dim_ordering;




enum n64_cpp_enum_dwarf_subscr_data_formats{
    FMT_FT_C_C = 0x0,
    FMT_FT_C_X = 0x1,
    FMT_FT_X_C = 0x2,
    FMT_FT_X_X = 0x3,
    FMT_UT_C_C = 0x4,
    FMT_UT_C_X = 0x5,
    FMT_UT_X_C = 0x6,
    FMT_UT_X_X = 0x7,
    FMT_ET = 0x8
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_subscr_data_formats) n64_enum_dwarf_subscr_data_formats;

enum n64_cpp_enum_dwarf_source_language{
    LANG_C89 = 0x00000001,
    LANG_C = 0x00000002,
    LANG_ADA83 = 0x00000003,
    LANG_C_PLUS_PLUS = 0x00000004,
    LANG_COBOL74 = 0x00000005,
    LANG_COBOL85 = 0x00000006,
    LANG_FORTRAN77 = 0x00000007,
    LANG_FORTRAN90 = 0x00000008,
    LANG_PASCAL83 = 0x00000009,
    LANG_MODULA2 = 0x0000000a
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_source_language) n64_enum_dwarf_source_language;







enum n64_cpp_enum_dwarf_macinfo_record_type{
    MACINFO_start = 's',
    MACINFO_resume = 'r',
    MACINFO_define = 'd',
    MACINFO_undef = 'u'
};
typedef __underlying_type(enum n64_cpp_enum_dwarf_macinfo_record_type) n64_enum_dwarf_macinfo_record_type;

enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern rtx reload_in[(2 * 10 * (1 + 1))];
extern rtx reload_out[(2 * 10 * (1 + 1))];
extern rtx reload_in_reg[(2 * 10 * (1 + 1))];
extern n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
extern char reload_optional[(2 * 10 * (1 + 1))];
extern int reload_inc[(2 * 10 * (1 + 1))];
extern int reload_opnum[(2 * 10 * (1 + 1))];
extern int reload_secondary_p[(2 * 10 * (1 + 1))];
extern int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
extern int reload_secondary_out_reload[(2 * 10 * (1 + 1))];




extern int n_reloads;

extern rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
enum n64_cpp_enum_reload_type{
  RELOAD_FOR_INPUT, RELOAD_FOR_OUTPUT, RELOAD_FOR_INSN,
  RELOAD_FOR_INPUT_ADDRESS, RELOAD_FOR_OUTPUT_ADDRESS,
  RELOAD_FOR_OPERAND_ADDRESS, RELOAD_FOR_OPADDR_ADDR,
  RELOAD_OTHER, RELOAD_FOR_OTHER_ADDRESS
};
typedef __underlying_type(enum n64_cpp_enum_reload_type) n64_enum_reload_type;


extern n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];

extern rtx *reg_equiv_constant;
extern rtx *reg_equiv_memory_loc;
extern rtx *reg_equiv_address;
extern rtx *reg_equiv_mem;



extern int n_earlyclobbers;
extern rtx reload_earlyclobbers[10];


extern int reload_n_operands;



extern int reload_first_uid;





extern char indirect_symref_ok;


extern char double_reg_address_ok;
extern rtx get_secondary_mem (rtx, n64_enum_machine_mode, int, n64_enum_reload_type) asm("_get_secondary_mem")
                               ;


extern void clear_secondary_mem (void) asm("_clear_secondary_mem");



extern void transfer_replacements (int, int) asm("_transfer_replacements");




extern int strict_memory_address_p (n64_enum_machine_mode, rtx) asm("_strict_memory_address_p");




extern int operands_match_p (rtx, rtx) asm("_operands_match_p");


extern int n_occurrences (int, char *) asm("_n_occurrences");


extern int safe_from_earlyclobber (rtx, rtx) asm("_safe_from_earlyclobber");




extern void find_reloads (rtx, int, int, int, short *) asm("_find_reloads");





extern rtx form_sum (rtx, rtx) asm("_form_sum");



extern void subst_reloads (void) asm("_subst_reloads");




extern void copy_replacements (rtx, rtx) asm("_copy_replacements");



extern rtx find_replacement (rtx *) asm("_find_replacement");




extern int refers_to_regno_for_reload_p (int, int, rtx, rtx *) asm("_refers_to_regno_for_reload_p");


extern int reg_overlap_mentioned_for_reload_p (rtx, rtx) asm("_reg_overlap_mentioned_for_reload_p");



extern int refers_to_mem_for_reload_p (rtx) asm("_refers_to_mem_for_reload_p");



extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg")
                             ;


extern int regno_clobbered_p (int, rtx) asm("_regno_clobbered_p");





extern void init_reload (void) asm("_init_reload");


extern int reload (rtx, int, FILE *) asm("_reload");



extern void mark_home_live (int) asm("_mark_home_live");



extern rtx eliminate_regs (rtx, n64_enum_machine_mode, rtx) asm("_eliminate_regs");




extern rtx gen_reload (rtx, rtx, int, n64_enum_reload_type) asm("_gen_reload");




extern void init_caller_save (void) asm("_init_caller_save");


extern void init_save_areas (void) asm("_init_save_areas");


extern int setup_save_areas (int *) asm("_setup_save_areas");


extern void save_call_clobbered_regs (n64_enum_machine_mode) asm("_save_call_clobbered_regs");
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
extern char *getpwd(void) asm("_getpwd");

extern char *strchr(...) asm("_strchr");
extern char *strrchr(...) asm("_strrchr");
extern int flag_traditional;
extern char *version_string;
extern char *language_string;
struct n64_tag_filename_entry {
  unsigned number;
  char * name;
};

typedef struct n64_tag_filename_entry filename_entry;



static filename_entry *filename_table;





static unsigned ft_entries_allocated;



static unsigned ft_entries;
static char *primary_filename;



static char *last_filename;
static unsigned next_block_number = 2;



static unsigned next_unused_dienum = 1;



static unsigned current_dienum;





static int next_pubname_number = 0;






static unsigned *pending_sibling_stack;




static unsigned pending_siblings;




static unsigned pending_siblings_allocated;
static int finalizing = 0;





static tree *pending_types_list;



static unsigned pending_types_allocated;



static unsigned pending_types;
static tree fake_containing_scope;







static unsigned current_funcdef_number = 1;






static tree dwarf_last_decl;



static void output_type(...) asm("_output_type");
static void type_attribute(...) asm("_type_attribute");
static void output_decls_for_scope(...) asm("_output_decls_for_scope");
static void output_decl(...) asm("_output_decl");
static unsigned lookup_filename(...) asm("_lookup_filename");
static char *
xstrdup(register char *s) asm("_xstrdup");
static char *
xstrdup(register char *s)
{
  register char *p = (char *) xmalloc (strlen (s) + 1);

  strcpy (p, s);
  return p;
}

static int
is_pseudo_reg(register rtx rtl) asm("_is_pseudo_reg");
static int
is_pseudo_reg(register rtx rtl)
{
  return (((((rtl)->code) == REG) && (((rtl)->fld[0].rtint) >= 68))
          || ((((rtl)->code) == SUBREG)
       && (((((rtl)->fld[0].rtx))->fld[0].rtint) >= 68)));
}

static tree
type_main_variant(register tree type) asm("_type_main_variant");
static tree
type_main_variant(register tree type)
{
  type = ((type)->type.main_variant);






  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
      while (type != ((type)->type.main_variant))
        type = ((type)->type.main_variant);
    }

  return type;
}



static int
is_tagged_type(register tree type) asm("_is_tagged_type");
static int
is_tagged_type(register tree type)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);

  return (code == RECORD_TYPE || code == UNION_TYPE
   || code == QUAL_UNION_TYPE || code == ENUMERAL_TYPE);
}

static char *
dwarf_tag_name(register unsigned int tag) asm("_dwarf_tag_name");
static char *
dwarf_tag_name(register unsigned int tag)
{
  switch (tag)
    {
    case TAG_padding: return "TAG_padding";
    case TAG_array_type: return "TAG_array_type";
    case TAG_class_type: return "TAG_class_type";
    case TAG_entry_point: return "TAG_entry_point";
    case TAG_enumeration_type: return "TAG_enumeration_type";
    case TAG_formal_parameter: return "TAG_formal_parameter";
    case TAG_global_subroutine: return "TAG_global_subroutine";
    case TAG_global_variable: return "TAG_global_variable";
    case TAG_label: return "TAG_label";
    case TAG_lexical_block: return "TAG_lexical_block";
    case TAG_local_variable: return "TAG_local_variable";
    case TAG_member: return "TAG_member";
    case TAG_pointer_type: return "TAG_pointer_type";
    case TAG_reference_type: return "TAG_reference_type";
    case TAG_compile_unit: return "TAG_compile_unit";
    case TAG_string_type: return "TAG_string_type";
    case TAG_structure_type: return "TAG_structure_type";
    case TAG_subroutine: return "TAG_subroutine";
    case TAG_subroutine_type: return "TAG_subroutine_type";
    case TAG_typedef: return "TAG_typedef";
    case TAG_union_type: return "TAG_union_type";
    case TAG_unspecified_parameters: return "TAG_unspecified_parameters";
    case TAG_variant: return "TAG_variant";
    case TAG_common_block: return "TAG_common_block";
    case TAG_common_inclusion: return "TAG_common_inclusion";
    case TAG_inheritance: return "TAG_inheritance";
    case TAG_inlined_subroutine: return "TAG_inlined_subroutine";
    case TAG_module: return "TAG_module";
    case TAG_ptr_to_member_type: return "TAG_ptr_to_member_type";
    case TAG_set_type: return "TAG_set_type";
    case TAG_subrange_type: return "TAG_subrange_type";
    case TAG_with_stmt: return "TAG_with_stmt";



    case TAG_format_label: return "TAG_format_label";
    case TAG_namelist: return "TAG_namelist";
    case TAG_function_template: return "TAG_function_template";
    case TAG_class_template: return "TAG_class_template";

    default: return "TAG_<unknown>";
    }
}

static char *
dwarf_attr_name(register unsigned int attr) asm("_dwarf_attr_name");
static char *
dwarf_attr_name(register unsigned int attr)
{
  switch (attr)
    {
    case AT_sibling: return "AT_sibling";
    case AT_location: return "AT_location";
    case AT_name: return "AT_name";
    case AT_fund_type: return "AT_fund_type";
    case AT_mod_fund_type: return "AT_mod_fund_type";
    case AT_user_def_type: return "AT_user_def_type";
    case AT_mod_u_d_type: return "AT_mod_u_d_type";
    case AT_ordering: return "AT_ordering";
    case AT_subscr_data: return "AT_subscr_data";
    case AT_byte_size: return "AT_byte_size";
    case AT_bit_offset: return "AT_bit_offset";
    case AT_bit_size: return "AT_bit_size";
    case AT_element_list: return "AT_element_list";
    case AT_stmt_list: return "AT_stmt_list";
    case AT_low_pc: return "AT_low_pc";
    case AT_high_pc: return "AT_high_pc";
    case AT_language: return "AT_language";
    case AT_member: return "AT_member";
    case AT_discr: return "AT_discr";
    case AT_discr_value: return "AT_discr_value";
    case AT_string_length: return "AT_string_length";
    case AT_common_reference: return "AT_common_reference";
    case AT_comp_dir: return "AT_comp_dir";
    case AT_const_value_string: return "AT_const_value_string";
    case AT_const_value_data2: return "AT_const_value_data2";
    case AT_const_value_data4: return "AT_const_value_data4";
    case AT_const_value_data8: return "AT_const_value_data8";
    case AT_const_value_block2: return "AT_const_value_block2";
    case AT_const_value_block4: return "AT_const_value_block4";
    case AT_containing_type: return "AT_containing_type";
    case AT_default_value_addr: return "AT_default_value_addr";
    case AT_default_value_data2: return "AT_default_value_data2";
    case AT_default_value_data4: return "AT_default_value_data4";
    case AT_default_value_data8: return "AT_default_value_data8";
    case AT_default_value_string: return "AT_default_value_string";
    case AT_friends: return "AT_friends";
    case AT_inline: return "AT_inline";
    case AT_is_optional: return "AT_is_optional";
    case AT_lower_bound_ref: return "AT_lower_bound_ref";
    case AT_lower_bound_data2: return "AT_lower_bound_data2";
    case AT_lower_bound_data4: return "AT_lower_bound_data4";
    case AT_lower_bound_data8: return "AT_lower_bound_data8";
    case AT_private: return "AT_private";
    case AT_producer: return "AT_producer";
    case AT_program: return "AT_program";
    case AT_protected: return "AT_protected";
    case AT_prototyped: return "AT_prototyped";
    case AT_public: return "AT_public";
    case AT_pure_virtual: return "AT_pure_virtual";
    case AT_return_addr: return "AT_return_addr";
    case AT_abstract_origin: return "AT_abstract_origin";
    case AT_start_scope: return "AT_start_scope";
    case AT_stride_size: return "AT_stride_size";
    case AT_upper_bound_ref: return "AT_upper_bound_ref";
    case AT_upper_bound_data2: return "AT_upper_bound_data2";
    case AT_upper_bound_data4: return "AT_upper_bound_data4";
    case AT_upper_bound_data8: return "AT_upper_bound_data8";
    case AT_virtual: return "AT_virtual";



    case AT_sf_names: return "AT_sf_names";
    case AT_src_info: return "AT_src_info";
    case AT_mac_info: return "AT_mac_info";
    case AT_src_coords: return "AT_src_coords";
    case AT_body_begin: return "AT_body_begin";
    case AT_body_end: return "AT_body_end";

    default: return "AT_<unknown>";
    }
}

static char *
dwarf_stack_op_name(register unsigned int op) asm("_dwarf_stack_op_name");
static char *
dwarf_stack_op_name(register unsigned int op)
{
  switch (op)
    {
    case OP_REG: return "OP_REG";
    case OP_BASEREG: return "OP_BASEREG";
    case OP_ADDR: return "OP_ADDR";
    case OP_CONST: return "OP_CONST";
    case OP_DEREF2: return "OP_DEREF2";
    case OP_DEREF4: return "OP_DEREF4";
    case OP_ADD: return "OP_ADD";
    default: return "OP_<unknown>";
    }
}

static char *
dwarf_typemod_name(register unsigned int mod) asm("_dwarf_typemod_name");
static char *
dwarf_typemod_name(register unsigned int mod)
{
  switch (mod)
    {
    case MOD_pointer_to: return "MOD_pointer_to";
    case MOD_reference_to: return "MOD_reference_to";
    case MOD_const: return "MOD_const";
    case MOD_volatile: return "MOD_volatile";
    default: return "MOD_<unknown>";
    }
}

static char *
dwarf_fmt_byte_name(register unsigned int fmt) asm("_dwarf_fmt_byte_name");
static char *
dwarf_fmt_byte_name(register unsigned int fmt)
{
  switch (fmt)
    {
    case FMT_FT_C_C: return "FMT_FT_C_C";
    case FMT_FT_C_X: return "FMT_FT_C_X";
    case FMT_FT_X_C: return "FMT_FT_X_C";
    case FMT_FT_X_X: return "FMT_FT_X_X";
    case FMT_UT_C_C: return "FMT_UT_C_C";
    case FMT_UT_C_X: return "FMT_UT_C_X";
    case FMT_UT_X_C: return "FMT_UT_X_C";
    case FMT_UT_X_X: return "FMT_UT_X_X";
    case FMT_ET: return "FMT_ET";
    default: return "FMT_<unknown>";
    }
}
static char *
dwarf_fund_type_name(register unsigned int ft) asm("_dwarf_fund_type_name");
static char *
dwarf_fund_type_name(register unsigned int ft)
{
  switch (ft)
    {
    case FT_char: return "FT_char";
    case FT_signed_char: return "FT_signed_char";
    case FT_unsigned_char: return "FT_unsigned_char";
    case FT_short: return "FT_short";
    case FT_signed_short: return "FT_signed_short";
    case FT_unsigned_short: return "FT_unsigned_short";
    case FT_integer: return "FT_integer";
    case FT_signed_integer: return "FT_signed_integer";
    case FT_unsigned_integer: return "FT_unsigned_integer";
    case FT_long: return "FT_long";
    case FT_signed_long: return "FT_signed_long";
    case FT_unsigned_long: return "FT_unsigned_long";
    case FT_pointer: return "FT_pointer";
    case FT_float: return "FT_float";
    case FT_dbl_prec_float: return "FT_dbl_prec_float";
    case FT_ext_prec_float: return "FT_ext_prec_float";
    case FT_complex: return "FT_complex";
    case FT_dbl_prec_complex: return "FT_dbl_prec_complex";
    case FT_void: return "FT_void";
    case FT_boolean: return "FT_boolean";
    case FT_ext_prec_complex: return "FT_ext_prec_complex";
    case FT_label: return "FT_label";



    case FT_long_long: return "FT_long_long";
    case FT_signed_long_long: return "FT_signed_long_long";
    case FT_unsigned_long_long: return "FT_unsigned_long_long";

    case FT_int8: return "FT_int8";
    case FT_signed_int8: return "FT_signed_int8";
    case FT_unsigned_int8: return "FT_unsigned_int8";
    case FT_int16: return "FT_int16";
    case FT_signed_int16: return "FT_signed_int16";
    case FT_unsigned_int16: return "FT_unsigned_int16";
    case FT_int32: return "FT_int32";
    case FT_signed_int32: return "FT_signed_int32";
    case FT_unsigned_int32: return "FT_unsigned_int32";
    case FT_int64: return "FT_int64";
    case FT_signed_int64: return "FT_signed_int64";
    case FT_unsigned_int64: return "FT_signed_int64";

    case FT_real32: return "FT_real32";
    case FT_real64: return "FT_real64";
    case FT_real96: return "FT_real96";
    case FT_real128: return "FT_real128";

    default: return "FT_<unknown>";
    }
}







static tree
decl_ultimate_origin(register tree decl) asm("_decl_ultimate_origin");
static tree
decl_ultimate_origin(register tree decl)
{
  register tree immediate_origin = ((decl)->decl.abstract_origin);

  if (immediate_origin == 
                         ((void *)0)
                             )
    return 
          ((void *)0)
              ;
  else
    {
      register tree ret_val;
      register tree lookahead = immediate_origin;

      do
 {
   ret_val = lookahead;
   lookahead = ((ret_val)->decl.abstract_origin);
 }
      while (lookahead != 
                         ((void *)0) 
                              && lookahead != ret_val);
      return ret_val;
    }
}







static tree
block_ultimate_origin(register tree block) asm("_block_ultimate_origin");
static tree
block_ultimate_origin(register tree block)
{
  register tree immediate_origin = ((block)->block.abstract_origin);

  if (immediate_origin == 
                         ((void *)0)
                             )
    return 
          ((void *)0)
              ;
  else
    {
      register tree ret_val;
      register tree lookahead = immediate_origin;

      do
 {
   ret_val = lookahead;
   lookahead = (((n64_enum_tree_code) (ret_val)->common.code) == BLOCK)
         ? ((ret_val)->block.abstract_origin)
         : 
          ((void *)0)
              ;
 }
      while (lookahead != 
                         ((void *)0) 
                              && lookahead != ret_val);
      return ret_val;
    }
}

static void
output_unsigned_leb128(register long unsigned int value) asm("_output_unsigned_leb128");
static void
output_unsigned_leb128(register long unsigned int value)
{
  register unsigned long orig_value = value;

  do
    {
      register unsigned byte = (value & 0x7f);

      value >>= 7;
      if (value != 0)
 byte |= 0x80;
      fprintf (asm_out_file, "\t%s\t0x%x", ".byte", (unsigned) byte);
      if (flag_verbose_asm && value == 0)
 fprintf (asm_out_file, "\t%s ULEB128 number - value = %u",
   "\t\t# ", orig_value);
      fputc ('\n', asm_out_file);
    }
  while (value != 0);
}

static void
output_signed_leb128(register long int value) asm("_output_signed_leb128");
static void
output_signed_leb128(register long int value)
{
  register long orig_value = value;
  register int negative = (value < 0);
  register int more;

  do
    {
      register unsigned byte = (value & 0x7f);

      value >>= 7;
      if (negative)
 value |= 0xfe000000;
      if (((value == 0) && ((byte & 0x40) == 0))
          || ((value == -1) && ((byte & 0x40) == 1)))
 more = 0;
      else
 {
   byte |= 0x80;
   more = 1;
 }
      fprintf (asm_out_file, "\t%s\t0x%x", ".byte", (unsigned) byte);
      if (flag_verbose_asm && more == 0)
 fprintf (asm_out_file, "\t%s SLEB128 number - value = %d",
   "\t\t# ", orig_value);
      fputc ('\n', asm_out_file);
    }
  while (more);
}
static int
is_body_block(register tree stmt) asm("_is_body_block");
static int
is_body_block(register tree stmt)
{
  if (((n64_enum_tree_code) (stmt)->common.code) == BLOCK)
    {
      register tree parent = ((stmt)->block.supercontext);

      if (((n64_enum_tree_code) (parent)->common.code) == BLOCK)
 {
   register tree grandparent = ((parent)->block.supercontext);

   if (((n64_enum_tree_code) (grandparent)->common.code) == FUNCTION_DECL)
     return 1;
 }
    }
  return 0;
}
static int
fundamental_type_code(register tree type) asm("_fundamental_type_code");
static int
fundamental_type_code(register tree type)
{
  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return 0;

  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case ERROR_MARK:
 return FT_void;

      case VOID_TYPE:
 return FT_void;

      case INTEGER_TYPE:




 if (((type)->type.name) != 0
     && ((n64_enum_tree_code) (((type)->type.name))->common.code) == TYPE_DECL
     && ((((type)->type.name))->decl.name) != 0
     && ((n64_enum_tree_code) (((((type)->type.name))->decl.name))->common.code) == IDENTIFIER_NODE)
   {
     char *name = ((((((type)->type.name))->decl.name))->identifier.pointer);

     if (!strcmp (name, "unsigned char"))
       return FT_unsigned_char;
     if (!strcmp (name, "signed char"))
       return FT_signed_char;
     if (!strcmp (name, "unsigned int"))
       return FT_unsigned_integer;
     if (!strcmp (name, "short int"))
       return FT_short;
     if (!strcmp (name, "short unsigned int"))
       return FT_unsigned_short;
     if (!strcmp (name, "long int"))
       return FT_long;
     if (!strcmp (name, "long unsigned int"))
       return FT_unsigned_long;
     if (!strcmp (name, "long long int"))
       return FT_long_long;
     if (!strcmp (name, "long long unsigned int"))
       return FT_unsigned_long_long;
   }





 if (((type)->type.precision) == ((target_flags & 0x00000001) ? 64 : 32))
   return (((type)->common.unsigned_flag) ? FT_unsigned_integer : FT_integer);

 if (((type)->type.precision) == ((target_flags & 0x00000002) ? 64 : 32))
   return (((type)->common.unsigned_flag) ? FT_unsigned_long : FT_long);

 if (((type)->type.precision) == 64)
   return (((type)->common.unsigned_flag) ? FT_unsigned_long_long : FT_long_long);

 if (((type)->type.precision) == 16)
   return (((type)->common.unsigned_flag) ? FT_unsigned_short : FT_short);

 if (((type)->type.precision) == 8)
   return (((type)->common.unsigned_flag) ? FT_unsigned_char : FT_char);

 abort ();

      case REAL_TYPE:


 if (((type)->type.name) != 0
     && ((n64_enum_tree_code) (((type)->type.name))->common.code) == TYPE_DECL
     && ((((type)->type.name))->decl.name) != 0
     && ((n64_enum_tree_code) (((((type)->type.name))->decl.name))->common.code) == IDENTIFIER_NODE)
   {
     char *name = ((((((type)->type.name))->decl.name))->identifier.pointer);





     if (!strcmp (name, "long double"))
       return FT_ext_prec_float;
   }

 if (((type)->type.precision) == 64)
   return FT_dbl_prec_float;
 if (((type)->type.precision) == 32)
   return FT_float;





 if (((type)->type.precision) == 64)
   return FT_ext_prec_float;
 abort ();

      case COMPLEX_TYPE:
 return FT_complex;

      case CHAR_TYPE:
 return FT_char;

      case BOOLEAN_TYPE:
 return FT_boolean;

      default:
 abort ();
    }
  return 0;
}
static tree
root_type(register tree type) asm("_root_type");
static tree
root_type(register tree type)
{
  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return error_mark_node;

  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case ERROR_MARK:
 return error_mark_node;

      case POINTER_TYPE:
      case REFERENCE_TYPE:
 return type_main_variant (root_type (((type)->common.type)));

      default:
 return type_main_variant (type);
    }
}




static void
write_modifier_bytes(register tree type, register int decl_const, register int decl_volatile) asm("_write_modifier_bytes");
static void
write_modifier_bytes(register tree type, register int decl_const, register int decl_volatile)
{
  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return;

  if (((type)->common.readonly_flag) || decl_const)
    do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) MOD_const); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_typemod_name (MOD_const)); fputc ('\n', (asm_out_file)); } while (0);
  if (((type)->common.volatile_flag) || decl_volatile)
    do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) MOD_volatile); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_typemod_name (MOD_volatile)); fputc ('\n', (asm_out_file)); } while (0);
  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case POINTER_TYPE:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) MOD_pointer_to); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_typemod_name (MOD_pointer_to)); fputc ('\n', (asm_out_file)); } while (0);
 write_modifier_bytes (((type)->common.type), 0, 0);
 return;

      case REFERENCE_TYPE:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) MOD_reference_to); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_typemod_name (MOD_reference_to)); fputc ('\n', (asm_out_file)); } while (0);
 write_modifier_bytes (((type)->common.type), 0, 0);
 return;

      case ERROR_MARK:
      default:
 return;
    }
}




static int
type_is_fundamental(register tree type) asm("_type_is_fundamental");
static int
type_is_fundamental(register tree type)
{
  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case ERROR_MARK:
      case VOID_TYPE:
      case INTEGER_TYPE:
      case REAL_TYPE:
      case COMPLEX_TYPE:
      case BOOLEAN_TYPE:
      case CHAR_TYPE:
 return 1;

      case SET_TYPE:
      case ARRAY_TYPE:
      case RECORD_TYPE:
      case UNION_TYPE:
      case QUAL_UNION_TYPE:
      case ENUMERAL_TYPE:
      case FUNCTION_TYPE:
      case METHOD_TYPE:
      case POINTER_TYPE:
      case REFERENCE_TYPE:
      case FILE_TYPE:
      case OFFSET_TYPE:
      case LANG_TYPE:
 return 0;

      default:
 abort ();
    }
  return 0;
}
static void
equate_decl_number_to_die_number(register tree decl) asm("_equate_decl_number_to_die_number");
static void
equate_decl_number_to_die_number(register tree decl)
{







  char decl_label[30];
  char die_label[30];

  sprintf (decl_label, ".L_E%u", ((decl)->decl.uid));
  sprintf (die_label, ".L_D%u", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".set"); assemble_name (asm_out_file, decl_label); fprintf (asm_out_file, ","); assemble_name (asm_out_file, die_label); fprintf (asm_out_file, "\n"); } while (0);
}
static void
equate_type_number_to_die_number(register tree type) asm("_equate_type_number_to_die_number");
static void
equate_type_number_to_die_number(register tree type)
{
  char type_label[30];
  char die_label[30];






  type = type_main_variant (type);

  sprintf (type_label, ".L_T%u", ((type)->type.uid));
  sprintf (die_label, ".L_D%u", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".set"); assemble_name (asm_out_file, type_label); fprintf (asm_out_file, ","); assemble_name (asm_out_file, die_label); fprintf (asm_out_file, "\n"); } while (0);
}

static void
output_reg_number(register rtx rtl) asm("_output_reg_number");
static void
output_reg_number(register rtx rtl)
{
  register unsigned regno = ((rtl)->fld[0].rtint);

  if (regno >= 68)
    {
      warning_with_decl (dwarf_last_decl, "internal regno botch: regno = %d\n",
    regno);
      regno = 0;
    }
  fprintf (asm_out_file, "\t%s\t0x%x",
    ".4byte", mips_dbx_regno[ (regno) ]);
  if (flag_verbose_asm)
    {
      fprintf (asm_out_file, "\t%s ", "\t\t# ");
      fprintf ((asm_out_file), "%s", reg_names[((rtl)->fld[0].rtint)]);
    }
  fputc ('\n', asm_out_file);
}
static void
output_mem_loc_descriptor(register rtx rtl) asm("_output_mem_loc_descriptor");
static void
output_mem_loc_descriptor(register rtx rtl)
{





  switch (((rtl)->code))
    {
      case SUBREG:







 rtl = ((rtl)->fld[0].rtx);


      case REG:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_BASEREG); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_BASEREG)); fputc ('\n', (asm_out_file)); } while (0);
 output_reg_number (rtl);
 break;

      case MEM:
 output_mem_loc_descriptor (((rtl)->fld[0].rtx));
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_DEREF4); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_DEREF4)); fputc ('\n', (asm_out_file)); } while (0);
 break;

      case CONST:
      case SYMBOL_REF:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_ADDR); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_ADDR)); fputc ('\n', (asm_out_file)); } while (0);
 do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); output_addr_const ((asm_out_file), (rtl)); fputc ('\n', (asm_out_file)); } while (0);
 break;

      case PLUS:
 output_mem_loc_descriptor (((rtl)->fld[0].rtx));
 output_mem_loc_descriptor (((rtl)->fld[1].rtx));
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_ADD); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_ADD)); fputc ('\n', (asm_out_file)); } while (0);
 break;

      case CONST_INT:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_CONST); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_CONST)); fputc ('\n', (asm_out_file)); } while (0);
 fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) ((rtl)->fld[0].rtwint));
 break;

      default:
 abort ();
    }
}







static void
output_loc_descriptor(register rtx rtl) asm("_output_loc_descriptor");
static void
output_loc_descriptor(register rtx rtl)
{
  switch (((rtl)->code))
    {
    case SUBREG:







 rtl = ((rtl)->fld[0].rtx);


    case REG:
 do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_REG); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_REG)); fputc ('\n', (asm_out_file)); } while (0);
 output_reg_number (rtl);
 break;

    case MEM:
      output_mem_loc_descriptor (((rtl)->fld[0].rtx));
      break;

    default:
      abort ();
    }
}




static void
output_bound_representation(register tree bound, register unsigned int dim_num, register char u_or_l) asm("_output_bound_representation");
static void
output_bound_representation(register tree bound, register unsigned int dim_num, register char u_or_l)
{
  switch (((n64_enum_tree_code) (bound)->common.code))
    {

      case ERROR_MARK:
 return;



      case INTEGER_CST:
 fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) (unsigned) ((bound)->int_cst.int_cst_low))
                                        ;
 break;




      case NOP_EXPR:
 bound = ((bound)->exp.operands[0]);


      case SAVE_EXPR:
 {
   char begin_label[30];
   char end_label[30];

   sprintf (begin_label, ".L_b%u_%u_%c",
    current_dienum, dim_num, u_or_l);

   sprintf (end_label, ".L_b%u_%u_%c_e",
    current_dienum, dim_num, u_or_l);

   do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
   do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);





   if (u_or_l != 'u')
     abort ();
   if (! optimize)
     output_loc_descriptor
       (eliminate_regs ((*(struct n64_tag_rtx_def **) &(bound)->exp.operands[2]), 0, (rtx) 0));

   do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
 }
 break;

      default:
 abort ();
    }
}





static void
output_enumeral_list(register tree link) asm("_output_enumeral_list");
static void
output_enumeral_list(register tree link)
{
  if (link)
    {
      output_enumeral_list (((link)->common.chain));
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) (unsigned) ((((link)->list.value))->int_cst.int_cst_low))
                                                         ;
      do { register unsigned char *_ascii_bytes = (unsigned char *) (((((link)->list.purpose))->identifier.pointer)); register unsigned char *limit = _ascii_bytes + (strlen (((((link)->list.purpose))->identifier.pointer))+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0)
                                                   ;
    }
}




static unsigned
ceiling(register unsigned int value, register unsigned int boundary) asm("_ceiling");
static unsigned
ceiling(register unsigned int value, register unsigned int boundary)
{
  return (((value + boundary - 1) / boundary) * boundary);
}





static tree
field_type(register tree decl) asm("_field_type");
static tree
field_type(register tree decl)
{
  register tree type;

  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return integer_type_node;

  type = ((decl)->decl.result);
  if (type == 
             ((void *)0)
                 )
    type = ((decl)->common.type);
  return type;
}





static unsigned
simple_type_align_in_bits(register tree type) asm("_simple_type_align_in_bits");
static unsigned
simple_type_align_in_bits(register tree type)
{
  return (((n64_enum_tree_code) (type)->common.code) != ERROR_MARK) ? ((type)->type.align) : ((target_flags & 0x00002000) ? 64 : 32);
}







static unsigned
simple_type_size_in_bits(register tree type) asm("_simple_type_size_in_bits");
static unsigned
simple_type_size_in_bits(register tree type)
{
  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return ((target_flags & 0x00002000) ? 64 : 32);
  else
    {
      register tree type_size_tree = ((type)->type.size);

      if (((n64_enum_tree_code) (type_size_tree)->common.code) != INTEGER_CST)
 return ((type)->type.align);

      return (unsigned) ((type_size_tree)->int_cst.int_cst_low);
    }
}
static unsigned
field_byte_offset(register tree decl) asm("_field_byte_offset");
static unsigned
field_byte_offset(register tree decl)
{
  register unsigned type_align_in_bytes;
  register unsigned type_align_in_bits;
  register unsigned type_size_in_bits;
  register unsigned object_offset_in_align_units;
  register unsigned object_offset_in_bits;
  register unsigned object_offset_in_bytes;
  register tree type;
  register tree bitpos_tree;
  register tree field_size_tree;
  register unsigned bitpos_int;
  register unsigned deepest_bitpos;
  register unsigned field_size_in_bits;

  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return 0;

  if (((n64_enum_tree_code) (decl)->common.code) != FIELD_DECL)
    abort ();

  type = field_type (decl);

  bitpos_tree = ((decl)->decl.arguments);
  field_size_tree = ((decl)->decl.size);





  if (((n64_enum_tree_code) (bitpos_tree)->common.code) != INTEGER_CST)
    return 0;
  bitpos_int = (unsigned) ((bitpos_tree)->int_cst.int_cst_low);

  if (((n64_enum_tree_code) (field_size_tree)->common.code) != INTEGER_CST)
    return 0;
  field_size_in_bits = (unsigned) ((field_size_tree)->int_cst.int_cst_low);

  type_size_in_bits = simple_type_size_in_bits (type);

  type_align_in_bits = simple_type_align_in_bits (type);
  type_align_in_bytes = type_align_in_bits / 8;
  deepest_bitpos = bitpos_int + field_size_in_bits;



  object_offset_in_bits
    = ceiling (deepest_bitpos, type_align_in_bits) - type_size_in_bits;


  object_offset_in_align_units = object_offset_in_bits / type_align_in_bits;


  object_offset_in_bytes = object_offset_in_align_units * type_align_in_bytes;

  return object_offset_in_bytes;
}
static void
sibling_attribute(void) asm("_sibling_attribute");
static void
sibling_attribute(void)
{
  char label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_sibling); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_sibling)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (label, ".L_D%u", pending_sibling_stack[pending_siblings-1]);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
}





static void
location_attribute(register rtx rtl) asm("_location_attribute");
static void
location_attribute(register rtx rtl)
{
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_location); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_location)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_l%u", current_dienum);
  sprintf (end_label, ".L_l%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  if (! is_pseudo_reg (rtl)
      && (((rtl)->code) != MEM || ! is_pseudo_reg (((rtl)->fld[0].rtx))))
    output_loc_descriptor (eliminate_regs (rtl, 0, (rtx) 0));

  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}
static void
data_member_location_attribute(register tree decl) asm("_data_member_location_attribute");
static void
data_member_location_attribute(register tree decl)
{
  register unsigned object_offset_in_bytes = field_byte_offset (decl);
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_location); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_location)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_l%u", current_dienum);
  sprintf (end_label, ".L_l%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_CONST); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_CONST)); fputc ('\n', (asm_out_file)); } while (0);
  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) object_offset_in_bytes);
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) OP_ADD); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_stack_op_name (OP_ADD)); fputc ('\n', (asm_out_file)); } while (0);
  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}







static void
const_value_attribute(register rtx rtl) asm("_const_value_attribute");
static void
const_value_attribute(register rtx rtl)
{
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_const_value_block4); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_const_value_block4)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_l%u", current_dienum);
  sprintf (end_label, ".L_l%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);

  switch (((rtl)->code))
    {
      case CONST_INT:
 fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) (unsigned) ((rtl)->fld[0].rtwint));
 break;

      case CONST_DOUBLE:







 do { if (((target_flags & 0x00010000) != 0)) { fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned int) ((rtl)->fld[3].rtwint)); fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned int) ((rtl)->fld[2].rtwint)); } else { fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned int) ((rtl)->fld[2].rtwint)); fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned int) ((rtl)->fld[3].rtwint)); } } while (0)

                                                    ;
 break;

      case CONST_STRING:
 do { register unsigned char *_ascii_bytes = (unsigned char *) (((rtl)->fld[0].rtstr)); register unsigned char *limit = _ascii_bytes + (strlen (((rtl)->fld[0].rtstr))+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
 break;

      case SYMBOL_REF:
      case LABEL_REF:
      case CONST:
 do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); output_addr_const ((asm_out_file), (rtl)); fputc ('\n', (asm_out_file)); } while (0);
 break;

      case PLUS:
 break;

      default:
 abort ();
    }

  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}
static void
location_or_const_value_attribute(register tree decl) asm("_location_or_const_value_attribute");
static void
location_or_const_value_attribute(register tree decl)
{
  register rtx rtl;

  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return;

  if ((((n64_enum_tree_code) (decl)->common.code) != VAR_DECL) && (((n64_enum_tree_code) (decl)->common.code) != PARM_DECL))
    {

      abort ();
      return;
    }
  rtl = ((decl)->decl.rtl);

  if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
    if (rtl == (rtx) 0 || is_pseudo_reg (rtl))
      {

        register tree declared_type = type_main_variant (((decl)->common.type));
        register tree passed_type = type_main_variant (((decl)->decl.initial));




 if (declared_type == passed_type)
   rtl = ((decl)->decl.saved_insns.r);
 else if (! ((target_flags & 0x00010000) != 0))
   if (((n64_enum_tree_code) (declared_type)->common.code) == INTEGER_TYPE)
     if (((declared_type)->type.size) <= ((passed_type)->type.size))
       rtl = ((decl)->decl.saved_insns.r);
      }

  if (rtl == (rtx) 0)
    return;

  switch (((rtl)->code))
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST_STRING:
    case SYMBOL_REF:
    case LABEL_REF:
    case CONST:
    case PLUS:
      const_value_attribute (rtl);
      break;

    case MEM:
    case REG:
    case SUBREG:
      location_attribute (rtl);
      break;

    default:
      abort ();
    }
}




static void
name_attribute(register char *name_string) asm("_name_attribute");
static void
name_attribute(register char *name_string)
{
  if (name_string && *name_string)
    {
      do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_name); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_name)); fputc ('\n', (asm_out_file)); } while (0);
      do { register unsigned char *_ascii_bytes = (unsigned char *) (name_string); register unsigned char *limit = _ascii_bytes + (strlen (name_string)+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
    }
}

static void
fund_type_attribute(register unsigned int ft_code) asm("_fund_type_attribute");
static void
fund_type_attribute(register unsigned int ft_code)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_fund_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_fund_type)); fputc ('\n', (asm_out_file)); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) ft_code); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fund_type_name (ft_code)); fputc ('\n', (asm_out_file)); } while (0);
}

static void
mod_fund_type_attribute(register tree type, register int decl_const, register int decl_volatile) asm("_mod_fund_type_attribute");
static void
mod_fund_type_attribute(register tree type, register int decl_const, register int decl_volatile)
{
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_mod_fund_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_mod_fund_type)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_t%u", current_dienum);
  sprintf (end_label, ".L_t%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  write_modifier_bytes (type, decl_const, decl_volatile);
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) fundamental_type_code (root_type (type))); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fund_type_name (fundamental_type_code (root_type (type)))); fputc ('\n', (asm_out_file)); } while (0)
                                                  ;
  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}

static void
user_def_type_attribute(register tree type) asm("_user_def_type_attribute");
static void
user_def_type_attribute(register tree type)
{
  char ud_type_name[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_user_def_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_user_def_type)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (ud_type_name, ".L_T%u", ((type)->type.uid));
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ud_type_name); fprintf (asm_out_file, "\n"); } while (0);
}

static void
mod_u_d_type_attribute(register tree type, register int decl_const, register int decl_volatile) asm("_mod_u_d_type_attribute");
static void
mod_u_d_type_attribute(register tree type, register int decl_const, register int decl_volatile)
{
  char begin_label[30];
  char end_label[30];
  char ud_type_name[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_mod_u_d_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_mod_u_d_type)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_t%u", current_dienum);
  sprintf (end_label, ".L_t%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  write_modifier_bytes (type, decl_const, decl_volatile);
  sprintf (ud_type_name, ".L_T%u", ((root_type (type))->type.uid));
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ud_type_name); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}
static void
subscript_data_attribute(register tree type) asm("_subscript_data_attribute");
static void
subscript_data_attribute(register tree type)
{
  register unsigned dimension_number;
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_subscr_data); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_subscr_data)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_s%u", current_dienum);
  sprintf (end_label, ".L_s%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  for (dimension_number = 0;
 ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE;
 type = ((type)->common.type), dimension_number++)
    {
      register tree domain = ((type)->type.values);





      if (domain)
 {


   register tree lower = ((domain)->type.minval);
   register tree upper = ((domain)->type.maxval);



   if (! type_is_fundamental (domain))
     abort ();



   do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) (((1) ? 0 : 4) | ((((n64_enum_tree_code) (lower)->common.code) == INTEGER_CST) ? 0 : 2) | ((((n64_enum_tree_code) (upper)->common.code) == INTEGER_CST) ? 0 : 1))); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fmt_byte_name ((((1) ? 0 : 4) | ((((n64_enum_tree_code) (lower)->common.code) == INTEGER_CST) ? 0 : 2) | ((((n64_enum_tree_code) (upper)->common.code) == INTEGER_CST) ? 0 : 1)))); fputc ('\n', (asm_out_file)); } while (0)


                                           ;



   do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) fundamental_type_code (domain)); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fund_type_name (fundamental_type_code (domain))); fputc ('\n', (asm_out_file)); } while (0)
                                         ;



   output_bound_representation (lower, dimension_number, 'l');



   output_bound_representation (upper, dimension_number, 'u');
 }
      else
 {
   do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) FMT_FT_C_X); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fmt_byte_name (FMT_FT_C_X)); fputc ('\n', (asm_out_file)); } while (0);



   do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) FT_integer); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fund_type_name (FT_integer)); fputc ('\n', (asm_out_file)); } while (0);



   fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);



   fprintf ((asm_out_file), "\t%s\t0x%x\n", ".2byte", (unsigned) 0);
 }
    }



  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".byte", (unsigned) FMT_ET); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_fmt_byte_name (FMT_ET)); fputc ('\n', (asm_out_file)); } while (0);



  type_attribute (type, 0, 0);

  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}

static void
byte_size_attribute(register tree tree_node) asm("_byte_size_attribute");
static void
byte_size_attribute(register tree tree_node)
{
  register unsigned size;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_byte_size); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_byte_size)); fputc ('\n', (asm_out_file)); } while (0);
  switch (((n64_enum_tree_code) (tree_node)->common.code))
    {
      case ERROR_MARK:
 size = 0;
 break;

      case ENUMERAL_TYPE:
      case RECORD_TYPE:
      case UNION_TYPE:
      case QUAL_UNION_TYPE:
 size = int_size_in_bytes (tree_node);
 break;

      case FIELD_DECL:




 size = simple_type_size_in_bits (field_type (tree_node))
        / 8;
 break;

      default:
 abort ();
    }






  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) size);
}
static void
bit_offset_attribute(register tree decl) asm("_bit_offset_attribute");
static void
bit_offset_attribute(register tree decl)
{
  register unsigned object_offset_in_bytes = field_byte_offset (decl);
  register tree type = ((decl)->decl.result);
  register tree bitpos_tree = ((decl)->decl.arguments);
  register unsigned bitpos_int;
  register unsigned highest_order_object_bit_offset;
  register unsigned highest_order_field_bit_offset;
  register unsigned bit_offset;
  if (((n64_enum_tree_code) (bitpos_tree)->common.code) != INTEGER_CST)
    return;
  bitpos_int = (unsigned) ((bitpos_tree)->int_cst.int_cst_low);







  highest_order_object_bit_offset = object_offset_in_bytes * 8;
  highest_order_field_bit_offset = bitpos_int;

  if (! ((target_flags & 0x00010000) != 0))
    {
      highest_order_field_bit_offset
 += (unsigned) ((((decl)->decl.size))->int_cst.int_cst_low);

      highest_order_object_bit_offset += simple_type_size_in_bits (type);
    }

  bit_offset =
    (! ((target_flags & 0x00010000) != 0)
     ? highest_order_object_bit_offset - highest_order_field_bit_offset
     : highest_order_field_bit_offset - highest_order_object_bit_offset);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_bit_offset); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_bit_offset)); fputc ('\n', (asm_out_file)); } while (0);
  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".2byte", (unsigned) bit_offset);
}




static void
bit_size_attribute(register tree decl) asm("_bit_size_attribute");
static void
bit_size_attribute(register tree decl)
{



  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_bit_size); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_bit_size)); fputc ('\n', (asm_out_file)); } while (0);
  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) (unsigned) ((((decl)->decl.size))->int_cst.int_cst_low))
                                                    ;
}






static void
element_list_attribute(register tree element) asm("_element_list_attribute");
static void
element_list_attribute(register tree element)
{
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_element_list); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_element_list)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_e%u", current_dienum);
  sprintf (end_label, ".L_e%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);






  output_enumeral_list (element);

  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}




static void
stmt_list_attribute(register char *label) asm("_stmt_list_attribute");
static void
stmt_list_attribute(register char *label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_stmt_list); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_stmt_list)); fputc ('\n', (asm_out_file)); } while (0);

  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
}




static void
low_pc_attribute(register char *asm_low_label) asm("_low_pc_attribute");
static void
low_pc_attribute(register char *asm_low_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_low_pc); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_low_pc)); fputc ('\n', (asm_out_file)); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, asm_low_label); fprintf (asm_out_file, "\n"); } while (0);
}




static void
high_pc_attribute(register char *asm_high_label) asm("_high_pc_attribute");
static void
high_pc_attribute(register char *asm_high_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_high_pc); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_high_pc)); fputc ('\n', (asm_out_file)); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, asm_high_label); fprintf (asm_out_file, "\n"); } while (0);
}



static void
body_begin_attribute(register char *asm_begin_label) asm("_body_begin_attribute");
static void
body_begin_attribute(register char *asm_begin_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_body_begin); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_body_begin)); fputc ('\n', (asm_out_file)); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, asm_begin_label); fprintf (asm_out_file, "\n"); } while (0);
}



static void
body_end_attribute(register char *asm_end_label) asm("_body_end_attribute");
static void
body_end_attribute(register char *asm_end_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_body_end); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_body_end)); fputc ('\n', (asm_out_file)); } while (0);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, asm_end_label); fprintf (asm_out_file, "\n"); } while (0);
}




static void
language_attribute(register unsigned int language_code) asm("_language_attribute");
static void
language_attribute(register unsigned int language_code)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_language); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_language)); fputc ('\n', (asm_out_file)); } while (0);
  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) language_code);
}

static void
member_attribute(register tree context) asm("_member_attribute");
static void
member_attribute(register tree context)
{
  char label[30];



  if (context != 
                ((void *)0) 
                     && is_tagged_type (context))
    {
      do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_member); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_member)); fputc ('\n', (asm_out_file)); } while (0);
      sprintf (label, ".L_T%u", ((context)->type.uid));
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
    }
}

static void
string_length_attribute(register tree upper_bound) asm("_string_length_attribute");
static void
string_length_attribute(register tree upper_bound)
{
  char begin_label[30];
  char end_label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_string_length); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_string_length)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (begin_label, ".L_sl%u", current_dienum);
  sprintf (end_label, ".L_sl%u_e", current_dienum);
  do { fprintf ((asm_out_file), "\t%s\t", ".2byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);
  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);
  output_bound_representation (upper_bound, 0, 'u');
  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}

static void
comp_dir_attribute(register char *dirname) asm("_comp_dir_attribute");
static void
comp_dir_attribute(register char *dirname)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_comp_dir); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_comp_dir)); fputc ('\n', (asm_out_file)); } while (0);
  do { register unsigned char *_ascii_bytes = (unsigned char *) (dirname); register unsigned char *limit = _ascii_bytes + (strlen (dirname)+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
}

static void
sf_names_attribute(register char *sf_names_start_label) asm("_sf_names_attribute");
static void
sf_names_attribute(register char *sf_names_start_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_sf_names); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_sf_names)); fputc ('\n', (asm_out_file)); } while (0);

  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, sf_names_start_label); fprintf (asm_out_file, "\n"); } while (0);
}

static void
src_info_attribute(register char *src_info_start_label) asm("_src_info_attribute");
static void
src_info_attribute(register char *src_info_start_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_src_info); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_src_info)); fputc ('\n', (asm_out_file)); } while (0);

  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, src_info_start_label); fprintf (asm_out_file, "\n"); } while (0);
}

static void
mac_info_attribute(register char *mac_info_start_label) asm("_mac_info_attribute");
static void
mac_info_attribute(register char *mac_info_start_label)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_mac_info); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_mac_info)); fputc ('\n', (asm_out_file)); } while (0);

  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, mac_info_start_label); fprintf (asm_out_file, "\n"); } while (0);
}

static void
prototyped_attribute(register tree func_type) asm("_prototyped_attribute");
static void
prototyped_attribute(register tree func_type)
{
  if ((strcmp (language_string, "GNU C") == 0)
      && (((func_type)->type.values) != 
                                       ((void *)0)
                                           ))
    {
      do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_prototyped); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_prototyped)); fputc ('\n', (asm_out_file)); } while (0);
      do { register unsigned char *_ascii_bytes = (unsigned char *) (""); register unsigned char *limit = _ascii_bytes + (strlen ("")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
    }
}

static void
producer_attribute(register char *producer) asm("_producer_attribute");
static void
producer_attribute(register char *producer)
{
  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_producer); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_producer)); fputc ('\n', (asm_out_file)); } while (0);
  do { register unsigned char *_ascii_bytes = (unsigned char *) (producer); register unsigned char *limit = _ascii_bytes + (strlen (producer)+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
}

static void
inline_attribute(register tree decl) asm("_inline_attribute");
static void
inline_attribute(register tree decl)
{
  if (((decl)->decl.inline_flag))
    {
      do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_inline); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_inline)); fputc ('\n', (asm_out_file)); } while (0);
      do { register unsigned char *_ascii_bytes = (unsigned char *) (""); register unsigned char *limit = _ascii_bytes + (strlen ("")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
    }
}

static void
containing_type_attribute(register tree containing_type) asm("_containing_type_attribute");
static void
containing_type_attribute(register tree containing_type)
{
  char label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_containing_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_containing_type)); fputc ('\n', (asm_out_file)); } while (0);
  sprintf (label, ".L_T%u", ((containing_type)->type.uid));
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
}

static void
abstract_origin_attribute(register tree origin) asm("_abstract_origin_attribute");
static void
abstract_origin_attribute(register tree origin)
{
  char label[30];

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_abstract_origin); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_abstract_origin)); fputc ('\n', (asm_out_file)); } while (0);
  switch ((*tree_code_type[(int) (((n64_enum_tree_code) (origin)->common.code))]))
    {
    case 'd':
      sprintf (label, ".L_E%u", ((origin)->decl.uid));
      break;

    case 't':
      sprintf (label, ".L_T%u", ((origin)->type.uid));
      break;

    default:
      abort ();

    }
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
}
static void
pure_or_virtual_attribute(register tree func_decl) asm("_pure_or_virtual_attribute");
static void
pure_or_virtual_attribute(register tree func_decl)
{
  if (((func_decl)->decl.virtual_flag))
    {





        do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) AT_virtual); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_attr_name (AT_virtual)); fputc ('\n', (asm_out_file)); } while (0);
      do { register unsigned char *_ascii_bytes = (unsigned char *) (""); register unsigned char *limit = _ascii_bytes + (strlen ("")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
    }
}
static void
name_and_src_coords_attributes(register tree decl) asm("_name_and_src_coords_attributes");
static void
name_and_src_coords_attributes(register tree decl)
{
  register tree decl_name = ((decl)->decl.name);

  if (decl_name && ((decl_name)->identifier.pointer))
    {
      name_attribute (((decl_name)->identifier.pointer));
    }
}




static void
type_attribute(register tree type, register int decl_const, register int decl_volatile) asm("_type_attribute");
static void
type_attribute(register tree type, register int decl_const, register int decl_volatile)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  register int root_type_modified;

  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return;





  if (((n64_enum_tree_code) (type)->common.code) == VOID_TYPE)
    return;

  root_type_modified = (code == POINTER_TYPE || code == REFERENCE_TYPE
   || decl_const || decl_volatile
   || ((type)->common.readonly_flag) || ((type)->common.volatile_flag));

  if (type_is_fundamental (root_type (type)))
    if (root_type_modified)
 mod_fund_type_attribute (type, decl_const, decl_volatile);
    else
 fund_type_attribute (fundamental_type_code (type));
  else
    if (root_type_modified)
 mod_u_d_type_attribute (type, decl_const, decl_volatile);
    else
 user_def_type_attribute (type_main_variant (type));
}





static char *
type_tag(register tree type) asm("_type_tag");
static char *
type_tag(register tree type)
{
  register char *name = 0;

  if (((type)->type.name) != 0)
    {
      register tree t = 0;


      if (((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE)
 t = ((type)->type.name);
      if (t != 0)
 name = ((t)->identifier.pointer);
    }

  return (name == 0 || *name == '\0') ? 0 : name;
}

static void
dienum_push(void) asm("_dienum_push");
static void
dienum_push(void)
{



  if (pending_siblings == pending_siblings_allocated)
    {
      pending_siblings_allocated += 64;
      pending_sibling_stack
 = (unsigned *) xrealloc (pending_sibling_stack,
     pending_siblings_allocated * sizeof(unsigned));
    }

  pending_siblings++;
  pending_sibling_stack[pending_siblings-1] = next_unused_dienum++;
}




static void
dienum_pop(void) asm("_dienum_pop");
static void
dienum_pop(void)
{
  pending_siblings--;
}

static tree
member_declared_type(register tree member) asm("_member_declared_type");
static tree
member_declared_type(register tree member)
{
  return (((member)->decl.result))
    ? ((member)->decl.result)
    : ((member)->common.type);
}





static char *
function_start_label(register tree decl) asm("_function_start_label");
static char *
function_start_label(register tree decl)
{
  rtx x;
  char *fnname;

  x = ((decl)->decl.rtl);
  if (((x)->code) != MEM)
    abort ();
  x = ((x)->fld[0].rtx);
  if (((x)->code) != SYMBOL_REF)
        abort ();
  fnname = ((x)->fld[0].rtstr);
  return fnname;
}
static void
output_array_type_die(register void *arg) asm("_output_array_type_die");
static void
output_array_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_array_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_array_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  member_attribute (((type)->type.context));
  subscript_data_attribute (type);
}

static void
output_set_type_die(register void *arg) asm("_output_set_type_die");
static void
output_set_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_set_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_set_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  member_attribute (((type)->type.context));
  type_attribute (((type)->common.type), 0, 0);
}
static void
output_inlined_enumeration_type_die(register void *arg) asm("_output_inlined_enumeration_type_die");
static void
output_inlined_enumeration_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_enumeration_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_enumeration_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();

  abstract_origin_attribute (type);
}



static void
output_inlined_structure_type_die(register void *arg) asm("_output_inlined_structure_type_die");
static void
output_inlined_structure_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_structure_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_structure_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();

  abstract_origin_attribute (type);
}



static void
output_inlined_union_type_die(register void *arg) asm("_output_inlined_union_type_die");
static void
output_inlined_union_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_union_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_union_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();

  abstract_origin_attribute (type);
}





static void
output_enumeration_type_die(register void *arg) asm("_output_enumeration_type_die");
static void
output_enumeration_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_enumeration_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_enumeration_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  name_attribute (type_tag (type));
  member_attribute (((type)->type.context));





  if (((type)->type.size))
    {
      byte_size_attribute (type);
      element_list_attribute (((type)->type.values));
    }
}
static void
output_formal_parameter_die(register void *arg) asm("_output_formal_parameter_die");
static void
output_formal_parameter_die(register void *arg)
{
  register tree node = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_formal_parameter); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_formal_parameter)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();

  switch ((*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]))
    {
    case 'd':
      {
 register tree origin = decl_ultimate_origin (node);

 if (origin != 
              ((void *)0)
                  )
   abstract_origin_attribute (origin);
 else
   {
     name_and_src_coords_attributes (node);
     type_attribute (((node)->common.type),
       ((node)->common.readonly_flag), ((node)->common.volatile_flag));
   }
 if (((node)->decl.abstract_flag))
   equate_decl_number_to_die_number (node);
 else
   location_or_const_value_attribute (node);
      }
      break;

    case 't':
      type_attribute (node, 0, 0);
      break;

    default:
      abort ();
    }
}




static void
output_global_subroutine_die(register void *arg) asm("_output_global_subroutine_die");
static void
output_global_subroutine_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_global_subroutine); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_global_subroutine)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    {
      register tree type = ((decl)->common.type);

      name_and_src_coords_attributes (decl);
      inline_attribute (decl);
      prototyped_attribute (type);
      member_attribute (((decl)->decl.context));
      type_attribute (((type)->common.type), 0, 0);
      pure_or_virtual_attribute (decl);
    }
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
  else
    {
      if (! ((decl)->decl.external_flag))
 {
   char label[30];

   low_pc_attribute (function_start_label (decl));
   sprintf (label, ".L_f%u_e", current_funcdef_number);
   high_pc_attribute (label);
   sprintf (label, ".L_b%u", current_funcdef_number);
   body_begin_attribute (label);
   sprintf (label, ".L_b%u_e", current_funcdef_number);
   body_end_attribute (label);
 }
    }
}




static void
output_global_variable_die(register void *arg) asm("_output_global_variable_die");
static void
output_global_variable_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_global_variable); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_global_variable)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    {
      name_and_src_coords_attributes (decl);
      member_attribute (((decl)->decl.context));
      type_attribute (((decl)->common.type),
        ((decl)->common.readonly_flag), ((decl)->common.volatile_flag));
    }
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
  else
    {
      if (!((decl)->decl.external_flag))
 location_or_const_value_attribute (decl);
    }
}

static void
output_label_die(register void *arg) asm("_output_label_die");
static void
output_label_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_label); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_label)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    name_and_src_coords_attributes (decl);
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
  else
    {
      register rtx insn = ((decl)->decl.rtl);

      if (((insn)->code) == CODE_LABEL)
 {
   char label[30];







   if (((insn)->volatil))
     abort ();

   sprintf (label, ".L_I%u_%u", current_funcdef_number,
              (unsigned) ((insn)->fld[0].rtint));
   low_pc_attribute (label);
 }
    }
}

static void
output_lexical_block_die(register void *arg) asm("_output_lexical_block_die");
static void
output_lexical_block_die(register void *arg)
{
  register tree stmt = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_lexical_block); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_lexical_block)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  if (! ((stmt)->block.abstract_flag))
    {
      char begin_label[30];
      char end_label[30];

      sprintf (begin_label, ".L_B%u", next_block_number);
      low_pc_attribute (begin_label);
      sprintf (end_label, ".L_B%u_e", next_block_number);
      high_pc_attribute (end_label);
    }
}

static void
output_inlined_subroutine_die(register void *arg) asm("_output_inlined_subroutine_die");
static void
output_inlined_subroutine_die(register void *arg)
{
  register tree stmt = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_inlined_subroutine); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_inlined_subroutine)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  abstract_origin_attribute (block_ultimate_origin (stmt));
  if (! ((stmt)->block.abstract_flag))
    {
      char begin_label[30];
      char end_label[30];

      sprintf (begin_label, ".L_B%u", next_block_number);
      low_pc_attribute (begin_label);
      sprintf (end_label, ".L_B%u_e", next_block_number);
      high_pc_attribute (end_label);
    }
}




static void
output_local_variable_die(register void *arg) asm("_output_local_variable_die");
static void
output_local_variable_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_local_variable); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_local_variable)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    {
      name_and_src_coords_attributes (decl);
      member_attribute (((decl)->decl.context));
      type_attribute (((decl)->common.type),
        ((decl)->common.readonly_flag), ((decl)->common.volatile_flag));
    }
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
  else
    location_or_const_value_attribute (decl);
}

static void
output_member_die(register void *arg) asm("_output_member_die");
static void
output_member_die(register void *arg)
{
  register tree decl = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_member); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_member)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  name_and_src_coords_attributes (decl);
  member_attribute (((decl)->decl.context));
  type_attribute (member_declared_type (decl),
    ((decl)->common.readonly_flag), ((decl)->common.volatile_flag));
  if (((decl)->decl.result))
    {
      byte_size_attribute (decl);
      bit_size_attribute (decl);
      bit_offset_attribute (decl);
    }
  data_member_location_attribute (decl);
}
static void
output_ptr_to_mbr_type_die(register void *arg) asm("_output_ptr_to_mbr_type_die");
static void
output_ptr_to_mbr_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_ptr_to_member_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_ptr_to_member_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  member_attribute (((type)->type.context));
  containing_type_attribute (((type)->type.maxval));
  type_attribute (((type)->common.type), 0, 0);
}

static void
output_compile_unit_die(register void *arg) asm("_output_compile_unit_die");
static void
output_compile_unit_die(register void *arg)
{
  register char *main_input_filename = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_compile_unit); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_compile_unit)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  name_attribute (main_input_filename);

  {
    char producer[250];

    sprintf (producer, "%s %s", language_string, version_string);
    producer_attribute (producer);
  }

  if (strcmp (language_string, "GNU C++") == 0)
    language_attribute (LANG_C_PLUS_PLUS);
  else if (strcmp (language_string, "GNU Ada") == 0)
    language_attribute (LANG_ADA83);
  else if (strcmp (language_string, "GNU F77") == 0)
    language_attribute (LANG_FORTRAN77);
  else if (flag_traditional)
    language_attribute (LANG_C);
  else
    language_attribute (LANG_C89);
  low_pc_attribute (".L_text_b");
  high_pc_attribute (".L_text_e");
  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    stmt_list_attribute (".L_line_b");
  last_filename = xstrdup (main_input_filename);

  {
    char *wd = getpwd ();
    if (wd)
      comp_dir_attribute (wd);
  }

  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    {
      sf_names_attribute (".L_sfnames_b");
      src_info_attribute (".L_srcinfo_b");
      if (debug_info_level >= DINFO_LEVEL_VERBOSE)
        mac_info_attribute (".L_macinfo_b");
    }
}

static void
output_string_type_die(register void *arg) asm("_output_string_type_die");
static void
output_string_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_string_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_string_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  member_attribute (((type)->type.context));



  string_length_attribute (((((type)->type.values))->type.maxval));
}

static void
output_structure_type_die(register void *arg) asm("_output_structure_type_die");
static void
output_structure_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_structure_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_structure_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  name_attribute (type_tag (type));
  member_attribute (((type)->type.context));







  if (((type)->type.size))
    {
      dienum_push ();
      byte_size_attribute (type);
    }
}




static void
output_local_subroutine_die(register void *arg) asm("_output_local_subroutine_die");
static void
output_local_subroutine_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_subroutine); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_subroutine)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    {
      register tree type = ((decl)->common.type);

      name_and_src_coords_attributes (decl);
      inline_attribute (decl);
      prototyped_attribute (type);
      member_attribute (((decl)->decl.context));
      type_attribute (((type)->common.type), 0, 0);
      pure_or_virtual_attribute (decl);
    }
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
  else
    {



      if (((decl)->common.asm_written_flag))
 {
   char label[30];
   low_pc_attribute (function_start_label (decl));
   sprintf (label, ".L_f%u_e", current_funcdef_number);
   high_pc_attribute (label);
   sprintf (label, ".L_b%u", current_funcdef_number);
   body_begin_attribute (label);
   sprintf (label, ".L_b%u_e", current_funcdef_number);
   body_end_attribute (label);
 }
    }
}

static void
output_subroutine_type_die(register void *arg) asm("_output_subroutine_type_die");
static void
output_subroutine_type_die(register void *arg)
{
  register tree type = arg;
  register tree return_type = ((type)->common.type);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_subroutine_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_subroutine_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  dienum_push ();
  equate_type_number_to_die_number (type);
  prototyped_attribute (type);
  member_attribute (((type)->type.context));
  type_attribute (return_type, 0, 0);
}

static void
output_typedef_die(register void *arg) asm("_output_typedef_die");
static void
output_typedef_die(register void *arg)
{
  register tree decl = arg;
  register tree origin = decl_ultimate_origin (decl);

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_typedef); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_typedef)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  if (origin != 
               ((void *)0)
                   )
    abstract_origin_attribute (origin);
  else
    {
      name_and_src_coords_attributes (decl);
      member_attribute (((decl)->decl.context));
      type_attribute (((decl)->common.type),
        ((decl)->common.readonly_flag), ((decl)->common.volatile_flag));
    }
  if (((decl)->decl.abstract_flag))
    equate_decl_number_to_die_number (decl);
}

static void
output_union_type_die(register void *arg) asm("_output_union_type_die");
static void
output_union_type_die(register void *arg)
{
  register tree type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_union_type); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_union_type)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  equate_type_number_to_die_number (type);
  name_attribute (type_tag (type));
  member_attribute (((type)->type.context));







  if (((type)->type.size))
    {
      dienum_push ();
      byte_size_attribute (type);
    }
}




static void
output_unspecified_parameters_die(register void *arg) asm("_output_unspecified_parameters_die");
static void
output_unspecified_parameters_die(register void *arg)
{
  register tree decl_or_type = arg;

  do { fprintf ((asm_out_file), "\t%s\t0x%x", ".2byte", (unsigned) TAG_unspecified_parameters); if (flag_verbose_asm) fprintf ((asm_out_file), "\t%s %s", "\t\t# ", dwarf_tag_name (TAG_unspecified_parameters)); fputc ('\n', (asm_out_file)); } while (0);
  sibling_attribute ();
  if (((n64_enum_tree_code) (decl_or_type)->common.code) == FUNCTION_DECL && ((decl_or_type)->decl.initial))
    {
      name_attribute ("...");
      fund_type_attribute (FT_pointer);

    }
}

static void
output_padded_null_die(register void *arg) asm("_output_padded_null_die");
static void
output_padded_null_die(register void *arg)
{
  { int mask = (1 << (2)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (2)); };
}
static void
output_die(register void (*die_specific_output_function) (...), register void *param) asm("_output_die");
static void
output_die(register void (*die_specific_output_function) (...), register void *param)
{
  char begin_label[30];
  char end_label[30];

  current_dienum = pending_sibling_stack[pending_siblings-1];
  pending_sibling_stack[pending_siblings-1] = next_unused_dienum;

  sprintf (begin_label, ".L_D%u", current_dienum);
  sprintf (end_label, ".L_D%u_e", current_dienum);



  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);



  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, end_label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, begin_label); fprintf (asm_out_file, "\n"); } while (0);



  next_unused_dienum++;
  die_specific_output_function (param);



  do { assemble_name (asm_out_file, end_label); fputs (":\n", asm_out_file); } while (0);
}

static void
end_sibling_chain(void) asm("_end_sibling_chain");
static void
end_sibling_chain(void)
{
  char begin_label[30];

  current_dienum = pending_sibling_stack[pending_siblings-1];
  pending_sibling_stack[pending_siblings-1] = next_unused_dienum;

  sprintf (begin_label, ".L_D%u", current_dienum);



  do { assemble_name (asm_out_file, begin_label); fputs (":\n", asm_out_file); } while (0);



  fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 4);

  dienum_pop ();
}
static void
output_formal_types(register tree function_or_method_type) asm("_output_formal_types");
static void
output_formal_types(register tree function_or_method_type)
{
  register tree link;
  register tree formal_type = 
                             ((void *)0)
                                 ;
  register tree first_parm_type = ((function_or_method_type)->type.values);
  if (((n64_enum_tree_code) (function_or_method_type)->common.code) == METHOD_TYPE)
    first_parm_type = ((first_parm_type)->common.chain);




  for (link = first_parm_type; link; link = ((link)->common.chain))
    {
      formal_type = ((link)->list.value);
      if (formal_type == void_type_node)
 break;



      output_die (output_formal_parameter_die, formal_type);
    }




  if (formal_type != void_type_node)
    output_die (output_unspecified_parameters_die, function_or_method_type);




  for (link = ((function_or_method_type)->type.values);
       link;
       link = ((link)->common.chain))
    {
      formal_type = ((link)->list.value);
      if (formal_type == void_type_node)
 break;

      output_type (formal_type, function_or_method_type);
    }
}



static void
pend_type(register tree type) asm("_pend_type");
static void
pend_type(register tree type)
{
  if (pending_types == pending_types_allocated)
    {
      pending_types_allocated += 64;
      pending_types_list
 = (tree *) xrealloc (pending_types_list,
        sizeof (tree) * pending_types_allocated);
    }
  pending_types_list[pending_types++] = type;





  ((type)->common.asm_written_flag) = 1;
}
static int
type_ok_for_scope(register tree type, register tree scope) asm("_type_ok_for_scope");
static int
type_ok_for_scope(register tree type, register tree scope)
{
  return is_tagged_type (type)
  ? (((type)->type.context) == scope)
  : (scope == (tree) 
             ((void *)0) 
                       || ! is_tagged_type (scope));
}
static void
output_pending_types_for_scope(register tree containing_scope) asm("_output_pending_types_for_scope");
static void
output_pending_types_for_scope(register tree containing_scope)
{
  register unsigned i;

  for (i = 0; i < pending_types; )
    {
      register tree type = pending_types_list[i];

      if (type_ok_for_scope (type, containing_scope))
 {
   register tree *mover;
   register tree *limit;

   pending_types--;
   limit = &pending_types_list[pending_types];
   for (mover = &pending_types_list[i]; mover < limit; mover++)
     *mover = *(mover+1);





   ((type)->common.asm_written_flag) = 0;
   output_type (type, containing_scope);




 }
      else
 i++;
    }
}

static void
output_type(register tree type, register tree containing_scope) asm("_output_type");
static void
output_type(register tree type, register tree containing_scope)
{
  if (type == 0 || type == error_mark_node)
    return;





  type = type_main_variant (type);

  if (((type)->common.asm_written_flag))
    return;




  if (! type_ok_for_scope (type, containing_scope))
    {
      pend_type (type);
      return;
    }

  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case ERROR_MARK:
 break;

      case POINTER_TYPE:
      case REFERENCE_TYPE:


 output_type (((type)->common.type), containing_scope);
 break;

      case OFFSET_TYPE:


 output_type (((type)->type.maxval), containing_scope);

 output_type (((type)->common.type), containing_scope);


 output_die (output_ptr_to_mbr_type_die, type);
 break;

      case SET_TYPE:
 output_type (((type)->type.values), containing_scope);
 output_die (output_set_type_die, type);
 break;

      case FILE_TYPE:
 output_type (((type)->common.type), containing_scope);
 abort ();
 break;

      case FUNCTION_TYPE:

 output_type (((type)->common.type), containing_scope);
 output_die (output_subroutine_type_die, type);
 output_formal_types (type);
 end_sibling_chain ();
 break;

      case METHOD_TYPE:

 output_type (((type)->common.type), containing_scope);
 output_die (output_subroutine_type_die, type);
 output_formal_types (type);
 end_sibling_chain ();
 break;

      case ARRAY_TYPE:
 if (((type)->type.string_flag) && ((n64_enum_tree_code) (((type)->common.type))->common.code) == CHAR_TYPE)
   {
     output_type (((type)->common.type), containing_scope);
     output_die (output_string_type_die, type);
   }
 else
   {
     register tree element_type;

     element_type = ((type)->common.type);
     while (((n64_enum_tree_code) (element_type)->common.code) == ARRAY_TYPE)
       element_type = ((element_type)->common.type);

     output_type (element_type, containing_scope);
     output_die (output_array_type_die, type);
   }
 break;

      case ENUMERAL_TYPE:
      case RECORD_TYPE:
      case UNION_TYPE:
      case QUAL_UNION_TYPE:
 if (((type)->type.size) == 0 && ((type)->type.context) == 
                                                    ((void *)0) 
                                                         && !finalizing)
   return;




 ((type)->common.asm_written_flag) = 1;



 switch (((n64_enum_tree_code) (type)->common.code))
   {
   case ENUMERAL_TYPE:
     output_die (output_enumeration_type_die, type);
     return;

   case RECORD_TYPE:
     output_die (output_structure_type_die, type);
     break;

   case UNION_TYPE:
   case QUAL_UNION_TYPE:
     output_die (output_union_type_die, type);
     break;

   default:
     abort ();
   }
 if (((type)->type.size))
   {
     {
       register tree normal_member;



       for (normal_member = ((type)->type.values);
     normal_member;
     normal_member = ((normal_member)->common.chain))
         output_decl (normal_member, type);
     }

     {
       register tree vec_base;



       vec_base = ((type)->type.maxval);
       if (vec_base)
  {
    register tree first_func_member = ((vec_base)->vec.a[0]);
    register tree func_member;







    if (first_func_member == 
                            ((void *)0)
                                )
      first_func_member = ((vec_base)->vec.a[1]);

    for (func_member = first_func_member;
         func_member;
         func_member = ((func_member)->common.chain))
      output_decl (func_member, type);
  }
     }





     output_pending_types_for_scope (type);

     end_sibling_chain ();
   }

 break;

      case VOID_TYPE:
      case INTEGER_TYPE:
      case REAL_TYPE:
      case COMPLEX_TYPE:
      case BOOLEAN_TYPE:
      case CHAR_TYPE:
 break;

      case LANG_TYPE:
 break;

      default:
 abort ();
    }

  ((type)->common.asm_written_flag) = 1;
}

static void
output_tagged_type_instantiation(register tree type) asm("_output_tagged_type_instantiation");
static void
output_tagged_type_instantiation(register tree type)
{
  if (type == 0 || type == error_mark_node)
    return;
  switch (((n64_enum_tree_code) (type)->common.code))
    {
      case ERROR_MARK:
 break;

      case ENUMERAL_TYPE:
 output_die (output_inlined_enumeration_type_die, type);
 break;

      case RECORD_TYPE:
 output_die (output_inlined_structure_type_die, type);
 break;

      case UNION_TYPE:
      case QUAL_UNION_TYPE:
 output_die (output_inlined_union_type_die, type);
 break;

      default:
 abort ();
    }
}




static void
output_block(register tree stmt) asm("_output_block");
static void
output_block(register tree stmt)
{
  register int must_output_die = 0;
  register tree origin;
  register n64_enum_tree_code origin_code;



  if (! stmt || ! ((stmt)->common.used_flag))
    return;







  origin = block_ultimate_origin (stmt);
  origin_code = (origin != 
                          ((void *)0)
                              ) ? ((n64_enum_tree_code) (origin)->common.code) : ERROR_MARK;




  if (origin_code == FUNCTION_DECL)


    must_output_die = 1;
  else
    {
      if (origin == 
                   ((void *)0) 
                        || ! is_body_block (origin))
 {



   if (debug_info_level > DINFO_LEVEL_TERSE)


     must_output_die = (((stmt)->block.vars) != 
                                            ((void *)0)
                                                );
   else
     {
       register tree decl;




       for (decl = ((stmt)->block.vars); decl; decl = ((decl)->common.chain))
  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.initial))
    {
      must_output_die = 1;
      break;
    }
     }
 }
    }
  if (must_output_die)
    {
      output_die ((origin_code == FUNCTION_DECL)
      ? output_inlined_subroutine_die
      : output_lexical_block_die,
    stmt);
      output_decls_for_scope (stmt);
      end_sibling_chain ();
    }
  else
    output_decls_for_scope (stmt);
}




static void
output_decls_for_scope(register tree stmt) asm("_output_decls_for_scope");
static void
output_decls_for_scope(register tree stmt)
{


  if (! stmt || ! ((stmt)->common.used_flag))
    return;

  if (! ((stmt)->block.abstract_flag))
    next_block_number++;





  {
    register tree decl;

    for (decl = ((stmt)->block.vars); decl; decl = ((decl)->common.chain))
      output_decl (decl, stmt);
  }

  output_pending_types_for_scope (stmt);




  {
    register tree subblocks;

    for (subblocks = ((stmt)->block.subblocks);
         subblocks;
         subblocks = ((subblocks)->common.chain))
      output_block (subblocks);
  }
}



static void
output_decl(register tree decl, register tree containing_scope) asm("_output_decl");
static void
output_decl(register tree decl, register tree containing_scope)
{




  dwarf_last_decl = decl;

  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return;





  if ((((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE
       || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE)
      && ((((decl)->decl.name) == 0 && ((((decl)->common.type))->type.name) == 0)
   || (((((decl)->common.type))->type.values)
       && (((n64_enum_tree_code) (((((decl)->common.type))->type.values))->common.code) == ERROR_MARK))))
    return;







  if (((decl)->decl.ignored_flag) && ((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL)
    return;

  switch (((n64_enum_tree_code) (decl)->common.code))
    {
    case CONST_DECL:


      break;

    case FUNCTION_DECL:





      if (((decl)->decl.initial) == (tree) 
                                ((void *)0)
                                         )



   break;




      output_type (((((decl)->common.type))->common.type), containing_scope);







      if (((decl)->common.public_flag))
 {
   char label[30];

   sprintf (label, ".L_P%u", next_pubname_number++);
   do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
 }



      output_die (((decl)->common.public_flag) || ((decl)->decl.external_flag)
    ? output_global_subroutine_die
    : output_local_subroutine_die,
    decl);
      if (((decl)->decl.initial) == (tree) 
                                ((void *)0)
                                         )
 output_formal_types (((decl)->common.type));
      else
 {


   register tree arg_decls = ((decl)->decl.arguments);
   register tree parm;
   for (parm = arg_decls; parm; parm = ((parm)->common.chain))
     if (((n64_enum_tree_code) (parm)->common.code) == PARM_DECL)
              {
  if (((parm)->decl.name) &&
      !strcmp(((((parm)->decl.name))->identifier.pointer),
       "__builtin_va_alist") )
    output_die (output_unspecified_parameters_die, decl);
         else
    output_decl (parm, fake_containing_scope);
       }
   output_pending_types_for_scope (decl);
   {
     register tree fn_arg_types = ((((decl)->common.type))->type.values);

     if (fn_arg_types)
       {

       if (((tree_last (fn_arg_types))->list.value) != void_type_node)
         output_die (output_unspecified_parameters_die, decl);
              }
            else
              {

              if (!((decl)->decl.initial))
                output_die (output_unspecified_parameters_die, decl);
              }
   }
 }




      {
 register tree outer_scope = ((decl)->decl.initial);

 if (outer_scope && ((n64_enum_tree_code) (outer_scope)->common.code) != ERROR_MARK)
   {
     {
       register tree label;

       for (label = ((outer_scope)->block.vars);
     label;
     label = ((label)->common.chain))
  output_decl (label, outer_scope);
     }






     output_decls_for_scope (((outer_scope)->block.subblocks));






     output_pending_types_for_scope (decl);
   }
      }




      end_sibling_chain ();

      break;

    case TYPE_DECL:






      if (debug_info_level <= DINFO_LEVEL_TERSE)
 if (((decl)->decl.name) != 
                        ((void *)0)
     
    || ! (((((decl)->common.type))->type.size) == 0))
          return;
      if (! ((decl)->decl.name) && ((decl)->decl.abstract_origin))
 {
   output_tagged_type_instantiation (((decl)->common.type));
   return;
 }

      output_type (((decl)->common.type), containing_scope);
      if (((decl)->decl.name))

 output_die (output_typedef_die, decl);
      break;

    case LABEL_DECL:
      if (debug_info_level >= DINFO_LEVEL_NORMAL)
 output_die (output_label_die, decl);
      break;

    case VAR_DECL:




      if (((decl)->decl.external_flag) && ! ((decl)->common.public_flag))
 break;





      if (debug_info_level <= DINFO_LEVEL_TERSE)
        break;




      output_type (((decl)->common.type), containing_scope);







      if (((decl)->common.public_flag) && ! ((decl)->decl.abstract_flag))
 {
   char label[30];

   sprintf (label, ".L_P%u", next_pubname_number++);
   do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
 }






      {
        register void (*func)(...);
 register tree origin = decl_ultimate_origin (decl);

 if (origin != 
              ((void *)0) 
                   && ((n64_enum_tree_code) (origin)->common.code) == PARM_DECL)
   func = output_formal_parameter_die;
 else
   {
     if (((decl)->common.public_flag) || ((decl)->decl.external_flag))
       func = output_global_variable_die;
     else
       func = output_local_variable_die;
   }
 output_die (func, decl);
      }
      break;

    case FIELD_DECL:

      if (((decl)->decl.name) != 0)
 {
   output_type (member_declared_type (decl), containing_scope);
          output_die (output_member_die, decl);
 }
      break;

    case PARM_DECL:





      output_type (((decl)->common.type), containing_scope);
      output_die (output_formal_parameter_die, decl);
      break;

    default:
      abort ();
    }
}

void
dwarfout_file_scope_decl(register tree decl, register int set_finalizing) asm("_dwarfout_file_scope_decl");
void
dwarfout_file_scope_decl(register tree decl, register int set_finalizing)
{
  if (((n64_enum_tree_code) (decl)->common.code) == ERROR_MARK)
    return;
  if (((decl)->decl.ignored_flag))
    {
      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.initial) != 
                                                                     ((void *)0)
                                                                         )
 abort ();
      return;
    }

  switch (((n64_enum_tree_code) (decl)->common.code))
    {
    case FUNCTION_DECL:





      if (((decl)->decl.external_flag) && ((decl)->decl.frame_size.f))
        return;
      if (((decl)->decl.initial) == (tree) 
                                ((void *)0)
                                         )
 return;

      if (((decl)->common.public_flag)
   && ! ((decl)->decl.external_flag)
   && ! ((decl)->decl.abstract_flag))
 {
   char label[30];




   fputc ('\n', asm_out_file);
   fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_pubnames");
   sprintf (label, ".L_P%u", next_pubname_number);
   do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
   do { register unsigned char *_ascii_bytes = (unsigned char *) (((((decl)->decl.name))->identifier.pointer)); register unsigned char *limit = _ascii_bytes + (strlen (((((decl)->decl.name))->identifier.pointer))+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0)
                                             ;
   fprintf ((asm_out_file), "\t%s\n", ".previous");
 }

      break;

    case VAR_DECL:
      if (((decl)->decl.external_flag) && !((decl)->common.used_flag))
 return;

      if (((decl)->common.public_flag)
   && ! ((decl)->decl.external_flag)
   && ((((decl)->decl.rtl))->code) == MEM
   && ! ((decl)->decl.abstract_flag))
 {
   char label[30];

   if (debug_info_level >= DINFO_LEVEL_NORMAL)
     {



       fputc ('\n', asm_out_file);
       fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_pubnames");
       sprintf (label, ".L_P%u", next_pubname_number);
       do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "\n"); } while (0);
       do { register unsigned char *_ascii_bytes = (unsigned char *) (((((decl)->decl.name))->identifier.pointer)); register unsigned char *limit = _ascii_bytes + (strlen (((((decl)->decl.name))->identifier.pointer))+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0)
                                                 ;
       fprintf ((asm_out_file), "\t%s\n", ".previous");
     }

   if (((decl)->decl.initial) == 
                             ((void *)0)
                                 )
     {



       fputc ('\n', asm_out_file);
       fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_aranges");
       do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ((((decl)->decl.assembler_name))->identifier.pointer)); fprintf (asm_out_file, "\n"); } while (0)
                                                         ;
       fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) (unsigned) int_size_in_bytes (((decl)->common.type)))
                                                   ;
       fprintf ((asm_out_file), "\t%s\n", ".previous");
     }
 }




      if (debug_info_level <= DINFO_LEVEL_TERSE)
        return;

      break;

    case TYPE_DECL:
      if (((decl)->decl.linenum) == 0
   && type_is_fundamental (((decl)->common.type)))
 return;







      if (debug_info_level <= DINFO_LEVEL_TERSE)
 if (((decl)->decl.name) != 
                        ((void *)0)
     
    || ! (((((decl)->common.type))->type.size) == 0))
          return;

      break;

    default:
      return;
    }

  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug");
  finalizing = set_finalizing;
  output_decl (decl, (tree) 
                    ((void *)0)
                             );
  output_pending_types_for_scope ((tree) 
                                 ((void *)0)
                                          );





  fprintf ((asm_out_file), "\t%s\n", ".previous");

  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.initial) != 
                                                                 ((void *)0)
                                                                     )
    current_funcdef_number++;
}




void
dwarfout_begin_block(register unsigned int blocknum) asm("_dwarfout_begin_block");
void
dwarfout_begin_block(register unsigned int blocknum)
{
  char label[30];

  function_section (current_function_decl);
  sprintf (label, ".L_B%u", blocknum);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
}




void
dwarfout_end_block(register unsigned int blocknum) asm("_dwarfout_end_block");
void
dwarfout_end_block(register unsigned int blocknum)
{
  char label[30];

  function_section (current_function_decl);
  sprintf (label, ".L_B%u_e", blocknum);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
}




void
dwarfout_label(register rtx insn) asm("_dwarfout_label");
void
dwarfout_label(register rtx insn)
{
  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    {
      char label[30];

      function_section (current_function_decl);
      sprintf (label, ".L_I%u_%u", current_funcdef_number,
          (unsigned) ((insn)->fld[0].rtint));
      do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
    }
}





void
dwarfout_begin_function(void) asm("_dwarfout_begin_function");
void
dwarfout_begin_function(void)
{
  char label[30];

  function_section (current_function_decl);
  sprintf (label, ".L_b%u", current_funcdef_number);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
}




void
dwarfout_end_function(void) asm("_dwarfout_end_function");
void
dwarfout_end_function(void)
{
  char label[30];

  function_section (current_function_decl);
  sprintf (label, ".L_b%u_e", current_funcdef_number);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
}





void
dwarfout_end_epilogue(void) asm("_dwarfout_end_epilogue");
void
dwarfout_end_epilogue(void)
{
  char label[30];




  sprintf (label, ".L_f%u_e", current_funcdef_number);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
}

static void
shuffle_filename_entry(register filename_entry *new_zeroth) asm("_shuffle_filename_entry");
static void
shuffle_filename_entry(register filename_entry *new_zeroth)
{
  filename_entry temp_entry;
  register filename_entry *limit_p;
  register filename_entry *move_p;

  if (new_zeroth == &filename_table[0])
    return;

  temp_entry = *new_zeroth;



  limit_p = &filename_table[0];
  for (move_p = new_zeroth; move_p > limit_p; move_p--)
    *move_p = *(move_p-1);



  filename_table[0] = temp_entry;
}



static void
generate_new_sfname_entry(void) asm("_generate_new_sfname_entry");
static void
generate_new_sfname_entry(void)
{
  char label[30];

  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_sfnames");
  sprintf (label, ".L_F%u", filename_table[0].number);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
  do { register unsigned char *_ascii_bytes = (unsigned char *) (filename_table[0].name ? filename_table[0].name : ""); register unsigned char *limit = _ascii_bytes + (strlen (filename_table[0].name ? filename_table[0].name : "")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0)


             ;
  fprintf ((asm_out_file), "\t%s\n", ".previous");
}
static unsigned
lookup_filename(char *file_name) asm("_lookup_filename");
static unsigned
lookup_filename(char *file_name)
{
  register filename_entry *search_p;
  register filename_entry *limit_p = &filename_table[ft_entries];

  for (search_p = filename_table; search_p < limit_p; search_p++)
    if (!strcmp (file_name, search_p->name))
      {






 shuffle_filename_entry (search_p);
        return filename_table[0].number;
      }







  if (ft_entries == ft_entries_allocated)
    {
      ft_entries_allocated += 64;
      filename_table
 = (filename_entry *)
   xrealloc (filename_table,
      ft_entries_allocated * sizeof (filename_entry));
    }



  filename_table[ft_entries].number = ft_entries;
  filename_table[ft_entries].name = xstrdup (file_name);



  shuffle_filename_entry (&filename_table[ft_entries]);

  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    generate_new_sfname_entry ();

  ft_entries++;
  return filename_table[0].number;
}

static void
generate_srcinfo_entry(unsigned int line_entry_num, unsigned int files_entry_num) asm("_generate_srcinfo_entry");
static void
generate_srcinfo_entry(unsigned int line_entry_num, unsigned int files_entry_num)
{
  char label[30];

  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_srcinfo");
  sprintf (label, ".L_LE%u", line_entry_num);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_line_b"); fprintf (asm_out_file, "\n"); } while (0);
  sprintf (label, ".L_F%u", files_entry_num);
  do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_sfnames_b"); fprintf (asm_out_file, "\n"); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
}

void
dwarfout_line(register char *filename, register unsigned int line) asm("_dwarfout_line");
void
dwarfout_line(register char *filename, register unsigned int line)
{
  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    {
      char label[30];
      static unsigned last_line_entry_num = 0;
      static unsigned prev_file_entry_num = (unsigned) -1;
      register unsigned this_file_entry_num = lookup_filename (filename);

      function_section (current_function_decl);
      sprintf (label, ".L_LC%u", ++last_line_entry_num);
      do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);

      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".line");

      if (this_file_entry_num != prev_file_entry_num)
        {
          char line_entry_label[30];

          sprintf (line_entry_label, ".L_LE%u", last_line_entry_num);
          do { assemble_name (asm_out_file, line_entry_label); fputs (":\n", asm_out_file); } while (0);
        }

      {
        register char *tail = strrchr (filename, '/');

        if (tail != 
                   ((void *)0)
                       )
          filename = tail;
      }

      fprintf (asm_out_file, "\t%s\t%u\t%s %s:%u\n",
        ".4byte", line, "\t\t# ",
        filename, line);
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".2byte", (unsigned) 0xffff);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");

      if (this_file_entry_num != prev_file_entry_num)
        generate_srcinfo_entry (last_line_entry_num, this_file_entry_num);
      prev_file_entry_num = this_file_entry_num;
    }
}



static void
generate_macinfo_entry(register char *type_and_offset, register char *string) asm("_generate_macinfo_entry");
static void
generate_macinfo_entry(register char *type_and_offset, register char *string)
{
  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_macinfo");
  fprintf (asm_out_file, "\t%s\t%s\n", ".4byte", type_and_offset);
  do { register unsigned char *_ascii_bytes = (unsigned char *) (string); register unsigned char *limit = _ascii_bytes + (strlen (string)+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
}

void
dwarfout_start_new_source_file(register char *filename) asm("_dwarfout_start_new_source_file");
void
dwarfout_start_new_source_file(register char *filename)
{
  char label[30];
  char type_and_offset[30*3];

  sprintf (label, ".L_F%u", lookup_filename (filename));
  sprintf (type_and_offset, "0x%08x+%s-%s",
    ((unsigned) MACINFO_start << 24), label, ".L_sfnames_b");
  generate_macinfo_entry (type_and_offset, "");
}

void
dwarfout_resume_previous_source_file(register unsigned int lineno) asm("_dwarfout_resume_previous_source_file");
void
dwarfout_resume_previous_source_file(register unsigned int lineno)
{
  char type_and_offset[30*2];

  sprintf (type_and_offset, "0x%08x+%u",
    ((unsigned) MACINFO_resume << 24), lineno);
  generate_macinfo_entry (type_and_offset, "");
}






void
dwarfout_define(register unsigned int lineno, register char *buffer) asm("_dwarfout_define");
void
dwarfout_define(register unsigned int lineno, register char *buffer)
{
  static int initialized = 0;
  char type_and_offset[30*2];

  if (!initialized)
    {
      dwarfout_start_new_source_file (primary_filename);
      initialized = 1;
    }
  sprintf (type_and_offset, "0x%08x+%u",
    ((unsigned) MACINFO_define << 24), lineno);
  generate_macinfo_entry (type_and_offset, buffer);
}






void
dwarfout_undef(register unsigned int lineno, register char *buffer) asm("_dwarfout_undef");
void
dwarfout_undef(register unsigned int lineno, register char *buffer)
{
  char type_and_offset[30*2];

  sprintf (type_and_offset, "0x%08x+%u",
    ((unsigned) MACINFO_undef << 24), lineno);
  generate_macinfo_entry (type_and_offset, buffer);
}



void
dwarfout_init(register FILE *asm_out_file, register char *main_input_filename) asm("_dwarfout_init");
void
dwarfout_init(register FILE *asm_out_file, register char *main_input_filename)
{


  primary_filename = main_input_filename;



  pending_sibling_stack
    = (unsigned *)
 xmalloc (64 * sizeof (unsigned));
  pending_siblings_allocated = 64;
  pending_siblings = 1;



  filename_table
    = (filename_entry *)
 xmalloc (64 * sizeof (filename_entry));
  ft_entries_allocated = 64;
  ft_entries = 0;



  pending_types_list
    = (tree *) xmalloc (64 * sizeof (tree));
  pending_types_allocated = 64;
  pending_types = 0;





  fake_containing_scope = make_node (RECORD_TYPE);



  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".text");
  do { assemble_name (asm_out_file, ".L_text_b"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");



  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".data");
  do { assemble_name (asm_out_file, ".L_data_b"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".rodata");
  do { assemble_name (asm_out_file, ".L_rodata_b"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".bss");
  do { assemble_name (asm_out_file, ".L_bss_b"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");

  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    {




      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_sfnames");
      do { assemble_name (asm_out_file, ".L_sfnames_b"); fputs (":\n", asm_out_file); } while (0);
      {
 register char *pwd;
 register unsigned len;
 register char *dirname;

 pwd = getpwd ();
 if (!pwd)
   pfatal_with_name ("getpwd");
 len = strlen (pwd);
 dirname = (char *) xmalloc (len + 2);

 strcpy (dirname, pwd);
 strcpy (dirname + len, "/");
        do { register unsigned char *_ascii_bytes = (unsigned char *) (dirname); register unsigned char *limit = _ascii_bytes + (strlen (dirname)+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
        free (dirname);
      }
      fprintf ((asm_out_file), "\t%s\n", ".previous");

      if (debug_info_level >= DINFO_LEVEL_VERBOSE)
 {




          fputc ('\n', asm_out_file);
          fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_macinfo");
          do { assemble_name (asm_out_file, ".L_macinfo_b"); fputs (":\n", asm_out_file); } while (0);
          fprintf ((asm_out_file), "\t%s\n", ".previous");
 }



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".line");
      do { assemble_name (asm_out_file, ".L_line_b"); fputs (":\n", asm_out_file); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_line_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_line_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_srcinfo");
      do { assemble_name (asm_out_file, ".L_srcinfo_b"); fputs (":\n", asm_out_file); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_line_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_sfnames_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_e"); fprintf (asm_out_file, "\n"); } while (0);



      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) -1);

      fprintf ((asm_out_file), "\t%s\n", ".previous");



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_pubnames");
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_debug_b"); fprintf (asm_out_file, "\n"); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_aranges");
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_debug_b"); fprintf (asm_out_file, "\n"); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");
    }


  pending_sibling_stack[pending_siblings-1] = next_unused_dienum++;







  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug");
  do { assemble_name (asm_out_file, ".L_debug_b"); fputs (":\n", asm_out_file); } while (0);
  output_die (output_compile_unit_die, main_input_filename);
  fprintf ((asm_out_file), "\t%s\n", ".previous");

  fputc ('\n', asm_out_file);
}



void
dwarfout_finish(void) asm("_dwarfout_finish");
void
dwarfout_finish(void)
{
  char label[30];

  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug");
  output_die (output_padded_null_die, (void *)0);
  dienum_pop ();

  sprintf (label, ".L_D%u", pending_sibling_stack[pending_siblings-1]);
  do { assemble_name (asm_out_file, label); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");



  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".text");
  do { assemble_name (asm_out_file, ".L_text_e"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");



  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".data");
  do { assemble_name (asm_out_file, ".L_data_e"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".rodata");
  do { assemble_name (asm_out_file, ".L_rodata_e"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");
  fputc ('\n', asm_out_file);
  fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".bss");
  do { assemble_name (asm_out_file, ".L_bss_e"); fputs (":\n", asm_out_file); } while (0);
  fprintf ((asm_out_file), "\t%s\n", ".previous");

  if (debug_info_level >= DINFO_LEVEL_NORMAL)
    {


      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".line");
      do { assemble_name (asm_out_file, ".L_line_last"); fputs (":\n", asm_out_file); } while (0);
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".2byte", (unsigned) 0xffff);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { assemble_name (asm_out_file, ".L_line_e"); fputs (":\n", asm_out_file); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_srcinfo");
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_line_last"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_line_b"); fprintf (asm_out_file, "\n"); } while (0)
                                                  ;
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) -1);
      fprintf ((asm_out_file), "\t%s\n", ".previous");

      if (debug_info_level >= DINFO_LEVEL_VERBOSE)
 {


   dwarfout_resume_previous_source_file (0);

   fputc ('\n', asm_out_file);
   fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_macinfo");
   fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);
   do { register unsigned char *_ascii_bytes = (unsigned char *) (""); register unsigned char *limit = _ascii_bytes + (strlen ("")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
   fprintf ((asm_out_file), "\t%s\n", ".previous");
 }



      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_pubnames");
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);
      do { register unsigned char *_ascii_bytes = (unsigned char *) (""); register unsigned char *limit = _ascii_bytes + (strlen ("")+1); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf (((asm_out_file)), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf ((((asm_out_file))), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, (((asm_out_file)))); break; case 1: fprintf ((((asm_out_file))), "\\%03o", ch); break; default: putc ('\\', (((asm_out_file)))); putc (escape, (((asm_out_file)))); break; } } fprintf ((((asm_out_file))), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf (((asm_out_file)), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, ((asm_out_file))); bytes_in_chunk++; break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf (((asm_out_file)), "\"\n"); } while (0);
      fprintf ((asm_out_file), "\t%s\n", ".previous");
      fputc ('\n', asm_out_file);
      fprintf ((asm_out_file), "\t%s\t%s\n", ".section", ".debug_aranges");

      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_text_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_text_b"); fprintf (asm_out_file, "\n"); } while (0);

      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_data_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_data_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_data_b"); fprintf (asm_out_file, "\n"); } while (0);







      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_rodata_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_rodata_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_rodata_b"); fprintf (asm_out_file, "\n"); } while (0)
                             ;







      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_bss_b"); fprintf (asm_out_file, "\n"); } while (0);
      do { fprintf ((asm_out_file), "\t%s\t", ".4byte"); assemble_name (asm_out_file, ".L_bss_e"); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, ".L_bss_b"); fprintf (asm_out_file, "\n"); } while (0);

      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);
      fprintf ((asm_out_file), "\t%s\t0x%x\n", ".4byte", (unsigned) 0);

      fprintf ((asm_out_file), "\t%s\n", ".previous");
    }
}

