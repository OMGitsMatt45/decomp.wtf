// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/gcc.c
/* Compiler driver program that can handle many languages.
   Copyright (C) 1987, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

This paragraph is here to try to keep Sun CC from dying.
The number of chars here seems crucial!!!!  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>
#include <signal.h>
#include <sys/stat.h>
#include <errno.h>
#include <process.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__obstack_chunk;
struct n64_tag_command;
struct n64_tag_compiler;
struct n64_tag_infile;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_option_map;
struct n64_tag_path_prefix;
struct n64_tag_prefix_list;
struct n64_tag_spec_list;
struct n64_tag_switchstr;
struct n64_tag_temp_file;
struct n64_tag_temp_name;







extern int windows_spawnv(...) asm("_windows_spawnv");
extern int windows_spawnvp(...) asm("_windows_spawnvp");



extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");







static char dir_separator_str[] = {'\\', 0};




extern void free(...) asm("_free");
extern char *getenv(...) asm("_getenv");






extern int 
          _sys_nerr
                  ;
extern char *strerror(...) asm("_strerror");


extern int execv (...) asm("_execv"), execvp (...) asm("_execvp");
static int print_search_dirs;




static char *print_file_name = 
                              ((void *)0)
                                  ;



static char *print_prog_name = 
                              ((void *)0)
                                  ;




static int print_multi_directory;




static int print_multi_lib;



static int verbose_flag;




static int save_temps_flag;



static char *compiler_version;



static char *spec_version = "2.7.2";



static char *spec_machine = "mips-mips-gnu";





static int cross_compile = 1;






static int error_count = 0;



static struct n64_tag_obstack obstack;






static struct n64_tag_obstack collect_obstack;

extern char *version_string;


struct n64_tag_path_prefix;

static void set_spec (char *, char *) asm("_set_spec");
static struct n64_tag_compiler *lookup_compiler (char *, int, char *) asm("_lookup_compiler");
static char *build_search_list (struct n64_tag_path_prefix *, char *, int) asm("_build_search_list");
static void putenv_from_prefixes (struct n64_tag_path_prefix *, char *) asm("_putenv_from_prefixes");
static char *find_a_file (struct n64_tag_path_prefix *, char *, int) asm("_find_a_file");
static void add_prefix (struct n64_tag_path_prefix *, char *, int, int, int *) asm("_add_prefix");
static char *skip_whitespace (char *) asm("_skip_whitespace");
static void record_temp_file (char *, int, int) asm("_record_temp_file");
static void delete_if_ordinary (char *) asm("_delete_if_ordinary");
static void delete_temp_files (void) asm("_delete_temp_files");
static void delete_failure_queue (void) asm("_delete_failure_queue");
static void clear_failure_queue (void) asm("_clear_failure_queue");
static char *choose_temp_base_try (char *, char *) asm("_choose_temp_base_try");
static void choose_temp_base (void) asm("_choose_temp_base");
static int check_live_switch (int, int) asm("_check_live_switch");
static char *handle_braces (char *) asm("_handle_braces");
static char *save_string (char *, int) asm("_save_string");
static char *concat (char *, char *) asm("_concat");
static char *concat3 (char *, char *, char *) asm("_concat3");
static char *concat4 (char *, char *, char *, char *) asm("_concat4");
static char *concat6 (char *, char *, char *, char *, char *, char *) asm("_concat6")
                                               ;
static int do_spec (char *) asm("_do_spec");
static int do_spec_1 (char *, int, char *) asm("_do_spec_1");
static char *find_file (char *) asm("_find_file");
static int is_directory (char *, char *, int) asm("_is_directory");
static void validate_switches (char *) asm("_validate_switches");
static void validate_all_switches (void) asm("_validate_all_switches");
static void give_switch (int, int) asm("_give_switch");
static int used_arg (char *, int) asm("_used_arg");
static int default_arg (char *, int) asm("_default_arg");
static void set_multilib_dir (void) asm("_set_multilib_dir");
static void print_multilib_info (void) asm("_print_multilib_info");
static void pfatal_with_name (char *) asm("_pfatal_with_name");
static void perror_with_name (char *) asm("_perror_with_name");
static void perror_exec (char *) asm("_perror_exec");

static void fatal (char *, ...) asm("_fatal");
static void error (char *, ...) asm("_error");






void fancy_abort(void) asm("_fancy_abort");
char *xmalloc(...) asm("_xmalloc");
char *xrealloc(...) asm("_xrealloc");
static char *cpp_spec = "%{posix:-D_POSIX_SOURCE} %{bsd:-D_BSD_SOURCE}";
static char *cpp_predefines = "-D" "mips" " -Acpu(" "mips" ") -Amachine(" "mips" ")" "-Dunix -Asystem(unix) -DMACH -Asystem(mach) -D__GNU__ -Asystem(gnu)" "-DMIPSEB -DR3000 -D_MIPSEB -D_R3000 -D_MIPS_SZINT=32 -D_MIPS_SZLONG=32 -D_MIPS_SZPTR=32";
static char *cc1_spec = "%{gline:%{!g:%{!g0:%{!g1:%{!g2: -g1}}}}} %{mips1:-mfp32 -mgp32}%{mips2:-mfp32 -mgp32}%{mips3:%{!msingle-float:%{!m4650:-mfp64}} -mgp64} %{mips4:%{!msingle-float:%{!m4650:-mfp64}} -mgp64} %{mfp64:%{msingle-float:%emay not use both -mfp64 and -msingle-float}} %{mfp64:%{m4650:%emay not use both -mfp64 and -m4650}} %{m4650:-mcpu=r4650} %{G*} %{EB:-meb} %{EL:-mel} %{EB:%{EL:%emay not use both -EB and -EL}} %{pic-none:   -mno-half-pic} %{pic-lib:    -mhalf-pic} %{pic-extern: -mhalf-pic} %{pic-calls:  -mhalf-pic} %{save-temps: }";
static char *cc1plus_spec = "";
static char *signed_char_spec = "%{funsigned-char:-D__CHAR_UNSIGNED__}";
static char *asm_spec = "%{mmips-as: 	%{!.s:-nocpp} %{.s: %{cpp} %{nocpp}} 	%{pipe: %e-pipe is not supported.} 	%{K}} %{!mmips-as: 	%{mcpu=*}} %{G*} %{EB} %{EL} %{mips1} %{mips2} %{mips3} %{v} %{noasmopt:-O0} %{!noasmopt:%{O:-O2} %{O1:-O2} %{O2:-O2} %{O3:-O3}} %{g} %{g0} %{g1} %{g2} %{g3} %{ggdb:-g} %{ggdb0:-g0} %{ggdb1:-g1} %{ggdb2:-g2} %{ggdb3:-g3} %{gstabs:-g} %{gstabs0:-g0} %{gstabs1:-g1} %{gstabs2:-g2} %{gstabs3:-g3} %{gstabs+:-g} %{gstabs+0:-g0} %{gstabs+1:-g1} %{gstabs+2:-g2} %{gstabs+3:-g3} %{gcoff:-g} %{gcoff0:-g0} %{gcoff1:-g1} %{gcoff2:-g2} %{gcoff3:-g3} %{membedded-pic}";
static char *asm_final_spec = "%{pipe:-}";
static char *link_spec = "%{G*} %{EB} %{EL} %{mips1} %{mips2} %{mips3} %{bestGnum} %{shared} %{non_shared} %{call_shared} %{no_archive} %{exact_version} %{!shared: %{!non_shared: %{!call_shared: -non_shared}}} -systype /gnu/ ";
static char *lib_spec = "%{bsd:-lbsd-compat} %{!p:%{!pg:-lc}}%{p:-lc_p}%{pg:-lc_p}";
static char *libgcc_spec = "%{!shared:%{!symbolic:-lgcc}}";
static char *endfile_spec = "crtend.o%s %{pg:gcrtn.o}%{!pg:crtn.o%s}";
static char *startfile_spec = "%{pg:gcrt0.o%s} %{!pg:%{p:gcrt0.o%s} %{!p:crt0.o%s}} %{static:-static}";
static char *switches_need_spaces = "";
static char *multilib_select = ". ;";
struct n64_tag_compiler
{
  char *suffix;


  char *spec[4];

};
static struct n64_tag_compiler *compilers;



static int n_compilers;



static struct n64_tag_compiler default_compilers[] =
{
  {".c", "@c"},
  {"@c",
   "cpp -lang-c%{ansi:89} %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C does not support -C without using -E}}	%{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG}        -undef -D__GNUC__=%v1 -D__GNUC_MINOR__=%v2	%{ansi:-trigraphs -$ -D__STRICT_ANSI__}	%{!undef:%{!ansi:%p} %P} %{trigraphs}         %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %{!M:%{!MM:%{!E:%{!pipe:%g.i}}}}%{E:%W{o*}}%{M:%W{o*}}%{MM:%W{o*}} |\n",
   "%{!M:%{!MM:%{!E:cc1 %{!pipe:%g.i} %1 		   %{!Q:-quiet} -dumpbase %b.c %{d*} %{m*} %{a}		   %{g*} %{O*} %{W*} %{w} %{pedantic*} %{ansi} 		   %{traditional} %{v:-version} %{pg:-p} %{p} %{f*}		   %{aux-info*}		   %{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}		   %{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}} |\n              %{!S:as %a %Y %{mabi*} %{irix-symtab}		      %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}                      %{!pipe:%g.s} %A\n }}}}"},
  {"-",
   "%{E:cpp -lang-c%{ansi:89} %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C does not support -C without using -E}}	%{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG}        -undef -D__GNUC__=%v1 -D__GNUC_MINOR__=%v2	%{ansi:-trigraphs -$ -D__STRICT_ANSI__}	%{!undef:%{!ansi:%p} %P} %{trigraphs}        %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %W{o*}}    %{!E:%e-E required when input is from standard input}"},
  {".m", "@objective-c"},
  {"@objective-c",
   "cpp -lang-objc %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C does not support -C without using -E}}	%{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG}        -undef -D__OBJC__ -D__GNUC__=%v1 -D__GNUC_MINOR__=%v2	 %{ansi:-trigraphs -$ -D__STRICT_ANSI__}	%{!undef:%{!ansi:%p} %P} %{trigraphs}        %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %{!M:%{!MM:%{!E:%{!pipe:%g.i}}}}%{E:%W{o*}}%{M:%W{o*}}%{MM:%W{o*}} |\n",
   "%{!M:%{!MM:%{!E:cc1obj %{!pipe:%g.i} %1 		   %{!Q:-quiet} -dumpbase %b.m %{d*} %{m*} %{a}		   %{g*} %{O*} %{W*} %{w} %{pedantic*} %{ansi} 		   %{traditional} %{v:-version} %{pg:-p} %{p} %{f*}     		   -lang-objc %{gen-decls} 		   %{aux-info*}		   %{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}		   %{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}} |\n              %{!S:as %a %Y %{mabi*} %{irix-symtab}		      %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}                      %{!pipe:%g.s} %A\n }}}}"},
  {".h", "@c-header"},
  {"@c-header",
   "%{!E:%eCompilation of header file requested}     cpp %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C does not support -C without using -E}}	 %{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG}        -undef -D__GNUC__=%v1 -D__GNUC_MINOR__=%v2	 %{ansi:-trigraphs -$ -D__STRICT_ANSI__}	%{!undef:%{!ansi:%p} %P} %{trigraphs}        %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %W{o*}"},
  {".i", "@cpp-output"},
  {"@cpp-output",
   "%{!M:%{!MM:%{!E:cc1 %i %1 %{!Q:-quiet} %{d*} %{m*} %{a}			%{g*} %{O*} %{W*} %{w} %{pedantic*} %{ansi}			%{traditional} %{v:-version} %{pg:-p} %{p} %{f*}			%{aux-info*}			%{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}			%{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}} |\n		     %{!S:as %a %Y %{mabi*} %{irix-symtab}			     %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}			     %{!pipe:%g.s} %A\n }}}}"},
  {".s", "@assembler"},
  {"@assembler",
   "%{!M:%{!MM:%{!E:%{!S:as %a %Y %{mabi*} %{irix-symtab}		            %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}			    %i %A\n }}}}"},


  {".S", "@assembler-with-cpp"},
  {"@assembler-with-cpp",
   "cpp -lang-asm %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C does not support -C without using -E}}	%{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG} %{trigraphs}        -undef -$ %{!undef:%p %P} -D__ASSEMBLER__         %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %{!M:%{!MM:%{!E:%{!pipe:%g.s}}}}%{E:%W{o*}}%{M:%W{o*}}%{MM:%W{o*}} |\n",







   "%{!M:%{!MM:%{!E:%{!S:as %a %Y %{mabi*} %{irix-symtab}                    %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}		    %{!pipe:%g.s} %A\n }}}}"},


  {".cc", "@c++"},
  {".cxx", "@c++"},
  {".cpp", "@c++"},
  {".c++", "@c++"},
  {".C", "@c++"},
  {"@c++",
   "cpp -lang-c++ %{nostdinc*} %{C} %{v} %{A*} %{I*} %{P} %I	%{C:%{!E:%eGNU C++ does not support -C without using -E}}	%{M} %{MM} %{MD:-MD %b.d} %{MMD:-MMD %b.d} %{MG}	-undef -D__GNUC__=%v1 -D__GNUG__=%v1 -D__cplusplus -D__GNUC_MINOR__=%v2	%{ansi:-trigraphs -$ -D__STRICT_ANSI__} %{!undef:%{!ansi:%p} %P}        %c %{O*:%{!O0:-D__OPTIMIZE__}} %{traditional} %{ftraditional:-traditional}        %{traditional-cpp:-traditional} %{trigraphs}	%{g*} %{W*} %{w} %{pedantic*} %{H} %{d*} %C %{D*} %{U*} %{i*} %Z        %i %{!M:%{!MM:%{!E:%{!pipe:%g.ii}}}}%{E:%W{o*}}%{M:%W{o*}}%{MM:%W{o*}} |\n",
   "%{!M:%{!MM:%{!E:cc1plus %{!pipe:%g.ii} %1 %2			    %{!Q:-quiet} -dumpbase %b.cc %{d*} %{m*} %{a}			    %{g*} %{O*} %{W*} %{w} %{pedantic*} %{ansi}			    %{traditional} %{v:-version} %{pg:-p} %{p}			    %{f*} %{+e*} %{aux-info*}			    %{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}			    %{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}}|\n              %{!S:as %a %Y		      %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}                      %{!pipe:%g.s} %A\n }}}}"},
  {".ii", "@c++-cpp-output"},
  {"@c++-cpp-output",
   "%{!M:%{!MM:%{!E:cc1plus %i %1 %2 %{!Q:-quiet} %{d*} %{m*} %{a}			    %{g*} %{O*} %{W*} %{w} %{pedantic*} %{ansi}			    %{traditional} %{v:-version} %{pg:-p} %{p}			    %{f*} %{+e*} %{aux-info*}			    %{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}			    %{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}} |\n	            %{!S:as %a %Y			    %{c:%W{o*}%{!o*:-o %w%b%O}}%{!c:-o %d%w%u%O}			    %{!pipe:%g.s} %A\n }}}}"},

  {0, 0}
};



static int n_default_compilers
  = (sizeof default_compilers / sizeof (struct n64_tag_compiler)) - 1;
static char *link_command_spec = "%{!fsyntax-only:  %{!c:%{!M:%{!MM:%{!E:%{!S:ld %l %X %{o*} %{A} %{d} %{e*} %{m} %{N} %{n} 			%{r} %{s} %{t} %{u*} %{x} %{z} %{Z}			%{!A:%{!nostdlib:%{!nostartfiles:%S}}}			%{static:} %{L*} %D %{T*} %o			%{!nostdlib:%{!nodefaultlibs:%G %L %G}}			%{!A:%{!nostdlib:%{!nostartfiles:%E}}}\n }}}}}}";
static int n_linker_options;
static char **linker_options;




static int n_assembler_options;
static char **assembler_options;




static int n_preprocessor_options;
static char **preprocessor_options;




struct n64_tag_option_map
{

  char *name;

  char *equivalent;





  char *arg_info;
};




struct n64_tag_option_map option_map[] =
 {
   {"--all-warnings", "-Wall", 0},
   {"--ansi", "-ansi", 0},
   {"--assemble", "-S", 0},
   {"--assert", "-A", "a"},
   {"--comments", "-C", 0},
   {"--compile", "-c", 0},
   {"--debug", "-g", "oj"},
   {"--define-macro", "-D", "a"},
   {"--dependencies", "-M", 0},
   {"--dump", "-d", "a"},
   {"--dumpbase", "-dumpbase", "a"},
   {"--entry", "-e", 0},
   {"--extra-warnings", "-W", 0},
   {"--for-assembler", "-Wa", "a"},
   {"--for-linker", "-Xlinker", "a"},
   {"--force-link", "-u", "a"},
   {"--imacros", "-imacros", "a"},
   {"--include", "-include", "a"},
   {"--include-barrier", "-I-", 0},
   {"--include-directory", "-I", "a"},
   {"--include-directory-after", "-idirafter", "a"},
   {"--include-prefix", "-iprefix", "a"},
   {"--include-with-prefix", "-iwithprefix", "a"},
   {"--include-with-prefix-before", "-iwithprefixbefore", "a"},
   {"--include-with-prefix-after", "-iwithprefix", "a"},
   {"--language", "-x", "a"},
   {"--library-directory", "-L", "a"},
   {"--machine", "-m", "aj"},
   {"--machine-", "-m", "*j"},
   {"--no-line-commands", "-P", 0},
   {"--no-precompiled-includes", "-noprecomp", 0},
   {"--no-standard-includes", "-nostdinc", 0},
   {"--no-standard-libraries", "-nostdlib", 0},
   {"--no-warnings", "-w", 0},
   {"--optimize", "-O", "oj"},
   {"--output", "-o", "a"},
   {"--pedantic", "-pedantic", 0},
   {"--pedantic-errors", "-pedantic-errors", 0},
   {"--pipe", "-pipe", 0},
   {"--prefix", "-B", "a"},
   {"--preprocess", "-E", 0},
   {"--print-search-dirs", "-print-search-dirs", 0},
   {"--print-file-name", "-print-file-name=", "aj"},
   {"--print-libgcc-file-name", "-print-libgcc-file-name", 0},
   {"--print-missing-file-dependencies", "-MG", 0},
   {"--print-multi-lib", "-print-multi-lib", 0},
   {"--print-multi-directory", "-print-multi-directory", 0},
   {"--print-prog-name", "-print-prog-name=", "aj"},
   {"--profile", "-p", 0},
   {"--profile-blocks", "-a", 0},
   {"--quiet", "-q", 0},
   {"--save-temps", "-save-temps", 0},
   {"--shared", "-shared", 0},
   {"--silent", "-q", 0},
   {"--static", "-static", 0},
   {"--symbolic", "-symbolic", 0},
   {"--target", "-b", "a"},
   {"--trace-includes", "-H", 0},
   {"--traditional", "-traditional", 0},
   {"--traditional-cpp", "-traditional-cpp", 0},
   {"--trigraphs", "-trigraphs", 0},
   {"--undefine-macro", "-U", "a"},
   {"--use-version", "-V", "a"},
   {"--user-dependencies", "-MM", 0},
   {"--verbose", "-v", 0},
   {"--version", "-dumpversion", 0},
   {"--warn-", "-W", "*j"},
   {"--write-dependencies", "-MD", 0},
   {"--write-user-dependencies", "-MMD", 0},
   {"--", "-f", "*j"}
 };





static void
translate_options(int *argcp, char ***argvp) asm("_translate_options");
static void
translate_options(int *argcp, char ***argvp)
{
  int i, j, k;
  int argc = *argcp;
  char **argv = *argvp;
  char **newv = (char **) xmalloc ((argc + 2) * 2 * sizeof (char *));
  int newindex = 0;

  i = 0;
  newv[newindex++] = argv[i++];

  while (i < argc)
    {

      if (argv[i][0] == '-' && argv[i][1] == '-')
 {

   for (j = 0; j < sizeof (option_map) / sizeof (option_map[0]); j++)
     {
       int optlen = strlen (option_map[j].name);
       int arglen = strlen (argv[i]);
       int complen = arglen > optlen ? optlen : arglen;
       char *arginfo = option_map[j].arg_info;

       if (arginfo == 0)
  arginfo = "";

       if (!strncmp (argv[i], option_map[j].name, complen))
  {
    char *arg = 0;

    if (arglen < optlen)
      {
        for (k = j + 1;
      k < sizeof (option_map) / sizeof (option_map[0]);
      k++)
   if (strlen (option_map[k].name) >= arglen
       && !strncmp (argv[i], option_map[k].name, arglen))
     {
       error ("Ambiguous abbreviation %s", argv[i]);
       break;
     }

        if (k != sizeof (option_map) / sizeof (option_map[0]))
   break;
      }

    if (arglen > optlen)
      {

        if (argv[i][optlen] == '=')
   arg = argv[i] + optlen + 1;



        else if (strchr (arginfo, '*') != 0)
   arg = argv[i] + optlen;



        else
   continue;
      }

    else if (strchr (arginfo, '*') != 0)
      {
        error ("Incomplete `%s' option", option_map[j].name);
        break;
      }


    if (strchr (arginfo, 'a') != 0)
      {
        if (arg == 0)
   {
     if (i + 1 == argc)
       {
         error ("Missing argument to `%s' option",
         option_map[j].name);
         break;
       }

     arg = argv[++i];
   }
      }
    else if (strchr (arginfo, '*') != 0)
      ;
    else if (strchr (arginfo, 'o') == 0)
      {
        if (arg != 0)
   error ("Extraneous argument to `%s' option",
          option_map[j].name);
        arg = 0;
      }


    if (arg != 0 && strchr (arginfo, 'j') != 0)
      newv[newindex++] = concat (option_map[j].equivalent, arg);
    else if (arg != 0)
      {
        newv[newindex++] = option_map[j].equivalent;
        newv[newindex++] = arg;
      }
    else
      newv[newindex++] = option_map[j].equivalent;

    break;
  }
     }
   i++;
 }



      else if (argv[i][0] == '-')
 {
   char *p = argv[i] + 1;
   int c = *p;
   int nskip = 1;

   if (((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') > (p[1] != 0))
     nskip += ((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') - (p[1] != 0);
   else if (((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss")))
     nskip += ((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss"));
   else if ((c == 'B' || c == 'b' || c == 'V' || c == 'x')
     && p[1] == 0)
     nskip += 1;
   else if (! strcmp (p, "Xlinker"))
     nskip += 1;




   if (nskip + i > argc)
     nskip = argc - i;

   while (nskip > 0)
     {
       newv[newindex++] = argv[i++];
       nskip--;
     }
 }
      else

 newv[newindex++] = argv[i++];
    }

  newv[newindex] = 0;

  *argvp = newv;
  *argcp = newindex;
}
static void
read_specs(char *filename) asm("_read_specs");
static void
read_specs(char *filename)
{
  int desc;
  int readlen;
  struct stat statbuf;
  char *buffer;
  register char *p;

  if (verbose_flag)
    fprintf (
            (__acrt_iob_func(2))
                  , "Reading specs from %s\n", filename);


  desc = open (filename, 0, 0);
  if (desc < 0)
    pfatal_with_name (filename);
  if (stat (filename, &statbuf) < 0)
    pfatal_with_name (filename);


  buffer = xmalloc ((unsigned) statbuf.st_size + 1);
  readlen = read (desc, buffer, (unsigned) statbuf.st_size);
  if (readlen < 0)
    pfatal_with_name (filename);
  buffer[readlen] = 0;
  close (desc);


  p = buffer;
  while (1)
    {
      char *suffix;
      char *spec;
      char *in, *out, *p1, *p2;


      p = skip_whitespace (p);
      if (*p == 0)
 break;


      p1 = p;
      while (*p1 && *p1 != ':' && *p1 != '\n') p1++;

      if (*p1 != ':')
 fatal ("specs file malformed after %d characters", p1 - buffer);

      p2 = p1;
      while (p2 > buffer && (p2[-1] == ' ' || p2[-1] == '\t')) p2--;

      suffix = save_string (p, p2 - p);

      p = skip_whitespace (p1 + 1);
      if (p[1] == 0)
 fatal ("specs file malformed after %d characters", p - buffer);
      p1 = p;

      while (*p1 && !(*p1 == '\n' && p1[1] == '\n')) p1++;

      spec = save_string (p, p1 - p);
      p = p1;


      in = spec;
      out = spec;
      while (*in != 0)
 {
   if (in[0] == '\\' && in[1] == '\n')
     in += 2;
   else if (in[0] == '#')
     {
       while (*in && *in != '\n') in++;
     }
   else
     *out++ = *in++;
 }
      *out = 0;

      if (suffix[0] == '*')
 {
   if (! strcmp (suffix, "*link_command"))
     link_command_spec = spec;
   else
     set_spec (suffix + 1, spec);
 }
      else
 {

   compilers
     = ((struct n64_tag_compiler *)
        xrealloc (compilers, (n_compilers + 2) * sizeof (struct n64_tag_compiler)));
   compilers[n_compilers].suffix = suffix;
   memset ((char *) compilers[n_compilers].spec,0,sizeof compilers[n_compilers].spec)
                                      ;
   compilers[n_compilers].spec[0] = spec;
   n_compilers++;
   memset ((char *) &compilers[n_compilers],0,sizeof compilers[n_compilers])
                                 ;
 }

      if (*suffix == 0)
 link_command_spec = spec;
    }

  if (link_command_spec == 0)
    fatal ("spec file has no spec for linking");
}

static char *
skip_whitespace(char *p) asm("_skip_whitespace");
static char *
skip_whitespace(char *p)
{
  while (1)
    {


      if (p[0] == '\n' && p[1] == '\n' && p[2] == '\n')
 return p + 1;
      else if (*p == '\n' || *p == ' ' || *p == '\t')
 p++;
      else if (*p == '#')
 {
   while (*p != '\n') p++;
   p++;
 }
      else
 break;
    }

  return p;
}




struct n64_tag_spec_list
{
  char *name;
  char *spec;
  struct n64_tag_spec_list *next;
};



static struct n64_tag_spec_list *specs = (struct n64_tag_spec_list *) 0;





static void
set_spec(char *name, char *spec) asm("_set_spec");
static void
set_spec(char *name, char *spec)
{
  struct n64_tag_spec_list *sl;
  char *old_spec;


  for (sl = specs; sl; sl = sl->next)
    if (strcmp (sl->name, name) == 0)
      break;

  if (!sl)
    {

      sl = (struct n64_tag_spec_list *) xmalloc (sizeof (struct n64_tag_spec_list));
      sl->name = save_string (name, strlen (name));
      sl->spec = save_string ("", 0);
      sl->next = specs;
      specs = sl;
    }

  old_spec = sl->spec;
  if (name && spec[0] == '+' && isspace (spec[1]))
    sl->spec = concat (old_spec, spec + 1);
  else
    sl->spec = save_string (spec, strlen (spec));

  if (! strcmp (name, "asm"))
    asm_spec = sl->spec;
  else if (! strcmp (name, "asm_final"))
    asm_final_spec = sl->spec;
  else if (! strcmp (name, "cc1"))
    cc1_spec = sl->spec;
  else if (! strcmp (name, "cc1plus"))
    cc1plus_spec = sl->spec;
  else if (! strcmp (name, "cpp"))
    cpp_spec = sl->spec;
  else if (! strcmp (name, "endfile"))
    endfile_spec = sl->spec;
  else if (! strcmp (name, "lib"))
    lib_spec = sl->spec;
  else if (! strcmp (name, "libgcc"))
    libgcc_spec = sl->spec;
  else if (! strcmp (name, "link"))
    link_spec = sl->spec;
  else if (! strcmp (name, "predefines"))
    cpp_predefines = sl->spec;
  else if (! strcmp (name, "signed_char"))
    signed_char_spec = sl->spec;
  else if (! strcmp (name, "startfile"))
    startfile_spec = sl->spec;
  else if (! strcmp (name, "switches_need_spaces"))
    switches_need_spaces = sl->spec;
  else if (! strcmp (name, "cross_compile"))
    cross_compile = atoi (sl->spec);
  else if (! strcmp (name, "multilib"))
    multilib_select = sl->spec;

  if (old_spec)
    free (old_spec);
}





static char **argbuf;



static int argbuf_length;



static int argbuf_index;




static struct n64_tag_temp_name {
  char *suffix;
  int length;
  int unique;
  char *filename;
  int filename_length;
  struct n64_tag_temp_name *next;
} *temp_names;



static int execution_count;



static int signal_count;



static char *programname;



struct n64_tag_prefix_list
{
  char *prefix;
  struct n64_tag_prefix_list *next;
  int require_machine_suffix;

  int *used_flag_ptr;
};

struct n64_tag_path_prefix
{
  struct n64_tag_prefix_list *plist;
  int max_len;
  char *name;
};



static struct n64_tag_path_prefix exec_prefixes = { 0, 0, "exec" };



static struct n64_tag_path_prefix startfile_prefixes = { 0, 0, "startfile" };



static struct n64_tag_path_prefix include_prefixes = { 0, 0, "include" };




static char *machine_suffix = 0;




static char *just_machine_suffix = 0;



static char *gcc_exec_prefix;
static char *standard_exec_prefix = "/opt/cross/lib/gcc-lib/";
static char *standard_exec_prefix_1 = "/usr/lib/gcc/";
static char *standard_startfile_prefix = "/opt/cross/lib/";
static char *standard_startfile_prefix_1 = "/lib/";
static char *standard_startfile_prefix_2 = "/usr/lib/";




static char *tooldir_base_prefix = "/opt/cross/";
static char *tooldir_prefix;




static char *multilib_dir;



static void
clear_args(void) asm("_clear_args");
static void
clear_args(void)
{
  argbuf_index = 0;
}
static void
store_arg(char *arg, int delete_always, int delete_failure) asm("_store_arg");
static void
store_arg(char *arg, int delete_always, int delete_failure)
{
  if (argbuf_index + 1 == argbuf_length)
    {
      argbuf = (char **) xrealloc (argbuf, (argbuf_length *= 2) * sizeof (char *));
    }

  argbuf[argbuf_index++] = arg;
  argbuf[argbuf_index] = 0;

  if (delete_always || delete_failure)
    record_temp_file (arg, delete_always, delete_failure);
}
static char *temp_filename;



static int temp_filename_length;



struct n64_tag_temp_file
{
  char *name;
  struct n64_tag_temp_file *next;
};


static struct n64_tag_temp_file *always_delete_queue;

static struct n64_tag_temp_file *failure_delete_queue;







static void
record_temp_file(char *filename, int always_delete, int fail_delete) asm("_record_temp_file");
static void
record_temp_file(char *filename, int always_delete, int fail_delete)
{
  register char *name;
  name = xmalloc (strlen (filename) + 1);
  strcpy (name, filename);

  if (always_delete)
    {
      register struct n64_tag_temp_file *temp;
      for (temp = always_delete_queue; temp; temp = temp->next)
 if (! strcmp (name, temp->name))
   goto already1;
      temp = (struct n64_tag_temp_file *) xmalloc (sizeof (struct n64_tag_temp_file));
      temp->next = always_delete_queue;
      temp->name = name;
      always_delete_queue = temp;
    already1:;
    }

  if (fail_delete)
    {
      register struct n64_tag_temp_file *temp;
      for (temp = failure_delete_queue; temp; temp = temp->next)
 if (! strcmp (name, temp->name))
   goto already2;
      temp = (struct n64_tag_temp_file *) xmalloc (sizeof (struct n64_tag_temp_file));
      temp->next = failure_delete_queue;
      temp->name = name;
      failure_delete_queue = temp;
    already2:;
    }
}



static void
delete_if_ordinary(char *name) asm("_delete_if_ordinary");
static void
delete_if_ordinary(char *name)
{
  struct stat st;
    if (stat (name, &st) >= 0 && (((st.st_mode)&
                                0xF000
                                ) == 
                                0x8000
                                ))
      if (unlink (name) < 0)
 if (verbose_flag)
   perror_with_name (name);
}

static void
delete_temp_files(void) asm("_delete_temp_files");
static void
delete_temp_files(void)
{
  register struct n64_tag_temp_file *temp;

  for (temp = always_delete_queue; temp; temp = temp->next)
    delete_if_ordinary (temp->name);
  always_delete_queue = 0;
}



static void
delete_failure_queue(void) asm("_delete_failure_queue");
static void
delete_failure_queue(void)
{
  register struct n64_tag_temp_file *temp;

  for (temp = failure_delete_queue; temp; temp = temp->next)
    delete_if_ordinary (temp->name);
}

static void
clear_failure_queue(void) asm("_clear_failure_queue");
static void
clear_failure_queue(void)
{
  failure_delete_queue = 0;
}




static char *
choose_temp_base_try(char *cxx_try, char *base) asm("_choose_temp_base_try");
static char *
choose_temp_base_try(char *cxx_try, char *base)
{
  char *rv;
  if (base)
    rv = base;
  else if (cxx_try == (char *)0)
    rv = 0;
  else if (access (cxx_try, 
                       4 
                            | 
                              2
                                  ) != 0)
    rv = 0;
  else
    rv = cxx_try;
  return rv;
}

static void
choose_temp_base(void) asm("_choose_temp_base");
static void
choose_temp_base(void)
{
  char *base = 0;
  int len;

  base = choose_temp_base_try (getenv ("TMPDIR"), base);
  base = choose_temp_base_try (getenv ("TMP"), base);
  base = choose_temp_base_try (getenv ("TEMP"), base);


  base = choose_temp_base_try (
                              "\\"
                                      , base);


  base = choose_temp_base_try (concat4 (dir_separator_str, "usr",
                                        dir_separator_str, "tmp"),
                                base);
  base = choose_temp_base_try (concat (dir_separator_str, "tmp"), base);


  if (base == (char *)0) base = concat(".", dir_separator_str);

  len = strlen (base);
  temp_filename = xmalloc (len + strlen (concat (dir_separator_str,
                                                 "ccXXXXXX")) + 1);
  strcpy (temp_filename, base);
  if (len > 0 && temp_filename[len-1] != '/'
      && temp_filename[len-1] != '\\')
    temp_filename[len++] = '\\';
  strcpy (temp_filename + len, "ccXXXXXX");

  mktemp (temp_filename);
  temp_filename_length = strlen (temp_filename);
  if (temp_filename_length == 0)
    abort ();
}
static char *
build_search_list(struct n64_tag_path_prefix *paths, char *prefix, int check_dir_p) asm("_build_search_list");
static char *
build_search_list(struct n64_tag_path_prefix *paths, char *prefix, int check_dir_p)
{
  int suffix_len = (machine_suffix) ? strlen (machine_suffix) : 0;
  int just_suffix_len
    = (just_machine_suffix) ? strlen (just_machine_suffix) : 0;
  int first_time = 1;
  struct n64_tag_prefix_list *pprefix;

  __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (strlen (prefix)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (prefix),__len); __o->next_free += __len; } (void) 0; });

  for (pprefix = paths->plist; pprefix != 0; pprefix = pprefix->next)
    {
      int len = strlen (pprefix->prefix);

      if (machine_suffix
   && (!check_dir_p
       || is_directory (pprefix->prefix, machine_suffix, 0)))
 {
   if (!first_time)
     __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (';'); (void) 0; });

   first_time = 0;
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (pprefix->prefix),__len); __o->next_free += __len; } (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (suffix_len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (machine_suffix),__len); __o->next_free += __len; } (void) 0; });
 }

      if (just_machine_suffix
   && pprefix->require_machine_suffix == 2
   && (!check_dir_p
       || is_directory (pprefix->prefix, just_machine_suffix, 0)))
 {
   if (!first_time)
     __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (';'); (void) 0; });

   first_time = 0;
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (pprefix->prefix),__len); __o->next_free += __len; } (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (just_suffix_len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (just_machine_suffix),__len); __o->next_free += __len; } (void) 0; })
                   ;
 }

      if (!pprefix->require_machine_suffix)
 {
   if (!first_time)
     __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (';'); (void) 0; });

   first_time = 0;
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (pprefix->prefix),__len); __o->next_free += __len; } (void) 0; });
 }
    }
  __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; });
  return __extension__ ({ struct n64_tag_obstack *__o1 = (&collect_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
}



static void
putenv_from_prefixes(struct n64_tag_path_prefix *paths, char *env_var) asm("_putenv_from_prefixes");
static void
putenv_from_prefixes(struct n64_tag_path_prefix *paths, char *env_var)
{
  putenv (build_search_list (paths, env_var, 1));
}





static char *
find_a_file(struct n64_tag_path_prefix *pprefix, char *name, int mode) asm("_find_a_file");
static char *
find_a_file(struct n64_tag_path_prefix *pprefix, char *name, int mode)
{
  char *temp;
  char *file_suffix = ((mode & 
                              1
                                  ) != 0 ? ".exe" : "");
  struct n64_tag_prefix_list *pl;
  int len = pprefix->max_len + strlen (name) + strlen (file_suffix) + 1;

  if (machine_suffix)
    len += strlen (machine_suffix);

  temp = xmalloc (len);



  if (*name == '/' || *name == '\\')
    {
      if (access (name, mode))
 {
   strcpy (temp, name);
   return temp;
 }
    }
  else
    for (pl = pprefix->plist; pl; pl = pl->next)
      {
 if (machine_suffix)
   {


     if (file_suffix[0] != 0)
       {
  strcpy (temp, pl->prefix);
  strcat (temp, machine_suffix);
  strcat (temp, name);
  strcat (temp, file_suffix);
  if (access (temp, mode) == 0)
    {
      if (pl->used_flag_ptr != 0)
        *pl->used_flag_ptr = 1;
      return temp;
    }
       }


     strcpy (temp, pl->prefix);
     strcat (temp, machine_suffix);
     strcat (temp, name);
     if (access (temp, mode) == 0)
       {
  if (pl->used_flag_ptr != 0)
    *pl->used_flag_ptr = 1;
  return temp;
       }
   }



 if (just_machine_suffix && pl->require_machine_suffix == 2)
   {


     if (file_suffix[0] != 0)
       {
  strcpy (temp, pl->prefix);
  strcat (temp, just_machine_suffix);
  strcat (temp, name);
  strcat (temp, file_suffix);
  if (access (temp, mode) == 0)
    {
      if (pl->used_flag_ptr != 0)
        *pl->used_flag_ptr = 1;
      return temp;
    }
       }

     strcpy (temp, pl->prefix);
     strcat (temp, just_machine_suffix);
     strcat (temp, name);
     if (access (temp, mode) == 0)
       {
  if (pl->used_flag_ptr != 0)
    *pl->used_flag_ptr = 1;
  return temp;
       }
   }



 if (!pl->require_machine_suffix)
   {


     if (file_suffix[0] != 0)
       {
  strcpy (temp, pl->prefix);
  strcat (temp, name);
  strcat (temp, file_suffix);
  if (access (temp, mode) == 0)
    {
      if (pl->used_flag_ptr != 0)
        *pl->used_flag_ptr = 1;
      return temp;
    }
       }

     strcpy (temp, pl->prefix);
     strcat (temp, name);
     if (access (temp, mode) == 0)
       {
  if (pl->used_flag_ptr != 0)
    *pl->used_flag_ptr = 1;
  return temp;
       }
   }
      }

  free (temp);
  return 0;
}
static void
add_prefix(struct n64_tag_path_prefix *pprefix, char *prefix, int first, int require_machine_suffix, int *warn) asm("_add_prefix");
static void
add_prefix(struct n64_tag_path_prefix *pprefix, char *prefix, int first, int require_machine_suffix, int *warn)
{
  struct n64_tag_prefix_list *pl, **prev;
  int len;

  if (!first && pprefix->plist)
    {
      for (pl = pprefix->plist; pl->next; pl = pl->next)
 ;
      prev = &pl->next;
    }
  else
    prev = &pprefix->plist;



  len = strlen (prefix);
  if (len > pprefix->max_len)
    pprefix->max_len = len;

  pl = (struct n64_tag_prefix_list *) xmalloc (sizeof (struct n64_tag_prefix_list));
  pl->prefix = save_string (prefix, len);
  pl->require_machine_suffix = require_machine_suffix;
  pl->used_flag_ptr = warn;
  if (warn)
    *warn = 0;

  if (*prev)
    pl->next = *prev;
  else
    pl->next = (struct n64_tag_prefix_list *) 0;
  *prev = pl;
}



static void
unused_prefix_warnings(struct n64_tag_path_prefix *pprefix) asm("_unused_prefix_warnings");
static void
unused_prefix_warnings(struct n64_tag_path_prefix *pprefix)
{
  struct n64_tag_prefix_list *pl = pprefix->plist;

  while (pl)
    {
      if (pl->used_flag_ptr != 0 && !*pl->used_flag_ptr)
 {
   error ("file path prefix `%s' never used",
   pl->prefix);

   *pl->used_flag_ptr = 1;
 }
      pl = pl->next;
    }
}



static void
free_path_prefix(struct n64_tag_path_prefix *pprefix) asm("_free_path_prefix");
static void
free_path_prefix(struct n64_tag_path_prefix *pprefix)
{
  struct n64_tag_prefix_list *pl = pprefix->plist;
  struct n64_tag_prefix_list *temp;

  while (pl)
    {
      temp = pl;
      pl = pl->next;
      free (temp->prefix);
      free ((char *) temp);
    }
  pprefix->plist = (struct n64_tag_prefix_list *) 0;
}
static int last_pipe_input;
static int
pexecute(int search_flag, char *program, char **argv, int not_last) asm("_pexecute");
static int
pexecute(int search_flag, char *program, char **argv, int not_last)
{
  return (search_flag ? windows_spawnv : windows_spawnvp) (1, program, argv);
}
static int
execute(void) asm("_execute");
static int
execute(void)
{
  int i;
  int n_commands;
  char *string;
  struct n64_tag_command
    {
      char *prog;
      char **argv;
      int pid;
    };

  struct n64_tag_command *commands;


  for (n_commands = 1, i = 0; i < argbuf_index; i++)
    if (strcmp (argbuf[i], "|") == 0)
      n_commands++;


  commands
    = (struct n64_tag_command *) 
                        __builtin_alloca((
                        n_commands * sizeof (struct n64_tag_command)
                        ))
                                                                     ;





  commands[0].prog = argbuf[0];
  commands[0].argv = &argbuf[0];
  string = find_a_file (&exec_prefixes, commands[0].prog, 
                                                         1
                                                             );
  if (string)
    commands[0].argv[0] = string;

  for (n_commands = 1, i = 0; i < argbuf_index; i++)
    if (strcmp (argbuf[i], "|") == 0)
      {



 argbuf[i] = 0;
 commands[n_commands].prog = argbuf[i + 1];
 commands[n_commands].argv = &argbuf[i + 1];
 string = find_a_file (&exec_prefixes, commands[n_commands].prog, 
                                                                 1
                                                                     );
 if (string)
   commands[n_commands].argv[0] = string;
 n_commands++;
      }

  argbuf[argbuf_index] = 0;



  if (verbose_flag)
    {

      for (i = 0; i < n_commands ; i++)
 {
   char **j;

   for (j = commands[i].argv; *j; j++)
     fprintf (
             (__acrt_iob_func(2))
                   , " %s", *j);


   if (i + 1 != n_commands)
     fprintf (
             (__acrt_iob_func(2))
                   , " |");
   fprintf (
           (__acrt_iob_func(2))
                 , "\n");
 }
      fflush (
             (__acrt_iob_func(2))
                   );
    }



  last_pipe_input = 0;
  for (i = 0; i < n_commands; i++)
    {
      char *string = commands[i].argv[0];

      commands[i].pid = pexecute (string != commands[i].prog,
      string, commands[i].argv,
      i + 1 < n_commands);

      if (string != commands[i].prog)
 free (string);
    }

  execution_count++;







  {
    int ret_code = 0;

    for (i = 0; i < n_commands; )
      {
 int j;
 int status;
 int pid;





 pid = _cwait (&status, commands[i].pid, 
                                        0
                                                   );



        status = status ? (1 << 8) : 0;




 if (pid < 0)
   abort ();

 for (j = 0; j < n_commands; j++)
   if (commands[j].pid == pid)
     {
       i++;
       if (status != 0)
  {
    if ((((status) & 0xff) != 0 && ((status) & 0xff) != 0x7f))
      {
        fatal ("Internal compiler error: program %s got fatal signal %d",
        commands[j].prog, ((status) & 0x7f));
        signal_count++;
        ret_code = -1;
      }
    else if ((((status) & 0xff) == 0)
      && (((status) & 0xff00) >> 8) >= 1)
      ret_code = -1;
  }
       break;
     }
      }
    return ret_code;
  }
}
struct n64_tag_switchstr
{
  char *part1;
  char **args;
  int live_cond;
  int valid;
};

static struct n64_tag_switchstr *switches;

static int n_switches;

struct n64_tag_infile
{
  char *name;
  char *language;
};



static struct n64_tag_infile *infiles;

static int n_infiles;



static char **outfiles;




static void
process_command(int argc, char **argv) asm("_process_command");
static void
process_command(int argc, char **argv)
{
  register int i;
  char *temp;
  char *spec_lang = 0;
  int last_language_n_infiles;

  gcc_exec_prefix = getenv ("GCC_EXEC_PREFIX");

  n_switches = 0;
  n_infiles = 0;



  compiler_version = save_string (version_string, strlen (version_string));
  for (temp = compiler_version; *temp; ++temp)
    {
      if (*temp == ' ')
 {
   *temp = '\0';
   break;
 }
    }



  if (gcc_exec_prefix)
    {
      add_prefix (&exec_prefixes, gcc_exec_prefix, 0, 0, ((void *)0));
      add_prefix (&startfile_prefixes, gcc_exec_prefix, 0, 0, ((void *)0));
    }




  temp = getenv ("COMPILER_PATH");
  if (temp)
    {
      char *startp, *endp;
      char *nstore = (char *) 
                             __builtin_alloca((
                             strlen (temp) + 3
                             ))
                                                       ;

      startp = endp = temp;
      while (1)
 {
   if (*endp == ';' || *endp == 0)
     {
       strncpy (nstore, startp, endp-startp);
       if (endp == startp)
  strcpy (nstore, concat (".", dir_separator_str));
       else if (endp[-1] != '/' && endp[-1] != '\\')
  {
    nstore[endp-startp] = '\\';
    nstore[endp-startp+1] = 0;
  }
       else
  nstore[endp-startp] = 0;
       add_prefix (&exec_prefixes, nstore, 0, 0, ((void *)0));
       if (*endp == 0)
  break;
       endp = startp = endp + 1;
     }
   else
     endp++;
 }
    }

  temp = getenv ("LIBRARY_PATH");
  if (temp && ! cross_compile)
    {
      char *startp, *endp;
      char *nstore = (char *) 
                             __builtin_alloca((
                             strlen (temp) + 3
                             ))
                                                       ;

      startp = endp = temp;
      while (1)
 {
   if (*endp == ';' || *endp == 0)
     {
       strncpy (nstore, startp, endp-startp);
       if (endp == startp)
  strcpy (nstore, concat (".", dir_separator_str));
       else if (endp[-1] != '/' && endp[-1] != '\\')
  {
    nstore[endp-startp] = '\\';
    nstore[endp-startp+1] = 0;
  }
       else
  nstore[endp-startp] = 0;
       add_prefix (&startfile_prefixes, nstore, 0, 0, ((void *)0));
       if (*endp == 0)
  break;
       endp = startp = endp + 1;
     }
   else
     endp++;
 }
    }


  temp = getenv ("LPATH");
  if (temp && ! cross_compile)
    {
      char *startp, *endp;
      char *nstore = (char *) 
                             __builtin_alloca((
                             strlen (temp) + 3
                             ))
                                                       ;

      startp = endp = temp;
      while (1)
 {
   if (*endp == ';' || *endp == 0)
     {
       strncpy (nstore, startp, endp-startp);
       if (endp == startp)
  strcpy (nstore, concat (".", dir_separator_str));
       else if (endp[-1] != '/' && endp[-1] != '\\')
  {
    nstore[endp-startp] = '\\';
    nstore[endp-startp+1] = 0;
  }
       else
  nstore[endp-startp] = 0;
       add_prefix (&startfile_prefixes, nstore, 0, 0, ((void *)0));
       if (*endp == 0)
  break;
       endp = startp = endp + 1;
     }
   else
     endp++;
 }
    }


  translate_options (&argc, &argv);





  for (i = 1; i < argc; i++)
    {
      if (! strcmp (argv[i], "-dumpspecs"))
 {
   printf ("*asm:\n%s\n\n", asm_spec);
   printf ("*asm_final:\n%s\n\n", asm_final_spec);
   printf ("*cpp:\n%s\n\n", cpp_spec);
   printf ("*cc1:\n%s\n\n", cc1_spec);
   printf ("*cc1plus:\n%s\n\n", cc1plus_spec);
   printf ("*endfile:\n%s\n\n", endfile_spec);
   printf ("*link:\n%s\n\n", link_spec);
   printf ("*lib:\n%s\n\n", lib_spec);
   printf ("*libgcc:\n%s\n\n", libgcc_spec);
   printf ("*startfile:\n%s\n\n", startfile_spec);
   printf ("*switches_need_spaces:\n%s\n\n", switches_need_spaces);
   printf ("*signed_char:\n%s\n\n", signed_char_spec);
   printf ("*predefines:\n%s\n\n", cpp_predefines);
   printf ("*cross_compile:\n%d\n\n", cross_compile);
   printf ("*multilib:\n%s\n\n", multilib_select);

   exit (0);
 }
      else if (! strcmp (argv[i], "-dumpversion"))
 {
   printf ("%s\n", version_string);
   exit (0);
 }
      else if (! strcmp (argv[i], "-dumpmachine"))
 {
   printf ("%s\n", spec_machine);
   exit (0);
 }
      else if (! strcmp (argv[i], "-print-search-dirs"))
 print_search_dirs = 1;
      else if (! strcmp (argv[i], "-print-libgcc-file-name"))
 print_file_name = "libgcc.a";
      else if (! strncmp (argv[i], "-print-file-name=", 17))
 print_file_name = argv[i] + 17;
      else if (! strncmp (argv[i], "-print-prog-name=", 17))
 print_prog_name = argv[i] + 17;
      else if (! strcmp (argv[i], "-print-multi-lib"))
 print_multi_lib = 1;
      else if (! strcmp (argv[i], "-print-multi-directory"))
 print_multi_directory = 1;
      else if (! strncmp (argv[i], "-Wa,", 4))
 {
   int prev, j;


   n_assembler_options++;
   if (!assembler_options)
     assembler_options
       = (char **) xmalloc (n_assembler_options * sizeof (char **));
   else
     assembler_options
       = (char **) xrealloc (assembler_options,
        n_assembler_options * sizeof (char **));


   prev = 4;
   for (j = 4; argv[i][j]; j++)
     if (argv[i][j] == ',')
       {
  assembler_options[n_assembler_options - 1]
    = save_string (argv[i] + prev, j - prev);
  n_assembler_options++;
  assembler_options
    = (char **) xrealloc (assembler_options,
     n_assembler_options * sizeof (char **));
  prev = j + 1;
       }

   assembler_options[n_assembler_options - 1] = argv[i] + prev;
 }
      else if (! strncmp (argv[i], "-Wp,", 4))
 {
   int prev, j;


   n_preprocessor_options++;
   if (!preprocessor_options)
     preprocessor_options
       = (char **) xmalloc (n_preprocessor_options * sizeof (char **));
   else
     preprocessor_options
       = (char **) xrealloc (preprocessor_options,
        n_preprocessor_options * sizeof (char **));


   prev = 4;
   for (j = 4; argv[i][j]; j++)
     if (argv[i][j] == ',')
       {
  preprocessor_options[n_preprocessor_options - 1]
    = save_string (argv[i] + prev, j - prev);
  n_preprocessor_options++;
  preprocessor_options
    = (char **) xrealloc (preprocessor_options,
     n_preprocessor_options * sizeof (char **));
  prev = j + 1;
       }

   preprocessor_options[n_preprocessor_options - 1] = argv[i] + prev;
 }
      else if (argv[i][0] == '+' && argv[i][1] == 'e')

 n_switches++;
      else if (strncmp (argv[i], "-Wl,", 4) == 0)
 {
   int j;

   for (j = 3; argv[i][j]; j++)
     n_infiles += (argv[i][j] == ',');
 }
      else if (strcmp (argv[i], "-Xlinker") == 0)
 {
   if (i + 1 == argc)
     fatal ("argument to `-Xlinker' is missing");

   n_infiles++;
   i++;
 }
      else if (strncmp (argv[i], "-l", 2) == 0)
 n_infiles++;
      else if (argv[i][0] == '-' && argv[i][1] != 0)
 {
   register char *p = &argv[i][1];
   register int c = *p;

   switch (c)
     {
     case 'b':
       if (p[1] == 0 && i + 1 == argc)
  fatal ("argument to `-b' is missing");
       if (p[1] == 0)
  spec_machine = argv[++i];
       else
  spec_machine = p + 1;
       break;

     case 'B':
       {
  int *temp = (int *) xmalloc (sizeof (int));
  char *value;
  if (p[1] == 0 && i + 1 == argc)
    fatal ("argument to `-B' is missing");
  if (p[1] == 0)
    value = argv[++i];
  else
    value = p + 1;
  add_prefix (&exec_prefixes, value, 1, 0, temp);
  add_prefix (&startfile_prefixes, value, 1, 0, temp);
  add_prefix (&include_prefixes, concat (value, "include"),
       1, 0, 0);



  {
    int len = strlen (value);
    if ((len == 7
         || (len > 7
      && (value[len - 8] == '/'
          || value[len - 8] == '\\')))
        && strncmp (value + len - 7, "stage", 5) == 0
        && isdigit (value[len - 2])
        && (value[len - 1] == '/'
     || value[len - 1] == '\\'))
      {
        if (len == 7)
   add_prefix (&include_prefixes, "include", 1, 0, 0);
        else
   {
     char *string = xmalloc (len + 1);
     strncpy (string, value, len-7);
     strcat (string, "include");
     add_prefix (&include_prefixes, string, 1, 0, 0);
   }
      }
  }
       }
       break;

     case 'v':
       n_switches++;


       if (p[1] != 0)
  break;
       verbose_flag++;
       break;

     case 'V':
       if (p[1] == 0 && i + 1 == argc)
  fatal ("argument to `-V' is missing");
       if (p[1] == 0)
  spec_version = argv[++i];
       else
  spec_version = p + 1;
       compiler_version = spec_version;
       break;

     case 's':
       if (!strcmp (p, "save-temps"))
  {
    save_temps_flag = 1;
    n_switches++;
    break;
  }
     default:
       n_switches++;

       if (((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') > (p[1] != 0))
  i += ((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') - (p[1] != 0);
       else if (((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss")))
  i += ((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss"));
     }
 }
      else
 n_infiles++;
    }
  add_prefix (&exec_prefixes, standard_exec_prefix, 0, 2, ((void *)0));
  add_prefix (&exec_prefixes, standard_exec_prefix_1, 0, 2, ((void *)0));


  add_prefix (&startfile_prefixes, standard_exec_prefix, 0, 1, ((void *)0));
  add_prefix (&startfile_prefixes, standard_exec_prefix_1, 0, 1, ((void *)0));

  tooldir_prefix = concat3 (tooldir_base_prefix, spec_machine,
                            dir_separator_str);
  if (*tooldir_prefix != '/' && *tooldir_prefix != '\\')
    {
      if (gcc_exec_prefix)
 {
   char *gcc_exec_tooldir_prefix
     = concat6 (gcc_exec_prefix, spec_machine, dir_separator_str,
        spec_version, dir_separator_str, tooldir_prefix);

   add_prefix (&exec_prefixes,
        concat3 (gcc_exec_tooldir_prefix, "bin",
                               dir_separator_str),
        0, 0, ((void *)0));
   add_prefix (&startfile_prefixes,
        concat3 (gcc_exec_tooldir_prefix, "lib",
                               dir_separator_str),
        0, 0, ((void *)0));
 }

      tooldir_prefix = concat6 (standard_exec_prefix, spec_machine,
           dir_separator_str, spec_version,
                                dir_separator_str, tooldir_prefix);
    }

  add_prefix (&exec_prefixes,
              concat3 (tooldir_prefix, "bin", dir_separator_str),
       0, 0, ((void *)0));
  add_prefix (&startfile_prefixes,
       concat3 (tooldir_prefix, "lib", dir_separator_str),
       0, 0, ((void *)0));







  switches = ((struct n64_tag_switchstr *)
       xmalloc ((n_switches + 1) * sizeof (struct n64_tag_switchstr)));
  infiles = (struct n64_tag_infile *) xmalloc ((n_infiles + 1) * sizeof (struct n64_tag_infile));
  n_switches = 0;
  n_infiles = 0;
  last_language_n_infiles = -1;





  for (i = 1; i < argc; i++)
    {

      if (! strncmp (argv[i], "-Wa,", 4))
 ;
      else if (! strncmp (argv[i], "-Wp,", 4))
 ;
      else if (! strcmp (argv[i], "-print-search-dirs"))
 ;
      else if (! strcmp (argv[i], "-print-libgcc-file-name"))
 ;
      else if (! strncmp (argv[i], "-print-file-name=", 17))
 ;
      else if (! strncmp (argv[i], "-print-prog-name=", 17))
 ;
      else if (! strcmp (argv[i], "-print-multi-lib"))
 ;
      else if (! strcmp (argv[i], "-print-multi-directory"))
 ;
      else if (argv[i][0] == '+' && argv[i][1] == 'e')
 {





   switches[n_switches].part1 = &argv[i][0];
   switches[n_switches].args = 0;
   switches[n_switches].live_cond = 0;
   switches[n_switches].valid = 0;
   n_switches++;
 }
      else if (strncmp (argv[i], "-Wl,", 4) == 0)
 {
   int prev, j;

   prev = 4;
   for (j = 4; argv[i][j]; j++)
     if (argv[i][j] == ',')
       {
  infiles[n_infiles].language = 0;
  infiles[n_infiles++].name
    = save_string (argv[i] + prev, j - prev);
  prev = j + 1;
       }

   infiles[n_infiles].language = 0;
   infiles[n_infiles++].name = argv[i] + prev;
 }
      else if (strcmp (argv[i], "-Xlinker") == 0)
 {
   infiles[n_infiles].language = 0;
   infiles[n_infiles++].name = argv[++i];
 }
      else if (strncmp (argv[i], "-l", 2) == 0)
 {
   infiles[n_infiles].language = 0;
   infiles[n_infiles++].name = argv[i];
 }
      else if (argv[i][0] == '-' && argv[i][1] != 0)
 {
   register char *p = &argv[i][1];
   register int c = *p;

   if (c == 'B' || c == 'b' || c == 'V')
     {

       if (p[1] == 0)
  i++;
       continue;
     }
   if (c == 'x')
     {
       if (p[1] == 0 && i + 1 == argc)
  fatal ("argument to `-x' is missing");
       if (p[1] == 0)
  spec_lang = argv[++i];
       else
  spec_lang = p + 1;
       if (! strcmp (spec_lang, "none"))



  spec_lang = 0;
       else
  last_language_n_infiles = n_infiles;
       continue;
     }
   switches[n_switches].part1 = p;

   if ((((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') > (p[1] != 0))
       || ((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss")))
     {
       int j = 0;
       int n_args = ((!strcmp (p, "Tdata") || !strcmp (p, "Ttext") || !strcmp (p, "Tbss") || !strcmp (p, "include") || !strcmp (p, "imacros") || !strcmp (p, "aux-info") || !strcmp (p, "idirafter") || !strcmp (p, "iprefix") || !strcmp (p, "iwithprefix") || !strcmp (p, "iwithprefixbefore") || !strcmp (p, "isystem")) && strcmp (p, "Tdata") && strcmp (p, "Ttext") && strcmp (p, "Tbss"));

       if (n_args == 0)
  {

    n_args = ((c) == 'D' || (c) == 'U' || (c) == 'o' || (c) == 'e' || (c) == 'T' || (c) == 'u' || (c) == 'I' || (c) == 'm' || (c) == 'h' || (c) == 'z' || (c) == 'L' || (c) == 'A' || (c) == 'G') - (p[1] != 0);
  }
       if (i + n_args >= argc)
  fatal ("argument to `-%s' is missing", p);
       switches[n_switches].args
  = (char **) xmalloc ((n_args + 1) * sizeof (char *));
       while (j < n_args)
  switches[n_switches].args[j++] = argv[++i];

       switches[n_switches].args[j] = 0;
     }
   else if (*switches_need_spaces != 0 && (c == 'o' || c == 'L'))
     {


       switches[n_switches].part1 = (c == 'o' ? "o" : "L");
       switches[n_switches].args = (char **) xmalloc (2 * sizeof (char *));
       switches[n_switches].args[0] = xmalloc (strlen (p));
       strcpy (switches[n_switches].args[0], &p[1]);
       switches[n_switches].args[1] = 0;
     }
   else
     switches[n_switches].args = 0;

   switches[n_switches].live_cond = 0;
   switches[n_switches].valid = 0;

   if (!strcmp (p, "save-temps"))
     switches[n_switches].valid = 1;
   n_switches++;
 }
      else
 {


   if (strlen (argv[i]) > 2
       && argv[i][strlen (argv[i]) - 2] == '.'
       && argv[i][strlen (argv[i]) - 1] == 'o')
     {
       int j;

       for (j = 0; j < strlen (argv[i]) - 2; j++)
  __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (argv[i][j]); (void) 0; });

       __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (strlen (".obj")); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (".obj"),__len); __o->next_free += __len; } (void) 0; });
       __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (0); (void) 0; });
       argv[i] = __extension__ ({ struct n64_tag_obstack *__o1 = (&obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
     }


   if (strcmp (argv[i], "-") != 0 && access (argv[i], 
                                                     4
                                                         ) < 0)
     {
       perror_with_name (argv[i]);
       error_count++;
     }
   else
     {
       infiles[n_infiles].language = spec_lang;
       infiles[n_infiles++].name = argv[i];
     }
 }
    }

  if (n_infiles == last_language_n_infiles && spec_lang != 0)
    error ("Warning: `-x %s' after last input file has no effect", spec_lang);

  switches[n_switches].part1 = 0;
  infiles[n_infiles].name = 0;
}
static char *input_filename;
static int input_file_number;
static int input_filename_length;
static int basename_length;
static char *input_basename;
static char *input_suffix;





static int arg_going;



static int delete_this_arg;



static int this_is_output_file;




static int this_is_library_file;


static int input_from_pipe;




static int
do_spec(char *spec) asm("_do_spec");
static int
do_spec(char *spec)
{
  int value;

  clear_args ();
  arg_going = 0;
  delete_this_arg = 0;
  this_is_output_file = 0;
  this_is_library_file = 0;
  input_from_pipe = 0;

  value = do_spec_1 (spec, 0, ((void *)0));



  if (value == 0)
    {
      if (argbuf_index > 0 && !strcmp (argbuf[argbuf_index - 1], "|"))
 argbuf_index--;

      if (argbuf_index > 0)
 value = execute ();
    }

  return value;
}
static int
do_spec_1(char *spec, int inswitch, char *soft_matched_part) asm("_do_spec_1");
static int
do_spec_1(char *spec, int inswitch, char *soft_matched_part)
{
  register char *p = spec;
  register int c;
  int i;
  char *string;
  int value;

  while (c = *p++)


    switch (inswitch ? 'a' : c)
      {
      case '\n':


 if (arg_going)
   {
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (0); (void) 0; });
     string = __extension__ ({ struct n64_tag_obstack *__o1 = (&obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
     if (this_is_library_file)
       string = find_file (string);
     store_arg (string, delete_this_arg, this_is_output_file);
     if (this_is_output_file)
       outfiles[input_file_number] = string;
   }
 arg_going = 0;

 if (argbuf_index > 0 && !strcmp (argbuf[argbuf_index - 1], "|"))
   {
     for (i = 0; i < n_switches; i++)
       if (!strcmp (switches[i].part1, "pipe"))
  break;




     if (i < n_switches)
       {
  input_from_pipe = 1;
  switches[i].valid = 1;
  break;
       }
     else
       argbuf_index--;
   }

 if (argbuf_index > 0)
   {
     value = execute ();
     if (value)
       return value;
   }

 clear_args ();
 arg_going = 0;
 delete_this_arg = 0;
 this_is_output_file = 0;
 this_is_library_file = 0;
 input_from_pipe = 0;
 break;

      case '|':

 if (arg_going)
   {
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (0); (void) 0; });
     string = __extension__ ({ struct n64_tag_obstack *__o1 = (&obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
     if (this_is_library_file)
       string = find_file (string);
     store_arg (string, delete_this_arg, this_is_output_file);
     if (this_is_output_file)
       outfiles[input_file_number] = string;
   }


 __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
 arg_going = 1;
 break;

      case '\t':
      case ' ':

 if (arg_going)
   {
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (0); (void) 0; });
     string = __extension__ ({ struct n64_tag_obstack *__o1 = (&obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
     if (this_is_library_file)
       string = find_file (string);
     store_arg (string, delete_this_arg, this_is_output_file);
     if (this_is_output_file)
       outfiles[input_file_number] = string;
   }

 arg_going = 0;
 delete_this_arg = 0;
 this_is_output_file = 0;
 this_is_library_file = 0;
 break;

      case '%':
 switch (c = *p++)
   {
   case 0:
     fatal ("Invalid specification!  Bug in cc.");

   case 'b':
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (basename_length); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (input_basename),__len); __o->next_free += __len; } (void) 0; });
     arg_going = 1;
     break;

   case 'd':
     delete_this_arg = 2;
     break;




   case 'D':
     {
       struct n64_tag_prefix_list *pl = startfile_prefixes.plist;
       int bufsize = 100;
       char *buffer = (char *) xmalloc (bufsize);
       int idx;

       for (; pl; pl = pl->next)
  {
    if (multilib_dir != 
                       ((void *)0)
                           )
      {
        if (machine_suffix)
   {
     if (strlen (pl->prefix) + strlen (machine_suffix)
         >= bufsize)
       bufsize = (strlen (pl->prefix)
           + strlen (machine_suffix)) * 2 + 1;
     buffer = (char *) xrealloc (buffer, bufsize);
     strcpy (buffer, pl->prefix);
     strcat (buffer, machine_suffix);
     if (is_directory (buffer, multilib_dir, 1))
       {
         do_spec_1 ("-L", 0, ((void *)0));



         do_spec_1 (buffer, 1, ((void *)0));
         do_spec_1 (multilib_dir, 1, ((void *)0));

         do_spec_1 (" ", 0, ((void *)0));
       }
   }
        if (!pl->require_machine_suffix)
   {
     if (is_directory (pl->prefix, multilib_dir, 1))
       {
         do_spec_1 ("-L", 0, ((void *)0));



         do_spec_1 (pl->prefix, 1, ((void *)0));
         do_spec_1 (multilib_dir, 1, ((void *)0));

         do_spec_1 (" ", 0, ((void *)0));
       }
   }
      }
    if (machine_suffix)
      {
        if (is_directory (pl->prefix, machine_suffix, 1))
   {
     do_spec_1 ("-L", 0, ((void *)0));



     do_spec_1 (pl->prefix, 1, ((void *)0));

     if (strlen (machine_suffix) >= bufsize)
       bufsize = strlen (machine_suffix) * 2 + 1;
     buffer = (char *) xrealloc (buffer, bufsize);
     strcpy (buffer, machine_suffix);
     idx = strlen (buffer);
     if (buffer[idx - 1] == '/'
         || buffer[idx - 1] == '\\')
       buffer[idx - 1] = 0;
     do_spec_1 (buffer, 1, ((void *)0));

     do_spec_1 (" ", 0, ((void *)0));
   }
      }
    if (!pl->require_machine_suffix)
      {
        if (is_directory (pl->prefix, "", 1))
   {
     do_spec_1 ("-L", 0, ((void *)0));




     if (strlen (pl->prefix) >= bufsize)
       bufsize = strlen (pl->prefix) * 2 + 1;
     buffer = (char *) xrealloc (buffer, bufsize);
     strcpy (buffer, pl->prefix);
     idx = strlen (buffer);
     if (buffer[idx - 1] == '/'
         || buffer[idx - 1] == '\\')
       buffer[idx - 1] = 0;
     do_spec_1 (buffer, 1, ((void *)0));

     do_spec_1 (" ", 0, ((void *)0));
   }
      }
  }
       free (buffer);
     }
     break;

   case 'e':


     {
       char *q = p;
       char *buf;
       while (*p != 0 && *p != '\n') p++;
       buf = (char *) 
                     __builtin_alloca((
                     p - q + 1
                     ))
                                       ;
       strncpy (buf, q, p - q);
       buf[p - q] = 0;
       error ("%s", buf);
       return -1;
     }
     break;

   case 'g':
   case 'u':
   case 'U':
     if (save_temps_flag)
       {
  __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (basename_length); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (input_basename),__len); __o->next_free += __len; } (void) 0; });
  delete_this_arg = 0;
       }
     else
       {
  __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (temp_filename_length); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (temp_filename),__len); __o->next_free += __len; } (void) 0; });
  if (c == 'u' || c == 'U')
    {
      static int unique;
      char buff[9];
      if (c == 'u')
        unique++;
      sprintf (buff, "%d", unique);
      __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (strlen (buff)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (buff),__len); __o->next_free += __len; } (void) 0; });
    }

  delete_this_arg = 1;
       }
     arg_going = 1;
     break;

   case 'i':
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (input_filename_length); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (input_filename),__len); __o->next_free += __len; } (void) 0; });
     arg_going = 1;
     break;

   case 'I':
     {
       struct n64_tag_prefix_list *pl = include_prefixes.plist;

       if (gcc_exec_prefix)
  {
    do_spec_1 ("-iprefix", 1, ((void *)0));

    do_spec_1 (" ", 0, ((void *)0));
    do_spec_1 (gcc_exec_prefix, 1, ((void *)0));
    do_spec_1 (" ", 0, ((void *)0));
  }

       for (; pl; pl = pl->next)
  {
    do_spec_1 ("-isystem", 1, ((void *)0));

    do_spec_1 (" ", 0, ((void *)0));
    do_spec_1 (pl->prefix, 1, ((void *)0));
    do_spec_1 (" ", 0, ((void *)0));
  }
     }
     break;

   case 'o':
     for (i = 0; i < n_infiles; i++)
       store_arg (outfiles[i], 0, 0);
     break;

   case 'O':
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (strlen (".obj")); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (".obj"),__len); __o->next_free += __len; } (void) 0; });
     arg_going = 1;
     break;

   case 's':
     this_is_library_file = 1;
     break;

   case 'w':
     this_is_output_file = 1;
     break;

   case 'W':
     {
       int strchr = argbuf_index;

       if (*p != '{')
  abort ();
       p = handle_braces (p + 1);
       if (p == 0)
  return -1;


       if (argbuf_index != strchr)
  record_temp_file (argbuf[argbuf_index - 1], 0, 1);
       break;
     }


   case 'x':
     {
       char *p1 = p;
       char *string;


       if (*p != '{')
  abort ();
       while (*p++ != '}')
  ;
       string = save_string (p1 + 1, p - p1 - 2);


       for (i = 0; i < n_linker_options; i++)
  if (! strcmp (string, linker_options[i]))
    {
      free (string);
      return 0;
    }


       n_linker_options++;
       if (!linker_options)
  linker_options
    = (char **) xmalloc (n_linker_options * sizeof (char **));
       else
  linker_options
    = (char **) xrealloc (linker_options,
     n_linker_options * sizeof (char **));

       linker_options[n_linker_options - 1] = string;
     }
     break;


   case 'X':
     for (i = 0; i < n_linker_options; i++)
       {
  do_spec_1 (linker_options[i], 1, ((void *)0));

  do_spec_1 (" ", 0, ((void *)0));
       }
     break;


   case 'Y':
     for (i = 0; i < n_assembler_options; i++)
       {
  do_spec_1 (assembler_options[i], 1, ((void *)0));

  do_spec_1 (" ", 0, ((void *)0));
       }
     break;


   case 'Z':
     for (i = 0; i < n_preprocessor_options; i++)
       {
  do_spec_1 (preprocessor_options[i], 1, ((void *)0));

  do_spec_1 (" ", 0, ((void *)0));
       }
     break;




   case '1':
     value = do_spec_1 (cc1_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case '2':
     value = do_spec_1 (cc1plus_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'a':
     value = do_spec_1 (asm_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'A':
     value = do_spec_1 (asm_final_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'c':
     value = do_spec_1 (signed_char_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'C':
     value = do_spec_1 (cpp_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'E':
     value = do_spec_1 (endfile_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'l':
     value = do_spec_1 (link_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'L':
     value = do_spec_1 (lib_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'G':
     value = do_spec_1 (libgcc_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;

   case 'p':
     {
       char *x = (char *) 
                         __builtin_alloca((
                         strlen (cpp_predefines) + 1
                         ))
                                                             ;
       char *buf = x;
       char *y;


       y = cpp_predefines;
       while (*y != 0)
  {
    if (! strncmp (y, "-D", 2))

      while (*y && *y != ' ' && *y != '\t')
        *x++ = *y++;
    else if (*y == ' ' || *y == '\t')

      *x++ = *y++;

    else
      y++;
  }

       *x = 0;

       value = do_spec_1 (buf, 0, ((void *)0));
       if (value != 0)
  return value;
     }
     break;

   case 'P':
     {
       char *x = (char *) 
                         __builtin_alloca((
                         strlen (cpp_predefines) * 4 + 1
                         ))
                                                                 ;
       char *buf = x;
       char *y;



       y = cpp_predefines;
       while (*y != 0)
  {
    if (! strncmp (y, "-D", 2))
      {
        int flag = 0;

        *x++ = *y++;
        *x++ = *y++;

        if (*y != '_'
     || (*(y+1) != '_' && ! isupper (*(y+1))))
          {

     *x++ = '_';
     *x++ = '_';

     flag = 1;
   }


        while (*y && *y != '=' && *y != ' ' && *y != '\t')
   *x++ = *y++;

        if (flag)
          {
     *x++ = '_';
     *x++ = '_';
   }


        while (*y && *y != ' ' && *y != '\t')
   *x++ = *y++;
      }
    else if (*y == ' ' || *y == '\t')

      *x++ = *y++;

    else
      y++;
  }
       *x++ = ' ';



       y = cpp_predefines;
       while (*y != 0)
  {
    if (! strncmp (y, "-D", 2))
      {
        y += 2;

        if (*y != '_'
     || (*(y+1) != '_' && ! isupper (*(y+1))))
          {

     *x++ = '-';
     *x++ = 'D';
     *x++ = '_';
     *x++ = '_';


     while (*y && *y != '=' && *y != ' ' && *y != '\t')
       *x++ = *y++;


     while (*y && *y != ' ' && *y != '\t')
       *x++ = *y++;
   }
        else
   {

     while (*y && *y != ' ' && *y != '\t')
       y++;
   }
      }
    else if (*y == ' ' || *y == '\t')

      *x++ = *y++;

    else
      y++;
  }
       *x++ = ' ';


       y = cpp_predefines;
       while (*y != 0)
  {
    if (! strncmp (y, "-A", 2))

      while (*y && *y != ' ' && *y != '\t')
        *x++ = *y++;
    else if (*y == ' ' || *y == '\t')

      *x++ = *y++;

    else
      y++;
  }

       *x = 0;

       value = do_spec_1 (buf, 0, ((void *)0));
       if (value != 0)
  return value;
     }
     break;

   case 'S':
     value = do_spec_1 (startfile_spec, 0, ((void *)0));
     if (value != 0)
       return value;
     break;



   case '{':
     p = handle_braces (p);
     if (p == 0)
       return -1;
     break;

   case '%':
     __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('%'); (void) 0; });
     break;

   case '*':
     do_spec_1 (soft_matched_part, 1, ((void *)0));
     do_spec_1 (" ", 0, ((void *)0));
     break;






   case '(':
   case '[':
     {
       char *name = p;
       struct n64_tag_spec_list *sl;
       int len;



       while (*p && *p != ')' && *p != ']')
  p++;


       for (len = p - name, sl = specs; sl; sl = sl->next)
  if (strncmp (sl->name, name, len) == 0 && !sl->name[len])
    {
      name = sl->spec;
      break;
    }

       if (sl)
  {
    if (c == '(')
      {
        value = do_spec_1 (name, 0, ((void *)0));
        if (value != 0)
   return value;
      }
    else
      {
        char *x = (char *) 
                          __builtin_alloca((
                          strlen (name) * 2 + 1
                          ))
                                                        ;
        char *buf = x;
        char *y = name;



        while (1)
   {
     if (! strncmp (y, "-D", 2))
       {
         *x++ = '-';
         *x++ = 'D';
         *x++ = '_';
         *x++ = '_';
         y += 2;
       }
     else if (*y == ' ' || *y == 0)
       {
         *x++ = '_';
         *x++ = '_';
         if (*y == 0)
    break;
         else
    *x++ = *y++;
       }
     else
       *x++ = *y++;
   }
        *x = 0;

        value = do_spec_1 (buf, 0, ((void *)0));
        if (value != 0)
   return value;
      }
  }


       if (*p)
  p++;
     }
     break;

   case 'v':
     {
       int c1 = *p++;
       char *v = compiler_version;
       char *q, *copy;

       if (c1 == '2')
  {

    while (*v != 0 && *v != ' ' && *v != '.')
      v++;
    if (*v == '.')
      v++;
  }

       q = v;
       while (*q != 0 && *q != ' ' && *q != '.')
  q++;

       if (p == q)
  {
    v = "0";
    q = v + 1;
  }

       __extension__ ({ struct n64_tag_obstack *__o = (&obstack); int __len = (q - v); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (v),__len); __o->next_free += __len; } (void) 0; });
       arg_going = 1;
     }
     break;

   case '|':
     if (input_from_pipe)
       do_spec_1 ("-", 0, ((void *)0));
     break;

   default:
     abort ();
   }
 break;

      case '\\':

 c = *p++;


      default:

 __extension__ ({ struct n64_tag_obstack *__o = (&obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
 arg_going = 1;
      }

  return 0;
}



static char *
handle_braces(register char *p) asm("_handle_braces");
static char *
handle_braces(register char *p)
{
  register char *q;
  char *filter;
  int pipe = 0;
  int negate = 0;
  int suffix = 0;

  if (*p == '|')



    pipe = 1, ++p;

  if (*p == '!')


    negate = 1, ++p;

  if (*p == '.')

    {
      if (pipe)
 abort ();

      suffix = 1;
      ++p;
    }

  filter = p;
  while (*p != ':' && *p != '}') p++;
  if (*p != '}')
    {
      register int count = 1;
      q = p + 1;
      while (count > 0)
 {
   if (*q == '{')
     count++;
   else if (*q == '}')
     count--;
   else if (*q == 0)
     abort ();
   q++;
 }
    }
  else
    q = p + 1;

  if (suffix)
    {
      int found = (input_suffix != 0
     && strlen (input_suffix) == p - filter
     && strncmp (input_suffix, filter, p - filter) == 0);

      if (p[0] == '}')
 abort ();

      if (negate != found
   && do_spec_1 (save_string (p + 1, q - p - 2), 0, ((void *)0)) < 0)
 return 0;

      return q;
    }
  else if (p[-1] == '*' && p[0] == '}')
    {

      register int i;
      --p;
      for (i = 0; i < n_switches; i++)
 if (!strncmp (switches[i].part1, filter, p - filter)
     && check_live_switch (i, p - filter))
   give_switch (i, 0);
    }
  else
    {

      register int i;
      int present = 0;



      if (p[-1] == '*' && !negate)
 {
   int substitution;
   char *r = p;


   substitution = 0;
   while (r < q)
     {
       if (*r == '%' && r[1] == '*')
  substitution = 1;
       r++;
     }

   if (substitution)
     {




       unsigned hard_match_len = p - filter - 1;
       char *string = save_string (p + 1, q - p - 2);

       for (i = 0; i < n_switches; i++)
  if (!strncmp (switches[i].part1, filter, hard_match_len)
      && check_live_switch (i, -1))
    {
      do_spec_1 (string, 0, &switches[i].part1[hard_match_len]);

      give_switch (i, 1);
    }

       return q;
     }
 }



      if (p[-1] == '*')
 {
   for (i = 0; i < n_switches; i++)
     {
       unsigned hard_match_len = p - filter - 1;

       if (!strncmp (switches[i].part1, filter, hard_match_len)
    && check_live_switch (i, hard_match_len))
  {
    present = 1;
  }
     }
 }

      else
 {
   for (i = 0; i < n_switches; i++)
     {
       if (!strncmp (switches[i].part1, filter, p - filter)
    && switches[i].part1[p - filter] == 0
    && check_live_switch (i, -1))
  {
    present = 1;
    break;
  }
     }
 }




      if (present != negate)
 {
   if (*p == '}')
     {
       give_switch (i, 0);
     }
   else
     {
       if (do_spec_1 (save_string (p + 1, q - p - 2), 0, ((void *)0)) < 0)
  return 0;
     }
 }
      else if (pipe)
 {


   do_spec_1 ("-", 0, ((void *)0));
 }
    }

  return q;
}
static int
check_live_switch(int switchnum, int prefix_length) asm("_check_live_switch");
static int
check_live_switch(int switchnum, int prefix_length)
{
  char *name = switches[switchnum].part1;
  int i;




  if (prefix_length >= 0 && prefix_length <= 1)
    return 1;



  if (switches[switchnum].live_cond != 0)
    return switches[switchnum].live_cond > 0;


  switch (*name)
    {
    case 'O':
 for (i = switchnum + 1; i < n_switches; i++)
   if (switches[i].part1[0] == 'O')
     {
       switches[switchnum].valid = 1;
       switches[switchnum].live_cond = -1;
       return 0;
     }
      break;

    case 'W': case 'f': case 'm':
      if (! strncmp (name + 1, "no-", 3))
 {

   for (i = switchnum + 1; i < n_switches; i++)
     if (switches[i].part1[0] == name[0]
  && ! strcmp (&switches[i].part1[1], &name[4]))
     {
       switches[switchnum].valid = 1;
       switches[switchnum].live_cond = -1;
       return 0;
     }
 }
      else
 {

   for (i = switchnum + 1; i < n_switches; i++)
     if (switches[i].part1[0] == name[0]
  && switches[i].part1[1] == 'n'
  && switches[i].part1[2] == 'o'
  && switches[i].part1[3] == '-'
  && !strcmp (&switches[i].part1[4], &name[1]))
     {
       switches[switchnum].valid = 1;
       switches[switchnum].live_cond = -1;
       return 0;
     }
 }
      break;
    }


  switches[switchnum].live_cond = 1;
  return 1;
}
static void
give_switch(int switchnum, int omit_first_word) asm("_give_switch");
static void
give_switch(int switchnum, int omit_first_word)
{
  if (!omit_first_word)
    {
      do_spec_1 ("-", 0, ((void *)0));
      do_spec_1 (switches[switchnum].part1, 1, ((void *)0));
    }
  do_spec_1 (" ", 0, ((void *)0));
  if (switches[switchnum].args != 0)
    {
      char **p;
      for (p = switches[switchnum].args; *p; p++)
 {
   do_spec_1 (*p, 1, ((void *)0));
   do_spec_1 (" ", 0, ((void *)0));
 }
    }
  switches[switchnum].valid = 1;
}





static char *
find_file(char *name) asm("_find_file");
static char *
find_file(char *name)
{
  char *newname;


  if (multilib_dir != 
                     ((void *)0)
                         )
    {
      char *cxx_try;

      cxx_try = (char *) 
                    __builtin_alloca((
                    strlen (multilib_dir) + strlen (name) + 2
                    ))
                                                                      ;
      strcpy (cxx_try, multilib_dir);
      strcat (cxx_try, dir_separator_str);
      strcat (cxx_try, name);

      newname = find_a_file (&startfile_prefixes, cxx_try, 
                                                      4
                                                          );



      if (newname != 
                    ((void *)0)
                        )
 return newname;
    }

  newname = find_a_file (&startfile_prefixes, name, 
                                                   4
                                                       );
  return newname ? newname : name;
}






static int
is_directory(char *path1, char *path2, int linker) asm("_is_directory");
static int
is_directory(char *path1, char *path2, int linker)
{
  int len1 = strlen (path1);
  int len2 = strlen (path2);
  char *path = (char *) 
                       __builtin_alloca((
                       3 + len1 + len2
                       ))
                                               ;
  char *cp;
  struct stat st;


  if (! linker)
    return 1;





  memcpy (path,path1,len1);
  memcpy (path + len1,path2,len2);
  cp = path + len1 + len2;
  if (cp[-1] != '/' && cp[-1] != '\\')
    *cp++ = '\\';
  *cp++ = '.';
  *cp = '\0';


  if (linker
      && ((cp - path == 6
    && strcmp (path, concat4 (dir_separator_str, "lib",
                                     dir_separator_str, ".")) == 0)
   || (cp - path == 10
       && strcmp (path, concat6 (dir_separator_str, "usr",
                                        dir_separator_str, "lib",
                                        dir_separator_str, ".")) == 0)))
    return 0;

  return (stat (path, &st) >= 0 && (((st.st_mode)&
                                  0xF000
                                  ) == 
                                  0x4000
                                  ));
}



static void
fatal_error(int signum) asm("_fatal_error");
static void
fatal_error(int signum)
{
  signal (signum, 
                 (__p_sig_fn_t)0
                        );
  delete_failure_queue ();
  delete_temp_files ();


  raise(signum);
}

int
main(int argc, char **argv) asm("_main");
int
main(int argc, char **argv)
{
  register int i;
  int j;
  int value;
  int linker_was_run = 0;
  char *explicit_link_files;
  char *specs_file;
  char *p;

  p = argv[0] + strlen (argv[0]);
  while (p != argv[0] && p[-1] != '/' && p[-1] != '\\') --p;
  programname = p;

  if (signal (
             2
                   , 
                     (__p_sig_fn_t)1
                            ) != 
                                 (__p_sig_fn_t)1
                                        )
    signal (
           2
                 , fatal_error);




  if (signal (
             15
                    , 
                      (__p_sig_fn_t)1
                             ) != 
                                  (__p_sig_fn_t)1
                                         )
    signal (
           15
                  , fatal_error);





  argbuf_length = 10;
  argbuf = (char **) xmalloc (argbuf_length * sizeof (char *));

  _obstack_begin ((&obstack), 0, 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);




  _obstack_begin ((&collect_obstack), 0, 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);
  __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (sizeof ("COLLECT_GCC=")-1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("COLLECT_GCC="),__len); __o->next_free += __len; } (void) 0; });
  __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (strlen (argv[0])+1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (argv[0]),__len); __o->next_free += __len; } (void) 0; });
  putenv (__extension__ ({ struct n64_tag_obstack *__o1 = (&collect_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }));
  choose_temp_base ();





  process_command (argc, argv);




  compilers = (struct n64_tag_compiler *) xmalloc (sizeof default_compilers);
  memcpy ((char *) compilers,(char *) default_compilers,sizeof default_compilers)
                           ;
  n_compilers = n_default_compilers;



  machine_suffix = concat4 (spec_machine, dir_separator_str,
                            spec_version, dir_separator_str);
  just_machine_suffix = concat (spec_machine, dir_separator_str);

  specs_file = find_a_file (&startfile_prefixes, "specs", 
                                                         4
                                                             );

  if (specs_file != 0 && strcmp (specs_file, "specs"))
    read_specs (specs_file);





  if (!cross_compile)
    {
      if (*standard_startfile_prefix == '/'
   || *standard_startfile_prefix == '\\')
 add_prefix (&startfile_prefixes, standard_startfile_prefix, 0, 0,
      ((void *)0));
      else
 {
   if (gcc_exec_prefix)
     add_prefix (&startfile_prefixes,
   concat3 (gcc_exec_prefix, machine_suffix,
     standard_startfile_prefix),
   0, 0, ((void *)0));
   add_prefix (&startfile_prefixes,
        concat3 (standard_exec_prefix,
          machine_suffix,
          standard_startfile_prefix),
        0, 0, ((void *)0));
 }

      add_prefix (&startfile_prefixes, standard_startfile_prefix_1, 0, 0,
    ((void *)0));
      add_prefix (&startfile_prefixes, standard_startfile_prefix_2, 0, 0,
    ((void *)0));



    }
  else
    {
      if (*standard_startfile_prefix != '\\' && gcc_exec_prefix)
 add_prefix (&startfile_prefixes,
      concat3 (gcc_exec_prefix, machine_suffix,
        standard_startfile_prefix),
      0, 0, ((void *)0));
    }


  if (gcc_exec_prefix)
    {
      char * temp = (char *) xmalloc (strlen (gcc_exec_prefix)
          + strlen (spec_version)
          + strlen (spec_machine) + 3);
      strcpy (temp, gcc_exec_prefix);
      strcat (temp, spec_machine);
      strcat (temp, dir_separator_str);
      strcat (temp, spec_version);
      strcat (temp, dir_separator_str);
      gcc_exec_prefix = temp;
    }




  validate_all_switches ();



  set_multilib_dir ();



  for (i = 0; i < n_switches; i++)
    if (! switches[i].valid)
      error ("unrecognized option `-%s'", switches[i].part1);



  if (print_search_dirs)
    {
      printf ("install: %s%s\n", standard_exec_prefix, machine_suffix);
      printf ("programs: %s\n", build_search_list (&exec_prefixes, "", 0));
      printf ("libraries: %s\n", build_search_list (&startfile_prefixes, "", 0));
      exit (0);
    }

  if (print_file_name)
    {
      printf ("%s\n", find_file (print_file_name));
      exit (0);
    }

  if (print_prog_name)
    {
      char *newname = find_a_file (&exec_prefixes, print_prog_name, 
                                                                   1
                                                                       );
      printf ("%s\n", (newname ? newname : print_prog_name));
      exit (0);
    }

  if (print_multi_lib)
    {
      print_multilib_info ();
      exit (0);
    }

  if (print_multi_directory)
    {
      if (multilib_dir == 
                         ((void *)0)
                             )
 printf (".\n");
      else
 printf ("%s\n", multilib_dir);
      exit (0);
    }

  if (verbose_flag)
    {
      if (! strcmp (version_string, compiler_version))
 fprintf (
         (__acrt_iob_func(2))
               , "gcc version %s\n", version_string);
      else
 fprintf (
         (__acrt_iob_func(2))
               , "gcc driver version %s executing gcc version %s\n",
   version_string, compiler_version);

      if (n_infiles == 0)
 exit (0);
    }

  if (n_infiles == 0)
    fatal ("No input files");




  outfiles = (char **) xmalloc (n_infiles * sizeof (char *));
  memset ((char *) outfiles,0,n_infiles * sizeof (char *));



  explicit_link_files = xmalloc (n_infiles);
  memset (explicit_link_files,0,n_infiles);

  for (i = 0; i < n_infiles; i++)
    {
      register struct n64_tag_compiler *cp = 0;
      int this_file_error = 0;



      input_filename = infiles[i].name;
      input_filename_length = strlen (input_filename);
      input_file_number = i;



      outfiles[i] = input_filename;



      cp = lookup_compiler (infiles[i].name, input_filename_length,
       infiles[i].language);

      if (cp)
 {


   register char *p;
   int len;

   input_basename = input_filename;
   for (p = input_filename; *p; p++)
     if (*p == '/' || *p == '\\')
       input_basename = p + 1;



   basename_length = strlen (input_basename);
   p = input_basename + basename_length;
   while (p != input_basename && *p != '.') --p;
   if (*p == '.' && p != input_basename)
     {
       basename_length = p - input_basename;
       input_suffix = p + 1;
     }
   else
     input_suffix = "";

   len = 0;
   for (j = 0; j < sizeof cp->spec / sizeof cp->spec[0]; j++)
     if (cp->spec[j])
       len += strlen (cp->spec[j]);

   p = (char *) xmalloc (len + 1);

   len = 0;
   for (j = 0; j < sizeof cp->spec / sizeof cp->spec[0]; j++)
     if (cp->spec[j])
       {
  strcpy (p + len, cp->spec[j]);
  len += strlen (cp->spec[j]);
       }

   value = do_spec (p);
   free (p);
   if (value < 0)
     this_file_error = 1;
 }




      else
 explicit_link_files[i] = 1;




      if (this_file_error)
 {
   delete_failure_queue ();
   error_count++;
 }

      clear_failure_queue ();
    }



  if (error_count == 0)
    {
      int tmp = execution_count;
      int i;
      int first_time;



      putenv_from_prefixes (&exec_prefixes, "COMPILER_PATH=");
      putenv_from_prefixes (&startfile_prefixes, "LIBRARY_PATH=");



      __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (sizeof ("COLLECT_GCC_OPTIONS=")-1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("COLLECT_GCC_OPTIONS="),__len); __o->next_free += __len; } (void) 0; })
                                        ;

      first_time = 1;
      for (i = 0; i < n_switches; i++)
 {
   char **args;
   if (!first_time)
     __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (" "),__len); __o->next_free += __len; } (void) 0; });

   first_time = 0;
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("-"),__len); __o->next_free += __len; } (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (strlen (switches[i].part1)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (switches[i].part1),__len); __o->next_free += __len; } (void) 0; })
                              ;

   for (args = switches[i].args; args && *args; args++)
     {
       __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (" "),__len); __o->next_free += __len; } (void) 0; });
       __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (strlen (*args)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (*args),__len); __o->next_free += __len; } (void) 0; });
     }
 }
      __extension__ ({ struct n64_tag_obstack *__o = (&collect_obstack); int __len = (1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("\0"),__len); __o->next_free += __len; } (void) 0; });
      putenv (__extension__ ({ struct n64_tag_obstack *__o1 = (&collect_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }));

      value = do_spec (link_command_spec);
      if (value < 0)
 error_count = 1;
      linker_was_run = (tmp != execution_count);
    }


  unused_prefix_warnings (&exec_prefixes);
  unused_prefix_warnings (&startfile_prefixes);




  if (! linker_was_run && error_count == 0)
    for (i = 0; i < n_infiles; i++)
      if (explicit_link_files[i])
 error ("%s: linker input file unused since linking not done",
        outfiles[i]);



  if (error_count)
    delete_failure_queue ();
  delete_temp_files ();

  exit (error_count > 0 ? (signal_count ? 2 : 1) : 0);

  return 0;
}





static struct n64_tag_compiler *
lookup_compiler(char *name, int length, char *language) asm("_lookup_compiler");
static struct n64_tag_compiler *
lookup_compiler(char *name, int length, char *language)
{
  struct n64_tag_compiler *cp;


  if (language != 0)
    {
      for (cp = compilers + n_compilers - 1; cp >= compilers; cp--)
 {
   if (language != 0)
     {
       if (cp->suffix[0] == '@'
    && !strcmp (cp->suffix + 1, language))
  return cp;
     }
 }
      error ("language %s not recognized", language);
    }


  for (cp = compilers + n_compilers - 1; cp >= compilers; cp--)
    {
      if (
   (!strcmp (cp->suffix, "-") && !strcmp (name, "-"))
   ||
   (strlen (cp->suffix) < length
    && !strcmp (cp->suffix,
         name + length - strlen (cp->suffix))))

 {
   if (cp->spec[0][0] == '@')
     {
       struct n64_tag_compiler *cxx_new;




       language = cp->spec[0] + 1;
       cxx_new = (struct n64_tag_compiler *) xmalloc (sizeof (struct n64_tag_compiler));
       cxx_new->suffix = cp->suffix;
       memcpy ((char *) cxx_new->spec,(char *) lookup_compiler (((void *)0), 0, language)->spec,sizeof cxx_new->spec)
                                            ;
       return cxx_new;
     }

   return cp;
 }
    }

  return 0;
}

char *
xmalloc(unsigned int size) asm("_xmalloc");
char *
xmalloc(unsigned int size)
{
  register char *value = (char *) malloc (size);
  if (value == 0)
    fatal ("virtual memory exhausted");
  return value;
}

char *
xrealloc(char *ptr, unsigned int size) asm("_xrealloc");
char *
xrealloc(char *ptr, unsigned int size)
{
  register char *value = (char *) realloc (ptr, size);
  if (value == 0)
    fatal ("virtual memory exhausted");
  return value;
}



static char *
concat(char *s1, char *s2) asm("_concat");
static char *
concat(char *s1, char *s2)
{
  int len1 = strlen (s1);
  int len2 = strlen (s2);
  char *result = xmalloc (len1 + len2 + 1);

  strcpy (result, s1);
  strcpy (result + len1, s2);
  *(result + len1 + len2) = 0;

  return result;
}

static char *
concat3(char *s1, char *s2, char *s3) asm("_concat3");
static char *
concat3(char *s1, char *s2, char *s3)
{
  return concat (concat (s1, s2), s3);
}

static char *
concat4(char *s1, char *s2, char *s3, char *s4) asm("_concat4");
static char *
concat4(char *s1, char *s2, char *s3, char *s4)
{
  return concat (concat (s1, s2), concat (s3, s4));
}

static char *
concat6(char *s1, char *s2, char *s3, char *s4, char *s5, char *s6) asm("_concat6");
static char *
concat6(char *s1, char *s2, char *s3, char *s4, char *s5, char *s6)
{
  return concat3 (concat (s1, s2), concat (s3, s4), concat (s5, s6));
}

static char *
save_string(char *s, int len) asm("_save_string");
static char *
save_string(char *s, int len)
{
  register char *result = xmalloc (len + 1);

  memcpy (result,s,len);
  result[len] = 0;
  return result;
}

static void
pfatal_with_name(char *name) asm("_pfatal_with_name");
static void
pfatal_with_name(char *name)
{
  fatal ("%s: %s", name, strerror (
                                  (*_errno())
                                       ));
}

static void
perror_with_name(char *name) asm("_perror_with_name");
static void
perror_with_name(char *name)
{
  error ("%s: %s", name, strerror (
                                  (*_errno())
                                       ));
}

static void
perror_exec(char *name) asm("_perror_exec");
static void
perror_exec(char *name)
{
  char *s;

  s = concat ("installation problem, cannot exec `%s': ", strerror (
                                                                   (*_errno())
                                                                        ));
  error (s, name);
}




void
fancy_abort(void) asm("_fancy_abort");
void
fancy_abort(void)
{
  fatal ("Internal gcc abort.");
}





static void
fatal (char *format, ...) asm("_fatal");
static void
fatal (char *format, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 format
 )
                      ;





  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", programname);
  vfprintf (
           (__acrt_iob_func(2))
                 , format, ap);
  
 __builtin_va_end(
 ap
 )
            ;
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  delete_temp_files ();
  exit (1);
}

static void
error (char *format, ...) asm("_error");
static void
error (char *format, ...)
{



  va_list ap;

  
 __builtin_va_start(
 ap
 ,
 format
 )
                      ;





  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", programname);
  vfprintf (
           (__acrt_iob_func(2))
                 , format, ap);
  
 __builtin_va_end(
 ap
 )
            ;

  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}
static void
validate_all_switches(void) asm("_validate_all_switches");
static void
validate_all_switches(void)
{
  struct n64_tag_compiler *comp;
  register char *p;
  register char c;
  struct n64_tag_spec_list *spec;

  for (comp = compilers; comp->spec[0]; comp++)
    {
      int i;
      for (i = 0; i < sizeof comp->spec / sizeof comp->spec[0] && comp->spec[i]; i++)
 {
   p = comp->spec[i];
   while (c = *p++)
     if (c == '%' && *p == '{')

       validate_switches (p + 1);
 }
    }


  for (spec = specs; spec ; spec = spec->next)
    {
      p = spec->spec;
      while (c = *p++)
 if (c == '%' && *p == '{')

   validate_switches (p + 1);
    }

  p = link_command_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);



  p = asm_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = asm_final_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = cpp_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = signed_char_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = cc1_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = cc1plus_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = link_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = lib_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = libgcc_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);

  p = startfile_spec;
  while (c = *p++)
    if (c == '%' && *p == '{')

      validate_switches (p + 1);
}




static void
validate_switches(char *start) asm("_validate_switches");
static void
validate_switches(char *start)
{
  register char *p = start;
  char *filter;
  register int i;
  int suffix = 0;

  if (*p == '|')
    ++p;

  if (*p == '!')
    ++p;

  if (*p == '.')
    suffix = 1, ++p;

  filter = p;
  while (*p != ':' && *p != '}') p++;

  if (suffix)
    ;
  else if (p[-1] == '*')
    {

      --p;
      for (i = 0; i < n_switches; i++)
 if (!strncmp (switches[i].part1, filter, p - filter))
   switches[i].valid = 1;
    }
  else
    {

      for (i = 0; i < n_switches; i++)
 {
   if (!strncmp (switches[i].part1, filter, p - filter)
       && switches[i].part1[p - filter] == 0)
     switches[i].valid = 1;
 }
    }
}



static int
used_arg(char *p, int len) asm("_used_arg");
static int
used_arg(char *p, int len)
{
  int i;

  for (i = 0; i < n_switches; i++)
    if (! strncmp (switches[i].part1, p, len)
 && strlen (switches[i].part1) == len)
      return 1;
  return 0;
}







static char *multilib_defaults[] = { "EB", "mips1" };

static int
default_arg(char *p, int len) asm("_default_arg");
static int
default_arg(char *p, int len)
{
  int count = sizeof multilib_defaults / sizeof multilib_defaults[0];
  int i;

  for (i = 0; i < count; i++)
    if (multilib_defaults[i] != 
                               ((void *)0)
 
&& strncmp (multilib_defaults[i], p, len) == 0
 && multilib_defaults[i][len] == '\0')
      return 1;

  return 0;
}
static void
set_multilib_dir(void) asm("_set_multilib_dir");
static void
set_multilib_dir(void)
{
  char *p = multilib_select;
  int this_path_len;
  char *this_path, *this_arg;
  int not_arg;
  int ok;

  while (*p != '\0')
    {

      if (*p == '\n')
 {
   ++p;
   continue;
 }


      this_path = p;
      while (*p != ' ')
 {
   if (*p == '\0')
     abort ();
   ++p;
 }
      this_path_len = p - this_path;


      ok = 1;
      ++p;
      while (*p != ';')
 {
   if (*p == '\0')
     abort ();

   if (! ok)
     {
       ++p;
       continue;
     }

   this_arg = p;
   while (*p != ' ' && *p != ';')
     {
       if (*p == '\0')
  abort ();
       ++p;
     }

   if (*this_arg != '!')
     not_arg = 0;
   else
     {
       not_arg = 1;
       ++this_arg;
     }
   if (! default_arg (this_arg, p - this_arg))
     {
       ok = used_arg (this_arg, p - this_arg);
       if (not_arg)
  ok = ! ok;
     }

   if (*p == ' ')
     ++p;
 }

      if (ok)
 {
   if (this_path_len != 1
       || this_path[0] != '.')
     {
       multilib_dir = xmalloc (this_path_len + 1);
       strncpy (multilib_dir, this_path, this_path_len);
       multilib_dir[this_path_len] = '\0';
     }
   break;
 }

      ++p;
    }
}
static void
print_multilib_info(void) asm("_print_multilib_info");
static void
print_multilib_info(void)
{
  char *p = multilib_select;
  char *last_path = 0, *this_path;
  int skip;
  int last_path_len = 0;

  while (*p != '\0')
    {

      if (*p == '\n')
 {
   ++p;
   continue;
 }


      this_path = p;
      while (*p != ' ')
 {
   if (*p == '\0')
     abort ();
   ++p;
 }


      skip = (last_path != 0 && p - this_path == last_path_len
       && ! strncmp (last_path, this_path, last_path_len));

      last_path = this_path;
      last_path_len = p - this_path;




      if (! skip)
 {
   char *q;

   q = p + 1;
   while (*q != ';')
     {
       char *arg;

       if (*q == '\0')
  abort ();

       if (*q == '!')
  arg = 
       ((void *)0)
           ;
       else
  arg = q;

       while (*q != ' ' && *q != ';')
  {
    if (*q == '\0')
      abort ();
    ++q;
  }

       if (arg != 
                 ((void *)0)
    
   && default_arg (arg, q - arg))
  {
    skip = 1;
    break;
  }

       if (*q == ' ')
  ++q;
     }
 }

      if (! skip)
 {
   char *p1;

   for (p1 = last_path; p1 < p; p1++)
     putchar (*p1);
   putchar (';');
 }

      ++p;
      while (*p != ';')
 {
   int use_arg;

   if (*p == '\0')
     abort ();

   if (skip)
     {
       ++p;
       continue;
     }

   use_arg = *p != '!';

   if (use_arg)
     putchar ('@');

   while (*p != ' ' && *p != ';')
     {
       if (*p == '\0')
  abort ();
       if (use_arg)
  putchar (*p);
       ++p;
     }

   if (*p == ' ')
     ++p;
 }

      if (! skip)
 putchar ('\n');

      ++p;
    }
}

