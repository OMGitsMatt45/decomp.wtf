// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/floatformat.c
/* IEEE floating point support routines, for GDB, the GNU Debugger.
   Copyright (C) 1991, 1994 Free Software Foundation, Inc.

This file is part of GDB.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_floatformat;







enum n64_cpp_enum_floatformat_byteorders{ floatformat_little, floatformat_big };
typedef __underlying_type(enum n64_cpp_enum_floatformat_byteorders) n64_enum_floatformat_byteorders;


enum n64_cpp_enum_floatformat_intbit{ floatformat_intbit_yes, floatformat_intbit_no };
typedef __underlying_type(enum n64_cpp_enum_floatformat_intbit) n64_enum_floatformat_intbit;


struct n64_tag_floatformat
{
  n64_enum_floatformat_byteorders byteorder;
  unsigned int totalsize;


  unsigned int sign_start;

  unsigned int exp_start;
  unsigned int exp_len;

  unsigned int exp_bias;



  unsigned int exp_nan;

  unsigned int man_start;
  unsigned int man_len;


  n64_enum_floatformat_intbit intbit;
};



extern const struct n64_tag_floatformat floatformat_ieee_single_big;
extern const struct n64_tag_floatformat floatformat_ieee_single_little;
extern const struct n64_tag_floatformat floatformat_ieee_double_big;
extern const struct n64_tag_floatformat floatformat_ieee_double_little;



extern const struct n64_tag_floatformat floatformat_i387_ext;
extern const struct n64_tag_floatformat floatformat_m68881_ext;
extern const struct n64_tag_floatformat floatformat_i960_ext;
extern const struct n64_tag_floatformat floatformat_m88110_ext;
extern const struct n64_tag_floatformat floatformat_arm_ext;





extern void
floatformat_to_double (const struct n64_tag_floatformat *, char *, double *) asm("_floatformat_to_double");




extern void
floatformat_from_double (const struct n64_tag_floatformat *, double *, char *) asm("_floatformat_from_double")
                       ;


extern void *memcpy (void *s1, const void *s2, size_t n) asm("_memcpy");
extern void *memset (void *s, int c, size_t n) asm("_memset");
extern const struct n64_tag_floatformat floatformat_ieee_single_big =
{
  floatformat_big, 32, 0, 1, 8, 127, 255, 9, 23, floatformat_intbit_no
};
extern const struct n64_tag_floatformat floatformat_ieee_single_little =
{
  floatformat_little, 32, 0, 1, 8, 127, 255, 9, 23, floatformat_intbit_no
};
extern const struct n64_tag_floatformat floatformat_ieee_double_big =
{
  floatformat_big, 64, 0, 1, 11, 1023, 2047, 12, 52, floatformat_intbit_no
};
extern const struct n64_tag_floatformat floatformat_ieee_double_little =
{
  floatformat_little, 64, 0, 1, 11, 1023, 2047, 12, 52, floatformat_intbit_no
};

extern const struct n64_tag_floatformat floatformat_i387_ext =
{
  floatformat_little, 80, 0, 1, 15, 0x3fff, 0x7fff, 16, 64,
  floatformat_intbit_yes
};
extern const struct n64_tag_floatformat floatformat_m68881_ext =
{

  floatformat_big, 96, 0, 1, 15, 0x3fff, 0x7fff, 32, 64, floatformat_intbit_yes
};
extern const struct n64_tag_floatformat floatformat_i960_ext =
{

  floatformat_little, 96, 16, 17, 15, 0x3fff, 0x7fff, 32, 64,
  floatformat_intbit_yes
};
extern const struct n64_tag_floatformat floatformat_m88110_ext =
{






  floatformat_big, 80, 0, 1, 15, 0x3fff, 0x7fff, 16, 64,
  floatformat_intbit_yes

};
extern const struct n64_tag_floatformat floatformat_arm_ext =
{

  floatformat_big, 96, 0, 17, 15, 0x3fff, 0x7fff, 32, 64,
  floatformat_intbit_yes
};

static unsigned long get_field (unsigned char *, n64_enum_floatformat_byteorders, unsigned int, unsigned int, unsigned int) asm("_get_field")



                   ;



static unsigned long
get_field(unsigned char *data, n64_enum_floatformat_byteorders order, unsigned int total_len, unsigned int start, unsigned int len) asm("_get_field");
static unsigned long
get_field(unsigned char *data, n64_enum_floatformat_byteorders order, unsigned int total_len, unsigned int start, unsigned int len)
{
  unsigned long result;
  unsigned int cur_byte;
  int cur_bitshift;


  cur_byte = (start + len) / 8;
  if (order == floatformat_little)
    cur_byte = (total_len / 8) - cur_byte - 1;
  cur_bitshift =
    ((start + len) % 8) - 8;
  result = *(data + cur_byte) >> (-cur_bitshift);
  cur_bitshift += 8;
  if (order == floatformat_little)
    ++cur_byte;
  else
    --cur_byte;


  while (cur_bitshift < len)
    {
      if (len - cur_bitshift < 8)


 result |=
   (*(data + cur_byte) & ((1 << (len - cur_bitshift)) - 1))
     << cur_bitshift;
      else
 result |= *(data + cur_byte) << cur_bitshift;
      cur_bitshift += 8;
      if (order == floatformat_little)
 ++cur_byte;
      else
 --cur_byte;
    }
  return result;
}





void
floatformat_to_double(const struct n64_tag_floatformat *fmt, char *from, double *to) asm("_floatformat_to_double");
void
floatformat_to_double(const struct n64_tag_floatformat *fmt, char *from, double *to)
{
  unsigned char *ufrom = (unsigned char *)from;
  double dto;
  long exponent;
  unsigned long mant;
  unsigned int mant_bits, mant_off;
  int mant_bits_left;

  exponent = get_field (ufrom, fmt->byteorder, fmt->totalsize,
   fmt->exp_start, fmt->exp_len);




  mant_bits_left = fmt->man_len;
  mant_off = fmt->man_start;
  dto = 0.0;
  exponent -= fmt->exp_bias;



  while (mant_bits_left > 0)
    {
      int exp_bits;
      exp_bits = mant_bits_left < 32 ? mant_bits_left : 32;
      if (mant_bits_left == fmt->man_len
   && exp_bits == 32
   && fmt->intbit == floatformat_intbit_no)
 {


   mant_bits = 31;
 }
      else
 mant_bits = exp_bits;

      mant = get_field (ufrom, fmt->byteorder, fmt->totalsize,
   mant_off, mant_bits);
      if (mant_bits_left == fmt->man_len)
 mant |= 0x80000000;
      dto += ldexp ((double)mant, exponent - (exp_bits - 1));
      exponent -= exp_bits;
      mant_off += mant_bits;
      mant_bits_left -= mant_bits;
    }


  if (get_field (ufrom, fmt->byteorder, fmt->totalsize, fmt->sign_start, 1))
    dto = -dto;
  memcpy (to, &dto, sizeof (dto));
}

static void put_field (unsigned char *, n64_enum_floatformat_byteorders, unsigned int, unsigned int, unsigned int, unsigned long) asm("_put_field")



                         ;



static void
put_field(unsigned char *data, n64_enum_floatformat_byteorders order, unsigned int total_len, unsigned int start, unsigned int len, long unsigned int stuff_to_put) asm("_put_field");
static void
put_field(unsigned char *data, n64_enum_floatformat_byteorders order, unsigned int total_len, unsigned int start, unsigned int len, long unsigned int stuff_to_put)
{
  unsigned int cur_byte;
  int cur_bitshift;


  cur_byte = (start + len) / 8;
  if (order == floatformat_little)
    cur_byte = (total_len / 8) - cur_byte - 1;
  cur_bitshift =
    ((start + len) % 8) - 8;
  *(data + cur_byte) &=
    ~(((1 << ((start + len) % 8)) - 1) << (-cur_bitshift));
  *(data + cur_byte) |=
    (stuff_to_put & ((1 << 8) - 1)) << (-cur_bitshift);
  cur_bitshift += 8;
  if (order == floatformat_little)
    ++cur_byte;
  else
    --cur_byte;


  while (cur_bitshift < len)
    {
      if (len - cur_bitshift < 8)
 {

   *(data + cur_byte) &=
     ~((1 << (len - cur_bitshift)) - 1);
   *(data + cur_byte) |= (stuff_to_put >> cur_bitshift);
 }
      else
 *(data + cur_byte) = ((stuff_to_put >> cur_bitshift)
         & ((1 << 8) - 1));
      cur_bitshift += 8;
      if (order == floatformat_little)
 ++cur_byte;
      else
 --cur_byte;
    }
}





void
floatformat_from_double(const struct n64_tag_floatformat *fmt, double *from, char *to) asm("_floatformat_from_double");
void
floatformat_from_double(const struct n64_tag_floatformat *fmt, double *from, char *to)
{
  double dfrom;
  int exponent;
  double mant;
  unsigned int mant_bits, mant_off;
  int mant_bits_left;
  unsigned char *uto = (unsigned char *)to;

  memcpy (&dfrom, from, sizeof (dfrom));
  memset (uto, 0, fmt->totalsize / 8);
  if (dfrom == 0)
    return;
  if (dfrom != dfrom)
    {

      put_field (uto, fmt->byteorder, fmt->totalsize, fmt->exp_start,
   fmt->exp_len, fmt->exp_nan);

      put_field (uto, fmt->byteorder, fmt->totalsize, fmt->man_start,
   32, 1);
      return;
    }


  if (dfrom < 0)
    {
      put_field (uto, fmt->byteorder, fmt->totalsize, fmt->sign_start, 1, 1);
      dfrom = -dfrom;
    }



  mant = frexp (dfrom, &exponent);
  put_field (uto, fmt->byteorder, fmt->totalsize, fmt->exp_start, fmt->exp_len,
      exponent + fmt->exp_bias - 1);

  mant_bits_left = fmt->man_len;
  mant_off = fmt->man_start;
  while (mant_bits_left > 0)
    {
      unsigned long mant_long;
      mant_bits = mant_bits_left < 32 ? mant_bits_left : 32;

      mant *= 4294967296.0;
      mant_long = (unsigned long)mant;
      mant -= mant_long;





      if (mant_bits_left == fmt->man_len
   && fmt->intbit == floatformat_intbit_no)
 {
   mant_long &= 0x7fffffff;
   mant_bits -= 1;
 }
      else if (mant_bits < 32)
 {


   mant_long >>= 32 - mant_bits;
 }

      put_field (uto, fmt->byteorder, fmt->totalsize,
   mant_off, mant_bits, mant_long);
      mant_off += mant_bits;
      mant_bits_left -= mant_bits;
    }
}

