// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/regclass.c
/* Compute register class preferences for pseudo-registers.
   Copyright (C) 1987, 88, 91, 92, 93, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int reg_class_subset_p(...) asm("_reg_class_subset_p");
extern int warning(...) asm("_warning");
extern int decode_reg_name(...) asm("_decode_reg_name");
extern int init_recog(...) asm("_init_recog");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int reg_fits_class_p(...) asm("_reg_fits_class_p");
struct n64_tag_costs;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern rtx reload_in[(2 * 10 * (1 + 1))];
extern rtx reload_out[(2 * 10 * (1 + 1))];
extern rtx reload_in_reg[(2 * 10 * (1 + 1))];
extern n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
extern char reload_optional[(2 * 10 * (1 + 1))];
extern int reload_inc[(2 * 10 * (1 + 1))];
extern int reload_opnum[(2 * 10 * (1 + 1))];
extern int reload_secondary_p[(2 * 10 * (1 + 1))];
extern int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
extern int reload_secondary_out_reload[(2 * 10 * (1 + 1))];




extern int n_reloads;

extern rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
enum n64_cpp_enum_reload_type{
  RELOAD_FOR_INPUT, RELOAD_FOR_OUTPUT, RELOAD_FOR_INSN,
  RELOAD_FOR_INPUT_ADDRESS, RELOAD_FOR_OUTPUT_ADDRESS,
  RELOAD_FOR_OPERAND_ADDRESS, RELOAD_FOR_OPADDR_ADDR,
  RELOAD_OTHER, RELOAD_FOR_OTHER_ADDRESS
};
typedef __underlying_type(enum n64_cpp_enum_reload_type) n64_enum_reload_type;


extern n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];

extern rtx *reg_equiv_constant;
extern rtx *reg_equiv_memory_loc;
extern rtx *reg_equiv_address;
extern rtx *reg_equiv_mem;



extern int n_earlyclobbers;
extern rtx reload_earlyclobbers[10];


extern int reload_n_operands;



extern int reload_first_uid;





extern char indirect_symref_ok;


extern char double_reg_address_ok;
extern rtx get_secondary_mem (rtx, n64_enum_machine_mode, int, n64_enum_reload_type) asm("_get_secondary_mem")
                               ;


extern void clear_secondary_mem (void) asm("_clear_secondary_mem");



extern void transfer_replacements (int, int) asm("_transfer_replacements");




extern int strict_memory_address_p (n64_enum_machine_mode, rtx) asm("_strict_memory_address_p");




extern int operands_match_p (rtx, rtx) asm("_operands_match_p");


extern int n_occurrences (int, char *) asm("_n_occurrences");


extern int safe_from_earlyclobber (rtx, rtx) asm("_safe_from_earlyclobber");




extern void find_reloads (rtx, int, int, int, short *) asm("_find_reloads");





extern rtx form_sum (rtx, rtx) asm("_form_sum");



extern void subst_reloads (void) asm("_subst_reloads");




extern void copy_replacements (rtx, rtx) asm("_copy_replacements");



extern rtx find_replacement (rtx *) asm("_find_replacement");




extern int refers_to_regno_for_reload_p (int, int, rtx, rtx *) asm("_refers_to_regno_for_reload_p");


extern int reg_overlap_mentioned_for_reload_p (rtx, rtx) asm("_reg_overlap_mentioned_for_reload_p");



extern int refers_to_mem_for_reload_p (rtx) asm("_refers_to_mem_for_reload_p");



extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg")
                             ;


extern int regno_clobbered_p (int, rtx) asm("_regno_clobbered_p");





extern void init_reload (void) asm("_init_reload");


extern int reload(...) asm("_reload");



extern void mark_home_live (int) asm("_mark_home_live");



extern rtx eliminate_regs (rtx, n64_enum_machine_mode, rtx) asm("_eliminate_regs");




extern rtx gen_reload (rtx, rtx, int, n64_enum_reload_type) asm("_gen_reload");




extern void init_caller_save (void) asm("_init_caller_save");


extern void init_save_areas (void) asm("_init_save_areas");


extern int setup_save_areas (int *) asm("_setup_save_areas");


extern void save_call_clobbered_regs (n64_enum_machine_mode) asm("_save_call_clobbered_regs");

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");
char fixed_regs[68];



HARD_REG_SET fixed_reg_set;



static char initial_fixed_regs[] = { 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };






char call_used_regs[68];



HARD_REG_SET call_used_reg_set;



static char initial_call_used_regs[] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 };







char call_fixed_regs[68];



HARD_REG_SET call_fixed_reg_set;



int n_non_fixed_regs;






char global_regs[68];
HARD_REG_SET reg_class_contents[(int) LIM_REG_CLASSES];
static unsigned int_reg_class_contents[(int) LIM_REG_CLASSES][((68 + (32 - 1)) / 32)]
  = { { 0x00000000, 0x00000000, 0x00000000 }, { 0xffffffff, 0x00000000, 0x00000000 }, { 0x00000000, 0xffffffff, 0x00000000 }, { 0x00000000, 0x00000000, 0x00000001 }, { 0x00000000, 0x00000000, 0x00000002 }, { 0x00000000, 0x00000000, 0x00000004 }, { 0x00000000, 0x00000000, 0x00000003 }, { 0x00000000, 0x00000000, 0x00000008 }, { 0xffffffff, 0xffffffff, 0x0000000f } };



int reg_class_size[(int) LIM_REG_CLASSES];



n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



char *reg_names[] = { &mips_reg_names[ 0][0], &mips_reg_names[ 1][0], &mips_reg_names[ 2][0], &mips_reg_names[ 3][0], &mips_reg_names[ 4][0], &mips_reg_names[ 5][0], &mips_reg_names[ 6][0], &mips_reg_names[ 7][0], &mips_reg_names[ 8][0], &mips_reg_names[ 9][0], &mips_reg_names[10][0], &mips_reg_names[11][0], &mips_reg_names[12][0], &mips_reg_names[13][0], &mips_reg_names[14][0], &mips_reg_names[15][0], &mips_reg_names[16][0], &mips_reg_names[17][0], &mips_reg_names[18][0], &mips_reg_names[19][0], &mips_reg_names[20][0], &mips_reg_names[21][0], &mips_reg_names[22][0], &mips_reg_names[23][0], &mips_reg_names[24][0], &mips_reg_names[25][0], &mips_reg_names[26][0], &mips_reg_names[27][0], &mips_reg_names[28][0], &mips_reg_names[29][0], &mips_reg_names[30][0], &mips_reg_names[31][0], &mips_reg_names[32][0], &mips_reg_names[33][0], &mips_reg_names[34][0], &mips_reg_names[35][0], &mips_reg_names[36][0], &mips_reg_names[37][0], &mips_reg_names[38][0], &mips_reg_names[39][0], &mips_reg_names[40][0], &mips_reg_names[41][0], &mips_reg_names[42][0], &mips_reg_names[43][0], &mips_reg_names[44][0], &mips_reg_names[45][0], &mips_reg_names[46][0], &mips_reg_names[47][0], &mips_reg_names[48][0], &mips_reg_names[49][0], &mips_reg_names[50][0], &mips_reg_names[51][0], &mips_reg_names[52][0], &mips_reg_names[53][0], &mips_reg_names[54][0], &mips_reg_names[55][0], &mips_reg_names[56][0], &mips_reg_names[57][0], &mips_reg_names[58][0], &mips_reg_names[59][0], &mips_reg_names[60][0], &mips_reg_names[61][0], &mips_reg_names[62][0], &mips_reg_names[63][0], &mips_reg_names[64][0], &mips_reg_names[65][0], &mips_reg_names[66][0], &mips_reg_names[67][0], };






n64_enum_machine_mode reg_raw_mode[68];
short *reg_n_sets;




static int move_cost[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




static int may_move_cost[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];
void
init_reg_sets(void) asm("_init_reg_sets");
void
init_reg_sets(void)
{
  register int i, j;




  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    {
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reg_class_contents[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

      for (j = 0; j < 68; j++)
 if (int_reg_class_contents[i][j / 32]
     & ((unsigned) 1 << (j % 32)))
   ((reg_class_contents[i])[(j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)));
    }

  memcpy (fixed_regs,initial_fixed_regs,sizeof fixed_regs);
  memcpy (call_used_regs,initial_call_used_regs,sizeof call_used_regs);
  memset (global_regs,0,sizeof global_regs);



  memset ((char *) reg_class_size,0,sizeof reg_class_size);
  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    for (j = 0; j < 68; j++)
      if (((reg_class_contents[i])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)))))
 reg_class_size[i]++;





  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    {
      for (j = 0; j < (int) LIM_REG_CLASSES; j++)
 {



     HARD_REG_SET c;
   register int k;

   do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[j]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
   for (k = 0; k < (int) LIM_REG_CLASSES; k++)
     {
       do { register HARD_REG_ELT_TYPE *scan_xp_ = (reg_class_contents[k]), *scan_yp_ = (c); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto subclass1; } while (0)
                   ;
       continue;

     subclass1:

       do { register HARD_REG_ELT_TYPE *scan_xp_ = (reg_class_contents[k]), *scan_yp_ = (reg_class_contents[(int) reg_class_subunion[i][j]]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto subclass2; } while (0)

                   ;
       reg_class_subunion[i][j] = (n64_enum_reg_class) k;
     subclass2:
       ;
     }
 }
    }





  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    {
      for (j = 0; j < (int) LIM_REG_CLASSES; j++)
 {



     HARD_REG_SET c;
   register int k;

   do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[j]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
   for (k = 0; k < (int) LIM_REG_CLASSES; k++)
     do { register HARD_REG_ELT_TYPE *scan_xp_ = (c), *scan_yp_ = (reg_class_contents[k]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto superclass; } while (0);

 superclass:
   reg_class_superunion[i][j] = (n64_enum_reg_class) k;
 }
    }




  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    {
      for (j = 0; j < (int) LIM_REG_CLASSES; j++)
 {
   reg_class_superclasses[i][j] = LIM_REG_CLASSES;
   reg_class_subclasses[i][j] = LIM_REG_CLASSES;
 }
    }

  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    {
      if (i == (int) NO_REGS)
 continue;

      for (j = i + 1; j < (int) LIM_REG_CLASSES; j++)
 {
   n64_enum_reg_class *p;

   do { register HARD_REG_ELT_TYPE *scan_xp_ = (reg_class_contents[i]), *scan_yp_ = (reg_class_contents[j]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto subclass; } while (0)
              ;
   continue;
 subclass:


   p = &reg_class_superclasses[i][0];
   while (*p != LIM_REG_CLASSES) p++;
   *p = (n64_enum_reg_class) j;

   p = &reg_class_subclasses[j][0];
   while (*p != LIM_REG_CLASSES) p++;
   *p = (n64_enum_reg_class) i;
 }
    }




  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    for (j = 0; j < (int) LIM_REG_CLASSES; j++)
      {
 int cost = i == j ? 2 : ((i) == GR_REGS && (j) == GR_REGS ? 2 : (i) == FP_REGS && (j) == FP_REGS ? 2 : (i) == GR_REGS && (j) == FP_REGS ? 4 : (i) == FP_REGS && (j) == GR_REGS ? 4 : (((i) == HI_REG || (i) == LO_REG || (i) == MD_REGS || (i) == HILO_REG) && (j) == GR_REGS) ? 6 : (((j) == HI_REG || (j) == LO_REG || (j) == MD_REGS || (i) == HILO_REG) && (i) == GR_REGS) ? 6 : 12);
 n64_enum_reg_class *p1, *p2;

 for (p2 = &reg_class_subclasses[j][0]; *p2 != LIM_REG_CLASSES; p2++)
   if (*p2 != i)
     cost = ((cost) > (((i) == GR_REGS && (*p2) == GR_REGS ? 2 : (i) == FP_REGS && (*p2) == FP_REGS ? 2 : (i) == GR_REGS && (*p2) == FP_REGS ? 4 : (i) == FP_REGS && (*p2) == GR_REGS ? 4 : (((i) == HI_REG || (i) == LO_REG || (i) == MD_REGS || (i) == HILO_REG) && (*p2) == GR_REGS) ? 6 : (((*p2) == HI_REG || (*p2) == LO_REG || (*p2) == MD_REGS || (i) == HILO_REG) && (i) == GR_REGS) ? 6 : 12)) ? (cost) : (((i) == GR_REGS && (*p2) == GR_REGS ? 2 : (i) == FP_REGS && (*p2) == FP_REGS ? 2 : (i) == GR_REGS && (*p2) == FP_REGS ? 4 : (i) == FP_REGS && (*p2) == GR_REGS ? 4 : (((i) == HI_REG || (i) == LO_REG || (i) == MD_REGS || (i) == HILO_REG) && (*p2) == GR_REGS) ? 6 : (((*p2) == HI_REG || (*p2) == LO_REG || (*p2) == MD_REGS || (i) == HILO_REG) && (i) == GR_REGS) ? 6 : 12)));

 for (p1 = &reg_class_subclasses[i][0]; *p1 != LIM_REG_CLASSES; p1++)
   {
     if (*p1 != j)
       cost = ((cost) > (((*p1) == GR_REGS && (j) == GR_REGS ? 2 : (*p1) == FP_REGS && (j) == FP_REGS ? 2 : (*p1) == GR_REGS && (j) == FP_REGS ? 4 : (*p1) == FP_REGS && (j) == GR_REGS ? 4 : (((*p1) == HI_REG || (*p1) == LO_REG || (*p1) == MD_REGS || (*p1) == HILO_REG) && (j) == GR_REGS) ? 6 : (((j) == HI_REG || (j) == LO_REG || (j) == MD_REGS || (*p1) == HILO_REG) && (*p1) == GR_REGS) ? 6 : 12)) ? (cost) : (((*p1) == GR_REGS && (j) == GR_REGS ? 2 : (*p1) == FP_REGS && (j) == FP_REGS ? 2 : (*p1) == GR_REGS && (j) == FP_REGS ? 4 : (*p1) == FP_REGS && (j) == GR_REGS ? 4 : (((*p1) == HI_REG || (*p1) == LO_REG || (*p1) == MD_REGS || (*p1) == HILO_REG) && (j) == GR_REGS) ? 6 : (((j) == HI_REG || (j) == LO_REG || (j) == MD_REGS || (*p1) == HILO_REG) && (*p1) == GR_REGS) ? 6 : 12)));

     for (p2 = &reg_class_subclasses[j][0];
   *p2 != LIM_REG_CLASSES; p2++)
       if (*p1 != *p2)
  cost = ((cost) > (((*p1) == GR_REGS && (*p2) == GR_REGS ? 2 : (*p1) == FP_REGS && (*p2) == FP_REGS ? 2 : (*p1) == GR_REGS && (*p2) == FP_REGS ? 4 : (*p1) == FP_REGS && (*p2) == GR_REGS ? 4 : (((*p1) == HI_REG || (*p1) == LO_REG || (*p1) == MD_REGS || (*p1) == HILO_REG) && (*p2) == GR_REGS) ? 6 : (((*p2) == HI_REG || (*p2) == LO_REG || (*p2) == MD_REGS || (*p1) == HILO_REG) && (*p1) == GR_REGS) ? 6 : 12)) ? (cost) : (((*p1) == GR_REGS && (*p2) == GR_REGS ? 2 : (*p1) == FP_REGS && (*p2) == FP_REGS ? 2 : (*p1) == GR_REGS && (*p2) == FP_REGS ? 4 : (*p1) == FP_REGS && (*p2) == GR_REGS ? 4 : (((*p1) == HI_REG || (*p1) == LO_REG || (*p1) == MD_REGS || (*p1) == HILO_REG) && (*p2) == GR_REGS) ? 6 : (((*p2) == HI_REG || (*p2) == LO_REG || (*p2) == MD_REGS || (*p1) == HILO_REG) && (*p1) == GR_REGS) ? 6 : 12)));
   }

 move_cost[i][j] = cost;

 if (reg_class_subset_p (i, j))
   cost = 0;

 may_move_cost[i][j] = cost;
      }
}




static void
init_reg_sets_1(void) asm("_init_reg_sets_1");
static void
init_reg_sets_1(void)
{
  register int i;





  do { if (!(! (target_flags & 0x00000100))) { int regno; for (regno = 32; regno <= 63; regno++) fixed_regs[regno] = call_used_regs[regno] = 1; } } while (0);




  do { register HARD_REG_ELT_TYPE *scan_tp_ = (fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (call_used_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (call_fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

  memcpy (call_fixed_regs,fixed_regs,sizeof call_fixed_regs);

  n_non_fixed_regs = 0;

  for (i = 0; i < 68; i++)
    {
      if (fixed_regs[i])
 ((fixed_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
      else
 n_non_fixed_regs++;

      if (call_used_regs[i])
 ((call_used_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
      if (call_fixed_regs[i])
 ((call_fixed_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
    }
}





static void
init_reg_modes(void) asm("_init_reg_modes");
static void
init_reg_modes(void)
{
  register int i;

  for (i = 0; i < 68; i++)
    {
      reg_raw_mode[i] = choose_hard_reg_mode (i, 1);







      if (reg_raw_mode[i] == VOIDmode)
 reg_raw_mode[i] = word_mode;
    }
}




void
init_regs(void) asm("_init_regs");
void
init_regs(void)
{


  if (!output_bytecode)
    init_reg_sets_1 ();

  init_reg_modes ();
}




n64_enum_machine_mode
choose_hard_reg_mode(int regno, int nregs) asm("_choose_hard_reg_mode");
n64_enum_machine_mode
choose_hard_reg_mode(int regno, int nregs)
{
  n64_enum_machine_mode found_mode = VOIDmode, mode;





  for (mode = class_narrowest_mode[(int)(MODE_INT)];
       mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    if ((! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) == nregs
 && mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
      found_mode = mode;

  if (found_mode != VOIDmode)
    return found_mode;

  for (mode = class_narrowest_mode[(int)(MODE_FLOAT)];
       mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    if ((! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) == nregs
 && mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
      found_mode = mode;

  if (found_mode != VOIDmode)
    return found_mode;

  if ((! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(CCmode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(CCmode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) == nregs
      && mips_hard_regno_mode_ok[ (int)(CCmode) ][ (regno) ])
    return CCmode;


  return VOIDmode;
}





void
fix_register(char *name, int fixed, int call_used) asm("_fix_register");
void
fix_register(char *name, int fixed, int call_used)
{
  int i;

  if (output_bytecode)
    {
      warning ("request to mark `%s' as %s ignored by bytecode compiler",
        name, call_used ? "call-used" : "fixed");
      return;
    }




  if ((i = decode_reg_name (name)) >= 0)
    {
      fixed_regs[i] = fixed;
      call_used_regs[i] = call_used;
    }
  else
    {
      warning ("unknown register name: %s", name);
    }
}



void
globalize_reg(int i) asm("_globalize_reg");
void
globalize_reg(int i)
{
  if (global_regs[i])
    {
      warning ("register used for two global register variables");
      return;
    }

  if (call_used_regs[i] && ! fixed_regs[i])
    warning ("call-clobbered register used for global register variable");

  global_regs[i] = 1;


  if (fixed_regs[i])
    return;

  fixed_regs[i] = call_used_regs[i] = call_fixed_regs[i] = 1;
  n_non_fixed_regs--;

  ((fixed_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
  ((call_used_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
  ((call_fixed_reg_set)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
}
struct n64_tag_costs
{
  int cost[(int) LIM_REG_CLASSES];
  int mem_cost;
};



static struct n64_tag_costs *costs;





static struct n64_tag_costs op_costs[10];




static char *prefclass;
static char *altclass;



static int loop_depth;




static int loop_cost;

static void record_reg_classes (int, int, rtx *, n64_enum_machine_mode *, char **, rtx) asm("_record_reg_classes")
                         ;
static int copy_cost (rtx, n64_enum_machine_mode, n64_enum_reg_class, int) asm("_copy_cost")
                                ;
static void record_address_regs (rtx, n64_enum_reg_class, int) asm("_record_address_regs");
static auto_inc_dec_reg_p (rtx, n64_enum_machine_mode) asm("_auto_inc_dec_reg_p");
static void reg_scan_mark_refs (rtx, rtx, int) asm("_reg_scan_mark_refs");





n64_enum_reg_class
reg_preferred_class(int regno) asm("_reg_preferred_class");
n64_enum_reg_class
reg_preferred_class(int regno)
{
  if (prefclass == 0)
    return GR_REGS;
  return (n64_enum_reg_class) prefclass[regno];
}

n64_enum_reg_class
reg_alternate_class(int regno) asm("_reg_alternate_class");
n64_enum_reg_class
reg_alternate_class(int regno)
{
  if (prefclass == 0)
    return ALL_REGS;

  return (n64_enum_reg_class) altclass[regno];
}




void
regclass_init(void) asm("_regclass_init");
void
regclass_init(void)
{
  prefclass = 0;
}






void
regclass(rtx f, int nregs) asm("_regclass");
void
regclass(rtx f, int nregs)
{

  register rtx insn;
  register int i, j;
  struct n64_tag_costs init_cost;
  rtx set;
  int pass;

  init_recog ();

  costs = (struct n64_tag_costs *) 
                          __builtin_alloca((
                          nregs * sizeof (struct n64_tag_costs)
                          ))
                                                                ;
  init_cost.mem_cost = 10000;
  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    init_cost.cost[i] = 10000;






  for (pass = 0; pass <= flag_expensive_optimizations; pass++)
    {


      memset ((char *) costs,0,nregs * sizeof (struct n64_tag_costs));





      loop_depth = 0, loop_cost = 1;




      for (insn = f; insn; insn = ((insn)->fld[2].rtx))
 {
   char *constraints[10];
   n64_enum_machine_mode modes[10];
   int nalternatives;
   int noperands;






   if (((insn)->code) == NOTE
       && ((insn)->fld[4].rtint) == -4)
     loop_depth++, loop_cost = 1 << (2 * ((loop_depth) < (5) ? (loop_depth) : (5)));
   else if (((insn)->code) == NOTE
     && ((insn)->fld[4].rtint) == -5)
     loop_depth--, loop_cost = 1 << (2 * ((loop_depth) < (5) ? (loop_depth) : (5)));

   else if ((((insn)->code) == INSN
      && ((((insn)->fld[3].rtx))->code) != USE
      && ((((insn)->fld[3].rtx))->code) != CLOBBER
      && ((((insn)->fld[3].rtx))->code) != ASM_INPUT)
     || (((insn)->code) == JUMP_INSN
         && ((((insn)->fld[3].rtx))->code) != ADDR_VEC
         && ((((insn)->fld[3].rtx))->code) != ADDR_DIFF_VEC)
     || ((insn)->code) == CALL_INSN)
     {
       if (((insn)->code) == INSN
    && (noperands = asm_noperands (((insn)->fld[3].rtx))) >= 0)
  {
    decode_asm_operands (((insn)->fld[3].rtx), recog_operand, ((void *)0),
           constraints, modes);
    nalternatives = (noperands == 0 ? 0
       : n_occurrences (',', constraints[0]) + 1);
  }
       else
  {
    int insn_code_number = recog_memoized (insn);
    rtx note;

    set = single_set (insn);
    insn_extract (insn);

    nalternatives = insn_n_alternatives[insn_code_number];
    noperands = insn_n_operands[insn_code_number];





    if (set != 0 && ((((set)->fld[0].rtx))->code) == REG
        && ((((set)->fld[1].rtx))->code) == MEM
        && (note = find_reg_note (insn, REG_EQUIV,
      (rtx) 0)) != 0
        && ((((note)->fld[0].rtx))->code) == MEM)
      {
        costs[((((set)->fld[0].rtx))->fld[0].rtint)].mem_cost
   -= (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4)
       * loop_cost);
        record_address_regs (((((set)->fld[1].rtx))->fld[0].rtx),
        GR_REGS, loop_cost * 2);
        continue;
      }
    if (pass == 0 && optimize
        && noperands >= 3
        && insn_operand_constraint[insn_code_number][1][0] == '0'
        && insn_operand_constraint[insn_code_number][1][1] == 0
        && (((recog_operand[1])->code) == LABEL_REF || ((recog_operand[1])->code) == SYMBOL_REF || ((recog_operand[1])->code) == CONST_INT || ((recog_operand[1])->code) == CONST_DOUBLE || ((recog_operand[1])->code) == CONST || ((recog_operand[1])->code) == HIGH)
        && ! rtx_equal_p (recog_operand[0], recog_operand[1])
        && ! rtx_equal_p (recog_operand[0], recog_operand[2])
        && ((recog_operand[0])->code) == REG
        && (((mode_class[(int)(((recog_operand[0])->mode))]) == MODE_FLOAT || (mode_class[(int)(((recog_operand[0])->mode))]) == MODE_COMPLEX_FLOAT) == ((mode_class[(int)(insn_operand_mode[insn_code_number][1])]) == MODE_FLOAT || (mode_class[(int)(insn_operand_mode[insn_code_number][1])]) == MODE_COMPLEX_FLOAT))
                                              )
      {
        rtx previnsn = prev_real_insn (insn);
        rtx dest
   = gen_lowpart (insn_operand_mode[insn_code_number][1],
           recog_operand[0]);
        rtx newinsn
   = emit_insn_before (gen_move_insn (dest,
          recog_operand[1]),
         insn);






        if (previnsn == 0 || ((previnsn)->code) == JUMP_INSN)
   {
     int b;
     for (b = 0; b < n_basic_blocks; b++)
       if (insn == basic_block_head[b])
         basic_block_head[b] = newinsn;
   }


        reg_n_sets[((recog_operand[0])->fld[0].rtint)]++;

        *recog_operand_loc[1] = recog_operand[0];
        for (i = insn_n_dups[insn_code_number] - 1; i >= 0; i--)
   if (recog_dup_num[i] == 1)
     *recog_dup_loc[i] = recog_operand[0];

        insn = ((newinsn)->fld[1].rtx);
        continue;
      }

    for (i = 0; i < noperands; i++)
      {
        constraints[i]
   = insn_operand_constraint[insn_code_number][i];
        modes[i] = insn_operand_mode[insn_code_number][i];
      }
  }







       for (i = 0; i < noperands; i++)
  {
    op_costs[i] = init_cost;

    if (((recog_operand[i])->code) == SUBREG)
      recog_operand[i] = ((recog_operand[i])->fld[0].rtx);

    if (((recog_operand[i])->code) == MEM)
      record_address_regs (((recog_operand[i])->fld[0].rtx),
      GR_REGS, loop_cost * 2);
    else if (constraints[i][0] == 'p')
      record_address_regs (recog_operand[i],
      GR_REGS, loop_cost * 2);
  }





       for (i = 0; i < noperands - 1; i++)
  if (constraints[i][0] == '%')
    {
      char *xconstraints[10];
      int j;




      for (j = 0; j < noperands; j++)
        xconstraints[j] = constraints[j];

      xconstraints[i] = constraints[i+1];
      xconstraints[i+1] = constraints[i];
      record_reg_classes (nalternatives, noperands,
     recog_operand, modes, xconstraints,
     insn);
    }

       record_reg_classes (nalternatives, noperands, recog_operand,
      modes, constraints, insn);




       for (i = 0; i < noperands; i++)
  if (((recog_operand[i])->code) == REG
      && ((recog_operand[i])->fld[0].rtint) >= 68)
    {
      int regno = ((recog_operand[i])->fld[0].rtint);
      struct n64_tag_costs *p = &costs[regno], *q = &op_costs[i];

      p->mem_cost += q->mem_cost * loop_cost;
      for (j = 0; j < (int) LIM_REG_CLASSES; j++)
        p->cost[j] += q->cost[j] * loop_cost;
    }
     }
 }






      if (pass == 0)
 {
   prefclass = (char *) oballoc (nregs);
   altclass = (char *) oballoc (nregs);
 }

      for (i = 68; i < nregs; i++)
 {
   register int best_cost = (1 << (32 - 2)) - 1;
   n64_enum_reg_class best = ALL_REGS, alt = NO_REGS;


   register int cxx_class;
   register struct n64_tag_costs *p = &costs[i];

   for (cxx_class = (int) ALL_REGS - 1; cxx_class > 0; cxx_class--)
     {


       if (((cxx_class) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + (8) - 1) / (8))) : (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))
    > reg_class_size[cxx_class]



    )
  ;
       else if (p->cost[cxx_class] < best_cost)
  {
    best_cost = p->cost[cxx_class];
    best = (n64_enum_reg_class) cxx_class;
  }
       else if (p->cost[cxx_class] == best_cost)
  best = reg_class_subunion[(int)best][cxx_class];
     }
   if (pass == 1 || ! flag_expensive_optimizations)
     for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
       if (p->cost[cxx_class] < p->mem_cost
    && (reg_class_size[(int) reg_class_subunion[(int) alt][cxx_class]]
        > reg_class_size[(int) alt])



    )
  alt = reg_class_subunion[(int) alt][cxx_class];


   if (alt == best)
     alt = (int) NO_REGS;


   prefclass[i] = (int) best;
   altclass[i] = (int) alt;
 }
    }

}
static void
record_reg_classes(int n_alts, int n_ops, rtx *ops, n64_enum_machine_mode *modes, char **constraints, rtx insn) asm("_record_reg_classes");
static void
record_reg_classes(int n_alts, int n_ops, rtx *ops, n64_enum_machine_mode *modes, char **constraints, rtx insn)
{
  int alt;
  enum n64_cpp_enum_op_type{OP_READ, OP_WRITE, OP_READ_WRITE};
typedef __underlying_type(enum n64_cpp_enum_op_type) n64_enum_op_type;
n64_enum_op_type op_types[10];
  int i, j;
  rtx set;



  for (i = 0; i < n_ops; i++)
    op_types[i] = OP_READ;




  for (alt = 0; alt < n_alts; alt++)
    {
      struct n64_tag_costs this_op_costs[10];
      int alt_fail = 0;
      int alt_cost = 0;
      n64_enum_reg_class classes[10];
      int cxx_class;

      for (i = 0; i < n_ops; i++)
 {
   char *p = constraints[i];
   rtx op = ops[i];
   n64_enum_machine_mode mode = modes[i];
   int allows_mem = 0;
   int win = 0;
   char c;




   if (*p == 0)
     {
       if (((op)->code) == REG && ((op)->fld[0].rtint) >= 68)
  memset ((char *) &this_op_costs[i],0,sizeof this_op_costs[i]);

       continue;
     }

   if (*p == '%')
     p++;





   if (p[0] >= '0' && p[0] <= '0' + i && (p[1] == ',' || p[1] == 0))
     {
       j = p[0] - '0';
       classes[i] = classes[j];

       if (((op)->code) != REG || ((op)->fld[0].rtint) < 68)
  {


    if (rtx_equal_p (ops[j], op))
      win = 1;





    else if (classes[j] != NO_REGS)
      alt_cost += copy_cost (op, mode, classes[j], 1), win = 1;
  }
       else if (((ops[j])->code) != REG
         || ((ops[j])->fld[0].rtint) < 68)
  {





    if (classes[j] == NO_REGS)
      alt_fail = 1;





    else
      alt_cost += copy_cost (ops[j], mode, classes[j], 1);
  }
       else
  {





    this_op_costs[i] = this_op_costs[j];
    if (((ops[i])->fld[0].rtint) != ((ops[j])->fld[0].rtint)
        && ! find_reg_note (insn, REG_DEAD, op))
      alt_cost += 2;




    while (*p && *p++ != ',')
      ;

    constraints[i] = p;
    continue;
  }
     }





   classes[i] = NO_REGS;
   while (*p && (c = *p++) != ',')
     switch (c)
       {
       case '=':
  op_types[i] = OP_WRITE;
  break;

       case '+':
  op_types[i] = OP_READ_WRITE;
  break;

       case '*':

  p++;
  break;

       case '%':
       case '?': case '!': case '#':
       case '&':
       case '0': case '1': case '2': case '3': case '4':
       case 'p':
  break;

       case 'm': case 'o': case 'V':


  allows_mem = 1;
  if (((op)->code) == MEM)
    win = 1;
  break;

       case '<':
  if (((op)->code) == MEM
      && (((((op)->fld[0].rtx))->code) == PRE_DEC
   || ((((op)->fld[0].rtx))->code) == POST_DEC))
    win = 1;
  break;

       case '>':
  if (((op)->code) == MEM
      && (((((op)->fld[0].rtx))->code) == PRE_INC
   || ((((op)->fld[0].rtx))->code) == POST_INC))
    win = 1;
  break;

       case 'E':
  if (((op)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'F':
  if (((op)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'G':
       case 'H':
  if (((op)->code) == CONST_DOUBLE
      && ((c) == 'G' && (op) == (const_tiny_rtx[0][(int) (((op)->mode))])))
    win = 1;
  break;

       case 's':
  if (((op)->code) == CONST_INT
      || (((op)->code) == CONST_DOUBLE
   && ((op)->mode) == VOIDmode))
    break;
       case 'i':
  if ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH)

      && (! flag_pic || (! pic_address_needs_scratch (op)))

      )
    win = 1;
  break;

       case 'n':
  if (((op)->code) == CONST_INT
      || (((op)->code) == CONST_DOUBLE
   && ((op)->mode) == VOIDmode))
    win = 1;
  break;

       case 'I':
       case 'J':
       case 'K':
       case 'L':
       case 'M':
       case 'N':
       case 'O':
       case 'P':
  if (((op)->code) == CONST_INT
      && ((c) == 'I' ? ((unsigned int) ((((op)->fld[0].rtwint)) + 0x8000) < 0x10000) : (c) == 'J' ? ((((op)->fld[0].rtwint)) == 0) : (c) == 'K' ? ((unsigned int) (((op)->fld[0].rtwint)) < 0x10000) : (c) == 'L' ? (((((op)->fld[0].rtwint)) & 0x0000ffff) == 0 && (((((op)->fld[0].rtwint)) & ~2147483647) == 0 || ((((op)->fld[0].rtwint)) & ~2147483647) == ~2147483647)) : (c) == 'M' ? ((((((op)->fld[0].rtwint)) & ~0x0000ffff) != 0) && (((((op)->fld[0].rtwint)) & ~0x0000ffff) != ~0x0000ffff) && (((((op)->fld[0].rtwint)) & 0x0000ffff) != 0 || (((((op)->fld[0].rtwint)) & ~2147483647) != 0 && ((((op)->fld[0].rtwint)) & ~2147483647) != ~2147483647))) : (c) == 'N' ? (((((op)->fld[0].rtwint)) & ~0x0000ffff) == ~0x0000ffff) : (c) == 'O' ? (exact_log2_wide ((int) (((op)->fld[0].rtwint))) >= 0) : (c) == 'P' ? ((((op)->fld[0].rtwint)) != 0 && (((((op)->fld[0].rtwint)) & ~0x0000ffff) == 0)) : 0))
    win = 1;
  break;

       case 'X':
  win = 1;
  break;


              case 'Q':
              case 'R':
              case 'S':
              case 'T':
              case 'U':
  if (((((op)->code) != MEM) ? 0 : ((c) == 'Q') ? !simple_memory_operand (op, ((op)->mode)) : ((c) == 'R') ? simple_memory_operand (op, ((op)->mode)) : ((c) == 'S') ? (0 && (((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH) && 0) : 0))
    win = 1;
  break;


       case 'g':
  if (((op)->code) == MEM
      || ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH)

   && (! flag_pic || (! pic_address_needs_scratch (op)))

   ))
    win = 1;
  allows_mem = 1;
       case 'r':
  classes[i]
    = reg_class_subunion[(int) classes[i]][(int) GR_REGS];
  break;

       default:
  classes[i]
    = reg_class_subunion[(int) classes[i]]
      [(int) mips_char_to_class[ (c) ]];
       }

   constraints[i] = p;
   if (((op)->code) == REG && ((op)->fld[0].rtint) >= 68)
     {
       if (classes[i] == NO_REGS)
  alt_fail = 1;
       else
  {
    struct n64_tag_costs *pp = &this_op_costs[i];

    for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
      pp->cost[cxx_class] = may_move_cost[cxx_class][(int) classes[i]];





    pp->mem_cost = ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4) - allows_mem;






    if (prefclass)
      alt_cost
        += may_move_cost[prefclass[((op)->fld[0].rtint)]][(int) classes[i]];
  }
     }





   else if (win
     || (((op)->code) == REG
         && reg_fits_class_p (op, classes[i], 0, ((op)->mode))))
     ;




   else if (classes[i] != NO_REGS)
     {
       if (op_types[i] != OP_WRITE)
  alt_cost += copy_cost (op, mode, classes[i], 1);

       if (op_types[i] != OP_READ)
  alt_cost += copy_cost (op, mode, classes[i], 0);
     }




   else if ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH) && allows_mem)
     alt_cost += ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4);
   else
     alt_fail = 1;
 }

      if (alt_fail)
 continue;




      for (i = 0; i < n_ops; i++)
 if (((ops[i])->code) == REG
     && ((ops[i])->fld[0].rtint) >= 68)
   {
     struct n64_tag_costs *pp = &op_costs[i], *qq = &this_op_costs[i];
     int scale = 1 + (op_types[i] == OP_READ_WRITE);

     pp->mem_cost = ((pp->mem_cost) < ((qq->mem_cost + alt_cost) * scale) ? (pp->mem_cost) : ((qq->mem_cost + alt_cost) * scale))
                                      ;

     for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
       pp->cost[cxx_class] = ((pp->cost[cxx_class]) < ((qq->cost[cxx_class] + alt_cost) * scale) ? (pp->cost[cxx_class]) : ((qq->cost[cxx_class] + alt_cost) * scale))
                                              ;
   }
    }





  if ((set = single_set (insn)) != 0
      && ops[0] == ((set)->fld[0].rtx) && ops[1] == ((set)->fld[1].rtx)
      && ((ops[0])->code) == REG && ((ops[1])->code) == REG)
    for (i = 0; i <= 1; i++)
      if (((ops[i])->fld[0].rtint) >= 68)
 {
   int regno = ((ops[!i])->fld[0].rtint);
   n64_enum_machine_mode mode = ((ops[!i])->mode);
   int cxx_class;
   int nr;

   if (regno >= 68 && prefclass != 0
       && (reg_class_size[prefclass[regno]]
    == ((prefclass[regno]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(mode)]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(mode)]) + (8) - 1) / (8))) : (((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))))
     op_costs[i].cost[prefclass[regno]] = -1;
   else if (regno < 68)
     for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
       if (((reg_class_contents[cxx_class])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
    && reg_class_size[cxx_class] == ((cxx_class) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(mode)]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(mode)]) + (8) - 1) / (8))) : (((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4)))))
  {
    if (reg_class_size[cxx_class] == 1)
      op_costs[i].cost[cxx_class] = -1;
    else
      {
        for (nr = 0; nr < (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))); nr++)
   {
     if (!((reg_class_contents[cxx_class])[(regno + nr) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + nr) % ((unsigned) 32)))))
       break;
   }

        if (nr == (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))))
   op_costs[i].cost[cxx_class] = -1;
      }
  }
 }
}






static int
copy_cost(rtx x, n64_enum_machine_mode mode, n64_enum_reg_class cxx_class, int to_p) asm("_copy_cost");
static int
copy_cost(rtx x, n64_enum_machine_mode mode, n64_enum_reg_class cxx_class, int to_p)
{
  n64_enum_reg_class secondary_class = NO_REGS;




  if (((x)->code) == SCRATCH)
    return 0;


  cxx_class = ((cxx_class) != ALL_REGS ? (cxx_class) : (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((x)->mode))]) == MODE_INT || ((x)->mode) == VOIDmode) ? GR_REGS : (cxx_class))));
  if (to_p == 1)
    secondary_class = mips_secondary_reload_class (cxx_class, mode, x, 1);



  if (! to_p)
    secondary_class = mips_secondary_reload_class (cxx_class, mode, x, 0);


  if (secondary_class != NO_REGS)
    return (move_cost[(int) secondary_class][(int) cxx_class]
     + copy_cost (x, mode, secondary_class, 2));






  if (((x)->code) == MEM || cxx_class == NO_REGS)
    return ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4);

  else if (((x)->code) == REG)
    return move_cost[(int) mips_regno_to_class[ (((x)->fld[0].rtint)) ]][(int) cxx_class];

  else

    return 2;
}
static void
record_address_regs(rtx x, n64_enum_reg_class cxx_class, int scale) asm("_record_address_regs");
static void
record_address_regs(rtx x, n64_enum_reg_class cxx_class, int scale)
{
  register n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case CONST_INT:
    case CONST:
    case CC0:
    case PC:
    case SYMBOL_REF:
    case LABEL_REF:
      return;

    case PLUS:
      {
 rtx arg0 = ((x)->fld[0].rtx);
 rtx arg1 = ((x)->fld[1].rtx);
 register n64_enum_rtx_code code0 = ((arg0)->code);
 register n64_enum_rtx_code code1 = ((arg1)->code);


 if (code0 == SUBREG)
   arg0 = ((arg0)->fld[0].rtx), code0 = ((arg0)->code);
 if (code1 == SUBREG)
   arg1 = ((arg1)->fld[0].rtx), code1 = ((arg1)->code);




 if (1 == 1)
   record_address_regs (arg0, cxx_class, scale);






 else if (NO_REGS == GR_REGS)
   {
     record_address_regs (arg0, cxx_class, scale);
     if (! (((arg1)->code) == LABEL_REF || ((arg1)->code) == SYMBOL_REF || ((arg1)->code) == CONST_INT || ((arg1)->code) == CONST_DOUBLE || ((arg1)->code) == CONST || ((arg1)->code) == HIGH))
       record_address_regs (arg1, cxx_class, scale);
   }




 else if (code1 == CONST_INT || code1 == CONST_DOUBLE)
   record_address_regs (arg0, cxx_class, scale);




 else if (code1 == SYMBOL_REF || code1 == CONST || code1 == LABEL_REF)
   record_address_regs (arg0, NO_REGS, scale);




 else if (code0 == REG && code1 == REG
   && regno_pointer_flag[((arg0)->fld[0].rtint)])
   {
     record_address_regs (arg0, GR_REGS, scale);
     record_address_regs (arg1, NO_REGS, scale);
   }





 else if (code0 == REG && code1 == REG
   && ! regno_pointer_flag[((arg0)->fld[0].rtint)]
   && ! regno_pointer_flag[((arg1)->fld[0].rtint)])
   {
     record_address_regs (arg0, GR_REGS, scale / 2);
     record_address_regs (arg0, NO_REGS, scale / 2);
     record_address_regs (arg1, GR_REGS, scale / 2);
     record_address_regs (arg1, NO_REGS, scale / 2);
   }




 else
   {
     record_address_regs (arg0, NO_REGS, scale);
     record_address_regs (arg1, GR_REGS, scale);
   }
      }
      break;

    case POST_INC:
    case PRE_INC:
    case POST_DEC:
    case PRE_DEC:
      record_address_regs (((x)->fld[0].rtx), cxx_class, 2 * scale);
      break;

    case REG:
      {
 register struct n64_tag_costs *pp = &costs[((x)->fld[0].rtint)];
 register int i;

 pp->mem_cost += (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4) * scale) / 2;

 for (i = 0; i < (int) LIM_REG_CLASSES; i++)
   pp->cost[i] += (may_move_cost[i][(int) cxx_class] * scale) / 2;
      }
      break;

    default:
      {
 register char *fmt = (rtx_format[(int)(code)]);
 register int i;
 for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
   if (fmt[i] == 'e')
     record_address_regs (((x)->fld[i].rtx), cxx_class, scale);
      }
    }
}
int *regno_first_uid;




int *regno_last_uid;




int *regno_last_note_uid;





static int highest_regno_in_uid_map;





int max_parallel;

void
reg_scan(rtx f, int nregs, int repeat) asm("_reg_scan");
void
reg_scan(rtx f, int nregs, int repeat)
{
  register rtx insn;

  if (!repeat || nregs > highest_regno_in_uid_map)
    {

      highest_regno_in_uid_map = nregs + nregs / 20;
      regno_first_uid
 = (int *) oballoc (highest_regno_in_uid_map * sizeof (int));
      regno_last_uid
 = (int *) oballoc (highest_regno_in_uid_map * sizeof (int));
      regno_last_note_uid
 = (int *) oballoc (highest_regno_in_uid_map * sizeof (int));
      reg_n_sets
 = (short *) oballoc (highest_regno_in_uid_map * sizeof (short));
    }

  memset ((char *) regno_first_uid,0,highest_regno_in_uid_map * sizeof (int));
  memset ((char *) regno_last_uid,0,highest_regno_in_uid_map * sizeof (int));
  memset ((char *) regno_last_note_uid,0,highest_regno_in_uid_map * sizeof (int))
                                          ;
  memset ((char *) reg_n_sets,0,highest_regno_in_uid_map * sizeof (short));

  max_parallel = 3;

  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == INSN
 || ((insn)->code) == CALL_INSN
 || ((insn)->code) == JUMP_INSN)
      {
 if (((((insn)->fld[3].rtx))->code) == PARALLEL
     && ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) > max_parallel)
   max_parallel = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem);
 reg_scan_mark_refs (((insn)->fld[3].rtx), insn, 0);

 if (((insn)->fld[6].rtx))
   reg_scan_mark_refs (((insn)->fld[6].rtx), insn, 1);
      }
}




static void
reg_scan_mark_refs(rtx x, rtx insn, int note_flag) asm("_reg_scan_mark_refs");
static void
reg_scan_mark_refs(rtx x, rtx insn, int note_flag)
{
  register n64_enum_rtx_code code = ((x)->code);
  register rtx dest;
  register rtx note;

  switch (code)
    {
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case CC0:
    case PC:
    case SYMBOL_REF:
    case LABEL_REF:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return;

    case REG:
      {
 register int regno = ((x)->fld[0].rtint);

 regno_last_note_uid[regno] = ((insn)->fld[0].rtint);
 if (!note_flag)
   regno_last_uid[regno] = ((insn)->fld[0].rtint);
 if (regno_first_uid[regno] == 0)
   regno_first_uid[regno] = ((insn)->fld[0].rtint);
      }
      break;

    case EXPR_LIST:
      if (((x)->fld[0].rtx))
 reg_scan_mark_refs (((x)->fld[0].rtx), insn, note_flag);
      if (((x)->fld[1].rtx))
 reg_scan_mark_refs (((x)->fld[1].rtx), insn, note_flag);
      break;

    case INSN_LIST:
      if (((x)->fld[1].rtx))
 reg_scan_mark_refs (((x)->fld[1].rtx), insn, note_flag);
      break;

    case SET:

      for (dest = ((x)->fld[0].rtx);
    ((dest)->code) == SUBREG || ((dest)->code) == STRICT_LOW_PART
    || ((dest)->code) == ZERO_EXTEND;
    dest = ((dest)->fld[0].rtx))
 ;

      if (((dest)->code) == REG)
 reg_n_sets[((dest)->fld[0].rtint)]++;
      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) >= 68
   && ! ((((x)->fld[0].rtx))->volatil)
   && ! regno_pointer_flag[((((x)->fld[0].rtx))->fld[0].rtint)]
   && ((((((x)->fld[1].rtx))->code) == REG
        && regno_pointer_flag[((((x)->fld[1].rtx))->fld[0].rtint)])
       || ((((((x)->fld[1].rtx))->code) == PLUS
     || ((((x)->fld[1].rtx))->code) == LO_SUM)
    && ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT
    && ((((((x)->fld[1].rtx))->fld[0].rtx))->code) == REG
    && regno_pointer_flag[((((((x)->fld[1].rtx))->fld[0].rtx))->fld[0].rtint)])
       || ((((x)->fld[1].rtx))->code) == CONST
       || ((((x)->fld[1].rtx))->code) == SYMBOL_REF
       || ((((x)->fld[1].rtx))->code) == LABEL_REF
       || (((((x)->fld[1].rtx))->code) == HIGH
    && (((((((x)->fld[1].rtx))->fld[0].rtx))->code) == CONST
        || ((((((x)->fld[1].rtx))->fld[0].rtx))->code) == SYMBOL_REF
        || ((((((x)->fld[1].rtx))->fld[0].rtx))->code) == LABEL_REF))
       || ((((((x)->fld[1].rtx))->code) == PLUS
     || ((((x)->fld[1].rtx))->code) == LO_SUM)
    && (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST
        || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == SYMBOL_REF
        || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF))
       || ((note = find_reg_note (insn, REG_EQUAL, 0)) != 0
    && (((((note)->fld[0].rtx))->code) == CONST
        || ((((note)->fld[0].rtx))->code) == SYMBOL_REF
        || ((((note)->fld[0].rtx))->code) == LABEL_REF))))
 regno_pointer_flag[((((x)->fld[0].rtx))->fld[0].rtint)] = 1;



    default:
      {
 register char *fmt = (rtx_format[(int)(code)]);
 register int i;
 for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
   {
     if (fmt[i] == 'e')
       reg_scan_mark_refs (((x)->fld[i].rtx), insn, note_flag);
     else if (fmt[i] == 'E' && ((x)->fld[i].rtvec) != 0)
       {
  register int j;
  for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
    reg_scan_mark_refs (((x)->fld[i].rtvec->elem[j].rtx), insn, note_flag);
       }
   }
      }
    }
}




int
reg_class_subset_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2) asm("_reg_class_subset_p");
int
reg_class_subset_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2)
{
  if (c1 == c2) return 1;

  if (c2 == ALL_REGS)
  win:
    return 1;
  do { register HARD_REG_ELT_TYPE *scan_xp_ = (reg_class_contents[(int)c1]), *scan_yp_ = (reg_class_contents[(int)c2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto win; } while (0)

        ;
  return 0;
}



int
reg_classes_intersect_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2) asm("_reg_classes_intersect_p");
int
reg_classes_intersect_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2)
{



    HARD_REG_SET c;

  if (c1 == c2) return 1;

  if (c1 == ALL_REGS || c2 == ALL_REGS)
    return 1;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[(int) c1]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[(int) c2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= *scan_fp_++; } while (0);

  do { register HARD_REG_ELT_TYPE *scan_xp_ = (c), *scan_yp_ = (reg_class_contents[(int) NO_REGS]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto lose; } while (0);
  return 1;

 lose:
  return 0;
}

