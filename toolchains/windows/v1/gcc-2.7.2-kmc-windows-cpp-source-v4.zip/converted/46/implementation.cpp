// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/reload.c
/* Search an insn for pseudo regs that must be in hard regs and are not.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int reg_class_subset_p(...) asm("_reg_class_subset_p");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int error_for_asm(...) asm("_error_for_asm");
extern int true_regnum(...) asm("_true_regnum");
extern int side_effects_p(...) asm("_side_effects_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int warning_for_asm(...) asm("_warning_for_asm");
extern int rtx_varies_p(...) asm("_rtx_varies_p");
extern int offsettable_memref_p(...) asm("_offsettable_memref_p");
extern int offsettable_nonstrict_memref_p(...) asm("_offsettable_nonstrict_memref_p");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int reg_fits_class_p(...) asm("_reg_fits_class_p");
extern int rtx_renumbered_equal_p(...) asm("_rtx_renumbered_equal_p");
extern int push_operand(...) asm("_push_operand");
struct n64_tag_decomposition;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_replacement;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern rtx reload_in[(2 * 10 * (1 + 1))];
extern rtx reload_out[(2 * 10 * (1 + 1))];
extern rtx reload_in_reg[(2 * 10 * (1 + 1))];
extern n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
extern char reload_optional[(2 * 10 * (1 + 1))];
extern int reload_inc[(2 * 10 * (1 + 1))];
extern int reload_opnum[(2 * 10 * (1 + 1))];
extern int reload_secondary_p[(2 * 10 * (1 + 1))];
extern int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
extern int reload_secondary_out_reload[(2 * 10 * (1 + 1))];

extern n64_enum_insn_code reload_secondary_in_icode[(2 * 10 * (1 + 1))];
extern n64_enum_insn_code reload_secondary_out_icode[(2 * 10 * (1 + 1))];

extern int n_reloads;

extern rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
enum n64_cpp_enum_reload_type{
  RELOAD_FOR_INPUT, RELOAD_FOR_OUTPUT, RELOAD_FOR_INSN,
  RELOAD_FOR_INPUT_ADDRESS, RELOAD_FOR_OUTPUT_ADDRESS,
  RELOAD_FOR_OPERAND_ADDRESS, RELOAD_FOR_OPADDR_ADDR,
  RELOAD_OTHER, RELOAD_FOR_OTHER_ADDRESS
};
typedef __underlying_type(enum n64_cpp_enum_reload_type) n64_enum_reload_type;


extern n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];

extern rtx *reg_equiv_constant;
extern rtx *reg_equiv_memory_loc;
extern rtx *reg_equiv_address;
extern rtx *reg_equiv_mem;



extern int n_earlyclobbers;
extern rtx reload_earlyclobbers[10];


extern int reload_n_operands;



extern int reload_first_uid;





extern char indirect_symref_ok;


extern char double_reg_address_ok;





extern n64_enum_insn_code reload_in_optab[];
extern n64_enum_insn_code reload_out_optab[];







extern rtx get_secondary_mem (rtx, n64_enum_machine_mode, int, n64_enum_reload_type) asm("_get_secondary_mem")
                               ;


extern void clear_secondary_mem (void) asm("_clear_secondary_mem");



extern void transfer_replacements (int, int) asm("_transfer_replacements");




extern int strict_memory_address_p (n64_enum_machine_mode, rtx) asm("_strict_memory_address_p");




extern int operands_match_p (rtx, rtx) asm("_operands_match_p");


extern int n_occurrences (int, char *) asm("_n_occurrences");


extern int safe_from_earlyclobber (rtx, rtx) asm("_safe_from_earlyclobber");




extern void find_reloads (rtx, int, int, int, short *) asm("_find_reloads");





extern rtx form_sum (rtx, rtx) asm("_form_sum");



extern void subst_reloads (void) asm("_subst_reloads");




extern void copy_replacements (rtx, rtx) asm("_copy_replacements");



extern rtx find_replacement (rtx *) asm("_find_replacement");




extern int refers_to_regno_for_reload_p (int, int, rtx, rtx *) asm("_refers_to_regno_for_reload_p");


extern int reg_overlap_mentioned_for_reload_p (rtx, rtx) asm("_reg_overlap_mentioned_for_reload_p");



extern int refers_to_mem_for_reload_p (rtx) asm("_refers_to_mem_for_reload_p");



extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg")
                             ;


extern int regno_clobbered_p (int, rtx) asm("_regno_clobbered_p");





extern void init_reload (void) asm("_init_reload");


extern int reload (rtx, int, FILE *) asm("_reload");



extern void mark_home_live (int) asm("_mark_home_live");



extern rtx eliminate_regs (rtx, n64_enum_machine_mode, rtx) asm("_eliminate_regs");




extern rtx gen_reload (rtx, rtx, int, n64_enum_reload_type) asm("_gen_reload");




extern void init_caller_save (void) asm("_init_caller_save");


extern void init_save_areas (void) asm("_init_save_areas");


extern int setup_save_areas (int *) asm("_setup_save_areas");


extern void save_call_clobbered_regs (n64_enum_machine_mode) asm("_save_call_clobbered_regs");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
int n_reloads;

rtx reload_in[(2 * 10 * (1 + 1))];
rtx reload_out[(2 * 10 * (1 + 1))];
n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
char reload_optional[(2 * 10 * (1 + 1))];
int reload_inc[(2 * 10 * (1 + 1))];
rtx reload_in_reg[(2 * 10 * (1 + 1))];
char reload_nocombine[(2 * 10 * (1 + 1))];
int reload_opnum[(2 * 10 * (1 + 1))];
n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];
int reload_secondary_p[(2 * 10 * (1 + 1))];
int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
int reload_secondary_out_reload[(2 * 10 * (1 + 1))];
n64_enum_insn_code reload_secondary_in_icode[(2 * 10 * (1 + 1))];
n64_enum_insn_code reload_secondary_out_icode[(2 * 10 * (1 + 1))];



int n_earlyclobbers;
rtx reload_earlyclobbers[10];

int reload_n_operands;
static int replace_reloads;


struct n64_tag_replacement
{
  rtx *where;
  rtx *subreg_loc;

  int what;
  n64_enum_machine_mode mode;
};

static struct n64_tag_replacement replacements[10 * ((1 * 2) + 1)];


static int n_replacements;


struct n64_tag_decomposition
{
  int reg_flag;
  int safe;
  rtx base;
  int start;
  int end;
};



static rtx memlocs[10 * ((1 * 2) + 1)];
static int n_memlocs;
static rtx secondary_memlocs[(int) MAX_MACHINE_MODE];
static rtx secondary_memlocs_elim[(int) MAX_MACHINE_MODE][10];




static rtx this_insn;


static int this_insn_is_asm;




static int hard_regs_live_known;





static short *static_reload_reg_p;


static int subst_reg_equivs_changed;



static int output_reloadnum;
static int push_secondary_reload (int, rtx, int, int, n64_enum_reg_class, n64_enum_machine_mode, n64_enum_reload_type, n64_enum_insn_code *) asm("_push_secondary_reload")

                       ;
static int push_reload (rtx, rtx, rtx *, rtx *, n64_enum_reg_class, n64_enum_machine_mode, n64_enum_machine_mode, int, int, int, n64_enum_reload_type) asm("_push_reload")

                                            ;
static void push_replacement (rtx *, int, n64_enum_machine_mode) asm("_push_replacement");
static void combine_reloads (void) asm("_combine_reloads");
static rtx find_dummy_reload (rtx, rtx, rtx *, rtx *, n64_enum_machine_mode, n64_enum_machine_mode, n64_enum_reg_class, int) asm("_find_dummy_reload")

                                ;
static int earlyclobber_operand_p (rtx) asm("_earlyclobber_operand_p");
static int hard_reg_set_here_p (int, int, rtx) asm("_hard_reg_set_here_p");
static struct n64_tag_decomposition decompose (rtx) asm("_decompose");
static int immune_p (rtx, rtx, struct n64_tag_decomposition) asm("_immune_p");
static int alternative_allows_memconst (char *, int) asm("_alternative_allows_memconst");
static rtx find_reloads_toplev (rtx, int, n64_enum_reload_type, int, int) asm("_find_reloads_toplev");
static rtx make_memloc (rtx, int) asm("_make_memloc");
static int find_reloads_address (n64_enum_machine_mode, rtx *, rtx, rtx *, int, n64_enum_reload_type, int) asm("_find_reloads_address")
                                       ;
static rtx subst_reg_equivs (rtx) asm("_subst_reg_equivs");
static rtx subst_indexed_address (rtx) asm("_subst_indexed_address");
static int find_reloads_address_1 (rtx, int, rtx *, int, n64_enum_reload_type,int) asm("_find_reloads_address_1")
                            ;
static void find_reloads_address_part (rtx, rtx *, n64_enum_reg_class, n64_enum_machine_mode, int, n64_enum_reload_type, int) asm("_find_reloads_address_part")

                                 ;
static int find_inc_amount (rtx, rtx) asm("_find_inc_amount");
static int
push_secondary_reload(int in_p, rtx x, int opnum, int optional, n64_enum_reg_class reload_class, n64_enum_machine_mode reload_mode, n64_enum_reload_type type, n64_enum_insn_code *picode) asm("_push_secondary_reload");
static int
push_secondary_reload(int in_p, rtx x, int opnum, int optional, n64_enum_reg_class reload_class, n64_enum_machine_mode reload_mode, n64_enum_reload_type type, n64_enum_insn_code *picode)
{
  n64_enum_reg_class cxx_class = NO_REGS;
  n64_enum_machine_mode mode = reload_mode;
  n64_enum_insn_code icode = CODE_FOR_nothing;
  n64_enum_reg_class t_class = NO_REGS;
  n64_enum_machine_mode t_mode = VOIDmode;
  n64_enum_insn_code t_icode = CODE_FOR_nothing;
  n64_enum_reload_type secondary_type;
  int i;
  int s_reload, t_reload = -1;

  if (type == RELOAD_FOR_INPUT_ADDRESS || type == RELOAD_FOR_OUTPUT_ADDRESS)
    secondary_type = type;
  else
    secondary_type = in_p ? RELOAD_FOR_INPUT_ADDRESS : RELOAD_FOR_OUTPUT_ADDRESS;

  *picode = CODE_FOR_nothing;



  if (((x)->code) == SUBREG
      && ((mode_size[(int)(((x)->mode))])
   > (mode_size[(int)(((((x)->fld[0].rtx))->mode))])))
    {
      x = ((x)->fld[0].rtx);
      reload_mode = ((x)->mode);
    }







  if (((x)->code) == REG && ((x)->fld[0].rtint) >= 68
      && reg_equiv_mem[((x)->fld[0].rtint)] != 0)
    x = reg_equiv_mem[((x)->fld[0].rtint)];


  if (in_p)
    cxx_class = mips_secondary_reload_class (reload_class, reload_mode, x, 1);



  if (! in_p)
    cxx_class = mips_secondary_reload_class (reload_class, reload_mode, x, 0);



  if (cxx_class == NO_REGS)
    return -1;




  icode = (in_p ? reload_in_optab[(int) reload_mode]
    : reload_out_optab[(int) reload_mode]);

  if (icode != CODE_FOR_nothing
      && insn_operand_predicate[(int) icode][in_p]
      && (! (insn_operand_predicate[(int) icode][in_p]) (x, reload_mode)))
    icode = CODE_FOR_nothing;







  if (icode != CODE_FOR_nothing)
    {





      char insn_letter = insn_operand_constraint[(int) icode][!in_p][in_p];
      n64_enum_reg_class insn_class
 = (insn_letter == 'r' ? GR_REGS
    : mips_char_to_class[ (insn_letter) ]);

      if (insn_class == NO_REGS
   || (in_p && insn_operand_constraint[(int) icode][!in_p][0] != '=')

   || insn_operand_constraint[(int) icode][2][0] != '='
   || insn_operand_constraint[(int) icode][2][1] != '&')
 abort ();

      if (reg_class_subset_p (reload_class, insn_class))
 mode = insn_operand_mode[(int) icode][2];
      else
 {
   char t_letter = insn_operand_constraint[(int) icode][2][2];
   cxx_class = insn_class;
   t_mode = insn_operand_mode[(int) icode][2];
   t_class = (t_letter == 'r' ? GR_REGS
       : mips_char_to_class[ (t_letter) ]);
   t_icode = icode;
   icode = CODE_FOR_nothing;
 }
    }
  if (in_p && cxx_class == reload_class && mode == reload_mode)
    abort ();




  if (t_class != NO_REGS)
    {
      for (t_reload = 0; t_reload < n_reloads; t_reload++)
 if (reload_secondary_p[t_reload]
     && (reg_class_subset_p (t_class, reload_reg_class[t_reload])
  || reg_class_subset_p (reload_reg_class[t_reload], t_class))
     && ((in_p && reload_inmode[t_reload] == t_mode)
  || (! in_p && reload_outmode[t_reload] == t_mode))
     && ((in_p && (reload_secondary_in_icode[t_reload]
     == CODE_FOR_nothing))
  || (! in_p &&(reload_secondary_out_icode[t_reload]
         == CODE_FOR_nothing)))
     && (reg_class_size[(int) t_class] == 1



  )
     && ((secondary_type) == RELOAD_OTHER || (reload_when_needed[t_reload]) == RELOAD_OTHER || ((secondary_type) == (reload_when_needed[t_reload]) && (opnum) == (reload_opnum[t_reload])) || ((secondary_type) == RELOAD_FOR_INPUT && (reload_when_needed[t_reload]) == RELOAD_FOR_INPUT) || ((secondary_type) == RELOAD_FOR_OPERAND_ADDRESS && (reload_when_needed[t_reload]) == RELOAD_FOR_OPERAND_ADDRESS) || ((secondary_type) == RELOAD_FOR_OTHER_ADDRESS && (reload_when_needed[t_reload]) == RELOAD_FOR_OTHER_ADDRESS))

                                   )
   {
     if (in_p)
       reload_inmode[t_reload] = t_mode;
     if (! in_p)
       reload_outmode[t_reload] = t_mode;

     if (reg_class_subset_p (t_class, reload_reg_class[t_reload]))
       reload_reg_class[t_reload] = t_class;

     reload_opnum[t_reload] = ((reload_opnum[t_reload]) < (opnum) ? (reload_opnum[t_reload]) : (opnum));
     reload_optional[t_reload] &= optional;
     reload_secondary_p[t_reload] = 1;
     if (((secondary_type) != (reload_when_needed[t_reload]) || ! ((opnum) == (reload_opnum[t_reload]) || (secondary_type) == RELOAD_FOR_INPUT || (secondary_type) == RELOAD_FOR_OPERAND_ADDRESS || (secondary_type) == RELOAD_FOR_OTHER_ADDRESS))
                                  )
       reload_when_needed[t_reload] = RELOAD_OTHER;
   }

      if (t_reload == n_reloads)
 {

   reload_in[t_reload] = reload_out[t_reload] = 0;
   reload_reg_class[t_reload] = t_class;
   reload_inmode[t_reload] = in_p ? t_mode : VOIDmode;
   reload_outmode[t_reload] = ! in_p ? t_mode : VOIDmode;
   reload_reg_rtx[t_reload] = 0;
   reload_optional[t_reload] = optional;
   reload_inc[t_reload] = 0;

   reload_nocombine[t_reload] = 1;
   reload_in_reg[t_reload] = 0;
   reload_opnum[t_reload] = opnum;
   reload_when_needed[t_reload] = secondary_type;
   reload_secondary_in_reload[t_reload] = -1;
   reload_secondary_out_reload[t_reload] = -1;
   reload_secondary_in_icode[t_reload] = CODE_FOR_nothing;
   reload_secondary_out_icode[t_reload] = CODE_FOR_nothing;
   reload_secondary_p[t_reload] = 1;

   n_reloads++;
 }
    }


  for (s_reload = 0; s_reload < n_reloads; s_reload++)
    if (reload_secondary_p[s_reload]
 && (reg_class_subset_p (cxx_class, reload_reg_class[s_reload])
     || reg_class_subset_p (reload_reg_class[s_reload], cxx_class))
 && ((in_p && reload_inmode[s_reload] == mode)
     || (! in_p && reload_outmode[s_reload] == mode))
 && ((in_p && reload_secondary_in_reload[s_reload] == t_reload)
     || (! in_p && reload_secondary_out_reload[s_reload] == t_reload))
 && ((in_p && reload_secondary_in_icode[s_reload] == t_icode)
     || (! in_p && reload_secondary_out_icode[s_reload] == t_icode))
 && (reg_class_size[(int) cxx_class] == 1



     )
 && ((secondary_type) == RELOAD_OTHER || (reload_when_needed[s_reload]) == RELOAD_OTHER || ((secondary_type) == (reload_when_needed[s_reload]) && (opnum) == (reload_opnum[s_reload])) || ((secondary_type) == RELOAD_FOR_INPUT && (reload_when_needed[s_reload]) == RELOAD_FOR_INPUT) || ((secondary_type) == RELOAD_FOR_OPERAND_ADDRESS && (reload_when_needed[s_reload]) == RELOAD_FOR_OPERAND_ADDRESS) || ((secondary_type) == RELOAD_FOR_OTHER_ADDRESS && (reload_when_needed[s_reload]) == RELOAD_FOR_OTHER_ADDRESS))
                                      )
      {
 if (in_p)
   reload_inmode[s_reload] = mode;
 if (! in_p)
   reload_outmode[s_reload] = mode;

 if (reg_class_subset_p (cxx_class, reload_reg_class[s_reload]))
   reload_reg_class[s_reload] = cxx_class;

 reload_opnum[s_reload] = ((reload_opnum[s_reload]) < (opnum) ? (reload_opnum[s_reload]) : (opnum));
 reload_optional[s_reload] &= optional;
 reload_secondary_p[s_reload] = 1;
 if (((secondary_type) != (reload_when_needed[s_reload]) || ! ((opnum) == (reload_opnum[s_reload]) || (secondary_type) == RELOAD_FOR_INPUT || (secondary_type) == RELOAD_FOR_OPERAND_ADDRESS || (secondary_type) == RELOAD_FOR_OTHER_ADDRESS))
                                     )
   reload_when_needed[s_reload] = RELOAD_OTHER;
      }

  if (s_reload == n_reloads)
    {

      reload_in[s_reload] = reload_out[s_reload] = 0;
      reload_reg_class[s_reload] = cxx_class;

      reload_inmode[s_reload] = in_p ? mode : VOIDmode;
      reload_outmode[s_reload] = ! in_p ? mode : VOIDmode;
      reload_reg_rtx[s_reload] = 0;
      reload_optional[s_reload] = optional;
      reload_inc[s_reload] = 0;

      reload_nocombine[s_reload] = 1;
      reload_in_reg[s_reload] = 0;
      reload_opnum[s_reload] = opnum;
      reload_when_needed[s_reload] = secondary_type;
      reload_secondary_in_reload[s_reload] = in_p ? t_reload : -1;
      reload_secondary_out_reload[s_reload] = ! in_p ? t_reload : -1;
      reload_secondary_in_icode[s_reload] = in_p ? t_icode : CODE_FOR_nothing;
      reload_secondary_out_icode[s_reload]
 = ! in_p ? t_icode : CODE_FOR_nothing;
      reload_secondary_p[s_reload] = 1;

      n_reloads++;





      if (in_p && icode == CODE_FOR_nothing
   && ((!(target_flags & 0x00400000) && (mode_class[(int)(reload_mode)]) == MODE_INT && ((cxx_class == FP_REGS && reload_class == GR_REGS) || (cxx_class == GR_REGS && reload_class == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (reload_mode) == DFmode && ((cxx_class == GR_REGS && reload_class == FP_REGS) || (reload_class == GR_REGS && cxx_class == FP_REGS)))))
 get_secondary_mem (x, reload_mode, opnum, type);

      if (! in_p && icode == CODE_FOR_nothing
   && ((!(target_flags & 0x00400000) && (mode_class[(int)(reload_mode)]) == MODE_INT && ((reload_class == FP_REGS && cxx_class == GR_REGS) || (reload_class == GR_REGS && cxx_class == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (reload_mode) == DFmode && ((reload_class == GR_REGS && cxx_class == FP_REGS) || (cxx_class == GR_REGS && reload_class == FP_REGS)))))
 get_secondary_mem (x, reload_mode, opnum, type);

    }

  *picode = icode;
  return s_reload;
}
rtx
get_secondary_mem(rtx x, n64_enum_machine_mode mode, int opnum, n64_enum_reload_type type) asm("_get_secondary_mem");
rtx
get_secondary_mem(rtx x, n64_enum_machine_mode mode, int opnum, n64_enum_reload_type type)
{
  rtx loc;
  int mem_valid;
  if ((8 * mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 64 : 32))
    mode = mode_for_size (((target_flags & 0x00002000) ? 64 : 32), (mode_class[(int)(mode)]), 0);



  if (secondary_memlocs_elim[(int) mode][opnum] != 0)
    return secondary_memlocs_elim[(int) mode][opnum];





  if (secondary_memlocs[(int) mode] == 0)
    {



      secondary_memlocs[(int) mode]
 = assign_stack_local (mode, (mode_size[(int)(mode)]), 0);

    }




  loc = eliminate_regs (secondary_memlocs[(int) mode], VOIDmode, (rtx) 0);
  mem_valid = strict_memory_address_p (mode, ((loc)->fld[0].rtx));

  if (! mem_valid && loc == secondary_memlocs[(int) mode])
    loc = copy_rtx (loc);
  if (! mem_valid)
    {
      type = (type == RELOAD_FOR_INPUT ? RELOAD_FOR_INPUT_ADDRESS
        : type == RELOAD_FOR_OUTPUT ? RELOAD_FOR_OUTPUT_ADDRESS
        : RELOAD_OTHER);

      find_reloads_address (mode, ((void *)0), ((loc)->fld[0].rtx), &((loc)->fld[0].rtx),
       opnum, type, 0);
    }

  secondary_memlocs_elim[(int) mode][opnum] = loc;
  return loc;
}



void
clear_secondary_mem(void) asm("_clear_secondary_mem");
void
clear_secondary_mem(void)
{
  memset ((char *) secondary_memlocs,0,sizeof secondary_memlocs);
}
static int
push_reload(register rtx in, register rtx out, rtx *inloc, rtx *outloc, n64_enum_reg_class cxx_class, n64_enum_machine_mode inmode, n64_enum_machine_mode outmode, int strict_low, int optional, int opnum, n64_enum_reload_type type) asm("_push_reload");
static int
push_reload(register rtx in, register rtx out, rtx *inloc, rtx *outloc, n64_enum_reg_class cxx_class, n64_enum_machine_mode inmode, n64_enum_machine_mode outmode, int strict_low, int optional, int opnum, n64_enum_reload_type type)
{
  register int i;
  int dont_share = 0;
  int dont_remove_subreg = 0;
  rtx *in_subreg_loc = 0, *out_subreg_loc = 0;
  int secondary_in_reload = -1, secondary_out_reload = -1;
  n64_enum_insn_code secondary_in_icode = CODE_FOR_nothing;
  n64_enum_insn_code secondary_out_icode = CODE_FOR_nothing;




  if (inmode == VOIDmode && in != 0)
    inmode = ((in)->mode);
  if (outmode == VOIDmode && out != 0)
    outmode = ((out)->mode);





  if (in != 0 && ((in)->code) == REG)
    {
      register int regno = ((in)->fld[0].rtint);

      if (regno >= 68 && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0)
 in = reg_equiv_constant[regno];
    }




  if (out != 0 && ((out)->code) == REG)
    {
      register int regno = ((out)->fld[0].rtint);

      if (regno >= 68 && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0)
 out = reg_equiv_constant[regno];
    }



  if (in != 0 && out != 0 && ((in)->code) == MEM && rtx_equal_p (in, out))
    {
      if (((((in)->fld[0].rtx))->code) == POST_INC
   || ((((in)->fld[0].rtx))->code) == POST_DEC)
 in = gen_rtx (MEM, ((in)->mode), ((((in)->fld[0].rtx))->fld[0].rtx));
      if (((((in)->fld[0].rtx))->code) == PRE_INC
   || ((((in)->fld[0].rtx))->code) == PRE_DEC)
 out = gen_rtx (MEM, ((out)->mode), ((((out)->fld[0].rtx))->fld[0].rtx));
    }
  if (in != 0 && ((in)->code) == SUBREG && ((in)->fld[1].rtint) == 0



      && ((((((in)->fld[0].rtx))->code) == LABEL_REF || ((((in)->fld[0].rtx))->code) == SYMBOL_REF || ((((in)->fld[0].rtx))->code) == CONST_INT || ((((in)->fld[0].rtx))->code) == CONST_DOUBLE || ((((in)->fld[0].rtx))->code) == CONST || ((((in)->fld[0].rtx))->code) == HIGH)
   || ((((in)->fld[0].rtx))->code) == PLUS
   || strict_low
   || (((((((in)->fld[0].rtx))->code) == REG
  && ((((in)->fld[0].rtx))->fld[0].rtint) >= 68)
        || ((((in)->fld[0].rtx))->code) == MEM)
       && (((mode_size[(int)(inmode)])
     > (mode_size[(int)(((((in)->fld[0].rtx))->mode))]))

    || ((mode_size[(int)(inmode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
        && ((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
     <= ((target_flags & 0x00002000) ? 8 : 4))
        && ((mode_size[(int)(inmode)])
     > (mode_size[(int)(((((in)->fld[0].rtx))->mode))]))
        && ((mode_class[(int)(((((in)->fld[0].rtx))->mode))]) == MODE_INT || (mode_class[(int)(((((in)->fld[0].rtx))->mode))]) == MODE_PARTIAL_INT || (mode_class[(int)(((((in)->fld[0].rtx))->mode))]) == MODE_COMPLEX_INT)
        && ZERO_EXTEND != NIL)

    ))
   || (((((in)->fld[0].rtx))->code) == REG
       && ((((in)->fld[0].rtx))->fld[0].rtint) < 68


       && (out == 0 || ((in)->fld[1].rtint) == 0)
       && (((mode_size[(int)(inmode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
     && ((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
         > ((target_flags & 0x00002000) ? 8 : 4))
     && (((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
   / ((target_flags & 0x00002000) ? 8 : 4))
         != (! ((unsigned) ((((((in)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((in)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((in)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                    ))
    || ! mips_hard_regno_mode_ok[ (int)(inmode) ][ ((((((in)->fld[0].rtx))->fld[0].rtint) + ((in)->fld[1].rtint))) ]

               ))

   || (mips_secondary_reload_class (cxx_class, inmode, in, 1) != NO_REGS
       && (mips_secondary_reload_class (cxx_class, ((((in)->fld[0].rtx))->mode), ((in)->fld[0].rtx), 1)


    == NO_REGS))
   ))
    {
      in_subreg_loc = inloc;
      inloc = &((in)->fld[0].rtx);
      in = *inloc;







      inmode = ((in)->mode);
    }
  if (in != 0 && ((in)->code) == SUBREG
      && ((((in)->fld[0].rtx))->code) == REG
      && ((((in)->fld[0].rtx))->fld[0].rtint) < 68
      && (! mips_hard_regno_mode_ok[ (int)(inmode) ][ (((((in)->fld[0].rtx))->fld[0].rtint)) ]
   || ((mode_size[(int)(inmode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
       && ((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
    > ((target_flags & 0x00002000) ? 8 : 4))
       && (((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
     / ((target_flags & 0x00002000) ? 8 : 4))
    != (! ((unsigned) ((((((in)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((in)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((in)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                      ))))
    {





      push_reload (((in)->fld[0].rtx), (rtx) 0, &((in)->fld[0].rtx), ((void *)0),
     GR_REGS, VOIDmode, VOIDmode, 0, 0, opnum, type);
      dont_remove_subreg = 1;
    }
  if (out != 0 && ((out)->code) == SUBREG && ((out)->fld[1].rtint) == 0



      && ((((((out)->fld[0].rtx))->code) == LABEL_REF || ((((out)->fld[0].rtx))->code) == SYMBOL_REF || ((((out)->fld[0].rtx))->code) == CONST_INT || ((((out)->fld[0].rtx))->code) == CONST_DOUBLE || ((((out)->fld[0].rtx))->code) == CONST || ((((out)->fld[0].rtx))->code) == HIGH)
   || strict_low
   || (((((((out)->fld[0].rtx))->code) == REG
  && ((((out)->fld[0].rtx))->fld[0].rtint) >= 68)
        || ((((out)->fld[0].rtx))->code) == MEM)
       && (((mode_size[(int)(outmode)])
     > (mode_size[(int)(((((out)->fld[0].rtx))->mode))]))))
   || (((((out)->fld[0].rtx))->code) == REG
       && ((((out)->fld[0].rtx))->fld[0].rtint) < 68
       && (((mode_size[(int)(outmode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
     && ((mode_size[(int)(((((out)->fld[0].rtx))->mode))])
         > ((target_flags & 0x00002000) ? 8 : 4))
     && (((mode_size[(int)(((((out)->fld[0].rtx))->mode))])
   / ((target_flags & 0x00002000) ? 8 : 4))
         != (! ((unsigned) ((((((out)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((out)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((out)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                     ))
    || ! mips_hard_regno_mode_ok[ (int)(outmode) ][ ((((((out)->fld[0].rtx))->fld[0].rtint) + ((out)->fld[1].rtint))) ]

                ))

   || (mips_secondary_reload_class (cxx_class, outmode, out, 0) != NO_REGS
       && (mips_secondary_reload_class (cxx_class, ((((out)->fld[0].rtx))->mode), ((out)->fld[0].rtx), 0)


    == NO_REGS))
   ))
    {
      out_subreg_loc = outloc;
      outloc = &((out)->fld[0].rtx);
      out = *outloc;





      outmode = ((out)->mode);
    }
  if (out != 0 && ((out)->code) == SUBREG
      && ((((out)->fld[0].rtx))->code) == REG
      && ((((out)->fld[0].rtx))->fld[0].rtint) < 68
      && (! mips_hard_regno_mode_ok[ (int)(outmode) ][ (((((out)->fld[0].rtx))->fld[0].rtint)) ]
   || ((mode_size[(int)(outmode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
       && ((mode_size[(int)(((((out)->fld[0].rtx))->mode))])
    > ((target_flags & 0x00002000) ? 8 : 4))
       && (((mode_size[(int)(((((out)->fld[0].rtx))->mode))])
     / ((target_flags & 0x00002000) ? 8 : 4))
    != (! ((unsigned) ((((((out)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((out)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((out)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                       ))))
    {





      dont_remove_subreg = 1;
      push_reload (((out)->fld[0].rtx), ((out)->fld[0].rtx), &((out)->fld[0].rtx),
     &((out)->fld[0].rtx), ALL_REGS, VOIDmode, VOIDmode, 0, 0,
     opnum, RELOAD_OTHER);
    }


  if (in != 0 && out != 0 && ((out)->code) == MEM
      && (((in)->code) == REG || ((in)->code) == MEM)
      && reg_overlap_mentioned_for_reload_p (in, ((out)->fld[0].rtx)))
    dont_share = 1;




  if (in != 0 && ((in)->code) == SUBREG && ((((in)->fld[0].rtx))->code) == REG
      && ((((in)->fld[0].rtx))->fld[0].rtint) < 68
      && ! dont_remove_subreg)
    in = gen_rtx (REG, ((in)->mode),
    ((((in)->fld[0].rtx))->fld[0].rtint) + ((in)->fld[1].rtint));


  if (out != 0 && ((out)->code) == SUBREG
      && ((((out)->fld[0].rtx))->code) == REG
      && ((((out)->fld[0].rtx))->fld[0].rtint) < 68
      && ! dont_remove_subreg)
    out = gen_rtx (REG, ((out)->mode),
    ((((out)->fld[0].rtx))->fld[0].rtint) + ((out)->fld[1].rtint));



  if (in != 0)
    cxx_class = ((cxx_class) != ALL_REGS ? (cxx_class) : (((mode_class[(int)(((in)->mode))]) == MODE_FLOAT || (mode_class[(int)(((in)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((in)->mode))]) == MODE_INT || ((in)->mode) == VOIDmode) ? GR_REGS : (cxx_class))));
  if (this_insn_is_asm)
    {
      n64_enum_machine_mode mode;
      if ((mode_size[(int)(inmode)]) > (mode_size[(int)(outmode)]))
 mode = inmode;
      else
 mode = outmode;
      if (mode == VOIDmode)
 {
   error_for_asm (this_insn, "cannot reload integer constant operand in `asm'");
   mode = word_mode;
   if (in != 0)
     inmode = word_mode;
   if (out != 0)
     outmode = word_mode;
 }
      for (i = 0; i < 68; i++)
 if (mips_hard_regno_mode_ok[ (int)(mode) ][ (i) ]
     && ((reg_class_contents[(int) cxx_class])[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)))))
   {
     int nregs = (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

     int j;
     for (j = 1; j < nregs; j++)
       if (! ((reg_class_contents[(int) cxx_class])[(i + j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + j) % ((unsigned) 32)))))
  break;
     if (j == nregs)
       break;
   }
      if (i == 68)
 {
   error_for_asm (this_insn, "impossible register constraint in `asm'");
   cxx_class = ALL_REGS;
 }
    }

  if (cxx_class == NO_REGS)
    abort ();
  for (i = 0; i < n_reloads; i++)
    if ((reg_class_subset_p (cxx_class, reload_reg_class[i])
  || reg_class_subset_p (reload_reg_class[i], cxx_class))

 && (reload_reg_rtx[i] == 0
     || ((reg_class_contents[(int) cxx_class])[(true_regnum (reload_reg_rtx[i])) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((true_regnum (reload_reg_rtx[i])) % ((unsigned) 32))))
                                      )
 && ((in != 0 && (reload_in[i] == in || (reload_in[i] != 0 && (((reload_in[i])->code) == REG ? ((in)->code) == REG && ((reload_in[i])->fld[0].rtint) == ((in)->fld[0].rtint) : rtx_equal_p (reload_in[i], in) && ! side_effects_p (reload_in[i])))) && ! dont_share
      && (out == 0 || reload_out[i] == 0 || (reload_out[i] == out || (reload_out[i] != 0 && (((reload_out[i])->code) == REG ? ((out)->code) == REG && ((reload_out[i])->fld[0].rtint) == ((out)->fld[0].rtint) : rtx_equal_p (reload_out[i], out) && ! side_effects_p (reload_out[i]))))))
     ||
     (out != 0 && (reload_out[i] == out || (reload_out[i] != 0 && (((reload_out[i])->code) == REG ? ((out)->code) == REG && ((reload_out[i])->fld[0].rtint) == ((out)->fld[0].rtint) : rtx_equal_p (reload_out[i], out) && ! side_effects_p (reload_out[i]))))
      && (in == 0 || reload_in[i] == 0 || (reload_in[i] == in || (reload_in[i] != 0 && (((reload_in[i])->code) == REG ? ((in)->code) == REG && ((reload_in[i])->fld[0].rtint) == ((in)->fld[0].rtint) : rtx_equal_p (reload_in[i], in) && ! side_effects_p (reload_in[i])))))))
 && (reg_class_size[(int) cxx_class] == 1



     )
 && ((type) == RELOAD_OTHER || (reload_when_needed[i]) == RELOAD_OTHER || ((type) == (reload_when_needed[i]) && (opnum) == (reload_opnum[i])) || ((type) == RELOAD_FOR_INPUT && (reload_when_needed[i]) == RELOAD_FOR_INPUT) || ((type) == RELOAD_FOR_OPERAND_ADDRESS && (reload_when_needed[i]) == RELOAD_FOR_OPERAND_ADDRESS) || ((type) == RELOAD_FOR_OTHER_ADDRESS && (reload_when_needed[i]) == RELOAD_FOR_OTHER_ADDRESS))
                               )
      break;






  if (i == n_reloads)
    for (i = 0; i < n_reloads; i++)
      if ((reg_class_subset_p (cxx_class, reload_reg_class[i])
    || reg_class_subset_p (reload_reg_class[i], cxx_class))

   && (reload_reg_rtx[i] == 0
       || ((reg_class_contents[(int) cxx_class])[(true_regnum (reload_reg_rtx[i])) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((true_regnum (reload_reg_rtx[i])) % ((unsigned) 32))))
                                        )
   && out == 0 && reload_out[i] == 0 && reload_in[i] != 0
   && ((((in)->code) == REG
        && (((reload_in[i])->code) == POST_INC
     || ((reload_in[i])->code) == POST_DEC
     || ((reload_in[i])->code) == PRE_INC
     || ((reload_in[i])->code) == PRE_DEC)
        && (((reload_in[i])->fld[0].rtx) == in || (((reload_in[i])->fld[0].rtx) != 0 && (((((reload_in[i])->fld[0].rtx))->code) == REG ? ((in)->code) == REG && ((((reload_in[i])->fld[0].rtx))->fld[0].rtint) == ((in)->fld[0].rtint) : rtx_equal_p (((reload_in[i])->fld[0].rtx), in) && ! side_effects_p (((reload_in[i])->fld[0].rtx))))))
       ||
       (((reload_in[i])->code) == REG
        && (((in)->code) == POST_INC
     || ((in)->code) == POST_DEC
     || ((in)->code) == PRE_INC
     || ((in)->code) == PRE_DEC)
        && (((in)->fld[0].rtx) == reload_in[i] || (((in)->fld[0].rtx) != 0 && (((((in)->fld[0].rtx))->code) == REG ? ((reload_in[i])->code) == REG && ((((in)->fld[0].rtx))->fld[0].rtint) == ((reload_in[i])->fld[0].rtint) : rtx_equal_p (((in)->fld[0].rtx), reload_in[i]) && ! side_effects_p (((in)->fld[0].rtx)))))))
   && (reg_class_size[(int) cxx_class] == 1



       )
   && ((type) == RELOAD_OTHER || (reload_when_needed[i]) == RELOAD_OTHER || ((type) == (reload_when_needed[i]) && (opnum) == (reload_opnum[i])) || ((type) == RELOAD_FOR_INPUT && (reload_when_needed[i]) == RELOAD_FOR_INPUT) || ((type) == RELOAD_FOR_OPERAND_ADDRESS && (reload_when_needed[i]) == RELOAD_FOR_OPERAND_ADDRESS) || ((type) == RELOAD_FOR_OTHER_ADDRESS && (reload_when_needed[i]) == RELOAD_FOR_OTHER_ADDRESS))
                                 )
 {


   if (((in)->code) == REG)
     in = reload_in[i];
   break;
 }

  if (i == n_reloads)
    {





      if (in != 0)
 secondary_in_reload
   = push_secondary_reload (1, in, opnum, optional, cxx_class, inmode, type,
       &secondary_in_icode);



      if (out != 0 && ((out)->code) != SCRATCH)
 secondary_out_reload
   = push_secondary_reload (0, out, opnum, optional, cxx_class, outmode,
       type, &secondary_out_icode);





      i = n_reloads;
      reload_in[i] = in;
      reload_out[i] = out;
      reload_reg_class[i] = cxx_class;
      reload_inmode[i] = inmode;
      reload_outmode[i] = outmode;
      reload_reg_rtx[i] = 0;
      reload_optional[i] = optional;
      reload_inc[i] = 0;
      reload_nocombine[i] = 0;
      reload_in_reg[i] = inloc ? *inloc : 0;
      reload_opnum[i] = opnum;
      reload_when_needed[i] = type;
      reload_secondary_in_reload[i] = secondary_in_reload;
      reload_secondary_out_reload[i] = secondary_out_reload;
      reload_secondary_in_icode[i] = secondary_in_icode;
      reload_secondary_out_icode[i] = secondary_out_icode;
      reload_secondary_p[i] = 0;

      n_reloads++;



      if (in != 0 && ((in)->code) == REG
   && ((in)->fld[0].rtint) < 68
   && ((!(target_flags & 0x00400000) && (mode_class[(int)(inmode)]) == MODE_INT && ((mips_regno_to_class[ (((in)->fld[0].rtint)) ] == FP_REGS && cxx_class == GR_REGS) || (mips_regno_to_class[ (((in)->fld[0].rtint)) ] == GR_REGS && cxx_class == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (inmode) == DFmode && ((mips_regno_to_class[ (((in)->fld[0].rtint)) ] == GR_REGS && cxx_class == FP_REGS) || (cxx_class == GR_REGS && mips_regno_to_class[ (((in)->fld[0].rtint)) ] == FP_REGS))))
                       )
 get_secondary_mem (in, inmode, opnum, type);

      if (out != 0 && ((out)->code) == REG
   && ((out)->fld[0].rtint) < 68
   && ((!(target_flags & 0x00400000) && (mode_class[(int)(outmode)]) == MODE_INT && ((cxx_class == FP_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == GR_REGS) || (cxx_class == GR_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (outmode) == DFmode && ((cxx_class == GR_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == FP_REGS) || (mips_regno_to_class[ (((out)->fld[0].rtint)) ] == GR_REGS && cxx_class == FP_REGS))))
                  )
 get_secondary_mem (out, outmode, opnum, type);

    }
  else
    {





      if (inmode != VOIDmode)
 reload_inmode[i] = inmode;
      if (outmode != VOIDmode)
 reload_outmode[i] = outmode;
      if (in != 0)
 reload_in[i] = in;
      if (out != 0)
 reload_out[i] = out;
      if (reg_class_subset_p (cxx_class, reload_reg_class[i]))
 reload_reg_class[i] = cxx_class;
      reload_optional[i] &= optional;
      if (((type) != (reload_when_needed[i]) || ! ((opnum) == (reload_opnum[i]) || (type) == RELOAD_FOR_INPUT || (type) == RELOAD_FOR_OPERAND_ADDRESS || (type) == RELOAD_FOR_OTHER_ADDRESS))
                            )
 reload_when_needed[i] = RELOAD_OTHER;
      reload_opnum[i] = ((reload_opnum[i]) < (opnum) ? (reload_opnum[i]) : (opnum));
    }





  if (in != 0 && in != *inloc)
    reload_nocombine[i] = 1;
  if (replace_reloads)
    {
      if (inloc != 0)
 {
   register struct n64_tag_replacement *r = &replacements[n_replacements++];
   r->what = i;
   r->subreg_loc = in_subreg_loc;
   r->where = inloc;
   r->mode = inmode;
 }
      if (outloc != 0 && outloc != inloc)
 {
   register struct n64_tag_replacement *r = &replacements[n_replacements++];
   r->what = i;
   r->where = outloc;
   r->subreg_loc = out_subreg_loc;
   r->mode = outmode;
 }
    }
  if (in != 0 && out != 0 && in != out && reload_reg_rtx[i] == 0)
    {
      reload_reg_rtx[i] = find_dummy_reload (in, out, inloc, outloc,
          inmode, outmode,
          reload_reg_class[i], i);





      if (reload_reg_rtx[i] == out
   && (((in)->code) == REG || (((in)->code) == LABEL_REF || ((in)->code) == SYMBOL_REF || ((in)->code) == CONST_INT || ((in)->code) == CONST_DOUBLE || ((in)->code) == CONST || ((in)->code) == HIGH))
   && 0 != find_equiv_reg (in, this_insn, 0, ((out)->fld[0].rtint),
      static_reload_reg_p, i, inmode))
 reload_in[i] = out;
    }
  if (reload_reg_rtx[i] == 0 && in != 0)
    {
      rtx note;
      int regno;

      for (note = ((this_insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
 if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
     && ((((note)->fld[0].rtx))->code) == REG
     && (regno = ((((note)->fld[0].rtx))->fld[0].rtint)) < 68
     && reg_mentioned_p (((note)->fld[0].rtx), in)
     && ! refers_to_regno_for_reload_p (regno,
            (regno
      + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(inmode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(inmode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                   ),
            ((this_insn)->fld[3].rtx), inloc)



     && (out == 0 || in == out
  || ! hard_reg_set_here_p (regno,
       (regno
        + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(inmode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(inmode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                     ),
       ((this_insn)->fld[3].rtx)))



     && (in != out
  || (((in)->code) == SUBREG
      && ((((mode_size[(int)(((in)->mode))]) + (((target_flags & 0x00002000) ? 8 : 4) - 1))
    / ((target_flags & 0x00002000) ? 8 : 4))
   == (((mode_size[(int)(((((in)->fld[0].rtx))->mode))])
        + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4)))))

     && (mode_size[(int)(inmode)]) <= (mode_size[(int)(((((note)->fld[0].rtx))->mode))])
     && mips_hard_regno_mode_ok[ (int)(inmode) ][ (regno) ]
     && (mode_size[(int)(outmode)]) <= (mode_size[(int)(((((note)->fld[0].rtx))->mode))])
     && mips_hard_regno_mode_ok[ (int)(outmode) ][ (regno) ]
     && ((reg_class_contents[(int) cxx_class])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     && !fixed_regs[regno])
   {
     reload_reg_rtx[i] = gen_rtx (REG, inmode, regno);
     break;
   }
    }

  if (out)
    output_reloadnum = i;

  return i;
}







static void
push_replacement(rtx *loc, int reloadnum, n64_enum_machine_mode mode) asm("_push_replacement");
static void
push_replacement(rtx *loc, int reloadnum, n64_enum_machine_mode mode)
{
  if (replace_reloads)
    {
      register struct n64_tag_replacement *r = &replacements[n_replacements++];
      r->what = reloadnum;
      r->where = loc;
      r->subreg_loc = 0;
      r->mode = mode;
    }
}




void
transfer_replacements(int to, int from) asm("_transfer_replacements");
void
transfer_replacements(int to, int from)
{
  int i;

  for (i = 0; i < n_replacements; i++)
    if (replacements[i].what == from)
      replacements[i].what = to;
}
static void
combine_reloads(void) asm("_combine_reloads");
static void
combine_reloads(void)
{
  int i;
  int output_reload = -1;
  int secondary_out = -1;
  rtx note;




  for (i = 0; i < n_reloads; i++)
    if (reload_out[i] != 0)
      {
 if (output_reload >= 0)
   return;
 output_reload = i;
      }

  if (output_reload < 0 || reload_optional[output_reload])
    return;



  if (reload_in[output_reload] != 0)
    return;


  if (earlyclobber_operand_p (reload_out[output_reload]))
    return;



  for (i = 0; i < n_reloads; i++)
    if (reload_in[i] && ! reload_optional[i] && ! reload_nocombine[i]

 && reload_when_needed[i] != RELOAD_FOR_OUTPUT_ADDRESS
 && reload_when_needed[i] != RELOAD_OTHER
 && (((reload_reg_class[i]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(reload_inmode[i])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(reload_inmode[i])]) + (8) - 1) / (8))) : (((mode_size[(int)(reload_inmode[i])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))
     == ((reload_reg_class[output_reload]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(reload_outmode[output_reload])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(reload_outmode[output_reload])]) + (8) - 1) / (8))) : (((mode_size[(int)(reload_outmode[output_reload])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))
                                  )
 && reload_inc[i] == 0
 && reload_reg_rtx[i] == 0



 && (secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[i]] == 0
     || secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[output_reload]] == 0
     || rtx_equal_p (secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[i]],
       secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[output_reload]]))




 && (reg_class_subset_p (reload_reg_class[i],
    reload_reg_class[output_reload])
     || reg_class_subset_p (reload_reg_class[output_reload],
       reload_reg_class[i]))

 && ((reload_in[i] == reload_out[output_reload] || (reload_in[i] != 0 && (((reload_in[i])->code) == REG ? ((reload_out[output_reload])->code) == REG && ((reload_in[i])->fld[0].rtint) == ((reload_out[output_reload])->fld[0].rtint) : rtx_equal_p (reload_in[i], reload_out[output_reload]) && ! side_effects_p (reload_in[i]))))



     || (! reg_overlap_mentioned_for_reload_p (reload_out[output_reload],
            reload_in[i])






  && ! (((reload_in[i])->code) == REG
        && reg_overlap_mentioned_for_reload_p (reload_in[i],
            reload_out[output_reload]))))
 && (reg_class_size[(int) reload_reg_class[i]]



     )


 && (reload_when_needed[i] == RELOAD_FOR_INPUT
     || reload_when_needed[i] == RELOAD_FOR_OUTPUT))
      {
 int j;


 reload_out[i] = reload_out[output_reload];
 reload_outmode[i] = reload_outmode[output_reload];

 reload_out[output_reload] = 0;

 reload_when_needed[i] = RELOAD_OTHER;

 if (reload_secondary_out_reload[output_reload] != -1)
   {
     reload_secondary_out_reload[i]
       = reload_secondary_out_reload[output_reload];
     reload_secondary_out_icode[i]
       = reload_secondary_out_icode[output_reload];
   }



 if (secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[output_reload]] != 0)
   secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[i]]
     = secondary_memlocs_elim[(int) reload_outmode[output_reload]][reload_opnum[output_reload]];


 if (reg_class_subset_p (reload_reg_class[output_reload],
    reload_reg_class[i]))
   reload_reg_class[i] = reload_reg_class[output_reload];


 for (j = 0; j < n_replacements; j++)
   if (replacements[j].what == output_reload)
     replacements[j].what = i;

 return;
      }







  if (((this_insn)->fld[4].rtint) == -1)
    return;

  for (i = 1; i < insn_n_operands[((this_insn)->fld[4].rtint)]; i++)
    if (insn_operand_constraint[((this_insn)->fld[4].rtint)][i][0] == '='
 || insn_operand_constraint[((this_insn)->fld[4].rtint)][i][0] == '+')
      return;




  for (note = ((this_insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
    if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
 && ((((note)->fld[0].rtx))->code) == REG
 && ! reg_overlap_mentioned_for_reload_p (((note)->fld[0].rtx),
       reload_out[output_reload])
 && ((((note)->fld[0].rtx))->fld[0].rtint) < 68
 && mips_hard_regno_mode_ok[ (int)(reload_outmode[output_reload]) ][ (((((note)->fld[0].rtx))->fld[0].rtint)) ]
 && ((reg_class_contents[(int) reload_reg_class[output_reload]])[(((((note)->fld[0].rtx))->fld[0].rtint)) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((((((note)->fld[0].rtx))->fld[0].rtint)) % ((unsigned) 32))))

 && ((! ((unsigned) ((((((note)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_outmode[output_reload])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_outmode[output_reload])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
     <= (! ((unsigned) ((((((note)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))))


        && ((secondary_out = reload_secondary_out_reload[output_reload]) == -1
            || (! (((reg_class_contents[(int) reload_reg_class[secondary_out]])[(((((note)->fld[0].rtx))->fld[0].rtint)) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((((((note)->fld[0].rtx))->fld[0].rtint)) % ((unsigned) 32))))

                              )
  && ((secondary_out = reload_secondary_out_reload[secondary_out]) == -1
      || ! (((reg_class_contents[(int) reload_reg_class[secondary_out]])[(((((note)->fld[0].rtx))->fld[0].rtint)) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((((((note)->fld[0].rtx))->fld[0].rtint)) % ((unsigned) 32))))

                              ))))
 && ! fixed_regs[((((note)->fld[0].rtx))->fld[0].rtint)])
      {
 reload_reg_rtx[output_reload] = gen_rtx (REG,
       reload_outmode[output_reload],
       ((((note)->fld[0].rtx))->fld[0].rtint));
 return;
      }
}
static rtx
find_dummy_reload(rtx real_in, rtx real_out, rtx *inloc, rtx *outloc, n64_enum_machine_mode inmode, n64_enum_machine_mode outmode, n64_enum_reg_class cxx_class, int for_real) asm("_find_dummy_reload");
static rtx
find_dummy_reload(rtx real_in, rtx real_out, rtx *inloc, rtx *outloc, n64_enum_machine_mode inmode, n64_enum_machine_mode outmode, n64_enum_reg_class cxx_class, int for_real)
{
  rtx in = real_in;
  rtx out = real_out;
  int in_offset = 0;
  int out_offset = 0;
  rtx value = 0;



  if ((mode_size[(int)(outmode)]) != (mode_size[(int)(inmode)])
      && ((mode_size[(int)(outmode)]) > ((target_flags & 0x00002000) ? 8 : 4)
   || (mode_size[(int)(inmode)]) > ((target_flags & 0x00002000) ? 8 : 4)))
    return 0;


  while (((out)->code) == SUBREG)
    {
      out_offset = ((out)->fld[1].rtint);
      out = ((out)->fld[0].rtx);
    }
  while (((in)->code) == SUBREG)
    {
      in_offset = ((in)->fld[1].rtint);
      in = ((in)->fld[0].rtx);
    }



  cxx_class = ((cxx_class) != ALL_REGS ? (cxx_class) : (((mode_class[(int)(((in)->mode))]) == MODE_FLOAT || (mode_class[(int)(((in)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((in)->mode))]) == MODE_INT || ((in)->mode) == VOIDmode) ? GR_REGS : (cxx_class))));


  if (((out)->code) == REG
      && ((out)->fld[0].rtint) < 68)
    {
      register int regno = ((out)->fld[0].rtint) + out_offset;
      int nwords = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(outmode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(outmode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      rtx saved_rtx;
      saved_rtx = *inloc;
      *inloc = const0_rtx;

      if (regno < 68





   && ! refers_to_regno_for_reload_p (regno, regno + nwords,
          ((this_insn)->fld[3].rtx), outloc))
 {
   int i;
   for (i = 0; i < nwords; i++)
     if (! ((reg_class_contents[(int) cxx_class])[(regno + i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + i) % ((unsigned) 32))))
                   )
       break;

   if (i == nwords)
     {
       if (((real_out)->code) == REG)
  value = real_out;
       else
  value = gen_rtx (REG, outmode, regno);
     }
 }

      *inloc = saved_rtx;
    }






  if (hard_regs_live_known
      && ((in)->code) == REG
      && ((in)->fld[0].rtint) < 68
      && (value == 0
   || find_reg_note (this_insn, REG_UNUSED, real_out))
      && find_reg_note (this_insn, REG_DEAD, real_in)
      && !fixed_regs[((in)->fld[0].rtint)]
      && mips_hard_regno_mode_ok[ (int)((((out)->mode) != VOIDmode ? ((out)->mode) : outmode)) ][ (((in)->fld[0].rtint)) ]





                                     )
    {
      register int regno = ((in)->fld[0].rtint) + in_offset;
      int nwords = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(inmode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(inmode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

      if (! refers_to_regno_for_reload_p (regno, regno + nwords, out, ((void *)0))
   && ! hard_reg_set_here_p (regno, regno + nwords,
        ((this_insn)->fld[3].rtx)))
 {
   int i;
   for (i = 0; i < nwords; i++)
     if (! ((reg_class_contents[(int) cxx_class])[(regno + i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + i) % ((unsigned) 32))))
                   )
       break;

   if (i == nwords)
     {



       if (for_real >= 0 && value == real_out)
  reload_out[for_real] = 0;
       if (((real_in)->code) == REG)
  value = real_in;
       else
  value = gen_rtx (REG, inmode, regno);
     }
 }
    }

  return value;
}







static int
earlyclobber_operand_p(rtx x) asm("_earlyclobber_operand_p");
static int
earlyclobber_operand_p(rtx x)
{
  int i;

  for (i = 0; i < n_earlyclobbers; i++)
    if (reload_earlyclobbers[i] == x)
      return 1;

  return 0;
}






static int
hard_reg_set_here_p(register int beg_regno, register int end_regno, rtx x) asm("_hard_reg_set_here_p");
static int
hard_reg_set_here_p(register int beg_regno, register int end_regno, rtx x)
{
  if (((x)->code) == SET || ((x)->code) == CLOBBER)
    {
      register rtx op0 = ((x)->fld[0].rtx);
      while (((op0)->code) == SUBREG)
 op0 = ((op0)->fld[0].rtx);
      if (((op0)->code) == REG)
 {
   register int r = ((op0)->fld[0].rtint);

   if (r < end_regno
       && r + (! ((unsigned) ((r) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((op0)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((op0)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > beg_regno)
     return 1;
 }
    }
  else if (((x)->code) == PARALLEL)
    {
      register int i = ((x)->fld[0].rtvec->num_elem) - 1;
      for (; i >= 0; i--)
 if (hard_reg_set_here_p (beg_regno, end_regno, ((x)->fld[0].rtvec->elem[i].rtx)))
   return 1;
    }

  return 0;
}





int
strict_memory_address_p(n64_enum_machine_mode mode, register rtx addr) asm("_strict_memory_address_p");
int
strict_memory_address_p(n64_enum_machine_mode mode, register rtx addr)
{
  { register rtx xinsn = (addr); if ((target_flags & 0x10000000)) { trace("\n========== GO_IF_LEGITIMATE_ADDRESS, %sstrict\n",(1) ? "" : "not "); debug_rtx(xinsn); } if (((xinsn)->code) == REG && ((unsigned) (((((xinsn)->fld[0].rtint) < 68) ? ((xinsn)->fld[0].rtint) : reg_renumber[((xinsn)->fld[0].rtint)]) - 0) < (31 - 0 + 1))) goto win; if (((((xinsn)->code) == LABEL_REF || ((xinsn)->code) == SYMBOL_REF || ((xinsn)->code) == CONST_INT || ((xinsn)->code) == HIGH || (((xinsn)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xinsn)) && ! 0)) && (!0 || !0))) goto win; if (((xinsn)->code) == PLUS) { register rtx xplus0 = ((xinsn)->fld[0].rtx); register rtx xplus1 = ((xinsn)->fld[1].rtx); register n64_enum_rtx_code code0 = ((xplus0)->code); register n64_enum_rtx_code code1 = ((xplus1)->code); if (code0 != REG && code1 == REG) { xplus0 = ((xinsn)->fld[1].rtx); xplus1 = ((xinsn)->fld[0].rtx); code0 = ((xplus0)->code); code1 = ((xplus1)->code); } if (code0 == REG && ((unsigned) (((((xplus0)->fld[0].rtint) < 68) ? ((xplus0)->fld[0].rtint) : reg_renumber[((xplus0)->fld[0].rtint)]) - 0) < (31 - 0 + 1))) { if (code1 == CONST_INT && ((xplus1)->fld[0].rtwint) >= -32768 && ((xplus1)->fld[0].rtwint) + (mode_size[(int)(mode)]) - 1 <= 32767) goto win; if (!(target_flags & 0x20000000) && ! 0 && ((((xplus1)->code) == LABEL_REF || ((xplus1)->code) == SYMBOL_REF || ((xplus1)->code) == CONST_INT || ((xplus1)->code) == HIGH || (((xplus1)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xplus1)) && ! 0)) && (!0 || !0)) && (!(target_flags & 0x00004000) || code1 != CONST || ((((xplus1)->fld[0].rtx))->code) != MINUS)) goto win; } } if ((target_flags & 0x10000000)) trace("Not a legitimate address\n"); };
  return 0;

 win:
  return 1;
}
int
operands_match_p(register rtx x, register rtx y) asm("_operands_match_p");
int
operands_match_p(register rtx x, register rtx y)
{
  register int i;
  register n64_enum_rtx_code code = ((x)->code);
  register char *fmt;
  int success_2;

  if (x == y)
    return 1;
  if ((code == REG || (code == SUBREG && ((((x)->fld[0].rtx))->code) == REG))
      && (((y)->code) == REG || (((y)->code) == SUBREG
      && ((((y)->fld[0].rtx))->code) == REG)))
    {
      register int j;

      if (code == SUBREG)
 {
   i = ((((x)->fld[0].rtx))->fld[0].rtint);
   if (i >= 68)
     goto slow;
   i += ((x)->fld[1].rtint);
 }
      else
 i = ((x)->fld[0].rtint);

      if (((y)->code) == SUBREG)
 {
   j = ((((y)->fld[0].rtx))->fld[0].rtint);
   if (j >= 68)
     goto slow;
   j += ((y)->fld[1].rtint);
 }
      else
 j = ((y)->fld[0].rtint);




      if (((target_flags & 0x00010000) != 0) && (mode_size[(int)(((x)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4)
   && i < 68)
 i += ((mode_size[(int)(((x)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4)) - 1;
      if (((target_flags & 0x00010000) != 0) && (mode_size[(int)(((y)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4)
   && j < 68)
 j += ((mode_size[(int)(((y)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4)) - 1;

      return i == j;
    }





  if (code == POST_DEC || code == POST_INC)
    return operands_match_p (((x)->fld[0].rtx), y);






  if (((y)->code) == PRE_DEC || ((y)->code) == PRE_INC)
    return operands_match_p (x, ((y)->fld[0].rtx)) ? 2 : 0;

 slow:



  if (code != ((y)->code))
    return 0;
  if (code == LABEL_REF)
    return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);
  if (code == SYMBOL_REF)
    return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);



  if (((x)->mode) != ((y)->mode))
    return 0;




  success_2 = 0;
  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      int val;
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'e':
   val = operands_match_p (((x)->fld[i].rtx), ((y)->fld[i].rtx));
   if (val == 0)
     return 0;


   if (val == 2)
     success_2 = 1;
   break;

 case '0':
   break;




 default:
   abort ();
 }
    }
  return 1 + success_2;
}



int
n_occurrences(int c, char *s) asm("_n_occurrences");
int
n_occurrences(int c, char *s)
{
  int n = 0;
  while (*s)
    n += (*s++ == c);
  return n;
}
static struct n64_tag_decomposition
decompose(rtx x) asm("_decompose");
static struct n64_tag_decomposition
decompose(rtx x)
{
  struct n64_tag_decomposition val;
  int all_const = 0;

  val.reg_flag = 0;
  val.safe = 0;
  if (((x)->code) == MEM)
    {
      rtx base, offset = 0;
      rtx addr = ((x)->fld[0].rtx);

      if (((addr)->code) == PRE_DEC || ((addr)->code) == PRE_INC
   || ((addr)->code) == POST_DEC || ((addr)->code) == POST_INC)
 {
   val.base = ((addr)->fld[0].rtx);
   val.start = - (mode_size[(int)(((x)->mode))]);
   val.end = (mode_size[(int)(((x)->mode))]);
   val.safe = ((val.base)->fld[0].rtint) == (0 + 29);
   return val;
 }

      if (((addr)->code) == CONST)
 {
   addr = ((addr)->fld[0].rtx);
   all_const = 1;
 }
      if (((addr)->code) == PLUS)
 {
   if ((((((addr)->fld[0].rtx))->code) == LABEL_REF || ((((addr)->fld[0].rtx))->code) == SYMBOL_REF || ((((addr)->fld[0].rtx))->code) == CONST_INT || ((((addr)->fld[0].rtx))->code) == CONST_DOUBLE || ((((addr)->fld[0].rtx))->code) == CONST || ((((addr)->fld[0].rtx))->code) == HIGH))
     {
       base = ((addr)->fld[1].rtx);
       offset = ((addr)->fld[0].rtx);
     }
   else if ((((((addr)->fld[1].rtx))->code) == LABEL_REF || ((((addr)->fld[1].rtx))->code) == SYMBOL_REF || ((((addr)->fld[1].rtx))->code) == CONST_INT || ((((addr)->fld[1].rtx))->code) == CONST_DOUBLE || ((((addr)->fld[1].rtx))->code) == CONST || ((((addr)->fld[1].rtx))->code) == HIGH))
     {
       base = ((addr)->fld[0].rtx);
       offset = ((addr)->fld[1].rtx);
     }
 }

      if (offset == 0)
 {
   base = addr;
   offset = const0_rtx;
 }
      if (((offset)->code) == CONST)
 offset = ((offset)->fld[0].rtx);
      if (((offset)->code) == PLUS)
 {
   if (((((offset)->fld[0].rtx))->code) == CONST_INT)
     {
       base = gen_rtx (PLUS, ((base)->mode), base, ((offset)->fld[1].rtx));
       offset = ((offset)->fld[0].rtx);
     }
   else if (((((offset)->fld[1].rtx))->code) == CONST_INT)
     {
       base = gen_rtx (PLUS, ((base)->mode), base, ((offset)->fld[0].rtx));
       offset = ((offset)->fld[1].rtx);
     }
   else
     {
       base = gen_rtx (PLUS, ((base)->mode), base, offset);
       offset = const0_rtx;
     }
 }
      else if (((offset)->code) != CONST_INT)
 {
   base = gen_rtx (PLUS, ((base)->mode), base, offset);
   offset = const0_rtx;
 }

      if (all_const && ((base)->code) == PLUS)
 base = gen_rtx (CONST, ((base)->mode), base);

      if (((offset)->code) != CONST_INT)
 abort ();

      val.start = ((offset)->fld[0].rtwint);
      val.end = val.start + (mode_size[(int)(((x)->mode))]);
      val.base = base;
      return val;
    }
  else if (((x)->code) == REG)
    {
      val.reg_flag = 1;
      val.start = true_regnum (x);
      if (val.start < 0)
 {

   val.start = ((x)->fld[0].rtint);
   val.end = val.start + 1;
 }
      else

 val.end = val.start + (! ((unsigned) ((val.start) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
    }
  else if (((x)->code) == SUBREG)
    {
      if (((((x)->fld[0].rtx))->code) != REG)

 return decompose (((x)->fld[0].rtx));
      val.reg_flag = 1;
      val.start = true_regnum (x);
      if (val.start < 0)
 return decompose (((x)->fld[0].rtx));
      else

 val.end = val.start + (! ((unsigned) ((val.start) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
    }
  else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH)

    || ((x)->code) == SCRATCH)
    val.safe = 1;
  else
    abort ();
  return val;
}




static int
immune_p(rtx x, rtx y, struct n64_tag_decomposition ydata) asm("_immune_p");
static int
immune_p(rtx x, rtx y, struct n64_tag_decomposition ydata)
{
  struct n64_tag_decomposition xdata;

  if (ydata.reg_flag)
    return !refers_to_regno_for_reload_p (ydata.start, ydata.end, x, ((void *)0));
  if (ydata.safe)
    return 1;

  if (((y)->code) != MEM)
    abort ();

  if (((x)->code) != MEM)
    return 1;

  xdata = decompose (x);

  if (! rtx_equal_p (xdata.base, ydata.base))
    {

      if ((((xdata.base)->code) == LABEL_REF || ((xdata.base)->code) == SYMBOL_REF || ((xdata.base)->code) == CONST_INT || ((xdata.base)->code) == CONST_DOUBLE || ((xdata.base)->code) == CONST || ((xdata.base)->code) == HIGH) && (((ydata.base)->code) == LABEL_REF || ((ydata.base)->code) == SYMBOL_REF || ((ydata.base)->code) == CONST_INT || ((ydata.base)->code) == CONST_DOUBLE || ((ydata.base)->code) == CONST || ((ydata.base)->code) == HIGH))
 return 1;

      if ((((xdata.base)->code) == LABEL_REF || ((xdata.base)->code) == SYMBOL_REF || ((xdata.base)->code) == CONST_INT || ((xdata.base)->code) == CONST_DOUBLE || ((xdata.base)->code) == CONST || ((xdata.base)->code) == HIGH)
   && (ydata.base == frame_pointer_rtx
       || ydata.base == hard_frame_pointer_rtx
       || ydata.base == stack_pointer_rtx))
 return 1;
      if ((((ydata.base)->code) == LABEL_REF || ((ydata.base)->code) == SYMBOL_REF || ((ydata.base)->code) == CONST_INT || ((ydata.base)->code) == CONST_DOUBLE || ((ydata.base)->code) == CONST || ((ydata.base)->code) == HIGH)
   && (xdata.base == frame_pointer_rtx
       || xdata.base == hard_frame_pointer_rtx
       || xdata.base == stack_pointer_rtx))
 return 1;

      return 0;
    }


  return (xdata.start >= ydata.end || ydata.start >= xdata.end);
}



int
safe_from_earlyclobber(rtx op, rtx clobber) asm("_safe_from_earlyclobber");
int
safe_from_earlyclobber(rtx op, rtx clobber)
{
  struct n64_tag_decomposition early_data;

  early_data = decompose (clobber);
  return immune_p (op, clobber, early_data);
}
void
find_reloads(rtx insn, int replace, int ind_levels, int live_known, short int *reload_reg_p) asm("_find_reloads");
void
find_reloads(rtx insn, int replace, int ind_levels, int live_known, short int *reload_reg_p)
{


  register int insn_code_number;
  register int i, j;
  int noperands;

  char *constraints1[10];


  char *constraints[10];


  n64_enum_reg_class preferred_class[10];
  char pref_or_nothing[10];

  int address_reloaded[10];

  n64_enum_reload_type operand_type[10];

  n64_enum_reload_type address_type[10];

  enum n64_cpp_enum_reload_usage{ RELOAD_READ, RELOAD_READ_WRITE, RELOAD_WRITE };
typedef __underlying_type(enum n64_cpp_enum_reload_usage) n64_enum_reload_usage;
n64_enum_reload_usage modified[10];
  int no_input_reloads = 0, no_output_reloads = 0;
  int n_alternatives;
  int this_alternative[10];
  char this_alternative_win[10];
  char this_alternative_offmemok[10];
  char this_alternative_earlyclobber[10];
  int this_alternative_matches[10];
  int swapped;
  int goal_alternative[10];
  int this_alternative_number;
  int goal_alternative_number;
  int operand_reloadnum[10];
  int goal_alternative_matches[10];
  int goal_alternative_matched[10];
  char goal_alternative_win[10];
  char goal_alternative_offmemok[10];
  char goal_alternative_earlyclobber[10];
  int goal_alternative_swapped;
  int best;
  int commutative;
  char operands_match[10][10];
  rtx substed_operand[10];
  rtx body = ((insn)->fld[3].rtx);
  rtx set = single_set (insn);
  int goal_earlyclobber, this_earlyclobber;
  n64_enum_machine_mode operand_mode[10];

  this_insn = insn;
  this_insn_is_asm = 0;
  n_reloads = 0;
  n_replacements = 0;
  n_memlocs = 0;
  n_earlyclobbers = 0;
  replace_reloads = replace;
  hard_regs_live_known = live_known;
  static_reload_reg_p = reload_reg_p;




  if (((insn)->code) == JUMP_INSN || ((insn)->code) == CALL_INSN)
    no_output_reloads = 1;
  memset ((char *) secondary_memlocs_elim,0,sizeof secondary_memlocs_elim);
  switch (((body)->code))
    {
    case USE:
    case CLOBBER:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return;

    case SET:



      if (((((body)->fld[0].rtx))->code) == REG
   && ((((body)->fld[0].rtx))->fld[0].rtint) < 68
   && ((((body)->fld[1].rtx))->code) == REG
   && ((((body)->fld[1].rtx))->fld[0].rtint) < 68
   && ((mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == GR_REGS && (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == GR_REGS ? 2 : (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == FP_REGS && (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == FP_REGS ? 2 : (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == GR_REGS && (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == FP_REGS ? 4 : (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == FP_REGS && (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == GR_REGS ? 4 : (((mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == HI_REG || (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == LO_REG || (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == MD_REGS || (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == HILO_REG) && (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == GR_REGS) ? 6 : (((mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == HI_REG || (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == LO_REG || (mips_regno_to_class[ (((((body)->fld[0].rtx))->fld[0].rtint)) ]) == MD_REGS || (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == HILO_REG) && (mips_regno_to_class[ (((((body)->fld[1].rtx))->fld[0].rtint)) ]) == GR_REGS) ? 6 : 12)
                                                == 2)
 return;
    case PARALLEL:
    case ASM_OPERANDS:
      reload_n_operands = noperands = asm_noperands (body);
      if (noperands >= 0)
 {


   insn_code_number = -1;
   this_insn_is_asm = 1;


   if (noperands > 10)
     abort ();



   decode_asm_operands (body, recog_operand, recog_operand_loc,
          constraints, operand_mode);
   if (noperands > 0)
     {
       memcpy ((char *) constraints1,(char *) constraints,noperands * sizeof (char *))
                                   ;
       n_alternatives = n_occurrences (',', constraints[0]) + 1;
       for (i = 1; i < noperands; i++)
  if (n_alternatives != n_occurrences (',', constraints[i]) + 1)
    {
      error_for_asm (insn, "operand constraints differ in number of alternatives");

      ((insn)->fld[3].rtx) = gen_rtx (USE, VOIDmode, const0_rtx);
      n_reloads = 0;
      return;
    }
     }
   break;
 }

    default:



      insn_code_number = recog_memoized (insn);
      if (insn_code_number < 0)
 fatal_insn_not_found (insn);

      reload_n_operands = noperands = insn_n_operands[insn_code_number];
      n_alternatives = insn_n_alternatives[insn_code_number];

      if (n_alternatives == 0)
 return;
      insn_extract (insn);
      for (i = 0; i < noperands; i++)
 {
   constraints[i] = constraints1[i]
     = insn_operand_constraint[insn_code_number][i];
   operand_mode[i] = insn_operand_mode[insn_code_number][i];
 }
    }

  if (noperands == 0)
    return;

  commutative = -1;






  for (i = 0; i < noperands; i++)
    {
      register char *p;
      register int c;

      substed_operand[i] = recog_operand[i];
      p = constraints[i];

      modified[i] = RELOAD_READ;




      while (c = *p++)
 {
   if (c == '=')
     modified[i] = RELOAD_WRITE;
   else if (c == '+')
     modified[i] = RELOAD_READ_WRITE;
   else if (c == '%')
     {

       if (i == noperands - 1)
  {
    if (this_insn_is_asm)
      warning_for_asm (this_insn,
         "`%%' constraint used with last operand");
    else
      abort ();
  }
       else
  commutative = i;
     }
   else if (c >= '0' && c <= '9')
     {
       c -= '0';
       operands_match[c][i]
  = operands_match_p (recog_operand[c], recog_operand[i]);


       if (c == i)
  {
    if (this_insn_is_asm)
      warning_for_asm (this_insn,
         "operand %d has constraint %d", i, c);
    else
      abort ();
  }



       if (commutative >= 0)
  {
    if (c == commutative || c == commutative + 1)
      {
        int other = c + (c == commutative ? 1 : -1);
        operands_match[other][i]
   = operands_match_p (recog_operand[other], recog_operand[i]);
      }
    if (i == commutative || i == commutative + 1)
      {
        int other = i + (i == commutative ? 1 : -1);
        operands_match[c][other]
   = operands_match_p (recog_operand[c], recog_operand[other]);
      }



  }
     }
 }
    }
  for (i = 0; i < noperands; i++)
    {
      register n64_enum_rtx_code code = ((recog_operand[i])->code);

      address_reloaded[i] = 0;
      operand_type[i] = (modified[i] == RELOAD_READ ? RELOAD_FOR_INPUT
    : modified[i] == RELOAD_WRITE ? RELOAD_FOR_OUTPUT
    : RELOAD_OTHER);
      address_type[i]
 = (modified[i] == RELOAD_READ ? RELOAD_FOR_INPUT_ADDRESS
    : modified[i] == RELOAD_WRITE ? RELOAD_FOR_OUTPUT_ADDRESS
    : RELOAD_OTHER);

      if (*constraints[i] == 0)

 ;
      else if (constraints[i][0] == 'p')
 {
   find_reloads_address (VOIDmode, ((void *)0),
    recog_operand[i], recog_operand_loc[i],
    i, operand_type[i], ind_levels);
   substed_operand[i] = recog_operand[i] = *recog_operand_loc[i];
 }
      else if (code == MEM)
 {
   if (find_reloads_address (((recog_operand[i])->mode),
        recog_operand_loc[i],
        ((recog_operand[i])->fld[0].rtx),
        &((recog_operand[i])->fld[0].rtx),
        i, address_type[i], ind_levels))
     address_reloaded[i] = 1;
   substed_operand[i] = recog_operand[i] = *recog_operand_loc[i];
 }
      else if (code == SUBREG)
 substed_operand[i] = recog_operand[i] = *recog_operand_loc[i]
   = find_reloads_toplev (recog_operand[i], i, address_type[i],
     ind_levels,
     set != 0
     && &((set)->fld[0].rtx) == recog_operand_loc[i]);
      else if (code == PLUS)


 substed_operand[i] = recog_operand[i] = *recog_operand_loc[i]
   = find_reloads_toplev (recog_operand[i], i, address_type[i],
     ind_levels, 0);
      else if (code == REG)
 {






   register int regno = ((recog_operand[i])->fld[0].rtint);
   if (reg_equiv_constant[regno] != 0
       && (set == 0 || &((set)->fld[0].rtx) != recog_operand_loc[i]))
     substed_operand[i] = recog_operand[i]
       = reg_equiv_constant[regno];






   if (reg_equiv_address[regno] != 0)
     {




       rtx address = ((eliminate_regs (reg_equiv_memory_loc[regno], 0, (rtx) 0))->fld[0].rtx)

        ;

       if (rtx_varies_p (address))
  address = copy_rtx (address);






       if (modified[i] != RELOAD_READ)
  ((emit_insn_after (gen_rtx (CLOBBER, VOIDmode, recog_operand[i]), insn))->mode = (DImode))


            ;

       *recog_operand_loc[i] = recog_operand[i]
  = gen_rtx (MEM, ((recog_operand[i])->mode), address);
       ((recog_operand[i])->unchanging)
  = ((regno_reg_rtx[regno])->unchanging);
       find_reloads_address (((recog_operand[i])->mode),
        recog_operand_loc[i],
        ((recog_operand[i])->fld[0].rtx),
        &((recog_operand[i])->fld[0].rtx),
        i, address_type[i], ind_levels);
       substed_operand[i] = recog_operand[i] = *recog_operand_loc[i];
     }
 }


      code = ((recog_operand[i])->code);
      preferred_class[i]
 = ((code == REG && ((recog_operand[i])->fld[0].rtint) >= 68)
    ? reg_preferred_class (((recog_operand[i])->fld[0].rtint)) : NO_REGS);
      pref_or_nothing[i]
 = (code == REG && ((recog_operand[i])->fld[0].rtint) >= 68
    && reg_alternate_class (((recog_operand[i])->fld[0].rtint)) == NO_REGS);
    }



  if (set != 0 && noperands >= 2 && recog_operand[0] == ((set)->fld[0].rtx)
      && recog_operand[1] == ((set)->fld[1].rtx))
    {
      preferred_class[0] = preferred_class[1]
 = reg_class_subunion[(int) preferred_class[0]][(int) preferred_class[1]];
      pref_or_nothing[0] |= pref_or_nothing[1];
      pref_or_nothing[1] |= pref_or_nothing[0];
    }





  best = 10 + 300;

  swapped = 0;
  goal_alternative_swapped = 0;
 try_swapped:
  for (this_alternative_number = 0;
       this_alternative_number < n_alternatives;
       this_alternative_number++)
    {



      int losers = 0;


      int bad = 0;






      int reject = 0;

      this_earlyclobber = 0;

      for (i = 0; i < noperands; i++)
 {
   register char *p = constraints[i];
   register int win = 0;

   int badop = 1;

   int winreg = 0;
   int c;
   register rtx operand = recog_operand[i];
   int offset = 0;


   int force_reload = 0;
   int offmemok = 0;


   int constmemok = 0;
   int earlyclobber = 0;





   while (((operand)->code) == SUBREG)
     {
       offset += ((operand)->fld[1].rtint);
       operand = ((operand)->fld[0].rtx);


       if ((((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH)
    || ((operand)->code) == PLUS
    || ((((operand)->code) == MEM
         || (((operand)->code)== REG
      && ((operand)->fld[0].rtint) >= 68))
        && ((((8 * mode_size[(int)(((operand)->mode))])
       < 64)
      && ((mode_size[(int)(operand_mode[i])])
          > (mode_size[(int)(((operand)->mode))])))
     || (((operand)->code) == MEM && ((target_flags & 0x00010000) != 0))

     || ((mode_size[(int)(operand_mode[i])]) <= ((target_flags & 0x00002000) ? 8 : 4)
         && ((mode_size[(int)(((operand)->mode))])
      <= ((target_flags & 0x00002000) ? 8 : 4))
         && ((mode_size[(int)(operand_mode[i])])
      > (mode_size[(int)(((operand)->mode))]))
         && ((mode_class[(int)(((operand)->mode))]) == MODE_INT || (mode_class[(int)(((operand)->mode))]) == MODE_PARTIAL_INT || (mode_class[(int)(((operand)->mode))]) == MODE_COMPLEX_INT)
         && ZERO_EXTEND != NIL)

     ))



    || (((operand)->code) == REG
        && ((operand)->fld[0].rtint) < 68
        && (((mode_size[(int)(operand_mode[i])]) <= ((target_flags & 0x00002000) ? 8 : 4)
      && ((mode_size[(int)(((operand)->mode))])
          > ((target_flags & 0x00002000) ? 8 : 4))
      && (((mode_size[(int)(((operand)->mode))])
    / ((target_flags & 0x00002000) ? 8 : 4))
          != (! ((unsigned) ((((operand)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((operand)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((operand)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                             ))
     || ! mips_hard_regno_mode_ok[ (int)(operand_mode[i]) ][ (((operand)->fld[0].rtint) + offset) ]
                         )))
  force_reload = 1;
     }

   this_alternative[i] = (int) NO_REGS;
   this_alternative_win[i] = 0;
   this_alternative_offmemok[i] = 0;
   this_alternative_earlyclobber[i] = 0;
   this_alternative_matches[i] = -1;



   if (*p == 0 || *p == ',')
     win = 1, badop = 0;
   while (*p && (c = *p++) != ',')
     switch (c)
       {
       case '=':
       case '+':
       case '*':
  break;

       case '%':

  if (i != noperands - 1)
    commutative = i;
  break;

       case '?':
  reject += 3;
  break;

       case '!':
  reject = 300;
  break;

       case '#':


  while (*p && *p != ',') p++;
  break;

       case '0':
       case '1':
       case '2':
       case '3':
       case '4':
  c -= '0';
  this_alternative_matches[i] = c;







  if ((swapped && (c != commutative || i != commutative + 1))






      ? (operands_match
          [(c == commutative || c == commutative + 1)
    ? 2*commutative + 1 - c : c]
          [(i == commutative || i == commutative + 1)
    ? 2*commutative + 1 - i : i])
      : operands_match[c][i])
    win = this_alternative_win[c];
  else
    {

      rtx value;


      if (this_alternative_win[c])
        losers++;
      this_alternative_win[c] = 0;
      if (this_alternative[c] == (int) NO_REGS)
        bad = 1;


      value
        = find_dummy_reload (recog_operand[i], recog_operand[c],
        recog_operand_loc[i], recog_operand_loc[c],
        operand_mode[i], operand_mode[c],
        this_alternative[c], -1);

      if (value != 0)
        losers--;
    }


  badop = 0;
  this_alternative[i] = this_alternative[c];





  if (! win || force_reload)
    for (j = 0; j < i; j++)
      if (this_alternative_matches[j]
   == this_alternative_matches[i])
        badop = 1;

  break;

       case 'p':


  this_alternative[i] = (int) GR_REGS;
  win = 1;
  break;

       case 'm':
  if (force_reload)
    break;
  if (((operand)->code) == MEM
      || (((operand)->code) == REG
   && ((operand)->fld[0].rtint) >= 68
   && reg_renumber[((operand)->fld[0].rtint)] < 0))
    win = 1;
  if ((((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH))
    badop = 0;
  constmemok = 1;
  break;

       case '<':
  if (((operand)->code) == MEM
      && ! address_reloaded[i]
      && (((((operand)->fld[0].rtx))->code) == PRE_DEC
   || ((((operand)->fld[0].rtx))->code) == POST_DEC))
    win = 1;
  break;

       case '>':
  if (((operand)->code) == MEM
      && ! address_reloaded[i]
      && (((((operand)->fld[0].rtx))->code) == PRE_INC
   || ((((operand)->fld[0].rtx))->code) == POST_INC))
    win = 1;
  break;


       case 'V':
  if (force_reload)
    break;
  if (((operand)->code) == MEM
      && ! (ind_levels ? offsettable_memref_p (operand)
     : offsettable_nonstrict_memref_p (operand))




      && !(((((operand)->fld[0].rtx))->code) == REG
    && (ind_levels == 0
        || reg_equiv_address[((((operand)->fld[0].rtx))->fld[0].rtint)] != 0)))
    win = 1;
  break;


       case 'o':
  if (force_reload)
    break;
  if ((((operand)->code) == MEM



       && (ind_levels ? offsettable_memref_p (operand)
    : offsettable_nonstrict_memref_p (operand)))


      || (((operand)->code) == MEM
   && address_reloaded[i]
   && (((((operand)->fld[0].rtx))->code) == PRE_INC
       || ((((operand)->fld[0].rtx))->code) == PRE_DEC
       || ((((operand)->fld[0].rtx))->code) == POST_INC
       || ((((operand)->fld[0].rtx))->code) == POST_DEC))




      || (((operand)->code) == MEM
   && ((((operand)->fld[0].rtx))->code) == REG
   && (ind_levels == 0
       || reg_equiv_address[((((operand)->fld[0].rtx))->fld[0].rtint)] != 0))
      || (((operand)->code) == REG
   && ((operand)->fld[0].rtint) >= 68
   && reg_renumber[((operand)->fld[0].rtint)] < 0




   && ((reg_equiv_mem[((operand)->fld[0].rtint)] != 0
        && offsettable_memref_p (reg_equiv_mem[((operand)->fld[0].rtint)]))
       || (reg_equiv_address[((operand)->fld[0].rtint)] != 0))))
    win = 1;
  if ((((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH) || ((operand)->code) == MEM)
    badop = 0;
  constmemok = 1;
  offmemok = 1;
  break;

       case '&':


  earlyclobber = 1, this_earlyclobber = 1;
  break;

       case 'E':
  if (((operand)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'F':
  if (((operand)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'G':
       case 'H':
  if (((operand)->code) == CONST_DOUBLE
      && ((c) == 'G' && (operand) == (const_tiny_rtx[0][(int) (((operand)->mode))])))
    win = 1;
  break;

       case 's':
  if (((operand)->code) == CONST_INT
      || (((operand)->code) == CONST_DOUBLE
   && ((operand)->mode) == VOIDmode))
    break;
       case 'i':
  if ((((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH)

      && (! flag_pic || (! pic_address_needs_scratch (operand)))

      )
    win = 1;
  break;

       case 'n':
  if (((operand)->code) == CONST_INT
      || (((operand)->code) == CONST_DOUBLE
   && ((operand)->mode) == VOIDmode))
    win = 1;
  break;

       case 'I':
       case 'J':
       case 'K':
       case 'L':
       case 'M':
       case 'N':
       case 'O':
       case 'P':
  if (((operand)->code) == CONST_INT
      && ((c) == 'I' ? ((unsigned int) ((((operand)->fld[0].rtwint)) + 0x8000) < 0x10000) : (c) == 'J' ? ((((operand)->fld[0].rtwint)) == 0) : (c) == 'K' ? ((unsigned int) (((operand)->fld[0].rtwint)) < 0x10000) : (c) == 'L' ? (((((operand)->fld[0].rtwint)) & 0x0000ffff) == 0 && (((((operand)->fld[0].rtwint)) & ~2147483647) == 0 || ((((operand)->fld[0].rtwint)) & ~2147483647) == ~2147483647)) : (c) == 'M' ? ((((((operand)->fld[0].rtwint)) & ~0x0000ffff) != 0) && (((((operand)->fld[0].rtwint)) & ~0x0000ffff) != ~0x0000ffff) && (((((operand)->fld[0].rtwint)) & 0x0000ffff) != 0 || (((((operand)->fld[0].rtwint)) & ~2147483647) != 0 && ((((operand)->fld[0].rtwint)) & ~2147483647) != ~2147483647))) : (c) == 'N' ? (((((operand)->fld[0].rtwint)) & ~0x0000ffff) == ~0x0000ffff) : (c) == 'O' ? (exact_log2_wide ((int) (((operand)->fld[0].rtwint))) >= 0) : (c) == 'P' ? ((((operand)->fld[0].rtwint)) != 0 && (((((operand)->fld[0].rtwint)) & ~0x0000ffff) == 0)) : 0))
    win = 1;
  break;

       case 'X':
  win = 1;
  break;

       case 'g':
  if (! force_reload


      && ((operand)->code) != PLUS

      && ((operand)->code) != SCRATCH

      && (! (((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH)
   || ! flag_pic
   || (! pic_address_needs_scratch (operand)))

      && (GR_REGS == ALL_REGS
   || ((operand)->code) != REG
   || (((operand)->fld[0].rtint) >= 68
       && reg_renumber[((operand)->fld[0].rtint)] < 0)))
    win = 1;


       case 'r':
  this_alternative[i]
    = (int) reg_class_subunion[this_alternative[i]][(int) GR_REGS];
  goto reg;


              case 'Q':
              case 'R':
              case 'S':
              case 'T':
              case 'U':
  if (((((operand)->code) != MEM) ? 0 : ((c) == 'Q') ? !simple_memory_operand (operand, ((operand)->mode)) : ((c) == 'R') ? simple_memory_operand (operand, ((operand)->mode)) : ((c) == 'S') ? (0 && (((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH) && 0) : 0))
    win = 1;
  break;


       default:
  this_alternative[i]
    = (int) reg_class_subunion[this_alternative[i]][(int) mips_char_to_class[ (c) ]];

       reg:
  if (((operand)->mode) == BLKmode)
    break;
  winreg = 1;
  if (((operand)->code) == REG
      && reg_fits_class_p (operand, this_alternative[i],
      offset, ((recog_operand[i])->mode)))
    win = 1;
  break;
       }

   constraints[i] = p;



   if (winreg && this_alternative[i] != (int) NO_REGS)
     badop = 0;


   this_alternative_earlyclobber[i] = earlyclobber;
   if (win && ! force_reload)
     this_alternative_win[i] = 1;
   else
     {
       int const_to_mem = 0;

       this_alternative_offmemok[i] = offmemok;
       losers++;
       if (badop)
  bad = 1;

       if (((operand)->code) == REG
    && this_alternative[i] == (int) NO_REGS
    && this_alternative_matches[i] < 0)
  bad = 1;




       if (((operand)->code) != SCRATCH
    && modified[i] != RELOAD_READ && no_output_reloads
    && ! find_reg_note (insn, REG_UNUSED, operand))
  bad = 1;
       else if (modified[i] != RELOAD_WRITE && no_input_reloads)
  bad = 1;
       if ((((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH)

    && ((operand)->code) != HIGH
    && ((((n64_enum_reg_class) this_alternative[i]) != ALL_REGS ? ((n64_enum_reg_class) this_alternative[i]) : (((mode_class[(int)(((operand)->mode))]) == MODE_FLOAT || (mode_class[(int)(((operand)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((operand)->mode))]) == MODE_INT || ((operand)->mode) == VOIDmode) ? GR_REGS : ((n64_enum_reg_class) this_alternative[i]))))

        == NO_REGS)
    && operand_mode[i] != VOIDmode)
  {
    const_to_mem = 1;
    if (this_alternative[i] != (int) NO_REGS)
      losers++;
  }






       if (! (((operand)->code) == LABEL_REF || ((operand)->code) == SYMBOL_REF || ((operand)->code) == CONST_INT || ((operand)->code) == CONST_DOUBLE || ((operand)->code) == CONST || ((operand)->code) == HIGH)
    && (n64_enum_reg_class) this_alternative[i] != NO_REGS
    && ((((n64_enum_reg_class) this_alternative[i]) != ALL_REGS ? ((n64_enum_reg_class) this_alternative[i]) : (((mode_class[(int)(((operand)->mode))]) == MODE_FLOAT || (mode_class[(int)(((operand)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((operand)->mode))]) == MODE_INT || ((operand)->mode) == VOIDmode) ? GR_REGS : ((n64_enum_reg_class) this_alternative[i]))))

        == NO_REGS))
  bad = 1;
       if (! (((operand)->code) == REG
       && ((operand)->fld[0].rtint) >= 68)
    && ((operand)->code) != SCRATCH
    && ! (const_to_mem && constmemok))
  reject++;
     }
   if (! win && this_alternative[i] != (int) NO_REGS
       && (mode_size[(int)(operand_mode[i])]) <= ((target_flags & 0x00002000) ? 8 : 4)
       && reg_class_size[(int) preferred_class[i]] > 1)
     {
       if (! reg_class_subset_p (this_alternative[i],
     preferred_class[i]))
  {




    if (reg_class_subset_p (preferred_class[i],
       this_alternative[i]))
      this_alternative[i] = (int) preferred_class[i];
    else
      reject += (1 + pref_or_nothing[i]);
  }
     }
 }





      for (i = 0; i < noperands; i++)
 if (this_alternative_earlyclobber[i]
     && this_alternative_win[i])
   {
     struct n64_tag_decomposition early_data;

     early_data = decompose (recog_operand[i]);

     if (modified[i] == RELOAD_READ)
       {
  if (this_insn_is_asm)
    warning_for_asm (this_insn,
       "`&' constraint used with input operand");
  else
    abort ();
  continue;
       }

     if (this_alternative[i] == NO_REGS)
       {
  this_alternative_earlyclobber[i] = 0;
  if (this_insn_is_asm)
    error_for_asm (this_insn,
     "`&' constraint used with no register class");
  else
    abort ();
       }

     for (j = 0; j < noperands; j++)

       if ((((recog_operand[j])->code) == MEM
     || modified[j] != RELOAD_WRITE)
    && j != i

    && *constraints1[j] != 0


    && ! (this_alternative_matches[j] == i
   && rtx_equal_p (recog_operand[i], recog_operand[j]))

    && !immune_p (recog_operand[j], recog_operand[i], early_data))
  {


    if (reg_class_size[this_alternative[i]] == 1
        && (((recog_operand[j])->code) == REG
     || ((recog_operand[j])->code) == SUBREG))
      {
        losers++;
        this_alternative_win[j] = 0;
      }
    else
      break;
  }


     if (j != noperands)
       {
  losers++;
  this_alternative_win[i] = 0;
  for (j = 0; j < noperands; j++)
    if (this_alternative_matches[j] == i
        && this_alternative_win[j])
      {
        this_alternative_win[j] = 0;
        losers++;
      }
       }
   }



      if (losers == 0)
 {

   if (commutative >= 0)
     {
       recog_operand[commutative] = substed_operand[commutative];
       recog_operand[commutative + 1]
  = substed_operand[commutative + 1];
     }
   for (i = 0; i < noperands; i++)
     {
       goal_alternative_win[i] = 1;
       goal_alternative[i] = this_alternative[i];
       goal_alternative_offmemok[i] = this_alternative_offmemok[i];
       goal_alternative_matches[i] = this_alternative_matches[i];
       goal_alternative_earlyclobber[i]
  = this_alternative_earlyclobber[i];
     }
   goal_alternative_number = this_alternative_number;
   goal_alternative_swapped = swapped;
   goal_earlyclobber = this_earlyclobber;
   goto finish;
 }





      losers = losers * 3 + reject;




      if (! bad && best > losers)
 {
   for (i = 0; i < noperands; i++)
     {
       goal_alternative[i] = this_alternative[i];
       goal_alternative_win[i] = this_alternative_win[i];
       goal_alternative_offmemok[i] = this_alternative_offmemok[i];
       goal_alternative_matches[i] = this_alternative_matches[i];
       goal_alternative_earlyclobber[i]
  = this_alternative_earlyclobber[i];
     }
   goal_alternative_swapped = swapped;
   best = losers;
   goal_alternative_number = this_alternative_number;
   goal_earlyclobber = this_earlyclobber;
 }
    }
  if (commutative >= 0)
    {
      swapped = !swapped;
      if (swapped)
 {
   register n64_enum_reg_class tclass;
   register int t;

   recog_operand[commutative] = substed_operand[commutative + 1];
   recog_operand[commutative + 1] = substed_operand[commutative];

   tclass = preferred_class[commutative];
   preferred_class[commutative] = preferred_class[commutative + 1];
   preferred_class[commutative + 1] = tclass;

   t = pref_or_nothing[commutative];
   pref_or_nothing[commutative] = pref_or_nothing[commutative + 1];
   pref_or_nothing[commutative + 1] = t;

   memcpy ((char *) constraints,(char *) constraints1,noperands * sizeof (char *))
                               ;
   goto try_swapped;
 }
      else
 {
   recog_operand[commutative] = substed_operand[commutative];
   recog_operand[commutative + 1] = substed_operand[commutative + 1];
 }
    }






  if (best == 10 + 300)
    {

      if (insn_code_number >= 0)
 abort ();
      error_for_asm (insn, "inconsistent operand constraints in an `asm'");

      ((insn)->fld[3].rtx) = gen_rtx (USE, VOIDmode, const0_rtx);
      n_reloads = 0;
      return;
    }



 finish:







  for (i = 0; i < noperands; i++)
    goal_alternative_matched[i] = -1;

  for (i = 0; i < noperands; i++)
    if (! goal_alternative_win[i]
 && goal_alternative_matches[i] >= 0)
      goal_alternative_matched[goal_alternative_matches[i]] = i;





  if (goal_alternative_swapped)
    {
      register rtx tem;

      tem = substed_operand[commutative];
      substed_operand[commutative] = substed_operand[commutative + 1];
      substed_operand[commutative + 1] = tem;
      tem = recog_operand[commutative];
      recog_operand[commutative] = recog_operand[commutative + 1];
      recog_operand[commutative + 1] = tem;

      for (i = 0; i < n_reloads; i++)
 {
   if (reload_opnum[i] == commutative)
     reload_opnum[i] = commutative + 1;
   else if (reload_opnum[i] == commutative + 1)
     reload_opnum[i] = commutative;
 }
    }





  for (i = 0; i < noperands; i++)
    {
      *recog_operand_loc[i] = substed_operand[i];

      operand_reloadnum[i] = -1;
      if (goal_alternative_earlyclobber[i])
 operand_type[i]
   = (find_reg_note (insn, REG_UNUSED, recog_operand[i])
      ? RELOAD_FOR_INSN : RELOAD_OTHER);
    }



  for (i = 0; i < noperands; i++)
    if (! goal_alternative_win[i]
 && (((recog_operand[i])->code) == LABEL_REF || ((recog_operand[i])->code) == SYMBOL_REF || ((recog_operand[i])->code) == CONST_INT || ((recog_operand[i])->code) == CONST_DOUBLE || ((recog_operand[i])->code) == CONST || ((recog_operand[i])->code) == HIGH)

 && ((recog_operand[i])->code) != HIGH
 && ((((n64_enum_reg_class) goal_alternative[i]) != ALL_REGS ? ((n64_enum_reg_class) goal_alternative[i]) : (((mode_class[(int)(((recog_operand[i])->mode))]) == MODE_FLOAT || (mode_class[(int)(((recog_operand[i])->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((recog_operand[i])->mode))]) == MODE_INT || ((recog_operand[i])->mode) == VOIDmode) ? GR_REGS : ((n64_enum_reg_class) goal_alternative[i]))))

     == NO_REGS)
 && operand_mode[i] != VOIDmode)
      {
 *recog_operand_loc[i] = recog_operand[i]
   = find_reloads_toplev (force_const_mem (operand_mode[i],
        recog_operand[i]),
     i, address_type[i], ind_levels, 0);
 if (alternative_allows_memconst (constraints1[i],
      goal_alternative_number))
   goal_alternative_win[i] = 1;
      }


  if (goal_earlyclobber)
    for (i = 0; i < noperands; i++)
      if (goal_alternative_earlyclobber[i])
 reload_earlyclobbers[n_earlyclobbers++] = recog_operand[i];


  for (i = 0; i < noperands; i++)
    if (! goal_alternative_win[i])
      {

 if (goal_alternative_matches[i] >= 0)
   ;







 else if (goal_alternative_matched[i] == -1
   && goal_alternative_offmemok[i]
   && ((recog_operand[i])->code) == MEM)
   {
     operand_reloadnum[i]
       = push_reload (((recog_operand[i])->fld[0].rtx), (rtx) 0,
        &((recog_operand[i])->fld[0].rtx), ((void *)0),
        GR_REGS, ((((recog_operand[i])->fld[0].rtx))->mode),
        VOIDmode, 0, 0, i, RELOAD_FOR_INPUT);
     reload_inc[operand_reloadnum[i]]
       = (mode_size[(int)(((recog_operand[i])->mode))]);






     if (modified[i] == RELOAD_WRITE)
       for (j = 0; j < n_reloads; j++)
  if (reload_opnum[j] == i
      && reload_when_needed[j] == RELOAD_FOR_OUTPUT_ADDRESS)
    reload_when_needed[j] = RELOAD_FOR_INPUT_ADDRESS;
   }
 else if (goal_alternative_matched[i] == -1)
   operand_reloadnum[i] =
     push_reload (modified[i] != RELOAD_WRITE ? recog_operand[i] : 0,
    modified[i] != RELOAD_READ ? recog_operand[i] : 0,
    (modified[i] != RELOAD_WRITE ?
     recog_operand_loc[i] : 0),
    modified[i] != RELOAD_READ ? recog_operand_loc[i] : 0,
    (n64_enum_reg_class) goal_alternative[i],
    (modified[i] == RELOAD_WRITE
     ? VOIDmode : operand_mode[i]),
    (modified[i] == RELOAD_READ
     ? VOIDmode : operand_mode[i]),
    (insn_code_number < 0 ? 0
     : insn_operand_strict_low[insn_code_number][i]),
    0, i, operand_type[i]);



 else if (modified[i] == RELOAD_READ
   && modified[goal_alternative_matched[i]] == RELOAD_WRITE)
   {
     operand_reloadnum[i]
       = push_reload (recog_operand[i],
        recog_operand[goal_alternative_matched[i]],
        recog_operand_loc[i],
        recog_operand_loc[goal_alternative_matched[i]],
        (n64_enum_reg_class) goal_alternative[i],
        operand_mode[i],
        operand_mode[goal_alternative_matched[i]],
        0, 0, i, RELOAD_OTHER);
     operand_reloadnum[goal_alternative_matched[i]] = output_reloadnum;
   }
 else if (modified[i] == RELOAD_WRITE
   && modified[goal_alternative_matched[i]] == RELOAD_READ)
   {
     operand_reloadnum[goal_alternative_matched[i]]
       = push_reload (recog_operand[goal_alternative_matched[i]],
        recog_operand[i],
        recog_operand_loc[goal_alternative_matched[i]],
        recog_operand_loc[i],
        (n64_enum_reg_class) goal_alternative[i],
        operand_mode[goal_alternative_matched[i]],
        operand_mode[i],
        0, 0, i, RELOAD_OTHER);
     operand_reloadnum[i] = output_reloadnum;
   }
 else if (insn_code_number >= 0)
   abort ();
 else
   {
     error_for_asm (insn, "inconsistent operand constraints in an `asm'");

     ((insn)->fld[3].rtx) = gen_rtx (USE, VOIDmode, const0_rtx);
     n_reloads = 0;
     return;
   }
      }
    else if (goal_alternative_matched[i] < 0
      && goal_alternative_matches[i] < 0
      && optimize)
      {




 rtx operand = recog_operand[i];

 while (((operand)->code) == SUBREG)
   operand = ((operand)->fld[0].rtx);
 if ((((operand)->code) == MEM
      || (((operand)->code) == REG
   && ((operand)->fld[0].rtint) >= 68))
     && (n64_enum_reg_class) goal_alternative[i] != NO_REGS
     && ! no_input_reloads



     && (modified[i] == RELOAD_READ
  || (modified[i] == RELOAD_READ_WRITE && ! no_output_reloads)))
   operand_reloadnum[i]
     = push_reload (modified[i] != RELOAD_WRITE ? recog_operand[i] : 0,
      modified[i] != RELOAD_READ ? recog_operand[i] : 0,
      (modified[i] != RELOAD_WRITE
       ? recog_operand_loc[i] : 0),
      (modified[i] != RELOAD_READ
       ? recog_operand_loc[i] : 0),
      (n64_enum_reg_class) goal_alternative[i],
      (modified[i] == RELOAD_WRITE
       ? VOIDmode : operand_mode[i]),
      (modified[i] == RELOAD_READ
       ? VOIDmode : operand_mode[i]),
      (insn_code_number < 0 ? 0
       : insn_operand_strict_low[insn_code_number][i]),
      1, i, operand_type[i]);
      }
    else if (goal_alternative_matches[i] >= 0
      && goal_alternative_win[goal_alternative_matches[i]]
      && modified[i] == RELOAD_READ
      && modified[goal_alternative_matches[i]] == RELOAD_WRITE
      && ! no_input_reloads && ! no_output_reloads
      && optimize)
      {



 rtx operand = recog_operand[i];

 while (((operand)->code) == SUBREG)
   operand = ((operand)->fld[0].rtx);
 if ((((operand)->code) == MEM
      || (((operand)->code) == REG
   && ((operand)->fld[0].rtint) >= 68))
     && ((n64_enum_reg_class) goal_alternative[goal_alternative_matches[i]]
  != NO_REGS))
   operand_reloadnum[i] = operand_reloadnum[goal_alternative_matches[i]]
     = push_reload (recog_operand[goal_alternative_matches[i]],
      recog_operand[i],
      recog_operand_loc[goal_alternative_matches[i]],
      recog_operand_loc[i],
      (n64_enum_reg_class) goal_alternative[goal_alternative_matches[i]],
      operand_mode[goal_alternative_matches[i]],
      operand_mode[i],
      0, 1, goal_alternative_matches[i], RELOAD_OTHER);
      }
  if (insn_code_number >= 0 && replace)
    for (i = insn_n_dups[insn_code_number] - 1; i >= 0; i--)
      {
 int opno = recog_dup_num[i];
 *recog_dup_loc[i] = *recog_operand_loc[opno];
 if (operand_reloadnum[opno] >= 0)
   push_replacement (recog_dup_loc[i], operand_reloadnum[opno],
       insn_operand_mode[insn_code_number][opno]);
      }
  if (!goal_earlyclobber)
    combine_reloads ();






  for (i = 0; i < n_reloads; i++)
    {
      int k;

      for (j = i + 1; j < n_reloads; j++)
 if ((reload_when_needed[i] == RELOAD_FOR_INPUT_ADDRESS
      || reload_when_needed[i] == RELOAD_FOR_OUTPUT_ADDRESS)
     && (reload_when_needed[j] == RELOAD_FOR_INPUT_ADDRESS
  || reload_when_needed[j] == RELOAD_FOR_OUTPUT_ADDRESS)
     && rtx_equal_p (reload_in[i], reload_in[j])
     && (operand_reloadnum[reload_opnum[i]] < 0
  || reload_optional[operand_reloadnum[reload_opnum[i]]])
     && (operand_reloadnum[reload_opnum[j]] < 0
  || reload_optional[operand_reloadnum[reload_opnum[j]]])
     && (goal_alternative_matches[reload_opnum[i]] == reload_opnum[j]
  || (goal_alternative_matches[reload_opnum[j]]
      == reload_opnum[i])))
   {
     for (k = 0; k < n_replacements; k++)
       if (replacements[k].what == j)
  replacements[k].what = i;

     reload_when_needed[i] = RELOAD_FOR_OPERAND_ADDRESS;
     reload_in[j] = 0;
   }
    }
  for (i = 0; i < n_reloads; i++)
    {
      if (reload_secondary_p[i]
   && reload_when_needed[i] == operand_type[reload_opnum[i]])
 reload_when_needed[i] = address_type[reload_opnum[i]];

      if ((reload_when_needed[i] == RELOAD_FOR_INPUT_ADDRESS
    || reload_when_needed[i] == RELOAD_FOR_OUTPUT_ADDRESS)
   && (operand_reloadnum[reload_opnum[i]] < 0
       || reload_optional[operand_reloadnum[reload_opnum[i]]]))
 {



   if (reload_when_needed[i] == RELOAD_FOR_INPUT_ADDRESS
       && reload_secondary_in_reload[i] != -1)
     {
       int secondary_in_reload = reload_secondary_in_reload[i];

       reload_when_needed[secondary_in_reload] =
  RELOAD_FOR_OPADDR_ADDR;


       if (secondary_in_reload > 0
    && reload_secondary_in_reload[secondary_in_reload] != -1)
  reload_when_needed[reload_secondary_in_reload[secondary_in_reload]]
    = RELOAD_FOR_OPADDR_ADDR;
     }

   if (reload_when_needed[i] == RELOAD_FOR_OUTPUT_ADDRESS
       && reload_secondary_out_reload[i] != -1)
     {
       int secondary_out_reload = reload_secondary_out_reload[i];

       reload_when_needed[secondary_out_reload] =
  RELOAD_FOR_OPADDR_ADDR;


       if (secondary_out_reload
    && reload_secondary_out_reload[secondary_out_reload] != -1)
  reload_when_needed[reload_secondary_out_reload[secondary_out_reload]]
    = RELOAD_FOR_OPADDR_ADDR;
     }
   reload_when_needed[i] = RELOAD_FOR_OPERAND_ADDRESS;
 }

      if (reload_when_needed[i] == RELOAD_FOR_INPUT_ADDRESS
   && operand_reloadnum[reload_opnum[i]] >= 0
   && (reload_when_needed[operand_reloadnum[reload_opnum[i]]]
       == RELOAD_OTHER))
 reload_when_needed[i] = RELOAD_FOR_OTHER_ADDRESS;

      if (goal_alternative_matches[reload_opnum[i]] >= 0)
 reload_opnum[i] = goal_alternative_matches[reload_opnum[i]];
    }






  for (i = 0; i < n_reloads; i++)
    if (reload_in[i] != 0 && reload_out[i] == 0
 && (reload_when_needed[i] == RELOAD_FOR_OPERAND_ADDRESS
     || reload_when_needed[i] == RELOAD_FOR_OTHER_ADDRESS))
      for (j = 0; j < n_reloads; j++)
 if (i != j && reload_in[j] != 0 && reload_out[j] == 0
     && reload_when_needed[j] == reload_when_needed[i]
     && (reload_in[i] == reload_in[j] || (reload_in[i] != 0 && (((reload_in[i])->code) == REG ? ((reload_in[j])->code) == REG && ((reload_in[i])->fld[0].rtint) == ((reload_in[j])->fld[0].rtint) : rtx_equal_p (reload_in[i], reload_in[j]) && ! side_effects_p (reload_in[i]))))
     && reload_reg_class[i] == reload_reg_class[j]
     && !reload_nocombine[i] && !reload_nocombine[j]
     && reload_reg_rtx[i] == reload_reg_rtx[j])
   {
     reload_opnum[i] = ((reload_opnum[i]) < (reload_opnum[j]) ? (reload_opnum[i]) : (reload_opnum[j]));
     transfer_replacements (i, j);
     reload_in[j] = 0;
   }
}




static int
alternative_allows_memconst(char *constraint, int altnum) asm("_alternative_allows_memconst");
static int
alternative_allows_memconst(char *constraint, int altnum)
{
  register int c;

  while (altnum > 0)
    {
      while (*constraint++ != ',');
      altnum--;
    }


  while ((c = *constraint++) && c != ',' && c != '#')
    if (c == 'm' || c == 'o')
      return 1;
  return 0;
}
static rtx
find_reloads_toplev(rtx x, int opnum, n64_enum_reload_type type, int ind_levels, int is_set_dest) asm("_find_reloads_toplev");
static rtx
find_reloads_toplev(rtx x, int opnum, n64_enum_reload_type type, int ind_levels, int is_set_dest)
{
  register n64_enum_rtx_code code = ((x)->code);

  register char *fmt = (rtx_format[(int)(code)]);
  register int i;

  if (code == REG)
    {

      register int regno = ((x)->fld[0].rtint);
      if (reg_equiv_constant[regno] != 0 && !is_set_dest)
 x = reg_equiv_constant[regno];






      else if (reg_equiv_address[regno] != 0)
 {



   rtx addr = ((eliminate_regs (reg_equiv_memory_loc[regno], 0, (rtx) 0))->fld[0].rtx)

        ;

   if (rtx_varies_p (addr))
     addr = copy_rtx (addr);

   x = gen_rtx (MEM, ((x)->mode), addr);
   ((x)->unchanging) = ((regno_reg_rtx[regno])->unchanging);
   find_reloads_address (((x)->mode), ((void *)0),
    ((x)->fld[0].rtx),
    &((x)->fld[0].rtx), opnum, type, ind_levels);
 }
      return x;
    }
  if (code == MEM)
    {
      rtx tem = x;
      find_reloads_address (((x)->mode), &tem, ((x)->fld[0].rtx), &((x)->fld[0].rtx),
       opnum, type, ind_levels);
      return tem;
    }

  if (code == SUBREG && ((((x)->fld[0].rtx))->code) == REG)
    {
      register int regno = ((((x)->fld[0].rtx))->fld[0].rtint);
      rtx tem;

      if (subreg_lowpart_p (x)
   && regno >= 68 && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0
   && (tem = gen_lowpart_common (((x)->mode),
     reg_equiv_constant[regno])) != 0)
 return tem;

      if ((8 * mode_size[(int)(((x)->mode))]) == ((target_flags & 0x00002000) ? 64 : 32)
   && regno >= 68 && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0
   && (tem = operand_subword (reg_equiv_constant[regno],
         ((x)->fld[1].rtint), 0,
         ((((x)->fld[0].rtx))->mode))) != 0)
 return tem;

      if (regno >= 68 && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0
   && ((reg_equiv_constant[regno])->mode) == VOIDmode)
 abort ();
      else if (regno >= 68

        && ((mode_size[(int)(((x)->mode))])
     <= (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))

        && (reg_equiv_address[regno] != 0
     || (reg_equiv_mem[regno] != 0
         && (! strict_memory_address_p (((x)->mode),
            ((reg_equiv_mem[regno])->fld[0].rtx))
      || ! offsettable_memref_p (reg_equiv_mem[regno])))))
 {
   int offset = ((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);


   rtx addr = ((eliminate_regs (reg_equiv_memory_loc[regno], 0, (rtx) 0))->fld[0].rtx)

        ;
   if (((target_flags & 0x00010000) != 0))
     {
       int size;
       size = (mode_size[(int)(((((x)->fld[0].rtx))->mode))]);
       offset += ((size) < (((target_flags & 0x00002000) ? 8 : 4)) ? (size) : (((target_flags & 0x00002000) ? 8 : 4)));
       size = (mode_size[(int)(((x)->mode))]);
       offset -= ((size) < (((target_flags & 0x00002000) ? 8 : 4)) ? (size) : (((target_flags & 0x00002000) ? 8 : 4)));
     }
   addr = plus_constant_wide (addr, (int) (offset));
   x = gen_rtx (MEM, ((x)->mode), addr);
   ((x)->unchanging) = ((regno_reg_rtx[regno])->unchanging);
   find_reloads_address (((x)->mode), ((void *)0),
    ((x)->fld[0].rtx),
    &((x)->fld[0].rtx), opnum, type, ind_levels);
 }

    }

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = find_reloads_toplev (((x)->fld[i].rtx), opnum, type,
        ind_levels, is_set_dest);
    }
  return x;
}




static rtx
make_memloc(rtx ad, int regno) asm("_make_memloc");
static rtx
make_memloc(rtx ad, int regno)
{
  register int i;


  rtx tem = ((eliminate_regs (reg_equiv_memory_loc[regno], 0, (rtx) 0))->fld[0].rtx)
      ;
  if (rtx_varies_p (tem))
    tem = copy_rtx (tem);

  tem = gen_rtx (MEM, ((ad)->mode), tem);
  ((tem)->unchanging) = ((regno_reg_rtx[regno])->unchanging);
  memlocs[n_memlocs++] = tem;
  return tem;
}
static int
find_reloads_address(n64_enum_machine_mode mode, rtx *memrefloc, rtx ad, rtx *loc, int opnum, n64_enum_reload_type type, int ind_levels) asm("_find_reloads_address");
static int
find_reloads_address(n64_enum_machine_mode mode, rtx *memrefloc, rtx ad, rtx *loc, int opnum, n64_enum_reload_type type, int ind_levels)
{
  register int regno;
  rtx tem;





  if (((ad)->code) == REG)
    {
      regno = ((ad)->fld[0].rtint);

      if (reg_equiv_constant[regno] != 0
   && strict_memory_address_p (mode, reg_equiv_constant[regno]))
 {
   *loc = ad = reg_equiv_constant[regno];
   return 1;
 }

      else if (reg_equiv_address[regno] != 0)
 {
   tem = make_memloc (ad, regno);
   find_reloads_address (((tem)->mode), ((void *)0), ((tem)->fld[0].rtx),
    &((tem)->fld[0].rtx), opnum, type, ind_levels);
   push_reload (tem, (rtx) 0, loc, ((void *)0), GR_REGS,
         ((ad)->mode), VOIDmode, 0, 0,
         opnum, type);
   return 1;
 }






      else if (reg_equiv_mem[regno] != 0 && ind_levels > 0
        && strict_memory_address_p (mode, reg_equiv_mem[regno])
        && (((((reg_equiv_mem[regno])->fld[0].rtx))->code) == REG
     || (((((reg_equiv_mem[regno])->fld[0].rtx))->code) == PLUS
         && ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[0].rtx))->code) == REG
         && (((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF || ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == SYMBOL_REF || ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT || ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == CONST_DOUBLE || ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == CONST || ((((((reg_equiv_mem[regno])->fld[0].rtx))->fld[1].rtx))->code) == HIGH))))
 return 0;





      else if (regno < 68 && ((unsigned) (((regno < 68) ? regno : reg_renumber[regno]) - 0) < (31 - 0 + 1))
        && ! regno_clobbered_p (regno, this_insn))
 return 0;


      push_reload (ad, (rtx) 0, loc, ((void *)0), GR_REGS,
     ((ad)->mode), VOIDmode, 0, 0, opnum, type);
      return 1;
    }

  if (strict_memory_address_p (mode, ad))
    {
      if (((ad)->code) == PLUS
   && ((((ad)->fld[1].rtx))->code) == CONST_INT
   && ((((ad)->fld[0].rtx))->code) == REG
   && reg_equiv_constant[((((ad)->fld[0].rtx))->fld[0].rtint)] == 0)
 return 0;

      subst_reg_equivs_changed = 0;
      *loc = subst_reg_equivs (ad);

      if (! subst_reg_equivs_changed)
 return 0;


      if (strict_memory_address_p (mode, ad))
 return 0;
    }







  if (((ad)->code) == MEM)
    {


      tem = ad;
      find_reloads_address (((ad)->mode), &tem, ((ad)->fld[0].rtx), &((ad)->fld[0].rtx),
       opnum, type, ind_levels == 0 ? 0 : ind_levels - 1);



      if (tem != ad && memrefloc)
 {
   *memrefloc = copy_rtx (*memrefloc);
   copy_replacements (tem, ((*memrefloc)->fld[0].rtx));
   loc = &((*memrefloc)->fld[0].rtx);
 }





      if (ind_levels == 0
   || (((((tem)->fld[0].rtx))->code) == SYMBOL_REF && ! indirect_symref_ok)
   || ((((tem)->fld[0].rtx))->code) == MEM
   || ! (((((tem)->fld[0].rtx))->code) == REG
  || (((((tem)->fld[0].rtx))->code) == PLUS
      && ((((((tem)->fld[0].rtx))->fld[0].rtx))->code) == REG
      && ((((((tem)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT)))
 {


   push_reload (tem, (rtx) 0, loc, ((void *)0),
         GR_REGS, ((tem)->mode), VOIDmode, 0,
         0, opnum, type);
   return 1;
 }
      else
 return 0;
    }






  else if (((ad)->code) == PLUS
    && ((((ad)->fld[0].rtx))->code) == REG
    && ((((ad)->fld[0].rtx))->fld[0].rtint) < 68
    && ((unsigned) (((((((ad)->fld[0].rtx))->fld[0].rtint) < 68) ? ((((ad)->fld[0].rtx))->fld[0].rtint) : reg_renumber[((((ad)->fld[0].rtx))->fld[0].rtint)]) - 0) < (31 - 0 + 1))
    && ((((ad)->fld[1].rtx))->code) == CONST_INT)
    {

      if (memrefloc)
 {
   *memrefloc = copy_rtx (*memrefloc);
   loc = &((*memrefloc)->fld[0].rtx);
 }
      if (double_reg_address_ok)
 {

   *loc = ad = copy_rtx (ad);


   find_reloads_address_part (((ad)->fld[1].rtx), &((ad)->fld[1].rtx),
         NO_REGS, ((ad)->mode), opnum,
         type, ind_levels);
 }
      else
 {



   find_reloads_address_part (ad, loc, GR_REGS, ((target_flags & 0x00000002) ? DImode : SImode),
         opnum, type, ind_levels);
 }
      return 1;
    }
  else if (((ad)->code) == PLUS && ((((ad)->fld[1].rtx))->code) == CONST_INT
    && ((((ad)->fld[0].rtx))->code) == PLUS
    && (((((ad)->fld[0].rtx))->fld[0].rtx) == frame_pointer_rtx




        || ((((ad)->fld[0].rtx))->fld[0].rtx) == arg_pointer_rtx

        || ((((ad)->fld[0].rtx))->fld[0].rtx) == stack_pointer_rtx)
    && ! memory_address_p (mode, ad))
    {
      *loc = ad = gen_rtx (PLUS, ((ad)->mode),
      plus_constant_wide (((((ad)->fld[0].rtx))->fld[0].rtx), (int) (((((ad)->fld[1].rtx))->fld[0].rtwint)))
                             ,
      ((((ad)->fld[0].rtx))->fld[1].rtx));
      find_reloads_address_part (((ad)->fld[0].rtx), &((ad)->fld[0].rtx), GR_REGS,
     ((ad)->mode), opnum, type, ind_levels);
      find_reloads_address_1 (((ad)->fld[1].rtx), 1, &((ad)->fld[1].rtx), opnum, type, 0);

      return 1;
    }

  else if (((ad)->code) == PLUS && ((((ad)->fld[1].rtx))->code) == CONST_INT
    && ((((ad)->fld[0].rtx))->code) == PLUS
    && (((((ad)->fld[0].rtx))->fld[1].rtx) == frame_pointer_rtx




        || ((((ad)->fld[0].rtx))->fld[1].rtx) == arg_pointer_rtx

        || ((((ad)->fld[0].rtx))->fld[1].rtx) == stack_pointer_rtx)
    && ! memory_address_p (mode, ad))
    {
      *loc = ad = gen_rtx (PLUS, ((ad)->mode),
      ((((ad)->fld[0].rtx))->fld[0].rtx),
      plus_constant_wide (((((ad)->fld[0].rtx))->fld[1].rtx), (int) (((((ad)->fld[1].rtx))->fld[0].rtwint)))
                             );
      find_reloads_address_part (((ad)->fld[1].rtx), &((ad)->fld[1].rtx), GR_REGS,
     ((ad)->mode), opnum, type, ind_levels);
      find_reloads_address_1 (((ad)->fld[0].rtx), 1, &((ad)->fld[0].rtx), opnum, type, 0);

      return 1;
    }




  tem = ad;
  if (((ad)->code) == PLUS)
    tem = subst_indexed_address (ad);
  if (tem != ad && strict_memory_address_p (mode, tem))
    {



      subst_reg_equivs_changed = 0;
      tem = subst_reg_equivs (tem);



      if (! subst_reg_equivs_changed || strict_memory_address_p (mode, tem))
 {
   *loc = tem;
   return 0;
 }
    }



  if ((((ad)->code) == LABEL_REF || ((ad)->code) == SYMBOL_REF || ((ad)->code) == CONST_INT || ((ad)->code) == CONST_DOUBLE || ((ad)->code) == CONST || ((ad)->code) == HIGH) && ! strict_memory_address_p (mode, ad))
    {


      if (memrefloc && ((ad)->code) == SYMBOL_REF
   && ((ad)->unchanging))
 {
   *memrefloc = copy_rtx (*memrefloc);
   loc = &((*memrefloc)->fld[0].rtx);
 }

      find_reloads_address_part (ad, loc, GR_REGS, ((target_flags & 0x00000002) ? DImode : SImode), opnum, type,
     ind_levels);
      return 1;
    }

  return find_reloads_address_1 (ad, 0, loc, opnum, type, ind_levels);
}





static rtx
subst_reg_equivs(rtx ad) asm("_subst_reg_equivs");
static rtx
subst_reg_equivs(rtx ad)
{
  register n64_enum_rtx_code code = ((ad)->code);
  register int i;
  register char *fmt;

  switch (code)
    {
    case HIGH:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case PC:
    case CC0:
      return ad;

    case REG:
      {
 register int regno = ((ad)->fld[0].rtint);

 if (reg_equiv_constant[regno] != 0)
   {
     subst_reg_equivs_changed = 1;
     return reg_equiv_constant[regno];
   }
      }
      return ad;

    case PLUS:

      if (((ad)->fld[0].rtx) == frame_pointer_rtx
   && ((((ad)->fld[1].rtx))->code) == CONST_INT)
 return ad;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      ((ad)->fld[i].rtx) = subst_reg_equivs (((ad)->fld[i].rtx));
  return ad;
}
rtx
form_sum(rtx x, rtx y) asm("_form_sum");
rtx
form_sum(rtx x, rtx y)
{
  rtx tem;
  n64_enum_machine_mode mode = ((x)->mode);

  if (mode == VOIDmode)
    mode = ((y)->mode);

  if (mode == VOIDmode)
    mode = ((target_flags & 0x00000002) ? DImode : SImode);

  if (((x)->code) == CONST_INT)
    return plus_constant_wide (y, (int) (((x)->fld[0].rtwint)));
  else if (((y)->code) == CONST_INT)
    return plus_constant_wide (x, (int) (((y)->fld[0].rtwint)));
  else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    tem = x, x = y, y = tem;

  if (((x)->code) == PLUS && (((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH))
    return form_sum (((x)->fld[0].rtx), form_sum (((x)->fld[1].rtx), y));



  if (((y)->code) == PLUS && (((((y)->fld[1].rtx))->code) == LABEL_REF || ((((y)->fld[1].rtx))->code) == SYMBOL_REF || ((((y)->fld[1].rtx))->code) == CONST_INT || ((((y)->fld[1].rtx))->code) == CONST_DOUBLE || ((((y)->fld[1].rtx))->code) == CONST || ((((y)->fld[1].rtx))->code) == HIGH))
    return form_sum (form_sum (x, ((y)->fld[0].rtx)), ((y)->fld[1].rtx));



  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH) && (((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH))
    {
      if (((x)->code) == CONST)
 x = ((x)->fld[0].rtx);
      if (((y)->code) == CONST)
 y = ((y)->fld[0].rtx);

      return gen_rtx (CONST, VOIDmode, gen_rtx (PLUS, mode, x, y));
    }

  return gen_rtx (PLUS, mode, x, y);
}
static rtx
subst_indexed_address(rtx addr) asm("_subst_indexed_address");
static rtx
subst_indexed_address(rtx addr)
{
  rtx op0 = 0, op1 = 0, op2 = 0;
  rtx tem;
  int regno;

  if (((addr)->code) == PLUS)
    {

      op0 = ((addr)->fld[0].rtx), op1 = ((addr)->fld[1].rtx), op2 = 0;
      if (((op0)->code) == REG
   && (regno = ((op0)->fld[0].rtint)) >= 68
   && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0)
 op0 = reg_equiv_constant[regno];
      else if (((op1)->code) == REG
   && (regno = ((op1)->fld[0].rtint)) >= 68
   && reg_renumber[regno] < 0
   && reg_equiv_constant[regno] != 0)
 op1 = reg_equiv_constant[regno];
      else if (((op0)->code) == PLUS
        && (tem = subst_indexed_address (op0)) != op0)
 op0 = tem;
      else if (((op1)->code) == PLUS
        && (tem = subst_indexed_address (op1)) != op1)
 op1 = tem;
      else
 return addr;


      if (((op1)->code) == PLUS)
 op2 = ((op1)->fld[1].rtx), op1 = ((op1)->fld[0].rtx);
      else if (((op0)->code) == PLUS)
 op2 = op1, op1 = ((op0)->fld[1].rtx), op0 = ((op0)->fld[0].rtx);


      if (op2 != 0)
 op1 = form_sum (op1, op2);
      if (op1 != 0)
 op0 = form_sum (op0, op1);

      return op0;
    }
  return addr;
}
static int
find_reloads_address_1(rtx x, int context, rtx *loc, int opnum, n64_enum_reload_type type, int ind_levels) asm("_find_reloads_address_1");
static int
find_reloads_address_1(rtx x, int context, rtx *loc, int opnum, n64_enum_reload_type type, int ind_levels)
{
  register n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case PLUS:
      {
 register rtx orig_op0 = ((x)->fld[0].rtx);
 register rtx orig_op1 = ((x)->fld[1].rtx);
 register n64_enum_rtx_code code0 = ((orig_op0)->code);
 register n64_enum_rtx_code code1 = ((orig_op1)->code);
 register rtx op0 = orig_op0;
 register rtx op1 = orig_op1;

 if (((op0)->code) == SUBREG)
   {
     op0 = ((op0)->fld[0].rtx);
     code0 = ((op0)->code);
     if (code0 == REG && ((op0)->fld[0].rtint) < 68)
       op0 = gen_rtx (REG, word_mode,
        ((op0)->fld[0].rtint) + ((orig_op0)->fld[1].rtint));
   }

 if (((op1)->code) == SUBREG)
   {
     op1 = ((op1)->fld[0].rtx);
     code1 = ((op1)->code);
     if (code1 == REG && ((op1)->fld[0].rtint) < 68)
       op1 = gen_rtx (REG, ((op1)->mode),
        ((op1)->fld[0].rtint) + ((orig_op1)->fld[1].rtint));
   }

 if (code0 == MULT || code0 == SIGN_EXTEND || code0 == TRUNCATE
     || code0 == ZERO_EXTEND || code1 == MEM)
   {
     find_reloads_address_1 (orig_op0, 1, &((x)->fld[0].rtx), opnum, type,
        ind_levels);
     find_reloads_address_1 (orig_op1, 0, &((x)->fld[1].rtx), opnum, type,
        ind_levels);
   }

 else if (code1 == MULT || code1 == SIGN_EXTEND || code1 == TRUNCATE
   || code1 == ZERO_EXTEND || code0 == MEM)
   {
     find_reloads_address_1 (orig_op0, 0, &((x)->fld[0].rtx), opnum, type,
        ind_levels);
     find_reloads_address_1 (orig_op1, 1, &((x)->fld[1].rtx), opnum, type,
        ind_levels);
   }

 else if (code0 == CONST_INT || code0 == CONST
   || code0 == SYMBOL_REF || code0 == LABEL_REF)
   find_reloads_address_1 (orig_op1, 0, &((x)->fld[1].rtx), opnum, type,
      ind_levels);

 else if (code1 == CONST_INT || code1 == CONST
   || code1 == SYMBOL_REF || code1 == LABEL_REF)
   find_reloads_address_1 (orig_op0, 0, &((x)->fld[0].rtx), opnum, type,
      ind_levels);

 else if (code0 == REG && code1 == REG)
   {
     if (0
  && ((unsigned) (((((op1)->fld[0].rtint) < 68) ? ((op1)->fld[0].rtint) : reg_renumber[((op1)->fld[0].rtint)]) - 0) < (31 - 0 + 1)))
       return 0;
     else if (0
       && ((unsigned) (((((op0)->fld[0].rtint) < 68) ? ((op0)->fld[0].rtint) : reg_renumber[((op0)->fld[0].rtint)]) - 0) < (31 - 0 + 1)))
       return 0;
     else if (((unsigned) (((((op1)->fld[0].rtint) < 68) ? ((op1)->fld[0].rtint) : reg_renumber[((op1)->fld[0].rtint)]) - 0) < (31 - 0 + 1)))
       find_reloads_address_1 (orig_op0, 1, &((x)->fld[0].rtx), opnum, type,
          ind_levels);
     else if (((unsigned) (((((op0)->fld[0].rtint) < 68) ? ((op0)->fld[0].rtint) : reg_renumber[((op0)->fld[0].rtint)]) - 0) < (31 - 0 + 1)))
       find_reloads_address_1 (orig_op1, 1, &((x)->fld[1].rtx), opnum, type,
          ind_levels);
     else if (0)
       find_reloads_address_1 (orig_op0, 0, &((x)->fld[0].rtx), opnum, type,
          ind_levels);
     else if (0)
     find_reloads_address_1 (orig_op1, 0, &((x)->fld[1].rtx), opnum, type,
        ind_levels);
     else
       {
  find_reloads_address_1 (orig_op0, 1, &((x)->fld[0].rtx), opnum, type,
     ind_levels);
  find_reloads_address_1 (orig_op1, 0, &((x)->fld[1].rtx), opnum, type,
     ind_levels);
       }
   }

 else if (code0 == REG)
   {
     find_reloads_address_1 (orig_op0, 1, &((x)->fld[0].rtx), opnum, type,
        ind_levels);
     find_reloads_address_1 (orig_op1, 0, &((x)->fld[1].rtx), opnum, type,
        ind_levels);
   }

 else if (code1 == REG)
   {
     find_reloads_address_1 (orig_op1, 1, &((x)->fld[1].rtx), opnum, type,
        ind_levels);
     find_reloads_address_1 (orig_op0, 0, &((x)->fld[0].rtx), opnum, type,
        ind_levels);
   }
      }

      return 0;

    case POST_INC:
    case POST_DEC:
    case PRE_INC:
    case PRE_DEC:
      if (((((x)->fld[0].rtx))->code) == REG)
 {
   register int regno = ((((x)->fld[0].rtx))->fld[0].rtint);
   int value = 0;
   rtx x_orig = x;


   if (regno >= 68
       && reg_equiv_constant[regno] != 0)
     abort ();



   if (reg_equiv_address[regno] != 0)
     {
       rtx tem = make_memloc (((x)->fld[0].rtx), regno);

       find_reloads_address (((tem)->mode), 0, ((tem)->fld[0].rtx),
        &((tem)->fld[0].rtx), opnum, type, ind_levels);

       x = gen_rtx (((x)->code), ((x)->mode), tem);

     }
   if (reg_renumber[regno] >= 0)
     regno = reg_renumber[regno];
   if ((regno >= 68
        || !(context ? 0
      : ((unsigned) (((regno < 68) ? regno : reg_renumber[regno]) - 0) < (31 - 0 + 1)))))
     {
       register rtx link;

       int reloadnum
  = push_reload (x, (rtx) 0, loc, ((void *)0),
          context ? NO_REGS : GR_REGS,
          ((x)->mode), ((x)->mode), VOIDmode, 0,
          opnum, type);
       reload_inc[reloadnum]
  = find_inc_amount (((this_insn)->fld[3].rtx), ((x_orig)->fld[0].rtx));

       value = 1;
     }
   return value;
 }

      else if (((((x)->fld[0].rtx))->code) == MEM)
 {




   rtx tem = ((x)->fld[0].rtx);
   register rtx link;
   int reloadnum;







   find_reloads_address (((x)->mode), &((x)->fld[0].rtx),
    ((((x)->fld[0].rtx))->fld[0].rtx), &((((x)->fld[0].rtx))->fld[0].rtx),
    opnum, type, ind_levels);

   reloadnum = push_reload (x, (rtx) 0, loc, ((void *)0),
       context ? NO_REGS : GR_REGS,
       ((x)->mode), VOIDmode, 0, 0, opnum, type);
   reload_inc[reloadnum]
     = find_inc_amount (((this_insn)->fld[3].rtx), ((x)->fld[0].rtx));

   link = 0;
   if (link != 0)
     push_replacement (&((link)->fld[0].rtx), reloadnum, VOIDmode);

   return 1;
 }
      return 0;

    case MEM:
      find_reloads_address (((x)->mode), loc, ((x)->fld[0].rtx), &((x)->fld[0].rtx),
       opnum, type, ind_levels);
      push_reload (*loc, (rtx) 0, loc, ((void *)0),
     context ? NO_REGS : GR_REGS,
     ((x)->mode), VOIDmode, 0, 0, opnum, type);
      return 1;

    case REG:
      {
 register int regno = ((x)->fld[0].rtint);

 if (reg_equiv_constant[regno] != 0)
   {
     find_reloads_address_part (reg_equiv_constant[regno], loc,
           (context ? NO_REGS
     : GR_REGS),
           ((x)->mode), opnum, type, ind_levels);
     return 1;
   }
 if (reg_equiv_address[regno] != 0)
   {
     x = make_memloc (x, regno);
     find_reloads_address (((x)->mode), 0, ((x)->fld[0].rtx), &((x)->fld[0].rtx),
      opnum, type, ind_levels);
   }

 if (reg_renumber[regno] >= 0)
   regno = reg_renumber[regno];

 if ((regno >= 68
      || !(context ? 0
    : ((unsigned) (((regno < 68) ? regno : reg_renumber[regno]) - 0) < (31 - 0 + 1)))))
   {
     push_reload (x, (rtx) 0, loc, ((void *)0),
    context ? NO_REGS : GR_REGS,
    ((x)->mode), VOIDmode, 0, 0, opnum, type);
     return 1;
   }





 if (regno_clobbered_p (regno, this_insn))
   {
     push_reload (x, (rtx) 0, loc, ((void *)0),
    context ? NO_REGS : GR_REGS,
    ((x)->mode), VOIDmode, 0, 0, opnum, type);
     return 1;
   }
      }
      return 0;

    case SUBREG:
      if (((((x)->fld[0].rtx))->code) == REG)
 {



   if (((((x)->fld[0].rtx))->fld[0].rtint) < 68)
     {
       int regno = ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint);

       if (! (context ? 0
       : ((unsigned) (((regno < 68) ? regno : reg_renumber[regno]) - 0) < (31 - 0 + 1))))
  {
    push_reload (x, (rtx) 0, loc, ((void *)0),
          context ? NO_REGS : GR_REGS,
          ((x)->mode), VOIDmode, 0, 0, opnum, type);
    return 1;
  }
     }


   else
     {
       n64_enum_reg_class cxx_class = (context
          ? NO_REGS : GR_REGS);
       if (((cxx_class) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(((((x)->fld[0].rtx))->mode))]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(((((x)->fld[0].rtx))->mode))]) + (8) - 1) / (8))) : (((mode_size[(int)(((((x)->fld[0].rtx))->mode))]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))
    > reg_class_size[cxx_class])
  {
    push_reload (x, (rtx) 0, loc, ((void *)0), cxx_class,
          ((x)->mode), VOIDmode, 0, 0, opnum, type);
    return 1;
  }
     }
 }
      break;
    }

  {
    register char *fmt = (rtx_format[(int)(code)]);
    register int i;

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e')
   find_reloads_address_1 (((x)->fld[i].rtx), context, &((x)->fld[i].rtx),
      opnum, type, ind_levels);
      }
  }

  return 0;
}
static void
find_reloads_address_part(rtx x, rtx *loc, n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, int opnum, n64_enum_reload_type type, int ind_levels) asm("_find_reloads_address_part");
static void
find_reloads_address_part(rtx x, rtx *loc, n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, int opnum, n64_enum_reload_type type, int ind_levels)
{
  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH)
      && (! ((((x)->code) != CONST_DOUBLE || mips_const_double_ok (x, ((x)->mode))) && ! (((x)->code) == CONST && 0))
   || ((cxx_class) != ALL_REGS ? (cxx_class) : (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((x)->mode))]) == MODE_INT || ((x)->mode) == VOIDmode) ? GR_REGS : (cxx_class)))) == NO_REGS))
    {
      rtx tem = x = force_const_mem (mode, x);
      find_reloads_address (mode, &tem, ((tem)->fld[0].rtx), &((tem)->fld[0].rtx),
       opnum, type, ind_levels);
    }

  else if (((x)->code) == PLUS
    && (((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH)
    && (! ((((((x)->fld[1].rtx))->code) != CONST_DOUBLE || mips_const_double_ok (((x)->fld[1].rtx), ((((x)->fld[1].rtx))->mode))) && ! (((((x)->fld[1].rtx))->code) == CONST && 0))
        || ((cxx_class) != ALL_REGS ? (cxx_class) : (((mode_class[(int)(((((x)->fld[1].rtx))->mode))]) == MODE_FLOAT || (mode_class[(int)(((((x)->fld[1].rtx))->mode))]) == MODE_COMPLEX_FLOAT) ? ((target_flags & 0x00000100) ? GR_REGS : FP_REGS) : (((mode_class[(int)(((((x)->fld[1].rtx))->mode))]) == MODE_INT || ((((x)->fld[1].rtx))->mode) == VOIDmode) ? GR_REGS : (cxx_class)))) == NO_REGS))
    {
      rtx tem = force_const_mem (((x)->mode), ((x)->fld[1].rtx));

      x = gen_rtx (PLUS, ((x)->mode), ((x)->fld[0].rtx), tem);
      find_reloads_address (mode, &tem, ((tem)->fld[0].rtx), &((tem)->fld[0].rtx),
       opnum, type, ind_levels);
    }

  push_reload (x, (rtx) 0, loc, ((void *)0), cxx_class,
        mode, VOIDmode, 0, 0, opnum, type);
}
void
subst_reloads(void) asm("_subst_reloads");
void
subst_reloads(void)
{
  register int i;

  for (i = 0; i < n_replacements; i++)
    {
      register struct n64_tag_replacement *r = &replacements[i];
      register rtx reloadreg = reload_reg_rtx[r->what];
      if (reloadreg)
 {




   if (((reloadreg)->mode) != r->mode && r->mode != VOIDmode)
     reloadreg = gen_rtx (REG, r->mode, ((reloadreg)->fld[0].rtint));





   if (r->subreg_loc != 0 && ((reloadreg)->code) == SUBREG)
     {
       if (((*r->subreg_loc)->mode)
    == ((((reloadreg)->fld[0].rtx))->mode))
  *r->subreg_loc = ((reloadreg)->fld[0].rtx);
       else
  {
    *r->where = ((reloadreg)->fld[0].rtx);
    ((*r->subreg_loc)->fld[1].rtint) += ((reloadreg)->fld[1].rtint);
  }
     }
   else
     *r->where = reloadreg;
 }

      else if (! reload_optional[r->what])
 abort ();
    }
}





void
copy_replacements(rtx x, rtx y) asm("_copy_replacements");
void
copy_replacements(rtx x, rtx y)
{
  int i, j;
  n64_enum_rtx_code code = ((x)->code);
  char *fmt = (rtx_format[(int)(code)]);
  struct n64_tag_replacement *r;



  if (code == SUBREG)
    abort ();

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      for (j = 0; j < n_replacements; j++)
 {
   if (replacements[j].subreg_loc == &((x)->fld[i].rtx))
     {
       r = &replacements[n_replacements++];
       r->where = replacements[j].where;
       r->subreg_loc = &((y)->fld[i].rtx);
       r->what = replacements[j].what;
       r->mode = replacements[j].mode;
     }
   else if (replacements[j].where == &((x)->fld[i].rtx))
     {
       r = &replacements[n_replacements++];
       r->where = &((y)->fld[i].rtx);
       r->subreg_loc = 0;
       r->what = replacements[j].what;
       r->mode = replacements[j].mode;
     }
 }
}




rtx
find_replacement(rtx *loc) asm("_find_replacement");
rtx
find_replacement(rtx *loc)
{
  struct n64_tag_replacement *r;

  for (r = &replacements[0]; r < &replacements[n_replacements]; r++)
    {
      rtx reloadreg = reload_reg_rtx[r->what];

      if (reloadreg && r->where == loc)
 {
   if (r->mode != VOIDmode && ((reloadreg)->mode) != r->mode)
     reloadreg = gen_rtx (REG, r->mode, ((reloadreg)->fld[0].rtint));

   return reloadreg;
 }
      else if (reloadreg && r->subreg_loc == loc)
 {




   if (((reloadreg)->code) == REG)
     return gen_rtx (REG, ((*loc)->mode),
       ((reloadreg)->fld[0].rtint) + ((*loc)->fld[1].rtint));
   else if (((reloadreg)->mode) == ((*loc)->mode))
     return reloadreg;
   else
     return gen_rtx (SUBREG, ((*loc)->mode), ((reloadreg)->fld[0].rtx),
       ((reloadreg)->fld[1].rtint) + ((*loc)->fld[1].rtint));
 }
    }

  return *loc;
}
int
refers_to_regno_for_reload_p(int regno, int endregno, rtx x, rtx *loc) asm("_refers_to_regno_for_reload_p");
int
refers_to_regno_for_reload_p(int regno, int endregno, rtx x, rtx *loc)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0)
    return 0;

 repeat:
  code = ((x)->code);

  switch (code)
    {
    case REG:
      i = ((x)->fld[0].rtint);



      if (i >= 68)
 {
   if (reg_equiv_memory_loc[i])
     return refers_to_regno_for_reload_p (regno, endregno,
       reg_equiv_memory_loc[i],
       ((void *)0));

   if (reg_equiv_constant[i])
     return 0;

   abort ();
 }

      return (endregno > i
       && regno < i + (i < 68
         ? (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
         : 1));

    case SUBREG:


      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68)
 {
   int inner_regno = ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint);
   int inner_endregno
     = inner_regno + (inner_regno < 68
        ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

   return endregno > inner_regno && regno < inner_endregno;
 }
      break;

    case CLOBBER:
    case SET:
      if (&((x)->fld[0].rtx) != loc



   && ((((((x)->fld[0].rtx))->code) == SUBREG
        && loc != &((((x)->fld[0].rtx))->fld[0].rtx)
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint) >= 68
        && refers_to_regno_for_reload_p (regno, endregno,
      ((((x)->fld[0].rtx))->fld[0].rtx),
      loc))


       || ((((((x)->fld[0].rtx))->code) != REG
     || earlyclobber_operand_p (((x)->fld[0].rtx)))
    && refers_to_regno_for_reload_p (regno, endregno,
         ((x)->fld[0].rtx), loc))))
 return 1;

      if (code == CLOBBER || loc == &((x)->fld[1].rtx))
 return 0;
      x = ((x)->fld[1].rtx);
      goto repeat;
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e' && loc != &((x)->fld[i].rtx))
 {
   if (i == 0)
     {
       x = ((x)->fld[0].rtx);
       goto repeat;
     }
   else
     if (refers_to_regno_for_reload_p (regno, endregno,
           ((x)->fld[i].rtx), loc))
       return 1;
 }
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >=0; j--)
     if (loc != &((x)->fld[i].rtvec->elem[j].rtx)
  && refers_to_regno_for_reload_p (regno, endregno,
       ((x)->fld[i].rtvec->elem[j].rtx), loc))
       return 1;
 }
    }
  return 0;
}
int
reg_overlap_mentioned_for_reload_p(rtx x, rtx in) asm("_reg_overlap_mentioned_for_reload_p");
int
reg_overlap_mentioned_for_reload_p(rtx x, rtx in)
{
  int regno, endregno;

  if (((x)->code) == SUBREG)
    {
      regno = ((((x)->fld[0].rtx))->fld[0].rtint);
      if (regno < 68)
 regno += ((x)->fld[1].rtint);
    }
  else if (((x)->code) == REG)
    {
      regno = ((x)->fld[0].rtint);




      if (regno >= 68)
 {
   if (reg_equiv_memory_loc[regno])
     return refers_to_mem_for_reload_p (in);
   else if (reg_equiv_constant[regno])
     return 0;
   abort ();
 }
    }
  else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    return 0;
  else if (((x)->code) == MEM)
    return refers_to_mem_for_reload_p (in);
  else if (((x)->code) == SCRATCH || ((x)->code) == PC
    || ((x)->code) == CC0)
    return reg_mentioned_p (x, in);
  else
    abort ();

  endregno = regno + (regno < 68
        ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

  return refers_to_regno_for_reload_p (regno, endregno, in, ((void *)0));
}




int
refers_to_mem_for_reload_p(rtx x) asm("_refers_to_mem_for_reload_p");
int
refers_to_mem_for_reload_p(rtx x)
{
  char *fmt;
  int i;

  if (((x)->code) == MEM)
    return 1;

  if (((x)->code) == REG)
    return (((x)->fld[0].rtint) >= 68
     && reg_equiv_memory_loc[((x)->fld[0].rtint)]);

  fmt = (rtx_format[(int)(((x)->code))]);
  for (i = (rtx_length[(int)(((x)->code))]) - 1; i >= 0; i--)
    if (fmt[i] == 'e'
 && (((((x)->fld[i].rtx))->code) == MEM
     || refers_to_mem_for_reload_p (((x)->fld[i].rtx))))
      return 1;

  return 0;
}
rtx
find_equiv_reg(register rtx goal, rtx insn, n64_enum_reg_class cxx_class, register int other, short int *reload_reg_p, int goalreg, n64_enum_machine_mode mode) asm("_find_equiv_reg");
rtx
find_equiv_reg(register rtx goal, rtx insn, n64_enum_reg_class cxx_class, register int other, short int *reload_reg_p, int goalreg, n64_enum_machine_mode mode)
{
  register rtx p = insn;
  rtx goaltry, valtry, value, where;
  register rtx pat;
  register int regno = -1;
  int valueno;
  int goal_mem = 0;
  int goal_const = 0;
  int goal_mem_addr_varies = 0;
  int need_stable_sp = 0;
  int nregs;
  int valuenregs;

  if (goal == 0)
    regno = goalreg;
  else if (((goal)->code) == REG)
    regno = ((goal)->fld[0].rtint);
  else if (((goal)->code) == MEM)
    {
      n64_enum_rtx_code code = ((((goal)->fld[0].rtx))->code);
      if (((goal)->volatil))
 return 0;
      if (flag_float_store && (mode_class[(int)(((goal)->mode))]) == MODE_FLOAT)
 return 0;

      switch (code)
 {
 case POST_INC:
 case PRE_INC:
 case POST_DEC:
 case PRE_DEC:
   return 0;
 }
      goal_mem = 1;
    }
  else if ((((goal)->code) == LABEL_REF || ((goal)->code) == SYMBOL_REF || ((goal)->code) == CONST_INT || ((goal)->code) == CONST_DOUBLE || ((goal)->code) == CONST || ((goal)->code) == HIGH))
    goal_const = 1;
  else if (((goal)->code) == PLUS
    && ((goal)->fld[0].rtx) == stack_pointer_rtx
    && (((((goal)->fld[1].rtx))->code) == LABEL_REF || ((((goal)->fld[1].rtx))->code) == SYMBOL_REF || ((((goal)->fld[1].rtx))->code) == CONST_INT || ((((goal)->fld[1].rtx))->code) == CONST_DOUBLE || ((((goal)->fld[1].rtx))->code) == CONST || ((((goal)->fld[1].rtx))->code) == HIGH))
    goal_const = need_stable_sp = 1;
  else
    return 0;
  while (1)
    {
      p = ((p)->fld[1].rtx);
      if (p == 0 || ((p)->code) == CODE_LABEL)
 return 0;
      if (((p)->code) == INSN

   && (! (reload_reg_p != 0
   && reload_reg_p != (short *) (int) 1)







       || ((p)->fld[0].rtint) < reload_first_uid))
 {
   rtx tem;
   pat = single_set (p);

   if (pat != 0
       && ((regno >= 0
     && true_regnum (((pat)->fld[1].rtx)) == regno
     && (valueno = true_regnum (valtry = ((pat)->fld[0].rtx))) >= 0)
    ||
    (regno >= 0
     && true_regnum (((pat)->fld[0].rtx)) == regno
     && (valueno = true_regnum (valtry = ((pat)->fld[1].rtx))) >= 0)
    ||
    (goal_const && rtx_equal_p (((pat)->fld[1].rtx), goal)
     && (valueno = true_regnum (valtry = ((pat)->fld[0].rtx))) >= 0)
    || (goal_mem
        && (valueno = true_regnum (valtry = ((pat)->fld[0].rtx))) >= 0
        && rtx_renumbered_equal_p (goal, ((pat)->fld[1].rtx)))
    || (goal_mem
        && (valueno = true_regnum (valtry = ((pat)->fld[1].rtx))) >= 0
        && rtx_renumbered_equal_p (goal, ((pat)->fld[0].rtx)))



    || (goal_const && (tem = find_reg_note (p, REG_EQUIV,
         (rtx) 0))
        && rtx_equal_p (((tem)->fld[0].rtx), goal)
        && (valueno = true_regnum (valtry = ((pat)->fld[0].rtx))) >= 0)
    || (goal_const && (tem = find_reg_note (p, REG_EQUIV,
         (rtx) 0))
        && ((((pat)->fld[0].rtx))->code) == REG
        && ((((tem)->fld[0].rtx))->code) == CONST_DOUBLE
        && (mode_class[(int)(((((tem)->fld[0].rtx))->mode))]) == MODE_FLOAT
        && ((goal)->code) == CONST_INT
        && 0 != (goaltry = operand_subword (((tem)->fld[0].rtx), 0, 0,
         VOIDmode))
        && rtx_equal_p (goal, goaltry)
        && (valtry = operand_subword (((pat)->fld[0].rtx), 0, 0,
          VOIDmode))
        && (valueno = true_regnum (valtry)) >= 0)
    || (goal_const && (tem = find_reg_note (p, REG_EQUIV,
         (rtx) 0))
        && ((((pat)->fld[0].rtx))->code) == REG
        && ((((tem)->fld[0].rtx))->code) == CONST_DOUBLE
        && (mode_class[(int)(((((tem)->fld[0].rtx))->mode))]) == MODE_FLOAT
        && ((goal)->code) == CONST_INT
        && 0 != (goaltry = operand_subword (((tem)->fld[0].rtx), 1, 0,
         VOIDmode))
        && rtx_equal_p (goal, goaltry)
        && (valtry
     = operand_subword (((pat)->fld[0].rtx), 1, 0, VOIDmode))
        && (valueno = true_regnum (valtry)) >= 0)))
     if (other >= 0
  ? valueno == other
  : ((unsigned) valueno < 68
     && ((reg_class_contents[(int) cxx_class])[(valueno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((valueno) % ((unsigned) 32))))
              ))
       {
  value = valtry;
  where = p;
  break;
       }
 }
    }
  if (find_reg_note (where, REG_UNUSED, value))
    return 0;



  if (valueno == (0 + 29)
      || (goal_mem && reg_overlap_mentioned_for_reload_p (stack_pointer_rtx,
         goal)))
    need_stable_sp = 1;


  if (((value)->mode) != mode)
    return 0;




  if (goal_mem && value == ((((where)->fld[3].rtx))->fld[0].rtx)
      && refers_to_regno_for_reload_p (valueno,
           (valueno
     + (! ((unsigned) ((valueno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))),
           goal, ((void *)0)))
    return 0;



  if (!goal_mem && !goal_const
      && regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > valueno
      && regno < valueno + (! ((unsigned) ((valueno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))))
    return 0;







  if (reload_reg_p != 0 && reload_reg_p != (short *) (int) 1
      && reload_reg_p[valueno] >= 0)
    return 0;
  nregs = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  valuenregs = (! ((unsigned) ((valueno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));




  if (reload_reg_p != 0)
    {
      int i;
      for (i = 0; i < n_reloads; i++)
 if (reload_reg_rtx[i] != 0 && reload_in[i])
   {
     int regno1 = ((reload_reg_rtx[i])->fld[0].rtint);
     int nregs1 = (! ((unsigned) ((regno1) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reload_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reload_reg_rtx[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                     ;
     if (regno1 < valueno + valuenregs
  && regno1 + nregs1 > valueno)
       return 0;
   }
    }

  if (goal_mem)


    goal_mem_addr_varies = !((((((goal)->fld[0].rtx))->code) == LABEL_REF || ((((goal)->fld[0].rtx))->code) == SYMBOL_REF || ((((goal)->fld[0].rtx))->code) == CONST_INT || ((((goal)->fld[0].rtx))->code) == HIGH || (((((goal)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((goal)->fld[0].rtx))) && ! 0)) && (!0 || !0));




  p = insn;
  while (1)
    {
      p = ((p)->fld[1].rtx);
      if (p == where)
 return value;



      if (((p)->code) == CALL_INSN
   && ((regno >= 0 && regno < 68
        && call_used_regs[regno])
       ||
       (valueno >= 0 && valueno < 68
        && call_used_regs[valueno])
       ||
       goal_mem
       || need_stable_sp))
 return 0;
      if ((rtx_class[(int)(((p)->code))]) == 'i')
 {





   pat = ((p)->fld[3].rtx);
   if (((pat)->code) == SET || ((pat)->code) == CLOBBER)
     {
       register rtx dest = ((pat)->fld[0].rtx);
       while (((dest)->code) == SUBREG
       || ((dest)->code) == ZERO_EXTRACT
       || ((dest)->code) == SIGN_EXTRACT
       || ((dest)->code) == STRICT_LOW_PART)
  dest = ((dest)->fld[0].rtx);
       if (((dest)->code) == REG)
  {
    register int xregno = ((dest)->fld[0].rtint);
    int xnregs;
    if (((dest)->fld[0].rtint) < 68)
      xnregs = (! ((unsigned) ((xregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
    else
      xnregs = 1;
    if (xregno < regno + nregs && xregno + xnregs > regno)
      return 0;
    if (xregno < valueno + valuenregs
        && xregno + xnregs > valueno)
      return 0;
    if (goal_mem_addr_varies
        && reg_overlap_mentioned_for_reload_p (dest, goal))
      return 0;
  }
       else if (goal_mem && ((dest)->code) == MEM
         && ! push_operand (dest, ((dest)->mode)))
  return 0;
       else if (((dest)->code) == MEM && regno >= 68
         && reg_equiv_memory_loc[regno] != 0)
  return 0;
       else if (need_stable_sp && push_operand (dest, ((dest)->mode)))
  return 0;
     }
   else if (((pat)->code) == PARALLEL)
     {
       register int i;
       for (i = ((pat)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
  {
    register rtx v1 = ((pat)->fld[0].rtvec->elem[i].rtx);
    if (((v1)->code) == SET || ((v1)->code) == CLOBBER)
      {
        register rtx dest = ((v1)->fld[0].rtx);
        while (((dest)->code) == SUBREG
        || ((dest)->code) == ZERO_EXTRACT
        || ((dest)->code) == SIGN_EXTRACT
        || ((dest)->code) == STRICT_LOW_PART)
   dest = ((dest)->fld[0].rtx);
        if (((dest)->code) == REG)
   {
     register int xregno = ((dest)->fld[0].rtint);
     int xnregs;
     if (((dest)->fld[0].rtint) < 68)
       xnregs = (! ((unsigned) ((xregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
     else
       xnregs = 1;
     if (xregno < regno + nregs
         && xregno + xnregs > regno)
       return 0;
     if (xregno < valueno + valuenregs
         && xregno + xnregs > valueno)
       return 0;
     if (goal_mem_addr_varies
         && reg_overlap_mentioned_for_reload_p (dest,
             goal))
       return 0;
   }
        else if (goal_mem && ((dest)->code) == MEM
          && ! push_operand (dest, ((dest)->mode)))
   return 0;
        else if (need_stable_sp
          && push_operand (dest, ((dest)->mode)))
   return 0;
      }
  }
     }

   if (((p)->code) == CALL_INSN && ((p)->fld[7].rtx))
     {
       rtx link;

       for (link = ((p)->fld[7].rtx); ((link)->fld[1].rtx) != 0;
     link = ((link)->fld[1].rtx))
  {
    pat = ((link)->fld[0].rtx);
    if (((pat)->code) == CLOBBER)
      {
        register rtx dest = ((pat)->fld[0].rtx);
        while (((dest)->code) == SUBREG
        || ((dest)->code) == ZERO_EXTRACT
        || ((dest)->code) == SIGN_EXTRACT
        || ((dest)->code) == STRICT_LOW_PART)
   dest = ((dest)->fld[0].rtx);
        if (((dest)->code) == REG)
   {
     register int xregno = ((dest)->fld[0].rtint);
     int xnregs;
     if (((dest)->fld[0].rtint) < 68)
       xnregs = (! ((unsigned) ((xregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
     else
       xnregs = 1;
     if (xregno < regno + nregs
         && xregno + xnregs > regno)
       return 0;
     if (xregno < valueno + valuenregs
         && xregno + xnregs > valueno)
       return 0;
     if (goal_mem_addr_varies
         && reg_overlap_mentioned_for_reload_p (dest,
             goal))
       return 0;
   }
        else if (goal_mem && ((dest)->code) == MEM
          && ! push_operand (dest, ((dest)->mode)))
   return 0;
        else if (need_stable_sp
          && push_operand (dest, ((dest)->mode)))
   return 0;
      }
  }
     }
 }
    }
}





static int
find_inc_amount(rtx x, rtx inced) asm("_find_inc_amount");
static int
find_inc_amount(rtx x, rtx inced)
{
  register n64_enum_rtx_code code = ((x)->code);
  register char *fmt;
  register int i;

  if (code == MEM)
    {
      register rtx addr = ((x)->fld[0].rtx);
      if ((((addr)->code) == PRE_DEC
    || ((addr)->code) == POST_DEC
    || ((addr)->code) == PRE_INC
    || ((addr)->code) == POST_INC)
   && ((addr)->fld[0].rtx) == inced)
 return (mode_size[(int)(((x)->mode))]);
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   register int tem = find_inc_amount (((x)->fld[i].rtx), inced);
   if (tem != 0)
     return tem;
 }
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     {
       register int tem = find_inc_amount (((x)->fld[i].rtvec->elem[j].rtx), inced);
       if (tem != 0)
  return tem;
     }
 }
    }

  return 0;
}



int
regno_clobbered_p(int regno, rtx insn) asm("_regno_clobbered_p");
int
regno_clobbered_p(int regno, rtx insn)
{
  if (((((insn)->fld[3].rtx))->code) == CLOBBER
      && ((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == REG)
    return ((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtint) == regno;

  if (((((insn)->fld[3].rtx))->code) == PARALLEL)
    {
      int i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1;

      for (; i >= 0; i--)
 {
   rtx elt = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
   if (((elt)->code) == CLOBBER && ((((elt)->fld[0].rtx))->code) == REG
       && ((((elt)->fld[0].rtx))->fld[0].rtint) == regno)
     return 1;
 }
    }

  return 0;
}

static char *reload_when_needed_name[] =
{
  "RELOAD_FOR_INPUT",
  "RELOAD_FOR_OUTPUT",
  "RELOAD_FOR_INSN",
  "RELOAD_FOR_INPUT_ADDRESS",
  "RELOAD_FOR_OUTPUT_ADDRESS",
  "RELOAD_FOR_OPERAND_ADDRESS",
  "RELOAD_FOR_OPADDR_ADDR",
  "RELOAD_OTHER",
  "RELOAD_FOR_OTHER_ADDRESS"
};

static char *reg_class_names[] = { "NO_REGS", "GR_REGS", "FP_REGS", "HI_REG", "LO_REG", "HILO_REG", "MD_REGS", "ST_REGS", "ALL_REGS" };



void
debug_reload(void) asm("_debug_reload");
void
debug_reload(void)
{
  int r;

  fprintf (
          (__acrt_iob_func(2))
                , "\nn_reloads = %d\n", n_reloads);

  for (r = 0; r < n_reloads; r++)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "\nRELOAD %d\n", r);

      if (reload_in[r])
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nreload_in (%s) = ",
     (mode_name[(int)(reload_inmode[r])]));
   debug_rtx (reload_in[r]);
 }

      if (reload_out[r])
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nreload_out (%s) = ",
     (mode_name[(int)(reload_outmode[r])]));
   debug_rtx (reload_out[r]);
 }

      fprintf (
              (__acrt_iob_func(2))
                    , "%s, ", reg_class_names[(int) reload_reg_class[r]]);

      fprintf (
              (__acrt_iob_func(2))
                    , "%s (opnum = %d)",
        reload_when_needed_name[(int)reload_when_needed[r]],
        reload_opnum[r]);

      if (reload_optional[r])
 fprintf (
         (__acrt_iob_func(2))
               , ", optional");

      if (reload_in[r])
 fprintf (
         (__acrt_iob_func(2))
               , ", inc by %d\n", reload_inc[r]);

      if (reload_nocombine[r])
 fprintf (
         (__acrt_iob_func(2))
               , ", can combine", reload_nocombine[r]);

      if (reload_secondary_p[r])
 fprintf (
         (__acrt_iob_func(2))
               , ", secondary_reload_p");

      if (reload_in_reg[r])
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nreload_in_reg:\t\t\t");
   debug_rtx (reload_in_reg[r]);
 }

      if (reload_reg_rtx[r])
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nreload_reg_rtx:\t\t\t");
   debug_rtx (reload_reg_rtx[r]);
 }

      if (reload_secondary_in_reload[r] != -1)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nsecondary_in_reload = ");
   fprintf (
           (__acrt_iob_func(2))
                 , "%d ", reload_secondary_in_reload[r]);
 }

      if (reload_secondary_out_reload[r] != -1)
 {
   if (reload_secondary_in_reload[r] != -1)
     fprintf (
             (__acrt_iob_func(2))
                   , ", secondary_out_reload = ");
   else
     fprintf (
             (__acrt_iob_func(2))
                   , "\nsecondary_out_reload = ");

   fprintf (
           (__acrt_iob_func(2))
                 , "%d", reload_secondary_out_reload[r]);
 }


      if (reload_secondary_in_icode[r] != CODE_FOR_nothing)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "\nsecondary_in_icode = ");
   fprintf (
           (__acrt_iob_func(2))
                 , "%s", insn_name[r]);
 }

      if (reload_secondary_out_icode[r] != CODE_FOR_nothing)
 {
   if (reload_secondary_in_icode[r] != CODE_FOR_nothing)
     fprintf (
             (__acrt_iob_func(2))
                   , ", secondary_out_icode = ");
   else
     fprintf (
             (__acrt_iob_func(2))
                   , "\nsecondary_out_icode = ");

   fprintf (
           (__acrt_iob_func(2))
                 , "%s ", insn_name[r]);
 }
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }

  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}

