// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/subsegs.c
/* subsegs.c - subsegments -
   Copyright (C) 1987, 1990, 1991, 1992, 1993, 1994
   Free Software Foundation, Inc.

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GAS; see the file COPYING.  If not, write to
   the Free Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_FLONUM_STRUCT;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__pseudo_type;
struct n64_tag__symbol_info;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_bit_fix;
struct n64_tag_carsym;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_emulation;
struct n64_tag_expressionS;
struct n64_tag_fix;
struct n64_tag_format_ops;
struct n64_tag_frag;
struct n64_tag_frchain;
struct n64_tag_hash_control;
struct n64_tag_hash_entry;
struct n64_tag_lineno_cache_entry;
struct n64_tag_mips_cl_insn;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relax_type;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol;
struct n64_tag_symbol_cache_entry;








extern char *strdup(...) asm("_strdup");


struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");



extern void * bfd_alloc_by_size_t (bfd *abfd, size_t sz) asm("_bfd_alloc_by_size_t");
extern char *strstr(...) asm("_strstr");

typedef unsigned short LITTLENUM_TYPE;







int bignum_copy (LITTLENUM_TYPE * in, int in_length, LITTLENUM_TYPE * out, int out_length) asm("_bignum_copy")
                                          ;
struct n64_tag_FLONUM_STRUCT
{
  LITTLENUM_TYPE *low;
  LITTLENUM_TYPE *high;
  LITTLENUM_TYPE *leader;

  long exponent;
  char sign;
};

typedef struct n64_tag_FLONUM_STRUCT FLONUM_TYPE;
extern const FLONUM_TYPE flonum_positive_powers_of_ten[];
extern const FLONUM_TYPE flonum_negative_powers_of_ten[];
extern const int table_size_of_flonum_powers_of_ten;
int atof_generic (char **address_of_string_pointer, const char *string_of_decimal_marks, const char *string_of_decimal_exponent_marks, FLONUM_TYPE * address_of_generic_floating_point_number) asm("_atof_generic")


                                                             ;

void flonum_copy (FLONUM_TYPE * in, FLONUM_TYPE * out) asm("_flonum_copy");
void flonum_multip (const FLONUM_TYPE * a, const FLONUM_TYPE * b, FLONUM_TYPE * product) asm("_flonum_multip")
                              ;




extern bfd *stdoutput;
typedef bfd_vma addressT;
typedef bfd_signed_vma offsetT;






typedef addressT valueT;
typedef asection *segT;





typedef int subsegT;


extern subsegT now_subseg;


extern segT now_seg;
extern segT reg_section, expr_section;

extern segT text_section, data_section, bss_section;
enum n64_cpp_enum__relax_state{



    rs_fill = 1,


    rs_align,



    rs_align_code,



    rs_org,



    rs_broken_word,



    rs_machine_dependent,





    rs_space
  };
typedef __underlying_type(enum n64_cpp_enum__relax_state) n64_enum__relax_state;


typedef n64_enum__relax_state relax_stateT;



typedef unsigned int relax_substateT;



typedef addressT relax_addressT;
struct n64_tag_frag
{

  addressT fr_address;

  struct n64_tag_frag *fr_next;


  offsetT fr_fix;

  offsetT fr_var;

  struct n64_tag_symbol *fr_symbol;

  offsetT fr_offset;

  char *fr_opcode;


  struct list_info_struct *line;



  relax_stateT fr_type;
  relax_substateT fr_subtype;



  unsigned short align_mask;
  unsigned short align_offset;
  char fr_pcrel_adjust, fr_bsr;


  char fr_literal[1];
};





typedef struct n64_tag_frag fragS;




extern fragS *frag_now;
extern int frag_now_fix(void) asm("_frag_now_fix");


extern fragS zero_address_frag;

extern fragS bss_address_frag;



extern unsigned char flag_no_comments;
extern unsigned char flag_debug;
extern unsigned char flag_signed_overflow_ok;

extern unsigned char flag_warn_displacement;



extern int flag_keep_locals;


extern int flag_mri;



extern unsigned char flag_readonly_data_in_text;


extern int flag_no_warnings;



extern unsigned char flag_always_generate_output;



extern unsigned char flag_print_statistics;


extern char *out_file_name;


extern int need_pass_2;



extern int linkrelax;


extern int listing;


extern int max_macro_nest;



extern int chunksize;

struct n64_tag__pseudo_type
  {

    const char *poc_name;

    void (*poc_handler) (int);

    int poc_val;
  };

typedef struct n64_tag__pseudo_type pseudo_typeS;
void as_bad (const char *format, ...) asm("_as_bad") __attribute__ ((format (printf, 1, 2)));
void as_fatal (const char *format, ...) asm("_as_fatal") __attribute__ ((format (printf, 1, 2)));
void as_tsktsk (const char *format, ...) asm("_as_tsktsk") __attribute__ ((format (printf, 1, 2)));
void as_warn (const char *format, ...) asm("_as_warn") __attribute__ ((format (printf, 1, 2)));
void as_bad_where (char *file, unsigned int line, const char *format, ...) asm("_as_bad_where") __attribute__ ((format (printf, 3, 4)));
void as_warn_where (char *file, unsigned int line, const char *format, ...) asm("_as_warn_where") __attribute__ ((format (printf, 3, 4)));
void as_assert (const char *, int, const char *) asm("_as_assert");
void as_abort (const char *, int, const char *) asm("_as_abort");

void fprint_value (FILE *file, addressT value) asm("_fprint_value");
void sprint_value (char *buf, addressT value) asm("_sprint_value");

int had_errors (void) asm("_had_errors");
int had_warnings (void) asm("_had_warnings");

void print_version_id (void) asm("_print_version_id");
char *app_push (void) asm("_app_push");
char *atof_ieee (char *str, int what_kind, LITTLENUM_TYPE * words) asm("_atof_ieee");
char *input_scrub_include_file (char *filename, char *position) asm("_input_scrub_include_file");
char *input_scrub_new_file (char *filename) asm("_input_scrub_new_file");
char *input_scrub_next_buffer (char **bufp) asm("_input_scrub_next_buffer");
void * xmalloc (unsigned long size) asm("_xmalloc");
void * xrealloc (void * ptr, unsigned long n) asm("_xrealloc");
int do_scrub_chars (int (*get) (char **), char *to, int tolen) asm("_do_scrub_chars");
int gen_to_words (LITTLENUM_TYPE * words, int precision, long exponent_bits) asm("_gen_to_words")
                         ;
int had_err (void) asm("_had_err");
int ignore_input (void) asm("_ignore_input");
int seen_at_least_1_file (void) asm("_seen_at_least_1_file");
void app_pop (char *arg) asm("_app_pop");
void as_howmuch (FILE * stream) asm("_as_howmuch");
void as_perror (const char *gripe, const char *filename) asm("_as_perror");
void as_where (char **namep, unsigned int *linep) asm("_as_where");
void bump_line_counters (void) asm("_bump_line_counters");
void do_scrub_begin (void) asm("_do_scrub_begin");
void input_scrub_begin (void) asm("_input_scrub_begin");
void input_scrub_close (void) asm("_input_scrub_close");
void input_scrub_end (void) asm("_input_scrub_end");
void new_logical_line (char *fname, int line_number) asm("_new_logical_line");
void subsegs_begin (void) asm("_subsegs_begin");
void subseg_change (segT seg, int subseg) asm("_subseg_change");
segT subseg_new (const char *name, subsegT subseg) asm("_subseg_new");
segT subseg_force_new (const char *name, subsegT subseg) asm("_subseg_force_new");
void subseg_set (segT seg, subsegT subseg) asm("_subseg_set");

segT subseg_get (const char *, int) asm("_subseg_get");


struct n64_tag_expressionS;
struct n64_tag_fix;
struct n64_tag_symbol;
struct n64_tag_relax_type;



valueT add_to_literal_pool (struct n64_tag_symbol *, valueT, segT, int) asm("_add_to_literal_pool");


enum n64_cpp_enum_anonymous_11{

  O_illegal,

  O_absent,

  O_constant,

  O_symbol,

  O_symbol_rva,

  O_register,




  O_big,

  O_uminus,

  O_bit_not,

  O_logical_not,

  O_multiply,

  O_divide,

  O_modulus,

  O_left_shift,

  O_right_shift,

  O_bit_inclusive_or,

  O_bit_or_not,

  O_bit_exclusive_or,

  O_bit_and,

  O_add,

  O_subtract,

  O_eq,

  O_ne,

  O_lt,

  O_le,

  O_ge,

  O_gt,

  O_logical_and,

  O_logical_or
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_11) n64_enum_anonymous_11;
typedef n64_enum_anonymous_11 operatorT;

typedef struct n64_tag_expressionS
{

  operatorT X_op;

  struct n64_tag_symbol *X_add_symbol;

  struct n64_tag_symbol *X_op_symbol;

  offsetT X_add_number;






  int X_unsigned;
} expressionS;







extern FLONUM_TYPE generic_floating_point_number;

extern LITTLENUM_TYPE generic_bignum[];



typedef char operator_rankT;

char get_symbol_end (void) asm("_get_symbol_end");
void expr_begin (void) asm("_expr_begin");
segT expr (int rank, expressionS * resultP) asm("_expr");
unsigned int get_single_number (void) asm("_get_single_number");
struct n64_tag_symbol *make_expr_symbol (expressionS * expressionP) asm("_make_expr_symbol");


typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");
extern int mips_local_label (const char *) asm("_mips_local_label");
extern const char *mips_target_format(void) asm("_mips_target_format");

struct n64_tag_mips_cl_insn {
    unsigned long insn_opcode;
    const struct mips_opcode *insn_mo;
};

extern int tc_get_register (int frame) asm("_tc_get_register");


extern int mips_parse_long_option (const char *) asm("_mips_parse_long_option");


extern void mips_define_label (struct n64_tag_symbol *) asm("_mips_define_label");


extern void cons_fix_new_mips(...) asm("_cons_fix_new_mips");




extern int mips_force_relocation(...) asm("_mips_force_relocation");






extern unsigned long mips_gprmask;
extern unsigned long mips_cprmask[4];




extern void mips_elf_final_processing (void) asm("_mips_elf_final_processing");
extern void md_mips_end (void) asm("_md_mips_end");





extern void mips_pop_insert (void) asm("_mips_pop_insert");


extern void mips_flush_pending_output (void) asm("_mips_flush_pending_output");


extern void mips_enable_auto_align (void) asm("_mips_enable_auto_align");


extern void mips_init_after_args (void) asm("_mips_init_after_args");
extern asection *gdb_section;



extern void elf_frob_file (void) asm("_elf_frob_file");
extern void elf_file_symbol (char *) asm("_elf_file_symbol");


extern void obj_elf_section (int) asm("_obj_elf_section");
extern void obj_elf_previous (int) asm("_obj_elf_previous");
extern void obj_elf_version (int) asm("_obj_elf_version");
extern void obj_elf_init_stab_section (segT) asm("_obj_elf_init_stab_section");
extern void elf_frob_symbol (struct n64_tag_symbol *, int *) asm("_elf_frob_symbol");


extern void elf_pop_insert (void) asm("_elf_pop_insert");

struct n64_tag_symbol
{
  asymbol *bsym;



  expressionS sy_value;


  struct n64_tag_symbol *sy_next;

  struct n64_tag_symbol *sy_previous;




  struct n64_tag_frag *sy_frag;

  unsigned int written : 1;


  unsigned int sy_resolved : 1;


  unsigned int sy_resolving : 1;



  unsigned int sy_used_in_reloc : 1;





  unsigned int sy_used : 1;





  unsigned int sy_mri_common : 1;


  expressionS * sy_obj;







  int local:1; unsigned long sy_name_offset;

};

typedef struct n64_tag_symbol symbolS;
extern const segT N_TYPE_seg[];


extern const short seg_N_TYPE[];



void symbol_clear_list_pointers (symbolS * symbolP) asm("_symbol_clear_list_pointers");



void symbol_insert (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_insert")
                                           ;
void symbol_remove (symbolS * symbolP, symbolS ** rootP, symbolS ** lastP) asm("_symbol_remove")
                         ;





void verify_symbol_chain (symbolS * rootP, symbolS * lastP) asm("_verify_symbol_chain");
void verify_symbol_chain_2 (symbolS * symP) asm("_verify_symbol_chain_2");

void symbol_append (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_append")
                                           ;
struct n64_tag_bit_fix
  {
    int fx_bit_size;
    int fx_bit_offset;
    long fx_bit_base;

    long fx_bit_base_adj;
    long fx_bit_max;
    long fx_bit_min;
    long fx_bit_add;
  };
typedef struct n64_tag_bit_fix bit_fixS;





struct n64_tag_fix
{




  char fx_pcrel_adjust;


  unsigned char fx_size;


  unsigned fx_pcrel : 1;






  unsigned fx_plt : 1;



  unsigned fx_im_disp : 2;



  unsigned fx_tcbit : 1;


  unsigned fx_done : 1;






  unsigned fx_no_overflow : 1;


  fragS *fx_frag;


  long fx_where;


  symbolS *fx_addsy;


  symbolS *fx_subsy;


  valueT fx_offset;


  struct n64_tag_fix *fx_next;




  bit_fixS *fx_bit_fixP;


  bfd_reloc_code_real_type fx_r_type;
  valueT fx_addnumber;



  char *fx_file;
  unsigned fx_line;






};

typedef struct n64_tag_fix fixS;
extern long string_byte_count;
extern int section_alignment[];

bit_fixS *bit_fix_new (int size, int offset, long base_type, long base_adj, long min, long max, long add) asm("_bit_fix_new")
                                                       ;
void append (char **charPP, char *fromP, unsigned long length) asm("_append");
void record_alignment (segT seg, int align) asm("_record_alignment");
void write_object_file (void) asm("_write_object_file");
void relax_segment (struct n64_tag_frag * seg_frag_root, segT seg_type) asm("_relax_segment");

void number_to_chars_littleendian (char *, valueT, int) asm("_number_to_chars_littleendian");
void number_to_chars_bigendian (char *, valueT, int) asm("_number_to_chars_bigendian");


fixS *fix_new (fragS * frag, int where, int size, symbolS * add_symbol, offsetT offset, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new")

                                          ;
fixS *fix_new_exp (fragS * frag, int where, int size, expressionS *exp, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new_exp")

                                       ;
extern void frag_append_1_char (int) asm("_frag_append_1_char");




void frag_init (void) asm("_frag_init");
void frag_grow (unsigned int nchars) asm("_frag_grow");
char *frag_more (int nchars) asm("_frag_more");
void frag_align (int alignment, int fill_character) asm("_frag_align");
void frag_align_pattern (int alignment, const char *fill_pattern, int n_fill) asm("_frag_align_pattern")

                 ;
void frag_new (int old_frags_var_max_size) asm("_frag_new");
void frag_wane (fragS * fragP) asm("_frag_wane");

char *frag_variant (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_variant")





                     ;

char *frag_var (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_var")





                 ;
struct n64_tag_hash_entry
{
  const char *hash_string;


  void * hash_value;
};



struct n64_tag_hash_control
{
  struct n64_tag_hash_entry *hash_where;
  int hash_sizelog;
  int hash_mask;
  int hash_full;

  struct n64_tag_hash_entry *hash_wall;

  int hash_stat[(6)];

};



struct n64_tag_hash_control *hash_new (void) asm("_hash_new");
void hash_die (struct n64_tag_hash_control *) asm("_hash_die");
void hash_say (struct n64_tag_hash_control *, int *buffer, int bufsiz) asm("_hash_say");

void * hash_delete (struct n64_tag_hash_control *, const char *str) asm("_hash_delete");

void * hash_replace (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_replace");

const char *hash_insert (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_insert")
              ;

char *hash_apply (struct n64_tag_hash_control *, char *(*fn) (const char *str, void * val)) asm("_hash_apply")
                                             ;

void * hash_find (struct n64_tag_hash_control *, const char *str) asm("_hash_find");

const char *hash_jam (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_jam")
                  ;
extern char *input_line_pointer;
extern char lex_type[];
extern char is_end_of_line[];

extern int target_big_endian;


extern const char comment_chars[];
extern const char line_comment_chars[];
extern const char line_separator_chars[];


extern int generate_asm_lineno;


extern addressT abs_section_offset;


extern symbolS *line_label;


extern symbolS *mri_common_symbol;

unsigned int get_stab_string_offset (const char *string, const char *stabstr_secname) asm("_get_stab_string_offset")
                                       ;

char *demand_copy_C_string (int *len_pointer) asm("_demand_copy_C_string");
char get_absolute_expression_and_terminator (long *val_pointer) asm("_get_absolute_expression_and_terminator");
offsetT get_absolute_expression (void) asm("_get_absolute_expression");
unsigned int next_char_of_string (void) asm("_next_char_of_string");
void s_mri_sect (char *) asm("_s_mri_sect");
char *mri_comment_field (char *) asm("_mri_comment_field");
void mri_comment_end (char *, int) asm("_mri_comment_end");
void add_include_dir (char *path) asm("_add_include_dir");
void cons (int nbytes) asm("_cons");
void demand_empty_rest_of_line (void) asm("_demand_empty_rest_of_line");
void emit_expr (expressionS *exp, unsigned int nbytes) asm("_emit_expr");
void equals (char *sym_name) asm("_equals");
void float_cons (int float_type) asm("_float_cons");
void ignore_rest_of_line (void) asm("_ignore_rest_of_line");
void pseudo_set (symbolS * symbolP) asm("_pseudo_set");
void read_a_source_file (char *name) asm("_read_a_source_file");
void read_begin (void) asm("_read_begin");
void s_abort (int) asm("_s_abort");
void s_align_bytes (int arg) asm("_s_align_bytes");
void s_align_ptwo (int) asm("_s_align_ptwo");
void s_app_file (int) asm("_s_app_file");
void s_app_line (int) asm("_s_app_line");
void s_comm (int) asm("_s_comm");
void s_data (int) asm("_s_data");
void s_desc (int) asm("_s_desc");
void s_else (int arg) asm("_s_else");
void s_end (int arg) asm("_s_end");
void s_endif (int arg) asm("_s_endif");
void s_err (int) asm("_s_err");
void s_fail (int) asm("_s_fail");
void s_fill (int) asm("_s_fill");
void s_float_space (int mult) asm("_s_float_space");
void s_globl (int arg) asm("_s_globl");
void s_if (int arg) asm("_s_if");
void s_ifc (int arg) asm("_s_ifc");
void s_ifdef (int arg) asm("_s_ifdef");
void s_ifeqs (int arg) asm("_s_ifeqs");
void s_ignore (int arg) asm("_s_ignore");
void s_include (int arg) asm("_s_include");
void s_irp (int arg) asm("_s_irp");
void s_lcomm (int needs_align) asm("_s_lcomm");
void s_lsym (int) asm("_s_lsym");
void s_macro (int) asm("_s_macro");
void s_mexit (int) asm("_s_mexit");
void s_mri_common (int) asm("_s_mri_common");
void s_org (int) asm("_s_org");
void s_print (int) asm("_s_print");
void s_purgem (int) asm("_s_purgem");
void s_rept (int) asm("_s_rept");
void s_set (int) asm("_s_set");
void s_space (int mult) asm("_s_space");
void s_stab (int what) asm("_s_stab");
void s_struct (int) asm("_s_struct");
void s_text (int) asm("_s_text");
void stringer (int append_zero) asm("_stringer");
void s_xstab (int what) asm("_s_xstab");
void s_rva (int) asm("_s_rva");
extern struct n64_tag_obstack notes;

extern struct n64_tag_obstack cond_obstack;


extern symbolS *symbol_rootP;
extern symbolS *symbol_lastP;

extern symbolS abs_symbol;

extern int symbol_table_frozen;



extern int symbols_case_sensitive;

char *decode_local_label_name (char *s) asm("_decode_local_label_name");
symbolS *symbol_find (const char *name) asm("_symbol_find");
symbolS *symbol_find_base (const char *name, int strip_underscore) asm("_symbol_find_base");
symbolS *symbol_find_or_make (const char *name) asm("_symbol_find_or_make");
symbolS *symbol_make (const char *name) asm("_symbol_make");
symbolS *symbol_new (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_new")
                      ;
symbolS *symbol_create (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_create")
                  ;
symbolS *colon (const char *sym_name) asm("_colon");
void local_colon (int n) asm("_local_colon");
void symbol_begin (void) asm("_symbol_begin");
void symbol_table_insert (symbolS * symbolP) asm("_symbol_table_insert");
void resolve_symbol_value (symbolS *) asm("_resolve_symbol_value");

int dollar_label_defined (long l) asm("_dollar_label_defined");
void dollar_label_clear (void) asm("_dollar_label_clear");
void define_dollar_label (long l) asm("_define_dollar_label");
char *dollar_label_name (long l, int augend) asm("_dollar_label_name");

void fb_label_instance_inc (long label) asm("_fb_label_instance_inc");
char *fb_label_name (long n, long augend) asm("_fb_label_name");

extern void copy_symbol_attributes (symbolS *, symbolS *) asm("_copy_symbol_attributes");


extern valueT S_GET_VALUE (symbolS *) asm("_S_GET_VALUE");
extern void S_SET_VALUE (symbolS *, valueT) asm("_S_SET_VALUE");


extern int S_IS_EXTERNAL (symbolS *) asm("_S_IS_EXTERNAL");
extern int S_IS_WEAK (symbolS *) asm("_S_IS_WEAK");
extern int S_IS_COMMON (symbolS *) asm("_S_IS_COMMON");
extern int S_IS_DEFINED (symbolS *) asm("_S_IS_DEFINED");
extern int S_IS_DEBUG (symbolS *) asm("_S_IS_DEBUG");
extern int S_IS_LOCAL (symbolS *) asm("_S_IS_LOCAL");
extern int S_IS_EXTERN (symbolS *) asm("_S_IS_EXTERN");
extern int S_IS_STABD (symbolS *) asm("_S_IS_STABD");
extern const char *S_GET_NAME (symbolS *) asm("_S_GET_NAME");
extern segT S_GET_SEGMENT (symbolS *) asm("_S_GET_SEGMENT");
extern void S_SET_SEGMENT (symbolS *, segT) asm("_S_SET_SEGMENT");
extern void S_SET_EXTERNAL (symbolS *) asm("_S_SET_EXTERNAL");
extern void S_SET_NAME (symbolS *, char *) asm("_S_SET_NAME");
extern void S_CLEAR_EXTERNAL (symbolS *) asm("_S_CLEAR_EXTERNAL");
extern void S_SET_WEAK (symbolS *) asm("_S_SET_WEAK");

extern const pseudo_typeS md_pseudo_table[];




struct n64_tag_relax_type
{

  long rlx_forward;

  long rlx_backward;


  unsigned char rlx_length;


  relax_substateT rlx_more;
};

typedef struct n64_tag_relax_type relax_typeS;

extern const int md_reloc_size;

char *md_atof (int what_statement_type, char *literalP, int *sizeP) asm("_md_atof");

int md_estimate_size_before_relax (fragS * fragP, segT segment) asm("_md_estimate_size_before_relax");

int md_parse_option (int c, char *arg) asm("_md_parse_option");
void md_show_usage (FILE *) asm("_md_show_usage");
long md_pcrel_from (fixS * fixP) asm("_md_pcrel_from");
short tc_coff_fix2rtype (fixS * fixP) asm("_tc_coff_fix2rtype");
void md_assemble (char *str) asm("_md_assemble");
void md_begin (void) asm("_md_begin");

void md_create_long_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_long_jump")

                           ;


void md_create_short_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_short_jump")

                            ;

void md_number_to_chars (char *buf, valueT val, int n) asm("_md_number_to_chars");
int md_apply_fix (fixS * fixP, valueT *val) asm("_md_apply_fix");

void md_convert_frag (bfd * headers, segT sec, fragS * fragP) asm("_md_convert_frag");


void tc_headers_hook (segT *, fixS *) asm("_tc_headers_hook");




extern arelent **tc_gen_reloc (asection *, fixS *) asm("_tc_gen_reloc");
valueT md_section_align (segT seg, valueT size) asm("_md_section_align");
char *obj_default_output_file_name (void) asm("_obj_default_output_file_name");
void obj_emit_relocations (char **where, fixS * fixP, relax_addressT segment_address_in_file) asm("_obj_emit_relocations")
                                               ;
void obj_emit_strings (char **where) asm("_obj_emit_strings");
void obj_emit_symbols (char **where, symbolS * symbols) asm("_obj_emit_symbols");

void obj_read_begin_hook (void) asm("_obj_read_begin_hook");
void obj_symbol_new_hook (symbolS * symbolP) asm("_obj_symbol_new_hook");


void obj_symbol_to_chars (char **where, symbolS * symbolP) asm("_obj_symbol_to_chars");

extern const pseudo_typeS obj_pseudo_table[];


struct n64_tag_format_ops {
  int flavor;
  unsigned dfl_leading_underscore : 1;
  unsigned emit_section_symbols : 1;
  void (*frob_symbol) (symbolS *, int *);
  void (*frob_file) (void);
  bfd_vma (*s_get_size) (symbolS *);
  void (*s_set_size) (symbolS *, bfd_vma);
  bfd_vma (*s_get_align) (symbolS *);
  void (*s_set_align) (symbolS *, bfd_vma);
  void (*copy_symbol_attributes) (symbolS *, symbolS *);
  void (*generate_asm_lineno) (const char *, int);
  void (*process_stab) (segT, int, const char *, int, int, int);
  int (*sec_sym_ok_for_reloc) (asection *);
  void (*pop_insert) (void);

  void (*ecoff_set_ext) (symbolS *, struct ecoff_extr *);

  void (*read_begin_hook) (void);
  void (*symbol_new_hook) (symbolS *);
};

extern const struct n64_tag_format_ops elf_format_ops;
extern const struct n64_tag_format_ops ecoff_format_ops;


extern const struct n64_tag_format_ops *this_format;





struct n64_tag_emulation {
  void (*match) (const char *);
  const char *name;
  void (*init)(...);
  const char *(*bfd_name)(...);
  unsigned local_labels_fb : 1;
  unsigned local_labels_dollar : 1;
  unsigned leading_underscore : 2;
  unsigned strip_underscore : 1;
  unsigned default_endian : 2;
  const char *fake_label_name;
  const struct n64_tag_format_ops *format;
};

extern struct n64_tag_emulation *this_emulation;

extern const char *default_emul_bfd_name(void) asm("_default_emul_bfd_name");
extern void common_emul_init(void) asm("_common_emul_init");

void listing_eject (int) asm("_listing_eject");
void listing_error (const char *message) asm("_listing_error");
void listing_file (const char *name) asm("_listing_file");
void listing_flags (int) asm("_listing_flags");
void listing_list (int on) asm("_listing_list");
void listing_newline (char *ps) asm("_listing_newline");
void listing_prev_line (void) asm("_listing_prev_line");
void listing_print (char *name) asm("_listing_print");
void listing_psize (int) asm("_listing_psize");
void listing_nopage (int) asm("_listing_nopage");
void listing_source_file (const char *) asm("_listing_source_file");
void listing_source_line (unsigned int) asm("_listing_source_line");
void listing_title (int depth) asm("_listing_title");
void listing_warning (const char *message) asm("_listing_warning");
void listing_width (unsigned int x) asm("_listing_width");

struct n64_tag_frchain
{
  struct n64_tag_frag *frch_root;
  struct n64_tag_frag *frch_last;
  struct n64_tag_frchain *frch_next;
  segT frch_seg;
  subsegT frch_subseg;

  fixS *fix_root;
  fixS *fix_tail;

  struct n64_tag_obstack frch_obstack;
  fragS *frch_frag_now;
};

typedef struct n64_tag_frchain frchainS;


extern frchainS *frchain_root;



extern frchainS *frchain_now;


typedef struct
{
  frchainS *frchainP;
  int hadone : 1;






  int bss : 1;

  int user_stuff;



  fixS *fix_root;
  fixS *fix_tail;




  symbolS *dot;

  struct lineno_list *lineno_list_head;
  struct lineno_list *lineno_list_tail;



  asection *bfd_section;



  symbolS *sym;


  union
    {

      unsigned long stab_string_size;

      char *p;
    }
  stabu;




} segment_info_type;



extern segment_info_type *seg_info (segT) asm("_seg_info");
extern symbolS *section_symbol (segT) asm("_section_symbol");


frchainS *frchain_root, *frchain_now;

static struct n64_tag_obstack frchains;
static segment_info_type *abs_seg_info;
static segment_info_type *und_seg_info;



static void subseg_set_rest (segT, subsegT) asm("_subseg_set_rest");

static fragS dummy_frag;

static frchainS absolute_frchain;

void
subsegs_begin(void) asm("_subsegs_begin");
void
subsegs_begin(void)
{
  _obstack_begin ((&frchains), (chunksize), 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);

  ((&frchains)->alignment_mask) = __alignof__ (frchainS) - 1;


  frchain_root = 
                ((void *)0)
                    ;
  frchain_now = 
               ((void *)0)
                   ;

  frag_now = &dummy_frag;
  absolute_frchain.frch_seg = ((asection *) &bfd_abs_section);
  absolute_frchain.frch_subseg = 0;

  absolute_frchain.fix_root = absolute_frchain.fix_tail = 0;

  absolute_frchain.frch_frag_now = &zero_address_frag;
  absolute_frchain.frch_root = absolute_frchain.frch_last = &zero_address_frag;
}
void
subseg_change(register segT seg, register int subseg) asm("_subseg_change");
void
subseg_change(register segT seg, register int subseg)
{
  now_seg = seg;
  now_subseg = subseg;

  if (now_seg == ((asection *) &bfd_abs_section))
    return;


  {
    segment_info_type *seginfo;
    seginfo = (segment_info_type *) ((seg)->userdata);
    if (! seginfo)
      {
 seginfo = (segment_info_type *) xmalloc (sizeof (*seginfo));
 memset ((void *) seginfo, 0, sizeof (*seginfo));
 seginfo->fix_root = 
                    ((void *)0)
                        ;
 seginfo->fix_tail = 
                    ((void *)0)
                        ;
 seginfo->bfd_section = seg;
 seginfo->sym = 0;
 if (seg == ((asection *) &bfd_abs_section))
   abs_seg_info = seginfo;
 else if (seg == ((asection *) &bfd_und_section))
   und_seg_info = seginfo;
 else
   (((seg)->userdata = ((void *) seginfo)),cxx_true);
      }
  }
}

static void
subseg_set_rest(segT seg, subsegT subseg) asm("_subseg_set_rest");
static void
subseg_set_rest(segT seg, subsegT subseg)
{
  long tmp;
  register frchainS *frcP;
  register frchainS **lastPP;
  frchainS *newP;
  register fragS *former_last_fragP;
  register fragS *new_fragP;

  mri_common_symbol = 
                     ((void *)0)
                         ;

  if (frag_now && frchain_now)
    frchain_now->frch_frag_now = frag_now;

  ((frchain_now == 0 || now_seg == ((asection *) &bfd_und_section) || now_seg == ((asection *) &bfd_abs_section) || frchain_now->frch_last == frag_now) ? 0 : (as_assert ("subsegs.c", 220, ((char*)0)), 0))


                                         ;

  subseg_change (seg, (int) subseg);

  if (seg == ((asection *) &bfd_abs_section))
    {
      frchain_now = &absolute_frchain;
      frag_now = &zero_address_frag;
      return;
    }

  ((frchain_now == 0 || now_seg == ((asection *) &bfd_und_section) || frchain_now->frch_last == frag_now) ? 0 : (as_assert ("subsegs.c", 234, ((char*)0)), 0))

                                         ;







  for (frcP = *(lastPP = &frchain_root);
       frcP && frcP->frch_seg <= seg;
       frcP = *(lastPP = &frcP->frch_next))
    {
      if (frcP->frch_seg == seg
   && frcP->frch_subseg >= subseg)
 {
   break;
 }
    }
  if (!frcP
      || (frcP->frch_seg > seg
   || frcP->frch_subseg > subseg))
    {



      extern fragS *frag_alloc(...) asm("_frag_alloc");
      newP = (frchainS *) __extension__ ({ struct n64_tag_obstack *__h = (&frchains); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (frchainS))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
      newP->frch_subseg = subseg;
      newP->frch_seg = seg;

      newP->fix_root = 
                      ((void *)0)
                          ;
      newP->fix_tail = 
                      ((void *)0)
                          ;

      _obstack_begin ((&newP->frch_obstack), (5000), 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);

      ((&newP->frch_obstack)->alignment_mask) = __alignof__ (fragS) - 1;

      newP->frch_frag_now = frag_alloc (&newP->frch_obstack);
      newP->frch_frag_now->fr_type = rs_fill;

      newP->frch_root = newP->frch_last = newP->frch_frag_now;

      *lastPP = newP;
      newP->frch_next = frcP;
      frcP = newP;
    }



  frchain_now = frcP;
  frag_now = frcP->frch_frag_now;

  ((frchain_now->frch_last == frag_now) ? 0 : (as_assert ("subsegs.c", 309, ((char*)0)), 0));
}
segT
subseg_get(const char *segname, int force_new) asm("_subseg_get");
segT
subseg_get(const char *segname, int force_new)
{
  segT secptr;
  segment_info_type *seginfo;
  const char *now_seg_name = (now_seg
         ? ((now_seg)->name + 0)
         : 0);

  if (!force_new
      && now_seg_name
      && (now_seg_name == segname
   || !strcmp (now_seg_name, segname)))
    return now_seg;

  if (!force_new)
    secptr = bfd_make_section_old_way (stdoutput, segname);
  else
    secptr = bfd_make_section_anyway (stdoutput, segname);

  seginfo = seg_info (secptr);
  if (! seginfo)
    {


      if (secptr->output_section != secptr)
 secptr->output_section = secptr;
      seginfo = (segment_info_type *) xmalloc (sizeof (*seginfo));
      memset ((void *) seginfo, 0, sizeof (*seginfo));
      seginfo->fix_root = 
                         ((void *)0)
                             ;
      seginfo->fix_tail = 
                         ((void *)0)
                             ;
      seginfo->bfd_section = secptr;
      if (secptr == ((asection *) &bfd_abs_section))
 abs_seg_info = seginfo;
      else if (secptr == ((asection *) &bfd_und_section))
 und_seg_info = seginfo;
      else
 (((secptr)->userdata = ((void *) seginfo)),cxx_true);
      seginfo->frchainP = 
                         ((void *)0)
                             ;
      seginfo->lineno_list_head = seginfo->lineno_list_tail = 
                                                             ((void *)0)
                                                                 ;
      seginfo->sym = 
                    ((void *)0)
                        ;
      seginfo->dot = 
                    ((void *)0)
                        ;
    }
  return secptr;
}

segT
subseg_new(const char *segname, subsegT subseg) asm("_subseg_new");
segT
subseg_new(const char *segname, subsegT subseg)
{
  segT secptr;
  segment_info_type *seginfo;

  secptr = subseg_get (segname, 0);
  subseg_set_rest (secptr, subseg);
  seginfo = seg_info (secptr);
  if (! seginfo->frchainP)
    seginfo->frchainP = frchain_now;
  return secptr;
}



segT
subseg_force_new(const char *segname, subsegT subseg) asm("_subseg_force_new");
segT
subseg_force_new(const char *segname, subsegT subseg)
{
  segT secptr;
  segment_info_type *seginfo;

  secptr = subseg_get (segname, 1);
  subseg_set_rest (secptr, subseg);
  seginfo = seg_info (secptr);
  if (! seginfo->frchainP)
    seginfo->frchainP = frchain_now;
  return secptr;
}

void
subseg_set(segT secptr, subsegT subseg) asm("_subseg_set");
void
subseg_set(segT secptr, subsegT subseg)
{
  if (! (secptr == now_seg && subseg == now_subseg))
    subseg_set_rest (secptr, subseg);
  mri_common_symbol = 
                     ((void *)0)
                         ;
}







segment_info_type *
seg_info(segT sec) asm("_seg_info");
segment_info_type *
seg_info(segT sec)
{
  if (sec == ((asection *) &bfd_abs_section))
    return abs_seg_info;
  else if (sec == ((asection *) &bfd_und_section))
    return und_seg_info;
  else
    return (segment_info_type *) ((sec)->userdata);
}

symbolS *
section_symbol(segT sec) asm("_section_symbol");
symbolS *
section_symbol(segT sec)
{
  segment_info_type *seginfo = seg_info (sec);
  symbolS *s;

  if (seginfo == 0)
    as_abort ("subsegs.c", 513, ((char*)0));
  if (seginfo->sym)
    return seginfo->sym;
  s = symbol_find (sec->name);
  if (!s)
    {




      if (! 1

   && symbol_table_frozen

   )

 s = symbol_create (sec->name, sec, 0, &zero_address_frag);
      else
 s = symbol_new (sec->name, sec, 0, &zero_address_frag);
      S_CLEAR_EXTERNAL (s);


      if (((sec)->owner != 0))
 s->bsym = sec->symbol;
    }
  seginfo->sym = s;
  return s;
}

