// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <signal.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_signal_info;








extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");











extern void *malloc (size_t size) asm("_malloc");
extern void *memset (void *s, int c, size_t n) asm("_memset");
struct n64_tag_signal_info
{
  int value;
  const char *name;

  const char *msg;

};







static const struct n64_tag_signal_info signal_table[] =
{




  {
 2
 , "SIGINT", "Interrupt"},





  {
 4
 , "SIGILL", "Illegal instruction"},
  {
 22
 , "SIGABRT", "Aborted"},





  {
 8
 , "SIGFPE", "Arithmetic exception"},
  {
 11
 , "SIGSEGV", "Segmentation fault"},
  {
 15
 , "SIGTERM", "Terminated"},
  {0, 
 ((void *)0)
 , 
 ((void *)0)
 }
};




static const char **signal_names;
static int num_signal_names = 0;
static int sys_nsig;
static const char **sys_siglist;
static void
init_signal_tables(void) asm("_init_signal_tables");
static void
init_signal_tables(void)
{
  const struct n64_tag_signal_info *eip;
  int nbytes;




  if (num_signal_names == 0)
    {
      for (eip = signal_table; eip -> name != 
                                             ((void *)0)
                                                 ; eip++)
 {
   if (eip -> value >= num_signal_names)
     {
       num_signal_names = eip -> value + 1;
     }
 }
    }




  if (signal_names == 
                     ((void *)0)
                         )
    {
      nbytes = num_signal_names * sizeof (char *);
      if ((signal_names = (const char **) malloc (nbytes)) != 
                                                             ((void *)0)
                                                                 )
 {
   memset (signal_names, 0, nbytes);
   for (eip = signal_table; eip -> name != 
                                          ((void *)0)
                                              ; eip++)
     {
       signal_names[eip -> value] = eip -> name;
     }
 }
    }






  if (sys_siglist == 
                    ((void *)0)
                        )
    {
      nbytes = num_signal_names * sizeof (char *);
      if ((sys_siglist = (const char **) malloc (nbytes)) != 
                                                            ((void *)0)
                                                                )
 {
   memset (sys_siglist, 0, nbytes);
   sys_nsig = num_signal_names;
   for (eip = signal_table; eip -> name != 
                                          ((void *)0)
                                              ; eip++)
     {
       sys_siglist[eip -> value] = eip -> msg;
     }
 }
    }



}
int
signo_max(void) asm("_signo_max");
int
signo_max(void)
{
  int maxsize;

  if (signal_names == 
                     ((void *)0)
                         )
    {
      init_signal_tables ();
    }
  maxsize = ((sys_nsig) > (num_signal_names) ? (sys_nsig) : (num_signal_names));
  return (maxsize - 1);
}
const char *
strsignal(int signo) asm("_strsignal");
const char *
strsignal(int signo)
{
  const char *msg;
  static char buf[32];



  if (signal_names == 
                     ((void *)0)
                         )
    {
      init_signal_tables ();
    }



  if ((signo < 0) || (signo >= sys_nsig))
    {

      msg = 
           ((void *)0)
               ;
    }
  else if ((sys_siglist == 
                          ((void *)0)
                              ) || (sys_siglist[signo] == 
                                                          ((void *)0)
                                                              ))
    {

      sprintf (buf, "Signal %d", signo);
      msg = (const char *) buf;
    }
  else
    {

      msg = (const char *) sys_siglist[signo];
    }

  return (msg);
}
const char *
strsigno(int signo) asm("_strsigno");
const char *
strsigno(int signo)
{
  const char *name;
  static char buf[32];

  if (signal_names == 
                     ((void *)0)
                         )
    {
      init_signal_tables ();
    }

  if ((signo < 0) || (signo >= num_signal_names))
    {

      name = 
            ((void *)0)
                ;
    }
  else if ((signal_names == 
                           ((void *)0)
                               ) || (signal_names[signo] == 
                                                            ((void *)0)
                                                                ))
    {

      sprintf (buf, "Signal %d", signo);
      name = (const char *) buf;
    }
  else
    {

      name = signal_names[signo];
    }

  return (name);
}
int
strtosigno(const char *name) asm("_strtosigno");
int
strtosigno(const char *name)
{
  int signo = 0;

  if (name != 
             ((void *)0)
                 )
    {
      if (signal_names == 
                         ((void *)0)
                             )
 {
   init_signal_tables ();
 }
      for (signo = 0; signo < num_signal_names; signo++)
 {
   if ((signal_names[signo] != 
                              ((void *)0)
                                  ) &&
       (strcmp (name, signal_names[signo]) == 0))
     {
       break;
     }
 }
      if (signo == num_signal_names)
 {
   signo = 0;
 }
    }
  return (signo);
}
void
psignal(unsigned int signo, char *message) asm("_psignal");
void
psignal(unsigned int signo, char *message)
{
  if (signal_names == 
                     ((void *)0)
                         )
    {
      init_signal_tables ();
    }
  if ((signo <= 0) || (signo >= sys_nsig))
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: unknown signal\n", message);
    }
  else
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: %s\n", message, sys_siglist[signo]);
    }
}

