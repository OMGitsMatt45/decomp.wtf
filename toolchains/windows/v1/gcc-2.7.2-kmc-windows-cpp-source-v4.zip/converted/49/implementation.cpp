// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/reorg.c
/* Perform instruction reorganizations for delay slot filling.
   Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by Richard Kenner (kenner@vlsi1.ultra.nyu.edu).
   Hacked by Michael Tiemann (tiemann@cygnus.com).

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int set_new_first_and_last_insn(...) asm("_set_new_first_and_last_insn");
extern int add_insn_after(...) asm("_add_insn_after");
extern int simplejump_p(...) asm("_simplejump_p");
extern int invert_jump(...) asm("_invert_jump");
extern int condjump_p(...) asm("_condjump_p");
extern int condjump_in_parallel_p(...) asm("_condjump_in_parallel_p");
extern int comparison_dominates_p(...) asm("_comparison_dominates_p");
extern int may_trap_p(...) asm("_may_trap_p");
extern int redirect_jump(...) asm("_redirect_jump");
extern int reg_referenced_p(...) asm("_reg_referenced_p");
extern int remove_note(...) asm("_remove_note");
extern int note_stores(...) asm("_note_stores");
extern int no_labels_between_p(...) asm("_no_labels_between_p");
extern int reg_set_p(...) asm("_reg_set_p");
extern int validate_replace_rtx(...) asm("_validate_replace_rtx");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int negate_rtx(...) asm("_negate_rtx");
extern int constrain_operands(...) asm("_constrain_operands");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int reposition_prologue_and_epilogue_notes(...) asm("_reposition_prologue_and_epilogue_notes");
struct n64_tag__obstack_chunk;
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_resources;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_target_info;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];
static struct n64_tag_obstack unfilled_slots_obstack;
static rtx *unfilled_firstobj;
struct n64_tag_resources
{
  char memory;
  char unch_memory;
  char volatil;
  char cc;
  HARD_REG_SET regs;
};







static struct n64_tag_resources start_of_epilogue_needs;


static struct n64_tag_resources end_of_function_needs;


static rtx end_of_function_label;






struct n64_tag_target_info
{
  int uid;
  struct n64_tag_target_info *next;
  HARD_REG_SET live_regs;
  int block;
  int bb_tick;
};




static struct n64_tag_target_info **target_hash_table;






static int *bb_ticks;



static int *uid_to_ruid;


static int max_uid;

static void mark_referenced_resources (rtx, struct n64_tag_resources *, int) asm("_mark_referenced_resources");
static void mark_set_resources (rtx, struct n64_tag_resources *, int, int) asm("_mark_set_resources");
static int stop_search_p (rtx, int) asm("_stop_search_p");
static int resource_conflicts_p (struct n64_tag_resources *, struct n64_tag_resources *) asm("_resource_conflicts_p")
                               ;
static int insn_references_resource_p (rtx, struct n64_tag_resources *, int) asm("_insn_references_resource_p");
static int insn_sets_resources_p (rtx, struct n64_tag_resources *, int) asm("_insn_sets_resources_p");
static rtx find_end_label (void) asm("_find_end_label");
static rtx emit_delay_sequence (rtx, rtx, int, int) asm("_emit_delay_sequence");
static rtx add_to_delay_list (rtx, rtx) asm("_add_to_delay_list");
static void delete_from_delay_slot (rtx) asm("_delete_from_delay_slot");
static void delete_scheduled_jump (rtx) asm("_delete_scheduled_jump");
static void note_delay_statistics (int, int) asm("_note_delay_statistics");
static rtx optimize_skip (rtx) asm("_optimize_skip");
static int get_jump_flags (rtx, rtx) asm("_get_jump_flags");
static int rare_destination (rtx) asm("_rare_destination");
static int mostly_true_jump (rtx, rtx) asm("_mostly_true_jump");
static rtx get_branch_condition (rtx, rtx) asm("_get_branch_condition");
static int condition_dominates_p (rtx, rtx) asm("_condition_dominates_p");
static rtx steal_delay_list_from_target (rtx, rtx, rtx, rtx, struct n64_tag_resources *, struct n64_tag_resources *, struct n64_tag_resources *, int, int *, int *, rtx *) asm("_steal_delay_list_from_target")



                                      ;
static rtx steal_delay_list_from_fallthrough (rtx, rtx, rtx, rtx, struct n64_tag_resources *, struct n64_tag_resources *, struct n64_tag_resources *, int, int *, int *) asm("_steal_delay_list_from_fallthrough")



                             ;
static void try_merge_delay_insns (rtx, rtx) asm("_try_merge_delay_insns");
static rtx redundant_insn (rtx, rtx, rtx) asm("_redundant_insn");
static int own_thread_p (rtx, rtx, int) asm("_own_thread_p");
static int find_basic_block (rtx) asm("_find_basic_block");
static void update_block (rtx, rtx) asm("_update_block");
static int reorg_redirect_jump (rtx, rtx) asm("_reorg_redirect_jump");
static void update_reg_dead_notes (rtx, rtx) asm("_update_reg_dead_notes");
static void update_reg_unused_notes (rtx, rtx) asm("_update_reg_unused_notes");
static void update_live_status (rtx, rtx) asm("_update_live_status");
static rtx next_insn_no_annul (rtx) asm("_next_insn_no_annul");
static void mark_target_live_regs (rtx, struct n64_tag_resources *) asm("_mark_target_live_regs");
static void fill_simple_delay_slots (rtx, int) asm("_fill_simple_delay_slots");
static rtx fill_slots_from_thread (rtx, rtx, rtx, rtx, int, int, int, int, int, int *) asm("_fill_slots_from_thread")
                            ;
static void fill_eager_delay_slots (rtx) asm("_fill_eager_delay_slots");
static void relax_delay_slots (rtx) asm("_relax_delay_slots");
static void make_return_insns (rtx) asm("_make_return_insns");
static int redirect_with_delay_slots_safe_p (rtx, rtx, rtx) asm("_redirect_with_delay_slots_safe_p");
static int redirect_with_delay_list_safe_p (rtx, rtx, rtx) asm("_redirect_with_delay_list_safe_p");






static void
mark_referenced_resources(register rtx x, register struct n64_tag_resources *res, register int include_delayed_effects) asm("_mark_referenced_resources");
static void
mark_referenced_resources(register rtx x, register struct n64_tag_resources *res, register int include_delayed_effects)
{
  register n64_enum_rtx_code code = ((x)->code);
  register int i, j;
  register char *format_ptr;



  switch (code)
    {
    case CONST:
    case CONST_INT:
    case CONST_DOUBLE:
    case PC:
    case SYMBOL_REF:
    case LABEL_REF:
      return;

    case SUBREG:
      if (((((x)->fld[0].rtx))->code) != REG)
 mark_referenced_resources (((x)->fld[0].rtx), res, 0);
      else
 {
   int regno = ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint);
   int last_regno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   for (i = regno; i < last_regno; i++)
     ((res->regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
 }
      return;

    case REG:
      for (i = 0; i < (! ((unsigned) ((((x)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))); i++)
 ((res->regs)[(((x)->fld[0].rtint) + i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((((x)->fld[0].rtint) + i) % ((unsigned) 32)));
      return;

    case MEM:


      if (((x)->unchanging))
 res->unch_memory = 1;
      else
 res->memory = 1;
      res->volatil = ((x)->volatil);


      mark_referenced_resources (((x)->fld[0].rtx), res, 0);
      return;

    case CC0:
      res->cc = 1;
      return;

    case UNSPEC_VOLATILE:
    case ASM_INPUT:

      res->volatil = 1;
      return;

    case ASM_OPERANDS:
      res->volatil = ((x)->volatil);






      for (i = 0; i < (((x))->fld[3].rtvec->num_elem); i++)
 mark_referenced_resources ((((x))->fld[3].rtvec->elem[(i)].rtx), res, 0);
      return;

    case CALL:


      mark_referenced_resources (((((x)->fld[0].rtx))->fld[0].rtx), res, 0);
      mark_referenced_resources (((x)->fld[1].rtx), res, 0);
      return;

    case SET:




      mark_referenced_resources (((x)->fld[1].rtx), res, 0);

      x = ((x)->fld[0].rtx);
      if (((x)->code) == SIGN_EXTRACT || ((x)->code) == ZERO_EXTRACT)
 mark_referenced_resources (x, res, 0);
      else if (((x)->code) == SUBREG)
 x = ((x)->fld[0].rtx);
      if (((x)->code) == MEM)
 mark_referenced_resources (((x)->fld[0].rtx), res, 0);
      return;

    case CLOBBER:
      return;

    case CALL_INSN:
      if (include_delayed_effects)
 {







   rtx insn = ((x)->fld[1].rtx);
   rtx sequence = 0;
   int seq_size = 0;
   rtx next = ((x)->fld[2].rtx);
   int i;


   if (((insn)->fld[2].rtx) != x)
     {
       next = ((((insn)->fld[2].rtx))->fld[2].rtx);
       sequence = ((((insn)->fld[2].rtx))->fld[3].rtx);
       seq_size = ((sequence)->fld[0].rtvec->num_elem);
       if (((sequence)->code) != SEQUENCE)
  abort ();
     }

   res->memory = 1;
   ((res->regs)[((0 + 29)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)));
   if (frame_pointer_needed)
     {
       ((res->regs)[((0 + 30)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 30)) % ((unsigned) 32)));



     }

   for (i = 0; i < 68; i++)
     if (global_regs[i])
       ((res->regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   if (next && ((next)->code) == NOTE
       && ((next)->fld[4].rtint) == -7)
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = -1; } while (0);

   {
     rtx link;

     for (link = ((x)->fld[7].rtx);
   link;
   link = ((link)->fld[1].rtx))
       if (((((link)->fld[0].rtx))->code) == USE)
  {
    for (i = 1; i < seq_size; i++)
      {
        rtx slot_pat = ((((sequence)->fld[0].rtvec->elem[i].rtx))->fld[3].rtx);
        if (((slot_pat)->code) == SET
     && rtx_equal_p (((slot_pat)->fld[0].rtx),
       ((((link)->fld[0].rtx))->fld[0].rtx)))
   break;
      }
    if (i >= seq_size)
      mark_referenced_resources (((((link)->fld[0].rtx))->fld[0].rtx),
            res, 0);
  }
   }
 }



    case INSN:
    case JUMP_INSN:
      mark_referenced_resources (((x)->fld[3].rtx), res, include_delayed_effects);
      return;
    }


  format_ptr = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    switch (*format_ptr++)
      {
      case 'e':
 mark_referenced_resources (((x)->fld[i].rtx), res, include_delayed_effects);
 break;

      case 'E':
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   mark_referenced_resources (((x)->fld[i].rtvec->elem[j].rtx), res,
         include_delayed_effects);
 break;
      }
}
static void
mark_set_resources(register rtx x, register struct n64_tag_resources *res, int in_dest, int include_delayed_effects) asm("_mark_set_resources");
static void
mark_set_resources(register rtx x, register struct n64_tag_resources *res, int in_dest, int include_delayed_effects)
{
  register n64_enum_rtx_code code;
  register int i, j;
  register char *format_ptr;

 restart:

  code = ((x)->code);

  switch (code)
    {
    case NOTE:
    case BARRIER:
    case CODE_LABEL:
    case USE:
    case CONST_INT:
    case CONST_DOUBLE:
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST:
    case PC:

      return;

    case CC0:
      if (in_dest)
 res->cc = 1;
      return;

    case CALL_INSN:




      if (include_delayed_effects)
 {
   rtx next = ((x)->fld[2].rtx);
   rtx prev = ((x)->fld[1].rtx);
   rtx link;

   res->cc = res->memory = 1;
   for (i = 0; i < 68; i++)
     if (call_used_regs[i] || global_regs[i])
       ((res->regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));



   if (((prev)->fld[2].rtx) != x)
     next = ((((prev)->fld[2].rtx))->fld[2].rtx);

   for (link = ((x)->fld[7].rtx);
        link; link = ((link)->fld[1].rtx))
     if (((((link)->fld[0].rtx))->code) == CLOBBER)
       mark_set_resources (((((link)->fld[0].rtx))->fld[0].rtx), res, 1, 0);



   if (next && ((next)->code) == NOTE
       && ((next)->fld[4].rtint) == -7)
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = -1; } while (0);
 }



    case JUMP_INSN:
    case INSN:
      x = ((x)->fld[3].rtx);
      if (((x)->code) != USE && ((x)->code) != CLOBBER)
 goto restart;
      return;

    case SET:




      mark_set_resources (((x)->fld[0].rtx), res,
     (include_delayed_effects
      || ((((x)->fld[1].rtx))->code) != CALL),
     0);

      mark_set_resources (((x)->fld[1].rtx), res, 0, 0);
      return;

    case CLOBBER:
      mark_set_resources (((x)->fld[0].rtx), res, 1, 0);
      return;

    case SEQUENCE:
      for (i = 0; i < ((x)->fld[0].rtvec->num_elem); i++)
 if (! (((((x)->fld[0].rtvec->elem[0].rtx))->unchanging)
        && ((((x)->fld[0].rtvec->elem[i].rtx))->in_struct)))
   mark_set_resources (((x)->fld[0].rtvec->elem[i].rtx), res, 0,
         include_delayed_effects);
      return;

    case POST_INC:
    case PRE_INC:
    case POST_DEC:
    case PRE_DEC:
      mark_set_resources (((x)->fld[0].rtx), res, 1, 0);
      return;

    case ZERO_EXTRACT:
      mark_set_resources (((x)->fld[0].rtx), res, in_dest, 0);
      mark_set_resources (((x)->fld[1].rtx), res, 0, 0);
      mark_set_resources (((x)->fld[2].rtx), res, 0, 0);
      return;

    case MEM:
      if (in_dest)
 {
   res->memory = 1;
   res->unch_memory = ((x)->unchanging);
   res->volatil = ((x)->volatil);
 }

      mark_set_resources (((x)->fld[0].rtx), res, 0, 0);
      return;

    case SUBREG:
      if (in_dest)
 {
   if (((((x)->fld[0].rtx))->code) != REG)
     mark_set_resources (((x)->fld[0].rtx), res,
    in_dest, include_delayed_effects);
   else
     {
       int regno = ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint);
       int last_regno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       for (i = regno; i < last_regno; i++)
  ((res->regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
     }
 }
      return;

    case REG:
      if (in_dest)
        for (i = 0; i < (! ((unsigned) ((((x)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))); i++)
   ((res->regs)[(((x)->fld[0].rtint) + i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((((x)->fld[0].rtint) + i) % ((unsigned) 32)));
      return;
    }


  format_ptr = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    switch (*format_ptr++)
      {
      case 'e':
 mark_set_resources (((x)->fld[i].rtx), res, in_dest, include_delayed_effects);
 break;

      case 'E':
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   mark_set_resources (((x)->fld[i].rtvec->elem[j].rtx), res, in_dest,
         include_delayed_effects);
 break;
      }
}





static int
stop_search_p(rtx insn, int labels_p) asm("_stop_search_p");
static int
stop_search_p(rtx insn, int labels_p)
{
  if (insn == 0)
    return 1;

  switch (((insn)->code))
    {
    case NOTE:
    case CALL_INSN:
      return 0;

    case CODE_LABEL:
      return labels_p;

    case JUMP_INSN:
    case BARRIER:
      return 1;

    case INSN:


      return (((((insn)->fld[3].rtx))->code) == SEQUENCE
       || ((((insn)->fld[3].rtx))->code) == ASM_INPUT
       || asm_noperands (((insn)->fld[3].rtx)) >= 0);

    default:
      abort ();
    }
}




static int
resource_conflicts_p(struct n64_tag_resources *res1, struct n64_tag_resources *res2) asm("_resource_conflicts_p");
static int
resource_conflicts_p(struct n64_tag_resources *res1, struct n64_tag_resources *res2)
{
  if ((res1->cc && res2->cc) || (res1->memory && res2->memory)
      || (res1->unch_memory && res2->unch_memory)
      || res1->volatil || res2->volatil)
    return 1;




  {
    int i;

    for (i = 0; i < ((68 + 32 - 1) / 32); i++)
      if ((res1->regs[i] & res2->regs[i]) != 0)
 return 1;
    return 0;
  }

}
static int
insn_references_resource_p(register rtx insn, register struct n64_tag_resources *res, int include_delayed_effects) asm("_insn_references_resource_p");
static int
insn_references_resource_p(register rtx insn, register struct n64_tag_resources *res, int include_delayed_effects)
{
  struct n64_tag_resources insn_res;

  do { (&insn_res)->memory = (&insn_res)->unch_memory = (&insn_res)->volatil = (&insn_res)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&insn_res)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  mark_referenced_resources (insn, &insn_res, include_delayed_effects);
  return resource_conflicts_p (&insn_res, res);
}






static int
insn_sets_resource_p(register rtx insn, register struct n64_tag_resources *res, int include_delayed_effects) asm("_insn_sets_resource_p");
static int
insn_sets_resource_p(register rtx insn, register struct n64_tag_resources *res, int include_delayed_effects)
{
  struct n64_tag_resources insn_sets;

  do { (&insn_sets)->memory = (&insn_sets)->unch_memory = (&insn_sets)->volatil = (&insn_sets)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&insn_sets)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  mark_set_resources (insn, &insn_sets, 0, include_delayed_effects);
  return resource_conflicts_p (&insn_sets, res);
}




static rtx
find_end_label(void) asm("_find_end_label");
static rtx
find_end_label(void)
{
  rtx insn;


  if (end_of_function_label)
    return end_of_function_label;





  insn = get_last_insn ();
  while (((insn)->code) == NOTE
  || (((insn)->code) == INSN
      && (((((insn)->fld[3].rtx))->code) == USE
   || ((((insn)->fld[3].rtx))->code) == CLOBBER)))
    insn = ((insn)->fld[1].rtx);




  if (((insn)->code) == BARRIER
      && ((((insn)->fld[1].rtx))->code) == JUMP_INSN
      && ((((((insn)->fld[1].rtx))->fld[3].rtx))->code) == RETURN)
    {
      rtx temp = ((((insn)->fld[1].rtx))->fld[1].rtx);
      end_of_function_label = gen_label_rtx ();
      ((end_of_function_label)->fld[5].rtint) = 0;


      while (((temp)->code) == USE)
 temp = ((temp)->fld[1].rtx);

      emit_label_after (end_of_function_label, temp);
    }

  else if (((insn)->code) == CODE_LABEL)
    end_of_function_label = insn;
  else
    {


      end_of_function_label = gen_label_rtx ();
      ((end_of_function_label)->fld[5].rtint) = 0;
      emit_label (end_of_function_label);

      if ((simple_epilogue_p ()))
 {

   rtx insn = gen_return ();
   insn = emit_jump_insn (insn);
   emit_barrier ();
          if (num_delay_slots (insn) > 0)
     __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)insn); __o->next_free += sizeof (void *); } (void) 0; });
 }

    }



  ++((end_of_function_label)->fld[5].rtint);

  return end_of_function_label;
}
static rtx
emit_delay_sequence(rtx insn, rtx list, int length, int avail) asm("_emit_delay_sequence");
static rtx
emit_delay_sequence(rtx insn, rtx list, int length, int avail)
{
  register int i = 1;
  register rtx li;
  int had_barrier = 0;


  rtvec seqv = rtvec_alloc (length + 1);
  rtx seq = gen_rtx (SEQUENCE, VOIDmode, seqv);
  rtx seq_insn = make_insn_raw (seq);
  rtx first = get_insns ();
  rtx last = get_last_insn ();


  rtx delay_insn = copy_rtx (insn);




  if (((insn)->fld[2].rtx) && ((((insn)->fld[2].rtx))->code) == BARRIER)
    {
      delete_insn (((insn)->fld[2].rtx));
      last = get_last_insn ();
      had_barrier = 1;
    }


  ((seq_insn)->fld[2].rtx) = ((insn)->fld[2].rtx);
  ((seq_insn)->fld[1].rtx) = ((insn)->fld[1].rtx);

  if (insn == last)
    set_new_first_and_last_insn (first, seq_insn);
  else
    ((((seq_insn)->fld[2].rtx))->fld[1].rtx) = seq_insn;

  if (insn == first)
    set_new_first_and_last_insn (seq_insn, last);
  else
    ((((seq_insn)->fld[1].rtx))->fld[2].rtx) = seq_insn;


  ((seq)->fld[0].rtvec->elem[0].rtx) = delay_insn;
  ((delay_insn)->volatil) = 0;
  ((delay_insn)->fld[1].rtx) = ((seq_insn)->fld[1].rtx);

  for (li = list; li; li = ((li)->fld[1].rtx), i++)
    {
      rtx tem = ((li)->fld[0].rtx);
      rtx note;


      ((tem)->volatil) = 0;

      ((seq)->fld[0].rtvec->elem[i].rtx) = tem;
      ((tem)->fld[1].rtx) = ((seq)->fld[0].rtvec->elem[i - 1].rtx);
      ((((seq)->fld[0].rtvec->elem[i - 1].rtx))->fld[2].rtx) = tem;



      for (note = ((tem)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
 if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD)
   ((note)->fld[0].rtx) = const0_rtx;
    }

  ((((seq)->fld[0].rtvec->elem[length].rtx))->fld[2].rtx) = ((seq_insn)->fld[2].rtx);





  if (((seq_insn)->fld[1].rtx) && ((((seq_insn)->fld[1].rtx))->code) == INSN
      && ((((((seq_insn)->fld[1].rtx))->fld[3].rtx))->code) == SEQUENCE)
    ((((((((seq_insn)->fld[1].rtx))->fld[3].rtx))->fld[0].rtvec->elem[((((((seq_insn)->fld[1].rtx))->fld[3].rtx))->fld[0].rtvec->num_elem) - 1].rtx))->fld[2].rtx)

      = seq_insn;

  if (((seq_insn)->fld[2].rtx) && ((((seq_insn)->fld[2].rtx))->code) == INSN
      && ((((((seq_insn)->fld[2].rtx))->fld[3].rtx))->code) == SEQUENCE)
    ((((((((seq_insn)->fld[2].rtx))->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx) = seq_insn;


  if (had_barrier)
    emit_barrier_after (seq_insn);

  if (i != length + 1)
    abort ();

  return seq_insn;
}




static rtx
add_to_delay_list(rtx insn, rtx delay_list) asm("_add_to_delay_list");
static rtx
add_to_delay_list(rtx insn, rtx delay_list)
{




  if (delay_list == 0)
    {
      struct n64_tag_target_info *tinfo;

      for (tinfo = target_hash_table[((insn)->fld[0].rtint) % 257];
    tinfo; tinfo = tinfo->next)
 if (tinfo->uid == ((insn)->fld[0].rtint))
   break;

      if (tinfo)
 tinfo->block = -1;

      return gen_rtx (INSN_LIST, VOIDmode, insn, (rtx) 0);
    }



  ((delay_list)->fld[1].rtx) = add_to_delay_list (insn, ((delay_list)->fld[1].rtx));

  return delay_list;
}




static void
delete_from_delay_slot(rtx insn) asm("_delete_from_delay_slot");
static void
delete_from_delay_slot(rtx insn)
{
  rtx trial, seq_insn, seq, prev;
  rtx delay_list = 0;
  int i;





  for (trial = insn;
       ((((trial)->fld[2].rtx))->fld[1].rtx) == trial;
       trial = ((trial)->fld[2].rtx))
    ;

  seq_insn = ((((trial)->fld[2].rtx))->fld[1].rtx);
  seq = ((seq_insn)->fld[3].rtx);



  if (((seq)->fld[0].rtvec->num_elem) > 2)
    for (i = 1; i < ((seq)->fld[0].rtvec->num_elem); i++)
      if (((seq)->fld[0].rtvec->elem[i].rtx) != insn)
 delay_list = add_to_delay_list (((seq)->fld[0].rtvec->elem[i].rtx), delay_list);



  prev = ((seq_insn)->fld[1].rtx);
  trial = ((seq)->fld[0].rtvec->elem[0].rtx);
  delete_insn (seq_insn);
  add_insn_after (trial, prev);

  if (((trial)->code) == JUMP_INSN
      && (simplejump_p (trial) || ((((trial)->fld[3].rtx))->code) == RETURN))
    emit_barrier_after (trial);



  if (delay_list)
    trial = emit_delay_sequence (trial, delay_list, ((seq)->fld[0].rtvec->num_elem) - 2, 0);
  else
    ((trial)->unchanging) = 0;

  ((insn)->in_struct) = 0;


  __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)trial); __o->next_free += sizeof (void *); } (void) 0; });
}




static void
delete_scheduled_jump(rtx insn) asm("_delete_scheduled_jump");
static void
delete_scheduled_jump(rtx insn)
{
  delete_insn (insn);
}







static int num_insns_needing_delays[2][2];

static int num_filled_delays[2][3 +1][2];

static int reorg_pass_number;

static void
note_delay_statistics(int slots_filled, int strchr) asm("_note_delay_statistics");
static void
note_delay_statistics(int slots_filled, int strchr)
{
  num_insns_needing_delays[strchr][reorg_pass_number]++;
  if (slots_filled > 3)
    slots_filled = 3;
  num_filled_delays[strchr][slots_filled][reorg_pass_number]++;
}
static rtx
optimize_skip(register rtx insn) asm("_optimize_skip");
static rtx
optimize_skip(register rtx insn)
{
  register rtx trial = next_nonnote_insn (insn);
  rtx next_trial = next_active_insn (trial);
  rtx delay_list = 0;
  rtx target_label;
  int flags;

  flags = get_jump_flags (insn, ((insn)->fld[7].rtx));

  if (trial == 0
      || ((trial)->code) != INSN
      || ((((trial)->fld[3].rtx))->code) == SEQUENCE
      || recog_memoized (trial) < 0
      || (! eligible_for_annul_false (insn, 0, trial, flags)
   && ! 0))
    return 0;







  if ((next_trial == next_active_insn (((insn)->fld[7].rtx)))
      || (next_trial != 0
   && ((next_trial)->code) == JUMP_INSN
   && ((insn)->fld[7].rtx) == ((next_trial)->fld[7].rtx)
   && (simplejump_p (next_trial)
       || ((((next_trial)->fld[3].rtx))->code) == RETURN)))
    {
      if (eligible_for_annul_false (insn, 0, trial, flags))
 {
   if (invert_jump (insn, ((insn)->fld[7].rtx)))
     ((trial)->in_struct) = 1;
   else if (! 0)
     return 0;
 }

      delay_list = add_to_delay_list (trial, (rtx) 0);
      next_trial = next_active_insn (trial);
      update_block (trial, trial);
      delete_insn (trial);





      if (next_trial && ((next_trial)->code) == JUMP_INSN
   && (simplejump_p (next_trial)
       || ((((next_trial)->fld[3].rtx))->code) == RETURN))
 {
   target_label = ((next_trial)->fld[7].rtx);
   if (target_label == 0)
     target_label = find_end_label ();





   flags = get_jump_flags (insn, target_label);
   if (0)
     reorg_redirect_jump (insn, target_label);
 }

      ((insn)->unchanging) = 1;
    }

  return delay_list;
}
static int
get_jump_flags(rtx insn, rtx label) asm("_get_jump_flags");
static int
get_jump_flags(rtx insn, rtx label)
{
  int flags;







  if (((insn)->code) == JUMP_INSN
      && (condjump_p (insn) || condjump_in_parallel_p (insn))
      && ((insn)->fld[0].rtint) <= max_uid
      && label != 0
      && ((label)->fld[0].rtint) <= max_uid)
    flags
      = (uid_to_ruid[((label)->fld[0].rtint)] > uid_to_ruid[((insn)->fld[0].rtint)])
  ? 0x1 : 0x2;

  else
    flags = 0;





  if (((insn)->code) == JUMP_INSN
      && (condjump_p (insn) || condjump_in_parallel_p (insn)))
    {
      int prediction;

      prediction = mostly_true_jump (insn, get_branch_condition (insn, label));
      switch (prediction)
 {
   case 2:
     flags |= (0x8 | 0x4);
     break;
   case 1:
     flags |= 0x4;
     break;
   case 0:
     flags |= 0x10;
     break;
   case -1:
     flags |= (0x20 | 0x10);
     break;

   default:
     abort();
 }
    }
  else
    flags |= (0x8 | 0x4);

  return flags;
}






static int
rare_destination(rtx insn) asm("_rare_destination");
static int
rare_destination(rtx insn)
{
  int jump_count = 0;
  rtx next;

  for (; insn; insn = next)
    {
      if (((insn)->code) == INSN && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
 insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);

      next = ((insn)->fld[2].rtx);

      switch (((insn)->code))
 {
 case CODE_LABEL:
   return 0;
 case BARRIER:




   return 2;
 case JUMP_INSN:
   if (((((insn)->fld[3].rtx))->code) == RETURN)
     return 1;
   else if (simplejump_p (insn)
     && jump_count++ < 10)
     next = ((insn)->fld[7].rtx);
   else
     return 0;
 }
    }




  return 1;
}
static int
mostly_true_jump(rtx jump_insn, rtx condition) asm("_mostly_true_jump");
static int
mostly_true_jump(rtx jump_insn, rtx condition)
{
  rtx target_label = ((jump_insn)->fld[7].rtx);
  rtx insn;
  int rare_dest = rare_destination (target_label);
  int rare_fallthrough = rare_destination (((jump_insn)->fld[2].rtx));


  if (((((jump_insn)->fld[3].rtx))->code) == SET
      && ((((((jump_insn)->fld[3].rtx))->fld[1].rtx))->code) == IF_THEN_ELSE
      && ((((((((((jump_insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF
    && ((((((((jump_insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->in_struct))
   || (((((((((jump_insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->code) == LABEL_REF
       && ((((((((jump_insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->in_struct))))
    return -1;

  if (target_label)
    {




      for (insn = ((target_label)->fld[1].rtx);
    insn && ((insn)->code) == NOTE;
    insn = ((insn)->fld[1].rtx))
 if (((insn)->fld[4].rtint) == -4)
   return 2;





      for (insn = ((target_label)->fld[2].rtx);
    insn && ((insn)->code) == NOTE;
    insn = ((insn)->fld[1].rtx))
 if (((insn)->fld[4].rtint) == -9)
   return 1;
    }




  switch (rare_fallthrough - rare_dest)
    {
    case -2:
      return -1;
    case -1:
      return 0;
    case 0:
      break;
    case 1:
      return 1;
    case 2:
      return 2;
    }



  if (condition == 0)
    return 0;




  switch (((condition)->code))
    {
    case CONST_INT:

      return 1;
    case EQ:
      return 0;
    case NE:
      return 1;
    case LE:
    case LT:
      if (((condition)->fld[1].rtx) == const0_rtx)
        return 0;
      break;
    case GE:
    case GT:
      if (((condition)->fld[1].rtx) == const0_rtx)
 return 1;
      break;
    }




  return (target_label == 0 || ((jump_insn)->fld[0].rtint) > max_uid
   || ((target_label)->fld[0].rtint) > max_uid
   || (uid_to_ruid[((jump_insn)->fld[0].rtint)]
       > uid_to_ruid[((target_label)->fld[0].rtint)]));;
}






static rtx
get_branch_condition(rtx insn, rtx target) asm("_get_branch_condition");
static rtx
get_branch_condition(rtx insn, rtx target)
{
  rtx pat = ((insn)->fld[3].rtx);
  rtx src;

  if (condjump_in_parallel_p (insn))
    pat = ((pat)->fld[0].rtvec->elem[0].rtx);

  if (((pat)->code) == RETURN)
    return target == 0 ? const_true_rtx : 0;

  else if (((pat)->code) != SET || ((pat)->fld[0].rtx) != pc_rtx)
    return 0;

  src = ((pat)->fld[1].rtx);
  if (((src)->code) == LABEL_REF && ((src)->fld[0].rtx) == target)
    return const_true_rtx;

  else if (((src)->code) == IF_THEN_ELSE
    && ((target == 0 && ((((src)->fld[1].rtx))->code) == RETURN)
        || (((((src)->fld[1].rtx))->code) == LABEL_REF
     && ((((src)->fld[1].rtx))->fld[0].rtx) == target))
    && ((src)->fld[2].rtx) == pc_rtx)
    return ((src)->fld[0].rtx);

  else if (((src)->code) == IF_THEN_ELSE
    && ((target == 0 && ((((src)->fld[2].rtx))->code) == RETURN)
        || (((((src)->fld[2].rtx))->code) == LABEL_REF
     && ((((src)->fld[2].rtx))->fld[0].rtx) == target))
    && ((src)->fld[1].rtx) == pc_rtx)
    return gen_rtx (reverse_condition (((((src)->fld[0].rtx))->code)),
      ((((src)->fld[0].rtx))->mode),
      ((((src)->fld[0].rtx))->fld[0].rtx), ((((src)->fld[0].rtx))->fld[1].rtx));

  return 0;
}




static int
condition_dominates_p(rtx condition, rtx insn) asm("_condition_dominates_p");
static int
condition_dominates_p(rtx condition, rtx insn)
{
  rtx other_condition = get_branch_condition (insn, ((insn)->fld[7].rtx));
  n64_enum_rtx_code code = ((condition)->code);
  n64_enum_rtx_code other_code;

  if (rtx_equal_p (condition, other_condition)
      || other_condition == const_true_rtx)
    return 1;

  else if (condition == const_true_rtx || other_condition == 0)
    return 0;

  other_code = ((other_condition)->code);
  if ((rtx_length[(int)(code)]) != 2 || (rtx_length[(int)(other_code)]) != 2
      || ! rtx_equal_p (((condition)->fld[0].rtx), ((other_condition)->fld[0].rtx))
      || ! rtx_equal_p (((condition)->fld[1].rtx), ((other_condition)->fld[1].rtx)))
    return 0;

  return comparison_dominates_p (code, other_code);
}




static int
redirect_with_delay_slots_safe_p(rtx jump, rtx newlabel, rtx seq) asm("_redirect_with_delay_slots_safe_p");
static int
redirect_with_delay_slots_safe_p(rtx jump, rtx newlabel, rtx seq)
{
  int flags, slots, i;
  rtx pat = ((seq)->fld[3].rtx);





  flags = get_jump_flags (jump, newlabel);
  for (i = 1; i < ((pat)->fld[0].rtvec->num_elem); i++)
    if (! (

    (((jump)->unchanging)
     && ((((pat)->fld[0].rtvec->elem[i].rtx))->in_struct))
    ? eligible_for_annul_false (jump, i - 1,
           ((pat)->fld[0].rtvec->elem[i].rtx), flags) :







    eligible_for_delay (jump, i -1, ((pat)->fld[0].rtvec->elem[i].rtx), flags)))
      break;

  return (i == ((pat)->fld[0].rtvec->num_elem));
}




static int
redirect_with_delay_list_safe_p(rtx jump, rtx newlabel, rtx delay_list) asm("_redirect_with_delay_list_safe_p");
static int
redirect_with_delay_list_safe_p(rtx jump, rtx newlabel, rtx delay_list)
{
  int flags, i;
  rtx li;





  flags = get_jump_flags (jump, newlabel);
  for (li = delay_list, i = 0; li; li = ((li)->fld[1].rtx), i++)
    if (! (

    (((jump)->unchanging)
     && ((((li)->fld[0].rtx))->in_struct))
    ? eligible_for_annul_false (jump, i, ((li)->fld[0].rtx), flags) :






    eligible_for_delay (jump, i, ((li)->fld[0].rtx), flags)))
      break;

  return (li == 
               ((void *)0)
                   );
}
static rtx
steal_delay_list_from_target(rtx insn, rtx condition, rtx seq, rtx delay_list, struct n64_tag_resources *sets, struct n64_tag_resources *needed, struct n64_tag_resources *other_needed, int slots_to_fill, int *pslots_filled, int *pannul_p, rtx *pnew_thread) asm("_steal_delay_list_from_target");
static rtx
steal_delay_list_from_target(rtx insn, rtx condition, rtx seq, rtx delay_list, struct n64_tag_resources *sets, struct n64_tag_resources *needed, struct n64_tag_resources *other_needed, int slots_to_fill, int *pslots_filled, int *pannul_p, rtx *pnew_thread)
{
  rtx temp;
  int slots_remaining = slots_to_fill - *pslots_filled;
  int total_slots_filled = *pslots_filled;
  rtx new_delay_list = 0;
  int must_annul = *pannul_p;
  int i;
  if (((seq)->fld[0].rtvec->num_elem) - 1 > slots_remaining
      || ! condition_dominates_p (condition, ((seq)->fld[0].rtvec->elem[0].rtx))
      || ! single_set (((seq)->fld[0].rtvec->elem[0].rtx)))
    return delay_list;

  for (i = 1; i < ((seq)->fld[0].rtvec->num_elem); i++)
    {
      rtx trial = ((seq)->fld[0].rtvec->elem[i].rtx);
      int flags;

      if (insn_references_resource_p (trial, sets, 0)
   || insn_sets_resource_p (trial, needed, 0)
   || insn_sets_resource_p (trial, sets, 0)







   || (((((seq)->fld[0].rtvec->elem[0].rtx))->unchanging)
       && ! ((trial)->in_struct)))
 return delay_list;



      if (redundant_insn (trial, insn, new_delay_list))
 continue;



      flags = get_jump_flags (insn, ((((seq)->fld[0].rtvec->elem[0].rtx))->fld[7].rtx));

      if (! must_annul
   && ((condition == const_true_rtx
        || (! insn_sets_resource_p (trial, other_needed, 0)
     && ! may_trap_p (((trial)->fld[3].rtx)))))
   ? eligible_for_delay (insn, total_slots_filled, trial, flags)
   : (must_annul = 1,
      eligible_for_annul_false (insn, total_slots_filled, trial, flags)))
 {
   temp = copy_rtx (trial);
   ((temp)->in_struct) = 1;
   new_delay_list = add_to_delay_list (temp, new_delay_list);
   total_slots_filled++;

   if (--slots_remaining == 0)
     break;
 }
      else
 return delay_list;
    }


  *pnew_thread = next_active_insn (((((seq)->fld[0].rtvec->elem[0].rtx))->fld[7].rtx));



  *pslots_filled = total_slots_filled;
  *pannul_p = must_annul;

  if (delay_list == 0)
    return new_delay_list;

  for (temp = new_delay_list; temp; temp = ((temp)->fld[1].rtx))
    delay_list = add_to_delay_list (((temp)->fld[0].rtx), delay_list);

  return delay_list;
}






static rtx
steal_delay_list_from_fallthrough(rtx insn, rtx condition, rtx seq, rtx delay_list, struct n64_tag_resources *sets, struct n64_tag_resources *needed, struct n64_tag_resources *other_needed, int slots_to_fill, int *pslots_filled, int *pannul_p) asm("_steal_delay_list_from_fallthrough");
static rtx
steal_delay_list_from_fallthrough(rtx insn, rtx condition, rtx seq, rtx delay_list, struct n64_tag_resources *sets, struct n64_tag_resources *needed, struct n64_tag_resources *other_needed, int slots_to_fill, int *pslots_filled, int *pannul_p)
{
  int i;
  int flags;

  flags = get_jump_flags (insn, ((insn)->fld[7].rtx));




  if (! simplejump_p (((seq)->fld[0].rtvec->elem[0].rtx))
      && ((((((seq)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->code) != RETURN)
    return delay_list;

  for (i = 1; i < ((seq)->fld[0].rtvec->num_elem); i++)
    {
      rtx trial = ((seq)->fld[0].rtvec->elem[i].rtx);



      if (insn_references_resource_p (trial, sets, 0)
   || insn_sets_resource_p (trial, needed, 0)
   || insn_sets_resource_p (trial, sets, 0)



   )

 break;


      if (redundant_insn (trial, insn, delay_list))
 {
   delete_from_delay_slot (trial);
   continue;
 }

      if (! *pannul_p
   && ((condition == const_true_rtx
        || (! insn_sets_resource_p (trial, other_needed, 0)
     && ! may_trap_p (((trial)->fld[3].rtx)))))
   ? eligible_for_delay (insn, *pslots_filled, trial, flags)
   : (*pannul_p = 1,
      0))
 {
   delete_from_delay_slot (trial);
   delay_list = add_to_delay_list (trial, delay_list);

   if (++(*pslots_filled) == slots_to_fill)
     break;
 }
      else
 break;
    }

  return delay_list;
}
static void
try_merge_delay_insns(rtx insn, rtx thread) asm("_try_merge_delay_insns");
static void
try_merge_delay_insns(rtx insn, rtx thread)
{
  rtx trial, next_trial;
  rtx delay_insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);
  int annul_p = ((delay_insn)->unchanging);
  int slot_number = 1;
  int num_slots = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem);
  rtx next_to_match = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[slot_number].rtx);
  struct n64_tag_resources set, needed;
  rtx merged_insns = 0;
  int i;
  int flags;

  flags = get_jump_flags (delay_insn, ((delay_insn)->fld[7].rtx));

  do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);







  if (! annul_p)
    mark_referenced_resources (next_to_match, &needed, 1);

  for (trial = thread; !stop_search_p (trial, 1); trial = next_trial)
    {
      rtx pat = ((trial)->fld[3].rtx);
      rtx oldtrial = trial;

      next_trial = next_nonnote_insn (trial);


      if (((trial)->code) == INSN
   && (((pat)->code) == USE || ((pat)->code) == CLOBBER))
 continue;

      if (((next_to_match)->code) == ((trial)->code)




   && ! insn_references_resource_p (trial, &set, 1)
   && ! insn_sets_resource_p (trial, &set, 1)
   && ! insn_sets_resource_p (trial, &needed, 1)
   && (trial = try_split (pat, trial, 0)) != 0

   && (next_trial = next_nonnote_insn (trial))

   && (thread = oldtrial == thread ? trial : thread)
   && rtx_equal_p (((next_to_match)->fld[3].rtx), ((trial)->fld[3].rtx))


   && eligible_for_delay (delay_insn, slot_number - 1, trial, flags))
 {

   if (! annul_p)
     {
       update_block (trial, thread);
       if (trial == thread)
  thread = next_active_insn (thread);

       delete_insn (trial);
       ((next_to_match)->in_struct) = 0;
     }
   else
     merged_insns = gen_rtx (INSN_LIST, VOIDmode, trial, merged_insns);

   if (++slot_number == num_slots)
     break;

   next_to_match = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[slot_number].rtx);
   if (! annul_p)
     mark_referenced_resources (next_to_match, &needed, 1);
 }

      mark_set_resources (trial, &set, 0, 1);
      mark_referenced_resources (trial, &needed, 1);
    }



  if (slot_number != num_slots
      && trial && ((trial)->code) == INSN
      && ((((trial)->fld[3].rtx))->code) == SEQUENCE
      && ! ((((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->unchanging))
    {
      rtx pat = ((trial)->fld[3].rtx);
      rtx filled_insn = ((pat)->fld[0].rtvec->elem[0].rtx);


      mark_set_resources (filled_insn, &set, 0, 1);
      mark_referenced_resources (filled_insn, &needed, 1);

      for (i = 1; i < ((pat)->fld[0].rtvec->num_elem); i++)
 {
   rtx dtrial = ((pat)->fld[0].rtvec->elem[i].rtx);

   if (! insn_references_resource_p (dtrial, &set, 1)
       && ! insn_sets_resource_p (dtrial, &set, 1)
       && ! insn_sets_resource_p (dtrial, &needed, 1)



       && rtx_equal_p (((next_to_match)->fld[3].rtx), ((dtrial)->fld[3].rtx))
       && eligible_for_delay (delay_insn, slot_number - 1, dtrial, flags))
     {
       if (! annul_p)
  {
    update_block (dtrial, thread);
    delete_from_delay_slot (dtrial);
    ((next_to_match)->in_struct) = 0;
  }
       else
  merged_insns = gen_rtx (INSN_LIST, SImode, dtrial,
     merged_insns);

       if (++slot_number == num_slots)
  break;

       next_to_match = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[slot_number].rtx);
     }
 }
    }






  if (slot_number == num_slots && annul_p)
    {
      for (; merged_insns; merged_insns = ((merged_insns)->fld[1].rtx))
 {
   if (((merged_insns)->mode) == SImode)
     {
       update_block (((merged_insns)->fld[0].rtx), thread);
       delete_from_delay_slot (((merged_insns)->fld[0].rtx));
     }
   else
     {
       update_block (((merged_insns)->fld[0].rtx), thread);
       delete_insn (((merged_insns)->fld[0].rtx));
     }
 }

      ((delay_insn)->unchanging) = 0;

      for (i = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
 ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->in_struct) = 0;
    }
}
static rtx
redundant_insn(rtx insn, rtx target, rtx delay_list) asm("_redundant_insn");
static rtx
redundant_insn(rtx insn, rtx target, rtx delay_list)
{
  rtx target_main = target;
  rtx ipat = ((insn)->fld[3].rtx);
  rtx trial, pat;
  struct n64_tag_resources needed, set;
  int i;


  for (trial = ((target)->fld[1].rtx); trial; trial = ((trial)->fld[1].rtx))
    {
      if (((trial)->code) == CODE_LABEL)
 return 0;

      if ((rtx_class[(int)(((trial)->code))]) != 'i')
 continue;

      pat = ((trial)->fld[3].rtx);
      if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
 continue;

      if (((pat)->code) == SEQUENCE)
 {


   if (((((pat)->fld[0].rtvec->elem[0].rtx))->code) == CALL_INSN)
     return 0;
   for (i = ((pat)->fld[0].rtvec->num_elem) - 1; i > 0; i--)
     if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) == ((insn)->code)
  && rtx_equal_p (((((pat)->fld[0].rtvec->elem[i].rtx))->fld[3].rtx), ipat))
       break;


   if (i > 0)
     break;
 }

      else if (((trial)->code) == ((insn)->code) && rtx_equal_p (pat, ipat))
 break;
    }


  if (trial == 0)
    return 0;




  do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  mark_set_resources (insn, &set, 0, 1);
  mark_referenced_resources (insn, &needed, 1);


  if (((target)->code) == INSN && ((((target)->fld[3].rtx))->code) == SEQUENCE)
    target_main = ((((target)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);

  if (resource_conflicts_p (&needed, &set)





      || insn_sets_resource_p (target_main, &needed, 1)
      || insn_sets_resource_p (target_main, &set, 1))
    return 0;



  needed.memory |= set.memory;
  needed.unch_memory |= set.unch_memory;
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (needed.regs), *scan_fp_ = (set.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);




  while (delay_list)
    {
      if (insn_sets_resource_p (((delay_list)->fld[0].rtx), &needed, 1))
 return 0;
      delay_list = ((delay_list)->fld[1].rtx);
    }

  if (((target)->code) == INSN && ((((target)->fld[3].rtx))->code) == SEQUENCE)
    for (i = 1; i < ((((target)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
      if (insn_sets_resource_p (((((target)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx), &needed, 1))
 return 0;




  for (trial = ((target)->fld[1].rtx);
       trial && ((trial)->code) != CODE_LABEL;
       trial = ((trial)->fld[1].rtx))
    {
      if (((trial)->code) != INSN && ((trial)->code) != CALL_INSN
   && ((trial)->code) != JUMP_INSN)
 continue;

      pat = ((trial)->fld[3].rtx);
      if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
 continue;

      if (((pat)->code) == SEQUENCE)
 {


   if (((((pat)->fld[0].rtvec->elem[0].rtx))->code) == CALL_INSN)
     return 0;
   for (i = ((pat)->fld[0].rtvec->num_elem) - 1; i > 0; i--)
     {
       rtx candidate = ((pat)->fld[0].rtvec->elem[i].rtx);



       if (rtx_equal_p (((candidate)->fld[3].rtx), ipat)
    && ! (((((pat)->fld[0].rtvec->elem[0].rtx))->unchanging)
   && ((candidate)->in_struct)))
  {

    ((candidate)->in_struct) = 0;
    return candidate;
  }



       if ((! ((((pat)->fld[0].rtvec->elem[0].rtx))->unchanging)
     || ! ((candidate)->in_struct))
    && insn_sets_resource_p (candidate, &needed, 1))
  return 0;
     }




   if (insn_sets_resource_p (((pat)->fld[0].rtvec->elem[0].rtx), &needed, 1))
     return 0;
 }
      else
 {

   pat = ((trial)->fld[3].rtx);
   if (rtx_equal_p (pat, ipat))
     return trial;


   if (insn_sets_resource_p (trial, &needed, 1))
     return 0;
 }
    }

  return 0;
}
static int
own_thread_p(rtx thread, rtx label, int allow_fallthrough) asm("_own_thread_p");
static int
own_thread_p(rtx thread, rtx label, int allow_fallthrough)
{
  rtx active_insn;
  rtx insn;


  if (thread == 0)
    return 0;


  active_insn = next_active_insn (((thread)->fld[1].rtx));

  for (insn = thread; insn != active_insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == CODE_LABEL
 && (insn != label || ((insn)->fld[5].rtint) != 1))
      return 0;

  if (allow_fallthrough)
    return 1;


  for (insn = prev_nonnote_insn (thread);
       insn == 0 || ((insn)->code) != BARRIER;
       insn = prev_nonnote_insn (insn))
    if (insn == 0
 || ((insn)->code) == CODE_LABEL
 || (((insn)->code) == INSN
     && ((((insn)->fld[3].rtx))->code) != USE
     && ((((insn)->fld[3].rtx))->code) != CLOBBER))
      return 0;

  return 1;
}




static int
find_basic_block(rtx insn) asm("_find_basic_block");
static int
find_basic_block(rtx insn)
{
  int i;




  for (insn = prev_nonnote_insn (insn);
       insn && ((insn)->code) != BARRIER;
       insn = prev_nonnote_insn (insn))
    ;


  if (insn == 0)
    return 0;



  for (insn = next_nonnote_insn (insn);
       insn && ((insn)->code) == CODE_LABEL;
       insn = next_nonnote_insn (insn))
    {
      for (i = 0; i < n_basic_blocks; i++)
 if (insn == basic_block_head[i])
   return i;
    }

  return -1;
}
static void
update_block(rtx insn, rtx where) asm("_update_block");
static void
update_block(rtx insn, rtx where)
{
  int b;



  if (((insn)->in_struct))
    return;

  emit_insn_before (gen_rtx (USE, VOIDmode, insn), where);




  b = find_basic_block (insn);
  if (b != -1)
    bb_ticks[b]++;
}




static int
reorg_redirect_jump(rtx jump, rtx nlabel) asm("_reorg_redirect_jump");
static int
reorg_redirect_jump(rtx jump, rtx nlabel)
{
  int b = find_basic_block (jump);

  if (b != -1)
    bb_ticks[b]++;

  return redirect_jump (jump, nlabel);
}
static void
update_reg_dead_notes(rtx insn, rtx delayed_insn) asm("_update_reg_dead_notes");
static void
update_reg_dead_notes(rtx insn, rtx delayed_insn)
{
  rtx p, link, next;

  for (p = next_nonnote_insn (insn); p != delayed_insn;
       p = next_nonnote_insn (p))
    for (link = ((p)->fld[6].rtx); link; link = next)
      {
 next = ((link)->fld[1].rtx);

 if (((n64_enum_reg_note) ((link)->mode)) != REG_DEAD
     || ((((link)->fld[0].rtx))->code) != REG)
   continue;

 if (reg_referenced_p (((link)->fld[0].rtx), ((insn)->fld[3].rtx)))
   {

     remove_note (p, link);
     ((link)->fld[1].rtx) = ((insn)->fld[6].rtx);
     ((insn)->fld[6].rtx) = link;
   }
      }
}
static void
update_reg_unused_notes(rtx insn, rtx redundant_insn) asm("_update_reg_unused_notes");
static void
update_reg_unused_notes(rtx insn, rtx redundant_insn)
{
  rtx p, link, next;

  for (link = ((insn)->fld[6].rtx); link; link = next)
    {
      next = ((link)->fld[1].rtx);

      if (((n64_enum_reg_note) ((link)->mode)) != REG_UNUSED
   || ((((link)->fld[0].rtx))->code) != REG)
 continue;

      if (! find_regno_note (redundant_insn, REG_UNUSED,
        ((((link)->fld[0].rtx))->fld[0].rtint)))
 remove_note (insn, link);
    }
}




static HARD_REG_SET current_live_regs;




static HARD_REG_SET pending_dead_regs;




static void
update_live_status(rtx dest, rtx x) asm("_update_live_status");
static void
update_live_status(rtx dest, rtx x)
{
  int first_regno, last_regno;
  int i;

  if (((dest)->code) != REG
      && (((dest)->code) != SUBREG || ((((dest)->fld[0].rtx))->code) != REG))
    return;

  if (((dest)->code) == SUBREG)
    first_regno = ((((dest)->fld[0].rtx))->fld[0].rtint) + ((dest)->fld[1].rtint);
  else
    first_regno = ((dest)->fld[0].rtint);

  last_regno = first_regno + (! ((unsigned) ((first_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

  if (((x)->code) == CLOBBER)
    for (i = first_regno; i < last_regno; i++)
      ((current_live_regs)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
  else
    for (i = first_regno; i < last_regno; i++)
      {
 ((current_live_regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
 ((pending_dead_regs)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
      }
}




static rtx
next_insn_no_annul(rtx insn) asm("_next_insn_no_annul");
static rtx
next_insn_no_annul(rtx insn)
{
  if (insn)
    {


      if (((insn)->unchanging)
   && ((((insn)->fld[1].rtx))->fld[2].rtx) != insn)
 while (((((insn)->fld[2].rtx))->in_struct))
   insn = ((insn)->fld[2].rtx);

      insn = ((insn)->fld[2].rtx);
      if (insn && ((insn)->code) == INSN
   && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
 insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);
    }

  return insn;
}
static void
mark_target_live_regs(rtx target, struct n64_tag_resources *res) asm("_mark_target_live_regs");
static void
mark_target_live_regs(rtx target, struct n64_tag_resources *res)
{
  int b = -1;
  int i;
  struct n64_tag_target_info *tinfo;
  rtx insn, next;
  rtx jump_insn = 0;
  rtx jump_target;
  HARD_REG_SET scratch;
  struct n64_tag_resources set, needed;
  int jump_count = 0;


  if (target == 0)
    {
      *res = end_of_function_needs;
      return;
    }


  res->memory = 1;
  res->volatil = res->unch_memory = 0;
  res->cc = 0;


  for (tinfo = target_hash_table[((target)->fld[0].rtint) % 257];
       tinfo; tinfo = tinfo->next)
    if (tinfo->uid == ((target)->fld[0].rtint))
      break;




  if (tinfo && tinfo->block != -1
      && ! ((basic_block_head[tinfo->block])->volatil))
    b = tinfo->block;

  if (b == -1)
    b = find_basic_block (target);

  if (tinfo)
    {


      if (b == tinfo->block && b != -1 && tinfo->bb_tick == bb_ticks[b])
 {
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs), *scan_fp_ = (tinfo->live_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
   return;
 }
    }
  else
    {


      tinfo = (struct n64_tag_target_info *) oballoc (sizeof (struct n64_tag_target_info));
      tinfo->uid = ((target)->fld[0].rtint);
      tinfo->block = b;
      tinfo->next = target_hash_table[((target)->fld[0].rtint) % 257];
      target_hash_table[((target)->fld[0].rtint) % 257] = tinfo;
    }

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (pending_dead_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);




  if (b != -1)
    {
      regset regs_live = basic_block_live_at_start[b];
      int offset, j;
      unsigned int bit;
      int regno;
      rtx start_insn, stop_insn;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (current_live_regs), *scan_fp_ = (regs_live); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);


      for (offset = 0, i = 0; offset < regset_size; offset++)
 {
   if (regs_live[offset] == 0)
     i += 32;
   else
     for (bit = 1; bit && i < max_regno; bit <<= 1, i++)
       if ((regs_live[offset] & bit)
    && (regno = reg_renumber[i]) >= 0)
  for (j = regno;
       j < regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                               ;
       j++)
    ((current_live_regs)[(j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)));
 }



      start_insn = (b == 0 ? get_insns () : basic_block_head[b]);
      stop_insn = target;

      if (((start_insn)->code) == INSN
   && ((((start_insn)->fld[3].rtx))->code) == SEQUENCE)
 start_insn = ((((start_insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);

      if (((stop_insn)->code) == INSN
   && ((((stop_insn)->fld[3].rtx))->code) == SEQUENCE)
 stop_insn = next_insn (((stop_insn)->fld[1].rtx));

      for (insn = start_insn; insn != stop_insn;
    insn = next_insn_no_annul (insn))
 {
   rtx link;
   rtx real_insn = insn;




   if (((insn)->in_struct))
     continue;



   if (((insn)->code) == INSN && ((((insn)->fld[3].rtx))->code) == USE
       && (rtx_class[(int)(((((((insn)->fld[3].rtx))->fld[0].rtx))->code))]) == 'i')
       real_insn = ((((insn)->fld[3].rtx))->fld[0].rtx);

   if (((real_insn)->code) == CALL_INSN)
     {



       for (i = 0; i < 68; i++)
  if (call_used_regs[i]
      && i != (0 + 29) && i != (0 + 30)
      && i != 0




      && ! (i == 0 && fixed_regs[i])


      && ! (i == (0 + 28) && flag_pic)

      )
    ((current_live_regs)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));



       for (i = 0; i < 68; i++)
  if (global_regs[i])
    ((current_live_regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
     }






   if ((((real_insn)->code) == INSN
        && ((((real_insn)->fld[3].rtx))->code) != USE
        && ((((real_insn)->fld[3].rtx))->code) != CLOBBER)
       || ((real_insn)->code) == JUMP_INSN
       || ((real_insn)->code) == CALL_INSN)
     {
       for (link = ((real_insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
  if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
      && ((((link)->fld[0].rtx))->code) == REG
      && ((((link)->fld[0].rtx))->fld[0].rtint) < 68)
    {
      int first_regno = ((((link)->fld[0].rtx))->fld[0].rtint);
      int last_regno
        = (first_regno
    + (! ((unsigned) ((first_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                    );

      for (i = first_regno; i < last_regno; i++)
        ((pending_dead_regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
    }

       note_stores (((real_insn)->fld[3].rtx), update_live_status);



       for (link = ((real_insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
  if (((n64_enum_reg_note) ((link)->mode)) == REG_UNUSED
      && ((((link)->fld[0].rtx))->code) == REG
      && ((((link)->fld[0].rtx))->fld[0].rtint) < 68)
    {
      int first_regno = ((((link)->fld[0].rtx))->fld[0].rtint);
      int last_regno
        = (first_regno
    + (! ((unsigned) ((first_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                    );

      for (i = first_regno; i < last_regno; i++)
        ((current_live_regs)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
    }
     }

   else if (((real_insn)->code) == CODE_LABEL)
     {


       do { register HARD_REG_ELT_TYPE *scan_tp_ = (current_live_regs), *scan_fp_ = (pending_dead_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
       do { register HARD_REG_ELT_TYPE *scan_tp_ = (pending_dead_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
     }




   else if (((real_insn)->code) == NOTE
      && ((real_insn)->fld[4].rtint) == -11)
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (current_live_regs), *scan_fp_ = (start_of_epilogue_needs.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
 }

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs), *scan_fp_ = (current_live_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
      tinfo->block = b;
      tinfo->bb_tick = bb_ticks[b];
    }
  else


    do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = -1; } while (0);






  do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);

  for (insn = target; insn; insn = next)
    {
      rtx this_jump_insn = insn;

      next = ((insn)->fld[2].rtx);
      switch (((insn)->code))
 {
 case CODE_LABEL:
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (pending_dead_regs), *scan_fp_ = (needed.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs), *scan_fp_ = (pending_dead_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (pending_dead_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
   continue;

 case BARRIER:
 case NOTE:
   continue;

 case INSN:
   if (((((insn)->fld[3].rtx))->code) == USE)
     {



       if ((rtx_class[(int)(((((((insn)->fld[3].rtx))->fld[0].rtx))->code))]) == 'i')
  mark_set_resources (((((insn)->fld[3].rtx))->fld[0].rtx), res, 0, 1);


       continue;
     }
   else if (((((insn)->fld[3].rtx))->code) == CLOBBER)
     continue;
   else if (((((insn)->fld[3].rtx))->code) == SEQUENCE)
     {


       for (i = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
  {
    this_jump_insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
    if (((this_jump_insn)->code) == JUMP_INSN)
      break;
  }
     }
 }

      if (((this_jump_insn)->code) == JUMP_INSN)
 {
   if (jump_count++ < 10
       && (simplejump_p (this_jump_insn)
    || ((((this_jump_insn)->fld[3].rtx))->code) == RETURN))
     {
       next = next_active_insn (((this_jump_insn)->fld[7].rtx));
       if (jump_insn == 0)
  {
    jump_insn = insn;
    jump_target = ((this_jump_insn)->fld[7].rtx);
  }
     }
   else
     break;
 }

      mark_referenced_resources (insn, &needed, 1);
      mark_set_resources (insn, &set, 0, 1);

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (scratch), *scan_fp_ = (set.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (scratch), *scan_fp_ = (needed.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs), *scan_fp_ = (scratch); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
    }
  if (jump_insn && jump_count < 10)
    {
      struct n64_tag_resources new_resources;
      rtx stop_insn = next_active_insn (jump_insn);

      mark_target_live_regs (next_active_insn (jump_target), &new_resources);
      do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
      do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);


      for (insn = target; insn != stop_insn; insn = next_active_insn (insn))
 {
   mark_referenced_resources (insn, &needed, 1);

   do { register HARD_REG_ELT_TYPE *scan_tp_ = (scratch), *scan_fp_ = (needed.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (scratch), *scan_fp_ = (set.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (new_resources.regs), *scan_fp_ = (scratch); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

   mark_set_resources (insn, &set, 0, 1);
 }

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (res->regs), *scan_fp_ = (new_resources.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= *scan_fp_++; } while (0);
    }

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (tinfo->live_regs), *scan_fp_ = (res->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
}
static void
fill_simple_delay_slots(rtx first, int non_jumps_p) asm("_fill_simple_delay_slots");
static void
fill_simple_delay_slots(rtx first, int non_jumps_p)
{
  register rtx insn, pat, trial, next_trial;
  register int i, j;
  int num_unfilled_slots = ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->next_free)) - ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base));
  struct n64_tag_resources needed, set;
  register int slots_to_fill, slots_filled;
  rtx delay_list;

  for (i = 0; i < num_unfilled_slots; i++)
    {
      int flags;



      insn = ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i];
      if (insn == 0
   || ((insn)->volatil)
   || (((insn)->code) == INSN
       && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
   || (((insn)->code) == JUMP_INSN && non_jumps_p)
   || (((insn)->code) != JUMP_INSN && ! non_jumps_p))
 continue;

      if (((insn)->code) == JUMP_INSN)
 flags = get_jump_flags (insn, ((insn)->fld[7].rtx));
      else
 flags = get_jump_flags (insn, (rtx) 0);
      slots_to_fill = num_delay_slots (insn);
      if (slots_to_fill == 0)
 abort ();
      slots_filled = 0;
      delay_list = 0;

      if ((trial = next_active_insn (insn))
   && ((trial)->code) == JUMP_INSN
   && simplejump_p (trial)
   && eligible_for_delay (insn, slots_filled, trial, flags)
   && no_labels_between_p (insn, trial))
 {
   rtx *tmp;
   slots_filled++;
   delay_list = add_to_delay_list (trial, delay_list);







   tmp = &((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i + 1];
   while (*tmp != trial && tmp != ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->next_free)))
     tmp++;



   if (*tmp == trial)
     *tmp = 0;
   {
     rtx next = ((trial)->fld[2].rtx);
     rtx prev = ((trial)->fld[1].rtx);
     if (prev)
       ((prev)->fld[2].rtx) = next;
     if (next)
       ((next)->fld[1].rtx) = prev;
   }
 }
      if (slots_filled < slots_to_fill)
 {
   do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
   do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
   mark_set_resources (insn, &set, 0, 0);
   mark_referenced_resources (insn, &needed, 0);

   for (trial = prev_nonnote_insn (insn); ! stop_search_p (trial, 1);
        trial = next_trial)
     {
       next_trial = prev_nonnote_insn (trial);


       pat = ((trial)->fld[3].rtx);


       if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
  continue;



       if (! insn_references_resource_p (trial, &set, 1)
    && ! insn_sets_resource_p (trial, &set, 1)
    && ! insn_sets_resource_p (trial, &needed, 1)





    )
  {
    trial = try_split (pat, trial, 1);
    next_trial = prev_nonnote_insn (trial);
    if (eligible_for_delay (insn, slots_filled, trial, flags))
      {





        update_reg_dead_notes (trial, insn);
        delay_list = gen_rtx (INSN_LIST, VOIDmode,
         trial, delay_list);
        update_block (trial, trial);
        delete_insn (trial);
        if (slots_to_fill == ++slots_filled)
   break;
        continue;
      }
  }

       mark_set_resources (trial, &set, 0, 1);
       mark_referenced_resources (trial, &needed, 1);
     }
 }





      if (slots_filled != slots_to_fill
   && delay_list == 0
   && ((insn)->code) == JUMP_INSN
   && (condjump_p (insn) || condjump_in_parallel_p (insn)))
 {
   delay_list = optimize_skip (insn);
   if (delay_list)
     slots_filled += 1;
 }
      if (slots_filled != slots_to_fill
          && (((insn)->code) != JUMP_INSN
       || ((condjump_p (insn) || condjump_in_parallel_p (insn))
     && ! simplejump_p (insn)
     && ((insn)->fld[7].rtx) != 0)))
 {
   rtx target = 0;
   int maybe_never = 0;
   struct n64_tag_resources needed_at_jump;

   do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
   do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);

   if (((insn)->code) == CALL_INSN)
     {
       mark_set_resources (insn, &set, 0, 1);
       mark_referenced_resources (insn, &needed, 1);
       maybe_never = 1;
     }
   else
     {
       mark_set_resources (insn, &set, 0, 1);
       mark_referenced_resources (insn, &needed, 1);
       if (((insn)->code) == JUMP_INSN)
  target = ((insn)->fld[7].rtx);
     }

   for (trial = next_nonnote_insn (insn); trial; trial = next_trial)
     {
       rtx pat, trial_delay;

       next_trial = next_nonnote_insn (trial);

       if (((trial)->code) == CODE_LABEL
    || ((trial)->code) == BARRIER)
  break;


       pat = ((trial)->fld[3].rtx);


       if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
  continue;



       if (((pat)->code) == SEQUENCE)
  trial_delay = ((pat)->fld[0].rtvec->elem[0].rtx);
       else
  trial_delay = trial;





       if (((trial_delay)->code) == JUMP_INSN)
  {
    if (target == 0)
      break;
    else if (((trial_delay)->fld[7].rtx) != target)
      {
        mark_target_live_regs
   (next_active_insn (((trial_delay)->fld[7].rtx)),
    &needed_at_jump);
        needed.memory |= needed_at_jump.memory;
        needed.unch_memory |= needed_at_jump.unch_memory;
        do { register HARD_REG_ELT_TYPE *scan_tp_ = (needed.regs), *scan_fp_ = (needed_at_jump.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
      }
  }



       if (target == 0
    && ((pat)->code) != SEQUENCE
    && ! insn_references_resource_p (trial, &set, 1)
    && ! insn_sets_resource_p (trial, &set, 1)
    && ! insn_sets_resource_p (trial, &needed, 1)



    && ! (maybe_never && may_trap_p (pat))
    && (trial = try_split (pat, trial, 0))
    && eligible_for_delay (insn, slots_filled, trial, flags))
  {
    next_trial = next_nonnote_insn (trial);
    delay_list = add_to_delay_list (trial, delay_list);






    delete_insn (trial);
    if (slots_to_fill == ++slots_filled)
      break;
    continue;
  }

       mark_set_resources (trial, &set, 0, 1);
       mark_referenced_resources (trial, &needed, 1);




       set.cc = 1;


       if (((trial_delay)->code) == CALL_INSN
    || ((trial_delay)->code) == JUMP_INSN)
  maybe_never = 1;
     }






   if (slots_to_fill != slots_filled
       && trial
       && ((trial)->code) == JUMP_INSN
       && simplejump_p (trial)
       && (target == 0 || ((trial)->fld[7].rtx) == target)
       && (next_trial = next_active_insn (((trial)->fld[7].rtx))) != 0
       && ! (((next_trial)->code) == INSN
      && ((((next_trial)->fld[3].rtx))->code) == SEQUENCE)
       && ((next_trial)->code) != JUMP_INSN
       && ! insn_references_resource_p (next_trial, &set, 1)
       && ! insn_sets_resource_p (next_trial, &set, 1)
       && ! insn_sets_resource_p (next_trial, &needed, 1)



       && ! (maybe_never && may_trap_p (((next_trial)->fld[3].rtx)))
       && (next_trial = try_split (((next_trial)->fld[3].rtx), next_trial, 0))
       && eligible_for_delay (insn, slots_filled, next_trial, flags))
     {
       rtx new_label = next_active_insn (next_trial);

       if (new_label != 0)
  new_label = get_label_before (new_label);
       else
  new_label = find_end_label ();

       delay_list
  = add_to_delay_list (copy_rtx (next_trial), delay_list);
       slots_filled++;
       reorg_redirect_jump (trial, new_label);



       if (target)
  reorg_redirect_jump (insn, new_label);
     }
 }

      if (delay_list)
 ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i]
   = emit_delay_sequence (insn, delay_list,
     slots_filled, slots_to_fill);

      if (slots_to_fill == slots_filled)
 ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i] = 0;

      note_delay_statistics (slots_filled, 0);
    }






  if (current_function_epilogue_delay_list)
    return;

  slots_to_fill = mips_epilogue_delay_slots ();
  if (slots_to_fill == 0)
    return;

  slots_filled = 0;
  do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);





  do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  if (frame_pointer_needed)
    {
      ((needed.regs)[((0 + 30)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 30)) % ((unsigned) 32)));




      if (! 1)

 ((needed.regs)[((0 + 29)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)));
    }
  else
    ((needed.regs)[((0 + 29)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)));

  for (trial = get_last_insn (); ! stop_search_p (trial, 1);
       trial = ((trial)->fld[1].rtx))
    {
      if (((trial)->code) == NOTE)
 continue;
      pat = ((trial)->fld[3].rtx);
      if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
 continue;

      if (! insn_references_resource_p (trial, &set, 1)
   && ! insn_sets_resource_p (trial, &needed, 1)
   && ! insn_sets_resource_p (trial, &set, 1)




   )
 {
   trial = try_split (pat, trial, 1);
   if ((get_attr_dslot (trial) == DSLOT_NO && get_attr_length (trial) == 1 && ! epilogue_reg_mentioned_p (((trial)->fld[3].rtx))))
     {



       current_function_epilogue_delay_list
  = gen_rtx (INSN_LIST, VOIDmode, trial,
      current_function_epilogue_delay_list);
       mark_referenced_resources (trial, &end_of_function_needs, 1);
       update_block (trial, trial);
       delete_insn (trial);


       ((trial)->volatil) = 0;

       if (slots_to_fill == ++slots_filled)
  break;
       continue;
     }
 }

      mark_set_resources (trial, &set, 0, 1);
      mark_referenced_resources (trial, &needed, 1);
    }

  note_delay_statistics (slots_filled, 0);

}
static rtx
fill_slots_from_thread(rtx insn, rtx condition, rtx thread, rtx opposite_thread, int likely, int thread_if_true, int own_thread, int own_opposite_thread, int slots_to_fill, int *pslots_filled) asm("_fill_slots_from_thread");
static rtx
fill_slots_from_thread(rtx insn, rtx condition, rtx thread, rtx opposite_thread, int likely, int thread_if_true, int own_thread, int own_opposite_thread, int slots_to_fill, int *pslots_filled)
{
  rtx new_thread;
  rtx delay_list = 0;
  struct n64_tag_resources opposite_needed, set, needed;
  rtx trial;
  int lose = 0;
  int must_annul = 0;
  int flags;


  if ((condition == const_true_rtx && ! thread_if_true)
      || (! own_thread && ! thread_if_true))
    abort ();

  flags = get_jump_flags (insn, ((insn)->fld[7].rtx));



  if (thread == 0)
    return 0;



  if (condition == const_true_rtx)
    do { (&opposite_needed)->memory = (&opposite_needed)->unch_memory = (&opposite_needed)->volatil = (&opposite_needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&opposite_needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  else
    mark_target_live_regs (opposite_thread, &opposite_needed);





  new_thread = thread = try_split (((thread)->fld[3].rtx), thread, 0);







  do { (&needed)->memory = (&needed)->unch_memory = (&needed)->volatil = (&needed)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&needed)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);
  do { (&set)->memory = (&set)->unch_memory = (&set)->volatil = (&set)->cc = 0; do { register HARD_REG_ELT_TYPE *scan_tp_ = ((&set)->regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0); } while (0);






  for (trial = thread;
       ! stop_search_p (trial, ! thread_if_true) && (! lose || own_thread);
       trial = next_nonnote_insn (trial))
    {
      rtx pat, old_trial;


      if (((trial)->code) == CODE_LABEL)
 {
   own_thread = 0;
   continue;
 }

      pat = ((trial)->fld[3].rtx);
      if (((pat)->code) == USE || ((pat)->code) == CLOBBER)
 continue;



      if (! insn_references_resource_p (trial, &set, 1)
   && ! insn_sets_resource_p (trial, &set, 1)
   && ! insn_sets_resource_p (trial, &needed, 1)




   )
 {
   rtx prior_insn;




   if (prior_insn = redundant_insn (trial, insn, delay_list))
     {
       if (own_thread)
  {
    update_block (trial, thread);
    if (trial == thread)
      {
        thread = next_active_insn (thread);
        if (new_thread == trial)
   new_thread = thread;
      }

    delete_insn (trial);
  }
       else
  {
    update_reg_unused_notes (prior_insn, trial);
    new_thread = next_active_insn (trial);
  }

       continue;
     }




   if (condition == const_true_rtx
       || (! insn_sets_resource_p (trial, &opposite_needed, 1)
    && ! may_trap_p (pat)))
     {
       old_trial = trial;
       trial = try_split (pat, trial, 0);
       if (new_thread == old_trial)
  new_thread = trial;
       if (thread == old_trial)
  thread = trial;
       pat = ((trial)->fld[3].rtx);
       if (eligible_for_delay (insn, *pslots_filled, trial, flags))
  goto winner;
     }
   else if (0




     || thread_if_true

     )
     {
       old_trial = trial;
       trial = try_split (pat, trial, 0);
       if (new_thread == old_trial)
  new_thread = trial;
       if (thread == old_trial)
  thread = trial;
       pat = ((trial)->fld[3].rtx);
       if ((thread_if_true
     ? eligible_for_annul_false (insn, *pslots_filled, trial, flags)
     : 0))
  {
    rtx temp;

    must_annul = 1;
  winner:
    if (own_thread)
      {
        update_block (trial, thread);
        delete_insn (trial);
      }
    else
      new_thread = next_active_insn (trial);

    temp = own_thread ? trial : copy_rtx (trial);
    if (thread_if_true)
      ((temp)->in_struct) = 1;

    delay_list = add_to_delay_list (temp, delay_list);

    if (slots_to_fill == ++(*pslots_filled))
      {



        while (new_thread && ! own_thread
        && ! insn_sets_resource_p (new_thread, &set, 1)
        && ! insn_sets_resource_p (new_thread, &needed, 1)
        && ! insn_references_resource_p (new_thread,
             &set, 1)
        && redundant_insn (new_thread, insn, delay_list))
   new_thread = next_active_insn (new_thread);
        break;
      }

    continue;
  }
     }
 }


      lose = 1;
      mark_set_resources (trial, &set, 0, 1);
      mark_referenced_resources (trial, &needed, 1);




      set.cc = 1;
      if (((trial)->code) == INSN && ((pat)->code) == SET
   && ((((pat)->fld[1].rtx))->code) == REG
   && ((((pat)->fld[0].rtx))->code) == REG)
 {
   rtx next = next_nonnote_insn (trial);

   if (next && ((next)->code) == INSN
       && ((((next)->fld[3].rtx))->code) != USE
       && ! reg_set_p (((pat)->fld[0].rtx), next)
       && ! reg_set_p (((pat)->fld[1].rtx), next)
       && reg_referenced_p (((pat)->fld[0].rtx), ((next)->fld[3].rtx)))
     validate_replace_rtx (((pat)->fld[0].rtx), ((pat)->fld[1].rtx), next);
 }
    }



  if (trial && ((trial)->code) == INSN
      && ((((trial)->fld[3].rtx))->code) == SEQUENCE
      && ((((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == JUMP_INSN)
    {


      if (thread_if_true && trial == new_thread)
 delay_list
   = steal_delay_list_from_target (insn, condition, ((trial)->fld[3].rtx),
       delay_list, &set, &needed,
       &opposite_needed, slots_to_fill,
       pslots_filled, &must_annul,
       &new_thread);
      else if (! thread_if_true)
 delay_list
   = steal_delay_list_from_fallthrough (insn, condition,
            ((trial)->fld[3].rtx),
            delay_list, &set, &needed,
            &opposite_needed, slots_to_fill,
            pslots_filled, &must_annul);
    }







  if (delay_list == 0 && likely && new_thread && ((new_thread)->code) == INSN)
    {
      rtx pat = ((new_thread)->fld[3].rtx);
      rtx dest;
      rtx src;

      trial = new_thread;
      pat = ((trial)->fld[3].rtx);

      if (((trial)->code) != INSN || ((pat)->code) != SET
   || ! eligible_for_delay (insn, 0, trial, flags))
 return 0;

      dest = ((pat)->fld[0].rtx), src = ((pat)->fld[1].rtx);
      if ((((src)->code) == PLUS || ((src)->code) == MINUS)
   && rtx_equal_p (((src)->fld[0].rtx), dest)
   && ! reg_overlap_mentioned_p (dest, ((src)->fld[1].rtx)))
 {
   rtx other = ((src)->fld[1].rtx);
   rtx new_arith;
   rtx ninsn;




   if (((other)->code) == CONST_INT)
     new_arith = gen_rtx (((src)->code), ((src)->mode), dest,
     negate_rtx (((src)->mode), other));
   else
     new_arith = gen_rtx (((src)->code) == PLUS ? MINUS : PLUS,
     ((src)->mode), dest, other);

   ninsn = emit_insn_after (gen_rtx (SET, VOIDmode, dest, new_arith),
       insn);

   if (recog_memoized (ninsn) < 0
       || (insn_extract (ninsn),
    ! constrain_operands (((ninsn)->fld[4].rtint), 1)))
     {
       delete_insn (ninsn);
       return 0;
     }

   if (own_thread)
     {
       update_block (trial, thread);
       delete_insn (trial);
     }
   else
     new_thread = next_active_insn (trial);

   ninsn = own_thread ? trial : copy_rtx (trial);
   if (thread_if_true)
     ((ninsn)->in_struct) = 1;

   delay_list = add_to_delay_list (ninsn, (rtx) 0);
   (*pslots_filled)++;
 }
    }

  if (delay_list && must_annul)
    ((insn)->unchanging) = 1;




  if (new_thread != thread)
    {
      rtx label;

      if (! thread_if_true)
 abort ();

      if (new_thread && ((new_thread)->code) == JUMP_INSN
   && (simplejump_p (new_thread)
       || ((((new_thread)->fld[3].rtx))->code) == RETURN)
   && redirect_with_delay_list_safe_p (insn,
           ((new_thread)->fld[7].rtx),
           delay_list))
 new_thread = follow_jumps (((new_thread)->fld[7].rtx));

      if (new_thread == 0)
 label = find_end_label ();
      else if (((new_thread)->code) == CODE_LABEL)
 label = new_thread;
      else
 label = get_label_before (new_thread);

      reorg_redirect_jump (insn, label);
    }

  return delay_list;
}
static void
fill_eager_delay_slots(rtx first) asm("_fill_eager_delay_slots");
static void
fill_eager_delay_slots(rtx first)
{
  register rtx insn;
  register int i;
  int num_unfilled_slots = ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->next_free)) - ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base));

  for (i = 0; i < num_unfilled_slots; i++)
    {
      rtx condition;
      rtx target_label, insn_at_target, fallthrough_insn;
      rtx delay_list = 0;
      int own_target;
      int own_fallthrough;
      int prediction, slots_to_fill, slots_filled;

      insn = ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i];
      if (insn == 0
   || ((insn)->volatil)
   || ((insn)->code) != JUMP_INSN
   || ! (condjump_p (insn) || condjump_in_parallel_p (insn)))
 continue;

      slots_to_fill = num_delay_slots (insn);
      if (slots_to_fill == 0)
 abort ();

      slots_filled = 0;
      target_label = ((insn)->fld[7].rtx);
      condition = get_branch_condition (insn, target_label);

      if (condition == 0)
 continue;





      insn_at_target = next_active_insn (target_label);
      own_target = own_thread_p (target_label, target_label, 0);

      if (condition == const_true_rtx)
 {
   own_fallthrough = 0;
   fallthrough_insn = 0;
   prediction = 2;
 }
      else
 {
   fallthrough_insn = next_active_insn (insn);
   own_fallthrough = own_thread_p (((insn)->fld[2].rtx), (rtx) 0, 1);
   prediction = mostly_true_jump (insn, condition);
 }





      if (prediction > 0)
 {
   delay_list
     = fill_slots_from_thread (insn, condition, insn_at_target,
          fallthrough_insn, prediction == 2, 1,
          own_target, own_fallthrough,
          slots_to_fill, &slots_filled);

   if (delay_list == 0 && own_fallthrough)
     {




       target_label = ((insn)->fld[7].rtx);
       insn_at_target = next_active_insn (target_label);

       delay_list
  = fill_slots_from_thread (insn, condition, fallthrough_insn,
       insn_at_target, 0, 0,
       own_fallthrough, own_target,
       slots_to_fill, &slots_filled);
     }
 }
      else
 {
   if (own_fallthrough)
     delay_list
       = fill_slots_from_thread (insn, condition, fallthrough_insn,
     insn_at_target, 0, 0,
     own_fallthrough, own_target,
     slots_to_fill, &slots_filled);

   if (delay_list == 0)
     delay_list
       = fill_slots_from_thread (insn, condition, insn_at_target,
     next_active_insn (insn), 0, 1,
     own_target, own_fallthrough,
     slots_to_fill, &slots_filled);
 }

      if (delay_list)
 ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i]
   = emit_delay_sequence (insn, delay_list,
     slots_filled, slots_to_fill);

      if (slots_to_fill == slots_filled)
 ((rtx *) ((&unfilled_slots_obstack)->alloc_failed ? 0 : (&unfilled_slots_obstack)->object_base))[i] = 0;

      note_delay_statistics (slots_filled, 1);
    }
}





static void
relax_delay_slots(rtx first) asm("_relax_delay_slots");
static void
relax_delay_slots(rtx first)
{
  register rtx insn, next, pat;
  register rtx trial, delay_insn, target_label;


  for (insn = first; insn; insn = next)
    {
      rtx other;

      next = next_active_insn (insn);




      if (((insn)->code) == JUMP_INSN
   && (condjump_p (insn) || condjump_in_parallel_p (insn))
   && (target_label = ((insn)->fld[7].rtx)) != 0)
 {
   target_label = follow_jumps (target_label);
   target_label = prev_label (next_active_insn (target_label));

   if (target_label == 0)
     target_label = find_end_label ();

   if (next_active_insn (target_label) == next
       && ! condjump_in_parallel_p (insn))
     {
       delete_jump (insn);
       continue;
     }

   if (target_label != ((insn)->fld[7].rtx))
     reorg_redirect_jump (insn, target_label);




   if (next && ((next)->code) == JUMP_INSN
       && (simplejump_p (next) || ((((next)->fld[3].rtx))->code) == RETURN)
       && next_active_insn (target_label) == next_active_insn (next)
       && no_labels_between_p (insn, next))
     {
       rtx label = ((next)->fld[7].rtx);
       ++((target_label)->fld[5].rtint);
       if (label)
  ++((label)->fld[5].rtint);

       if (invert_jump (insn, label))
  {
    delete_insn (next);
    next = insn;
  }

       if (label)
  --((label)->fld[5].rtint);

       if (--((target_label)->fld[5].rtint) == 0)
  delete_insn (target_label);

       continue;
     }
 }
      if (((insn)->code) == JUMP_INSN
   && (simplejump_p (insn) || ((((insn)->fld[3].rtx))->code) == RETURN)
   && (other = prev_active_insn (insn)) != 0
   && (condjump_p (other) || condjump_in_parallel_p (other))
   && no_labels_between_p (other, insn)
   && 0 < mostly_true_jump (other,
       get_branch_condition (other,
        ((other)->fld[7].rtx))))
 {
   rtx other_target = ((other)->fld[7].rtx);
   target_label = ((insn)->fld[7].rtx);



   if (other_target)
     ++((other_target)->fld[5].rtint);

   if (invert_jump (other, target_label))
     reorg_redirect_jump (insn, other_target);

   if (other_target)
     --((other_target)->fld[5].rtint);
 }


      if (((insn)->code) != INSN
   || ((((insn)->fld[3].rtx))->code) != SEQUENCE)
 continue;

      pat = ((insn)->fld[3].rtx);
      delay_insn = ((pat)->fld[0].rtvec->elem[0].rtx);




      if (redundant_insn (((pat)->fld[0].rtvec->elem[1].rtx), delay_insn, 0))
 {
   delete_from_delay_slot (((pat)->fld[0].rtvec->elem[1].rtx));
   next = prev_active_insn (next);
   continue;
 }


      if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) != JUMP_INSN
   || ! (condjump_p (((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))
  || condjump_in_parallel_p (((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))))
 continue;

      target_label = ((delay_insn)->fld[7].rtx);

      if (target_label)
 {


   trial = follow_jumps (target_label);





   trial = prev_label (next_real_insn (trial));
   if (trial == 0 && target_label != 0)
     trial = find_end_label ();

   if (trial != target_label
       && redirect_with_delay_slots_safe_p (delay_insn, trial, insn))
     {
       reorg_redirect_jump (delay_insn, trial);
       target_label = trial;
     }



   trial = next_active_insn (target_label);
   if (trial && ((((trial)->fld[3].rtx))->code) != SEQUENCE
       && redundant_insn (trial, insn, 0))
     {
       trial = next_active_insn (trial);
       if (trial == 0)
  target_label = find_end_label ();
       else
  target_label = get_label_before (trial);
       reorg_redirect_jump (delay_insn, target_label);
       next = insn;
       continue;
     }



   if (trial && ((((trial)->fld[3].rtx))->code) == SEQUENCE
       && ((((trial)->fld[3].rtx))->fld[0].rtvec->num_elem) == 2
       && ((((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == JUMP_INSN
       && (simplejump_p (((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))
    || ((((((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->code) == RETURN)
       && redundant_insn (((((trial)->fld[3].rtx))->fld[0].rtvec->elem[1].rtx), insn, 0))
     {
       target_label = ((((((trial)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[7].rtx);
       if (target_label == 0)
  target_label = find_end_label ();

       if (redirect_with_delay_slots_safe_p (delay_insn, target_label,
          insn))
  {
    reorg_redirect_jump (delay_insn, target_label);
    next = insn;
    continue;
  }
     }
 }

      if (! ((delay_insn)->unchanging)
   && prev_active_insn (target_label) == insn
   && ! condjump_in_parallel_p (delay_insn)
   )
 {
   int i;
   for (i = 0; i < ((pat)->fld[0].rtvec->num_elem); i++)
     ((((pat)->fld[0].rtvec->elem[i].rtx))->in_struct) = 0;

   trial = ((insn)->fld[1].rtx);
   delete_insn (insn);
   emit_insn_after (pat, trial);
   delete_scheduled_jump (delay_insn);
   continue;
 }




      if (next && ((next)->code) == INSN
   && prev_label (next_active_insn (next)) == target_label
   && simplejump_p (insn)
   && ((pat)->fld[0].rtvec->num_elem) == 2
   && rtx_equal_p (((next)->fld[3].rtx), ((((pat)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx)))
 {
   delete_insn (insn);
   continue;
 }






      if (! ((delay_insn)->unchanging)
   && next && ((next)->code) == JUMP_INSN
   && (simplejump_p (next) || ((((next)->fld[3].rtx))->code) == RETURN)
   && next_active_insn (target_label) == next_active_insn (next)
   && no_labels_between_p (insn, next))
 {
   rtx label = ((next)->fld[7].rtx);
   rtx old_label = ((delay_insn)->fld[7].rtx);

   if (label == 0)
     label = find_end_label ();

   if (redirect_with_delay_slots_safe_p (delay_insn, label, insn))
     {



       if (old_label)
  ++((old_label)->fld[5].rtint);

       if (invert_jump (delay_insn, label))
  {
    int i;




    for (i = 1; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
      {
        rtx slot = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
        ((slot)->in_struct) = ! ((slot)->in_struct);
      }

    delete_insn (next);
    next = insn;
  }

       if (old_label && --((old_label)->fld[5].rtint) == 0)
  delete_insn (old_label);
       continue;
     }
 }



      if (((((pat)->fld[0].rtvec->elem[1].rtx))->in_struct)
   && own_thread_p (((insn)->fld[2].rtx), 0, 1))
 try_merge_delay_insns (insn, next);
      else if (! ((((pat)->fld[0].rtvec->elem[1].rtx))->in_struct)
        && own_thread_p (target_label, target_label, 0))
 try_merge_delay_insns (insn, next_active_insn (target_label));



      next = next_active_insn (insn);
    }
}







static void
make_return_insns(rtx first) asm("_make_return_insns");
static void
make_return_insns(rtx first)
{
  rtx insn, jump_insn, pat;
  rtx real_return_label = end_of_function_label;
  int slots, i;




  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == JUMP_INSN && ((((insn)->fld[3].rtx))->code) == RETURN)
      {
 real_return_label = get_label_before (insn);
 break;
      }



  ((real_return_label)->fld[5].rtint)++;


  __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); void *__obj = (unfilled_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    {
      int flags;



      if (((insn)->code) != INSN
   || ((((insn)->fld[3].rtx))->code) != SEQUENCE
   || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) != JUMP_INSN
   || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[7].rtx) != end_of_function_label)
 continue;

      pat = ((insn)->fld[3].rtx);
      jump_insn = ((pat)->fld[0].rtvec->elem[0].rtx);



      if (! reorg_redirect_jump (jump_insn, (rtx) 0))
 {


   if (redirect_with_delay_slots_safe_p (jump_insn,
      real_return_label,
      insn))
     reorg_redirect_jump (jump_insn, real_return_label);
   continue;
 }





      flags = get_jump_flags (jump_insn, ((jump_insn)->fld[7].rtx));
      slots = num_delay_slots (jump_insn);
      if (slots >= ((pat)->fld[0].rtvec->num_elem) - 1)
 {
   for (i = 1; i < ((pat)->fld[0].rtvec->num_elem); i++)
     if (! (

     (((jump_insn)->unchanging)
      && ((((pat)->fld[0].rtvec->elem[i].rtx))->in_struct))
     ? eligible_for_annul_false (jump_insn, i - 1,
            ((pat)->fld[0].rtvec->elem[i].rtx), flags) :







     eligible_for_delay (jump_insn, i -1, ((pat)->fld[0].rtvec->elem[i].rtx), flags)))
       break;
 }
      else
 i = 0;

      if (i == ((pat)->fld[0].rtvec->num_elem))
 continue;





      if (((((jump_insn)->fld[3].rtx))->code) == RETURN)
 {
   rtx prev = ((insn)->fld[1].rtx);

   delete_insn (insn);
   for (i = 1; i < ((pat)->fld[0].rtvec->num_elem); i++)
     prev = emit_insn_after (((((pat)->fld[0].rtvec->elem[i].rtx))->fld[3].rtx), prev);

   insn = emit_jump_insn_after (((jump_insn)->fld[3].rtx), prev);
   emit_barrier_after (insn);

   if (slots)
     __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)insn); __o->next_free += sizeof (void *); } (void) 0; });
 }
      else


 reorg_redirect_jump (jump_insn, real_return_label);
    }



  if (--((real_return_label)->fld[5].rtint) == 0)
    delete_insn (real_return_label);

  fill_simple_delay_slots (first, 1);
  fill_simple_delay_slots (first, 0);
}




void
dbr_schedule(rtx first, FILE *file) asm("_dbr_schedule");
void
dbr_schedule(rtx first, FILE *file)
{
  rtx insn, next, epilogue_insn = 0;
  int i;
  if (n_basic_blocks == 0)
    return;



  for (max_uid = 0, insn = first; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->fld[0].rtint) > max_uid)
 max_uid = ((insn)->fld[0].rtint);
      if (((insn)->code) == NOTE
   && ((insn)->fld[4].rtint) == -11)
 epilogue_insn = insn;
    }

  uid_to_ruid = (int *) 
                       __builtin_alloca((
                       (max_uid + 1) * sizeof (int *)
                       ))
                                                              ;
  for (i = 0, insn = first; insn; i++, insn = ((insn)->fld[2].rtx))
    uid_to_ruid[((insn)->fld[0].rtint)] = i;


  if (unfilled_firstobj == 0)
    {
      gcc_obstack_init (&unfilled_slots_obstack);
      unfilled_firstobj = (rtx *) __extension__ ({ struct n64_tag_obstack *__h = (&unfilled_slots_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
    }

  for (insn = next_active_insn (first); insn; insn = next_active_insn (insn))
    {
      rtx target;

      ((insn)->unchanging) = 0;
      ((insn)->in_struct) = 0;


      if (((insn)->code) == JUMP_INSN
   && (((((insn)->fld[3].rtx))->code) == ADDR_VEC
       || ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC))
 continue;

      if (num_delay_slots (insn) > 0)
 __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)insn); __o->next_free += sizeof (void *); } (void) 0; });


      if (((insn)->code) == JUMP_INSN
   && (condjump_p (insn) || condjump_in_parallel_p (insn))
   && ((insn)->fld[7].rtx) != 0
   && ((target = prev_label (next_active_insn (((insn)->fld[7].rtx))))
       != ((insn)->fld[7].rtx)))
 redirect_jump (insn, target);
    }
  end_of_function_needs.cc = 0;
  end_of_function_needs.memory = 1;
  end_of_function_needs.unch_memory = 0;
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (end_of_function_needs.regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

  if (frame_pointer_needed)
    {
      ((end_of_function_needs.regs)[((0 + 30)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 30)) % ((unsigned) 32)));




      if (! 1)

 ((end_of_function_needs.regs)[((0 + 29)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)));
    }
  else
    ((end_of_function_needs.regs)[((0 + 29)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)));

  if (current_function_return_rtx != 0
      && ((current_function_return_rtx)->code) == REG)
    mark_referenced_resources (current_function_return_rtx,
          &end_of_function_needs, 1);

  for (i = 0; i < 68; i++)
    if (global_regs[i])
      ((end_of_function_needs.regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
  start_of_epilogue_needs = end_of_function_needs;

  while (epilogue_insn = next_nonnote_insn (epilogue_insn))
    mark_set_resources (epilogue_insn, &end_of_function_needs, 0, 1);


  end_of_function_label = 0;


  target_hash_table
    = (struct n64_tag_target_info **) 
                             __builtin_alloca((
                             (257 * sizeof (struct n64_tag_target_info *))
                             ))
                                            
                                           ;
  memset ((char *) target_hash_table,0,257 * sizeof (struct n64_tag_target_info *))
                                                    ;

  bb_ticks = (int *) 
                    __builtin_alloca((
                    n_basic_blocks * sizeof (int)
                    ))
                                                          ;
  memset ((char *) bb_ticks,0,n_basic_blocks * sizeof (int));


  memset ((char *) num_insns_needing_delays,0,sizeof num_insns_needing_delays);
  memset ((char *) num_filled_delays,0,sizeof num_filled_delays);




  for (reorg_pass_number = 0;
       reorg_pass_number < 2;
       reorg_pass_number++)
    {
      fill_simple_delay_slots (first, 1);
      fill_simple_delay_slots (first, 0);
      fill_eager_delay_slots (first);
      relax_delay_slots (first);
    }



  for (insn = first; insn; insn = next)
    {
      next = ((insn)->fld[2].rtx);

      if (((insn)->code) == INSN && ((((insn)->fld[3].rtx))->code) == USE
   && (rtx_class[(int)(((((((insn)->fld[3].rtx))->fld[0].rtx))->code))]) == 'i')
 next = delete_insn (insn);
    }




  if (end_of_function_label && --((end_of_function_label)->fld[5].rtint) == 0)
    delete_insn (end_of_function_label);


  if ((simple_epilogue_p ()) && end_of_function_label != 0)
    make_return_insns (first);


  __extension__ ({ struct n64_tag_obstack *__o = (&unfilled_slots_obstack); void *__obj = (unfilled_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });


  unfilled_firstobj = (rtx *) __extension__ ({ struct n64_tag_obstack *__h = (&unfilled_slots_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  reposition_prologue_and_epilogue_notes (first);

  if (file)
    {
      register int i, j, need_comma;

      for (reorg_pass_number = 0;
    reorg_pass_number < 2;
    reorg_pass_number++)
 {
   fprintf (file, ";; Reorg pass #%d:\n", reorg_pass_number + 1);
   for (i = 0; i < 2; i++)
     {
       need_comma = 0;
       fprintf (file, ";; Reorg function #%d\n", i);

       fprintf (file, ";; %d insns needing delay slots\n;; ",
         num_insns_needing_delays[i][reorg_pass_number]);

       for (j = 0; j < 3; j++)
  if (num_filled_delays[i][j][reorg_pass_number])
    {
      if (need_comma)
        fprintf (file, ", ");
      need_comma = 1;
      fprintf (file, "%d got %d delays",
        num_filled_delays[i][j][reorg_pass_number], j);
    }
       fprintf (file, "\n");
     }
 }
    }
}

