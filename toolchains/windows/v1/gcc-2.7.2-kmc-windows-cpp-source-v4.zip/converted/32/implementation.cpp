// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/varasm.c
/* Output variables, constants and external declarations, for GNU compiler.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int bc_text(...) asm("_bc_text");
extern int bc_data(...) asm("_bc_data");
extern int error(...) asm("_error");
extern int error_with_decl(...) asm("_error_with_decl");
extern int warning(...) asm("_warning");
extern int globalize_reg(...) asm("_globalize_reg");
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit(...) asm("_bc_emit");
extern int error_with_file_and_line(...) asm("_error_with_file_and_line");
extern int bc_emit_labelref(...) asm("_bc_emit_labelref");
extern int set_float_handler(...) asm("_set_float_handler");
extern int rtl_in_saveable_obstack(...) asm("_rtl_in_saveable_obstack");
extern int target_isnan(...) asm("_target_isnan");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
struct n64_tag__obstack_chunk;
struct n64_tag_addr_const;
struct n64_tag_args_size;
struct n64_tag_constant_descriptor;
struct n64_tag_deferred_constant;
struct n64_tag_function;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_optab;
struct n64_tag_pool_constant;
struct n64_tag_pool_sym;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_const;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_var_refs_queue;
struct n64_tag_weak_syms;


extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct n64_tag_constant_descriptor **const_rtx_hash_table;
  struct n64_tag_pool_sym **const_rtx_sym_hash_table;
  struct n64_tag_pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;

extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
enum n64_cpp_enum_pragma_state{
  ps_start,
  ps_done,
  ps_bad,
  ps_weak,
  ps_name,
  ps_equals,
  ps_value,
  ps_pack,
  ps_left,
  ps_align,
  ps_right
};
typedef __underlying_type(enum n64_cpp_enum_pragma_state) n64_enum_pragma_state;



extern void handle_pragma_weak (n64_enum_pragma_state, char *, char *) asm("_handle_pragma_weak");


extern void handle_pragma_token (char *, tree) asm("_handle_pragma_token");






extern FILE *asm_out_file;


char *first_global_object_name;

extern struct n64_tag_obstack *current_obstack;
extern struct n64_tag_obstack *saveable_obstack;
extern struct n64_tag_obstack *rtl_obstack;
extern struct n64_tag_obstack permanent_obstack;





int const_labelno;




int var_labelno;




int size_directive_output;






tree last_assemble_variable_decl;





struct n64_tag_weak_syms
{
  struct n64_tag_weak_syms *next;
  char *name;
  char *value;
};

static struct n64_tag_weak_syms *weak_decls;




static int function_defined;

struct n64_tag_addr_const;
struct n64_tag_constant_descriptor;
struct n64_tag_rtx_const;
struct n64_tag_pool_constant;

static void bc_make_decl_rtl (tree, char *, int) asm("_bc_make_decl_rtl");
static char *strip_reg_name (char *) asm("_strip_reg_name");
static void bc_output_ascii (FILE *, char *, int) asm("_bc_output_ascii");
static int contains_pointers_p (tree) asm("_contains_pointers_p");
static void decode_addr_const (tree, struct n64_tag_addr_const *) asm("_decode_addr_const");
static int const_hash (tree) asm("_const_hash");
static int compare_constant (tree, struct n64_tag_constant_descriptor *) asm("_compare_constant")
                                          ;
static char *compare_constant_1 (tree, char *) asm("_compare_constant_1");
static struct n64_tag_constant_descriptor *record_constant (tree) asm("_record_constant");
static void record_constant_1 (tree) asm("_record_constant_1");
static tree copy_constant (tree) asm("_copy_constant");
static void output_constant_def_contents (tree, int, int) asm("_output_constant_def_contents");
static void decode_rtx_const (n64_enum_machine_mode, rtx, struct n64_tag_rtx_const *) asm("_decode_rtx_const")
                                ;
static int const_hash_rtx (n64_enum_machine_mode, rtx) asm("_const_hash_rtx");
static int compare_constant_rtx (n64_enum_machine_mode, rtx, struct n64_tag_constant_descriptor *) asm("_compare_constant_rtx")
                                          ;
static struct n64_tag_constant_descriptor *record_constant_rtx (n64_enum_machine_mode, rtx) asm("_record_constant_rtx")
                  ;
static struct n64_tag_pool_constant *find_pool_constant (rtx) asm("_find_pool_constant");
static int output_addressed_constants (tree) asm("_output_addressed_constants");
static void bc_assemble_integer (tree, int) asm("_bc_assemble_integer");
static void output_constructor (tree, int) asm("_output_constructor");


enum n64_cpp_enum_in_section{no_section, in_text, in_data, in_named, in_const, in_ctors, in_dtors};
typedef __underlying_type(enum n64_cpp_enum_in_section) n64_enum_in_section;
static n64_enum_in_section in_section
  = no_section;
static char *in_named_name;



void const_section(void) asm("_const_section");
void const_section(void)
{ if (!1) text_section(); else if (in_section != in_const) { fprintf (asm_out_file, "%s\n", ".section\t.rodata"); in_section = in_const; } } void ctors_section(void)
{ if (in_section != in_ctors) { fprintf (asm_out_file, "%s\n", ".section\t.ctors,\"aw\""); in_section = in_ctors; } } void dtors_section(void)
{ if (in_section != in_dtors) { fprintf (asm_out_file, "%s\n", ".section\t.dtors,\"aw\""); in_section = in_dtors; } }




void
text_section(void) asm("_text_section");
void
text_section(void)
{
  if (in_section != in_text)
    {
      if (output_bytecode)
 bc_text ();
      else
 fprintf (asm_out_file, "%s\n", "\t.text");

      in_section = in_text;
    }
}



void
data_section(void) asm("_data_section");
void
data_section(void)
{
  if (in_section != in_data)
    {
      if (output_bytecode)
 bc_data ();
      else
 {
   if (flag_shared_data)
     {



       fprintf (asm_out_file, "%s\n", "\t.data");

     }
   else
     fprintf (asm_out_file, "%s\n", "\t.data");
 }

      in_section = in_data;
    }
}




void
readonly_data_section(void) asm("_readonly_data_section");
void
readonly_data_section(void)
{

  const_section ();



}



int
in_text_section(void) asm("_in_text_section");
int
in_text_section(void)
{
  return in_section == in_text;
}





void
named_section(tree decl, char *name) asm("_named_section");
void
named_section(tree decl, char *name)
{
  if (decl != (tree) 
             ((void *)0)
      
     && (((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL && ((n64_enum_tree_code) (decl)->common.code) != VAR_DECL))
    abort ();
  if (name == 
             ((void *)0)
                 )
    name = ((((decl)->decl.section_name))->string.pointer);

  if (in_section != in_named || strcmp (name, in_named_name))
    {
      in_named_name = name;
      in_section = in_named;


      fprintf (asm_out_file, ".section\t%s,\"%s\",@progbits\n", name, (decl) && ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL ? "ax" : (decl) && ((decl)->common.readonly_flag) ? "a" : "aw");






    }
}







void
function_section(tree decl) asm("_function_section");
void
function_section(tree decl)
{
  if (decl != (tree) 
             ((void *)0)
      
     && ((decl)->decl.section_name) != (tree) 
                                    ((void *)0)
                                             )
    named_section (decl, (char *) 0);
 else
   text_section ();
}





void
make_function_rtl(tree decl) asm("_make_function_rtl");
void
make_function_rtl(tree decl)
{
  char *name = ((((decl)->decl.assembler_name))->identifier.pointer);

  if (output_bytecode)
    {
      if (((decl)->decl.rtl) == 0)
 ((decl)->decl.rtl) = bc_gen_rtx (name, 0, (struct bc_label *) 0);


      function_defined = 1;
      return;
    }


  if (decl_function_context (decl) != 0
      && ((decl)->decl.initial) != 0
      && ((decl)->decl.rtl) == 0)
    {
      char *label;

      name = ((((decl)->decl.name))->identifier.pointer);
      ( (label) = (char *) 
     __builtin_alloca((
     strlen ((name)) + 10
     ))
     , sprintf ((label), "%s.%d", (name), (var_labelno)));
      name = __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
      var_labelno++;
    }

  if (((decl)->decl.rtl) == 0)
    {
      ((decl)->decl.rtl)
 = gen_rtx (MEM, ((decl)->decl.mode),
     gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name));





      do { if ((target_flags & 0x00004000)) { if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 1; else if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 0; else if (((n64_enum_tree_code) (decl)->common.code) == STRING_CST && ! flag_writable_strings) ((((((decl)->real_cst.rtl))->fld[0].rtx))->volatil) = 0; else ((((((decl)->real_cst.rtl))->fld[0].rtx))->volatil) = 1; } else if ((target_flags & 0x00000008) && ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) { int size = int_size_in_bytes (((decl)->common.type)); if (size > 0 && size <= mips_section_threshold) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 1; } else if (0) ; } while (0);

    }


  function_defined = 1;
}
static void
bc_make_decl_rtl(tree decl, char *asmspec, int top_level) asm("_bc_make_decl_rtl");
static void
bc_make_decl_rtl(tree decl, char *asmspec, int top_level)
{
  register char *name = ((((decl)->decl.assembler_name))->string.pointer);

  if (((decl)->decl.rtl) == 0)
    {

      if (((decl)->decl.regdecl_flag) && ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 error ("function declared `register'");
      else if (((decl)->decl.regdecl_flag))
 error ("global register variables not supported in the interpreter");


      if (((decl)->decl.rtl) == 0)
 {



   if (!top_level && !((decl)->decl.external_flag) && asmspec == 0)
     {
       char *label;

       ( (label) = (char *) 
      __builtin_alloca((
      strlen ((name)) + 10
      ))
      , sprintf ((label), "%s.%d", (name), (var_labelno)));
       name = __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
       var_labelno++;
     }

   ((decl)->decl.rtl) = bc_gen_rtx (name, 0, (struct bc_label *) 0);
 }
    }
}



static char *
strip_reg_name(char *name) asm("_strip_reg_name");
static char *
strip_reg_name(char *name)
{




  if (name[0] == '%' || name[0] == '#')
    name++;
  return name;
}
int
decode_reg_name(char *asmspec) asm("_decode_reg_name");
int
decode_reg_name(char *asmspec)
{
  if (asmspec != 0)
    {
      int i;


      asmspec = strip_reg_name (asmspec);


      for (i = strlen (asmspec) - 1; i >= 0; i--)
 if (! (asmspec[i] >= '0' && asmspec[i] <= '9'))
   break;
      if (asmspec[0] != 0 && i < 0)
 {
   i = atoi (asmspec);
   if (i < 68 && i >= 0)
     return i;
   else
     return -2;
 }

      for (i = 0; i < 68; i++)
 if (reg_names[i][0]
     && ! strcmp (asmspec, strip_reg_name (reg_names[i])))
   return i;


      {
 static struct { char *name; int number; } table[]
   = { { "$0", 0 + 0 }, { "$1", 1 + 0 }, { "$2", 2 + 0 }, { "$3", 3 + 0 }, { "$4", 4 + 0 }, { "$5", 5 + 0 }, { "$6", 6 + 0 }, { "$7", 7 + 0 }, { "$8", 8 + 0 }, { "$9", 9 + 0 }, { "$10", 10 + 0 }, { "$11", 11 + 0 }, { "$12", 12 + 0 }, { "$13", 13 + 0 }, { "$14", 14 + 0 }, { "$15", 15 + 0 }, { "$16", 16 + 0 }, { "$17", 17 + 0 }, { "$18", 18 + 0 }, { "$19", 19 + 0 }, { "$20", 20 + 0 }, { "$21", 21 + 0 }, { "$22", 22 + 0 }, { "$23", 23 + 0 }, { "$24", 24 + 0 }, { "$25", 25 + 0 }, { "$26", 26 + 0 }, { "$27", 27 + 0 }, { "$28", 28 + 0 }, { "$29", 29 + 0 }, { "$30", 30 + 0 }, { "$31", 31 + 0 }, { "$sp", 29 + 0 }, { "$fp", 30 + 0 }, { "at", 1 + 0 }, { "v0", 2 + 0 }, { "v1", 3 + 0 }, { "a0", 4 + 0 }, { "a1", 5 + 0 }, { "a2", 6 + 0 }, { "a3", 7 + 0 }, { "t0", 8 + 0 }, { "t1", 9 + 0 }, { "t2", 10 + 0 }, { "t3", 11 + 0 }, { "t4", 12 + 0 }, { "t5", 13 + 0 }, { "t6", 14 + 0 }, { "t7", 15 + 0 }, { "s0", 16 + 0 }, { "s1", 17 + 0 }, { "s2", 18 + 0 }, { "s3", 19 + 0 }, { "s4", 20 + 0 }, { "s5", 21 + 0 }, { "s6", 22 + 0 }, { "s7", 23 + 0 }, { "t8", 24 + 0 }, { "t9", 25 + 0 }, { "k0", 26 + 0 }, { "k1", 27 + 0 }, { "gp", 28 + 0 }, { "sp", 29 + 0 }, { "fp", 30 + 0 }, { "ra", 31 + 0 }, { "$sp", 29 + 0 }, { "$fp", 30 + 0 }, { "cc", 67 }, };

 for (i = 0; i < sizeof (table) / sizeof (table[0]); i++)
   if (! strcmp (asmspec, table[i].name))
     return table[i].number;
      }


      if (!strcmp (asmspec, "memory"))
 return -4;

      if (!strcmp (asmspec, "cc"))
 return -3;

      return -2;
    }

  return -1;
}
void
make_decl_rtl(tree decl, char *asmspec, int top_level) asm("_make_decl_rtl");
void
make_decl_rtl(tree decl, char *asmspec, int top_level)
{
  register char *name = 0;
  int reg_number;

  if (output_bytecode)
    {
      bc_make_decl_rtl (decl, asmspec, top_level);
      return;
    }

  reg_number = decode_reg_name (asmspec);

  if (((decl)->decl.assembler_name) != (tree) 
                                   ((void *)0)
                                            )
    name = ((((decl)->decl.assembler_name))->identifier.pointer);

  if (reg_number == -2)
    {

      name = (char *) __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (asmspec) + 2)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                              ;
      name[0] = '*';
      strcpy (&name[1], asmspec);
    }



  if (((decl)->decl.rtl) == 0)
    {
      ((decl)->decl.rtl) = 0;


      if (((decl)->decl.regdecl_flag) && reg_number == -1)
 error_with_decl (decl,
    "register name not specified for `%s'");
      else if (((decl)->decl.regdecl_flag) && reg_number < 0)
 error_with_decl (decl,
    "invalid register name for `%s'");
      else if ((reg_number >= 0 || reg_number == -3) && ! ((decl)->decl.regdecl_flag))
 error_with_decl (decl,
    "register name given for non-register variable `%s'");
      else if (((decl)->decl.regdecl_flag) && ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 error ("function declared `register'");
      else if (((decl)->decl.regdecl_flag) && ((((decl)->common.type))->type.mode) == BLKmode)
 error_with_decl (decl, "data type of `%s' isn't suitable for a register");
      else if (((decl)->decl.regdecl_flag)
        && ! mips_hard_regno_mode_ok[ (int)(((((decl)->common.type))->type.mode)) ][ (reg_number) ])
 error_with_decl (decl, "register number for `%s' isn't suitable for the data type");

      else if (((decl)->decl.regdecl_flag))
 {
   int nregs;




   if (((decl)->decl.initial) != 0 && top_level)
     {
       ((decl)->decl.initial) = 0;
       error ("global register variable has initial value");
     }
   if (fixed_regs[reg_number] == 0
       && function_defined && top_level)
     error ("global register variable follows a function definition");
   if (((decl)->common.volatile_flag))
     warning ("volatile register variables don't work as you might wish");







   ((decl)->decl.rtl)
     = gen_rtx (REG, ((decl)->decl.mode), 68);
   ((((decl)->decl.rtl))->fld[0].rtint) = reg_number;
   ((((decl)->decl.rtl))->volatil) = 1;

   if (top_level)
     {


       nregs = (! ((unsigned) ((reg_number) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((decl)->decl.mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((decl)->decl.mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       while (nregs > 0)
  globalize_reg (reg_number + --nregs);
     }
 }






      else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
        && ((decl)->decl.section_name) != (tree) 
                                      ((void *)0)
        
       && ((decl)->decl.initial) == (tree) 
                                 ((void *)0)
        
       && ((decl)->decl.common_flag)
        && ! flag_no_common)
 {
   warning_with_decl (decl,
        "section attribute ignored for uninitialized variable `%s'");


   ((decl)->decl.section_name) = (tree) 
                             ((void *)0)
                                      ;
 }



      if (((decl)->decl.rtl) == 0)
 {



   if (!top_level && !((decl)->decl.external_flag) && asmspec == 0)
     {
       char *label;

       ( (label) = (char *) 
      __builtin_alloca((
      strlen ((name)) + 10
      ))
      , sprintf ((label), "%s.%d", (name), (var_labelno)));
       name = __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
       var_labelno++;
     }

   if (name == 0)
     abort ();

   ((decl)->decl.rtl) = gen_rtx (MEM, ((decl)->decl.mode),
         gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name));





   if (flag_volatile_global && ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
       && ((decl)->common.public_flag))
     ((decl)->common.side_effects_flag) = 1;
   if (((decl)->common.side_effects_flag))
     ((((decl)->decl.rtl))->volatil) = 1;

   if (((decl)->common.readonly_flag))
     ((((decl)->decl.rtl))->unchanging) = 1;
   ((((decl)->decl.rtl))->in_struct)
     = (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == SET_TYPE);






   do { if ((target_flags & 0x00004000)) { if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 1; else if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 0; else if (((n64_enum_tree_code) (decl)->common.code) == STRING_CST && ! flag_writable_strings) ((((((decl)->real_cst.rtl))->fld[0].rtx))->volatil) = 0; else ((((((decl)->real_cst.rtl))->fld[0].rtx))->volatil) = 1; } else if ((target_flags & 0x00000008) && ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) { int size = int_size_in_bytes (((decl)->common.type)); if (size > 0 && size <= mips_section_threshold) ((((((decl)->decl.rtl))->fld[0].rtx))->volatil) = 1; } else if (0) ; } while (0);

 }
    }

  else if (((((decl)->decl.rtl))->mode) != ((decl)->decl.mode))
    {
      rtx rtl = ((decl)->decl.rtl);
      ((rtl)->mode = (((decl)->decl.mode)));
    }
}




void
make_var_volatile(tree var) asm("_make_var_volatile");
void
make_var_volatile(tree var)
{
  if (((((var)->decl.rtl))->code) != MEM)
    abort ();

  ((((var)->decl.rtl))->volatil) = 1;
}



void
assemble_constant_align(tree exp) asm("_assemble_constant_align");
void
assemble_constant_align(tree exp)
{
  int align;


  align = ((((exp)->common.type))->type.align);

  align = ((((n64_enum_tree_code) (exp)->common.code) == STRING_CST || ((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR) && (align) < ((target_flags & 0x00002000) ? 64 : 32) ? ((target_flags & 0x00002000) ? 64 : 32) : (align));


  if (align > 8)
    { int mask = (1 << (floor_log2_wide ((int) (align / 8)))) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (floor_log2_wide ((int) (align / 8)))); };
}




void
assemble_asm(tree string) asm("_assemble_asm");
void
assemble_asm(tree string)
{
  if (output_bytecode)
    {
      error ("asm statements not allowed in interpreter");
      return;
    }

  app_enable ();

  if (((n64_enum_tree_code) (string)->common.code) == ADDR_EXPR)
    string = ((string)->exp.operands[0]);

  fprintf (asm_out_file, "\t%s\n", ((string)->string.pointer));
}
void
assemble_destructor(char *name) asm("_assemble_destructor");
void
assemble_destructor(char *name)
{

  do { dtors_section (); fprintf (asm_out_file, "\t%s\t ", ".long"); assemble_name (asm_out_file, name); fprintf (asm_out_file, "\n"); } while (0);
}



void
assemble_constructor(char *name) asm("_assemble_constructor");
void
assemble_constructor(char *name)
{

  do { ctors_section (); fprintf (asm_out_file, "\t%s\t ", ".long"); assemble_name (asm_out_file, name); fprintf (asm_out_file, "\n"); } while (0);
}




void
assemble_gc_entry(char *name) asm("_assemble_gc_entry");
void
assemble_gc_entry(char *name)
{



  if (flag_gnu_linker)
    {

      fprintf (asm_out_file, "%s \"___PTR_LIST__\",22,0,0,", (((target_flags & 0x00000010)) ? ".stabs" : " #.stabs"));
      assemble_name (asm_out_file, name);
      fputc ('\n', asm_out_file);
    }

}






void
assemble_start_function(tree decl, char *fnname) asm("_assemble_start_function");
void
assemble_start_function(tree decl, char *fnname)
{
  int align;



  app_disable ();

  output_constant_pool (fnname, decl);

  function_section (decl);


  align = floor_log2_wide ((int) (32 / 8));
  if (align > 0)
    {
      if (output_bytecode)
 (0);
      else
 { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };
    }
  if (((decl)->common.public_flag))
    {
      if (!first_global_object_name)
 {
   char *p;

   (p) = ((fnname) + ((fnname)[0] == '*'));
   first_global_object_name = permalloc (strlen (p) + 1);
   strcpy (first_global_object_name, p);
 }


      if (((decl)->decl.weak_flag))
 do { fputs ("\t.weak\t", asm_out_file); assemble_name (asm_out_file, fnname); fputc ('\n', asm_out_file); } while (0);
      else

      if (output_bytecode)
 (0);
      else
 do { fputs ("\t.globl\t", asm_out_file); assemble_name (asm_out_file, fnname); fputs ("\n", asm_out_file); } while (0);
    }



  do { extern FILE *asm_out_text_file; if ((target_flags & 0x00000008)) asm_out_file = asm_out_text_file; fprintf (asm_out_file, "\t%s\t ", ".type"); assemble_name (asm_out_file, fnname); putc (',', asm_out_file); fprintf (asm_out_file, "@%s", "function"); putc ('\n', asm_out_file); ; ; } while (0);







}




void
assemble_end_function(tree decl, char *fnname) asm("_assemble_end_function");
void
assemble_end_function(tree decl, char *fnname)
{

  do { if (!flag_inhibit_size_directive) { char label[256]; static int labelno; labelno++; do { sprintf (label, "*.%s%d", "Lfe", labelno); } while (0); do { fprintf (asm_out_file, ".%s%d:\n", "Lfe", labelno); } while (0); fprintf (asm_out_file, "\t%s\t ", ".size"); assemble_name (asm_out_file, (fnname)); fprintf (asm_out_file, ","); assemble_name (asm_out_file, label); fprintf (asm_out_file, "-"); assemble_name (asm_out_file, (fnname)); putc ('\n', asm_out_file); } } while (0);

}



void
assemble_zeros(int size) asm("_assemble_zeros");
void
assemble_zeros(int size)
{
  if (output_bytecode)
    {
      bc_emit_const_skip (size);
      return;
    }
    if (size > 0)
      {
 if (output_bytecode)
   (0);
 else
   fprintf (asm_out_file, "\t%s\t%u\n", ".zero", (size));
      }
}



void
assemble_align(int align) asm("_assemble_align");
void
assemble_align(int align)
{
  if (align > 8)
    { int mask = (1 << (floor_log2_wide ((int) (align / 8)))) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (floor_log2_wide ((int) (align / 8)))); };
}



void
assemble_string(char *p, int size) asm("_assemble_string");
void
assemble_string(char *p, int size)
{
  register int i;
  int pos = 0;
  int maximum = 2000;

  if (output_bytecode)
    {
      bc_emit (p, size);
      return;
    }



  while (pos < size)
    {
      int thissize = size - pos;
      if (thissize > maximum)
 thissize = maximum;

      if (output_bytecode)
 bc_output_ascii (asm_out_file, p, thissize);
      else
 {
   do { register unsigned char *_ascii_bytes = (unsigned char *) (p); register unsigned char *limit = _ascii_bytes + (thissize); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf ((asm_out_file), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf ((asm_out_file), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf (((asm_out_file)), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, ((asm_out_file))); break; case 1: fprintf (((asm_out_file)), "\\%03o", ch); break; default: putc ('\\', ((asm_out_file))); putc (escape, ((asm_out_file))); break; } } fprintf (((asm_out_file)), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf ((asm_out_file), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, (asm_out_file)); bytes_in_chunk++; break; case 1: fprintf ((asm_out_file), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', (asm_out_file)); putc (escape, (asm_out_file)); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf ((asm_out_file), "\"\n"); } while (0);
 }

      pos += thissize;
      p += thissize;
    }
}

static void
bc_output_ascii(FILE *file, char *p, int size) asm("_bc_output_ascii");
static void
bc_output_ascii(FILE *file, char *p, int size)
{
  do { register unsigned char *_ascii_bytes = (unsigned char *) (p); register unsigned char *limit = _ascii_bytes + (size); register unsigned bytes_in_chunk = 0; for (; _ascii_bytes < limit; _ascii_bytes++) { register unsigned char *p; if (bytes_in_chunk >= 60) { fprintf ((file), "\"\n"); bytes_in_chunk = 0; } for (p = _ascii_bytes; p < limit && *p != '\0'; p++) continue; if (p < limit && (p - _ascii_bytes) <= ((unsigned) 256)) { if (bytes_in_chunk > 0) { fprintf ((file), "\"\n"); bytes_in_chunk = 0; } do { register unsigned char *_limited_str = (unsigned char *) (_ascii_bytes); register unsigned ch; fprintf (((file)), "\t%s\t\"", ".string"); for (; ch = *_limited_str; _limited_str++) { register int escape; switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch]) { case 0: putc (ch, ((file))); break; case 1: fprintf (((file)), "\\%03o", ch); break; default: putc ('\\', ((file))); putc (escape, ((file))); break; } } fprintf (((file)), "\"\n"); } while (0); _ascii_bytes = p; } else { register int escape; register unsigned ch; if (bytes_in_chunk == 0) fprintf ((file), "\t%s\t\"", ".ascii"); switch (escape = "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"[ch = *_ascii_bytes]) { case 0: putc (ch, (file)); bytes_in_chunk++; break; case 1: fprintf ((file), "\\%03o", ch); bytes_in_chunk += 4; break; default: putc ('\\', (file)); putc (escape, (file)); bytes_in_chunk += 2; break; } } } if (bytes_in_chunk > 0) fprintf ((file), "\"\n"); } while (0);
}
void
assemble_variable(tree decl, int top_level, int at_end, int dont_output_data) asm("_assemble_variable");
void
assemble_variable(tree decl, int top_level, int at_end, int dont_output_data)
{
  register char *name;
  int align;
  tree size_tree;
  int reloc = 0;
  n64_enum_in_section saved_in_section;

  last_assemble_variable_decl = 0;

  if (output_bytecode)
    return;

  if (((((decl)->decl.rtl))->code) == REG)
    {



      if (((decl)->common.asm_written_flag))
 return;
      ((decl)->common.asm_written_flag) = 1;

      if (!output_bytecode)
 {
 }
      return;
    }





  if (((decl)->decl.external_flag))
    return;




  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    return;




  if (((decl)->decl.size) == 0)
    layout_decl (decl, 0);




  if (!dont_output_data && ((decl)->decl.size) == 0)
    {
      error_with_file_and_line (((decl)->decl.filename),
    ((decl)->decl.linenum),
    "storage size of `%s' isn't known",
    ((((decl)->decl.name))->identifier.pointer));
      ((decl)->common.asm_written_flag) = 1;
      return;
    }






  if (((decl)->common.asm_written_flag))
    return;

  ((decl)->common.asm_written_flag) = 1;

  app_disable ();

  if (! dont_output_data)
    {
      if (((n64_enum_tree_code) (((decl)->decl.size))->common.code) != INTEGER_CST)
 goto finish;


      size_tree = size_binop (CEIL_DIV_EXPR,
     ((decl)->decl.size), size_int (8));

      if (((size_tree)->int_cst.int_cst_high) != 0)
 {
   error_with_decl (decl, "size of variable `%s' is too large");
   goto finish;
 }
    }

  name = ((((((decl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr);
  if ((! flag_no_common || ! ((decl)->common.public_flag))
      && ((decl)->decl.common_flag)
      && ! dont_output_data
      && (((decl)->decl.initial) == 0 || ((decl)->decl.initial) == error_mark_node))
    {
      int size = ((size_tree)->int_cst.int_cst_low);
      int rounded = size;

      if (((size_tree)->int_cst.int_cst_high) != 0)
 error_with_decl (decl, "size of variable `%s' is too large");


      if (size == 0) rounded = 1;


      rounded += (64 / 8) - 1;
      rounded = (rounded / (64 / 8)
   * (64 / 8));
      if (((decl)->common.public_flag))
 {





     if (output_bytecode)
       {
  (0);
       }
     else
       {

  do { fprintf ((asm_out_file), "\t%s\t", ".comm"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), ",%u,%u\n", (size), (((decl)->decl.frame_size.u)) / 8); } while (0)
                          ;



       }
 }
      else
 {





     if (output_bytecode)
       {
  (0);
       }
     else
       {

  do { fprintf ((asm_out_file), "\t%s\t", ".local"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), "\n"); do { fprintf ((asm_out_file), "\t%s\t", ".comm"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), ",%u,%u\n", (size), (((decl)->decl.frame_size.u)) / 8); } while (0); } while (0)
                         ;



       }
 }
      goto finish;
    }




  if (((decl)->common.public_flag) && ((decl)->decl.name))
    {
      if (!first_global_object_name)
 {
   char *p;

   (p) = ((name) + ((name)[0] == '*'));
   first_global_object_name = permalloc (strlen (p) + 1);
   strcpy (first_global_object_name, p);
 }


      if (((decl)->decl.weak_flag))
 do { fputs ("\t.weak\t", asm_out_file); assemble_name (asm_out_file, name); fputc ('\n', asm_out_file); } while (0);
      else

      do { fputs ("\t.globl\t", asm_out_file); assemble_name (asm_out_file, name); fputs ("\n", asm_out_file); } while (0);
    }
  if (((decl)->decl.initial) == error_mark_node)
    reloc = contains_pointers_p (((decl)->common.type));
  else if (((decl)->decl.initial))
    reloc = output_addressed_constants (((decl)->decl.initial));


  if (((((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL || ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) && ((decl)->decl.section_name) != (tree) 
     ((void *)0)
     ))
    named_section (decl, 
                        ((void *)0)
                            );
  else
    {
      { if (((n64_enum_tree_code) (decl)->common.code) == STRING_CST) { if (! flag_writable_strings) const_section (); else data_section (); } else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) { if ((flag_pic && reloc) || !((decl)->common.readonly_flag) || ((decl)->common.side_effects_flag) || !((decl)->decl.initial) || (((decl)->decl.initial) != error_mark_node && !((((decl)->decl.initial))->common.constant_flag))) data_section (); else const_section (); } else const_section (); };
    }


  if (in_text_section ())
    ((decl)->decl.bit_field_flag) = 1;


  saved_in_section = in_section;
  if (in_section != saved_in_section)
    {


      { if (((n64_enum_tree_code) (decl)->common.code) == STRING_CST) { if (! flag_writable_strings) const_section (); else data_section (); } else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL) { if ((flag_pic && reloc) || !((decl)->common.readonly_flag) || ((decl)->common.side_effects_flag) || !((decl)->decl.initial) || (((decl)->decl.initial) != error_mark_node && !((((decl)->decl.initial))->common.constant_flag))) data_section (); else const_section (); } else const_section (); };
    }



  align = ((decl)->decl.frame_size.u);



  if (dont_output_data && ((decl)->decl.size) == 0
      && ((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE)
    align = ((align) > (((((((decl)->common.type))->common.type))->type.align)) ? (align) : (((((((decl)->common.type))->common.type))->type.align)));






  if (align > 64)
    {
      warning_with_decl (decl,
   "alignment of `%s' is greater than maximum object file alignment");
      align = 64;
    }


  align = ((((align) < ((target_flags & 0x00002000) ? 64 : 32)) && (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE)) ? ((target_flags & 0x00002000) ? 64 : 32) : (align));


  if (((decl)->decl.initial))
    align = ((((n64_enum_tree_code) (((decl)->decl.initial))->common.code) == STRING_CST || ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) == CONSTRUCTOR) && (align) < ((target_flags & 0x00002000) ? 64 : 32) ? ((target_flags & 0x00002000) ? 64 : 32) : (align));




  ((decl)->decl.frame_size.u) = align;

  if (align > 8)
    {
      if (output_bytecode)
 (0);
      else
 { int mask = (1 << (floor_log2_wide ((int) (align / 8)))) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (floor_log2_wide ((int) (align / 8)))); };
    }



  last_assemble_variable_decl = decl;
  do { fprintf (asm_out_file, "\t%s\t ", ".type"); assemble_name (asm_out_file, name); putc (',', asm_out_file); fprintf (asm_out_file, "@%s", "object"); putc ('\n', asm_out_file); size_directive_output = 0; if (!flag_inhibit_size_directive && ((decl)->decl.size)) { size_directive_output = 1; fprintf (asm_out_file, "\t%s\t ", ".size"); assemble_name (asm_out_file, name); fprintf (asm_out_file, ",%d\n", int_size_in_bytes (((decl)->common.type))); } do { assemble_name (asm_out_file, name); fputs (":\n", asm_out_file); } while (0); } while (0);
  if (!dont_output_data)
    {
      if (((decl)->decl.initial))

 output_constant (((decl)->decl.initial), ((size_tree)->int_cst.int_cst_low));
      else

 assemble_zeros (((size_tree)->int_cst.int_cst_low));
    }

 finish:
  ;

}



static int
contains_pointers_p(tree type) asm("_contains_pointers_p");
static int
contains_pointers_p(tree type)
{
  switch (((n64_enum_tree_code) (type)->common.code))
    {
    case POINTER_TYPE:
    case REFERENCE_TYPE:


    case OFFSET_TYPE:
      return 1;

    case RECORD_TYPE:
    case UNION_TYPE:
    case QUAL_UNION_TYPE:
      {
 tree fields;

 for (fields = ((type)->type.values); fields; fields = ((fields)->common.chain))
   if (((n64_enum_tree_code) (fields)->common.code) == FIELD_DECL
       && contains_pointers_p (((fields)->common.type)))
     return 1;
 return 0;
      }

    case ARRAY_TYPE:

      return contains_pointers_p (((type)->common.type));

    default:
      return 0;
    }
}



void
bc_output_constructor(tree constr, int size) asm("_bc_output_constructor");
void
bc_output_constructor(tree constr, int size)
{
  int i;




  if (!((constr)->common.constant_flag))
    abort ();


  text_section ();


  for (i = 0; ((constr)->type.align) >= 8 << (i + 1); i++)
    ;

  if (i > 0)
    (0);


  output_constant (constr, size);
}



void
bc_output_data_constructor(tree constr) asm("_bc_output_data_constructor");
void
bc_output_data_constructor(tree constr)
{
  int i;


  data_section ();


  for (i = 0; ((constr)->type.align) >= 8 << (i + 1); i++);
  if (i > 0)
    (0);


  (0);
}





void
assemble_external(tree decl) asm("_assemble_external");
void
assemble_external(tree decl)
{
  if (output_bytecode)
    return;


  if ((*tree_code_type[(int) (((n64_enum_tree_code) (decl)->common.code))]) == 'd'
      && ((decl)->decl.external_flag) && ((decl)->common.public_flag))
    {
      rtx rtl = ((decl)->decl.rtl);

      if (((rtl)->code) == MEM && ((((rtl)->fld[0].rtx))->code) == SYMBOL_REF
   && ! ((((rtl)->fld[0].rtx))->used))
 {

   ((((rtl)->fld[0].rtx))->used) = 1;
   mips_output_external(asm_out_file,decl,((((rtl)->fld[0].rtx))->fld[0].rtstr));
 }
    }

}



void
assemble_external_libcall(rtx fun) asm("_assemble_external_libcall");
void
assemble_external_libcall(rtx fun)
{

  if (!output_bytecode)
    {

      if (! ((fun)->used))
 {
   ((fun)->used) = 1;
   do { fputs ("\t.globl\t", asm_out_file); assemble_name (asm_out_file, ((fun)->fld[0].rtstr)); fputs ("\n", asm_out_file); } while (0);
 }
    }

}



void
assemble_global(char *name) asm("_assemble_global");
void
assemble_global(char *name)
{
  do { fputs ("\t.globl\t", asm_out_file); assemble_name (asm_out_file, name); fputs ("\n", asm_out_file); } while (0);
}



void
assemble_label(char *name) asm("_assemble_label");
void
assemble_label(char *name)
{
  if (output_bytecode)
    (0);
  else
    do { assemble_name (asm_out_file, name); fputs (":\n", asm_out_file); } while (0);
}







void
assemble_name(FILE *file, char *name) asm("_assemble_name");
void
assemble_name(FILE *file, char *name)
{
  char *real_name;
  int save_warn_id_clash = warn_id_clash;

  (real_name) = ((name) + ((name)[0] == '*'));



  warn_id_clash = 0;
  ((get_identifier (real_name))->common.static_flag) = 1;
  warn_id_clash = save_warn_id_clash;

  if (name[0] == '*')
    {
      if (output_bytecode)
 bc_emit_labelref (name, 0);
      else
 fputs (&name[1], file);
    }
  else
    {
      if (output_bytecode)
 (0);
      else
 fprintf (file, "%s", name);
    }
}




rtx
assemble_static_space(int size) asm("_assemble_static_space");
rtx
assemble_static_space(int size)
{
  char name[12];
  char *namestring;
  rtx x;


  int rounded = ((size + (64 / 8) - 1)
   / (64 / 8)
   * (64 / 8));






  do { sprintf (name, "*.%s%d", "LF", const_labelno); } while (0);
  ++const_labelno;

  namestring = (char *) __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (name) + 2)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                             ;
  strcpy (namestring, name);

  if (output_bytecode)
    x = bc_gen_rtx (namestring, 0, (struct bc_label *) 0);
  else
    x = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), namestring);

  if (output_bytecode)
    {
      (0);
    }
  else
    {

      do { fprintf ((asm_out_file), "\t%s\t", ".local"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), "\n"); do { fprintf ((asm_out_file), "\t%s\t", ".comm"); assemble_name ((asm_out_file), (name)); fprintf ((asm_out_file), ",%u,%u\n", (size), (64) / 8); } while (0); } while (0);



    }
  return x;
}





rtx
assemble_trampoline_template(void) asm("_assemble_trampoline_template");
rtx
assemble_trampoline_template(void)
{
  char label[256];
  char *name;
  int align;


  if (output_bytecode)
    abort ();






  readonly_data_section ();



  align = floor_log2_wide ((int) (32 / 8));
  if (align > 0)
    { int mask = (1 << (align)) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (align)); };

  do { fprintf (asm_out_file, ".%s%d:\n", "LTRAMP", 0); } while (0);
  { fprintf (asm_out_file, "\t.word\t0x03e00821\t\t# move   $1,$31\n"); fprintf (asm_out_file, "\t.word\t0x04110001\t\t# bgezal $0,.+8\n"); fprintf (asm_out_file, "\t.word\t0x00000000\t\t# nop\n"); if ((target_flags & 0x00000002)) { fprintf (asm_out_file, "\t.word\t0xdfe30014\t\t# ld     $3,20($31)\n"); fprintf (asm_out_file, "\t.word\t0xdfe2001c\t\t# ld     $2,28($31)\n"); } else { fprintf (asm_out_file, "\t.word\t0x8fe30014\t\t# lw     $3,20($31)\n"); fprintf (asm_out_file, "\t.word\t0x8fe20018\t\t# lw     $2,24($31)\n"); } fprintf (asm_out_file, "\t.word\t0x0060c821\t\t# move   $25,$3 (abicalls)\n"); fprintf (asm_out_file, "\t.word\t0x00600008\t\t# jr     $3\n"); fprintf (asm_out_file, "\t.word\t0x0020f821\t\t# move   $31,$1\n"); if ((target_flags & 0x00000002)) { fprintf (asm_out_file, "\t.dword\t0x00000000\t\t# <function address>\n"); fprintf (asm_out_file, "\t.dword\t0x00000000\t\t# <static chain value>\n"); } else { fprintf (asm_out_file, "\t.word\t0x00000000\t\t# <function address>\n"); fprintf (asm_out_file, "\t.word\t0x00000000\t\t# <static chain value>\n"); } };


  do { sprintf (label, "*.%s%d", "LTRAMP", 0); } while (0);
  name
    = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  return gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), name);
}







int
assemble_integer(rtx x, int size, int force) asm("_assemble_integer");
int
assemble_integer(rtx x, int size, int force)
{



  switch (size)
    {

    case 1:
      { fprintf (asm_out_file, "\t.byte\t"); output_addr_const (asm_out_file, (x)); fprintf (asm_out_file, "\n"); };
      return 1;



    case 2:
      { fprintf (asm_out_file, "\t.half\t"); output_addr_const (asm_out_file, (x)); fprintf (asm_out_file, "\n"); };
      return 1;



    case 4:
      do { fprintf (asm_out_file, "\t.word\t"); output_addr_const (asm_out_file, (x)); fprintf (asm_out_file, "\n"); } while (0);
      return 1;



    case 8:
      do { if ((target_flags & 0x00002000)) { fprintf (asm_out_file, "\t.dword\t"); output_addr_const (asm_out_file, (x)); fprintf (asm_out_file, "\n"); } else { assemble_integer (operand_subword ((x), 0, 0, DImode), ((target_flags & 0x00002000) ? 8 : 4), 1); assemble_integer (operand_subword ((x), 1, 0, DImode), ((target_flags & 0x00002000) ? 8 : 4), 1); } } while (0);
      return 1;







    }






  if (size == 1 && ((x)->code) == CONST_INT)
    {
      fprintf (asm_out_file, "\t.byte\t0x%x\n", (((x)->fld[0].rtwint)));
      return 1;
    }





  if (size > ((target_flags & 0x00002000) ? 8 : 4))
    {
      int i;
      n64_enum_machine_mode mode
 = mode_for_size (size * 8, MODE_INT, 0);
      rtx word;

      for (i = 0; i < size / ((target_flags & 0x00002000) ? 8 : 4); i++)
 {
   word = operand_subword (x, i, 0, mode);

   if (word == 0)
     break;

   if (! assemble_integer (word, ((target_flags & 0x00002000) ? 8 : 4), 0))
     break;
 }

      if (i == size / ((target_flags & 0x00002000) ? 8 : 4))
 return 1;


      if (i > 0)
 abort ();
    }

  if (force)
    abort ();

  return 0;
}



void
assemble_real(double d, n64_enum_machine_mode mode) asm("_assemble_real");
void
assemble_real(double d, n64_enum_machine_mode mode)
{
  jmp_buf output_constant_handler;

  if (
     _setjmp3((
     output_constant_handler
     ), ((void *)0))
                                     )
    {
      error ("floating point trap outputting a constant");

      memset ((char *) &d,0,sizeof d);
      d = dconst0;



    }

  set_float_handler (output_constant_handler);

  switch (mode)
    {
    case SFmode:
      mips_output_float (asm_out_file, d);
      break;



    case DFmode:
      mips_output_double (asm_out_file, d);
      break;
    default:
      abort ();
    }

  set_float_handler (((void *)0));
}
static rtx const_double_chain;






rtx
immed_double_const(int i0, int i1, n64_enum_machine_mode mode) asm("_immed_double_const");
rtx
immed_double_const(int i0, int i1, n64_enum_machine_mode mode)
{
  register rtx r;
  int in_current_obstack;

  if ((mode_class[(int)(mode)]) == MODE_INT
      || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT)
    {



      int width = (8 * mode_size[(int)(mode)]);
      if (width < 32
   && ((i0 & ((int) (-1) << (width - 1)))
       != ((int) (-1) << (width - 1))))
 i0 &= ((int) 1 << width) - 1, i1 = 0;
      else if (width == 32
        && ! (i1 == ~0 && i0 < 0))
 i1 = 0;
      else if (width > 2 * 32)

 abort ();
      if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
   && (i0 & ((int) 1 << (width - 1))))
 i0 |= ((int) (-1) << width);
      if (width <= 32)
 i1 = (i0 < 0) ? ~0 : 0;


      if ((i1 == 0 && i0 >= 0)
   || (i1 == ~0 && i0 < 0))
 return gen_rtx (CONST_INT, VOIDmode, (int) (i0));


      mode = VOIDmode;
    }




  for (r = const_double_chain; r; r = ((r)->fld[1].rtx))
    if (((r)->fld[2].rtwint) == i0 && ((r)->fld[3].rtwint) == i1
 && ((r)->mode) == mode)
      return r;
  push_obstacks_nochange ();
  rtl_in_saveable_obstack ();
  r = gen_rtx (CONST_DOUBLE, mode, 0, i0, i1);
  pop_obstacks ();



  if (outer_function_chain == 0 && current_function_decl != 0)
    {
      ((r)->fld[1].rtx) = const_double_chain;
      const_double_chain = r;
    }




  ((r)->fld[0].rtx) = const0_rtx;

  return r;
}




rtx
immed_real_const_1(double d, n64_enum_machine_mode mode) asm("_immed_real_const_1");
rtx
immed_real_const_1(double d, n64_enum_machine_mode mode)
{
  union n64_tag_real_extract u;
  register rtx r;
  int in_current_obstack;




  u.d = d;




  if (!memcmp ((char *) &dconst0,(char *) &d,sizeof d))
    return (const_tiny_rtx[0][(int) (mode)]);




  else if (! (target_isnan (d)) && (ereal_cmp ((dconst1), (d)) == 0))
    return (const_tiny_rtx[1][(int) (mode)]);

  if (sizeof u == 2 * sizeof (int))
    return immed_double_const (u.i[0], u.i[1], mode);
  for (r = const_double_chain; r; r = ((r)->fld[1].rtx))
    if (! memcmp ((char *) &((r)->fld[2].rtwint),(char *) &u,sizeof u)
 && ((r)->mode) == mode)
      return r;
  push_obstacks_nochange ();
  rtl_in_saveable_obstack ();
  r = rtx_alloc (CONST_DOUBLE);
  ((r)->mode = (mode));
  memcpy ((char *) &((r)->fld[2].rtwint),(char *) &u,sizeof u);
  pop_obstacks ();



  if (outer_function_chain == 0 && current_function_decl != 0)
    {
      ((r)->fld[1].rtx) = const_double_chain;
      const_double_chain = r;
    }





  ((r)->fld[0].rtx) = const0_rtx;

  return r;
}




rtx
immed_real_const(tree exp) asm("_immed_real_const");
rtx
immed_real_const(tree exp)
{
  return immed_real_const_1 (((exp)->real_cst.real_cst), ((((exp)->common.type))->type.mode));
}





void
clear_const_double_mem(void) asm("_clear_const_double_mem");
void
clear_const_double_mem(void)
{
  register rtx r, next;



  if (outer_function_chain != 0)
    return;

  for (r = const_double_chain; r; r = next)
    {
      next = ((r)->fld[1].rtx);
      ((r)->fld[1].rtx) = 0;
      ((r)->fld[0].rtx) = cc0_rtx;
    }
  const_double_chain = 0;
}






struct n64_tag_addr_const
{
  rtx base;
  int offset;
};

static void
decode_addr_const(tree exp, struct n64_tag_addr_const *value) asm("_decode_addr_const");
static void
decode_addr_const(tree exp, struct n64_tag_addr_const *value)
{
  register tree target = ((exp)->exp.operands[0]);
  register int offset = 0;
  register rtx x;

  while (1)
    {
      if (((n64_enum_tree_code) (target)->common.code) == COMPONENT_REF
   && (((n64_enum_tree_code) (((((target)->exp.operands[1]))->decl.arguments))->common.code)
       == INTEGER_CST))
 {
   offset += ((((((target)->exp.operands[1]))->decl.arguments))->int_cst.int_cst_low) / 8;
   target = ((target)->exp.operands[0]);
 }
      else if (((n64_enum_tree_code) (target)->common.code) == ARRAY_REF)
 {
   if (((n64_enum_tree_code) (((target)->exp.operands[1]))->common.code) != INTEGER_CST
       || ((n64_enum_tree_code) (((((target)->common.type))->type.size))->common.code) != INTEGER_CST)
     abort ();
   offset += ((((((((target)->common.type))->type.size))->int_cst.int_cst_low)
        * ((((target)->exp.operands[1]))->int_cst.int_cst_low))
       / 8);
   target = ((target)->exp.operands[0]);
 }
      else
 break;
    }

  switch (((n64_enum_tree_code) (target)->common.code))
    {
    case VAR_DECL:
    case FUNCTION_DECL:
      x = ((target)->decl.rtl);
      break;

    case LABEL_DECL:
      if (output_bytecode)

 x = bc_gen_rtx (((target)->string.pointer), 0, (struct bc_label *) 0);
      else
 x = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode),
       gen_rtx (LABEL_REF, VOIDmode,
         label_rtx (((exp)->exp.operands[0]))));
      break;

    case REAL_CST:
    case STRING_CST:
    case COMPLEX_CST:
    case CONSTRUCTOR:
      x = ((target)->real_cst.rtl);
      break;

    default:
      abort ();
    }

  if (!output_bytecode)
    {
      if (((x)->code) != MEM)
 abort ();
      x = ((x)->fld[0].rtx);
    }

  value->base = x;
  value->offset = offset;
}
struct n64_tag_constant_descriptor
{
  struct n64_tag_constant_descriptor *next;
  char *label;
  char contents[1];
};



static struct n64_tag_constant_descriptor *const_hash_table[1009];



static int
const_hash(tree exp) asm("_const_hash");
static int
const_hash(tree exp)
{
  register char *p;
  register int len, hi, i;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);

  if (code == INTEGER_CST)
    {
      p = (char *) &((exp)->int_cst.int_cst_low);
      len = 2 * sizeof ((exp)->int_cst.int_cst_low);
    }
  else if (code == REAL_CST)
    {
      p = (char *) &((exp)->real_cst.real_cst);
      len = sizeof ((exp)->real_cst.real_cst);
    }
  else if (code == STRING_CST)
    p = ((exp)->string.pointer), len = ((exp)->string.length);
  else if (code == COMPLEX_CST)
    return const_hash (((exp)->complex.real)) * 5
      + const_hash (((exp)->complex.imag));
  else if (code == CONSTRUCTOR && ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)
    {
      len = int_size_in_bytes (((exp)->common.type));
      p = (char*) 
                 __builtin_alloca((
                 len
                 ))
                             ;
      get_set_constructor_bytes (exp, (unsigned char *) p, len);
    }
  else if (code == CONSTRUCTOR)
    {
      register tree link;







      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE)
 hi = ((int) ((exp)->common.type) & ((1 << 30) - 1))
   % 1009;
      else
 hi = ((5 + int_size_in_bytes (((exp)->common.type)))
        & ((1 << 30) - 1)) % 1009;

      for (link = ((exp)->exp.operands[1]); link; link = ((link)->common.chain))
 if (((link)->list.value))
   hi = (hi * 603 + const_hash (((link)->list.value))) % 1009;

      return hi;
    }
  else if (code == ADDR_EXPR)
    {
      struct n64_tag_addr_const value;
      decode_addr_const (exp, &value);
      if (((value.base)->code) == SYMBOL_REF)
 {


   hi = value.offset;
   p = ((value.base)->fld[0].rtstr);
   for (i = 0; p[i] != 0; i++)
     hi = ((hi * 613) + (unsigned)(p[i]));
 }
      else if (((value.base)->code) == LABEL_REF)
 hi = value.offset + ((((value.base)->fld[0].rtx))->fld[3].rtint) * 13;

      hi &= (1 << 30) - 1;
      hi %= 1009;
      return hi;
    }
  else if (code == PLUS_EXPR || code == MINUS_EXPR)
    return const_hash (((exp)->exp.operands[0])) * 9
      + const_hash (((exp)->exp.operands[1]));
  else if (code == NOP_EXPR || code == CONVERT_EXPR)
    return const_hash (((exp)->exp.operands[0])) * 7 + 2;


  hi = len;
  for (i = 0; i < len; i++)
    hi = ((hi * 613) + (unsigned)(p[i]));

  hi &= (1 << 30) - 1;
  hi %= 1009;
  return hi;
}




static int
compare_constant(tree exp, struct n64_tag_constant_descriptor *desc) asm("_compare_constant");
static int
compare_constant(tree exp, struct n64_tag_constant_descriptor *desc)
{
  return 0 != compare_constant_1 (exp, desc->contents);
}
static char *
compare_constant_1(tree exp, char *p) asm("_compare_constant_1");
static char *
compare_constant_1(tree exp, char *p)
{
  register char *strp;
  register int len;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);

  if (code != (n64_enum_tree_code) *p++)
    return 0;

  if (code == INTEGER_CST)
    {

      if (*p++ != ((((exp)->common.type))->type.precision))
 return 0;
      strp = (char *) &((exp)->int_cst.int_cst_low);
      len = 2 * sizeof ((exp)->int_cst.int_cst_low);
    }
  else if (code == REAL_CST)
    {

      if (*p++ != ((((exp)->common.type))->type.precision))
 return 0;
      strp = (char *) &((exp)->real_cst.real_cst);
      len = sizeof ((exp)->real_cst.real_cst);
    }
  else if (code == STRING_CST)
    {
      if (flag_writable_strings)
 return 0;
      strp = ((exp)->string.pointer);
      len = ((exp)->string.length);
      if (memcmp ((char *) &((exp)->string.length),p,sizeof ((exp)->string.length))
                                  )
 return 0;
      p += sizeof ((exp)->string.length);
    }
  else if (code == COMPLEX_CST)
    {
      p = compare_constant_1 (((exp)->complex.real), p);
      if (p == 0) return 0;
      p = compare_constant_1 (((exp)->complex.imag), p);
      return p;
    }
  else if (code == CONSTRUCTOR && ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)
    {
      len = int_size_in_bytes (((exp)->common.type));
      strp = (char*) 
                    __builtin_alloca((
                    len
                    ))
                                ;
      get_set_constructor_bytes (exp, (unsigned char *) strp, len);
    }
  else if (code == CONSTRUCTOR)
    {
      register tree link;
      int length = list_length (((exp)->exp.operands[1]));
      tree type;

      if (memcmp ((char *) &length,p,sizeof length))
 return 0;
      p += sizeof length;



      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE)
 type = ((exp)->common.type);
      else
 type = 0;
      if (memcmp ((char *) &type,p,sizeof type))
 return 0;
      p += sizeof type;


      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE)
 {
   int size = int_size_in_bytes (((exp)->common.type));
   if (memcmp ((char *) &size,p,sizeof size))
     return 0;
   p += sizeof size;
 }

      for (link = ((exp)->exp.operands[1]); link; link = ((link)->common.chain))
 {
   if (((link)->list.value))
     {
       if ((p = compare_constant_1 (((link)->list.value), p)) == 0)
  return 0;
     }
   else
     {
       tree zero = 0;

       if (memcmp ((char *) &zero,p,sizeof zero))
  return 0;
       p += sizeof zero;
     }
 }

      return p;
    }
  else if (code == ADDR_EXPR)
    {
      struct n64_tag_addr_const value;
      decode_addr_const (exp, &value);
      strp = (char *) &value.offset;
      len = sizeof value.offset;

      while (--len >= 0)
 if (*p++ != *strp++)
   return 0;

      strp = ((value.base)->fld[0].rtstr);
      len = strlen (strp) + 1;
    }
  else if (code == PLUS_EXPR || code == MINUS_EXPR)
    {
      p = compare_constant_1 (((exp)->exp.operands[0]), p);
      if (p == 0) return 0;
      p = compare_constant_1 (((exp)->exp.operands[1]), p);
      return p;
    }
  else if (code == NOP_EXPR || code == CONVERT_EXPR)
    {
      p = compare_constant_1 (((exp)->exp.operands[0]), p);
      return p;
    }


  while (--len >= 0)
    if (*p++ != *strp++)
      return 0;

  return p;
}




static struct n64_tag_constant_descriptor *
record_constant(tree exp) asm("_record_constant");
static struct n64_tag_constant_descriptor *
record_constant(tree exp)
{
  struct n64_tag_constant_descriptor *next = 0;
  char *label = 0;




  __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof next); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &next),__len); __o->next_free += __len; } (void) 0; });
  __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof label); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &label),__len); __o->next_free += __len; } (void) 0; });
  record_constant_1 (exp);
  return (struct n64_tag_constant_descriptor *) __extension__ ({ struct n64_tag_obstack *__o1 = (&permanent_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
}






static void
record_constant_1(tree exp) asm("_record_constant_1");
static void
record_constant_1(tree exp)
{
  register char *strp;
  register int len;
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);

  __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ((unsigned int) code); (void) 0; });

  switch (code)
    {
    case INTEGER_CST:
      __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (((((exp)->common.type))->type.precision)); (void) 0; });
      strp = (char *) &((exp)->int_cst.int_cst_low);
      len = 2 * sizeof ((exp)->int_cst.int_cst_low);
      break;

    case REAL_CST:
      __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (((((exp)->common.type))->type.precision)); (void) 0; });
      strp = (char *) &((exp)->real_cst.real_cst);
      len = sizeof ((exp)->real_cst.real_cst);
      break;

    case STRING_CST:
      if (flag_writable_strings)
 return;

      strp = ((exp)->string.pointer);
      len = ((exp)->string.length);
      __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof ((exp)->string.length)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &((exp)->string.length)),__len); __o->next_free += __len; } (void) 0; })
                                      ;
      break;

    case COMPLEX_CST:
      record_constant_1 (((exp)->complex.real));
      record_constant_1 (((exp)->complex.imag));
      return;

    case CONSTRUCTOR:
      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)
 {
   int nbytes = int_size_in_bytes (((exp)->common.type));
   __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof (nbytes)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (&nbytes),__len); __o->next_free += __len; } (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (nbytes); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; });
   get_set_constructor_bytes
     (exp, (unsigned char *) permanent_obstack.next_free, nbytes);
   return;
 }
      else
 {
   register tree link;
   int length = list_length (((exp)->exp.operands[1]));
   tree type;

   __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof length); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &length),__len); __o->next_free += __len; } (void) 0; });



   if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE)
     type = ((exp)->common.type);
   else
     type = 0;
   __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof type); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &type),__len); __o->next_free += __len; } (void) 0; });


   if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE)
     {
       int size = int_size_in_bytes (((exp)->common.type));
       __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof size); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &size),__len); __o->next_free += __len; } (void) 0; });
     }

   for (link = ((exp)->exp.operands[1]); link; link = ((link)->common.chain))
     {
       if (((link)->list.value))
  record_constant_1 (((link)->list.value));
       else
  {
    tree zero = 0;

    __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof zero); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &zero),__len); __o->next_free += __len; } (void) 0; })
                                ;
  }
     }
 }
      return;

    case ADDR_EXPR:
      {
 struct n64_tag_addr_const value;

 decode_addr_const (exp, &value);

 __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (sizeof value.offset); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((char *) &value.offset),__len); __o->next_free += __len; } (void) 0; })
                                                    ;

 __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (strlen (((value.base)->fld[0].rtstr)) + 1); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((value.base)->fld[0].rtstr)),__len); __o->next_free += __len; } (void) 0; })
                                          ;
      }
      return;

    case PLUS_EXPR:
    case MINUS_EXPR:
      record_constant_1 (((exp)->exp.operands[0]));
      record_constant_1 (((exp)->exp.operands[1]));
      return;

    case NOP_EXPR:
    case CONVERT_EXPR:
    case NON_LVALUE_EXPR:
      record_constant_1 (((exp)->exp.operands[0]));
      return;

    default:
      abort ();
    }


  __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (strp),__len); __o->next_free += __len; } (void) 0; });
}




struct n64_tag_deferred_constant
{
  struct n64_tag_deferred_constant *next;
  tree exp;
  int reloc;
  int labelno;
};

static struct n64_tag_deferred_constant *deferred_constants;



static int defer_addressed_constants_flag;



void
defer_addressed_constants(void) asm("_defer_addressed_constants");
void
defer_addressed_constants(void)
{
  defer_addressed_constants_flag++;
}




void
output_deferred_addressed_constants(void) asm("_output_deferred_addressed_constants");
void
output_deferred_addressed_constants(void)
{
  struct n64_tag_deferred_constant *p, *next;

  defer_addressed_constants_flag--;

  if (defer_addressed_constants_flag > 0)
    return;

  for (p = deferred_constants; p; p = next)
    {
      output_constant_def_contents (p->exp, p->reloc, p->labelno);
      next = p->next;
      free (p);
    }

  deferred_constants = 0;
}





static tree
copy_constant(tree exp) asm("_copy_constant");
static tree
copy_constant(tree exp)
{
  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case ADDR_EXPR:


      if ((*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code))]) == 'c')
 return build1 (((n64_enum_tree_code) (exp)->common.code), ((exp)->common.type),
         copy_constant (((exp)->exp.operands[0])));
      else
 return copy_node (exp);

    case INTEGER_CST:
    case REAL_CST:
    case STRING_CST:
      return copy_node (exp);

    case COMPLEX_CST:
      return build_complex (copy_constant (((exp)->complex.real)),
       copy_constant (((exp)->complex.imag)));

    case PLUS_EXPR:
    case MINUS_EXPR:
      return build (((n64_enum_tree_code) (exp)->common.code), ((exp)->common.type),
      copy_constant (((exp)->exp.operands[0])),
      copy_constant (((exp)->exp.operands[1])));

    case NOP_EXPR:
    case CONVERT_EXPR:
      return build1 (((n64_enum_tree_code) (exp)->common.code), ((exp)->common.type),
       copy_constant (((exp)->exp.operands[0])));

    case CONSTRUCTOR:
      {
 tree copy = copy_node (exp);
 tree list = copy_list (((exp)->exp.operands[1]));
 tree tail;

 ((copy)->exp.operands[1]) = list;
 for (tail = list; tail; tail = ((tail)->common.chain))
   ((tail)->list.value) = copy_constant (((tail)->list.value));
 if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)
   for (tail = list; tail; tail = ((tail)->common.chain))
     ((tail)->list.purpose) = copy_constant (((tail)->list.purpose));

 return copy;
      }

    default:
      abort ();
    }
}
rtx
output_constant_def(tree exp) asm("_output_constant_def");
rtx
output_constant_def(tree exp)
{
  register int hash;
  register struct n64_tag_constant_descriptor *desc;
  char label[256];
  char *found = 0;
  int reloc;
  register rtx def;

  if (((n64_enum_tree_code) (exp)->common.code) == INTEGER_CST)
    abort ();

  if (((exp)->real_cst.rtl))
    return ((exp)->real_cst.rtl);




  reloc = output_addressed_constants (exp);





  hash = const_hash (exp) % 1009;

  for (desc = const_hash_table[hash]; desc; desc = desc->next)
    if (compare_constant (exp, desc))
      {
 found = desc->label;
 break;
      }

  if (found == 0)
    {






      do { sprintf (label, "*.%s%d", "LC", const_labelno); } while (0);

      desc = record_constant (exp);
      desc->next = const_hash_table[hash];
      desc->label
 = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
      const_hash_table[hash] = desc;
    }
  else
    {

      do { sprintf (label, "*.%s%d", "LC", const_labelno); } while (0);
    }



  push_obstacks_nochange ();
  if (((exp)->common.permanent_flag))
    end_temporary_allocation ();

  def = gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), desc->label);

  ((exp)->real_cst.rtl)
    = gen_rtx (MEM, ((((exp)->common.type))->type.mode), def);
  ((((exp)->real_cst.rtl))->unchanging) = 1;
  if ((((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE))
    ((((exp)->real_cst.rtl))->in_struct) = 1;

  pop_obstacks ();





  do { if ((target_flags & 0x00004000)) { if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL) ((((((exp)->decl.rtl))->fld[0].rtx))->volatil) = 1; else if (((n64_enum_tree_code) (exp)->common.code) == FUNCTION_DECL) ((((((exp)->decl.rtl))->fld[0].rtx))->volatil) = 0; else if (((n64_enum_tree_code) (exp)->common.code) == STRING_CST && ! flag_writable_strings) ((((((exp)->real_cst.rtl))->fld[0].rtx))->volatil) = 0; else ((((((exp)->real_cst.rtl))->fld[0].rtx))->volatil) = 1; } else if ((target_flags & 0x00000008) && ((n64_enum_tree_code) (exp)->common.code) == VAR_DECL) { int size = int_size_in_bytes (((exp)->common.type)); if (size > 0 && size <= mips_section_threshold) ((((((exp)->decl.rtl))->fld[0].rtx))->volatil) = 1; } else if (0) ; } while (0);




  if (found == 0)
    {
      if (defer_addressed_constants_flag)
 {
   struct n64_tag_deferred_constant *p;
   p = (struct n64_tag_deferred_constant *) xmalloc (sizeof (struct n64_tag_deferred_constant));

   push_obstacks_nochange ();
   suspend_momentary ();
   p->exp = copy_constant (exp);
   pop_obstacks ();
   p->reloc = reloc;
   p->labelno = const_labelno++;
   p->next = deferred_constants;
   deferred_constants = p;
 }
      else
 output_constant_def_contents (exp, reloc, const_labelno++);
    }

  return ((exp)->real_cst.rtl);
}




static void
output_constant_def_contents(tree exp, int reloc, int labelno) asm("_output_constant_def_contents");
static void
output_constant_def_contents(tree exp, int reloc, int labelno)
{
  int align;

  if (((((n64_enum_tree_code) (exp)->common.code) == FUNCTION_DECL || ((n64_enum_tree_code) (exp)->common.code) == VAR_DECL) && ((exp)->decl.section_name) != (tree) 
     ((void *)0)
     ))
    named_section (exp, 
                       ((void *)0)
                           );
  else
    {


      { if (((n64_enum_tree_code) (exp)->common.code) == STRING_CST) { if (! flag_writable_strings) const_section (); else data_section (); } else if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL) { if ((flag_pic && reloc) || !((exp)->common.readonly_flag) || ((exp)->common.side_effects_flag) || !((exp)->decl.initial) || (((exp)->decl.initial) != error_mark_node && !((((exp)->decl.initial))->common.constant_flag))) data_section (); else const_section (); } else const_section (); };







    }


  align = ((((exp)->common.type))->type.align);

  align = ((((n64_enum_tree_code) (exp)->common.code) == STRING_CST || ((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR) && (align) < ((target_flags & 0x00002000) ? 64 : 32) ? ((target_flags & 0x00002000) ? 64 : 32) : (align));


  if (align > 8)
    {
      if (!output_bytecode)
 {
   { int mask = (1 << (floor_log2_wide ((int) (align / 8)))) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (floor_log2_wide ((int) (align / 8)))); };
 }
      else
 {
   (0);
 }
    }


  do { fprintf (asm_out_file, ".%s%d:\n", "LC", labelno); } while (0);


  output_constant (exp,
     (((n64_enum_tree_code) (exp)->common.code) == STRING_CST
      ? ((exp)->string.length)
      : int_size_in_bytes (((exp)->common.type))));

}
static struct n64_tag_constant_descriptor **const_rtx_hash_table;






struct n64_tag_pool_constant
{
  struct n64_tag_constant_descriptor *desc;
  struct n64_tag_pool_constant *next;
  n64_enum_machine_mode mode;
  rtx constant;
  int labelno;
  int align;
  int offset;
};



static struct n64_tag_pool_constant *first_pool, *last_pool;




static int pool_offset;




struct n64_tag_pool_sym
{
  char *label;
  struct n64_tag_pool_constant *pool;
  struct n64_tag_pool_sym *next;
};

static struct n64_tag_pool_sym **const_rtx_sym_hash_table;
void
init_const_rtx_hash_table(void) asm("_init_const_rtx_hash_table");
void
init_const_rtx_hash_table(void)
{
  const_rtx_hash_table
    = ((struct n64_tag_constant_descriptor **)
       oballoc (61 * sizeof (struct n64_tag_constant_descriptor *)));
  const_rtx_sym_hash_table
    = ((struct n64_tag_pool_sym **)
       oballoc (61 * sizeof (struct n64_tag_pool_sym *)));
  memset ((char *) const_rtx_hash_table,0,61 * sizeof (struct n64_tag_constant_descriptor *))
                                                             ;
  memset ((char *) const_rtx_sym_hash_table,0,61 * sizeof (struct n64_tag_pool_sym *))
                                                  ;

  first_pool = last_pool = 0;
  pool_offset = 0;
}



void
save_varasm_status(struct n64_tag_function *p) asm("_save_varasm_status");
void
save_varasm_status(struct n64_tag_function *p)
{
  p->const_rtx_hash_table = const_rtx_hash_table;
  p->const_rtx_sym_hash_table = const_rtx_sym_hash_table;
  p->first_pool = first_pool;
  p->last_pool = last_pool;
  p->pool_offset = pool_offset;
}

void
restore_varasm_status(struct n64_tag_function *p) asm("_restore_varasm_status");
void
restore_varasm_status(struct n64_tag_function *p)
{
  const_rtx_hash_table = p->const_rtx_hash_table;
  const_rtx_sym_hash_table = p->const_rtx_sym_hash_table;
  first_pool = p->first_pool;
  last_pool = p->last_pool;
  pool_offset = p->pool_offset;
}

enum n64_cpp_enum_kind{ RTX_DOUBLE, RTX_INT };
typedef __underlying_type(enum n64_cpp_enum_kind) n64_enum_kind;


struct n64_tag_rtx_const
{

  unsigned int kind : 16;
  unsigned int mode : 16;




  union {
    union n64_tag_real_extract du;
    struct n64_tag_addr_const addr;
    struct {int high, low;} di;
  } un;
};





static void
decode_rtx_const(n64_enum_machine_mode mode, rtx x, struct n64_tag_rtx_const *value) asm("_decode_rtx_const");
static void
decode_rtx_const(n64_enum_machine_mode mode, rtx x, struct n64_tag_rtx_const *value)
{


  {
    int *p = (int *) value;
    int *end = (int *) (value + 1);
    while (p < end)
      *p++ = 0;
  }

  value->kind = RTX_INT;
  value->mode = mode;

  switch (((x)->code))
    {
    case CONST_DOUBLE:
      value->kind = RTX_DOUBLE;
      if (((x)->mode) != VOIDmode)
 {
   value->mode = ((x)->mode);
   memcpy ((char *) &value->un.du,(char *) &((x)->fld[2].rtwint),sizeof value->un.du)
                                               ;
 }
      else
 {
   value->un.di.low = ((x)->fld[2].rtwint);
   value->un.di.high = ((x)->fld[3].rtwint);
 }
      break;

    case CONST_INT:
      value->un.addr.offset = ((x)->fld[0].rtwint);
      break;

    case SYMBOL_REF:
    case LABEL_REF:
    case PC:
      value->un.addr.base = x;
      break;

    case CONST:
      x = ((x)->fld[0].rtx);
      if (((x)->code) == PLUS)
 {
   value->un.addr.base = ((x)->fld[0].rtx);
   if (((((x)->fld[1].rtx))->code) != CONST_INT)
     abort ();
   value->un.addr.offset = ((((x)->fld[1].rtx))->fld[0].rtwint);
 }
      else if (((x)->code) == MINUS)
 {
   value->un.addr.base = ((x)->fld[0].rtx);
   if (((((x)->fld[1].rtx))->code) != CONST_INT)
     abort ();
   value->un.addr.offset = - ((((x)->fld[1].rtx))->fld[0].rtwint);
 }
      else
 abort ();
      break;

    default:
      abort ();
    }

  if (value->kind == RTX_INT && value->un.addr.base != 0)
    switch (((value->un.addr.base)->code))
      {
      case SYMBOL_REF:
      case LABEL_REF:



 value->un.addr.base = ((value->un.addr.base)->fld[0].rtx);
      }
}




rtx
simplify_subtraction(rtx x) asm("_simplify_subtraction");
rtx
simplify_subtraction(rtx x)
{
  struct n64_tag_rtx_const val0, val1;

  decode_rtx_const (((x)->mode), ((x)->fld[0].rtx), &val0);
  decode_rtx_const (((x)->mode), ((x)->fld[1].rtx), &val1);

  if (val0.un.addr.base == val1.un.addr.base)
    return gen_rtx (CONST_INT, VOIDmode, (int) (val0.un.addr.offset - val1.un.addr.offset));
  return x;
}



static int
const_hash_rtx(n64_enum_machine_mode mode, rtx x) asm("_const_hash_rtx");
static int
const_hash_rtx(n64_enum_machine_mode mode, rtx x)
{
  register int hi, i;

  struct n64_tag_rtx_const value;
  decode_rtx_const (mode, x, &value);


  hi = 0;
  for (i = 0; i < sizeof value / sizeof (int); i++)
    hi += ((int *) &value)[i];

  hi &= (1 << 30) - 1;
  hi %= 61;
  return hi;
}




static int
compare_constant_rtx(n64_enum_machine_mode mode, rtx x, struct n64_tag_constant_descriptor *desc) asm("_compare_constant_rtx");
static int
compare_constant_rtx(n64_enum_machine_mode mode, rtx x, struct n64_tag_constant_descriptor *desc)
{
  register int *p = (int *) desc->contents;
  register int *strp;
  register int len;
  struct n64_tag_rtx_const value;

  decode_rtx_const (mode, x, &value);
  strp = (int *) &value;
  len = sizeof value / sizeof (int);


  while (--len >= 0)
    if (*p++ != *strp++)
      return 0;

  return 1;
}




static struct n64_tag_constant_descriptor *
record_constant_rtx(n64_enum_machine_mode mode, rtx x) asm("_record_constant_rtx");
static struct n64_tag_constant_descriptor *
record_constant_rtx(n64_enum_machine_mode mode, rtx x)
{
  struct n64_tag_constant_descriptor *ptr;
  char *label;
  struct n64_tag_rtx_const value;

  decode_rtx_const (mode, x, &value);




  __extension__ ({ struct n64_tag_obstack *__o = (saveable_obstack); int __len = (sizeof ptr); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (&ptr),__len); __o->next_free += __len; } (void) 0; });
  __extension__ ({ struct n64_tag_obstack *__o = (saveable_obstack); int __len = (sizeof label); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (&label),__len); __o->next_free += __len; } (void) 0; });


  __extension__ ({ struct n64_tag_obstack *__o = (saveable_obstack); int __len = (sizeof value); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (&value),__len); __o->next_free += __len; } (void) 0; });

  return (struct n64_tag_constant_descriptor *) __extension__ ({ struct n64_tag_obstack *__o1 = (saveable_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
}




rtx
force_const_mem(n64_enum_machine_mode mode, rtx x) asm("_force_const_mem");
rtx
force_const_mem(n64_enum_machine_mode mode, rtx x)
{
  register int hash;
  register struct n64_tag_constant_descriptor *desc;
  char label[256];
  char *found = 0;
  rtx def;
  if (outer_function_chain == 0)
    if (((x)->code) == CONST_DOUBLE
 && ((((x)->fld[0].rtx))->code) == MEM
 && ((((x)->fld[0].rtx))->mode) == mode)
      return ((x)->fld[0].rtx);





  hash = const_hash_rtx (mode, x);

  for (desc = const_rtx_hash_table[hash]; desc; desc = desc->next)
    if (compare_constant_rtx (mode, x, desc))
      {
 found = desc->label;
 break;
      }

  if (found == 0)
    {
      register struct n64_tag_pool_constant *pool;
      register struct n64_tag_pool_sym *sym;
      int align;






      desc = record_constant_rtx (mode, x);
      desc->next = const_rtx_hash_table[hash];
      const_rtx_hash_table[hash] = desc;


      align = (mode == VOIDmode) ? ((target_flags & 0x00002000) ? 8 : 4) : (mode_size[(int)(mode)]);
      if (align > 64 / 8)
 align = 64 / 8;

      pool_offset += align - 1;
      pool_offset &= ~ (align - 1);






      if (rtl_obstack != saveable_obstack
   && ((x)->code) == CONST)
 {
   push_obstacks_nochange ();
   rtl_in_saveable_obstack ();

   x = gen_rtx (CONST, ((x)->mode),
         gen_rtx (PLUS, ((x)->mode),
    ((((x)->fld[0].rtx))->fld[0].rtx), ((((x)->fld[0].rtx))->fld[1].rtx)));
   pop_obstacks ();
 }



      pool = (struct n64_tag_pool_constant *) savealloc (sizeof (struct n64_tag_pool_constant));
      pool->desc = desc;
      pool->constant = x;
      pool->mode = mode;
      pool->labelno = const_labelno;
      pool->align = align;
      pool->offset = pool_offset;
      pool->next = 0;

      if (last_pool == 0)
 first_pool = pool;
      else
 last_pool->next = pool;

      last_pool = pool;
      pool_offset += (mode_size[(int)(mode)]);


      do { sprintf (label, "*.%s%d", "LC", const_labelno); } while (0);

      ++const_labelno;

      desc->label = found
 = (char *) __extension__ ({ struct n64_tag_obstack *__h = (saveable_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });


      hash = ((((int) (found)) & ((1 << 30) - 1)) % 61);
      sym = (struct n64_tag_pool_sym *) savealloc (sizeof (struct n64_tag_pool_sym));
      sym->label = found;
      sym->pool = pool;
      sym->next = const_rtx_sym_hash_table[hash];
      const_rtx_sym_hash_table[hash] = sym;
    }



  def = gen_rtx (MEM, mode, gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), found));

  ((def)->unchanging) = 1;

  ((((def)->fld[0].rtx))->unchanging) = 1;
  current_function_uses_const_pool = 1;

  if (outer_function_chain == 0)
    if (((x)->code) == CONST_DOUBLE)
      {
 if (((x)->fld[0].rtx) == cc0_rtx)
   {
     ((x)->fld[1].rtx) = const_double_chain;
     const_double_chain = x;
   }
 ((x)->fld[0].rtx) = def;
      }

  return def;
}




static struct n64_tag_pool_constant *
find_pool_constant(rtx addr) asm("_find_pool_constant");
static struct n64_tag_pool_constant *
find_pool_constant(rtx addr)
{
  struct n64_tag_pool_sym *sym;
  char *label = ((addr)->fld[0].rtstr);

  for (sym = const_rtx_sym_hash_table[((((int) (label)) & ((1 << 30) - 1)) % 61)]; sym; sym = sym->next)
    if (sym->label == label)
      return sym->pool;

  abort ();
}



rtx
get_pool_constant(rtx addr) asm("_get_pool_constant");
rtx
get_pool_constant(rtx addr)
{
  return (find_pool_constant (addr))->constant;
}



n64_enum_machine_mode
get_pool_mode(rtx addr) asm("_get_pool_mode");
n64_enum_machine_mode
get_pool_mode(rtx addr)
{
  return (find_pool_constant (addr))->mode;
}



int
get_pool_offset(rtx addr) asm("_get_pool_offset");
int
get_pool_offset(rtx addr)
{
  return (find_pool_constant (addr))->offset;
}



int
get_pool_size(void) asm("_get_pool_size");
int
get_pool_size(void)
{
  return pool_offset;
}



void
output_constant_pool(char *fnname, tree fndecl) asm("_output_constant_pool");
void
output_constant_pool(char *fnname, tree fndecl)
{
  struct n64_tag_pool_constant *pool;
  rtx x;
  union n64_tag_real_extract u;





  for (pool = first_pool; pool; pool = pool->next)
    {
      x = pool->constant;






      if (((((x)->code) == LABEL_REF
     && (((((x)->fld[0].rtx))->volatil)
  || ((((x)->fld[0].rtx))->code) == NOTE)))
   || (((x)->code) == CONST && ((((x)->fld[0].rtx))->code) == PLUS
       && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == LABEL_REF
       && (((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->volatil)
    || ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->code) == NOTE)))
 x = const0_rtx;



      const_section();
      if (pool->align > 1)
 { int mask = (1 << (exact_log2_wide ((int) (pool->align)))) - 1; fprintf (asm_out_file, "\t.align\t%d\n", (exact_log2_wide ((int) (pool->align)))); };


      do { fprintf (asm_out_file, ".%s%d:\n", "LC", pool->labelno); } while (0);


      switch ((mode_class[(int)(pool->mode)]))
 {
 case MODE_FLOAT:
   if (((x)->code) != CONST_DOUBLE)
     abort ();

   memcpy ((char *) &u,(char *) &((x)->fld[2].rtwint),sizeof u);
   assemble_real (u.d, pool->mode);
   break;

 case MODE_INT:
 case MODE_PARTIAL_INT:
   assemble_integer (x, (mode_size[(int)(pool->mode)]), 1);
   break;

 default:
   abort ();
 }

    done: ;
    }


  first_pool = last_pool = 0;
}





static int
output_addressed_constants(tree exp) asm("_output_addressed_constants");
static int
output_addressed_constants(tree exp)
{
  int reloc = 0;

  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case ADDR_EXPR:
      {
 register tree constant = ((exp)->exp.operands[0]);

 while (((n64_enum_tree_code) (constant)->common.code) == COMPONENT_REF)
   {
     constant = ((constant)->exp.operands[0]);
   }

 if ((*tree_code_type[(int) (((n64_enum_tree_code) (constant)->common.code))]) == 'c'
     || ((n64_enum_tree_code) (constant)->common.code) == CONSTRUCTOR)


   output_constant_def (constant);
      }
      reloc = 1;
      break;

    case PLUS_EXPR:
    case MINUS_EXPR:
      reloc = output_addressed_constants (((exp)->exp.operands[0]));
      reloc |= output_addressed_constants (((exp)->exp.operands[1]));
      break;

    case NOP_EXPR:
    case CONVERT_EXPR:
    case NON_LVALUE_EXPR:
      reloc = output_addressed_constants (((exp)->exp.operands[0]));
      break;

    case CONSTRUCTOR:
      {
 register tree link;
 for (link = ((exp)->exp.operands[1]); link; link = ((link)->common.chain))
   if (((link)->list.value) != 0)
     reloc |= output_addressed_constants (((link)->list.value));
      }
      break;

    case ERROR_MARK:
      break;
    }
  return reloc;
}
void
output_constant(register tree exp, register int size) asm("_output_constant");
void
output_constant(register tree exp, register int size)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (((exp)->common.type))->common.code);
  rtx x;

  if (size == 0)
    return;




  while ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
   && (((exp)->common.type) == ((((exp)->exp.operands[0]))->common.type)
       || (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)))
  || ((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR)
    exp = ((exp)->exp.operands[0]);



  if (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR && ((exp)->exp.operands[1]) == 0)
    {
      if (output_bytecode)
 bc_emit_const_skip (size);
      else
 assemble_zeros (size);
      return;
    }

  switch (code)
    {
    case CHAR_TYPE:
    case BOOLEAN_TYPE:
    case INTEGER_TYPE:
    case ENUMERAL_TYPE:
    case POINTER_TYPE:
    case REFERENCE_TYPE:

      while (((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR
      || ((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR)
 exp = ((exp)->exp.operands[0]);

      if (! assemble_integer (expand_expr (exp, (rtx) 0, VOIDmode,
        EXPAND_INITIALIZER),
         size, 0))
 error ("initializer for integer value is too complicated");
      size = 0;
      break;

    case REAL_TYPE:
      if (((n64_enum_tree_code) (exp)->common.code) != REAL_CST)
 error ("initializer for floating value is not a floating constant");

      assemble_real (((exp)->real_cst.real_cst),
       mode_for_size (size * 8, MODE_FLOAT, 0));
      size = 0;
      break;

    case COMPLEX_TYPE:
      output_constant (((exp)->complex.real), size / 2);
      output_constant (((exp)->complex.imag), size / 2);
      size -= (size / 2) * 2;
      break;

    case ARRAY_TYPE:
      if (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR)
 {
   output_constructor (exp, size);
   return;
 }
      else if (((n64_enum_tree_code) (exp)->common.code) == STRING_CST)
 {
   int excess = 0;

   if (size > ((exp)->string.length))
     {
       excess = size - ((exp)->string.length);
       size = ((exp)->string.length);
     }

   assemble_string (((exp)->string.pointer), size);
   size = excess;
 }
      else
 abort ();
      break;

    case RECORD_TYPE:
    case UNION_TYPE:
      if (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR)
 output_constructor (exp, size);
      else
 abort ();
      return;

    case SET_TYPE:
      if (((n64_enum_tree_code) (exp)->common.code) == INTEGER_CST)
 assemble_integer (expand_expr (exp, (rtx) 0,
           VOIDmode, EXPAND_INITIALIZER),
     size, 1);
      else if (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR)
 {
   unsigned char *buffer = (unsigned char *) 
                                            __builtin_alloca((
                                            size
                                            ))
                                                         ;
   if (get_set_constructor_bytes (exp, buffer, size))
     abort ();
   assemble_string ((char *) buffer, size);
 }
      else
 error ("unknown set constructor type");
      return;
    }

  if (size > 0)
    assemble_zeros (size);
}



static void
bc_assemble_integer(tree exp, int size) asm("_bc_assemble_integer");
static void
bc_assemble_integer(tree exp, int size)
{
  tree const_part;
  tree addr_part;
  tree tmp;






  exp = fold (exp);

  while (((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR)
    exp = ((exp)->exp.operands[0]);
  if (((n64_enum_tree_code) (exp)->common.code) == INTEGER_CST)
    {
      const_part = exp;
      addr_part = 0;
    }
  else if (((n64_enum_tree_code) (exp)->common.code) == PLUS_EXPR)
    {
      const_part = ((exp)->exp.operands[0]);
      while (((n64_enum_tree_code) (const_part)->common.code) == NOP_EXPR
      || ((n64_enum_tree_code) (const_part)->common.code) == CONVERT_EXPR)
 const_part = ((const_part)->exp.operands[0]);
      addr_part = ((exp)->exp.operands[1]);
      while (((n64_enum_tree_code) (addr_part)->common.code) == NOP_EXPR
      || ((n64_enum_tree_code) (addr_part)->common.code) == CONVERT_EXPR)
 addr_part = ((addr_part)->exp.operands[0]);
      if (((n64_enum_tree_code) (const_part)->common.code) != INTEGER_CST)
 tmp = const_part, const_part = addr_part, addr_part = tmp;
      if (((n64_enum_tree_code) (const_part)->common.code) != INTEGER_CST
   || ((n64_enum_tree_code) (addr_part)->common.code) != ADDR_EXPR)
 abort ();

    }
  else if (((n64_enum_tree_code) (exp)->common.code) == ADDR_EXPR)
    {
      const_part = integer_zero_node;
      addr_part = exp;
    }
  else
    abort ();

  if (addr_part == 0)
    {
      if (size == 1)
 {
   char c = ((const_part)->int_cst.int_cst_low);
   bc_emit (&c, 1);
   size -= 1;
 }
      else if (size == 2)
 {
   short s = ((const_part)->int_cst.int_cst_low);
   bc_emit ((char *) &s, 2);
   size -= 2;
 }
      else if (size == 4)
 {
   int i = ((const_part)->int_cst.int_cst_low);
   bc_emit ((char *) &i, 4);
   size -= 4;
 }
      else if (size == 8)
 {
   if (((target_flags & 0x00010000) != 0))
     {
       int i = ((const_part)->int_cst.int_cst_high);
       bc_emit ((char *) &i, 4);
       i = ((const_part)->int_cst.int_cst_low);
       bc_emit ((char *) &i, 4);
     }
   else
     {
       int i = ((const_part)->int_cst.int_cst_low);
       bc_emit ((char *) &i, 4);
       i = ((const_part)->int_cst.int_cst_high);
       bc_emit ((char *) &i, 4);
     }
   size -= 8;
 }
    }
  else
    if (size == 4
 && ((n64_enum_tree_code) (((addr_part)->exp.operands[0]))->common.code) == VAR_DECL)
      bc_emit_labelref (((((((addr_part)->exp.operands[0]))->decl.assembler_name))->identifier.pointer)
                                                      ,
   ((const_part)->int_cst.int_cst_low));
    else
      abort ();
}





static void
output_constructor(tree exp, int size) asm("_output_constructor");
static void
output_constructor(tree exp, int size)
{
  register tree link, field = 0;
  int min_index = 0;


  int total_bytes = 0;

  int byte_buffer_in_use = 0;
  register int byte;

  if (32 < 8)
    abort ();

  if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE)
    field = ((((exp)->common.type))->type.values);

  if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE
      && ((((exp)->common.type))->type.values) != 0)
    min_index
      = ((((((((exp)->common.type))->type.values))->type.minval))->int_cst.int_cst_low);






  for (link = ((exp)->exp.operands[1]);
       link;
       link = ((link)->common.chain),
       field = field ? ((field)->common.chain) : 0)
    {
      tree val = ((link)->list.value);
      tree strchr = 0;



      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE)
 {

   if (((link)->list.purpose) != 0)
     field = ((link)->list.purpose);
 }

      if (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE)
 strchr = ((link)->list.purpose);


      if (val != 0)
 while ((((n64_enum_tree_code) (val)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (val)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (val)->common.code) == NON_LVALUE_EXPR) && (((((val)->common.type))->type.mode) == ((((((val)->exp.operands[0]))->common.type))->type.mode))) (val) = ((val)->exp.operands[0]);;

      if (field == 0 || !((field)->decl.bit_field_flag))
 {


   register int fieldsize;


   int bitpos = (field ? (((((field)->decl.arguments))->int_cst.int_cst_low)
     / 8)
   : 0);
   if (strchr != 0)
     bitpos = (((((((val)->common.type))->type.size))->int_cst.int_cst_low)
        / 8
        * (((strchr)->int_cst.int_cst_low) - min_index));


   if (byte_buffer_in_use)
     {
       fprintf (asm_out_file, "\t.byte\t0x%x\n", (byte));
       total_bytes++;
       byte_buffer_in_use = 0;
     }




   if ((field != 0 || strchr != 0) && bitpos != total_bytes)
     {
       if (!output_bytecode)
  assemble_zeros (bitpos - total_bytes);
       else
  bc_emit_const_skip (bitpos - total_bytes);
       total_bytes = bitpos;
     }


   if (field)
     {
       if (((n64_enum_tree_code) (((field)->decl.size))->common.code) != INTEGER_CST)
  abort ();
       if (((((field)->decl.size))->int_cst.int_cst_low) > 100000)
  {

    tree size_tree = size_binop (CEIL_DIV_EXPR,
            ((field)->decl.size),
            size_int (8));
    fieldsize = ((size_tree)->int_cst.int_cst_low);
  }
       else
  {
    fieldsize = ((((field)->decl.size))->int_cst.int_cst_low);
    fieldsize = (fieldsize + 8 - 1) / 8;
  }
     }
   else
     fieldsize = int_size_in_bytes (((((exp)->common.type))->common.type));


   if (val == 0)
     assemble_zeros (fieldsize);
   else
     output_constant (val, fieldsize);


   total_bytes += fieldsize;
 }
      else if (val != 0 && ((n64_enum_tree_code) (val)->common.code) != INTEGER_CST)
 error ("invalid initial value for member `%s'",
        ((((field)->decl.name))->identifier.pointer));
      else
 {


   int next_offset = ((((field)->decl.arguments))->int_cst.int_cst_low);
   int end_offset
     = (next_offset + ((((field)->decl.size))->int_cst.int_cst_low));

   if (val == 0)
     val = integer_zero_node;



   if (next_offset / 8 != total_bytes)
     {

       if (byte_buffer_in_use)
  {
    fprintf (asm_out_file, "\t.byte\t0x%x\n", (byte));
    total_bytes++;
    byte_buffer_in_use = 0;
  }


       if (next_offset / 8 != total_bytes)
  {
    assemble_zeros (next_offset / 8 - total_bytes);
    total_bytes = next_offset / 8;
  }
     }

   if (! byte_buffer_in_use)
     byte = 0;
   while (next_offset < end_offset)
     {
       int this_time;
       int shift;
       int value;
       int next_byte = next_offset / 8;
       int next_bit = next_offset % 8;



       while (next_byte != total_bytes)
  {
    fprintf (asm_out_file, "\t.byte\t0x%x\n", (byte));
    total_bytes++;
    byte = 0;
  }



       this_time = ((end_offset - next_offset) < (8 - next_bit) ? (end_offset - next_offset) : (8 - next_bit))
                                   ;
       if (((target_flags & 0x00010000) != 0))
  {



    shift = end_offset - next_offset - this_time;


    if (shift < 32
        && shift + this_time > 32)
      {
        this_time -= (32 - shift);
        shift = 32;
      }


    if (shift < 32)
      {
        value = ((val)->int_cst.int_cst_low);
      }
    else if (shift < 2 * 32)
      {
        value = ((val)->int_cst.int_cst_high);
        shift -= 32;
      }
    else
      abort ();
    byte |= (((value >> shift)
       & (((int) 1 << this_time) - 1))
      << (8 - this_time - next_bit));
  }
       else
  {




    shift = (next_offset
      - ((((field)->decl.arguments))->int_cst.int_cst_low));


    if (shift < 32
        && shift + this_time > 32)
      {
        this_time -= (32 - shift);
        shift = 32;
      }


    if (shift < 32)
      value = ((val)->int_cst.int_cst_low);
    else if (shift < 2 * 32)
      {
        value = ((val)->int_cst.int_cst_high);
        shift -= 32;
      }
    else
      abort ();
    byte |= (((value >> shift)
       & (((int) 1 << this_time) - 1))
      << next_bit);
  }
       next_offset += this_time;
       byte_buffer_in_use = 1;
     }
 }
    }
  if (byte_buffer_in_use)
    {
      fprintf (asm_out_file, "\t.byte\t0x%x\n", (byte));
      total_bytes++;
    }
  if (total_bytes < size)
    assemble_zeros (size - total_bytes);
}


void
handle_pragma_weak(n64_enum_pragma_state what, char *name, char *value) asm("_handle_pragma_weak");
void
handle_pragma_weak(n64_enum_pragma_state what, char *name, char *value)
{

  if (what == ps_name || what == ps_value)
    {
      struct n64_tag_weak_syms *weak =
 (struct n64_tag_weak_syms *)permalloc (sizeof (struct n64_tag_weak_syms));
      weak->next = weak_decls;
      weak->name = permalloc (strlen (name) + 1);
      strcpy (weak->name, name);

      if (what != ps_value)
 weak->value = ((void *)0);

      else
 {
   weak->value = permalloc (strlen (value) + 1);
   strcpy (weak->value, value);
 }

      weak_decls = weak;
    }
  else if (! (what == ps_done || what == ps_start))
    warning ("malformed `#pragma weak'");

}



void
declare_weak(tree decl) asm("_declare_weak");
void
declare_weak(tree decl)
{
  if (! ((decl)->common.public_flag))
    error_with_decl (decl, "weak declaration of `%s' must be public");
  else if (((decl)->common.asm_written_flag))
    error_with_decl (decl, "weak declaration of `%s' must precede definition");
  else if (1)
    ((decl)->decl.weak_flag) = 1;
}



void
weak_finish(void) asm("_weak_finish");
void
weak_finish(void)
{

  if (1)
    {
      struct n64_tag_weak_syms *t;
      for (t = weak_decls; t; t = t->next)
 {
   do { fputs ("\t.weak\t", asm_out_file); assemble_name (asm_out_file, t->name); fputc ('\n', asm_out_file); } while (0);
   if (t->value)
     do { fprintf ((asm_out_file), "\t%s\t", ".set"); assemble_name (asm_out_file, t->name); fprintf (asm_out_file, ","); assemble_name (asm_out_file, t->value); fprintf (asm_out_file, "\n"); } while (0);
 }
    }

}

void
assemble_alias(tree decl, tree target) asm("_assemble_alias");
void
assemble_alias(tree decl, tree target)
{

  char *name;

  make_decl_rtl (decl, (char*)0, 1);
  name = ((((((decl)->decl.rtl))->fld[0].rtx))->fld[0].rtstr);



  if (((decl)->common.public_flag))
    {

      if (((decl)->decl.weak_flag))
 do { fputs ("\t.weak\t", asm_out_file); assemble_name (asm_out_file, name); fputc ('\n', asm_out_file); } while (0);
      else

      if (output_bytecode)
 (0);
      else
 do { fputs ("\t.globl\t", asm_out_file); assemble_name (asm_out_file, name); fputs ("\n", asm_out_file); } while (0);
    }

  do { fprintf ((asm_out_file), "\t%s\t", ".set"); assemble_name (asm_out_file, name); fprintf (asm_out_file, ","); assemble_name (asm_out_file, ((target)->identifier.pointer)); fprintf (asm_out_file, "\n"); } while (0);
  ((decl)->common.asm_written_flag) = 1;



}

