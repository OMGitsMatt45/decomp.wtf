// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/c-decl.c
/* Process declarations and variables for C compiler.
   Copyright (C) 1988, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int print_node(...) asm("_print_node");
extern int push_function_context(...) asm("_push_function_context");
extern int output_inline_function(...) asm("_output_inline_function");
extern int pop_function_context(...) asm("_pop_function_context");
extern int remember_end_note(...) asm("_remember_end_note");
extern int error_with_decl(...) asm("_error_with_decl");
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int push_obstacks(...) asm("_push_obstacks");
extern int pedwarn_with_decl(...) asm("_pedwarn_with_decl");
extern int error(...) asm("_error");
extern int warning(...) asm("_warning");
extern int pedwarn(...) asm("_pedwarn");
extern int pedwarn_with_file_and_line(...) asm("_pedwarn_with_file_and_line");
extern int chain_member(...) asm("_chain_member");
extern int rest_of_decl_compilation(...) asm("_rest_of_decl_compilation");
extern int label_rtx(...) asm("_label_rtx");
extern int error_with_file_and_line(...) asm("_error_with_file_and_line");
extern int start_identifier_warnings(...) asm("_start_identifier_warnings");
extern int init_iterators(...) asm("_init_iterators");
extern int expand_decl(...) asm("_expand_decl");
extern int temporary_allocation(...) asm("_temporary_allocation");
extern int preserve_initializer(...) asm("_preserve_initializer");
extern int min_precision(...) asm("_min_precision");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int announce_function(...) asm("_announce_function");
extern int warning_with_file_and_line(...) asm("_warning_with_file_and_line");
extern int init_function_start(...) asm("_init_function_start");
extern int mark_varargs(...) asm("_mark_varargs");
extern int expand_function_start(...) asm("_expand_function_start");
extern int expand_main_function(...) asm("_expand_main_function");
extern int setjmp_protect(...) asm("_setjmp_protect");
extern int setjmp_protect_args(...) asm("_setjmp_protect_args");
extern int expand_function_end(...) asm("_expand_function_end");
extern int rest_of_compilation(...) asm("_rest_of_compilation");
struct n64_tag_binding_level;
struct n64_tag_c_function;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");
extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");
extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;
extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus, limbo_value;
};
extern int pedantic;
struct n64_tag_lang_type
{
  int len;
  tree elts[1];
};
extern tree lookup_interface (tree) asm("_lookup_interface");
extern tree is_class_name (tree) asm("_is_class_name");
extern void maybe_objc_check_decl (tree) asm("_maybe_objc_check_decl");
extern int maybe_objc_comptypes (tree, tree, int) asm("_maybe_objc_comptypes");
extern tree maybe_building_objc_message_expr (void) asm("_maybe_building_objc_message_expr");
extern tree maybe_objc_method_name (tree) asm("_maybe_objc_method_name");
extern int recognize_objc_keyword (void) asm("_recognize_objc_keyword");
extern tree build_objc_string (int, char *) asm("_build_objc_string");


extern void gen_aux_info_record (tree, int, int, int) asm("_gen_aux_info_record");


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree convert (tree, tree) asm("_convert");



extern tree char_array_type_node;
extern tree char_type_node;
extern tree const_ptr_type_node;
extern tree const_string_type_node;
extern tree default_function_type;
extern tree double_ftype_double;
extern tree double_ftype_double_double;
extern tree double_type_node;
extern tree float_type_node;
extern tree intDI_type_node;
extern tree intHI_type_node;
extern tree intQI_type_node;
extern tree intSI_type_node;
extern tree int_array_type_node;
extern tree int_ftype_cptr_cptr_sizet;
extern tree int_ftype_int;
extern tree int_ftype_ptr_ptr_int;
extern tree int_ftype_string_string;
extern tree integer_type_node;
extern tree long_double_type_node;
extern tree long_ftype_long;
extern tree long_integer_type_node;
extern tree long_long_integer_type_node;
extern tree long_long_unsigned_type_node;
extern tree long_unsigned_type_node;
extern tree complex_integer_type_node;
extern tree complex_float_type_node;
extern tree complex_double_type_node;
extern tree complex_long_double_type_node;
extern tree ptr_type_node;
extern tree ptrdiff_type_node;
extern tree short_integer_type_node;
extern tree short_unsigned_type_node;
extern tree signed_char_type_node;
extern tree signed_wchar_type_node;
extern tree string_ftype_ptr_ptr;
extern tree string_type_node;
extern tree unsigned_char_type_node;
extern tree unsigned_intDI_type_node;
extern tree unsigned_intHI_type_node;
extern tree unsigned_intQI_type_node;
extern tree unsigned_intSI_type_node;
extern tree unsigned_type_node;
extern tree unsigned_wchar_type_node;
extern tree void_ftype_ptr_int_int;
extern tree void_ftype_ptr_ptr_int;
extern tree void_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node;
extern tree boolean_type_node;
extern tree boolean_true_node;
extern tree boolean_false_node;

extern tree build_enumerator (tree, tree) asm("_build_enumerator");

extern tree builtin_function (char *, tree, n64_enum_built_in_function function_, char *) asm("_builtin_function");

extern tree c_build_type_variant (tree, int, int) asm("_c_build_type_variant");
extern int c_decode_option (char *) asm("_c_decode_option");
extern void c_mark_varargs (void) asm("_c_mark_varargs");
extern tree check_identifier (tree, tree) asm("_check_identifier");
extern void clear_parm_order (void) asm("_clear_parm_order");
extern tree combine_parm_decls (tree, tree, int) asm("_combine_parm_decls");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern void declare_parm_level (int) asm("_declare_parm_level");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void delete_block (tree) asm("_delete_block");
extern void finish_decl (tree, tree, tree) asm("_finish_decl");
extern void finish_decl_top_level (tree, tree, tree) asm("_finish_decl_top_level");
extern tree finish_enum (tree, tree, tree) asm("_finish_enum");
extern void finish_function (int) asm("_finish_function");
extern tree finish_struct (tree, tree, tree) asm("_finish_struct");
extern tree get_parm_info (int) asm("_get_parm_info");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern int global_bindings_p (void) asm("_global_bindings_p");
extern tree grokfield (char *, int, tree, tree, tree) asm("_grokfield");
extern tree groktypename (tree) asm("_groktypename");
extern tree groktypename_in_parm_context (tree) asm("_groktypename_in_parm_context");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern int in_parm_level_p (void) asm("_in_parm_level_p");
extern void init_decl_processing (void) asm("_init_decl_processing");
extern void insert_block (tree) asm("_insert_block");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree lookup_name (tree) asm("_lookup_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern tree lookup_name_current_level_global (tree) asm("_lookup_name_current_level_global");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void parmlist_tags_warning (void) asm("_parmlist_tags_warning");
extern void pending_xref_error (void) asm("_pending_xref_error");
extern void pop_c_function_context (void) asm("_pop_c_function_context");
extern void pop_label_level (void) asm("_pop_label_level");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void print_lang_decl (...) asm("_print_lang_decl")
                 ;
extern void print_lang_identifier (...) asm("_print_lang_identifier")
                 ;
extern void print_lang_type (...) asm("_print_lang_type")
                 ;
extern void push_c_function_context (void) asm("_push_c_function_context");
extern void push_label_level (void) asm("_push_label_level");
extern void push_parm_decl (tree) asm("_push_parm_decl");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void pushlevel (int) asm("_pushlevel");
extern void pushtag (tree, tree) asm("_pushtag");
extern void set_block (tree) asm("_set_block");
extern tree shadow_label (tree) asm("_shadow_label");
extern void shadow_record_fields (tree) asm("_shadow_record_fields");
extern void shadow_tag (tree) asm("_shadow_tag");
extern void shadow_tag_warned (tree, int) asm("_shadow_tag_warned");
extern tree start_enum (tree) asm("_start_enum");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function")
                        ;
extern tree start_decl (tree, tree, int, tree, tree) asm("_start_decl")
                         ;
extern tree start_struct (n64_enum_tree_code, tree) asm("_start_struct");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern tree xref_tag (n64_enum_tree_code, tree) asm("_xref_tag");


extern tree require_complete_type (tree) asm("_require_complete_type");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");


extern tree common_type (tree, tree) asm("_common_type");
extern int comptypes (tree, tree) asm("_comptypes");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_size_in_bytes (tree) asm("_c_size_in_bytes");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree c_alignof_expr (tree) asm("_c_alignof_expr");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_component_ref (tree, tree) asm("_build_component_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree parser_build_binary_op (n64_enum_tree_code, tree, tree) asm("_parser_build_binary_op")
                         ;
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op")
                              ;
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op")
                        ;
extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern void readonly_warning (tree, char *) asm("_readonly_warning");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_c_cast (tree, tree) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr")
                   ;
extern tree initializer_constant_valid_p (tree, tree) asm("_initializer_constant_valid_p");
extern void store_init_value (tree, tree) asm("_store_init_value");
extern void error_init (char *, char *, char *) asm("_error_init")
                     ;
extern void pedwarn_init (char *, char *, char *) asm("_pedwarn_init")
                     ;
extern void start_init (tree, tree, int) asm("_start_init");
extern void finish_init (void) asm("_finish_init");
extern void really_start_incremental_init (tree) asm("_really_start_incremental_init");
extern void push_init_level (int) asm("_push_init_level");
extern tree pop_init_level (int) asm("_pop_init_level");
extern void set_init_index (tree, tree) asm("_set_init_index");
extern void set_init_label (tree) asm("_set_init_label");
extern void process_init_element (tree) asm("_process_init_element");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands")
                               ;
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");


extern void iterator_expand (tree) asm("_iterator_expand");
extern void iterator_for_loop_start (tree) asm("_iterator_for_loop_start");
extern void iterator_for_loop_end (tree) asm("_iterator_for_loop_end");
extern void iterator_for_loop_record (tree) asm("_iterator_for_loop_record");
extern void push_iterator_stack (void) asm("_push_iterator_stack");
extern void pop_iterator_stack (void) asm("_pop_iterator_stack");




extern int current_function_returns_value;




extern int current_function_returns_null;



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_no_ident;



extern int warn_implicit;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;




extern int warn_redundant_decls;







extern int warn_nested_externs;




extern int warn_cast_qual;





extern int warn_bad_function_cast;



extern int warn_traditional;



extern int warn_format;



extern int warn_char_subscripts;



extern int warn_conversion;



extern int flag_traditional;



extern int flag_allow_single_precision;



extern int warn_parentheses;



extern int warn_missing_braces;




extern int (*comptypes_record_hook)(...);



extern int system_header_p;



extern int doing_objc_thang;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_CHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,
  RID_UNUSED1,

  RID_UNSIGNED,
  RID_SHORT,
  RID_LONG,
  RID_AUTO,
  RID_STATIC,
  RID_EXTERN,
  RID_REGISTER,
  RID_TYPEDEF,
  RID_SIGNED,
  RID_CONST,
  RID_VOLATILE,
  RID_INLINE,
  RID_NOALIAS,
  RID_ITERATOR,
  RID_COMPLEX,

  RID_IN,
  RID_OUT,
  RID_INOUT,
  RID_BYCOPY,
  RID_ONEWAY,
  RID_ID,

  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;

extern tree make_pointer_declarator(...) asm("_make_pointer_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern int yylex(void) asm("_yylex");

extern char *get_directive_line(...) asm("_get_directive_line");



enum n64_cpp_enum_decl_context{ NORMAL,
  FUNCDEF,
  PARM,
  FIELD,
  BITFIELD,
  TYPENAME};
typedef __underlying_type(enum n64_cpp_enum_decl_context) n64_enum_decl_context;

tree error_mark_node;



tree short_integer_type_node;
tree integer_type_node;
tree long_integer_type_node;
tree long_long_integer_type_node;

tree short_unsigned_type_node;
tree unsigned_type_node;
tree long_unsigned_type_node;
tree long_long_unsigned_type_node;

tree boolean_type_node;
tree boolean_false_node;
tree boolean_true_node;

tree ptrdiff_type_node;

tree unsigned_char_type_node;
tree signed_char_type_node;
tree char_type_node;
tree wchar_type_node;
tree signed_wchar_type_node;
tree unsigned_wchar_type_node;

tree float_type_node;
tree double_type_node;
tree long_double_type_node;

tree complex_integer_type_node;
tree complex_float_type_node;
tree complex_double_type_node;
tree complex_long_double_type_node;

tree intQI_type_node;
tree intHI_type_node;
tree intSI_type_node;
tree intDI_type_node;

tree unsigned_intQI_type_node;
tree unsigned_intHI_type_node;
tree unsigned_intSI_type_node;
tree unsigned_intDI_type_node;



tree void_type_node;



tree ptr_type_node, const_ptr_type_node;



tree string_type_node, const_string_type_node;




tree char_array_type_node;




tree int_array_type_node;




tree wchar_array_type_node;



tree default_function_type;



tree double_ftype_double, double_ftype_double_double;
tree int_ftype_int, long_ftype_long;
tree float_ftype_float;
tree ldouble_ftype_ldouble;



tree void_ftype_ptr_ptr_int, int_ftype_ptr_ptr_int, void_ftype_ptr_int_int;


tree string_ftype_ptr_ptr, int_ftype_string_string;


tree int_ftype_cptr_cptr_sizet;




tree integer_zero_node;
tree null_pointer_node;



tree integer_one_node;




tree pending_invalid_xref;

char *pending_invalid_xref_file;
int pending_invalid_xref_line;







static tree enum_next_value;



static int enum_overflow;




static tree last_function_parms;




static tree last_function_parm_tags;





static tree current_function_parms;


static tree current_function_parm_tags;



static char *current_function_prototype_file;
static int current_function_prototype_line;





static tree named_labels;



static tree shadowed_labels;




static int c_function_varargs;



tree current_function_decl;




int current_function_returns_value;




int current_function_returns_null;




static int warn_about_return_type;



static int current_extern_inline;
struct n64_tag_binding_level
  {



    tree names;







    tree tags;





    tree shadowed;




    tree blocks;



    tree this_block;


    struct n64_tag_binding_level *level_chain;


    char parm_flag;


    char tag_transparent;





    char subblocks_tag_transparent;


    char keep;


    char keep_if_subblocks;



    int n_incomplete;




    tree parm_order;
  };





static struct n64_tag_binding_level *current_binding_level;



static struct n64_tag_binding_level *free_binding_level;





static struct n64_tag_binding_level *global_binding_level;



static struct n64_tag_binding_level clear_binding_level
  = {
    ((void *)0)
        , 
          ((void *)0)
              , 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , (struct n64_tag_binding_level *) 
                                  ((void *)0)
                                                    , 0, 0, 0, 0, 0, 0,
     
    ((void *)0)
        };



static int keep_next_level_flag;




static int keep_next_if_subblocks;







static struct n64_tag_binding_level *label_level_chain;



tree static_ctors, static_dtors;



static tree grokparms (...) asm("_grokparms"), grokdeclarator (...) asm("_grokdeclarator");
tree pushdecl(...) asm("_pushdecl");
tree builtin_function(...) asm("_builtin_function");
void shadow_tag_warned(...) asm("_shadow_tag_warned");

static tree lookup_tag(...) asm("_lookup_tag");
static tree lookup_tag_reverse(...) asm("_lookup_tag_reverse");
tree lookup_name_current_level(...) asm("_lookup_name_current_level");
static char *redeclaration_error_message(...) asm("_redeclaration_error_message");
static void layout_array_type(...) asm("_layout_array_type");






int flag_cond_mismatch;



int flag_short_double;



int flag_no_asm;



int flag_no_builtin;




int flag_no_nonansi_builtin;



int flag_traditional;



int flag_allow_single_precision = 0;



int flag_signed_bitfields = 1;
int explicit_flag_signed_bitfields = 0;



int flag_no_ident = 0;



int warn_implicit;





int warn_write_strings;




int warn_cast_qual;





int warn_bad_function_cast;



int warn_traditional;




int warn_pointer_arith;




int warn_strict_prototypes;




int warn_missing_prototypes;




int warn_missing_declarations;




int warn_redundant_decls = 0;







int warn_nested_externs = 0;



int warn_format;



int warn_char_subscripts = 0;



int warn_conversion;



int warn_parentheses;



int warn_missing_braces;







int dollars_in_ident = 1 > 1;





int
c_decode_option(char *p) asm("_c_decode_option");
int
c_decode_option(char *p)
{
  if (!strcmp (p, "-ftraditional") || !strcmp (p, "-traditional"))
    {
      flag_traditional = 1;
      flag_writable_strings = 1;

      dollars_in_ident = 1;

    }
  else if (!strcmp (p, "-fallow-single-precision"))
    flag_allow_single_precision = 1;
  else if (!strcmp (p, "-fnotraditional") || !strcmp (p, "-fno-traditional"))
    {
      flag_traditional = 0;
      flag_writable_strings = 0;
      dollars_in_ident = 1 > 1;
    }
  else if (!strcmp (p, "-fdollars-in-identifiers"))
    {

      dollars_in_ident = 1;

    }
  else if (!strcmp (p, "-fno-dollars-in-identifiers"))
    dollars_in_ident = 0;
  else if (!strcmp (p, "-fsigned-char"))
    flag_signed_char = 1;
  else if (!strcmp (p, "-funsigned-char"))
    flag_signed_char = 0;
  else if (!strcmp (p, "-fno-signed-char"))
    flag_signed_char = 0;
  else if (!strcmp (p, "-fno-unsigned-char"))
    flag_signed_char = 1;
  else if (!strcmp (p, "-fsigned-bitfields")
    || !strcmp (p, "-fno-unsigned-bitfields"))
    {
      flag_signed_bitfields = 1;
      explicit_flag_signed_bitfields = 1;
    }
  else if (!strcmp (p, "-funsigned-bitfields")
    || !strcmp (p, "-fno-signed-bitfields"))
    {
      flag_signed_bitfields = 0;
      explicit_flag_signed_bitfields = 1;
    }
  else if (!strcmp (p, "-fshort-enums"))
    flag_short_enums = 1;
  else if (!strcmp (p, "-fno-short-enums"))
    flag_short_enums = 0;
  else if (!strcmp (p, "-fcond-mismatch"))
    flag_cond_mismatch = 1;
  else if (!strcmp (p, "-fno-cond-mismatch"))
    flag_cond_mismatch = 0;
  else if (!strcmp (p, "-fshort-double"))
    flag_short_double = 1;
  else if (!strcmp (p, "-fno-short-double"))
    flag_short_double = 0;
  else if (!strcmp (p, "-fasm"))
    flag_no_asm = 0;
  else if (!strcmp (p, "-fno-asm"))
    flag_no_asm = 1;
  else if (!strcmp (p, "-fbuiltin"))
    flag_no_builtin = 0;
  else if (!strcmp (p, "-fno-builtin"))
    flag_no_builtin = 1;
  else if (!strcmp (p, "-fno-ident"))
    flag_no_ident = 1;
  else if (!strcmp (p, "-fident"))
    flag_no_ident = 0;
  else if (!strcmp (p, "-ansi"))
    flag_no_asm = 1, flag_no_nonansi_builtin = 1, dollars_in_ident = 0;
  else if (!strcmp (p, "-Wimplicit"))
    warn_implicit = 1;
  else if (!strcmp (p, "-Wno-implicit"))
    warn_implicit = 0;
  else if (!strcmp (p, "-Wwrite-strings"))
    warn_write_strings = 1;
  else if (!strcmp (p, "-Wno-write-strings"))
    warn_write_strings = 0;
  else if (!strcmp (p, "-Wcast-qual"))
    warn_cast_qual = 1;
  else if (!strcmp (p, "-Wno-cast-qual"))
    warn_cast_qual = 0;
  else if (!strcmp (p, "-Wbad-function-cast"))
    warn_bad_function_cast = 1;
  else if (!strcmp (p, "-Wno-bad-function-cast"))
    warn_bad_function_cast = 0;
  else if (!strcmp (p, "-Wpointer-arith"))
    warn_pointer_arith = 1;
  else if (!strcmp (p, "-Wno-pointer-arith"))
    warn_pointer_arith = 0;
  else if (!strcmp (p, "-Wstrict-prototypes"))
    warn_strict_prototypes = 1;
  else if (!strcmp (p, "-Wno-strict-prototypes"))
    warn_strict_prototypes = 0;
  else if (!strcmp (p, "-Wmissing-prototypes"))
    warn_missing_prototypes = 1;
  else if (!strcmp (p, "-Wno-missing-prototypes"))
    warn_missing_prototypes = 0;
  else if (!strcmp (p, "-Wmissing-declarations"))
    warn_missing_declarations = 1;
  else if (!strcmp (p, "-Wno-missing-declarations"))
    warn_missing_declarations = 0;
  else if (!strcmp (p, "-Wredundant-decls"))
    warn_redundant_decls = 1;
  else if (!strcmp (p, "-Wno-redundant-decls"))
    warn_redundant_decls = 0;
  else if (!strcmp (p, "-Wnested-externs"))
    warn_nested_externs = 1;
  else if (!strcmp (p, "-Wno-nested-externs"))
    warn_nested_externs = 0;
  else if (!strcmp (p, "-Wtraditional"))
    warn_traditional = 1;
  else if (!strcmp (p, "-Wno-traditional"))
    warn_traditional = 0;
  else if (!strcmp (p, "-Wformat"))
    warn_format = 1;
  else if (!strcmp (p, "-Wno-format"))
    warn_format = 0;
  else if (!strcmp (p, "-Wchar-subscripts"))
    warn_char_subscripts = 1;
  else if (!strcmp (p, "-Wno-char-subscripts"))
    warn_char_subscripts = 0;
  else if (!strcmp (p, "-Wconversion"))
    warn_conversion = 1;
  else if (!strcmp (p, "-Wno-conversion"))
    warn_conversion = 0;
  else if (!strcmp (p, "-Wparentheses"))
    warn_parentheses = 1;
  else if (!strcmp (p, "-Wno-parentheses"))
    warn_parentheses = 0;
  else if (!strcmp (p, "-Wreturn-type"))
    warn_return_type = 1;
  else if (!strcmp (p, "-Wno-return-type"))
    warn_return_type = 0;
  else if (!strcmp (p, "-Wcomment"))
    ;
  else if (!strcmp (p, "-Wno-comment"))
    ;
  else if (!strcmp (p, "-Wcomments"))
    ;
  else if (!strcmp (p, "-Wno-comments"))
    ;
  else if (!strcmp (p, "-Wtrigraphs"))
    ;
  else if (!strcmp (p, "-Wno-trigraphs"))
    ;
  else if (!strcmp (p, "-Wimport"))
    ;
  else if (!strcmp (p, "-Wno-import"))
    ;
  else if (!strcmp (p, "-Wmissing-braces"))
    warn_missing_braces = 1;
  else if (!strcmp (p, "-Wno-missing-braces"))
    warn_missing_braces = 0;
  else if (!strcmp (p, "-Wall"))
    {



      if (warn_uninitialized != 1)
 warn_uninitialized = 2;
      warn_implicit = 1;
      warn_return_type = 1;
      warn_unused = 1;
      warn_switch = 1;
      warn_format = 1;
      warn_char_subscripts = 1;
      warn_parentheses = 1;
      warn_missing_braces = 1;
    }
  else
    return 0;

  return 1;
}



void
print_lang_decl(FILE *file, tree node, int indent) asm("_print_lang_decl");
void
print_lang_decl(FILE *file, tree node, int indent)
{
}

void
print_lang_type(FILE *file, tree node, int indent) asm("_print_lang_type");
void
print_lang_type(FILE *file, tree node, int indent)
{
}

void
print_lang_identifier(FILE *file, tree node, int indent) asm("_print_lang_identifier");
void
print_lang_identifier(FILE *file, tree node, int indent)
{
  print_node (file, "global", (((struct n64_tag_lang_identifier *)(node))->global_value), indent + 4);
  print_node (file, "local", (((struct n64_tag_lang_identifier *)(node))->local_value), indent + 4);
  print_node (file, "label", (((struct n64_tag_lang_identifier *)(node))->label_value), indent + 4);
  print_node (file, "implicit", (((struct n64_tag_lang_identifier *)(node))->implicit_decl), indent + 4);
  print_node (file, "error locus", (((struct n64_tag_lang_identifier *)(node))->error_locus), indent + 4);
  print_node (file, "limbo value", (((struct n64_tag_lang_identifier *)(node))->limbo_value), indent + 4);
}




void
finish_incomplete_decl(tree decl) asm("_finish_incomplete_decl");
void
finish_incomplete_decl(tree decl)
{
  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->common.type) != error_mark_node)
    {
      tree type = ((decl)->common.type);
      if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
   && ((type)->type.values) == 0
   && ((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
 {
   complete_array_type (type, (tree) 
                             ((void *)0)
                                      , 1);

   layout_decl (decl, 0);
 }
    }
}



static
struct n64_tag_binding_level *
make_binding_level(void) asm("_make_binding_level");
struct n64_tag_binding_level *
make_binding_level(void)
{

  return (struct n64_tag_binding_level *) xmalloc (sizeof (struct n64_tag_binding_level));
}



int
global_bindings_p(void) asm("_global_bindings_p");
int
global_bindings_p(void)
{
  return current_binding_level == global_binding_level;
}

void
keep_next_level(void) asm("_keep_next_level");
void
keep_next_level(void)
{
  keep_next_level_flag = 1;
}



int
kept_level_p(void) asm("_kept_level_p");
int
kept_level_p(void)
{
  return ((current_binding_level->keep_if_subblocks
    && current_binding_level->blocks != 0)
   || current_binding_level->keep
   || current_binding_level->names != 0
   || (current_binding_level->tags != 0
       && !current_binding_level->tag_transparent));
}






void
declare_parm_level(int definition_flag) asm("_declare_parm_level");
void
declare_parm_level(int definition_flag)
{
  current_binding_level->parm_flag = 1;
}



int
in_parm_level_p(void) asm("_in_parm_level_p");
int
in_parm_level_p(void)
{
  return current_binding_level->parm_flag;
}





void
pushlevel(int tag_transparent) asm("_pushlevel");
void
pushlevel(int tag_transparent)
{
  register struct n64_tag_binding_level *newlevel = (struct n64_tag_binding_level *) 
                                           ((void *)0)
                                                             ;




  if (current_binding_level == global_binding_level)
    {
      named_labels = 0;
    }



  if (free_binding_level)
    {
      newlevel = free_binding_level;
      free_binding_level = free_binding_level->level_chain;
    }
  else
    {
      newlevel = make_binding_level ();
    }




  *newlevel = clear_binding_level;
  newlevel->tag_transparent
    = (tag_transparent
       || (current_binding_level
    ? current_binding_level->subblocks_tag_transparent
    : 0));
  newlevel->level_chain = current_binding_level;
  current_binding_level = newlevel;
  newlevel->keep = keep_next_level_flag;
  keep_next_level_flag = 0;
  newlevel->keep_if_subblocks = keep_next_if_subblocks;
  keep_next_if_subblocks = 0;
}
tree
poplevel(int keep, int reverse, int functionbody) asm("_poplevel");
tree
poplevel(int keep, int reverse, int functionbody)
{
  register tree link;


  tree decls;
  tree tags = current_binding_level->tags;
  tree subblocks = current_binding_level->blocks;
  tree block = 0;
  tree decl;
  int block_previously_created;

  keep |= current_binding_level->keep;
  if (reverse)
    current_binding_level->names
      = decls = nreverse (current_binding_level->names);
  else
    decls = current_binding_level->names;




  for (decl = decls; decl; decl = ((decl)->common.chain))
    if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
 && ! ((decl)->common.asm_written_flag)
 && ((decl)->decl.initial) != 0
 && ((decl)->common.addressable_flag))
      {






 if (((decl)->decl.abstract_origin) != 0
     && ((decl)->decl.abstract_origin) != decl)
   ((((decl)->decl.abstract_origin))->common.addressable_flag) = 1;
 else
   {
     push_function_context ();
     output_inline_function (decl);
     pop_function_context ();
   }
      }





  block = 0;
  block_previously_created = (current_binding_level->this_block != 0);
  if (block_previously_created)
    block = current_binding_level->this_block;
  else if (keep || functionbody
    || (current_binding_level->keep_if_subblocks && subblocks != 0))
    block = make_node (BLOCK);
  if (block != 0)
    {
      ((block)->block.vars) = decls;
      ((block)->block.type_tags) = tags;
      ((block)->block.subblocks) = subblocks;
      remember_end_note (block);
    }



  for (link = subblocks; link; link = ((link)->common.chain))
    ((link)->block.supercontext) = block;



  for (link = decls; link; link = ((link)->common.chain))
    {
      if (((link)->decl.name) != 0)
 {


   if (((link)->decl.external_flag))
     {
       if (((link)->common.used_flag))
  ((((link)->decl.name))->common.used_flag) = 1;
       if (((link)->common.addressable_flag))
  ((((link)->decl.assembler_name))->common.addressable_flag) = 1;
     }
   (((struct n64_tag_lang_identifier *)(((link)->decl.name)))->local_value) = 0;
 }
    }




  for (link = current_binding_level->shadowed; link; link = ((link)->common.chain))
    (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->local_value) = ((link)->list.value);





  if (functionbody)
    {





      ((block)->block.vars) = 0;





      for (link = named_labels; link; link = ((link)->common.chain))
 {
   register tree label = ((link)->list.value);

   if (((label)->decl.initial) == 0)
     {
       error_with_decl (label, "label `%s' used but not defined");

       define_label (input_filename, lineno,
       ((label)->decl.name));
     }
   else if (warn_unused && !((label)->common.used_flag))
     warning_with_decl (label, "label `%s' defined but not used");
   (((struct n64_tag_lang_identifier *)(((label)->decl.name)))->label_value) = 0;



   ((label)->common.chain) = ((block)->block.vars);
   ((block)->block.vars) = label;
 }
    }



  {
    register struct n64_tag_binding_level *level = current_binding_level;
    current_binding_level = current_binding_level->level_chain;

    level->level_chain = free_binding_level;
    free_binding_level = level;
  }


  if (functionbody)
    ((current_function_decl)->decl.initial) = block;
  else if (block)
    {
      if (!block_previously_created)
        current_binding_level->blocks
          = chainon (current_binding_level->blocks, block);
    }





  else if (subblocks)
    current_binding_level->blocks
      = chainon (current_binding_level->blocks, subblocks);
  if (functionbody)
    for (link = tags; link; link = ((link)->common.chain))
      ((((link)->list.value))->type.context) = current_function_decl;
  else if (block)
    for (link = tags; link; link = ((link)->common.chain))
      ((((link)->list.value))->type.context) = block;

  if (block)
    ((block)->common.used_flag) = 1;
  return block;
}





void
delete_block(tree block) asm("_delete_block");
void
delete_block(tree block)
{
  tree t;
  if (current_binding_level->blocks == block)
    current_binding_level->blocks = ((block)->common.chain);
  for (t = current_binding_level->blocks; t;)
    {
      if (((t)->common.chain) == block)
 ((t)->common.chain) = ((block)->common.chain);
      else
 t = ((t)->common.chain);
    }
  ((block)->common.chain) = 
                      ((void *)0)
                          ;


  ((block)->common.used_flag) = 0;
}





void
insert_block(tree block) asm("_insert_block");
void
insert_block(tree block)
{
  ((block)->common.used_flag) = 1;
  current_binding_level->blocks
    = chainon (current_binding_level->blocks, block);
}




void
set_block(register tree block) asm("_set_block");
void
set_block(register tree block)
{
  current_binding_level->this_block = block;
}

void
push_label_level(void) asm("_push_label_level");
void
push_label_level(void)
{
  register struct n64_tag_binding_level *newlevel;



  if (free_binding_level)
    {
      newlevel = free_binding_level;
      free_binding_level = free_binding_level->level_chain;
    }
  else
    {
      newlevel = make_binding_level ();
    }



  newlevel->level_chain = label_level_chain;
  label_level_chain = newlevel;

  newlevel->names = named_labels;
  newlevel->shadowed = shadowed_labels;
  named_labels = 0;
  shadowed_labels = 0;
}

void
pop_label_level(void) asm("_pop_label_level");
void
pop_label_level(void)
{
  register struct n64_tag_binding_level *level = label_level_chain;
  tree link, prev;



  for (link = named_labels, prev = 0; link;)
    {
      if (((((link)->list.value))->common.lang_flag_1))
 {
   if (((((link)->list.value))->decl.linenum) == 0)
     {
       error_with_decl (((link)->list.value),
          "label `%s' used but not defined");

       define_label (input_filename, lineno,
       ((((link)->list.value))->decl.name));
     }
   else if (warn_unused && !((((link)->list.value))->common.used_flag))
     warning_with_decl (((link)->list.value),
          "label `%s' defined but not used");
   (((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->label_value) = 0;


   link = ((link)->common.chain);
   if (prev)
     ((prev)->common.chain) = link;
   else
     named_labels = link;
 }
      else
 {
   prev = link;
   link = ((link)->common.chain);
 }
    }


  for (link = shadowed_labels; link; link = ((link)->common.chain))
    if (((((link)->list.value))->decl.name) != 0)
      (((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->label_value)
 = ((link)->list.value);

  named_labels = chainon (named_labels, level->names);
  shadowed_labels = level->shadowed;


  label_level_chain = label_level_chain->level_chain;
  level->level_chain = free_binding_level;
  free_binding_level = level;
}
void
pushtag(tree name, tree type) asm("_pushtag");
void
pushtag(tree name, tree type)
{
  register struct n64_tag_binding_level *b;



  for (b = current_binding_level; b->tag_transparent; b = b->level_chain)
    continue;

  if (name)
    {


      if (((type)->type.name) == 0)
 ((type)->type.name) = name;
    }

  if (b == global_binding_level)
    b->tags = perm_tree_cons (name, type, b->tags);
  else
    b->tags = saveable_tree_cons (name, type, b->tags);
  (((type)->common.chain)) = pushdecl (build_decl (TYPE_DECL, (tree) 
                                                          ((void *)0)
                                                                   , type));
}
static int
duplicate_decls(register tree newdecl, register tree olddecl) asm("_duplicate_decls");
static int
duplicate_decls(register tree newdecl, register tree olddecl)
{
  int types_match = comptypes (((newdecl)->common.type), ((olddecl)->common.type));
  int new_is_definition = (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && ((newdecl)->decl.initial) != 0);
  tree oldtype = ((olddecl)->common.type);
  tree newtype = ((newdecl)->common.type);
  char *errmsg = 0;

  if ((*tree_code_type[(int) (((n64_enum_tree_code) (olddecl)->common.code))]) == 'd')
    ((newdecl)->decl.machine_attributes) = ((olddecl)->decl.machine_attributes);

  if (((n64_enum_tree_code) (newtype)->common.code) == ERROR_MARK
      || ((n64_enum_tree_code) (oldtype)->common.code) == ERROR_MARK)
    types_match = 0;




  if (((n64_enum_tree_code) (olddecl)->common.code) != ((n64_enum_tree_code) (newdecl)->common.code))
    {
      if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
   && (((olddecl)->decl.bit_field_flag)
       || ((olddecl)->common.unsigned_flag)))
 {



   if (!((newdecl)->common.public_flag))
     {
       if (!warn_shadow)
  ;
       else if (((olddecl)->decl.bit_field_flag))
  warning_with_decl (newdecl, "shadowing built-in function `%s'");
       else
  warning_with_decl (newdecl, "shadowing library function `%s'");
     }


   else if (! ((olddecl)->decl.bit_field_flag))
     warning_with_decl (newdecl,
          "library function `%s' declared as non-function");

   else if (((olddecl)->common.unsigned_flag))
     warning_with_decl (newdecl,
          "built-in function `%s' declared as non-function");
   else
     warning_with_decl (newdecl,
        "built-in function `%s' declared as non-function");
 }
      else
 {
   error_with_decl (newdecl, "`%s' redeclared as different kind of symbol");
   error_with_decl (olddecl, "previous declaration of `%s'");
 }

      return 0;
    }



  if (types_match && ((n64_enum_tree_code) (newdecl)->common.code) == PARM_DECL
      && ((olddecl)->common.asm_written_flag) && ! ((newdecl)->common.asm_written_flag))
    return 1;






  if (flag_traditional && ((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && (((struct n64_tag_lang_identifier *)(((newdecl)->decl.name)))->implicit_decl) == olddecl
      && ((olddecl)->decl.initial) == 0)


    ;
  else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
    && ((olddecl)->decl.bit_field_flag))
    {

      if (!((newdecl)->common.public_flag))
 {



   if (warn_shadow)
     warning_with_decl (newdecl, "shadowing built-in function `%s'");

   return 0;
 }
      else if (!types_match)
 {

   tree oldreturntype = ((((olddecl)->common.type))->common.type);
   tree newreturntype = ((((newdecl)->common.type))->common.type);




   if (((oldtype)->type.obstack) == ((newtype)->type.obstack))
     push_obstacks (((oldtype)->type.obstack), ((oldtype)->type.obstack));
   else
     {
       push_obstacks_nochange ();
       end_temporary_allocation ();
     }

          if (((oldreturntype)->type.mode) == ((newreturntype)->type.mode))
            {


       tree newtype
  = build_function_type (newreturntype,
           ((((olddecl)->common.type))->type.values));

              types_match = comptypes (((newdecl)->common.type), newtype);
       if (types_match)
  ((olddecl)->common.type) = newtype;
     }


   if (((((newdecl)->common.type))->type.values) != 0
       && ((((olddecl)->common.type))->type.values) != 0
       && ((((((newdecl)->common.type))->type.values))->list.value) != 0
       && ((((((olddecl)->common.type))->type.values))->list.value) != 0
       && (((((((((newdecl)->common.type))->type.values))->list.value))->type.mode)
    ==
    ((((((((olddecl)->common.type))->type.values))->list.value))->type.mode)))
     {


       tree newtype
  = build_function_type (((((olddecl)->common.type))->common.type),
           tree_cons ((tree) 
                     ((void *)0)
                              ,
        ((((((newdecl)->common.type))->type.values))->list.value),
        ((((((olddecl)->common.type))->type.values))->common.chain)));

              types_match = comptypes (((newdecl)->common.type), newtype);
       if (types_match)
  ((olddecl)->common.type) = newtype;
     }

   pop_obstacks ();
 }
      if (!types_match)
 {

   warning_with_decl (newdecl, "conflicting types for built-in function `%s'");
   return 0;
 }
    }
  else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
    && ((olddecl)->decl.linenum) == 0)
    {


      if (!((newdecl)->common.public_flag))
 {


   return 0;
 }
      else if (!types_match)
 {



   ((newdecl)->common.volatile_flag) |= ((olddecl)->common.volatile_flag);
 }
    }


  else if (!types_match
    && ((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
    && ((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
    && ((n64_enum_tree_code) (((oldtype)->common.type))->common.code) == POINTER_TYPE
    && ((n64_enum_tree_code) (((newtype)->common.type))->common.code) == POINTER_TYPE
    && (((olddecl)->decl.in_system_header_flag)
        || ((newdecl)->decl.in_system_header_flag))
    && ((((((((newtype)->common.type))->common.type))->type.main_variant) == void_type_node
  && ((oldtype)->type.values) == 0
  && self_promoting_args_p (((newtype)->type.values))
  && ((((oldtype)->common.type))->common.type) == char_type_node)
        ||
        (((((newtype)->common.type))->common.type) == char_type_node
  && ((newtype)->type.values) == 0
  && self_promoting_args_p (((oldtype)->type.values))
  && ((((((oldtype)->common.type))->common.type))->type.main_variant) == void_type_node)))
    {
      if (pedantic)
 pedwarn_with_decl (newdecl, "conflicting types for `%s'");

      if (((((((oldtype)->common.type))->common.type))->type.main_variant) == void_type_node)
 ((newdecl)->common.type) = newtype = oldtype;



      ((newdecl)->decl.in_system_header_flag) = 1;
    }
  else if (!types_match


    && ! (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
   && ! pedantic

   && comptypes (((oldtype)->common.type),
          ((newtype)->common.type))
   && ((newtype)->type.values) == 0))
    {
      error_with_decl (newdecl, "conflicting types for `%s'");


      if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
   && comptypes (((oldtype)->common.type),
   ((newtype)->common.type))
   && ((((oldtype)->type.values) == 0
        && ((olddecl)->decl.initial) == 0)
       ||
       (((newtype)->type.values) == 0
        && ((newdecl)->decl.initial) == 0)))
 {

   register tree t = ((oldtype)->type.values);
   if (t == 0)
     t = ((newtype)->type.values);
   for (; t; t = ((t)->common.chain))
     {
       register tree type = ((t)->list.value);

       if (((t)->common.chain) == 0
    && ((type)->type.main_variant) != void_type_node)
  {
    error ("A parameter list with an ellipsis can't match");
    error ("an empty parameter name list declaration.");
    break;
  }

       if (((type)->type.main_variant) == float_type_node
    || (((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
  {
    error ("An argument type that has a default promotion");
    error ("can't match an empty parameter name list declaration.");
    break;
  }
     }
 }
      error_with_decl (olddecl, "previous declaration of `%s'");
    }
  else
    {
      errmsg = redeclaration_error_message (newdecl, olddecl);
      if (errmsg)
 {
   error_with_decl (newdecl, errmsg);
   error_with_decl (olddecl,
      ((((olddecl)->decl.initial)
        && current_binding_level == global_binding_level)
       ? "`%s' previously defined here"
       : "`%s' previously declared here"));
 }
      else if (((n64_enum_tree_code) (newdecl)->common.code) == TYPE_DECL
               && (((olddecl)->decl.in_system_header_flag)
                   || ((newdecl)->decl.in_system_header_flag)))
 {
   warning_with_decl (newdecl, "redefinition of `%s'");
   warning_with_decl
     (olddecl,
      ((((olddecl)->decl.initial)
        && current_binding_level == global_binding_level)
       ? "`%s' previously defined here"
       : "`%s' previously declared here"));
 }
      else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
        && ((olddecl)->decl.initial) != 0
        && ((oldtype)->type.values) == 0
        && ((newtype)->type.values) != 0
        && ((oldtype)->type.noncopied_parts) != 0)
 {
   register tree type, parm;
   register int nargs;


   for (parm = ((oldtype)->type.noncopied_parts),
        type = ((newtype)->type.values),
        nargs = 1;
        (((((parm)->list.value))->type.main_variant) != void_type_node
  || ((((type)->list.value))->type.main_variant) != void_type_node);
        parm = ((parm)->common.chain), type = ((type)->common.chain), nargs++)
     {
       if (((((parm)->list.value))->type.main_variant) == void_type_node
    || ((((type)->list.value))->type.main_variant) == void_type_node)
  {
    errmsg = "prototype for `%s' follows and number of arguments";
    break;
  }


       if (! comptypes (((parm)->list.value), ((type)->list.value))


    && (! (flag_traditional
    && ((((parm)->list.value))->type.main_variant) == integer_type_node
    && ((((type)->list.value))->type.main_variant) == unsigned_type_node)))
  {
    errmsg = "prototype for `%s' follows and argument %d";
    break;
  }
     }
   if (errmsg)
     {
       error_with_decl (newdecl, errmsg, nargs);
       error_with_decl (olddecl,
          "doesn't match non-prototype definition here");
     }
   else
     {
       warning_with_decl (newdecl, "prototype for `%s' follows");
       warning_with_decl (olddecl, "non-prototype definition here");
     }
 }

      else
 {


   if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
       && ! ((olddecl)->decl.inline_flag) && ((newdecl)->decl.inline_flag)
       && ((olddecl)->common.used_flag))
     warning_with_decl (newdecl,
          "`%s' declared inline after being called");
   if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
       && ! ((olddecl)->decl.inline_flag) && ((newdecl)->decl.inline_flag)
       && ((olddecl)->decl.initial) != 0)
     warning_with_decl (newdecl,
          "`%s' declared inline after its definition");



   if ((pedantic || ((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL)
       && ((olddecl)->common.public_flag)
       && !((newdecl)->common.public_flag))
     warning_with_decl (newdecl, "static declaration for `%s' follows non-static");



   if (((n64_enum_tree_code) (olddecl)->common.code) != FUNCTION_DECL
       && !((olddecl)->common.readonly_flag)
       && ((newdecl)->common.readonly_flag))
     warning_with_decl (newdecl, "const declaration for `%s' follows non-const");



   else if (pedantic && ((n64_enum_tree_code) (olddecl)->common.code) != FUNCTION_DECL
       && (((newdecl)->common.readonly_flag) != ((olddecl)->common.readonly_flag)
    || ((newdecl)->common.volatile_flag) != ((olddecl)->common.volatile_flag)))
     pedwarn_with_decl (newdecl, "type qualifiers for `%s' conflict with previous decl");
 }
    }


  if (errmsg == 0 && warn_redundant_decls && ((olddecl)->decl.linenum) != 0


      && !(((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL && ((newdecl)->decl.initial) != 0
    && ((olddecl)->decl.initial) == 0)

      && !(((olddecl)->decl.external_flag) && ! ((newdecl)->decl.external_flag)))
    {
      warning_with_decl (newdecl, "redundant redeclaration of `%s' in same scope");
      warning_with_decl (olddecl, "previous declaration of `%s'");
    }







  if (types_match)
    {



      if (((oldtype)->type.obstack) == ((newtype)->type.obstack))
 push_obstacks (((oldtype)->type.obstack), ((oldtype)->type.obstack));
      else
 {
   push_obstacks_nochange ();
   end_temporary_allocation ();
 }


      if (((n64_enum_tree_code) (newdecl)->common.code) != FUNCTION_DECL || !((olddecl)->decl.bit_field_flag))
 ((newdecl)->common.type)
   = ((olddecl)->common.type)
     = common_type (newtype, oldtype);


      if (oldtype != ((newdecl)->common.type))
 {
   if (((newdecl)->common.type) != error_mark_node)
     layout_type (((newdecl)->common.type));
   if (((n64_enum_tree_code) (newdecl)->common.code) != FUNCTION_DECL
       && ((n64_enum_tree_code) (newdecl)->common.code) != TYPE_DECL
       && ((n64_enum_tree_code) (newdecl)->common.code) != CONST_DECL)
     layout_decl (newdecl, 0);
 }
      else
 {

   ((newdecl)->decl.size) = ((olddecl)->decl.size);
   if (((n64_enum_tree_code) (olddecl)->common.code) != FUNCTION_DECL)
     if (((olddecl)->decl.frame_size.u) > ((newdecl)->decl.frame_size.u))
       ((newdecl)->decl.frame_size.u) = ((olddecl)->decl.frame_size.u);
 }


      ((newdecl)->decl.rtl) = ((olddecl)->decl.rtl);


      if (((olddecl)->common.unsigned_flag) && ((olddecl)->common.volatile_flag)
   && !((newdecl)->common.volatile_flag))
 ((olddecl)->common.volatile_flag) = 0;
      if (((newdecl)->common.readonly_flag))
 ((olddecl)->common.readonly_flag) = 1;
      if (((newdecl)->common.volatile_flag))
 {
   ((olddecl)->common.volatile_flag) = 1;
   if (((n64_enum_tree_code) (newdecl)->common.code) == VAR_DECL)
     make_var_volatile (newdecl);
 }



      if ((((newdecl)->decl.initial) == 0 && ((olddecl)->decl.initial) != 0)
   || (((newdecl)->decl.context) != 0 && ((olddecl)->decl.context) == 0))
 {
   ((newdecl)->decl.linenum) = ((olddecl)->decl.linenum);
   ((newdecl)->decl.filename) = ((olddecl)->decl.filename);

   if (((olddecl)->decl.context) == 0
       && ((n64_enum_tree_code) (newdecl)->common.code) != FUNCTION_DECL)
     ((newdecl)->decl.context) = 0;
 }


      if (((olddecl)->decl.in_system_header_flag))
 ((newdecl)->decl.in_system_header_flag) = 1;
      else if (((newdecl)->decl.in_system_header_flag))
 ((olddecl)->decl.in_system_header_flag) = 1;


      if (((newdecl)->decl.initial) == 0)
 ((newdecl)->decl.initial) = ((olddecl)->decl.initial);





      if (((newdecl)->decl.section_name) == (tree) 
                                        ((void *)0)
                                                 )
 ((newdecl)->decl.section_name) = ((olddecl)->decl.section_name);

      if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
 {
   ((newdecl)->decl.static_ctor_flag) |= ((olddecl)->decl.static_ctor_flag);
   ((newdecl)->decl.static_dtor_flag) |= ((olddecl)->decl.static_dtor_flag);
 }

      pop_obstacks ();
    }


  else
    {
      ((olddecl)->common.type) = ((newdecl)->common.type);
      ((olddecl)->common.readonly_flag) = ((newdecl)->common.readonly_flag);
      ((olddecl)->common.volatile_flag) = ((newdecl)->common.volatile_flag);
      ((olddecl)->common.side_effects_flag) = ((newdecl)->common.side_effects_flag);
    }


  ((newdecl)->decl.weak_flag) |= ((olddecl)->decl.weak_flag);

  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {
      ((newdecl)->common.public_flag) &= ((olddecl)->common.public_flag);


      ((olddecl)->common.public_flag) = ((newdecl)->common.public_flag);

      if (! ((olddecl)->common.public_flag))
 ((((olddecl)->decl.name))->common.public_flag) = 0;
    }
  if (((newdecl)->decl.external_flag))
    {
      ((newdecl)->common.static_flag) = ((olddecl)->common.static_flag);
      ((newdecl)->decl.external_flag) = ((olddecl)->decl.external_flag);

      ((newdecl)->common.public_flag) = ((olddecl)->common.public_flag);
    }
  else
    {
      ((olddecl)->common.static_flag) = ((newdecl)->common.static_flag);
      ((olddecl)->common.public_flag) = ((newdecl)->common.public_flag);
    }



  if (((newdecl)->decl.inline_flag) && ((olddecl)->decl.initial) == 0)
    ((olddecl)->decl.inline_flag) = 1;
  ((newdecl)->decl.inline_flag) = ((olddecl)->decl.inline_flag);



  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && ((olddecl)->decl.bit_field_flag)
      && (!types_match || new_is_definition))
    {
      ((olddecl)->common.type) = ((newdecl)->common.type);
      ((olddecl)->decl.bit_field_flag) = 0;
    }




  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL && !new_is_definition)
    {
      if (((olddecl)->decl.bit_field_flag))
 {
   ((newdecl)->decl.bit_field_flag) = 1;
   ((newdecl)->decl.frame_size.f) = ((olddecl)->decl.frame_size.f);
 }
      else
 ((newdecl)->decl.frame_size.i) = ((olddecl)->decl.frame_size.i);

      ((newdecl)->decl.result) = ((olddecl)->decl.result);
      ((newdecl)->decl.initial) = ((olddecl)->decl.initial);
      ((newdecl)->decl.saved_insns.r) = ((olddecl)->decl.saved_insns.r);
      ((newdecl)->decl.arguments) = ((olddecl)->decl.arguments);
    }



  {
    register unsigned olddecl_uid = ((olddecl)->decl.uid);

    memcpy ((char *) olddecl + sizeof (struct n64_tag_tree_common),(char *) newdecl + sizeof (struct n64_tag_tree_common),sizeof (struct n64_tag_tree_decl) - sizeof (struct n64_tag_tree_common))

                                                            ;
    ((olddecl)->decl.uid) = olddecl_uid;
  }

  return 1;
}
tree
pushdecl(tree x) asm("_pushdecl");
tree
pushdecl(tree x)
{
  register tree t;
  register tree name = ((x)->decl.name);
  register struct n64_tag_binding_level *b = current_binding_level;

  ((x)->decl.context) = current_function_decl;



  if (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL && ((x)->decl.initial) == 0
      && ((x)->decl.external_flag))
    ((x)->decl.context) = 0;

  if (warn_nested_externs && ((x)->decl.external_flag) && b != global_binding_level
      && x != (((struct n64_tag_lang_identifier *)(name))->implicit_decl)

      && !((x)->decl.in_system_header_flag))
    warning ("nested extern declaration of `%s'", ((name)->identifier.pointer));

  if (name)
    {
      char *file;
      int line;
      int declared_global;




      if (((x)->decl.external_flag) && ((x)->common.public_flag) && ! flag_traditional)
 t = lookup_name_current_level_global (name);
      else
 t = lookup_name_current_level (name);
      if (t != 0 && t == error_mark_node)

 {
   t = 0;
   error_with_decl (x, "`%s' used prior to declaration");
 }

      if (t != 0)
 {
   file = ((t)->decl.filename);
   line = ((t)->decl.linenum);
 }



      declared_global = ((x)->common.public_flag) || ((x)->decl.external_flag);
      if (t != 0 && duplicate_decls (x, t))
 {
   if (((n64_enum_tree_code) (t)->common.code) == PARM_DECL)
     {


       ((t)->common.asm_written_flag) = ((x)->common.asm_written_flag);
       return t;
     }



   if (!flag_traditional && ((name)->common.public_flag)


       && ! ((x)->common.public_flag) && ! ((x)->decl.external_flag)



       && (((struct n64_tag_lang_identifier *)(name))->implicit_decl) != 0)
     {
       pedwarn ("`%s' was declared implicitly `extern' and later `static'",
         ((name)->identifier.pointer));
       pedwarn_with_file_and_line (file, line,
       "previous declaration of `%s'",
       ((name)->identifier.pointer));
     }






   if (! declared_global || lookup_name (name) == t)
     return t;
 }
      if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
        {
          if (((x)->decl.linenum) == 0)
            {
       if (((((x)->common.type))->type.name) == 0)
         ((((x)->common.type))->type.name) = x;
            }
          else if (((x)->common.type) != error_mark_node)
            {
              tree tt = ((x)->common.type);

              tt = build_type_copy (tt);
              ((tt)->type.name) = x;
              ((x)->common.type) = tt;
            }
        }







      if (((x)->common.public_flag) && ! ((x)->decl.inline_flag))
 {
   tree decl;

   if (flag_traditional && (((struct n64_tag_lang_identifier *)(name))->global_value) != 0
       && ((((((struct n64_tag_lang_identifier *)(name))->global_value))->decl.external_flag)
    || (((((struct n64_tag_lang_identifier *)(name))->global_value))->common.public_flag)))
     decl = (((struct n64_tag_lang_identifier *)(name))->global_value);
   else if ((((struct n64_tag_lang_identifier *)(name))->limbo_value) != 0)

     decl = (((struct n64_tag_lang_identifier *)(name))->limbo_value);
   else
     decl = 0;

   if (decl && ! comptypes (((x)->common.type), ((decl)->common.type))

       && !((decl)->decl.bit_field_flag))
     {
       pedwarn_with_decl (x,
     "type mismatch with previous external decl");
       pedwarn_with_decl (decl, "previous external decl of `%s'");
     }
 }




      if ((((struct n64_tag_lang_identifier *)(name))->implicit_decl) != 0
   && (((struct n64_tag_lang_identifier *)(name))->global_value) == 0
   && ((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL
   && ! comptypes (((x)->common.type),
     (((((struct n64_tag_lang_identifier *)(name))->implicit_decl))->common.type)))
 {
   warning_with_decl (x, "type mismatch with previous implicit declaration");
   warning_with_decl ((((struct n64_tag_lang_identifier *)(name))->implicit_decl),
        "previous implicit declaration of `%s'");
 }



      if (flag_traditional && ((x)->decl.external_flag)
   && lookup_name (name) == 0)
 {
   tree type = ((x)->common.type);


   while (type)
     {
       if (type == error_mark_node)
  break;
       if (! ((type)->common.permanent_flag))
  {
    warning_with_decl (x, "type of external `%s' is not global");


    break;
  }
       else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
         && ((type)->type.values) != 0)




  break;
       type = ((type)->common.type);
     }

   if (type == 0)
     b = global_binding_level;
 }



      if (b == global_binding_level)
 {




   if ((((struct n64_tag_lang_identifier *)(name))->global_value) == 0 && ((x)->common.public_flag))
     ((name)->common.public_flag) = 1;

   (((struct n64_tag_lang_identifier *)(name))->global_value) = x;


   (((struct n64_tag_lang_identifier *)(name))->limbo_value) = 0;


   if ((((struct n64_tag_lang_identifier *)(name))->implicit_decl)
       && (((((struct n64_tag_lang_identifier *)(name))->implicit_decl))->common.used_flag))
     ((x)->common.used_flag) = 1, ((name)->common.used_flag) = 1;


   if ((((struct n64_tag_lang_identifier *)(name))->implicit_decl)
       && (((((struct n64_tag_lang_identifier *)(name))->implicit_decl))->common.addressable_flag))
     ((x)->common.addressable_flag) = 1;


   if ((((struct n64_tag_lang_identifier *)(name))->implicit_decl) != 0

       && ! (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL
      && (((((((x)->common.type))->common.type))->type.main_variant)
   == integer_type_node)))
     pedwarn ("`%s' was previously implicitly declared to return `int'",
       ((name)->identifier.pointer));



   if (((name)->common.public_flag)
       && ! ((x)->common.public_flag) && ! ((x)->decl.external_flag))
     {

       if (t != 0 && ((t)->decl.bit_field_flag))
  ;

       else if (t != 0 && ((t)->common.unsigned_flag))
  ;
       else if ((((struct n64_tag_lang_identifier *)(name))->implicit_decl))
  pedwarn ("`%s' was declared implicitly `extern' and later `static'",
    ((name)->identifier.pointer));
       else
  pedwarn ("`%s' was declared `extern' and later `static'",
    ((name)->identifier.pointer));
     }
 }
      else
 {

   tree oldlocal = (((struct n64_tag_lang_identifier *)(name))->local_value);
   tree oldglobal = (((struct n64_tag_lang_identifier *)(name))->global_value);
   (((struct n64_tag_lang_identifier *)(name))->local_value) = x;



   if (oldlocal == 0
       && ((x)->decl.external_flag) && !((x)->decl.inline_flag)
       && oldglobal != 0
       && ((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL
       && ((n64_enum_tree_code) (oldglobal)->common.code) == FUNCTION_DECL)
     {

       if (! comptypes (((x)->common.type),
          (((((struct n64_tag_lang_identifier *)(name))->global_value))->common.type)))
  pedwarn_with_decl (x, "extern declaration of `%s' doesn't match global one");
       else
  {


    if (((oldglobal)->decl.inline_flag))
      {
        ((x)->decl.inline_flag) = ((oldglobal)->decl.inline_flag);
        ((x)->decl.initial) = (current_function_decl == oldglobal
       ? 0 : ((oldglobal)->decl.initial));
        ((x)->decl.saved_insns.r) = ((oldglobal)->decl.saved_insns.r);
        ((x)->decl.frame_size.i) = ((oldglobal)->decl.frame_size.i);
        ((x)->decl.arguments) = ((oldglobal)->decl.arguments);
        ((x)->decl.result) = ((oldglobal)->decl.result);
        ((x)->common.asm_written_flag) = ((oldglobal)->common.asm_written_flag);
        ((x)->decl.abstract_origin) = oldglobal;
      }

    if (((oldglobal)->decl.bit_field_flag))
      {
        ((x)->decl.bit_field_flag) = ((oldglobal)->decl.bit_field_flag);
        ((x)->decl.frame_size.f) = ((oldglobal)->decl.frame_size.f);
      }

    if (((((oldglobal)->common.type))->type.values) != 0
        && ((oldglobal)->decl.initial)
        && ((((x)->common.type))->type.values) == 0)
      ((x)->common.type) = ((oldglobal)->common.type);
  }
     }
   if (oldlocal == 0
       && oldglobal == 0
       && ((x)->decl.external_flag)
       && ((x)->common.public_flag))
     {
       ((name)->common.public_flag) = 1;
       if ((((struct n64_tag_lang_identifier *)(name))->limbo_value) == 0)
  (((struct n64_tag_lang_identifier *)(name))->limbo_value) = x;
     }


   if (oldlocal != 0 && !((x)->decl.external_flag)

       && ! current_binding_level->parm_flag

       && current_binding_level->level_chain->parm_flag


       && chain_member (oldlocal, current_binding_level->level_chain->names))
     {
       if (((n64_enum_tree_code) (oldlocal)->common.code) == PARM_DECL)
  pedwarn ("declaration of `%s' shadows a parameter",
    ((name)->identifier.pointer));
       else
  pedwarn ("declaration of `%s' shadows a symbol from the parameter list",
    ((name)->identifier.pointer));
     }


   else if (warn_shadow && !((x)->decl.external_flag)

     && ((x)->decl.linenum) != 0

     && ! (((x)->decl.abstract_origin) != (tree) 0))
     {
       char *warnstring = 0;

       if (((n64_enum_tree_code) (x)->common.code) == PARM_DECL
    && current_binding_level->level_chain->parm_flag)





  ;
       else if (oldlocal != 0 && ((n64_enum_tree_code) (oldlocal)->common.code) == PARM_DECL)
  warnstring = "declaration of `%s' shadows a parameter";
       else if (oldlocal != 0)
  warnstring = "declaration of `%s' shadows previous local";
       else if ((((struct n64_tag_lang_identifier *)(name))->global_value) != 0
         && (((struct n64_tag_lang_identifier *)(name))->global_value) != error_mark_node)
  warnstring = "declaration of `%s' shadows global declaration";

       if (warnstring)
  warning (warnstring, ((name)->identifier.pointer));
     }



   if (oldlocal != 0)
     b->shadowed = tree_cons (name, oldlocal, b->shadowed);
 }


      if (((((x)->common.type))->type.size) == 0)
 ++b->n_incomplete;
    }



  ((x)->common.chain) = b->names;
  b->names = x;

  return x;
}



tree
pushdecl_top_level(tree x) asm("_pushdecl_top_level");
tree
pushdecl_top_level(tree x)
{
  register tree t;
  register struct n64_tag_binding_level *b = current_binding_level;

  current_binding_level = global_binding_level;
  t = pushdecl (x);
  current_binding_level = b;
  return t;
}




tree
implicitly_declare(tree functionid) asm("_implicitly_declare");
tree
implicitly_declare(tree functionid)
{
  register tree decl;
  int traditional_warning = 0;

  int implicit_warning;


  push_obstacks_nochange ();
  end_temporary_allocation ();







    decl = build_decl (FUNCTION_DECL, functionid, default_function_type);



  if (((functionid)->common.public_flag) && (((struct n64_tag_lang_identifier *)(functionid))->global_value) == 0)
    traditional_warning = 1;


  implicit_warning = ((((struct n64_tag_lang_identifier *)(functionid))->implicit_decl) == 0);

  ((decl)->decl.external_flag) = 1;
  ((decl)->common.public_flag) = 1;


  (((struct n64_tag_lang_identifier *)(functionid))->implicit_decl) = decl;




  pushdecl (decl);


  maybe_objc_check_decl (decl);

  rest_of_decl_compilation (decl, ((void *)0), 0, 0);

  if (warn_implicit && implicit_warning)
    warning ("implicit declaration of function `%s'",
      ((functionid)->identifier.pointer));
  else if (warn_traditional && traditional_warning)
    warning ("function `%s' was previously declared within a block",
      ((functionid)->identifier.pointer));




  gen_aux_info_record (decl, 0, 1, 0);

  pop_obstacks ();

  return decl;
}







static char *
redeclaration_error_message(tree newdecl, tree olddecl) asm("_redeclaration_error_message");
static char *
redeclaration_error_message(tree newdecl, tree olddecl)
{
  if (((n64_enum_tree_code) (newdecl)->common.code) == TYPE_DECL)
    {
      if (flag_traditional && ((newdecl)->common.type) == ((olddecl)->common.type))
 return 0;






      if (flag_traditional
   && ((((olddecl)->common.type))->type.main_variant) == ((newdecl)->common.type))
 return 0;
      if (((olddecl)->decl.in_system_header_flag) || ((newdecl)->decl.in_system_header_flag))
 return 0;
      return "redefinition of `%s'";
    }
  else if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {




      if (((olddecl)->decl.initial) != 0 && ((newdecl)->decl.initial) != 0


   && !(((olddecl)->decl.inline_flag) && ((olddecl)->decl.external_flag)
        && !(((newdecl)->decl.inline_flag) && ((newdecl)->decl.external_flag))))
 return "redefinition of `%s'";
      return 0;
    }
  else if (current_binding_level == global_binding_level)
    {


      if (((newdecl)->decl.external_flag) || ((olddecl)->decl.external_flag))
 return 0;

      if (((olddecl)->decl.initial) != 0 && ((newdecl)->decl.initial) != 0)
 return "redefinition of `%s'";


      if (((olddecl)->common.public_flag) != ((newdecl)->common.public_flag))
 return "conflicting declarations of `%s'";
      return 0;
    }
  else if (current_binding_level->parm_flag
    && ((olddecl)->common.asm_written_flag) && !((newdecl)->common.asm_written_flag))
    return 0;
  else
    {




      if (!(((newdecl)->decl.external_flag) && ((olddecl)->decl.external_flag))
   && ((newdecl)->decl.context) == ((olddecl)->decl.context))
 return "redeclaration of `%s'";
      return 0;
    }
}





tree
lookup_label(tree id) asm("_lookup_label");
tree
lookup_label(tree id)
{
  register tree decl = (((struct n64_tag_lang_identifier *)(id))->label_value);

  if (current_function_decl == 0)
    {
      error ("label %s referenced outside of any function",
      ((id)->identifier.pointer));
      return 0;
    }


  if (decl != 0)
    {

      if (((decl)->decl.context) != current_function_decl
   && ! ((decl)->common.lang_flag_1))
 return shadow_label (id);
      return decl;
    }

  decl = build_decl (LABEL_DECL, id, void_type_node);


  label_rtx (decl);


  ((decl)->decl.context) = current_function_decl;

  ((decl)->decl.mode) = VOIDmode;



  ((decl)->decl.linenum) = lineno;
  ((decl)->decl.filename) = input_filename;

  (((struct n64_tag_lang_identifier *)(id))->label_value) = decl;

  named_labels = tree_cons ((tree) 
                           ((void *)0)
                                    , decl, named_labels);

  return decl;
}
tree
shadow_label(tree name) asm("_shadow_label");
tree
shadow_label(tree name)
{
  register tree decl = (((struct n64_tag_lang_identifier *)(name))->label_value);

  if (decl != 0)
    {
      register tree dup;



      for (dup = named_labels; dup; dup = ((dup)->common.chain))
 if (((dup)->list.value) == decl)
   {
     error ("duplicate label declaration `%s'",
     ((name)->identifier.pointer));
     error_with_decl (((dup)->list.value),
        "this is a previous declaration");

     return lookup_label (name);
   }

      shadowed_labels = tree_cons ((tree) 
                                  ((void *)0)
                                           , decl, shadowed_labels);
      (((struct n64_tag_lang_identifier *)(name))->label_value) = decl = 0;
    }

  return lookup_label (name);
}





tree
define_label(char *filename, int line, tree name) asm("_define_label");
tree
define_label(char *filename, int line, tree name)
{
  tree decl = lookup_label (name);


  if (decl != 0 && ((decl)->decl.context) != current_function_decl)
    {
      shadowed_labels = tree_cons ((tree) 
                                  ((void *)0)
                                           , decl, shadowed_labels);
      (((struct n64_tag_lang_identifier *)(name))->label_value) = 0;
      decl = lookup_label (name);
    }

  if (((decl)->decl.initial) != 0)
    {
      error ("duplicate label `%s'", ((name)->identifier.pointer));
      return 0;
    }
  else
    {

      ((decl)->decl.initial) = error_mark_node;

      ((decl)->decl.filename) = filename;
      ((decl)->decl.linenum) = line;
      return decl;
    }
}






tree
getdecls(void) asm("_getdecls");
tree
getdecls(void)
{
  return current_binding_level->names;
}



tree
gettags(void) asm("_gettags");
tree
gettags(void)
{
  return current_binding_level->tags;
}





static void
storedecls(tree decls) asm("_storedecls");
static void
storedecls(tree decls)
{
  current_binding_level->names = decls;
}



static void
storetags(tree tags) asm("_storetags");
static void
storetags(tree tags)
{
  current_binding_level->tags = tags;
}
static tree
lookup_tag(n64_enum_tree_code code, tree name, struct n64_tag_binding_level *binding_level, int thislevel_only) asm("_lookup_tag");
static tree
lookup_tag(n64_enum_tree_code code, tree name, struct n64_tag_binding_level *binding_level, int thislevel_only)
{
  register struct n64_tag_binding_level *level;

  for (level = binding_level; level; level = level->level_chain)
    {
      register tree tail;
      for (tail = level->tags; tail; tail = ((tail)->common.chain))
 {
   if (((tail)->list.purpose) == name)
     {
       if (((n64_enum_tree_code) (((tail)->list.value))->common.code) != code)
  {

    pending_invalid_xref = name;
    pending_invalid_xref_file = input_filename;
    pending_invalid_xref_line = lineno;
  }
       return ((tail)->list.value);
     }
 }
      if (thislevel_only && ! level->tag_transparent)
 return (tree) 
       ((void *)0)
                ;
    }
  return (tree) 
        ((void *)0)
                 ;
}






void
pending_xref_error(void) asm("_pending_xref_error");
void
pending_xref_error(void)
{
  if (pending_invalid_xref != 0)
    error_with_file_and_line (pending_invalid_xref_file,
         pending_invalid_xref_line,
         "`%s' defined as wrong kind of tag",
         ((pending_invalid_xref)->identifier.pointer));
  pending_invalid_xref = 0;
}




static tree
lookup_tag_reverse(tree type) asm("_lookup_tag_reverse");
static tree
lookup_tag_reverse(tree type)
{
  register struct n64_tag_binding_level *level;

  for (level = current_binding_level; level; level = level->level_chain)
    {
      register tree tail;
      for (tail = level->tags; tail; tail = ((tail)->common.chain))
 {
   if (((tail)->list.value) == type)
     return ((tail)->list.purpose);
 }
    }
  return (tree) 
        ((void *)0)
                 ;
}






tree
lookup_name(tree name) asm("_lookup_name");
tree
lookup_name(tree name)
{
  register tree val;
  if (current_binding_level != global_binding_level
      && (((struct n64_tag_lang_identifier *)(name))->local_value))
    val = (((struct n64_tag_lang_identifier *)(name))->local_value);
  else
    val = (((struct n64_tag_lang_identifier *)(name))->global_value);
  return val;
}



tree
lookup_name_current_level(tree name) asm("_lookup_name_current_level");
tree
lookup_name_current_level(tree name)
{
  register tree t;

  if (current_binding_level == global_binding_level)
    return (((struct n64_tag_lang_identifier *)(name))->global_value);

  if ((((struct n64_tag_lang_identifier *)(name))->local_value) == 0)
    return 0;

  for (t = current_binding_level->names; t; t = ((t)->common.chain))
    if (((t)->decl.name) == name)
      break;

  return t;
}




tree
lookup_name_current_level_global(tree name) asm("_lookup_name_current_level_global");
tree
lookup_name_current_level_global(tree name)
{
  register tree t = 0;

  if (current_binding_level == global_binding_level)
    return (((struct n64_tag_lang_identifier *)(name))->global_value);

  if ((((struct n64_tag_lang_identifier *)(name))->local_value) != 0)
    for (t = current_binding_level->names; t; t = ((t)->common.chain))
      if (((t)->decl.name) == name)
 break;

  if (t == 0)
    t = (((struct n64_tag_lang_identifier *)(name))->global_value);

  return t;
}






void
init_decl_processing(void) asm("_init_decl_processing");
void
init_decl_processing(void)
{
  register tree endlink;

  tree traditional_ptr_type_node;

  tree memcpy_ftype, strlen_ftype;
  tree void_ftype_any;
  int wchar_type_size;
  tree temp;
  tree array_domain_type;

  current_function_decl = 
                         ((void *)0)
                             ;
  named_labels = 
                ((void *)0)
                    ;
  current_binding_level = (struct n64_tag_binding_level *) 
                         ((void *)0)
                                           ;
  free_binding_level = (struct n64_tag_binding_level *) 
                      ((void *)0)
                                        ;
  pushlevel (0);
  global_binding_level = current_binding_level;



  integer_type_node = make_signed_type (((target_flags & 0x00000001) ? 64 : 32));
  pushdecl (build_decl (TYPE_DECL, ridpointers[(int) RID_INT],
   integer_type_node));




  char_type_node
    = (flag_signed_char
       ? make_signed_type (8)
       : make_unsigned_type (8));
  pushdecl (build_decl (TYPE_DECL, get_identifier ("char"),
   char_type_node));

  long_integer_type_node = make_signed_type (((target_flags & 0x00000002) ? 64 : 32));
  pushdecl (build_decl (TYPE_DECL, get_identifier ("long int"),
   long_integer_type_node));

  unsigned_type_node = make_unsigned_type (((target_flags & 0x00000001) ? 64 : 32));
  pushdecl (build_decl (TYPE_DECL, get_identifier ("unsigned int"),
   unsigned_type_node));

  long_unsigned_type_node = make_unsigned_type (((target_flags & 0x00000002) ? 64 : 32));
  pushdecl (build_decl (TYPE_DECL, get_identifier ("long unsigned int"),
   long_unsigned_type_node));

  long_long_integer_type_node = make_signed_type (64);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("long long int"),
   long_long_integer_type_node));

  long_long_unsigned_type_node = make_unsigned_type (64);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("long long unsigned int"),
   long_long_unsigned_type_node));





  sizetype
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("unsigned int")))->global_value))->common.type);
  if (flag_traditional && ((sizetype)->common.unsigned_flag))
    sizetype = signed_type (sizetype);

  ptrdiff_type_node
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("int")))->global_value))->common.type);

  ((((integer_type_node)->type.size))->common.type) = sizetype;
  ((((char_type_node)->type.size))->common.type) = sizetype;
  ((((unsigned_type_node)->type.size))->common.type) = sizetype;
  ((((long_unsigned_type_node)->type.size))->common.type) = sizetype;
  ((((long_integer_type_node)->type.size))->common.type) = sizetype;
  ((((long_long_integer_type_node)->type.size))->common.type) = sizetype;
  ((((long_long_unsigned_type_node)->type.size))->common.type) = sizetype;

  error_mark_node = make_node (ERROR_MARK);
  ((error_mark_node)->common.type) = error_mark_node;

  short_integer_type_node = make_signed_type (16);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("short int"),
   short_integer_type_node));

  short_unsigned_type_node = make_unsigned_type (16);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("short unsigned int"),
   short_unsigned_type_node));


  signed_char_type_node = make_signed_type (8);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("signed char"),
   signed_char_type_node));

  unsigned_char_type_node = make_unsigned_type (8);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("unsigned char"),
   unsigned_char_type_node));

  intQI_type_node = make_signed_type ((8 * mode_size[(int)(QImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intQI_type_node));

  intHI_type_node = make_signed_type ((8 * mode_size[(int)(HImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intHI_type_node));

  intSI_type_node = make_signed_type ((8 * mode_size[(int)(SImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intSI_type_node));

  intDI_type_node = make_signed_type ((8 * mode_size[(int)(DImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intDI_type_node));

  unsigned_intQI_type_node = make_unsigned_type ((8 * mode_size[(int)(QImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intQI_type_node));

  unsigned_intHI_type_node = make_unsigned_type ((8 * mode_size[(int)(HImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intHI_type_node));

  unsigned_intSI_type_node = make_unsigned_type ((8 * mode_size[(int)(SImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intSI_type_node));

  unsigned_intDI_type_node = make_unsigned_type ((8 * mode_size[(int)(DImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intDI_type_node));

  float_type_node = make_node (REAL_TYPE);
  ((float_type_node)->type.precision) = 32;
  pushdecl (build_decl (TYPE_DECL, ridpointers[(int) RID_FLOAT],
   float_type_node));
  layout_type (float_type_node);

  double_type_node = make_node (REAL_TYPE);
  if (flag_short_double)
    ((double_type_node)->type.precision) = 32;
  else
    ((double_type_node)->type.precision) = 64;
  pushdecl (build_decl (TYPE_DECL, ridpointers[(int) RID_DOUBLE],
   double_type_node));
  layout_type (double_type_node);

  long_double_type_node = make_node (REAL_TYPE);
  ((long_double_type_node)->type.precision) = 64;
  pushdecl (build_decl (TYPE_DECL, get_identifier ("long double"),
   long_double_type_node));
  layout_type (long_double_type_node);

  complex_integer_type_node = make_node (COMPLEX_TYPE);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("complex int"),
   complex_integer_type_node));
  ((complex_integer_type_node)->common.type) = integer_type_node;
  layout_type (complex_integer_type_node);

  complex_float_type_node = make_node (COMPLEX_TYPE);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("complex float"),
   complex_float_type_node));
  ((complex_float_type_node)->common.type) = float_type_node;
  layout_type (complex_float_type_node);

  complex_double_type_node = make_node (COMPLEX_TYPE);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("complex double"),
   complex_double_type_node));
  ((complex_double_type_node)->common.type) = double_type_node;
  layout_type (complex_double_type_node);

  complex_long_double_type_node = make_node (COMPLEX_TYPE);
  pushdecl (build_decl (TYPE_DECL, get_identifier ("complex long double"),
   complex_long_double_type_node));
  ((complex_long_double_type_node)->common.type) = long_double_type_node;
  layout_type (complex_long_double_type_node);

  wchar_type_node
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("long int")))->global_value))->common.type);
  wchar_type_size = ((wchar_type_node)->type.precision);
  signed_wchar_type_node = signed_type (wchar_type_node);
  unsigned_wchar_type_node = unsigned_type (wchar_type_node);

  integer_zero_node = build_int_2_wide ((int) (0), (int) (0));
  ((integer_zero_node)->common.type) = integer_type_node;
  integer_one_node = build_int_2_wide ((int) (1), (int) (0));
  ((integer_one_node)->common.type) = integer_type_node;

  boolean_type_node = integer_type_node;
  boolean_true_node = integer_one_node;
  boolean_false_node = integer_zero_node;

  size_zero_node = build_int_2_wide ((int) (0), (int) (0));
  ((size_zero_node)->common.type) = sizetype;
  size_one_node = build_int_2_wide ((int) (1), (int) (0));
  ((size_one_node)->common.type) = sizetype;

  void_type_node = make_node (VOID_TYPE);
  pushdecl (build_decl (TYPE_DECL,
   ridpointers[(int) RID_VOID], void_type_node));
  layout_type (void_type_node);


  ((void_type_node)->type.align) = 8;

  null_pointer_node = build_int_2_wide ((int) (0), (int) (0));
  ((null_pointer_node)->common.type) = build_pointer_type (void_type_node);
  layout_type (((null_pointer_node)->common.type));

  string_type_node = build_pointer_type (char_type_node);
  const_string_type_node
    = build_pointer_type (build_type_variant (char_type_node, 1, 0));






  array_domain_type = build_index_type (build_int_2_wide ((int) (200), (int) (0)));




  char_array_type_node
    = build_array_type (char_type_node, array_domain_type);

  int_array_type_node
    = build_array_type (integer_type_node, array_domain_type);

  wchar_array_type_node
    = build_array_type (wchar_type_node, array_domain_type);

  default_function_type
    = build_function_type (integer_type_node, (tree) 
                                             ((void *)0)
                                                      );

  ptr_type_node = build_pointer_type (void_type_node);
  const_ptr_type_node
    = build_pointer_type (build_type_variant (void_type_node, 1, 0));

  endlink = tree_cons ((tree) 
                      ((void *)0)
                               , void_type_node, (tree) 
                                                 ((void *)0)
                                                          );

  void_ftype_any
    = build_function_type (void_type_node, (tree) 
                                          ((void *)0)
                                                   );

  float_ftype_float
    = build_function_type (float_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , float_type_node, endlink));

  double_ftype_double
    = build_function_type (double_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , double_type_node, endlink));

  ldouble_ftype_ldouble
    = build_function_type (long_double_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , long_double_type_node,
          endlink));

  double_ftype_double_double
    = build_function_type (double_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , double_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       double_type_node, endlink)));

  int_ftype_int
    = build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , integer_type_node, endlink));

  long_ftype_long
    = build_function_type (long_integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          long_integer_type_node, endlink));

  void_ftype_ptr_ptr_int
    = build_function_type (void_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , ptr_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           integer_type_node,
           endlink))));

  int_ftype_cptr_cptr_sizet
    = build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , const_ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , const_ptr_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           sizetype,
           endlink))));

  void_ftype_ptr_int_int
    = build_function_type (void_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , integer_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           integer_type_node,
           endlink))));

  string_ftype_ptr_ptr
    = build_function_type (string_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , string_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       const_string_type_node,
       endlink)));

  int_ftype_string_string
    = build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , const_string_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       const_string_type_node,
       endlink)));

  strlen_ftype
    = build_function_type (flag_traditional ? integer_type_node : sizetype,
      tree_cons ((tree) 
                ((void *)0)
                         , const_string_type_node,
          endlink));

  traditional_ptr_type_node
    = (flag_traditional ? string_type_node : ptr_type_node);

  memcpy_ftype
    = build_function_type (traditional_ptr_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , const_ptr_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           sizetype,
           endlink))));

  builtin_function ("__builtin_constant_p", default_function_type,
      BUILT_IN_CONSTANT_P, ((void *)0));

  builtin_function ("__builtin_return_address",
      build_function_type (ptr_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          unsigned_type_node,
          endlink)),
      BUILT_IN_RETURN_ADDRESS, ((void *)0));

  builtin_function ("__builtin_frame_address",
      build_function_type (ptr_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          unsigned_type_node,
          endlink)),
      BUILT_IN_FRAME_ADDRESS, ((void *)0));

  builtin_function ("__builtin_alloca",
      build_function_type (ptr_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          sizetype,
          endlink)),
      BUILT_IN_ALLOCA, "alloca");
  builtin_function ("__builtin_ffs", int_ftype_int, BUILT_IN_FFS, ((void *)0));


  if (! flag_no_builtin && !flag_no_nonansi_builtin)
    {
      temp = builtin_function ("alloca",
          build_function_type (ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
              sizetype,
              endlink)),
          BUILT_IN_ALLOCA, ((void *)0));

      ((temp)->common.unsigned_flag) = 1;
      temp = builtin_function ("ffs", int_ftype_int, BUILT_IN_FFS, ((void *)0));

      ((temp)->common.unsigned_flag) = 1;
      temp = builtin_function ("_exit", void_ftype_any, NOT_BUILT_IN,
          ((void *)0));
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;

      ((temp)->common.unsigned_flag) = 1;
    }

  builtin_function ("__builtin_abs", int_ftype_int, BUILT_IN_ABS, ((void *)0));
  builtin_function ("__builtin_fabsf", float_ftype_float, BUILT_IN_FABS,
      ((void *)0));
  builtin_function ("__builtin_fabs", double_ftype_double, BUILT_IN_FABS,
      ((void *)0));
  builtin_function ("__builtin_fabsl", ldouble_ftype_ldouble, BUILT_IN_FABS,
      ((void *)0));
  builtin_function ("__builtin_labs", long_ftype_long, BUILT_IN_LABS,
      ((void *)0));
  builtin_function ("__builtin_saveregs",
      build_function_type (ptr_type_node, (tree) 
                                         ((void *)0)
                                                  ),
      BUILT_IN_SAVEREGS, ((void *)0));
  builtin_function ("__builtin_classify_type", default_function_type,
      BUILT_IN_CLASSIFY_TYPE, ((void *)0));
  builtin_function ("__builtin_next_arg",
      build_function_type (ptr_type_node, (tree) 
                                         ((void *)0)
                                                  ),
      BUILT_IN_NEXT_ARG, ((void *)0));
  builtin_function ("__builtin_args_info",
      build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          integer_type_node,
          endlink)),
      BUILT_IN_ARGS_INFO, ((void *)0));


  builtin_function ("__builtin_apply_args",
      build_function_type (ptr_type_node, (tree) 
                                         ((void *)0)
                                                  ),
      BUILT_IN_APPLY_ARGS, ((void *)0));

  temp = tree_cons ((tree) 
                   ((void *)0)
                            ,
      build_pointer_type (build_function_type (void_type_node,
            (tree) 
           ((void *)0)
                    )),
      tree_cons ((tree) 
                ((void *)0)
                         ,
          ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       sizetype,
       endlink)));
  builtin_function ("__builtin_apply",
      build_function_type (ptr_type_node, temp),
      BUILT_IN_APPLY, ((void *)0));
  builtin_function ("__builtin_return",
      build_function_type (void_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         ,
          ptr_type_node,
          endlink)),
      BUILT_IN_RETURN, ((void *)0));


  builtin_function ("__builtin_memcpy", memcpy_ftype,
      BUILT_IN_MEMCPY, "memcpy");
  builtin_function ("__builtin_memcmp", int_ftype_cptr_cptr_sizet,
      BUILT_IN_MEMCMP, "memcmp");
  builtin_function ("__builtin_strcmp", int_ftype_string_string,
      BUILT_IN_STRCMP, "strcmp");
  builtin_function ("__builtin_strcpy", string_ftype_ptr_ptr,
      BUILT_IN_STRCPY, "strcpy");
  builtin_function ("__builtin_strlen", strlen_ftype,
      BUILT_IN_STRLEN, "strlen");
  builtin_function ("__builtin_sqrtf", float_ftype_float,
      BUILT_IN_FSQRT, "sqrtf");
  builtin_function ("__builtin_fsqrt", double_ftype_double,
      BUILT_IN_FSQRT, "sqrt");
  builtin_function ("__builtin_sqrtl", ldouble_ftype_ldouble,
      BUILT_IN_FSQRT, "sqrtl");
  builtin_function ("__builtin_sinf", float_ftype_float,
      BUILT_IN_SIN, "sinf");
  builtin_function ("__builtin_sin", double_ftype_double,
      BUILT_IN_SIN, "sin");
  builtin_function ("__builtin_sinl", ldouble_ftype_ldouble,
      BUILT_IN_SIN, "sinl");
  builtin_function ("__builtin_cosf", float_ftype_float,
      BUILT_IN_COS, "cosf");
  builtin_function ("__builtin_cos", double_ftype_double,
      BUILT_IN_COS, "cos");
  builtin_function ("__builtin_cosl", ldouble_ftype_ldouble,
      BUILT_IN_COS, "cosl");





  if (!flag_no_builtin)
    {
      builtin_function ("abs", int_ftype_int, BUILT_IN_ABS, ((void *)0));
      builtin_function ("fabsf", float_ftype_float, BUILT_IN_FABS, ((void *)0));
      builtin_function ("fabs", double_ftype_double, BUILT_IN_FABS, ((void *)0));
      builtin_function ("fabsl", ldouble_ftype_ldouble, BUILT_IN_FABS,
   ((void *)0));
      builtin_function ("labs", long_ftype_long, BUILT_IN_LABS, ((void *)0));
      builtin_function ("memcpy", memcpy_ftype, BUILT_IN_MEMCPY, ((void *)0));
      builtin_function ("memcmp", int_ftype_cptr_cptr_sizet, BUILT_IN_MEMCMP,
   ((void *)0));
      builtin_function ("strcmp", int_ftype_string_string, BUILT_IN_STRCMP,
   ((void *)0));
      builtin_function ("strcpy", string_ftype_ptr_ptr, BUILT_IN_STRCPY,
   ((void *)0));
      builtin_function ("strlen", strlen_ftype, BUILT_IN_STRLEN, ((void *)0));
      builtin_function ("sqrtf", float_ftype_float, BUILT_IN_FSQRT, ((void *)0));
      builtin_function ("sqrt", double_ftype_double, BUILT_IN_FSQRT, ((void *)0));
      builtin_function ("sqrtl", ldouble_ftype_ldouble, BUILT_IN_FSQRT,
   ((void *)0));
      builtin_function ("sinf", float_ftype_float, BUILT_IN_SIN, ((void *)0));
      builtin_function ("sin", double_ftype_double, BUILT_IN_SIN, ((void *)0));
      builtin_function ("sinl", ldouble_ftype_ldouble, BUILT_IN_SIN, ((void *)0));
      builtin_function ("cosf", float_ftype_float, BUILT_IN_COS, ((void *)0));
      builtin_function ("cos", double_ftype_double, BUILT_IN_COS, ((void *)0));
      builtin_function ("cosl", ldouble_ftype_ldouble, BUILT_IN_COS, ((void *)0));





      temp = builtin_function ("abort", void_ftype_any, NOT_BUILT_IN,
          ((void *)0));
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;
      temp = builtin_function ("exit", void_ftype_any, NOT_BUILT_IN, ((void *)0));
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;
    }
  pedantic_lvalues = pedantic;


  declare_function_name ();

  start_identifier_warnings ();


  init_function_format_info ();

  init_iterators ();

  incomplete_decl_finalize_hook = finish_incomplete_decl;
}
tree
builtin_function(char *name, tree type, n64_enum_built_in_function function_code, char *library_name) asm("_builtin_function");
tree
builtin_function(char *name, tree type, n64_enum_built_in_function function_code, char *library_name)
{
  tree decl = build_decl (FUNCTION_DECL, get_identifier (name), type);
  ((decl)->decl.external_flag) = 1;
  ((decl)->common.public_flag) = 1;



  if (flag_traditional && name[0] != '_')
    ((decl)->common.unsigned_flag) = 1;
  if (library_name)
    ((decl)->decl.assembler_name) = get_identifier (library_name);
  make_decl_rtl (decl, ((void *)0), 1);
  pushdecl (decl);
  if (function_code != NOT_BUILT_IN)
    {
      ((decl)->decl.bit_field_flag) = 1;
      ((decl)->decl.frame_size.f) = function_code;
    }


  if (name[0] != '_' || name[1] != '_')
    (((decl))->decl.lang_flag_3) = 1;

  return decl;
}
void
shadow_tag(tree declspecs) asm("_shadow_tag");
void
shadow_tag(tree declspecs)
{
  shadow_tag_warned (declspecs, 0);
}

void
shadow_tag_warned(tree declspecs, int warned) asm("_shadow_tag_warned");
void
shadow_tag_warned(tree declspecs, int warned)
{
  int found_tag = 0;
  register tree link;

  pending_invalid_xref = 0;

  for (link = declspecs; link; link = ((link)->common.chain))
    {
      register tree value = ((link)->list.value);
      register n64_enum_tree_code code = ((n64_enum_tree_code) (value)->common.code);

      if (code == RECORD_TYPE || code == UNION_TYPE || code == ENUMERAL_TYPE)


 {
   register tree name = lookup_tag_reverse (value);
   register tree t;

   found_tag++;

   if (name == 0)
     {
       if (warned != 1 && code != ENUMERAL_TYPE)

  {
    pedwarn ("unnamed struct/union that defines no instances");
    warned = 1;
  }
     }
   else
     {
       t = lookup_tag (code, name, current_binding_level, 1);

       if (t == 0)
  {
    t = make_node (code);
    pushtag (name, t);
  }
     }
 }
      else
 {
   if (!warned && ! in_system_header)
     {
       warning ("useless keyword or type name in empty declaration");
       warned = 2;
     }
 }
    }

  if (found_tag > 1)
    error ("two types specified in one empty declaration");

  if (warned != 1)
    {
      if (found_tag == 0)
 pedwarn ("empty declaration");
    }
}



tree
groktypename(tree cxx_typename) asm("_groktypename");
tree
groktypename(tree cxx_typename)
{
  if (((n64_enum_tree_code) (cxx_typename)->common.code) != TREE_LIST)
    return cxx_typename;
  return grokdeclarator (((cxx_typename)->list.value),
    ((cxx_typename)->list.purpose),
    TYPENAME, 0);
}



tree
groktypename_in_parm_context(tree cxx_typename) asm("_groktypename_in_parm_context");
tree
groktypename_in_parm_context(tree cxx_typename)
{
  if (((n64_enum_tree_code) (cxx_typename)->common.code) != TREE_LIST)
    return cxx_typename;
  return grokdeclarator (((cxx_typename)->list.value),
    ((cxx_typename)->list.purpose),
    PARM, 0);
}
int debug_temp_inits = 1;

tree
start_decl(tree declarator, tree declspecs, int initialized, tree attributes, tree prefix_attributes) asm("_start_decl");
tree
start_decl(tree declarator, tree declspecs, int initialized, tree attributes, tree prefix_attributes)
{
  register tree decl = grokdeclarator (declarator, declspecs,
           NORMAL, initialized);
  register tree tem;
  int init_written = initialized;


  push_obstacks_nochange ();

  if (initialized)



    switch (((n64_enum_tree_code) (decl)->common.code))
      {
      case TYPE_DECL:



 if (pedantic || list_length (declspecs) > 1)
   {
     error ("typedef `%s' is initialized",
     ((((decl)->decl.name))->identifier.pointer));
     initialized = 0;
   }
 break;

      case FUNCTION_DECL:
 error ("function `%s' is initialized like a variable",
        ((((decl)->decl.name))->identifier.pointer));
 initialized = 0;
 break;

      case PARM_DECL:

 error ("parameter `%s' is initialized",
        ((((decl)->decl.name))->identifier.pointer));
 initialized = 0;
 break;

      default:


 if (((((decl)->common.type))->type.size) != 0)
   {


     if (((n64_enum_tree_code) (((((decl)->common.type))->type.size))->common.code) != INTEGER_CST
  || ((decl)->decl.lang_flag_0))
       {
  error ("variable-sized object may not be initialized");
  initialized = 0;
       }
   }
 else if (((n64_enum_tree_code) (((decl)->common.type))->common.code) != ARRAY_TYPE)
   {
     error ("variable `%s' has initializer but incomplete type",
     ((((decl)->decl.name))->identifier.pointer));
     initialized = 0;
   }
 else if (((((((decl)->common.type))->common.type))->type.size) == 0)
   {
     error ("elements of array `%s' have incomplete type",
     ((((decl)->decl.name))->identifier.pointer));
     initialized = 0;
   }
      }

  if (initialized)
    {







      ((decl)->decl.external_flag) = 0;
      if (current_binding_level == global_binding_level)
 ((decl)->common.static_flag) = 1;




      ((decl)->decl.initial) = error_mark_node;
    }




  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    gen_aux_info_record (decl, 0, 0, ((((decl)->common.type))->type.values) != 0);



  ((decl)->decl.common_flag) = 1;


  decl_attributes (decl, attributes, prefix_attributes);



  tem = pushdecl (decl);


  if (current_binding_level != global_binding_level



      && ((tem)->decl.rtl) == 0)
    {
      if (((((tem)->common.type))->type.size) != 0)
 expand_decl (tem);
      else if (((n64_enum_tree_code) (((tem)->common.type))->common.code) == ARRAY_TYPE
        && ((tem)->decl.initial) != 0)
 expand_decl (tem);
    }

  if (init_written)
    {


      if (current_binding_level == global_binding_level && debug_temp_inits)
 temporary_allocation ();
    }

  return tem;
}






void
finish_decl(tree decl, tree init, tree asmspec_tree) asm("_finish_decl");
void
finish_decl(tree decl, tree init, tree asmspec_tree)
{
  register tree type = ((decl)->common.type);
  int was_incomplete = (((decl)->decl.size) == 0);
  int temporary = allocation_temporary_p ();
  char *asmspec = 0;


  if (asmspec_tree)
    asmspec = ((asmspec_tree)->string.pointer);



  if (init != 0 && ((decl)->decl.initial) == 0)
    init = 0;

  if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
    init = 0;

  if ((((decl)->decl.lang_flag_4)))
    {
      if (init == 0)
 error_with_decl (decl, "iterator has no initial value");
      else
 init = save_expr (init);
    }

  if (init)
    {
      if (((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
 store_init_value (decl, init);
      else
 {

   ((decl)->common.type) = ((init)->common.type);
   ((decl)->decl.initial) = init = 0;
 }
    }





  pop_obstacks ();







  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
      && ((type)->type.values) == 0
      && ((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
    {
      int do_default
 = (((decl)->common.static_flag)


    ? pedantic && !((decl)->common.public_flag)
    : !((decl)->decl.external_flag));
      int failure
 = complete_array_type (type, ((decl)->decl.initial), do_default);


      type = ((decl)->common.type);

      if (failure == 1)
 error_with_decl (decl, "initializer fails to determine size of `%s'");

      if (failure == 2)
 {
   if (do_default)
     error_with_decl (decl, "array size missing in `%s'");






   else if (!pedantic && ((decl)->common.static_flag) && ! ((decl)->common.public_flag))
     ((decl)->decl.external_flag) = 1;
 }




      if (pedantic && ((type)->type.values) != 0
   && tree_int_cst_sgn (((((type)->type.values))->type.maxval)) < 0)
 error_with_decl (decl, "zero or negative size array `%s'");

      layout_decl (decl, 0);
    }

  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
    {
      if (((decl)->decl.size) == 0
   && ((((decl)->common.type))->type.size) != 0)
 layout_decl (decl, 0);

      if (((decl)->decl.size) == 0
   && (((decl)->common.static_flag)
       ?
  (((decl)->decl.initial) != 0 || ((decl)->decl.context) != 0)
       :


  !((decl)->decl.external_flag)))
 {
   error_with_decl (decl, "storage size of `%s' isn't known");
   ((decl)->common.type) = error_mark_node;
 }

      if ((((decl)->decl.external_flag) || ((decl)->common.static_flag))
   && ((decl)->decl.size) != 0)
 {
   if (((n64_enum_tree_code) (((decl)->decl.size))->common.code) == INTEGER_CST)
     constant_expression_warning (((decl)->decl.size));
   else
     error_with_decl (decl, "storage size of `%s' isn't constant");
 }
    }




  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && asmspec)
      {
 ((decl)->decl.bit_field_flag) = 0;
 ((decl)->decl.rtl) = 0;
      }





  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL || ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    {
      if ((flag_traditional || ((decl)->common.permanent_flag))
   && allocation_temporary_p ())
 {
   push_obstacks_nochange ();
   end_temporary_allocation ();

   maybe_objc_check_decl (decl);
   rest_of_decl_compilation (decl, asmspec, ((decl)->decl.context) == 0,
        0);
   pop_obstacks ();
 }
      else
 {

   maybe_objc_check_decl (decl);
   rest_of_decl_compilation (decl, asmspec, ((decl)->decl.context) == 0,
        0);
 }
      if (((decl)->decl.context) != 0)
 {


   if (was_incomplete
       && ! ((decl)->common.static_flag) && ! ((decl)->decl.external_flag))
     {

       ((decl)->common.addressable_flag) = ((decl)->common.used_flag);

       if (((decl)->decl.size) == 0)
  ((decl)->decl.initial) = 0;
       expand_decl (decl);
     }

   if (((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL)
     expand_decl_init (decl);
 }
    }

  if (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL)
    {

      maybe_objc_check_decl (decl);
      rest_of_decl_compilation (decl, ((void *)0), ((decl)->decl.context) == 0,
    0);
    }





  if (!(((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.inline_flag))
      && temporary


      && ((n64_enum_tree_code) (decl)->common.code) != PARM_DECL)
    {






      if (((decl)->decl.initial) != 0 && ((decl)->decl.initial) != error_mark_node)
 {





   if (((decl)->common.readonly_flag) || (((decl)->decl.lang_flag_4)))
     {
       preserve_initializer ();




       ((((decl)->decl.initial))->common.permanent_flag) = 1;





       ((((decl)->decl.initial))->common.type) = type;
     }
   else
     ((decl)->decl.initial) = error_mark_node;
 }
    }



  if (warn_larger_than
      && (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL || ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
      && !((decl)->decl.external_flag))
    {
      register tree decl_size = ((decl)->decl.size);

      if (decl_size && ((n64_enum_tree_code) (decl_size)->common.code) == INTEGER_CST)
 {
    unsigned units = ((decl_size)->int_cst.int_cst_low) / 8;

   if (units > larger_than_size)
     warning_with_decl (decl, "size of `%s' is %u bytes", units);
 }
    }
  if (temporary && !allocation_temporary_p ())
    permanent_allocation (0);




  if (current_binding_level == global_binding_level)
    get_pending_sizes ();
}




tree
maybe_build_cleanup(tree decl) asm("_maybe_build_cleanup");
tree
maybe_build_cleanup(tree decl)
{

  return (tree) 
        ((void *)0)
                 ;
}






void
push_parm_decl(tree parm) asm("_push_parm_decl");
void
push_parm_decl(tree parm)
{
  tree decl;
  int old_immediate_size_expand = immediate_size_expand;

  immediate_size_expand = 0;


  push_obstacks_nochange ();

  decl = grokdeclarator (((((parm)->list.purpose))->list.value),
    ((((parm)->list.purpose))->list.purpose), PARM, 0);
  decl_attributes (decl, ((((parm)->list.value))->list.value),
     ((((parm)->list.value))->list.purpose));
  decl = pushdecl (decl);

  immediate_size_expand = old_immediate_size_expand;

  current_binding_level->parm_order
    = tree_cons ((tree) 
                ((void *)0)
                         , decl, current_binding_level->parm_order);


  finish_decl (decl, (tree) 
                    ((void *)0)
                             , (tree) 
                               ((void *)0)
                                        );
}





void
clear_parm_order(void) asm("_clear_parm_order");
void
clear_parm_order(void)
{
  current_binding_level->parm_order = (tree) 
                                     ((void *)0)
                                              ;
}





int
complete_array_type(tree type, tree initial_value, int do_default) asm("_complete_array_type");
int
complete_array_type(tree type, tree initial_value, int do_default)
{
  register tree maxindex = (tree) 
                          ((void *)0)
                                   ;
  int value = 0;

  if (initial_value)
    {


      if (((n64_enum_tree_code) (initial_value)->common.code) == STRING_CST)
 {
   int eltsize
     = int_size_in_bytes (((((initial_value)->common.type))->common.type));
   maxindex = build_int_2_wide ((int) ((((initial_value)->string.length) / eltsize) - 1), (int) (0))
                         ;
 }
      else if (((n64_enum_tree_code) (initial_value)->common.code) == CONSTRUCTOR)
 {
   tree elts = ((initial_value)->exp.operands[1]);
   maxindex = size_binop (MINUS_EXPR, integer_zero_node, size_one_node);
   for (; elts; elts = ((elts)->common.chain))
     {
       if (((elts)->list.purpose))
  maxindex = ((elts)->list.purpose);
       else
  maxindex = size_binop (PLUS_EXPR, maxindex, size_one_node);
     }
   maxindex = copy_node (maxindex);
 }
      else
 {

   if (initial_value != error_mark_node)
     value = 1;


   maxindex = build_int_2_wide ((int) (0), (int) (0));
 }
    }

  if (!maxindex)
    {
      if (do_default)
 maxindex = build_int_2_wide ((int) (0), (int) (0));
      value = 2;
    }

  if (maxindex)
    {
      ((type)->type.values) = build_index_type (maxindex);
      if (!((maxindex)->common.type))
 ((maxindex)->common.type) = ((type)->type.values);






    }



  layout_type (type);

  return value;
}
static tree
grokdeclarator(tree declarator, tree declspecs, n64_enum_decl_context decl_context, int initialized) asm("_grokdeclarator");
static tree
grokdeclarator(tree declarator, tree declspecs, n64_enum_decl_context decl_context, int initialized)
{
  int specbits = 0;
  tree spec;
  tree type = (tree) 
             ((void *)0)
                      ;
  int longlong = 0;
  int constp;
  int volatilep;
  int inlinep;
  int explicit_int = 0;
  int explicit_char = 0;
  int defaulted_int = 0;
  tree typedef_decl = 0;
  char *name;
  tree typedef_type = 0;
  int funcdef_flag = 0;
  n64_enum_tree_code innermost_code = ERROR_MARK;
  int bitfield = 0;
  int size_varies = 0;
  tree decl_machine_attr = (tree) 
                          ((void *)0)
                                   ;

  if (decl_context == BITFIELD)
    bitfield = 1, decl_context = FIELD;

  if (decl_context == FUNCDEF)
    funcdef_flag = 1, decl_context = NORMAL;

  push_obstacks_nochange ();

  if (flag_traditional && allocation_temporary_p ())
    end_temporary_allocation ();



  {
    register tree decl = declarator;
    name = 0;

    while (decl)
      switch (((n64_enum_tree_code) (decl)->common.code))
 {
 case ARRAY_REF:
 case INDIRECT_REF:
 case CALL_EXPR:
   innermost_code = ((n64_enum_tree_code) (decl)->common.code);
   decl = ((decl)->exp.operands[0]);
   break;

 case IDENTIFIER_NODE:
   name = ((decl)->identifier.pointer);
   decl = 0;
   break;

 default:
   abort ();
 }
    if (name == 0)
      name = "type name";
  }




  if (funcdef_flag && innermost_code != CALL_EXPR)
    return 0;
  if (decl_context == NORMAL && !funcdef_flag
      && current_binding_level->parm_flag)
    decl_context = PARM;
  for (spec = declspecs; spec; spec = ((spec)->common.chain))
    {
      register int i;
      register tree id = ((spec)->list.value);

      if (id == ridpointers[(int) RID_INT])
 explicit_int = 1;
      if (id == ridpointers[(int) RID_CHAR])
 explicit_char = 1;

      if (((n64_enum_tree_code) (id)->common.code) == IDENTIFIER_NODE)
 for (i = (int) RID_UNSIGNED; i < (int) RID_MAX; i++)
   {
     if (ridpointers[i] == id)
       {
  if (i == (int) RID_LONG && specbits & (1<<i))
    {
      if (longlong)
        error ("`long long long' is too long for GCC");
      else
        {
   if (pedantic && ! in_system_header)
     pedwarn ("ANSI C does not support `long long'");
   longlong = 1;
        }
    }
  else if (specbits & (1 << i))
    pedwarn ("duplicate `%s'", ((id)->identifier.pointer));
  specbits |= 1 << i;
  goto found;
       }
   }
      if (type)
 error ("two or more data types in declaration of `%s'", name);

      else if (((n64_enum_tree_code) (id)->common.code) == TYPE_DECL)
 {
   type = ((id)->common.type);
          decl_machine_attr = ((id)->decl.machine_attributes);
   typedef_decl = id;
 }

      else if (((n64_enum_tree_code) (id)->common.code) == IDENTIFIER_NODE)
 {
   register tree t = lookup_name (id);
   if (((t)->common.type) == error_mark_node)
     ;
   else if (!t || ((n64_enum_tree_code) (t)->common.code) != TYPE_DECL)
     error ("`%s' fails to be a typedef or built in type",
     ((id)->identifier.pointer));
   else
     {
       type = ((t)->common.type);
       typedef_decl = t;
     }
 }
      else if (((n64_enum_tree_code) (id)->common.code) != ERROR_MARK)
 type = id;

    found: {}
    }

  typedef_type = type;
  if (type)
    size_varies = ((type)->type.lang_flag_1);




  if (type == 0)
    {
      if (funcdef_flag && warn_return_type
   && ! (specbits & ((1 << (int) RID_LONG) | (1 << (int) RID_SHORT)
       | (1 << (int) RID_SIGNED) | (1 << (int) RID_UNSIGNED))))
 warn_about_return_type = 1;
      defaulted_int = 1;
      type = integer_type_node;
    }






  if ((specbits & 1 << (int) RID_LONG)
      && ((type)->type.main_variant) == double_type_node)
    {
      specbits &= ~ (1 << (int) RID_LONG);
      type = long_double_type_node;
    }



  if (specbits & ((1 << (int) RID_LONG) | (1 << (int) RID_SHORT)
    | (1 << (int) RID_UNSIGNED) | (1 << (int) RID_SIGNED)))
    {
      int ok = 0;

      if (((n64_enum_tree_code) (type)->common.code) != INTEGER_TYPE)
 error ("long, short, signed or unsigned invalid for `%s'", name);
      else if ((specbits & 1 << (int) RID_LONG)
        && (specbits & 1 << (int) RID_SHORT))
 error ("long and short specified together for `%s'", name);
      else if (((specbits & 1 << (int) RID_LONG)
  || (specbits & 1 << (int) RID_SHORT))
        && explicit_char)
 error ("long or short specified with char for `%s'", name);
      else if (((specbits & 1 << (int) RID_LONG)
  || (specbits & 1 << (int) RID_SHORT))
        && ((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
 error ("long or short specified with floating type for `%s'", name);
      else if ((specbits & 1 << (int) RID_SIGNED)
        && (specbits & 1 << (int) RID_UNSIGNED))
 error ("signed and unsigned given together for `%s'", name);
      else
 {
   ok = 1;
   if (!explicit_int && !defaulted_int && !explicit_char && pedantic)
     {
       pedwarn ("long, short, signed or unsigned used invalidly for `%s'",
         name);
       if (flag_pedantic_errors)
  ok = 0;
     }
 }


      if (! ok)
 {
   specbits &= ~((1 << (int) RID_LONG) | (1 << (int) RID_SHORT)
   | (1 << (int) RID_UNSIGNED) | (1 << (int) RID_SIGNED));
   longlong = 0;
 }
    }

  if ((specbits & (1 << (int) RID_COMPLEX))
      && ((n64_enum_tree_code) (type)->common.code) != INTEGER_TYPE && ((n64_enum_tree_code) (type)->common.code) != REAL_TYPE)
    {
      error ("complex invalid for `%s'", name);
      specbits &= ~ (1 << (int) RID_COMPLEX);
    }



  if (specbits & 1 << (int) RID_UNSIGNED

      || (bitfield && flag_traditional
   && (! explicit_flag_signed_bitfields || !flag_signed_bitfields))
      || (bitfield && ! flag_signed_bitfields
   && (explicit_int || defaulted_int || explicit_char


       || ! (typedef_decl != 0
      && (((typedef_decl))->decl.lang_flag_1)))
   && ((n64_enum_tree_code) (type)->common.code) != ENUMERAL_TYPE
   && !(specbits & 1 << (int) RID_SIGNED)))
    {
      if (longlong)
 type = long_long_unsigned_type_node;
      else if (specbits & 1 << (int) RID_LONG)
 type = long_unsigned_type_node;
      else if (specbits & 1 << (int) RID_SHORT)
 type = short_unsigned_type_node;
      else if (type == char_type_node)
 type = unsigned_char_type_node;
      else if (typedef_decl)
 type = unsigned_type (type);
      else
 type = unsigned_type_node;
    }
  else if ((specbits & 1 << (int) RID_SIGNED)
    && type == char_type_node)
    type = signed_char_type_node;
  else if (longlong)
    type = long_long_integer_type_node;
  else if (specbits & 1 << (int) RID_LONG)
    type = long_integer_type_node;
  else if (specbits & 1 << (int) RID_SHORT)
    type = short_integer_type_node;

  if (specbits & 1 << (int) RID_COMPLEX)
    {





      if (defaulted_int && ! longlong
   && ! (specbits & ((1 << (int) RID_LONG) | (1 << (int) RID_SHORT)
       | (1 << (int) RID_SIGNED)
       | (1 << (int) RID_UNSIGNED))))
 type = complex_double_type_node;
      else if (type == integer_type_node)
 type = complex_integer_type_node;
      else if (type == float_type_node)
 type = complex_float_type_node;
      else if (type == double_type_node)
 type = complex_double_type_node;
      else if (type == long_double_type_node)
 type = complex_long_double_type_node;
      else
 type = build_complex_type (type);
    }





  constp = !! (specbits & 1 << (int) RID_CONST) + ((type)->common.readonly_flag);
  volatilep = !! (specbits & 1 << (int) RID_VOLATILE) + ((type)->common.volatile_flag);
  inlinep = !! (specbits & (1 << (int) RID_INLINE));
  if (constp > 1)
    pedwarn ("duplicate `const'");
  if (volatilep > 1)
    pedwarn ("duplicate `volatile'");
  if (! flag_gen_aux_info && (((type)->common.readonly_flag) || ((type)->common.volatile_flag)))
    type = ((type)->type.main_variant);



  {
    int nclasses = 0;

    if (specbits & 1 << (int) RID_AUTO) nclasses++;
    if (specbits & 1 << (int) RID_STATIC) nclasses++;
    if (specbits & 1 << (int) RID_EXTERN) nclasses++;
    if (specbits & 1 << (int) RID_REGISTER) nclasses++;
    if (specbits & 1 << (int) RID_TYPEDEF) nclasses++;
    if (specbits & 1 << (int) RID_ITERATOR) nclasses++;




    if (nclasses > 1)
      error ("multiple storage classes in declaration of `%s'", name);
    else if (funcdef_flag
      && (specbits
   & ((1 << (int) RID_REGISTER)
      | (1 << (int) RID_AUTO)
      | (1 << (int) RID_TYPEDEF))))
      {
 if (specbits & 1 << (int) RID_AUTO
     && (pedantic || current_binding_level == global_binding_level))
   pedwarn ("function definition declared `auto'");
 if (specbits & 1 << (int) RID_REGISTER)
   error ("function definition declared `register'");
 if (specbits & 1 << (int) RID_TYPEDEF)
   error ("function definition declared `typedef'");
 specbits &= ~ ((1 << (int) RID_TYPEDEF) | (1 << (int) RID_REGISTER)
         | (1 << (int) RID_AUTO));
      }
    else if (decl_context != NORMAL && nclasses > 0)
      {
 if (decl_context == PARM && specbits & 1 << (int) RID_REGISTER)
   ;
 else
   {
     error ((decl_context == FIELD
      ? "storage class specified for structure field `%s'"
      : (decl_context == PARM
         ? "storage class specified for parameter `%s'"
         : "storage class specified for typename")),
     name);
     specbits &= ~ ((1 << (int) RID_TYPEDEF) | (1 << (int) RID_REGISTER)
      | (1 << (int) RID_AUTO) | (1 << (int) RID_STATIC)
      | (1 << (int) RID_EXTERN));
   }
      }
    else if (specbits & 1 << (int) RID_EXTERN && initialized && ! funcdef_flag)
      {

 if (current_binding_level == global_binding_level)
   warning ("`%s' initialized and declared `extern'", name);
 else
   error ("`%s' has both `extern' and initializer", name);
      }
    else if (specbits & 1 << (int) RID_EXTERN && funcdef_flag
      && current_binding_level != global_binding_level)
      error ("nested function `%s' declared `extern'", name);
    else if (current_binding_level == global_binding_level
      && specbits & (1 << (int) RID_AUTO))
      error ("top-level declaration of `%s' specifies `auto'", name);
    else if ((specbits & 1 << (int) RID_ITERATOR)
      && ((n64_enum_tree_code) (declarator)->common.code) != IDENTIFIER_NODE)
      {
 error ("iterator `%s' has derived type", name);
 type = error_mark_node;
      }
    else if ((specbits & 1 << (int) RID_ITERATOR)
      && ((n64_enum_tree_code) (type)->common.code) != INTEGER_TYPE)
      {
 error ("iterator `%s' has noninteger type", name);
 type = error_mark_node;
      }
  }





  while (declarator && ((n64_enum_tree_code) (declarator)->common.code) != IDENTIFIER_NODE)
    {
      if (type == error_mark_node)
 {
   declarator = ((declarator)->exp.operands[0]);
   continue;
 }
      if (((n64_enum_tree_code) (declarator)->common.code) == ARRAY_REF)
 {
   register tree itype = (tree) 
                        ((void *)0)
                                 ;
   register tree size = ((declarator)->exp.operands[1]);

   int extern_ref = !initialized && (specbits & (1 << (int) RID_EXTERN));

   tree index_type = signed_type (sizetype);

   declarator = ((declarator)->exp.operands[0]);



   if (((type)->type.main_variant) == void_type_node)
     {
       error ("declaration of `%s' as array of voids", name);
       type = error_mark_node;
     }

   if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
     {
       error ("declaration of `%s' as array of functions", name);
       type = error_mark_node;
     }

   if (size == error_mark_node)
     type = error_mark_node;

   if (type == error_mark_node)
     continue;




   if (extern_ref && allocation_temporary_p ())
     end_temporary_allocation ();





   if (size)
     {

       while ((((n64_enum_tree_code) (size)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (size)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (size)->common.code) == NON_LVALUE_EXPR) && (((size)->common.type) == ((((size)->exp.operands[0]))->common.type))) (size) = ((size)->exp.operands[0]);;

       if (((n64_enum_tree_code) (((size)->common.type))->common.code) != INTEGER_TYPE
    && ((n64_enum_tree_code) (((size)->common.type))->common.code) != ENUMERAL_TYPE)
  {
    error ("size of array `%s' has non-integer type", name);
    size = integer_one_node;
  }

       if (pedantic && integer_zerop (size))
  pedwarn ("ANSI C forbids zero-size array `%s'", name);

       if (((n64_enum_tree_code) (size)->common.code) == INTEGER_CST)
  {
    constant_expression_warning (size);
    if (tree_int_cst_sgn (size) < 0)
      {
        error ("size of array `%s' is negative", name);
        size = integer_one_node;
      }
  }
       else
  {


    size_varies = 1;

    if (pedantic)
      {
        if (((size)->common.constant_flag))
   pedwarn ("ANSI C forbids array `%s' whose size can't be evaluated", name);
        else
   pedwarn ("ANSI C forbids variable-size array `%s'", name);
      }
  }



       itype = fold (build (MINUS_EXPR, index_type,
       convert (index_type, size),
       convert (index_type, size_one_node)));

       if (size_varies)
  itype = variable_size (itype);
       itype = build_index_type (itype);
     }
   type = build_array_type (type, itype);
   if (constp || volatilep)
     type = c_build_type_variant (type, constp, volatilep);







   if (size_varies)
     ((type)->type.lang_flag_1) = 1;
 }
      else if (((n64_enum_tree_code) (declarator)->common.code) == CALL_EXPR)
 {
   int extern_ref = (!(specbits & (1 << (int) RID_AUTO))
       || current_binding_level == global_binding_level);
   tree arg_types;



   if (type == error_mark_node)
     continue;

   size_varies = 0;



   if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
     {
       error ("`%s' declared as function returning a function", name);
       type = integer_type_node;
     }
   if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
     {
       error ("`%s' declared as function returning an array", name);
       type = integer_type_node;
     }




   if (flag_traditional && ((type)->type.main_variant) == float_type_node)
     type = double_type_node;





   if (extern_ref && allocation_temporary_p ())
     end_temporary_allocation ();




   arg_types = grokparms (((declarator)->exp.operands[1]),
     funcdef_flag



     && ((n64_enum_tree_code) (((declarator)->exp.operands[0]))->common.code) == IDENTIFIER_NODE);
   if (constp || volatilep)
     type = c_build_type_variant (type, constp, volatilep);
   constp = 0;
   volatilep = 0;

   type = build_function_type (type, arg_types);
   declarator = ((declarator)->exp.operands[0]);





   {
     register tree link;

     for (link = current_function_parm_tags;
   link;
   link = ((link)->common.chain))
       ((((link)->list.value))->type.context) = type;
   }
 }
      else if (((n64_enum_tree_code) (declarator)->common.code) == INDIRECT_REF)
 {



   if (pedantic && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
       && (constp || volatilep))
     pedwarn ("ANSI C forbids const or volatile function types");
   if (constp || volatilep)
     type = c_build_type_variant (type, constp, volatilep);
   constp = 0;
   volatilep = 0;
   size_varies = 0;

   type = build_pointer_type (type);




   if (((declarator)->common.type))
     {
       register tree typemodlist;
       int erred = 0;
       for (typemodlist = ((declarator)->common.type); typemodlist;
     typemodlist = ((typemodlist)->common.chain))
  {
    if (((typemodlist)->list.value) == ridpointers[(int) RID_CONST])
      constp++;
    else if (((typemodlist)->list.value) == ridpointers[(int) RID_VOLATILE])
      volatilep++;
    else if (!erred)
      {
        erred = 1;
        error ("invalid type modifier within pointer declarator");
      }
  }
       if (constp > 1)
  pedwarn ("duplicate `const'");
       if (volatilep > 1)
  pedwarn ("duplicate `volatile'");
     }

   declarator = ((declarator)->exp.operands[0]);
 }
      else
 abort ();

    }





  if (specbits & (1 << (int) RID_TYPEDEF))
    {
      tree decl;


      if (pedantic && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
   && (constp || volatilep))
 pedwarn ("ANSI C forbids const or volatile function types");
      if (constp || volatilep)
 type = c_build_type_variant (type, constp, volatilep);
      pop_obstacks ();
      decl = build_decl (TYPE_DECL, declarator, type);
      if ((specbits & (1 << (int) RID_SIGNED))
   || (typedef_decl && (((typedef_decl))->decl.lang_flag_1)))
 (((decl))->decl.lang_flag_1) = 1;
      return decl;
    }







  if (type != 0 && typedef_type != 0
      && ((type)->type.main_variant) == ((typedef_type)->type.main_variant)
      && ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && ((type)->type.values) == 0)
    {
      type = build_array_type (((type)->common.type), 0);
      if (size_varies)
 ((type)->type.lang_flag_1) = 1;
    }




  if (decl_context == TYPENAME)
    {


      if (pedantic && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
   && (constp || volatilep))
 pedwarn ("ANSI C forbids const or volatile function types");
      if (constp || volatilep)
 type = c_build_type_variant (type, constp, volatilep);
      pop_obstacks ();
      return type;
    }







  if (((type)->type.main_variant) == void_type_node && decl_context != PARM
      && ! ((decl_context != FIELD && ((n64_enum_tree_code) (type)->common.code) != FUNCTION_TYPE)
     && ((specbits & (1 << (int) RID_EXTERN))
  || (current_binding_level == global_binding_level
      && !(specbits
    & ((1 << (int) RID_STATIC) | (1 << (int) RID_REGISTER)))))))
    {
      error ("variable or field `%s' declared void", name);
      type = integer_type_node;
    }




  {
    register tree decl;

    if (decl_context == PARM)
      {
 tree type_as_written = type;
 tree main_type;




 if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
   {

     type = ((type)->common.type);
     if (constp || volatilep)
       type = c_build_type_variant (type, constp, volatilep);
     type = build_pointer_type (type);
     volatilep = constp = 0;
     size_varies = 0;
   }
 else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
   {
     if (pedantic && (constp || volatilep))
       pedwarn ("ANSI C forbids const or volatile function types");
     if (constp || volatilep)
       type = c_build_type_variant (type, constp, volatilep);
     type = build_pointer_type (type);
     volatilep = constp = 0;
   }

 decl = build_decl (PARM_DECL, declarator, type);
 if (size_varies)
   ((decl)->decl.lang_flag_0) = 1;






 ((decl)->decl.initial) = type;
 main_type = (type == error_mark_node
       ? error_mark_node
       : ((type)->type.main_variant));
 if (main_type == float_type_node)
   ((decl)->decl.initial) = double_type_node;



 else if (((n64_enum_tree_code) (main_type)->common.code) != ERROR_MARK
   && (((n64_enum_tree_code) ((main_type))->common.code) == INTEGER_TYPE && (((main_type)->type.main_variant) == char_type_node || ((main_type)->type.main_variant) == signed_char_type_node || ((main_type)->type.main_variant) == unsigned_char_type_node || ((main_type)->type.main_variant) == short_integer_type_node || ((main_type)->type.main_variant) == short_unsigned_type_node)))
   {
     if (((type)->type.precision) == ((integer_type_node)->type.precision)
  && ((type)->common.unsigned_flag))
       ((decl)->decl.initial) = unsigned_type_node;
     else
       ((decl)->decl.initial) = integer_type_node;
   }

 ((decl)->decl.result) = type_as_written;
      }
    else if (decl_context == FIELD)
      {


 if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
   {
     error ("field `%s' declared as a function", name);
     type = build_pointer_type (type);
   }
 else if (((n64_enum_tree_code) (type)->common.code) != ERROR_MARK && ((type)->type.size) == 0)
   {
     error ("field `%s' has incomplete type", name);
     type = error_mark_node;
   }

 if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && (constp || volatilep))
   {
     type = build_array_type (c_build_type_variant (((type)->common.type),
          constp, volatilep),
         ((type)->type.values));



   }
 decl = build_decl (FIELD_DECL, declarator, type);
 if (size_varies)
   ((decl)->decl.lang_flag_0) = 1;
      }
    else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
      {





 int extern_ref = (!(specbits & (1 << (int) RID_AUTO))
     || current_binding_level == global_binding_level);

 if (specbits & (1 << (int) RID_AUTO)
     && (pedantic || current_binding_level == global_binding_level))
   pedwarn ("invalid storage class for function `%s'", name);
 if (specbits & (1 << (int) RID_REGISTER))
   error ("invalid storage class for function `%s'", name);



 if (current_binding_level != global_binding_level
     && (specbits & ((1 << (int) RID_STATIC) | (1 << (int) RID_INLINE)))
     && pedantic)
   pedwarn ("invalid storage class for function `%s'", name);




 if (extern_ref && allocation_temporary_p ())
   end_temporary_allocation ();

 decl = build_decl (FUNCTION_DECL, declarator, type);
 decl = build_decl_attribute_variant (decl, decl_machine_attr);

 if (pedantic && (constp || volatilep)
     && ! ((decl)->decl.in_system_header_flag))
   pedwarn ("ANSI C forbids const or volatile functions");

 if (volatilep
     && ((((decl)->common.type))->common.type) != void_type_node)
   warning ("`noreturn' function returns non-void value");

 if (extern_ref)
   ((decl)->decl.external_flag) = 1;

 ((decl)->common.public_flag)
   = !(specbits & ((1 << (int) RID_STATIC) | (1 << (int) RID_AUTO)));


 if (inlinep)
   {
     tree last = tree_last (((type)->type.values));

     if (! strcmp (((declarator)->identifier.pointer), "main"))
       warning ("cannot inline function `main'");
     else if (last && (((((last)->list.value))->type.main_variant)
         != void_type_node))
       warning ("inline declaration ignored for function with `...'");
     else

       ((decl)->decl.inline_flag) = 1;

     if (specbits & (1 << (int) RID_EXTERN))
       current_extern_inline = 1;
   }
      }
    else
      {


 int extern_ref = !initialized && (specbits & (1 << (int) RID_EXTERN));


 if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && (constp || volatilep))
   {
     type = build_array_type (c_build_type_variant (((type)->common.type),
          constp, volatilep),
         ((type)->type.values));



   }




 if (extern_ref && allocation_temporary_p ())
   end_temporary_allocation ();

 decl = build_decl (VAR_DECL, declarator, type);
 if (size_varies)
   ((decl)->decl.lang_flag_0) = 1;

 if (inlinep)
   pedwarn_with_decl (decl, "variable `%s' declared `inline'");

 ((decl)->decl.external_flag) = extern_ref;




 if (current_binding_level == global_binding_level)
   {
     ((decl)->common.public_flag)
       = !(specbits
    & ((1 << (int) RID_STATIC) | (1 << (int) RID_REGISTER)));
     ((decl)->common.static_flag) = ! ((decl)->decl.external_flag);
   }

 else
   {
     ((decl)->common.static_flag) = (specbits & (1 << (int) RID_STATIC)) != 0;
     ((decl)->common.public_flag) = ((decl)->decl.external_flag);
   }

 if (specbits & 1 << (int) RID_ITERATOR)
   (((decl)->decl.lang_flag_4)) = 1;
      }




    if (specbits & (1 << (int) RID_REGISTER))
      ((decl)->decl.regdecl_flag) = 1;



    if (constp)
      ((decl)->common.readonly_flag) = 1;
    if (volatilep)
      {
 ((decl)->common.side_effects_flag) = 1;
 ((decl)->common.volatile_flag) = 1;
      }



    if (((((decl)->common.type))->common.lang_flag_2))
      mark_addressable (decl);

    pop_obstacks ();

    return decl;
  }
}
static tree
grokparms(tree parms_info, int funcdef_flag) asm("_grokparms");
static tree
grokparms(tree parms_info, int funcdef_flag)
{
  tree first_parm = ((parms_info)->common.chain);

  last_function_parms = ((parms_info)->list.purpose);
  last_function_parm_tags = ((parms_info)->list.value);

  if (warn_strict_prototypes && first_parm == 0 && !funcdef_flag
      && !in_system_header)
    warning ("function declaration isn't a prototype");

  if (first_parm != 0
      && ((n64_enum_tree_code) (((first_parm)->list.value))->common.code) == IDENTIFIER_NODE)
    {
      if (! funcdef_flag)
 pedwarn ("parameter names (without types) in function declaration");

      last_function_parms = first_parm;
      return 0;
    }
  else
    {
      tree parm;
      tree typelt;
 for (parm = last_function_parms, typelt = first_parm;
      parm;
      parm = ((parm)->common.chain))

   if (((n64_enum_tree_code) (parm)->common.code) == PARM_DECL)
     {

       tree type = ((typelt)->list.value);
       if (((type)->type.size) == 0)
  {
    if (funcdef_flag && ((parm)->decl.name) != 0)
      error ("parameter `%s' has incomplete type",
      ((((parm)->decl.name))->identifier.pointer));
    else
      warning ("parameter has incomplete type");
    if (funcdef_flag)
      {
        ((typelt)->list.value) = error_mark_node;
        ((parm)->common.type) = error_mark_node;
      }
  }
       typelt = ((typelt)->common.chain);
     }


      if (first_parm && ! ((first_parm)->common.permanent_flag))
 {


   tree result = 
                ((void *)0)
                    ;
   for (typelt = first_parm; typelt; typelt = ((typelt)->common.chain))
     result = saveable_tree_cons ((tree) 
                                 ((void *)0)
                                          , ((typelt)->list.value),
      result);
   return nreverse (result);
 }
      else

 return first_parm;
    }
}
tree
get_parm_info(int void_at_end) asm("_get_parm_info");
tree
get_parm_info(int void_at_end)
{
  register tree decl, t;
  register tree types = 0;
  int erred = 0;
  tree tags = gettags ();
  tree parms = getdecls ();
  tree new_parms = 0;
  tree order = current_binding_level->parm_order;


  if (void_at_end && parms != 0
      && ((parms)->common.chain) == 0
      && ((((parms)->common.type))->type.main_variant) == void_type_node
      && ((parms)->decl.name) == 0)
    {
      parms = (tree) 
             ((void *)0)
                      ;
      storedecls ((tree) 
                 ((void *)0)
                          );
      return saveable_tree_cons ((tree) 
                                ((void *)0)
                                         , (tree) 
                                           ((void *)0)
                                                    ,
     saveable_tree_cons ((tree) 
                        ((void *)0)
                                 , void_type_node, (tree) 
                                                   ((void *)0)
                                                            ));
    }



  for (decl = parms; decl; )
    {
      tree next = ((decl)->common.chain);

      if (((n64_enum_tree_code) (decl)->common.code) != PARM_DECL)
 {
   ((decl)->common.chain) = new_parms;
   new_parms = decl;
 }
      else if (((decl)->common.asm_written_flag))
 {
   error_with_decl (decl, "parameter `%s' has just a forward declaration");
   ((decl)->common.chain) = new_parms;
   new_parms = decl;
 }
      decl = next;
    }


  for (t = order; t; t = ((t)->common.chain))
    {
      if (((t)->common.chain))
 ((((t)->list.value))->common.chain) = ((((t)->common.chain))->list.value);
      else
 ((((t)->list.value))->common.chain) = 0;
    }

  new_parms = chainon (order ? nreverse (((order)->list.value)) : 0,
         new_parms);



  storedecls (new_parms);

  for (decl = new_parms; decl; decl = ((decl)->common.chain))


    if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
      {


 tree type = ((decl)->common.type);
 ((decl)->decl.initial) = type;

 if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
     && ((type)->type.precision) < ((integer_type_node)->type.precision))
   ((decl)->decl.initial) = integer_type_node;


 types = saveable_tree_cons ((tree) 
                            ((void *)0)
                                     , ((decl)->common.type), types);
 if (((((types)->list.value))->type.main_variant) == void_type_node && ! erred
     && ((decl)->decl.name) == 0)
   {
     error ("`void' in parameter list must be the entire list");
     erred = 1;
   }
      }

  if (void_at_end)
    return saveable_tree_cons (new_parms, tags,
          nreverse (saveable_tree_cons ((tree) 
                                       ((void *)0)
                                                , void_type_node, types)));

  return saveable_tree_cons (new_parms, tags, nreverse (types));
}




void
parmlist_tags_warning(void) asm("_parmlist_tags_warning");
void
parmlist_tags_warning(void)
{
  tree elt;
  static int already;

  for (elt = current_binding_level->tags; elt; elt = ((elt)->common.chain))
    {
      n64_enum_tree_code code = ((n64_enum_tree_code) (((elt)->list.value))->common.code);


      if (code == UNION_TYPE && !pedantic)
 continue;
      if (((elt)->list.purpose) != 0)
 warning ("`%s %s' declared inside parameter list",
   (code == RECORD_TYPE ? "struct"
    : code == UNION_TYPE ? "union"
    : "enum"),
   ((((elt)->list.purpose))->identifier.pointer));
      else
 warning ("anonymous %s declared inside parameter list",
   (code == RECORD_TYPE ? "struct"
    : code == UNION_TYPE ? "union"
    : "enum"));

      if (! already)
 {
   warning ("its scope is only this definition or declaration,");
   warning ("which is probably not what you want.");
   already = 1;
 }
    }
}




tree
xref_tag(n64_enum_tree_code code, tree name) asm("_xref_tag");
tree
xref_tag(n64_enum_tree_code code, tree name)
{
  int temporary = allocation_temporary_p ();




  register tree ref = lookup_tag (code, name, current_binding_level, 0);




  if (ref)
    return ref;

  push_obstacks_nochange ();

  if (current_binding_level == global_binding_level && temporary)
    end_temporary_allocation ();






  ref = make_node (code);
  if (code == ENUMERAL_TYPE)
    {

      if (pedantic)
 pedwarn ("ANSI C forbids forward references to `enum' types");


      ((ref)->type.mode) = ((unsigned_type_node)->type.mode);
      ((ref)->type.align) = ((unsigned_type_node)->type.align);
      ((ref)->common.unsigned_flag) = 1;
      ((ref)->type.precision) = ((unsigned_type_node)->type.precision);
      ((ref)->type.minval) = ((unsigned_type_node)->type.minval);
      ((ref)->type.maxval) = ((unsigned_type_node)->type.maxval);
    }

  pushtag (name, ref);

  pop_obstacks ();

  return ref;
}
tree
start_struct(n64_enum_tree_code code, tree name) asm("_start_struct");
tree
start_struct(n64_enum_tree_code code, tree name)
{



  register tree ref = 0;

  push_obstacks_nochange ();
  if (current_binding_level == global_binding_level)
    end_temporary_allocation ();

  if (name != 0)
    ref = lookup_tag (code, name, current_binding_level, 1);
  if (ref && ((n64_enum_tree_code) (ref)->common.code) == code)
    {
      ((ref)->type.lang_flag_0) = 1;
      if (((ref)->type.values))
 error ((code == UNION_TYPE ? "redefinition of `union %s'"
  : "redefinition of `struct %s'"),
        ((name)->identifier.pointer));

      return ref;
    }



  ref = make_node (code);
  pushtag (name, ref);
  ((ref)->type.lang_flag_0) = 1;
  return ref;
}
tree
grokfield(char *filename, int line, tree declarator, tree declspecs, tree width) asm("_grokfield");
tree
grokfield(char *filename, int line, tree declarator, tree declspecs, tree width)
{
  tree value;


  push_obstacks_nochange ();

  value = grokdeclarator (declarator, declspecs, width ? BITFIELD : FIELD, 0);

  finish_decl (value, (tree) 
                     ((void *)0)
                              , (tree) 
                                ((void *)0)
                                         );
  ((value)->decl.initial) = width;

  maybe_objc_check_decl (value);
  return value;
}



static int
field_decl_cmp(tree *x, tree *y) asm("_field_decl_cmp");
static int
field_decl_cmp(tree *x, tree *y)
{
  if (((*x)->decl.name) == ((*y)->decl.name))
    return 0;
  if (((*x)->decl.name) == 
                       ((void *)0)
                           )
    return -1;
  if (((*y)->decl.name) == 
                       ((void *)0)
                           )
    return 1;
  if (((*x)->decl.name) < ((*y)->decl.name))
    return -1;
  return 1;
}







tree
finish_struct(tree t, tree fieldlist, tree attributes) asm("_finish_struct");
tree
finish_struct(tree t, tree fieldlist, tree attributes)
{
  register tree x;
  int old_momentary;
  int toplevel = global_binding_level == current_binding_level;




  ((t)->type.size) = 0;

  decl_attributes (t, attributes, (tree) 
                                 ((void *)0)
                                          );


  if (! (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE && ((t)->type.name) == 0) && !pedantic)

    if (in_parm_level_p ())
      {
 if (pedantic)
   pedwarn ((((n64_enum_tree_code) (t)->common.code) == UNION_TYPE ? "union defined inside parms"
      : "structure defined inside parms"));
 else if (! flag_traditional)
   warning ((((n64_enum_tree_code) (t)->common.code) == UNION_TYPE ? "union defined inside parms"
      : "structure defined inside parms"));
      }

  old_momentary = suspend_momentary ();

  if (fieldlist == 0 && pedantic)
    pedwarn ((((n64_enum_tree_code) (t)->common.code) == UNION_TYPE ? "union has no members"
       : "structure has no members"));
  for (x = fieldlist; x; x = ((x)->common.chain))
    {
      ((x)->decl.context) = t;
      ((x)->decl.regdecl_flag) |= ((t)->type.packed_flag);
      ((x)->decl.saved_insns.i) = 0;


      if (((x)->common.readonly_flag))
 ((t)->common.lang_flag_1) = 1;
      else
 {

   tree t1 = ((x)->common.type);
   while (((n64_enum_tree_code) (t1)->common.code) == ARRAY_TYPE)
     t1 = ((t1)->common.type);
   if ((((n64_enum_tree_code) (t1)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (t1)->common.code) == UNION_TYPE)
       && ((t1)->common.lang_flag_1))
     ((t)->common.lang_flag_1) = 1;
 }



      if (((x)->common.volatile_flag))
 ((t)->common.lang_flag_2) = 1;


      if (((x)->decl.lang_flag_0))
 ((t)->type.lang_flag_1) = 1;


      if (((x)->common.type) == t)
 error ("nested redefinition of `%s'",
        ((((t)->type.name))->identifier.pointer));


      if (((x)->decl.initial))
 while ((((n64_enum_tree_code) (((x)->decl.initial))->common.code) == NOP_EXPR || ((n64_enum_tree_code) (((x)->decl.initial))->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (((x)->decl.initial))->common.code) == NON_LVALUE_EXPR) && (((((((x)->decl.initial))->common.type))->type.mode) == ((((((((x)->decl.initial))->exp.operands[0]))->common.type))->type.mode))) (((x)->decl.initial)) = ((((x)->decl.initial))->exp.operands[0]);;
      if (((x)->decl.initial))
 {
   if (((n64_enum_tree_code) (((x)->decl.initial))->common.code) == INTEGER_CST)
     constant_expression_warning (((x)->decl.initial));
   else
     {
       error_with_decl (x, "bit-field `%s' width not an integer constant");
       ((x)->decl.initial) = 
                         ((void *)0)
                             ;
     }
 }


      if (((x)->decl.initial)
   && ((n64_enum_tree_code) (((x)->common.type))->common.code) != INTEGER_TYPE
   && ((n64_enum_tree_code) (((x)->common.type))->common.code) != ENUMERAL_TYPE)
 {
   error_with_decl (x, "bit-field `%s' has invalid type");
   ((x)->decl.initial) = 
                     ((void *)0)
                         ;
 }
      if (((x)->decl.initial) && pedantic
   && ((((x)->common.type))->type.main_variant) != integer_type_node
   && ((((x)->common.type))->type.main_variant) != unsigned_type_node

   && !(((n64_enum_tree_code) (((x)->common.type))->common.code) == ENUMERAL_TYPE
        && (((((x)->common.type))->type.precision)
     == ((integer_type_node)->type.precision))))
 pedwarn_with_decl (x, "bit-field `%s' type invalid in ANSI C");


      if (((x)->decl.initial))
 {
   unsigned int width = ((((x)->decl.initial))->int_cst.int_cst_low);

   if (tree_int_cst_sgn (((x)->decl.initial)) < 0)
     {
       ((x)->decl.initial) = 
                         ((void *)0)
                             ;
       error_with_decl (x, "negative width in bit-field `%s'");
     }
   else if (((((x)->decl.initial))->int_cst.int_cst_high) != 0
     || width > ((((x)->common.type))->type.precision))
     {
       ((x)->decl.initial) = 
                         ((void *)0)
                             ;
       pedwarn_with_decl (x, "width of `%s' exceeds its type");
     }
   else if (width == 0 && ((x)->decl.name) != 0)
     {
       error_with_decl (x, "zero width for bit-field `%s'");
       ((x)->decl.initial) = 
                         ((void *)0)
                             ;
     }
 }


      if (((x)->decl.initial))
 {
   register int width = ((((x)->decl.initial))->int_cst.int_cst_low);

   ((x)->decl.saved_insns.i) = width;
   ((x)->decl.bit_field_flag) = 1;
   ((x)->decl.initial) = 
                     ((void *)0)
                         ;

   if (width == 0)
     {


       ((x)->decl.frame_size.u) = ((((x)->decl.frame_size.u)) > (((target_flags & 0x00000002) ? 64 : 32)) ? (((x)->decl.frame_size.u)) : (((target_flags & 0x00000002) ? 64 : 32)));


       ((x)->decl.frame_size.u) = ((((x)->decl.frame_size.u)) > (((((x)->common.type))->type.align)) ? (((x)->decl.frame_size.u)) : (((((x)->common.type))->type.align)))
                                   ;

     }
 }
      else if (((x)->common.type) != error_mark_node)
 {
   int min_align = (((x)->decl.regdecl_flag) ? 8
      : ((((x)->common.type))->type.align));


   ((x)->decl.frame_size.u) = ((((x)->decl.frame_size.u)) > (min_align) ? (((x)->decl.frame_size.u)) : (min_align));
 }
    }




  for (x = fieldlist; x && ((x)->common.chain);)

    if (((((x)->common.chain))->decl.name) == 0)
      x = ((x)->common.chain);
    else
      {
 register tree y = fieldlist;

 while (1)
   {
     if (((y)->decl.name) == ((((x)->common.chain))->decl.name))
       break;
     if (y == x)
       break;
     y = ((y)->common.chain);
   }
 if (((y)->decl.name) == ((((x)->common.chain))->decl.name))
   {
     error_with_decl (((x)->common.chain), "duplicate member `%s'");
     ((x)->common.chain) = ((((x)->common.chain))->common.chain);
   }
 else x = ((x)->common.chain);
      }




  ((t)->type.values) = fieldlist;

  layout_type (t);


  while (fieldlist
  && ((fieldlist)->decl.initial))
    fieldlist = ((fieldlist)->common.chain);

  for (x = fieldlist; x;)
    {
      if (((x)->common.chain) && ((((x)->common.chain))->decl.initial))
 ((x)->common.chain) = ((((x)->common.chain))->common.chain);
      else x = ((x)->common.chain);
    }




  ((t)->type.values) = fieldlist;



  {
    int len = 0;

    for (x = fieldlist; x; x = ((x)->common.chain))
      {
 if (len > 15)
   break;
 len += 1;
      }
    if (len > 15)
      {
 tree *field_array;
 char *space;

 len += list_length (x);



 if (allocation_temporary_p ())
   space = savealloc (sizeof (struct n64_tag_lang_type) + len * sizeof (tree));
 else
   space = oballoc (sizeof (struct n64_tag_lang_type) + len * sizeof (tree));

 ((t)->type.lang_specific) = (struct n64_tag_lang_type *) space;
 ((t)->type.lang_specific)->len = len;

 field_array = &((t)->type.lang_specific)->elts[0];
 len = 0;
 for (x = fieldlist; x; x = ((x)->common.chain))
   field_array[len++] = x;

 qsort (field_array, len, sizeof (tree), field_decl_cmp);
      }
  }

  for (x = ((t)->type.main_variant); x; x = ((x)->type.next_variant))
    {
      ((x)->type.values) = ((t)->type.values);
      ((x)->type.lang_specific) = ((t)->type.lang_specific);
      ((x)->type.align) = ((t)->type.align);
    }


  for (x = fieldlist; x; x = ((x)->common.chain))
    if (((x)->decl.bit_field_flag)
 && ((((n64_enum_tree_code) ((((x)->common.type)))->common.code) == INTEGER_TYPE && (((((x)->common.type))->type.main_variant) == char_type_node || ((((x)->common.type))->type.main_variant) == signed_char_type_node || ((((x)->common.type))->type.main_variant) == unsigned_char_type_node || ((((x)->common.type))->type.main_variant) == short_integer_type_node || ((((x)->common.type))->type.main_variant) == short_unsigned_type_node))
     || ((x)->decl.saved_insns.i) < ((integer_type_node)->type.precision)))
      {
 tree type = ((x)->common.type);



 if (((type)->common.unsigned_flag)
     && (flag_traditional
  ||
  (((type)->type.precision) == ((integer_type_node)->type.precision)
   &&
   ((x)->decl.saved_insns.i) == ((integer_type_node)->type.precision))))
   ((x)->common.type) = unsigned_type_node;
 else
   ((x)->common.type) = integer_type_node;
      }



  if (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE
      && ((t)->type.transparent_union_flag)
      && ((t)->type.mode) != ((((t)->type.values))->decl.mode))
    {
      ((t)->type.transparent_union_flag) = 0;
      warning ("cannot make `%s' a transparent union");
    }




  if (current_binding_level->n_incomplete != 0)
    {
      tree decl;
      for (decl = current_binding_level->names; decl; decl = ((decl)->common.chain))
 {
   if (((decl)->common.type) == t
       && ((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
     {
       layout_decl (decl, 0);

       maybe_objc_check_decl (decl);
       rest_of_decl_compilation (decl, ((void *)0), toplevel, 0);
       if (! toplevel)
  expand_decl (decl);
       --current_binding_level->n_incomplete;
     }
   else if (((((decl)->common.type))->type.size) == 0
     && ((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE)
     {
       tree element = ((decl)->common.type);
       while (((n64_enum_tree_code) (element)->common.code) == ARRAY_TYPE)
  element = ((element)->common.type);
       if (element == t)
  layout_array_type (((decl)->common.type));
     }
 }
    }

  resume_momentary (old_momentary);


  rest_of_type_compilation (t, toplevel);


  pop_obstacks ();

  return t;
}



static void
layout_array_type(tree t) asm("_layout_array_type");
static void
layout_array_type(tree t)
{
  if (((n64_enum_tree_code) (((t)->common.type))->common.code) == ARRAY_TYPE)
    layout_array_type (((t)->common.type));
  layout_type (t);
}







tree
start_enum(tree name) asm("_start_enum");
tree
start_enum(tree name)
{
  register tree enumtype = 0;





  if (name != 0)
    enumtype = lookup_tag (ENUMERAL_TYPE, name, current_binding_level, 1);


  push_obstacks_nochange ();

  if (current_binding_level == global_binding_level)
    end_temporary_allocation ();

  if (enumtype == 0 || ((n64_enum_tree_code) (enumtype)->common.code) != ENUMERAL_TYPE)
    {
      enumtype = make_node (ENUMERAL_TYPE);
      pushtag (name, enumtype);
    }

  ((enumtype)->type.lang_flag_0) = 1;

  if (((enumtype)->type.values) != 0)
    {

      error ("redeclaration of `enum %s'", ((name)->identifier.pointer));



      ((enumtype)->type.values) = 0;
    }

  enum_next_value = integer_zero_node;
  enum_overflow = 0;

  return enumtype;
}







tree
finish_enum(tree enumtype, tree values, tree attributes) asm("_finish_enum");
tree
finish_enum(tree enumtype, tree values, tree attributes)
{
  register tree pair, tem;
  tree minnode = 0, maxnode = 0;
  int lowprec, highprec, precision;
  int toplevel = global_binding_level == current_binding_level;

  if (in_parm_level_p ())
    warning ("enum defined inside parms");

  decl_attributes (enumtype, attributes, (tree) 
                                        ((void *)0)
                                                 );



  if (values == error_mark_node)
    minnode = maxnode = integer_zero_node;
  else
    for (pair = values; pair; pair = ((pair)->common.chain))
      {
 tree value = ((pair)->list.value);
 if (pair == values)
   minnode = maxnode = ((pair)->list.value);
 else
   {
     if (tree_int_cst_lt (maxnode, value))
       maxnode = value;
     if (tree_int_cst_lt (value, minnode))
       minnode = value;
   }
      }

  ((enumtype)->type.minval) = minnode;
  ((enumtype)->type.maxval) = maxnode;


  ((enumtype)->common.unsigned_flag) = tree_int_cst_sgn (minnode) >= 0;



  lowprec = min_precision (minnode, ((enumtype)->common.unsigned_flag));
  highprec = min_precision (maxnode, ((enumtype)->common.unsigned_flag));
  precision = ((lowprec) > (highprec) ? (lowprec) : (highprec));

  if (flag_short_enums || ((enumtype)->type.packed_flag)
      || precision > ((integer_type_node)->type.precision))

    ((enumtype)->type.precision) = ((type_for_size (precision, 1))->type.precision);
  else
    ((enumtype)->type.precision) = ((integer_type_node)->type.precision);

  ((enumtype)->type.size) = 0;
  layout_type (enumtype);

  if (values != error_mark_node)
    {





      for (pair = values; pair; pair = ((pair)->common.chain))
 {
   ((((pair)->list.purpose))->common.type) = enumtype;
   ((((pair)->list.purpose))->decl.size) = ((enumtype)->type.size);
   if (((n64_enum_tree_code) (((pair)->list.purpose))->common.code) != FUNCTION_DECL)
     ((((pair)->list.purpose))->decl.frame_size.u) = ((enumtype)->type.align);
 }


      for (pair = values; pair; pair = ((pair)->common.chain))
 ((pair)->list.purpose) = ((((pair)->list.purpose))->decl.name);

      ((enumtype)->type.values) = values;
    }


  for (tem = ((enumtype)->type.main_variant); tem; tem = ((tem)->type.next_variant))
    {
      ((tem)->type.values) = ((enumtype)->type.values);
      ((tem)->type.minval) = ((enumtype)->type.minval);
      ((tem)->type.maxval) = ((enumtype)->type.maxval);
      ((tem)->type.size) = ((enumtype)->type.size);
      ((tem)->type.mode) = ((enumtype)->type.mode);
      ((tem)->type.precision) = ((enumtype)->type.precision);
      ((tem)->type.align) = ((enumtype)->type.align);
      ((tem)->common.unsigned_flag) = ((enumtype)->common.unsigned_flag);
    }


  rest_of_type_compilation (enumtype, toplevel);


  pop_obstacks ();

  return enumtype;
}






tree
build_enumerator(tree name, tree value) asm("_build_enumerator");
tree
build_enumerator(tree name, tree value)
{
  register tree decl, type;




  if (value)
    while ((((n64_enum_tree_code) (value)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (value)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR) && (((value)->common.type) == ((((value)->exp.operands[0]))->common.type))) (value) = ((value)->exp.operands[0]);;

  if (value != 0)
    {
      if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST)
 {
   value = default_conversion (value);
   constant_expression_warning (value);
 }
      else
 {
   error ("enumerator value for `%s' not integer constant",
   ((name)->identifier.pointer));
   value = 0;
 }
    }




  if (value == 0)
    {
      value = enum_next_value;
      if (enum_overflow)
 error ("overflow in enumeration values");
    }

  if (pedantic && ! int_fits_type_p (value, integer_type_node))
    {
      pedwarn ("ANSI C restricts enumerator values to range of `int'");
      value = integer_zero_node;
    }


  enum_next_value = build_binary_op (PLUS_EXPR, value, integer_one_node, 0);
  enum_overflow = tree_int_cst_lt (enum_next_value, value);



  type = ((value)->common.type);
  type = type_for_size (((((type)->type.precision)) > (((integer_type_node)->type.precision)) ? (((type)->type.precision)) : (((integer_type_node)->type.precision)))
                                           ,
   ((flag_traditional
     || ((type)->type.precision) >= ((integer_type_node)->type.precision))
    && ((type)->common.unsigned_flag)));

  decl = build_decl (CONST_DECL, name, type);
  ((decl)->decl.initial) = value;
  ((value)->common.type) = type;
  pushdecl (decl);

  return saveable_tree_cons (decl, value, (tree) 
                                         ((void *)0)
                                                  );
}
int
start_function(tree declspecs, tree declarator, tree prefix_attributes, tree attributes, int nested) asm("_start_function");
int
start_function(tree declspecs, tree declarator, tree prefix_attributes, tree attributes, int nested)
{
  tree decl1, old_decl;
  tree restype;
  int old_immediate_size_expand = immediate_size_expand;

  current_function_returns_value = 0;
  current_function_returns_null = 0;
  warn_about_return_type = 0;
  current_extern_inline = 0;
  c_function_varargs = 0;
  named_labels = 0;
  shadowed_labels = 0;


  immediate_size_expand = 0;

  decl1 = grokdeclarator (declarator, declspecs, FUNCDEF, 1);



  if (decl1 == 0)
    return 0;

  decl_attributes (decl1, prefix_attributes, attributes);

  announce_function (decl1);

  if (((((((decl1)->common.type))->common.type))->type.size) == 0)
    {
      error ("return-type is an incomplete type");

      ((decl1)->common.type)
 = build_function_type (void_type_node,
          ((((decl1)->common.type))->type.values));
    }

  if (warn_about_return_type)
    warning ("return-type defaults to `int'");



  current_function_parms = last_function_parms;
  current_function_parm_tags = last_function_parm_tags;



  ((decl1)->decl.initial) = error_mark_node;




  old_decl = lookup_name_current_level (((decl1)->decl.name));
  if (old_decl != 0 && ((n64_enum_tree_code) (((old_decl)->common.type))->common.code) == FUNCTION_TYPE
      && !((old_decl)->decl.bit_field_flag)
      && (((((((decl1)->common.type))->common.type))->type.main_variant)
   == ((((((old_decl)->common.type))->common.type))->type.main_variant))
      && ((((decl1)->common.type))->type.values) == 0)
    {
      ((decl1)->common.type) = ((old_decl)->common.type);
      current_function_prototype_file = ((old_decl)->decl.filename);
      current_function_prototype_line = ((old_decl)->decl.linenum);
    }



  if (old_decl == 0)
    old_decl = (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->implicit_decl);


  if (warn_strict_prototypes
      && ((((decl1)->common.type))->type.values) == 0
      && !(old_decl != 0 && ((((old_decl)->common.type))->type.values) != 0))
    warning ("function declaration isn't a prototype");

  else if (warn_missing_prototypes
    && ((decl1)->common.public_flag)
    && !(old_decl != 0 && ((((old_decl)->common.type))->type.values) != 0)
    && strcmp ("main", ((((decl1)->decl.name))->identifier.pointer)))
    warning_with_decl (decl1, "no previous prototype for `%s'");


  else if (warn_missing_prototypes
    && old_decl != 0 && ((old_decl)->common.used_flag)
    && ((((old_decl)->common.type))->type.values) == 0)
    warning_with_decl (decl1,
        "`%s' was used with no prototype before its definition");

  else if (warn_missing_declarations
    && ((decl1)->common.public_flag)
    && old_decl == 0
    && strcmp ("main", ((((decl1)->decl.name))->identifier.pointer)))
    warning_with_decl (decl1, "no previous declaration for `%s'");


  else if (warn_missing_declarations
    && old_decl != 0 && ((old_decl)->common.used_flag)
    && old_decl == (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->implicit_decl))
    warning_with_decl (decl1,
      "`%s' was used with no declaration before its definition");





  ((decl1)->decl.external_flag) = current_extern_inline;



  ((decl1)->common.static_flag) = 1;


  if (current_function_decl != 0)
    ((decl1)->common.public_flag) = 0;





  current_function_decl = pushdecl (decl1);

  pushlevel (0);
  declare_parm_level (1);
  current_binding_level->subblocks_tag_transparent = 1;

  make_function_rtl (current_function_decl);

  restype = ((((current_function_decl)->common.type))->common.type);

  if ((((n64_enum_tree_code) ((restype))->common.code) == INTEGER_TYPE && (((restype)->type.main_variant) == char_type_node || ((restype)->type.main_variant) == signed_char_type_node || ((restype)->type.main_variant) == unsigned_char_type_node || ((restype)->type.main_variant) == short_integer_type_node || ((restype)->type.main_variant) == short_unsigned_type_node)))
    {


      if (((restype)->common.unsigned_flag)
   && (flag_traditional
       || (((restype)->type.precision)
    == ((integer_type_node)->type.precision))))
 restype = unsigned_type_node;
      else
 restype = integer_type_node;
    }
  ((current_function_decl)->decl.result)
    = build_decl (RESULT_DECL, (tree) 
                              ((void *)0)
                                       , restype);

  if (!nested)


    temporary_allocation ();



  if (((((current_function_decl)->decl.assembler_name))->common.addressable_flag))
    ((current_function_decl)->common.addressable_flag) = 1;

  immediate_size_expand = old_immediate_size_expand;

  return 1;
}





void
c_mark_varargs(void) asm("_c_mark_varargs");
void
c_mark_varargs(void)
{
  c_function_varargs = 1;
}
void
store_parm_decls(void) asm("_store_parm_decls");
void
store_parm_decls(void)
{
  register tree fndecl = current_function_decl;
  register tree parm;



  tree specparms = current_function_parms;


  tree parmtags = current_function_parm_tags;


  register tree parmdecls = getdecls ();




  tree nonparms = 0;


  int prototype = 0;

  if (specparms != 0 && ((n64_enum_tree_code) (specparms)->common.code) != TREE_LIST)
    {





      register tree next;
      tree others = 0;

      prototype = 1;

      if (parmdecls != 0)
 {
   tree decl, link;

   error_with_decl (fndecl,
      "parm types given both in parmlist and separately");


   for (decl = current_binding_level->names;
        decl; decl = ((decl)->common.chain))
     if (((decl)->decl.name))
       (((struct n64_tag_lang_identifier *)(((decl)->decl.name)))->local_value) = 0;
   for (link = current_binding_level->shadowed;
        link; link = ((link)->common.chain))
     (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->local_value) = ((link)->list.value);
   current_binding_level->names = 0;
   current_binding_level->shadowed = 0;
 }

      specparms = nreverse (specparms);
      for (parm = specparms; parm; parm = next)
 {
   next = ((parm)->common.chain);
   if (((n64_enum_tree_code) (parm)->common.code) == PARM_DECL)
     {
       if (((parm)->decl.name) == 0)
  error_with_decl (parm, "parameter name omitted");
       else if (((((parm)->common.type))->type.main_variant) == void_type_node)
  {
    error_with_decl (parm, "parameter `%s' declared void");


    ((parm)->common.type) = error_mark_node;
  }
       pushdecl (parm);
     }
   else
     {


       ((parm)->common.chain) = 0;
       others = chainon (others, parm);
     }
 }



      ((fndecl)->decl.arguments) = getdecls ();
      for (parm = others; parm; parm = next)
 {
   next = ((parm)->common.chain);
   if (((parm)->decl.name) == 0)
     ;
   else if (((((parm)->common.type))->type.main_variant) == void_type_node)
     ;
   else if (((n64_enum_tree_code) (parm)->common.code) != PARM_DECL)
     pushdecl (parm);
 }

      storetags (chainon (parmtags, gettags ()));
    }
  else
    {
      for (parm = parmdecls; parm; parm = ((parm)->common.chain))
 ((parm)->decl.result) = 0;

      for (parm = specparms; parm; parm = ((parm)->common.chain))
 {
   register tree tail, found = 
                              ((void *)0)
                                  ;

   if (((parm)->list.value) == 0)
     {
       error_with_decl (fndecl, "parameter name missing from parameter list");
       ((parm)->list.purpose) = 0;
       continue;
     }



   for (tail = parmdecls; tail; tail = ((tail)->common.chain))
     if (((tail)->decl.name) == ((parm)->list.value)
  && ((n64_enum_tree_code) (tail)->common.code) == PARM_DECL)
       {
  found = tail;
  break;
       }



   if (found && ((found)->decl.result) != 0)
     {
       error_with_decl (found, "multiple parameters named `%s'");
       found = 0;
     }


   if (found && ((((found)->common.type))->type.main_variant) == void_type_node)
     {
       error_with_decl (found, "parameter `%s' declared void");
       ((found)->common.type) = integer_type_node;
       ((found)->decl.initial) = integer_type_node;
       layout_decl (found, 0);
     }


   if (found && flag_traditional
       && ((((found)->common.type))->type.main_variant) == float_type_node)
     {
       ((found)->common.type) = double_type_node;
       ((found)->decl.initial) = double_type_node;
       layout_decl (found, 0);
     }


   if (!found)
     {
       found = build_decl (PARM_DECL, ((parm)->list.value),
      integer_type_node);
       ((found)->decl.initial) = ((found)->common.type);
       ((found)->decl.linenum) = ((fndecl)->decl.linenum);
       ((found)->decl.filename) = ((fndecl)->decl.filename);
       if (extra_warnings)
  warning_with_decl (found, "type of `%s' defaults to `int'");
       pushdecl (found);
     }

   ((parm)->list.purpose) = found;




   ((found)->decl.result) = error_mark_node;
 }







      nonparms = 0;
      for (parm = parmdecls; parm; )
 {
   tree next = ((parm)->common.chain);
   ((parm)->common.chain) = 0;

   if (((n64_enum_tree_code) (parm)->common.code) != PARM_DECL)
     nonparms = chainon (nonparms, parm);
   else
     {

       if (((((parm)->common.type))->type.size) == 0)
         {
           error_with_decl (parm, "parameter `%s' has incomplete type");
           ((parm)->common.type) = error_mark_node;
         }

       if (((parm)->decl.result) == 0)
         {
           error_with_decl (parm,
              "declaration for parameter `%s' but no such parameter");



           specparms
      = chainon (specparms,
          tree_cons (parm, (tree) 
                          ((void *)0)
                                   , (tree) 
                                     ((void *)0)
                                              ));
  }
     }

   parm = next;
 }



      parm = specparms;
      ((fndecl)->decl.arguments) = 0;
      {
 register tree last;
 for (last = 0; parm; parm = ((parm)->common.chain))
   if (((parm)->list.purpose))
     {
       if (last == 0)
  ((fndecl)->decl.arguments) = ((parm)->list.purpose);
       else
  ((last)->common.chain) = ((parm)->list.purpose);
       last = ((parm)->list.purpose);
       ((last)->common.chain) = 0;
     }
      }





      if (((((fndecl)->common.type))->type.values))
 {
   register tree type;
   for (parm = ((fndecl)->decl.arguments),
        type = ((((fndecl)->common.type))->type.values);
        parm || (type && (((((type)->list.value))->type.main_variant)
     != void_type_node));
        parm = ((parm)->common.chain), type = ((type)->common.chain))
     {
       if (parm == 0 || type == 0
    || ((((type)->list.value))->type.main_variant) == void_type_node)
  {
    error ("number of arguments doesn't match prototype");
    error_with_file_and_line (current_function_prototype_file,
         current_function_prototype_line,
         "prototype declaration");
    break;
  }


       if (! comptypes (((parm)->decl.initial), ((type)->list.value)))
  {
    if (((((parm)->common.type))->type.main_variant)
        == ((((type)->list.value))->type.main_variant))
      {





        ((parm)->decl.initial) = ((parm)->common.type);

        if ((((n64_enum_tree_code) (((parm)->common.type))->common.code) == INTEGER_TYPE
      || ((n64_enum_tree_code) (((parm)->common.type))->common.code) == ENUMERAL_TYPE)
     && ((((parm)->common.type))->type.precision)
     < ((integer_type_node)->type.precision))
   ((parm)->decl.initial) = integer_type_node;

        if (pedantic)
   {
     pedwarn ("promoted argument `%s' doesn't match prototype",
       ((((parm)->decl.name))->identifier.pointer));
     warning_with_file_and_line
       (current_function_prototype_file,
        current_function_prototype_line,
        "prototype declaration");
   }
      }


    else if (! (flag_traditional
         && ((((parm)->common.type))->type.main_variant) == integer_type_node
         && ((((type)->list.value))->type.main_variant) == unsigned_type_node))
      {
        error ("argument `%s' doesn't match prototype",
        ((((parm)->decl.name))->identifier.pointer));
        error_with_file_and_line (current_function_prototype_file,
      current_function_prototype_line,
      "prototype declaration");
      }
  }
     }
   ((((fndecl)->common.type))->type.noncopied_parts) = 0;
 }



      else
 {
   tree actual = 0, last = 0, type;

   for (parm = ((fndecl)->decl.arguments); parm; parm = ((parm)->common.chain))
     {
       type = perm_tree_cons ((tree) 
                             ((void *)0)
                                      , ((parm)->decl.initial),
         (tree) 
        ((void *)0)
                 );
       if (last)
  ((last)->common.chain) = type;
       else
  actual = type;
       last = type;
     }
   type = perm_tree_cons ((tree) 
                         ((void *)0)
                                  , void_type_node, (tree) 
                                                    ((void *)0)
                                                             );
   if (last)
     ((last)->common.chain) = type;
   else
     actual = type;
   ((fndecl)->common.type) = build_type_copy (((fndecl)->common.type));

   ((((fndecl)->common.type))->type.noncopied_parts) = actual;
 }






      storedecls (chainon (nonparms, ((fndecl)->decl.arguments)));
    }





  keep_next_if_subblocks = 1;
  gen_aux_info_record (fndecl, 1, 0, prototype);



  init_function_start (fndecl, input_filename, lineno);



  if (c_function_varargs)
    mark_varargs ();



  declare_function_name ();



  expand_function_start (fndecl, 0);



  if (((fndecl)->decl.name)
      && strcmp (((((fndecl)->decl.name))->identifier.pointer), "main") == 0
      && ((fndecl)->decl.context) == (tree) 
                                 ((void *)0)
                                          )
    expand_main_function ();
}
tree
combine_parm_decls(tree specparms, tree parmlist, int void_at_end) asm("_combine_parm_decls");
tree
combine_parm_decls(tree specparms, tree parmlist, int void_at_end)
{
  register tree fndecl = current_function_decl;
  register tree parm;

  tree parmdecls = ((parmlist)->list.purpose);




  tree nonparms = ((parmlist)->list.value);

  tree types = 0;

  for (parm = parmdecls; parm; parm = ((parm)->common.chain))
    ((parm)->decl.result) = 0;

  for (parm = specparms; parm; parm = ((parm)->common.chain))
    {
      register tree tail, found = 
                                 ((void *)0)
                                     ;


      for (tail = parmdecls; tail; tail = ((tail)->common.chain))
 if (((tail)->decl.name) == ((parm)->list.value))
   {
     found = tail;
     break;
   }



      if (found && ((found)->decl.result) != 0)
 {
   error_with_decl (found, "multiple parameters named `%s'");
   found = 0;
 }


      if (found && ((((found)->common.type))->type.main_variant) == void_type_node)
 {
   error_with_decl (found, "parameter `%s' declared void");
   ((found)->common.type) = integer_type_node;
   ((found)->decl.initial) = integer_type_node;
   layout_decl (found, 0);
 }


      if (found && flag_traditional
   && ((((found)->common.type))->type.main_variant) == float_type_node)
 {
   ((found)->common.type) = double_type_node;
   ((found)->decl.initial) = double_type_node;
   layout_decl (found, 0);
 }


      if (!found)
 {
   found = build_decl (PARM_DECL, ((parm)->list.value),
         integer_type_node);
   ((found)->decl.initial) = ((found)->common.type);
   ((found)->decl.linenum) = ((fndecl)->decl.linenum);
   ((found)->decl.filename) = ((fndecl)->decl.filename);
   error_with_decl (found, "type of parameter `%s' is not declared");
   pushdecl (found);
 }

      ((parm)->list.purpose) = found;




      ((found)->decl.result) = error_mark_node;
    }



  for (parm = parmdecls; parm; )
    {
      tree next = ((parm)->common.chain);
      ((parm)->common.chain) = 0;


      if (((((parm)->common.type))->type.size) == 0)
 {
   error_with_decl (parm, "parameter `%s' has incomplete type");
   ((parm)->common.type) = error_mark_node;
 }

      if (((parm)->decl.result) == 0)
 {
   error_with_decl (parm,
      "declaration for parameter `%s' but no such parameter");



   specparms
     = chainon (specparms,
         tree_cons (parm, (tree) 
                         ((void *)0)
                                  , (tree) 
                                    ((void *)0)
                                             ));
 }

      parm = next;
    }




  parm = specparms;
  parmdecls = 0;
  {
    register tree last;
    for (last = 0; parm; parm = ((parm)->common.chain))
      if (((parm)->list.purpose))
 {
   if (last == 0)
     parmdecls = ((parm)->list.purpose);
   else
     ((last)->common.chain) = ((parm)->list.purpose);
   last = ((parm)->list.purpose);
   ((last)->common.chain) = 0;

   types = saveable_tree_cons ((tree) 
                              ((void *)0)
                                       , ((parm)->common.type), types);
 }
  }

  if (void_at_end)
    return saveable_tree_cons (parmdecls, nonparms,
          nreverse (saveable_tree_cons ((tree) 
                                       ((void *)0)
                                                , void_type_node, types)));

  return saveable_tree_cons (parmdecls, nonparms, nreverse (types));
}
void
finish_function(int nested) asm("_finish_function");
void
finish_function(int nested)
{
  register tree fndecl = current_function_decl;





  poplevel (1, 0, 1);
  ((((fndecl)->decl.initial))->block.supercontext) = fndecl;



  ((((fndecl)->decl.result))->decl.context) = fndecl;


  if (flag_traditional && current_function_calls_setjmp)
    {
      setjmp_protect (((fndecl)->decl.initial));
      setjmp_protect_args ();
    }
  expand_function_end (input_filename, lineno, 0);


  can_reach_end = 0;


  rest_of_compilation (fndecl);

  current_function_returns_null |= can_reach_end;

  if (((fndecl)->common.volatile_flag) && current_function_returns_null)
    warning ("`noreturn' function does return");
  else if (warn_return_type && can_reach_end
    && ((((((fndecl)->common.type))->common.type))->type.main_variant) != void_type_node)


    warning ("control reaches end of non-void function");


  else if (extra_warnings
    && current_function_returns_value && current_function_returns_null)
    warning ("this function may return with or without a value");





  if (warn_larger_than && !((fndecl)->decl.external_flag) && ((fndecl)->common.type))
    {
      register tree ret_type = ((((fndecl)->common.type))->common.type);

      if (ret_type)
 {
   register tree ret_type_size = ((ret_type)->type.size);

   if (((n64_enum_tree_code) (ret_type_size)->common.code) == INTEGER_CST)
     {
       unsigned units
  = ((ret_type_size)->int_cst.int_cst_low) / 8;

       if (units > larger_than_size)
  warning_with_decl (fndecl,
       "size of return value of `%s' is %u bytes",
       units);
     }
 }
    }




  if (! nested)
    permanent_allocation (1);

  if (((fndecl)->decl.saved_insns.r) == 0 && ! nested)
    {





      if (((fndecl)->decl.initial) != 0)
 ((fndecl)->decl.initial) = error_mark_node;
      ((fndecl)->decl.arguments) = 0;
    }

  if (((fndecl)->decl.static_ctor_flag))
    {





      assemble_constructor (((((fndecl)->decl.name))->identifier.pointer));
    }
  if (((fndecl)->decl.static_dtor_flag))
    {





      assemble_destructor (((((fndecl)->decl.name))->identifier.pointer));
    }

  if (! nested)
    {



      current_function_decl = 
                             ((void *)0)
                                 ;
    }
}





struct n64_tag_c_function
{
  struct n64_tag_c_function *next;
  tree named_labels;
  tree shadowed_labels;
  int returns_value;
  int returns_null;
  int warn_about_return_type;
  int extern_inline;
  struct n64_tag_binding_level *binding_level;
};

struct n64_tag_c_function *c_function_chain;




void
push_c_function_context(void) asm("_push_c_function_context");
void
push_c_function_context(void)
{
  struct n64_tag_c_function *p
    = (struct n64_tag_c_function *) xmalloc (sizeof (struct n64_tag_c_function));

  if (pedantic)
    pedwarn ("ANSI C forbids nested functions");

  push_function_context ();

  p->next = c_function_chain;
  c_function_chain = p;

  p->named_labels = named_labels;
  p->shadowed_labels = shadowed_labels;
  p->returns_value = current_function_returns_value;
  p->returns_null = current_function_returns_null;
  p->warn_about_return_type = warn_about_return_type;
  p->extern_inline = current_extern_inline;
  p->binding_level = current_binding_level;
}



void
pop_c_function_context(void) asm("_pop_c_function_context");
void
pop_c_function_context(void)
{
  struct n64_tag_c_function *p = c_function_chain;
  tree link;


  for (link = shadowed_labels; link; link = ((link)->common.chain))
    if (((((link)->list.value))->decl.name) != 0)
      (((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->label_value)
 = ((link)->list.value);

  if (((current_function_decl)->decl.saved_insns.r) == 0)
    {



      ((current_function_decl)->decl.initial) = error_mark_node;
      ((current_function_decl)->decl.arguments) = 0;
    }

  pop_function_context ();

  c_function_chain = p->next;

  named_labels = p->named_labels;
  shadowed_labels = p->shadowed_labels;
  current_function_returns_value = p->returns_value;
  current_function_returns_null = p->returns_null;
  warn_about_return_type = p->warn_about_return_type;
  current_extern_inline = p->extern_inline;
  current_binding_level = p->binding_level;

  free (p);
}




void
copy_lang_decl(tree node) asm("_copy_lang_decl");
void
copy_lang_decl(tree node)
{
}

