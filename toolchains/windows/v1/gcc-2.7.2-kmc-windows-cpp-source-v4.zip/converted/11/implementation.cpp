// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/c-common.c
/* Subroutines shared by all languages that are variants of C.
   Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int warning(...) asm("_warning");
extern int error(...) asm("_error");
extern int error_with_decl(...) asm("_error_with_decl");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int declare_weak(...) asm("_declare_weak");
extern int assemble_alias(...) asm("_assemble_alias");
extern int pedwarn(...) asm("_pedwarn");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int push_obstacks(...) asm("_push_obstacks");
struct n64_tag__obstack_chunk;
struct n64_tag_function_format_info;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_CHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,
  RID_UNUSED1,

  RID_UNSIGNED,
  RID_SHORT,
  RID_LONG,
  RID_AUTO,
  RID_STATIC,
  RID_EXTERN,
  RID_REGISTER,
  RID_TYPEDEF,
  RID_SIGNED,
  RID_CONST,
  RID_VOLATILE,
  RID_INLINE,
  RID_NOALIAS,
  RID_ITERATOR,
  RID_COMPLEX,

  RID_IN,
  RID_OUT,
  RID_INOUT,
  RID_BYCOPY,
  RID_ONEWAY,
  RID_ID,

  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;

extern tree make_pointer_declarator(...) asm("_make_pointer_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern int yylex(void) asm("_yylex");

extern char *get_directive_line(...) asm("_get_directive_line");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus, limbo_value;
};
extern int pedantic;
struct n64_tag_lang_type
{
  int len;
  tree elts[1];
};
extern tree lookup_interface (tree) asm("_lookup_interface");
extern tree is_class_name (tree) asm("_is_class_name");
extern void maybe_objc_check_decl (tree) asm("_maybe_objc_check_decl");
extern int maybe_objc_comptypes (tree, tree, int) asm("_maybe_objc_comptypes");
extern tree maybe_building_objc_message_expr (void) asm("_maybe_building_objc_message_expr");
extern tree maybe_objc_method_name (tree) asm("_maybe_objc_method_name");
extern int recognize_objc_keyword (void) asm("_recognize_objc_keyword");
extern tree build_objc_string (int, char *) asm("_build_objc_string");


extern void gen_aux_info_record (tree, int, int, int) asm("_gen_aux_info_record");


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree convert (tree, tree) asm("_convert");



extern tree char_array_type_node;
extern tree char_type_node;
extern tree const_ptr_type_node;
extern tree const_string_type_node;
extern tree default_function_type;
extern tree double_ftype_double;
extern tree double_ftype_double_double;
extern tree double_type_node;
extern tree float_type_node;
extern tree intDI_type_node;
extern tree intHI_type_node;
extern tree intQI_type_node;
extern tree intSI_type_node;
extern tree int_array_type_node;
extern tree int_ftype_cptr_cptr_sizet;
extern tree int_ftype_int;
extern tree int_ftype_ptr_ptr_int;
extern tree int_ftype_string_string;
extern tree integer_type_node;
extern tree long_double_type_node;
extern tree long_ftype_long;
extern tree long_integer_type_node;
extern tree long_long_integer_type_node;
extern tree long_long_unsigned_type_node;
extern tree long_unsigned_type_node;
extern tree complex_integer_type_node;
extern tree complex_float_type_node;
extern tree complex_double_type_node;
extern tree complex_long_double_type_node;
extern tree ptr_type_node;
extern tree ptrdiff_type_node;
extern tree short_integer_type_node;
extern tree short_unsigned_type_node;
extern tree signed_char_type_node;
extern tree signed_wchar_type_node;
extern tree string_ftype_ptr_ptr;
extern tree string_type_node;
extern tree unsigned_char_type_node;
extern tree unsigned_intDI_type_node;
extern tree unsigned_intHI_type_node;
extern tree unsigned_intQI_type_node;
extern tree unsigned_intSI_type_node;
extern tree unsigned_type_node;
extern tree unsigned_wchar_type_node;
extern tree void_ftype_ptr_int_int;
extern tree void_ftype_ptr_ptr_int;
extern tree void_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node;
extern tree boolean_type_node;
extern tree boolean_true_node;
extern tree boolean_false_node;

extern tree build_enumerator (tree, tree) asm("_build_enumerator");

extern tree builtin_function (char *, tree, n64_enum_built_in_function function_, char *) asm("_builtin_function");

extern tree c_build_type_variant (tree, int, int) asm("_c_build_type_variant");
extern int c_decode_option (char *) asm("_c_decode_option");
extern void c_mark_varargs (void) asm("_c_mark_varargs");
extern tree check_identifier (tree, tree) asm("_check_identifier");
extern void clear_parm_order (void) asm("_clear_parm_order");
extern tree combine_parm_decls (tree, tree, int) asm("_combine_parm_decls");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern void declare_parm_level (int) asm("_declare_parm_level");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void delete_block (tree) asm("_delete_block");
extern void finish_decl (tree, tree, tree) asm("_finish_decl");
extern void finish_decl_top_level (tree, tree, tree) asm("_finish_decl_top_level");
extern tree finish_enum (tree, tree, tree) asm("_finish_enum");
extern void finish_function (int) asm("_finish_function");
extern tree finish_struct (tree, tree, tree) asm("_finish_struct");
extern tree get_parm_info (int) asm("_get_parm_info");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern int global_bindings_p (void) asm("_global_bindings_p");
extern tree grokfield (char *, int, tree, tree, tree) asm("_grokfield");
extern tree groktypename (tree) asm("_groktypename");
extern tree groktypename_in_parm_context (tree) asm("_groktypename_in_parm_context");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern int in_parm_level_p (void) asm("_in_parm_level_p");
extern void init_decl_processing (void) asm("_init_decl_processing");
extern void insert_block (tree) asm("_insert_block");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree lookup_name (tree) asm("_lookup_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern tree lookup_name_current_level_global (tree) asm("_lookup_name_current_level_global");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void parmlist_tags_warning (void) asm("_parmlist_tags_warning");
extern void pending_xref_error (void) asm("_pending_xref_error");
extern void pop_c_function_context (void) asm("_pop_c_function_context");
extern void pop_label_level (void) asm("_pop_label_level");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void print_lang_decl (...) asm("_print_lang_decl")
                 ;
extern void print_lang_identifier (...) asm("_print_lang_identifier")
                 ;
extern void print_lang_type (...) asm("_print_lang_type")
                 ;
extern void push_c_function_context (void) asm("_push_c_function_context");
extern void push_label_level (void) asm("_push_label_level");
extern void push_parm_decl (tree) asm("_push_parm_decl");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void pushlevel (int) asm("_pushlevel");
extern void pushtag (tree, tree) asm("_pushtag");
extern void set_block (tree) asm("_set_block");
extern tree shadow_label (tree) asm("_shadow_label");
extern void shadow_record_fields (tree) asm("_shadow_record_fields");
extern void shadow_tag (tree) asm("_shadow_tag");
extern void shadow_tag_warned (tree, int) asm("_shadow_tag_warned");
extern tree start_enum (tree) asm("_start_enum");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function")
                        ;
extern tree start_decl (tree, tree, int, tree, tree) asm("_start_decl")
                         ;
extern tree start_struct (n64_enum_tree_code, tree) asm("_start_struct");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern tree xref_tag (n64_enum_tree_code, tree) asm("_xref_tag");


extern tree require_complete_type (tree) asm("_require_complete_type");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");


extern tree common_type (tree, tree) asm("_common_type");
extern int comptypes (tree, tree) asm("_comptypes");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_size_in_bytes (tree) asm("_c_size_in_bytes");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree c_alignof_expr (tree) asm("_c_alignof_expr");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_component_ref (tree, tree) asm("_build_component_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree parser_build_binary_op (n64_enum_tree_code, tree, tree) asm("_parser_build_binary_op")
                         ;
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op")
                              ;
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op")
                        ;
extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern void readonly_warning (tree, char *) asm("_readonly_warning");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_c_cast (tree, tree) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr")
                   ;
extern tree initializer_constant_valid_p (tree, tree) asm("_initializer_constant_valid_p");
extern void store_init_value (tree, tree) asm("_store_init_value");
extern void error_init (char *, char *, char *) asm("_error_init")
                     ;
extern void pedwarn_init (char *, char *, char *) asm("_pedwarn_init")
                     ;
extern void start_init (tree, tree, int) asm("_start_init");
extern void finish_init (void) asm("_finish_init");
extern void really_start_incremental_init (tree) asm("_really_start_incremental_init");
extern void push_init_level (int) asm("_push_init_level");
extern tree pop_init_level (int) asm("_pop_init_level");
extern void set_init_index (tree, tree) asm("_set_init_index");
extern void set_init_label (tree) asm("_set_init_label");
extern void process_init_element (tree) asm("_process_init_element");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands")
                               ;
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");


extern void iterator_expand (tree) asm("_iterator_expand");
extern void iterator_for_loop_start (tree) asm("_iterator_for_loop_start");
extern void iterator_for_loop_end (tree) asm("_iterator_for_loop_end");
extern void iterator_for_loop_record (tree) asm("_iterator_for_loop_record");
extern void push_iterator_stack (void) asm("_push_iterator_stack");
extern void pop_iterator_stack (void) asm("_pop_iterator_stack");




extern int current_function_returns_value;




extern int current_function_returns_null;



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_no_ident;



extern int warn_implicit;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;




extern int warn_redundant_decls;







extern int warn_nested_externs;




extern int warn_cast_qual;





extern int warn_bad_function_cast;



extern int warn_traditional;



extern int warn_format;



extern int warn_char_subscripts;



extern int warn_conversion;



extern int flag_traditional;



extern int flag_allow_single_precision;



extern int warn_parentheses;



extern int warn_missing_braces;




extern int (*comptypes_record_hook)(...);



extern int system_header_p;



extern int doing_objc_thang;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");


extern struct n64_tag_obstack permanent_obstack;

enum n64_cpp_enum_attrs{A_PACKED, A_NOCOMMON, A_NORETURN, A_CONST, A_T_UNION,
     A_CONSTRUCTOR, A_DESTRUCTOR, A_MODE, A_SECTION, A_ALIGNED,
     A_UNUSED, A_FORMAT, A_WEAK, A_ALIAS};
typedef __underlying_type(enum n64_cpp_enum_attrs) n64_enum_attrs;


static void declare_hidden_char_array (char *, char *) asm("_declare_hidden_char_array");
static void add_attribute (n64_enum_attrs, char *, int, int, int) asm("_add_attribute")
                           ;
static void init_attributes (void) asm("_init_attributes");



void
declare_function_name(void) asm("_declare_function_name");
void
declare_function_name(void)
{
  char *name, *printable_name;

  if (current_function_decl == 
                              ((void *)0)
                                  )
    {
      name = "";
      printable_name = "top level";
    }
  else
    {
      char *kind = "function";
      if (((n64_enum_tree_code) (((current_function_decl)->common.type))->common.code) == METHOD_TYPE)
 kind = "method";

      if (((current_function_decl)->decl.name))
        name = ((((current_function_decl)->decl.name))->identifier.pointer);
      else
 name = "";
      printable_name = (*decl_printable_name) (current_function_decl, &kind);
    }

  declare_hidden_char_array ("__FUNCTION__", name);
  declare_hidden_char_array ("__PRETTY_FUNCTION__", printable_name);
}

static void
declare_hidden_char_array(char *name, char *value) asm("_declare_hidden_char_array");
static void
declare_hidden_char_array(char *name, char *value)
{
  tree decl, type, init;
  int vlen;



  vlen = strlen (value) + 1;
  type = char_array_type_node;
  if (((((((type)->common.type))->type.maxval))->int_cst.int_cst_low) < vlen
      || warn_larger_than)
    type = build_array_type (char_type_node,
        build_index_type (build_int_2_wide ((int) (vlen), (int) (0))));
  push_obstacks_nochange ();
  decl = build_decl (VAR_DECL, get_identifier (name), type);
  ((decl)->common.static_flag) = 1;
  ((decl)->common.readonly_flag) = 1;
  ((decl)->common.asm_written_flag) = 1;
  ((decl)->decl.linenum) = 0;
  ((decl)->decl.artificial_flag) = 1;
  ((decl)->decl.in_system_header_flag) = 1;
  ((decl)->decl.ignored_flag) = 1;
  init = build_string (vlen, value);
  ((init)->common.type) = type;
  ((decl)->decl.initial) = init;
  finish_decl (pushdecl (decl), init, (tree) 
                                     ((void *)0)
                                              );
}





tree
combine_strings(tree strings) asm("_combine_strings");
tree
combine_strings(tree strings)
{
  register tree value, t;
  register int length = 1;
  int wide_length = 0;
  int wide_flag = 0;
  int wchar_bytes = ((wchar_type_node)->type.precision) / 8;
  int nchars;

  if (((strings)->common.chain))
    {

      register char *p, *q;




      for (t = strings; t; t = ((t)->common.chain))
 {
   if (((t)->common.type) == wchar_array_type_node)
     {
       wide_length += (((t)->string.length) - wchar_bytes);
       wide_flag = 1;
     }
   else
     length += (((t)->string.length) - 1);
 }



      if (wide_flag)
 length = length * wchar_bytes + wide_length;

      p = savealloc (length);





      q = p;
      for (t = strings; t; t = ((t)->common.chain))
 {
   int len = (((t)->string.length)
       - ((((t)->common.type) == wchar_array_type_node)
   ? wchar_bytes : 1));
   if ((((t)->common.type) == wchar_array_type_node) == wide_flag)
     {
       memcpy (q,((t)->string.pointer),len);
       q += len;
     }
   else
     {
       int i;
       for (i = 0; i < len; i++)
  ((int *) q)[i] = ((t)->string.pointer)[i];
       q += len * wchar_bytes;
     }
 }
      if (wide_flag)
 {
   int i;
   for (i = 0; i < wchar_bytes; i++)
     *q++ = 0;
 }
      else
 *q = 0;

      value = make_node (STRING_CST);
      ((value)->string.pointer) = p;
      ((value)->string.length) = length;
      ((value)->common.constant_flag) = 1;
    }
  else
    {
      value = strings;
      length = ((value)->string.length);
      if (((value)->common.type) == wchar_array_type_node)
 wide_flag = 1;
    }


  nchars = wide_flag ? length / wchar_bytes : length;




  if (warn_write_strings
      && (! flag_traditional && ! flag_writable_strings))
    {
      tree elements
 = build_type_variant (wide_flag ? wchar_type_node : char_type_node,
         1, 0);
      ((value)->common.type)
 = build_array_type (elements,
       build_index_type (build_int_2_wide ((int) (nchars - 1), (int) (0))));
    }
  else
    ((value)->common.type)
      = build_array_type (wide_flag ? wchar_type_node : char_type_node,
     build_index_type (build_int_2_wide ((int) (nchars - 1), (int) (0))));
  ((value)->common.constant_flag) = 1;
  ((value)->common.static_flag) = 1;
  return value;
}






static struct {n64_enum_attrs id; tree name; int min, max, decl_req;} attrtab[50];

static int attrtab_idx = 0;



static void
add_attribute(n64_enum_attrs id, char *string, int min_len, int max_len, int decl_req) asm("_add_attribute");
static void
add_attribute(n64_enum_attrs id, char *string, int min_len, int max_len, int decl_req)
{
  char buf[100];

  attrtab[attrtab_idx].id = id;
  attrtab[attrtab_idx].name = get_identifier (string);
  attrtab[attrtab_idx].min = min_len;
  attrtab[attrtab_idx].max = max_len;
  attrtab[attrtab_idx++].decl_req = decl_req;

  sprintf (buf, "__%s__", string);

  attrtab[attrtab_idx].id = id;
  attrtab[attrtab_idx].name = get_identifier (buf);
  attrtab[attrtab_idx].min = min_len;
  attrtab[attrtab_idx].max = max_len;
  attrtab[attrtab_idx++].decl_req = decl_req;
}



static void
init_attributes(void) asm("_init_attributes");
static void
init_attributes(void)
{
  add_attribute (A_PACKED, "packed", 0, 0, 0);
  add_attribute (A_NOCOMMON, "nocommon", 0, 0, 1);
  add_attribute (A_NORETURN, "noreturn", 0, 0, 1);
  add_attribute (A_NORETURN, "volatile", 0, 0, 1);
  add_attribute (A_UNUSED, "unused", 0, 0, 1);
  add_attribute (A_CONST, "const", 0, 0, 1);
  add_attribute (A_T_UNION, "transparent_union", 0, 0, 0);
  add_attribute (A_CONSTRUCTOR, "constructor", 0, 0, 1);
  add_attribute (A_DESTRUCTOR, "destructor", 0, 0, 1);
  add_attribute (A_MODE, "mode", 1, 1, 1);
  add_attribute (A_SECTION, "section", 1, 1, 1);
  add_attribute (A_ALIGNED, "aligned", 0, 1, 0);
  add_attribute (A_FORMAT, "format", 3, 3, 1);
  add_attribute (A_WEAK, "weak", 0, 0, 1);
  add_attribute (A_ALIAS, "alias", 1, 1, 1);
}






void
decl_attributes(tree node, tree attributes, tree prefix_attributes) asm("_decl_attributes");
void
decl_attributes(tree node, tree attributes, tree prefix_attributes)
{
  tree decl = 0, type;
  int is_type;
  tree a;

  if (attrtab_idx == 0)
    init_attributes ();

  if ((*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]) == 'd')
    {
      decl = node;
      type = ((decl)->common.type);
      is_type = ((n64_enum_tree_code) (node)->common.code) == TYPE_DECL;
    }
  else if ((*tree_code_type[(int) (((n64_enum_tree_code) (node)->common.code))]) == 't')
    type = node, is_type = 1;

  attributes = chainon (prefix_attributes, attributes);

  for (a = attributes; a; a = ((a)->common.chain))
    {
      tree name = ((a)->list.purpose);
      tree args = ((a)->list.value);
      int i;
      n64_enum_attrs id;

      for (i = 0; i < attrtab_idx; i++)
 if (attrtab[i].name == name)
   break;

      if (i == attrtab_idx)
 {
   if (! valid_machine_attribute (name, args, decl, type))
     warning ("`%s' attribute directive ignored",
       ((name)->identifier.pointer));
   continue;
 }
      else if (attrtab[i].decl_req && decl == 0)
 {
   warning ("`%s' attribute does not apply to types",
     ((name)->identifier.pointer));
   continue;
 }
      else if (list_length (args) < attrtab[i].min
        || list_length (args) > attrtab[i].max)
 {
   error ("wrong number of arguments specified for `%s' attribute",
   ((name)->identifier.pointer));
   continue;
 }

      id = attrtab[i].id;
      switch (id)
 {
 case A_PACKED:
   if (is_type)
     ((type)->type.packed_flag) = 1;
   else if (((n64_enum_tree_code) (decl)->common.code) == FIELD_DECL)
     ((decl)->decl.regdecl_flag) = 1;


   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_NOCOMMON:
   if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
     ((decl)->decl.common_flag) = 0;
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_NORETURN:
   if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
     ((decl)->common.volatile_flag) = 1;
   else if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
     && ((n64_enum_tree_code) (((type)->common.type))->common.code) == FUNCTION_TYPE)
     ((decl)->common.type) = type
       = build_pointer_type
  (build_type_variant (((type)->common.type),
         ((((type)->common.type))->common.readonly_flag), 1));
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_UNUSED:
   if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL || ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
       || ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
     ((decl)->common.used_flag) = 1;
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_CONST:
   if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
     ((decl)->common.readonly_flag) = 1;
   else if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
     && ((n64_enum_tree_code) (((type)->common.type))->common.code) == FUNCTION_TYPE)
     ((decl)->common.type) = type
       = build_pointer_type
  (build_type_variant (((type)->common.type), 1,
         ((((type)->common.type))->common.volatile_flag)));
   else
     warning ( "`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_T_UNION:
   if (is_type
       && ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE
       && (decl == 0
    || ((type)->type.mode) == ((((type)->type.values))->decl.mode)))
     ((type)->type.transparent_union_flag) = 1;
   else if (decl != 0 && ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL
     && ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE
     && ((type)->type.mode) == ((((type)->type.values))->decl.mode))
     ((decl)->decl.transparent_union) = 1;
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_CONSTRUCTOR:
   if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
       && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
       && decl_function_context (decl) == 0)
     {
       ((decl)->decl.static_ctor_flag) = 1;
       ((decl)->common.used_flag) = 1;
     }
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_DESTRUCTOR:
   if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
       && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
       && decl_function_context (decl) == 0)
     {
       ((decl)->decl.static_dtor_flag) = 1;
       ((decl)->common.used_flag) = 1;
     }
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;

 case A_MODE:
   if (((n64_enum_tree_code) (((args)->list.value))->common.code) != IDENTIFIER_NODE)
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   else
     {
       int j;
       char *p = ((((args)->list.value))->identifier.pointer);
       int len = strlen (p);
       n64_enum_machine_mode mode = VOIDmode;
       tree typefm;

       if (len > 4 && p[0] == '_' && p[1] == '_'
    && p[len - 1] == '_' && p[len - 2] == '_')
  {
    char *newp = (char *) 
                         __builtin_alloca((
                         len - 1
                         ))
                                         ;

    strcpy (newp, &p[2]);
    newp[len - 4] = '\0';
    p = newp;
  }



       if (! strcmp (p, "byte"))
  mode = byte_mode;
       else if (!strcmp (p, "word"))
  mode = word_mode;
       else if (! strcmp (p, "pointer"))
  mode = ptr_mode;
       else
  for (j = 0; j < (int) MAX_MACHINE_MODE; j++)
    if (!strcmp (p, (mode_name[(int)(j)])))
      mode = (n64_enum_machine_mode) j;

       if (mode == VOIDmode)
  error ("unknown machine mode `%s'", p);
       else if (0 == (typefm = type_for_mode (mode,
           ((type)->common.unsigned_flag))))
  error ("no data type for mode `%s'", p);
       else
  {
    ((decl)->common.type) = type = typefm;
    ((decl)->decl.size) = 0;
    layout_decl (decl, 0);
  }
     }
   break;

 case A_SECTION:

   if ((((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
        || ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
       && ((n64_enum_tree_code) (((args)->list.value))->common.code) == STRING_CST)
     {
       if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
    && current_function_decl != (tree) 
                               ((void *)0)
                                        )
  error_with_decl (decl,
    "section attribute cannot be specified for local variables");


       else if (((decl)->decl.section_name) != (tree) 
                                           ((void *)0)
         
        && strcmp (((((decl)->decl.section_name))->string.pointer),
      ((((args)->list.value))->string.pointer)) != 0)
  error_with_decl (node,
     "section of `%s' conflicts with previous declaration");
       else
  ((decl)->decl.section_name) = ((args)->list.value);
     }
   else
     error_with_decl (node,
      "section attribute not allowed for `%s'");




   break;

 case A_ALIGNED:
   {
     tree align_expr
       = args ? ((args)->list.value) : size_int (64);
     int align;


     while (((n64_enum_tree_code) (align_expr)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (align_expr)->common.code) == CONVERT_EXPR
     || ((n64_enum_tree_code) (align_expr)->common.code) == NON_LVALUE_EXPR)
       align_expr = ((align_expr)->exp.operands[0]);

     if (((n64_enum_tree_code) (align_expr)->common.code) != INTEGER_CST)
       {
  error ("requested alignment is not a constant");
  continue;
       }

     align = ((align_expr)->int_cst.int_cst_low) * 8;

     if (exact_log2_wide ((int) (align)) == -1)
       error ("requested alignment is not a power of 2");
     else if (is_type)
       ((type)->type.align) = align;
     else if (((n64_enum_tree_code) (decl)->common.code) != VAR_DECL
       && ((n64_enum_tree_code) (decl)->common.code) != FIELD_DECL)
       error_with_decl (decl,
          "alignment may not be specified for `%s'");
     else
       ((decl)->decl.frame_size.u) = align;
   }
   break;

 case A_FORMAT:
   {
     tree format_type = ((args)->list.value);
     tree format_num_expr = ((((args)->common.chain))->list.value);
     tree first_arg_num_expr
       = ((((((args)->common.chain))->common.chain))->list.value);
     int format_num;
     int first_arg_num;
     int is_scan;
     tree argument;
     int arg_num;

     if (((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL)
       {
  error_with_decl (decl,
    "argument format specified for non-function `%s'");
  continue;
       }

     if (((n64_enum_tree_code) (format_type)->common.code) == IDENTIFIER_NODE
  && (!strcmp (((format_type)->identifier.pointer), "printf")
      || !strcmp (((format_type)->identifier.pointer),
    "__printf__")))
       is_scan = 0;
     else if (((n64_enum_tree_code) (format_type)->common.code) == IDENTIFIER_NODE
       && (!strcmp (((format_type)->identifier.pointer), "scanf")
    || !strcmp (((format_type)->identifier.pointer),
         "__scanf__")))
       is_scan = 1;
     else
       {
  error ("unrecognized format specifier for `%s'");
  continue;
       }



     while (((n64_enum_tree_code) (format_num_expr)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (format_num_expr)->common.code) == CONVERT_EXPR
     || ((n64_enum_tree_code) (format_num_expr)->common.code) == NON_LVALUE_EXPR)
       format_num_expr = ((format_num_expr)->exp.operands[0]);

     while (((n64_enum_tree_code) (first_arg_num_expr)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (first_arg_num_expr)->common.code) == CONVERT_EXPR
     || ((n64_enum_tree_code) (first_arg_num_expr)->common.code) == NON_LVALUE_EXPR)
       first_arg_num_expr = ((first_arg_num_expr)->exp.operands[0]);

     if (((n64_enum_tree_code) (format_num_expr)->common.code) != INTEGER_CST
  || ((n64_enum_tree_code) (first_arg_num_expr)->common.code) != INTEGER_CST)
       {
  error ("format string has non-constant operand number");
  continue;
       }

     format_num = ((format_num_expr)->int_cst.int_cst_low);
     first_arg_num = ((first_arg_num_expr)->int_cst.int_cst_low);
     if (first_arg_num != 0 && first_arg_num <= format_num)
       {
  error ("format string arg follows the args to be formatted");
  continue;
       }




     argument = ((type)->type.values);
     if (argument)
       {
  for (arg_num = 1; ; ++arg_num)
    {
      if (argument == 0 || arg_num == format_num)
        break;
      argument = ((argument)->common.chain);
    }
  if (! argument
      || ((n64_enum_tree_code) (((argument)->list.value))->common.code) != POINTER_TYPE
    || (((((((argument)->list.value))->common.type))->type.main_variant)
        != char_type_node))
    {
      error ("format string arg not a string type");
      continue;
    }
  if (first_arg_num != 0)
    {


      while (argument)
        arg_num++, argument = ((argument)->common.chain);
    if (arg_num != first_arg_num)
      {
        error ("args to be formatted is not ...");
        continue;
      }
    }
       }

     record_function_format (((decl)->decl.name),
        ((decl)->decl.assembler_name),
        is_scan, format_num, first_arg_num);
     break;
   }

 case A_WEAK:
   declare_weak (decl);
   break;

 case A_ALIAS:
   if ((((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.initial))
       || ((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL && ! ((decl)->decl.external_flag))
     error_with_decl (decl,
        "`%s' defined both normally and as an alias");
   else if (decl_function_context (decl) == 0)
     {
       tree id = get_identifier (((((args)->list.value))->string.pointer)
                        );
       if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
  ((decl)->decl.initial) = error_mark_node;
       else
  ((decl)->decl.external_flag) = 0;
       assemble_alias (decl, id);
     }
   else
     warning ("`%s' attribute ignored", ((name)->identifier.pointer));
   break;
 }
    }
}
typedef struct {
  char *format_chars;
  int pointer_count;

  tree *nolen;


  tree *hlen;


  tree *llen;


  tree *qlen;


  tree *bigllen;

  char *flag_chars;
} format_char_info;

static format_char_info print_char_table[] = {
  { "di", 0, &integer_type_node, &integer_type_node, &long_integer_type_node, &long_long_integer_type_node, &long_long_integer_type_node, "-wp0 +" },
  { "oxX", 0, &unsigned_type_node, &unsigned_type_node, &long_unsigned_type_node, &long_long_unsigned_type_node, &long_long_unsigned_type_node, "-wp0#" },
  { "u", 0, &unsigned_type_node, &unsigned_type_node, &long_unsigned_type_node, &long_long_unsigned_type_node, &long_long_unsigned_type_node, "-wp0" },

  { "Z", 0, &sizetype, 
                 ((void *)0)
                     , 
                       ((void *)0)
                           , 
                             ((void *)0)
                                 , 
                                   ((void *)0)
                                       , "-wp0" },
  { "m", 0, &void_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "-wp" },
  { "feEgG", 0, &double_type_node, 
                    ((void *)0)
                        , 
                          ((void *)0)
                              , 
                                ((void *)0)
                                    , &long_double_type_node, "-wp0 +#" },
  { "c", 0, &integer_type_node, 
                ((void *)0)
                    , &wchar_type_node, 
                           ((void *)0)
                               , 
                                 ((void *)0)
                                     , "-w" },
  { "C", 0, &wchar_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "-w" },
  { "s", 1, &char_type_node, 
                ((void *)0)
                    , &wchar_type_node, 
                           ((void *)0)
                               , 
                                 ((void *)0)
                                     , "-wp" },
  { "S", 1, &wchar_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "-wp" },
  { "p", 1, &void_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "-w" },
  { "n", 1, &integer_type_node, &short_integer_type_node, &long_integer_type_node, &long_long_integer_type_node, 
                                ((void *)0)
                                    , "" },
  { 
   ((void *)0) 
        }
};

static format_char_info scan_char_table[] = {
  { "di", 1, &integer_type_node, &short_integer_type_node, &long_integer_type_node, &long_long_integer_type_node, &long_long_integer_type_node, "*" },
  { "ouxX", 1, &unsigned_type_node, &short_unsigned_type_node, &long_unsigned_type_node, &long_long_unsigned_type_node, &long_long_unsigned_type_node, "*" },
  { "efgEG", 1, &float_type_node, 
                    ((void *)0)
                        , &double_type_node, 
                               ((void *)0)
                                   , &long_double_type_node, "*" },
  { "sc", 1, &char_type_node, 
                 ((void *)0)
                     , &wchar_type_node, 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "*a" },
  { "[", 1, &char_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "*a" },
  { "C", 1, &wchar_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "*" },
  { "S", 1, &wchar_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "*" },
  { "p", 2, &void_type_node, 
                ((void *)0)
                    , 
                      ((void *)0)
                          , 
                            ((void *)0)
                                , 
                                  ((void *)0)
                                      , "*" },
  { "n", 1, &integer_type_node, &short_integer_type_node, &long_integer_type_node, &long_long_integer_type_node, 
                                ((void *)0)
                                    , "" },
  { 
   ((void *)0) 
        }
};

typedef struct n64_tag_function_format_info {
  struct n64_tag_function_format_info *next;
  tree name;
  tree assembler_name;
  int is_scan;
  int format_num;
  int first_arg_num;
} function_format_info;

static function_format_info *function_format_list = 
                                                   ((void *)0)
                                                       ;

static void check_format_info (function_format_info *, tree) asm("_check_format_info");
void
init_function_format_info(void) asm("_init_function_format_info");
void
init_function_format_info(void)
{
  record_function_format (get_identifier ("printf"), (tree) 
                                                    ((void *)0)
                                                             , 0, 1, 2);
  record_function_format (get_identifier ("fprintf"), (tree) 
                                                     ((void *)0)
                                                              , 0, 2, 3);
  record_function_format (get_identifier ("sprintf"), (tree) 
                                                     ((void *)0)
                                                              , 0, 2, 3);
  record_function_format (get_identifier ("scanf"), (tree) 
                                                   ((void *)0)
                                                            , 1, 1, 2);
  record_function_format (get_identifier ("fscanf"), (tree) 
                                                    ((void *)0)
                                                             , 1, 2, 3);
  record_function_format (get_identifier ("sscanf"), (tree) 
                                                    ((void *)0)
                                                             , 1, 2, 3);
  record_function_format (get_identifier ("vprintf"), (tree) 
                                                     ((void *)0)
                                                              , 0, 1, 0);
  record_function_format (get_identifier ("vfprintf"), (tree) 
                                                      ((void *)0)
                                                               , 0, 2, 0);
  record_function_format (get_identifier ("vsprintf"), (tree) 
                                                      ((void *)0)
                                                               , 0, 2, 0);
}
void
record_function_format(tree name, tree assembler_name, int is_scan, int format_num, int first_arg_num) asm("_record_function_format");
void
record_function_format(tree name, tree assembler_name, int is_scan, int format_num, int first_arg_num)
{
  function_format_info *info;



  for (info = function_format_list; info; info = info->next)
    {
      if (info->name == name && info->assembler_name == assembler_name)
 break;
    }
  if (! info)
    {
      info = (function_format_info *) xmalloc (sizeof (function_format_info));
      info->next = function_format_list;
      function_format_list = info;

      info->name = name;
      info->assembler_name = assembler_name;
    }

  info->is_scan = is_scan;
  info->format_num = format_num;
  info->first_arg_num = first_arg_num;
}

static char tfaff[] = "too few arguments for format";







void
check_function_format(tree name, tree assembler_name, tree params) asm("_check_function_format");
void
check_function_format(tree name, tree assembler_name, tree params)
{
  function_format_info *info;


  for (info = function_format_list; info; info = info->next)
    {
      if (info->assembler_name
   ? (info->assembler_name == assembler_name)
   : (info->name == name))
 {

   check_format_info (info, params);
   break;
 }
    }
}





static void
check_format_info(function_format_info *info, tree params) asm("_check_format_info");
static void
check_format_info(function_format_info *info, tree params)
{
  int i;
  int arg_num;
  int suppressed, wide, precise;
  int length_char;
  int format_char;
  int format_length;
  tree format_tree;
  tree cur_param;
  tree cur_type;
  tree wanted_type;
  tree first_fillin_param;
  char *format_chars;
  format_char_info *fci;
  static char message[132];
  char flag_chars[8];
  int has_operand_number = 0;



  for (arg_num = 1; ; ++arg_num)
    {
      if (params == 0)
 return;
      if (arg_num == info->format_num)
 break;
      params = ((params)->common.chain);
    }
  format_tree = ((params)->list.value);
  params = ((params)->common.chain);
  if (format_tree == 0)
    return;

  while (((n64_enum_tree_code) (format_tree)->common.code) == NOP_EXPR)
    format_tree = ((format_tree)->exp.operands[0]);
  if (integer_zerop (format_tree))
    {
      warning ("null format string");
      return;
    }
  if (((n64_enum_tree_code) (format_tree)->common.code) != ADDR_EXPR)
    return;
  format_tree = ((format_tree)->exp.operands[0]);
  if (((n64_enum_tree_code) (format_tree)->common.code) != STRING_CST)
    return;
  format_chars = ((format_tree)->string.pointer);
  format_length = ((format_tree)->string.length);
  if (format_length <= 1)
    warning ("zero-length format string");
  if (format_chars[--format_length] != 0)
    {
      warning ("unterminated format string");
      return;
    }

  while (arg_num + 1 < info->first_arg_num)
    {
      if (params == 0)
 return;
      params = ((params)->common.chain);
      ++arg_num;
    }

  first_fillin_param = params;
  while (1)
    {
      int aflag;
      if (*format_chars == 0)
 {
   if (format_chars - ((format_tree)->string.pointer) != format_length)
     warning ("embedded `\\0' in format");
   if (info->first_arg_num != 0 && params != 0 && ! has_operand_number)
     warning ("too many arguments for format");
   return;
 }
      if (*format_chars++ != '%')
 continue;
      if (*format_chars == 0)
 {
   warning ("spurious trailing `%%' in format");
   continue;
 }
      if (*format_chars == '%')
 {
   ++format_chars;
   continue;
 }
      flag_chars[0] = 0;
      suppressed = wide = precise = 0;
      if (info->is_scan)
 {
   suppressed = *format_chars == '*';
   if (suppressed)
     ++format_chars;
   while (isdigit (*format_chars))
     ++format_chars;
 }
      else
 {


   if (*format_chars >= '0' && *format_chars <= '9')
     {
       char *p = format_chars;

       while (*p >= '0' && *p++ <= '9')
  ;

       if (*p == '$')
  {
    int opnum = atoi (format_chars);

    params = first_fillin_param;
    format_chars = p + 1;
    has_operand_number = 1;

    for (i = 1; i < opnum && params != 0; i++)
      params = ((params)->common.chain);

    if (opnum == 0 || params == 0)
      {
        warning ("operand number out of range in format");
        return;
      }
  }
     }

   while (*format_chars != 0 && strchr (" +#0-", *format_chars) != 0)
     {
       if (strchr (flag_chars, *format_chars) != 0)
  {
    sprintf (message, "repeated `%c' flag in format",
      *format_chars);
    warning (message);
  }
       i = strlen (flag_chars);
       flag_chars[i++] = *format_chars++;
       flag_chars[i] = 0;
     }


   if (strchr (flag_chars, ' ') != 0
       && strchr (flag_chars, '+') != 0)
     warning ("use of both ` ' and `+' flags in format");


   if (strchr (flag_chars, '0') != 0
       && strchr (flag_chars, '-') != 0)
     warning ("use of both `0' and `-' flags in format");
   if (*format_chars == '*')
     {
       wide = 1;


       ++format_chars;
       if (params == 0)
  {
    warning (tfaff);
    return;
  }
       if (info->first_arg_num != 0)
  {
    cur_param = ((params)->list.value);
    params = ((params)->common.chain);
    ++arg_num;




    if ((((((cur_param)->common.type))->type.main_variant)
         != integer_type_node)
        &&
        (((((cur_param)->common.type))->type.main_variant)
         != unsigned_type_node))
      {
        sprintf (message,
          "field width is not type int (arg %d)",
          arg_num);
        warning (message);
      }
  }
     }
   else
     {
       while (isdigit (*format_chars))
  {
    wide = 1;
    ++format_chars;
  }
     }
   if (*format_chars == '.')
     {
       precise = 1;
       ++format_chars;
       if (*format_chars != '*' && !isdigit (*format_chars))
  warning ("`.' not followed by `*' or digit in format");


       if (*format_chars == '*')
  {
    if (info->first_arg_num != 0)
      {
        ++format_chars;
        if (params == 0)
          {
     warning (tfaff);
     return;
   }
        cur_param = ((params)->list.value);
        params = ((params)->common.chain);
        ++arg_num;
        if (((((cur_param)->common.type))->type.main_variant)
     != integer_type_node)
          {
            sprintf (message,
       "field width is not type int (arg %d)",
       arg_num);
            warning (message);
          }
      }
  }
       else
  {
    while (isdigit (*format_chars))
      ++format_chars;
  }
     }
 }
      if (*format_chars == 'h' || *format_chars == 'l' || *format_chars == 'q' ||
   *format_chars == 'L')
 length_char = *format_chars++;
      else
 length_char = 0;
      if (length_char == 'l' && *format_chars == 'l')
 length_char = 'q', format_chars++;
      aflag = 0;
      if (*format_chars == 'a')
 {
   aflag = 1;
   format_chars++;
 }
      if (suppressed && length_char != 0)
 {
   sprintf (message,
     "use of `*' and `%c' together in format",
     length_char);
   warning (message);
 }
      format_char = *format_chars;
      if (format_char == 0)
 {
   warning ("conversion lacks type at end of format");
   continue;
 }
      format_chars++;
      fci = info->is_scan ? scan_char_table : print_char_table;
      while (fci->format_chars != 0
      && strchr (fci->format_chars, format_char) == 0)
   ++fci;
      if (fci->format_chars == 0)
 {
   if (format_char >= 040 && format_char < 0177)
     sprintf (message,
       "unknown conversion type character `%c' in format",
       format_char);
   else
     sprintf (message,
       "unknown conversion type character 0x%x in format",
       format_char);
   warning (message);
   continue;
 }
      if (wide && strchr (fci->flag_chars, 'w') == 0)
 {
   sprintf (message, "width used with `%c' format",
     format_char);
   warning (message);
 }
      if (precise && strchr (fci->flag_chars, 'p') == 0)
 {
   sprintf (message, "precision used with `%c' format",
     format_char);
   warning (message);
 }
      if (aflag && strchr (fci->flag_chars, 'a') == 0)
 {
   sprintf (message, "`a' flag used with `%c' format",
     format_char);
   warning (message);
 }
      if (info->is_scan && format_char == '[')
 {

   if (*format_chars == '^')
     ++format_chars;


   if (*format_chars == ']')
     ++format_chars;
   while (*format_chars && *format_chars != ']')
     ++format_chars;
   if (*format_chars != ']')

       warning ("no closing `]' for `%%[' format");
 }
      if (suppressed)
 {
   if (strchr (fci->flag_chars, '*') == 0)
     {
       sprintf (message,
         "suppression of `%c' conversion in format",
         format_char);
       warning (message);
     }
   continue;
 }
      for (i = 0; flag_chars[i] != 0; ++i)
 {
   if (strchr (fci->flag_chars, flag_chars[i]) == 0)
     {
       sprintf (message, "flag `%c' used with type `%c'",
         flag_chars[i], format_char);
       warning (message);
     }
 }
      if (precise && strchr (flag_chars, '0') != 0
   && (format_char == 'd' || format_char == 'i'
       || format_char == 'o' || format_char == 'u'
       || format_char == 'x' || format_char == 'x'))
 {
   sprintf (message,
     "precision and `0' flag not both allowed with `%c' format",
     format_char);
   warning (message);
 }
      switch (length_char)
 {
 default: wanted_type = fci->nolen ? *(fci->nolen) : 0; break;
 case 'h': wanted_type = fci->hlen ? *(fci->hlen) : 0; break;
 case 'l': wanted_type = fci->llen ? *(fci->llen) : 0; break;
 case 'q': wanted_type = fci->qlen ? *(fci->qlen) : 0; break;
 case 'L': wanted_type = fci->bigllen ? *(fci->bigllen) : 0; break;
 }
      if (wanted_type == 0)
 {
   sprintf (message,
     "use of `%c' length character with `%c' type character",
     length_char, format_char);
   warning (message);
 }
      if (info->first_arg_num == 0)
 continue;
      if (fci->pointer_count == 0 && wanted_type == void_type_node)

 continue;
      if (params == 0)
 {
   warning (tfaff);
   return;
 }
      cur_param = ((params)->list.value);
      params = ((params)->common.chain);
      ++arg_num;
      cur_type = ((cur_param)->common.type);



      for (i = 0; i < fci->pointer_count; ++i)
 {
   if (((n64_enum_tree_code) (cur_type)->common.code) == POINTER_TYPE)
     {
       cur_type = ((cur_type)->common.type);
       continue;
     }
   if (((n64_enum_tree_code) (cur_type)->common.code) != ERROR_MARK)
     {
       sprintf (message,
         "format argument is not a %s (arg %d)",
         ((fci->pointer_count == 1) ? "pointer" : "pointer to a pointer"),
         arg_num);
       warning (message);
     }
   break;
 }


      if (i == fci->pointer_count && wanted_type != 0
   && ((n64_enum_tree_code) (cur_type)->common.code) != ERROR_MARK
   && wanted_type != ((cur_type)->type.main_variant)


   && ! (wanted_type == void_type_node
  && fci->pointer_count > 0)

   && !(((n64_enum_tree_code) (wanted_type)->common.code) == INTEGER_TYPE
        && ((n64_enum_tree_code) (((cur_type)->type.main_variant))->common.code) == INTEGER_TYPE
        && (((wanted_type)->common.unsigned_flag)
     ? wanted_type == (cur_type = unsigned_type (cur_type))
     : wanted_type == (cur_type = signed_type (cur_type))))


   && ! (wanted_type == char_type_node
  && (((cur_type)->type.main_variant) == signed_char_type_node
      || ((cur_type)->type.main_variant) == unsigned_char_type_node)))
 {
   register char *cxx_this;
   register char *that;

   cxx_this = ((((((wanted_type)->type.name))->decl.name))->identifier.pointer);
   that = 0;
   if (((n64_enum_tree_code) (cur_type)->common.code) != ERROR_MARK
       && ((cur_type)->type.name) != 0
       && ((n64_enum_tree_code) (cur_type)->common.code) != INTEGER_TYPE
       && !(((n64_enum_tree_code) (cur_type)->common.code) == POINTER_TYPE
     && ((n64_enum_tree_code) (((cur_type)->common.type))->common.code) == INTEGER_TYPE))
     {
       if (((n64_enum_tree_code) (((cur_type)->type.name))->common.code) == TYPE_DECL
    && ((((cur_type)->type.name))->decl.name) != 0)
  that = ((((((cur_type)->type.name))->decl.name))->identifier.pointer);
       else
  that = ((((cur_type)->type.name))->identifier.pointer);
     }




   if (that == 0)
     {
       if (((n64_enum_tree_code) (cur_type)->common.code) == POINTER_TYPE)
  that = "pointer";
       else
  that = "different type";
     }


   if (((n64_enum_tree_code) (cur_type)->common.code) == INTEGER_TYPE
       && ((n64_enum_tree_code) (wanted_type)->common.code) == INTEGER_TYPE
       && ((cur_type)->type.precision) == ((wanted_type)->type.precision)
       && ((cur_type)->type.name) != 0
       && ((n64_enum_tree_code) (((cur_type)->type.name))->common.code) == TYPE_DECL)
     that = ((((((cur_type)->type.name))->decl.name))->identifier.pointer);

   if (strcmp (cxx_this, that) != 0)
     {
       sprintf (message, "%s format, %s arg (arg %d)",
   cxx_this, that, arg_num);
       warning (message);
     }
 }
    }
}







void
constant_expression_warning(tree value) asm("_constant_expression_warning");
void
constant_expression_warning(tree value)
{
  if ((((n64_enum_tree_code) (value)->common.code) == INTEGER_CST || ((n64_enum_tree_code) (value)->common.code) == REAL_CST
       || ((n64_enum_tree_code) (value)->common.code) == COMPLEX_CST)
      && ((value)->common.static_flag) && pedantic)
    pedwarn ("overflow in constant expression");
}
void
overflow_warning(tree value) asm("_overflow_warning");
void
overflow_warning(tree value)
{
  if ((((n64_enum_tree_code) (value)->common.code) == INTEGER_CST
       || (((n64_enum_tree_code) (value)->common.code) == COMPLEX_CST
    && ((n64_enum_tree_code) (((value)->complex.real))->common.code) == INTEGER_CST))
      && ((value)->common.public_flag))
    {
      ((value)->common.public_flag) = 0;
      warning ("integer overflow in expression");
    }
  else if ((((n64_enum_tree_code) (value)->common.code) == REAL_CST
     || (((n64_enum_tree_code) (value)->common.code) == COMPLEX_CST
  && ((n64_enum_tree_code) (((value)->complex.real))->common.code) == REAL_CST))
    && ((value)->common.public_flag))
    {
      ((value)->common.public_flag) = 0;
      warning ("floating-pointer overflow in expression");
    }
}






void
unsigned_conversion_warning(tree result, tree operand) asm("_unsigned_conversion_warning");
void
unsigned_conversion_warning(tree result, tree operand)
{
  if (((n64_enum_tree_code) (operand)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (((result)->common.type))->common.code) == INTEGER_TYPE
      && ((((result)->common.type))->common.unsigned_flag)
      && !int_fits_type_p (operand, ((result)->common.type)))
    {
      if (!int_fits_type_p (operand, signed_type (((result)->common.type))))

 warning ("large integer implicitly truncated to unsigned type");
      else if (warn_conversion)
 warning ("negative integer implicitly converted to unsigned type");
    }
}





tree
convert_and_check(tree type, tree expr) asm("_convert_and_check");
tree
convert_and_check(tree type, tree expr)
{
  tree t = convert (type, expr);
  if (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST)
    {
      if (((t)->common.public_flag))
 {
   ((t)->common.public_flag) = 0;



   ((t)->common.static_flag) = ((expr)->common.static_flag);


   if (!(((type)->common.unsigned_flag) < ((((expr)->common.type))->common.unsigned_flag)
  && ((n64_enum_tree_code) (((expr)->common.type))->common.code) == INTEGER_TYPE
  && ((type)->type.precision) == ((((expr)->common.type))->type.precision)))


     if (pedantic
  || ((type)->common.unsigned_flag)
  || ! int_fits_type_p (expr, unsigned_type (type)))
       warning ("overflow in implicit constant conversion");
 }
      else
 unsigned_conversion_warning (t, expr);
    }
  return t;
}

void
c_expand_expr_stmt(tree expr) asm("_c_expand_expr_stmt");
void
c_expand_expr_stmt(tree expr)
{


  if ((((n64_enum_tree_code) (((expr)->common.type))->common.code) == ARRAY_TYPE && lvalue_p (expr))
      || ((n64_enum_tree_code) (((expr)->common.type))->common.code) == FUNCTION_TYPE)
    expr = default_conversion (expr);

  if (((expr)->common.type) != error_mark_node
      && ((((expr)->common.type))->type.size) == 0
      && ((n64_enum_tree_code) (((expr)->common.type))->common.code) != ARRAY_TYPE)
    error ("expression statement has incomplete type");

  expand_expr_stmt (expr);
}



tree
check_case_value(tree value) asm("_check_case_value");
tree
check_case_value(tree value)
{
  if (value == (tree) 
              ((void *)0)
                       )
    return value;


  while ((((n64_enum_tree_code) (value)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (value)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR) && (((value)->common.type) == ((((value)->exp.operands[0]))->common.type))) (value) = ((value)->exp.operands[0]);;

  if (((n64_enum_tree_code) (value)->common.code) != INTEGER_CST
      && value != error_mark_node)
    {
      error ("case label does not reduce to an integer constant");
      value = error_mark_node;
    }
  else

    value = default_conversion (value);

  constant_expression_warning (value);

  return value;
}




tree
type_for_size(unsigned int bits, int unsignedp) asm("_type_for_size");
tree
type_for_size(unsigned int bits, int unsignedp)
{
  if (bits == ((integer_type_node)->type.precision))
    return unsignedp ? unsigned_type_node : integer_type_node;

  if (bits == ((signed_char_type_node)->type.precision))
    return unsignedp ? unsigned_char_type_node : signed_char_type_node;

  if (bits == ((short_integer_type_node)->type.precision))
    return unsignedp ? short_unsigned_type_node : short_integer_type_node;

  if (bits == ((long_integer_type_node)->type.precision))
    return unsignedp ? long_unsigned_type_node : long_integer_type_node;

  if (bits == ((long_long_integer_type_node)->type.precision))
    return (unsignedp ? long_long_unsigned_type_node
     : long_long_integer_type_node);

  if (bits <= ((intQI_type_node)->type.precision))
    return unsignedp ? unsigned_intQI_type_node : intQI_type_node;

  if (bits <= ((intHI_type_node)->type.precision))
    return unsignedp ? unsigned_intHI_type_node : intHI_type_node;

  if (bits <= ((intSI_type_node)->type.precision))
    return unsignedp ? unsigned_intSI_type_node : intSI_type_node;

  if (bits <= ((intDI_type_node)->type.precision))
    return unsignedp ? unsigned_intDI_type_node : intDI_type_node;

  return 0;
}





tree
type_for_mode(n64_enum_machine_mode mode, int unsignedp) asm("_type_for_mode");
tree
type_for_mode(n64_enum_machine_mode mode, int unsignedp)
{
  if (mode == ((integer_type_node)->type.mode))
    return unsignedp ? unsigned_type_node : integer_type_node;

  if (mode == ((signed_char_type_node)->type.mode))
    return unsignedp ? unsigned_char_type_node : signed_char_type_node;

  if (mode == ((short_integer_type_node)->type.mode))
    return unsignedp ? short_unsigned_type_node : short_integer_type_node;

  if (mode == ((long_integer_type_node)->type.mode))
    return unsignedp ? long_unsigned_type_node : long_integer_type_node;

  if (mode == ((long_long_integer_type_node)->type.mode))
    return unsignedp ? long_long_unsigned_type_node : long_long_integer_type_node;

  if (mode == ((intQI_type_node)->type.mode))
    return unsignedp ? unsigned_intQI_type_node : intQI_type_node;

  if (mode == ((intHI_type_node)->type.mode))
    return unsignedp ? unsigned_intHI_type_node : intHI_type_node;

  if (mode == ((intSI_type_node)->type.mode))
    return unsignedp ? unsigned_intSI_type_node : intSI_type_node;

  if (mode == ((intDI_type_node)->type.mode))
    return unsignedp ? unsigned_intDI_type_node : intDI_type_node;

  if (mode == ((float_type_node)->type.mode))
    return float_type_node;

  if (mode == ((double_type_node)->type.mode))
    return double_type_node;

  if (mode == ((long_double_type_node)->type.mode))
    return long_double_type_node;

  if (mode == ((build_pointer_type (char_type_node))->type.mode))
    return build_pointer_type (char_type_node);

  if (mode == ((build_pointer_type (integer_type_node))->type.mode))
    return build_pointer_type (integer_type_node);

  return 0;
}




int
min_precision(tree value, int unsignedp) asm("_min_precision");
int
min_precision(tree value, int unsignedp)
{
  int log;






  if (tree_int_cst_sgn (value) < 0)
    value = fold (build1 (BIT_NOT_EXPR, ((value)->common.type), value));




  if (integer_zerop (value))
    log = 0;
  else if (((value)->int_cst.int_cst_high) != 0)
    log = 32 + floor_log2_wide ((int) (((value)->int_cst.int_cst_high)));
  else
    log = floor_log2_wide ((int) (((value)->int_cst.int_cst_low)));

  return log + 1 + ! unsignedp;
}




void
binary_op_error(n64_enum_tree_code code) asm("_binary_op_error");
void
binary_op_error(n64_enum_tree_code code)
{
  register char *opname = "unknown";

  switch (code)
    {
    case NOP_EXPR:
      error ("invalid truth-value expression");
      return;

    case PLUS_EXPR:
      opname = "+"; break;
    case MINUS_EXPR:
      opname = "-"; break;
    case MULT_EXPR:
      opname = "*"; break;
    case MAX_EXPR:
      opname = "max"; break;
    case MIN_EXPR:
      opname = "min"; break;
    case EQ_EXPR:
      opname = "=="; break;
    case NE_EXPR:
      opname = "!="; break;
    case LE_EXPR:
      opname = "<="; break;
    case GE_EXPR:
      opname = ">="; break;
    case LT_EXPR:
      opname = "<"; break;
    case GT_EXPR:
      opname = ">"; break;
    case LSHIFT_EXPR:
      opname = "<<"; break;
    case RSHIFT_EXPR:
      opname = ">>"; break;
    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
      opname = "%"; break;
    case TRUNC_DIV_EXPR:
    case FLOOR_DIV_EXPR:
      opname = "/"; break;
    case BIT_AND_EXPR:
      opname = "&"; break;
    case BIT_IOR_EXPR:
      opname = "|"; break;
    case TRUTH_ANDIF_EXPR:
      opname = "&&"; break;
    case TRUTH_ORIF_EXPR:
      opname = "||"; break;
    case BIT_XOR_EXPR:
      opname = "^"; break;
    case LROTATE_EXPR:
    case RROTATE_EXPR:
      opname = "rotate"; break;
    }
  error ("invalid operands to binary %s", opname);
}
tree
shorten_compare(tree *op0_ptr, tree *op1_ptr, tree *restype_ptr, n64_enum_tree_code *rescode_ptr) asm("_shorten_compare");
tree
shorten_compare(tree *op0_ptr, tree *op1_ptr, tree *restype_ptr, n64_enum_tree_code *rescode_ptr)
{
  register tree type;
  tree op0 = *op0_ptr;
  tree op1 = *op1_ptr;
  int unsignedp0, unsignedp1;
  int real1, real2;
  tree primop0, primop1;
  n64_enum_tree_code code = *rescode_ptr;




  primop0 = get_narrower (op0, &unsignedp0);
  primop1 = get_narrower (op1, &unsignedp1);




  if (op0 == primop0 && ((op0)->common.type) != *restype_ptr)
    unsignedp0 = ((((op0)->common.type))->common.unsigned_flag);
  if (op1 == primop1 && ((op1)->common.type) != *restype_ptr)
    unsignedp1 = ((((op1)->common.type))->common.unsigned_flag);


  real1 = ((n64_enum_tree_code) (((primop0)->common.type))->common.code) == REAL_TYPE;
  real2 = ((n64_enum_tree_code) (((primop1)->common.type))->common.code) == REAL_TYPE;





  if (((primop0)->common.constant_flag)
      && ! integer_zerop (primop1) && ! real_zerop (primop1))
    {
      register tree tem = primop0;
      register int temi = unsignedp0;
      primop0 = primop1;
      primop1 = tem;
      tem = op0;
      op0 = op1;
      op1 = tem;
      *op0_ptr = op0;
      *op1_ptr = op1;
      unsignedp0 = unsignedp1;
      unsignedp1 = temi;
      temi = real1;
      real1 = real2;
      real2 = temi;

      switch (code)
 {
 case LT_EXPR:
   code = GT_EXPR;
   break;
 case GT_EXPR:
   code = LT_EXPR;
   break;
 case LE_EXPR:
   code = GE_EXPR;
   break;
 case GE_EXPR:
   code = LE_EXPR;
   break;
 }
      *rescode_ptr = code;
    }
  if (!real1 && !real2
      && ((n64_enum_tree_code) (primop1)->common.code) == INTEGER_CST
      && ((((primop0)->common.type))->type.precision) < ((*restype_ptr)->type.precision))
    {
      int min_gt, max_gt, min_lt, max_lt;
      tree maxval, minval;

      int unsignedp = ((*restype_ptr)->common.unsigned_flag);
      tree val;

      type = signed_or_unsigned_type (unsignedp0, ((primop0)->common.type));

      maxval = ((type)->type.maxval);
      minval = ((type)->type.minval);

      if (unsignedp && !unsignedp0)
 *restype_ptr = signed_type (*restype_ptr);

      if (((primop1)->common.type) != *restype_ptr)
 primop1 = convert (*restype_ptr, primop1);
      if (type != *restype_ptr)
 {
   minval = convert (*restype_ptr, minval);
   maxval = convert (*restype_ptr, maxval);
 }

      if (unsignedp && unsignedp0)
 {
   min_gt = (((unsigned int) ((primop1)->int_cst.int_cst_high) < (unsigned int) ((minval)->int_cst.int_cst_high)) || (((unsigned int) ((primop1)->int_cst.int_cst_high) == (unsigned int ) ((minval)->int_cst.int_cst_high)) && (((unsigned int) ((primop1)->int_cst.int_cst_low) < (unsigned int) ((minval)->int_cst.int_cst_low)))));
   max_gt = (((unsigned int) ((primop1)->int_cst.int_cst_high) < (unsigned int) ((maxval)->int_cst.int_cst_high)) || (((unsigned int) ((primop1)->int_cst.int_cst_high) == (unsigned int ) ((maxval)->int_cst.int_cst_high)) && (((unsigned int) ((primop1)->int_cst.int_cst_low) < (unsigned int) ((maxval)->int_cst.int_cst_low)))));
   min_lt = (((unsigned int) ((minval)->int_cst.int_cst_high) < (unsigned int) ((primop1)->int_cst.int_cst_high)) || (((unsigned int) ((minval)->int_cst.int_cst_high) == (unsigned int ) ((primop1)->int_cst.int_cst_high)) && (((unsigned int) ((minval)->int_cst.int_cst_low) < (unsigned int) ((primop1)->int_cst.int_cst_low)))));
   max_lt = (((unsigned int) ((maxval)->int_cst.int_cst_high) < (unsigned int) ((primop1)->int_cst.int_cst_high)) || (((unsigned int) ((maxval)->int_cst.int_cst_high) == (unsigned int ) ((primop1)->int_cst.int_cst_high)) && (((unsigned int) ((maxval)->int_cst.int_cst_low) < (unsigned int) ((primop1)->int_cst.int_cst_low)))));
 }
      else
 {
   min_gt = (((primop1)->int_cst.int_cst_high) < ((minval)->int_cst.int_cst_high) || (((primop1)->int_cst.int_cst_high) == ((minval)->int_cst.int_cst_high) && ((unsigned int) ((primop1)->int_cst.int_cst_low) < (unsigned int) ((minval)->int_cst.int_cst_low))));
   max_gt = (((primop1)->int_cst.int_cst_high) < ((maxval)->int_cst.int_cst_high) || (((primop1)->int_cst.int_cst_high) == ((maxval)->int_cst.int_cst_high) && ((unsigned int) ((primop1)->int_cst.int_cst_low) < (unsigned int) ((maxval)->int_cst.int_cst_low))));
   min_lt = (((minval)->int_cst.int_cst_high) < ((primop1)->int_cst.int_cst_high) || (((minval)->int_cst.int_cst_high) == ((primop1)->int_cst.int_cst_high) && ((unsigned int) ((minval)->int_cst.int_cst_low) < (unsigned int) ((primop1)->int_cst.int_cst_low))));
   max_lt = (((maxval)->int_cst.int_cst_high) < ((primop1)->int_cst.int_cst_high) || (((maxval)->int_cst.int_cst_high) == ((primop1)->int_cst.int_cst_high) && ((unsigned int) ((maxval)->int_cst.int_cst_low) < (unsigned int) ((primop1)->int_cst.int_cst_low))));
 }

      val = 0;

      if (code == NE_EXPR)
 {
   if (max_lt || min_gt)
     val = boolean_true_node;
 }
      else if (code == EQ_EXPR)
 {
   if (max_lt || min_gt)
     val = boolean_false_node;
 }
      else if (code == LT_EXPR)
 {
   if (max_lt)
     val = boolean_true_node;
   if (!min_lt)
     val = boolean_false_node;
 }
      else if (code == GT_EXPR)
 {
   if (min_gt)
     val = boolean_true_node;
   if (!max_gt)
     val = boolean_false_node;
 }
      else if (code == LE_EXPR)
 {
   if (!max_gt)
     val = boolean_true_node;
   if (min_gt)
     val = boolean_false_node;
 }
      else if (code == GE_EXPR)
 {
   if (!min_lt)
     val = boolean_true_node;
   if (max_lt)
     val = boolean_false_node;
 }
      if (unsignedp && !unsignedp0)
 {
   if (val != 0)
     switch (code)
       {
       case LT_EXPR:
       case GE_EXPR:
  primop1 = ((type)->type.minval);
  val = 0;
  break;

       case LE_EXPR:
       case GT_EXPR:
  primop1 = ((type)->type.maxval);
  val = 0;
  break;
       }
   type = unsigned_type (type);
 }

      if (!max_gt && !unsignedp0 && ((n64_enum_tree_code) (primop0)->common.code) != INTEGER_CST)
 {


   if (val == boolean_false_node)
     warning ("comparison is always 0 due to limited range of data type");
   if (val == boolean_true_node)
     warning ("comparison is always 1 due to limited range of data type");
 }

      if (!min_lt && unsignedp0 && ((n64_enum_tree_code) (primop0)->common.code) != INTEGER_CST)
 {

   if (val == boolean_false_node)
     warning ("comparison is always 0 due to limited range of data type");
   if (val == boolean_true_node)
     warning ("comparison is always 1 due to limited range of data type");
 }

      if (val != 0)
 {

   if (((primop0)->common.side_effects_flag))
     return build (COMPOUND_EXPR, ((val)->common.type), primop0, val);
   return val;
 }




    }
  else if (real1 && real2
    && (((((primop0)->common.type))->type.precision)
        == ((((primop1)->common.type))->type.precision)))
    type = ((primop0)->common.type);
  else if (unsignedp0 == unsignedp1 && real1 == real2
    && ((((primop0)->common.type))->type.precision) < ((*restype_ptr)->type.precision)
    && ((((primop1)->common.type))->type.precision) < ((*restype_ptr)->type.precision))
    {
      type = common_type (((primop0)->common.type), ((primop1)->common.type));
      type = signed_or_unsigned_type (unsignedp0
          || ((*restype_ptr)->common.unsigned_flag),
          type);


      primop0 = convert (signed_or_unsigned_type (unsignedp0, ((primop0)->common.type)),
    primop0);
      primop1 = convert (signed_or_unsigned_type (unsignedp1, ((primop1)->common.type)),
    primop1);
    }
  else
    {


      type = *restype_ptr;
      primop0 = op0;
      primop1 = op1;

      if (!real1 && !real2 && integer_zerop (primop1)
   && ((*restype_ptr)->common.unsigned_flag))
 {
   tree value = 0;
   switch (code)
     {
     case GE_EXPR:




       if (extra_warnings
    && ! (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST
   && ! ((convert (signed_type (type), primop0))->common.public_flag)
                    ))
  warning ("unsigned value >= 0 is always 1");
       value = boolean_true_node;
       break;

     case LT_EXPR:
       if (extra_warnings
    && ! (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST
   && ! ((convert (signed_type (type), primop0))->common.public_flag)
                    ))
  warning ("unsigned value < 0 is always 0");
       value = boolean_false_node;
     }

   if (value != 0)
     {

       if (((primop0)->common.side_effects_flag))
  return build (COMPOUND_EXPR, ((value)->common.type),
         primop0, value);
       return value;
     }
 }
    }

  *op0_ptr = convert (type, primop0);
  *op1_ptr = convert (type, primop1);

  *restype_ptr = boolean_type_node;

  return 0;
}
tree
truthvalue_conversion(tree expr) asm("_truthvalue_conversion");
tree
truthvalue_conversion(tree expr)
{
  if (((n64_enum_tree_code) (expr)->common.code) == ERROR_MARK)
    return expr;
  switch (((n64_enum_tree_code) (expr)->common.code))
    {
    case EQ_EXPR:






    case NE_EXPR: case LE_EXPR: case GE_EXPR: case LT_EXPR: case GT_EXPR:
    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
    case TRUTH_AND_EXPR:
    case TRUTH_OR_EXPR:
    case TRUTH_XOR_EXPR:
    case TRUTH_NOT_EXPR:
      ((expr)->common.type) = boolean_type_node;
      return expr;

    case ERROR_MARK:
      return expr;

    case INTEGER_CST:
      return integer_zerop (expr) ? boolean_false_node : boolean_true_node;

    case REAL_CST:
      return real_zerop (expr) ? boolean_false_node : boolean_true_node;

    case ADDR_EXPR:
      if (((((expr)->exp.operands[0]))->common.side_effects_flag))
 return build (COMPOUND_EXPR, boolean_type_node,
        ((expr)->exp.operands[0]), boolean_true_node);
      else
 return boolean_true_node;

    case COMPLEX_EXPR:
      return build_binary_op ((((((expr)->exp.operands[1]))->common.side_effects_flag)
          ? TRUTH_OR_EXPR : TRUTH_ORIF_EXPR),
         truthvalue_conversion (((expr)->exp.operands[0])),
         truthvalue_conversion (((expr)->exp.operands[1])),
         0);

    case NEGATE_EXPR:
    case ABS_EXPR:
    case FLOAT_EXPR:
    case FFS_EXPR:

      return truthvalue_conversion (((expr)->exp.operands[0]));

    case LROTATE_EXPR:
    case RROTATE_EXPR:


      if (((((expr)->exp.operands[1]))->common.side_effects_flag))
 return build (COMPOUND_EXPR, boolean_type_node, ((expr)->exp.operands[1]),
        truthvalue_conversion (((expr)->exp.operands[0])));
      else
 return truthvalue_conversion (((expr)->exp.operands[0]));

    case COND_EXPR:

      return fold (build (COND_EXPR, boolean_type_node, ((expr)->exp.operands[0]),
     truthvalue_conversion (((expr)->exp.operands[1])),
     truthvalue_conversion (((expr)->exp.operands[2]))));

    case CONVERT_EXPR:


      if (((n64_enum_tree_code) (((expr)->common.type))->common.code) == REFERENCE_TYPE
   || ((n64_enum_tree_code) (((((expr)->exp.operands[0]))->common.type))->common.code) == REFERENCE_TYPE)
 break;

    case NOP_EXPR:

      if (((((expr)->common.type))->type.precision)
   >= ((((((expr)->exp.operands[0]))->common.type))->type.precision))
 return truthvalue_conversion (((expr)->exp.operands[0]));
      break;

    case MINUS_EXPR:


      if (1 == 1
   && ((n64_enum_tree_code) (((expr)->common.type))->common.code) == REAL_TYPE)
 break;

    case BIT_XOR_EXPR:


      if (((((expr)->exp.operands[0]))->common.type)
   == ((((expr)->exp.operands[1]))->common.type))
 return build_binary_op (NE_EXPR, ((expr)->exp.operands[0]),
    ((expr)->exp.operands[1]), 1);
      return build_binary_op (NE_EXPR, ((expr)->exp.operands[0]),
         fold (build1 (NOP_EXPR,
         ((((expr)->exp.operands[0]))->common.type),
         ((expr)->exp.operands[1]))), 1);

    case BIT_AND_EXPR:
      if (integer_onep (((expr)->exp.operands[1]))
   && ((expr)->common.type) != boolean_type_node)

 return build1 (NOP_EXPR, boolean_type_node, expr);
      break;

    case MODIFY_EXPR:
      if (warn_parentheses && ((n64_enum_tree_code) ((expr)->exp.complexity)) == MODIFY_EXPR)
 warning ("suggest parentheses around assignment used as truth value");
      break;
    }

  if (((n64_enum_tree_code) (((expr)->common.type))->common.code) == COMPLEX_TYPE)
    return (build_binary_op
     ((((expr)->common.side_effects_flag)
       ? TRUTH_OR_EXPR : TRUTH_ORIF_EXPR),
      truthvalue_conversion (build_unary_op (REALPART_EXPR, expr, 0)),
      truthvalue_conversion (build_unary_op (IMAGPART_EXPR, expr, 0)),
      0));

  return build_binary_op (NE_EXPR, expr, integer_zero_node, 1);
}
char *
get_directive_line(register FILE *finput) asm("_get_directive_line");
char *
get_directive_line(register FILE *finput)
{
  static char *directive_buffer = 
                                 ((void *)0)
                                     ;
  static unsigned buffer_length = 0;
  register char *p;
  register char *buffer_limit;
  register int looking_for = 0;
  register int char_escaped = 0;

  if (buffer_length == 0)
    {
      directive_buffer = (char *)xmalloc (128);
      buffer_length = 128;
    }

  buffer_limit = &directive_buffer[buffer_length];

  for (p = directive_buffer; ; )
    {
      int c;


      if (p >= buffer_limit)
        {
   register unsigned bytes_used = (p - directive_buffer);

   buffer_length *= 2;
   directive_buffer
     = (char *)xrealloc (directive_buffer, buffer_length);
   p = &directive_buffer[bytes_used];
   buffer_limit = &directive_buffer[buffer_length];
        }

      c = getc (finput);


      if ((c == ' ' || c == '\t') && p == directive_buffer)
 continue;


      if (c == '\n' && looking_for == 0)
 {
          ungetc (c, finput);
   c = '\0';
 }

      *p++ = c;

      if (c == 0)
 return directive_buffer;


      if (looking_for)
 {
   if (looking_for == c && !char_escaped)
     looking_for = 0;
 }
      else
        if (c == '\'' || c == '"')
   looking_for = c;



      char_escaped = (c == '\\' && ! char_escaped);
    }
}




tree
c_build_type_variant(tree type, int constp, int volatilep) asm("_c_build_type_variant");
tree
c_build_type_variant(tree type, int constp, int volatilep)
{
  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
      tree real_main_variant = ((type)->type.main_variant);

      push_obstacks (((real_main_variant)->type.obstack),
       ((real_main_variant)->type.obstack));
      type = build_array_type (c_build_type_variant (((type)->common.type),
           constp, volatilep),
          ((type)->type.values));





      if (((type)->type.obstack) != ((real_main_variant)->type.obstack))
 {
   type = copy_node (type);
   ((type)->type.pointer_to) = ((type)->type.reference_to) = 0;
 }

      ((type)->type.main_variant) = real_main_variant;
      pop_obstacks ();
    }
  return build_type_variant (type, constp, volatilep);
}

