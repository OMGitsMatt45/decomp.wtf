// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/elf.c
/* ELF executable support for BFD.
   Copyright 1993 Free Software Foundation, Inc.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_areltdata;
struct n64_tag_artdata;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct ecoff_debug_info * const, const struct ecoff_debug_swap * const, struct ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct n64_tag_elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");

typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");

static file_ptr map_program_segments (bfd *, file_ptr, Elf_Internal_Shdr *, Elf_Internal_Shdr **, bfd_size_type) asm("_map_program_segments")


                          ;
static boolean assign_file_positions_except_relocs (bfd *) asm("_assign_file_positions_except_relocs");
static boolean prep_headers (bfd *) asm("_prep_headers");
static boolean swap_out_syms (bfd *, struct bfd_strtab_hash **) asm("_swap_out_syms");




unsigned long
bfd_elf_hash(const unsigned char *name) asm("_bfd_elf_hash");
unsigned long
bfd_elf_hash(const unsigned char *name)
{
  unsigned long h = 0;
  unsigned long g;
  int ch;

  while ((ch = *name++) != '\0')
    {
      h = (h << 4) + ch;
      if ((g = (h & 0xf0000000)) != 0)
 {
   h ^= g >> 24;
   h &= ~g;
 }
    }
  return h;
}





static char *
elf_read(bfd *abfd, long int offset, unsigned int size) asm("_elf_read");
static char *
elf_read(bfd *abfd, long int offset, unsigned int size)
{
  char *buf;

  if ((buf = bfd_alloc (abfd, size)) == 
                                       ((void *)0)
                                           )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  if (bfd_seek (abfd, offset, 
                             0
                                     ) == -1)
    return 
          ((void *)0)
              ;
  if (bfd_read ((void *) buf, size, 1, abfd) != size)
    {
      if (bfd_get_error () != bfd_error_system_call)
 bfd_set_error (bfd_error_file_truncated);
      return 
            ((void *)0)
                ;
    }
  return buf;
}

boolean
bfd_elf_mkobject(bfd *abfd) asm("_bfd_elf_mkobject");
boolean
bfd_elf_mkobject(bfd *abfd)
{


  ((abfd) -> tdata.elf_obj_data) = (struct n64_tag_elf_obj_tdata *)
    bfd_zalloc (abfd, sizeof (struct n64_tag_elf_obj_tdata));
  if (((abfd) -> tdata.elf_obj_data) == 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }



  return cxx_true;
}

char *
bfd_elf_get_str_section(bfd *abfd, unsigned int shindex) asm("_bfd_elf_get_str_section");
char *
bfd_elf_get_str_section(bfd *abfd, unsigned int shindex)
{
  Elf_Internal_Shdr **i_shdrp;
  char *shstrtab = 
                  ((void *)0)
                      ;
  unsigned int offset;
  unsigned int shstrtabsize;

  i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);
  if (i_shdrp == 0 || i_shdrp[shindex] == 0)
    return 0;

  shstrtab = (char *) i_shdrp[shindex]->contents;
  if (shstrtab == 
                 ((void *)0)
                     )
    {

      offset = i_shdrp[shindex]->sh_offset;
      shstrtabsize = i_shdrp[shindex]->sh_size;
      shstrtab = elf_read (abfd, offset, shstrtabsize);
      i_shdrp[shindex]->contents = (void *) shstrtab;
    }
  return shstrtab;
}

char *
bfd_elf_string_from_elf_section(bfd *abfd, unsigned int shindex, unsigned int strindex) asm("_bfd_elf_string_from_elf_section");
char *
bfd_elf_string_from_elf_section(bfd *abfd, unsigned int shindex, unsigned int strindex)
{
  Elf_Internal_Shdr *hdr;

  if (strindex == 0)
    return "";

  hdr = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex];

  if (hdr->contents == 
                      ((void *)0)
      
     && bfd_elf_get_str_section (abfd, shindex) == 
                                                   ((void *)0)
                                                       )
    return 
          ((void *)0)
              ;

  return ((char *) hdr->contents) + strindex;
}




boolean
_bfd_elf_make_section_from_shdr(bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
boolean
_bfd_elf_make_section_from_shdr(bfd *abfd, Elf_Internal_Shdr *hdr, const char *name)
{
  asection *newsect;
  flagword flags;

  if (hdr->bfd_section != 
                         ((void *)0)
                             )
    {
      { if (!(strcmp (name, ((hdr->bfd_section)->name + 0)) == 0)) bfd_assert("elf.c",179); }
                                                         ;
      return cxx_true;
    }

  newsect = bfd_make_section_anyway (abfd, name);
  if (newsect == 
                ((void *)0)
                    )
    return cxx_false;

  newsect->filepos = hdr->sh_offset;

  if (! (((newsect)->vma = (newsect)->lma= (hdr->sh_addr)), ((newsect)->user_set_vma = (boolean)cxx_true), cxx_true)
      || ! bfd_set_section_size (abfd, newsect, hdr->sh_size)
      || ! (((newsect)->alignment_power = (bfd_log2 (hdr->sh_addralign))),cxx_true)
                                       )
    return cxx_false;

  flags = 0x000;
  if (hdr->sh_type != 8)
    flags |= 0x200;
  if ((hdr->sh_flags & (1 << 1)) != 0)
    {
      flags |= 0x001;
      if (hdr->sh_type != 8)
 flags |= 0x002;
    }
  if ((hdr->sh_flags & (1 << 0)) == 0)
    flags |= 0x010;
  if ((hdr->sh_flags & (1 << 2)) != 0)
    flags |= 0x020;
  else if ((flags & 0x002) != 0)
    flags |= 0x040;



  if (strncmp (name, ".debug", sizeof ".debug" - 1) == 0
      || strncmp (name, ".line", sizeof ".line" - 1) == 0
      || strncmp (name, ".stab", sizeof ".stab" - 1) == 0)
    flags |= 0x10000;

  if (! bfd_set_section_flags (abfd, newsect, flags))
    return cxx_false;

  if ((flags & 0x001) != 0)
    {
      Elf_Internal_Phdr *phdr;
      unsigned int i;


      phdr = ((abfd) -> tdata.elf_obj_data)->phdr;
      for (i = 0; i < (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_phnum; i++, phdr++)
 {
   if (phdr->p_type == 1
       && phdr->p_vaddr != phdr->p_paddr
       && phdr->p_vaddr <= hdr->sh_addr
       && phdr->p_vaddr + phdr->p_memsz >= hdr->sh_addr + hdr->sh_size)
     {
       newsect->lma += phdr->p_paddr - phdr->p_vaddr;
       break;
     }
 }
    }

  hdr->bfd_section = newsect;
  ((struct n64_tag_bfd_elf_section_data*)newsect->used_by_bfd)->this_hdr = *hdr;

  return cxx_true;
}
struct n64_tag_elf_internal_shdr *
bfd_elf_find_section(bfd *abfd, char *name) asm("_bfd_elf_find_section");
struct n64_tag_elf_internal_shdr *
bfd_elf_find_section(bfd *abfd, char *name)
{
  Elf_Internal_Shdr **i_shdrp;
  char *shstrtab;
  unsigned int max;
  unsigned int i;

  i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);
  if (i_shdrp != 
                ((void *)0)
                    )
    {
      shstrtab = bfd_elf_get_str_section (abfd, (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shstrndx);
      if (shstrtab != 
                     ((void *)0)
                         )
 {
   max = (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum;
   for (i = 1; i < max; i++)
     if (!strcmp (&shstrtab[i_shdrp[i]->sh_name], name))
       return i_shdrp[i];
 }
    }
  return 0;
}

extern const char *const bfd_elf_section_type_names[] = {
  "SHT_NULL", "SHT_PROGBITS", "SHT_SYMTAB", "SHT_STRTAB",
  "SHT_RELA", "SHT_HASH", "SHT_DYNAMIC", "SHT_NOTE",
  "SHT_NOBITS", "SHT_REL", "SHT_SHLIB", "SHT_DYNSYM",
};
bfd_reloc_status_type
bfd_elf_generic_reloc(bfd *abfd, arelent *reloc_entry, asymbol *symbol, void *data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_elf_generic_reloc");
bfd_reloc_status_type
bfd_elf_generic_reloc(bfd *abfd, arelent *reloc_entry, asymbol *symbol, void *data, asection *input_section, bfd *output_bfd, char **error_message)
{
  if (output_bfd != (bfd *) 
                           ((void *)0)
      
     && (symbol->flags & 0x100) == 0
      && (! reloc_entry->howto->partial_inplace
   || reloc_entry->addend == 0))
    {
      reloc_entry->address += input_section->output_offset;
      return bfd_reloc_ok;
    }

  return bfd_reloc_continue;
}


void
bfd_elf_print_symbol(bfd *ignore_abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how) asm("_bfd_elf_print_symbol");
void
bfd_elf_print_symbol(bfd *ignore_abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how)
{
  FILE *file = (FILE *) filep;
  switch (how)
    {
    case bfd_print_symbol_name:
      fprintf (file, "%s", symbol->name);
      break;
    case bfd_print_symbol_more:
      fprintf (file, "elf ");
      fprintf(file, "%08lx", symbol->value);
      fprintf (file, " %lx", (long) symbol->flags);
      break;
    case bfd_print_symbol_all:
      {
 const char *section_name;
 section_name = symbol->section ? symbol->section->name : "(*none*)";
 bfd_print_symbol_vandf ((void *) file, symbol);
 fprintf (file, " %s\t", section_name);




 fprintf(file, "%08lx", ((((symbol->section)->flags & 0x8000) != 0) ? ((elf_symbol_type *) symbol)->internal_elf_sym.st_value : ((elf_symbol_type *) symbol)->internal_elf_sym.st_size))


                                                                  ;
 fprintf (file, " %s", symbol->name);
      }
      break;
    }
}



struct n64_tag_bfd_hash_entry *
_bfd_elf_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_elf_link_hash_newfunc");
struct n64_tag_bfd_hash_entry *
_bfd_elf_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string)
{
  struct n64_tag_elf_link_hash_entry *ret = (struct n64_tag_elf_link_hash_entry *) entry;



  if (ret == (struct n64_tag_elf_link_hash_entry *) 
                                           ((void *)0)
                                               )
    ret = ((struct n64_tag_elf_link_hash_entry *)
    bfd_hash_allocate (table, sizeof (struct n64_tag_elf_link_hash_entry)));
  if (ret == (struct n64_tag_elf_link_hash_entry *) 
                                           ((void *)0)
                                               )
    {
      bfd_set_error (bfd_error_no_memory);
      return (struct n64_tag_bfd_hash_entry *) ret;
    }


  ret = ((struct n64_tag_elf_link_hash_entry *)
  _bfd_link_hash_newfunc ((struct n64_tag_bfd_hash_entry *) ret,
     table, string));
  if (ret != (struct n64_tag_elf_link_hash_entry *) 
                                           ((void *)0)
                                               )
    {

      ret->indx = -1;
      ret->size = 0;
      ret->dynindx = -1;
      ret->dynstr_index = 0;
      ret->weakdef = 
                    ((void *)0)
                        ;
      ret->got_offset = (bfd_vma) -1;
      ret->plt_offset = (bfd_vma) -1;
      ret->type = 0;
      ret->elf_link_hash_flags = 0;
    }

  return (struct n64_tag_bfd_hash_entry *) ret;
}



boolean
_bfd_elf_link_hash_table_init(struct n64_tag_elf_link_hash_table *table, bfd *abfd, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init");
boolean
_bfd_elf_link_hash_table_init(struct n64_tag_elf_link_hash_table *table, bfd *abfd, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *))
{
  table->dynamic_sections_created = cxx_false;
  table->dynobj = 
                 ((void *)0)
                     ;

  table->dynsymcount = 1;
  table->dynstr = 
                 ((void *)0)
                     ;
  table->bucketcount = 0;
  table->needed = 
                 ((void *)0)
                     ;
  return _bfd_link_hash_table_init (&table->root, abfd, newfunc);
}



struct n64_tag_bfd_link_hash_table *
_bfd_elf_link_hash_table_create(bfd *abfd) asm("__bfd_elf_link_hash_table_create");
struct n64_tag_bfd_link_hash_table *
_bfd_elf_link_hash_table_create(bfd *abfd)
{
  struct n64_tag_elf_link_hash_table *ret;

  ret = ((struct n64_tag_elf_link_hash_table *)
  bfd_alloc (abfd, sizeof (struct n64_tag_elf_link_hash_table)));
  if (ret == (struct n64_tag_elf_link_hash_table *) 
                                           ((void *)0)
                                               )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }

  if (! _bfd_elf_link_hash_table_init (ret, abfd, _bfd_elf_link_hash_newfunc))
    {
      (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (ret); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
      return 
            ((void *)0)
                ;
    }

  return &ret->root;
}






void
bfd_elf_set_dt_needed_name(bfd *abfd, const char *name) asm("_bfd_elf_set_dt_needed_name");
void
bfd_elf_set_dt_needed_name(bfd *abfd, const char *name)
{
  if (((abfd)->xvec->flavour) == bfd_target_elf_flavour)
    (((abfd) -> tdata.elf_obj_data) -> dt_needed_name) = name;
}



struct n64_tag_bfd_link_needed_list *
bfd_elf_get_needed_list(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_bfd_elf_get_needed_list");
struct n64_tag_bfd_link_needed_list *
bfd_elf_get_needed_list(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  if (info->hash->creator->flavour != bfd_target_elf_flavour)
    return 
          ((void *)0)
              ;
  return ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->needed;
}



struct bfd_strtab_hash *
_bfd_elf_stringtab_init(void) asm("__bfd_elf_stringtab_init");
struct bfd_strtab_hash *
_bfd_elf_stringtab_init(void)
{
  struct bfd_strtab_hash *ret;

  ret = _bfd_stringtab_init ();
  if (ret != 
            ((void *)0)
                )
    {
      bfd_size_type loc;

      loc = _bfd_stringtab_add (ret, "", cxx_true, cxx_false);
      { if (!(loc == 0 || loc == (bfd_size_type) -1)) bfd_assert("elf.c",498); };
      if (loc == (bfd_size_type) -1)
 {
   _bfd_stringtab_free (ret);
   ret = 
        ((void *)0)
            ;
 }
    }
  return ret;
}





boolean
bfd_section_from_shdr(bfd *abfd, unsigned int shindex) asm("_bfd_section_from_shdr");
boolean
bfd_section_from_shdr(bfd *abfd, unsigned int shindex)
{
  Elf_Internal_Shdr *hdr = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex];
  Elf_Internal_Ehdr *ehdr = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  char *name;

  name = bfd_elf_string_from_elf_section(abfd,(((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shstrndx,hdr->sh_name);

  switch (hdr->sh_type)
    {
    case 0:

      return cxx_true;

    case 1:
    case 6:
    case 8:
    case 5:
      return _bfd_elf_make_section_from_shdr (abfd, hdr, name);

    case 2:
      if ((((abfd) -> tdata.elf_obj_data) -> symtab_section) == shindex)
 return cxx_true;

      { if (!(hdr->sh_entsize == bed->s->sizeof_sym)) bfd_assert("elf.c",540); };
      { if (!((((abfd) -> tdata.elf_obj_data) -> symtab_section) == 0)) bfd_assert("elf.c",541); };
      (((abfd) -> tdata.elf_obj_data) -> symtab_section) = shindex;
      ((abfd) -> tdata.elf_obj_data)->symtab_hdr = *hdr;
      (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;
      abfd->flags |= 0x10;







      if ((hdr->sh_flags & (1 << 1)) != 0
   && (abfd->flags & 0x40) != 0
   && ! _bfd_elf_make_section_from_shdr (abfd, hdr, name))
 return cxx_false;

      return cxx_true;

    case 11:
      if ((((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) == shindex)
 return cxx_true;

      { if (!(hdr->sh_entsize == bed->s->sizeof_sym)) bfd_assert("elf.c",564); };
      { if (!((((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) == 0)) bfd_assert("elf.c",565); };
      (((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) = shindex;
      ((abfd) -> tdata.elf_obj_data)->dynsymtab_hdr = *hdr;
      (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = hdr = &((abfd) -> tdata.elf_obj_data)->dynsymtab_hdr;
      abfd->flags |= 0x10;



      return _bfd_elf_make_section_from_shdr (abfd, hdr, name);

    case 3:
      if (hdr->bfd_section != 
                             ((void *)0)
                                 )
 return cxx_true;
      if (ehdr->e_shstrndx == shindex)
 {
   ((abfd) -> tdata.elf_obj_data)->shstrtab_hdr = *hdr;
   (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = &((abfd) -> tdata.elf_obj_data)->shstrtab_hdr;
   return cxx_true;
 }
      {
 unsigned int i;

 for (i = 1; i < ehdr->e_shnum; i++)
   {
     Elf_Internal_Shdr *hdr2 = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[i];
     if (hdr2->sh_link == shindex)
       {
  if (! bfd_section_from_shdr (abfd, i))
    return cxx_false;
  if ((((abfd) -> tdata.elf_obj_data) -> symtab_section) == i)
    {
      ((abfd) -> tdata.elf_obj_data)->strtab_hdr = *hdr;
      (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] =
        &((abfd) -> tdata.elf_obj_data)->strtab_hdr;
      return cxx_true;
    }
  if ((((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) == i)
    {
      ((abfd) -> tdata.elf_obj_data)->dynstrtab_hdr = *hdr;
      (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = hdr =
        &((abfd) -> tdata.elf_obj_data)->dynstrtab_hdr;


      break;
    }
       }
   }
      }

      return _bfd_elf_make_section_from_shdr (abfd, hdr, name);

    case 9:
    case 4:

      {
 asection *target_sect;
 Elf_Internal_Shdr *hdr2;
 int use_rela_p = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->use_rela_p;
 if ((((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[hdr->sh_link]->sh_type != 2
     && (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[hdr->sh_link]->sh_type != 11)
   {
     int scan;
     int found;

     found = 0;
     for (scan = 1; scan < ehdr->e_shnum; scan++)
       {
  if ((((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[scan]->sh_type == 2
      || (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[scan]->sh_type == 11)
    {
      if (found != 0)
        {
   found = 0;
   break;
        }
      found = scan;
    }
       }
     if (found != 0)
       hdr->sh_link = found;
   }


 if ((((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[hdr->sh_link]->sh_type == 2
     && ! bfd_section_from_shdr (abfd, hdr->sh_link))
   return cxx_false;





 if (hdr->sh_link != (((abfd) -> tdata.elf_obj_data) -> symtab_section))
   return _bfd_elf_make_section_from_shdr (abfd, hdr, name);
 { if (!(use_rela_p ? (hdr->sh_type == 4 && hdr->sh_entsize == bed->s->sizeof_rela) : (hdr->sh_type == 9 && hdr->sh_entsize == bed->s->sizeof_rel))) bfd_assert("elf.c",686); }



                                                   ;

 if (! bfd_section_from_shdr (abfd, hdr->sh_info))
   return cxx_false;
 target_sect = bfd_section_from_elf_index (abfd, hdr->sh_info);
 if (target_sect == 
                   ((void *)0)
                       )
   return cxx_false;

 hdr2 = &((struct n64_tag_bfd_elf_section_data*)target_sect->used_by_bfd)->rel_hdr;
 *hdr2 = *hdr;
 (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = hdr2;
 target_sect->reloc_count = hdr->sh_size / hdr->sh_entsize;
 target_sect->flags |= 0x004;
 target_sect->relocation = 
                          ((void *)0)
                              ;
 target_sect->rel_filepos = hdr->sh_offset;
 abfd->flags |= 0x01;
 return cxx_true;
      }
      break;

    case 7:
      break;

    case 10:
      return cxx_true;

    default:

      {
 if (bed->elf_backend_section_from_shdr)
   (*bed->elf_backend_section_from_shdr) (abfd, hdr, name);
      }
      break;
    }

  return cxx_true;
}




asection *
bfd_section_from_elf_index(bfd *abfd, unsigned int index) asm("_bfd_section_from_elf_index");
asection *
bfd_section_from_elf_index(bfd *abfd, unsigned int index)
{
  { if (!(index > 0 && index < 0xFF00)) bfd_assert("elf.c",736); };
  if (index >= (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum)
    return 
          ((void *)0)
              ;
  return (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[index]->bfd_section;
}

boolean
_bfd_elf_new_section_hook(bfd *abfd, asection *sec) asm("__bfd_elf_new_section_hook");
boolean
_bfd_elf_new_section_hook(bfd *abfd, asection *sec)
{
  struct n64_tag_bfd_elf_section_data *sdata;

  sdata = (struct n64_tag_bfd_elf_section_data *) bfd_alloc (abfd, sizeof (*sdata));
  if (!sdata)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  sec->used_by_bfd = (void *) sdata;
  memset (sdata, 0, sizeof (*sdata));
  return cxx_true;
}
boolean
bfd_section_from_phdr(bfd *abfd, Elf_Internal_Phdr *hdr, int index) asm("_bfd_section_from_phdr");
boolean
bfd_section_from_phdr(bfd *abfd, Elf_Internal_Phdr *hdr, int index)
{
  asection *newsect;
  char *name;
  char namebuf[64];
  int split;

  split = ((hdr->p_memsz > 0) &&
    (hdr->p_filesz > 0) &&
    (hdr->p_memsz > hdr->p_filesz));
  sprintf (namebuf, split ? "segment%da" : "segment%d", index);
  name = bfd_alloc (abfd, strlen (namebuf) + 1);
  if (!name)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  strcpy (name, namebuf);
  newsect = bfd_make_section (abfd, name);
  if (newsect == 
                ((void *)0)
                    )
    return cxx_false;
  newsect->vma = hdr->p_vaddr;
  newsect->lma = hdr->p_paddr;
  newsect->_raw_size = hdr->p_filesz;
  newsect->filepos = hdr->p_offset;
  newsect->flags |= 0x200;
  if (hdr->p_type == 1)
    {
      newsect->flags |= 0x001;
      newsect->flags |= 0x002;
      if (hdr->p_flags & (1 << 0))
 {


   newsect->flags |= 0x020;
 }
    }
  if (!(hdr->p_flags & (1 << 1)))
    {
      newsect->flags |= 0x010;
    }

  if (split)
    {
      sprintf (namebuf, "segment%db", index);
      name = bfd_alloc (abfd, strlen (namebuf) + 1);
      if (!name)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      strcpy (name, namebuf);
      newsect = bfd_make_section (abfd, name);
      if (newsect == 
                    ((void *)0)
                        )
 return cxx_false;
      newsect->vma = hdr->p_vaddr + hdr->p_filesz;
      newsect->lma = hdr->p_paddr + hdr->p_filesz;
      newsect->_raw_size = hdr->p_memsz - hdr->p_filesz;
      if (hdr->p_type == 1)
 {
   newsect->flags |= 0x001;
   if (hdr->p_flags & (1 << 0))
     newsect->flags |= 0x020;
 }
      if (!(hdr->p_flags & (1 << 1)))
 newsect->flags |= 0x010;
    }

  return cxx_true;
}




static void
elf_fake_sections(bfd *abfd, asection *asect, void *failedptrarg) asm("_elf_fake_sections");
static void
elf_fake_sections(bfd *abfd, asection *asect, void *failedptrarg)
{
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  boolean *failedptr = (boolean *) failedptrarg;
  Elf_Internal_Shdr *this_hdr;

  if (*failedptr)
    {


      return;
    }

  this_hdr = &((struct n64_tag_bfd_elf_section_data*)asect->used_by_bfd)->this_hdr;

  this_hdr->sh_name = (unsigned long) _bfd_stringtab_add ((((abfd) -> tdata.elf_obj_data) -> strtab_ptr),
         asect->name,
         cxx_true, cxx_false);
  if (this_hdr->sh_name == (unsigned long) -1)
    {
      *failedptr = cxx_true;
      return;
    }

  this_hdr->sh_flags = 0;

  if ((asect->flags & 0x001) != 0)
    this_hdr->sh_addr = asect->vma;
  else
    this_hdr->sh_addr = 0;

  this_hdr->sh_offset = 0;
  this_hdr->sh_size = asect->_raw_size;
  this_hdr->sh_link = 0;
  this_hdr->sh_addralign = 1 << asect->alignment_power;



  this_hdr->bfd_section = asect;
  this_hdr->contents = 
                      ((void *)0)
                          ;


  if (strcmp (asect->name, ".dynstr") == 0)
    this_hdr->sh_type = 3;
  else if (strcmp (asect->name, ".hash") == 0)
    {
      this_hdr->sh_type = 5;
      this_hdr->sh_entsize = bed->s->arch_size / 8;
    }
  else if (strcmp (asect->name, ".dynsym") == 0)
    {
      this_hdr->sh_type = 11;
      this_hdr->sh_entsize = bed->s->sizeof_sym;
    }
  else if (strcmp (asect->name, ".dynamic") == 0)
    {
      this_hdr->sh_type = 6;
      this_hdr->sh_entsize = bed->s->sizeof_dyn;
    }
  else if (strncmp (asect->name, ".rela", 5) == 0
    && ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->use_rela_p)
    {
      this_hdr->sh_type = 4;
      this_hdr->sh_entsize = bed->s->sizeof_rela;
    }
  else if (strncmp (asect->name, ".rel", 4) == 0
    && ! ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->use_rela_p)
    {
      this_hdr->sh_type = 9;
      this_hdr->sh_entsize = bed->s->sizeof_rel;
    }
  else if (strcmp (asect->name, ".note") == 0)
    this_hdr->sh_type = 7;
  else if (strncmp (asect->name, ".stab", 5) == 0
    && strcmp (asect->name + strlen (asect->name) - 3, "str") == 0)
    this_hdr->sh_type = 3;
  else if ((asect->flags & 0x001) != 0
    && (asect->flags & 0x002) != 0)
    this_hdr->sh_type = 1;
  else if ((asect->flags & 0x001) != 0
    && ((asect->flags & 0x002) == 0))
    this_hdr->sh_type = 8;
  else
    {

      this_hdr->sh_type = 1;
    }

  if ((asect->flags & 0x001) != 0)
    this_hdr->sh_flags |= (1 << 1);
  if ((asect->flags & 0x010) == 0)
    this_hdr->sh_flags |= (1 << 0);
  if ((asect->flags & 0x020) != 0)
    this_hdr->sh_flags |= (1 << 2);


  {
    struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);

    if (bed->elf_backend_fake_sections)
      (*bed->elf_backend_fake_sections) (abfd, this_hdr, asect);
  }



  if ((asect->flags & 0x004) != 0)
    {
      Elf_Internal_Shdr *rela_hdr;
      int use_rela_p = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->use_rela_p;
      char *name;

      rela_hdr = &((struct n64_tag_bfd_elf_section_data*)asect->used_by_bfd)->rel_hdr;
      name = bfd_alloc (abfd, sizeof ".rela" + strlen (asect->name));
      if (name == 
                 ((void *)0)
                     )
 {
   bfd_set_error (bfd_error_no_memory);
   *failedptr = cxx_true;
   return;
 }
      sprintf (name, "%s%s", use_rela_p ? ".rela" : ".rel", asect->name);
      rela_hdr->sh_name =
 (unsigned int) _bfd_stringtab_add ((((abfd) -> tdata.elf_obj_data) -> strtab_ptr), name,
        cxx_true, cxx_false);
      if (rela_hdr->sh_name == (unsigned int) -1)
 {
   *failedptr = cxx_true;
   return;
 }
      rela_hdr->sh_type = use_rela_p ? 4 : 9;
      rela_hdr->sh_entsize = (use_rela_p
         ? bed->s->sizeof_rela
         : bed->s->sizeof_rel);
      rela_hdr->sh_addralign = bed->s->file_align;
      rela_hdr->sh_flags = 0;
      rela_hdr->sh_addr = 0;
      rela_hdr->sh_size = 0;
      rela_hdr->sh_offset = 0;
    }
}





static boolean
assign_section_numbers(bfd *abfd) asm("_assign_section_numbers");
static boolean
assign_section_numbers(bfd *abfd)
{
  struct n64_tag_elf_obj_tdata *t = ((abfd) -> tdata.elf_obj_data);
  asection *sec;
  unsigned int section_number;
  Elf_Internal_Shdr **i_shdrp;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);

  section_number = 1;

  for (sec = abfd->sections; sec; sec = sec->next)
    {
      struct n64_tag_bfd_elf_section_data *d = ((struct n64_tag_bfd_elf_section_data*)sec->used_by_bfd);

      d->this_idx = section_number++;
      if ((sec->flags & 0x004) == 0)
 d->rel_idx = 0;
      else
 d->rel_idx = section_number++;
    }

  t->shstrtab_section = section_number++;
  (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shstrndx = t->shstrtab_section;
  t->shstrtab_hdr.sh_size = _bfd_stringtab_size ((((abfd) -> tdata.elf_obj_data) -> strtab_ptr));

  if (abfd->symcount > 0)
    {
      t->symtab_section = section_number++;
      t->strtab_section = section_number++;
    }

  (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum = section_number;



  i_shdrp = ((Elf_Internal_Shdr **)
      bfd_alloc (abfd, section_number * sizeof (Elf_Internal_Shdr *)));
  if (i_shdrp == 
                ((void *)0)
                    )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  i_shdrp[0] = ((Elf_Internal_Shdr *)
  bfd_alloc (abfd, sizeof (Elf_Internal_Shdr)));
  if (i_shdrp[0] == 
                   ((void *)0)
                       )
    {
      (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (i_shdrp); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  memset (i_shdrp[0], 0, sizeof (Elf_Internal_Shdr));

  (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr) = i_shdrp;

  i_shdrp[t->shstrtab_section] = &t->shstrtab_hdr;
  if (abfd->symcount > 0)
    {
      i_shdrp[t->symtab_section] = &t->symtab_hdr;
      i_shdrp[t->strtab_section] = &t->strtab_hdr;
      t->symtab_hdr.sh_link = t->strtab_section;
    }
  for (sec = abfd->sections; sec; sec = sec->next)
    {
      struct n64_tag_bfd_elf_section_data *d = ((struct n64_tag_bfd_elf_section_data*)sec->used_by_bfd);
      asection *s;
      const char *name;

      i_shdrp[d->this_idx] = &d->this_hdr;
      if (d->rel_idx != 0)
 i_shdrp[d->rel_idx] = &d->rel_hdr;






      if (d->rel_idx != 0)
 {
   d->rel_hdr.sh_link = t->symtab_section;
   d->rel_hdr.sh_info = d->this_idx;
 }

      switch (d->this_hdr.sh_type)
 {
 case 9:
 case 4:






   s = bfd_get_section_by_name (abfd, ".dynsym");
   if (s != 
           ((void *)0)
               )
     d->this_hdr.sh_link = ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_idx;


   name = sec->name;
   if (d->this_hdr.sh_type == 9)
     name += 4;
   else
     name += 5;
   s = bfd_get_section_by_name (abfd, name);
   if (s != 
           ((void *)0)
               )
     d->this_hdr.sh_info = ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_idx;
   break;

 case 3:




   if (strncmp (sec->name, ".stab", sizeof ".stab" - 1) == 0
       && strcmp (sec->name + strlen (sec->name) - 3, "str") == 0)
     {
       size_t len;
       char *alc;

       len = strlen (sec->name);
       alc = (char *) malloc (len - 2);
       if (alc == 
                 ((void *)0)
                     )
  {
    bfd_set_error (bfd_error_no_memory);
    return cxx_false;
  }
       strncpy (alc, sec->name, len - 3);
       alc[len - 3] = '\0';
       s = bfd_get_section_by_name (abfd, alc);
       free (alc);
       if (s != 
               ((void *)0)
                   )
  {
    ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_hdr.sh_link = d->this_idx;


    ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_hdr.sh_entsize =
      4 + 2 * (bed->s->arch_size / 8);
  }
     }
   break;

 case 6:
 case 11:


   s = bfd_get_section_by_name (abfd, ".dynstr");
   if (s != 
           ((void *)0)
               )
     d->this_hdr.sh_link = ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_idx;
   break;

 case 5:


   s = bfd_get_section_by_name (abfd, ".dynsym");
   if (s != 
           ((void *)0)
               )
     d->this_hdr.sh_link = ((struct n64_tag_bfd_elf_section_data*)s->used_by_bfd)->this_idx;
   break;
 }
    }

  return cxx_true;
}




static  int
sym_is_global(bfd *abfd, asymbol *sym) asm("_sym_is_global");
static  int
sym_is_global(bfd *abfd, asymbol *sym)
{

  if (((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->elf_backend_sym_is_global)
    return ((*((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->elf_backend_sym_is_global)
     (abfd, sym));

  return ((sym->flags & (0x02 | 0x80)) != 0
   || ((((sym)->section)) == ((asection *) &bfd_und_section))
   || (((((sym)->section))->flags & 0x8000) != 0));
}

static boolean
elf_map_symbols(bfd *abfd) asm("_elf_map_symbols");
static boolean
elf_map_symbols(bfd *abfd)
{
  int symcount = ((abfd)->symcount);
  asymbol **syms = ((abfd)->outsymbols);
  asymbol **sect_syms;
  int num_locals = 0;
  int num_globals = 0;
  int num_locals2 = 0;
  int num_globals2 = 0;
  int max_index = 0;
  int num_sections = 0;
  int idx;
  asection *asect;
  asymbol **new_syms;
  for (asect = abfd->sections; asect; asect = asect->next)
    {
      if (max_index < asect->index)
 max_index = asect->index;
    }

  max_index++;
  sect_syms = (asymbol **) bfd_zalloc (abfd, max_index * sizeof (asymbol *));
  if (sect_syms == 
                  ((void *)0)
                      )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  (((abfd) -> tdata.elf_obj_data) -> section_syms) = sect_syms;

  for (idx = 0; idx < symcount; idx++)
    {
      if ((syms[idx]->flags & 0x100) != 0
   && (syms[idx]->value + syms[idx]->section->vma) == 0)
 {
   asection *sec;

   sec = syms[idx]->section;
   if (sec->owner != 
                    ((void *)0)
                        )
     {
       if (sec->owner != abfd)
  {
    if (sec->output_offset != 0)
      continue;
    sec = sec->output_section;
    { if (!(sec->owner == abfd)) bfd_assert("elf.c",1245); };
  }
       sect_syms[sec->index] = syms[idx];
     }
 }
    }

  for (asect = abfd->sections; asect; asect = asect->next)
    {
      asymbol *sym;

      if (sect_syms[asect->index] != 
                                    ((void *)0)
                                        )
 continue;

      sym = ((*((abfd)->xvec->_bfd_make_empty_symbol)) (abfd));
      if (sym == 
                ((void *)0)
                    )
 return cxx_false;
      sym->the_bfd = abfd;
      sym->name = asect->name;
      sym->value = 0;

      sym->flags = 0;
      sym->section = asect;
      sect_syms[asect->index] = sym;
      num_sections++;





    }


  for (idx = 0; idx < symcount; idx++)
    {
      if (!sym_is_global (abfd, syms[idx]))
 num_locals++;
      else
 num_globals++;
    }
  for (asect = abfd->sections; asect; asect = asect->next)
    {
      if (sect_syms[asect->index] != 
                                    ((void *)0)
   
  && sect_syms[asect->index]->flags == 0)
 {
   sect_syms[asect->index]->flags = 0x100;
   if (!sym_is_global (abfd, sect_syms[asect->index]))
     num_locals++;
   else
     num_globals++;
   sect_syms[asect->index]->flags = 0;
 }
    }


  new_syms = ((asymbol **)
       bfd_alloc (abfd,
    (num_locals + num_globals) * sizeof (asymbol *)));
  if (new_syms == 
                 ((void *)0)
                     )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  for (idx = 0; idx < symcount; idx++)
    {
      asymbol *sym = syms[idx];
      int i;

      if (!sym_is_global (abfd, sym))
 i = num_locals2++;
      else
 i = num_locals + num_globals2++;
      new_syms[i] = sym;
      sym->udata.i = i + 1;
    }
  for (asect = abfd->sections; asect; asect = asect->next)
    {
      if (sect_syms[asect->index] != 
                                    ((void *)0)
   
  && sect_syms[asect->index]->flags == 0)
 {
   asymbol *sym = sect_syms[asect->index];
   int i;

   sym->flags = 0x100;
   if (!sym_is_global (abfd, sym))
     i = num_locals2++;
   else
     i = num_locals + num_globals2++;
   new_syms[i] = sym;
   sym->udata.i = i + 1;
 }
    }

  bfd_set_symtab (abfd, new_syms, num_locals + num_globals);

  (((abfd) -> tdata.elf_obj_data) -> num_locals) = num_locals;
  (((abfd) -> tdata.elf_obj_data) -> num_globals) = num_globals;
  return cxx_true;
}




static  file_ptr align_file_position (file_ptr, int) asm("_align_file_position");
static  file_ptr
align_file_position(file_ptr off, int align) asm("_align_file_position");
static  file_ptr
align_file_position(file_ptr off, int align)
{
  return (off + align - 1) & ~(align - 1);
}




 file_ptr
_bfd_elf_assign_file_position_for_section(Elf_Internal_Shdr *i_shdrp, file_ptr offset, boolean align) asm("__bfd_elf_assign_file_position_for_section");
 file_ptr
_bfd_elf_assign_file_position_for_section(Elf_Internal_Shdr *i_shdrp, file_ptr offset, boolean align)
{
  if (align)
    {
      unsigned int al;

      al = i_shdrp->sh_addralign;
      if (al > 1)
 offset = ((( (offset) + ((al) -1)) & (~((al)-1))));
    }
  i_shdrp->sh_offset = offset;
  if (i_shdrp->bfd_section != 
                             ((void *)0)
                                 )
    i_shdrp->bfd_section->filepos = offset;
  if (i_shdrp->sh_type != 8)
    offset += i_shdrp->sh_size;
  return offset;
}





boolean
_bfd_elf_compute_section_file_positions(bfd *abfd, struct n64_tag_bfd_link_info *link_info) asm("__bfd_elf_compute_section_file_positions");
boolean
_bfd_elf_compute_section_file_positions(bfd *abfd, struct n64_tag_bfd_link_info *link_info)
{
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  boolean failed;
  struct bfd_strtab_hash *strtab;
  Elf_Internal_Shdr *shstrtab_hdr;

  if (abfd->output_has_begun)
    return cxx_true;


  if (bed->elf_backend_begin_write_processing)
    (*bed->elf_backend_begin_write_processing) (abfd, link_info);

  if (! prep_headers (abfd))
    return cxx_false;

  failed = cxx_false;
  bfd_map_over_sections (abfd, elf_fake_sections, &failed);
  if (failed)
    return cxx_false;

  if (!assign_section_numbers (abfd))
    return cxx_false;


  if (link_info == 
                  ((void *)0) 
                       && abfd->symcount > 0)
    {
      if (! swap_out_syms (abfd, &strtab))
 return cxx_false;
    }

  shstrtab_hdr = &((abfd) -> tdata.elf_obj_data)->shstrtab_hdr;

  shstrtab_hdr->sh_type = 3;
  shstrtab_hdr->sh_flags = 0;
  shstrtab_hdr->sh_addr = 0;
  shstrtab_hdr->sh_size = _bfd_stringtab_size ((((abfd) -> tdata.elf_obj_data) -> strtab_ptr));
  shstrtab_hdr->sh_entsize = 0;
  shstrtab_hdr->sh_link = 0;
  shstrtab_hdr->sh_info = 0;

  shstrtab_hdr->sh_addralign = 1;

  if (!assign_file_positions_except_relocs (abfd))
    return cxx_false;

  if (link_info == 
                  ((void *)0) 
                       && abfd->symcount > 0)
    {
      file_ptr off;
      Elf_Internal_Shdr *hdr;

      off = ((abfd) -> tdata.elf_obj_data)->next_file_pos;

      hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;
      off = _bfd_elf_assign_file_position_for_section (hdr, off, cxx_true);

      hdr = &((abfd) -> tdata.elf_obj_data)->strtab_hdr;
      off = _bfd_elf_assign_file_position_for_section (hdr, off, cxx_true);

      ((abfd) -> tdata.elf_obj_data)->next_file_pos = off;



      if (bfd_seek (abfd, hdr->sh_offset, 
                                         0
                                                 ) != 0
   || ! _bfd_stringtab_emit (abfd, strtab))
 return cxx_false;
      _bfd_stringtab_free (strtab);
    }

  abfd->output_has_begun = cxx_true;

  return cxx_true;
}
static bfd_size_type
get_program_header_size(bfd *abfd, Elf_Internal_Shdr **sorted_hdrs, unsigned int count, bfd_vma maxpagesize) asm("_get_program_header_size");
static bfd_size_type
get_program_header_size(bfd *abfd, Elf_Internal_Shdr **sorted_hdrs, unsigned int count, bfd_vma maxpagesize)
{
  size_t segs;
  asection *s;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);


  if (((abfd) -> tdata.elf_obj_data)->program_header_size != 0)
    return ((abfd) -> tdata.elf_obj_data)->program_header_size;

  if (sorted_hdrs != 
                    ((void *)0)
                        )
    {
      unsigned int i;
      unsigned int last_type;
      Elf_Internal_Shdr **hdrpp;

      bfd_vma p_offset;

      bfd_vma p_vaddr;

      bfd_vma p_memsz;

      bfd_vma file_offset;
      bfd_vma next_offset;
      segs = 1;

      file_offset = p_offset = sorted_hdrs[0]->sh_addr % maxpagesize;
      p_vaddr = sorted_hdrs[0]->sh_addr;
      p_memsz = 0;
      last_type = 1;

      for (i = 0, hdrpp = sorted_hdrs; i < count; i++, hdrpp++)
 {
   Elf_Internal_Shdr *hdr;

   hdr = *hdrpp;



   if ((hdr->sh_flags & (1 << 1)) == 0)
     continue;




   file_offset += (hdr->sh_addr - file_offset) % maxpagesize;
   next_offset = file_offset;
   if (hdr->sh_type != 8)
     next_offset = file_offset + hdr->sh_size;



   if ((file_offset - (p_offset + p_memsz)
        == hdr->sh_addr - (p_vaddr + p_memsz))
       && (last_type != 8 || hdr->sh_type == 8))
     {
       bfd_size_type adjust;

       adjust = hdr->sh_addr - (p_vaddr + p_memsz);
       p_memsz += hdr->sh_size + adjust;
       file_offset = next_offset;
       last_type = hdr->sh_type;
       continue;
     }


   ++segs;


   p_vaddr = hdr->sh_addr;
   p_memsz = hdr->sh_size;
   p_offset = file_offset;
   file_offset = next_offset;

   last_type = hdr->sh_type;
 }
    }
  else
    {


      segs = 2;
    }

  s = bfd_get_section_by_name (abfd, ".interp");
  if (s != 
          ((void *)0) 
               && (s->flags & 0x002) != 0)
    {




      segs += 2;
    }

  if (bfd_get_section_by_name (abfd, ".dynamic") != 
                                                   ((void *)0)
                                                       )
    {

      ++segs;
    }


  if (bed->elf_backend_create_program_headers)
    segs = ((*bed->elf_backend_create_program_headers)
     (abfd, (Elf_Internal_Phdr *) 
                                 ((void *)0)
                                     , segs));

  ((abfd) -> tdata.elf_obj_data)->program_header_size = segs * bed->s->sizeof_phdr;
  return ((abfd) -> tdata.elf_obj_data)->program_header_size;
}







static file_ptr
map_program_segments(bfd *abfd, file_ptr off, Elf_Internal_Shdr *first, Elf_Internal_Shdr **sorted_hdrs, bfd_size_type phdr_size) asm("_map_program_segments");
static file_ptr
map_program_segments(bfd *abfd, file_ptr off, Elf_Internal_Shdr *first, Elf_Internal_Shdr **sorted_hdrs, bfd_size_type phdr_size)
{
  Elf_Internal_Phdr phdrs[10];
  unsigned int phdr_count;
  Elf_Internal_Phdr *phdr;
  int phdr_size_adjust;
  unsigned int i;
  Elf_Internal_Shdr **hdrpp;
  asection *sinterp, *sdyn;
  unsigned int last_type;
  Elf_Internal_Ehdr *i_ehdrp;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);

  { if (!((abfd->flags & (0x02 | 0x40)) != 0)) bfd_assert("elf.c",1632); };
  { if (!(phdr_size / sizeof (Elf_Internal_Phdr) <= sizeof phdrs / sizeof (phdrs[0]))) bfd_assert("elf.c",1633); }
                                           ;

  phdr_count = 0;
  phdr = phdrs;

  if (bed->want_hdr_in_seg)
    phdr_size_adjust = first->sh_offset - phdr_size;
  else
    phdr_size_adjust = 0;





  sinterp = bfd_get_section_by_name (abfd, ".interp");
  if (sinterp != 
                ((void *)0) 
                     && (sinterp->flags & 0x002) != 0)
    {
      { if (!(first != 
     ((void *)0)
     )) bfd_assert("elf.c",1651); };

      phdr->p_type = 6;

      phdr->p_offset = off;



      phdr_size_adjust = (first->sh_offset - phdr_size) - off;
      { if (!(phdr_size_adjust >= 0 && phdr_size_adjust < 128)) bfd_assert("elf.c",1660); };




      phdr->p_vaddr = first->sh_addr - (phdr_size + phdr_size_adjust);

      phdr->p_paddr = first->bfd_section->lma - (phdr_size + phdr_size_adjust);
      phdr->p_filesz = phdr_size;
      phdr->p_memsz = phdr_size;


      phdr->p_flags = (1 << 2) | (1 << 0);

      phdr->p_align = bed->s->file_align;
      { if (!((phdr->p_vaddr - phdr->p_offset) % bed->s->file_align == 0)) bfd_assert("elf.c",1675); };


      phdr_size_adjust += off;

      ++phdr_count;
      ++phdr;

      phdr->p_type = 3;
      phdr->p_offset = sinterp->filepos;
      phdr->p_vaddr = sinterp->vma;
      phdr->p_paddr = sinterp->lma;
      phdr->p_filesz = sinterp->_raw_size;
      phdr->p_memsz = sinterp->_raw_size;
      phdr->p_flags = (1 << 2);
      phdr->p_align = 1 << ((sinterp)->alignment_power + 0);

      ++phdr_count;
      ++phdr;
    }




  phdr->p_type = 0;
  last_type = 1;
  for (i = 1, hdrpp = sorted_hdrs;
       i < (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum;
       i++, hdrpp++)
    {
      Elf_Internal_Shdr *hdr;

      hdr = *hdrpp;



      if ((hdr->sh_flags & (1 << 1)) == 0)
 continue;



      if (phdr->p_type != 0
   && (hdr->sh_offset - (phdr->p_offset + phdr->p_memsz)
       == hdr->sh_addr - (phdr->p_vaddr + phdr->p_memsz))
   && (hdr->sh_addr - hdr->bfd_section->lma
       == phdr->p_vaddr - phdr->p_paddr)
   && (last_type != 8 || hdr->sh_type == 8))
 {
   bfd_size_type adjust;

   adjust = hdr->sh_addr - (phdr->p_vaddr + phdr->p_memsz);
   phdr->p_memsz += hdr->sh_size + adjust;
   if (hdr->sh_type != 8)
     phdr->p_filesz += hdr->sh_size + adjust;
   if ((hdr->sh_flags & (1 << 0)) != 0)
     phdr->p_flags |= (1 << 1);
   if ((hdr->sh_flags & (1 << 2)) != 0)
     phdr->p_flags |= (1 << 0);
   last_type = hdr->sh_type;
   continue;
 }



      if (phdr->p_type != 0)
 {
   ++phdr;
   ++phdr_count;
 }


      phdr->p_type = 1;
      phdr->p_offset = hdr->sh_offset;
      phdr->p_vaddr = hdr->sh_addr;
      phdr->p_paddr = hdr->bfd_section->lma;
      if (hdr->sh_type == 8)
 phdr->p_filesz = 0;
      else
 phdr->p_filesz = hdr->sh_size;
      phdr->p_memsz = hdr->sh_size;
      phdr->p_flags = (1 << 2);
      if ((hdr->sh_flags & (1 << 0)) != 0)
 phdr->p_flags |= (1 << 1);
      if ((hdr->sh_flags & (1 << 2)) != 0)
 phdr->p_flags |= (1 << 0);
      phdr->p_align = bed->maxpagesize;

      if (hdr == first
   && (bed->want_hdr_in_seg
       || (sinterp != 
                     ((void *)0)
    
   && (sinterp->flags & 0x002) != 0)))
 {
   phdr->p_offset -= phdr_size + phdr_size_adjust;
   phdr->p_vaddr -= phdr_size + phdr_size_adjust;
   phdr->p_paddr -= phdr_size + phdr_size_adjust;
   phdr->p_filesz += phdr_size + phdr_size_adjust;
   phdr->p_memsz += phdr_size + phdr_size_adjust;
 }

      last_type = hdr->sh_type;
    }

  if (phdr->p_type != 0)
    {
      ++phdr;
      ++phdr_count;
    }


  sdyn = bfd_get_section_by_name (abfd, ".dynamic");
  if (sdyn != 
             ((void *)0) 
                  && (sdyn->flags & 0x002) != 0)
    {
      phdr->p_type = 2;
      phdr->p_offset = sdyn->filepos;
      phdr->p_vaddr = sdyn->vma;
      phdr->p_paddr = sdyn->lma;
      phdr->p_filesz = sdyn->_raw_size;
      phdr->p_memsz = sdyn->_raw_size;
      phdr->p_flags = (1 << 2);
      if ((sdyn->flags & 0x010) == 0)
 phdr->p_flags |= (1 << 1);
      if ((sdyn->flags & 0x020) != 0)
 phdr->p_flags |= (1 << 0);
      phdr->p_align = 1 << ((sdyn)->alignment_power + 0);

      ++phdr;
      ++phdr_count;
    }


  if (bed->elf_backend_create_program_headers)
    phdr_count = (*bed->elf_backend_create_program_headers) (abfd,
            phdrs,
            phdr_count);




  if (phdr_count > phdr_size / bed->s->sizeof_phdr)
    {
      ((*_bfd_error_handler)
       ("%s: Not enough room for program headers (allocated %lu, need %u)",
 ((char *) (abfd)->filename),
 (unsigned long) (phdr_size / bed->s->sizeof_phdr),
 phdr_count));
      bfd_set_error (bfd_error_bad_value);
      return (file_ptr) -1;
    }


  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  i_ehdrp->e_phentsize = bed->s->sizeof_phdr;
  i_ehdrp->e_phoff = off;
  i_ehdrp->e_phnum = phdr_count;



  ((abfd) -> tdata.elf_obj_data)->phdr = ((Elf_Internal_Phdr *)
       bfd_alloc (abfd,
           (phdr_count
     * sizeof (Elf_Internal_Phdr))));
  if (((abfd) -> tdata.elf_obj_data)->phdr == 
                               ((void *)0) 
                                    && phdr_count != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return (file_ptr) -1;
    }
  memcpy (((abfd) -> tdata.elf_obj_data)->phdr, phdrs,
   phdr_count * sizeof (Elf_Internal_Phdr));


  if (bfd_seek (abfd, off, 
                          0
                                  ) != 0)
    return (file_ptr) -1;

  if (bed->s->write_out_phdrs (abfd, phdrs, phdr_count) != 0)
    return (file_ptr) -1;

  return off + phdr_count * bed->s->sizeof_phdr;
}
static int elf_sort_hdrs (const void *, const void *) asm("_elf_sort_hdrs");

static boolean
assign_file_positions_except_relocs(bfd *abfd) asm("_assign_file_positions_except_relocs");
static boolean
assign_file_positions_except_relocs(bfd *abfd)
{
  struct n64_tag_elf_obj_tdata * const tdata = ((abfd) -> tdata.elf_obj_data);
  Elf_Internal_Ehdr * const i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  Elf_Internal_Shdr ** const i_shdrpp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);
  file_ptr off;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);


  off = i_ehdrp->e_ehsize;

  if ((abfd->flags & (0x02 | 0x40)) == 0)
    {
      Elf_Internal_Shdr **hdrpp;
      unsigned int i;




      for (i = 1, hdrpp = i_shdrpp + 1; i < i_ehdrp->e_shnum; i++, hdrpp++)
 {
   Elf_Internal_Shdr *hdr;

   hdr = *hdrpp;
   if (hdr->sh_type == 9 || hdr->sh_type == 4)
     {
       hdr->sh_offset = -1;
       continue;
     }
   if (i == tdata->symtab_section
       || i == tdata->strtab_section)
     {
       hdr->sh_offset = -1;
       continue;
     }

   off = _bfd_elf_assign_file_position_for_section (hdr, off, cxx_true);
 }
    }
  else
    {
      file_ptr phdr_off;
      bfd_size_type phdr_size;
      bfd_vma maxpagesize;
      size_t hdrppsize;
      Elf_Internal_Shdr **sorted_hdrs;
      Elf_Internal_Shdr **hdrpp;
      unsigned int i;
      Elf_Internal_Shdr *first;
      file_ptr phdr_map;



      maxpagesize = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->maxpagesize;
      if (maxpagesize == 0)
 maxpagesize = 1;





      hdrppsize = (i_ehdrp->e_shnum - 1) * sizeof (Elf_Internal_Shdr *);
      sorted_hdrs = (Elf_Internal_Shdr **) malloc (hdrppsize);
      if (sorted_hdrs == 
                        ((void *)0)
                            )
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }

      memcpy (sorted_hdrs, i_shdrpp + 1, hdrppsize);
      qsort (sorted_hdrs, (size_t) i_ehdrp->e_shnum - 1,
      sizeof (Elf_Internal_Shdr *), elf_sort_hdrs);




      off = align_file_position (off, bed->s->file_align);
      phdr_size = get_program_header_size (abfd,
        sorted_hdrs, i_ehdrp->e_shnum - 1,
        maxpagesize);
      if (phdr_size == (bfd_size_type) -1)
 return cxx_false;


      phdr_off = off;
      off += phdr_size;
      first = 
             ((void *)0)
                 ;
      for (i = 1, hdrpp = sorted_hdrs; i < i_ehdrp->e_shnum; i++, hdrpp++)
 {
   Elf_Internal_Shdr *hdr;

   hdr = *hdrpp;
   if ((hdr->sh_flags & (1 << 1)) == 0)
     {
       if (hdr->sh_type == 9 || hdr->sh_type == 4)
  {
    hdr->sh_offset = -1;
    continue;
  }
       if (hdr == i_shdrpp[tdata->symtab_section]
    || hdr == i_shdrpp[tdata->strtab_section])
  {
    hdr->sh_offset = -1;
    continue;
  }
       off = _bfd_elf_assign_file_position_for_section (hdr, off,
              cxx_true);
     }
   else
     {
       if (first == 
                   ((void *)0)
                       )
  first = hdr;




       off += (hdr->sh_addr - off) % maxpagesize;
       off = _bfd_elf_assign_file_position_for_section (hdr, off,
              cxx_false);
     }
 }


      phdr_map = map_program_segments (abfd, phdr_off, first, sorted_hdrs,
           phdr_size);
      if (phdr_map == (file_ptr) -1)
 return cxx_false;
      { if (!((bfd_size_type) phdr_map <= (bfd_size_type) phdr_off + phdr_size)) bfd_assert("elf.c",1996); }
                                            ;

      free (sorted_hdrs);
    }


  off = align_file_position (off, bed->s->file_align);
  i_ehdrp->e_shoff = off;
  off += i_ehdrp->e_shnum * i_ehdrp->e_shentsize;

  ((abfd) -> tdata.elf_obj_data)->next_file_pos = off;

  return cxx_true;
}



static int
elf_sort_hdrs(const void *arg1, const void *arg2) asm("_elf_sort_hdrs");
static int
elf_sort_hdrs(const void *arg1, const void *arg2)
{
  int ret;
  const Elf_Internal_Shdr *hdr1 = *(const Elf_Internal_Shdr **) arg1;
  const Elf_Internal_Shdr *hdr2 = *(const Elf_Internal_Shdr **) arg2;



  if ((((hdr1)->sh_flags & (1 << 1))==0))
    if ((((hdr2)->sh_flags & (1 << 1))==0))
      return 0;
    else
      return 1;

  if ((((hdr2)->sh_flags & (1 << 1))==0))
    return -1;

  if (hdr1->sh_addr < hdr2->sh_addr)
    return -1;
  else if (hdr1->sh_addr > hdr2->sh_addr)
    return 1;




  ret = (hdr1->sh_type == 8) - (hdr2->sh_type == 8);

  if (ret != 0)
    return ret;
  if (hdr1->sh_size < hdr2->sh_size)
    return -1;
  if (hdr1->sh_size > hdr2->sh_size)
    return 1;
  return 0;
}

static boolean
prep_headers(bfd *abfd) asm("_prep_headers");
static boolean
prep_headers(bfd *abfd)
{
  Elf_Internal_Ehdr *i_ehdrp;
  Elf_Internal_Phdr *i_phdrp = 0;
  Elf_Internal_Shdr **i_shdrp;
  int count;
  struct bfd_strtab_hash *shstrtab;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);

  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);

  shstrtab = _bfd_elf_stringtab_init ();
  if (shstrtab == 
                 ((void *)0)
                     )
    return cxx_false;

  (((abfd) -> tdata.elf_obj_data) -> strtab_ptr) = shstrtab;

  i_ehdrp->e_ident[0] = 0x7F;
  i_ehdrp->e_ident[1] = 'E';
  i_ehdrp->e_ident[2] = 'L';
  i_ehdrp->e_ident[3] = 'F';

  i_ehdrp->e_ident[4] = bed->s->elfclass;
  i_ehdrp->e_ident[5] =
    abfd->xvec->byteorder_big_p ? 2 : 1;
  i_ehdrp->e_ident[6] = bed->s->ev_current;

  for (count = 7; count < 16; count++)
    i_ehdrp->e_ident[count] = 0;

  if ((abfd->flags & 0x40) != 0)
    i_ehdrp->e_type = 3;
  else if ((abfd->flags & 0x02) != 0)
    i_ehdrp->e_type = 2;
  else
    i_ehdrp->e_type = 1;

  switch (bfd_get_arch (abfd))
    {
    case bfd_arch_unknown:
      i_ehdrp->e_machine = 0;
      break;
    case bfd_arch_sparc:
      if (bed->s->arch_size == 64)
 i_ehdrp->e_machine = 11;
      else
 i_ehdrp->e_machine = 2;
      break;
    case bfd_arch_i386:
      i_ehdrp->e_machine = 3;
      break;
    case bfd_arch_m68k:
      i_ehdrp->e_machine = 4;
      break;
    case bfd_arch_m88k:
      i_ehdrp->e_machine = 5;
      break;
    case bfd_arch_i860:
      i_ehdrp->e_machine = 7;
      break;
    case bfd_arch_mips:
      i_ehdrp->e_machine = 8;
      break;
    case bfd_arch_hppa:
      i_ehdrp->e_machine = 15;
      break;
    case bfd_arch_powerpc:
      i_ehdrp->e_machine = 20;
      break;

    default:
      i_ehdrp->e_machine = 0;
    }
  i_ehdrp->e_version = bed->s->ev_current;
  i_ehdrp->e_ehsize = bed->s->sizeof_ehdr;


  i_ehdrp->e_phoff = 0;
  i_ehdrp->e_phentsize = 0;
  i_ehdrp->e_phnum = 0;


  i_ehdrp->e_entry = ((abfd)->start_address);
  i_ehdrp->e_shentsize = bed->s->sizeof_shdr;


  if (abfd->flags & 0x02)
    {
    }
  else
    {
      i_ehdrp->e_phentsize = 0;
      i_phdrp = 0;
      i_ehdrp->e_phoff = 0;
    }

  ((abfd) -> tdata.elf_obj_data)->symtab_hdr.sh_name =
    (unsigned int) _bfd_stringtab_add (shstrtab, ".symtab", cxx_true, cxx_false);
  ((abfd) -> tdata.elf_obj_data)->strtab_hdr.sh_name =
    (unsigned int) _bfd_stringtab_add (shstrtab, ".strtab", cxx_true, cxx_false);
  ((abfd) -> tdata.elf_obj_data)->shstrtab_hdr.sh_name =
    (unsigned int) _bfd_stringtab_add (shstrtab, ".shstrtab", cxx_true, cxx_false);
  if (((abfd) -> tdata.elf_obj_data)->symtab_hdr.sh_name == (unsigned int) -1
      || ((abfd) -> tdata.elf_obj_data)->symtab_hdr.sh_name == (unsigned int) -1
      || ((abfd) -> tdata.elf_obj_data)->shstrtab_hdr.sh_name == (unsigned int) -1)
    return cxx_false;

  return cxx_true;
}




void
_bfd_elf_assign_file_positions_for_relocs(bfd *abfd) asm("__bfd_elf_assign_file_positions_for_relocs");
void
_bfd_elf_assign_file_positions_for_relocs(bfd *abfd)
{
  file_ptr off;
  unsigned int i;
  Elf_Internal_Shdr **shdrpp;

  off = ((abfd) -> tdata.elf_obj_data)->next_file_pos;

  for (i = 1, shdrpp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr) + 1;
       i < (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum;
       i++, shdrpp++)
    {
      Elf_Internal_Shdr *shdrp;

      shdrp = *shdrpp;
      if ((shdrp->sh_type == 9 || shdrp->sh_type == 4)
   && shdrp->sh_offset == -1)
 off = _bfd_elf_assign_file_position_for_section (shdrp, off, cxx_true);
    }

  ((abfd) -> tdata.elf_obj_data)->next_file_pos = off;
}

boolean
_bfd_elf_write_object_contents(bfd *abfd) asm("__bfd_elf_write_object_contents");
boolean
_bfd_elf_write_object_contents(bfd *abfd)
{
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  Elf_Internal_Ehdr *i_ehdrp;
  Elf_Internal_Shdr **i_shdrp;
  boolean failed;
  unsigned int count;

  if (! abfd->output_has_begun
      && ! _bfd_elf_compute_section_file_positions (abfd,
          (struct n64_tag_bfd_link_info *) 
                                  ((void *)0)
                                      ))
    return cxx_false;

  i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);
  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);

  failed = cxx_false;
  bfd_map_over_sections (abfd, bed->s->write_relocs, &failed);
  if (failed)
    return cxx_false;
  _bfd_elf_assign_file_positions_for_relocs (abfd);


  for (count = 1; count < i_ehdrp->e_shnum; count++)
    {
      if (bed->elf_backend_section_processing)
 (*bed->elf_backend_section_processing) (abfd, i_shdrp[count]);
      if (i_shdrp[count]->contents)
 {
   if (bfd_seek (abfd, i_shdrp[count]->sh_offset, 
                                                 0
                                                         ) != 0
       || (bfd_write (i_shdrp[count]->contents, i_shdrp[count]->sh_size,
        1, abfd)
    != i_shdrp[count]->sh_size))
     return cxx_false;
 }
    }


  if (bfd_seek (abfd, ((abfd) -> tdata.elf_obj_data)->shstrtab_hdr.sh_offset, 
                                                               0
                                                                       ) != 0
      || ! _bfd_stringtab_emit (abfd, (((abfd) -> tdata.elf_obj_data) -> strtab_ptr)))
    return cxx_false;

  if (bed->elf_backend_final_write_processing)
    (*bed->elf_backend_final_write_processing) (abfd,
      ((abfd) -> tdata.elf_obj_data)->linker);

  return bed->s->write_shdrs_and_ehdr (abfd);
}


int
_bfd_elf_section_from_bfd_section(bfd *abfd, struct n64_tag_sec *asect) asm("__bfd_elf_section_from_bfd_section");
int
_bfd_elf_section_from_bfd_section(bfd *abfd, struct n64_tag_sec *asect)
{
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  Elf_Internal_Shdr **i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);
  int index;
  Elf_Internal_Shdr *hdr;
  int maxindex = (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum;

  for (index = 0; index < maxindex; index++)
    {
      hdr = i_shdrp[index];
      if (hdr->bfd_section == asect)
 return index;
    }

  if (bed->elf_backend_section_from_bfd_section)
    {
      for (index = 0; index < maxindex; index++)
 {
   int retval;

   hdr = i_shdrp[index];
   retval = index;
   if ((*bed->elf_backend_section_from_bfd_section)
       (abfd, hdr, asect, &retval))
     return retval;
 }
    }

  if (((asect) == ((asection *) &bfd_abs_section)))
    return 0xFFF1;
  if ((((asect)->flags & 0x8000) != 0))
    return 0xFFF2;
  if (((asect) == ((asection *) &bfd_und_section)))
    return 0;

  return -1;
}


 int
_bfd_elf_symbol_from_bfd_symbol(bfd *abfd, struct n64_tag_symbol_cache_entry **asym_ptr_ptr) asm("__bfd_elf_symbol_from_bfd_symbol");
 int
_bfd_elf_symbol_from_bfd_symbol(bfd *abfd, struct n64_tag_symbol_cache_entry **asym_ptr_ptr)
{
  struct n64_tag_symbol_cache_entry *asym_ptr = *asym_ptr_ptr;
  int idx;
  flagword flags = asym_ptr->flags;






  if (asym_ptr->udata.i == 0
      && (flags & 0x100)
      && asym_ptr->section)
    {
      int indx;

      if (asym_ptr->section->output_section != 
                                              ((void *)0)
                                                  )
 indx = asym_ptr->section->output_section->index;
      else
 indx = asym_ptr->section->index;
      if ((((abfd) -> tdata.elf_obj_data) -> section_syms)[indx])
 asym_ptr->udata.i = (((abfd) -> tdata.elf_obj_data) -> section_syms)[indx]->udata.i;
    }

  idx = asym_ptr->udata.i;
  { if (!(idx != 0)) bfd_assert("elf.c",2328); };
  return idx;
}




boolean
_bfd_elf_copy_private_section_data(bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("__bfd_elf_copy_private_section_data");
boolean
_bfd_elf_copy_private_section_data(bfd *ibfd, asection *isec, bfd *obfd, asection *osec)
{
  Elf_Internal_Shdr *ihdr, *ohdr;

  if (ibfd->xvec->flavour != bfd_target_elf_flavour
      || obfd->xvec->flavour != bfd_target_elf_flavour)
    return cxx_true;

  ihdr = &((struct n64_tag_bfd_elf_section_data*)isec->used_by_bfd)->this_hdr;
  ohdr = &((struct n64_tag_bfd_elf_section_data*)osec->used_by_bfd)->this_hdr;

  ohdr->sh_entsize = ihdr->sh_entsize;

  if (ihdr->sh_type == 2
      || ihdr->sh_type == 11)
    ohdr->sh_info = ihdr->sh_info;

  return cxx_true;
}
boolean
_bfd_elf_copy_private_symbol_data(bfd *ibfd, asymbol *isymarg, bfd *obfd, asymbol *osymarg) asm("__bfd_elf_copy_private_symbol_data");
boolean
_bfd_elf_copy_private_symbol_data(bfd *ibfd, asymbol *isymarg, bfd *obfd, asymbol *osymarg)
{
  elf_symbol_type *isym, *osym;

  isym = (((isymarg)->the_bfd->xvec->flavour == bfd_target_elf_flavour && (isymarg)->the_bfd->tdata.elf_obj_data != 0) ? (elf_symbol_type *) (isymarg) : 0);
  osym = (((osymarg)->the_bfd->xvec->flavour == bfd_target_elf_flavour && (osymarg)->the_bfd->tdata.elf_obj_data != 0) ? (elf_symbol_type *) (osymarg) : 0);

  if (isym != 
             ((void *)0)
      
     && osym != 
                ((void *)0)
      
     && ((isym->symbol.section) == ((asection *) &bfd_abs_section)))
    {
      unsigned int shndx;

      shndx = isym->internal_elf_sym.st_shndx;
      if (shndx == (((ibfd) -> tdata.elf_obj_data) -> symtab_section))
 shndx = (0xFF00 - 1);
      else if (shndx == (((ibfd) -> tdata.elf_obj_data) -> dynsymtab_section))
 shndx = (0xFF00 - 2);
      else if (shndx == ((ibfd) -> tdata.elf_obj_data)->strtab_section)
 shndx = (0xFF00 - 3);
      else if (shndx == ((ibfd) -> tdata.elf_obj_data)->shstrtab_section)
 shndx = (0xFF00 - 4);
      osym->internal_elf_sym.st_shndx = shndx;
    }

  return cxx_true;
}



static boolean
swap_out_syms(bfd *abfd, struct bfd_strtab_hash **sttp) asm("_swap_out_syms");
static boolean
swap_out_syms(bfd *abfd, struct bfd_strtab_hash **sttp)
{
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);

  if (!elf_map_symbols (abfd))
    return cxx_false;


  {
    int symcount = ((abfd)->symcount);
    asymbol **syms = ((abfd)->outsymbols);
    struct bfd_strtab_hash *stt;
    Elf_Internal_Shdr *symtab_hdr;
    Elf_Internal_Shdr *symstrtab_hdr;
    char *outbound_syms;
    int idx;

    stt = _bfd_elf_stringtab_init ();
    if (stt == 
              ((void *)0)
                  )
      return cxx_false;

    symtab_hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;
    symtab_hdr->sh_type = 2;
    symtab_hdr->sh_entsize = bed->s->sizeof_sym;
    symtab_hdr->sh_size = symtab_hdr->sh_entsize * (symcount + 1);
    symtab_hdr->sh_info = (((abfd) -> tdata.elf_obj_data) -> num_locals) + 1;
    symtab_hdr->sh_addralign = bed->s->file_align;

    symstrtab_hdr = &((abfd) -> tdata.elf_obj_data)->strtab_hdr;
    symstrtab_hdr->sh_type = 3;

    outbound_syms = bfd_alloc (abfd,
          (1 + symcount) * bed->s->sizeof_sym);
    if (outbound_syms == 
                        ((void *)0)
                            )
      {
 bfd_set_error (bfd_error_no_memory);
 return cxx_false;
      }
    symtab_hdr->contents = (void *) outbound_syms;


    {

      Elf_Internal_Sym sym;
      sym.st_name = 0;
      sym.st_value = 0;
      sym.st_size = 0;
      sym.st_info = 0;
      sym.st_other = 0;
      sym.st_shndx = 0;
      bed->s->swap_symbol_out (abfd, &sym, (void *) outbound_syms);
      outbound_syms += bed->s->sizeof_sym;
    }
    for (idx = 0; idx < symcount; idx++)
      {
 Elf_Internal_Sym sym;
 bfd_vma value = syms[idx]->value;
 elf_symbol_type *type_ptr;
 flagword flags = syms[idx]->flags;

 if (flags & 0x100)

   sym.st_name = 0;
 else
   {
     sym.st_name = (unsigned long) _bfd_stringtab_add (stt,
             syms[idx]->name,
             cxx_true, cxx_false);
     if (sym.st_name == (unsigned long) -1)
       return cxx_false;
   }

 type_ptr = (((syms[idx])->the_bfd->xvec->flavour == bfd_target_elf_flavour && (syms[idx])->the_bfd->tdata.elf_obj_data != 0) ? (elf_symbol_type *) (syms[idx]) : 0);

 if ((((syms[idx]->section)->flags & 0x8000) != 0))
   {



     sym.st_size = value;
     if (type_ptr == 
                    ((void *)0)
  
 || type_ptr->internal_elf_sym.st_value == 0)
       sym.st_value = value >= 16 ? 16 : (1 << bfd_log2 (value));
     else
       sym.st_value = type_ptr->internal_elf_sym.st_value;
     sym.st_shndx = _bfd_elf_section_from_bfd_section (abfd,
             syms[idx]->section);
   }
 else
   {
     asection *sec = syms[idx]->section;
     int shndx;

     if (sec->output_section)
       {
  value += sec->output_offset;
  sec = sec->output_section;
       }
     value += sec->vma;
     sym.st_value = value;
     sym.st_size = type_ptr ? type_ptr->internal_elf_sym.st_size : 0;

     if (((sec) == ((asection *) &bfd_abs_section))
  && type_ptr != 
                ((void *)0)
  
 && type_ptr->internal_elf_sym.st_shndx != 0)
       {



  shndx = type_ptr->internal_elf_sym.st_shndx;
  switch (shndx)
    {
    case (0xFF00 - 1):
      shndx = (((abfd) -> tdata.elf_obj_data) -> symtab_section);
      break;
    case (0xFF00 - 2):
      shndx = (((abfd) -> tdata.elf_obj_data) -> dynsymtab_section);
      break;
    case (0xFF00 - 3):
      shndx = ((abfd) -> tdata.elf_obj_data)->strtab_section;
      break;
    case (0xFF00 - 4):
      shndx = ((abfd) -> tdata.elf_obj_data)->shstrtab_section;
      break;
    default:
      break;
    }
       }
     else
       {
  shndx = _bfd_elf_section_from_bfd_section (abfd, sec);

  if (shndx == -1)
    {
      asection *sec2;
      sec2 = bfd_get_section_by_name (abfd, sec->name);
      { if (!(sec2 != 0)) bfd_assert("elf.c",2563); };
      shndx = _bfd_elf_section_from_bfd_section (abfd, sec2);
      { if (!(shndx != -1)) bfd_assert("elf.c",2565); };
    }
       }

     sym.st_shndx = shndx;
   }

 if ((((syms[idx]->section)->flags & 0x8000) != 0))
   sym.st_info = (((1) << 4) + ((1) & 0xF));
 else if (((syms[idx]->section) == ((asection *) &bfd_und_section)))
   sym.st_info = (((((flags & 0x80) ? 2 : 1)) << 4) + ((((flags & 0x10) ? 2 : 0)) & 0xF))




                        ;
 else if (flags & 0x100)
   sym.st_info = (((0) << 4) + ((3) & 0xF));
 else if (flags & 0x4000)
   sym.st_info = (((0) << 4) + ((4) & 0xF));
 else
   {
     int bind = 0;
     int type = 1;

     if (flags & 0x01)
       bind = 0;
     else if (flags & 0x80)
       bind = 2;
     else if (flags & 0x02)
       bind = 1;

     if (flags & 0x10)
       type = 2;

     sym.st_info = (((bind) << 4) + ((type) & 0xF));
   }

 sym.st_other = 0;
 bed->s->swap_symbol_out (abfd, &sym, (void *) outbound_syms);
 outbound_syms += bed->s->sizeof_sym;
      }

    *sttp = stt;
    symstrtab_hdr->sh_size = _bfd_stringtab_size (stt);
    symstrtab_hdr->sh_type = 3;

    symstrtab_hdr->sh_flags = 0;
    symstrtab_hdr->sh_addr = 0;
    symstrtab_hdr->sh_entsize = 0;
    symstrtab_hdr->sh_link = 0;
    symstrtab_hdr->sh_info = 0;
    symstrtab_hdr->sh_addralign = 1;
  }

  return cxx_true;
}







long
_bfd_elf_get_symtab_upper_bound(bfd *abfd) asm("__bfd_elf_get_symtab_upper_bound");
long
_bfd_elf_get_symtab_upper_bound(bfd *abfd)
{
  long symcount;
  long symtab_size;
  Elf_Internal_Shdr *hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;

  symcount = hdr->sh_size / ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->sizeof_sym;
  symtab_size = (symcount - 1 + 1) * (sizeof (asymbol *));

  return symtab_size;
}

long
_bfd_elf_get_dynamic_symtab_upper_bound(bfd *abfd) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
long
_bfd_elf_get_dynamic_symtab_upper_bound(bfd *abfd)
{
  long symcount;
  long symtab_size;
  Elf_Internal_Shdr *hdr = &((abfd) -> tdata.elf_obj_data)->dynsymtab_hdr;

  if ((((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) == 0)
    {
      bfd_set_error (bfd_error_invalid_operation);
      return -1;
    }

  symcount = hdr->sh_size / ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->sizeof_sym;
  symtab_size = (symcount - 1 + 1) * (sizeof (asymbol *));

  return symtab_size;
}

long
_bfd_elf_get_reloc_upper_bound(bfd *abfd, sec_ptr asect) asm("__bfd_elf_get_reloc_upper_bound");
long
_bfd_elf_get_reloc_upper_bound(bfd *abfd, sec_ptr asect)
{
  return (asect->reloc_count + 1) * sizeof (arelent *);
}



long
_bfd_elf_canonicalize_reloc(bfd *abfd, sec_ptr section, arelent **relptr, asymbol **symbols) asm("__bfd_elf_canonicalize_reloc");
long
_bfd_elf_canonicalize_reloc(bfd *abfd, sec_ptr section, arelent **relptr, asymbol **symbols)
{
  arelent *tblptr;
  unsigned int i;

  if (! ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->slurp_reloc_table (abfd, section, symbols))
    return -1;

  tblptr = section->relocation;
  for (i = 0; i < section->reloc_count; i++)
    *relptr++ = tblptr++;

  *relptr = 
           ((void *)0)
               ;

  return section->reloc_count;
}

long
_bfd_elf_get_symtab(bfd *abfd, asymbol **alocation) asm("__bfd_elf_get_symtab");
long
_bfd_elf_get_symtab(bfd *abfd, asymbol **alocation)
{
  long symcount = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->slurp_symbol_table (abfd, alocation, cxx_false);

  if (symcount >= 0)
    ((abfd)->symcount) = symcount;
  return symcount;
}

long
_bfd_elf_canonicalize_dynamic_symtab(bfd *abfd, asymbol **alocation) asm("__bfd_elf_canonicalize_dynamic_symtab");
long
_bfd_elf_canonicalize_dynamic_symtab(bfd *abfd, asymbol **alocation)
{
  return ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->slurp_symbol_table (abfd, alocation, cxx_true);
}

asymbol *
_bfd_elf_make_empty_symbol(bfd *abfd) asm("__bfd_elf_make_empty_symbol");
asymbol *
_bfd_elf_make_empty_symbol(bfd *abfd)
{
  elf_symbol_type *newsym;

  newsym = (elf_symbol_type *) bfd_zalloc (abfd, sizeof (elf_symbol_type));
  if (!newsym)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  else
    {
      newsym->symbol.the_bfd = abfd;
      return &newsym->symbol;
    }
}

void
_bfd_elf_get_symbol_info(bfd *ignore_abfd, asymbol *symbol, symbol_info *ret) asm("__bfd_elf_get_symbol_info");
void
_bfd_elf_get_symbol_info(bfd *ignore_abfd, asymbol *symbol, symbol_info *ret)
{
  bfd_symbol_info (symbol, ret);
}

alent *
_bfd_elf_get_lineno(bfd *ignore_abfd, asymbol *symbol) asm("__bfd_elf_get_lineno");
alent *
_bfd_elf_get_lineno(bfd *ignore_abfd, asymbol *symbol)
{
  abort ();
  return 
        ((void *)0)
            ;
}

boolean
_bfd_elf_set_arch_mach(bfd *abfd, n64_enum_bfd_architecture arch, long unsigned int machine) asm("__bfd_elf_set_arch_mach");
boolean
_bfd_elf_set_arch_mach(bfd *abfd, n64_enum_bfd_architecture arch, long unsigned int machine)
{


  if (arch != ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->arch
      && arch != bfd_arch_unknown
      && ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->arch != bfd_arch_unknown)
    return cxx_false;

  return bfd_default_set_arch_mach (abfd, arch, machine);
}




boolean
_bfd_elf_find_nearest_line(bfd *abfd, asection *section, asymbol **symbols, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr) asm("__bfd_elf_find_nearest_line");
boolean
_bfd_elf_find_nearest_line(bfd *abfd, asection *section, asymbol **symbols, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr)
{
  const char *filename;
  asymbol *func;
  asymbol **p;

  if (symbols == 
                ((void *)0)
                    )
    return cxx_false;

  filename = 
            ((void *)0)
                ;
  func = 
        ((void *)0)
            ;

  for (p = symbols; *p != 
                         ((void *)0)
                             ; p++)
    {
      elf_symbol_type *q;

      q = (elf_symbol_type *) *p;

      if (((&q->symbol)->section) != section)
 continue;

      switch (((q->internal_elf_sym.st_info) & 0xF))
 {
 default:
   break;
 case 4:
   filename = ((&q->symbol)->name);
   break;
 case 2:
   if (func == 
              ((void *)0)
       
      || q->symbol.value <= offset)
     func = (asymbol *) q;
   break;
 }
    }

  if (func == 
             ((void *)0)
                 )
    return cxx_false;

  *filename_ptr = filename;
  *functionname_ptr = ((func)->name);
  *line_ptr = 0;
  return cxx_true;
}

int
_bfd_elf_sizeof_headers(bfd *abfd, boolean reloc) asm("__bfd_elf_sizeof_headers");
int
_bfd_elf_sizeof_headers(bfd *abfd, boolean reloc)
{
  int ret;

  ret = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->s->sizeof_ehdr;
  if (! reloc)
    ret += get_program_header_size (abfd, (Elf_Internal_Shdr **) 
                                                                ((void *)0)
                                                                    , 0,
        (bfd_vma) 0);
  return ret;
}

boolean
_bfd_elf_set_section_contents(bfd *abfd, sec_ptr section, void *location, file_ptr offset, bfd_size_type count) asm("__bfd_elf_set_section_contents");
boolean
_bfd_elf_set_section_contents(bfd *abfd, sec_ptr section, void *location, file_ptr offset, bfd_size_type count)
{
  Elf_Internal_Shdr *hdr;

  if (! abfd->output_has_begun
      && ! _bfd_elf_compute_section_file_positions (abfd,
          (struct n64_tag_bfd_link_info *) 
                                  ((void *)0)
                                      ))
    return cxx_false;

  hdr = &((struct n64_tag_bfd_elf_section_data*)section->used_by_bfd)->this_hdr;

  if (bfd_seek (abfd, hdr->sh_offset + offset, 
                                              0
                                                      ) == -1)
    return cxx_false;
  if (bfd_write (location, 1, count, abfd) != count)
    return cxx_false;

  return cxx_true;
}

void
_bfd_elf_no_info_to_howto(bfd *abfd, arelent *cache_ptr, Elf_Internal_Rela *dst) asm("__bfd_elf_no_info_to_howto");
void
_bfd_elf_no_info_to_howto(bfd *abfd, arelent *cache_ptr, Elf_Internal_Rela *dst)
{
  abort ();
}

