// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/combine.c
/* Optimize by combining instructions for GNU compiler.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int init_recog_no_volatile(...) asm("_init_recog_no_volatile");
extern int note_stores(...) asm("_note_stores");
extern int side_effects_p(...) asm("_side_effects_p");
extern int reg_used_between_p(...) asm("_reg_used_between_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int volatile_refs_p(...) asm("_volatile_refs_p");
extern int volatile_insn_p(...) asm("_volatile_insn_p");
extern int reg_referenced_p(...) asm("_reg_referenced_p");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int max_reg_num(...) asm("_max_reg_num");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int check_asm_operands(...) asm("_check_asm_operands");
extern int reg_set_p(...) asm("_reg_set_p");
extern int remove_note(...) asm("_remove_note");
extern int reset_used_flags(...) asm("_reset_used_flags");
extern int simplejump_p(...) asm("_simplejump_p");
extern int obfree(...) asm("_obfree");
extern int mode_dependent_address_p(...) asm("_mode_dependent_address_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int can_conditionally_move_p(...) asm("_can_conditionally_move_p");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int rtx_cost(...) asm("_rtx_cost");
extern int comparison_dominates_p(...) asm("_comparison_dominates_p");
extern int recog(...) asm("_recog");
extern int add_clobbers(...) asm("_add_clobbers");
extern int push_operand(...) asm("_push_operand");
extern int refers_to_regno_p(...) asm("_refers_to_regno_p");
extern int dead_or_set_regno_p(...) asm("_dead_or_set_regno_p");
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_undo;
struct n64_tag_undobuf;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");








enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");

enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;







static int combine_attempts;



static int combine_merges;



static int combine_extras;



static int combine_successes;



static int total_attempts, total_merges, total_extras, total_successes;
static int *uid_cuid;
static int max_uid_cuid;
static int combine_max_regno;



static rtx *reg_last_death;



static rtx *reg_last_set;




static int mem_last_set;




static int last_call_cuid;







static rtx subst_insn;




static rtx subst_prev_insn;
static int subst_low_cuid;




static HARD_REG_SET newpat_used_regs;





static rtx added_links_insn;






static int previous_num_undos;


static int this_basic_block;
static rtx *reg_last_set_value;




static int *reg_last_set_label;




static int *reg_last_set_table_tick;




static char *reg_last_set_invalid;



static int label_tick;
static unsigned int *reg_nonzero_bits;




static n64_enum_machine_mode nonzero_bits_mode;




static char *reg_sign_bit_copies;






static int nonzero_sign_valid;






static n64_enum_machine_mode *reg_last_set_mode;
static unsigned int *reg_last_set_nonzero_bits;
static char *reg_last_set_sign_bit_copies;





struct n64_tag_undo
{
  int is_int;
  union {rtx r; int i;} old_contents;
  union {rtx *r; int *i;} where;
};
struct n64_tag_undobuf
{
  int num_undo;
  char *storage;
  struct n64_tag_undo undo[50];
  rtx other_insn;
};

static struct n64_tag_undobuf undobuf;
static int n_occurrences;

static void init_reg_last_arrays(void) asm("_init_reg_last_arrays");
static void setup_incoming_promotions(void) asm("_setup_incoming_promotions");
static void set_nonzero_bits_and_sign_copies (rtx, rtx) asm("_set_nonzero_bits_and_sign_copies");
static int can_combine_p (rtx, rtx, rtx, rtx, rtx *, rtx *) asm("_can_combine_p");
static int combinable_i3pat (rtx, rtx *, rtx, rtx, int, rtx *) asm("_combinable_i3pat");
static rtx try_combine (rtx, rtx, rtx) asm("_try_combine");
static void undo_all (void) asm("_undo_all");
static rtx *find_split_point (rtx *, rtx) asm("_find_split_point");
static rtx subst (rtx, rtx, rtx, int, int) asm("_subst");
static rtx simplify_rtx (rtx, n64_enum_machine_mode, int, int) asm("_simplify_rtx");
static rtx simplify_if_then_else (rtx) asm("_simplify_if_then_else");
static rtx simplify_set (rtx) asm("_simplify_set");
static rtx simplify_logical (rtx, int) asm("_simplify_logical");
static rtx expand_compound_operation (rtx) asm("_expand_compound_operation");
static rtx expand_field_assignment (rtx) asm("_expand_field_assignment");
static rtx make_extraction (n64_enum_machine_mode, rtx, int, rtx, int, int, int, int) asm("_make_extraction")
                          ;
static rtx extract_left_shift (rtx, int) asm("_extract_left_shift");
static rtx make_compound_operation (rtx, n64_enum_rtx_code) asm("_make_compound_operation");
static int get_pos_from_mask (unsigned int, int *) asm("_get_pos_from_mask");
static rtx force_to_mode (rtx, n64_enum_machine_mode, unsigned int, rtx, int) asm("_force_to_mode")
                                             ;
static rtx if_then_else_cond (rtx, rtx *, rtx *) asm("_if_then_else_cond");
static rtx known_cond (rtx, n64_enum_rtx_code, rtx, rtx) asm("_known_cond");
static rtx make_field_assignment (rtx) asm("_make_field_assignment");
static rtx apply_distributive_law (rtx) asm("_apply_distributive_law");
static rtx simplify_and_const_int (rtx, n64_enum_machine_mode, rtx, unsigned int) asm("_simplify_and_const_int")
                               ;
static unsigned int nonzero_bits (rtx, n64_enum_machine_mode) asm("_nonzero_bits");
static int num_sign_bit_copies (rtx, n64_enum_machine_mode) asm("_num_sign_bit_copies");
static int merge_outer_ops (n64_enum_rtx_code *, int *, n64_enum_rtx_code, int, n64_enum_machine_mode, int *) asm("_merge_outer_ops")

                                     ;
static rtx simplify_shift_const (rtx, n64_enum_rtx_code, n64_enum_machine_mode, rtx, int) asm("_simplify_shift_const")
                     ;
static int recog_for_combine (rtx *, rtx, rtx *, int *) asm("_recog_for_combine");
static rtx gen_lowpart_for_combine (n64_enum_machine_mode, rtx) asm("_gen_lowpart_for_combine");
static rtx gen_rtx_combine (n64_enum_rtx_code code, n64_enum_machine_mode mode, ...) asm("_gen_rtx_combine")
           ;
static rtx gen_binary (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_gen_binary")
                     ;
static rtx gen_unary (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx) asm("_gen_unary")
                                   ;
static n64_enum_rtx_code simplify_comparison (n64_enum_rtx_code, rtx *, rtx *) asm("_simplify_comparison");
static int reversible_comparison_p (rtx) asm("_reversible_comparison_p");
static void update_table_tick (rtx) asm("_update_table_tick");
static void record_value_for_reg (rtx, rtx, rtx) asm("_record_value_for_reg");
static void record_dead_and_set_regs_1 (rtx, rtx) asm("_record_dead_and_set_regs_1");
static void record_dead_and_set_regs (rtx) asm("_record_dead_and_set_regs");
static int get_last_value_validate (rtx *, int, int) asm("_get_last_value_validate");
static rtx get_last_value (rtx) asm("_get_last_value");
static int use_crosses_set_p (rtx, int) asm("_use_crosses_set_p");
static void reg_dead_at_p_1 (rtx, rtx) asm("_reg_dead_at_p_1");
static int reg_dead_at_p (rtx, rtx) asm("_reg_dead_at_p");
static void move_deaths (rtx, int, rtx, rtx *) asm("_move_deaths");
static int reg_bitfield_target_p (rtx, rtx) asm("_reg_bitfield_target_p");
static void distribute_notes (rtx, rtx, rtx, rtx, rtx, rtx) asm("_distribute_notes");
static void distribute_links (rtx) asm("_distribute_links");
static void mark_used_regs_combine (rtx) asm("_mark_used_regs_combine");




void
combine_instructions(rtx f, int nregs) asm("_combine_instructions");
void
combine_instructions(rtx f, int nregs)
{
  register rtx insn, next, prev;
  register int i;
  register rtx links, nextlinks;

  combine_attempts = 0;
  combine_merges = 0;
  combine_extras = 0;
  combine_successes = 0;
  undobuf.num_undo = previous_num_undos = 0;

  combine_max_regno = nregs;

  reg_nonzero_bits
    = (unsigned int *) 
                                __builtin_alloca((
                                nregs * sizeof (int)
                                ))
                                                                       ;
  reg_sign_bit_copies = (char *) 
                                __builtin_alloca((
                                nregs * sizeof (char)
                                ))
                                                              ;

  memset ((char *) reg_nonzero_bits,0,nregs * sizeof (int));
  memset (reg_sign_bit_copies,0,nregs * sizeof (char));

  reg_last_death = (rtx *) 
                          __builtin_alloca((
                          nregs * sizeof (rtx)
                          ))
                                                       ;
  reg_last_set = (rtx *) 
                        __builtin_alloca((
                        nregs * sizeof (rtx)
                        ))
                                                     ;
  reg_last_set_value = (rtx *) 
                              __builtin_alloca((
                              nregs * sizeof (rtx)
                              ))
                                                           ;
  reg_last_set_table_tick = (int *) 
                                   __builtin_alloca((
                                   nregs * sizeof (int)
                                   ))
                                                                ;
  reg_last_set_label = (int *) 
                              __builtin_alloca((
                              nregs * sizeof (int)
                              ))
                                                           ;
  reg_last_set_invalid = (char *) 
                                 __builtin_alloca((
                                 nregs * sizeof (char)
                                 ))
                                                               ;
  reg_last_set_mode
    = (n64_enum_machine_mode *) 
                           __builtin_alloca((
                           nregs * sizeof (n64_enum_machine_mode)
                           ))
                                                                      ;
  reg_last_set_nonzero_bits
    = (unsigned int *) 
                                __builtin_alloca((
                                nregs * sizeof (int)
                                ))
                                                                       ;
  reg_last_set_sign_bit_copies
    = (char *) 
              __builtin_alloca((
              nregs * sizeof (char)
              ))
                                            ;

  init_reg_last_arrays ();

  init_recog_no_volatile ();



  for (insn = f, i = 0; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->fld[0].rtint) > i)
      i = ((insn)->fld[0].rtint);

  uid_cuid = (int *) 
                    __builtin_alloca((
                    (i + 1) * sizeof (int)
                    ))
                                                   ;
  max_uid_cuid = i;

  nonzero_bits_mode = mode_for_size (32, MODE_INT, 0);




  nonzero_sign_valid = 0;
  label_tick = 1;



  subst_prev_insn = (rtx) 0;

  setup_incoming_promotions ();

  for (insn = f, i = 0; insn; insn = ((insn)->fld[2].rtx))
    {
      uid_cuid[((insn)->fld[0].rtint)] = ++i;
      subst_low_cuid = i;
      subst_insn = insn;

      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   note_stores (((insn)->fld[3].rtx), set_nonzero_bits_and_sign_copies);
   record_dead_and_set_regs (insn);
 }

      if (((insn)->code) == CODE_LABEL)
 label_tick++;
    }

  nonzero_sign_valid = 1;



  this_basic_block = -1;
  label_tick = 1;
  last_call_cuid = 0;
  mem_last_set = 0;
  init_reg_last_arrays ();
  setup_incoming_promotions ();

  for (insn = f; insn; insn = next ? next : ((insn)->fld[2].rtx))
    {
      next = 0;


      if (this_basic_block + 1 < n_basic_blocks
   && basic_block_head[this_basic_block + 1] == insn)
 this_basic_block++;

      if (((insn)->code) == CODE_LABEL)
 label_tick++;

      else if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {


   for (links = ((insn)->fld[5].rtx); links; links = ((links)->fld[1].rtx))
     if ((next = try_combine (insn, ((links)->fld[0].rtx), (rtx) 0)) != 0)
       goto retry;



   for (links = ((insn)->fld[5].rtx); links; links = ((links)->fld[1].rtx))
     for (nextlinks = ((((links)->fld[0].rtx))->fld[5].rtx); nextlinks;
   nextlinks = ((nextlinks)->fld[1].rtx))
       if ((next = try_combine (insn, ((links)->fld[0].rtx),
           ((nextlinks)->fld[0].rtx))) != 0)
  goto retry;
   for (links = ((insn)->fld[5].rtx); links; links = ((links)->fld[1].rtx))
     for (nextlinks = ((links)->fld[1].rtx); nextlinks;
   nextlinks = ((nextlinks)->fld[1].rtx))
       if ((next = try_combine (insn, ((links)->fld[0].rtx),
           ((nextlinks)->fld[0].rtx))) != 0)
  goto retry;

   if (((insn)->code) != NOTE)
     record_dead_and_set_regs (insn);

 retry:
   ;
 }
    }

  total_attempts += combine_attempts;
  total_merges += combine_merges;
  total_extras += combine_extras;
  total_successes += combine_successes;

  nonzero_sign_valid = 0;
}



static void
init_reg_last_arrays(void) asm("_init_reg_last_arrays");
static void
init_reg_last_arrays(void)
{
  int nregs = combine_max_regno;

  memset ((char *) reg_last_death,0,nregs * sizeof (rtx));
  memset ((char *) reg_last_set,0,nregs * sizeof (rtx));
  memset ((char *) reg_last_set_value,0,nregs * sizeof (rtx));
  memset ((char *) reg_last_set_table_tick,0,nregs * sizeof (int));
  memset ((char *) reg_last_set_label,0,nregs * sizeof (int));
  memset (reg_last_set_invalid,0,nregs * sizeof (char));
  memset ((char *) reg_last_set_mode,0,nregs * sizeof (n64_enum_machine_mode));
  memset ((char *) reg_last_set_nonzero_bits,0,nregs * sizeof (int));
  memset (reg_last_set_sign_bit_copies,0,nregs * sizeof (char));
}



static void
setup_incoming_promotions(void) asm("_setup_incoming_promotions");
static void
setup_incoming_promotions(void)
{
}
static void
set_nonzero_bits_and_sign_copies(rtx x, rtx set) asm("_set_nonzero_bits_and_sign_copies");
static void
set_nonzero_bits_and_sign_copies(rtx x, rtx set)
{
  int num;

  if (((x)->code) == REG
      && ((x)->fld[0].rtint) >= 68
      && reg_n_sets[((x)->fld[0].rtint)] > 1
      && reg_basic_block[((x)->fld[0].rtint)] < 0


      && ! (basic_block_live_at_start[0][((x)->fld[0].rtint) / 32]
     & ((unsigned int) 1 << (((x)->fld[0].rtint) % 32)))
      && (8 * mode_size[(int)(((x)->mode))]) <= 32)
    {
      if (((set)->code) == CLOBBER)
 {
   reg_nonzero_bits[((x)->fld[0].rtint)] = (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1));
   reg_sign_bit_copies[((x)->fld[0].rtint)] = 0;
   return;
 }



      set = expand_field_assignment (set);




      if (((set)->fld[0].rtx) == x
   || (((((set)->fld[0].rtx))->code) == SUBREG
       && ((mode_size[(int)(((((set)->fld[0].rtx))->mode))])
    > (mode_size[(int)(((((((set)->fld[0].rtx))->fld[0].rtx))->mode))]))
       && ((((set)->fld[0].rtx))->fld[0].rtx) == x))
 {
   rtx src = ((set)->fld[1].rtx);
   reg_nonzero_bits[((x)->fld[0].rtint)]
     |= nonzero_bits (src, nonzero_bits_mode);
   num = num_sign_bit_copies (((set)->fld[1].rtx), ((x)->mode));
   if (reg_sign_bit_copies[((x)->fld[0].rtint)] == 0
       || reg_sign_bit_copies[((x)->fld[0].rtint)] > num)
     reg_sign_bit_copies[((x)->fld[0].rtint)] = num;
 }
      else
 {
   reg_nonzero_bits[((x)->fld[0].rtint)] = (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1));
   reg_sign_bit_copies[((x)->fld[0].rtint)] = 0;
 }
    }
}
static int
can_combine_p(rtx insn, rtx i3, rtx pred, rtx succ, rtx *pdest, rtx *psrc) asm("_can_combine_p");
static int
can_combine_p(rtx insn, rtx i3, rtx pred, rtx succ, rtx *pdest, rtx *psrc)
{
  int i;
  rtx set = 0, src, dest;
  rtx p, link;
  int all_adjacent = (succ ? (next_active_insn (insn) == succ
         && next_active_insn (succ) == i3)
        : next_active_insn (insn) == i3);
  if (((((insn)->fld[3].rtx))->code) == SET)
    set = ((insn)->fld[3].rtx);
  else if (((((insn)->fld[3].rtx))->code) == PARALLEL
    && ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == SET)
    {
      for (i = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
 {
   rtx elt = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);

   switch (((elt)->code))
     {

     case CLOBBER:
       break;

     case SET:


       if (find_reg_note (insn, REG_UNUSED, ((elt)->fld[0].rtx))
    && ! side_effects_p (elt))
  break;



       if (set)
  return 0;

       set = elt;
       break;

     default:

       return 0;
     }
 }

      if (set == 0


   || ((((set)->fld[1].rtx))->code) == ASM_OPERANDS)
 return 0;
    }
  else
    return 0;

  if (set == 0)
    return 0;

  set = expand_field_assignment (set);
  src = ((set)->fld[1].rtx), dest = ((set)->fld[0].rtx);


  if (dest == stack_pointer_rtx

      || ((dest)->code) == ZERO_EXTRACT || ((dest)->code) == STRICT_LOW_PART


      || (rtx_equal_p (src, dest) && find_reg_note (insn, REG_EQUAL, (rtx) 0))

      || ((src)->code) == CALL

      || (((i3)->code) == CALL_INSN
   && (find_reg_fusage (i3, USE, dest)
       || (((dest)->code) == REG
    && ((dest)->fld[0].rtint) < 68
    && global_regs[((dest)->fld[0].rtint)])))

      || 0
      || (succ && 0)

      || find_reg_note (insn, REG_RETVAL, (rtx) 0)

      || (succ && ! all_adjacent
   && reg_used_between_p (dest, succ, i3))
      || (! all_adjacent
   && (((((src)->code) != MEM
  || ! find_reg_note (insn, REG_EQUIV, src))
        && use_crosses_set_p (src, (((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)])))
       || (((src)->code) == ASM_OPERANDS && ((src)->volatil))
       || ((src)->code) == UNSPEC_VOLATILE))


      || find_reg_note (i3, REG_NO_CONFLICT, dest)
      || (succ && find_reg_note (succ, REG_NO_CONFLICT, dest))





      || ((((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)]) < last_call_cuid && ! (((src)->code) == LABEL_REF || ((src)->code) == SYMBOL_REF || ((src)->code) == CONST_INT || ((src)->code) == CONST_DOUBLE || ((src)->code) == CONST || ((src)->code) == HIGH)))
    return 0;


  if (((dest)->code) == REG)
    {
      if (((src)->code) == REG
   && ((((dest)->fld[0].rtint) < 68
        && ! mips_hard_regno_mode_ok[ (int)(((dest)->mode)) ][ (((dest)->fld[0].rtint)) ])




       || (((src)->fld[0].rtint) < 68
    && (! mips_hard_regno_mode_ok[ (int)(((src)->mode)) ][ (((src)->fld[0].rtint)) ]



        ))))
 return 0;
    }
  else if (((dest)->code) != CC0)
    return 0;




  if (((((i3)->fld[3].rtx))->code) == PARALLEL)
    for (i = ((((i3)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
      if (((((((i3)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) == CLOBBER
   && (reg_overlap_mentioned_p (((((((i3)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx),
           src)
       || rtx_equal_p (((((((i3)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx), dest)))
 return 0;





  if (((src)->code) == ASM_OPERANDS || volatile_refs_p (src))
    for (p = ((insn)->fld[2].rtx); p != i3; p = ((p)->fld[2].rtx))
      if ((rtx_class[(int)(((p)->code))]) == 'i'
   && p != succ && volatile_refs_p (((p)->fld[3].rtx)))
 return 0;




  for (p = ((insn)->fld[2].rtx); p != i3; p = ((p)->fld[2].rtx))
    if ((rtx_class[(int)(((p)->code))]) == 'i'
 && p != succ && volatile_insn_p (((p)->fld[3].rtx)))
      return 0;
  *pdest = dest;
  *psrc = src;

  return 1;
}
static int
combinable_i3pat(rtx i3, rtx *loc, rtx i2dest, rtx i1dest, int i1_not_in_src, rtx *pi3dest_killed) asm("_combinable_i3pat");
static int
combinable_i3pat(rtx i3, rtx *loc, rtx i2dest, rtx i1dest, int i1_not_in_src, rtx *pi3dest_killed)
{
  rtx x = *loc;

  if (((x)->code) == SET)
    {
      rtx set = expand_field_assignment (x);
      rtx dest = ((set)->fld[0].rtx);
      rtx src = ((set)->fld[1].rtx);
      rtx inner_dest = dest, inner_src = src;

      do { rtx _new = (set); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*loc; undobuf.undo[undobuf.num_undo].old_contents.r = *loc; *loc = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *loc) undobuf.num_undo++; } } while (0);

      while (((inner_dest)->code) == STRICT_LOW_PART
      || ((inner_dest)->code) == SUBREG
      || ((inner_dest)->code) == ZERO_EXTRACT)
 inner_dest = ((inner_dest)->fld[0].rtx);
      if ((inner_dest != dest
    && (reg_overlap_mentioned_p (i2dest, inner_dest)
        || (i1dest && reg_overlap_mentioned_p (i1dest, inner_dest))))



   || (((inner_dest)->code) == REG
       && ((inner_dest)->fld[0].rtint) < 68
       && (! mips_hard_regno_mode_ok[ (int)(((inner_dest)->mode)) ][ (((inner_dest)->fld[0].rtint)) ]




    ))
   || (i1_not_in_src && reg_overlap_mentioned_p (i1dest, src)))
 return 0;






      if (pi3dest_killed && ((dest)->code) == REG
   && reg_referenced_p (dest, ((i3)->fld[3].rtx))
   && ((dest)->fld[0].rtint) != (0 + 30)




   && (((dest)->fld[0].rtint) != 0
       || ! fixed_regs [((dest)->fld[0].rtint)])

   && ((dest)->fld[0].rtint) != (0 + 29))
 {
   if (*pi3dest_killed)
     return 0;

   *pi3dest_killed = dest;
 }
    }

  else if (((x)->code) == PARALLEL)
    {
      int i;

      for (i = 0; i < ((x)->fld[0].rtvec->num_elem); i++)
 if (! combinable_i3pat (i3, &((x)->fld[0].rtvec->elem[i].rtx), i2dest, i1dest,
    i1_not_in_src, pi3dest_killed))
   return 0;
    }

  return 1;
}
static rtx
try_combine(register rtx i3, register rtx i2, register rtx i1) asm("_try_combine");
static rtx
try_combine(register rtx i3, register rtx i2, register rtx i1)
{

  rtx newpat, newi2pat = 0;

  int added_sets_1, added_sets_2;

  int total_sets;

  int i2_is_used;

  int insn_code_number, i2_code_number, other_code_number;



  rtx i3dest_killed = 0;

  rtx i2dest, i2src, i1dest = 0, i1src = 0;

  rtx i2pat;

  int i2dest_in_i2src = 0, i1dest_in_i1src = 0, i2dest_in_i1src = 0;
  int i1_feeds_i3 = 0;

  rtx new_i3_notes, new_i2_notes;

  int i3_subst_into_i2 = 0;

  int have_mult = 0;

  int i3_scratches = 0, i2_scratches = 0, other_scratches = 0;

  int maxreg;
  rtx temp;
  register rtx link;
  int i;







  if ((rtx_class[(int)(((i3)->code))]) != 'i'
      || (rtx_class[(int)(((i2)->code))]) != 'i'
      || (i1 && (rtx_class[(int)(((i1)->code))]) != 'i')
      || find_reg_note (i3, REG_LIBCALL, (rtx) 0))
    return 0;

  combine_attempts++;

  undobuf.num_undo = previous_num_undos = 0;
  undobuf.other_insn = 0;



  undobuf.storage = (char *) oballoc (0);


  do { register HARD_REG_ELT_TYPE *scan_tp_ = (newpat_used_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);



  if (i1 && (((i1)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i1)->fld[0].rtint)]) > (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]))
    temp = i1, i1 = i2, i2 = temp;

  added_links_insn = 0;
  if (i1 == 0 && ((i3)->code) == INSN && ((((i3)->fld[3].rtx))->code) == SET
      && ((((((i3)->fld[3].rtx))->fld[1].rtx))->code) == REG
      && ((((((i3)->fld[3].rtx))->fld[1].rtx))->fld[0].rtint) >= 68





      && find_reg_note (i3, REG_DEAD, ((((i3)->fld[3].rtx))->fld[1].rtx))
      && ((((i2)->fld[3].rtx))->code) == PARALLEL
      && ! side_effects_p (((((i3)->fld[3].rtx))->fld[0].rtx))




      && ((((((i3)->fld[3].rtx))->fld[0].rtx))->code) != ZERO_EXTRACT
      && ((((((i3)->fld[3].rtx))->fld[0].rtx))->code) != STRICT_LOW_PART
      && ! reg_overlap_mentioned_p (((((i3)->fld[3].rtx))->fld[1].rtx),
        ((((i3)->fld[3].rtx))->fld[0].rtx))
      && next_real_insn (i2) == i3)
    {
      rtx p2 = ((i2)->fld[3].rtx);
      for (i = 0; i < ((p2)->fld[0].rtvec->num_elem); i++)
 if (((((p2)->fld[0].rtvec->elem[i].rtx))->code) == SET
     && reg_overlap_mentioned_p (((((i3)->fld[3].rtx))->fld[0].rtx),
     ((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx)))
   break;

      if (i == ((p2)->fld[0].rtvec->num_elem))
 for (i = 0; i < ((p2)->fld[0].rtvec->num_elem); i++)
   if (((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx) == ((((i3)->fld[3].rtx))->fld[1].rtx))
     {
       combine_merges++;

       subst_insn = i3;
       subst_low_cuid = (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]);

       added_sets_2 = added_sets_1 = 0;
       i2dest = ((((i3)->fld[3].rtx))->fld[1].rtx);




       do { rtx _new = (((((i3)->fld[3].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx); ((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((((p2)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx)) undobuf.num_undo++; } } while (0)
                               ;

       newpat = p2;
       i3_subst_into_i2 = 1;
       goto validate_replacement;
     }
    }
  if (i1 == 0 && ((((i2)->fld[3].rtx))->code) == PARALLEL
      && ((((i2)->fld[3].rtx))->fld[0].rtvec->num_elem) >= 2
      && ((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->code) == SET
      && ((mode_class[(int)(((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))->mode))])
   == MODE_CC)
      && ((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) == COMPARE
      && ((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->fld[1].rtx) == const0_rtx
      && ((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[1].rtx))->code) == SET
      && ((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) == REG
      && rtx_equal_p (((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->fld[0].rtx),
        ((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[1].rtx))->fld[1].rtx)))
    {
      for (i = ((((i2)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 2; i--)
 if (((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) != CLOBBER)
   break;

      if (i == 1)
 {





   subst_prev_insn = i1
     = gen_rtx (INSN, VOIDmode, ((i2)->fld[0].rtint), 0, i2,
         ((((i2)->fld[3].rtx))->fld[0].rtvec->elem[1].rtx), -1, 0, 0);

   do { rtx _new = (((((i2)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((i2)->fld[3].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((i2)->fld[3].rtx); ((i2)->fld[3].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((i2)->fld[3].rtx)) undobuf.num_undo++; } } while (0);
   do { rtx _new = (((((i1)->fld[3].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((((((i2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((((((i2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx); ((((((i2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((((((i2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx)) undobuf.num_undo++; } } while (0)
                           ;
 }
    }



  if (! can_combine_p (i2, i3, i1, (rtx) 0, &i2dest, &i2src)
      || (i1 && ! can_combine_p (i1, i3, (rtx) 0, i2, &i1dest, &i1src)))
    {
      undo_all ();
      return 0;
    }



  i2dest_in_i2src = reg_overlap_mentioned_p (i2dest, i2src);
  i1dest_in_i1src = i1 && reg_overlap_mentioned_p (i1dest, i1src);
  i2dest_in_i1src = i1 && reg_overlap_mentioned_p (i2dest, i1src);



  i1_feeds_i3 = i1 && ! reg_overlap_mentioned_p (i1dest, i2src);


  if (! combinable_i3pat (i3, &((i3)->fld[3].rtx), i2dest, i1dest,
     i1 && i2dest_in_i1src && i1_feeds_i3,
     &i3dest_killed))
    {
      undo_all ();
      return 0;
    }




  if (((i2src)->code) == MULT
      || (i1 != 0 && ((i1src)->code) == MULT)
      || (((((i3)->fld[3].rtx))->code) == SET
   && ((((((i3)->fld[3].rtx))->fld[1].rtx))->code) == MULT))
    have_mult = 1;
  added_sets_2 = ! dead_or_set_p (i3, i2dest);

  added_sets_1
    = i1 && ! (i1_feeds_i3 ? dead_or_set_p (i3, i1dest)
        : (dead_or_set_p (i3, i1dest) || dead_or_set_p (i2, i1dest)));
  i2pat = (((((i2)->fld[3].rtx))->code) == PARALLEL
    ? gen_rtx (SET, VOIDmode, i2dest, i2src)
    : ((i2)->fld[3].rtx));

  if (added_sets_2)
    i2pat = copy_rtx (i2pat);

  combine_merges++;



  maxreg = max_reg_num ();

  subst_insn = i3;
  if (flag_expensive_optimizations)
    {



      if (i1)
 {
   subst_low_cuid = (((i1)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i1)->fld[0].rtint)]);
   i1src = subst (i1src, pc_rtx, pc_rtx, 0, 0);
 }
      else
 {
   subst_low_cuid = (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]);
   i2src = subst (i2src, pc_rtx, pc_rtx, 0, 0);
 }

      previous_num_undos = undobuf.num_undo;
    }
  if (i1 == 0 && added_sets_2 && ((((i3)->fld[3].rtx))->code) == SET
      && ((((((i3)->fld[3].rtx))->fld[1].rtx))->code) == COMPARE
      && ((((((i3)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) == const0_rtx
      && rtx_equal_p (((((((i3)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx), i2dest))
    {
      rtx *cc_use;
      n64_enum_machine_mode compare_mode;

      newpat = ((i3)->fld[3].rtx);
      do { rtx _new = (i2src); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((((newpat)->fld[1].rtx))->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((((newpat)->fld[1].rtx))->fld[0].rtx); ((((newpat)->fld[1].rtx))->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((((newpat)->fld[1].rtx))->fld[0].rtx)) undobuf.num_undo++; } } while (0);

      i2_is_used = 1;







      if (undobuf.other_insn == 0
   && (cc_use = find_single_use (((newpat)->fld[0].rtx), i3,
     &undobuf.other_insn))
   && ((compare_mode = ((mode_class[(int)(((i2src)->mode))]) != MODE_FLOAT ? SImode : ((((*cc_use)->code) == NE) ? CC_REV_FPmode : CC_FPmode))
                             )
       != ((((newpat)->fld[0].rtx))->mode)))
 {
   int regno = ((((newpat)->fld[0].rtx))->fld[0].rtint);
   rtx new_dest = gen_rtx (REG, compare_mode, regno);

   if (regno < 68
       || (reg_n_sets[regno] == 1 && ! added_sets_2
    && ! ((((newpat)->fld[0].rtx))->volatil)))
     {
       if (regno >= 68)
  do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &regno_reg_rtx[regno]; undobuf.undo[undobuf.num_undo].old_contents.r = regno_reg_rtx[regno]; regno_reg_rtx[regno] = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != regno_reg_rtx[regno]) undobuf.num_undo++; } } while (0);

       do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((newpat)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((newpat)->fld[0].rtx); ((newpat)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((newpat)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
       do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((*cc_use)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((*cc_use)->fld[0].rtx); ((*cc_use)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((*cc_use)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
       do { rtx _new = (gen_rtx_combine (COMPARE, compare_mode, i2src, const0_rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((newpat)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((newpat)->fld[1].rtx); ((newpat)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((newpat)->fld[1].rtx)) undobuf.num_undo++; } } while (0)

                             ;
     }
   else
     undobuf.other_insn = 0;
 }

    }
  else

    {
      n_occurrences = 0;





      subst_low_cuid = (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]);
      newpat = subst (((i3)->fld[3].rtx), i2dest, i2src, 0,
        ! i1_feeds_i3 && i1dest_in_i1src);
      previous_num_undos = undobuf.num_undo;


      i2_is_used = n_occurrences;
    }




  if (i1 && ((newpat)->code) != CLOBBER)
    {




      if (! combinable_i3pat ((rtx) 0, &newpat, i1dest, (rtx) 0,
         0, ((void *)0)))
 {
   undo_all ();
   return 0;
 }

      n_occurrences = 0;
      subst_low_cuid = (((i1)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i1)->fld[0].rtint)]);
      newpat = subst (newpat, i1dest, i1src, 0, 0);
      previous_num_undos = undobuf.num_undo;
    }



  if ((0 != 0
       && i2_is_used + added_sets_2 > 1)
      || (i1 != 0 && 0 != 0
   && (n_occurrences + added_sets_1 + (added_sets_2 && ! i1_feeds_i3)
       > 1))


      || max_reg_num () != maxreg

      || ((newpat)->code) == CLOBBER


      || (((newpat)->code) == SET && ((((newpat)->fld[1].rtx))->code) == MULT
   && ! have_mult))
    {
      undo_all ();
      return 0;
    }






  if (added_sets_1 || added_sets_2)
    {
      combine_extras++;

      if (((newpat)->code) == PARALLEL)
 {
   rtvec old = ((newpat)->fld[0].rtvec);
   total_sets = ((newpat)->fld[0].rtvec->num_elem) + added_sets_1 + added_sets_2;
   newpat = gen_rtx (PARALLEL, VOIDmode, rtvec_alloc (total_sets));
   memcpy ((char *) &((newpat)->fld[0].rtvec->elem[0].rtx),(char *) &old->elem[0],sizeof (old->elem[0]) * old->num_elem)
                                         ;
 }
      else
 {
   rtx old = newpat;
   total_sets = 1 + added_sets_1 + added_sets_2;
   newpat = gen_rtx (PARALLEL, VOIDmode, rtvec_alloc (total_sets));
   ((newpat)->fld[0].rtvec->elem[0].rtx) = old;
 }

     if (added_sets_1)
       ((newpat)->fld[0].rtvec->elem[--total_sets].rtx)
  = (((((i1)->fld[3].rtx))->code) == PARALLEL
     ? gen_rtx (SET, VOIDmode, i1dest, i1src) : ((i1)->fld[3].rtx));

     if (added_sets_2)
 {



   if (i1 == 0)
     ((newpat)->fld[0].rtvec->elem[--total_sets].rtx) = i2pat;
   else

     ((newpat)->fld[0].rtvec->elem[--total_sets].rtx)
       = subst (i2pat, i1dest, i1src, 0, 0);
 }
    }



 validate_replacement:


  mark_used_regs_combine (newpat);


  insn_code_number
    = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);
  if (insn_code_number < 0 && ((newpat)->code) == PARALLEL
      && ((newpat)->fld[0].rtvec->num_elem) == 2
      && ((((newpat)->fld[0].rtvec->elem[0].rtx))->code) == SET
      && ((((newpat)->fld[0].rtvec->elem[1].rtx))->code) == SET
      && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) == REG
      && find_reg_note (i3, REG_UNUSED, ((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))
      && ! side_effects_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[1].rtx))
      && asm_noperands (newpat) < 0)
    {
      newpat = ((newpat)->fld[0].rtvec->elem[0].rtx);
      insn_code_number
 = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);
    }

  else if (insn_code_number < 0 && ((newpat)->code) == PARALLEL
    && ((newpat)->fld[0].rtvec->num_elem) == 2
    && ((((newpat)->fld[0].rtvec->elem[0].rtx))->code) == SET
    && ((((newpat)->fld[0].rtvec->elem[1].rtx))->code) == SET
    && ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))->code) == REG
    && find_reg_note (i3, REG_UNUSED, ((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))
    && ! side_effects_p (((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))
    && asm_noperands (newpat) < 0)
    {
      newpat = ((newpat)->fld[0].rtvec->elem[1].rtx);
      insn_code_number
 = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);
    }







  if (i1 && insn_code_number < 0 && ((newpat)->code) == SET
      && asm_noperands (newpat) < 0)
    {
      rtx m_split, *split;
      rtx ni2dest = i2dest;





      m_split = split_insns (newpat, i3);
      if (m_split == 0 && ! reg_overlap_mentioned_p (ni2dest, newpat))
 {


   if (((((newpat)->fld[0].rtx))->mode) != ((i2dest)->mode)
       && ((((newpat)->fld[0].rtx))->mode) != VOIDmode
       && ((i2dest)->code) == REG
       && (((i2dest)->fld[0].rtint) < 68
    || (reg_n_sets[((i2dest)->fld[0].rtint)] == 1 && ! added_sets_2
        && ! ((i2dest)->volatil))))
     ni2dest = gen_rtx (REG, ((((newpat)->fld[0].rtx))->mode),
          ((i2dest)->fld[0].rtint));

   m_split = split_insns (gen_rtx (PARALLEL, VOIDmode,
       gen_rtvec (2, newpat,
           gen_rtx (CLOBBER,
             VOIDmode,
             ni2dest))),
     i3);
 }

      if (m_split && ((m_split)->code) == SEQUENCE
   && ((m_split)->fld[0].rtvec->num_elem) == 2
   && (next_real_insn (i2) == i3
       || ! use_crosses_set_p (((((m_split)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx),
          (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]))))
 {
   rtx i2set, i3set;
   rtx newi3pat = ((((m_split)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx);
   newi2pat = ((((m_split)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx);

   i3set = single_set (((m_split)->fld[0].rtvec->elem[1].rtx));
   i2set = single_set (((m_split)->fld[0].rtvec->elem[0].rtx));





   if (((i2dest)->fld[0].rtint) >= 68)
     do { rtx _new = (ni2dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &regno_reg_rtx[((i2dest)->fld[0].rtint)]; undobuf.undo[undobuf.num_undo].old_contents.r = regno_reg_rtx[((i2dest)->fld[0].rtint)]; regno_reg_rtx[((i2dest)->fld[0].rtint)] = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != regno_reg_rtx[((i2dest)->fld[0].rtint)]) undobuf.num_undo++; } } while (0);

   i2_code_number = recog_for_combine (&newi2pat, i2, &new_i2_notes,
           &i2_scratches);




   if (i2_code_number >= 0 && i2set && i3set)
     insn_code_number = recog_for_combine (&newi3pat, i3, &new_i3_notes,
        &i3_scratches);
   if (insn_code_number >= 0)
     newpat = newi3pat;




   if (insn_code_number >= 0 && ((((i3set)->fld[0].rtx))->code) == REG
       && ((((i2set)->fld[0].rtx))->code) == REG
       && ((((i3set)->fld[0].rtx))->fld[0].rtint) == ((((i2set)->fld[0].rtx))->fld[0].rtint))
     reg_n_sets[((((i2set)->fld[0].rtx))->fld[0].rtint)]++;
 }




      if (insn_code_number < 0 && (split = find_split_point (&newpat, i3)) != 0





   && (((*split)->mode) == ((i2dest)->mode)
       || ((*split)->mode) == VOIDmode
       || ((i2dest)->fld[0].rtint) < 68
       || (reg_n_sets[((i2dest)->fld[0].rtint)] == 1 && ! added_sets_2
    && ! ((i2dest)->volatil)))
   && (next_real_insn (i2) == i3
       || ! use_crosses_set_p (*split, (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)])))


   && ! reg_referenced_p (i2dest, newpat))
 {
   rtx newdest = i2dest;
   n64_enum_rtx_code split_code = ((*split)->code);
   n64_enum_machine_mode split_mode = ((*split)->mode);



   if (((i2dest)->mode) != split_mode && split_mode != VOIDmode)
     {
       newdest = gen_rtx (REG, split_mode, ((i2dest)->fld[0].rtint));

       if (((i2dest)->fld[0].rtint) >= 68)
  do { rtx _new = (newdest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &regno_reg_rtx[((i2dest)->fld[0].rtint)]; undobuf.undo[undobuf.num_undo].old_contents.r = regno_reg_rtx[((i2dest)->fld[0].rtint)]; regno_reg_rtx[((i2dest)->fld[0].rtint)] = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != regno_reg_rtx[((i2dest)->fld[0].rtint)]) undobuf.num_undo++; } } while (0);
     }




   if (split_code == MULT
       && ((((*split)->fld[1].rtx))->code) == CONST_INT
       && (i = exact_log2_wide ((int) (((((*split)->fld[1].rtx))->fld[0].rtwint)))) >= 0)
     {
       do { rtx _new = (gen_rtx_combine (ASHIFT, split_mode, ((*split)->fld[0].rtx), gen_rtx (CONST_INT, VOIDmode, (int) (i)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*split; undobuf.undo[undobuf.num_undo].old_contents.r = *split; *split = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *split) undobuf.num_undo++; } } while (0)
                                          ;


       split_code = ((*split)->code);
     }




   if (split_code == SUBREG && ((((*split)->fld[0].rtx))->code) == MEM)
     do { rtx _new = (gen_rtx_combine (ZERO_EXTEND, split_mode, ((*split)->fld[0].rtx))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*split; undobuf.undo[undobuf.num_undo].old_contents.r = *split; *split = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *split) undobuf.num_undo++; } } while (0)
                           ;


   newi2pat = gen_rtx_combine (SET, VOIDmode, newdest, *split);
   do { rtx _new = (newdest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*split; undobuf.undo[undobuf.num_undo].old_contents.r = *split; *split = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *split) undobuf.num_undo++; } } while (0);
   i2_code_number
     = recog_for_combine (&newi2pat, i2, &new_i2_notes, &i2_scratches);



   if (i2_code_number >= 0 && ! (split_code == MULT && ! have_mult))
     insn_code_number
       = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);
 }
    }
  else if (i1 && insn_code_number < 0 && asm_noperands (newpat) < 0
    && ((newpat)->code) == PARALLEL
    && ((newpat)->fld[0].rtvec->num_elem) == 2
    && ((((newpat)->fld[0].rtvec->elem[0].rtx))->code) == SET
    && ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) == SIGN_EXTEND
    && ((((newpat)->fld[0].rtvec->elem[1].rtx))->code) == SET
    && rtx_equal_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[1].rtx),
      ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->fld[0].rtx))
    && ! use_crosses_set_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[1].rtx),
       (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]))
    && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) != ZERO_EXTRACT
    && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) != STRICT_LOW_PART
    && ! (temp = ((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx),
   (((temp)->code) == REG
    && reg_nonzero_bits[((temp)->fld[0].rtint)] != 0
    && (8 * mode_size[(int)(((temp)->mode))]) < ((target_flags & 0x00002000) ? 64 : 32)
    && (8 * mode_size[(int)(((temp)->mode))]) < 32
    && (reg_nonzero_bits[((temp)->fld[0].rtint)]
        != (((8 * mode_size[(int)(word_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(word_mode)])) - 1)))))
    && ! (((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) == SUBREG
   && (temp = ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->fld[0].rtx),
       (((temp)->code) == REG
        && reg_nonzero_bits[((temp)->fld[0].rtint)] != 0
        && (8 * mode_size[(int)(((temp)->mode))]) < ((target_flags & 0x00002000) ? 64 : 32)
        && (8 * mode_size[(int)(((temp)->mode))]) < 32
        && (reg_nonzero_bits[((temp)->fld[0].rtint)]
     != (((8 * mode_size[(int)(word_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(word_mode)])) - 1))))))
    && ! reg_overlap_mentioned_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx),
      ((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[1].rtx))
    && ! find_reg_note (i3, REG_UNUSED,
          ((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx)))
    {
      rtx ni2dest;

      newi2pat = ((newpat)->fld[0].rtvec->elem[0].rtx);
      ni2dest = ((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx);
      newpat = ((newpat)->fld[0].rtvec->elem[1].rtx);
      do { rtx _new = (gen_lowpart_for_combine (((((newpat)->fld[1].rtx))->mode), ni2dest)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((newpat)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((newpat)->fld[1].rtx); ((newpat)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((newpat)->fld[1].rtx)) undobuf.num_undo++; } } while (0)
                                                                     ;
      i2_code_number
 = recog_for_combine (&newi2pat, i2, &new_i2_notes, &i2_scratches);

      if (i2_code_number >= 0)
 insn_code_number
   = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);

      if (insn_code_number >= 0)
 {
   rtx insn;
   rtx link;
   ((i3)->fld[3].rtx) = newpat;
   distribute_links (gen_rtx (INSN_LIST, VOIDmode, i3, (rtx) 0));
   for (insn = ((i3)->fld[2].rtx);
        insn && (this_basic_block == n_basic_blocks - 1
   || insn != basic_block_head[this_basic_block + 1]);
        insn = ((insn)->fld[2].rtx))
     {
       if ((rtx_class[(int)(((insn)->code))]) == 'i'
    && reg_referenced_p (ni2dest, ((insn)->fld[3].rtx)))
  {
    for (link = ((insn)->fld[5].rtx); link;
         link = ((link)->fld[1].rtx))
      if (((link)->fld[0].rtx) == i3)
        ((link)->fld[0].rtx) = i1;

    break;
  }
     }
 }
    }






  else if (i1 && insn_code_number < 0 && asm_noperands (newpat) < 0
    && ((newpat)->code) == PARALLEL
    && ((newpat)->fld[0].rtvec->num_elem) == 2
    && ((((newpat)->fld[0].rtvec->elem[0].rtx))->code) == SET
    && ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))->code) != ZERO_EXTRACT
    && ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))->code) != STRICT_LOW_PART
    && ((((newpat)->fld[0].rtvec->elem[1].rtx))->code) == SET
    && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) != ZERO_EXTRACT
    && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) != STRICT_LOW_PART
    && ! use_crosses_set_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[1].rtx),
       (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]))

    && ((((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx))->code) != USE
    && ((((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx))->code) != USE
    && ! reg_referenced_p (((((newpat)->fld[0].rtvec->elem[1].rtx))->fld[0].rtx),
      ((newpat)->fld[0].rtvec->elem[0].rtx))
    && ! reg_referenced_p (((((newpat)->fld[0].rtvec->elem[0].rtx))->fld[0].rtx),
      ((newpat)->fld[0].rtvec->elem[1].rtx)))
    {
      newi2pat = ((newpat)->fld[0].rtvec->elem[1].rtx);
      newpat = ((newpat)->fld[0].rtvec->elem[0].rtx);

      i2_code_number
 = recog_for_combine (&newi2pat, i2, &new_i2_notes, &i2_scratches);

      if (i2_code_number >= 0)
 insn_code_number
   = recog_for_combine (&newpat, i3, &new_i3_notes, &i3_scratches);
    }



  if ((insn_code_number < 0

       && (! check_asm_operands (newpat) || added_sets_1 || added_sets_2)))
    {
      undo_all ();
      return 0;
    }


  if (undobuf.other_insn)
    {
      rtx other_pat = ((undobuf.other_insn)->fld[3].rtx);
      rtx new_other_notes;
      rtx note, next;

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (newpat_used_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

      other_code_number
 = recog_for_combine (&other_pat, undobuf.other_insn,
        &new_other_notes, &other_scratches);

      if (other_code_number < 0 && ! check_asm_operands (other_pat))
 {
   undo_all ();
   return 0;
 }

      ((undobuf.other_insn)->fld[3].rtx) = other_pat;




      for (note = ((undobuf.other_insn)->fld[6].rtx); note; note = next)
 {
   next = ((note)->fld[1].rtx);

   if (((n64_enum_reg_note) ((note)->mode)) == REG_UNUSED
       && ! reg_set_p (((note)->fld[0].rtx), ((undobuf.other_insn)->fld[3].rtx)))
     {
       if (((((note)->fld[0].rtx))->code) == REG)
  reg_n_deaths[((((note)->fld[0].rtx))->fld[0].rtint)]--;

       remove_note (undobuf.other_insn, note);
     }
 }

      for (note = new_other_notes; note; note = ((note)->fld[1].rtx))
 if (((((note)->fld[0].rtx))->code) == REG)
   reg_n_deaths[((((note)->fld[0].rtx))->fld[0].rtint)]++;

      distribute_notes (new_other_notes, undobuf.other_insn,
   undobuf.other_insn, (rtx) 0, (rtx) 0, (rtx) 0);
    }




  {
    rtx i3notes, i2notes, i1notes = 0;
    rtx i3links, i2links, i1links = 0;
    rtx midnotes = 0;
    register int regno;

    rtx elim_i2 = (newi2pat || i2dest_in_i2src || i2dest_in_i1src
     ? 0 : i2dest);
    rtx elim_i1 = i1 == 0 || i1dest_in_i1src ? 0 : i1dest;



    i3notes = ((i3)->fld[6].rtx), i3links = ((i3)->fld[5].rtx);
    i2notes = ((i2)->fld[6].rtx), i2links = ((i2)->fld[5].rtx);
    if (i1)
      i1notes = ((i1)->fld[6].rtx), i1links = ((i1)->fld[5].rtx);





    reset_used_flags (i3notes);
    reset_used_flags (i2notes);
    reset_used_flags (i1notes);
    reset_used_flags (newpat);
    reset_used_flags (newi2pat);
    if (undobuf.other_insn)
      reset_used_flags (((undobuf.other_insn)->fld[3].rtx));

    i3notes = copy_rtx_if_shared (i3notes);
    i2notes = copy_rtx_if_shared (i2notes);
    i1notes = copy_rtx_if_shared (i1notes);
    newpat = copy_rtx_if_shared (newpat);
    newi2pat = copy_rtx_if_shared (newi2pat);
    if (undobuf.other_insn)
      reset_used_flags (((undobuf.other_insn)->fld[3].rtx));

    ((i3)->fld[4].rtint) = insn_code_number;
    ((i3)->fld[3].rtx) = newpat;
    if (undobuf.other_insn)
      ((undobuf.other_insn)->fld[4].rtint) = other_code_number;
    if (i3_subst_into_i2)
      {
 for (i = 0; i < ((((i2)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
   if (((((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))->code) == REG
       && ((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx) != i2dest
       && ! find_reg_note (i2, REG_UNUSED,
      ((((((i2)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->fld[0].rtx)))
     for (temp = ((i2)->fld[2].rtx);
   temp && (this_basic_block == n_basic_blocks - 1
     || basic_block_head[this_basic_block] != temp);
   temp = ((temp)->fld[2].rtx))
       if (temp != i3 && (rtx_class[(int)(((temp)->code))]) == 'i')
  for (link = ((temp)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
    if (((link)->fld[0].rtx) == i2)
      ((link)->fld[0].rtx) = i3;

 if (i3notes)
   {
     rtx link = i3notes;
     while (((link)->fld[1].rtx))
       link = ((link)->fld[1].rtx);
     ((link)->fld[1].rtx) = i2notes;
   }
 else
   i3notes = i2notes;
 i2notes = 0;
      }

    ((i3)->fld[5].rtx) = 0;
    ((i3)->fld[6].rtx) = 0;
    ((i2)->fld[5].rtx) = 0;
    ((i2)->fld[6].rtx) = 0;

    if (newi2pat)
      {
 ((i2)->fld[4].rtint) = i2_code_number;
 ((i2)->fld[3].rtx) = newi2pat;
      }
    else
      {
 ((i2)->code = (NOTE));
 ((i2)->fld[4].rtint) = -1;
 ((i2)->fld[3].rtstr) = 0;
      }

    if (i1)
      {
 ((i1)->fld[5].rtx) = 0;
 ((i1)->fld[6].rtx) = 0;
 ((i1)->code = (NOTE));
 ((i1)->fld[4].rtint) = -1;
 ((i1)->fld[3].rtstr) = 0;
      }




    move_deaths (newpat, i1 ? (((i1)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i1)->fld[0].rtint)]) : (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]), i3, &midnotes);
    if (newi2pat)
      move_deaths (newi2pat, (((i1)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i1)->fld[0].rtint)]), i2, &midnotes);


    if (i3notes)
      distribute_notes (i3notes, i3, i3, newi2pat ? i2 : (rtx) 0,
   elim_i2, elim_i1);
    if (i2notes)
      distribute_notes (i2notes, i2, i3, newi2pat ? i2 : (rtx) 0,
   elim_i2, elim_i1);
    if (i1notes)
      distribute_notes (i1notes, i1, i3, newi2pat ? i2 : (rtx) 0,
   elim_i2, elim_i1);
    if (midnotes)
      distribute_notes (midnotes, (rtx) 0, i3, newi2pat ? i2 : (rtx) 0,
   elim_i2, elim_i1);






    if (newi2pat && new_i2_notes)
      {
 for (temp = new_i2_notes; temp; temp = ((temp)->fld[1].rtx))
   if (((((temp)->fld[0].rtx))->code) == REG)
     reg_n_deaths[((((temp)->fld[0].rtx))->fld[0].rtint)]++;

 distribute_notes (new_i2_notes, i2, i2, (rtx) 0, (rtx) 0, (rtx) 0);
      }

    if (new_i3_notes)
      {
 for (temp = new_i3_notes; temp; temp = ((temp)->fld[1].rtx))
   if (((((temp)->fld[0].rtx))->code) == REG)
     reg_n_deaths[((((temp)->fld[0].rtx))->fld[0].rtint)]++;

 distribute_notes (new_i3_notes, i3, i3, (rtx) 0, (rtx) 0, (rtx) 0);
      }






    if (i3dest_killed)
      {
 if (((i3dest_killed)->code) == REG)
   reg_n_deaths[((i3dest_killed)->fld[0].rtint)]++;

 distribute_notes (gen_rtx (EXPR_LIST, REG_DEAD, i3dest_killed,
       (rtx) 0),
     (rtx) 0, i3, newi2pat ? i2 : (rtx) 0,
     (rtx) 0, (rtx) 0);
      }





    if (i2dest_in_i2src)
      {
 if (((i2dest)->code) == REG)
   reg_n_deaths[((i2dest)->fld[0].rtint)]++;

 if (newi2pat && reg_set_p (i2dest, newi2pat))
   distribute_notes (gen_rtx (EXPR_LIST, REG_DEAD, i2dest, (rtx) 0),
       (rtx) 0, i2, (rtx) 0, (rtx) 0, (rtx) 0);
 else
   distribute_notes (gen_rtx (EXPR_LIST, REG_DEAD, i2dest, (rtx) 0),
       (rtx) 0, i3, newi2pat ? i2 : (rtx) 0,
       (rtx) 0, (rtx) 0);
      }

    if (i1dest_in_i1src)
      {
 if (((i1dest)->code) == REG)
   reg_n_deaths[((i1dest)->fld[0].rtint)]++;

 if (newi2pat && reg_set_p (i1dest, newi2pat))
   distribute_notes (gen_rtx (EXPR_LIST, REG_DEAD, i1dest, (rtx) 0),
       (rtx) 0, i2, (rtx) 0, (rtx) 0, (rtx) 0);
 else
   distribute_notes (gen_rtx (EXPR_LIST, REG_DEAD, i1dest, (rtx) 0),
       (rtx) 0, i3, newi2pat ? i2 : (rtx) 0,
       (rtx) 0, (rtx) 0);
      }

    distribute_links (i3links);
    distribute_links (i2links);
    distribute_links (i1links);

    if (((i2dest)->code) == REG)
      {
 rtx link;
 rtx i2_insn = 0, i2_val = 0, set;
 for (link = ((i3)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
   if ((set = single_set (((link)->fld[0].rtx))) != 0
       && rtx_equal_p (i2dest, ((set)->fld[0].rtx)))
     i2_insn = ((link)->fld[0].rtx), i2_val = ((set)->fld[1].rtx);

 record_value_for_reg (i2dest, i2_insn, i2_val);



 if (! added_sets_2 && newi2pat == 0 && ! i2dest_in_i2src)
   {
     regno = ((i2dest)->fld[0].rtint);
     reg_n_sets[regno]--;
     if (reg_n_sets[regno] == 0
  && ! (basic_block_live_at_start[0][regno / 32]
        & ((unsigned int) 1 << (regno % 32))))
       reg_n_refs[regno] = 0;
   }
      }

    if (i1 && ((i1dest)->code) == REG)
      {
 rtx link;
 rtx i1_insn = 0, i1_val = 0, set;

 for (link = ((i3)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
   if ((set = single_set (((link)->fld[0].rtx))) != 0
       && rtx_equal_p (i1dest, ((set)->fld[0].rtx)))
     i1_insn = ((link)->fld[0].rtx), i1_val = ((set)->fld[1].rtx);

 record_value_for_reg (i1dest, i1_insn, i1_val);

 regno = ((i1dest)->fld[0].rtint);
 if (! added_sets_1 && ! i1dest_in_i1src)
   {
     reg_n_sets[regno]--;
     if (reg_n_sets[regno] == 0
  && ! (basic_block_live_at_start[0][regno / 32]
        & ((unsigned int) 1 << (regno % 32))))
       reg_n_refs[regno] = 0;
   }
      }




    note_stores (newpat, set_nonzero_bits_and_sign_copies);
    if (newi2pat)
      note_stores (newi2pat, set_nonzero_bits_and_sign_copies);





    max_scratch += i3_scratches + i2_scratches + other_scratches;





    if ((((newpat)->code) == RETURN || simplejump_p (i3))
 && ((temp = next_nonnote_insn (i3)) == (rtx) 0
     || ((temp)->code) != BARRIER))
      emit_barrier_after (i3);
  }

  combine_successes++;



  subst_prev_insn = (rtx) 0;

  if (added_links_insn
      && (newi2pat == 0 || (((added_links_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((added_links_insn)->fld[0].rtint)]) < (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)]))
      && (((added_links_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((added_links_insn)->fld[0].rtint)]) < (((i3)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i3)->fld[0].rtint)]))
    return added_links_insn;
  else
    return newi2pat ? i2 : i3;
}



static void
undo_all(void) asm("_undo_all");
static void
undo_all(void)
{
  register int i;
  if (undobuf.num_undo > 50)
    undobuf.num_undo = 50;
  for (i = undobuf.num_undo - 1; i >= 0; i--)
    {
      if (undobuf.undo[i].is_int)
 *undobuf.undo[i].where.i = undobuf.undo[i].old_contents.i;
      else
 *undobuf.undo[i].where.r = undobuf.undo[i].old_contents.r;

    }

  obfree (undobuf.storage);
  undobuf.num_undo = 0;



  subst_prev_insn = (rtx) 0;
}
static rtx *
find_split_point(rtx *loc, rtx insn) asm("_find_split_point");
static rtx *
find_split_point(rtx *loc, rtx insn)
{
  rtx x = *loc;
  n64_enum_rtx_code code = ((x)->code);
  rtx *split;
  int len = 0, pos, unsignedp;
  rtx inner;


  switch (code)
    {
    case SUBREG:



      if (((((x)->fld[0].rtx))->code) == MEM)
 return loc;

      return find_split_point (&((x)->fld[0].rtx), insn);

    case MEM:
      if (((((x)->fld[0].rtx))->code) == PLUS
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ! memory_address_p (((x)->mode), ((x)->fld[0].rtx)))
 {
   rtx reg = regno_reg_rtx[68];
   rtx seq = split_insns (gen_rtx (SET, VOIDmode, reg, ((x)->fld[0].rtx)),
     subst_insn);






   if (seq && ((seq)->fld[0].rtvec->num_elem) == 2
       && ((((seq)->fld[0].rtvec->elem[0].rtx))->code) == INSN
       && ((((((seq)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->code) == SET
       && ((((((seq)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->fld[0].rtx) == reg
       && ! reg_mentioned_p (reg,
        ((((((seq)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->fld[1].rtx))
       && ((((seq)->fld[0].rtvec->elem[1].rtx))->code) == INSN
       && ((((((seq)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx))->code) == SET
       && ((((((seq)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx))->fld[0].rtx) == reg
       && memory_address_p (((x)->mode),
       ((((((seq)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx))->fld[1].rtx)))
     {
       rtx src1 = ((((((seq)->fld[0].rtvec->elem[0].rtx))->fld[3].rtx))->fld[1].rtx);
       rtx src2 = ((((((seq)->fld[0].rtvec->elem[1].rtx))->fld[3].rtx))->fld[1].rtx);






       src2 = replace_rtx (src2, reg, src1);
       split = 0;
       if (((src2)->fld[0].rtx) == src1)
  split = &((src2)->fld[0].rtx);
       else if ((rtx_format[(int)(((((src2)->fld[0].rtx))->code))])[0] == 'e'
         && ((((src2)->fld[0].rtx))->fld[0].rtx) == src1)
  split = &((((src2)->fld[0].rtx))->fld[0].rtx);

       if (split)
  {
    do { rtx _new = (src2); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
    return split;
  }
     }






   else if ((rtx_class[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->code))]) != 'o'
     && ! (((((((x)->fld[0].rtx))->fld[0].rtx))->code) == SUBREG
    && ((rtx_class[(int)(((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->code))])
        == 'o')))
     return &((((x)->fld[0].rtx))->fld[0].rtx);
 }
      break;

    case SET:
      split = find_split_point (&((x)->fld[1].rtx), insn);
      if (split && split != &((x)->fld[1].rtx))
 return split;



      if (((((x)->fld[0].rtx))->code) == ZERO_EXTRACT
   && ((8 * mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))])
       <= 32)
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[0].rtx))->fld[2].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)
       + ((((((x)->fld[0].rtx))->fld[2].rtx))->fld[0].rtwint))
       <= (8 * mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))]))
   && ! side_effects_p (((((x)->fld[0].rtx))->fld[0].rtx)))
 {
   int pos = ((((((x)->fld[0].rtx))->fld[2].rtx))->fld[0].rtwint);
   int len = ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint);
   int src = ((((x)->fld[1].rtx))->fld[0].rtwint);
   rtx dest = ((((x)->fld[0].rtx))->fld[0].rtx);
   n64_enum_machine_mode mode = ((dest)->mode);
   unsigned int mask = ((int) 1 << len) - 1;

   if (0)
     pos = (8 * mode_size[(int)(mode)]) - len - pos;

   if (src == mask)
     do { rtx _new = (gen_binary (IOR, mode, dest, gen_rtx (CONST_INT, VOIDmode, (int) (src << pos)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)
                                                        ;
   else
     do { rtx _new = (gen_binary (IOR, mode, gen_binary (AND, mode, dest, gen_rtx (CONST_INT, VOIDmode, (int) (~ (mask << pos) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))))), gen_rtx (CONST_INT, VOIDmode, (int) (src << pos)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)




                                ;

   do { rtx _new = (dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);

   split = find_split_point (&((x)->fld[1].rtx), insn);
   if (split && split != &((x)->fld[1].rtx))
     return split;
 }



      code = ((((x)->fld[1].rtx))->code);

      switch (code)
 {
 case AND:
   if (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((x)->fld[1].rtx))->fld[0].rtx))->code) == REG
       && (pos = exact_log2_wide ((int) (((((((x)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint)))) >= 7
       && ((((x)->fld[0].rtx))->code) == REG
       && (split = find_single_use (((x)->fld[0].rtx), insn, ((void *)0))) != 0
       && (((*split)->code) == EQ || ((*split)->code) == NE)
       && ((*split)->fld[0].rtx) == ((x)->fld[0].rtx)
       && ((*split)->fld[1].rtx) == const0_rtx)
     {
       do { rtx _new = (make_extraction (((((x)->fld[0].rtx))->mode), ((((x)->fld[1].rtx))->fld[0].rtx), pos, (rtx) 0, 1, 1, 0, 0)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)


                                     ;
       return find_split_point (loc, insn);
     }
   break;

 case SIGN_EXTEND:
   inner = ((((x)->fld[1].rtx))->fld[0].rtx);
   pos = 0;
   len = (8 * mode_size[(int)(((inner)->mode))]);
   unsignedp = 0;
   break;

 case SIGN_EXTRACT:
 case ZERO_EXTRACT:
   if (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((x)->fld[1].rtx))->fld[2].rtx))->code) == CONST_INT)
     {
       inner = ((((x)->fld[1].rtx))->fld[0].rtx);
       len = ((((((x)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint);
       pos = ((((((x)->fld[1].rtx))->fld[2].rtx))->fld[0].rtwint);

       if (0)
  pos = (8 * mode_size[(int)(((inner)->mode))]) - len - pos;
       unsignedp = (code == ZERO_EXTRACT);
     }
   break;
 }

      if (len && pos >= 0 && pos + len <= (8 * mode_size[(int)(((inner)->mode))]))
 {
   n64_enum_machine_mode mode = ((((x)->fld[1].rtx))->mode);







   if (unsignedp && len <= 8)
     {
       do { rtx _new = (gen_rtx_combine (AND, mode, gen_rtx_combine (LSHIFTRT, mode, gen_lowpart_for_combine (mode, inner), gen_rtx (CONST_INT, VOIDmode, (int) (pos))), gen_rtx (CONST_INT, VOIDmode, (int) (((int) 1 << len) - 1)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)





                                                  ;

       split = find_split_point (&((x)->fld[1].rtx), insn);
       if (split && split != &((x)->fld[1].rtx))
  return split;
     }
   else
     {
       do { rtx _new = (gen_rtx_combine (unsignedp ? LSHIFTRT : ASHIFTRT, mode, gen_rtx_combine (ASHIFT, mode, gen_lowpart_for_combine (mode, inner), gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(mode)]) - len - pos))), gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(mode)]) - len)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)






                                                 ;

       split = find_split_point (&((x)->fld[1].rtx), insn);
       if (split && split != &((x)->fld[1].rtx))
  return split;
     }
 }




      if (((rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '2'
    || (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == 'c'
    || (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '<')
   && (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == SYMBOL_REF || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_DOUBLE || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == HIGH)
   && ((rtx_class[(int)(((((((x)->fld[1].rtx))->fld[0].rtx))->code))]) == 'o'
       || (((((((x)->fld[1].rtx))->fld[0].rtx))->code) == SUBREG
    && ((rtx_class[(int)(((((((((x)->fld[1].rtx))->fld[0].rtx))->fld[0].rtx))->code))])
        == 'o'))))
 return &((((x)->fld[1].rtx))->fld[1].rtx);






      if (((rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '2'
    || (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == 'c'
    || (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '<'
    || (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '1')
   && ! register_operand (((((x)->fld[1].rtx))->fld[0].rtx), VOIDmode))
 return &((((x)->fld[1].rtx))->fld[0].rtx);

      return 0;

    case AND:
    case IOR:



      if (((((x)->fld[0].rtx))->code) == NOT && ((((x)->fld[1].rtx))->code) == NOT)
 {
   do { rtx _new = (gen_rtx_combine (NOT, ((x)->mode), gen_rtx_combine (code == IOR ? AND : IOR, ((x)->mode), ((((x)->fld[0].rtx))->fld[0].rtx), ((((x)->fld[1].rtx))->fld[0].rtx)))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*loc; undobuf.undo[undobuf.num_undo].old_contents.r = *loc; *loc = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *loc) undobuf.num_undo++; } } while (0)




                                 ;
   return find_split_point (loc, insn);
 }




      if (((((x)->fld[1].rtx))->code) == NOT)
 {
   rtx tem = ((x)->fld[0].rtx);
   do { rtx _new = (((x)->fld[1].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
   do { rtx _new = (tem); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
 }
      break;
    }


  switch ((rtx_class[(int)(code)]))
    {
    case 'b':
    case '3':
      split = find_split_point (&((x)->fld[2].rtx), insn);
      if (split)
 return split;

    case '2':
    case 'c':
    case '<':
      split = find_split_point (&((x)->fld[1].rtx), insn);
      if (split)
 return split;

    case '1':


      if (((x)->code) != AND && ((((x)->fld[0].rtx))->code) == AND)
 return &((x)->fld[0].rtx);

      split = find_split_point (&((x)->fld[0].rtx), insn);
      if (split)
 return split;
      return loc;
    }


  return 0;
}
static rtx
subst(register rtx x, register rtx from, register rtx to, int in_dest, int unique_copy) asm("_subst");
static rtx
subst(register rtx x, register rtx from, register rtx to, int in_dest, int unique_copy)
{
  register n64_enum_rtx_code code = ((x)->code);
  n64_enum_machine_mode op0_mode = VOIDmode;
  register char *fmt;
  register int len, i;
  rtx cxx_new;
  if (! in_dest && ((x) == (from) || (((x)->code) == REG && ((from)->code) == REG && ((x)->fld[0].rtint) == ((from)->fld[0].rtint) && ((x)->mode) == ((from)->mode))))
    {
      n_occurrences++;
      return (unique_copy && n_occurrences > 1 ? copy_rtx (to) : to);
    }
  if (! in_dest && code == REG && ((from)->code) == REG
      && ((x)->fld[0].rtint) == ((from)->fld[0].rtint))
    return gen_rtx (CLOBBER, ((x)->mode), const0_rtx);



  if (code != MEM && code != LO_SUM && (rtx_class[(int)(code)]) == 'o')
    return x;







  if (((x) == (to) || (((x)->code) == REG && ((to)->code) == REG && ((x)->fld[0].rtint) == ((to)->fld[0].rtint) && ((x)->mode) == ((to)->mode))))
    return to;

  len = (rtx_length[(int)(code)]);
  fmt = (rtx_format[(int)(code)]);





  if (code == SET
      && (((((x)->fld[0].rtx))->code) == REG
        || ((((x)->fld[0].rtx))->code) == CC0
        || ((((x)->fld[0].rtx))->code) == PC))
    fmt = "ie";


  if (fmt[0] == 'e')
    op0_mode = ((((x)->fld[0].rtx))->mode);

  for (i = 0; i < len; i++)
    {
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     {
       if (((((x)->fld[i].rtvec->elem[j].rtx)) == (from) || (((((x)->fld[i].rtvec->elem[j].rtx))->code) == REG && ((from)->code) == REG && ((((x)->fld[i].rtvec->elem[j].rtx))->fld[0].rtint) == ((from)->fld[0].rtint) && ((((x)->fld[i].rtvec->elem[j].rtx))->mode) == ((from)->mode))))
  {
    cxx_new = (unique_copy && n_occurrences ? copy_rtx (to) : to);
    n_occurrences++;
  }
       else
  {
    cxx_new = subst (((x)->fld[i].rtvec->elem[j].rtx), from, to, 0, unique_copy);


    if (((cxx_new)->code) == CLOBBER && ((cxx_new)->fld[0].rtx) == const0_rtx)
      return cxx_new;
  }

       do { rtx _new = (cxx_new); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[i].rtvec->elem[j].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[i].rtvec->elem[j].rtx); ((x)->fld[i].rtvec->elem[j].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[i].rtvec->elem[j].rtx)) undobuf.num_undo++; } } while (0);
     }
 }
      else if (fmt[i] == 'e')
 {
   if (((((x)->fld[i].rtx)) == (from) || (((((x)->fld[i].rtx))->code) == REG && ((from)->code) == REG && ((((x)->fld[i].rtx))->fld[0].rtint) == ((from)->fld[0].rtint) && ((((x)->fld[i].rtx))->mode) == ((from)->mode))))
     {
       if (((to)->code) == SUBREG
    && ! (((mode_class[(int)(((to)->mode))]) == MODE_FLOAT || (mode_class[(int)(((to)->mode))]) == MODE_COMPLEX_FLOAT) == ((mode_class[(int)(((((to)->fld[0].rtx))->mode))]) == MODE_FLOAT || (mode_class[(int)(((((to)->fld[0].rtx))->mode))]) == MODE_COMPLEX_FLOAT))

    && ! (code == SUBREG
   && (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT) == ((mode_class[(int)(((((to)->fld[0].rtx))->mode))]) == MODE_FLOAT || (mode_class[(int)(((((to)->fld[0].rtx))->mode))]) == MODE_COMPLEX_FLOAT))
                                    )



    )
  return gen_rtx (CLOBBER, VOIDmode, const0_rtx);

       cxx_new = (unique_copy && n_occurrences ? copy_rtx (to) : to);
       n_occurrences++;
     }
   else
     cxx_new = subst (((x)->fld[i].rtx), from, to,
    (((in_dest
       && (code == SUBREG || code == STRICT_LOW_PART
    || code == ZERO_EXTRACT))
      || code == SET)
     && i == 0), unique_copy);







   if (((cxx_new)->code) == CLOBBER && ((cxx_new)->fld[0].rtx) == const0_rtx)
     return cxx_new;

   do { rtx _new = (cxx_new); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[i].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[i].rtx); ((x)->fld[i].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[i].rtx)) undobuf.num_undo++; } } while (0);
 }
    }





  for (i = 0; i < 4; i++)
    {


      if (code != CONST_INT && code != REG && code != CLOBBER)
 x = simplify_rtx (x, op0_mode, i == 3, in_dest);

      if (((x)->code) == code)
 break;

      code = ((x)->code);



      op0_mode = VOIDmode;
    }

  return x;
}
static rtx
simplify_rtx(rtx x, n64_enum_machine_mode op0_mode, int last, int in_dest) asm("_simplify_rtx");
static rtx
simplify_rtx(rtx x, n64_enum_machine_mode op0_mode, int last, int in_dest)
{
  n64_enum_rtx_code code = ((x)->code);
  n64_enum_machine_mode mode = ((x)->mode);
  rtx temp;
  int i;



  if ((rtx_class[(int)(code)]) == 'c'
      && (((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH) && ((((x)->fld[1].rtx))->code) != CONST_INT)
   || ((rtx_class[(int)(((((x)->fld[0].rtx))->code))]) == 'o'
       && (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) != 'o')
   || (((((x)->fld[0].rtx))->code) == SUBREG
       && (rtx_class[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->code))]) == 'o'
       && (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) != 'o')))
    {
      temp = ((x)->fld[0].rtx);
      do { rtx _new = (((x)->fld[1].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      do { rtx _new = (temp); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
    }
  if ((code == PLUS || code == MINUS || code == MULT)
      && ((((x)->fld[0].rtx))->code) == ASHIFTRT
      && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == PLUS
      && ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->code) == ASHIFT
      && ((((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->fld[1].rtx) == ((((x)->fld[0].rtx))->fld[1].rtx)
      && ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && (temp = simplify_binary_operation (ASHIFTRT, mode,
         ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx),
         ((((x)->fld[0].rtx))->fld[1].rtx))) != 0)
    {
      rtx cxx_new
 = simplify_shift_const ((rtx) 0, ASHIFT, mode,
    ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->fld[0].rtx),
    ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint));

      cxx_new = simplify_shift_const ((rtx) 0, ASHIFTRT, mode, cxx_new,
      ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint));

      do { rtx _new = (gen_binary (PLUS, mode, cxx_new, temp)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
    }
  if ((((rtx_class[(int)(code)]) == '2' || (rtx_class[(int)(code)]) == 'c'
 || (rtx_class[(int)(code)]) == '<')
       && (((rtx_class[(int)(((((x)->fld[0].rtx))->code))]) != 'o'
     && ! (((((x)->fld[0].rtx))->code) == SUBREG
    && ((rtx_class[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->code))])
        == 'o')))
    || ((rtx_class[(int)(((((x)->fld[1].rtx))->code))]) != 'o'
        && ! (((((x)->fld[1].rtx))->code) == SUBREG
       && ((rtx_class[(int)(((((((x)->fld[1].rtx))->fld[0].rtx))->code))])
    == 'o')))))
      || ((rtx_class[(int)(code)]) == '1'
   && (((rtx_class[(int)(((((x)->fld[0].rtx))->code))]) != 'o'
        && ! (((((x)->fld[0].rtx))->code) == SUBREG
       && ((rtx_class[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->code))])
    == 'o'))))))
    {
      rtx cond, cxx_true, cxx_false;

      cond = if_then_else_cond (x, &cxx_true, &cxx_false);
      if (cond != 0)
 {
   rtx cop1 = const0_rtx;
   n64_enum_rtx_code cond_code = simplify_comparison (NE, &cond, &cop1);

   if (cond_code == NE && (rtx_class[(int)(((cond)->code))]) == '<')
     return x;



   cxx_true = subst (cxx_true, pc_rtx, pc_rtx, 0, 0);
   cxx_false = subst (cxx_false, pc_rtx, pc_rtx, 0, 0);






   if (cxx_true == const_true_rtx && cxx_false == const0_rtx)
     x = gen_binary (cond_code, mode, cond, cop1);
   else if (cxx_true == const0_rtx && cxx_false == const_true_rtx)
     x = gen_binary (reverse_condition (cond_code), mode, cond, cop1);



   else if (((cxx_true)->code) == CONST_INT
     && ((cxx_true)->fld[0].rtwint) == - 1
     && cxx_false == const0_rtx)
     x = gen_unary (NEG, mode, mode,
      gen_binary (cond_code, mode, cond, cop1));
   else if (((cxx_false)->code) == CONST_INT
     && ((cxx_false)->fld[0].rtwint) == - 1
     && cxx_true == const0_rtx)
     x = gen_unary (NEG, mode, mode,
      gen_binary (reverse_condition (cond_code),
           mode, cond, cop1));
   else
     return gen_rtx (IF_THEN_ELSE, mode,
       gen_binary (cond_code, VOIDmode, cond, cop1),
       cxx_true, cxx_false);

   code = ((x)->code);
   op0_mode = VOIDmode;
 }
    }



  temp = 0;
  switch ((rtx_class[(int)(code)]))
    {
    case '1':
      temp = simplify_unary_operation (code, mode, ((x)->fld[0].rtx), op0_mode);
      break;
    case '<':
      temp = simplify_relational_operation (code, op0_mode,
         ((x)->fld[0].rtx), ((x)->fld[1].rtx));





      break;
    case 'c':
    case '2':
      temp = simplify_binary_operation (code, mode, ((x)->fld[0].rtx), ((x)->fld[1].rtx));
      break;
    case 'b':
    case '3':
      temp = simplify_ternary_operation (code, mode, op0_mode, ((x)->fld[0].rtx),
      ((x)->fld[1].rtx), ((x)->fld[2].rtx));
      break;
    }

  if (temp)
    x = temp, code = ((temp)->code);


  if (code == PLUS || code == MINUS
      || code == AND || code == IOR || code == XOR)
    {
      x = apply_distributive_law (x);
      code = ((x)->code);
    }




  if ((code == PLUS || code == MINUS
       || code == MULT || code == AND || code == IOR || code == XOR
       || code == DIV || code == UDIV
       || code == SMAX || code == SMIN || code == UMAX || code == UMIN)
      && ((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT))
    {
      if (((((x)->fld[0].rtx))->code) == code)
 {
   rtx other = ((((x)->fld[0].rtx))->fld[0].rtx);
   rtx inner_op0 = ((((x)->fld[0].rtx))->fld[1].rtx);
   rtx inner_op1 = ((x)->fld[1].rtx);
   rtx inner;



   if ((((inner_op0)->code) == LABEL_REF || ((inner_op0)->code) == SYMBOL_REF || ((inner_op0)->code) == CONST_INT || ((inner_op0)->code) == CONST_DOUBLE || ((inner_op0)->code) == CONST || ((inner_op0)->code) == HIGH) && (rtx_class[(int)(code)]) == 'c')
     {
       rtx tem = inner_op0;
       inner_op0 = inner_op1;
       inner_op1 = tem;
     }
   inner = simplify_binary_operation (code == MINUS ? PLUS
          : code == DIV ? MULT
          : code == UDIV ? MULT
          : code,
          mode, inner_op0, inner_op1);



   if (inner == 0 && (rtx_class[(int)(code)]) == 'c')
     {
       other = ((((x)->fld[0].rtx))->fld[1].rtx);
       inner = simplify_binary_operation (code, mode,
       ((((x)->fld[0].rtx))->fld[0].rtx),
       ((x)->fld[1].rtx));
     }

   if (inner)
     return gen_binary (code, mode, other, inner);
 }
    }


  switch (code)
    {
    case MEM:


      temp = make_compound_operation (((x)->fld[0].rtx), MEM);
      do { rtx _new = (temp); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      break;

    case SUBREG:




      if (((((x)->fld[0].rtx))->code) == MEM
   && ((mode_size[(int)(mode)])
       <= (mode_size[(int)(((((x)->fld[0].rtx))->mode))])))
 {
   rtx inner = ((x)->fld[0].rtx);
   int endian_offset = 0;


   if (((((x)->fld[0].rtx))->volatil)
       || mode_dependent_address_p (((inner)->fld[0].rtx)))
     return gen_rtx (CLOBBER, mode, const0_rtx);

   if (((target_flags & 0x00010000) != 0))
     {
       if ((mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4))
  endian_offset += ((target_flags & 0x00002000) ? 8 : 4) - (mode_size[(int)(mode)]);
       if ((mode_size[(int)(((inner)->mode))]) < ((target_flags & 0x00002000) ? 8 : 4))
  endian_offset -= (((target_flags & 0x00002000) ? 8 : 4)
      - (mode_size[(int)(((inner)->mode))]));
     }


   x = gen_rtx (MEM, mode,
         plus_constant_wide (((inner)->fld[0].rtx), (int) ((((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4) + endian_offset)))

                            );
   ((x)->volatil) = ((inner)->volatil);
   ((x)->unchanging) = ((inner)->unchanging);
   ((x)->in_struct) = ((inner)->in_struct);
   return x;
 }


      if (in_dest)
 return x;



      if (((((x)->fld[0].rtx))->code) == SUBREG)
 {
   if (mode == ((((((x)->fld[0].rtx))->fld[0].rtx))->mode)
       && ((x)->fld[1].rtint) == 0 && ((((x)->fld[0].rtx))->fld[1].rtint) == 0)
     return ((((x)->fld[0].rtx))->fld[0].rtx);

   do { if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 1; undobuf.undo[undobuf.num_undo].where.i = (int *) &((x)->fld[1].rtint); undobuf.undo[undobuf.num_undo].old_contents.i = ((x)->fld[1].rtint); ((x)->fld[1].rtint) = ((x)->fld[1].rtint) + ((((x)->fld[0].rtx))->fld[1].rtint); if (undobuf.undo[undobuf.num_undo].old_contents.i != ((x)->fld[1].rtint)) undobuf.num_undo++; } } while (0)
                                                      ;
   do { rtx _new = (((((x)->fld[0].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
 }






      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68
   && ((((x)->fld[0].rtx))->fld[0].rtint) != (0 + 30)




   && ((((x)->fld[0].rtx))->fld[0].rtint) != 0

   && ((((x)->fld[0].rtx))->fld[0].rtint) != (0 + 29))
 {
   if (mips_hard_regno_mode_ok[ (int)(mode) ][ (((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint)) ]
           )
     return gen_rtx (REG, mode,
       ((((x)->fld[0].rtx))->fld[0].rtint) + ((x)->fld[1].rtint));
   else
     return gen_rtx (CLOBBER, mode, const0_rtx);
 }






      if ((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH) && op0_mode != VOIDmode
   && (mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 8 : 4)
   && (mode_size[(int)(op0_mode)]) < ((target_flags & 0x00002000) ? 8 : 4)
   && (mode_class[(int)(mode)]) == MODE_INT)
 {
   temp = operand_subword (((x)->fld[0].rtx), ((x)->fld[1].rtint),
      0, op0_mode);
   if (temp)
     return temp;
 }





      if ((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH) && subreg_lowpart_p (x)
   && (mode_size[(int)(mode)]) < (mode_size[(int)(op0_mode)])
   && (! ((target_flags & 0x00010000) != 0)
       || (8 * mode_size[(int)(op0_mode)]) <= ((target_flags & 0x00002000) ? 64 : 32)))
 return gen_lowpart_for_combine (mode, ((x)->fld[0].rtx));



      if ((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH) && ((((x)->fld[0].rtx))->mode) == VOIDmode
   && (mode_size[(int)(mode)]) > (mode_size[(int)(op0_mode)]))
 return ((x)->fld[0].rtx);





      break;

    case NOT:

      if (((((x)->fld[0].rtx))->code) == PLUS
   && ((((x)->fld[0].rtx))->fld[1].rtx) == constm1_rtx)
 return gen_rtx_combine (NEG, mode, ((((x)->fld[0].rtx))->fld[0].rtx));


      if (((((x)->fld[0].rtx))->code) == NEG)
 return gen_rtx_combine (PLUS, mode, ((((x)->fld[0].rtx))->fld[0].rtx),
    constm1_rtx);


      if (((((x)->fld[0].rtx))->code) == XOR
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && (temp = simplify_unary_operation (NOT, mode,
            ((((x)->fld[0].rtx))->fld[1].rtx),
            mode)) != 0)
 return gen_binary (XOR, mode, ((((x)->fld[0].rtx))->fld[0].rtx), temp);





      if (((((x)->fld[0].rtx))->code) == ASHIFT
   && ((((x)->fld[0].rtx))->fld[0].rtx) == const1_rtx)
 return gen_rtx (ROTATE, mode, gen_unary (NOT, mode, mode, const1_rtx),
   ((((x)->fld[0].rtx))->fld[1].rtx));

      if (((((x)->fld[0].rtx))->code) == SUBREG
   && subreg_lowpart_p (((x)->fld[0].rtx))
   && ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])
       < (mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))]))
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == ASHIFT
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx) == const1_rtx)
 {
   n64_enum_machine_mode inner_mode = ((((((x)->fld[0].rtx))->fld[0].rtx))->mode);

   x = gen_rtx (ROTATE, inner_mode,
         gen_unary (NOT, inner_mode, inner_mode, const1_rtx),
         ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx));
   return gen_lowpart_for_combine (mode, x);
 }
      if (((((x)->fld[0].rtx))->code) == IOR || ((((x)->fld[0].rtx))->code) == AND)
  {
   rtx in1 = ((((x)->fld[0].rtx))->fld[0].rtx), in2 = ((((x)->fld[0].rtx))->fld[1].rtx);

  if (((in1)->code) == NOT)
    in1 = ((in1)->fld[0].rtx);
   else
    in1 = gen_rtx_combine (NOT, ((in1)->mode), in1);

  if (((in2)->code) == NOT)
    in2 = ((in2)->fld[0].rtx);
   else if (((in2)->code) == CONST_INT
    && (8 * mode_size[(int)(mode)]) <= 32)
    in2 = gen_rtx (CONST_INT, VOIDmode, (int) ((((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) & ~ ((in2)->fld[0].rtwint)));
  else
    in2 = gen_rtx_combine (NOT, ((in2)->mode), in2);

  if (((in2)->code) == NOT)
    {
      rtx tem = in2;
      in2 = in1; in1 = tem;
    }

  return gen_rtx_combine (((((x)->fld[0].rtx))->code) == IOR ? AND : IOR,
     mode, in1, in2);
       }
      break;

    case NEG:

      if (((((x)->fld[0].rtx))->code) == PLUS
   && ((((x)->fld[0].rtx))->fld[1].rtx) == const1_rtx)
 return gen_rtx_combine (NOT, mode, ((((x)->fld[0].rtx))->fld[0].rtx));


      if (((((x)->fld[0].rtx))->code) == NOT)
 return plus_constant_wide (((((x)->fld[0].rtx))->fld[0].rtx), (int) (1));


      if (((((x)->fld[0].rtx))->code) == MINUS
   && (! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT)

       || 1 != 1
       || flag_fast_math))
 return gen_binary (MINUS, mode, ((((x)->fld[0].rtx))->fld[1].rtx),
      ((((x)->fld[0].rtx))->fld[0].rtx));


      if (((((x)->fld[0].rtx))->code) == XOR && ((((x)->fld[0].rtx))->fld[1].rtx) == const1_rtx
   && nonzero_bits (((((x)->fld[0].rtx))->fld[0].rtx), mode) == 1)
 return gen_binary (PLUS, mode, ((((x)->fld[0].rtx))->fld[0].rtx), constm1_rtx);





      if (((((x)->fld[0].rtx))->code) == ASHIFT)
 {
   temp = simplify_unary_operation (NEG, mode,
        ((((x)->fld[0].rtx))->fld[0].rtx), mode);
   if (temp)
     {
       do { rtx _new = (temp); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((((x)->fld[0].rtx))->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((((x)->fld[0].rtx))->fld[0].rtx); ((((x)->fld[0].rtx))->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((((x)->fld[0].rtx))->fld[0].rtx)) undobuf.num_undo++; } } while (0);
       return ((x)->fld[0].rtx);
     }
 }

      temp = expand_compound_operation (((x)->fld[0].rtx));





      if (((temp)->code) == ASHIFTRT
   && ((((temp)->fld[1].rtx))->code) == CONST_INT
   && ((((temp)->fld[1].rtx))->fld[0].rtwint) == (8 * mode_size[(int)(mode)]) - 1)
 return simplify_shift_const (temp, LSHIFTRT, mode, ((temp)->fld[0].rtx),
         ((((temp)->fld[1].rtx))->fld[0].rtwint));
      if (((temp)->code) != REG
   && ! (((temp)->code) == SUBREG
  && ((((temp)->fld[0].rtx))->code) == REG)
   && (i = exact_log2_wide ((int) (nonzero_bits (temp, mode)))) >= 0)
 {
   rtx temp1 = simplify_shift_const
     ((rtx) 0, ASHIFTRT, mode,
      simplify_shift_const ((rtx) 0, ASHIFT, mode, temp,
       (8 * mode_size[(int)(mode)]) - 1 - i),
      (8 * mode_size[(int)(mode)]) - 1 - i);




   if (((temp1)->code) != ASHIFTRT
       || ((((temp1)->fld[0].rtx))->code) != ASHIFT
       || ((((temp1)->fld[0].rtx))->fld[0].rtx) != temp)
     return temp1;
 }
      break;

    case TRUNCATE:
      if ((8 * mode_size[(int)(mode)]) <= 32)
 do { rtx _new = (force_to_mode (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode), (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)), (rtx) 0, 0)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0)

                                            ;
      break;

    case FLOAT_TRUNCATE:

      if (((((x)->fld[0].rtx))->code) == FLOAT_EXTEND
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->mode) == mode)
  return ((((x)->fld[0].rtx))->fld[0].rtx);



      if ((((((x)->fld[0].rtx))->code) == ABS
    || ((((x)->fld[0].rtx))->code) == NEG)
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == FLOAT_EXTEND
   && ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->mode) == mode)
 return gen_unary (((((x)->fld[0].rtx))->code), mode, mode,
     ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx));



      if (((((x)->fld[0].rtx))->code) == SUBREG
   && subreg_lowpart_p (((x)->fld[0].rtx))
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == FLOAT_TRUNCATE)
 return ((((x)->fld[0].rtx))->fld[0].rtx);
      break;
    case CONST:



      if (((((x)->fld[0].rtx))->code) == CONST)
 do { rtx _new = (((((x)->fld[0].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      break;
    case PLUS:




      if (((((x)->fld[0].rtx))->code) == PLUS
   && ((((((((x)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == SYMBOL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == HIGH || (((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((((x)->fld[0].rtx))->fld[1].rtx))) && ! 0)) && (!0 || !0)))
 return gen_binary (PLUS, mode,
      gen_binary (PLUS, mode, ((((x)->fld[0].rtx))->fld[0].rtx),
           ((x)->fld[1].rtx)),
      ((((x)->fld[0].rtx))->fld[1].rtx));





      if (((((x)->fld[0].rtx))->code) == XOR
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) == - ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)
   && (i = exact_log2_wide ((int) (((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)))) >= 0
   && (8 * mode_size[(int)(mode)]) <= 32
   && ((((((((x)->fld[0].rtx))->fld[0].rtx))->code) == AND
        && ((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
        && (((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)
     == ((int) 1 << (i + 1)) - 1))
       || (((((((x)->fld[0].rtx))->fld[0].rtx))->code) == ZERO_EXTEND
    && ((8 * mode_size[(int)(((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->mode))])
        == i + 1))))
 return simplify_shift_const
   ((rtx) 0, ASHIFTRT, mode,
    simplify_shift_const ((rtx) 0, ASHIFT, mode,
     ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx),
     (8 * mode_size[(int)(mode)]) - (i + 1)),
    (8 * mode_size[(int)(mode)]) - (i + 1));





      if ((rtx_class[(int)(((((x)->fld[0].rtx))->code))]) == '<'
   && reversible_comparison_p (((x)->fld[0].rtx))
   && ((1 == -1 && ((x)->fld[1].rtx) == const1_rtx)
       || (1 == 1 && ((x)->fld[1].rtx) == constm1_rtx)))
 return
   gen_unary (NEG, mode, mode,
       gen_binary (reverse_condition (((((x)->fld[0].rtx))->code)),
     mode, ((((x)->fld[0].rtx))->fld[0].rtx),
     ((((x)->fld[0].rtx))->fld[1].rtx)));





      if (((x)->fld[1].rtx) == constm1_rtx
   && ((((x)->fld[0].rtx))->code) != REG
   && ! (((((x)->fld[0].rtx))->code) == SUBREG
  && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG)
   && nonzero_bits (((x)->fld[0].rtx), mode) == 1)
 return simplify_shift_const ((rtx) 0, ASHIFTRT, mode,
    simplify_shift_const ((rtx) 0, ASHIFT, mode,
     gen_rtx_combine (XOR, mode,
        ((x)->fld[0].rtx), const1_rtx),
     (8 * mode_size[(int)(mode)]) - 1),
    (8 * mode_size[(int)(mode)]) - 1);






      if ((8 * mode_size[(int)(mode)]) <= 32
   && (nonzero_bits (((x)->fld[0].rtx), mode)
       & nonzero_bits (((x)->fld[1].rtx), mode)) == 0)
 return gen_binary (IOR, mode, ((x)->fld[0].rtx), ((x)->fld[1].rtx));
      break;

    case MINUS:



      if (((x)->fld[0].rtx) == const1_rtx
   && (rtx_class[(int)(((((x)->fld[1].rtx))->code))]) == '<'
   && reversible_comparison_p (((x)->fld[1].rtx)))
 return gen_binary (reverse_condition (((((x)->fld[1].rtx))->code)),
      mode, ((((x)->fld[1].rtx))->fld[0].rtx),
    ((((x)->fld[1].rtx))->fld[1].rtx));




      if (((((x)->fld[1].rtx))->code) == AND
   && ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT
   && exact_log2_wide ((int) (- ((((((x)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint))) >= 0
   && rtx_equal_p (((((x)->fld[1].rtx))->fld[0].rtx), ((x)->fld[0].rtx)))
 return simplify_and_const_int ((rtx) 0, mode, ((x)->fld[0].rtx),
           - ((((((x)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint) - 1);



      if (((((x)->fld[1].rtx))->code) == PLUS && ((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT))
 return gen_binary (MINUS, mode,
      gen_binary (MINUS, mode, ((x)->fld[0].rtx),
           ((((x)->fld[1].rtx))->fld[0].rtx)),
      ((((x)->fld[1].rtx))->fld[1].rtx));
      break;

    case MULT:




      if (((((x)->fld[0].rtx))->code) == PLUS)
 {
   x = apply_distributive_law
     (gen_binary (PLUS, mode,
    gen_binary (MULT, mode,
         ((((x)->fld[0].rtx))->fld[0].rtx), ((x)->fld[1].rtx)),
    gen_binary (MULT, mode,
         ((((x)->fld[0].rtx))->fld[1].rtx), ((x)->fld[1].rtx))));

   if (((x)->code) != MULT)
     return x;
 }
      break;

    case UDIV:


      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint)))) >= 0
   && (((((x)->fld[0].rtx))->code) == ASHIFT
       || ((((x)->fld[0].rtx))->code) == LSHIFTRT
       || ((((x)->fld[0].rtx))->code) == ASHIFTRT
       || ((((x)->fld[0].rtx))->code) == ROTATE
       || ((((x)->fld[0].rtx))->code) == ROTATERT))
 return simplify_shift_const ((rtx) 0, LSHIFTRT, mode, ((x)->fld[0].rtx), i);
      break;

    case EQ: case NE:
    case GT: case GTU: case GE: case GEU:
    case LT: case LTU: case LE: case LEU:


      if (((((x)->fld[0].rtx))->code) == COMPARE
   || ((mode_class[(int)(((((x)->fld[0].rtx))->mode))]) != MODE_CC



        ))
 {
   rtx op0 = ((x)->fld[0].rtx);
   rtx op1 = ((x)->fld[1].rtx);
   n64_enum_rtx_code new_code;

   if (((op0)->code) == COMPARE)
     op1 = ((op0)->fld[1].rtx), op0 = ((op0)->fld[0].rtx);


   new_code = simplify_comparison (code, &op0, &op1);
   if (new_code == NE && (mode_class[(int)(mode)]) == MODE_INT
       && op1 == const0_rtx
       && nonzero_bits (op0, mode) == 1)
     return gen_lowpart_for_combine (mode,
         expand_compound_operation (op0));

   else if (new_code == NE && (mode_class[(int)(mode)]) == MODE_INT
     && op1 == const0_rtx
     && (num_sign_bit_copies (op0, mode)
         == (8 * mode_size[(int)(mode)])))
     {
       op0 = expand_compound_operation (op0);
       return gen_unary (NEG, mode, mode,
    gen_lowpart_for_combine (mode, op0));
     }

   else if (new_code == EQ && (mode_class[(int)(mode)]) == MODE_INT
     && op1 == const0_rtx
     && nonzero_bits (op0, mode) == 1)
     {
       op0 = expand_compound_operation (op0);
       return gen_binary (XOR, mode,
     gen_lowpart_for_combine (mode, op0),
     const1_rtx);
     }

   else if (new_code == EQ && (mode_class[(int)(mode)]) == MODE_INT
     && op1 == const0_rtx
     && (num_sign_bit_copies (op0, mode)
         == (8 * mode_size[(int)(mode)])))
     {
       op0 = expand_compound_operation (op0);
       return plus_constant_wide (gen_lowpart_for_combine (mode, op0), (int) (1));
     }
   if (new_code == NE && (mode_class[(int)(mode)]) == MODE_INT
       && (8 * mode_size[(int)(mode)]) <= 32
       && (1
    == (int) 1 << ((8 * mode_size[(int)(mode)]) - 1))
       && op1 == const0_rtx
       && mode == ((op0)->mode)
       && (i = exact_log2_wide ((int) (nonzero_bits (op0, mode)))) >= 0)
     {
       x = simplify_shift_const ((rtx) 0, ASHIFT, mode,
     expand_compound_operation (op0),
     (8 * mode_size[(int)(mode)]) - 1 - i);
       if (((x)->code) == AND && ((x)->fld[1].rtx) == const_true_rtx)
  return ((x)->fld[0].rtx);
       else
  return x;
     }


   if (new_code != code)
     return gen_rtx_combine (new_code, mode, op0, op1);



   do { rtx _new = (op0); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
   do { rtx _new = (op1); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
 }
      break;

    case IF_THEN_ELSE:
      return simplify_if_then_else (x);

    case ZERO_EXTRACT:
    case SIGN_EXTRACT:
    case ZERO_EXTEND:
    case SIGN_EXTEND:

      if (in_dest)
 return x;

      return expand_compound_operation (x);

    case SET:
      return simplify_set (x);

    case AND:
    case IOR:
    case XOR:
      return simplify_logical (x, last);

    case ABS:

      if (((((x)->fld[0].rtx))->code) == NEG)
 do { rtx _new = (((((x)->fld[0].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);


      if (((((x)->fld[0].rtx))->code) == FFS || ((((x)->fld[0].rtx))->code) == ABS
   || (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])
        <= 32)
       && ((nonzero_bits (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode))
     & ((int) 1
        << ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - 1)))
    == 0)))
 return ((x)->fld[0].rtx);



      if (num_sign_bit_copies (((x)->fld[0].rtx), mode) == (8 * mode_size[(int)(mode)]))
 return gen_rtx_combine (NEG, mode, ((x)->fld[0].rtx));

      break;

    case FFS:

      if (((((x)->fld[0].rtx))->code) == SIGN_EXTEND
   || ((((x)->fld[0].rtx))->code) == ZERO_EXTEND)
 do { rtx _new = (((((x)->fld[0].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      break;

    case FLOAT:

      if (((((x)->fld[0].rtx))->code) == SIGN_EXTEND)
 do { rtx _new = (((((x)->fld[0].rtx))->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      break;

    case ASHIFT:
    case LSHIFTRT:
    case ASHIFTRT:
    case ROTATE:
    case ROTATERT:

      if (((((x)->fld[1].rtx))->code) == CONST_INT)
 return simplify_shift_const (x, code, mode, ((x)->fld[0].rtx),
         ((((x)->fld[1].rtx))->fld[0].rtwint));


      else if (1 && ((((x)->fld[1].rtx))->code) != REG)
 do { rtx _new = (force_to_mode (((x)->fld[1].rtx), ((x)->mode), ((int) 1 << exact_log2_wide ((int) ((8 * mode_size[(int)(((x)->mode))])))) - 1, (rtx) 0, 0)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)




                      ;


      break;
    }

  return x;
}



static rtx
simplify_if_then_else(rtx x) asm("_simplify_if_then_else");
static rtx
simplify_if_then_else(rtx x)
{
  n64_enum_machine_mode mode = ((x)->mode);
  rtx cond = ((x)->fld[0].rtx);
  rtx cxx_true = ((x)->fld[1].rtx);
  rtx cxx_false = ((x)->fld[2].rtx);
  n64_enum_rtx_code true_code = ((cond)->code);
  int comparison_p = (rtx_class[(int)(true_code)]) == '<';
  rtx temp;
  int i;


  if (comparison_p && cxx_true == const_true_rtx && cxx_false == const0_rtx)
    return gen_binary (true_code, mode, ((cond)->fld[0].rtx), ((cond)->fld[1].rtx));


  if (comparison_p && reversible_comparison_p (cond)
      && cxx_true == const0_rtx && cxx_false == const_true_rtx)
    return gen_binary (reverse_condition (true_code),
         mode, ((cond)->fld[0].rtx), ((cond)->fld[1].rtx));





  if (comparison_p && reversible_comparison_p (cond)
      && ((((cond)->fld[0].rtx))->code) == REG)
    {
      int nzb;
      rtx from = ((cond)->fld[0].rtx);
      n64_enum_rtx_code false_code = reverse_condition (true_code);
      rtx true_val = ((cond)->fld[1].rtx);
      rtx false_val = true_val;
      int swapped = 0;



      if (false_code == EQ)
 {
   swapped = 1, true_code = EQ, false_code = NE;
   temp = cxx_true, cxx_true = cxx_false, cxx_false = temp;
 }





      if (true_code == EQ && true_val == const0_rtx
   && exact_log2_wide ((int) (nzb = nonzero_bits (from, ((from)->mode)))) >= 0)
 false_code = EQ, false_val = gen_rtx (CONST_INT, VOIDmode, (int) (nzb));
      else if (true_code == EQ && true_val == const0_rtx
        && (num_sign_bit_copies (from, ((from)->mode))
     == (8 * mode_size[(int)(((from)->mode))])))
 false_code = EQ, false_val = constm1_rtx;





      if (reg_mentioned_p (from, cxx_true))
 cxx_true = subst (known_cond (copy_rtx (cxx_true), true_code, from, true_val),
        pc_rtx, pc_rtx, 0, 0);
      if (reg_mentioned_p (from, cxx_false))
 cxx_false = subst (known_cond (copy_rtx (cxx_false), false_code,
       from, false_val),
         pc_rtx, pc_rtx, 0, 0);

      do { rtx _new = (swapped ? cxx_false : cxx_true); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
      do { rtx _new = (swapped ? cxx_true : cxx_false); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[2].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[2].rtx); ((x)->fld[2].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[2].rtx)) undobuf.num_undo++; } } while (0);

      cxx_true = ((x)->fld[1].rtx), cxx_false = ((x)->fld[2].rtx), true_code = ((cond)->code);
    }







  if (comparison_p && reversible_comparison_p (cond)
      && (cxx_true == pc_rtx
   || ((((cxx_true)->code) == LABEL_REF || ((cxx_true)->code) == SYMBOL_REF || ((cxx_true)->code) == CONST_INT || ((cxx_true)->code) == CONST_DOUBLE || ((cxx_true)->code) == CONST || ((cxx_true)->code) == HIGH)
       && ((cxx_false)->code) != CONST_INT && cxx_false != pc_rtx)
   || cxx_true == const0_rtx
   || ((rtx_class[(int)(((cxx_true)->code))]) == 'o'
       && (rtx_class[(int)(((cxx_false)->code))]) != 'o')
   || (((cxx_true)->code) == SUBREG
       && (rtx_class[(int)(((((cxx_true)->fld[0].rtx))->code))]) == 'o'
       && (rtx_class[(int)(((cxx_false)->code))]) != 'o')
   || reg_mentioned_p (cxx_true, cxx_false)
   || rtx_equal_p (cxx_false, ((cond)->fld[0].rtx))))
    {
      true_code = reverse_condition (true_code);
      do { rtx _new = (gen_binary (true_code, ((cond)->mode), ((cond)->fld[0].rtx), ((cond)->fld[1].rtx))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0)

                    ;

      do { rtx _new = (cxx_false); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
      do { rtx _new = (cxx_true); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[2].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[2].rtx); ((x)->fld[2].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[2].rtx)) undobuf.num_undo++; } } while (0);

      temp = cxx_true, cxx_true = cxx_false, cxx_false = temp, cond = ((x)->fld[0].rtx);
    }



  if (rtx_equal_p (cxx_true, cxx_false) && ! side_effects_p (cond))
    return cxx_true;



  if ((mode_class[(int)(mode)]) == MODE_INT
      && ((cxx_false)->code) == NEG
      && rtx_equal_p (cxx_true, ((cxx_false)->fld[0].rtx))
      && comparison_p
      && rtx_equal_p (cxx_true, ((cond)->fld[0].rtx))
      && ! side_effects_p (cxx_true))
    switch (true_code)
      {
      case GT:
      case GE:
 return gen_unary (ABS, mode, mode, cxx_true);
      case LT:
      case LE:
 return gen_unary (NEG, mode, mode, gen_unary (ABS, mode, mode, cxx_true));
      }



  if ((! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) || flag_fast_math)
      && comparison_p
      && rtx_equal_p (((cond)->fld[0].rtx), cxx_true)
      && rtx_equal_p (((cond)->fld[1].rtx), cxx_false)
      && ! side_effects_p (cond))
    switch (true_code)
      {
      case GE:
      case GT:
 return gen_binary (SMAX, mode, cxx_true, cxx_false);
      case LE:
      case LT:
 return gen_binary (SMIN, mode, cxx_true, cxx_false);
      case GEU:
      case GTU:
 return gen_binary (UMAX, mode, cxx_true, cxx_false);
      case LEU:
      case LTU:
 return gen_binary (UMIN, mode, cxx_true, cxx_false);
      }
  if (comparison_p && mode != VOIDmode && ! side_effects_p (x))
    {
      rtx t = make_compound_operation (cxx_true, SET);
      rtx f = make_compound_operation (cxx_false, SET);
      rtx cond_op0 = ((cond)->fld[0].rtx);
      rtx cond_op1 = ((cond)->fld[1].rtx);
      n64_enum_rtx_code op, extend_op = NIL;
      n64_enum_machine_mode m = mode;
      rtx z = 0, c1;

      if ((((t)->code) == PLUS || ((t)->code) == MINUS
    || ((t)->code) == IOR || ((t)->code) == XOR
    || ((t)->code) == ASHIFT
    || ((t)->code) == LSHIFTRT || ((t)->code) == ASHIFTRT)
   && rtx_equal_p (((t)->fld[0].rtx), f))
 c1 = ((t)->fld[1].rtx), op = ((t)->code), z = f;



      else if ((((t)->code) == PLUS || ((t)->code) == IOR
  || ((t)->code) == XOR)
        && rtx_equal_p (((t)->fld[1].rtx), f))
 c1 = ((t)->fld[0].rtx), op = ((t)->code), z = f;
      else if (((t)->code) == SIGN_EXTEND
        && (((((t)->fld[0].rtx))->code) == PLUS
     || ((((t)->fld[0].rtx))->code) == MINUS
     || ((((t)->fld[0].rtx))->code) == IOR
     || ((((t)->fld[0].rtx))->code) == XOR
     || ((((t)->fld[0].rtx))->code) == ASHIFT
     || ((((t)->fld[0].rtx))->code) == LSHIFTRT
     || ((((t)->fld[0].rtx))->code) == ASHIFTRT)
        && ((((((t)->fld[0].rtx))->fld[0].rtx))->code) == SUBREG
        && subreg_lowpart_p (((((t)->fld[0].rtx))->fld[0].rtx))
        && rtx_equal_p (((((((t)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx), f)
        && (num_sign_bit_copies (f, ((f)->mode))
     > ((8 * mode_size[(int)(mode)])
        - (8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[0].rtx))->mode))]))))
 {
   c1 = ((((t)->fld[0].rtx))->fld[1].rtx); z = f; op = ((((t)->fld[0].rtx))->code);
   extend_op = SIGN_EXTEND;
   m = ((((t)->fld[0].rtx))->mode);
 }
      else if (((t)->code) == SIGN_EXTEND
        && (((((t)->fld[0].rtx))->code) == PLUS
     || ((((t)->fld[0].rtx))->code) == IOR
     || ((((t)->fld[0].rtx))->code) == XOR)
        && ((((((t)->fld[0].rtx))->fld[1].rtx))->code) == SUBREG
        && subreg_lowpart_p (((((t)->fld[0].rtx))->fld[1].rtx))
        && rtx_equal_p (((((((t)->fld[0].rtx))->fld[1].rtx))->fld[0].rtx), f)
        && (num_sign_bit_copies (f, ((f)->mode))
     > ((8 * mode_size[(int)(mode)])
        - (8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[1].rtx))->mode))]))))
 {
   c1 = ((((t)->fld[0].rtx))->fld[0].rtx); z = f; op = ((((t)->fld[0].rtx))->code);
   extend_op = SIGN_EXTEND;
   m = ((((t)->fld[0].rtx))->mode);
 }
      else if (((t)->code) == ZERO_EXTEND
        && (((((t)->fld[0].rtx))->code) == PLUS
     || ((((t)->fld[0].rtx))->code) == MINUS
     || ((((t)->fld[0].rtx))->code) == IOR
     || ((((t)->fld[0].rtx))->code) == XOR
     || ((((t)->fld[0].rtx))->code) == ASHIFT
     || ((((t)->fld[0].rtx))->code) == LSHIFTRT
     || ((((t)->fld[0].rtx))->code) == ASHIFTRT)
        && ((((((t)->fld[0].rtx))->fld[0].rtx))->code) == SUBREG
        && (8 * mode_size[(int)(mode)]) <= 32
        && subreg_lowpart_p (((((t)->fld[0].rtx))->fld[0].rtx))
        && rtx_equal_p (((((((t)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx), f)
        && ((nonzero_bits (f, ((f)->mode))
      & ~ (((8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[0].rtx))->mode))])) - 1)))
     == 0))
 {
   c1 = ((((t)->fld[0].rtx))->fld[1].rtx); z = f; op = ((((t)->fld[0].rtx))->code);
   extend_op = ZERO_EXTEND;
   m = ((((t)->fld[0].rtx))->mode);
 }
      else if (((t)->code) == ZERO_EXTEND
        && (((((t)->fld[0].rtx))->code) == PLUS
     || ((((t)->fld[0].rtx))->code) == IOR
     || ((((t)->fld[0].rtx))->code) == XOR)
        && ((((((t)->fld[0].rtx))->fld[1].rtx))->code) == SUBREG
        && (8 * mode_size[(int)(mode)]) <= 32
        && subreg_lowpart_p (((((t)->fld[0].rtx))->fld[1].rtx))
        && rtx_equal_p (((((((t)->fld[0].rtx))->fld[1].rtx))->fld[0].rtx), f)
        && ((nonzero_bits (f, ((f)->mode))
      & ~ (((8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[1].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((((t)->fld[0].rtx))->fld[1].rtx))->mode))])) - 1)))
     == 0))
 {
   c1 = ((((t)->fld[0].rtx))->fld[0].rtx); z = f; op = ((((t)->fld[0].rtx))->code);
   extend_op = ZERO_EXTEND;
   m = ((((t)->fld[0].rtx))->mode);
 }

      if (z)
 {
   temp = subst (gen_binary (true_code, m, cond_op0, cond_op1),
   pc_rtx, pc_rtx, 0, 0);
   temp = gen_binary (MULT, m, temp,
        gen_binary (MULT, m, c1, const_true_rtx));
   temp = subst (temp, pc_rtx, pc_rtx, 0, 0);
   temp = gen_binary (op, m, gen_lowpart_for_combine (m, z), temp);

   if (extend_op != NIL)
     temp = gen_unary (extend_op, mode, m, temp);

   return temp;
 }
    }







  if (true_code == NE && ((cond)->fld[1].rtx) == const0_rtx
      && cxx_false == const0_rtx && ((cxx_true)->code) == CONST_INT
      && ((1 == nonzero_bits (((cond)->fld[0].rtx), mode)
    && (i = exact_log2_wide ((int) (((cxx_true)->fld[0].rtwint)))) >= 0)
   || ((num_sign_bit_copies (((cond)->fld[0].rtx), mode)
        == (8 * mode_size[(int)(mode)]))
       && (i = exact_log2_wide ((int) (- ((cxx_true)->fld[0].rtwint)))) >= 0)))
    return
      simplify_shift_const ((rtx) 0, ASHIFT, mode,
       gen_lowpart_for_combine (mode, ((cond)->fld[0].rtx)), i);

  return x;
}



static rtx
simplify_set(rtx x) asm("_simplify_set");
static rtx
simplify_set(rtx x)
{
  rtx src = ((x)->fld[1].rtx);
  rtx dest = ((x)->fld[0].rtx);
  n64_enum_machine_mode mode
    = ((src)->mode) != VOIDmode ? ((src)->mode) : ((dest)->mode);
  rtx other_insn;
  rtx *cc_use;


  if (((dest)->code) == PC && ((src)->code) == RETURN)
    return src;





  if ((mode_class[(int)(mode)]) == MODE_INT)
    src = force_to_mode (src, mode, (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)), (rtx) 0, 0);




  if ((((src)->code) == COMPARE



       )
      && (cc_use = find_single_use (dest, subst_insn, &other_insn)) != 0
      && (undobuf.other_insn == 0 || other_insn == undobuf.other_insn)
      && (rtx_class[(int)(((*cc_use)->code))]) == '<'
      && rtx_equal_p (((*cc_use)->fld[0].rtx), dest))
    {
      n64_enum_rtx_code old_code = ((*cc_use)->code);
      n64_enum_rtx_code new_code;
      rtx op0, op1;
      int other_changed = 0;
      n64_enum_machine_mode compare_mode = ((dest)->mode);

      if (((src)->code) == COMPARE)
 op0 = ((src)->fld[0].rtx), op1 = ((src)->fld[1].rtx);
      else
 op0 = src, op1 = const0_rtx;


      new_code = simplify_comparison (old_code, &op0, &op1);




      compare_mode = ((mode_class[(int)(((op0)->mode))]) != MODE_FLOAT ? SImode : ((new_code == NE) ? CC_REV_FPmode : CC_FPmode));
      if (compare_mode != ((dest)->mode))
 {
   int regno = ((dest)->fld[0].rtint);
   rtx new_dest = gen_rtx (REG, compare_mode, regno);

   if (regno < 68
       || (reg_n_sets[regno] == 1 && ! ((dest)->volatil)))
     {
       if (regno >= 68)
  do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &regno_reg_rtx[regno]; undobuf.undo[undobuf.num_undo].old_contents.r = regno_reg_rtx[regno]; regno_reg_rtx[regno] = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != regno_reg_rtx[regno]) undobuf.num_undo++; } } while (0);

       do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
       do { rtx _new = (new_dest); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((*cc_use)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((*cc_use)->fld[0].rtx); ((*cc_use)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((*cc_use)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
       other_changed = 1;

       dest = new_dest;
     }
 }




      if (new_code != old_code)
 {
   unsigned int mask;

   do { rtx _new = (gen_rtx_combine (new_code, ((*cc_use)->mode), dest, const0_rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &*cc_use; undobuf.undo[undobuf.num_undo].old_contents.r = *cc_use; *cc_use = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != *cc_use) undobuf.num_undo++; } } while (0)
                          ;







   if (((old_code == NE && new_code == EQ)
        || (old_code == EQ && new_code == NE))
       && ! other_changed && op1 == const0_rtx
       && (8 * mode_size[(int)(((op0)->mode))]) <= 32
       && exact_log2_wide ((int) (mask = nonzero_bits (op0, ((op0)->mode)))) >= 0)
     {
       rtx pat = ((other_insn)->fld[3].rtx), note = 0;
       int scratches;

       if ((recog_for_combine (&pat, other_insn, &note, &scratches) < 0
     && ! check_asm_operands (pat)))
  {
    ((*cc_use)->code = (old_code));
    other_insn = 0;

    op0 = gen_binary (XOR, ((op0)->mode), op0, gen_rtx (CONST_INT, VOIDmode, (int) (mask)));
  }
     }

   other_changed = 1;
 }

      if (other_changed)
 undobuf.other_insn = other_insn;
      if (((src)->code) != COMPARE || ((src)->mode) != compare_mode)
 {
   do { rtx _new = (gen_rtx_combine (COMPARE, compare_mode, op0, op1)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)
                                                     ;
   src = ((x)->fld[1].rtx);
 }
      else
 {

   do { rtx _new = (op0); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((src)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((src)->fld[0].rtx); ((src)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((src)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
   do { rtx _new = (op1); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((src)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((src)->fld[1].rtx); ((src)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((src)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
 }
    }
  else
    {


      src = make_compound_operation (src, SET);
      do { rtx _new = (src); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
    }
  if (((src)->code) == SUBREG && subreg_lowpart_p (src)
      && (rtx_class[(int)(((((src)->fld[0].rtx))->code))]) != 'o'
      && ((((mode_size[(int)(((src)->mode))]) + (((target_flags & 0x00002000) ? 8 : 4) - 1))
    / ((target_flags & 0x00002000) ? 8 : 4))
   == (((mode_size[(int)(((((src)->fld[0].rtx))->mode))])
        + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4)))
      && (((dest)->code) == REG
   || (((dest)->code) == SUBREG
       && ((((dest)->fld[0].rtx))->code) == REG)))
    {
      do { rtx _new = (gen_lowpart_for_combine (((((src)->fld[0].rtx))->mode), dest)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0)

                ;
      do { rtx _new = (((src)->fld[0].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);

      src = ((x)->fld[1].rtx), dest = ((x)->fld[0].rtx);
    }






  if (((src)->code) == SUBREG && subreg_lowpart_p (src)
      && ZERO_EXTEND != NIL
      && ((src)->fld[1].rtint) == 0
      && ((mode_size[(int)(((src)->mode))])
   > (mode_size[(int)(((((src)->fld[0].rtx))->mode))]))
      && ((((src)->fld[0].rtx))->code) == MEM)
    {
      do { rtx _new = (gen_rtx_combine (ZERO_EXTEND, ((src)->mode), ((src)->fld[0].rtx))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)

                                        ;

      src = ((x)->fld[1].rtx);
    }
  if (((dest)->code) != PC
      && ((src)->code) == IF_THEN_ELSE
      && (mode_class[(int)(((src)->mode))]) == MODE_INT
      && (((((src)->fld[0].rtx))->code) == EQ || ((((src)->fld[0].rtx))->code) == NE)
      && ((((src)->fld[0].rtx))->fld[1].rtx) == const0_rtx
      && ((src)->mode) == ((((((src)->fld[0].rtx))->fld[0].rtx))->mode)

      && ! can_conditionally_move_p (((src)->mode))

      && (num_sign_bit_copies (((((src)->fld[0].rtx))->fld[0].rtx),
          ((((((src)->fld[0].rtx))->fld[0].rtx))->mode))
   == (8 * mode_size[(int)(((((((src)->fld[0].rtx))->fld[0].rtx))->mode))]))
      && ! side_effects_p (src))
    {
      rtx cxx_true = (((((src)->fld[0].rtx))->code) == NE
        ? ((src)->fld[1].rtx) : ((src)->fld[2].rtx));
      rtx cxx_false = (((((src)->fld[0].rtx))->code) == NE
     ? ((src)->fld[2].rtx) : ((src)->fld[1].rtx));
      rtx term1 = const0_rtx, term2, term3;

      if (((cxx_true)->code) == IOR && rtx_equal_p (((cxx_true)->fld[0].rtx), cxx_false))
 term1 = cxx_false, cxx_true = ((cxx_true)->fld[1].rtx), cxx_false = const0_rtx;
      else if (((cxx_true)->code) == IOR
        && rtx_equal_p (((cxx_true)->fld[1].rtx), cxx_false))
 term1 = cxx_false, cxx_true = ((cxx_true)->fld[0].rtx), cxx_false = const0_rtx;
      else if (((cxx_false)->code) == IOR
        && rtx_equal_p (((cxx_false)->fld[0].rtx), cxx_true))
 term1 = cxx_true, cxx_false = ((cxx_false)->fld[1].rtx), cxx_true = const0_rtx;
      else if (((cxx_false)->code) == IOR
        && rtx_equal_p (((cxx_false)->fld[1].rtx), cxx_true))
 term1 = cxx_true, cxx_false = ((cxx_false)->fld[0].rtx), cxx_true = const0_rtx;

      term2 = gen_binary (AND, ((src)->mode), ((((src)->fld[0].rtx))->fld[0].rtx), cxx_true);
      term3 = gen_binary (AND, ((src)->mode),
     gen_unary (NOT, ((src)->mode), ((src)->mode),
         ((((src)->fld[0].rtx))->fld[0].rtx)),
     cxx_false);

      do { rtx _new = (gen_binary (IOR, ((src)->mode), gen_binary (IOR, ((src)->mode), term1, term2), term3)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)


           ;

      src = ((x)->fld[1].rtx);
    }



  if (((src)->code) == CLOBBER && ((src)->fld[0].rtx) == const0_rtx)
    return src;
  else if (((dest)->code) == CLOBBER && ((dest)->fld[0].rtx) == const0_rtx)
    return dest;
  else

    return make_field_assignment (x);
}




static rtx
simplify_logical(rtx x, int last) asm("_simplify_logical");
static rtx
simplify_logical(rtx x, int last)
{
  n64_enum_machine_mode mode = ((x)->mode);
  rtx op0 = ((x)->fld[0].rtx);
  rtx op1 = ((x)->fld[1].rtx);

  switch (((x)->code))
    {
    case AND:


      if (((op0)->code) == XOR
   && rtx_equal_p (((op0)->fld[0].rtx), op1)
   && ! side_effects_p (op1))
 x = gen_binary (AND, mode,
   gen_unary (NOT, mode, mode, ((op0)->fld[1].rtx)), op1);

      if (((op0)->code) == XOR
   && rtx_equal_p (((op0)->fld[1].rtx), op1)
   && ! side_effects_p (op1))
 x = gen_binary (AND, mode,
   gen_unary (NOT, mode, mode, ((op0)->fld[0].rtx)), op1);


      if (((op0)->code) == NOT
   && ((((op0)->fld[0].rtx))->code) == XOR
   && rtx_equal_p (((((op0)->fld[0].rtx))->fld[0].rtx), op1)
   && ! side_effects_p (op1))
 x = gen_binary (AND, mode, ((((op0)->fld[0].rtx))->fld[1].rtx), op1);

      if (((op0)->code) == NOT
   && ((((op0)->fld[0].rtx))->code) == XOR
   && rtx_equal_p (((((op0)->fld[0].rtx))->fld[1].rtx), op1)
   && ! side_effects_p (op1))
 x = gen_binary (AND, mode, ((((op0)->fld[0].rtx))->fld[0].rtx), op1);

      if (((op1)->code) == CONST_INT)
 {
   x = simplify_and_const_int (x, mode, op0, ((op1)->fld[0].rtwint));




   if (last
       && ((x)->code) == IOR && ((op0)->code) == AND
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((op1)->code) == CONST_INT)
     return gen_binary (IOR, mode,
          gen_binary (AND, mode, ((op0)->fld[0].rtx),
        gen_rtx (CONST_INT, VOIDmode, (int) (((((op0)->fld[1].rtx))->fld[0].rtwint) & ~ ((op1)->fld[0].rtwint)))
                           ), op1);

   if (((x)->code) != AND)
     return x;

   if ((rtx_class[(int)(((x)->code))]) == 'c'
       || (rtx_class[(int)(((x)->code))]) == '2')
     op0 = ((x)->fld[0].rtx), op1 = ((x)->fld[1].rtx);
 }


      if (((op0)->code) == IOR
   && (rtx_equal_p (((op0)->fld[0].rtx), op1)
       || rtx_equal_p (((op0)->fld[1].rtx), op1))
   && ! side_effects_p (((op0)->fld[0].rtx))
   && ! side_effects_p (((op0)->fld[1].rtx)))
 return op1;
      if (((op0)->code) == IOR || ((op0)->code) == XOR)
 {
   x = apply_distributive_law
     (gen_binary (((op0)->code), mode,
    gen_binary (AND, mode, ((op0)->fld[0].rtx), op1),
    gen_binary (AND, mode, ((op0)->fld[1].rtx), op1)));
   if (((x)->code) != AND)
     return x;
 }

      if (((op1)->code) == IOR || ((op1)->code) == XOR)
 return apply_distributive_law
   (gen_binary (((op1)->code), mode,
         gen_binary (AND, mode, ((op1)->fld[0].rtx), op0),
         gen_binary (AND, mode, ((op1)->fld[1].rtx), op0)));




      if (((op0)->code) == NOT && ((op1)->code) == XOR)
 return apply_distributive_law
   (gen_binary (XOR, mode,
         gen_binary (IOR, mode, ((op0)->fld[0].rtx), ((op1)->fld[0].rtx)),
         gen_binary (IOR, mode, ((op0)->fld[0].rtx), ((op1)->fld[1].rtx))));

      else if (((op1)->code) == NOT && ((op0)->code) == XOR)
 return apply_distributive_law
   (gen_binary (XOR, mode,
         gen_binary (IOR, mode, ((op1)->fld[0].rtx), ((op0)->fld[0].rtx)),
         gen_binary (IOR, mode, ((op1)->fld[0].rtx), ((op0)->fld[1].rtx))));
      break;

    case IOR:

      if (((op1)->code) == CONST_INT
   && (8 * mode_size[(int)(mode)]) <= 32
   && (nonzero_bits (op0, mode) & ~ ((op1)->fld[0].rtwint)) == 0)
 return op1;


      if (((op0)->code) == AND
   && (rtx_equal_p (((op0)->fld[0].rtx), op1)
       || rtx_equal_p (((op0)->fld[1].rtx), op1))
   && ! side_effects_p (((op0)->fld[0].rtx))
   && ! side_effects_p (((op0)->fld[1].rtx)))
 return op1;




      if (((op0)->code) == AND)
 {
   x = apply_distributive_law
     (gen_binary (AND, mode,
    gen_binary (IOR, mode, ((op0)->fld[0].rtx), op1),
    gen_binary (IOR, mode, ((op0)->fld[1].rtx), op1)));

   if (((x)->code) != IOR)
     return x;
 }

      if (((op1)->code) == AND)
 {
   x = apply_distributive_law
     (gen_binary (AND, mode,
    gen_binary (IOR, mode, ((op1)->fld[0].rtx), op0),
    gen_binary (IOR, mode, ((op1)->fld[1].rtx), op0)));

   if (((x)->code) != IOR)
     return x;
 }




      if (((((op0)->code) == ASHIFT && ((op1)->code) == LSHIFTRT)
    || (((op1)->code) == ASHIFT && ((op0)->code) == LSHIFTRT))
   && rtx_equal_p (((op0)->fld[0].rtx), ((op1)->fld[0].rtx))
   && ((((op0)->fld[1].rtx))->code) == CONST_INT
   && ((((op1)->fld[1].rtx))->code) == CONST_INT
   && (((((op0)->fld[1].rtx))->fld[0].rtwint) + ((((op1)->fld[1].rtx))->fld[0].rtwint)
       == (8 * mode_size[(int)(mode)])))
 return gen_rtx (ROTATE, mode, ((op0)->fld[0].rtx),
   (((op0)->code) == ASHIFT
    ? ((op0)->fld[1].rtx) : ((op1)->fld[1].rtx)));






      if (((op1)->code) == CONST_INT && ((op0)->code) == ASHIFTRT
   && ((((op0)->fld[0].rtx))->code) == PLUS
   && ((((((op0)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((op0)->fld[1].rtx))->code) == CONST_INT
   && ((((op0)->fld[1].rtx))->fld[0].rtwint) < 32)
 {
   int count = ((((op0)->fld[1].rtx))->fld[0].rtwint);
   int mask = ((op1)->fld[0].rtwint) << count;

   if (mask >> count == ((op1)->fld[0].rtwint)
       && (mask & nonzero_bits (((op0)->fld[0].rtx), mode)) == 0)
     {
       do { rtx _new = (gen_rtx (CONST_INT, VOIDmode, (int) (((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) | mask))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((((op0)->fld[0].rtx))->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((((op0)->fld[0].rtx))->fld[1].rtx); ((((op0)->fld[0].rtx))->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((((op0)->fld[0].rtx))->fld[1].rtx)) undobuf.num_undo++; } } while (0)
                                                         ;
       return op0;
     }
 }
      break;

    case XOR:



      {
 int num_negated = 0;

 if (((op0)->code) == NOT)
   num_negated++, op0 = ((op0)->fld[0].rtx);
 if (((op1)->code) == NOT)
   num_negated++, op1 = ((op1)->fld[0].rtx);

 if (num_negated == 2)
   {
     do { rtx _new = (op0); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
     do { rtx _new = (op1); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
   }
 else if (num_negated == 1)
   return gen_unary (NOT, mode, mode, gen_binary (XOR, mode, op0, op1));
      }





      if (((op0)->code) == AND
   && rtx_equal_p (((op0)->fld[1].rtx), op1)
   && ! side_effects_p (op1))
 return gen_binary (AND, mode,
      gen_unary (NOT, mode, mode, ((op0)->fld[0].rtx)),
      op1);

      else if (((op0)->code) == AND
        && rtx_equal_p (((op0)->fld[0].rtx), op1)
        && ! side_effects_p (op1))
 return gen_binary (AND, mode,
      gen_unary (NOT, mode, mode, ((op0)->fld[1].rtx)),
      op1);




      if (op1 == const1_rtx
   && (rtx_class[(int)(((op0)->code))]) == '<'
   && reversible_comparison_p (op0))
 return gen_rtx_combine (reverse_condition (((op0)->code)),
    mode, ((op0)->fld[0].rtx), ((op0)->fld[1].rtx));





      if (op1 == const1_rtx
   && ((op0)->code) == LSHIFTRT
   && ((((op0)->fld[1].rtx))->code) == CONST_INT
   && ((((op0)->fld[1].rtx))->fld[0].rtwint) == (8 * mode_size[(int)(mode)]) - 1)
 return gen_rtx_combine (GE, mode, ((op0)->fld[0].rtx), const0_rtx);




      if ((8 * mode_size[(int)(mode)]) <= 32
   && (1
       == (int) 1 << ((8 * mode_size[(int)(mode)]) - 1))
   && op1 == const_true_rtx
   && (rtx_class[(int)(((op0)->code))]) == '<'
   && reversible_comparison_p (op0))
 return gen_rtx_combine (reverse_condition (((op0)->code)),
    mode, ((op0)->fld[0].rtx), ((op0)->fld[1].rtx));
      break;
    }

  return x;
}
static rtx
expand_compound_operation(rtx x) asm("_expand_compound_operation");
static rtx
expand_compound_operation(rtx x)
{
  int pos = 0, len;
  int unsignedp = 0;
  int modewidth;
  rtx tem;

  switch (((x)->code))
    {
    case ZERO_EXTEND:
      unsignedp = 1;
    case SIGN_EXTEND:
      if (((((x)->fld[0].rtx))->code) == CONST_INT)
 return x;
      if ((mode_size[(int)(((((x)->fld[0].rtx))->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 return x;

      len = (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]);



      if (len == 0)
 return x;

      break;

    case ZERO_EXTRACT:
      unsignedp = 1;
    case SIGN_EXTRACT:

      if (((((x)->fld[0].rtx))->code) == CLOBBER)
 return ((x)->fld[0].rtx);

      if (((((x)->fld[1].rtx))->code) != CONST_INT
   || ((((x)->fld[2].rtx))->code) != CONST_INT
   || ((((x)->fld[0].rtx))->mode) == VOIDmode)
 return x;

      len = ((((x)->fld[1].rtx))->fld[0].rtwint);
      pos = ((((x)->fld[2].rtx))->fld[0].rtwint);




      if (len + pos > (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
 do { rtx _new = (gen_rtx (USE, ((x)->mode), ((x)->fld[0].rtx))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);

      if (0)
 pos = (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - len - pos;

      break;

    default:
      return x;
    }
  modewidth = (8 * mode_size[(int)(((x)->mode))]);
  if (modewidth >= pos - len)
    tem = simplify_shift_const ((rtx) 0, unsignedp ? LSHIFTRT : ASHIFTRT,
    ((x)->mode),
    simplify_shift_const ((rtx) 0, ASHIFT,
            ((x)->mode),
            ((x)->fld[0].rtx),
            modewidth - pos - len),
    modewidth - len);

  else if (unsignedp && len < 32)
    tem = simplify_and_const_int ((rtx) 0, ((x)->mode),
      simplify_shift_const ((rtx) 0, LSHIFTRT,
       ((x)->mode),
       ((x)->fld[0].rtx), pos),
      ((int) 1 << len) - 1);
  else

    return x;




  if (((tem)->code) == CLOBBER)
    return x;

  return tem;
}
static rtx
expand_field_assignment(rtx x) asm("_expand_field_assignment");
static rtx
expand_field_assignment(rtx x)
{
  rtx inner;
  rtx pos;
  int len;
  rtx mask;
  n64_enum_machine_mode compute_mode;


  while (1)
    {
      if (((((x)->fld[0].rtx))->code) == STRICT_LOW_PART
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == SUBREG)
 {
   inner = ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx);
   len = (8 * mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))]);
   pos = const0_rtx;
 }
      else if (((((x)->fld[0].rtx))->code) == ZERO_EXTRACT
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT)
 {
   inner = ((((x)->fld[0].rtx))->fld[0].rtx);
   len = ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint);
   pos = ((((x)->fld[0].rtx))->fld[2].rtx);



   if (((pos)->code) == CONST_INT
       && ((pos)->fld[0].rtwint) + len > (8 * mode_size[(int)(((inner)->mode))]))
     inner = gen_rtx (USE, ((((x)->fld[0].rtx))->mode), inner);

   if (0)
     {
       if (((pos)->code) == CONST_INT)
  pos = gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(((inner)->mode))]) - len - ((pos)->fld[0].rtwint)))
                         ;
       else if (((pos)->code) == MINUS
         && ((((pos)->fld[1].rtx))->code) == CONST_INT
         && (((((pos)->fld[1].rtx))->fld[0].rtwint)
      == (8 * mode_size[(int)(((inner)->mode))]) - len))

  pos = ((pos)->fld[0].rtx);
       else
  pos = gen_binary (MINUS, ((pos)->mode),
      gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(((inner)->mode))]) - len))
              ,
      pos);
     }
 }



      else if (((((x)->fld[0].rtx))->code) == SUBREG
        && ((((mode_size[(int)(((((x)->fld[0].rtx))->mode))])
       + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))
     == (((mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))])
   + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))))
 {
   x = gen_rtx (SET, VOIDmode, ((((x)->fld[0].rtx))->fld[0].rtx),
         gen_lowpart_for_combine (((((((x)->fld[0].rtx))->fld[0].rtx))->mode),
      ((x)->fld[1].rtx)));
   continue;
 }
      else
 break;

      while (((inner)->code) == SUBREG && subreg_lowpart_p (inner))
 inner = ((inner)->fld[0].rtx);

      compute_mode = ((inner)->mode);


      if (len < 32)
 mask = gen_rtx (CONST_INT, VOIDmode, (int) (((int) 1 << len) - 1));
      else
 break;




      x = gen_rtx (SET, VOIDmode, copy_rtx (inner),
     gen_binary (IOR, compute_mode,
          gen_binary (AND, compute_mode,
        gen_unary (NOT, compute_mode,
            compute_mode,
            gen_binary (ASHIFT,
          compute_mode,
          mask, pos)),
        inner),
          gen_binary (ASHIFT, compute_mode,
        gen_binary (AND, compute_mode,
             gen_lowpart_for_combine
             (compute_mode,
       ((x)->fld[1].rtx)),
             mask),
        pos)));
    }

  return x;
}
static rtx
make_extraction(n64_enum_machine_mode mode, rtx inner, int pos, rtx pos_rtx, int len, int unsignedp, int in_dest, int in_compare) asm("_make_extraction");
static rtx
make_extraction(n64_enum_machine_mode mode, rtx inner, int pos, rtx pos_rtx, int len, int unsignedp, int in_dest, int in_compare)
{



  n64_enum_machine_mode is_mode = ((inner)->mode);
  n64_enum_machine_mode inner_mode;
  n64_enum_machine_mode wanted_mem_mode = byte_mode;
  n64_enum_machine_mode pos_mode = word_mode;
  n64_enum_machine_mode extraction_mode = word_mode;
  n64_enum_machine_mode tmode = mode_for_size (len, MODE_INT, 1);
  int spans_byte = 0;
  rtx cxx_new = 0;
  rtx orig_pos_rtx = pos_rtx;
  int orig_pos;


  if (((inner)->code) == USE)



    spans_byte = 1, inner = ((inner)->fld[0].rtx);
  else if (((inner)->code) == SUBREG && subreg_lowpart_p (inner))
    {





      if (((((inner)->fld[0].rtx))->code) == MEM)
 is_mode = ((((inner)->fld[0].rtx))->mode);
      inner = ((inner)->fld[0].rtx);
    }

  inner_mode = ((inner)->mode);

  if (pos_rtx && ((pos_rtx)->code) == CONST_INT)
    pos = ((pos_rtx)->fld[0].rtwint), pos_rtx = 0;
  if (tmode != BLKmode
      && ! (spans_byte && inner_mode != tmode)
      && ((pos_rtx == 0 && pos == 0 && ((inner)->code) != MEM
    && (! in_dest
        || (((inner)->code) == REG
     && (movstrict_optab->handlers[(int) tmode].insn_code
         != CODE_FOR_nothing))))
   || (((inner)->code) == MEM && pos_rtx == 0
       && (pos
    % (1 ? ((64) < (((1) > (((mode_unit_size[(int)(tmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(tmode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(tmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(tmode)]) * 8)))))
       : 8)) == 0


       && (8 * mode_size[(int)(inner_mode)]) >= (8 * mode_size[(int)(tmode)])
       && (inner_mode == tmode
    || (! mode_dependent_address_p (((inner)->fld[0].rtx))
        && ! ((inner)->volatil))))))
    {







      if (((inner)->code) == MEM)
 {
   int offset;

   if (((target_flags & 0x00010000) != 0))
     offset = ((8 * mode_size[(int)(is_mode)]) - len - pos) / 8;
   else
     offset = pos / 8;

   cxx_new = gen_rtx (MEM, tmode, plus_constant_wide (((inner)->fld[0].rtx), (int) (offset)));
   ((cxx_new)->unchanging) = ((inner)->unchanging);
   ((cxx_new)->volatil) = ((inner)->volatil);
   ((cxx_new)->in_struct) = ((inner)->in_struct);
 }
      else if (((inner)->code) == REG)
 {


   if (tmode != inner_mode)
     cxx_new = gen_rtx (SUBREG, tmode, inner,
      (((target_flags & 0x00010000) != 0)
       && (mode_size[(int)(inner_mode)]) > ((target_flags & 0x00002000) ? 8 : 4)
       ? (((mode_size[(int)(inner_mode)])
    - (mode_size[(int)(tmode)]))
          / ((target_flags & 0x00002000) ? 8 : 4))
       : 0));
   else
     cxx_new = inner;
 }
      else
 cxx_new = force_to_mode (inner, tmode,
        len >= 32
        ? (((8 * mode_size[(int)(tmode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(tmode)])) - 1))
        : ((int) 1 << len) - 1,
        (rtx) 0, 0);




      if (in_dest)
 return (((cxx_new)->code) == MEM ? cxx_new
  : (((cxx_new)->code) != SUBREG
     ? gen_rtx (CLOBBER, tmode, const0_rtx)
     : gen_rtx_combine (STRICT_LOW_PART, VOIDmode, cxx_new)));




      return (mode == tmode ? cxx_new
       : gen_rtx_combine (unsignedp ? ZERO_EXTEND : SIGN_EXTEND,
     mode, cxx_new));
    }




  if (pos_rtx == 0 && pos == 0 && ! in_dest
      && ! in_compare && ! spans_byte && unsignedp)
    return 0;






  if (! spans_byte
      && ((pos_rtx == 0 && pos + len > (8 * mode_size[(int)(is_mode)]))
   || (pos_rtx != 0 && len != 1)))
    return 0;




  if (in_dest)
    {
      wanted_mem_mode = insn_operand_mode[(int) CODE_FOR_insv][0];
      pos_mode = insn_operand_mode[(int) CODE_FOR_insv][2];
      extraction_mode = insn_operand_mode[(int) CODE_FOR_insv][3];
    }



  if (! in_dest && unsignedp)
    {
      wanted_mem_mode = insn_operand_mode[(int) CODE_FOR_extzv][1];
      pos_mode = insn_operand_mode[(int) CODE_FOR_extzv][3];
      extraction_mode = insn_operand_mode[(int) CODE_FOR_extzv][0];
    }



  if (! in_dest && ! unsignedp)
    {
      wanted_mem_mode = insn_operand_mode[(int) CODE_FOR_extv][1];
      pos_mode = insn_operand_mode[(int) CODE_FOR_extv][3];
      extraction_mode = insn_operand_mode[(int) CODE_FOR_extv][0];
    }




  if (mode != VOIDmode
      && (mode_size[(int)(extraction_mode)]) < (mode_size[(int)(mode)]))
    extraction_mode = mode;

  if (pos_rtx && ((pos_rtx)->mode) != VOIDmode
      && (mode_size[(int)(pos_mode)]) < (mode_size[(int)(((pos_rtx)->mode))]))
    pos_mode = ((pos_rtx)->mode);



  if (((inner)->code) != MEM
      || (inner_mode != wanted_mem_mode
   && (mode_dependent_address_p (((inner)->fld[0].rtx))
       || ((inner)->volatil))))
    wanted_mem_mode = extraction_mode;

  orig_pos = pos;

  if (0)
    {


      if (pos_rtx == 0)
 pos = ((((8 * mode_size[(int)(is_mode)])) > ((8 * mode_size[(int)(wanted_mem_mode)])) ? ((8 * mode_size[(int)(is_mode)])) : ((8 * mode_size[(int)(wanted_mem_mode)])))

        - len - pos);
      else
 pos_rtx
   = gen_rtx_combine (MINUS, ((pos_rtx)->mode),
        gen_rtx (CONST_INT, VOIDmode, (int) ((((8 * mode_size[(int)(is_mode)])) > ((8 * mode_size[(int)(wanted_mem_mode)])) ? ((8 * mode_size[(int)(is_mode)])) : ((8 * mode_size[(int)(wanted_mem_mode)]))) - len))

                ,
        pos_rtx);
    }




  if (wanted_mem_mode != VOIDmode
      && (mode_size[(int)(wanted_mem_mode)]) < (mode_size[(int)(is_mode)])
      && ((((inner)->code) == MEM
    && (inner_mode == wanted_mem_mode
        || (! mode_dependent_address_p (((inner)->fld[0].rtx))
     && ! ((inner)->volatil))))))
    {
      int offset = 0;







      if (((target_flags & 0x00010000) != 0)
   && ! spans_byte
   && (mode_size[(int)(inner_mode)]) < (mode_size[(int)(is_mode)]))
 offset -= (mode_size[(int)(is_mode)]) - (mode_size[(int)(inner_mode)]);


      if (pos_rtx == 0)
 {
   offset += pos / 8;
   pos %= (8 * mode_size[(int)(wanted_mem_mode)]);
 }

      if (((target_flags & 0x00010000) != 0) != 0
   && ! spans_byte
   && is_mode != wanted_mem_mode)
 offset = ((mode_size[(int)(is_mode)])
    - (mode_size[(int)(wanted_mem_mode)]) - offset);

      if (offset != 0 || inner_mode != wanted_mem_mode)
 {
   rtx newmem = gen_rtx (MEM, wanted_mem_mode,
    plus_constant_wide (((inner)->fld[0].rtx), (int) (offset)));
   ((newmem)->unchanging) = ((inner)->unchanging);
   ((newmem)->volatil) = ((inner)->volatil);
   ((newmem)->in_struct) = ((inner)->in_struct);
   inner = newmem;
 }
    }


  else if (((inner)->code) != MEM)
    inner = force_to_mode (inner, extraction_mode,
      pos_rtx || len + orig_pos >= 32
      ? (((8 * mode_size[(int)(extraction_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(extraction_mode)])) - 1))
      : (((int) 1 << len) - 1) << orig_pos,
      (rtx) 0, 0);



  if (pos_rtx != 0
      && (mode_size[(int)(pos_mode)]) > (mode_size[(int)(((pos_rtx)->mode))]))
    pos_rtx = gen_rtx_combine (ZERO_EXTEND, pos_mode, pos_rtx);
  else if (pos_rtx != 0
    && (mode_size[(int)(pos_mode)]) < (mode_size[(int)(((pos_rtx)->mode))]))
    pos_rtx = gen_lowpart_for_combine (pos_mode, pos_rtx);




  if (pos_rtx == 0 && orig_pos_rtx != 0 && ((orig_pos_rtx)->fld[0].rtwint) == pos)
    pos_rtx = orig_pos_rtx;

  else if (pos_rtx == 0)
    pos_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (pos));


  cxx_new = gen_rtx_combine (unsignedp ? ZERO_EXTRACT : SIGN_EXTRACT,
    extraction_mode, inner, gen_rtx (CONST_INT, VOIDmode, (int) (len)), pos_rtx);
  if (! in_dest)
    cxx_new = gen_lowpart_for_combine (mode, cxx_new);

  return cxx_new;
}




static rtx
extract_left_shift(rtx x, int count) asm("_extract_left_shift");
static rtx
extract_left_shift(rtx x, int count)
{
  n64_enum_rtx_code code = ((x)->code);
  n64_enum_machine_mode mode = ((x)->mode);
  rtx tem;

  switch (code)
    {
    case ASHIFT:



      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= count)
 return simplify_shift_const ((rtx) 0, ASHIFT, mode, ((x)->fld[0].rtx),
         ((((x)->fld[1].rtx))->fld[0].rtwint) - count);
      break;

    case NEG: case NOT:
      if ((tem = extract_left_shift (((x)->fld[0].rtx), count)) != 0)
 return gen_unary (code, mode, mode, tem);

      break;

    case PLUS: case IOR: case XOR: case AND:


      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && (((((x)->fld[1].rtx))->fld[0].rtwint) & (((int) 1 << count)) - 1) == 0
   && (tem = extract_left_shift (((x)->fld[0].rtx), count)) != 0)
 return gen_binary (code, mode, tem,
      gen_rtx (CONST_INT, VOIDmode, (int) (((((x)->fld[1].rtx))->fld[0].rtwint) >> count)));

      break;
    }

  return 0;
}
static rtx
make_compound_operation(rtx x, n64_enum_rtx_code in_code) asm("_make_compound_operation");
static rtx
make_compound_operation(rtx x, n64_enum_rtx_code in_code)
{
  n64_enum_rtx_code code = ((x)->code);
  n64_enum_machine_mode mode = ((x)->mode);
  int mode_width = (8 * mode_size[(int)(mode)]);
  rtx rhs, lhs;
  n64_enum_rtx_code next_code;
  int i;
  rtx cxx_new = 0;
  rtx tem;
  char *fmt;





  next_code = (code == MEM || code == PLUS || code == MINUS ? MEM
        : ((code == COMPARE || (rtx_class[(int)(code)]) == '<')
    && ((x)->fld[1].rtx) == const0_rtx) ? COMPARE
        : in_code == COMPARE ? SET : in_code);




  switch (code)
    {
    case ASHIFT:


      if (in_code == MEM && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 32
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0)
 {
   cxx_new = make_compound_operation (((x)->fld[0].rtx), next_code);
   cxx_new = gen_rtx_combine (MULT, mode, cxx_new,
     gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << ((((x)->fld[1].rtx))->fld[0].rtwint)))
                               );
 }
      break;

    case AND:


      if (((((x)->fld[1].rtx))->code) != CONST_INT)
 break;



      if (((((x)->fld[0].rtx))->code) == LSHIFTRT
   && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint) + 1))) >= 0)
 {
   cxx_new = make_compound_operation (((((x)->fld[0].rtx))->fld[0].rtx), next_code);
   cxx_new = make_extraction (mode, cxx_new, 0, ((((x)->fld[0].rtx))->fld[1].rtx), i, 1,
     0, in_code == COMPARE);
 }


      else if (((((x)->fld[0].rtx))->code) == SUBREG
        && subreg_lowpart_p (((x)->fld[0].rtx))
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == LSHIFTRT
        && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint) + 1))) >= 0)
 {
   cxx_new = make_compound_operation (((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx),
      next_code);
   cxx_new = make_extraction (((((((x)->fld[0].rtx))->fld[0].rtx))->mode), cxx_new, 0,
     ((((((x)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx), i, 1,
     0, in_code == COMPARE);
 }

      else if ((((((x)->fld[0].rtx))->code) == XOR
  || ((((x)->fld[0].rtx))->code) == IOR)
        && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == LSHIFTRT
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == LSHIFTRT
        && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint) + 1))) >= 0)
 {

   cxx_new = gen_rtx_combine (((((x)->fld[0].rtx))->code), mode,
     gen_rtx (AND, mode, ((((x)->fld[0].rtx))->fld[0].rtx),
       ((x)->fld[1].rtx)),
     gen_rtx (AND, mode, ((((x)->fld[0].rtx))->fld[1].rtx),
       ((x)->fld[1].rtx)));
   cxx_new = make_compound_operation (cxx_new, in_code);
 }




      else if (((((x)->fld[0].rtx))->code) == ROTATE
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
        && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint) + 1))) >= 0
        && i <= ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint))
 {
   cxx_new = make_compound_operation (((((x)->fld[0].rtx))->fld[0].rtx), next_code);
   cxx_new = make_extraction (mode, cxx_new,
     ((8 * mode_size[(int)(mode)])
      - ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)),
     (rtx) 0, i, 1, 0, in_code == COMPARE);
 }




      else if (ashr_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing
        && (lshr_optab->handlers[(int) mode].insn_code
     == CODE_FOR_nothing)
        && ((((x)->fld[0].rtx))->code) == LSHIFTRT
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) >= 0
        && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) < 32
        && mode_width <= 32)
 {
   unsigned int mask = (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));

   mask >>= ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint);
   if ((((((x)->fld[1].rtx))->fld[0].rtwint) & ~mask) == 0)
     do { rtx _new = (gen_rtx_combine (ASHIFTRT, mode, make_compound_operation (((((x)->fld[0].rtx))->fld[0].rtx), next_code), ((((x)->fld[0].rtx))->fld[1].rtx))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0)



                               ;
 }





      else if ((i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint) + 1))) >= 0)
 cxx_new = make_extraction (mode,
          make_compound_operation (((x)->fld[0].rtx),
       next_code),
          0, (rtx) 0, i, 1, 0, in_code == COMPARE);



      else if (in_code == COMPARE
        && (i = exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint)))) >= 0)
 cxx_new = make_extraction (mode,
          make_compound_operation (((x)->fld[0].rtx),
       next_code),
          i, (rtx) 0, 1, 1, 0, 1);

      break;

    case LSHIFTRT:


      if (ashr_optab->handlers[(int) mode].insn_code == CODE_FOR_nothing
   && lshr_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing
   && mode_width <= 32
   && (nonzero_bits (((x)->fld[0].rtx), mode) & (1 << (mode_width - 1))) == 0)
 {
   cxx_new = gen_rtx_combine (ASHIFTRT, mode,
     make_compound_operation (((x)->fld[0].rtx),
         next_code),
     ((x)->fld[1].rtx));
   break;
 }



    case ASHIFTRT:
      lhs = ((x)->fld[0].rtx);
      rhs = ((x)->fld[1].rtx);



      if (((rhs)->code) == CONST_INT
   && ((lhs)->code) == ASHIFT
   && ((((lhs)->fld[1].rtx))->code) == CONST_INT
   && ((rhs)->fld[0].rtwint) >= ((((lhs)->fld[1].rtx))->fld[0].rtwint))
 {
   cxx_new = make_compound_operation (((lhs)->fld[0].rtx), next_code);
   cxx_new = make_extraction (mode, cxx_new,
     ((rhs)->fld[0].rtwint) - ((((lhs)->fld[1].rtx))->fld[0].rtwint),
     (rtx) 0, mode_width - ((rhs)->fld[0].rtwint),
     code == LSHIFTRT, 0, in_code == COMPARE);
 }






      if ((rtx_class[(int)(((lhs)->code))]) != 'o'
   && ! (((lhs)->code) == SUBREG
  && ((rtx_class[(int)(((((lhs)->fld[0].rtx))->code))]) == 'o'))
   && ((rhs)->code) == CONST_INT
   && ((rhs)->fld[0].rtwint) < 32
   && (cxx_new = extract_left_shift (lhs, ((rhs)->fld[0].rtwint))) != 0)
 cxx_new = make_extraction (mode, make_compound_operation (cxx_new, next_code),
          0, (rtx) 0, mode_width - ((rhs)->fld[0].rtwint),
          code == LSHIFTRT, 0, in_code == COMPARE);

      break;

    case SUBREG:




      tem = make_compound_operation (((x)->fld[0].rtx), in_code);
      if (((tem)->code) != ((((x)->fld[0].rtx))->code)
   && (mode_size[(int)(mode)]) < (mode_size[(int)(((tem)->mode))])
   && subreg_lowpart_p (x))
 {
   rtx newer = force_to_mode (tem, mode,
         (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)), (rtx) 0, 0);



   if (((newer)->code) != SUBREG)
     newer = make_compound_operation (newer, in_code);

   return newer;
 }
    }

  if (cxx_new)
    {
      x = gen_lowpart_for_combine (mode, cxx_new);
      code = ((x)->code);
    }


  fmt = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    if (fmt[i] == 'e')
      {
 cxx_new = make_compound_operation (((x)->fld[i].rtx), next_code);
 do { rtx _new = (cxx_new); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[i].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[i].rtx); ((x)->fld[i].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[i].rtx)) undobuf.num_undo++; } } while (0);
      }

  return x;
}
static int
get_pos_from_mask(unsigned int m, int *plen) asm("_get_pos_from_mask");
static int
get_pos_from_mask(unsigned int m, int *plen)
{

  int pos = exact_log2_wide ((int) (m & - m));

  if (pos < 0)
    return -1;



  *plen = exact_log2_wide ((int) ((m >> pos) + 1));

  if (*plen <= 0)
    return -1;

  return pos;
}
static rtx
force_to_mode(rtx x, n64_enum_machine_mode mode, unsigned int mask, rtx reg, int just_select) asm("_force_to_mode");
static rtx
force_to_mode(rtx x, n64_enum_machine_mode mode, unsigned int mask, rtx reg, int just_select)
{
  n64_enum_rtx_code code = ((x)->code);
  int next_select = just_select || code == XOR || code == NOT || code == NEG;
  n64_enum_machine_mode op_mode;
  unsigned int fuller_mask, nonzero;
  rtx op0, op1, temp;



  if (code == CALL)
    return x;




  op_mode = (((mode_class[(int)(mode)]) == (mode_class[(int)(((x)->mode))])
       && code_to_optab[(int) code] != 0
       && (code_to_optab[(int) code]->handlers[(int) mode].insn_code
    != CODE_FOR_nothing))
      ? mode : ((x)->mode));



  if ((code == LSHIFTRT || code == ASHIFTRT)
      && (8 * mode_size[(int)(mode)]) < (8 * mode_size[(int)(((x)->mode))]))
    op_mode = ((x)->mode);


  if (op_mode)
    mask &= (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1));




  if (op_mode)
    fuller_mask = ((8 * mode_size[(int)(op_mode)]) >= 32
     ? (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1))
     : ((int) 1 << (floor_log2_wide ((int) (mask)) + 1)) - 1);
  else
    fuller_mask = ~ (int) 0;


  nonzero = nonzero_bits (x, mode);


  if (! just_select && (nonzero & mask) == 0)
    return const0_rtx;



  if (((x)->code) == CONST_INT)
    {
      int cval = ((x)->fld[0].rtwint) & mask;
      int width = (8 * mode_size[(int)(mode)]);



      if (width > 0 && width < 32
   && (cval & ((int) 1 << (width - 1))) != 0)
 cval |= (int) -1 << width;

      return gen_rtx (CONST_INT, VOIDmode, (int) (cval));
    }



  if ((mode_size[(int)(((x)->mode))]) < (mode_size[(int)(mode)])
      && ((((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1)) & ~ mask) == 0)
    return gen_lowpart_for_combine (mode, x);



  if (((x)->mode) == mode && code != SUBREG && (~ mask & nonzero) == 0)
    return x;

  switch (code)
    {
    case CLOBBER:


      return x;

    case USE:



      if (! 0
   && (mask & ~ (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])) - 1))) == 0)
 return force_to_mode (((x)->fld[0].rtx), mode, mask, reg, next_select);
      break;

    case SIGN_EXTEND:
    case ZERO_EXTEND:
    case ZERO_EXTRACT:
    case SIGN_EXTRACT:
      x = expand_compound_operation (x);
      if (((x)->code) != code)
 return force_to_mode (x, mode, mask, reg, next_select);
      break;

    case REG:
      if (reg != 0 && (rtx_equal_p (get_last_value (reg), x)
         || rtx_equal_p (reg, get_last_value (x))))
 x = reg;
      break;

    case SUBREG:
      if (subreg_lowpart_p (x)



   && (((mode_size[(int)(((x)->mode))])
        < (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
       || (0 == (mask
   & (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1))
   & ~ (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])) - 1))))))
 return force_to_mode (((x)->fld[0].rtx), mode, mask, reg, next_select);
      break;

    case AND:




      if (((((x)->fld[1].rtx))->code) == CONST_INT)
 {
   x = simplify_and_const_int (x, op_mode, ((x)->fld[0].rtx),
          mask & ((((x)->fld[1].rtx))->fld[0].rtwint));





   if (((x)->code) == AND && ((((x)->fld[1].rtx))->code) == CONST_INT
       && ((((x)->fld[1].rtx))->fld[0].rtwint) == mask)
     x = ((x)->fld[0].rtx);






   if (((x)->code) == AND && ((((x)->fld[1].rtx))->code) == CONST_INT
       && (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1)) != mask
       && (8 * mode_size[(int)(((x)->mode))]) <= 32)
     {
       int cval = (((((x)->fld[1].rtx))->fld[0].rtwint)
        | ((((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1)) & ~ mask));
       int width = (8 * mode_size[(int)(((x)->mode))]);
       rtx y;



       if (width > 0 && width < 32
    && (cval & ((int) 1 << (width - 1))) != 0)
  cval |= (int) -1 << width;

       y = gen_binary (AND, ((x)->mode), ((x)->fld[0].rtx), gen_rtx (CONST_INT, VOIDmode, (int) (cval)));
       if (rtx_cost (y, SET) < rtx_cost (x, SET))
  x = y;
     }

   break;
 }

      goto binop;

    case PLUS:





      {
 int width = (8 * mode_size[(int)(mode)]);
 unsigned int smask = mask;




 if (width < 32
     && (smask & ((int) 1 << (width - 1))) != 0)
   smask |= (int) -1 << width;

 if (((((x)->fld[1].rtx))->code) == CONST_INT
     && exact_log2_wide ((int) (- smask)) >= 0
     && (nonzero_bits (((x)->fld[0].rtx), mode) & ~ mask) == 0
     && (((((x)->fld[1].rtx))->fld[0].rtwint) & ~ mask) != 0)
   return force_to_mode (plus_constant_wide (((x)->fld[0].rtx), (int) (((((x)->fld[1].rtx))->fld[0].rtwint) & mask))
                                        ,
    mode, mask, reg, next_select);
      }



    case MINUS:
    case MULT:



      mask = fuller_mask;
      goto binop;

    case IOR:
    case XOR:





      if (((((x)->fld[0].rtx))->code) == LSHIFTRT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) < 32
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)
        + floor_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint))))
       < (8 * mode_size[(int)(((x)->mode))]))
   && (((((x)->fld[1].rtx))->fld[0].rtwint)
       & ~ nonzero_bits (((x)->fld[0].rtx), ((x)->mode)) == 0))
 {
   temp = gen_rtx (CONST_INT, VOIDmode, (int) ((((((x)->fld[1].rtx))->fld[0].rtwint) & mask) << ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)))
                                           ;
   temp = gen_binary (((x)->code), ((x)->mode),
        ((((x)->fld[0].rtx))->fld[0].rtx), temp);
   x = gen_binary (LSHIFTRT, ((x)->mode), temp, ((x)->fld[1].rtx));
   return force_to_mode (x, mode, mask, reg, next_select);
 }

    binop:



      op0 = gen_lowpart_for_combine (op_mode,
         force_to_mode (((x)->fld[0].rtx), mode, mask,
          reg, next_select));
      op1 = gen_lowpart_for_combine (op_mode,
         force_to_mode (((x)->fld[1].rtx), mode, mask,
          reg, next_select));





      if (((op1)->code) == CONST_INT && (code == IOR || code == XOR)
   && (((op1)->fld[0].rtwint) & mask) != 0)
 op1 = gen_rtx (CONST_INT, VOIDmode, (int) (((op1)->fld[0].rtwint) & mask));

      if (op_mode != ((x)->mode) || op0 != ((x)->fld[0].rtx) || op1 != ((x)->fld[1].rtx))
 x = gen_binary (code, op_mode, op0, op1);
      break;

    case ASHIFT:






      if (! (((((x)->fld[1].rtx))->code) == CONST_INT
      && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
      && ((((x)->fld[1].rtx))->fld[0].rtwint) < (8 * mode_size[(int)(mode)]))
   && ! (((((x)->fld[1].rtx))->mode) != VOIDmode
  && (nonzero_bits (((x)->fld[1].rtx), ((((x)->fld[1].rtx))->mode))
      < (unsigned int) (8 * mode_size[(int)(mode)]))))
 break;




      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < (8 * mode_size[(int)(op_mode)])
   && (8 * mode_size[(int)(op_mode)]) <= 32)
 mask >>= ((((x)->fld[1].rtx))->fld[0].rtwint);
      else
 mask = fuller_mask;

      op0 = gen_lowpart_for_combine (op_mode,
         force_to_mode (((x)->fld[0].rtx), op_mode,
          mask, reg, next_select));

      if (op_mode != ((x)->mode) || op0 != ((x)->fld[0].rtx))
 x = gen_binary (code, op_mode, op0, ((x)->fld[1].rtx));
      break;

    case LSHIFTRT:




      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 32
   && (8 * mode_size[(int)(op_mode)]) <= 32)
 {
   rtx inner = ((x)->fld[0].rtx);


   mask <<= ((((x)->fld[1].rtx))->fld[0].rtwint);




   if ((8 * mode_size[(int)(op_mode)]) > 32
       || (mask & ~ (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1))) != 0)
     op_mode = ((x)->mode);

   inner = force_to_mode (inner, op_mode, mask, reg, next_select);

   if (((x)->mode) != op_mode || inner != ((x)->fld[0].rtx))
     x = gen_binary (LSHIFTRT, op_mode, inner, ((x)->fld[1].rtx));
 }





      if (((x)->code) == LSHIFTRT
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[1].rtx))->fld[0].rtwint)
        + num_sign_bit_copies (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode)))
       >= (8 * mode_size[(int)(((x)->mode))]))
   && exact_log2_wide ((int) (mask + 1)) >= 0
   && (num_sign_bit_copies (((x)->fld[0].rtx), ((((x)->fld[0].rtx))->mode))
       >= exact_log2_wide ((int) (mask + 1))))
 x = gen_binary (LSHIFTRT, ((x)->mode), ((x)->fld[0].rtx),
   gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(((x)->mode))]) - exact_log2_wide ((int) (mask + 1))))
                             );
      break;

    case ASHIFTRT:


      if ((8 * mode_size[(int)(((x)->mode))]) <= 32
   && (mask == ((int) 1
         << ((8 * mode_size[(int)(((x)->mode))]) - 1))))
 return force_to_mode (((x)->fld[0].rtx), mode, mask, reg, next_select);
      if (((((x)->fld[1].rtx))->code) == CONST_INT && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 32)
 {
   int i = -1;





   if ((8 * mode_size[(int)(((x)->mode))]) > 32)
     {
       nonzero = ~(int)0;






       if ((8 * mode_size[(int)(((x)->mode))]) - ((((x)->fld[1].rtx))->fld[0].rtwint)
    < 32)
  nonzero >>= ((((x)->fld[1].rtx))->fld[0].rtwint)
       + 32
       - (8 * mode_size[(int)(((x)->mode))]) ;
     }
   else
     {
       nonzero = (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1));
       nonzero >>= ((((x)->fld[1].rtx))->fld[0].rtwint);
     }

   if ((mask & ~ nonzero) == 0
       || (i = exact_log2_wide ((int) (mask))) >= 0)
     {
       x = simplify_shift_const
  (x, LSHIFTRT, ((x)->mode), ((x)->fld[0].rtx),
   i < 0 ? ((((x)->fld[1].rtx))->fld[0].rtwint)
   : (8 * mode_size[(int)(((x)->mode))]) - 1 - i);

       if (((x)->code) != ASHIFTRT)
  return force_to_mode (x, mode, mask, reg, next_select);
     }
 }



      if (mask == 1)
 x = gen_binary (LSHIFTRT, ((x)->mode), ((x)->fld[0].rtx), ((x)->fld[1].rtx));





      if ((((x)->code) == LSHIFTRT || ((x)->code) == ASHIFTRT)
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
   && (((((x)->fld[1].rtx))->fld[0].rtwint)
       <= (8 * mode_size[(int)(((x)->mode))]) - (floor_log2_wide ((int) (mask)) + 1))
   && ((((x)->fld[0].rtx))->code) == ASHIFT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) == ((((x)->fld[1].rtx))->fld[0].rtwint))
 return force_to_mode (((((x)->fld[0].rtx))->fld[0].rtx), mode, mask,
         reg, next_select);

      break;

    case ROTATE:
    case ROTATERT:




      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0)
 {
   temp = simplify_binary_operation (code == ROTATE ? ROTATERT : ROTATE,
         ((x)->mode), gen_rtx (CONST_INT, VOIDmode, (int) (mask)),
         ((x)->fld[1].rtx));
   if (temp && ((temp)->code) == CONST_INT)
     do { rtx _new = (force_to_mode (((x)->fld[0].rtx), ((x)->mode), ((temp)->fld[0].rtwint), reg, next_select)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0)

                                       ;
 }
      break;

    case NEG:


      if (mask == 1)
 return force_to_mode (((x)->fld[0].rtx), mode, mask, reg, just_select);




      mask = fuller_mask;
      goto unop;

    case NOT:




      if (((((x)->fld[0].rtx))->code) == LSHIFTRT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) >= 0
   && (((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) + floor_log2_wide ((int) (mask))
       < (8 * mode_size[(int)(((x)->mode))]))
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) < 32)
 {
   temp = gen_rtx (CONST_INT, VOIDmode, (int) (mask << ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)));
   temp = gen_binary (XOR, ((x)->mode), ((((x)->fld[0].rtx))->fld[0].rtx), temp);
   x = gen_binary (LSHIFTRT, ((x)->mode), temp, ((((x)->fld[0].rtx))->fld[1].rtx));

   return force_to_mode (x, mode, mask, reg, next_select);
 }

    unop:
      op0 = gen_lowpart_for_combine (op_mode,
         force_to_mode (((x)->fld[0].rtx), mode, mask,
          reg, next_select));
      if (op_mode != ((x)->mode) || op0 != ((x)->fld[0].rtx))
 x = gen_unary (code, op_mode, op_mode, op0);
      break;

    case NE:



      if ((mask & ~ 1) == 0 && ((x)->fld[0].rtx) == const0_rtx
   && (nonzero_bits (((x)->fld[0].rtx), mode) & ~ mask) == 0)
 return force_to_mode (((x)->fld[0].rtx), mode, mask, reg, next_select);

      break;

    case IF_THEN_ELSE:



      do { rtx _new = (gen_lowpart_for_combine (((x)->mode), force_to_mode (((x)->fld[1].rtx), mode, mask, reg, next_select))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0)


                                    ;
      do { rtx _new = (gen_lowpart_for_combine (((x)->mode), force_to_mode (((x)->fld[2].rtx), mode, mask, reg,next_select))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[2].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[2].rtx); ((x)->fld[2].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[2].rtx)) undobuf.num_undo++; } } while (0)


                                   ;
      break;
    }


  return gen_lowpart_for_combine (mode, x);
}
static rtx
if_then_else_cond(rtx x, rtx *ptrue, rtx *pfalse) asm("_if_then_else_cond");
static rtx
if_then_else_cond(rtx x, rtx *ptrue, rtx *pfalse)
{
  n64_enum_machine_mode mode = ((x)->mode);
  n64_enum_rtx_code code = ((x)->code);
  int size = (8 * mode_size[(int)(mode)]);
  rtx cond0, cond1, true0, true1, false0, false1;
  unsigned int nz;



  if ((rtx_class[(int)(code)]) == '1'
      && (cond0 = if_then_else_cond (((x)->fld[0].rtx), &true0, &false0)) != 0)
    {
      *ptrue = gen_unary (code, mode, ((((x)->fld[0].rtx))->mode), true0);
      *pfalse = gen_unary (code, mode, ((((x)->fld[0].rtx))->mode), false0);
      return cond0;
    }



  else if (code == COMPARE)
    ;




  else if ((rtx_class[(int)(code)]) == 'c' || (rtx_class[(int)(code)]) == '2'
    || (rtx_class[(int)(code)]) == '<')
    {
      cond0 = if_then_else_cond (((x)->fld[0].rtx), &true0, &false0);
      cond1 = if_then_else_cond (((x)->fld[1].rtx), &true1, &false1);

      if ((cond0 != 0 || cond1 != 0)
   && ! (cond0 != 0 && cond1 != 0 && ! rtx_equal_p (cond0, cond1)))
 {
   *ptrue = gen_binary (code, mode, true0, true1);
   *pfalse = gen_binary (code, mode, false0, false1);
   return cond0 ? cond0 : cond1;
 }






      if ((code == PLUS || code == IOR || code == XOR || code == MINUS
    || code == UMAX)
   && ((((x)->fld[0].rtx))->code) == MULT && ((((x)->fld[1].rtx))->code) == MULT)
 {
   rtx op0 = ((((x)->fld[0].rtx))->fld[1].rtx);
   rtx op1 = ((((x)->fld[1].rtx))->fld[1].rtx);

   cond0 = ((((x)->fld[0].rtx))->fld[0].rtx);
   cond1 = ((((x)->fld[1].rtx))->fld[0].rtx);

   if ((rtx_class[(int)(((cond0)->code))]) == '<'
       && (rtx_class[(int)(((cond1)->code))]) == '<'
       && reversible_comparison_p (cond1)
       && ((((cond0)->code) == reverse_condition (((cond1)->code))
     && rtx_equal_p (((cond0)->fld[0].rtx), ((cond1)->fld[0].rtx))
     && rtx_equal_p (((cond0)->fld[1].rtx), ((cond1)->fld[1].rtx)))
    || ((swap_condition (((cond0)->code))
         == reverse_condition (((cond1)->code)))
        && rtx_equal_p (((cond0)->fld[0].rtx), ((cond1)->fld[1].rtx))
        && rtx_equal_p (((cond0)->fld[1].rtx), ((cond1)->fld[0].rtx))))
       && ! side_effects_p (x))
     {
       *ptrue = gen_binary (MULT, mode, op0, const_true_rtx);
       *pfalse = gen_binary (MULT, mode,
        (code == MINUS
         ? gen_unary (NEG, mode, mode, op1) : op1),
        const_true_rtx);
       return cond0;
     }
 }



      if ((code == MULT || code == AND || code == UMIN)
   && ((((x)->fld[0].rtx))->code) == MULT && ((((x)->fld[1].rtx))->code) == MULT)
 {
   cond0 = ((((x)->fld[0].rtx))->fld[0].rtx);
   cond1 = ((((x)->fld[1].rtx))->fld[0].rtx);

   if ((rtx_class[(int)(((cond0)->code))]) == '<'
       && (rtx_class[(int)(((cond1)->code))]) == '<'
       && reversible_comparison_p (cond1)
       && ((((cond0)->code) == reverse_condition (((cond1)->code))
     && rtx_equal_p (((cond0)->fld[0].rtx), ((cond1)->fld[0].rtx))
     && rtx_equal_p (((cond0)->fld[1].rtx), ((cond1)->fld[1].rtx)))
    || ((swap_condition (((cond0)->code))
         == reverse_condition (((cond1)->code)))
        && rtx_equal_p (((cond0)->fld[0].rtx), ((cond1)->fld[1].rtx))
        && rtx_equal_p (((cond0)->fld[1].rtx), ((cond1)->fld[0].rtx))))
       && ! side_effects_p (x))
     {
       *ptrue = *pfalse = const0_rtx;
       return cond0;
     }
 }

    }

  else if (code == IF_THEN_ELSE)
    {


      cond0 = ((x)->fld[0].rtx);
      *ptrue = ((x)->fld[1].rtx), *pfalse = ((x)->fld[2].rtx);
      if (((cond0)->code) == NE && ((cond0)->fld[1].rtx) == const0_rtx)
 return ((cond0)->fld[0].rtx);
      else if (((cond0)->code) == EQ && ((cond0)->fld[1].rtx) == const0_rtx)
 {
   *ptrue = ((x)->fld[2].rtx), *pfalse = ((x)->fld[1].rtx);
   return ((cond0)->fld[0].rtx);
 }
      else
 return cond0;
    }




  else if (code == SUBREG && (mode_class[(int)(mode)]) == MODE_INT
    && (mode_class[(int)(((((x)->fld[0].rtx))->mode))]) == MODE_INT
    && (mode_size[(int)(mode)]) <= (mode_size[(int)(((((x)->fld[0].rtx))->mode))])
    && 0 != (cond0 = if_then_else_cond (((x)->fld[0].rtx),
            &true0, &false0)))
    {
      *ptrue = force_to_mode (true0, mode, (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)), (rtx) 0, 0);
      *pfalse
 = force_to_mode (false0, mode, (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)), (rtx) 0, 0);

      return cond0;
    }



  else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH)
    || ((cond0 = get_last_value (x)) != 0 && (((cond0)->code) == LABEL_REF || ((cond0)->code) == SYMBOL_REF || ((cond0)->code) == CONST_INT || ((cond0)->code) == CONST_DOUBLE || ((cond0)->code) == CONST || ((cond0)->code) == HIGH)))
    ;



  else if (num_sign_bit_copies (x, mode) == size)
    {
      *ptrue = constm1_rtx, *pfalse = const0_rtx;
      return x;
    }


  else if (exact_log2_wide ((int) (nz = nonzero_bits (x, mode))) >= 0)
    {
      *ptrue = gen_rtx (CONST_INT, VOIDmode, (int) (nz)), *pfalse = const0_rtx;
      return x;
    }


  *ptrue = *pfalse = x;
  return 0;
}
static rtx
known_cond(rtx x, n64_enum_rtx_code cond, rtx reg, rtx val) asm("_known_cond");
static rtx
known_cond(rtx x, n64_enum_rtx_code cond, rtx reg, rtx val)
{
  n64_enum_rtx_code code = ((x)->code);
  rtx temp;
  char *fmt;
  int i, j;

  if (side_effects_p (x))
    return x;

  if (cond == EQ && rtx_equal_p (x, reg))
    return val;




  if (code == ABS && rtx_equal_p (((x)->fld[0].rtx), reg) && val == const0_rtx)
    switch (cond)
      {
      case GE: case GT: case EQ:
 return ((x)->fld[0].rtx);
      case LT: case LE:
 return gen_unary (NEG, ((((x)->fld[0].rtx))->mode), ((((x)->fld[0].rtx))->mode),
     ((x)->fld[0].rtx));
      }




  else if ((rtx_class[(int)(code)]) == '<' || (rtx_class[(int)(code)]) == 'c')
    {
      if (rtx_equal_p (((x)->fld[0].rtx), val))
 cond = swap_condition (cond), temp = val, val = reg, reg = temp;

      if (rtx_equal_p (((x)->fld[0].rtx), reg) && rtx_equal_p (((x)->fld[1].rtx), val))
 {
   if ((rtx_class[(int)(code)]) == '<')
     return (comparison_dominates_p (cond, code) ? const_true_rtx
      : (comparison_dominates_p (cond,
            reverse_condition (code))
         ? const0_rtx : x));

   else if (code == SMAX || code == SMIN
     || code == UMIN || code == UMAX)
     {
       int unsignedp = (code == UMIN || code == UMAX);

       if (code == SMAX || code == UMAX)
  cond = reverse_condition (cond);

       switch (cond)
  {
  case GE: case GT:
    return unsignedp ? x : ((x)->fld[1].rtx);
  case LE: case LT:
    return unsignedp ? x : ((x)->fld[0].rtx);
  case GEU: case GTU:
    return unsignedp ? ((x)->fld[1].rtx) : x;
  case LEU: case LTU:
    return unsignedp ? ((x)->fld[0].rtx) : x;
  }
     }
 }
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 do { rtx _new = (known_cond (((x)->fld[i].rtx), cond, reg, val)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[i].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[i].rtx); ((x)->fld[i].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[i].rtx)) undobuf.num_undo++; } } while (0);
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   do { rtx _new = (known_cond (((x)->fld[i].rtvec->elem[j].rtx), cond, reg, val)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[i].rtvec->elem[j].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[i].rtvec->elem[j].rtx); ((x)->fld[i].rtvec->elem[j].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[i].rtvec->elem[j].rtx)) undobuf.num_undo++; } } while (0)
                      ;
    }

  return x;
}






static rtx
make_field_assignment(rtx x) asm("_make_field_assignment");
static rtx
make_field_assignment(rtx x)
{
  rtx dest = ((x)->fld[0].rtx);
  rtx src = ((x)->fld[1].rtx);
  rtx assign;
  int c1;
  int pos, len;
  rtx other;
  n64_enum_machine_mode mode;






  if (((src)->code) == AND && ((((src)->fld[0].rtx))->code) == ROTATE
      && ((((((src)->fld[0].rtx))->fld[0].rtx))->code) == CONST_INT
      && ((((((src)->fld[0].rtx))->fld[0].rtx))->fld[0].rtwint) == -2
      && (rtx_equal_p (dest, ((src)->fld[1].rtx))
   || rtx_equal_p (dest, get_last_value (((src)->fld[1].rtx)))
   || rtx_equal_p (get_last_value (dest), ((src)->fld[1].rtx))))
    {
      assign = make_extraction (VOIDmode, dest, 0, ((((src)->fld[0].rtx))->fld[1].rtx),
    1, 1, 1, 0);
      return gen_rtx (SET, VOIDmode, assign, const0_rtx);
    }

  else if (((src)->code) == AND && ((((src)->fld[0].rtx))->code) == SUBREG
    && subreg_lowpart_p (((src)->fld[0].rtx))
    && ((mode_size[(int)(((((src)->fld[0].rtx))->mode))])
        < (mode_size[(int)(((((((src)->fld[0].rtx))->fld[0].rtx))->mode))]))
    && ((((((src)->fld[0].rtx))->fld[0].rtx))->code) == ROTATE
    && ((((((((src)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->fld[0].rtwint) == -2
    && (rtx_equal_p (dest, ((src)->fld[1].rtx))
        || rtx_equal_p (dest, get_last_value (((src)->fld[1].rtx)))
        || rtx_equal_p (get_last_value (dest), ((src)->fld[1].rtx))))
    {
      assign = make_extraction (VOIDmode, dest, 0,
    ((((((src)->fld[0].rtx))->fld[0].rtx))->fld[1].rtx),
    1, 1, 1, 0);
      return gen_rtx (SET, VOIDmode, assign, const0_rtx);
    }



  else if (((src)->code) == IOR && ((((src)->fld[0].rtx))->code) == ASHIFT
    && ((((src)->fld[0].rtx))->fld[0].rtx) == const1_rtx
    && (rtx_equal_p (dest, ((src)->fld[1].rtx))
        || rtx_equal_p (dest, get_last_value (((src)->fld[1].rtx)))
        || rtx_equal_p (get_last_value (dest), ((src)->fld[1].rtx))))
    {
      assign = make_extraction (VOIDmode, dest, 0, ((((src)->fld[0].rtx))->fld[1].rtx),
    1, 1, 1, 0);
      return gen_rtx (SET, VOIDmode, assign, const1_rtx);
    }
  if (((src)->code) == IOR && ((((src)->fld[0].rtx))->code) == AND
      && ((((((src)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && (rtx_equal_p (((((src)->fld[0].rtx))->fld[0].rtx), dest)
   || rtx_equal_p (((((src)->fld[0].rtx))->fld[0].rtx), get_last_value (dest))
   || rtx_equal_p (get_last_value (((((src)->fld[0].rtx))->fld[1].rtx)), dest)))
    c1 = ((((((src)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint), other = ((src)->fld[1].rtx);
  else if (((src)->code) == IOR && ((((src)->fld[1].rtx))->code) == AND
    && ((((((src)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT
    && (rtx_equal_p (((((src)->fld[1].rtx))->fld[0].rtx), dest)
        || rtx_equal_p (((((src)->fld[1].rtx))->fld[0].rtx), get_last_value (dest))
        || rtx_equal_p (get_last_value (((((src)->fld[1].rtx))->fld[0].rtx)),
          dest)))
    c1 = ((((((src)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint), other = ((src)->fld[0].rtx);
  else
    return x;

  pos = get_pos_from_mask (c1 ^ (((8 * mode_size[(int)(((dest)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((dest)->mode))])) - 1)), &len);
  if (pos < 0 || pos + len > (8 * mode_size[(int)(((dest)->mode))])
      || ((8 * mode_size[(int)(((other)->mode))]) <= 32
   && (c1 & nonzero_bits (other, ((other)->mode))) != 0))
    return x;

  assign = make_extraction (VOIDmode, dest, pos, (rtx) 0, len, 1, 1, 0);



  mode = (((assign)->code) == STRICT_LOW_PART
   ? ((((assign)->fld[0].rtx))->mode) : ((assign)->mode));




  src = force_to_mode (simplify_shift_const ((rtx) 0, LSHIFTRT,
          ((src)->mode), other, pos),
         mode,
         (8 * mode_size[(int)(mode)]) >= 32
         ? (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
         : ((int) 1 << len) - 1,
         dest, 0);

  return gen_rtx_combine (SET, VOIDmode, assign, src);
}




static rtx
apply_distributive_law(rtx x) asm("_apply_distributive_law");
static rtx
apply_distributive_law(rtx x)
{
  n64_enum_rtx_code code = ((x)->code);
  rtx lhs, rhs, other;
  rtx tem;
  n64_enum_rtx_code inner_code;




  if (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT))
    return x;


  if (code != IOR && code != AND && code != XOR
      && code != PLUS && code != MINUS)
    return x;

  lhs = ((x)->fld[0].rtx), rhs = ((x)->fld[1].rtx);


  if ((rtx_class[(int)(((lhs)->code))]) == 'o'
      || (rtx_class[(int)(((rhs)->code))]) == 'o')
    return x;

  lhs = expand_compound_operation (lhs);
  rhs = expand_compound_operation (rhs);
  inner_code = ((lhs)->code);
  if (inner_code != ((rhs)->code))
    return x;


  switch (inner_code)
    {
    case LSHIFTRT:
    case ASHIFTRT:
    case AND:
    case IOR:

      if (code == PLUS || code == MINUS)
 return x;
      break;

    case MULT:
      if (code != PLUS && code != MINUS)
 return x;
      break;

    case ASHIFT:

      break;

    case SUBREG:
      if (((((lhs)->fld[0].rtx))->mode) != ((((rhs)->fld[0].rtx))->mode)
   || ((lhs)->fld[1].rtint) != ((rhs)->fld[1].rtint)
   || ! subreg_lowpart_p (lhs)
   || ((mode_class[(int)(((lhs)->mode))])
       != (mode_class[(int)(((((lhs)->fld[0].rtx))->mode))]))
   || ((mode_size[(int)(((lhs)->mode))])
       > (mode_size[(int)(((((lhs)->fld[0].rtx))->mode))]))
   || (mode_size[(int)(((((lhs)->fld[0].rtx))->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 return x;

      tem = gen_binary (code, ((((lhs)->fld[0].rtx))->mode),
   ((lhs)->fld[0].rtx), ((rhs)->fld[0].rtx));
      return gen_lowpart_for_combine (((x)->mode), tem);

    default:
      return x;
    }





  if ((rtx_class[(int)(inner_code)]) == 'c'
      && rtx_equal_p (((lhs)->fld[0].rtx), ((rhs)->fld[0].rtx)))
    other = ((lhs)->fld[0].rtx), lhs = ((lhs)->fld[1].rtx), rhs = ((rhs)->fld[1].rtx);
  else if ((rtx_class[(int)(inner_code)]) == 'c'
    && rtx_equal_p (((lhs)->fld[0].rtx), ((rhs)->fld[1].rtx)))
    other = ((lhs)->fld[0].rtx), lhs = ((lhs)->fld[1].rtx), rhs = ((rhs)->fld[0].rtx);
  else if ((rtx_class[(int)(inner_code)]) == 'c'
    && rtx_equal_p (((lhs)->fld[1].rtx), ((rhs)->fld[0].rtx)))
    other = ((lhs)->fld[1].rtx), lhs = ((lhs)->fld[0].rtx), rhs = ((rhs)->fld[1].rtx);
  else if (rtx_equal_p (((lhs)->fld[1].rtx), ((rhs)->fld[1].rtx)))
    other = ((lhs)->fld[1].rtx), lhs = ((lhs)->fld[0].rtx), rhs = ((rhs)->fld[0].rtx);
  else
    return x;


  tem = gen_binary (code, ((x)->mode), lhs, rhs);



  if (code == XOR && inner_code == IOR)
    {
      inner_code = AND;
      other = gen_unary (NOT, ((x)->mode), ((x)->mode), other);
    }




  return gen_binary (inner_code, ((x)->mode),
       apply_distributive_law (tem), other);
}







static rtx
simplify_and_const_int(rtx x, n64_enum_machine_mode mode, rtx varop, unsigned int constop) asm("_simplify_and_const_int");
static rtx
simplify_and_const_int(rtx x, n64_enum_machine_mode mode, rtx varop, unsigned int constop)
{
  unsigned int nonzero;
  int width = (8 * mode_size[(int)(mode)]);
  int i;



  varop = force_to_mode (varop, mode, constop, (rtx) 0, 0);



  if (((varop)->code) == CLOBBER || ((varop)->code) == CONST_INT)
    return varop;





  nonzero = nonzero_bits (varop, mode) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
  if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
      && (nonzero & ((int) 1 << (width - 1))))
    nonzero |= ((int) (-1) << width);





  constop &= nonzero;


  if (constop == 0)
    return const0_rtx;



  if (((varop)->code) == NEG && nonzero_bits (((varop)->fld[0].rtx), mode) == 1
      && (i = exact_log2_wide ((int) (constop))) >= 0)
    return simplify_shift_const ((rtx) 0, ASHIFT, mode, ((varop)->fld[0].rtx), i);







  if (((varop)->code) == IOR || ((varop)->code) == XOR)
    return
      gen_lowpart_for_combine
 (mode,
  apply_distributive_law
  (gen_binary (((varop)->code), ((varop)->mode),
        simplify_and_const_int ((rtx) 0, ((varop)->mode),
           ((varop)->fld[0].rtx), constop),
        simplify_and_const_int ((rtx) 0, ((varop)->mode),
           ((varop)->fld[1].rtx), constop))));



  if (x && ((((x)->fld[0].rtx))->code) == SUBREG
      && ((((x)->fld[0].rtx))->mode) == mode
      && ((((x)->fld[0].rtx))->fld[0].rtx) == varop)
    varop = ((x)->fld[0].rtx);
  else
    varop = gen_lowpart_for_combine (mode, varop);


  if (((varop)->code) == CLOBBER)
    return x ? x : varop;


  if (constop == nonzero)
    x = varop;


  else if (x == 0 || ((x)->code) != AND || ((x)->mode) != mode)
    x = gen_binary (AND, mode, varop, gen_rtx (CONST_INT, VOIDmode, (int) (constop)));

  else
    {
      if (((((x)->fld[1].rtx))->code) != CONST_INT
   || ((((x)->fld[1].rtx))->fld[0].rtwint) != constop)
 do { rtx _new = (gen_rtx (CONST_INT, VOIDmode, (int) (constop))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);

      do { rtx _new = (varop); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
    }

  return x;
}







static unsigned int
nonzero_bits(rtx x, n64_enum_machine_mode mode) asm("_nonzero_bits");
static unsigned int
nonzero_bits(rtx x, n64_enum_machine_mode mode)
{
  unsigned int nonzero = (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
  unsigned int inner_nz;
  n64_enum_rtx_code code;
  int mode_width = (8 * mode_size[(int)(mode)]);
  rtx tem;


  if (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT) || ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT))
    return nonzero;


  if ((8 * mode_size[(int)(((x)->mode))]) > mode_width)
    {
      mode = ((x)->mode);
      nonzero = (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
      mode_width = (8 * mode_size[(int)(mode)]);
    }

  if (mode_width > 32)


    return nonzero;
  code = ((x)->code);
  switch (code)
    {
    case REG:
      if (x == stack_pointer_rtx)
 {
   int sp_alignment = 64 / 8;
   return nonzero &= ~ (sp_alignment - 1);
 }







      if (reg_last_set_value[((x)->fld[0].rtint)] != 0
   && reg_last_set_mode[((x)->fld[0].rtint)] == mode
   && (reg_n_sets[((x)->fld[0].rtint)] == 1
       || reg_last_set_label[((x)->fld[0].rtint)] == label_tick)
   && (((reg_last_set[((x)->fld[0].rtint)])->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((reg_last_set[((x)->fld[0].rtint)])->fld[0].rtint)]) < subst_low_cuid)
 return reg_last_set_nonzero_bits[((x)->fld[0].rtint)];

      tem = get_last_value (x);

      if (tem)
 {
   return nonzero_bits (tem, mode);
 }
      else if (nonzero_sign_valid && reg_nonzero_bits[((x)->fld[0].rtint)])
 return reg_nonzero_bits[((x)->fld[0].rtint)] & nonzero;
      else
 return nonzero;

    case CONST_INT:







      return ((x)->fld[0].rtwint);

    case MEM:




      if (ZERO_EXTEND == ZERO_EXTEND)
 nonzero &= (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1));

      break;

    case EQ: case NE:
    case GT: case GTU:
    case LT: case LTU:
    case GE: case GEU:
    case LE: case LEU:





      if ((mode_class[(int)(mode)]) == MODE_INT
   && mode_width <= 32)
 nonzero = 1;
      break;

    case NEG:
      if (num_sign_bit_copies (((x)->fld[0].rtx), ((x)->mode))
   == (8 * mode_size[(int)(((x)->mode))]))
 nonzero = 1;

      if ((mode_size[(int)(((x)->mode))]) < mode_width)
 nonzero |= ((((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) & ~ (((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1)));
      break;

    case ABS:
      if (num_sign_bit_copies (((x)->fld[0].rtx), ((x)->mode))
   == (8 * mode_size[(int)(((x)->mode))]))
 nonzero = 1;
      break;

    case TRUNCATE:
      nonzero &= (nonzero_bits (((x)->fld[0].rtx), mode) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)));
      break;

    case ZERO_EXTEND:
      nonzero &= nonzero_bits (((x)->fld[0].rtx), mode);
      if (((((x)->fld[0].rtx))->mode) != VOIDmode)
 nonzero &= (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])) - 1));
      break;

    case SIGN_EXTEND:



      inner_nz = nonzero_bits (((x)->fld[0].rtx), mode);
      if (((((x)->fld[0].rtx))->mode) != VOIDmode)
 {
   inner_nz &= (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])) - 1));
   if (inner_nz &
       (((int) 1
  << ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - 1))))
     inner_nz |= ((((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
     & ~ (((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])) - 1)));
 }

      nonzero &= inner_nz;
      break;

    case AND:
      nonzero &= (nonzero_bits (((x)->fld[0].rtx), mode)
    & nonzero_bits (((x)->fld[1].rtx), mode));
      break;

    case XOR: case IOR:
    case UMIN: case UMAX: case SMIN: case SMAX:
      nonzero &= (nonzero_bits (((x)->fld[0].rtx), mode)
    | nonzero_bits (((x)->fld[1].rtx), mode));
      break;

    case PLUS: case MINUS:
    case MULT:
    case DIV: case UDIV:
    case MOD: case UMOD:




      {
 unsigned int nz0 = nonzero_bits (((x)->fld[0].rtx), mode);
 unsigned int nz1 = nonzero_bits (((x)->fld[1].rtx), mode);
 int width0 = floor_log2_wide ((int) (nz0)) + 1;
 int width1 = floor_log2_wide ((int) (nz1)) + 1;
 int low0 = floor_log2_wide ((int) (nz0 & -nz0));
 int low1 = floor_log2_wide ((int) (nz1 & -nz1));
 int op0_maybe_minusp
   = (nz0 & ((int) 1 << (mode_width - 1)));
 int op1_maybe_minusp
   = (nz1 & ((int) 1 << (mode_width - 1)));
 int result_width = mode_width;
 int result_low = 0;

 switch (code)
   {
   case PLUS:
     result_width = ((width0) > (width1) ? (width0) : (width1)) + 1;
     result_low = ((low0) < (low1) ? (low0) : (low1));
     break;
   case MINUS:
     result_low = ((low0) < (low1) ? (low0) : (low1));
     break;
   case MULT:
     result_width = width0 + width1;
     result_low = low0 + low1;
     break;
   case DIV:
     if (! op0_maybe_minusp && ! op1_maybe_minusp)
       result_width = width0;
     break;
   case UDIV:
     result_width = width0;
     break;
   case MOD:
     if (! op0_maybe_minusp && ! op1_maybe_minusp)
       result_width = ((width0) < (width1) ? (width0) : (width1));
     result_low = ((low0) < (low1) ? (low0) : (low1));
     break;
   case UMOD:
     result_width = ((width0) < (width1) ? (width0) : (width1));
     result_low = ((low0) < (low1) ? (low0) : (low1));
     break;
   }

 if (result_width < mode_width)
   nonzero &= ((int) 1 << result_width) - 1;

 if (result_low > 0)
   nonzero &= ~ (((int) 1 << result_low) - 1);
      }
      break;

    case ZERO_EXTRACT:
      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 32)
 nonzero &= ((int) 1 << ((((x)->fld[1].rtx))->fld[0].rtwint)) - 1;
      break;

    case SUBREG:




      if (((x)->in_struct) && ((x)->unchanging))
 nonzero = ((((8 * mode_size[(int)(((x)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((x)->mode))])) - 1))
     & nonzero_bits (((x)->fld[0].rtx), ((x)->mode)));




      if ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) <= ((target_flags & 0x00002000) ? 64 : 32)
   && ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])
       <= 32))
 {
   nonzero &= nonzero_bits (((x)->fld[0].rtx), mode);
 }
      break;

    case ASHIFTRT:
    case LSHIFTRT:
    case ASHIFT:
    case ROTATE:






      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((x)->fld[1].rtx))->fld[0].rtwint) < 32)
 {
   n64_enum_machine_mode inner_mode = ((x)->mode);
   int width = (8 * mode_size[(int)(inner_mode)]);
   int count = ((((x)->fld[1].rtx))->fld[0].rtwint);
   unsigned int mode_mask = (((8 * mode_size[(int)(inner_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(inner_mode)])) - 1));
   unsigned int op_nonzero = nonzero_bits (((x)->fld[0].rtx), mode);
   unsigned int inner = op_nonzero & mode_mask;
   unsigned int outer = 0;

   if (mode_width > width)
     outer = (op_nonzero & nonzero & ~ mode_mask);

   if (code == LSHIFTRT)
     inner >>= count;
   else if (code == ASHIFTRT)
     {
       inner >>= count;




       if (inner & ((int) 1 << (width - 1 - count)))
  inner |= (((int) 1 << count) - 1) << (width - count);
     }
   else if (code == ASHIFT)
     inner <<= count;
   else
     inner = ((inner << (count % width)
        | (inner >> (width - (count % width)))) & mode_mask);

   nonzero &= (outer | inner);
 }
      break;

    case FFS:

      nonzero = ((int) 1 << (floor_log2_wide ((int) (mode_width)) + 1)) - 1;
      break;

    case IF_THEN_ELSE:
      nonzero &= (nonzero_bits (((x)->fld[1].rtx), mode)
    | nonzero_bits (((x)->fld[2].rtx), mode));
      break;
    }

  return nonzero;
}






static int
num_sign_bit_copies(rtx x, n64_enum_machine_mode mode) asm("_num_sign_bit_copies");
static int
num_sign_bit_copies(rtx x, n64_enum_machine_mode mode)
{
  n64_enum_rtx_code code = ((x)->code);
  int bitwidth;
  int num0, num1, result;
  unsigned int nonzero;
  rtx tem;





  if (mode == VOIDmode)
    mode = ((x)->mode);

  if (mode == VOIDmode || ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) || ((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT))
    return 1;

  bitwidth = (8 * mode_size[(int)(mode)]);


  if (bitwidth < (8 * mode_size[(int)(((x)->mode))]))
    return ((1) > ((num_sign_bit_copies (x, ((x)->mode)) - ((8 * mode_size[(int)(((x)->mode))]) - bitwidth))) ? (1) : ((num_sign_bit_copies (x, ((x)->mode)) - ((8 * mode_size[(int)(((x)->mode))]) - bitwidth))))
                                                      ;
  switch (code)
    {
    case REG:
      if (reg_last_set_value[((x)->fld[0].rtint)] != 0
   && reg_last_set_mode[((x)->fld[0].rtint)] == mode
   && (reg_n_sets[((x)->fld[0].rtint)] == 1
       || reg_last_set_label[((x)->fld[0].rtint)] == label_tick)
   && (((reg_last_set[((x)->fld[0].rtint)])->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((reg_last_set[((x)->fld[0].rtint)])->fld[0].rtint)]) < subst_low_cuid)
 return reg_last_set_sign_bit_copies[((x)->fld[0].rtint)];

      tem = get_last_value (x);
      if (tem != 0)
 return num_sign_bit_copies (tem, mode);

      if (nonzero_sign_valid && reg_sign_bit_copies[((x)->fld[0].rtint)] != 0)
 return reg_sign_bit_copies[((x)->fld[0].rtint)];
      break;

    case MEM:


      if (ZERO_EXTEND == SIGN_EXTEND)
 return ((1) > (bitwidth - (8 * mode_size[(int)(((x)->mode))]) + 1) ? (1) : (bitwidth - (8 * mode_size[(int)(((x)->mode))]) + 1));

      break;

    case CONST_INT:


      nonzero = ((x)->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
      if (bitwidth <= 32
   && (nonzero & ((int) 1 << (bitwidth - 1))) != 0)
 nonzero = (~ nonzero) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));

      return (nonzero == 0 ? bitwidth : bitwidth - floor_log2_wide ((int) (nonzero)) - 1);

    case SUBREG:




      if (((x)->in_struct) && ! ((x)->unchanging))
 return ((bitwidth - (8 * mode_size[(int)(((x)->mode))]) + 1) > (num_sign_bit_copies (((x)->fld[0].rtx), mode)) ? (bitwidth - (8 * mode_size[(int)(((x)->mode))]) + 1) : (num_sign_bit_copies (((x)->fld[0].rtx), mode)))
                                                 ;


      if (bitwidth <= (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
 {
   num0 = num_sign_bit_copies (((x)->fld[0].rtx), VOIDmode);
   return ((1) > ((num0 - ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - bitwidth))) ? (1) : ((num0 - ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - bitwidth))))

                     ;
 }
      if (((mode_size[(int)(((x)->mode))])
    > (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
   && ZERO_EXTEND == SIGN_EXTEND)
 return num_sign_bit_copies (((x)->fld[0].rtx), mode);


      break;

    case SIGN_EXTRACT:
      if (((((x)->fld[1].rtx))->code) == CONST_INT)
 return ((1) > (bitwidth - ((((x)->fld[1].rtx))->fld[0].rtwint)) ? (1) : (bitwidth - ((((x)->fld[1].rtx))->fld[0].rtwint)));
      break;

    case SIGN_EXTEND:
      return (bitwidth - (8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))])
       + num_sign_bit_copies (((x)->fld[0].rtx), VOIDmode));

    case TRUNCATE:

      num0 = num_sign_bit_copies (((x)->fld[0].rtx), VOIDmode);
      return ((1) > ((num0 - ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - bitwidth))) ? (1) : ((num0 - ((8 * mode_size[(int)(((((x)->fld[0].rtx))->mode))]) - bitwidth))))
                      ;

    case NOT:
      return num_sign_bit_copies (((x)->fld[0].rtx), mode);

    case ROTATE: case ROTATERT:



      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) >= 0 && ((((x)->fld[1].rtx))->fld[0].rtwint) < bitwidth)
 {
   num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
   return ((1) > (num0 - (code == ROTATE ? ((((x)->fld[1].rtx))->fld[0].rtwint) : bitwidth - ((((x)->fld[1].rtx))->fld[0].rtwint))) ? (1) : (num0 - (code == ROTATE ? ((((x)->fld[1].rtx))->fld[0].rtwint) : bitwidth - ((((x)->fld[1].rtx))->fld[0].rtwint))))
                                        ;
 }
      break;

    case NEG:




      nonzero = nonzero_bits (((x)->fld[0].rtx), mode);
      if (nonzero == 1)
 return bitwidth;

      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      if (num0 > 1
   && bitwidth <= 32
   && (((int) 1 << (bitwidth - 1)) & nonzero))
 num0--;

      return num0;

    case IOR: case AND: case XOR:
    case SMIN: case SMAX: case UMIN: case UMAX:


      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      num1 = num_sign_bit_copies (((x)->fld[1].rtx), mode);
      return ((num0) < (num1) ? (num0) : (num1));

    case PLUS: case MINUS:





      if (code == PLUS && ((x)->fld[1].rtx) == constm1_rtx
   && bitwidth <= 32)
 {
   nonzero = nonzero_bits (((x)->fld[0].rtx), mode);
   if ((((int) 1 << (bitwidth - 1)) & nonzero) == 0)
     return (nonzero == 1 || nonzero == 0 ? bitwidth
      : bitwidth - floor_log2_wide ((int) (nonzero)) - 1);
 }

      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      num1 = num_sign_bit_copies (((x)->fld[1].rtx), mode);
      return ((1) > (((num0) < (num1) ? (num0) : (num1)) - 1) ? (1) : (((num0) < (num1) ? (num0) : (num1)) - 1));

    case MULT:





      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      num1 = num_sign_bit_copies (((x)->fld[1].rtx), mode);

      result = bitwidth - (bitwidth - num0) - (bitwidth - num1);
      if (result > 0
   && bitwidth <= 32
   && ((nonzero_bits (((x)->fld[0].rtx), mode)
        & ((int) 1 << (bitwidth - 1))) != 0)
   && (nonzero_bits (((x)->fld[1].rtx), mode)
       & ((int) 1 << (bitwidth - 1)) != 0))
 result--;

      return ((1) > (result) ? (1) : (result));

    case UDIV:

      return num_sign_bit_copies (((x)->fld[0].rtx), mode);

    case UMOD:

      return num_sign_bit_copies (((x)->fld[1].rtx), mode);

    case DIV:



      result = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      if (result > 1
   && bitwidth <= 32
   && (nonzero_bits (((x)->fld[1].rtx), mode)
       & ((int) 1 << (bitwidth - 1))) != 0)
 result --;

      return result;

    case MOD:
      result = num_sign_bit_copies (((x)->fld[1].rtx), mode);
      if (result > 1
   && bitwidth <= 32
   && (nonzero_bits (((x)->fld[1].rtx), mode)
       & ((int) 1 << (bitwidth - 1))) != 0)
 result --;

      return result;

    case ASHIFTRT:


      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[1].rtx))->fld[0].rtwint) > 0)
 num0 = ((bitwidth) < (num0 + ((((x)->fld[1].rtx))->fld[0].rtwint)) ? (bitwidth) : (num0 + ((((x)->fld[1].rtx))->fld[0].rtwint)));

      return num0;

    case ASHIFT:

      if (((((x)->fld[1].rtx))->code) != CONST_INT
   || ((((x)->fld[1].rtx))->fld[0].rtwint) < 0
   || ((((x)->fld[1].rtx))->fld[0].rtwint) >= bitwidth)
 return 1;

      num0 = num_sign_bit_copies (((x)->fld[0].rtx), mode);
      return ((1) > (num0 - ((((x)->fld[1].rtx))->fld[0].rtwint)) ? (1) : (num0 - ((((x)->fld[1].rtx))->fld[0].rtwint)));

    case IF_THEN_ELSE:
      num0 = num_sign_bit_copies (((x)->fld[1].rtx), mode);
      num1 = num_sign_bit_copies (((x)->fld[2].rtx), mode);
      return ((num0) < (num1) ? (num0) : (num1));






    }






  if (bitwidth > 32)
    return 1;

  nonzero = nonzero_bits (x, mode);
  return (nonzero & ((int) 1 << (bitwidth - 1))
   ? 1 : bitwidth - floor_log2_wide ((int) (nonzero)) - 1);
}
int
extended_count(rtx x, n64_enum_machine_mode mode, int unsignedp) asm("_extended_count");
int
extended_count(rtx x, n64_enum_machine_mode mode, int unsignedp)
{
  if (nonzero_sign_valid == 0)
    return 0;

  return (unsignedp
   ? ((8 * mode_size[(int)(mode)]) <= 32
      && ((8 * mode_size[(int)(mode)]) - 1
   - floor_log2_wide ((int) (nonzero_bits (x, mode)))))
   : num_sign_bit_copies (x, mode) - 1);
}
static int
merge_outer_ops(n64_enum_rtx_code *pop0, int *pconst0, n64_enum_rtx_code op1, int const1, n64_enum_machine_mode mode, int *pcomp_p) asm("_merge_outer_ops");
static int
merge_outer_ops(n64_enum_rtx_code *pop0, int *pconst0, n64_enum_rtx_code op1, int const1, n64_enum_machine_mode mode, int *pcomp_p)
{
  n64_enum_rtx_code op0 = *pop0;
  int const0 = *pconst0;
  int width = (8 * mode_size[(int)(mode)]);

  const0 &= (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
  const1 &= (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));


  if (op0 == AND)
    const1 &= const0;




  if (op1 == NIL || op0 == SET)
    return 1;

  else if (op0 == NIL)
    op0 = op1, const0 = const1;

  else if (op0 == op1)
    {
      switch (op0)
 {
 case AND:
   const0 &= const1;
   break;
 case IOR:
   const0 |= const1;
   break;
 case XOR:
   const0 ^= const1;
   break;
 case PLUS:
   const0 += const1;
   break;
 case NEG:
   op0 = NIL;
   break;
 }
    }


  else if (op0 == PLUS || op1 == PLUS || op0 == NEG || op1 == NEG)
    return 0;



  else if (const0 != const1)
    return 0;

  else
    switch (op0)
      {
      case IOR:
 if (op1 == AND)

   op0 = SET;
 else

   ;
 break;

      case XOR:
 if (op1 == AND)

   op0 = AND, *pcomp_p = 1;
 else

   op0 = AND, *pconst0 = ~ const0;
 break;

      case AND:
 if (op1 == IOR)

 op0 = SET;
 else

   *pcomp_p = 1;
 break;
      }


  const0 &= (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
  if (const0 == 0
      && (op0 == IOR || op0 == XOR || op0 == PLUS))
    op0 = NIL;
  else if (const0 == 0 && op0 == AND)
    op0 = SET;
  else if (const0 == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) && op0 == AND)
    op0 = NIL;
  if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
      && (const0 & ((int) 1 << (width - 1))))
    const0 |= ((int) (-1) << width);

  *pop0 = op0;
  *pconst0 = const0;

  return 1;
}
static rtx
simplify_shift_const(rtx x, n64_enum_rtx_code code, n64_enum_machine_mode result_mode, rtx varop, int count) asm("_simplify_shift_const");
static rtx
simplify_shift_const(rtx x, n64_enum_rtx_code code, n64_enum_machine_mode result_mode, rtx varop, int count)
{
  n64_enum_rtx_code orig_code = code;
  int orig_count = count;
  n64_enum_machine_mode mode = result_mode;
  n64_enum_machine_mode shift_mode, tmode;
  int mode_words
    = ((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4);

  n64_enum_rtx_code outer_op = NIL;
  int outer_const = 0;
  rtx const_rtx;
  int complement_p = 0;
  rtx cxx_new;




  if (count < 0 || count > (8 * mode_size[(int)(mode)]))
    {
      if (x)
 return x;

      return gen_rtx (code, mode, varop, gen_rtx (CONST_INT, VOIDmode, (int) (count)));
    }




  while (count != 0)
    {


      if (((varop)->code) == CLOBBER)
 return varop;



      if (complement_p)
 break;


      if (code == ROTATERT)
 code = ROTATE, count = (8 * mode_size[(int)(result_mode)]) - count;





      shift_mode
 = (code == ASHIFTRT || code == LSHIFTRT || code == ROTATE
    ? result_mode : mode);
      if (count > (8 * mode_size[(int)(shift_mode)]) - 1)
 {
   if (code == ASHIFTRT)
     count = (8 * mode_size[(int)(shift_mode)]) - 1;
   else if (code == ROTATE || code == ROTATERT)
     count %= (8 * mode_size[(int)(shift_mode)]);
   else
     {


       varop = const0_rtx;
       count = 0;
       break;
     }
 }




      else if (count < 0)
 abort ();



      if (code == ASHIFTRT
   && (num_sign_bit_copies (varop, shift_mode)
       == (8 * mode_size[(int)(shift_mode)])))
 {
   count = 0;
   break;
 }






      if (code == ASHIFTRT
   && (count + num_sign_bit_copies (varop, shift_mode)
       >= (8 * mode_size[(int)(shift_mode)])))
 count = (8 * mode_size[(int)(shift_mode)]) - 1;





      if ((8 * mode_size[(int)(shift_mode)]) <= 32
   && code == ASHIFTRT
   && ((nonzero_bits (varop, shift_mode)
        & ((int) 1 << ((8 * mode_size[(int)(shift_mode)]) - 1)))
       == 0))
 code = LSHIFTRT;

      switch (((varop)->code))
 {
 case SIGN_EXTEND:
 case ZERO_EXTEND:
 case SIGN_EXTRACT:
 case ZERO_EXTRACT:
   cxx_new = expand_compound_operation (varop);
   if (cxx_new != varop)
     {
       varop = cxx_new;
       continue;
     }
   break;

 case MEM:



   if ((code == ASHIFTRT || code == LSHIFTRT)
       && ! mode_dependent_address_p (((varop)->fld[0].rtx))
       && ! ((varop)->volatil)
       && (tmode = mode_for_size ((8 * mode_size[(int)(mode)]) - count,
      MODE_INT, 1)) != BLKmode)
     {
       if (((target_flags & 0x00010000) != 0))
  cxx_new = gen_rtx (MEM, tmode, ((varop)->fld[0].rtx));
       else
  cxx_new = gen_rtx (MEM, tmode,
          plus_constant_wide (((varop)->fld[0].rtx), (int) (count / 8))
                                 );
       ((cxx_new)->unchanging) = ((varop)->unchanging);
       ((cxx_new)->volatil) = ((varop)->volatil);
       ((cxx_new)->in_struct) = ((varop)->in_struct);
       varop = gen_rtx_combine (code == ASHIFTRT ? SIGN_EXTEND
           : ZERO_EXTEND, mode, cxx_new);
       count = 0;
       continue;
     }
   break;

 case USE:




   if ((code == ASHIFTRT || code == LSHIFTRT)
       && (tmode = mode_for_size ((8 * mode_size[(int)(mode)]) - count,
      MODE_INT, 1)) != BLKmode
       && tmode == ((((varop)->fld[0].rtx))->mode))
     {
       if (0)
  cxx_new = ((varop)->fld[0].rtx);
       else
  {
    cxx_new = copy_rtx (((varop)->fld[0].rtx));
    do { rtx _new = (plus_constant_wide (((cxx_new)->fld[0].rtx), (int) (count / 8))); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((cxx_new)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((cxx_new)->fld[0].rtx); ((cxx_new)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((cxx_new)->fld[0].rtx)) undobuf.num_undo++; } } while (0)

                            ;
  }

       varop = gen_rtx_combine (code == ASHIFTRT ? SIGN_EXTEND
           : ZERO_EXTEND, mode, cxx_new);
       count = 0;
       continue;
     }
   break;

 case SUBREG:



   if (subreg_lowpart_p (varop)
       && ((mode_size[(int)(((((varop)->fld[0].rtx))->mode))])
    > (mode_size[(int)(((varop)->mode))]))
       && ((((mode_size[(int)(((((varop)->fld[0].rtx))->mode))])
      + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))
    == mode_words))
     {
       varop = ((varop)->fld[0].rtx);
       if ((mode_size[(int)(((varop)->mode))]) > (mode_size[(int)(mode)]))
  mode = ((varop)->mode);
       continue;
     }
   break;

 case MULT:



   if (((((varop)->fld[1].rtx))->code) == CONST_INT
       && exact_log2_wide ((int) (((((varop)->fld[1].rtx))->fld[0].rtwint))) >= 0)
     {
       varop = gen_binary (ASHIFT, ((varop)->mode), ((varop)->fld[0].rtx),
      gen_rtx (CONST_INT, VOIDmode, (int) (exact_log2_wide ((int) (((((varop)->fld[1].rtx))->fld[0].rtwint))))));;
       continue;
     }
   break;

 case UDIV:

   if (((((varop)->fld[1].rtx))->code) == CONST_INT
       && exact_log2_wide ((int) (((((varop)->fld[1].rtx))->fld[0].rtwint))) >= 0)
     {
       varop = gen_binary (LSHIFTRT, ((varop)->mode), ((varop)->fld[0].rtx),
      gen_rtx (CONST_INT, VOIDmode, (int) (exact_log2_wide ((int) (((((varop)->fld[1].rtx))->fld[0].rtwint))))));
       continue;
     }
   break;

 case ASHIFTRT:


   if (code == LSHIFTRT && count == (8 * mode_size[(int)(result_mode)]) - 1)
     {
       varop = ((varop)->fld[0].rtx);
       continue;
     }



 case LSHIFTRT:
 case ASHIFT:
 case ROTATE:


   if (((((varop)->fld[1].rtx))->code) == CONST_INT
       && ((((varop)->fld[1].rtx))->fld[0].rtwint) >= 0
       && ((((varop)->fld[1].rtx))->fld[0].rtwint) < (8 * mode_size[(int)(((varop)->mode))])
       && (8 * mode_size[(int)(result_mode)]) <= 32
       && (8 * mode_size[(int)(mode)]) <= 32)
     {
       n64_enum_rtx_code first_code = ((varop)->code);
       int first_count = ((((varop)->fld[1].rtx))->fld[0].rtwint);
       unsigned int mask;
       rtx mask_rtx;
       if (code == ASHIFT && first_code == ASHIFTRT
    && ((8 * mode_size[(int)(result_mode)])
        - (8 * mode_size[(int)(((varop)->mode))])) == count)
  {


    mask = ((((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
     & ~ (((int) 1 << first_count) - 1));

    varop = simplify_and_const_int ((rtx) 0, result_mode,
        ((varop)->fld[0].rtx), mask);
    varop = simplify_shift_const ((rtx) 0, ASHIFT, result_mode,
      varop, count);
    count = first_count;
    code = ASHIFTRT;
    continue;
  }
       if (code == ASHIFTRT && first_code == ASHIFT
    && ((varop)->mode) == shift_mode
    && (num_sign_bit_copies (((varop)->fld[0].rtx), shift_mode)
        > first_count))
  {
    count -= first_count;
    if (count < 0)
      count = - count, code = ASHIFT;
    varop = ((varop)->fld[0].rtx);
    continue;
  }
       if (code == first_code)
  {
    if (((varop)->mode) != result_mode
        && (code == ASHIFTRT || code == LSHIFTRT
     || code == ROTATE))
      break;

    count += first_count;
    varop = ((varop)->fld[0].rtx);
    continue;
  }

       if (code == ASHIFTRT
    || (code == ROTATE && first_code == ASHIFTRT)
    || (8 * mode_size[(int)(mode)]) > 32
    || (((varop)->mode) != result_mode
        && (first_code == ASHIFTRT || first_code == LSHIFTRT
     || first_code == ROTATE
     || code == ROTATE)))
  break;





       mask_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (nonzero_bits (varop, ((varop)->mode))));

       mask_rtx
  = simplify_binary_operation (code, result_mode, mask_rtx,
          gen_rtx (CONST_INT, VOIDmode, (int) (count)));


       if (mask_rtx == 0
    || ((mask_rtx)->code) != CONST_INT
    || ! merge_outer_ops (&outer_op, &outer_const, AND,
     ((mask_rtx)->fld[0].rtwint),
     result_mode, &complement_p))
  break;



       if ((code == ASHIFTRT || code == LSHIFTRT)
    == (first_code == ASHIFTRT || first_code == LSHIFTRT))
  count += first_count;
       else
  count -= first_count;





       if (count > 0
    && ((first_code == ROTATE && code == ASHIFT)
        || (first_code == ASHIFTRT && code == LSHIFTRT)))
  code = first_code;
       else if (count < 0)
  code = first_code, count = - count;

       varop = ((varop)->fld[0].rtx);
       continue;
     }





   else if (((varop)->code) == code
     && ((((varop)->fld[1].rtx))->code) != CONST_INT
     && 0 != (cxx_new
       = simplify_binary_operation (code, mode,
        ((varop)->fld[0].rtx),
        gen_rtx (CONST_INT, VOIDmode, (int) (count)))))
     {
       varop = gen_rtx_combine (code, mode, cxx_new, ((varop)->fld[1].rtx));
       count = 0;
       continue;
     }
   break;

 case NOT:

   varop = gen_rtx_combine (XOR, mode, ((varop)->fld[0].rtx),
       gen_rtx (CONST_INT, VOIDmode, (int) ((((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))));
   continue;

 case IOR:
 case AND:
 case XOR:







   if (((varop)->code) == IOR && ((((varop)->fld[0].rtx))->code) == PLUS
       && ((((varop)->fld[0].rtx))->fld[1].rtx) == constm1_rtx
       && (1 == 1 || 1 == -1)
       && (code == LSHIFTRT || code == ASHIFTRT)
       && count == (8 * mode_size[(int)(((varop)->mode))]) - 1
       && rtx_equal_p (((((varop)->fld[0].rtx))->fld[0].rtx), ((varop)->fld[1].rtx)))
     {
       count = 0;
       varop = gen_rtx_combine (LE, ((varop)->mode), ((varop)->fld[1].rtx),
           const0_rtx);

       if (1 == 1 ? code == ASHIFTRT : code == LSHIFTRT)
  varop = gen_rtx_combine (NEG, ((varop)->mode), varop);

       continue;
     }







   if (((((varop)->fld[1].rtx))->code) == CONST_INT
       && (cxx_new = simplify_binary_operation (code, result_mode,
         ((varop)->fld[1].rtx),
         gen_rtx (CONST_INT, VOIDmode, (int) (count)))) != 0
       && ((cxx_new)->code) == CONST_INT
       && merge_outer_ops (&outer_op, &outer_const, ((varop)->code),
      ((cxx_new)->fld[0].rtwint), result_mode, &complement_p))
     {
       varop = ((varop)->fld[0].rtx);
       continue;
     }




   {
     rtx lhs = simplify_shift_const ((rtx) 0, code, shift_mode,
         ((varop)->fld[0].rtx), count);
     rtx rhs = simplify_shift_const ((rtx) 0, code, shift_mode,
         ((varop)->fld[1].rtx), count);

     varop = gen_binary (((varop)->code), shift_mode, lhs, rhs);
     varop = apply_distributive_law (varop);

     count = 0;
   }
   break;

 case EQ:




   if (code == LSHIFTRT
       && ((varop)->fld[1].rtx) == const0_rtx
       && ((((varop)->fld[0].rtx))->mode) == result_mode
       && count == (8 * mode_size[(int)(result_mode)]) - 1
       && (8 * mode_size[(int)(result_mode)]) <= 32
       && ((1
     & ((int) 1 << ((8 * mode_size[(int)(result_mode)]) - 1))))
       && nonzero_bits (((varop)->fld[0].rtx), result_mode) == 1
       && merge_outer_ops (&outer_op, &outer_const, XOR,
      (int) 1, result_mode,
      &complement_p))
     {
       varop = ((varop)->fld[0].rtx);
       count = 0;
       continue;
     }
   break;

 case NEG:


   if (code == LSHIFTRT && count == (8 * mode_size[(int)(result_mode)]) - 1
       && nonzero_bits (((varop)->fld[0].rtx), result_mode) == 1)
     {
       varop = ((varop)->fld[0].rtx);
       count = 0;
       continue;
     }



   if (code == ASHIFT
       && merge_outer_ops (&outer_op, &outer_const, NEG,
      (int) 0, result_mode,
      &complement_p))
     {
       varop = ((varop)->fld[0].rtx);
       continue;
     }
   break;

 case PLUS:



   if (code == LSHIFTRT && count == (8 * mode_size[(int)(result_mode)]) - 1
       && ((varop)->fld[1].rtx) == constm1_rtx
       && nonzero_bits (((varop)->fld[0].rtx), result_mode) == 1
       && merge_outer_ops (&outer_op, &outer_const, XOR,
      (int) 1, result_mode,
      &complement_p))
     {
       count = 0;
       varop = ((varop)->fld[0].rtx);
       continue;
     }







   if ((code == ASHIFTRT || code == LSHIFTRT)
       && count < 32
       && nonzero_bits (((varop)->fld[1].rtx), result_mode) >> count == 0
       && (nonzero_bits (((varop)->fld[1].rtx), result_mode)
    & nonzero_bits (((varop)->fld[0].rtx), result_mode)) == 0)
     {
       varop = ((varop)->fld[0].rtx);
       continue;
     }
   else if ((code == ASHIFTRT || code == LSHIFTRT)
     && count < 32
     && (8 * mode_size[(int)(result_mode)]) <= 32
     && 0 == (nonzero_bits (((varop)->fld[0].rtx), result_mode)
       >> count)
     && 0 == (nonzero_bits (((varop)->fld[0].rtx), result_mode)
       & nonzero_bits (((varop)->fld[1].rtx),
       result_mode)))
     {
       varop = ((varop)->fld[1].rtx);
       continue;
     }


   if (code == ASHIFT
       && ((((varop)->fld[1].rtx))->code) == CONST_INT
       && (cxx_new = simplify_binary_operation (ASHIFT, result_mode,
         ((varop)->fld[1].rtx),
         gen_rtx (CONST_INT, VOIDmode, (int) (count)))) != 0
       && ((cxx_new)->code) == CONST_INT
       && merge_outer_ops (&outer_op, &outer_const, PLUS,
      ((cxx_new)->fld[0].rtwint), result_mode, &complement_p))
     {
       varop = ((varop)->fld[0].rtx);
       continue;
     }
   break;

 case MINUS:







   if (((((varop)->fld[0].rtx))->code) == ASHIFTRT
       && count == (8 * mode_size[(int)(((varop)->mode))]) - 1
       && (1 == 1 || 1 == -1)
       && (code == LSHIFTRT || code == ASHIFTRT)
       && ((((((varop)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((varop)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) == count
       && rtx_equal_p (((((varop)->fld[0].rtx))->fld[0].rtx), ((varop)->fld[1].rtx)))
     {
       count = 0;
       varop = gen_rtx_combine (GT, ((varop)->mode), ((varop)->fld[1].rtx),
           const0_rtx);

       if (1 == 1 ? code == ASHIFTRT : code == LSHIFTRT)
  varop = gen_rtx_combine (NEG, ((varop)->mode), varop);

       continue;
     }
   break;
 }

      break;
    }






  shift_mode
    = (code == ASHIFTRT || code == LSHIFTRT || code == ROTATE
       ? result_mode : mode);
  if (x && (rtx_class[(int)(((x)->code))]) == '2'
      && ((((x)->fld[1].rtx))->code) == CONST_INT
      && ((((x)->fld[1].rtx))->fld[0].rtwint) == count)
    const_rtx = ((x)->fld[1].rtx);
  else
    const_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (count));

  if (x && ((((x)->fld[0].rtx))->code) == SUBREG
      && ((((x)->fld[0].rtx))->mode) == shift_mode
      && ((((x)->fld[0].rtx))->fld[0].rtx) == varop)
    varop = ((x)->fld[0].rtx);
  else if (((varop)->mode) != shift_mode)
    varop = gen_lowpart_for_combine (shift_mode, varop);


  if (((varop)->code) == CLOBBER)
    return x ? x : varop;

  cxx_new = simplify_binary_operation (code, shift_mode, varop, const_rtx);
  if (cxx_new != 0)
    x = cxx_new;
  else
    {
      if (x == 0 || ((x)->code) != code || ((x)->mode) != shift_mode)
 x = gen_rtx_combine (code, shift_mode, varop, const_rtx);

      do { rtx _new = (varop); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[0].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[0].rtx)) undobuf.num_undo++; } } while (0);
      do { rtx _new = (const_rtx); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((x)->fld[1].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((x)->fld[1].rtx); ((x)->fld[1].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((x)->fld[1].rtx)) undobuf.num_undo++; } } while (0);
    }






  if (outer_op != NIL && ((x)->code) == code
      && ((((x)->fld[1].rtx))->code) == CONST_INT)
    x = simplify_shift_const (x, code, shift_mode, ((x)->fld[0].rtx),
         ((((x)->fld[1].rtx))->fld[0].rtwint));



  if (orig_code == LSHIFTRT && result_mode != shift_mode)
    x = simplify_and_const_int ((rtx) 0, shift_mode, x,
    (((8 * mode_size[(int)(result_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(result_mode)])) - 1)) >> orig_count);


  x = gen_lowpart_for_combine (result_mode, x);



  if (complement_p)
    x = gen_unary (NOT, result_mode, result_mode, x);

  if (outer_op != NIL)
    {
      if ((8 * mode_size[(int)(result_mode)]) < 32)
 {
   int width = (8 * mode_size[(int)(result_mode)]);

   outer_const &= (((8 * mode_size[(int)(result_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(result_mode)])) - 1));
   if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
       && (outer_const & ((int) 1 << (width - 1))))
     outer_const |= ((int) (-1) << width);
 }

      if (outer_op == AND)
 x = simplify_and_const_int ((rtx) 0, result_mode, x, outer_const);
      else if (outer_op == SET)


 x = gen_rtx (CONST_INT, VOIDmode, (int) (outer_const));
      else if ((rtx_class[(int)(outer_op)]) == '1')
 x = gen_unary (outer_op, result_mode, result_mode, x);
      else
 x = gen_binary (outer_op, result_mode, x, gen_rtx (CONST_INT, VOIDmode, (int) (outer_const)));
    }

  return x;
}
static int
recog_for_combine(rtx *pnewpat, rtx insn, rtx *pnotes, int *padded_scratches) asm("_recog_for_combine");
static int
recog_for_combine(rtx *pnewpat, rtx insn, rtx *pnotes, int *padded_scratches)
{
  register rtx pat = *pnewpat;
  int insn_code_number;
  int num_clobbers_to_add = 0;
  int i;
  rtx notes = 0;

  *padded_scratches = 0;




  if (((pat)->code) == PARALLEL)
    for (i = ((pat)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
      if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) == CLOBBER
   && ((((pat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx) == const0_rtx)
 return -1;


  insn_code_number = recog (pat, insn, &num_clobbers_to_add);






  if (insn_code_number < 0 && ! check_asm_operands (pat)
      && ((pat)->code) == PARALLEL)
    {
      int pos;

      for (pos = 0, i = 0; i < ((pat)->fld[0].rtvec->num_elem); i++)
 if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) != CLOBBER)
   {
     if (i != pos)
       do { rtx _new = (((pat)->fld[0].rtvec->elem[i].rtx)); if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 0; undobuf.undo[undobuf.num_undo].where.r = &((pat)->fld[0].rtvec->elem[pos].rtx); undobuf.undo[undobuf.num_undo].old_contents.r = ((pat)->fld[0].rtvec->elem[pos].rtx); ((pat)->fld[0].rtvec->elem[pos].rtx) = _new; if (undobuf.undo[undobuf.num_undo].old_contents.r != ((pat)->fld[0].rtvec->elem[pos].rtx)) undobuf.num_undo++; } } while (0);
     pos++;
   }

      do { if (undobuf.num_undo < 50) { undobuf.undo[undobuf.num_undo].is_int = 1; undobuf.undo[undobuf.num_undo].where.i = (int *) &((pat)->fld[0].rtvec->num_elem); undobuf.undo[undobuf.num_undo].old_contents.i = ((pat)->fld[0].rtvec->num_elem); ((pat)->fld[0].rtvec->num_elem) = pos; if (undobuf.undo[undobuf.num_undo].old_contents.i != ((pat)->fld[0].rtvec->num_elem)) undobuf.num_undo++; } } while (0);

      if (pos == 1)
 pat = ((pat)->fld[0].rtvec->elem[0].rtx);

      insn_code_number = recog (pat, insn, &num_clobbers_to_add);
    }



  if (num_clobbers_to_add)
    {
      rtx newpat = gen_rtx (PARALLEL, VOIDmode,
       gen_rtvec (((pat)->code) == PARALLEL
           ? ((pat)->fld[0].rtvec->num_elem) + num_clobbers_to_add
           : num_clobbers_to_add + 1));

      if (((pat)->code) == PARALLEL)
 for (i = 0; i < ((pat)->fld[0].rtvec->num_elem); i++)
   ((newpat)->fld[0].rtvec->elem[i].rtx) = ((pat)->fld[0].rtvec->elem[i].rtx);
      else
 ((newpat)->fld[0].rtvec->elem[0].rtx) = pat;

      add_clobbers (newpat, insn_code_number);

      for (i = ((newpat)->fld[0].rtvec->num_elem) - num_clobbers_to_add;
    i < ((newpat)->fld[0].rtvec->num_elem); i++)
 {
   if (((((((newpat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))->code) == REG
       && ! reg_dead_at_p (((((newpat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx), insn))
     return -1;
   else if (((((((newpat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))->code) == SCRATCH)
     (*padded_scratches)++;
   notes = gen_rtx (EXPR_LIST, REG_UNUSED,
      ((((newpat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx), notes);
 }
      pat = newpat;
    }

  *pnewpat = pat;
  *pnotes = notes;

  return insn_code_number;
}
static rtx
gen_lowpart_for_combine(n64_enum_machine_mode mode, register rtx x) asm("_gen_lowpart_for_combine");
static rtx
gen_lowpart_for_combine(n64_enum_machine_mode mode, register rtx x)
{
  rtx result;

  if (((x)->mode) == mode)
    return x;




  if ((mode_size[(int)(mode)]) > ((target_flags & 0x00002000) ? 8 : 4)
      && ! ((((x)->mode) == VOIDmode
      && (((x)->code) == CONST_INT
   || ((x)->code) == CONST_DOUBLE))
     || (mode_size[(int)(((x)->mode))]) == (mode_size[(int)(mode)])))
    return gen_rtx (CLOBBER, ((x)->mode), const0_rtx);




  if (((x)->code) == SUBREG && ((((x)->fld[0].rtx))->code) == MEM)
    {
      x = ((x)->fld[0].rtx);
      if (((x)->mode) == mode)
 return x;
    }

  result = gen_lowpart_common (mode, x);
  if (result != 0
      && ((result)->code) == SUBREG
      && ((((result)->fld[0].rtx))->code) == REG
      && ((((result)->fld[0].rtx))->fld[0].rtint) >= 68
      && ((mode_size[(int)(((result)->mode))])
   != (mode_size[(int)(((((result)->fld[0].rtx))->mode))])))
    reg_changes_size[((((result)->fld[0].rtx))->fld[0].rtint)] = 1;

  if (result)
    return result;

  if (((x)->code) == MEM)
    {
      register int offset = 0;
      rtx cxx_new;



      if (((x)->volatil) || mode_dependent_address_p (((x)->fld[0].rtx)))
 return gen_rtx (CLOBBER, ((x)->mode), const0_rtx);




      if ((mode_size[(int)(((x)->mode))]) < (mode_size[(int)(mode)]))
 return gen_rtx (SUBREG, mode, x, 0);

      if (((target_flags & 0x00010000) != 0))
 offset = ((((mode_size[(int)(((x)->mode))])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(((x)->mode))])) : (((target_flags & 0x00002000) ? 8 : 4)))
    - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))));
      if (((target_flags & 0x00010000) != 0))
 {


   offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)])))
       - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((x)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((x)->mode))]))));
 }
      cxx_new = gen_rtx (MEM, mode, plus_constant_wide (((x)->fld[0].rtx), (int) (offset)));
      ((cxx_new)->unchanging) = ((x)->unchanging);
      ((cxx_new)->volatil) = ((x)->volatil);
      ((cxx_new)->in_struct) = ((x)->in_struct);
      return cxx_new;
    }



  else if ((rtx_class[(int)(((x)->code))]) == '<')
    return gen_rtx_combine (((x)->code), mode, ((x)->fld[0].rtx), ((x)->fld[1].rtx));




  else
    {
      int word = 0;

      if (((target_flags & 0x00010000) != 0) && (mode_size[(int)(((x)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 word = (((mode_size[(int)(((x)->mode))])
   - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))))
  / ((target_flags & 0x00002000) ? 8 : 4));
      return gen_rtx (SUBREG, mode, x, word);
    }
}
static rtx
gen_rtx_combine (n64_enum_rtx_code code, n64_enum_machine_mode mode, ...) asm("_gen_rtx_combine");
static rtx
gen_rtx_combine (n64_enum_rtx_code code, n64_enum_machine_mode mode, ...)
{




  va_list p;
  int n_args;
  rtx args[3];
  int i, j;
  char *fmt;
  rtx rt;

  
 __builtin_va_start(
 p
 ,
 mode
 )
                   ;






  n_args = (rtx_length[(int)(code)]);
  fmt = (rtx_format[(int)(code)]);

  if (n_args == 0 || n_args > 3)
    abort ();


  for (j = 0; j < n_args; j++)
    {
      if (*fmt++ != 'e')
 abort ();

      args[j] = 
               __builtin_va_arg(
               p
               ,
               rtx
               )
                              ;
    }




  for (i = previous_num_undos; i < undobuf.num_undo; i++)
    if (!undobuf.undo[i].is_int
 && ((undobuf.undo[i].old_contents.r)->code) == code
 && ((undobuf.undo[i].old_contents.r)->mode) == mode)
      {
 for (j = 0; j < n_args; j++)
   if (((undobuf.undo[i].old_contents.r)->fld[j].rtx) != args[j])
     break;

 if (j == n_args)
   return undobuf.undo[i].old_contents.r;
      }



  rt = rtx_alloc (code);
  ((rt)->mode = (mode));
  ((rt)->fld[0].rtx) = args[0];
  if (n_args > 1)
    {
      ((rt)->fld[1].rtx) = args[1];
      if (n_args > 2)
 ((rt)->fld[2].rtx) = args[2];
    }
  return rt;
}




static rtx
gen_binary(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1) asm("_gen_binary");
static rtx
gen_binary(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1)
{
  rtx result;
  rtx tem;

  if ((rtx_class[(int)(code)]) == 'c'
      && (((op0)->code) == CONST_INT
   || ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ((op1)->code) != CONST_INT)))
    tem = op0, op0 = op1, op1 = tem;

  if ((rtx_class[(int)(code)]) == '<')
    {
      n64_enum_machine_mode op_mode = ((op0)->mode);



      if (((op0)->code) == COMPARE && op1 == const0_rtx)
 {
   op1 = ((op0)->fld[1].rtx);
   op0 = ((op0)->fld[0].rtx);
   op_mode = ((op0)->mode);
 }

      if (op_mode == VOIDmode)
 op_mode = ((op1)->mode);
      result = simplify_relational_operation (code, op_mode, op0, op1);
    }
  else
    result = simplify_binary_operation (code, mode, op0, op1);

  if (result)
    return result;


  if ((rtx_class[(int)(code)]) == 'c'
      && (((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ((op1)->code) != CONST_INT)
   || ((rtx_class[(int)(((op0)->code))]) == 'o'
       && (rtx_class[(int)(((op1)->code))]) != 'o')
   || (((op0)->code) == SUBREG
       && (rtx_class[(int)(((((op0)->fld[0].rtx))->code))]) == 'o'
       && (rtx_class[(int)(((op1)->code))]) != 'o')))
    return gen_rtx_combine (code, mode, op1, op0);

  return gen_rtx_combine (code, mode, op0, op1);
}

static rtx
gen_unary(n64_enum_rtx_code code, n64_enum_machine_mode mode, n64_enum_machine_mode op0_mode, rtx op0) asm("_gen_unary");
static rtx
gen_unary(n64_enum_rtx_code code, n64_enum_machine_mode mode, n64_enum_machine_mode op0_mode, rtx op0)
{
  rtx result = simplify_unary_operation (code, mode, op0, op0_mode);

  if (result)
    return result;

  return gen_rtx_combine (code, mode, op0);
}
static n64_enum_rtx_code
simplify_comparison(n64_enum_rtx_code code, rtx *pop0, rtx *pop1) asm("_simplify_comparison");
static n64_enum_rtx_code
simplify_comparison(n64_enum_rtx_code code, rtx *pop0, rtx *pop1)
{
  rtx op0 = *pop0;
  rtx op1 = *pop1;
  rtx tem, tem1;
  int i;
  n64_enum_machine_mode mode, tmode;


  while (1)
    {
      if (((op0)->code) == ((op1)->code)
   && (8 * mode_size[(int)(((op0)->mode))]) <= 32
   && ((((op0)->code) == ROTATE && (code == NE || code == EQ))
       || ((((op0)->code) == LSHIFTRT || ((op0)->code) == ASHIFT)
    && (code != GT && code != LT && code != GE && code != LE))
       || (((op0)->code) == ASHIFTRT
    && (code != GTU && code != LTU
        && code != GEU && code != GEU)))
   && ((((op0)->fld[1].rtx))->code) == CONST_INT
   && ((((op0)->fld[1].rtx))->fld[0].rtwint) >= 0
   && ((((op0)->fld[1].rtx))->fld[0].rtwint) < 32
   && ((op0)->fld[1].rtx) == ((op1)->fld[1].rtx))
 {
   n64_enum_machine_mode mode = ((op0)->mode);
   unsigned int mask = (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
   int shift_count = ((((op0)->fld[1].rtx))->fld[0].rtwint);

   if (((op0)->code) == LSHIFTRT || ((op0)->code) == ASHIFTRT)
     mask &= (mask >> shift_count) << shift_count;
   else if (((op0)->code) == ASHIFT)
     mask = (mask & (mask << shift_count)) >> shift_count;

   if ((nonzero_bits (((op0)->fld[0].rtx), mode) & ~ mask) == 0
       && (nonzero_bits (((op1)->fld[0].rtx), mode) & ~ mask) == 0)
     op0 = ((op0)->fld[0].rtx), op1 = ((op1)->fld[0].rtx);
   else
     break;
 }
      else if (((op0)->code) == AND && ((op1)->code) == AND
  && ((((op0)->fld[1].rtx))->code) == CONST_INT
  && ((((op1)->fld[1].rtx))->code) == CONST_INT)
 {
   rtx inner_op0 = ((op0)->fld[0].rtx);
   rtx inner_op1 = ((op1)->fld[0].rtx);
   int c0 = ((((op0)->fld[1].rtx))->fld[0].rtwint);
   int c1 = ((((op1)->fld[1].rtx))->fld[0].rtwint);
   int changed = 0;

   if (((inner_op0)->code) == SUBREG && ((inner_op1)->code) == SUBREG
       && ((mode_size[(int)(((inner_op0)->mode))])
    > (mode_size[(int)(((((inner_op0)->fld[0].rtx))->mode))]))
       && (((((inner_op0)->fld[0].rtx))->mode)
    == ((((inner_op1)->fld[0].rtx))->mode))
       && ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])
    <= 32)
       && (0 == (~c0) & nonzero_bits (((inner_op0)->fld[0].rtx),
          ((((op0)->fld[0].rtx))->mode)))
       && (0 == (~c1) & nonzero_bits (((inner_op1)->fld[0].rtx),
          ((((inner_op1)->fld[0].rtx))->mode))))
     {
       op0 = ((inner_op0)->fld[0].rtx);
       op1 = ((inner_op1)->fld[0].rtx);



       code = unsigned_condition (code);

       changed = 1;
     }

   else if (c0 == c1)
     for (tmode = class_narrowest_mode[(int)((mode_class[(int)(((op0)->mode))]))]
                                    ;
   tmode != ((op0)->mode); tmode = (mode_wider_mode[(int)(tmode)]))
       if (c0 == (((8 * mode_size[(int)(tmode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(tmode)])) - 1)))
  {
    op0 = gen_lowpart_for_combine (tmode, inner_op0);
    op1 = gen_lowpart_for_combine (tmode, inner_op1);
    code = unsigned_condition (code);
    changed = 1;
    break;
  }

   if (! changed)
     break;
 }




      else if ((((op0)->code) == NOT && ((op1)->code) == NOT)
        || (((op0)->code) == NEG && ((op1)->code) == NEG
     && (code == EQ || code == NE)))
 op0 = ((op0)->fld[0].rtx), op1 = ((op1)->fld[0].rtx), code = swap_condition (code);

      else
 break;
    }



  if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
    {
      tem = op0, op0 = op1, op1 = tem;
      code = swap_condition (code);
    }






  while (((op1)->code) == CONST_INT)
    {
      n64_enum_machine_mode mode = ((op0)->mode);
      int mode_width = (8 * mode_size[(int)(mode)]);
      unsigned int mask = (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
      int equality_comparison_p;
      int sign_bit_comparison_p;
      int unsigned_comparison_p;
      int const_op;






      if ((mode_class[(int)(mode)]) != MODE_INT
   && ! (mode == VOIDmode
  && (((op0)->code) == COMPARE
      || (rtx_class[(int)(((op0)->code))]) == '<')))
 break;



      const_op = ((op1)->fld[0].rtwint);
      if (mode_width <= 32)
 const_op &= mask;





      if (const_op
   && (code == EQ || code == NE || code == GE || code == GEU
       || code == LT || code == LTU)
   && mode_width <= 32
   && exact_log2_wide ((int) (const_op)) >= 0
   && nonzero_bits (op0, mode) == const_op)
 {
   code = (code == EQ || code == GE || code == GEU ? NE : EQ);
   op1 = const0_rtx, const_op = 0;
 }




      if (const_op == -1
   && (code == EQ || code == NE || code == GT || code == LE
       || code == GEU || code == LTU)
   && num_sign_bit_copies (op0, mode) == mode_width)
 {
   code = (code == EQ || code == LE || code == GEU ? NE : EQ);
   op1 = const0_rtx, const_op = 0;
 }





      switch (code)
 {
 case LT:

   if (const_op > 0)
     {
       const_op -= 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = LE;

     }
   else
     break;

 case LE:

   if (const_op < 0)
     {
       const_op += 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = LT;
     }



   else if (const_op == 0
     && mode_width <= 32
     && (nonzero_bits (op0, mode)
         & ((int) 1 << (mode_width - 1))) == 0)
     code = EQ;
   break;

 case GE:

   if (const_op > 0)
     {
       const_op -= 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = GT;

     }
   else
     break;

 case GT:

   if (const_op < 0)
     {
       const_op += 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = GE;
     }



   else if (const_op == 0
     && mode_width <= 32
     && (nonzero_bits (op0, mode)
         & ((int) 1 << (mode_width - 1))) == 0)
     code = NE;
   break;

 case LTU:

   if (const_op > 0)
     {
       const_op -= 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = LEU;

     }


   else if (const_op == (int) 1 << (mode_width - 1))
     {
       const_op = 0, op1 = const0_rtx;
       code = GE;
       break;
     }
   else
     break;

 case LEU:

   if (const_op == 0)
     code = EQ;


   else if (const_op == ((int) 1 << (mode_width - 1)) - 1)
     {
       const_op = 0, op1 = const0_rtx;
       code = GE;
     }
   break;

 case GEU:

   if (const_op > 1)
     {
       const_op -= 1;
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       code = GTU;

     }


   else if (const_op == (int) 1 << (mode_width - 1))
     {
       const_op = 0, op1 = const0_rtx;
       code = LT;
       break;
     }
   else
     break;

 case GTU:

   if (const_op == 0)
     code = NE;


   else if (const_op == ((int) 1 << (mode_width - 1)) - 1)
     {
       const_op = 0, op1 = const0_rtx;
       code = LT;
     }
   break;
 }



      equality_comparison_p = (code == EQ || code == NE);
      sign_bit_comparison_p = ((code == LT || code == GE) && const_op == 0);
      unsigned_comparison_p = (code == LTU || code == LEU || code == GTU
          || code == LEU);



      if (sign_bit_comparison_p
   && (8 * mode_size[(int)(mode)]) <= 32)
 op0 = force_to_mode (op0, mode,
        ((int) 1
         << ((8 * mode_size[(int)(mode)]) - 1)),
        (rtx) 0, 0);





      switch (((op0)->code))
 {
 case ZERO_EXTRACT:







   if (((((op0)->fld[0].rtx))->code) == CONST_INT
       && ((op0)->fld[1].rtx) == const1_rtx
       && equality_comparison_p && const_op == 0
       && (i = exact_log2_wide ((int) (((((op0)->fld[0].rtx))->fld[0].rtwint)))) >= 0
       && (! 0

    || 1

    ))
     {

       if (0)
  i = ((8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_extzv][1])])
                                                    - 1 - i);


       op0 = ((op0)->fld[2].rtx);
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (i));
       const_op = i;


       code = reverse_condition (code);
       continue;
     }



 case SIGN_EXTRACT:
   tem = expand_compound_operation (op0);
   if (tem != op0)
     {
       op0 = tem;
       continue;
     }
   break;

 case NOT:

   if (equality_comparison_p
       && (tem = simplify_unary_operation (NOT, mode, op1, mode)) != 0)
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }



   if (sign_bit_comparison_p)
     {
       op0 = ((op0)->fld[0].rtx);
       code = (code == GE ? LT : GE);
       continue;
     }
   break;

 case NEG:

   if (equality_comparison_p
       && (tem = simplify_unary_operation (NEG, mode, op1, mode)) != 0)
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }


   if (const_op != 0)
     break;




   if (sign_bit_comparison_p
       && (((((op0)->fld[0].rtx))->code) == ABS
    || (mode_width <= 32
        && (nonzero_bits (((op0)->fld[0].rtx), mode)
     & ((int) 1 << (mode_width - 1))) == 0)))
     {
       op0 = ((op0)->fld[0].rtx);
       code = (code == LT ? NE : EQ);
       continue;
     }



   if (num_sign_bit_copies (op0, mode) >= 2)
     {
       op0 = ((op0)->fld[0].rtx);
       code = swap_condition (code);
       continue;
     }
   break;

 case ROTATE:


   if (equality_comparison_p && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && (tem = simplify_binary_operation (ROTATERT, mode,
         op1, ((op0)->fld[1].rtx))) != 0)
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }




   if (const_op == 0 && sign_bit_comparison_p
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && mode_width <= 32)
     {
       op0 = simplify_and_const_int ((rtx) 0, mode, ((op0)->fld[0].rtx),
         ((int) 1
          << (mode_width - 1
       - ((((op0)->fld[1].rtx))->fld[0].rtwint))));
       code = (code == LT ? NE : EQ);
       continue;
     }



 case ABS:

   if (const_op == 0 && equality_comparison_p)
     {
       op0 = ((op0)->fld[0].rtx);
       continue;
     }
   break;


 case SIGN_EXTEND:




   if (! unsigned_comparison_p
       && ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])
    <= 32)
       && ((unsigned int) const_op
    < (((int) 1
        << ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))]) - 1)))))
     {
       op0 = ((op0)->fld[0].rtx);
       continue;
     }
   break;

 case SUBREG:
   if (mode_width <= 32
       && subreg_lowpart_p (op0)
       && ((((op0)->fld[0].rtx))->code) == PLUS
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) < 0
       && (- ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint)
    < (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) / 2)
       && (unsigned int) const_op < (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) / 2
       && (0 == (nonzero_bits (((((op0)->fld[0].rtx))->fld[0].rtx),
          ((((op0)->fld[0].rtx))->mode))
   & ~ (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
    || (num_sign_bit_copies (((((op0)->fld[0].rtx))->fld[0].rtx),
        ((((op0)->fld[0].rtx))->mode))
        > ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])
    - (8 * mode_size[(int)(mode)])))))
     {
       op0 = ((op0)->fld[0].rtx);
       continue;
     }



   if (subreg_lowpart_p (op0)
       && (8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))]) < mode_width)
                        ;
   else
     break;



 case ZERO_EXTEND:
   if ((unsigned_comparison_p || equality_comparison_p)
       && ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])
    <= 32)
       && ((unsigned int) const_op
    < (((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])) - 1))))
     {
       op0 = ((op0)->fld[0].rtx);
       continue;
     }
   break;

 case PLUS:



   if (equality_comparison_p
       && 0 != (tem = simplify_binary_operation (MINUS, mode,
       op1, ((op0)->fld[1].rtx))))
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }


   if (const_op == 0 && ((op0)->fld[1].rtx) == constm1_rtx
       && ((((op0)->fld[0].rtx))->code) == ABS && sign_bit_comparison_p)
     {
       op0 = ((((op0)->fld[0].rtx))->fld[0].rtx);
       code = (code == LT ? EQ : NE);
       continue;
     }
   break;

 case MINUS:




   if (equality_comparison_p
       && 0 != (tem = simplify_binary_operation (PLUS, mode,
       ((op0)->fld[1].rtx), op1)))
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }

   if (equality_comparison_p
       && 0 != (tem = simplify_binary_operation (MINUS, mode,
       ((op0)->fld[0].rtx), op1)))
     {
       op0 = ((op0)->fld[1].rtx);
       op1 = tem;
       continue;
     }



   if (sign_bit_comparison_p && ((((op0)->fld[0].rtx))->code) == ASHIFTRT
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) == mode_width - 1
       && rtx_equal_p (((((op0)->fld[0].rtx))->fld[0].rtx), ((op0)->fld[1].rtx)))
     {
       op0 = ((op0)->fld[1].rtx);
       code = (code == GE ? LE : GT);
       continue;
     }
   break;

 case XOR:


   if (equality_comparison_p
       && 0 != (tem = simplify_binary_operation (XOR, mode,
       ((op0)->fld[1].rtx), op1)))
     {
       op0 = ((op0)->fld[0].rtx);
       op1 = tem;
       continue;
     }
   break;

 case EQ: case NE:
 case LT: case LTU: case LE: case LEU:
 case GT: case GTU: case GE: case GEU:


   if (const_op != 0



       || (mode_class[(int)(((((op0)->fld[0].rtx))->mode))]) == MODE_CC)
     break;


   if (((((op0)->fld[0].rtx))->code) == COMPARE)
     tem = ((((op0)->fld[0].rtx))->fld[0].rtx), tem1 = ((((op0)->fld[0].rtx))->fld[1].rtx);
   else
     tem = ((op0)->fld[0].rtx), tem1 = ((op0)->fld[1].rtx);



   if (code == NE
       || (code == EQ && reversible_comparison_p (op0))
       || ((8 * mode_size[(int)(((op0)->mode))]) <= 32
    && (mode_class[(int)(((op0)->mode))]) == MODE_INT
    && (1
        & (((int) 1
     << ((8 * mode_size[(int)(((op0)->mode))]) - 1))))
    && (code == LT
        || (code == GE && reversible_comparison_p (op0)))))
     {
       code = (code == LT || code == NE
        ? ((op0)->code) : reverse_condition (((op0)->code)));
       op0 = tem, op1 = tem1;
       continue;
     }
   break;

 case IOR:


   if (sign_bit_comparison_p && ((((op0)->fld[0].rtx))->code) == PLUS
       && ((((op0)->fld[0].rtx))->fld[1].rtx) == constm1_rtx
       && rtx_equal_p (((((op0)->fld[0].rtx))->fld[0].rtx), ((op0)->fld[1].rtx)))
     {
       op0 = ((op0)->fld[1].rtx);
       code = (code == GE ? GT : LE);
       continue;
     }
   break;

 case AND:


   if (const_op == 0 && equality_comparison_p
       && ((((op0)->fld[0].rtx))->code) == ASHIFT
       && ((((op0)->fld[0].rtx))->fld[0].rtx) == const1_rtx)
     {
       op0 = simplify_and_const_int
  (op0, mode, gen_rtx_combine (LSHIFTRT, mode,
          ((op0)->fld[1].rtx),
          ((((op0)->fld[0].rtx))->fld[1].rtx)),
   (int) 1);
       continue;
     }




   if (const_op == 0 && equality_comparison_p
       && mode_width <= 32
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[0].rtx))->code) == LSHIFTRT
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) >= 0
       && ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) < 32)
     {
       mask = ((((((op0)->fld[1].rtx))->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
        << ((((((op0)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint));
       if ((~ 1 & mask) == 0
    && ((rtx_class[(int)(((((((op0)->fld[0].rtx))->fld[0].rtx))->code))]) == '<'
        || ((tem = get_last_value (((((op0)->fld[0].rtx))->fld[0].rtx))) != 0
     && (rtx_class[(int)(((tem)->code))]) == '<')))
  {
    op0 = ((((op0)->fld[0].rtx))->fld[0].rtx);
    continue;
  }
     }




   if (equality_comparison_p
       && const_op == 0
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && mode_width <= 32
       && ((((((op0)->fld[1].rtx))->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
    == (int) 1 << (mode_width - 1)))
     {
       op0 = ((op0)->fld[0].rtx);
       code = (code == EQ ? GE : LT);
       continue;
     }





   if ((equality_comparison_p || unsigned_comparison_p)
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && (i = exact_log2_wide ((int) ((((((op0)->fld[1].rtx))->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) + 1))

          ) >= 0
       && const_op >> i == 0
       && (tmode = mode_for_size (i, MODE_INT, 1)) != BLKmode)
     {
       op0 = gen_lowpart_for_combine (tmode, ((op0)->fld[0].rtx));
       continue;
     }
   break;

 case ASHIFT:





   if (((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[1].rtx))->fld[0].rtwint) >= 0
       && ((((((op0)->fld[1].rtx))->fld[0].rtwint) + ! equality_comparison_p)
    < 32)
       && ((const_op
     & (((int) 1 << ((((op0)->fld[1].rtx))->fld[0].rtwint)) - 1)) == 0)
       && mode_width <= 32
       && (nonzero_bits (((op0)->fld[0].rtx), mode)
    & ~ (mask >> (((((op0)->fld[1].rtx))->fld[0].rtwint)
    + ! equality_comparison_p))) == 0)
     {
       const_op >>= ((((op0)->fld[1].rtx))->fld[0].rtwint);
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       op0 = ((op0)->fld[0].rtx);
       continue;
     }



   if (sign_bit_comparison_p && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && mode_width <= 32)
     {
       op0 = simplify_and_const_int ((rtx) 0, mode, ((op0)->fld[0].rtx),
         ((int) 1
          << (mode_width - 1
       - ((((op0)->fld[1].rtx))->fld[0].rtwint))));
       code = (code == LT ? NE : EQ);
       continue;
     }




   if (const_op == 0 && equality_comparison_p
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[1].rtx))->fld[0].rtwint) == mode_width - 1)
     {
       op0 = simplify_and_const_int ((rtx) 0, mode, ((op0)->fld[0].rtx),
         (int) 1);
       continue;
     }
   break;

 case ASHIFTRT:


   if (equality_comparison_p && const_op == 0
       && ((((op0)->fld[1].rtx))->code) == CONST_INT)
     {
       op0 = simplify_shift_const ((rtx) 0, LSHIFTRT, mode,
       ((op0)->fld[0].rtx),
       ((((op0)->fld[1].rtx))->fld[0].rtwint));
       continue;
     }



   if (! unsigned_comparison_p
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[0].rtx))->code) == ASHIFT
       && ((op0)->fld[1].rtx) == ((((op0)->fld[0].rtx))->fld[1].rtx)
       && (tmode = mode_for_size (mode_width - ((((op0)->fld[1].rtx))->fld[0].rtwint),
      MODE_INT, 1)) != BLKmode
       && ((unsigned int) const_op <= (((8 * mode_size[(int)(tmode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(tmode)])) - 1))
    || ((unsigned int) - const_op
        <= (((8 * mode_size[(int)(tmode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(tmode)])) - 1)))))
     {
       op0 = gen_lowpart_for_combine (tmode, ((((op0)->fld[0].rtx))->fld[0].rtx));
       continue;
     }


 case LSHIFTRT:




   if (((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[1].rtx))->fld[0].rtwint) >= 0
       && ((((op0)->fld[1].rtx))->fld[0].rtwint) < 32
       && mode_width <= 32
       && (nonzero_bits (((op0)->fld[0].rtx), mode)
    & (((int) 1 << ((((op0)->fld[1].rtx))->fld[0].rtwint)) - 1)) == 0
       && (const_op == 0
    || (floor_log2_wide ((int) (const_op)) + ((((op0)->fld[1].rtx))->fld[0].rtwint)
        < mode_width)))
     {
       const_op <<= ((((op0)->fld[1].rtx))->fld[0].rtwint);
       op1 = gen_rtx (CONST_INT, VOIDmode, (int) (const_op));
       op0 = ((op0)->fld[0].rtx);
       continue;
     }



   if (const_op == 0
       && (equality_comparison_p || sign_bit_comparison_p)
       && ((((op0)->fld[1].rtx))->code) == CONST_INT
       && ((((op0)->fld[1].rtx))->fld[0].rtwint) == mode_width - 1)
     {
       op0 = ((op0)->fld[0].rtx);
       code = (code == NE || code == GT ? LT : GE);
       continue;
     }
   break;
 }

      break;
    }
  op0 = make_compound_operation (op0, op1 == const0_rtx ? COMPARE : SET);
  op1 = make_compound_operation (op1, SET);

  if (((op0)->code) == SUBREG && subreg_lowpart_p (op0)
      && (mode_class[(int)(((op0)->mode))]) == MODE_INT
      && (code == NE || code == EQ)
      && (((mode_size[(int)(((op0)->mode))])
    > (mode_size[(int)(((((op0)->fld[0].rtx))->mode))]))))
    {
      op0 = ((op0)->fld[0].rtx);
      op1 = gen_lowpart_for_combine (((op0)->mode), op1);
    }

  else if (((op0)->code) == SUBREG && subreg_lowpart_p (op0)
    && (mode_class[(int)(((op0)->mode))]) == MODE_INT
    && (code == NE || code == EQ)
    && ((8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))])
        <= 32)
    && (nonzero_bits (((op0)->fld[0].rtx), ((((op0)->fld[0].rtx))->mode))
        & ~ (((8 * mode_size[(int)(((op0)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((op0)->mode))])) - 1))) == 0
    && (tem = gen_lowpart_for_combine (((((op0)->fld[0].rtx))->mode),
           op1),
        (nonzero_bits (tem, ((((op0)->fld[0].rtx))->mode))
  & ~ (((8 * mode_size[(int)(((op0)->mode))]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(((op0)->mode))])) - 1))) == 0))
    op0 = ((op0)->fld[0].rtx), op1 = tem;







  mode = ((op0)->mode);
  if (mode != VOIDmode && (mode_class[(int)(mode)]) == MODE_INT
      && (mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4)
      && cmp_optab->handlers[(int) mode].insn_code == CODE_FOR_nothing)
    for (tmode = (mode_wider_mode[(int)(mode)]);
  (tmode != VOIDmode
   && (8 * mode_size[(int)(tmode)]) <= 32);
  tmode = (mode_wider_mode[(int)(tmode)]))
      if (cmp_optab->handlers[(int) tmode].insn_code != CODE_FOR_nothing)
 {




   if (((code == EQ || code == NE
  || code == GEU || code == GTU || code == LEU || code == LTU)
        && (nonzero_bits (op0, tmode) & ~ (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) == 0
        && (nonzero_bits (op1, tmode) & ~ (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) == 0)
       || ((num_sign_bit_copies (op0, tmode)
     > (8 * mode_size[(int)(tmode)]) - (8 * mode_size[(int)(mode)]))
    && (num_sign_bit_copies (op1, tmode)
        > (8 * mode_size[(int)(tmode)]) - (8 * mode_size[(int)(mode)]))))
     {
       op0 = gen_lowpart_for_combine (tmode, op0);
       op1 = gen_lowpart_for_combine (tmode, op1);
       break;
     }




   if (op1 == const0_rtx && (code == LT || code == GE)
       && (8 * mode_size[(int)(mode)]) <= 32)
     {
       op0 = gen_binary (AND, tmode,
    gen_lowpart_for_combine (tmode, op0),
    gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << ((8 * mode_size[(int)(mode)]) - 1)))
                                       );
       code = (code == LT) ? NE : EQ;
       break;
     }
 }







  *pop0 = op0;
  *pop1 = op1;

  return code;
}





static int
reversible_comparison_p(rtx x) asm("_reversible_comparison_p");
static int
reversible_comparison_p(rtx x)
{
  if (1 != 1
      || flag_fast_math
      || ((x)->code) == NE || ((x)->code) == EQ)
    return 1;

  switch ((mode_class[(int)(((((x)->fld[0].rtx))->mode))]))
    {
    case MODE_INT:
    case MODE_PARTIAL_INT:
    case MODE_COMPLEX_INT:
      return 1;

    case MODE_CC:


      if (0)
 return 1;



      x = get_last_value (((x)->fld[0].rtx));
      return (x && ((x)->code) == COMPARE
       && ! ((mode_class[(int)(((((x)->fld[0].rtx))->mode))]) == MODE_FLOAT || (mode_class[(int)(((((x)->fld[0].rtx))->mode))]) == MODE_COMPLEX_FLOAT));
    }

  return 0;
}





static void
update_table_tick(rtx x) asm("_update_table_tick");
static void
update_table_tick(rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);
  register char *fmt = (rtx_format[(int)(code)]);
  register int i;

  if (code == REG)
    {
      int regno = ((x)->fld[0].rtint);
      int endregno = regno + (regno < 68
         ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

      for (i = regno; i < endregno; i++)
 reg_last_set_table_tick[i] = label_tick;

      return;
    }

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)


    if (fmt[i] == 'e')
      update_table_tick (((x)->fld[i].rtx));
}






static void
record_value_for_reg(rtx reg, rtx insn, rtx value) asm("_record_value_for_reg");
static void
record_value_for_reg(rtx reg, rtx insn, rtx value)
{
  int regno = ((reg)->fld[0].rtint);
  int endregno = regno + (regno < 68
     ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);
  int i;



  if (value && insn && reg_overlap_mentioned_p (reg, value))
    {
      rtx tem;



      subst_low_cuid = (((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)]);
      tem = get_last_value (reg);

      if (tem)
 value = replace_rtx (copy_rtx (value), reg, tem);
    }





  for (i = regno; i < endregno; i ++)
    {
      if (insn)
 reg_last_set[i] = insn;
      reg_last_set_value[i] = 0;
      reg_last_set_mode[i] = 0;
      reg_last_set_nonzero_bits[i] = 0;
      reg_last_set_sign_bit_copies[i] = 0;
      reg_last_death[i] = 0;
    }


  if (value)
    update_table_tick (value);
  for (i = regno; i < endregno; i++)
    {
      reg_last_set_label[i] = label_tick;
      if (value && reg_last_set_table_tick[i] == label_tick)
 reg_last_set_invalid[i] = 1;
      else
 reg_last_set_invalid[i] = 0;
    }




  if (value && ! get_last_value_validate (&value,
       reg_last_set_label[regno], 0))
    {
      value = copy_rtx (value);
      if (! get_last_value_validate (&value, reg_last_set_label[regno], 1))
 value = 0;
    }




  reg_last_set_value[regno] = value;

  if (value)
    {
      subst_low_cuid = (((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)]);
      reg_last_set_mode[regno] = ((reg)->mode);
      reg_last_set_nonzero_bits[regno] = nonzero_bits (value, ((reg)->mode));
      reg_last_set_sign_bit_copies[regno]
 = num_sign_bit_copies (value, ((reg)->mode));
    }
}


static rtx record_dead_insn;




static void
record_dead_and_set_regs_1(rtx dest, rtx setter) asm("_record_dead_and_set_regs_1");
static void
record_dead_and_set_regs_1(rtx dest, rtx setter)
{
  if (((dest)->code) == SUBREG)
    dest = ((dest)->fld[0].rtx);

  if (((dest)->code) == REG)
    {



      if (((setter)->code) == SET && dest == ((setter)->fld[0].rtx))
 record_value_for_reg (dest, record_dead_insn, ((setter)->fld[1].rtx));
      else if (((setter)->code) == SET
        && ((((setter)->fld[0].rtx))->code) == SUBREG
        && ((((setter)->fld[0].rtx))->fld[0].rtx) == dest
        && (8 * mode_size[(int)(((dest)->mode))]) <= ((target_flags & 0x00002000) ? 64 : 32)
        && subreg_lowpart_p (((setter)->fld[0].rtx)))
 record_value_for_reg (dest, record_dead_insn,
         gen_lowpart_for_combine (((dest)->mode),
             ((setter)->fld[1].rtx)));
      else
 record_value_for_reg (dest, record_dead_insn, (rtx) 0);
    }
  else if (((dest)->code) == MEM

    && ! push_operand (dest, ((dest)->mode)))
    mem_last_set = (((record_dead_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((record_dead_insn)->fld[0].rtint)]);
}
static void
record_dead_and_set_regs(rtx insn) asm("_record_dead_and_set_regs");
static void
record_dead_and_set_regs(rtx insn)
{
  register rtx link;
  int i;

  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    {
      if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
   && ((((link)->fld[0].rtx))->code) == REG)
 {
   int regno = ((((link)->fld[0].rtx))->fld[0].rtint);
   int endregno
     = regno + (regno < 68
         ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
         : 1);

   for (i = regno; i < endregno; i++)
     reg_last_death[i] = insn;
 }
      else if (((n64_enum_reg_note) ((link)->mode)) == REG_INC)
 record_value_for_reg (((link)->fld[0].rtx), insn, (rtx) 0);
    }

  if (((insn)->code) == CALL_INSN)
    {
      for (i = 0; i < 68; i++)
 if (call_used_regs[i])
   {
     reg_last_set_value[i] = 0;
     reg_last_set_mode[i] = 0;
     reg_last_set_nonzero_bits[i] = 0;
     reg_last_set_sign_bit_copies[i] = 0;
     reg_last_death[i] = 0;
   }

      last_call_cuid = mem_last_set = (((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)]);
    }

  record_dead_insn = insn;
  note_stores (((insn)->fld[3].rtx), record_dead_and_set_regs_1);
}
static int
get_last_value_validate(rtx *loc, int tick, int replace) asm("_get_last_value_validate");
static int
get_last_value_validate(rtx *loc, int tick, int replace)
{
  rtx x = *loc;
  char *fmt = (rtx_format[(int)(((x)->code))]);
  int len = (rtx_length[(int)(((x)->code))]);
  int i;

  if (((x)->code) == REG)
    {
      int regno = ((x)->fld[0].rtint);
      int endregno = regno + (regno < 68
         ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);
      int j;

      for (j = regno; j < endregno; j++)
 if (reg_last_set_invalid[j]


     || (! (regno >= 68 && reg_n_sets[regno] == 1)
  && reg_last_set_label[j] > tick))
   {
     if (replace)
       *loc = gen_rtx (CLOBBER, ((x)->mode), const0_rtx);
     return replace;
   }

      return 1;
    }

  for (i = 0; i < len; i++)
    if ((fmt[i] == 'e'
  && get_last_value_validate (&((x)->fld[i].rtx), tick, replace) == 0)

 || fmt[i] == 'E')
      return 0;


  return 1;
}





static rtx
get_last_value(rtx x) asm("_get_last_value");
static rtx
get_last_value(rtx x)
{
  int regno;
  rtx value;




  if (((x)->code) == SUBREG
      && subreg_lowpart_p (x)
      && ((mode_size[(int)(((x)->mode))])
   <= (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
      && (value = get_last_value (((x)->fld[0].rtx))) != 0)
    return gen_lowpart_for_combine (((x)->mode), value);

  if (((x)->code) != REG)
    return 0;

  regno = ((x)->fld[0].rtint);
  value = reg_last_set_value[regno];



  if (value == 0
      || (reg_n_sets[regno] != 1
   && reg_last_set_label[regno] != label_tick))
    return 0;
  if ((((reg_last_set[regno])->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((reg_last_set[regno])->fld[0].rtint)]) >= subst_low_cuid)
    {
      rtx insn, set;



      if (subst_prev_insn)
 return 0;







      for (insn = prev_nonnote_insn (subst_insn);
    insn && ((((insn)->code) == INSN
       && ((((insn)->fld[3].rtx))->code) == USE)
      || ((insn)->code) == BARRIER
      || (((insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((insn)->fld[0].rtint)]) >= subst_low_cuid);
    insn = prev_nonnote_insn (insn))
 ;

      if (insn
   && (set = single_set (insn)) != 0
   && rtx_equal_p (((set)->fld[0].rtx), x))
 {
   value = ((set)->fld[1].rtx);





   if (reg_mentioned_p (x, value))
     value = replace_rtx (copy_rtx (value), x,
     gen_rtx (CLOBBER, ((x)->mode), const0_rtx));

   if (reg_overlap_mentioned_p (x, value))
     return 0;
 }
      else
 return 0;
    }


  if (get_last_value_validate (&value, reg_last_set_label[regno], 0))
    return value;




  value = copy_rtx (value);
  if (get_last_value_validate (&value, reg_last_set_label[regno], 1))
    return value;

  return 0;
}




static int
use_crosses_set_p(register rtx x, int from_cuid) asm("_use_crosses_set_p");
static int
use_crosses_set_p(register rtx x, int from_cuid)
{
  register char *fmt;
  register int i;
  register n64_enum_rtx_code code = ((x)->code);

  if (code == REG)
    {
      register int regno = ((x)->fld[0].rtint);
      int endreg = regno + (regno < 68
       ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);







      for (;regno < endreg; regno++)
 if (reg_last_set[regno]
     && (((reg_last_set[regno])->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((reg_last_set[regno])->fld[0].rtint)]) > from_cuid)
   return 1;
      return 0;
    }

  if (code == MEM && mem_last_set > from_cuid)
    return 1;

  fmt = (rtx_format[(int)(code)]);

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (use_crosses_set_p (((x)->fld[i].rtvec->elem[j].rtx), from_cuid))
       return 1;
 }
      else if (fmt[i] == 'e'
        && use_crosses_set_p (((x)->fld[i].rtx), from_cuid))
 return 1;
    }
  return 0;
}




static int reg_dead_regno, reg_dead_endregno;
static int reg_dead_flag;






static void
reg_dead_at_p_1(rtx dest, rtx x) asm("_reg_dead_at_p_1");
static void
reg_dead_at_p_1(rtx dest, rtx x)
{
  int regno, endregno;

  if (((dest)->code) != REG)
    return;

  regno = ((dest)->fld[0].rtint);
  endregno = regno + (regno < 68
        ? (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) : 1);

  if (reg_dead_endregno > regno && reg_dead_regno < endregno)
    reg_dead_flag = (((x)->code) == CLOBBER) ? 1 : -1;
}
static int
reg_dead_at_p(rtx reg, rtx insn) asm("_reg_dead_at_p");
static int
reg_dead_at_p(rtx reg, rtx insn)
{
  int block, i;


  reg_dead_regno = ((reg)->fld[0].rtint);
  reg_dead_endregno = reg_dead_regno + (reg_dead_regno < 68
     ? (! ((unsigned) ((reg_dead_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))

     : 1);

  reg_dead_flag = 0;


  if (reg_dead_regno < 68)
    {
      for (i = reg_dead_regno; i < reg_dead_endregno; i++)
 if (((newpat_used_regs)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)))))
   return 0;
    }



  for (; insn && ((insn)->code) != CODE_LABEL && ((insn)->code) != BARRIER;
       insn = prev_nonnote_insn (insn))
    {
      note_stores (((insn)->fld[3].rtx), reg_dead_at_p_1);
      if (reg_dead_flag)
 return reg_dead_flag == 1 ? 1 : 0;

      if (find_regno_note (insn, REG_DEAD, reg_dead_regno))
 return 1;
    }


  if (insn == 0)
    block = 0;
  else
    {
      for (block = 0; block < n_basic_blocks; block++)
 if (insn == basic_block_head[block])
   break;

      if (block == n_basic_blocks)
 return 0;
    }

  for (i = reg_dead_regno; i < reg_dead_endregno; i++)
    if (basic_block_live_at_start[block][i / 32]
 & ((unsigned int) 1 << (i % 32)))
      return 0;

  return 1;
}




static void
mark_used_regs_combine(rtx x) asm("_mark_used_regs_combine");
static void
mark_used_regs_combine(rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);
  register int regno;
  int i;

  switch (code)
    {
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case PC:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case ASM_INPUT:





      return;

    case CLOBBER:


      if (((((x)->fld[0].rtx))->code) == MEM)
 mark_used_regs_combine (((((x)->fld[0].rtx))->fld[0].rtx));
      return;

    case REG:
      regno = ((x)->fld[0].rtint);


      if (regno < 68)
 {

   if (regno == (0 + 29)




       || (regno == 0 && fixed_regs[regno])

       || regno == (0 + 30))
     return;

   i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   while (i-- > 0)
     ((newpat_used_regs)[(regno + i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno + i) % ((unsigned) 32)));
 }
      return;

    case SET:
      {


 register rtx testreg = ((x)->fld[0].rtx);

 while (((testreg)->code) == SUBREG
        || ((testreg)->code) == ZERO_EXTRACT
        || ((testreg)->code) == SIGN_EXTRACT
        || ((testreg)->code) == STRICT_LOW_PART)
   testreg = ((testreg)->fld[0].rtx);

 if (((testreg)->code) == MEM)
   mark_used_regs_combine (((testreg)->fld[0].rtx));

 mark_used_regs_combine (((x)->fld[1].rtx));
 return;
      }
    }



  {
    register char *fmt = (rtx_format[(int)(code)]);

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
        if (fmt[i] == 'e')
   mark_used_regs_combine (((x)->fld[i].rtx));
        else if (fmt[i] == 'E')
          {
            register int j;

            for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
              mark_used_regs_combine (((x)->fld[i].rtvec->elem[j].rtx));
          }
      }
  }
}






rtx
remove_death(int regno, rtx insn) asm("_remove_death");
rtx
remove_death(int regno, rtx insn)
{
  register rtx note = find_regno_note (insn, REG_DEAD, regno);

  if (note)
    {
      reg_n_deaths[regno]--;
      remove_note (insn, note);
    }

  return note;
}
static void
move_deaths(rtx x, int from_cuid, rtx to_insn, rtx *pnotes) asm("_move_deaths");
static void
move_deaths(rtx x, int from_cuid, rtx to_insn, rtx *pnotes)
{
  register char *fmt;
  register int len, i;
  register n64_enum_rtx_code code = ((x)->code);

  if (code == REG)
    {
      register int regno = ((x)->fld[0].rtint);
      register rtx where_dead = reg_last_death[regno];
      register rtx before_dead, after_dead;



      before_dead = where_dead;
      while (before_dead && ((before_dead)->fld[0].rtint) > max_uid_cuid)
 before_dead = ((before_dead)->fld[1].rtx);
      after_dead = where_dead;
      while (after_dead && ((after_dead)->fld[0].rtint) > max_uid_cuid)
 after_dead = ((after_dead)->fld[2].rtx);

      if (before_dead && after_dead
   && (((before_dead)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((before_dead)->fld[0].rtint)]) >= from_cuid
   && ((((after_dead)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((after_dead)->fld[0].rtint)]) < (((to_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((to_insn)->fld[0].rtint)])
       || (where_dead != after_dead
    && (((after_dead)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((after_dead)->fld[0].rtint)]) == (((to_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((to_insn)->fld[0].rtint)]))))
 {
   rtx note = remove_death (regno, where_dead);
   if (note != 0 && regno < 68
       && ((mode_size[(int)(((((note)->fld[0].rtx))->mode))])
    != (mode_size[(int)(((x)->mode))])))
     {
       int deadregno = ((((note)->fld[0].rtx))->fld[0].rtint);
       int deadend
  = (deadregno + (! ((unsigned) ((deadregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                 );
       int ourend = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       int i;

       for (i = deadregno; i < deadend; i++)
  if (i < regno || i >= ourend)
    ((where_dead)->fld[6].rtx)
      = gen_rtx (EXPR_LIST, REG_DEAD,
          gen_rtx (REG, reg_raw_mode[i], i),
          ((where_dead)->fld[6].rtx));
     }




   else if (note == 0 && regno < 68
     && (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > 1)
     {
       int ourend = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       int i;
       rtx oldnotes = 0;

       for (i = regno + 1; i < ourend; i++)
  move_deaths (gen_rtx (REG, reg_raw_mode[i], i),
        from_cuid, to_insn, &oldnotes);
     }

   if (note != 0 && ((((note)->fld[0].rtx))->mode) == ((x)->mode))
     {
       ((note)->fld[1].rtx) = *pnotes;
       *pnotes = note;
     }
   else
     *pnotes = gen_rtx (EXPR_LIST, REG_DEAD, x, *pnotes);

   reg_n_deaths[regno]++;
 }

      return;
    }

  else if (((x)->code) == SET)
    {
      rtx dest = ((x)->fld[0].rtx);

      move_deaths (((x)->fld[1].rtx), from_cuid, to_insn, pnotes);






      if (((dest)->code) == ZERO_EXTRACT
   || ((dest)->code) == STRICT_LOW_PART
   || (((dest)->code) == SUBREG
       && ((((mode_size[(int)(((dest)->mode))])
      + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))
    == (((mode_size[(int)(((((dest)->fld[0].rtx))->mode))])
         + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)))))
 {
   move_deaths (dest, from_cuid, to_insn, pnotes);
   return;
 }



      if (((dest)->code) == SUBREG)
 dest = ((dest)->fld[0].rtx);





      if (((dest)->code) == MEM)
 move_deaths (((dest)->fld[0].rtx), from_cuid, to_insn, pnotes);
      return;
    }

  else if (((x)->code) == CLOBBER)
    return;

  len = (rtx_length[(int)(code)]);
  fmt = (rtx_format[(int)(code)]);

  for (i = 0; i < len; i++)
    {
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     move_deaths (((x)->fld[i].rtvec->elem[j].rtx), from_cuid, to_insn, pnotes);
 }
      else if (fmt[i] == 'e')
 move_deaths (((x)->fld[i].rtx), from_cuid, to_insn, pnotes);
    }
}




static int
reg_bitfield_target_p(rtx x, rtx body) asm("_reg_bitfield_target_p");
static int
reg_bitfield_target_p(rtx x, rtx body)
{
  int i;

  if (((body)->code) == SET)
    {
      rtx dest = ((body)->fld[0].rtx);
      rtx target;
      int regno, tregno, endregno, endtregno;

      if (((dest)->code) == ZERO_EXTRACT)
 target = ((dest)->fld[0].rtx);
      else if (((dest)->code) == STRICT_LOW_PART)
 target = ((((dest)->fld[0].rtx))->fld[0].rtx);
      else
 return 0;

      if (((target)->code) == SUBREG)
 target = ((target)->fld[0].rtx);

      if (((target)->code) != REG)
 return 0;

      tregno = ((target)->fld[0].rtint), regno = ((x)->fld[0].rtint);
      if (tregno >= 68 || regno >= 68)
 return target == x;

      endtregno = tregno + (! ((unsigned) ((tregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((target)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((target)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

      return endregno > tregno && regno < endtregno;
    }

  else if (((body)->code) == PARALLEL)
    for (i = ((body)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
      if (reg_bitfield_target_p (x, ((body)->fld[0].rtvec->elem[i].rtx)))
 return 1;

  return 0;
}
static void
distribute_notes(rtx notes, rtx from_insn, rtx i3, rtx i2, rtx elim_i2, rtx elim_i1) asm("_distribute_notes");
static void
distribute_notes(rtx notes, rtx from_insn, rtx i3, rtx i2, rtx elim_i2, rtx elim_i1)
{
  rtx note, next_note;
  rtx tem;

  for (note = notes; note; note = next_note)
    {
      rtx place = 0, place2 = 0;



      if (((note)->fld[0].rtx) && ((((note)->fld[0].rtx))->code) == REG
   && ((((note)->fld[0].rtx))->fld[0].rtint) >= 68)
 ((note)->fld[0].rtx) = regno_reg_rtx[((((note)->fld[0].rtx))->fld[0].rtint)];

      next_note = ((note)->fld[1].rtx);
      switch (((n64_enum_reg_note) ((note)->mode)))
 {
 case REG_UNUSED:
   if (reg_set_p (((note)->fld[0].rtx), ((i3)->fld[3].rtx)))
     {
       if (from_insn != i3)
  break;

       if (! (((((note)->fld[0].rtx))->code) == REG
       ? find_regno_note (i3, REG_UNUSED, ((((note)->fld[0].rtx))->fld[0].rtint))
       : find_reg_note (i3, REG_UNUSED, ((note)->fld[0].rtx))))
  place = i3;
     }



   else if (reg_referenced_p (((note)->fld[0].rtx), ((i3)->fld[3].rtx))
     && ! (((((note)->fld[0].rtx))->code) == REG
    ? find_regno_note (i3, REG_DEAD, ((((note)->fld[0].rtx))->fld[0].rtint))
    : find_reg_note (i3, REG_DEAD, ((note)->fld[0].rtx))))
     {
       ((note)->mode = ((n64_enum_machine_mode) (REG_DEAD)));
       place = i3;
     }
   break;

 case REG_EQUAL:
 case REG_EQUIV:
 case REG_NONNEG:
   if (from_insn == i3
       && (((note)->fld[0].rtx) == 0 || (((((note)->fld[0].rtx))->code) == LABEL_REF || ((((note)->fld[0].rtx))->code) == SYMBOL_REF || ((((note)->fld[0].rtx))->code) == CONST_INT || ((((note)->fld[0].rtx))->code) == CONST_DOUBLE || ((((note)->fld[0].rtx))->code) == CONST || ((((note)->fld[0].rtx))->code) == HIGH)))
     place = i3;
   break;

 case REG_INC:
 case REG_NO_CONFLICT:
 case REG_LABEL:


   if (reg_mentioned_p (((note)->fld[0].rtx), ((i3)->fld[3].rtx)))
     place = i3;

   if (i2 && reg_mentioned_p (((note)->fld[0].rtx), ((i2)->fld[3].rtx)))
     {
       if (place)
  place2 = i2;
       else
  place = i2;
     }
   break;

 case REG_WAS_0:


   break;

 case REG_RETVAL:



   if (((from_insn)->code) != NOTE)
     place = from_insn;
   else
     {
       tem = find_reg_note (((note)->fld[0].rtx), REG_LIBCALL, (rtx) 0);
       place = prev_real_insn (from_insn);
       if (tem && place)
  ((tem)->fld[0].rtx) = place;
     }
   break;

 case REG_LIBCALL:

   if (((from_insn)->code) != NOTE)
     place = from_insn;
   else
     {
       tem = find_reg_note (((note)->fld[0].rtx), REG_RETVAL, (rtx) 0);
       place = next_real_insn (from_insn);
       if (tem && place)
  ((tem)->fld[0].rtx) = place;
     }
   break;

 case REG_DEAD:
   if (from_insn
       && ((from_insn)->code) == CALL_INSN
              && find_reg_fusage (from_insn, USE, ((note)->fld[0].rtx)))
     place = from_insn;
   else if (reg_referenced_p (((note)->fld[0].rtx), ((i3)->fld[3].rtx)))
     place = i3;
   else if (i2 != 0 && next_nonnote_insn (i2) == i3
     && reg_referenced_p (((note)->fld[0].rtx), ((i2)->fld[3].rtx)))
     place = i2;

   if (((note)->fld[0].rtx) == elim_i2 || ((note)->fld[0].rtx) == elim_i1)
     break;
   if (place == i3 && i2 != 0 && ((((note)->fld[0].rtx))->code) == REG
       && reg_n_refs[((((note)->fld[0].rtx))->fld[0].rtint)]== 2
       && reg_referenced_p (((note)->fld[0].rtx), ((i2)->fld[3].rtx)))
     reg_n_refs[((((note)->fld[0].rtx))->fld[0].rtint)] = 3;

   if (place == 0)
     {
       for (tem = prev_nonnote_insn (i3);
     place == 0 && tem
     && (((tem)->code) == INSN || ((tem)->code) == CALL_INSN);
     tem = prev_nonnote_insn (tem))
  {



    if (reg_set_p (((note)->fld[0].rtx), ((tem)->fld[3].rtx)))
      {
        rtx set = single_set (tem);




        if (set != 0 && ! side_effects_p (((set)->fld[1].rtx))
     && (rtx_equal_p (((note)->fld[0].rtx), ((set)->fld[0].rtx))
         || (((((set)->fld[0].rtx))->code) == SUBREG
      && rtx_equal_p (((note)->fld[0].rtx),
        ((((set)->fld[0].rtx))->fld[0].rtx)))))
   {





     ((tem)->fld[3].rtx) = pc_rtx;

     distribute_notes (((tem)->fld[6].rtx), tem, tem,
         (rtx) 0, (rtx) 0, (rtx) 0);
     distribute_links (((tem)->fld[5].rtx));

     ((tem)->code = (NOTE));
     ((tem)->fld[4].rtint) = -1;
     ((tem)->fld[3].rtstr) = 0;
   }
        else
   {
     ((note)->mode = ((n64_enum_machine_mode) (REG_UNUSED)));



     if (! find_regno_note (tem, REG_UNUSED,
       ((((note)->fld[0].rtx))->fld[0].rtint)))
       place = tem;
     break;
        }
    }
  else if (reg_referenced_p (((note)->fld[0].rtx), ((tem)->fld[3].rtx))
    || (((tem)->code) == CALL_INSN
        && find_reg_fusage (tem, USE, ((note)->fld[0].rtx))))
    {
      place = tem;







      if (i2 && ((place)->fld[0].rtint) <= max_uid_cuid
   && (((place)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((place)->fld[0].rtint)]) > (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)])
   && from_insn && (((from_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((from_insn)->fld[0].rtint)]) > (((i2)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((i2)->fld[0].rtint)])
   && reg_referenced_p (((note)->fld[0].rtx), ((i2)->fld[3].rtx)))
        {
   rtx links = ((place)->fld[5].rtx);
   ((place)->fld[5].rtx) = 0;
   distribute_links (links);
        }
      break;
    }
  }






       if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD && place == 0 && tem != 0)
  {
    place
      = emit_insn_after (gen_rtx (USE, VOIDmode, ((note)->fld[0].rtx)),
           tem);



    if (basic_block_end[this_basic_block - 1] == tem)
      basic_block_head[this_basic_block] = place;
  }
     }
   if (place && ((n64_enum_reg_note) ((note)->mode)) == REG_DEAD)
     {
       int regno = ((((note)->fld[0].rtx))->fld[0].rtint);

       if (dead_or_set_p (place, ((note)->fld[0].rtx))
    || reg_bitfield_target_p (((note)->fld[0].rtx), ((place)->fld[3].rtx)))
  {



    if (reg_last_death[regno] != place)
      reg_last_death[regno] = 0;
    place = 0;
  }
       else
  reg_last_death[regno] = place;
       if (place && regno < 68
    && (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > 1)
  {
    int endregno
      = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((note)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                ;
    int all_used = 1;
    int i;

    for (i = regno; i < endregno; i++)
      if (! refers_to_regno_p (i, i + 1, ((place)->fld[3].rtx), 0)
   && ! find_regno_fusage (place, USE, i))
        {
   rtx piece = gen_rtx (REG, reg_raw_mode[i], i);
   rtx p;



   for (p = place;
        ((((p)->fld[1].rtx))->code) == INSN
        && ((((((p)->fld[1].rtx))->fld[3].rtx))->code) == USE;
        p = ((p)->fld[1].rtx))
     if (rtx_equal_p (piece,
        ((((((p)->fld[1].rtx))->fld[3].rtx))->fld[0].rtx)))
       {
         p = 0;
         break;
       }

   if (p)
     {
       rtx use_insn
         = emit_insn_before (gen_rtx (USE, VOIDmode,
          piece),
        p);
       ((use_insn)->fld[6].rtx)
         = gen_rtx (EXPR_LIST, REG_DEAD, piece,
      ((use_insn)->fld[6].rtx));
     }

   all_used = 0;
        }



    if (all_used)
      for (i = regno; i < endregno; i++)
        if (dead_or_set_regno_p (place, i))
     {
       all_used = 0;
       break;
     }

    if (! all_used)
      {



        for (i = regno; i < endregno; i++)
   {
     rtx piece = gen_rtx (REG, reg_raw_mode[i], i);

     if ((reg_referenced_p (piece, ((place)->fld[3].rtx))
          || (((place)->code) == CALL_INSN
       && find_reg_fusage (place, USE, piece)))
         && ! dead_or_set_p (place, piece)
         && ! reg_bitfield_target_p (piece,
         ((place)->fld[3].rtx)))
       ((place)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_DEAD,
        piece,
        ((place)->fld[6].rtx));
   }

        place = 0;
      }
  }
     }
   break;

 default:


   abort ();
 }

      if (place)
 {
   ((note)->fld[1].rtx) = ((place)->fld[6].rtx);
   ((place)->fld[6].rtx) = note;
 }
      else if ((((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
  || ((n64_enum_reg_note) ((note)->mode)) == REG_UNUSED)
        && ((((note)->fld[0].rtx))->code) == REG)
 reg_n_deaths[((((note)->fld[0].rtx))->fld[0].rtint)]--;

      if (place2)
 {
   if ((((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
        || ((n64_enum_reg_note) ((note)->mode)) == REG_UNUSED)
       && ((((note)->fld[0].rtx))->code) == REG)
     reg_n_deaths[((((note)->fld[0].rtx))->fld[0].rtint)]++;

   ((place2)->fld[6].rtx) = gen_rtx (((note)->code), ((n64_enum_reg_note) ((note)->mode)),
     ((note)->fld[0].rtx), ((place2)->fld[6].rtx));
 }
    }
}





static void
distribute_links(rtx links) asm("_distribute_links");
static void
distribute_links(rtx links)
{
  rtx link, next_link;

  for (link = links; link; link = next_link)
    {
      rtx place = 0;
      rtx insn;
      rtx set, reg;

      next_link = ((link)->fld[1].rtx);
      if (((((link)->fld[0].rtx))->code) == NOTE
   || (set = single_set (((link)->fld[0].rtx))) == 0)
 continue;

      reg = ((set)->fld[0].rtx);
      while (((reg)->code) == SUBREG || ((reg)->code) == ZERO_EXTRACT
      || ((reg)->code) == SIGN_EXTRACT
      || ((reg)->code) == STRICT_LOW_PART)
 reg = ((reg)->fld[0].rtx);
      for (insn = ((((link)->fld[0].rtx))->fld[2].rtx);
    (insn && (this_basic_block == n_basic_blocks - 1
       || basic_block_head[this_basic_block + 1] != insn));
    insn = ((insn)->fld[2].rtx))
 if ((rtx_class[(int)(((insn)->code))]) == 'i'
     && reg_overlap_mentioned_p (reg, ((insn)->fld[3].rtx)))
   {
     if (reg_referenced_p (reg, ((insn)->fld[3].rtx)))
       place = insn;
     break;
   }
 else if (((insn)->code) == CALL_INSN
       && find_reg_fusage (insn, USE, reg))
   {
     place = insn;
     break;
   }




      if (place)
 {
   rtx link2;

   for (link2 = ((place)->fld[5].rtx); link2; link2 = ((link2)->fld[1].rtx))
     if (((link2)->fld[0].rtx) == ((link)->fld[0].rtx))
       break;

   if (link2 == 0)
     {
       ((link)->fld[1].rtx) = ((place)->fld[5].rtx);
       ((place)->fld[5].rtx) = link;



       if (added_links_insn == 0
    || (((added_links_insn)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((added_links_insn)->fld[0].rtint)]) > (((place)->fld[0].rtint) > max_uid_cuid ? (abort(), 0) : uid_cuid[((place)->fld[0].rtint)]))
  added_links_insn = place;
     }
 }
    }
}

void
dump_combine_stats(FILE *file) asm("_dump_combine_stats");
void
dump_combine_stats(FILE *file)
{
  fprintf
    (file,
     ";; Combiner statistics: %d attempts, %d substitutions (%d requiring new space),\n;; %d successes.\n\n",
     combine_attempts, combine_merges, combine_extras, combine_successes);
}

void
dump_combine_total_stats(FILE *file) asm("_dump_combine_total_stats");
void
dump_combine_total_stats(FILE *file)
{
  fprintf
    (file,
     "\n;; Combiner totals: %d attempts, %d substitutions (%d requiring new space),\n;; %d successes.\n",
     total_attempts, total_merges, total_extras, total_successes);
}

