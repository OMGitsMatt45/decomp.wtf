// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/binutils/arlex.c
/*   Copyright (C) 1992 Free Software Foundation, Inc.

This file is part of GNU Binutils.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_yy_buffer_state;

typedef struct n64_tag_yy_buffer_state *YY_BUFFER_STATE;

extern int yyleng;
extern FILE *yyin, *yyout;
typedef unsigned int yy_size_t;


struct n64_tag_yy_buffer_state
 {
 FILE *yy_input_file;

 char *yy_ch_buf;
 char *yy_buf_pos;




 yy_size_t yy_buf_size;




 int yy_n_chars;





 int yy_is_our_buffer;






 int yy_is_interactive;





 int yy_at_bol;




 int yy_fill_buffer;

 int yy_buffer_status;
 };

static YY_BUFFER_STATE yy_current_buffer = 0;
static char yy_hold_char;

static int yy_n_chars;


int yyleng;


static char *yy_c_buf_p = (char *) 0;
static int yy_init = 1;
static int yy_start = 0;




static int yy_did_buffer_switch_on_eof;

void yyrestart ( FILE *input_file ) asm("_yyrestart");

void yy_switch_to_buffer ( YY_BUFFER_STATE new_buffer ) asm("_yy_switch_to_buffer");
void yy_load_buffer_state ( void ) asm("_yy_load_buffer_state");
YY_BUFFER_STATE yy_create_buffer ( FILE *file, int size ) asm("_yy_create_buffer");
void yy_delete_buffer ( YY_BUFFER_STATE b ) asm("_yy_delete_buffer");
void yy_init_buffer ( YY_BUFFER_STATE b, FILE *file ) asm("_yy_init_buffer");
void yy_flush_buffer ( YY_BUFFER_STATE b ) asm("_yy_flush_buffer");


YY_BUFFER_STATE yy_scan_buffer ( char *base, yy_size_t size ) asm("_yy_scan_buffer");
YY_BUFFER_STATE yy_scan_string ( const char *str ) asm("_yy_scan_string");
YY_BUFFER_STATE yy_scan_bytes ( const char *bytes, int len ) asm("_yy_scan_bytes");

static void *yy_flex_alloc ( yy_size_t ) asm("_yy_flex_alloc");
static void *yy_flex_realloc ( void *, yy_size_t ) asm("_yy_flex_realloc");
static void yy_flex_free ( void * ) asm("_yy_flex_free");
typedef unsigned char YY_CHAR;
FILE *yyin = (FILE *) 0, *yyout = (FILE *) 0;
typedef int yy_state_type;
extern char *yytext;


static yy_state_type yy_get_previous_state ( void ) asm("_yy_get_previous_state");
static yy_state_type yy_try_NUL_trans ( yy_state_type current_state ) asm("_yy_try_NUL_trans");
static int yy_get_next_buffer ( void ) asm("_yy_get_next_buffer");
static void yy_fatal_error ( const char msg[] ) asm("_yy_fatal_error");
static const short int yy_accept[177] =
    { 0,
        0, 0, 41, 40, 39, 38, 35, 32, 33, 36,
       40, 34, 37, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 36, 31, 37, 35,
       35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 7, 35, 35, 35, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 22, 35, 35, 35,
       35, 35, 35, 35, 35, 35, 35, 35, 35, 35,

       35, 35, 35, 10, 11, 12, 35, 15, 35, 35,
       35, 35, 35, 35, 35, 35, 35, 25, 26, 27,
       35, 30, 35, 35, 35, 3, 35, 35, 35, 35,
       35, 35, 35, 35, 35, 18, 35, 35, 35, 35,
       35, 35, 35, 1, 2, 4, 5, 35, 35, 35,
       35, 35, 16, 17, 19, 20, 35, 35, 35, 35,
       35, 35, 8, 9, 13, 14, 35, 23, 24, 28,
       29, 35, 35, 6, 21, 0
    } ;

static const int yy_ec[256] =
    { 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 3, 1, 1, 1, 4, 1, 1, 1, 5,
        6, 7, 8, 9, 4, 4, 4, 4, 4, 4,
        4, 4, 4, 4, 4, 4, 4, 4, 10, 1,
        1, 1, 1, 1, 11, 12, 13, 14, 15, 16,
        4, 17, 18, 4, 4, 19, 20, 21, 22, 23,
        4, 24, 25, 26, 27, 28, 4, 29, 30, 4,
        1, 1, 1, 1, 4, 1, 31, 32, 33, 34,

       35, 36, 4, 37, 38, 4, 4, 39, 40, 41,
       42, 43, 4, 44, 45, 46, 47, 48, 4, 49,
       50, 4, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1
    } ;

static const int yy_meta[51] =
    { 0,
        1, 2, 1, 3, 1, 1, 1, 1, 1, 1,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3
    } ;

static const short int yy_base[180] =
    { 0,
        0, 0, 193, 194, 194, 194, 0, 194, 194, 0,
      190, 194, 0, 177, 32, 37, 32, 163, 174, 170,
      164, 171, 174, 169, 149, 15, 22, 17, 135, 146,
      142, 136, 143, 146, 141, 0, 0, 194, 0, 161,
      159, 158, 153, 147, 156, 143, 149, 148, 141, 150,
      141, 135, 138, 127, 125, 124, 119, 113, 122, 109,
      115, 114, 107, 116, 107, 101, 104, 43, 136, 135,
      130, 129, 0, 119, 123, 118, 114, 118, 119, 122,
      124, 25, 104, 103, 98, 97, 0, 87, 91, 86,
       82, 86, 87, 90, 92, 105, 100, 97, 94, 93,

      105, 106, 102, 0, 0, 0, 104, 0, 92, 75,
       70, 67, 64, 63, 75, 76, 72, 0, 0, 0,
       74, 0, 62, 91, 88, 0, 86, 85, 73, 85,
       79, 83, 70, 62, 59, 0, 57, 56, 44, 56,
       50, 54, 41, 0, 0, 0, 0, 63, 58, 59,
       67, 66, 0, 0, 0, 0, 38, 33, 34, 42,
       41, 51, 0, 0, 0, 0, 30, 0, 0, 0,
        0, 43, 21, 0, 0, 194, 65, 66, 69
    } ;

static const short int yy_def[180] =
    { 0,
      176, 1, 176, 176, 176, 176, 177, 176, 176, 178,
      176, 176, 179, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 178, 176, 179, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,

      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 177, 177, 177, 177, 177,
      177, 177, 177, 177, 177, 0, 176, 176, 176
    } ;

static const short int yy_nxt[245] =
    { 0,
        4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
       14, 7, 15, 16, 17, 18, 19, 7, 20, 7,
        7, 21, 7, 22, 23, 7, 7, 24, 7, 7,
       25, 7, 26, 27, 28, 29, 30, 7, 31, 7,
        7, 32, 7, 33, 34, 7, 7, 35, 7, 7,
       41, 43, 45, 55, 44, 42, 57, 59, 56, 58,
       46, 96, 97, 110, 111, 60, 37, 36, 37, 39,
      175, 39, 174, 173, 172, 171, 170, 169, 168, 167,
      166, 165, 164, 163, 162, 161, 160, 159, 158, 157,
      156, 155, 154, 153, 152, 151, 150, 149, 148, 147,

      146, 145, 144, 143, 142, 141, 140, 139, 138, 137,
      136, 135, 134, 133, 132, 131, 130, 129, 128, 127,
      126, 125, 124, 123, 122, 121, 120, 119, 118, 117,
      116, 115, 114, 113, 112, 109, 108, 107, 106, 105,
      104, 103, 102, 101, 100, 99, 98, 95, 94, 93,
       92, 91, 90, 89, 88, 87, 86, 85, 84, 83,
       82, 81, 80, 79, 78, 77, 76, 75, 74, 73,
       72, 71, 70, 69, 68, 67, 66, 65, 64, 63,
       62, 61, 54, 53, 52, 51, 50, 49, 48, 47,
       40, 38, 176, 3, 176, 176, 176, 176, 176, 176,

      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176
    } ;

static const short int yy_chk[245] =
    { 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       15, 16, 17, 26, 16, 15, 27, 28, 26, 27,
       17, 68, 68, 82, 82, 28, 178, 177, 178, 179,
      173, 179, 172, 167, 162, 161, 160, 159, 158, 157,
      152, 151, 150, 149, 148, 143, 142, 141, 140, 139,
      138, 137, 135, 134, 133, 132, 131, 130, 129, 128,

      127, 125, 124, 123, 121, 117, 116, 115, 114, 113,
      112, 111, 110, 109, 107, 103, 102, 101, 100, 99,
       98, 97, 96, 95, 94, 93, 92, 91, 90, 89,
       88, 86, 85, 84, 83, 81, 80, 79, 78, 77,
       76, 75, 74, 72, 71, 70, 69, 67, 66, 65,
       64, 63, 62, 61, 60, 59, 58, 57, 56, 55,
       54, 53, 52, 51, 50, 49, 48, 47, 46, 45,
       44, 43, 42, 41, 40, 35, 34, 33, 32, 31,
       30, 29, 25, 24, 23, 22, 21, 20, 19, 18,
       14, 11, 3, 176, 176, 176, 176, 176, 176, 176,

      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176, 176, 176, 176, 176, 176, 176,
      176, 176, 176, 176
    } ;

static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;







char *yytext;
typedef union {
  char *name;
struct list *list ;

} YYSTYPE;
extern YYSTYPE yylval;
extern char *strdup(...) asm("_strdup");
int linenumber;
extern int yywrap ( void ) asm("_yywrap");




static void yyunput ( int c, char *buf_ptr ) asm("_yyunput");
static int input ( void ) asm("_input");

int yylex ( void ) asm("_yylex");
int yylex ( void )
 {
 register yy_state_type yy_current_state;
 register char *yy_cp, *yy_bp;
 register int yy_act;

 if ( yy_init )
  {
  yy_init = 0;





  if ( ! yy_start )
   yy_start = 1;

  if ( ! yyin )
   yyin = 
         (__acrt_iob_func(0))
              ;

  if ( ! yyout )
   yyout = 
          (__acrt_iob_func(1))
                ;

  if ( ! yy_current_buffer )
   yy_current_buffer =
    yy_create_buffer( yyin, 16384 );

  yy_load_buffer_state();
  }

 while ( 1 )
  {
  yy_cp = yy_c_buf_p;


  *yy_cp = yy_hold_char;




  yy_bp = yy_cp;

  yy_current_state = yy_start;
yy_match:
  do
   {
   register YY_CHAR yy_c = yy_ec[((unsigned int) (unsigned char) *yy_cp)];
   if ( yy_accept[yy_current_state] )
    {
    yy_last_accepting_state = yy_current_state;
    yy_last_accepting_cpos = yy_cp;
    }
   while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
    {
    yy_current_state = (int) yy_def[yy_current_state];
    if ( yy_current_state >= 177 )
     yy_c = yy_meta[(unsigned int) yy_c];
    }
   yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
   ++yy_cp;
   }
  while ( yy_base[yy_current_state] != 194 );

yy_find_action:
  yy_act = yy_accept[yy_current_state];
  if ( yy_act == 0 )
   {
   yy_cp = yy_last_accepting_cpos;
   yy_current_state = yy_last_accepting_state;
   yy_act = yy_accept[yy_current_state];
   }

  yytext = yy_bp; yyleng = (int) (yy_cp - yy_bp); yy_hold_char = *yy_cp; *yy_cp = '\0'; yy_c_buf_p = yy_cp;;


do_action:


  switch ( yy_act )
 {
   case 0:

   *yy_cp = yy_hold_char;
   yy_cp = yy_last_accepting_cpos;
   yy_current_state = yy_last_accepting_state;
   goto yy_find_action;

case 1:

{ return 261; }
 break;
case 2:

{ return 263; }
 break;
case 3:

{ return 264; }
 break;
case 4:

{ return 265; }
 break;
case 5:

{ return 266; }
 break;
case 6:

{ return 267; }
 break;
case 7:

{ return 268; }
 break;
case 8:

{ return 269; }
 break;
case 9:

{ return 270; }
 break;
case 10:

{ return 271; }
 break;
case 11:

{ return 262; }
 break;
case 12:

{ return 275; }
 break;
case 13:

{ return 273; }
 break;
case 14:

{ return 259; }
 break;
case 15:

{ return 274; }
 break;
case 16:

{ return 261; }
 break;
case 17:

{ return 263; }
 break;
case 18:

{ return 264; }
 break;
case 19:

{ return 265; }
 break;
case 20:

{ return 266; }
 break;
case 21:

{ return 267; }
 break;
case 22:

{ return 268; }
 break;
case 23:

{ return 269; }
 break;
case 24:

{ return 270; }
 break;
case 25:

{ return 271; }
 break;
case 26:

{ return 262; }
 break;
case 27:

{ return 275; }
 break;
case 28:

{ return 273; }
 break;
case 29:

{ return 259; }
 break;
case 30:

{ return 274; }
 break;
case 31:

{ linenumber ++; }
 break;
case 32:

{ return '('; }
 break;
case 33:

{ return ')'; }
 break;
case 34:

{ return ','; }
 break;
case 35:

{
  yylval.name = strdup(yytext);
  return 260;
  }
 break;
case 36:

{ }
 break;
case 37:

{ }
 break;
case 38:

{ }
 break;
case 39:

{ linenumber ++; return 258; }
 break;
case 40:

(void) fwrite( yytext, yyleng, 1, yyout );
 break;
case (41 + 0 + 1):
 return 0;

 case 41:
  {

  int yy_amount_of_matched_text = (int) (yy_cp - yytext) - 1;


  *yy_cp = yy_hold_char;

  if ( yy_current_buffer->yy_buffer_status == 0 )
   {
   yy_n_chars = yy_current_buffer->yy_n_chars;
   yy_current_buffer->yy_input_file = yyin;
   yy_current_buffer->yy_buffer_status = 1;
   }
  if ( yy_c_buf_p <= &yy_current_buffer->yy_ch_buf[yy_n_chars] )
   {
   yy_state_type yy_next_state;

   yy_c_buf_p = yytext + yy_amount_of_matched_text;

   yy_current_state = yy_get_previous_state();
   yy_next_state = yy_try_NUL_trans( yy_current_state );

   yy_bp = yytext + 0;

   if ( yy_next_state )
    {

    yy_cp = ++yy_c_buf_p;
    yy_current_state = yy_next_state;
    goto yy_match;
    }

   else
    {
    yy_cp = yy_c_buf_p;
    goto yy_find_action;
    }
   }

  else switch ( yy_get_next_buffer() )
   {
   case 1:
    {
    yy_did_buffer_switch_on_eof = 0;

    if ( yywrap() )
     {
     yy_c_buf_p = yytext + 0;

     yy_act = (41 + ((yy_start - 1) / 2) + 1);
     goto do_action;
     }

    else
     {
     if ( ! yy_did_buffer_switch_on_eof )
      yyrestart( yyin );
     }
    break;
    }

   case 0:
    yy_c_buf_p =
     yytext + yy_amount_of_matched_text;

    yy_current_state = yy_get_previous_state();

    yy_cp = yy_c_buf_p;
    yy_bp = yytext + 0;
    goto yy_match;

   case 2:
    yy_c_buf_p =
    &yy_current_buffer->yy_ch_buf[yy_n_chars];

    yy_current_state = yy_get_previous_state();

    yy_cp = yy_c_buf_p;
    yy_bp = yytext + 0;
    goto yy_find_action;
   }
  break;
  }

 default:
  yy_fatal_error( "fatal flex scanner internal error--no action found" )
                                                         ;
 }
  }
 }
static int yy_get_next_buffer(void) asm("_yy_get_next_buffer");
static int yy_get_next_buffer(void)
{
 register char *dest = yy_current_buffer->yy_ch_buf;
 register char *source = yytext;
 register int number_to_move, i;
 int ret_val;

 if ( yy_c_buf_p > &yy_current_buffer->yy_ch_buf[yy_n_chars + 1] )
  yy_fatal_error( "fatal flex scanner internal error--end of buffer missed" )
                                                             ;

 if ( yy_current_buffer->yy_fill_buffer == 0 )
  {
  if ( yy_c_buf_p - yytext - 0 == 1 )
   {



   return 1;
   }

  else
   {



   return 2;
   }
  }




 number_to_move = (int) (yy_c_buf_p - yytext) - 1;

 for ( i = 0; i < number_to_move; ++i )
  *(dest++) = *(source++);

 if ( yy_current_buffer->yy_buffer_status == 2 )



  yy_n_chars = 0;

 else
  {
  int num_to_read =
   yy_current_buffer->yy_buf_size - number_to_move - 1;

  while ( num_to_read <= 0 )
   {






   YY_BUFFER_STATE b = yy_current_buffer;

   int yy_c_buf_p_offset =
    (int) (yy_c_buf_p - b->yy_ch_buf);

   if ( b->yy_is_our_buffer )
    {
    int new_size = b->yy_buf_size * 2;

    if ( new_size <= 0 )
     b->yy_buf_size += b->yy_buf_size / 8;
    else
     b->yy_buf_size *= 2;

    b->yy_ch_buf = (char *)

     yy_flex_realloc( (void *) b->yy_ch_buf,
        b->yy_buf_size + 2 );
    }
   else

    b->yy_ch_buf = 0;

   if ( ! b->yy_ch_buf )
    yy_fatal_error( "fatal error - scanner input buffer overflow" )
                                                   ;

   yy_c_buf_p = &b->yy_ch_buf[yy_c_buf_p_offset];

   num_to_read = yy_current_buffer->yy_buf_size -
      number_to_move - 1;

   }

  if ( num_to_read > 8192 )
   num_to_read = 8192;


  if ( yy_current_buffer->yy_is_interactive ) { int c = '*', n; for ( n = 0; n < num_to_read && (c = getc( yyin )) != 
 (-1) 
 && c != '\n'; ++n ) (&yy_current_buffer->yy_ch_buf[number_to_move])[n] = (char) c; if ( c == '\n' ) (&yy_current_buffer->yy_ch_buf[number_to_move])[n++] = (char) c; if ( c == 
 (-1) 
 && ferror( yyin ) ) yy_fatal_error( "input in flex scanner failed" ); yy_n_chars = n; } else if ( ((yy_n_chars = fread( (&yy_current_buffer->yy_ch_buf[number_to_move]), 1, num_to_read, yyin )) == 0) && ferror( yyin ) ) yy_fatal_error( "input in flex scanner failed" );
                            ;
  }

 if ( yy_n_chars == 0 )
  {
  if ( number_to_move == 0 )
   {
   ret_val = 1;
   yyrestart( yyin );
   }

  else
   {
   ret_val = 2;
   yy_current_buffer->yy_buffer_status =
    2;
   }
  }

 else
  ret_val = 0;

 yy_n_chars += number_to_move;
 yy_current_buffer->yy_ch_buf[yy_n_chars] = 0;
 yy_current_buffer->yy_ch_buf[yy_n_chars + 1] = 0;

 yytext = &yy_current_buffer->yy_ch_buf[0];

 return ret_val;
 }




static yy_state_type yy_get_previous_state(void) asm("_yy_get_previous_state");
static yy_state_type yy_get_previous_state(void)
{
 register yy_state_type yy_current_state;
 register char *yy_cp;

 yy_current_state = yy_start;

 for ( yy_cp = yytext + 0; yy_cp < yy_c_buf_p; ++yy_cp )
  {
  register YY_CHAR yy_c = (*yy_cp ? yy_ec[((unsigned int) (unsigned char) *yy_cp)] : 1);
  if ( yy_accept[yy_current_state] )
   {
   yy_last_accepting_state = yy_current_state;
   yy_last_accepting_cpos = yy_cp;
   }
  while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
   {
   yy_current_state = (int) yy_def[yy_current_state];
   if ( yy_current_state >= 177 )
    yy_c = yy_meta[(unsigned int) yy_c];
   }
  yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
  }

 return yy_current_state;
 }
static yy_state_type yy_try_NUL_trans( yy_state_type yy_current_state ) asm("_yy_try_NUL_trans");
static yy_state_type yy_try_NUL_trans( yy_state_type yy_current_state )




 {
 register int yy_is_jam;
 register char *yy_cp = yy_c_buf_p;

 register YY_CHAR yy_c = 1;
 if ( yy_accept[yy_current_state] )
  {
  yy_last_accepting_state = yy_current_state;
  yy_last_accepting_cpos = yy_cp;
  }
 while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
  {
  yy_current_state = (int) yy_def[yy_current_state];
  if ( yy_current_state >= 177 )
   yy_c = yy_meta[(unsigned int) yy_c];
  }
 yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
 yy_is_jam = (yy_current_state == 176);

 return yy_is_jam ? 0 : yy_current_state;
 }




static void yyunput( int c, register char *yy_bp ) asm("_yyunput");
static void yyunput( int c, register char *yy_bp )





 {
 register char *yy_cp = yy_c_buf_p;


 *yy_cp = yy_hold_char;

 if ( yy_cp < yy_current_buffer->yy_ch_buf + 2 )
  {

  register int number_to_move = yy_n_chars + 2;
  register char *dest = &yy_current_buffer->yy_ch_buf[
     yy_current_buffer->yy_buf_size + 2];
  register char *source =
    &yy_current_buffer->yy_ch_buf[number_to_move];

  while ( source > yy_current_buffer->yy_ch_buf )
   *--dest = *--source;

  yy_cp += (int) (dest - source);
  yy_bp += (int) (dest - source);
  yy_n_chars = yy_current_buffer->yy_buf_size;

  if ( yy_cp < yy_current_buffer->yy_ch_buf + 2 )
   yy_fatal_error( "flex scanner push-back overflow" );
  }

 *--yy_cp = (char) c;


 yytext = yy_bp;
 yy_hold_char = *yy_cp;
 yy_c_buf_p = yy_cp;
 }






static int input(void) asm("_input");
static int input(void)
{
 int c;

 *yy_c_buf_p = yy_hold_char;

 if ( *yy_c_buf_p == 0 )
  {




  if ( yy_c_buf_p < &yy_current_buffer->yy_ch_buf[yy_n_chars] )

   *yy_c_buf_p = '\0';

  else
   {
   yytext = yy_c_buf_p;
   ++yy_c_buf_p;

   switch ( yy_get_next_buffer() )
    {
    case 1:
     {
     if ( yywrap() )
      {
      yy_c_buf_p =
      yytext + 0;
      return 
            (-1)
               ;
      }

     if ( ! yy_did_buffer_switch_on_eof )
      yyrestart( yyin );



     return input();

     }

    case 0:
     yy_c_buf_p = yytext + 0;
     break;

    case 2:




     yy_fatal_error( "unexpected last match in input()" )
                                         ;

    }
   }
  }

 c = *(unsigned char *) yy_c_buf_p;
 *yy_c_buf_p = '\0';
 yy_hold_char = *++yy_c_buf_p;


 return c;
 }



void yyrestart( FILE *input_file ) asm("_yyrestart");
void yyrestart( FILE *input_file )




 {
 if ( ! yy_current_buffer )
  yy_current_buffer = yy_create_buffer( yyin, 16384 );

 yy_init_buffer( yy_current_buffer, input_file );
 yy_load_buffer_state();
 }



void yy_switch_to_buffer( YY_BUFFER_STATE new_buffer ) asm("_yy_switch_to_buffer");
void yy_switch_to_buffer( YY_BUFFER_STATE new_buffer )




 {
 if ( yy_current_buffer == new_buffer )
  return;

 if ( yy_current_buffer )
  {

  *yy_c_buf_p = yy_hold_char;
  yy_current_buffer->yy_buf_pos = yy_c_buf_p;
  yy_current_buffer->yy_n_chars = yy_n_chars;
  }

 yy_current_buffer = new_buffer;
 yy_load_buffer_state();






 yy_did_buffer_switch_on_eof = 1;
 }



void yy_load_buffer_state( void ) asm("_yy_load_buffer_state");
void yy_load_buffer_state( void )



 {
 yy_n_chars = yy_current_buffer->yy_n_chars;
 yytext = yy_c_buf_p = yy_current_buffer->yy_buf_pos;
 yyin = yy_current_buffer->yy_input_file;
 yy_hold_char = *yy_c_buf_p;
 }



YY_BUFFER_STATE yy_create_buffer( FILE *file, int size ) asm("_yy_create_buffer");
YY_BUFFER_STATE yy_create_buffer( FILE *file, int size )





 {
 YY_BUFFER_STATE b;

 b = (YY_BUFFER_STATE) yy_flex_alloc( sizeof( struct n64_tag_yy_buffer_state ) );
 if ( ! b )
  yy_fatal_error( "out of dynamic memory in yy_create_buffer()" );

 b->yy_buf_size = size;




 b->yy_ch_buf = (char *) yy_flex_alloc( b->yy_buf_size + 2 );
 if ( ! b->yy_ch_buf )
  yy_fatal_error( "out of dynamic memory in yy_create_buffer()" );

 b->yy_is_our_buffer = 1;

 yy_init_buffer( b, file );

 return b;
 }



void yy_delete_buffer( YY_BUFFER_STATE b ) asm("_yy_delete_buffer");
void yy_delete_buffer( YY_BUFFER_STATE b )




 {
 if ( ! b )
  return;

 if ( b == yy_current_buffer )
  yy_current_buffer = (YY_BUFFER_STATE) 0;

 if ( b->yy_is_our_buffer )
  yy_flex_free( (void *) b->yy_ch_buf );

 yy_flex_free( (void *) b );
 }




extern int isatty ( int ) asm("_isatty");




void yy_init_buffer( YY_BUFFER_STATE b, FILE *file ) asm("_yy_init_buffer");
void yy_init_buffer( YY_BUFFER_STATE b, FILE *file )







 {
 yy_flush_buffer( b );

 b->yy_input_file = file;
 b->yy_fill_buffer = 1;







 b->yy_is_interactive = file ? (isatty( fileno(file) ) > 0) : 0;


 }



void yy_flush_buffer( YY_BUFFER_STATE b ) asm("_yy_flush_buffer");
void yy_flush_buffer( YY_BUFFER_STATE b )





 {
 b->yy_n_chars = 0;





 b->yy_ch_buf[0] = 0;
 b->yy_ch_buf[1] = 0;

 b->yy_buf_pos = &b->yy_ch_buf[0];

 b->yy_at_bol = 1;
 b->yy_buffer_status = 0;

 if ( b == yy_current_buffer )
  yy_load_buffer_state();
 }




YY_BUFFER_STATE yy_scan_buffer( char *base, yy_size_t size ) asm("_yy_scan_buffer");
YY_BUFFER_STATE yy_scan_buffer( char *base, yy_size_t size )





 {
 YY_BUFFER_STATE b;

 if ( size < 2 ||
      base[size-2] != 0 ||
      base[size-1] != 0 )

  return 0;

 b = (YY_BUFFER_STATE) yy_flex_alloc( sizeof( struct n64_tag_yy_buffer_state ) );
 if ( ! b )
  yy_fatal_error( "out of dynamic memory in yy_scan_buffer()" );

 b->yy_buf_size = size - 2;
 b->yy_buf_pos = b->yy_ch_buf = base;
 b->yy_is_our_buffer = 0;
 b->yy_input_file = 0;
 b->yy_n_chars = b->yy_buf_size;
 b->yy_is_interactive = 0;
 b->yy_at_bol = 1;
 b->yy_fill_buffer = 0;
 b->yy_buffer_status = 0;

 yy_switch_to_buffer( b );

 return b;
 }





YY_BUFFER_STATE yy_scan_string( const char *str ) asm("_yy_scan_string");
YY_BUFFER_STATE yy_scan_string( const char *str )




 {
 int len;
 for ( len = 0; str[len]; ++len )
  ;

 return yy_scan_bytes( str, len );
 }





YY_BUFFER_STATE yy_scan_bytes( const char *bytes, int len ) asm("_yy_scan_bytes");
YY_BUFFER_STATE yy_scan_bytes( const char *bytes, int len )





 {
 YY_BUFFER_STATE b;
 char *buf;
 yy_size_t n;
 int i;


 n = len + 2;
 buf = (char *) yy_flex_alloc( n );
 if ( ! buf )
  yy_fatal_error( "out of dynamic memory in yy_scan_bytes()" );

 for ( i = 0; i < len; ++i )
  buf[i] = bytes[i];

 buf[len] = buf[len+1] = 0;

 b = yy_scan_buffer( buf, n );
 if ( ! b )
  yy_fatal_error( "bad buffer in yy_scan_bytes()" );




 b->yy_is_our_buffer = 1;

 return b;
 }
static void yy_fatal_error( const char msg[] ) asm("_yy_fatal_error");
static void yy_fatal_error( const char msg[] )




 {
 (void) fprintf( 
                (__acrt_iob_func(2))
                      , "%s\n", msg );
 exit( 2 );
 }
static void *yy_flex_alloc( yy_size_t size ) asm("_yy_flex_alloc");
static void *yy_flex_alloc( yy_size_t size )




 {
 return (void *) malloc( size );
 }


static void *yy_flex_realloc( void *ptr, yy_size_t size ) asm("_yy_flex_realloc");
static void *yy_flex_realloc( void *ptr, yy_size_t size )





 {







 return (void *) realloc( (char *) ptr, size );
 }


static void yy_flex_free( void *ptr ) asm("_yy_flex_free");
static void yy_flex_free( void *ptr )




 {
 free( ptr );
 }



int yywrap(void) asm("_yywrap");
int yywrap(void)
{ return 1; }

