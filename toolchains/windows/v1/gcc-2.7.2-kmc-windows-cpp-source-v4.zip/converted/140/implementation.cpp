// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/xatexit.c
/*
 * Copyright (c) 1990 Regents of the University of California.
 * All rights reserved.
 *
 * %sccs.include.redist.c%
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_xatexit;




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");









void * malloc (size_t) asm("_malloc");

static void xatexit_cleanup (void) asm("_xatexit_cleanup");


extern void (*_xexit_cleanup)(...);



struct n64_tag_xatexit {
 struct n64_tag_xatexit *next;
 int ind;
 void (*fns[32]) (void);
};



static struct n64_tag_xatexit xatexit_first;


static struct n64_tag_xatexit *xatexit_head = &xatexit_first;




int
xatexit(void (*fn) (void)) asm("_xatexit");
int
xatexit(void (*fn) (void))
{
  register struct n64_tag_xatexit *p;


  if (!_xexit_cleanup)
    _xexit_cleanup = xatexit_cleanup;

  p = xatexit_head;
  if (p->ind >= 32)
    {
      if ((p = (struct n64_tag_xatexit *) malloc (sizeof *p)) == 
                                                        ((void *)0)
                                                            )
 return -1;
      p->ind = 0;
      p->next = xatexit_head;
      xatexit_head = p;
    }
  p->fns[p->ind++] = fn;
  return 0;
}



static void
xatexit_cleanup(void) asm("_xatexit_cleanup");
static void
xatexit_cleanup(void)
{
  register struct n64_tag_xatexit *p;
  register int n;

  for (p = xatexit_head; p; p = p->next)
    for (n = p->ind; --n >= 0;)
      (*p->fns[n]) ();
}

