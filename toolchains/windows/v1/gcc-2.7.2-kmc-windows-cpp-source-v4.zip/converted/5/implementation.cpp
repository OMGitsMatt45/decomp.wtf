// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/c-lex.c
/* Lexical analyzer for C and Objective C.
   Copyright (C) 1987, 88, 89, 92, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <errno.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int set_identifier_size(...) asm("_set_identifier_size");
extern int warning(...) asm("_warning");
extern int error(...) asm("_error");
extern int handle_sysv_pragma(...) asm("_handle_sysv_pragma");
extern int dwarfout_define(...) asm("_dwarfout_define");
extern int dwarfout_undef(...) asm("_dwarfout_undef");
extern int dwarfout_start_new_source_file(...) asm("_dwarfout_start_new_source_file");
extern int dwarfout_resume_previous_source_file(...) asm("_dwarfout_resume_previous_source_file");
extern int pedwarn(...) asm("_pedwarn");
extern int set_float_handler(...) asm("_set_float_handler");
extern int target_isinf(...) asm("_target_isinf");
extern int target_isnan(...) asm("_target_isnan");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
struct n64_tag_file_stack;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_resword;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;


extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *input_filename;


extern char *main_input_filename;


extern int lineno;


extern FILE *finput;

struct n64_tag_file_stack
  {
    char *name;
    struct n64_tag_file_stack *next;
    int line;
  };



extern struct n64_tag_file_stack *input_file_stack;


extern int input_file_stack_tick;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_CHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,
  RID_UNUSED1,

  RID_UNSIGNED,
  RID_SHORT,
  RID_LONG,
  RID_AUTO,
  RID_STATIC,
  RID_EXTERN,
  RID_REGISTER,
  RID_TYPEDEF,
  RID_SIGNED,
  RID_CONST,
  RID_VOLATILE,
  RID_INLINE,
  RID_NOALIAS,
  RID_ITERATOR,
  RID_COMPLEX,

  RID_IN,
  RID_OUT,
  RID_INOUT,
  RID_BYCOPY,
  RID_ONEWAY,
  RID_ID,

  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;

extern tree make_pointer_declarator(...) asm("_make_pointer_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern int yylex(void) asm("_yylex");

extern char *get_directive_line(...) asm("_get_directive_line");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus, limbo_value;
};
extern int pedantic;
struct n64_tag_lang_type
{
  int len;
  tree elts[1];
};
extern tree lookup_interface (tree) asm("_lookup_interface");
extern tree is_class_name (tree) asm("_is_class_name");
extern void maybe_objc_check_decl (tree) asm("_maybe_objc_check_decl");
extern int maybe_objc_comptypes (tree, tree, int) asm("_maybe_objc_comptypes");
extern tree maybe_building_objc_message_expr (void) asm("_maybe_building_objc_message_expr");
extern tree maybe_objc_method_name (tree) asm("_maybe_objc_method_name");
extern int recognize_objc_keyword (void) asm("_recognize_objc_keyword");
extern tree build_objc_string (int, char *) asm("_build_objc_string");


extern void gen_aux_info_record (tree, int, int, int) asm("_gen_aux_info_record");


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree convert (tree, tree) asm("_convert");



extern tree char_array_type_node;
extern tree char_type_node;
extern tree const_ptr_type_node;
extern tree const_string_type_node;
extern tree default_function_type;
extern tree double_ftype_double;
extern tree double_ftype_double_double;
extern tree double_type_node;
extern tree float_type_node;
extern tree intDI_type_node;
extern tree intHI_type_node;
extern tree intQI_type_node;
extern tree intSI_type_node;
extern tree int_array_type_node;
extern tree int_ftype_cptr_cptr_sizet;
extern tree int_ftype_int;
extern tree int_ftype_ptr_ptr_int;
extern tree int_ftype_string_string;
extern tree integer_type_node;
extern tree long_double_type_node;
extern tree long_ftype_long;
extern tree long_integer_type_node;
extern tree long_long_integer_type_node;
extern tree long_long_unsigned_type_node;
extern tree long_unsigned_type_node;
extern tree complex_integer_type_node;
extern tree complex_float_type_node;
extern tree complex_double_type_node;
extern tree complex_long_double_type_node;
extern tree ptr_type_node;
extern tree ptrdiff_type_node;
extern tree short_integer_type_node;
extern tree short_unsigned_type_node;
extern tree signed_char_type_node;
extern tree signed_wchar_type_node;
extern tree string_ftype_ptr_ptr;
extern tree string_type_node;
extern tree unsigned_char_type_node;
extern tree unsigned_intDI_type_node;
extern tree unsigned_intHI_type_node;
extern tree unsigned_intQI_type_node;
extern tree unsigned_intSI_type_node;
extern tree unsigned_type_node;
extern tree unsigned_wchar_type_node;
extern tree void_ftype_ptr_int_int;
extern tree void_ftype_ptr_ptr_int;
extern tree void_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node;
extern tree boolean_type_node;
extern tree boolean_true_node;
extern tree boolean_false_node;

extern tree build_enumerator (tree, tree) asm("_build_enumerator");

extern tree builtin_function (char *, tree, n64_enum_built_in_function function_, char *) asm("_builtin_function");

extern tree c_build_type_variant (tree, int, int) asm("_c_build_type_variant");
extern int c_decode_option (char *) asm("_c_decode_option");
extern void c_mark_varargs (void) asm("_c_mark_varargs");
extern tree check_identifier (tree, tree) asm("_check_identifier");
extern void clear_parm_order (void) asm("_clear_parm_order");
extern tree combine_parm_decls (tree, tree, int) asm("_combine_parm_decls");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern void declare_parm_level (int) asm("_declare_parm_level");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void delete_block (tree) asm("_delete_block");
extern void finish_decl (tree, tree, tree) asm("_finish_decl");
extern void finish_decl_top_level (tree, tree, tree) asm("_finish_decl_top_level");
extern tree finish_enum (tree, tree, tree) asm("_finish_enum");
extern void finish_function (int) asm("_finish_function");
extern tree finish_struct (tree, tree, tree) asm("_finish_struct");
extern tree get_parm_info (int) asm("_get_parm_info");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern int global_bindings_p (void) asm("_global_bindings_p");
extern tree grokfield (char *, int, tree, tree, tree) asm("_grokfield");
extern tree groktypename (tree) asm("_groktypename");
extern tree groktypename_in_parm_context (tree) asm("_groktypename_in_parm_context");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern int in_parm_level_p (void) asm("_in_parm_level_p");
extern void init_decl_processing (void) asm("_init_decl_processing");
extern void insert_block (tree) asm("_insert_block");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree lookup_name (tree) asm("_lookup_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern tree lookup_name_current_level_global (tree) asm("_lookup_name_current_level_global");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void parmlist_tags_warning (void) asm("_parmlist_tags_warning");
extern void pending_xref_error (void) asm("_pending_xref_error");
extern void pop_c_function_context (void) asm("_pop_c_function_context");
extern void pop_label_level (void) asm("_pop_label_level");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void print_lang_decl (FILE *, tree, int) asm("_print_lang_decl")
                 ;
extern void print_lang_identifier (FILE *, tree, int) asm("_print_lang_identifier")
                 ;
extern void print_lang_type (FILE *, tree, int) asm("_print_lang_type")
                 ;
extern void push_c_function_context (void) asm("_push_c_function_context");
extern void push_label_level (void) asm("_push_label_level");
extern void push_parm_decl (tree) asm("_push_parm_decl");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void pushlevel (int) asm("_pushlevel");
extern void pushtag (tree, tree) asm("_pushtag");
extern void set_block (tree) asm("_set_block");
extern tree shadow_label (tree) asm("_shadow_label");
extern void shadow_record_fields (tree) asm("_shadow_record_fields");
extern void shadow_tag (tree) asm("_shadow_tag");
extern void shadow_tag_warned (tree, int) asm("_shadow_tag_warned");
extern tree start_enum (tree) asm("_start_enum");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function")
                        ;
extern tree start_decl (tree, tree, int, tree, tree) asm("_start_decl")
                         ;
extern tree start_struct (n64_enum_tree_code, tree) asm("_start_struct");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern tree xref_tag (n64_enum_tree_code, tree) asm("_xref_tag");


extern tree require_complete_type (tree) asm("_require_complete_type");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");


extern tree common_type (tree, tree) asm("_common_type");
extern int comptypes (tree, tree) asm("_comptypes");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_size_in_bytes (tree) asm("_c_size_in_bytes");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree c_alignof_expr (tree) asm("_c_alignof_expr");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_component_ref (tree, tree) asm("_build_component_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree parser_build_binary_op (n64_enum_tree_code, tree, tree) asm("_parser_build_binary_op")
                         ;
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op")
                              ;
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op")
                        ;
extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern void readonly_warning (tree, char *) asm("_readonly_warning");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_c_cast (tree, tree) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr")
                   ;
extern tree initializer_constant_valid_p (tree, tree) asm("_initializer_constant_valid_p");
extern void store_init_value (tree, tree) asm("_store_init_value");
extern void error_init (char *, char *, char *) asm("_error_init")
                     ;
extern void pedwarn_init (char *, char *, char *) asm("_pedwarn_init")
                     ;
extern void start_init (tree, tree, int) asm("_start_init");
extern void finish_init (void) asm("_finish_init");
extern void really_start_incremental_init (tree) asm("_really_start_incremental_init");
extern void push_init_level (int) asm("_push_init_level");
extern tree pop_init_level (int) asm("_pop_init_level");
extern void set_init_index (tree, tree) asm("_set_init_index");
extern void set_init_label (tree) asm("_set_init_label");
extern void process_init_element (tree) asm("_process_init_element");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands")
                               ;
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");


extern void iterator_expand (tree) asm("_iterator_expand");
extern void iterator_for_loop_start (tree) asm("_iterator_for_loop_start");
extern void iterator_for_loop_end (tree) asm("_iterator_for_loop_end");
extern void iterator_for_loop_record (tree) asm("_iterator_for_loop_record");
extern void push_iterator_stack (void) asm("_push_iterator_stack");
extern void pop_iterator_stack (void) asm("_pop_iterator_stack");




extern int current_function_returns_value;




extern int current_function_returns_null;



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_no_ident;



extern int warn_implicit;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;




extern int warn_redundant_decls;







extern int warn_nested_externs;




extern int warn_cast_qual;





extern int warn_bad_function_cast;



extern int warn_traditional;



extern int warn_format;



extern int warn_char_subscripts;



extern int warn_conversion;



extern int flag_traditional;



extern int flag_allow_single_precision;



extern int warn_parentheses;



extern int warn_missing_braces;




extern int (*comptypes_record_hook)(...);



extern int system_header_p;



extern int doing_objc_thang;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
typedef union {long itype; tree ttype; n64_enum_tree_code code;
 char *filename; int lineno; int ends_in_label; } YYSTYPE;
extern YYSTYPE yylval;
enum n64_cpp_enum_pragma_state{
  ps_start,
  ps_done,
  ps_bad,
  ps_weak,
  ps_name,
  ps_equals,
  ps_value,
  ps_pack,
  ps_left,
  ps_align,
  ps_right
};
typedef __underlying_type(enum n64_cpp_enum_pragma_state) n64_enum_pragma_state;



extern void handle_pragma_weak (n64_enum_pragma_state, char *, char *) asm("_handle_pragma_weak");


extern void handle_pragma_token (char *, tree) asm("_handle_pragma_token");


tree ridpointers[(int) RID_MAX];
tree lastiddecl;



int doing_objc_thang;

extern tree is_class_name(...) asm("_is_class_name");

extern int yydebug;


extern FILE *asm_out_file;
static int maxtoken;
char *token_buffer;




static int end_of_file;


static int nextchar = -1;

int check_newline(void) asm("_check_newline");






struct n64_tag_resword { char *name; short token; n64_enum_rid rid; };


static unsigned int
hash(register char *str, register unsigned int len) asm("_hash");
static unsigned int
hash(register char *str, register unsigned int len)
{
  static unsigned char asso_values[] =
    {
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 25, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 145, 145, 145, 145, 145,
     145, 145, 145, 145, 145, 1, 145, 46, 8, 15,
      61, 6, 36, 48, 3, 5, 145, 18, 63, 25,
      29, 76, 1, 145, 13, 2, 1, 51, 37, 9,
       9, 1, 3, 145, 145, 145, 145, 145,
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 3:
        hval += asso_values[str[2]];
      case 2:
      case 1:
        hval += asso_values[str[0]];
    }
  return hval + asso_values[str[len - 1]];
}

static struct n64_tag_resword wordlist[] =
{
  {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
  {"",},
  {"int", 261, RID_INT},
  {"",}, {"",},
  {"__typeof__", 283, RID_UNUSED},
  {"__signed__", 261, RID_SIGNED},
  {"__imag__", 289, RID_UNUSED},
  {"switch", 275, RID_UNUSED},
  {"__inline__", 260, RID_INLINE},
  {"else", 271, RID_UNUSED},
  {"__iterator__", 260, RID_ITERATOR},
  {"__inline", 260, RID_INLINE},
  {"__extension__", 286, RID_UNUSED},
  {"struct", 268, RID_UNUSED},
  {"__real__", 288, RID_UNUSED},
  {"__const", 262, RID_CONST},
  {"while", 272, RID_UNUSED},
  {"__const__", 262, RID_CONST},
  {"case", 276, RID_UNUSED},
  {"__complex__", 261, RID_COMPLEX},
  {"__iterator", 260, RID_ITERATOR},
  {"bycopy", 262, RID_BYCOPY},
  {"",}, {"",}, {"",},
  {"__complex", 261, RID_COMPLEX},
  {"",},
  {"in", 262, RID_IN},
  {"break", 278, RID_UNUSED},
  {"@defs", 306, RID_UNUSED},
  {"",}, {"",}, {"",},
  {"extern", 260, RID_EXTERN},
  {"if", 270, RID_UNUSED},
  {"typeof", 283, RID_UNUSED},
  {"typedef", 260, RID_TYPEDEF},
  {"__typeof", 283, RID_UNUSED},
  {"sizeof", 266, RID_UNUSED},
  {"",},
  {"return", 280, RID_UNUSED},
  {"const", 262, RID_CONST},
  {"__volatile__", 262, RID_VOLATILE},
  {"@private", 310, RID_UNUSED},
  {"@selector", 305, RID_UNUSED},
  {"__volatile", 262, RID_VOLATILE},
  {"__asm__", 282, RID_UNUSED},
  {"",}, {"",},
  {"continue", 279, RID_UNUSED},
  {"__alignof__", 284, RID_UNUSED},
  {"__imag", 289, RID_UNUSED},
  {"__attribute__", 285, RID_UNUSED},
  {"",}, {"",},
  {"__attribute", 285, RID_UNUSED},
  {"for", 274, RID_UNUSED},
  {"",},
  {"@encode", 307, RID_UNUSED},
  {"id", 313, RID_ID},
  {"static", 260, RID_STATIC},
  {"@interface", 302, RID_UNUSED},
  {"",},
  {"__signed", 261, RID_SIGNED},
  {"",},
  {"__label__", 287, RID_UNUSED},
  {"",}, {"",},
  {"__asm", 282, RID_UNUSED},
  {"char", 261, RID_CHAR},
  {"",},
  {"inline", 260, RID_INLINE},
  {"out", 262, RID_OUT},
  {"register", 260, RID_REGISTER},
  {"__real", 288, RID_UNUSED},
  {"short", 261, RID_SHORT},
  {"",},
  {"enum", 267, RID_UNUSED},
  {"inout", 262, RID_INOUT},
  {"",},
  {"oneway", 262, RID_ONEWAY},
  {"union", 269, RID_UNUSED},
  {"",},
  {"__alignof", 284, RID_UNUSED},
  {"",},
  {"@implementation", 303, RID_UNUSED},
  {"",},
  {"@class", 314, RID_UNUSED},
  {"",},
  {"@public", 309, RID_UNUSED},
  {"asm", 282, RID_UNUSED},
  {"",}, {"",}, {"",}, {"",}, {"",},
  {"default", 277, RID_UNUSED},
  {"",},
  {"void", 261, RID_VOID},
  {"",},
  {"@protected", 311, RID_UNUSED},
  {"@protocol", 312, RID_UNUSED},
  {"",}, {"",}, {"",},
  {"volatile", 262, RID_VOLATILE},
  {"",}, {"",},
  {"signed", 261, RID_SIGNED},
  {"float", 261, RID_FLOAT},
  {"@end", 304, RID_UNUSED},
  {"",}, {"",},
  {"unsigned", 261, RID_UNSIGNED},
  {"@compatibility_alias", 315, RID_UNUSED},
  {"double", 261, RID_DOUBLE},
  {"",}, {"",},
  {"auto", 260, RID_AUTO},
  {"",},
  {"goto", 281, RID_UNUSED},
  {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
  {"do", 273, RID_UNUSED},
  {"",}, {"",}, {"",}, {"",},
  {"long", 261, RID_LONG},
};




struct n64_tag_resword *
is_reserved_word(register char *str, register unsigned int len) asm("_is_reserved_word");
struct n64_tag_resword *
is_reserved_word(register char *str, register unsigned int len)
{
  if (len <= 20 && len >= 2)
    {
      register int key = hash (str, len);

      if (key <= 144 && key >= 0)
        {
          register char *s = wordlist[key].name;

          if (*s == *str && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
tree
make_pointer_declarator(tree type_quals, tree target) asm("_make_pointer_declarator");
tree
make_pointer_declarator(tree type_quals, tree target)
{
  return build1 (INDIRECT_REF, type_quals, target);
}

void
forget_protocol_qualifiers(void) asm("_forget_protocol_qualifiers");
void
forget_protocol_qualifiers(void)
{
  int i, n = sizeof wordlist / sizeof (struct n64_tag_resword);

  for (i = 0; i < n; i++)
    if ((int) wordlist[i].rid >= (int) RID_IN
        && (int) wordlist[i].rid <= (int) RID_ONEWAY)
      wordlist[i].name = "";
}

void
remember_protocol_qualifiers(void) asm("_remember_protocol_qualifiers");
void
remember_protocol_qualifiers(void)
{
  int i, n = sizeof wordlist / sizeof (struct n64_tag_resword);

  for (i = 0; i < n; i++)
    if (wordlist[i].rid == RID_IN)
      wordlist[i].name = "in";
    else if (wordlist[i].rid == RID_OUT)
      wordlist[i].name = "out";
    else if (wordlist[i].rid == RID_INOUT)
      wordlist[i].name = "inout";
    else if (wordlist[i].rid == RID_BYCOPY)
      wordlist[i].name = "bycopy";
    else if (wordlist[i].rid == RID_ONEWAY)
      wordlist[i].name = "oneway";
}

void
init_lex(void) asm("_init_lex");
void
init_lex(void)
{

  set_identifier_size (sizeof (struct n64_tag_lang_identifier));



  lineno = 0;






  maxtoken = 40;
  token_buffer = (char *) xmalloc (maxtoken + 2);

  ridpointers[(int) RID_INT] = get_identifier ("int");
  ridpointers[(int) RID_CHAR] = get_identifier ("char");
  ridpointers[(int) RID_VOID] = get_identifier ("void");
  ridpointers[(int) RID_FLOAT] = get_identifier ("float");
  ridpointers[(int) RID_DOUBLE] = get_identifier ("double");
  ridpointers[(int) RID_SHORT] = get_identifier ("short");
  ridpointers[(int) RID_LONG] = get_identifier ("long");
  ridpointers[(int) RID_UNSIGNED] = get_identifier ("unsigned");
  ridpointers[(int) RID_SIGNED] = get_identifier ("signed");
  ridpointers[(int) RID_INLINE] = get_identifier ("inline");
  ridpointers[(int) RID_CONST] = get_identifier ("const");
  ridpointers[(int) RID_VOLATILE] = get_identifier ("volatile");
  ridpointers[(int) RID_AUTO] = get_identifier ("auto");
  ridpointers[(int) RID_STATIC] = get_identifier ("static");
  ridpointers[(int) RID_EXTERN] = get_identifier ("extern");
  ridpointers[(int) RID_TYPEDEF] = get_identifier ("typedef");
  ridpointers[(int) RID_REGISTER] = get_identifier ("register");
  ridpointers[(int) RID_ITERATOR] = get_identifier ("iterator");
  ridpointers[(int) RID_COMPLEX] = get_identifier ("complex");
  ridpointers[(int) RID_ID] = get_identifier ("id");
  ridpointers[(int) RID_IN] = get_identifier ("in");
  ridpointers[(int) RID_OUT] = get_identifier ("out");
  ridpointers[(int) RID_INOUT] = get_identifier ("inout");
  ridpointers[(int) RID_BYCOPY] = get_identifier ("bycopy");
  ridpointers[(int) RID_ONEWAY] = get_identifier ("oneway");
  forget_protocol_qualifiers();







  if (! doing_objc_thang)
    do { struct n64_tag_resword *s = is_reserved_word ("id", sizeof ("id") - 1); if (s) s->name = ""; } while (0);

  if (flag_traditional)
    {
      do { struct n64_tag_resword *s = is_reserved_word ("const", sizeof ("const") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("volatile", sizeof ("volatile") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("typeof", sizeof ("typeof") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("signed", sizeof ("signed") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("inline", sizeof ("inline") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("iterator", sizeof ("iterator") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("complex", sizeof ("complex") - 1); if (s) s->name = ""; } while (0);
    }
  if (flag_no_asm)
    {
      do { struct n64_tag_resword *s = is_reserved_word ("asm", sizeof ("asm") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("typeof", sizeof ("typeof") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("inline", sizeof ("inline") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("iterator", sizeof ("iterator") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("complex", sizeof ("complex") - 1); if (s) s->name = ""; } while (0);
    }
}

void
reinit_parse_for_function(void) asm("_reinit_parse_for_function");
void
reinit_parse_for_function(void)
{
}



void
yyprint(FILE *file, int yychar, YYSTYPE yylval) asm("_yyprint");
void
yyprint(FILE *file, int yychar, YYSTYPE yylval)
{
  tree t;
  switch (yychar)
    {
    case 258:
    case 259:
    case 313:
      t = yylval.ttype;
      if (((t)->identifier.pointer))
 fprintf (file, " `%s'", ((t)->identifier.pointer));
      break;

    case 263:
      t = yylval.ttype;
      if (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST)
 fprintf (file,
   " 0x%x%08x",


   ((t)->int_cst.int_cst_high), ((t)->int_cst.int_cst_low));
      break;
    }
}





static int
skip_white_space(register int c) asm("_skip_white_space");
static int
skip_white_space(register int c)
{
  static int newline_warning = 0;

  for (;;)
    {
      switch (c)
 {




 case '\n':
   c = check_newline ();
   break;

 case ' ':
 case '\t':
 case '\f':
 case '\v':
 case '\b':
   c = getc (finput);
   break;

 case '\r':


   if (pedantic && !newline_warning)
     {
       warning ("carriage return in source file");
       warning ("(we only warn about the first carriage return)");
       newline_warning = 1;
     }
   c = getc (finput);
   break;

 case '\\':
   c = getc (finput);
   if (c == '\n')
     lineno++;
   else
     error ("stray '\\' in program");
   c = getc (finput);
   break;

 default:
   return (c);
 }
    }
}




void
position_after_white_space(void) asm("_position_after_white_space");
void
position_after_white_space(void)
{
  register int c;

  if (nextchar != -1)
    c = nextchar, nextchar = -1;
  else
    c = getc (finput);

  ungetc (skip_white_space (c), finput);
}






static char *
extend_token_buffer(char *p) asm("_extend_token_buffer");
static char *
extend_token_buffer(char *p)
{
  int offset = p - token_buffer;

  maxtoken = maxtoken * 2 + 10;
  token_buffer = (char *) xrealloc (token_buffer, maxtoken + 2);

  return token_buffer + offset;
}






int
check_newline(void) asm("_check_newline");
int
check_newline(void)
{
  register int c;
  register int token;

  lineno++;



  c = getc (finput);
  while (c == ' ' || c == '\t')
    c = getc (finput);

  if (c != '#')
    {

      return c;
    }



  c = getc (finput);
  while (c == ' ' || c == '\t')
    c = getc (finput);





  if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    {
      if (c == 'p')
 {
   if (getc (finput) == 'r'
       && getc (finput) == 'a'
       && getc (finput) == 'g'
       && getc (finput) == 'm'
       && getc (finput) == 'a'
       && ((c = getc (finput)) == ' ' || c == '\t' || c == '\n'))
     {

       return handle_sysv_pragma (finput, c);






     }
 }

      else if (c == 'd')
 {
   if (getc (finput) == 'e'
       && getc (finput) == 'f'
       && getc (finput) == 'i'
       && getc (finput) == 'n'
       && getc (finput) == 'e'
       && ((c = getc (finput)) == ' ' || c == '\t' || c == '\n'))
     {

       if ((debug_info_level == DINFO_LEVEL_VERBOSE)
    && (write_symbols == DWARF_DEBUG))
         dwarfout_define (lineno, get_directive_line (finput));

       goto skipline;
     }
 }
      else if (c == 'u')
 {
   if (getc (finput) == 'n'
       && getc (finput) == 'd'
       && getc (finput) == 'e'
       && getc (finput) == 'f'
       && ((c = getc (finput)) == ' ' || c == '\t' || c == '\n'))
     {

       if ((debug_info_level == DINFO_LEVEL_VERBOSE)
    && (write_symbols == DWARF_DEBUG))
         dwarfout_undef (lineno, get_directive_line (finput));

       goto skipline;
     }
 }
      else if (c == 'l')
 {
   if (getc (finput) == 'i'
       && getc (finput) == 'n'
       && getc (finput) == 'e'
       && ((c = getc (finput)) == ' ' || c == '\t'))
     goto linenum;
 }
      else if (c == 'i')
 {
   if (getc (finput) == 'd'
       && getc (finput) == 'e'
       && getc (finput) == 'n'
       && getc (finput) == 't'
       && ((c = getc (finput)) == ' ' || c == '\t'))
     {





       while (c == ' ' || c == '\t')
  c = getc (finput);


       if (c == '\n')
  return c;

       ungetc (c, finput);
       token = yylex ();
       if (token != 264
    || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
  {
    error ("invalid #ident");
    goto skipline;
  }

       if (!flag_no_ident)
  {

    fprintf (asm_out_file, "\t%s\t\"%s\"\n", ".ident", ((yylval.ttype)->string.pointer));;

  }


       goto skipline;
     }
 }

      error ("undefined or invalid # directive");
      goto skipline;
    }

linenum:



  while (c == ' ' || c == '\t')
    c = getc (finput);



  if (c == '\n')
    return c;



  ungetc (c, finput);
  token = yylex ();

  if (token == 263
      && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST)
    {
      int old_lineno = lineno;
      int used_up = 0;



      int l = ((yylval.ttype)->int_cst.int_cst_low) - 1;


      c = getc (finput);
      while (c == ' ' || c == '\t')
 c = getc (finput);
      if (c == '\n')
 {

   lineno = l;
   return c;
 }
      ungetc (c, finput);




      token = yylex ();

      if (token != 264 || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
 {
   error ("invalid #line");
   goto skipline;
 }

      input_filename
 = (char *) permalloc (((yylval.ttype)->string.length) + 1);
      strcpy (input_filename, ((yylval.ttype)->string.pointer));
      lineno = l;



      in_system_header = 0;

      if (main_input_filename == 0)
 main_input_filename = input_filename;


      c = getc (finput);
      while (c == ' ' || c == '\t')
 c = getc (finput);
      if (c == '\n')
 {

   if (input_file_stack)
     input_file_stack->name = input_filename;

   return c;
 }
      ungetc (c, finput);

      token = yylex ();
      used_up = 0;




      if (token == 263
   && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST)
 {
   if (((yylval.ttype)->int_cst.int_cst_low) == 1)
     {

       struct n64_tag_file_stack *p
  = (struct n64_tag_file_stack *) xmalloc (sizeof (struct n64_tag_file_stack));
       input_file_stack->line = old_lineno;
       p->next = input_file_stack;
       p->name = input_filename;
       input_file_stack = p;
       input_file_stack_tick++;

       if (debug_info_level == DINFO_LEVEL_VERBOSE
    && write_symbols == DWARF_DEBUG)
  dwarfout_start_new_source_file (input_filename);


       used_up = 1;
     }
   else if (((yylval.ttype)->int_cst.int_cst_low) == 2)
     {

       if (input_file_stack->next)
  {
    struct n64_tag_file_stack *p = input_file_stack;
    input_file_stack = p->next;
    free (p);
    input_file_stack_tick++;

    if (debug_info_level == DINFO_LEVEL_VERBOSE
        && write_symbols == DWARF_DEBUG)
      dwarfout_resume_previous_source_file (input_file_stack->line);

  }
       else
  error ("#-lines for entering and leaving files don't match");

       used_up = 1;
     }
 }



      if (input_file_stack)
 input_file_stack->name = input_filename;



      if (used_up)
 {

   c = getc (finput);
   while (c == ' ' || c == '\t')
     c = getc (finput);
   if (c == '\n')
     return c;
   ungetc (c, finput);

   token = yylex ();
   used_up = 0;
 }



      if (token == 263
   && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST
   && ((yylval.ttype)->int_cst.int_cst_low) == 3)
 in_system_header = 1, used_up = 1;

      if (used_up)
 {

   c = getc (finput);
   while (c == ' ' || c == '\t')
     c = getc (finput);
   if (c == '\n')
     return c;
   ungetc (c, finput);
 }

      warning ("unrecognized text at end of #line");
    }
  else
    error ("invalid #-line");


 skipline:
  if (c == '\n')
    return c;
  while ((c = getc (finput)) != 
                               (-1) 
                                   && c != '\n');
  return c;
}
int
handle_sysv_pragma(FILE *input, int c) asm("_handle_sysv_pragma");
int
handle_sysv_pragma(FILE *input, int c)
{
  for (;;)
    {
      while (c == ' ' || c == '\t')
 c = getc (input);
      if (c == '\n' || c == 
                           (-1)
                              )
 {
   handle_pragma_token (0, 0);
   return c;
 }
      ungetc (c, input);
      switch (yylex ())
 {
 case 258:
 case 259:
 case 264:
 case 263:
   handle_pragma_token (token_buffer, yylval.ttype);
   break;
 default:
   handle_pragma_token (token_buffer, 0);
 }
      if (nextchar >= 0)
 c = nextchar, nextchar = -1;
      else
 c = getc (input);
    }
}
static int
readescape(int *ignore_ptr) asm("_readescape");
static int
readescape(int *ignore_ptr)
{
  register int c = getc (finput);
  register int code;
  register unsigned count;
  unsigned firstdig = 0;
  int nonnull;

  switch (c)
    {
    case 'x':
      if (warn_traditional)
 warning ("the meaning of `\\x' varies with -traditional");

      if (flag_traditional)
 return c;

      code = 0;
      count = 0;
      nonnull = 0;
      while (1)
 {
   c = getc (finput);
   if (!(c >= 'a' && c <= 'f')
       && !(c >= 'A' && c <= 'F')
       && !(c >= '0' && c <= '9'))
     {
       ungetc (c, finput);
       break;
     }
   code *= 16;
   if (c >= 'a' && c <= 'f')
     code += c - 'a' + 10;
   if (c >= 'A' && c <= 'F')
     code += c - 'A' + 10;
   if (c >= '0' && c <= '9')
     code += c - '0';
   if (code != 0 || count != 0)
     {
       if (count == 0)
  firstdig = code;
       count++;
     }
   nonnull = 1;
 }
      if (! nonnull)
 error ("\\x used with no following hex digits");
      else if (count == 0)

 ;
      else if ((count - 1) * 4 >= ((integer_type_node)->type.precision)
        || (count > 1
     && ((1 << (((integer_type_node)->type.precision) - (count - 1) * 4))
         <= firstdig)))
 pedwarn ("hex escape out of range");
      return code;

    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7':
      code = 0;
      count = 0;
      while ((c <= '7') && (c >= '0') && (count++ < 3))
 {
   code = (code * 8) + (c - '0');
   c = getc (finput);
 }
      ungetc (c, finput);
      return code;

    case '\\': case '\'': case '"':
      return c;

    case '\n':
      lineno++;
      *ignore_ptr = 1;
      return 0;

    case 'n':
      return 012;

    case 't':
      return 011;

    case 'r':
      return 015;

    case 'f':
      return 014;

    case 'b':
      return 010;

    case 'a':
      if (warn_traditional)
 warning ("the meaning of `\\a' varies with -traditional");

      if (flag_traditional)
 return c;
      return 007;

    case 'v':




      return 013;

    case 'e':
    case 'E':
      if (pedantic)
 pedwarn ("non-ANSI-standard escape sequence, `\\%c'", c);
      return 033;

    case '?':
      return c;


    case '(':
    case '{':
    case '[':

    case '%':
      if (pedantic)
 pedwarn ("non-ANSI escape sequence `\\%c'", c);
      return c;
    }
  if (c >= 040 && c < 0177)
    pedwarn ("unknown escape sequence `\\%c'", c);
  else
    pedwarn ("unknown escape sequence: `\\' followed by char code 0x%x", c);
  return c;
}

void
yyerror(char *string) asm("_yyerror");
void
yyerror(char *string)
{
  char buf[200];

  strcpy (buf, string);



  if (end_of_file)
    strcat (buf, " at end of input");
  else if (token_buffer[0] == 0)
    strcat (buf, " at null character");
  else if (token_buffer[0] == '"')
    strcat (buf, " before string constant");
  else if (token_buffer[0] == '\'')
    strcat (buf, " before character constant");
  else if (token_buffer[0] < 040 || (unsigned char) token_buffer[0] >= 0177)
    sprintf (buf + strlen (buf), " before character 0%o",
      (unsigned char) token_buffer[0]);
  else
    strcat (buf, " before `%s'");

  error (buf, token_buffer);
}
int
yylex(void) asm("_yylex");
int
yylex(void)
{
  register int c;
  register char *p;
  register int value;
  int wide_flag = 0;
  int objc_flag = 0;

  if (nextchar >= 0)
    c = nextchar, nextchar = -1;
  else
    c = getc (finput);



  while (1)
    switch (c)
      {
      case ' ':
      case '\t':
      case '\f':
      case '\v':
      case '\b':
 c = getc (finput);
 break;

      case '\r':


      case '\n':
      case '/':
      case '\\':
 c = skip_white_space (c);
      default:
 goto found_nonwhite;
      }
 found_nonwhite:

  token_buffer[0] = c;
  token_buffer[1] = 0;



  switch (c)
    {
    case 
        (-1)
           :
      end_of_file = 1;
      token_buffer[0] = 0;
      value = -1;
      break;

    case '$':
      if (dollars_in_ident)
 goto letter;
      return '$';

    case 'L':

      {
 register int c = getc (finput);
 if (c == '\'')
   {
     wide_flag = 1;
     goto char_constant;
   }
 if (c == '"')
   {
     wide_flag = 1;
     goto string_constant;
   }
 ungetc (c, finput);
      }
      goto letter;

    case '@':
      if (!doing_objc_thang)
 {
   value = c;
   break;
 }
      else
 {

   register int c = getc(finput);
   if (c == '"')
     {
       objc_flag = 1;
       goto string_constant;
     }
   ungetc(c, finput);

 }

    case 'A': case 'B': case 'C': case 'D': case 'E':
    case 'F': case 'G': case 'H': case 'I': case 'J':
    case 'K': case 'M': case 'N': case 'O':
    case 'P': case 'Q': case 'R': case 'S': case 'T':
    case 'U': case 'V': case 'W': case 'X': case 'Y':
    case 'Z':
    case 'a': case 'b': case 'c': case 'd': case 'e':
    case 'f': case 'g': case 'h': case 'i': case 'j':
    case 'k': case 'l': case 'm': case 'n': case 'o':
    case 'p': case 'q': case 'r': case 's': case 't':
    case 'u': case 'v': case 'w': case 'x': case 'y':
    case 'z':
    case '_':
    letter:
      p = token_buffer;
      while (isalnum (c) || c == '_' || c == '$' || c == '@')
 {

   if (c == '@' && ! doing_objc_thang)
     break;
   if (c == '$' && ! dollars_in_ident)
     break;

   if (p >= token_buffer + maxtoken)
     p = extend_token_buffer (p);

   *p++ = c;
   c = getc (finput);
 }

      *p = 0;
      nextchar = c;

      value = 258;
      yylval.itype = 0;



      {
 register struct n64_tag_resword *ptr;

 if (ptr = is_reserved_word (token_buffer, p - token_buffer))
   {
     if (ptr->rid)
       yylval.ttype = ridpointers[(int) ptr->rid];
     value = (int) ptr->token;


     if (doing_objc_thang && value == 313)
       {
  lastiddecl = lookup_name(yylval.ttype);

  if (lastiddecl == (tree) 
                   ((void *)0)
      
     || ((n64_enum_tree_code) (lastiddecl)->common.code) != TYPE_DECL)
    value = 258;
       }


     if (pedantic
  && (value == 282 || value == 283
      || ptr->rid == RID_INLINE)
  && token_buffer[0] != '_')
       pedwarn ("ANSI does not permit the keyword `%s'",
         token_buffer);
   }
      }




      if (value == 258)
 {
    if (token_buffer[0] == '@')
     error("invalid identifier `%s'", token_buffer);

          yylval.ttype = get_identifier (token_buffer);
   lastiddecl = lookup_name (yylval.ttype);

   if (lastiddecl != 0 && ((n64_enum_tree_code) (lastiddecl)->common.code) == TYPE_DECL)
     value = 259;



   else if (lastiddecl != 0 && ((n64_enum_tree_code) (lastiddecl)->common.code) == VAR_DECL
     && ((lastiddecl)->decl.ignored_flag)
     && ((lastiddecl)->common.readonly_flag)
     && ((lastiddecl)->decl.initial) != 0
     && ((n64_enum_tree_code) (((lastiddecl)->decl.initial))->common.code) == STRING_CST)
     {
       tree stringval = ((lastiddecl)->decl.initial);



       yylval.ttype = build_string (((stringval)->string.length),
        ((stringval)->string.pointer));
       value = 264;
     }
          else if (doing_objc_thang)
            {
       tree objc_interface_decl = is_class_name (yylval.ttype);

       if (objc_interface_decl)
  {
    value = 308;
    yylval.ttype = objc_interface_decl;
  }
     }
 }

      break;

    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
    case '.':
      {
 int base = 10;
 int count = 0;
 int largest_digit = 0;
 int numdigits = 0;







 int parts[((32 / 8) * 2 + 2)];
 int overflow = 0;

 enum n64_cpp_enum_anon1{ NOT_FLOAT, AFTER_POINT, TOO_MANY_POINTS};
typedef __underlying_type(enum n64_cpp_enum_anon1) n64_enum_anon1;
n64_enum_anon1 floatflag
   = NOT_FLOAT;

 for (count = 0; count < ((32 / 8) * 2 + 2); count++)
   parts[count] = 0;

 p = token_buffer;
 *p++ = c;

 if (c == '0')
   {
     *p++ = (c = getc (finput));
     if ((c == 'x') || (c == 'X'))
       {
  base = 16;
  *p++ = (c = getc (finput));
       }

     else if (c >= '0' && c <= '9')
       {
  base = 8;
  numdigits++;
       }
     else
       numdigits++;
   }



 while (c == '.'
        || (isalnum (c) && c != 'l' && c != 'L'
     && c != 'u' && c != 'U'
     && c != 'i' && c != 'I' && c != 'j' && c != 'J'
     && (floatflag == NOT_FLOAT || ((c != 'f') && (c != 'F')))))
   {
     if (c == '.')
       {
  if (base == 16)
    error ("floating constant may not be in radix 16");
  if (floatflag == TOO_MANY_POINTS)

    ;
  else if (floatflag == AFTER_POINT)
    {
      error ("malformed floating constant");
      floatflag = TOO_MANY_POINTS;


      p[-1] = '\0';
    }
  else
    floatflag = AFTER_POINT;

  base = 10;
  *p++ = c = getc (finput);




  if (p == token_buffer + 2 && !isdigit (c))
    {
      if (c == '.')
        {
   c = getc (finput);
   if (c == '.')
     {
       *p++ = c;
       *p = 0;
       return 265;
     }
   error ("parse error at `..'");
        }
      ungetc (c, finput);
      token_buffer[1] = 0;
      value = '.';
      goto done;
    }
       }
     else
       {



  if (isdigit (c))
    {
      c = c - '0';
    }
  else if (base <= 10)
    {
      if (c == 'e' || c == 'E')
        {
   base = 10;
   floatflag = AFTER_POINT;
   break;
        }
      error ("nondigits in number and not hexadecimal");
      c = 0;
    }
  else if (c >= 'a')
    {
      c = c - 'a' + 10;
    }
  else
    {
      c = c - 'A' + 10;
    }
  if (c >= largest_digit)
    largest_digit = c;
  numdigits++;

  for (count = 0; count < ((32 / 8) * 2 + 2); count++)
    {
      parts[count] *= base;
      if (count)
        {
   parts[count]
     += (parts[count-1] >> 8);
   parts[count-1]
     &= (1 << 8) - 1;
        }
      else
        parts[0] += c;
    }



  if (parts[((32 / 8) * 2 + 2) - 1] != 0)
    overflow = 1;

  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = (c = getc (finput));
       }
   }

 if (numdigits == 0)
   error ("numeric constant with no digits");

 if (largest_digit >= base)
   error ("numeric constant contains digits beyond the radix");


 *--p = 0;

 if (floatflag != NOT_FLOAT)
   {
     tree type = double_type_node;
     int garbage_chars = 0, exceeds_double = 0;
     int imag = 0;
     double value;
     jmp_buf handler;



     if ((c == 'e') || (c == 'E'))
       {
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = getc (finput);
  if ((c == '+') || (c == '-'))
    {
      *p++ = c;
      c = getc (finput);
    }
  if (! isdigit (c))
    error ("floating constant exponent has no digits");
         while (isdigit (c))
    {
      if (p >= token_buffer + maxtoken - 3)
        p = extend_token_buffer (p);
      *p++ = c;
      c = getc (finput);
    }
       }

     *p = 0;
     
    (*_errno()) 
          = 0;


     if (
        _setjmp3((
        handler
        ), ((void *)0))
                        )
       {
  error ("floating constant out of range");
  value = dconst0;
       }
     else
       {
  int fflag = 0, lflag = 0;



  char *copy = (char *) 
                       __builtin_alloca((
                       p - token_buffer + 1
                       ))
                                                    ;
  memcpy (copy,token_buffer,p - token_buffer + 1);

  set_float_handler (handler);

  while (1)
    {
      int lose = 0;


      switch (c)
        {
        case 'f': case 'F':
   if (fflag)
     error ("more than one `f' in numeric constant");
   fflag = 1;
   break;

        case 'l': case 'L':
   if (lflag)
     error ("more than one `l' in numeric constant");
   lflag = 1;
   break;

        case 'i': case 'I':
   if (imag)
     error ("more than one `i' or `j' in numeric constant");
   else if (pedantic)
     pedwarn ("ANSI C forbids imaginary numeric constants");
   imag = 1;
   break;

        default:
   lose = 1;
        }

      if (lose)
        break;

      if (p >= token_buffer + maxtoken - 3)
        p = extend_token_buffer (p);
      *p++ = c;
      *p = 0;
      c = getc (finput);
    }





  if (fflag)
    {
      if (lflag)
        error ("both `f' and `l' in floating constant");

      type = float_type_node;
      value = ereal_atof (copy, ((type)->type.mode));



      if ((target_isinf (value)) && pedantic)
        warning ("floating point number exceeds range of `float'");
    }
  else if (lflag)
    {
      type = long_double_type_node;
      value = ereal_atof (copy, ((type)->type.mode));
      if ((target_isinf (value)) && pedantic)
        warning ("floating point number exceeds range of `long double'");
    }
  else
    {
      value = ereal_atof (copy, ((type)->type.mode));
      if ((target_isinf (value)) && pedantic)
        warning ("floating point number exceeds range of `double'");
    }

  set_float_handler (((void *)0));
     }

     if (
        (*_errno()) 
              == 
                 34 
                        && !flag_traditional && pedantic)
       {


  if ((ereal_cmp ((dconst1), (value)) == -1)
      || (ereal_cmp ((value), (dconstm1)) == -1))
    {
      warning ("floating point number exceeds range of `double'");
      exceeds_double = 1;
    }
       }

     garbage_chars = 0;
     while (isalnum (c) || c == '.' || c == '_'
     || (!flag_traditional && (c == '+' || c == '-')
         && (p[-1] == 'e' || p[-1] == 'E')))
       {
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = getc (finput);
  garbage_chars++;
       }
     if (garbage_chars > 0)
       error ("garbage at end of number");




     if ((target_isnan (value)))
       value = dconst0;


     if (imag)
       yylval.ttype = build_complex (convert (type, integer_zero_node),
         build_real (type, value));
     else
       yylval.ttype = build_real (type, value);

     ungetc (c, finput);
     *p = 0;
   }
 else
   {
     tree traditional_type, ansi_type, type;
     int high, low;
     int spec_unsigned = 0;
     int spec_long = 0;
     int spec_long_long = 0;
     int spec_imag = 0;
     int bytes, warn, i;

     while (1)
       {
  if (c == 'u' || c == 'U')
    {
      if (spec_unsigned)
        error ("two `u's in integer constant");
      spec_unsigned = 1;
    }
  else if (c == 'l' || c == 'L')
    {
      if (spec_long)
        {
   if (spec_long_long)
     error ("three `l's in integer constant");
   else if (pedantic)
     pedwarn ("ANSI C forbids long long integer constants");
   spec_long_long = 1;
        }
      spec_long = 1;
    }
  else if (c == 'i' || c == 'j' || c == 'I' || c == 'J')
    {
      if (spec_imag)
        error ("more than one `i' or `j' in numeric constant");
      else if (pedantic)
        pedwarn ("ANSI C forbids imaginary numeric constants");
      spec_imag = 1;
    }
  else
    {
      if (isalnum (c) || c == '.' || c == '_'
   || (!flag_traditional && (c == '+' || c == '-')
       && (p[-1] == 'e' || p[-1] == 'E')))
        {
   error ("garbage at end of number");
   while (isalnum (c) || c == '.' || c == '_'
          || (!flag_traditional && (c == '+' || c == '-')
       && (p[-1] == 'e' || p[-1] == 'E')))
     {
       if (p >= token_buffer + maxtoken - 3)
         p = extend_token_buffer (p);
       *p++ = c;
       c = getc (finput);
     }
        }
      break;
    }
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = getc (finput);
       }

     ungetc (c, finput);
     if (spec_long_long)
       bytes = ((long_long_integer_type_node)->type.precision) / 8;
     else
       bytes = ((long_integer_type_node)->type.precision) / 8;

     warn = overflow;
     for (i = bytes; i < ((32 / 8) * 2 + 2); i++)
       if (parts[i])
  warn = 1;
     if (warn)
       pedwarn ("integer constant out of range");




     high = low = 0;

     for (i = 0; i < 32 / 8; i++)
       {
  high |= ((int) parts[i + (32
          / 8)]
    << (i * 8));
  low |= (int) parts[i] << (i * 8);
       }

     yylval.ttype = build_int_2_wide ((int) (low), (int) (high));
     ((yylval.ttype)->common.type) = long_long_unsigned_type_node;




     if (warn_traditional || flag_traditional)
       {





  if (! spec_long && base != 10
      && int_fits_type_p (yylval.ttype, unsigned_type_node))
    traditional_type = (spec_unsigned ? unsigned_type_node
          : integer_type_node);




  else if (! spec_long && base == 10
    && int_fits_type_p (yylval.ttype, integer_type_node))
    traditional_type = (spec_unsigned ? unsigned_type_node
          : integer_type_node);
  else if (! spec_long_long)
    traditional_type = (spec_unsigned ? long_unsigned_type_node
          : long_integer_type_node);
  else
    traditional_type = (spec_unsigned
          ? long_long_unsigned_type_node
          : long_long_integer_type_node);
       }
     if (warn_traditional || ! flag_traditional)
       {

  if (! spec_long && ! spec_unsigned
      && int_fits_type_p (yylval.ttype, integer_type_node))
    ansi_type = integer_type_node;
  else if (! spec_long && (base != 10 || spec_unsigned)
    && int_fits_type_p (yylval.ttype, unsigned_type_node))
    ansi_type = unsigned_type_node;
  else if (! spec_unsigned && !spec_long_long
    && int_fits_type_p (yylval.ttype, long_integer_type_node))
    ansi_type = long_integer_type_node;
  else if (! spec_long_long)
    ansi_type = long_unsigned_type_node;
  else if (! spec_unsigned

    && ((yylval.ttype)->int_cst.int_cst_high) >= 0
    && int_fits_type_p (yylval.ttype,
          long_long_integer_type_node))
    ansi_type = long_long_integer_type_node;
  else
    ansi_type = long_long_unsigned_type_node;
       }

     type = flag_traditional ? traditional_type : ansi_type;

     if (warn_traditional && traditional_type != ansi_type)
       {
  if (((traditional_type)->type.precision)
      != ((ansi_type)->type.precision))
    warning ("width of integer constant changes with -traditional");
  else if (((traditional_type)->common.unsigned_flag)
    != ((ansi_type)->common.unsigned_flag))
    warning ("integer constant is unsigned in ANSI C, signed with -traditional");
  else
    warning ("width of integer constant may change on other systems with -traditional");
       }

     if (!flag_traditional && !int_fits_type_p (yylval.ttype, type)
  && !warn)
       pedwarn ("integer constant out of range");

     if (base == 10 && ! spec_unsigned && ((type)->common.unsigned_flag))
       warning ("decimal constant is so large that it is unsigned");

     if (spec_imag)
       {
  if (((type)->type.precision)
      <= ((integer_type_node)->type.precision))
    yylval.ttype
      = build_complex (integer_zero_node,
         convert (integer_type_node, yylval.ttype));
  else
    error ("complex integer constant is too wide for `complex int'");
       }
     else if (flag_traditional && !int_fits_type_p (yylval.ttype, type))



       {
  ((yylval.ttype)->common.type) = unsigned_type (type);
  yylval.ttype = convert (type, yylval.ttype);
  ((yylval.ttype)->common.public_flag)
    = ((yylval.ttype)->common.static_flag) = 0;
       }
     else
       ((yylval.ttype)->common.type) = type;

     *p = 0;
   }

 value = 263; break;
      }

    case '\'':
    char_constant:
      {
 register int result = 0;
 register int num_chars = 0;
 unsigned width = ((char_type_node)->type.precision);
 int max_chars;

 if (wide_flag)
   {
     width = ((target_flags & 0x00002000) ? 64 : 32);



     max_chars = 1;

   }
 else
   max_chars = ((integer_type_node)->type.precision) / width;

 while (1)
   {
   tryagain:

     c = getc (finput);

     if (c == '\'' || c == 
                          (-1)
                             )
       break;

     if (c == '\\')
       {
  int ignore = 0;
  c = readescape (&ignore);
  if (ignore)
    goto tryagain;
  if (width < 32
      && (unsigned) c >= (1 << width))
    pedwarn ("escape sequence out of range for character");




       }
     else if (c == '\n')
       {
  if (pedantic)
    pedwarn ("ANSI C forbids newline in character constant");
  lineno++;
       }





     num_chars++;
     if (num_chars > maxtoken - 4)
       extend_token_buffer (token_buffer);

     token_buffer[num_chars] = c;


     if (num_chars < max_chars + 1)
       {
  if (width < 32)
    result = (result << width) | (c & ((1 << width) - 1));
  else
    result = c;
       }
   }

 token_buffer[num_chars + 1] = '\'';
 token_buffer[num_chars + 2] = 0;

 if (c != '\'')
   error ("malformatted character constant");
 else if (num_chars == 0)
   error ("empty character constant");
 else if (num_chars > max_chars)
   {
     num_chars = max_chars;
     error ("character constant too long");
   }
 else if (num_chars != 1 && ! flag_traditional)
   warning ("multi-character character constant");


 if (! wide_flag)
   {
     int num_bits = num_chars * width;
     if (num_bits == 0)

       yylval.ttype = build_int_2_wide ((int) (0), (int) (0));
     else if (((char_type_node)->common.unsigned_flag)
       || ((result >> (num_bits - 1)) & 1) == 0)
       yylval.ttype
  = build_int_2_wide ((int) (result & ((unsigned int) ~0 >> (32 - num_bits))), (int) (0))

            ;
     else
       yylval.ttype
  = build_int_2_wide ((int) (result | ~((unsigned int) ~0 >> (32 - num_bits))), (int) (-1))

             ;
     ((yylval.ttype)->common.type) = integer_type_node;
   }
 else
   {
     yylval.ttype = build_int_2_wide ((int) (result), (int) (0));
     ((yylval.ttype)->common.type) = wchar_type_node;
   }

 value = 263;
 break;
      }

    case '"':
    string_constant:
      {
 c = getc (finput);
 p = token_buffer + 1;

 while (c != '"' && c >= 0)
   {
     if (c == '\\')
       {
  int ignore = 0;
  c = readescape (&ignore);
  if (ignore)
    goto skipnewline;
  if (!wide_flag
      && ((char_type_node)->type.precision) < 32
      && c >= (1 << ((char_type_node)->type.precision)))
    pedwarn ("escape sequence out of range for character");
       }
     else if (c == '\n')
       {
  if (pedantic)
    pedwarn ("ANSI C forbids newline in string constant");
  lineno++;
       }

     if (p == token_buffer + maxtoken)
       p = extend_token_buffer (p);
     *p++ = c;

   skipnewline:
     c = getc (finput);
   }
 *p = 0;

 if (c < 0)
   error ("Unterminated string constant");




 if (wide_flag)
   {


     char *widep = (char *) 
                           __builtin_alloca((
                           (p - token_buffer) * (((target_flags & 0x00002000) ? 64 : 32) / 8)
                           ))
                                                                    ;
     int len;
     {
       union { long l; char c[sizeof (long)]; } u;
       int big_endian;
       char *wp, *cp;


       u.l = 1;
       big_endian = u.c[sizeof (long) - 1];
       wp = widep + (big_endian ? (((target_flags & 0x00002000) ? 64 : 32) / 8) - 1 : 0);

       memset (widep,0,(p - token_buffer) * (((target_flags & 0x00002000) ? 64 : 32) / 8));
       for (cp = token_buffer + 1; cp < p; cp++)
  *wp = *cp, wp += (((target_flags & 0x00002000) ? 64 : 32) / 8);
       len = p - token_buffer - 1;
     }

     yylval.ttype = build_string ((len + 1) * (((target_flags & 0x00002000) ? 64 : 32) / 8), widep);
     ((yylval.ttype)->common.type) = wchar_array_type_node;
     value = 264;
   }
 else if (objc_flag)
   {
     extern tree build_objc_string(...) asm("_build_objc_string");

     yylval.ttype = build_objc_string (p - token_buffer,
           token_buffer + 1);
     ((yylval.ttype)->common.type) = char_array_type_node;
     value = 316;
   }
 else
   {
     yylval.ttype = build_string (p - token_buffer, token_buffer + 1);
     ((yylval.ttype)->common.type) = char_array_type_node;
     value = 264;
   }

 *p++ = '"';
 *p = 0;

 break;
      }

    case '+':
    case '-':
    case '&':
    case '|':
    case ':':
    case '<':
    case '>':
    case '*':
    case '/':
    case '%':
    case '^':
    case '!':
    case '=':
      {
 register int c1;

      combine:

 switch (c)
   {
   case '+':
     yylval.code = PLUS_EXPR; break;
   case '-':
     yylval.code = MINUS_EXPR; break;
   case '&':
     yylval.code = BIT_AND_EXPR; break;
   case '|':
     yylval.code = BIT_IOR_EXPR; break;
   case '*':
     yylval.code = MULT_EXPR; break;
   case '/':
     yylval.code = TRUNC_DIV_EXPR; break;
   case '%':
     yylval.code = TRUNC_MOD_EXPR; break;
   case '^':
     yylval.code = BIT_XOR_EXPR; break;
   case 295:
     yylval.code = LSHIFT_EXPR; break;
   case 296:
     yylval.code = RSHIFT_EXPR; break;
   case '<':
     yylval.code = LT_EXPR; break;
   case '>':
     yylval.code = GT_EXPR; break;
   }

 token_buffer[1] = c1 = getc (finput);
 token_buffer[2] = 0;

 if (c1 == '=')
   {
     switch (c)
       {
       case '<':
  value = 294; yylval.code = LE_EXPR; goto done;
       case '>':
  value = 294; yylval.code = GE_EXPR; goto done;
       case '!':
  value = 293; yylval.code = NE_EXPR; goto done;
       case '=':
  value = 293; yylval.code = EQ_EXPR; goto done;
       }
     value = 290; goto done;
   }
 else if (c == c1)
   switch (c)
     {
     case '+':
       value = 298; goto done;
     case '-':
       value = 299; goto done;
     case '&':
       value = 292; goto done;
     case '|':
       value = 291; goto done;
     case '<':
       c = 295;
       goto combine;
     case '>':
       c = 296;
       goto combine;
     }
 else
   switch (c)
     {
     case '-':
       if (c1 == '>')
  { value = 301; goto done; }
       break;
     case ':':
       if (c1 == '>')
  { value = ']'; goto done; }
       break;
     case '<':
       if (c1 == '%')
  { value = '{'; goto done; }
       if (c1 == ':')
  { value = '['; goto done; }
       break;
     case '%':
       if (c1 == '>')
  { value = '}'; goto done; }
       break;
     }
 ungetc (c1, finput);
 token_buffer[1] = 0;

 if ((c == '<') || (c == '>'))
   value = 294;
 else value = c;
 goto done;
      }

    case 0:

      value = 1;
      break;

    default:
      value = c;
    }

done:


  return value;
}





void
set_yydebug(int value) asm("_set_yydebug");
void
set_yydebug(int value)
{

  yydebug = value;



}

