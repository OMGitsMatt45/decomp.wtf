// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/vasprintf.c
/* Like vsprintf but provides a pointer to malloc'd storage, which must
   be freed by the caller.
   Copyright (C) 1994 Free Software Foundation, Inc.

This file is part of the libiberty library.
Libiberty is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

Libiberty is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with libiberty; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);


unsigned long strtoul(...) asm("_strtoul");
char *malloc(...) asm("_malloc");

static int
int_vasprintf(char **result, const char *format, va_list *args) asm("_int_vasprintf");
static int
int_vasprintf(char **result, const char *format, va_list *args)
{
  const char *p = format;


  int total_width = strlen (format) + 1;
  va_list ap;

  memcpy ((void *) &ap, (void *) args, sizeof (va_list));

  while (*p != '\0')
    {
      if (*p++ == '%')
 {
   while (strchr ("-+ #0", *p))
     ++p;
   if (*p == '*')
     {
       ++p;
       total_width += abs (
                          __builtin_va_arg(
                          ap
                          ,
                          int
                          )
                                          );
     }
   else
     total_width += strtoul (p, &p, 10);
   if (*p == '.')
     {
       ++p;
       if (*p == '*')
  {
    ++p;
    total_width += abs (
                       __builtin_va_arg(
                       ap
                       ,
                       int
                       )
                                       );
  }
       else
       total_width += strtoul (p, &p, 10);
     }
   while (strchr ("hlL", *p))
     ++p;

   total_width += 30;
   switch (*p)
     {
     case 'd':
     case 'i':
     case 'o':
     case 'u':
     case 'x':
     case 'X':
     case 'c':
       (void) 
             __builtin_va_arg(
             ap
             ,
             int
             )
                             ;
       break;
     case 'f':
     case 'e':
     case 'E':
     case 'g':
     case 'G':
       (void) 
             __builtin_va_arg(
             ap
             ,
             double
             )
                                ;
       break;
     case 's':
       total_width += strlen (
                             __builtin_va_arg(
                             ap
                             ,
                             char *
                             )
                                                );
       break;
     case 'p':
     case 'n':
       (void) 
             __builtin_va_arg(
             ap
             ,
             char *
             )
                                ;
       break;
     }
 }
    }



  *result = malloc (total_width);
  if (*result != 
                ((void *)0)
                    )
    return vsprintf (*result, format, *args);
  else
    return 0;
}

int
vasprintf(char **result, const char *format, va_list args) asm("_vasprintf");
int
vasprintf(char **result, const char *format, va_list args)
{
  return int_vasprintf (result, format, &args);
}

