// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/expr.c
/* Convert tree expression to rtl instructions, for GNU compiler.
   Copyright (C) 1988, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int recog(...) asm("_recog");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int mode_dependent_address_p(...) asm("_mode_dependent_address_p");
extern int delete_insns_since(...) asm("_delete_insns_since");
extern int push_operand(...) asm("_push_operand");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int bc_emit_instruction(...) asm("_bc_emit_instruction");
extern int push_temp_slots(...) asm("_push_temp_slots");
extern int preserve_temp_slots(...) asm("_preserve_temp_slots");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int pop_temp_slots(...) asm("_pop_temp_slots");
extern int aggregate_value_p(...) asm("_aggregate_value_p");
extern int preserve_subexpressions_p(...) asm("_preserve_subexpressions_p");
extern int push_obstacks(...) asm("_push_obstacks");
extern int error_with_decl(...) asm("_error_with_decl");
extern int mark_addressable(...) asm("_mark_addressable");
extern int put_var_into_stack(...) asm("_put_var_into_stack");
extern int insert_block(...) asm("_insert_block");
extern int expand_decl(...) asm("_expand_decl");
extern int preserve_rtl_expr_result(...) asm("_preserve_rtl_expr_result");
extern int free_temps_for_rtl_expr(...) asm("_free_temps_for_rtl_expr");
extern int emit_jump(...) asm("_emit_jump");
extern int really_constant_p(...) asm("_really_constant_p");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int reorder_insns(...) asm("_reorder_insns");
extern int mark_temp_addr_taken(...) asm("_mark_temp_addr_taken");
extern int mark_reg_pointer(...) asm("_mark_reg_pointer");
extern int update_temp_slot_address(...) asm("_update_temp_slot_address");
extern int warning(...) asm("_warning");
extern int push_topmost_sequence(...) asm("_push_topmost_sequence");
extern int pop_topmost_sequence(...) asm("_pop_topmost_sequence");
extern int fatal(...) asm("_fatal");
extern int error(...) asm("_error");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int invert_jump(...) asm("_invert_jump");
extern int redirect_jump(...) asm("_redirect_jump");
extern int bc_xstrdup(...) asm("_bc_xstrdup");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_bc_label;
struct n64_tag_bc_labelref;
struct n64_tag_bc_seg;
struct n64_tag_bc_segreloc;
struct n64_tag_bc_segsym;
struct n64_tag_bc_sym;
struct n64_tag_binary_operator;
struct n64_tag_function;
struct n64_tag_increment_operator;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_move_by_pieces;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_unary_operator;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;

typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;


enum n64_cpp_enum_type_class{
  no_type_class = -1,
  void_type_class, integer_type_class, char_type_class,
  enumeral_type_class, boolean_type_class,
  pointer_type_class, reference_type_class, offset_type_class,
  real_type_class, complex_type_class,
  function_type_class, method_type_class,
  record_type_class, union_type_class,
  array_type_class, string_type_class, set_type_class, file_type_class,
  lang_type_class
};
typedef __underlying_type(enum n64_cpp_enum_type_class) n64_enum_type_class;


extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");



enum n64_cpp_enum_bytecode_opcode{ neverneverland,
  drop,
  duplicate,
  over,
  setstackSI,
  adjstackSI,
  constQI,
  constHI,
  constSI,
  constDI,
  constSF,
  constDF,
  constXF,
  constP,
  loadQI,
  loadHI,
  loadSI,
  loadDI,
  loadSF,
  loadDF,
  loadXF,
  loadP,
  storeQI,
  storeHI,
  storeSI,
  storeDI,
  storeSF,
  storeDF,
  storeXF,
  storeP,
  storeBLK,
  clearBLK,
  addconstPSI,
  newlocalSI,
  localP,
  argP,
  convertQIHI,
  convertHISI,
  convertSIDI,
  convertQISI,
  convertQUHU,
  convertHUSU,
  convertSUDU,
  convertQUSU,
  convertSFDF,
  convertDFXF,
  convertHIQI,
  convertSIHI,
  convertDISI,
  convertSIQI,
  convertSUQU,
  convertDFSF,
  convertXFDF,
  convertSISF,
  convertSIDF,
  convertSIXF,
  convertSUSF,
  convertSUDF,
  convertSUXF,
  convertDISF,
  convertDIDF,
  convertDIXF,
  convertDUSF,
  convertDUDF,
  convertDUXF,
  convertSFSI,
  convertDFSI,
  convertXFSI,
  convertSFSU,
  convertDFSU,
  convertXFSU,
  convertSFDI,
  convertDFDI,
  convertXFDI,
  convertSFDU,
  convertDFDU,
  convertXFDU,
  convertPSI,
  convertSIP,
  convertSIT,
  convertDIT,
  convertSFT,
  convertDFT,
  convertXFT,
  convertPT,
  zxloadBI,
  sxloadBI,
  sstoreBI,
  addSI,
  addDI,
  addSF,
  addDF,
  addXF,
  addPSI,
  subSI,
  subDI,
  subSF,
  subDF,
  subXF,
  subPP,
  mulSI,
  mulDI,
  mulSU,
  mulDU,
  mulSF,
  mulDF,
  mulXF,
  divSI,
  divDI,
  divSU,
  divDU,
  divSF,
  divDF,
  divXF,
  modSI,
  modDI,
  modSU,
  modDU,
  andSI,
  andDI,
  iorSI,
  iorDI,
  xorSI,
  xorDI,
  lshiftSI,
  lshiftSU,
  lshiftDI,
  lshiftDU,
  rshiftSI,
  rshiftSU,
  rshiftDI,
  rshiftDU,
  ltSI,
  ltSU,
  ltDI,
  ltDU,
  ltSF,
  ltDF,
  ltXF,
  ltP,
  leSI,
  leSU,
  leDI,
  leDU,
  leSF,
  leDF,
  leXF,
  leP,
  geSI,
  geSU,
  geDI,
  geDU,
  geSF,
  geDF,
  geXF,
  geP,
  gtSI,
  gtSU,
  gtDI,
  gtDU,
  gtSF,
  gtDF,
  gtXF,
  gtP,
  eqSI,
  eqDI,
  eqSF,
  eqDF,
  eqXF,
  eqP,
  neSI,
  neDI,
  neSF,
  neDF,
  neXF,
  neP,
  negSI,
  negDI,
  negSF,
  negDF,
  negXF,
  notSI,
  notDI,
  notT,
  predecQI,
  predecHI,
  predecSI,
  predecDI,
  predecP,
  predecSF,
  predecDF,
  predecXF,
  predecBI,
  preincQI,
  preincHI,
  preincSI,
  preincDI,
  preincP,
  preincSF,
  preincDF,
  preincXF,
  preincBI,
  postdecQI,
  postdecHI,
  postdecSI,
  postdecDI,
  postdecP,
  postdecSF,
  postdecDF,
  postdecXF,
  postdecBI,
  postincQI,
  postincHI,
  postincSI,
  postincDI,
  postincP,
  postincSF,
  postincDF,
  postincXF,
  postincBI,
  xjumpif,
  xjumpifnot,
  jump,
  jumpP,
  caseSI,
  caseSU,
  caseDI,
  caseDU,
  call,
  returnP,
  ret,
  linenote,
  LAST_AND_UNUSED_OPCODE
};
typedef __underlying_type(enum n64_cpp_enum_bytecode_opcode) n64_enum_bytecode_opcode;

enum n64_cpp_enum_typecode{

QIcode,
QUcode,
HIcode,
HUcode,
SIcode,
SUcode,
DIcode,
DUcode,
SFcode,
DFcode,
XFcode,
Pcode,
Tcode,


  LAST_AND_UNUSED_TYPECODE
};
typedef __underlying_type(enum n64_cpp_enum_typecode) n64_enum_typecode;

extern void bc_expand_conversion(...) asm("_bc_expand_conversion");
extern void bc_expand_truth_conversion(...) asm("_bc_expand_truth_conversion");
extern void bc_expand_binary_operation(...) asm("_bc_expand_binary_operation");
extern void bc_expand_unary_operation(...) asm("_bc_expand_unary_operation");

struct n64_tag_binary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
  n64_enum_typecode arg1;
};

extern struct n64_tag_binary_operator optab_plus_expr[];
extern struct n64_tag_binary_operator optab_minus_expr[];
extern struct n64_tag_binary_operator optab_mult_expr[];
extern struct n64_tag_binary_operator optab_trunc_div_expr[];
extern struct n64_tag_binary_operator optab_trunc_mod_expr[];
extern struct n64_tag_binary_operator optab_rdiv_expr[];
extern struct n64_tag_binary_operator optab_bit_and_expr[];
extern struct n64_tag_binary_operator optab_bit_ior_expr[];
extern struct n64_tag_binary_operator optab_bit_xor_expr[];
extern struct n64_tag_binary_operator optab_lshift_expr[];
extern struct n64_tag_binary_operator optab_rshift_expr[];
extern struct n64_tag_binary_operator optab_truth_and_expr[];
extern struct n64_tag_binary_operator optab_truth_or_expr[];
extern struct n64_tag_binary_operator optab_lt_expr[];
extern struct n64_tag_binary_operator optab_le_expr[];
extern struct n64_tag_binary_operator optab_ge_expr[];
extern struct n64_tag_binary_operator optab_gt_expr[];
extern struct n64_tag_binary_operator optab_eq_expr[];
extern struct n64_tag_binary_operator optab_ne_expr[];

struct n64_tag_unary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
};

extern struct n64_tag_unary_operator optab_negate_expr[];
extern struct n64_tag_unary_operator optab_bit_not_expr[];
extern struct n64_tag_unary_operator optab_truth_not_expr[];

struct n64_tag_increment_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode arg;
};

extern struct n64_tag_increment_operator optab_predecrement_expr[];
extern struct n64_tag_increment_operator optab_preincrement_expr[];
extern struct n64_tag_increment_operator optab_postdecrement_expr[];
extern struct n64_tag_increment_operator optab_postincrement_expr[];



struct n64_tag_bc_sym
{

  char *name;


  unsigned int defined:1;


  unsigned int global:1;


  unsigned int common:1;


  unsigned long int val;


  struct n64_tag_bc_sym *next;
};



struct n64_tag_bc_segsym
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *next;
};



struct n64_tag_bc_segreloc
{

  unsigned int offset;


  struct n64_tag_bc_sym *sym;

  struct n64_tag_bc_segreloc *next;
};



struct n64_tag_bc_seg
{

  unsigned int alloc;


  char *data;


  unsigned int size;


  struct n64_tag_bc_segsym *syms;


  struct n64_tag_bc_segreloc *relocs;
};



struct n64_tag_bc_label
{

  unsigned int offset;


  unsigned int defined:1;



  int uid;


  struct n64_tag_bc_label *next;
};






struct n64_tag_bc_labelref
{

  struct n64_tag_bc_label *label;


  unsigned int offset;


  struct n64_tag_bc_labelref *next;
};



extern void bc_initialize(void) asm("_bc_initialize");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern void bc_emit_bytecode(...) asm("_bc_emit_bytecode");
extern void bc_emit_bytecode_const(...) asm("_bc_emit_bytecode_const");
extern struct n64_tag_bc_label *bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
extern int bc_emit_bytecode_labeldef(...) asm("_bc_emit_bytecode_labeldef");
extern void bc_emit_bytecode_labelref(...) asm("_bc_emit_bytecode_labelref");
extern void bc_emit_code_labelref(...) asm("_bc_emit_code_labelref");
extern char *bc_end_function(void) asm("_bc_end_function");
extern void bc_align_const(...) asm("_bc_align_const");
extern void bc_emit_const(...) asm("_bc_emit_const");
extern void bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern void bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern void bc_align_data(...) asm("_bc_align_data");
extern void bc_emit_data(...) asm("_bc_emit_data");
extern void bc_emit_data_skip(...) asm("_bc_emit_data_skip");
extern int bc_emit_data_labeldef(...) asm("_bc_emit_data_labeldef");
extern void bc_emit_data_labelref(...) asm("_bc_emit_data_labelref");
extern int bc_define_pointer(...) asm("_bc_define_pointer");
extern int bc_emit_common(...) asm("_bc_emit_common");
extern void bc_globalize_label(...) asm("_bc_globalize_label");
extern void bc_text(void) asm("_bc_text");
extern void bc_data(void) asm("_bc_data");
extern void bc_align(...) asm("_bc_align");
extern void bc_emit(...) asm("_bc_emit");
extern void bc_emit_skip(...) asm("_bc_emit_skip");
extern int bc_emit_labeldef(...) asm("_bc_emit_labeldef");
extern void bc_emit_labelref(...) asm("_bc_emit_labelref");
extern void bc_write_file(...) asm("_bc_write_file");
int cse_not_expected;




int do_preexpand_calls = 1;



int pending_stack_adjust;





int inhibit_defer_pop;



tree cleanups_this_call;





int target_temp_slot_level;




static rtx saveregs_value;


static rtx apply_args_value;




struct n64_tag_move_by_pieces
{
  rtx to;
  rtx to_addr;
  int autinc_to;
  int explicit_inc_to;
  int to_struct;
  rtx from;
  rtx from_addr;
  int autinc_from;
  int explicit_inc_from;
  int from_struct;
  int len;
  int offset;
  int reverse;
};





extern int local_vars_size;
extern int stack_depth;
extern int max_stack_depth;
extern struct n64_tag_obstack permanent_obstack;


static rtx enqueue_insn (rtx, rtx) asm("_enqueue_insn");
static int queued_subexp_p (rtx) asm("_queued_subexp_p");
static void init_queue (void) asm("_init_queue");
static void move_by_pieces (rtx, rtx, int, int) asm("_move_by_pieces");
static int move_by_pieces_ninsns (unsigned int, int) asm("_move_by_pieces_ninsns");
static void move_by_pieces_1 (rtx (*)(...), n64_enum_machine_mode, struct n64_tag_move_by_pieces *) asm("_move_by_pieces_1")
                                    ;
static void store_constructor (tree, rtx) asm("_store_constructor");
static rtx store_field (rtx, int, int, n64_enum_machine_mode, tree, n64_enum_machine_mode, int, int, int) asm("_store_field")
                                             ;
static int get_inner_unaligned_p (tree) asm("_get_inner_unaligned_p");
static tree save_noncopied_parts (tree, tree) asm("_save_noncopied_parts");
static tree init_noncopied_parts (tree, tree) asm("_init_noncopied_parts");
static int safe_from_p (rtx, tree) asm("_safe_from_p");
static int fixed_type_p (tree) asm("_fixed_type_p");
static int get_pointer_alignment (tree, unsigned) asm("_get_pointer_alignment");
static tree string_constant (tree, tree *) asm("_string_constant");
static tree c_strlen (tree) asm("_c_strlen");
static rtx expand_builtin (tree, rtx, rtx, n64_enum_machine_mode, int) asm("_expand_builtin")
                                   ;
static int apply_args_size (void) asm("_apply_args_size");
static int apply_result_size (void) asm("_apply_result_size");
static rtx result_vector (int, rtx) asm("_result_vector");
static rtx expand_builtin_apply_args (void) asm("_expand_builtin_apply_args");
static rtx expand_builtin_apply (rtx, rtx, rtx) asm("_expand_builtin_apply");
static void expand_builtin_return (rtx) asm("_expand_builtin_return");
static rtx expand_increment (tree, int) asm("_expand_increment");
rtx bc_expand_increment (struct n64_tag_increment_operator *, tree) asm("_bc_expand_increment");
tree bc_runtime_type_code (tree) asm("_bc_runtime_type_code");
rtx bc_allocate_local (int, int) asm("_bc_allocate_local");
void bc_store_memory (tree, tree) asm("_bc_store_memory");
tree bc_expand_component_address (tree) asm("_bc_expand_component_address");
tree bc_expand_address (tree) asm("_bc_expand_address");
void bc_expand_constructor (tree) asm("_bc_expand_constructor");
void bc_adjust_stack (int) asm("_bc_adjust_stack");
tree bc_canonicalize_array_ref (tree) asm("_bc_canonicalize_array_ref");
void bc_load_memory (tree, tree) asm("_bc_load_memory");
void bc_load_externaddr (rtx) asm("_bc_load_externaddr");
void bc_load_externaddr_id (tree, int) asm("_bc_load_externaddr_id");
void bc_load_localaddr (rtx) asm("_bc_load_localaddr");
void bc_load_parmaddr (rtx) asm("_bc_load_parmaddr");
static void preexpand_calls (tree) asm("_preexpand_calls");
static void do_jump_by_parts_greater (tree, int, rtx, rtx) asm("_do_jump_by_parts_greater");
void do_jump_by_parts_greater_rtx (n64_enum_machine_mode, int, rtx, rtx, rtx, rtx) asm("_do_jump_by_parts_greater_rtx");
static void do_jump_by_parts_equality (tree, rtx, rtx) asm("_do_jump_by_parts_equality");
static void do_jump_by_parts_equality_rtx (rtx, rtx, rtx) asm("_do_jump_by_parts_equality_rtx");
static void do_jump_for_compare (rtx, rtx, rtx) asm("_do_jump_for_compare");
static rtx compare (tree, n64_enum_rtx_code, n64_enum_rtx_code) asm("_compare");
static rtx do_store_flag (tree, rtx, n64_enum_machine_mode, int) asm("_do_store_flag");
static tree defer_cleanups_to (tree) asm("_defer_cleanups_to");
extern void (*interim_eh_hook) (tree);
extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");





static char direct_load[(int) MAX_MACHINE_MODE];
static char direct_store[(int) MAX_MACHINE_MODE];
n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];
n64_enum_bytecode_opcode mode_to_const_map[MAX_MACHINE_MODE];
n64_enum_bytecode_opcode mode_to_load_map[MAX_MACHINE_MODE];
n64_enum_bytecode_opcode mode_to_store_map[MAX_MACHINE_MODE];



void
bc_init_mode_to_opcode_maps(void) asm("_bc_init_mode_to_opcode_maps");
void
bc_init_mode_to_opcode_maps(void)
{
  int mode;

  for (mode = 0; mode < (int) MAX_MACHINE_MODE; mode++)
    mode_to_const_map[mode] =
      mode_to_load_map[mode] =
 mode_to_store_map[mode] = neverneverland;






mode_to_const_map[(int) QImode] = constQI; mode_to_load_map[(int) QImode] = loadQI; mode_to_store_map[(int) QImode] = storeQI;
mode_to_const_map[(int) HImode] = constHI; mode_to_load_map[(int) HImode] = loadHI; mode_to_store_map[(int) HImode] = storeHI;
mode_to_const_map[(int) VOIDmode] = constSI; mode_to_load_map[(int) VOIDmode] = loadSI; mode_to_store_map[(int) VOIDmode] = storeSI;
mode_to_const_map[(int) SImode] = constSI; mode_to_load_map[(int) SImode] = loadSI; mode_to_store_map[(int) SImode] = storeSI;
mode_to_const_map[(int) DImode] = constDI; mode_to_load_map[(int) DImode] = loadDI; mode_to_store_map[(int) DImode] = storeDI;
mode_to_const_map[(int) PSImode] = constP; mode_to_load_map[(int) PSImode] = loadP; mode_to_store_map[(int) PSImode] = storeP;
mode_to_const_map[(int) BLKmode] = constP; mode_to_load_map[(int) BLKmode] = loadP; mode_to_store_map[(int) BLKmode] = neverneverland;
mode_to_const_map[(int) SFmode] = constSF; mode_to_load_map[(int) SFmode] = loadSF; mode_to_store_map[(int) SFmode] = storeSF;
mode_to_const_map[(int) DFmode] = constDF; mode_to_load_map[(int) DFmode] = loadDF; mode_to_store_map[(int) DFmode] = storeDF;

}




void
init_expr_once(void) asm("_init_expr_once");
void
init_expr_once(void)
{
  rtx insn, pat;
  n64_enum_machine_mode mode;



  rtx mem = gen_rtx (MEM, VOIDmode, stack_pointer_rtx);
  rtx mem1 = gen_rtx (MEM, VOIDmode, frame_pointer_rtx);

  start_sequence ();
  insn = emit_insn (gen_rtx (SET, 0, 0));
  pat = ((insn)->fld[3].rtx);

  for (mode = VOIDmode; (int) mode < (int) MAX_MACHINE_MODE;
       mode = (n64_enum_machine_mode) ((int) mode + 1))
    {
      int regno;
      rtx reg;
      int num_clobbers;

      direct_load[(int) mode] = direct_store[(int) mode] = 0;
      ((mem)->mode = (mode));
      ((mem1)->mode = (mode));




      if (mode != VOIDmode && mode != BLKmode)
 for (regno = 0; regno < 68
      && (direct_load[(int) mode] == 0 || direct_store[(int) mode] == 0);
      regno++)
   {
     if (! mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
       continue;

     reg = gen_rtx (REG, mode, regno);

     ((pat)->fld[1].rtx) = mem;
     ((pat)->fld[0].rtx) = reg;
     if (recog (pat, insn, &num_clobbers) >= 0)
       direct_load[(int) mode] = 1;

     ((pat)->fld[1].rtx) = mem1;
     ((pat)->fld[0].rtx) = reg;
     if (recog (pat, insn, &num_clobbers) >= 0)
       direct_load[(int) mode] = 1;

     ((pat)->fld[1].rtx) = reg;
     ((pat)->fld[0].rtx) = mem;
     if (recog (pat, insn, &num_clobbers) >= 0)
       direct_store[(int) mode] = 1;

     ((pat)->fld[1].rtx) = reg;
     ((pat)->fld[0].rtx) = mem1;
     if (recog (pat, insn, &num_clobbers) >= 0)
       direct_store[(int) mode] = 1;
   }
    }

  end_sequence ();
}



void
init_expr(void) asm("_init_expr");
void
init_expr(void)
{
  init_queue ();

  pending_stack_adjust = 0;
  inhibit_defer_pop = 0;
  cleanups_this_call = 0;
  saveregs_value = 0;
  apply_args_value = 0;
  forced_labels = 0;
}




void
save_expr_status(struct n64_tag_function *p) asm("_save_expr_status");
void
save_expr_status(struct n64_tag_function *p)
{

  emit_queue ();

  p->pending_stack_adjust = pending_stack_adjust;
  p->inhibit_defer_pop = inhibit_defer_pop;
  p->cleanups_this_call = cleanups_this_call;
  p->saveregs_value = saveregs_value;
  p->apply_args_value = apply_args_value;
  p->forced_labels = forced_labels;

  pending_stack_adjust = 0;
  inhibit_defer_pop = 0;
  cleanups_this_call = 0;
  saveregs_value = 0;
  apply_args_value = 0;
  forced_labels = 0;
}




void
restore_expr_status(struct n64_tag_function *p) asm("_restore_expr_status");
void
restore_expr_status(struct n64_tag_function *p)
{
  pending_stack_adjust = p->pending_stack_adjust;
  inhibit_defer_pop = p->inhibit_defer_pop;
  cleanups_this_call = p->cleanups_this_call;
  saveregs_value = p->saveregs_value;
  apply_args_value = p->apply_args_value;
  forced_labels = p->forced_labels;
}




static rtx pending_chain;
static rtx
enqueue_insn(rtx var, rtx body) asm("_enqueue_insn");
static rtx
enqueue_insn(rtx var, rtx body)
{
  pending_chain = gen_rtx (QUEUED, ((var)->mode),
      var, (rtx) 0, (rtx) 0, body, pending_chain);
  return pending_chain;
}
rtx
protect_from_queue(register rtx x, int modify) asm("_protect_from_queue");
rtx
protect_from_queue(register rtx x, int modify)
{
  register n64_enum_rtx_code code = ((x)->code);







  if (code != QUEUED)
    {





      if (code == MEM && ((x)->mode) != BLKmode
   && ((((x)->fld[0].rtx))->code) == QUEUED && !modify)
 {
   register rtx y = ((x)->fld[0].rtx);
   register rtx cxx_new = gen_rtx (MEM, ((x)->mode), ((y)->fld[0].rtx));

   ((cxx_new)->in_struct) = ((x)->in_struct);
   ((cxx_new)->unchanging) = ((x)->unchanging);
   ((cxx_new)->volatil) = ((x)->volatil);

   if (((y)->fld[1].rtx))
     {
       register rtx temp = gen_reg_rtx (((cxx_new)->mode));
       emit_insn_before (gen_move_insn (temp, cxx_new),
    ((y)->fld[1].rtx));
       return temp;
     }
   return cxx_new;
 }


      if (code == MEM)
 {
   rtx tem = protect_from_queue (((x)->fld[0].rtx), 0);
   if (tem != ((x)->fld[0].rtx))
     {
       x = copy_rtx (x);
       ((x)->fld[0].rtx) = tem;
     }
 }
      else if (code == PLUS || code == MULT)
 {
   rtx new0 = protect_from_queue (((x)->fld[0].rtx), 0);
   rtx new1 = protect_from_queue (((x)->fld[1].rtx), 0);
   if (new0 != ((x)->fld[0].rtx) || new1 != ((x)->fld[1].rtx))
     {
       x = copy_rtx (x);
       ((x)->fld[0].rtx) = new0;
       ((x)->fld[1].rtx) = new1;
     }
 }
      return x;
    }

  if (((x)->fld[1].rtx) == 0)
    return ((x)->fld[0].rtx);


  if (((x)->fld[2].rtx) != 0)
    return ((x)->fld[2].rtx);


  ((x)->fld[2].rtx) = gen_reg_rtx (((((x)->fld[0].rtx))->mode));
  emit_insn_before (gen_move_insn (((x)->fld[2].rtx), ((x)->fld[0].rtx)),
      ((x)->fld[1].rtx));
  return ((x)->fld[2].rtx);
}






static int
queued_subexp_p(rtx x) asm("_queued_subexp_p");
static int
queued_subexp_p(rtx x)
{
  register n64_enum_rtx_code code = ((x)->code);
  switch (code)
    {
    case QUEUED:
      return 1;
    case MEM:
      return queued_subexp_p (((x)->fld[0].rtx));
    case MULT:
    case PLUS:
    case MINUS:
      return queued_subexp_p (((x)->fld[0].rtx))
 || queued_subexp_p (((x)->fld[1].rtx));
    }
  return 0;
}



void
emit_queue(void) asm("_emit_queue");
void
emit_queue(void)
{
  register rtx p;
  while (p = pending_chain)
    {
      ((p)->fld[1].rtx) = emit_insn (((p)->fld[3].rtx));
      pending_chain = ((p)->fld[4].rtx);
    }
}

static void
init_queue(void) asm("_init_queue");
static void
init_queue(void)
{
  if (pending_chain)
    abort ();
}






void
convert_move(register rtx to, register rtx from, int unsignedp) asm("_convert_move");
void
convert_move(register rtx to, register rtx from, int unsignedp)
{
  n64_enum_machine_mode to_mode = ((to)->mode);
  n64_enum_machine_mode from_mode = ((from)->mode);
  int to_real = (mode_class[(int)(to_mode)]) == MODE_FLOAT;
  int from_real = (mode_class[(int)(from_mode)]) == MODE_FLOAT;
  n64_enum_insn_code code;
  rtx libcall;


  n64_enum_rtx_code equiv_code = (unsignedp ? ZERO_EXTEND : SIGN_EXTEND);

  to = protect_from_queue (to, 1);
  from = protect_from_queue (from, 0);

  if (to_real != from_real)
    abort ();





  if (((from)->code) == SUBREG && ((from)->in_struct)
      && ((mode_size[(int)(((((from)->fld[0].rtx))->mode))])
   >= (mode_size[(int)(to_mode)]))
      && ((from)->unchanging) == unsignedp)
    from = gen_lowpart (to_mode, from), from_mode = to_mode;

  if (((to)->code) == SUBREG && ((to)->in_struct))
    abort ();

  if (to_mode == from_mode
      || (from_mode == VOIDmode && (((from)->code) == LABEL_REF || ((from)->code) == SYMBOL_REF || ((from)->code) == CONST_INT || ((from)->code) == CONST_DOUBLE || ((from)->code) == CONST || ((from)->code) == HIGH)))
    {
      emit_move_insn (to, from);
      return;
    }

  if (to_real)
    {
      rtx value;
      if (((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000))) && from_mode == SFmode && to_mode == DFmode)
 {
   emit_unop_insn (CODE_FOR_extendsfdf2, to, from, UNKNOWN);
   return;
 }
      if (((! (target_flags & 0x00000100)) && (! (target_flags & 0x00020000))) && from_mode == DFmode && to_mode == SFmode)
 {
   emit_unop_insn (CODE_FOR_truncdfsf2, to, from, UNKNOWN);
   return;
 }
      libcall = (rtx) 0;
      switch (from_mode)
 {
 case SFmode:
   switch (to_mode)
     {
     case DFmode:
       libcall = extendsfdf2_libfunc;
       break;

     case XFmode:
       libcall = extendsfxf2_libfunc;
       break;

     case TFmode:
       libcall = extendsftf2_libfunc;
       break;
     }
   break;

 case DFmode:
   switch (to_mode)
     {
     case SFmode:
       libcall = truncdfsf2_libfunc;
       break;

     case XFmode:
       libcall = extenddfxf2_libfunc;
       break;

     case TFmode:
       libcall = extenddftf2_libfunc;
       break;
     }
   break;

 case XFmode:
   switch (to_mode)
     {
     case SFmode:
       libcall = truncxfsf2_libfunc;
       break;

     case DFmode:
       libcall = truncxfdf2_libfunc;
       break;
     }
   break;

 case TFmode:
   switch (to_mode)
     {
     case SFmode:
       libcall = trunctfsf2_libfunc;
       break;

     case DFmode:
       libcall = trunctfdf2_libfunc;
       break;
     }
   break;
 }

      if (libcall == (rtx) 0)

 abort ();

      value = emit_library_call_value (libcall, (rtx) 0, 1, to_mode,
           1, from, from_mode);
      emit_move_insn (to, value);
      return;
    }




  if ((8 * mode_size[(int)(from_mode)]) < (8 * mode_size[(int)(to_mode)])
      && (8 * mode_size[(int)(to_mode)]) > ((target_flags & 0x00002000) ? 64 : 32))
    {
      rtx insns;
      rtx lowpart;
      rtx fill_value;
      rtx lowfrom;
      int i;
      n64_enum_machine_mode lowpart_mode;
      int nwords = ((((mode_size[(int)(to_mode)])) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4)));


      if ((code = can_extend_p (to_mode, from_mode, unsignedp))
   != CODE_FOR_nothing)
 {




   if (optimize > 0 && ((from)->code) == SUBREG)
     from = force_reg (from_mode, from);
   emit_unop_insn (code, to, from, equiv_code);
   return;
 }

      else if ((8 * mode_size[(int)(from_mode)]) < ((target_flags & 0x00002000) ? 64 : 32)
        && ((code = can_extend_p (to_mode, word_mode, unsignedp))
     != CODE_FOR_nothing))
 {
   if (((to)->code) == REG)
     emit_insn (gen_rtx (CLOBBER, VOIDmode, to));
   convert_move (gen_lowpart (word_mode, to), from, unsignedp);
   emit_unop_insn (code, to,
     gen_lowpart (word_mode, to), equiv_code);
   return;
 }


      start_sequence ();




      if (reg_overlap_mentioned_p (to, from))
 from = force_reg (from_mode, from);


      if ((8 * mode_size[(int)(from_mode)]) < ((target_flags & 0x00002000) ? 64 : 32))
 lowpart_mode = word_mode;
      else
 lowpart_mode = from_mode;

      lowfrom = convert_to_mode (lowpart_mode, from, unsignedp);

      lowpart = gen_lowpart (lowpart_mode, to);
      emit_move_insn (lowpart, lowfrom);


      if (unsignedp)
 fill_value = const0_rtx;
      else
 {

   if (1
       && insn_operand_mode[(int) CODE_FOR_slt][0] == word_mode
       && 1 == -1)
     {
       emit_cmp_insn (lowfrom, const0_rtx, NE, (rtx) 0,
        lowpart_mode, 0, 0);
       fill_value = gen_reg_rtx (word_mode);
       emit_insn (gen_slt (fill_value));
     }
   else

     {
       fill_value
  = expand_shift (RSHIFT_EXPR, lowpart_mode, lowfrom,
    size_int ((8 * mode_size[(int)(lowpart_mode)]) - 1),
    (rtx) 0, 0);
       fill_value = convert_to_mode (word_mode, fill_value, 1);
     }
 }


      for (i = (mode_size[(int)(lowpart_mode)]) / ((target_flags & 0x00002000) ? 8 : 4); i < nwords; i++)
 {
   int strchr = (((target_flags & 0x00010000) != 0) ? nwords - i - 1 : i);
   rtx subword = operand_subword (to, strchr, 1, to_mode);

   if (subword == 0)
     abort ();

   if (fill_value != subword)
     emit_move_insn (subword, fill_value);
 }

      insns = get_insns ();
      end_sequence ();

      emit_no_conflict_block (insns, to, from, (rtx) 0,
         gen_rtx (equiv_code, to_mode, copy_rtx (from)));
      return;
    }


  if ((8 * mode_size[(int)(from_mode)]) > ((target_flags & 0x00002000) ? 64 : 32)
      && (8 * mode_size[(int)(to_mode)]) <= ((target_flags & 0x00002000) ? 64 : 32))
    {
      if (!((((from)->code) == MEM
      && ! ((from)->volatil)
      && direct_load[(int) to_mode]
      && ! mode_dependent_address_p (((from)->fld[0].rtx)))
     || ((from)->code) == REG
     || ((from)->code) == SUBREG))
 from = force_reg (from_mode, from);
      convert_move (to, gen_lowpart (word_mode, from), 0);
      return;
    }


  if (to_mode == PSImode)
    {
      if (from_mode != SImode)
 from = convert_to_mode (SImode, from, unsignedp);
      abort ();
    }

  if (from_mode == PSImode)
    {
      if (to_mode != SImode)
 {
   from = convert_to_mode (SImode, from, unsignedp);
   from_mode = SImode;
 }
      else
 {







   abort ();
 }
    }

  if (to_mode == PDImode)
    {
      if (from_mode != DImode)
 from = convert_to_mode (DImode, from, unsignedp);
      abort ();
    }

  if (from_mode == PDImode)
    {
      if (to_mode != DImode)
 {
   from = convert_to_mode (DImode, from, unsignedp);
   from_mode = DImode;
 }
      else
 {







   abort ();
 }
    }





  if ((8 * mode_size[(int)(to_mode)]) < (8 * mode_size[(int)(from_mode)])
      && ((target_flags & 0x00002000) ? (((8 * mode_size[(int)(from_mode)])) <= 32 || ((8 * mode_size[(int)(to_mode)])) > 32) : 1)
                                 )
    {
      if (!((((from)->code) == MEM
      && ! ((from)->volatil)
      && direct_load[(int) to_mode]
      && ! mode_dependent_address_p (((from)->fld[0].rtx)))
     || ((from)->code) == REG
     || ((from)->code) == SUBREG))
 from = force_reg (from_mode, from);
      if (((from)->code) == REG && ((from)->fld[0].rtint) < 68
   && ! mips_hard_regno_mode_ok[ (int)(to_mode) ][ (((from)->fld[0].rtint)) ])
 from = copy_to_reg (from);
      emit_move_insn (to, gen_lowpart (to_mode, from));
      return;
    }


  if ((8 * mode_size[(int)(to_mode)]) > (8 * mode_size[(int)(from_mode)]))
    {

      if ((code = can_extend_p (to_mode, from_mode, unsignedp))
   != CODE_FOR_nothing)
 {
   emit_unop_insn (code, to, from, equiv_code);
   return;
 }
      else
 {
   n64_enum_machine_mode intermediate;


   for (intermediate = from_mode; intermediate != VOIDmode;
        intermediate = (mode_wider_mode[(int)(intermediate)]))
     if (((can_extend_p (to_mode, intermediate, unsignedp)
    != CODE_FOR_nothing)
   || ((mode_size[(int)(to_mode)]) < (mode_size[(int)(intermediate)])
       && ((target_flags & 0x00002000) ? ((intermediate) <= 32 || (to_mode) > 32) : 1)))
  && (can_extend_p (intermediate, from_mode, unsignedp)
      != CODE_FOR_nothing))
       {
  convert_move (to, convert_to_mode (intermediate, from,
         unsignedp), unsignedp);
  return;
       }


   abort ();
 }
    }



  if (from_mode == DImode && to_mode == SImode)
    {

      if (((target_flags & 0x00002000)))
 {
   emit_unop_insn (CODE_FOR_truncdisi2, to, from, UNKNOWN);
   return;
 }

      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == DImode && to_mode == HImode)
    {

      if (((target_flags & 0x00002000)))
 {
   emit_unop_insn (CODE_FOR_truncdihi2, to, from, UNKNOWN);
   return;
 }

      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == DImode && to_mode == QImode)
    {

      if (((target_flags & 0x00002000)))
 {
   emit_unop_insn (CODE_FOR_truncdiqi2, to, from, UNKNOWN);
   return;
 }

      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == SImode && to_mode == HImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == SImode && to_mode == QImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == HImode && to_mode == QImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == TImode && to_mode == DImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == TImode && to_mode == SImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == TImode && to_mode == HImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }

  if (from_mode == TImode && to_mode == QImode)
    {







      convert_move (to, force_reg (from_mode, from), unsignedp);
      return;
    }




  if ((8 * mode_size[(int)(to_mode)]) < (8 * mode_size[(int)(from_mode)]))
    {
      rtx temp = force_reg (to_mode, gen_lowpart (to_mode, from));
      emit_move_insn (to, temp);
      return;
    }


  abort ();
}
rtx
convert_to_mode(n64_enum_machine_mode mode, rtx x, int unsignedp) asm("_convert_to_mode");
rtx
convert_to_mode(n64_enum_machine_mode mode, rtx x, int unsignedp)
{
  return convert_modes (mode, VOIDmode, x, unsignedp);
}
rtx
convert_modes(n64_enum_machine_mode mode, n64_enum_machine_mode oldmode, rtx x, int unsignedp) asm("_convert_modes");
rtx
convert_modes(n64_enum_machine_mode mode, n64_enum_machine_mode oldmode, rtx x, int unsignedp)
{
  register rtx temp;




  if (((x)->code) == SUBREG && ((x)->in_struct)
      && (mode_size[(int)(((((x)->fld[0].rtx))->mode))]) >= (mode_size[(int)(mode)])
      && ((x)->unchanging) == unsignedp)
    x = gen_lowpart (mode, x);

  if (((x)->mode) != VOIDmode)
    oldmode = ((x)->mode);

  if (mode == oldmode)
    return x;







  if (unsignedp && (mode_class[(int)(mode)]) == MODE_INT
      && (8 * mode_size[(int)(mode)]) == 2 * 32
      && ((x)->code) == CONST_INT && ((x)->fld[0].rtwint) < 0)
    return immed_double_const (((x)->fld[0].rtwint), (int) 0, mode);






  if ((((x)->code) == CONST_INT
       && (8 * mode_size[(int)(mode)]) <= 32)
      || ((mode_class[(int)(mode)]) == MODE_INT
   && (mode_class[(int)(oldmode)]) == MODE_INT
   && (((x)->code) == CONST_DOUBLE
       || ((mode_size[(int)(mode)]) <= (mode_size[(int)(oldmode)])
    && ((((x)->code) == MEM && ! ((x)->volatil)
         && direct_load[(int) mode])
        || (((x)->code) == REG
     && ((target_flags & 0x00002000) ? (((8 * mode_size[(int)(((x)->mode))])) <= 32 || ((8 * mode_size[(int)(mode)])) > 32) : 1)
                                          ))))))
    {



      if (((x)->code) == CONST_INT && oldmode != VOIDmode
   && (mode_size[(int)(mode)]) > (mode_size[(int)(oldmode)]))
 {
   int val = ((x)->fld[0].rtwint);
   int width = (8 * mode_size[(int)(oldmode)]);



   val &= ((int) 1 << width) - 1;
   if (! unsignedp
       && (val & ((int) 1 << (width - 1))))
     val |= (int) (-1) << width;

   return gen_rtx (CONST_INT, VOIDmode, (int) (val));
 }

      return gen_lowpart (mode, x);
    }

  temp = gen_reg_rtx (mode);
  convert_move (temp, x, unsignedp);
  return temp;
}







static void
move_by_pieces(rtx to, rtx from, int len, int align) asm("_move_by_pieces");
static void
move_by_pieces(rtx to, rtx from, int len, int align)
{
  struct n64_tag_move_by_pieces data;
  rtx to_addr = ((to)->fld[0].rtx), from_addr = ((from)->fld[0].rtx);
  int max_size = ((target_flags & 0x00002000) ? 8 : 4) + 1;

  data.offset = 0;
  data.to_addr = to_addr;
  data.from_addr = from_addr;
  data.to = to;
  data.from = from;
  data.autinc_to
    = (((to_addr)->code) == PRE_INC || ((to_addr)->code) == PRE_DEC
       || ((to_addr)->code) == POST_INC || ((to_addr)->code) == POST_DEC);
  data.autinc_from
    = (((from_addr)->code) == PRE_INC || ((from_addr)->code) == PRE_DEC
       || ((from_addr)->code) == POST_INC
       || ((from_addr)->code) == POST_DEC);

  data.explicit_inc_from = 0;
  data.explicit_inc_to = 0;
  data.reverse
    = (((to_addr)->code) == PRE_DEC || ((to_addr)->code) == POST_DEC);
  if (data.reverse) data.offset = len;
  data.len = len;

  data.to_struct = ((to)->in_struct);
  data.from_struct = ((from)->in_struct);




  if (!(data.autinc_from && data.autinc_to)
      && move_by_pieces_ninsns (len, align) > 2)
    {
      if (!data.autinc_from && (((from_addr)->code) == LABEL_REF || ((from_addr)->code) == SYMBOL_REF || ((from_addr)->code) == CONST_INT || ((from_addr)->code) == CONST_DOUBLE || ((from_addr)->code) == CONST || ((from_addr)->code) == HIGH))
 data.from_addr = copy_addr_to_reg (from_addr);
      if (!data.autinc_to && (((to_addr)->code) == LABEL_REF || ((to_addr)->code) == SYMBOL_REF || ((to_addr)->code) == CONST_INT || ((to_addr)->code) == CONST_DOUBLE || ((to_addr)->code) == CONST || ((to_addr)->code) == HIGH))
 data.to_addr = copy_addr_to_reg (to_addr);
    }

  if (! 1
      || align > ((target_flags & 0x00002000) ? 8 : 4) || align >= 64 / 8)
    align = ((target_flags & 0x00002000) ? 8 : 4);




  while (max_size > 1)
    {
      n64_enum_machine_mode mode = VOIDmode, tmode;
      n64_enum_insn_code icode;

      for (tmode = class_narrowest_mode[(int)(MODE_INT)];
    tmode != VOIDmode; tmode = (mode_wider_mode[(int)(tmode)]))
 if ((mode_size[(int)(tmode)]) < max_size)
   mode = tmode;

      if (mode == VOIDmode)
 break;

      icode = mov_optab->handlers[(int) mode].insn_code;
      if (icode != CODE_FOR_nothing
   && align >= ((64 / 8) < ((mode_size[(int)(mode)])) ? (64 / 8) : ((mode_size[(int)(mode)])))
                           )
 move_by_pieces_1 ((*insn_gen_function[(int) (icode)]), mode, &data);

      max_size = (mode_size[(int)(mode)]);
    }


  if (data.len != 0)
    abort ();
}




static int
move_by_pieces_ninsns(unsigned int l, int align) asm("_move_by_pieces_ninsns");
static int
move_by_pieces_ninsns(unsigned int l, int align)
{
  register int n_insns = 0;
  int max_size = ((target_flags & 0x00002000) ? 8 : 4) + 1;

  if (! 1
      || align > ((target_flags & 0x00002000) ? 8 : 4) || align >= 64 / 8)
    align = ((target_flags & 0x00002000) ? 8 : 4);

  while (max_size > 1)
    {
      n64_enum_machine_mode mode = VOIDmode, tmode;
      n64_enum_insn_code icode;

      for (tmode = class_narrowest_mode[(int)(MODE_INT)];
    tmode != VOIDmode; tmode = (mode_wider_mode[(int)(tmode)]))
 if ((mode_size[(int)(tmode)]) < max_size)
   mode = tmode;

      if (mode == VOIDmode)
 break;

      icode = mov_optab->handlers[(int) mode].insn_code;
      if (icode != CODE_FOR_nothing
   && align >= ((64 / 8) < ((mode_size[(int)(mode)])) ? (64 / 8) : ((mode_size[(int)(mode)])))
                           )
 n_insns += l / (mode_size[(int)(mode)]), l %= (mode_size[(int)(mode)]);

      max_size = (mode_size[(int)(mode)]);
    }

  return n_insns;
}





static void
move_by_pieces_1(rtx (*genfun) (...), n64_enum_machine_mode mode, struct n64_tag_move_by_pieces *data) asm("_move_by_pieces_1");
static void
move_by_pieces_1(rtx (*genfun) (...), n64_enum_machine_mode mode, struct n64_tag_move_by_pieces *data)
{
  register int size = (mode_size[(int)(mode)]);
  register rtx to1, from1;

  while (data->len >= size)
    {
      if (data->reverse) data->offset -= size;

      to1 = (data->autinc_to
      ? gen_rtx (MEM, mode, data->to_addr)
      : change_address (data->to, mode,
          plus_constant_wide (data->to_addr, (int) (data->offset))));
      ((to1)->in_struct) = data->to_struct;
      from1 =
 (data->autinc_from
  ? gen_rtx (MEM, mode, data->from_addr)
  : change_address (data->from, mode,
      plus_constant_wide (data->from_addr, (int) (data->offset))));
      ((from1)->in_struct) = data->from_struct;
      emit_insn ((*genfun) (to1, from1));







      if (! data->reverse) data->offset += size;

      data->len -= size;
    }
}
void
emit_block_move(rtx x, rtx y, rtx size, int align) asm("_emit_block_move");
void
emit_block_move(rtx x, rtx y, rtx size, int align)
{
  if (((x)->mode) != BLKmode)
    abort ();

  if (((y)->mode) != BLKmode)
    abort ();

  x = protect_from_queue (x, 1);
  y = protect_from_queue (y, 0);
  size = protect_from_queue (size, 0);

  if (((x)->code) != MEM)
    abort ();
  if (((y)->code) != MEM)
    abort ();
  if (size == 0)
    abort ();

  if (((size)->code) == CONST_INT
      && (move_by_pieces_ninsns (((size)->fld[0].rtwint), align) < 2))
    move_by_pieces (x, y, ((size)->fld[0].rtwint), align);
  else
    {




      rtx opalign = gen_rtx (CONST_INT, VOIDmode, (int) (align));
      n64_enum_machine_mode mode;

      for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
    mode = (mode_wider_mode[(int)(mode)]))
 {
   n64_enum_insn_code code = movstr_optab[(int) mode];

   if (code != CODE_FOR_nothing




       && ((((size)->code) == CONST_INT
     && ((unsigned int) ((size)->fld[0].rtwint)
         <= (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))))
    || (8 * mode_size[(int)(mode)]) >= ((target_flags & 0x00002000) ? 64 : 32))
       && (insn_operand_predicate[(int) code][0] == 0
    || (*insn_operand_predicate[(int) code][0]) (x, BLKmode))
       && (insn_operand_predicate[(int) code][1] == 0
    || (*insn_operand_predicate[(int) code][1]) (y, BLKmode))
       && (insn_operand_predicate[(int) code][3] == 0
    || (*insn_operand_predicate[(int) code][3]) (opalign,
              VOIDmode)))
     {
       rtx op2;
       rtx last = get_last_insn ();
       rtx pat;

       op2 = convert_to_mode (mode, size, 1);
       if (insn_operand_predicate[(int) code][2] != 0
    && ! (*insn_operand_predicate[(int) code][2]) (op2, mode))
  op2 = copy_to_mode_reg (mode, op2);

       pat = (*insn_gen_function[(int) ((int) code)]) (x, y, op2, opalign);
       if (pat)
  {
    emit_insn (pat);
    return;
  }
       else
  delete_insns_since (last);
     }
 }


      emit_library_call (memcpy_libfunc, 0,
    VOIDmode, 3, ((x)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
    ((y)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
    convert_to_mode (((sizetype)->type.mode), size,
       ((sizetype)->common.unsigned_flag)),
    ((sizetype)->type.mode));
    }
}




void
move_block_to_reg(int regno, rtx x, int nregs, n64_enum_machine_mode mode) asm("_move_block_to_reg");
void
move_block_to_reg(int regno, rtx x, int nregs, n64_enum_machine_mode mode)
{
  int i;
  rtx pat, last;

  if (nregs == 0)
    return;

  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH) && ! ((((x)->code) != CONST_DOUBLE || mips_const_double_ok (x, ((x)->mode))) && ! (((x)->code) == CONST && 0)))
    x = validize_mem (force_const_mem (mode, x));
  for (i = 0; i < nregs; i++)
    emit_move_insn (gen_rtx (REG, word_mode, regno + i),
      operand_subword_force (x, i, mode));
}






void
move_block_from_reg(int regno, rtx x, int nregs, int size) asm("_move_block_from_reg");
void
move_block_from_reg(int regno, rtx x, int nregs, int size)
{
  int i;
  rtx pat, last;



  if (size < ((target_flags & 0x00002000) ? 8 : 4) && ((target_flags & 0x00010000) != 0))
    {
      rtx tem = operand_subword (x, 0, 1, BLKmode);
      rtx shift;

      if (tem == 0)
 abort ();

      shift = expand_shift (LSHIFT_EXPR, word_mode,
       gen_rtx (REG, word_mode, regno),
       build_int_2_wide ((int) ((((target_flags & 0x00002000) ? 8 : 4) - size) * 8), (int) (0))
                         , (rtx) 0, 0);
      emit_move_insn (tem, shift);
      return;
    }
  for (i = 0; i < nregs; i++)
    {
      rtx tem = operand_subword (x, i, 1, BLKmode);

      if (tem == 0)
 abort ();

      emit_move_insn (tem, gen_rtx (REG, word_mode, regno + i));
    }
}




void
use_reg(rtx *call_fusage, rtx reg) asm("_use_reg");
void
use_reg(rtx *call_fusage, rtx reg)
{
  if (((reg)->code) != REG
      || ((reg)->fld[0].rtint) >= 68)
    abort();

  *call_fusage
    = gen_rtx (EXPR_LIST, VOIDmode,
        gen_rtx (USE, VOIDmode, reg), *call_fusage);
}




void
use_regs(rtx *call_fusage, int regno, int nregs) asm("_use_regs");
void
use_regs(rtx *call_fusage, int regno, int nregs)
{
  int i;

  if (regno + nregs > 68)
    abort ();

  for (i = 0; i < nregs; i++)
    use_reg (call_fusage, gen_rtx (REG, reg_raw_mode[regno + i], regno + i));
}




void
clear_storage(rtx object, rtx size) asm("_clear_storage");
void
clear_storage(rtx object, rtx size)
{
  if (((object)->mode) == BLKmode)
    {

      emit_library_call (memset_libfunc, 0,
    VOIDmode, 3,
    ((object)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode), const0_rtx, ptr_mode,
    convert_to_mode (((sizetype)->type.mode),
       size, ((sizetype)->common.unsigned_flag)),
    ((sizetype)->type.mode));
    }
  else
    emit_move_insn (object, const0_rtx);
}
rtx
emit_move_insn(rtx x, rtx y) asm("_emit_move_insn");
rtx
emit_move_insn(rtx x, rtx y)
{
  n64_enum_machine_mode mode = ((x)->mode);

  x = protect_from_queue (x, 1);
  y = protect_from_queue (y, 0);

  if (mode == BLKmode || (((y)->mode) != mode && ((y)->mode) != VOIDmode))
    abort ();

  if ((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH) && ! ((((y)->code) != CONST_DOUBLE || mips_const_double_ok (y, ((y)->mode))) && ! (((y)->code) == CONST && 0)))
    y = force_const_mem (mode, y);



  if (((x)->code) == MEM
      && ((! memory_address_p (((x)->mode), ((x)->fld[0].rtx))
    && ! push_operand (x, ((x)->mode)))
   || (flag_force_addr
       && ((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == HIGH || (((((x)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((x)->fld[0].rtx))) && ! 0)) && (!0 || !0)))))
    x = change_address (x, VOIDmode, ((x)->fld[0].rtx));

  if (((y)->code) == MEM
      && (! memory_address_p (((y)->mode), ((y)->fld[0].rtx))
   || (flag_force_addr
       && ((((((y)->fld[0].rtx))->code) == LABEL_REF || ((((y)->fld[0].rtx))->code) == SYMBOL_REF || ((((y)->fld[0].rtx))->code) == CONST_INT || ((((y)->fld[0].rtx))->code) == HIGH || (((((y)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((y)->fld[0].rtx))) && ! 0)) && (!0 || !0)))))
    y = change_address (y, VOIDmode, ((y)->fld[0].rtx));

  if (mode == BLKmode)
    abort ();

  return emit_move_insn_1 (x, y);
}





rtx
emit_move_insn_1(rtx x, rtx y) asm("_emit_move_insn_1");
rtx
emit_move_insn_1(rtx x, rtx y)
{
  n64_enum_machine_mode mode = ((x)->mode);
  n64_enum_machine_mode submode;
  n64_enum_mode_class cxx_class = (mode_class[(int)(mode)]);
  int i;

  if (mov_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
    return
      emit_insn ((*insn_gen_function[(int) (mov_optab->handlers[(int) mode].insn_code)]) (x, y));


  else if ((cxx_class == MODE_COMPLEX_FLOAT || cxx_class == MODE_COMPLEX_INT)
    && BLKmode != (submode = mode_for_size (((mode_unit_size[(int)(mode)])
          * 8),
         (cxx_class == MODE_COMPLEX_INT
          ? MODE_INT : MODE_FLOAT),
         0))
    && (mov_optab->handlers[(int) submode].insn_code
        != CODE_FOR_nothing))
    {

      int stack = push_operand (x, ((x)->mode));
      rtx insns;






      if (stack)
 {



   emit_insn ((*insn_gen_function[(int) (mov_optab->handlers[(int) submode].insn_code)])
       (gen_rtx (MEM, submode, (((x)->fld[0].rtx))),
        gen_imagpart (submode, y)));
   emit_insn ((*insn_gen_function[(int) (mov_optab->handlers[(int) submode].insn_code)])
       (gen_rtx (MEM, submode, (((x)->fld[0].rtx))),
        gen_realpart (submode, y)));
 }
      else
 {
   emit_insn ((*insn_gen_function[(int) (mov_optab->handlers[(int) submode].insn_code)])
       (gen_realpart (submode, x), gen_realpart (submode, y)));
   emit_insn ((*insn_gen_function[(int) (mov_optab->handlers[(int) submode].insn_code)])
       (gen_imagpart (submode, x), gen_imagpart (submode, y)));
 }

      return get_last_insn ();
    }




  else if ((mode_size[(int)(mode)]) > ((target_flags & 0x00002000) ? 8 : 4))
    {
      rtx last_insn = 0;
      rtx insns;
      emit_insn (gen_rtx (CLOBBER, VOIDmode, x));

      for (i = 0;
    i < ((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4);
    i++)
 {
   rtx xpart = operand_subword (x, i, 1, mode);
   rtx ypart = operand_subword (y, i, 1, mode);




   if (ypart == 0 && (((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH))
     {
       y = force_const_mem (mode, y);
       ypart = operand_subword (y, i, 1, mode);
     }
   else if (ypart == 0)
     ypart = operand_subword_force (y, i, mode);

   if (xpart == 0 || ypart == 0)
     abort ();

   last_insn = emit_move_insn (xpart, ypart);
 }

      return last_insn;
    }
  else
    abort ();
}
rtx
push_block(rtx size, int extra, int below) asm("_push_block");
rtx
push_block(rtx size, int extra, int below)
{
  register rtx temp;

  size = convert_modes (((target_flags & 0x00000002) ? DImode : SImode), ptr_mode, size, 1);
  if ((((size)->code) == LABEL_REF || ((size)->code) == SYMBOL_REF || ((size)->code) == CONST_INT || ((size)->code) == CONST_DOUBLE || ((size)->code) == CONST || ((size)->code) == HIGH))
    anti_adjust_stack (plus_constant_wide (size, (int) (extra)));
  else if (((size)->code) == REG && extra == 0)
    anti_adjust_stack (size);
  else
    {
      rtx temp = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), size);
      if (extra != 0)
 temp = expand_binop (((target_flags & 0x00000002) ? DImode : SImode), add_optab, temp, gen_rtx (CONST_INT, VOIDmode, (int) (extra)),
        temp, 0, OPTAB_LIB_WIDEN);
      anti_adjust_stack (temp);
    }


  temp = virtual_outgoing_args_rtx;
  if (extra != 0 && below)
    temp = plus_constant_wide (temp, (int) (extra));
  return memory_address (class_narrowest_mode[(int)(MODE_INT)], temp);
}

rtx
gen_push_operand(void) asm("_gen_push_operand");
rtx
gen_push_operand(void)
{
  return gen_rtx (PRE_DEC, ((target_flags & 0x00000002) ? DImode : SImode), stack_pointer_rtx);
}
void
emit_push_insn(register rtx x, n64_enum_machine_mode mode, tree type, rtx size, int align, int partial, rtx reg, int extra, rtx args_addr, rtx args_so_far) asm("_emit_push_insn");
void
emit_push_insn(register rtx x, n64_enum_machine_mode mode, tree type, rtx size, int align, int partial, rtx reg, int extra, rtx args_addr, rtx args_so_far)
{
  rtx xinner;
  n64_enum_direction stack_direction

    = downward;







  n64_enum_direction where_pad = (! ((target_flags & 0x00010000) != 0) ? upward : (((mode) == BLKmode ? ((type) && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST && int_size_in_bytes (type) < (((target_flags & 0x00002000) ? 64 : 32) / 8)) : (8 * mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 64 : 32)) ? downward : upward));


  if (PRE_DEC == POST_INC || PRE_DEC == POST_DEC)
    if (where_pad != none)
      where_pad = (where_pad == downward ? upward : downward);

  xinner = x = protect_from_queue (x, 0);

  if (mode == BLKmode)
    {


      register rtx temp;
      int used = partial * ((target_flags & 0x00002000) ? 8 : 4);
      int offset = used % (((target_flags & 0x00002000) ? 64 : 32) / 8);
      int skip;

      if (size == 0)
 abort ();

      used -= offset;




      if (partial != 0)
 xinner = change_address (xinner, BLKmode,
     plus_constant_wide (((xinner)->fld[0].rtx), (int) (used)));
      skip = used;
 {




   if (partial != 0)
     {
       if (((size)->code) == CONST_INT)
  size = gen_rtx (CONST_INT, VOIDmode, (int) (((size)->fld[0].rtwint) - used));
       else
  size = expand_binop (((size)->mode), sub_optab, size,
         gen_rtx (CONST_INT, VOIDmode, (int) (used)), (rtx) 0, 0,
         OPTAB_LIB_WIDEN);
     }




   if (! args_addr)
     {
       temp = push_block (size, extra, where_pad == downward);
       extra = 0;
     }
   else if (((args_so_far)->code) == CONST_INT)
     temp = memory_address (BLKmode,
       plus_constant_wide (args_addr, (int) (skip + ((args_so_far)->fld[0].rtwint)))
                                    );
   else
     temp = memory_address (BLKmode,
       plus_constant_wide (gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), args_addr, args_so_far), (int) (skip))

             );


   if (((size)->code) == CONST_INT
       && (move_by_pieces_ninsns ((unsigned) ((size)->fld[0].rtwint), align)
    < 2))
     {
       move_by_pieces (gen_rtx (MEM, BLKmode, temp), xinner,
         ((size)->fld[0].rtwint), align);
       goto ret;
     }
   if (1)
     {
       rtx pat = gen_movstrsi (gen_rtx (MEM, BLKmode, temp),
          xinner, size, gen_rtx (CONST_INT, VOIDmode, (int) (align)));
       if (pat != 0)
  {
    emit_insn (pat);
    goto ret;
  }
     }
   (inhibit_defer_pop += 1);

   emit_library_call (memcpy_libfunc, 0,
        VOIDmode, 3, temp, ((target_flags & 0x00000002) ? DImode : SImode), ((xinner)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
        convert_to_mode (((sizetype)->type.mode),
           size, ((sizetype)->common.unsigned_flag)),
        ((sizetype)->type.mode));







   (inhibit_defer_pop -= 1);
 }
    }
  else if (partial > 0)
    {


      int size = (mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 8 : 4);
      int i;
      int not_stack;


      int offset = partial % (((target_flags & 0x00002000) ? 64 : 32) / ((target_flags & 0x00002000) ? 64 : 32));
      int args_offset = ((args_so_far)->fld[0].rtwint);
      int skip;




      if (extra && args_addr == 0
   && where_pad != none && where_pad != stack_direction)
 anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (extra)));




      if (args_addr == 0)
 offset = 0;



      not_stack = partial - offset;
      skip = not_stack;


      if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH) && ! ((((x)->code) != CONST_DOUBLE || mips_const_double_ok (x, ((x)->mode))) && ! (((x)->code) == CONST && 0)))
 x = validize_mem (force_const_mem (mode, x));



      if ((((x)->code) == REG && ((x)->fld[0].rtint) < 68
    && (mode_class[(int)(((x)->mode))]) != MODE_INT))
 x = copy_to_reg (x);





      for (i = not_stack; i < size; i++)



 if (i >= not_stack + offset)
   emit_push_insn (operand_subword_force (x, i, mode),
     word_mode, (tree) 
               ((void *)0)
                        , (rtx) 0, align, 0, (rtx) 0,
     0, args_addr,
     gen_rtx (CONST_INT, VOIDmode, (int) (args_offset + ((i - not_stack + skip) * ((target_flags & 0x00002000) ? 8 : 4))))
                          );
    }
  else
    {
      rtx addr;




      if (extra && args_addr == 0
   && where_pad != none && where_pad != stack_direction)
 anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (extra)));






 if (((args_so_far)->code) == CONST_INT)
   addr
     = memory_address (mode,
         plus_constant_wide (args_addr, (int) (((args_so_far)->fld[0].rtwint))));
      else
 addr = memory_address (mode, gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), args_addr,
           args_so_far));

      emit_move_insn (gen_rtx (MEM, mode, addr), x);
    }

 ret:



  if (partial > 0 && reg != 0)
    move_block_to_reg (((reg)->fld[0].rtint), x, partial, mode);

  if (extra && args_addr == 0 && where_pad == stack_direction)
    anti_adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (extra)));
}
rtx
expand_assignment(tree to, tree from, int want_value, int suggest_reg) asm("_expand_assignment");
rtx
expand_assignment(tree to, tree from, int want_value, int suggest_reg)
{
  register rtx to_rtx = 0;
  rtx result;



  if (((n64_enum_tree_code) (to)->common.code) == ERROR_MARK)
    {
      result = expand_expr (from, (rtx) 0, VOIDmode, 0);
      return want_value ? result : (rtx) 0;
    }

  if (output_bytecode)
    {
      tree dest_innermost;

      bc_expand_expr (from);
      bc_emit_instruction (duplicate);

      dest_innermost = bc_expand_address (to);




      bc_store_memory (((to)->common.type), dest_innermost);
      return 
            ((void *)0)
                ;
    }







  if (((n64_enum_tree_code) (to)->common.code) == COMPONENT_REF
      || ((n64_enum_tree_code) (to)->common.code) == BIT_FIELD_REF
      || (((n64_enum_tree_code) (to)->common.code) == ARRAY_REF
   && ((((n64_enum_tree_code) (((to)->exp.operands[1]))->common.code) == INTEGER_CST
        && ((n64_enum_tree_code) (((((to)->common.type))->type.size))->common.code) == INTEGER_CST)
       || (1 && get_inner_unaligned_p (to)))))
    {
      n64_enum_machine_mode mode1;
      int bitsize;
      int bitpos;
      tree offset;
      int unsignedp;
      int volatilep = 0;
      tree tem;
      int alignment;

      push_temp_slots ();
      tem = get_inner_reference (to, &bitsize, &bitpos, &offset,
          &mode1, &unsignedp, &volatilep);




      if (mode1 == VOIDmode && want_value)
 tem = stabilize_reference (tem);

      alignment = ((((tem)->common.type))->type.align) / 8;
      to_rtx = expand_expr (tem, (rtx) 0, VOIDmode, 0);
      if (offset != 0)
 {
   rtx offset_rtx = expand_expr (offset, (rtx) 0, VOIDmode, 0);

   if (((to_rtx)->code) != MEM)
     abort ();
   to_rtx = change_address (to_rtx, VOIDmode,
       gen_rtx (PLUS, ptr_mode, ((to_rtx)->fld[0].rtx),
         force_reg (ptr_mode, offset_rtx)));




   if (((n64_enum_tree_code) (to)->common.code) == COMPONENT_REF
       || ((n64_enum_tree_code) (to)->common.code) == BIT_FIELD_REF)
     alignment
       = ((((((to)->exp.operands[0]))->common.type))->type.align) / 8;
 }
      if (volatilep)
 {
   if (((to_rtx)->code) == MEM)
     {



       if (offset == 0)
  to_rtx = change_address (to_rtx, VOIDmode, ((to_rtx)->fld[0].rtx));
       ((to_rtx)->volatil) = 1;
     }






 }

      result = store_field (to_rtx, bitsize, bitpos, mode1, from,
       (want_value

        ? (n64_enum_machine_mode) ((((to)->common.type))->type.mode)
        : VOIDmode),
       unsignedp,

       alignment,
       int_size_in_bytes (((tem)->common.type)));
      preserve_temp_slots (result);
      free_temp_slots ();
      pop_temp_slots ();



      return (want_value ? convert_modes (((((to)->common.type))->type.mode),
       ((((from)->common.type))->type.mode),
       result,
       ((((to)->common.type))->common.unsigned_flag))
       : (rtx) 0);
    }
  if (((n64_enum_tree_code) (from)->common.code) == CALL_EXPR && ! aggregate_value_p (from)
      && ! (((n64_enum_tree_code) (to)->common.code) == VAR_DECL && ((((to)->decl.rtl))->code) == REG))
    {
      rtx value;

      push_temp_slots ();
      value = expand_expr (from, (rtx) 0, VOIDmode, 0);
      if (to_rtx == 0)
 to_rtx = expand_expr (to, (rtx) 0, VOIDmode, 0);

      if (((to_rtx)->mode) == BLKmode)
 {
   int align = ((((((from)->common.type))->type.align)) < (((target_flags & 0x00002000) ? 64 : 32)) ? (((((from)->common.type))->type.align)) : (((target_flags & 0x00002000) ? 64 : 32)));
   emit_block_move (to_rtx, value, expr_size (from), align);
 }
      else
 emit_move_insn (to_rtx, value);
      preserve_temp_slots (to_rtx);
      free_temp_slots ();
      pop_temp_slots ();
      return want_value ? to_rtx : (rtx) 0;
    }




  if (to_rtx == 0)
    to_rtx = expand_expr (to, (rtx) 0, VOIDmode, 0);


  if (((n64_enum_tree_code) (to)->common.code) == RESULT_DECL && ((to_rtx)->code) == REG)
    {
      rtx temp;

      push_temp_slots ();
      temp = expand_expr (from, 0, ((to_rtx)->mode), 0);
      emit_move_insn (to_rtx, temp);
      preserve_temp_slots (to_rtx);
      free_temp_slots ();
      pop_temp_slots ();
      return want_value ? to_rtx : (rtx) 0;
    }




  if (((n64_enum_tree_code) (to)->common.code) == RESULT_DECL && ((n64_enum_tree_code) (from)->common.code) == INDIRECT_REF
      && current_function_returns_struct
      && !current_function_returns_pcc_struct)
    {
      rtx from_rtx, size;

      push_temp_slots ();
      size = expr_size (from);
      from_rtx = expand_expr (from, (rtx) 0, VOIDmode, 0);


      emit_library_call (memcpy_libfunc, 0,
    VOIDmode, 3, ((to_rtx)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
    ((from_rtx)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
    convert_to_mode (((sizetype)->type.mode),
       size, ((sizetype)->common.unsigned_flag)),
    ((sizetype)->type.mode));
      preserve_temp_slots (to_rtx);
      free_temp_slots ();
      pop_temp_slots ();
      return want_value ? to_rtx : (rtx) 0;
    }



  push_temp_slots ();
  result = store_expr (from, to_rtx, want_value);
  preserve_temp_slots (result);
  free_temp_slots ();
  pop_temp_slots ();
  return want_value ? result : (rtx) 0;
}
rtx
store_expr(register tree exp, register rtx target, int want_value) asm("_store_expr");
rtx
store_expr(register tree exp, register rtx target, int want_value)
{
  register rtx temp;
  int dont_return_target = 0;

  if (((n64_enum_tree_code) (exp)->common.code) == COMPOUND_EXPR)
    {


      expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode, 0);
      emit_queue ();
      return store_expr (((exp)->exp.operands[1]), target, want_value);
    }
  else if (((n64_enum_tree_code) (exp)->common.code) == COND_EXPR && ((target)->mode) == BLKmode)
    {





      rtx lab1 = gen_label_rtx (), lab2 = gen_label_rtx ();

      emit_queue ();
      target = protect_from_queue (target, 1);

      do_pending_stack_adjust ();
      (inhibit_defer_pop += 1);
      jumpifnot (((exp)->exp.operands[0]), lab1);
      store_expr (((exp)->exp.operands[1]), target, 0);
      emit_queue ();
      emit_jump_insn (gen_jump (lab2));
      emit_barrier ();
      emit_label (lab1);
      store_expr (((exp)->exp.operands[2]), target, 0);
      emit_queue ();
      emit_label (lab2);
      (inhibit_defer_pop -= 1);
      return want_value ? target : (rtx) 0;
    }
  else if (want_value && ((target)->code) == MEM && ! ((target)->volatil)
    && ((target)->mode) != BLKmode)






    {
      temp = expand_expr (exp, cse_not_expected ? (rtx) 0 : target,
     ((target)->mode), 0);
      if (((temp)->mode) != BLKmode && ((temp)->mode) != VOIDmode)
 temp = copy_to_reg (temp);
      dont_return_target = 1;
    }
  else if (queued_subexp_p (target))


    {
      if (((target)->mode) != BLKmode && ((target)->mode) != VOIDmode)
 {

   temp = gen_reg_rtx (((target)->mode));
   temp = expand_expr (exp, temp, ((target)->mode), 0);
 }
      else
 temp = expand_expr (exp, (rtx) 0, ((target)->mode), 0);




      if (! ((target)->volatil) && want_value)
 dont_return_target = 1;
    }
  else if (((target)->code) == SUBREG && ((target)->in_struct))




    {




      if (! want_value)
 {
   if (((((exp)->common.type))->common.unsigned_flag)
       != ((target)->unchanging))
     exp
       = convert
  (signed_or_unsigned_type (((target)->unchanging),
       ((exp)->common.type)),
   exp);

   exp = convert (type_for_mode (((((target)->fld[0].rtx))->mode),
     ((target)->unchanging)),
    exp);
 }

      temp = expand_expr (exp, (rtx) 0, VOIDmode, 0);




      if (((temp)->code) == MEM && want_value
   && (((temp)->volatil)
       || reg_mentioned_p (((target)->fld[0].rtx), ((temp)->fld[0].rtx))))
 temp = copy_to_reg (temp);



      if ((((temp)->code) == LABEL_REF || ((temp)->code) == SYMBOL_REF || ((temp)->code) == CONST_INT || ((temp)->code) == CONST_DOUBLE || ((temp)->code) == CONST || ((temp)->code) == HIGH) && ((temp)->mode) == VOIDmode)
 temp = convert_modes (((((target)->fld[0].rtx))->mode),
         ((((exp)->common.type))->type.mode), temp,
         ((target)->unchanging));

      convert_move (((target)->fld[0].rtx), temp,
      ((target)->unchanging));
      return want_value ? temp : (rtx) 0;
    }
  else
    {
      temp = expand_expr (exp, target, ((target)->mode), 0);







      if (!(target && ((target)->code) == REG
     && ((target)->fld[0].rtint) < 68)
   && !(((target)->code) == MEM && ((target)->volatil))
   && temp != target
   && ((((temp)->code) == LABEL_REF || ((temp)->code) == SYMBOL_REF || ((temp)->code) == CONST_INT || ((temp)->code) == CONST_DOUBLE || ((temp)->code) == CONST || ((temp)->code) == HIGH) || want_value))
 dont_return_target = 1;
    }





  if ((((temp)->code) == LABEL_REF || ((temp)->code) == SYMBOL_REF || ((temp)->code) == CONST_INT || ((temp)->code) == CONST_DOUBLE || ((temp)->code) == CONST || ((temp)->code) == HIGH) && ((temp)->mode) == VOIDmode
      && ((n64_enum_tree_code) (exp)->common.code) != ERROR_MARK
      && ((target)->mode) != ((((exp)->common.type))->type.mode))
    temp = convert_modes (((target)->mode), ((((exp)->common.type))->type.mode),
     temp, ((((exp)->common.type))->common.unsigned_flag));




  if (temp != target && ((n64_enum_tree_code) (exp)->common.code) != ERROR_MARK)
    {
      target = protect_from_queue (target, 1);
      if (((temp)->mode) != ((target)->mode)
   && ((temp)->mode) != VOIDmode)
 {
   int unsignedp = ((((exp)->common.type))->common.unsigned_flag);
   if (dont_return_target)
     {



       temp = convert_to_mode (((target)->mode), temp, unsignedp);
       emit_move_insn (target, temp);
     }
   else
     convert_move (target, temp, unsignedp);
 }

      else if (((temp)->mode) == BLKmode && ((n64_enum_tree_code) (exp)->common.code) == STRING_CST)
 {



   rtx size;
   rtx addr;



   size = expr_size (exp);
   if (((size)->code) == CONST_INT
       && ((size)->fld[0].rtwint) < ((exp)->string.length))
     emit_block_move (target, temp, size,
        ((((exp)->common.type))->type.align) / 8);
   else
     {

       tree copy_size
  = size_binop (MIN_EXPR,
         make_tree (sizetype, size),
         convert (sizetype,
           build_int_2_wide ((int) (((exp)->string.length)), (int) (0))));
       rtx copy_size_rtx = expand_expr (copy_size, (rtx) 0,
            VOIDmode, 0);
       rtx label = 0;


       emit_block_move (target, temp, copy_size_rtx,
          ((((exp)->common.type))->type.align) / 8);




       addr = ((target)->fld[0].rtx);
       addr = convert_modes (ptr_mode, ((target_flags & 0x00000002) ? DImode : SImode), addr, 1);

       if (((copy_size_rtx)->code) == CONST_INT)
  {
    addr = plus_constant_wide (addr, (int) (((exp)->string.length)));
    size = plus_constant_wide (size, (int) (- ((exp)->string.length)));
  }
       else
  {
    addr = force_reg (ptr_mode, addr);
    addr = expand_binop (ptr_mode, add_optab, addr,
           copy_size_rtx, (rtx) 0, 0,
           OPTAB_LIB_WIDEN);

    size = expand_binop (ptr_mode, sub_optab, size,
           copy_size_rtx, (rtx) 0, 0,
           OPTAB_LIB_WIDEN);

    emit_cmp_insn (size, const0_rtx, LT, (rtx) 0,
     ((size)->mode), 0, 0);
    label = gen_label_rtx ();
    emit_jump_insn (gen_blt (label));
  }

       if (size != const0_rtx)
  {

    emit_library_call (memset_libfunc, 0, VOIDmode, 3, addr,
         ((target_flags & 0x00000002) ? DImode : SImode), const0_rtx, ((target_flags & 0x00000002) ? DImode : SImode), size, ptr_mode);




  }

       if (label)
  emit_label (label);
     }
 }
      else if (((temp)->mode) == BLKmode)
 emit_block_move (target, temp, expr_size (exp),
    ((((exp)->common.type))->type.align) / 8);
      else
 emit_move_insn (target, temp);
    }


  if (! want_value)
    return (rtx) 0;



  else if (dont_return_target && ((temp)->code) != MEM)
    return temp;


  else if (want_value && ((target)->mode) != BLKmode
    && ! (((target)->code) == REG
   && ((target)->fld[0].rtint) < 68))
    return copy_to_reg (target);

  else
    return target;
}




static void
store_constructor(tree exp, rtx target) asm("_store_constructor");
static void
store_constructor(tree exp, rtx target)
{
  tree type = ((exp)->common.type);
  if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE)
    {
      register tree elt;


      if (((n64_enum_tree_code) (type)->common.code) == UNION_TYPE
   || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE)
 emit_insn (gen_rtx (CLOBBER, VOIDmode, target));





      else if (((target)->code) == REG && ((exp)->common.static_flag)
        && (mode_size[(int)(((target)->mode))]) <= ((target_flags & 0x00002000) ? 8 : 4))
 emit_move_insn (target, const0_rtx);



      else if (list_length (((exp)->exp.operands[1]))
        != list_length (((type)->type.values)))
 clear_storage (target, expr_size (exp));
      else

 emit_insn (gen_rtx (CLOBBER, VOIDmode, target));




      for (elt = ((exp)->exp.operands[1]); elt; elt = ((elt)->common.chain))
 {
   register tree field = ((elt)->list.purpose);
   register n64_enum_machine_mode mode;
   int bitsize;
   int bitpos = 0;
   int unsignedp;
   tree pos, constant = 0, offset = 0;
   rtx to_rtx = target;




   if (field == 0)
     continue;

   bitsize = ((((field)->decl.size))->int_cst.int_cst_low);
   unsignedp = ((field)->common.unsigned_flag);
   mode = ((field)->decl.mode);
   if (((field)->decl.bit_field_flag))
     mode = VOIDmode;

   pos = ((field)->decl.arguments);
   if (((n64_enum_tree_code) (pos)->common.code) == INTEGER_CST)
     constant = pos;
   else if (((n64_enum_tree_code) (pos)->common.code) == PLUS_EXPR
     && ((n64_enum_tree_code) (((pos)->exp.operands[1]))->common.code) == INTEGER_CST)
     constant = ((pos)->exp.operands[1]), offset = ((pos)->exp.operands[0]);
   else
     offset = pos;

   if (constant)
     bitpos = ((constant)->int_cst.int_cst_low);

   if (offset)
     {
       rtx offset_rtx;

       if (contains_placeholder_p (offset))
  offset = build (WITH_RECORD_EXPR, sizetype,
    offset, exp);

       offset = size_binop (FLOOR_DIV_EXPR, offset,
       size_int (8));

       offset_rtx = expand_expr (offset, (rtx) 0, VOIDmode, 0);
       if (((to_rtx)->code) != MEM)
  abort ();

       to_rtx
  = change_address (to_rtx, VOIDmode,
      gen_rtx (PLUS, ptr_mode, ((to_rtx)->fld[0].rtx),
        force_reg (ptr_mode, offset_rtx)));
     }

   store_field (to_rtx, bitsize, bitpos, mode, ((elt)->list.value),


         VOIDmode, 0,
         ((type)->type.align) / 8,
         int_size_in_bytes (type));
 }
    }
  else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
      register tree elt;
      register int i;
      tree domain = ((type)->type.values);
      int minelt = ((((domain)->type.minval))->int_cst.int_cst_low);
      int maxelt = ((((domain)->type.maxval))->int_cst.int_cst_low);
      tree elttype = ((type)->common.type);





      if (list_length (((exp)->exp.operands[1])) < maxelt - minelt + 1
   || (((target)->code) == REG && ((exp)->common.static_flag)))
 clear_storage (target, expr_size (exp));
      else

 emit_insn (gen_rtx (CLOBBER, VOIDmode, target));




      for (elt = ((exp)->exp.operands[1]), i = 0;
    elt;
    elt = ((elt)->common.chain), i++)
 {
   register n64_enum_machine_mode mode;
   int bitsize;
   int bitpos;
   int unsignedp;
   tree strchr = ((elt)->list.purpose);
   rtx xtarget = target;

   mode = ((elttype)->type.mode);
   bitsize = (8 * mode_size[(int)(mode)]);
   unsignedp = ((elttype)->common.unsigned_flag);

   if ((strchr != 0 && ((n64_enum_tree_code) (strchr)->common.code) != INTEGER_CST)
       || ((n64_enum_tree_code) (((elttype)->type.size))->common.code) != INTEGER_CST)
     {
       rtx pos_rtx, addr, xtarget;
       tree position;

       if (strchr == 0)
  strchr = size_int (i);

       position = size_binop (EXACT_DIV_EXPR, ((elttype)->type.size),
         size_int (8));
       position = size_binop (MULT_EXPR, strchr, position);
       pos_rtx = expand_expr (position, 0, VOIDmode, 0);
       addr = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), ((target)->fld[0].rtx), pos_rtx);
       xtarget = change_address (target, mode, addr);
       store_expr (((elt)->list.value), xtarget, 0);
     }
   else
     {
       if (strchr != 0)
  bitpos = ((((strchr)->int_cst.int_cst_low) - minelt)
     * ((((elttype)->type.size))->int_cst.int_cst_low));
       else
  bitpos = (i * ((((elttype)->type.size))->int_cst.int_cst_low));

       store_field (xtarget, bitsize, bitpos, mode, ((elt)->list.value),


      VOIDmode, 0,
      ((type)->type.align) / 8,
      int_size_in_bytes (type));
     }
 }
    }

  else if (((n64_enum_tree_code) (type)->common.code) == SET_TYPE)
    {
      tree elt;
      rtx xtarget = ((target)->fld[0].rtx);
      int set_word_size = ((type)->type.align);
      int nbytes = int_size_in_bytes (type);
      tree non_const_elements;
      int need_to_clear_first;
      tree domain = ((type)->type.values);
      tree domain_min, domain_max, bitlength;
      if (((exp)->exp.operands[1]) == (tree) 
                                   ((void *)0)
                                            )
 {
   clear_storage (target, expr_size (exp));
   return;
 }

      if (nbytes < 0)
 abort ();

      domain_min = convert (sizetype, ((domain)->type.minval));
      domain_max = convert (sizetype, ((domain)->type.maxval));
      bitlength = size_binop (PLUS_EXPR,
         size_binop (MINUS_EXPR, domain_max, domain_min),
         size_one_node);



      if (((target)->mode) == BLKmode && nbytes > 16
   && ((((exp)->exp.operands[1]))->common.chain) == (tree) 
                                            ((void *)0)
                                                     )
 {
   need_to_clear_first = 1;
   non_const_elements = ((exp)->exp.operands[1]);
 }
      else
 {
   int nbits = nbytes * 8;
   int set_word_size = ((((exp)->common.type))->type.align);
   n64_enum_machine_mode mode = mode_for_size (set_word_size, MODE_INT, 1);
   char *bit_buffer = (char*) 
                             __builtin_alloca((
                             nbits
                             ))
                                           ;
   int word = 0;
   int bit_pos = 0;
   int ibit = 0;
   int offset = 0;
   non_const_elements = get_set_constructor_bits (exp,
        bit_buffer, nbits);
   for (;;)
     {
       if (bit_buffer[ibit])
  {
    if (((target_flags & 0x00010000) != 0))
      word |= (1 << (set_word_size - 1 - bit_pos));
    else
      word |= 1 << bit_pos;
  }
       bit_pos++; ibit++;
       if (bit_pos >= set_word_size || ibit == nbits)
  {
    rtx datum = gen_rtx (CONST_INT, VOIDmode, (int) (word));
    rtx to_rtx;


    if (((target)->code) == MEM)
      to_rtx = change_address (target, mode,
          plus_constant_wide (((target)->fld[0].rtx), (int) (offset))
                  );
    else if (offset == 0)
      to_rtx = target;
    else
      abort ();
    emit_move_insn (to_rtx, datum);
    if (ibit == nbits)
      break;
    word = 0;
    bit_pos = 0;
    offset += set_word_size / 8;
  }
     }
   need_to_clear_first = 0;
 }

      for (elt = non_const_elements; elt != (tree) 
                                           ((void *)0)
                                                    ; elt = ((elt)->common.chain))
 {

   tree startbit = ((elt)->list.purpose);

   tree endbit = ((elt)->list.value);
   int startb, endb;
   rtx bitlength_rtx, startbit_rtx, endbit_rtx, targetx;

   bitlength_rtx = expand_expr (bitlength,
       (rtx) 0, MEM, EXPAND_CONST_ADDRESS);


   if (startbit == (tree) 
                  ((void *)0)
                           )
     {
       startbit = save_expr (endbit);
       endbit = startbit;
     }
   startbit = convert (sizetype, startbit);
   endbit = convert (sizetype, endbit);
   if (! integer_zerop (domain_min))
     {
       startbit = size_binop (MINUS_EXPR, startbit, domain_min);
       endbit = size_binop (MINUS_EXPR, endbit, domain_min);
     }
   startbit_rtx = expand_expr (startbit, (rtx) 0, MEM,
          EXPAND_CONST_ADDRESS);
   endbit_rtx = expand_expr (endbit, (rtx) 0, MEM,
        EXPAND_CONST_ADDRESS);

   if ((((target)->code) == REG))
     {
       targetx = assign_stack_temp (((target)->mode),
        (mode_size[(int)(((target)->mode))]),
        0);
       emit_move_insn (targetx, target);
     }
   else if (((target)->code) == MEM)
     targetx = target;
   else
     abort ();





   if (((n64_enum_tree_code) (startbit)->common.code) == INTEGER_CST
       && ((n64_enum_tree_code) (endbit)->common.code) == INTEGER_CST
       && (startb = ((startbit)->int_cst.int_cst_low)) % 8 == 0
       && (endb = ((endbit)->int_cst.int_cst_low)) % 8 == 0)
     {

       if (need_to_clear_first
    && endb - startb != nbytes * 8)
  clear_storage (target, expr_size (exp));
       need_to_clear_first = 0;
       emit_library_call (memset_libfunc, 0,
     VOIDmode, 3,
     plus_constant_wide (((targetx)->fld[0].rtx), (int) (startb)),
     ((target_flags & 0x00000002) ? DImode : SImode),
     constm1_rtx, ((target_flags & 0x00000002) ? DImode : SImode),
     gen_rtx (CONST_INT, VOIDmode, (int) ((endb - startb) / 8)),
     ((target_flags & 0x00000002) ? DImode : SImode));
     }
   else

     {
       if (need_to_clear_first)
  {
    clear_storage (target, expr_size (exp));
    need_to_clear_first = 0;
  }
       emit_library_call (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "__setbits"),
     0, VOIDmode, 4, ((targetx)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode),
     bitlength_rtx, ((sizetype)->type.mode),
     startbit_rtx, ((sizetype)->type.mode),
     endbit_rtx, ((sizetype)->type.mode));
     }
   if ((((target)->code) == REG))
     emit_move_insn (target, targetx);
 }
    }

  else
    abort ();
}
static rtx
store_field(rtx target, int bitsize, int bitpos, n64_enum_machine_mode mode, tree exp, n64_enum_machine_mode value_mode, int unsignedp, int align, int total_size) asm("_store_field");
static rtx
store_field(rtx target, int bitsize, int bitpos, n64_enum_machine_mode mode, tree exp, n64_enum_machine_mode value_mode, int unsignedp, int align, int total_size)
{
  int width_mask = 0;

  if (bitsize < 32)
    width_mask = ((int) 1 << bitsize) - 1;
  if (mode == BLKmode
      && (((target)->code) == REG || ((target)->code) == SUBREG))
    {
      rtx object = assign_stack_temp (((target)->mode),
          (mode_size[(int)(((target)->mode))]), 0);
      rtx blk_object = copy_rtx (object);

      ((object)->in_struct) = 1;
      ((blk_object)->in_struct) = 1;
      ((blk_object)->mode = (BLKmode));

      if (bitsize != (8 * mode_size[(int)(((target)->mode))]))
 emit_move_insn (object, target);

      store_field (blk_object, bitsize, bitpos, mode, exp, VOIDmode, 0,
     align, total_size);



      emit_move_insn (target, object);

      return blk_object;
    }





  if (mode == VOIDmode
      || (mode != BLKmode && ! direct_store[(int) mode])
      || ((target)->code) == REG
      || ((target)->code) == SUBREG


      || (1
   && align * 8 < ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))))
      || (1 && bitpos % ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) != 0))
    {
      rtx temp = expand_expr (exp, (rtx) 0, VOIDmode, 0);



      if (mode != VOIDmode && mode != BLKmode
   && mode != ((((exp)->common.type))->type.mode))
 temp = convert_modes (mode, ((((exp)->common.type))->type.mode), temp, 1);


      store_bit_field (target, bitsize, bitpos, mode, temp, align, total_size);
      if (value_mode != VOIDmode)
 {


   if (width_mask != 0
       && ! (((target)->code) == MEM && ((target)->volatil)))
     {
       tree count;
       n64_enum_machine_mode tmode;

       if (unsignedp)
  return expand_and (temp, gen_rtx (CONST_INT, VOIDmode, (int) (width_mask)), (rtx) 0);
       tmode = ((temp)->mode);
       if (tmode == VOIDmode)
  tmode = value_mode;
       count = build_int_2_wide ((int) ((8 * mode_size[(int)(tmode)]) - bitsize), (int) (0));
       temp = expand_shift (LSHIFT_EXPR, tmode, temp, count, 0, 0);
       return expand_shift (RSHIFT_EXPR, tmode, temp, count, 0, 0);
     }
   return extract_bit_field (target, bitsize, bitpos, unsignedp,
        (rtx) 0, value_mode, 0, align,
        total_size);
 }
      return const0_rtx;
    }
  else
    {
      rtx addr = ((target)->fld[0].rtx);
      rtx to_rtx;




      if (value_mode != VOIDmode && ((addr)->code) != REG
   && ! ((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == HIGH || (((addr)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (addr)) && ! 0)) && (!0 || !0))

   && ! (((addr)->code) == PLUS
  && ((((addr)->fld[1].rtx))->code) == CONST_INT
  && (((addr)->fld[0].rtx) == virtual_incoming_args_rtx
      || ((addr)->fld[0].rtx) == virtual_stack_vars_rtx)))
 addr = copy_to_reg (addr);



      to_rtx = change_address (target, mode,
          plus_constant_wide (addr, (int) ((bitpos / 8))));
      ((to_rtx)->in_struct) = 1;

      return store_expr (exp, to_rtx, value_mode != VOIDmode);
    }
}




static int
get_inner_unaligned_p(tree exp) asm("_get_inner_unaligned_p");
static int
get_inner_unaligned_p(tree exp)
{
  int needed_alignment = ((((exp)->common.type))->type.align);

  while (1)
    {
      if (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF || ((n64_enum_tree_code) (exp)->common.code) == BIT_FIELD_REF)
 {
   if (((((((exp)->exp.operands[0]))->common.type))->type.align)
       < needed_alignment)
     return 1;
 }
      else if (((n64_enum_tree_code) (exp)->common.code) != ARRAY_REF
        && ((n64_enum_tree_code) (exp)->common.code) != NON_LVALUE_EXPR
        && ! ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
        || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR)
       && (((((exp)->common.type))->type.mode)
    == ((((((exp)->exp.operands[0]))->common.type))->type.mode))))
 break;

      exp = ((exp)->exp.operands[0]);
    }

  return 0;
}
tree
get_inner_reference(tree exp, int *pbitsize, int *pbitpos, tree *poffset, n64_enum_machine_mode *pmode, int *punsignedp, int *pvolatilep) asm("_get_inner_reference");
tree
get_inner_reference(tree exp, int *pbitsize, int *pbitpos, tree *poffset, n64_enum_machine_mode *pmode, int *punsignedp, int *pvolatilep)
{
  tree orig_exp = exp;
  tree size_tree = 0;
  n64_enum_machine_mode mode = VOIDmode;
  tree offset = integer_zero_node;

  if (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF)
    {
      size_tree = ((((exp)->exp.operands[1]))->decl.size);
      if (! ((((exp)->exp.operands[1]))->decl.bit_field_flag))
 mode = ((((exp)->exp.operands[1]))->decl.mode);
      *punsignedp = ((((exp)->exp.operands[1]))->common.unsigned_flag);
    }
  else if (((n64_enum_tree_code) (exp)->common.code) == BIT_FIELD_REF)
    {
      size_tree = ((exp)->exp.operands[1]);
      *punsignedp = ((exp)->common.unsigned_flag);
    }
  else
    {
      mode = ((((exp)->common.type))->type.mode);
      *pbitsize = (8 * mode_size[(int)(mode)]);
      *punsignedp = ((((exp)->common.type))->common.unsigned_flag);
    }

  if (size_tree)
    {
      if (((n64_enum_tree_code) (size_tree)->common.code) != INTEGER_CST)
 mode = BLKmode, *pbitsize = -1;
      else
 *pbitsize = ((size_tree)->int_cst.int_cst_low);
    }




  *pbitpos = 0;

  while (1)
    {
      if (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF || ((n64_enum_tree_code) (exp)->common.code) == BIT_FIELD_REF)
 {
   tree pos = (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF
        ? ((((exp)->exp.operands[1]))->decl.arguments)
        : ((exp)->exp.operands[2]));
   tree constant = integer_zero_node, var = pos;




   if (pos == 0)
     break;



   if (((n64_enum_tree_code) (pos)->common.code) == PLUS_EXPR
       && ((n64_enum_tree_code) (((pos)->exp.operands[1]))->common.code) == INTEGER_CST)
     constant = ((pos)->exp.operands[1]), var = ((pos)->exp.operands[0]);
   else if (((n64_enum_tree_code) (pos)->common.code) == INTEGER_CST)
     constant = pos, var = integer_zero_node;

   *pbitpos += ((constant)->int_cst.int_cst_low);

   if (var)
     offset = size_binop (PLUS_EXPR, offset,
     size_binop (EXACT_DIV_EXPR, var,
          size_int (8)));
 }

      else if (((n64_enum_tree_code) (exp)->common.code) == ARRAY_REF)
 {




   tree strchr = ((exp)->exp.operands[1]);
   tree domain = ((((((exp)->exp.operands[0]))->common.type))->type.values);
   tree low_bound
     = domain ? ((domain)->type.minval) : integer_zero_node;
   tree index_type = ((strchr)->common.type);

   if (! integer_zerop (low_bound))
     strchr = fold (build (MINUS_EXPR, index_type, strchr, low_bound));

   if (((index_type)->type.precision) != ((sizetype)->type.precision))
     {
       strchr = convert (type_for_size (((sizetype)->type.precision), 0),
          strchr);
       index_type = ((strchr)->common.type);
     }

   strchr = fold (build (MULT_EXPR, index_type, strchr,
          ((((exp)->common.type))->type.size)));

   if (((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
       && ((strchr)->int_cst.int_cst_high) == 0)
     *pbitpos += ((strchr)->int_cst.int_cst_low);
   else
     offset = size_binop (PLUS_EXPR, offset,
     size_binop (FLOOR_DIV_EXPR, strchr,
          size_int (8)));
 }
      else if (((n64_enum_tree_code) (exp)->common.code) != NON_LVALUE_EXPR
        && ! ((((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
        || ((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR)
       && ! (((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE
      && (((n64_enum_tree_code) (((((exp)->exp.operands[0]))->common.type))->common.code)
          != UNION_TYPE))
       && (((((exp)->common.type))->type.mode)
    == ((((((exp)->exp.operands[0]))->common.type))->type.mode))))
 break;


      if (((exp)->common.volatile_flag))
 *pvolatilep = 1;
      exp = ((exp)->exp.operands[0]);
    }



  if (mode == VOIDmode && *pbitsize != 0 && *pbitpos % *pbitsize == 0)
    {
      mode = mode_for_size (*pbitsize, MODE_INT, 0);
      if (mode == BLKmode)
 mode = VOIDmode;
    }

  if (integer_zerop (offset))
    offset = 0;

  if (offset != 0 && contains_placeholder_p (offset))
    offset = build (WITH_RECORD_EXPR, sizetype, offset, orig_exp);

  *pmode = mode;
  *poffset = offset;
  return exp;
}
rtx
force_operand(rtx value, rtx target) asm("_force_operand");
rtx
force_operand(rtx value, rtx target)
{
  register optab binoptab = 0;


  rtx tmp;
  register rtx op2;

  register rtx subtarget = (target != 0 && ((target)->code) == REG ? target : 0);

  if (((value)->code) == PLUS)
    binoptab = add_optab;
  else if (((value)->code) == MINUS)
    binoptab = sub_optab;
  else if (((value)->code) == MULT)
    {
      op2 = ((value)->fld[1].rtx);
      if (!(((op2)->code) == LABEL_REF || ((op2)->code) == SYMBOL_REF || ((op2)->code) == CONST_INT || ((op2)->code) == CONST_DOUBLE || ((op2)->code) == CONST || ((op2)->code) == HIGH)
   && !(((op2)->code) == REG && op2 != subtarget))
 subtarget = 0;
      tmp = force_operand (((value)->fld[0].rtx), subtarget);
      return expand_mult (((value)->mode), tmp,
     force_operand (op2, (rtx) 0),
     target, 0);
    }

  if (binoptab)
    {
      op2 = ((value)->fld[1].rtx);
      if (!(((op2)->code) == LABEL_REF || ((op2)->code) == SYMBOL_REF || ((op2)->code) == CONST_INT || ((op2)->code) == CONST_DOUBLE || ((op2)->code) == CONST || ((op2)->code) == HIGH)
   && !(((op2)->code) == REG && op2 != subtarget))
 subtarget = 0;
      if (binoptab == sub_optab && ((op2)->code) == CONST_INT)
 {
   binoptab = add_optab;
   op2 = negate_rtx (((value)->mode), op2);
 }







      if (binoptab == add_optab && ((op2)->code) == CONST_INT
   && ((((value)->fld[0].rtx))->code) == PLUS
   && ((((((value)->fld[0].rtx))->fld[0].rtx))->code) == REG
   && ((((((value)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint) >= (68)
   && ((((((value)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3))
 {
   rtx temp = expand_binop (((value)->mode), binoptab,
       ((((value)->fld[0].rtx))->fld[0].rtx), op2,
       subtarget, 0, OPTAB_LIB_WIDEN);
   return expand_binop (((value)->mode), binoptab, temp,
          force_operand (((((value)->fld[0].rtx))->fld[1].rtx), 0),
          target, 0, OPTAB_LIB_WIDEN);
 }

      tmp = force_operand (((value)->fld[0].rtx), subtarget);
      return expand_binop (((value)->mode), binoptab, tmp,
      force_operand (op2, (rtx) 0),
      target, 0, OPTAB_LIB_WIDEN);


    }
  return value;
}






static tree
save_noncopied_parts(tree lhs, tree list) asm("_save_noncopied_parts");
static tree
save_noncopied_parts(tree lhs, tree list)
{
  tree tail;
  tree parts = 0;

  for (tail = list; tail; tail = ((tail)->common.chain))
    if (((n64_enum_tree_code) (((tail)->list.value))->common.code) == TREE_LIST)
      parts = chainon (parts, save_noncopied_parts (lhs, ((tail)->list.value)));
    else
      {
 tree part = ((tail)->list.value);
 tree part_type = ((part)->common.type);
 tree to_be_saved = build (COMPONENT_REF, part_type, lhs, part);
 rtx target = assign_stack_temp (((part_type)->type.mode),
     int_size_in_bytes (part_type), 0);
 ((target)->in_struct) = (((n64_enum_tree_code) (part_type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (part_type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (part_type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (part_type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (part_type)->common.code) == SET_TYPE);
 if (! memory_address_p (((part_type)->type.mode), ((target)->fld[0].rtx)))
   target = change_address (target, ((part_type)->type.mode), (rtx) 0);
 parts = tree_cons (to_be_saved,
      build (RTL_EXPR, part_type, (tree) 
                                 ((void *)0)
                                          ,
      (tree) target),
      parts);
 store_expr (((parts)->list.purpose), (*(struct n64_tag_rtx_def **) &(((parts)->list.value))->exp.operands[1]), 0);
      }
  return parts;
}





static tree
init_noncopied_parts(tree lhs, tree list) asm("_init_noncopied_parts");
static tree
init_noncopied_parts(tree lhs, tree list)
{
  tree tail;
  tree parts = 0;

  for (tail = list; tail; tail = ((tail)->common.chain))
    if (((n64_enum_tree_code) (((tail)->list.value))->common.code) == TREE_LIST)
      parts = chainon (parts, init_noncopied_parts (lhs, ((tail)->list.value)));
    else
      {
 tree part = ((tail)->list.value);
 tree part_type = ((part)->common.type);
 tree to_be_initialized = build (COMPONENT_REF, part_type, lhs, part);
 parts = tree_cons (((tail)->list.purpose), to_be_initialized, parts);
      }
  return parts;
}




static int
safe_from_p(rtx x, tree exp) asm("_safe_from_p");
static int
safe_from_p(rtx x, tree exp)
{
  rtx exp_rtl = 0;
  int i, nops;

  if (x == 0





      || (((exp)->common.type) != 0 && ((((exp)->common.type))->type.size) != 0
   && ((n64_enum_tree_code) (((((exp)->common.type))->type.size))->common.code) != INTEGER_CST
   && ((x)->mode) == BLKmode))
    return 1;



  if (((x)->code) == SUBREG)
    {
      x = ((x)->fld[0].rtx);
      if (((x)->code) == REG && ((x)->fld[0].rtint) < 68)
 return 0;
    }


  if (((x)->code) == MEM
      && (((x)->fld[0].rtx) == virtual_outgoing_args_rtx
   || (((((x)->fld[0].rtx))->code) == PLUS
       && ((((x)->fld[0].rtx))->fld[0].rtx) == virtual_outgoing_args_rtx)))
    return 1;

  switch ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]))
    {
    case 'd':
      exp_rtl = ((exp)->decl.rtl);
      break;

    case 'c':
      return 1;

    case 'x':
      if (((n64_enum_tree_code) (exp)->common.code) == TREE_LIST)
 return ((((exp)->list.value) == 0
   || safe_from_p (x, ((exp)->list.value)))
  && (((exp)->common.chain) == 0
      || safe_from_p (x, ((exp)->common.chain))));
      else
 return 0;

    case '1':
      return safe_from_p (x, ((exp)->exp.operands[0]));

    case '2':
    case '<':
      return (safe_from_p (x, ((exp)->exp.operands[0]))
       && safe_from_p (x, ((exp)->exp.operands[1])));

    case 'e':
    case 'r':





      switch (((n64_enum_tree_code) (exp)->common.code))
 {
 case ADDR_EXPR:
   return (staticp (((exp)->exp.operands[0]))
    || safe_from_p (x, ((exp)->exp.operands[0])));

 case INDIRECT_REF:
   if (((x)->code) == MEM)
     return 0;
   break;

 case CALL_EXPR:
   exp_rtl = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);
   if (exp_rtl == 0)
     {


       if ((((x)->code) == REG && ((x)->fld[0].rtint) < 68)
    || ((x)->code) == MEM)
  return 0;
     }

   break;

 case RTL_EXPR:



   if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[0]))
     return 0;

   exp_rtl = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]);
   break;

 case WITH_CLEANUP_EXPR:
   exp_rtl = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]);
   break;

 case CLEANUP_POINT_EXPR:
   return safe_from_p (x, ((exp)->exp.operands[0]));

 case SAVE_EXPR:
   exp_rtl = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);
   break;

 case BIND_EXPR:


   return safe_from_p (x, ((exp)->exp.operands[1]));

 case METHOD_CALL_EXPR:

   abort ();
 }


      if (exp_rtl)
 break;

      nops = tree_code_length[(int) ((n64_enum_tree_code) (exp)->common.code)];
      for (i = 0; i < nops; i++)
 if (((exp)->exp.operands[i]) != 0
     && ! safe_from_p (x, ((exp)->exp.operands[i])))
   return 0;
    }



  if (exp_rtl)
    {
      if (((exp_rtl)->code) == SUBREG)
 {
   exp_rtl = ((exp_rtl)->fld[0].rtx);
   if (((exp_rtl)->code) == REG
       && ((exp_rtl)->fld[0].rtint) < 68)
     return 0;
 }



      return ! (rtx_equal_p (x, exp_rtl)
  || (((x)->code) == MEM && ((exp_rtl)->code) == MEM
      && ! ((exp)->common.readonly_flag)));
    }


  return 1;
}




static int
fixed_type_p(tree exp) asm("_fixed_type_p");
static int
fixed_type_p(tree exp)
{
  if (((n64_enum_tree_code) (exp)->common.code) == PARM_DECL
      || ((n64_enum_tree_code) (exp)->common.code) == VAR_DECL
      || ((n64_enum_tree_code) (exp)->common.code) == CALL_EXPR || ((n64_enum_tree_code) (exp)->common.code) == TARGET_EXPR
      || ((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF
      || ((n64_enum_tree_code) (exp)->common.code) == ARRAY_REF)
    return 1;
  return 0;
}
rtx
expand_expr(register tree exp, rtx target, n64_enum_machine_mode tmode, n64_enum_expand_modifier modifier) asm("_expand_expr");
rtx
expand_expr(register tree exp, rtx target, n64_enum_machine_mode tmode, n64_enum_expand_modifier modifier)
{


  static tree placeholder_list = 0;
  register rtx op0, op1, temp;
  tree type = ((exp)->common.type);
  int unsignedp = ((type)->common.unsigned_flag);
  register n64_enum_machine_mode mode = ((type)->type.mode);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);
  optab this_optab;

  rtx subtarget = (target != 0 && ((target)->code) == REG ? target : 0);
  rtx original_target = target;

  int ignore = (target == const0_rtx
  || ((code == NON_LVALUE_EXPR || code == NOP_EXPR
       || code == CONVERT_EXPR || code == REFERENCE_EXPR
       || code == COND_EXPR)
      && ((n64_enum_tree_code) (type)->common.code) == VOID_TYPE));
  tree context;


  if (output_bytecode && modifier != EXPAND_INITIALIZER)
    {
      bc_expand_expr (exp);
      return 
            ((void *)0)
                ;
    }



  if (subtarget && ((subtarget)->fld[0].rtint) < 68)
    subtarget = 0;


  if (preserve_subexpressions_p ())
    subtarget = 0;







  if (ignore)
    {
      if (! ((exp)->common.side_effects_flag))
 return const0_rtx;


      if (((exp)->common.volatile_flag)
   && ((n64_enum_tree_code) (exp)->common.code) != FUNCTION_DECL
   && mode != VOIDmode && mode != BLKmode)
 {
   temp = expand_expr (exp, (rtx) 0, VOIDmode, modifier);
   if (((temp)->code) == MEM)
     temp = copy_to_reg (temp);
   return const0_rtx;
 }

      if ((*tree_code_type[(int) (code)]) == '1')
 return expand_expr (((exp)->exp.operands[0]), const0_rtx,
       VOIDmode, modifier);
      else if ((*tree_code_type[(int) (code)]) == '2'
        || (*tree_code_type[(int) (code)]) == '<')
 {
   expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode, modifier);
   expand_expr (((exp)->exp.operands[1]), const0_rtx, VOIDmode, modifier);
   return const0_rtx;
 }
      else if ((code == TRUTH_ANDIF_EXPR || code == TRUTH_ORIF_EXPR)
        && ! ((((exp)->exp.operands[1]))->common.side_effects_flag))


 return expand_expr (((exp)->exp.operands[0]), const0_rtx,
       VOIDmode, modifier);

      target = 0;
    }






  if (! cse_not_expected && mode != BLKmode && target
      && (((target)->code) != REG || ((target)->fld[0].rtint) < 68))
    target = subtarget;

  switch (code)
    {
    case LABEL_DECL:
      {
 tree function = decl_function_context (exp);

 if (function != current_function_decl && function != 0)
   {
     struct n64_tag_function *p = find_function_data (function);


     push_obstacks (p->function_obstack,
      p->function_maybepermanent_obstack);

     p->forced_labels = gen_rtx (EXPR_LIST, VOIDmode,
     label_rtx (exp), p->forced_labels);
     pop_obstacks ();
   }
 else if (modifier == EXPAND_INITIALIZER)
   forced_labels = gen_rtx (EXPR_LIST, VOIDmode,
       label_rtx (exp), forced_labels);
 temp = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode),
   gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), label_rtx (exp)));
 if (function != current_function_decl && function != 0)
   ((((temp)->fld[0].rtx))->volatil) = 1;
 return temp;
      }

    case PARM_DECL:
      if (((exp)->decl.rtl) == 0)
 {
   error_with_decl (exp, "prior parameter's size depends on `%s'");
   return (const_tiny_rtx[0][(int) (mode)]);
 }



    case VAR_DECL:


      if (((exp)->decl.size) == 0 && ((((exp)->common.type))->type.size) != 0
   && (((exp)->common.static_flag) || ((exp)->decl.external_flag)))
 {
   push_obstacks_nochange ();
   end_temporary_allocation ();
   layout_decl (exp, 0);
   ((((exp)->decl.rtl))->mode = (((exp)->decl.mode)));
   pop_obstacks ();
 }



    case FUNCTION_DECL:
    case RESULT_DECL:
      if (((exp)->decl.rtl) == 0)
 abort ();




      if (! ((exp)->common.used_flag))
 {
   assemble_external (exp);
   ((exp)->common.used_flag) = 1;
 }


      context = decl_function_context (exp);






      if (context != 0 && context != current_function_decl
   && context != inline_function_decl

   && ! (((((exp)->decl.rtl))->code) == MEM
  && (((((((exp)->decl.rtl))->fld[0].rtx))->code) == LABEL_REF || ((((((exp)->decl.rtl))->fld[0].rtx))->code) == SYMBOL_REF || ((((((exp)->decl.rtl))->fld[0].rtx))->code) == CONST_INT || ((((((exp)->decl.rtl))->fld[0].rtx))->code) == CONST_DOUBLE || ((((((exp)->decl.rtl))->fld[0].rtx))->code) == CONST || ((((((exp)->decl.rtl))->fld[0].rtx))->code) == HIGH)))
 {
   rtx addr;


   ((exp)->decl.nonlocal_flag) = 1;
   mark_addressable (exp);
   if (((((exp)->decl.rtl))->code) != MEM)
     abort ();
   addr = ((((exp)->decl.rtl))->fld[0].rtx);
   if (((addr)->code) == MEM)
     addr = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode),
       fix_lexical_addr (((addr)->fld[0].rtx), exp));
   else
     addr = fix_lexical_addr (addr, exp);
   return change_address (((exp)->decl.rtl), mode, addr);
 }





      if (((((exp)->decl.rtl))->code) == MEM
   && ((((((exp)->decl.rtl))->fld[0].rtx))->code) == REG)
 return change_address (((exp)->decl.rtl), ((((exp)->decl.rtl))->mode),
          ((((exp)->decl.rtl))->fld[0].rtx));





      if (((((exp)->decl.rtl))->code) == MEM
   && modifier != EXPAND_CONST_ADDRESS
   && modifier != EXPAND_SUM
   && modifier != EXPAND_INITIALIZER
   && (! memory_address_p (((exp)->decl.mode), ((((exp)->decl.rtl))->fld[0].rtx))
       || (flag_force_addr
    && ((((((exp)->decl.rtl))->fld[0].rtx))->code) != REG)))
 return change_address (((exp)->decl.rtl), VOIDmode,
          copy_rtx (((((exp)->decl.rtl))->fld[0].rtx)));





      if (((((exp)->decl.rtl))->code) == REG
   && ((((exp)->decl.rtl))->mode) != mode)
 {


   if (((((exp)->decl.rtl))->mode)
       != promote_mode (type, ((exp)->decl.mode), &unsignedp, 0))
     abort ();

   temp = gen_rtx (SUBREG, mode, ((exp)->decl.rtl), 0);
   ((temp)->in_struct) = 1;
   ((temp)->unchanging) = unsignedp;
   return temp;
 }

      return ((exp)->decl.rtl);

    case INTEGER_CST:
      return immed_double_const (((exp)->int_cst.int_cst_low),
     ((exp)->int_cst.int_cst_high),
     mode);

    case CONST_DECL:
      return expand_expr (((exp)->decl.initial), target, VOIDmode, 0);

    case REAL_CST:
      return immed_real_const (exp);

    case COMPLEX_CST:
    case STRING_CST:
      if (! ((exp)->real_cst.rtl))
 output_constant_def (exp);




      if (((((exp)->real_cst.rtl))->code) == MEM
   && modifier != EXPAND_CONST_ADDRESS
   && modifier != EXPAND_INITIALIZER
   && modifier != EXPAND_SUM
   && (! memory_address_p (mode, ((((exp)->real_cst.rtl))->fld[0].rtx))
       || (flag_force_addr
    && ((((((exp)->real_cst.rtl))->fld[0].rtx))->code) != REG)))
 return change_address (((exp)->real_cst.rtl), VOIDmode,
          copy_rtx (((((exp)->real_cst.rtl))->fld[0].rtx)));
      return ((exp)->real_cst.rtl);

    case SAVE_EXPR:
      context = decl_function_context (exp);





      if (context == current_function_decl || context == inline_function_decl)
 context = 0;


      if (context)
 {
   temp = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);
   if (temp && ((temp)->code) == REG)
     {
       put_var_into_stack (exp);
       temp = (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);
     }
   if (temp == 0 || ((temp)->code) != MEM)
     abort ();
   return change_address (temp, mode,
     fix_lexical_addr (((temp)->fld[0].rtx), exp));
 }
      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) == 0)
 {
   if (mode == BLKmode)
     {
       temp
  = assign_stack_temp (mode, int_size_in_bytes (type), 0);
       ((temp)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
     }
   else if (mode == VOIDmode)
     temp = const0_rtx;
   else
     temp = gen_reg_rtx (promote_mode (type, mode, &unsignedp, 0));

   (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) = temp;
   if (!optimize && ((temp)->code) == REG)
     save_expr_regs = gen_rtx (EXPR_LIST, VOIDmode, temp,
          save_expr_regs);







   if (((temp)->code) == REG && ((temp)->mode) != mode)
     {
       temp = gen_rtx (SUBREG, mode, (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]), 0);
       ((temp)->in_struct) = 1;
       ((temp)->unchanging) = unsignedp;
     }

   if (temp == const0_rtx)
     expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode, 0);
   else
     store_expr (((exp)->exp.operands[0]), temp, 0);
 }





      if ((((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]))->code) == REG
   && (((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]))->mode) != mode)
 {

   promote_mode (type, mode, &unsignedp, 0);
   temp = gen_rtx (SUBREG, mode, (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]), 0);
   ((temp)->in_struct) = 1;
   ((temp)->unchanging) = unsignedp;
   return temp;
 }

      return (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);

    case PLACEHOLDER_EXPR:



      if (placeholder_list)
 {
   tree object;
   tree old_list = placeholder_list;

   for (object = ((placeholder_list)->list.purpose);
        (((((object)->common.type))->type.main_variant)
  != ((type)->type.main_variant))
        && ((*tree_code_type[(int) (((n64_enum_tree_code) (object)->common.code))]) == 'r'
     || (*tree_code_type[(int) (((n64_enum_tree_code) (object)->common.code))]) == '1'
     || (*tree_code_type[(int) (((n64_enum_tree_code) (object)->common.code))]) == '2'
     || (*tree_code_type[(int) (((n64_enum_tree_code) (object)->common.code))]) == 'e');
        object = ((object)->exp.operands[0]))
     ;

   if (object != 0
       && (((((object)->common.type))->type.main_variant)
    == ((type)->type.main_variant)))
     {




       placeholder_list = ((placeholder_list)->common.chain);
       temp = expand_expr (object, original_target, tmode, modifier);
       placeholder_list = old_list;
       return temp;
     }
 }


      abort ();

    case WITH_RECORD_EXPR:


      placeholder_list = tree_cons (((exp)->exp.operands[1]), (tree) 
                                                          ((void *)0)
                                                                   ,
        placeholder_list);
      target = expand_expr (((exp)->exp.operands[0]), original_target,
       tmode, modifier);
      placeholder_list = ((placeholder_list)->common.chain);
      return target;

    case EXIT_EXPR:
      expand_exit_loop_if_false (((void *)0),
     invert_truthvalue (((exp)->exp.operands[0])));
      return const0_rtx;

    case LOOP_EXPR:
      push_temp_slots ();
      expand_start_loop (1);
      expand_expr_stmt (((exp)->exp.operands[0]));
      expand_end_loop ();
      pop_temp_slots ();

      return const0_rtx;

    case BIND_EXPR:
      {
 tree vars = ((exp)->exp.operands[0]);
 int vars_need_expansion = 0;



 expand_start_bindings (0);


 if (((exp)->exp.operands[2]) != 0
     && ! ((((exp)->exp.operands[2]))->common.used_flag))
   insert_block (((exp)->exp.operands[2]));


 while (vars)
   {
     if (((vars)->decl.rtl) == 0)
       {
  vars_need_expansion = 1;
  expand_decl (vars);
       }
     expand_decl_init (vars);
     vars = ((vars)->common.chain);
   }

 temp = expand_expr (((exp)->exp.operands[1]), target, tmode, modifier);

 expand_end_bindings (((exp)->exp.operands[0]), 0, 0);

 return temp;
      }

    case RTL_EXPR:
      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[0]) == const0_rtx)
 abort ();
      emit_insns ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[0]));
      (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[0]) = const0_rtx;
      preserve_rtl_expr_result ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]));
      free_temps_for_rtl_expr (exp);
      return (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]);

    case CONSTRUCTOR:


      if (ignore)
 {
   tree elt;
   for (elt = ((exp)->exp.operands[1]); elt; elt = ((elt)->common.chain))
     expand_expr (((elt)->list.value), const0_rtx, VOIDmode, 0);
   return const0_rtx;
 }
      else if ((((exp)->common.static_flag)
  && ((mode == BLKmode
       && ! (target != 0 && safe_from_p (target, exp)))
      || ((exp)->common.addressable_flag)
      || (((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST
   && (move_by_pieces_ninsns
       (((((type)->type.size))->int_cst.int_cst_low)/8,
        ((type)->type.align) / 8)
       > 2))))
        || (modifier == EXPAND_INITIALIZER && ((exp)->common.constant_flag)))
 {
   rtx constructor = output_constant_def (exp);
   if (modifier != EXPAND_CONST_ADDRESS
       && modifier != EXPAND_INITIALIZER
       && modifier != EXPAND_SUM
       && (! memory_address_p (((constructor)->mode),
          ((constructor)->fld[0].rtx))
    || (flag_force_addr
        && ((((constructor)->fld[0].rtx))->code) != REG)))
     constructor = change_address (constructor, VOIDmode,
       ((constructor)->fld[0].rtx));
   return constructor;
 }

      else
 {
   if (target == 0 || ! safe_from_p (target, exp))
     {
       if (mode != BLKmode && ! ((exp)->common.addressable_flag))
  target = gen_reg_rtx (tmode != VOIDmode ? tmode : mode);
       else
  {
    target
      = assign_stack_temp (mode, int_size_in_bytes (type), 0);
    if ((((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE))
      ((target)->in_struct) = 1;
  }
     }
   store_constructor (exp, target);
   return target;
 }

    case INDIRECT_REF:
      {
 tree exp1 = ((exp)->exp.operands[0]);
 tree exp2;







 if (((n64_enum_tree_code) (exp1)->common.code) == SAVE_EXPR
     && (*(struct n64_tag_rtx_def **) &(exp1)->exp.operands[2]) == 0
     && ((((exp1)->common.type))->type.mode) == ptr_mode)
   {
     temp = expand_expr (((exp1)->exp.operands[0]), (rtx) 0,
    VOIDmode, EXPAND_SUM);
     op0 = memory_address (mode, temp);
     op0 = copy_all_regs (op0);
     (*(struct n64_tag_rtx_def **) &(exp1)->exp.operands[2]) = op0;
   }
 else
   {
     op0 = expand_expr (exp1, (rtx) 0, VOIDmode, EXPAND_SUM);
     op0 = memory_address (mode, op0);
   }

 temp = gen_rtx (MEM, mode, op0);


 if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == PLUS_EXPR
     || (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == SAVE_EXPR
  && ((n64_enum_tree_code) (((((exp)->exp.operands[0]))->exp.operands[0]))->common.code) == PLUS_EXPR)
     || (((n64_enum_tree_code) (((exp)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp)->common.type))->common.code) == SET_TYPE)
     || (((n64_enum_tree_code) (exp1)->common.code) == ADDR_EXPR
  && (exp2 = ((exp1)->exp.operands[0]))
  && (((n64_enum_tree_code) (((exp2)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((exp2)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((exp2)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((exp2)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((exp2)->common.type))->common.code) == SET_TYPE)))
   ((temp)->in_struct) = 1;
 ((temp)->volatil) = ((exp)->common.volatile_flag) | flag_volatile;






 ((temp)->unchanging) = ((exp)->common.readonly_flag) | ((exp)->common.static_flag);
 return temp;
      }

    case ARRAY_REF:
      if (((n64_enum_tree_code) (((((exp)->exp.operands[0]))->common.type))->common.code) != ARRAY_TYPE)
 abort ();

      {
 tree array = ((exp)->exp.operands[0]);
 tree domain = ((((array)->common.type))->type.values);
 tree low_bound = domain ? ((domain)->type.minval) : integer_zero_node;
 tree strchr = ((exp)->exp.operands[1]);
 tree index_type = ((strchr)->common.type);
 int i;

 if (((n64_enum_tree_code) (low_bound)->common.code) != INTEGER_CST
     && contains_placeholder_p (low_bound))
   low_bound = build (WITH_RECORD_EXPR, sizetype, low_bound, exp);
 if (! integer_zerop (low_bound))
   strchr = fold (build (MINUS_EXPR, index_type, strchr,
          convert (sizetype, low_bound)));

 if ((((n64_enum_tree_code) (strchr)->common.code) != INTEGER_CST
      || ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
     && (! 1 || ! get_inner_unaligned_p (exp)))
   {
     tree variant_type = build_type_variant (type,
          ((exp)->common.readonly_flag),
          ((exp)->common.volatile_flag));
     tree array_adr = build1 (ADDR_EXPR,
         build_pointer_type (variant_type), array);
     tree elt;
     tree size = size_in_bytes (type);



     if (((index_type)->type.precision) != ((sizetype)->type.precision))
       strchr = convert (type_for_size (((sizetype)->type.precision), 0),
          strchr);

     if (((n64_enum_tree_code) (size)->common.code) != INTEGER_CST
  && contains_placeholder_p (size))
       size = build (WITH_RECORD_EXPR, sizetype, size, exp);






     ((array_adr)->common.side_effects_flag) = 0;

     elt
       = build1
  (INDIRECT_REF, type,
   fold (build (PLUS_EXPR,
         ((variant_type)->type.pointer_to),
         array_adr,
         fold
         (build1
          (NOP_EXPR,
    ((variant_type)->type.pointer_to),
    fold (build (MULT_EXPR, ((strchr)->common.type),
          strchr,
          convert (((strchr)->common.type),
            size))))))));;



     ((elt)->common.side_effects_flag) = ((exp)->common.side_effects_flag);
     ((elt)->common.volatile_flag) = ((exp)->common.volatile_flag);
     ((elt)->common.readonly_flag) = ((exp)->common.readonly_flag);

     return expand_expr (elt, target, tmode, modifier);
   }






 if (((n64_enum_tree_code) (array)->common.code) == STRING_CST
     && ((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
     && !((strchr)->int_cst.int_cst_high)
     && (i = ((strchr)->int_cst.int_cst_low)) < ((array)->string.length)
     && (mode_class[(int)(mode)]) == MODE_INT
     && (mode_size[(int)(mode)]) == 1)
   return gen_rtx (CONST_INT, VOIDmode, (int) (((array)->string.pointer)[i]));






 if (((n64_enum_tree_code) (array)->common.code) == CONSTRUCTOR && ! ((array)->common.side_effects_flag))
   {
     if (((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
  && ((strchr)->int_cst.int_cst_high) == 0)
       {
  tree elem = ((((exp)->exp.operands[0]))->exp.operands[1]);

  i = ((strchr)->int_cst.int_cst_low);
  while (elem && i--)
    elem = ((elem)->common.chain);
  if (elem)
    return expand_expr (fold (((elem)->list.value)), target,
          tmode, modifier);
       }
   }

 else if (optimize >= 1
   && ((array)->common.readonly_flag) && ! ((array)->common.side_effects_flag)
   && ((n64_enum_tree_code) (array)->common.code) == VAR_DECL && ((array)->decl.initial)
   && ((n64_enum_tree_code) (((array)->decl.initial))->common.code) != ERROR_MARK)
   {
     if (((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
  && ((strchr)->int_cst.int_cst_high) == 0)
       {
  tree init = ((array)->decl.initial);

  i = ((strchr)->int_cst.int_cst_low);
  if (((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR)
    {
      tree elem = ((init)->exp.operands[1]);

      while (elem
      && !tree_int_cst_equal (((elem)->list.purpose), strchr))
        elem = ((elem)->common.chain);
      if (elem)
        return expand_expr (fold (((elem)->list.value)), target,
       tmode, modifier);
    }
  else if (((n64_enum_tree_code) (init)->common.code) == STRING_CST
    && i < ((init)->string.length))
    return gen_rtx (CONST_INT, VOIDmode, (int) (((init)->string.pointer)[i]));
       }
   }
      }



    case COMPONENT_REF:
    case BIT_FIELD_REF:




      if (code != ARRAY_REF
   && ((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == CONSTRUCTOR
   && ((((exp)->exp.operands[0]))->real_cst.rtl) == 0)
 {
   tree elt;

   for (elt = ((((exp)->exp.operands[0]))->exp.operands[1]); elt;
        elt = ((elt)->common.chain))
     if (((elt)->list.purpose) == ((exp)->exp.operands[1]))
       return expand_expr (((elt)->list.value), target, tmode, modifier);
 }

      {
 n64_enum_machine_mode mode1;
 int bitsize;
 int bitpos;
 tree offset;
 int volatilep = 0;
 tree tem = get_inner_reference (exp, &bitsize, &bitpos, &offset,
     &mode1, &unsignedp, &volatilep);
 int alignment;




 if (tem == exp)
   abort ();
 op0 = expand_expr (tem,
      (((n64_enum_tree_code) (((tem)->common.type))->common.code) == UNION_TYPE
       && (((n64_enum_tree_code) (((((tem)->common.type))->type.size))->common.code)
    != INTEGER_CST)
       ? target : (rtx) 0),
      VOIDmode, EXPAND_SUM);



 if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
   {
     n64_enum_machine_mode mode = ((((tem)->common.type))->type.mode);
     if (mode != BLKmode && ((((op0)->code) != CONST_DOUBLE || mips_const_double_ok (op0, ((op0)->mode))) && ! (((op0)->code) == CONST && 0)))
       op0 = force_reg (mode, op0);
     else
       op0 = validize_mem (force_const_mem (mode, op0));
   }

 alignment = ((((tem)->common.type))->type.align) / 8;
 if (offset != 0)
   {
     rtx offset_rtx = expand_expr (offset, (rtx) 0, VOIDmode, 0);

     if (((op0)->code) != MEM)
       abort ();
     op0 = change_address (op0, VOIDmode,
      gen_rtx (PLUS, ptr_mode, ((op0)->fld[0].rtx),
        force_reg (ptr_mode, offset_rtx)));




   if (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF
       || ((n64_enum_tree_code) (exp)->common.code) == BIT_FIELD_REF)
     alignment = (((((((exp)->exp.operands[0]))->common.type))->type.align)
    / 8);
   }


 if (((op0)->code) == MEM && volatilep && ! ((op0)->volatil))
   {
     op0 = copy_rtx (op0);
     ((op0)->volatil) = 1;
   }







 if (mode1 == VOIDmode
     || ((op0)->code) == REG || ((op0)->code) == SUBREG
     || (modifier != EXPAND_CONST_ADDRESS
  && modifier != EXPAND_SUM
  && modifier != EXPAND_INITIALIZER
  && ((mode1 != BLKmode && ! direct_load[(int) mode1])


      || (1
   && ((((((tem)->common.type))->type.align) < ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))))
       || (bitpos % ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) != 0))))))
   {
     n64_enum_machine_mode ext_mode = mode;

     if (ext_mode == BLKmode)
       ext_mode = mode_for_size (bitsize, MODE_INT, 1);

     if (ext_mode == BLKmode)
       abort ();

     op0 = extract_bit_field (validize_mem (op0), bitsize, bitpos,
         unsignedp, target, ext_mode, ext_mode,
         alignment,
         int_size_in_bytes (((tem)->common.type)));
     if (mode == BLKmode)
       {
  rtx cxx_new = assign_stack_temp (ext_mode,
          bitsize / 8, 0);

  emit_move_insn (cxx_new, op0);
  op0 = copy_rtx (cxx_new);
  ((op0)->mode = (BLKmode));
  ((op0)->in_struct) = 1;
       }

     return op0;
   }


 if (modifier == EXPAND_CONST_ADDRESS
     || modifier == EXPAND_SUM || modifier == EXPAND_INITIALIZER)
   op0 = gen_rtx (MEM, mode1, plus_constant_wide (((op0)->fld[0].rtx), (int) ((bitpos / 8)))
                                   );
 else
   op0 = change_address (op0, mode1,
    plus_constant_wide (((op0)->fld[0].rtx), (int) ((bitpos / 8)))
                                     );
 ((op0)->in_struct) = 1;
 ((op0)->volatil) |= volatilep;
 if (mode == mode1 || mode1 == BLKmode || mode1 == tmode)
   return op0;
 if (target == 0)
   target = gen_reg_rtx (tmode != VOIDmode ? tmode : mode);
 convert_move (target, op0, unsignedp);
 return target;
      }

    case OFFSET_REF:
      {
 tree base = build1 (ADDR_EXPR, type, ((exp)->exp.operands[0]));
 tree addr = build (PLUS_EXPR, type, base, ((exp)->exp.operands[1]));
 op0 = expand_expr (addr, (rtx) 0, VOIDmode, EXPAND_SUM);
 temp = gen_rtx (MEM, mode, memory_address (mode, op0));
 ((temp)->in_struct) = 1;
 ((temp)->volatil) = ((exp)->common.volatile_flag);





 return temp;
      }




    case BUFFER_REF:
      abort ();

    case IN_EXPR:
      {
 tree set = ((exp)->exp.operands[0]);
 tree strchr = ((exp)->exp.operands[1]);
 int iunsignedp = ((((strchr)->common.type))->common.unsigned_flag);
 tree set_type = ((set)->common.type);
 tree set_low_bound = ((((set_type)->type.values))->type.minval);
 tree set_high_bound = ((((set_type)->type.values))->type.maxval);
 rtx index_val = expand_expr (strchr, 0, VOIDmode, 0);
 rtx lo_r = expand_expr (set_low_bound, 0, VOIDmode, 0);
 rtx hi_r = expand_expr (set_high_bound, 0, VOIDmode, 0);
 rtx setval = expand_expr (set, 0, VOIDmode, 0);
 rtx setaddr = ((setval)->fld[0].rtx);
 n64_enum_machine_mode index_mode = ((((strchr)->common.type))->type.mode);
 rtx rlow;
 rtx diff, quo, rem, addr, bit, result;

 preexpand_calls (exp);



 if ((((n64_enum_tree_code) (set_high_bound)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (set_low_bound)->common.code) == INTEGER_CST
      && tree_int_cst_lt (set_high_bound, set_low_bound)
      || (((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (set_low_bound)->common.code) == INTEGER_CST
   && tree_int_cst_lt (strchr, set_low_bound))
      || (((n64_enum_tree_code) (set_high_bound)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
   && tree_int_cst_lt (set_high_bound, strchr))))
   return const0_rtx;

 if (target == 0)
   target = gen_reg_rtx (tmode != VOIDmode ? tmode : mode);




 op0 = gen_label_rtx ();
 op1 = gen_label_rtx ();

 if (! (((index_val)->code) == CONST_INT
        && ((lo_r)->code) == CONST_INT))
   {
     emit_cmp_insn (index_val, lo_r, LT, (rtx) 0,
      ((index_val)->mode), iunsignedp, 0);
     emit_jump_insn (gen_blt (op1));
   }

 if (! (((index_val)->code) == CONST_INT
        && ((hi_r)->code) == CONST_INT))
   {
     emit_cmp_insn (index_val, hi_r, GT, (rtx) 0,
      ((index_val)->mode), iunsignedp, 0);
     emit_jump_insn (gen_bgt (op1));
   }



 if (((lo_r)->code) == CONST_INT)
   rlow = gen_rtx (CONST_INT, VOIDmode, (int) (((lo_r)->fld[0].rtwint) & ~ ((int) 1 << 8)))
                                              ;
 else
   rlow = expand_binop (index_mode, and_optab, lo_r,
          gen_rtx (CONST_INT, VOIDmode, (int) (~((int) 1 << 8))),
          (rtx) 0, iunsignedp, OPTAB_LIB_WIDEN);

 diff = expand_binop (index_mode, sub_optab, index_val, rlow,
        (rtx) 0, iunsignedp, OPTAB_LIB_WIDEN);

 quo = expand_divmod (0, TRUNC_DIV_EXPR, index_mode, diff,
        gen_rtx (CONST_INT, VOIDmode, (int) (8)), (rtx) 0, iunsignedp);
 rem = expand_divmod (1, TRUNC_MOD_EXPR, index_mode, index_val,
        gen_rtx (CONST_INT, VOIDmode, (int) (8)), (rtx) 0, iunsignedp);

 addr = memory_address (byte_mode,
          expand_binop (index_mode, add_optab, diff,
          setaddr, (rtx) 0, iunsignedp,
          OPTAB_LIB_WIDEN));


 bit = expand_shift (RSHIFT_EXPR, byte_mode,
       gen_rtx (MEM, byte_mode, addr),
       make_tree (((strchr)->common.type), rem),
       (rtx) 0, 1);
 result = expand_binop (byte_mode, and_optab, bit, const1_rtx,
          ((target)->mode) == byte_mode ? target : 0,
          1, OPTAB_LIB_WIDEN);

 if (result != target)
   convert_move (target, result, 1);


 emit_jump (op0);
 emit_label (op1);
 emit_move_insn (target, const0_rtx);
 emit_label (op0);
 return target;
      }

    case WITH_CLEANUP_EXPR:
      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]) == 0)
 {
   (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1])
     = expand_expr (((exp)->exp.operands[0]), target, tmode, modifier);
   cleanups_this_call
     = tree_cons ((tree) 
                 ((void *)0)
                          , ((exp)->exp.operands[2]), cleanups_this_call);

   ((exp)->exp.operands[2]) = 0;
   (*interim_eh_hook) ((tree) 
                      ((void *)0)
                               );
 }
      return (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[1]);

    case CLEANUP_POINT_EXPR:
      {
 extern int temp_slot_level;
 tree old_cleanups = cleanups_this_call;
 int old_temp_level = target_temp_slot_level;
 push_temp_slots ();
 target_temp_slot_level = temp_slot_level;
 op0 = expand_expr (((exp)->exp.operands[0]), target, tmode, modifier);

 if (! ignore)
   op0 = force_not_mem (op0);
 expand_cleanups_to (old_cleanups);
 preserve_temp_slots (op0);
 free_temp_slots ();
 pop_temp_slots ();
 target_temp_slot_level = old_temp_level;
      }
      return op0;

    case CALL_EXPR:

      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == ADDR_EXPR
   && (((n64_enum_tree_code) (((((exp)->exp.operands[0]))->exp.operands[0]))->common.code)
       == FUNCTION_DECL)
   && ((((((exp)->exp.operands[0]))->exp.operands[0]))->decl.bit_field_flag))
 return expand_builtin (exp, target, subtarget, tmode, ignore);



      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) != 0)
 return (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]);

      return expand_call (exp, target, ignore);

    case NON_LVALUE_EXPR:
    case NOP_EXPR:
    case CONVERT_EXPR:
    case REFERENCE_EXPR:
      if (((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
 {
   tree valtype = ((((exp)->exp.operands[0]))->common.type);
   if (target == 0)
     {
       if (mode == BLKmode)
  {
    if (((type)->type.size) == 0
        || ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
      abort ();
    target = assign_stack_temp (BLKmode,
           (((((type)->type.size))->int_cst.int_cst_low)
            + 8 - 1)
           / 8, 0);
    ((target)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
  }
       else
  target = gen_reg_rtx (tmode != VOIDmode ? tmode : mode);
     }

   if (((target)->code) == MEM)

     store_expr (((exp)->exp.operands[0]),
   change_address (target, ((valtype)->type.mode), 0), 0);

   else if (((target)->code) == REG)

     store_field (target, (8 * mode_size[(int)(((valtype)->type.mode))]), 0,
    ((valtype)->type.mode), ((exp)->exp.operands[0]),
    VOIDmode, 0, 1,
    int_size_in_bytes (((((exp)->exp.operands[0]))->common.type)));
   else
     abort ();


   return target;
 }

      if (mode == ((((((exp)->exp.operands[0]))->common.type))->type.mode))
 {
   op0 = expand_expr (((exp)->exp.operands[0]), target, VOIDmode,
        modifier);




   if (((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag) != unsignedp
       && ((op0)->code) == SUBREG)
     ((op0)->in_struct) = 0;

   return op0;
 }

      op0 = expand_expr (((exp)->exp.operands[0]), (rtx) 0, mode, 0);
      if (((op0)->mode) == mode)
 return op0;


      if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
 return
   convert_modes (mode, ((((((exp)->exp.operands[0]))->common.type))->type.mode),
    op0, ((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag));

      if (modifier == EXPAND_INITIALIZER)
 return gen_rtx (unsignedp ? ZERO_EXTEND : SIGN_EXTEND, mode, op0);

      if (flag_force_mem && ((op0)->code) == MEM)
 op0 = copy_to_reg (op0);

      if (target == 0)
 return
   convert_to_mode (mode, op0,
      ((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag));
      else
 convert_move (target, op0,
        ((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag));
      return target;

    case PLUS_EXPR:

    plus_expr:
      this_optab = add_optab;
      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == PLUS_EXPR
   && ((n64_enum_tree_code) (((((exp)->exp.operands[0]))->exp.operands[1]))->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == RTL_EXPR
   && ((*(struct n64_tag_rtx_def **) &(((exp)->exp.operands[1]))->exp.operands[1]) == frame_pointer_rtx
       || (*(struct n64_tag_rtx_def **) &(((exp)->exp.operands[1]))->exp.operands[1]) == stack_pointer_rtx
       || (*(struct n64_tag_rtx_def **) &(((exp)->exp.operands[1]))->exp.operands[1]) == arg_pointer_rtx))
 {
   tree t = ((exp)->exp.operands[1]);

   ((exp)->exp.operands[1]) = ((((exp)->exp.operands[0]))->exp.operands[0]);
   ((((exp)->exp.operands[0]))->exp.operands[0]) = t;
 }
      if (modifier == EXPAND_SUM || modifier == EXPAND_INITIALIZER
   || mode == ptr_mode)
 {
   if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == INTEGER_CST
       && (8 * mode_size[(int)(mode)]) <= 32
       && ((((exp)->exp.operands[1]))->common.constant_flag))
     {
       op1 = expand_expr (((exp)->exp.operands[1]), subtarget, VOIDmode,
     EXPAND_SUM);
       op1 = plus_constant_wide (op1, (int) (((((exp)->exp.operands[0]))->int_cst.int_cst_low)));
       if (modifier != EXPAND_SUM && modifier != EXPAND_INITIALIZER)
  op1 = force_operand (op1, target);
       return op1;
     }

   else if (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST
     && (8 * mode_size[(int)(mode)]) <= 32
     && ((((exp)->exp.operands[0]))->common.constant_flag))
     {
       op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode,
     EXPAND_SUM);
       if (! (((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
  {
    op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0,
         VOIDmode, modifier);


    if (modifier != EXPAND_SUM && modifier != EXPAND_INITIALIZER)
      goto binop2;
    goto both_summands;
  }
       op0 = plus_constant_wide (op0, (int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low)));
       if (modifier != EXPAND_SUM && modifier != EXPAND_INITIALIZER)
  op0 = force_operand (op0, target);
       return op0;
     }
 }





      if ((modifier != EXPAND_SUM && modifier != EXPAND_INITIALIZER)
   || mode != ptr_mode)
 goto binop;

      preexpand_calls (exp);
      if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
 subtarget = 0;

      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, modifier);
      op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, modifier);

    both_summands:

      if (((op0)->code) == PLUS
   && (((((op0)->fld[1].rtx))->code) == LABEL_REF || ((((op0)->fld[1].rtx))->code) == SYMBOL_REF || ((((op0)->fld[1].rtx))->code) == CONST_INT || ((((op0)->fld[1].rtx))->code) == CONST_DOUBLE || ((((op0)->fld[1].rtx))->code) == CONST || ((((op0)->fld[1].rtx))->code) == HIGH))
 {
   temp = op0;
   op0 = op1;
   op1 = temp;
 }


      if (((op1)->code) == PLUS
   && (((((op1)->fld[1].rtx))->code) == LABEL_REF || ((((op1)->fld[1].rtx))->code) == SYMBOL_REF || ((((op1)->fld[1].rtx))->code) == CONST_INT || ((((op1)->fld[1].rtx))->code) == CONST_DOUBLE || ((((op1)->fld[1].rtx))->code) == CONST || ((((op1)->fld[1].rtx))->code) == HIGH))
 {
   rtx constant_term = const0_rtx;

   temp = simplify_binary_operation (PLUS, mode, ((op1)->fld[0].rtx), op0);
   if (temp != 0)
     op0 = temp;

   else if (((op0)->code) == MULT)
     op0 = gen_rtx (PLUS, mode, op0, ((op1)->fld[0].rtx));
   else
     op0 = gen_rtx (PLUS, mode, ((op1)->fld[0].rtx), op0);


   op0 = eliminate_constant_term (op0, &constant_term);





   temp = simplify_binary_operation (PLUS, mode, constant_term,
         ((op1)->fld[1].rtx));
   if (temp != 0)
     op1 = temp;
   else
     op1 = gen_rtx (PLUS, mode, constant_term, ((op1)->fld[1].rtx));
 }


      if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) || ((op1)->code) == MULT)
 temp = op1, op1 = op0, op0 = temp;

      temp = simplify_binary_operation (PLUS, mode, op0, op1);
      return temp ? temp : gen_rtx (PLUS, mode, op0, op1);

    case MINUS_EXPR:





      if ((modifier == EXPAND_SUM || modifier == EXPAND_INITIALIZER)
   && really_constant_p (((exp)->exp.operands[0]))
   && really_constant_p (((exp)->exp.operands[1])))
 {
   rtx op0 = expand_expr (((exp)->exp.operands[0]), (rtx) 0,
     VOIDmode, modifier);
   rtx op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0,
     VOIDmode, modifier);



   if (((op1)->code) == CONST_INT)
     return plus_constant_wide (op0, (int) (- ((op1)->fld[0].rtwint)));
   else
     return gen_rtx (MINUS, mode, op0, op1);
 }

      if (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST)
 {
   tree negated = fold (build1 (NEGATE_EXPR, type,
           ((exp)->exp.operands[1])));



   if (((type)->common.unsigned_flag) || ((negated)->common.public_flag))
     {
       tree newtype = signed_type (type);
       tree newop0 = convert (newtype, ((exp)->exp.operands[0]));
       tree newop1 = convert (newtype, ((exp)->exp.operands[1]));
       tree newneg = fold (build1 (NEGATE_EXPR, newtype, newop1));

       if (! ((newneg)->common.public_flag))
  return expand_expr (convert (type,
          build (PLUS_EXPR, newtype,
          newop0, newneg)),
        target, tmode, modifier);
     }
   else
     {
       exp = build (PLUS_EXPR, type, ((exp)->exp.operands[0]), negated);
       goto plus_expr;
     }
 }
      this_optab = sub_optab;
      goto binop;

    case MULT_EXPR:
      preexpand_calls (exp);



      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == INTEGER_CST)
 {
   register tree t1 = ((exp)->exp.operands[0]);
   ((exp)->exp.operands[0]) = ((exp)->exp.operands[1]);
   ((exp)->exp.operands[1]) = t1;
 }




      if (modifier == EXPAND_SUM && mode == ptr_mode
   && ((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST
   && (8 * mode_size[(int)(mode)]) <= 32)
 {
   op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, EXPAND_SUM);


   if (((op0)->code) == PLUS
       && ((((op0)->fld[1].rtx))->code) == CONST_INT)
     return gen_rtx (PLUS, mode,
       gen_rtx (MULT, mode, ((op0)->fld[0].rtx),
         gen_rtx (CONST_INT, VOIDmode, (int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low)))),
       gen_rtx (CONST_INT, VOIDmode, (int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low) * ((((op0)->fld[1].rtx))->fld[0].rtwint)))
                                  );

   if (((op0)->code) != REG)
     op0 = force_operand (op0, (rtx) 0);
   if (((op0)->code) != REG)
     op0 = copy_to_mode_reg (mode, op0);

   return gen_rtx (MULT, mode, op0,
     gen_rtx (CONST_INT, VOIDmode, (int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low))));
 }

      if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
 subtarget = 0;





      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == NOP_EXPR
   && ((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
   && (((((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))->type.precision)
       < ((((((exp)->exp.operands[0]))->common.type))->type.precision))
   && ((((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST
        && int_fits_type_p (((exp)->exp.operands[1]),
       ((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))

        && (((8 * mode_size[(int)(((((((exp)->exp.operands[1]))->common.type))->type.mode))])
      > 32)
     || exact_log2_wide ((int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low))) < 0))
       ||
       (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == NOP_EXPR
        && (((((((((exp)->exp.operands[1]))->exp.operands[0]))->common.type))->type.precision)
     ==
     ((((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))->type.precision))


        && (((((((((exp)->exp.operands[1]))->exp.operands[0]))->common.type))->common.unsigned_flag)
     ==
     ((((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))->common.unsigned_flag)))))
 {
   n64_enum_machine_mode innermode
     = ((((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))->type.mode);
   this_optab = (((((((((exp)->exp.operands[0]))->exp.operands[0]))->common.type))->common.unsigned_flag)
   ? umul_widen_optab : smul_widen_optab);
   if (mode == (mode_wider_mode[(int)(innermode)])
       && this_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
     {
       op0 = expand_expr (((((exp)->exp.operands[0]))->exp.operands[0]),
     (rtx) 0, VOIDmode, 0);
       if (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST)
  op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0,
       VOIDmode, 0);
       else
  op1 = expand_expr (((((exp)->exp.operands[1]))->exp.operands[0]),
       (rtx) 0, VOIDmode, 0);
       goto binop2;
     }
 }
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
      return expand_mult (mode, op0, op1, target, unsignedp);

    case TRUNC_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case EXACT_DIV_EXPR:
      preexpand_calls (exp);
      if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
 subtarget = 0;



      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
      return expand_divmod (0, code, mode, op0, op1, target, unsignedp);

    case RDIV_EXPR:
      this_optab = flodiv_optab;
      goto binop;

    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
    case CEIL_MOD_EXPR:
    case ROUND_MOD_EXPR:
      preexpand_calls (exp);
      if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
 subtarget = 0;
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
      return expand_divmod (1, code, mode, op0, op1, target, unsignedp);

    case FIX_ROUND_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_CEIL_EXPR:
      abort ();

    case FIX_TRUNC_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), (rtx) 0, VOIDmode, 0);
      if (target == 0)
 target = gen_reg_rtx (mode);
      expand_fix (target, op0, unsignedp);
      return target;

    case FLOAT_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), (rtx) 0, VOIDmode, 0);
      if (target == 0)
 target = gen_reg_rtx (mode);


      if (((op0)->mode) == VOIDmode)
 op0 = copy_to_mode_reg (((((((exp)->exp.operands[0]))->common.type))->type.mode),
    op0);
      expand_float (target, op0,
      ((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag));
      return target;

    case NEGATE_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      temp = expand_unop (mode, neg_optab, op0, target, 0);
      if (temp == 0)
 abort ();
      return temp;

    case ABS_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);


      if ((mode_class[(int)(mode)]) == MODE_COMPLEX_INT
   || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT)
 return expand_complex_abs (mode, op0, target, unsignedp);



      if (((type)->common.unsigned_flag))
 return op0;

      return expand_abs (mode, op0, target, unsignedp,
    safe_from_p (target, ((exp)->exp.operands[0])));

    case MAX_EXPR:
    case MIN_EXPR:
      target = original_target;
      if (target == 0 || ! safe_from_p (target, ((exp)->exp.operands[1]))
   || (((target)->code) == MEM && ((target)->volatil))
   || ((target)->mode) != mode
   || (((target)->code) == REG
       && ((target)->fld[0].rtint) < 68))
 target = gen_reg_rtx (mode);
      op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
      op0 = expand_expr (((exp)->exp.operands[0]), target, VOIDmode, 0);




      this_optab = (((type)->common.unsigned_flag)
      ? (code == MIN_EXPR ? umin_optab : umax_optab)
      : (code == MIN_EXPR ? smin_optab : smax_optab));

      temp = expand_binop (mode, this_optab, op0, op1, target, unsignedp,
      OPTAB_WIDEN);
      if (temp != 0)
 return temp;




      if (((target)->code) == MEM)
 target = gen_reg_rtx (mode);

      if (target != op0)
 emit_move_insn (target, op0);

      op0 = gen_label_rtx ();



      if ((mode_class[(int)(mode)]) == MODE_INT && !can_compare_p (mode))
 {
   if (code == MAX_EXPR)
     do_jump_by_parts_greater_rtx (mode, ((type)->common.unsigned_flag),
       target, op1, (rtx) 0, op0);
   else
     do_jump_by_parts_greater_rtx (mode, ((type)->common.unsigned_flag),
       op1, target, (rtx) 0, op0);
   emit_move_insn (target, op1);
 }
      else
 {
   if (code == MAX_EXPR)
     temp = (((((((exp)->exp.operands[1]))->common.type))->common.unsigned_flag)
      ? compare_from_rtx (target, op1, GEU, 1, mode, (rtx) 0, 0)
      : compare_from_rtx (target, op1, GE, 0, mode, (rtx) 0, 0));
   else
     temp = (((((((exp)->exp.operands[1]))->common.type))->common.unsigned_flag)
      ? compare_from_rtx (target, op1, LEU, 1, mode, (rtx) 0, 0)
      : compare_from_rtx (target, op1, LE, 0, mode, (rtx) 0, 0));
   if (temp == const0_rtx)
     emit_move_insn (target, op1);
   else if (temp != const_true_rtx)
     {
       if (bcc_gen_fctn[(int) ((temp)->code)] != 0)
  emit_jump_insn ((*bcc_gen_fctn[(int) ((temp)->code)]) (op0));
       else
  abort ();
       emit_move_insn (target, op1);
     }
 }
      emit_label (op0);
      return target;

    case BIT_NOT_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      temp = expand_unop (mode, one_cmpl_optab, op0, target, 1);
      if (temp == 0)
 abort ();
      return temp;

    case FFS_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      temp = expand_unop (mode, ffs_optab, op0, target, 1);
      if (temp == 0)
 abort ();
      return temp;
    case TRUTH_AND_EXPR:
    case BIT_AND_EXPR:
      this_optab = and_optab;
      goto binop;

    case TRUTH_OR_EXPR:
    case BIT_IOR_EXPR:
      this_optab = ior_optab;
      goto binop;

    case TRUTH_XOR_EXPR:
    case BIT_XOR_EXPR:
      this_optab = xor_optab;
      goto binop;

    case LSHIFT_EXPR:
    case RSHIFT_EXPR:
    case LROTATE_EXPR:
    case RROTATE_EXPR:
      preexpand_calls (exp);
      if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
 subtarget = 0;
      op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
      return expand_shift (code, mode, op0, ((exp)->exp.operands[1]), target,
      unsignedp);



    case LT_EXPR:
    case LE_EXPR:
    case GT_EXPR:
    case GE_EXPR:
    case EQ_EXPR:
    case NE_EXPR:
      preexpand_calls (exp);
      temp = do_store_flag (exp, target, tmode != VOIDmode ? tmode : mode, 0);
      if (temp != 0)
 return temp;


      if (code == NE_EXPR && integer_zerop (((exp)->exp.operands[1]))
   && original_target
   && ((original_target)->code) == REG
   && (((original_target)->mode)
       == ((((((exp)->exp.operands[0]))->common.type))->type.mode)))
 {
   temp = expand_expr (((exp)->exp.operands[0]), original_target,
         VOIDmode, 0);

   if (temp != original_target)
     temp = copy_to_reg (temp);

   op1 = gen_label_rtx ();
   emit_cmp_insn (temp, const0_rtx, EQ, (rtx) 0,
    ((temp)->mode), unsignedp, 0);
   emit_jump_insn (gen_beq (op1));
   emit_move_insn (temp, const1_rtx);
   emit_label (op1);
   return temp;
 }





    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
      if (! ignore
   && (target == 0 || ! safe_from_p (target, exp)


       || (!optimize && ((target)->code) == REG
    && ((target)->fld[0].rtint) < 68)))
 target = gen_reg_rtx (tmode != VOIDmode ? tmode : mode);

      if (target)
 emit_clr_insn (target);

      op1 = gen_label_rtx ();
      jumpifnot (exp, op1);

      if (target)
 emit_0_to_1_insn (target);

      emit_label (op1);
      return ignore ? const0_rtx : target;

    case TRUTH_NOT_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), target, VOIDmode, 0);


      temp = expand_binop (mode, xor_optab, op0, const1_rtx,
      target, 1, OPTAB_LIB_WIDEN);
      if (temp == 0)
 abort ();
      return temp;

    case COMPOUND_EXPR:
      expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode, 0);
      emit_queue ();
      return expand_expr (((exp)->exp.operands[1]),
     (ignore ? const0_rtx : target),
     VOIDmode, 0);

    case COND_EXPR:
      {
 rtx flag = (rtx) 0;
 tree left_cleanups = (tree) 
                     ((void *)0)
                              ;
 tree right_cleanups = (tree) 
                      ((void *)0)
                               ;





 rtx dest_right_flag = (rtx) 0;
 rtx dest_left_flag = (rtx) 0;
 tree singleton = 0;
 tree binary_op = 0, unary_op = 0;
 tree old_cleanups = cleanups_this_call;



 if (integer_onep (((exp)->exp.operands[1]))
     && integer_zerop (((exp)->exp.operands[2]))
     && (*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code))]) == '<')
   {
     if (ignore)
       {
  expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode,
        modifier);
  return const0_rtx;
       }

     op0 = expand_expr (((exp)->exp.operands[0]), target, mode, modifier);
     if (((op0)->mode) == mode)
       return op0;

     if (target == 0)
       target = gen_reg_rtx (mode);
     convert_move (target, op0, unsignedp);
     return target;
   }






 if (ignore)
   temp = 0;
 else if (original_target
   && safe_from_p (original_target, ((exp)->exp.operands[0]))
   && ((original_target)->mode) == mode
   && ! (((original_target)->code) == MEM
         && ((original_target)->volatil)))
   temp = original_target;
 else if (mode == BLKmode)
   {
     if (((type)->type.size) == 0
  || ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
       abort ();

     temp = assign_stack_temp (BLKmode,
          (((((type)->type.size))->int_cst.int_cst_low)
           + 8 - 1)
          / 8, 0);
     ((temp)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
   }
 else
   temp = gen_reg_rtx (mode);







 if ((*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code))]) == '2'
     && operand_equal_p (((exp)->exp.operands[2]),
    ((((exp)->exp.operands[1]))->exp.operands[0]), 0))
   singleton = ((exp)->exp.operands[2]), binary_op = ((exp)->exp.operands[1]);
 else if ((*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[2]))->common.code))]) == '2'
   && operand_equal_p (((exp)->exp.operands[1]),
         ((((exp)->exp.operands[2]))->exp.operands[0]), 0))
   singleton = ((exp)->exp.operands[1]), binary_op = ((exp)->exp.operands[2]);
 else if ((*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code))]) == '1'
   && operand_equal_p (((exp)->exp.operands[2]),
         ((((exp)->exp.operands[1]))->exp.operands[0]), 0))
   singleton = ((exp)->exp.operands[2]), unary_op = ((exp)->exp.operands[1]);
 else if ((*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[2]))->common.code))]) == '1'
   && operand_equal_p (((exp)->exp.operands[1]),
         ((((exp)->exp.operands[2]))->exp.operands[0]), 0))
   singleton = ((exp)->exp.operands[1]), unary_op = ((exp)->exp.operands[2]);




 if (temp && singleton && binary_op
     && ! ((((exp)->exp.operands[0]))->common.side_effects_flag)
     && (((n64_enum_tree_code) (binary_op)->common.code) == PLUS_EXPR
  || ((n64_enum_tree_code) (binary_op)->common.code) == MINUS_EXPR
  || ((n64_enum_tree_code) (binary_op)->common.code) == BIT_IOR_EXPR
  || ((n64_enum_tree_code) (binary_op)->common.code) == BIT_XOR_EXPR)
     && integer_onep (((binary_op)->exp.operands[1]))
     && (*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code))]) == '<')
   {
     rtx result;
     optab boptab = (((n64_enum_tree_code) (binary_op)->common.code) == PLUS_EXPR ? add_optab
       : ((n64_enum_tree_code) (binary_op)->common.code) == MINUS_EXPR ? sub_optab
       : ((n64_enum_tree_code) (binary_op)->common.code) == BIT_IOR_EXPR ? ior_optab
       : xor_optab);
     if (singleton == ((exp)->exp.operands[1]))
       ((exp)->exp.operands[0])
  = invert_truthvalue (((exp)->exp.operands[0]));

     result = do_store_flag (((exp)->exp.operands[0]),
        (safe_from_p (temp, singleton)
         ? temp : (rtx) 0),
        mode, ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) <= 1);

     if (result)
       {
  op1 = expand_expr (singleton, (rtx) 0, VOIDmode, 0);
  return expand_binop (mode, boptab, op1, result, temp,
         unsignedp, OPTAB_LIB_WIDEN);
       }
     else if (singleton == ((exp)->exp.operands[1]))
       ((exp)->exp.operands[0])
  = invert_truthvalue (((exp)->exp.operands[0]));
   }

 do_pending_stack_adjust ();
 (inhibit_defer_pop += 1);
 op0 = gen_label_rtx ();

 flag = gen_reg_rtx (word_mode);
 if (singleton && ! ((((exp)->exp.operands[0]))->common.side_effects_flag))
   {
     if (temp != 0)
       {




  if ((binary_op
       && ! safe_from_p (temp, ((binary_op)->exp.operands[1])))
      || (((temp)->code) == REG
   && ((temp)->fld[0].rtint) < 68))
    temp = gen_reg_rtx (mode);
  store_expr (singleton, temp, 0);
       }
     else
       expand_expr (singleton,
      ignore ? const0_rtx : (rtx) 0, VOIDmode, 0);
     dest_left_flag = get_last_insn ();
     if (singleton == ((exp)->exp.operands[1]))
       jumpif (((exp)->exp.operands[0]), op0);
     else
       jumpifnot (((exp)->exp.operands[0]), op0);


     old_cleanups = cleanups_this_call;
     if (binary_op && temp == 0)

       expand_expr (((binary_op)->exp.operands[1]),
      ignore ? const0_rtx : (rtx) 0, VOIDmode, 0);
     else if (binary_op)
       store_expr (build (((n64_enum_tree_code) (binary_op)->common.code), type,
     make_tree (type, temp),
     ((binary_op)->exp.operands[1])),
     temp, 0);
     else
       store_expr (build1 (((n64_enum_tree_code) (unary_op)->common.code), type,
      make_tree (type, temp)),
     temp, 0);
     op1 = op0;
     dest_right_flag = get_last_insn ();
   }
 else if (temp
   && (*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code))]) == '<'
   && integer_zerop (((((exp)->exp.operands[0]))->exp.operands[1]))
   && operand_equal_p (((((exp)->exp.operands[0]))->exp.operands[0]),
         ((exp)->exp.operands[1]), 0)
   && ! ((((exp)->exp.operands[0]))->common.side_effects_flag)
   && safe_from_p (temp, ((exp)->exp.operands[2])))
   {
     if (((temp)->code) == REG && ((temp)->fld[0].rtint) < 68)
       temp = gen_reg_rtx (mode);
     store_expr (((exp)->exp.operands[1]), temp, 0);
     dest_left_flag = get_last_insn ();
     jumpif (((exp)->exp.operands[0]), op0);


     old_cleanups = cleanups_this_call;
     store_expr (((exp)->exp.operands[2]), temp, 0);
     op1 = op0;
     dest_right_flag = get_last_insn ();
   }
 else if (temp
   && (*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code))]) == '<'
   && integer_zerop (((((exp)->exp.operands[0]))->exp.operands[1]))
   && operand_equal_p (((((exp)->exp.operands[0]))->exp.operands[0]),
         ((exp)->exp.operands[2]), 0)
   && ! ((((exp)->exp.operands[0]))->common.side_effects_flag)
   && safe_from_p (temp, ((exp)->exp.operands[1])))
   {
     if (((temp)->code) == REG && ((temp)->fld[0].rtint) < 68)
       temp = gen_reg_rtx (mode);
     store_expr (((exp)->exp.operands[2]), temp, 0);
     dest_left_flag = get_last_insn ();
     jumpifnot (((exp)->exp.operands[0]), op0);


     old_cleanups = cleanups_this_call;
     store_expr (((exp)->exp.operands[1]), temp, 0);
     op1 = op0;
     dest_right_flag = get_last_insn ();
   }
 else
   {
     op1 = gen_label_rtx ();
     jumpifnot (((exp)->exp.operands[0]), op0);


     old_cleanups = cleanups_this_call;
     if (temp != 0)
       store_expr (((exp)->exp.operands[1]), temp, 0);
     else
       expand_expr (((exp)->exp.operands[1]),
      ignore ? const0_rtx : (rtx) 0, VOIDmode, 0);
     dest_left_flag = get_last_insn ();


     left_cleanups = defer_cleanups_to (old_cleanups);

     emit_queue ();
     emit_jump_insn (gen_jump (op1));
     emit_barrier ();
     emit_label (op0);
     if (temp != 0)
       store_expr (((exp)->exp.operands[2]), temp, 0);
     else
       expand_expr (((exp)->exp.operands[2]),
      ignore ? const0_rtx : (rtx) 0, VOIDmode, 0);
     dest_right_flag = get_last_insn ();
   }


 right_cleanups = defer_cleanups_to (old_cleanups);

 emit_queue ();
 emit_label (op1);
 (inhibit_defer_pop -= 1);


 if (left_cleanups || right_cleanups)
   {
     tree new_cleanups;
     tree cond;
     rtx last;





     last = get_last_insn ();

     emit_move_insn (flag, const1_rtx);

     reorder_insns (((last)->fld[2].rtx), get_last_insn (), dest_left_flag);


     last = get_last_insn ();

     emit_move_insn (flag, const0_rtx);

     reorder_insns (((last)->fld[2].rtx), get_last_insn (), dest_right_flag);


     cond = make_node (RTL_EXPR);
     ((cond)->common.type) = integer_type_node;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[1]) = flag;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[0]) = (rtx) 0;
     cond = save_expr (cond);

     if (! left_cleanups)
       left_cleanups = integer_zero_node;
     if (! right_cleanups)
       right_cleanups = integer_zero_node;
     new_cleanups = build (COND_EXPR, void_type_node,
      truthvalue_conversion (cond),
      left_cleanups, right_cleanups);
     new_cleanups = fold (new_cleanups);


     cleanups_this_call
       = tree_cons ((tree) 
                   ((void *)0)
                            , new_cleanups, cleanups_this_call);
     (*interim_eh_hook) ((tree) 
                        ((void *)0)
                                 );
   }
 return temp;
      }

    case TARGET_EXPR:
      {
 int need_exception_region = 0;
 tree slot = ((exp)->exp.operands[0]);
 tree exp1;
 rtx temp;

 if (((n64_enum_tree_code) (slot)->common.code) != VAR_DECL)
   abort ();

 if (! ignore)
   target = original_target;

 if (target == 0)
   {
     if (((slot)->decl.rtl) != 0)
       {
  target = ((slot)->decl.rtl);


  if (((exp)->exp.operands[1]) == (tree) 
                              ((void *)0)
                                       )
    return target;
       }
     else
       {
  target = assign_stack_temp (mode, int_size_in_bytes (type), 2);
  ((target)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);

  preserve_temp_slots (target);
  ((slot)->decl.rtl) = target;
  if (((exp)->exp.operands[2]) == 0)
    ((exp)->exp.operands[2]) = maybe_build_cleanup (slot);
  if (((exp)->exp.operands[2]))
    {
      cleanups_this_call = tree_cons ((tree) 
                                     ((void *)0)
                                              ,
          ((exp)->exp.operands[2]),
          cleanups_this_call);
      need_exception_region = 1;
    }
       }
   }
 else
   {
     if (((slot)->decl.rtl) != 0)
              {
                target = ((slot)->decl.rtl);


                if (((exp)->exp.operands[1]) == (tree) 
                                            ((void *)0)
                                                     )
                  return target;
       }

     ((slot)->decl.rtl) = target;
   }

 exp1 = ((exp)->exp.operands[1]);

 ((exp)->exp.operands[1]) = (tree) 
                        ((void *)0)
                                 ;

 temp = expand_expr (exp1, target, tmode, modifier);

 if (need_exception_region)
   (*interim_eh_hook) ((tree) 
                      ((void *)0)
                               );

 return temp;
      }

    case INIT_EXPR:
      {
 tree lhs = ((exp)->exp.operands[0]);
 tree rhs = ((exp)->exp.operands[1]);
 tree noncopied_parts = 0;
 tree lhs_type = ((lhs)->common.type);

 temp = expand_assignment (lhs, rhs, ! ignore, original_target != 0);
 if (((lhs_type)->type.noncopied_parts) != 0 && !fixed_type_p (rhs))
   noncopied_parts = init_noncopied_parts (stabilize_reference (lhs),
        ((lhs_type)->type.noncopied_parts));
 while (noncopied_parts != 0)
   {
     expand_assignment (((noncopied_parts)->list.value),
          ((noncopied_parts)->list.purpose), 0, 0);
     noncopied_parts = ((noncopied_parts)->common.chain);
   }
 return temp;
      }

    case MODIFY_EXPR:
      {







 tree lhs = ((exp)->exp.operands[0]);
 tree rhs = ((exp)->exp.operands[1]);
 tree noncopied_parts = 0;
 tree lhs_type = ((lhs)->common.type);

 temp = 0;

 if (((n64_enum_tree_code) (lhs)->common.code) != VAR_DECL
     && ((n64_enum_tree_code) (lhs)->common.code) != RESULT_DECL
     && ((n64_enum_tree_code) (lhs)->common.code) != PARM_DECL)
   preexpand_calls (exp);
 if (ignore
     && ((n64_enum_tree_code) (lhs)->common.code) == COMPONENT_REF
     && (((n64_enum_tree_code) (rhs)->common.code) == BIT_IOR_EXPR
  || ((n64_enum_tree_code) (rhs)->common.code) == BIT_AND_EXPR)
     && ((rhs)->exp.operands[0]) == lhs
     && ((n64_enum_tree_code) (((rhs)->exp.operands[1]))->common.code) == COMPONENT_REF
     && ((((((lhs)->exp.operands[1]))->decl.size))->int_cst.int_cst_low) == 1
     && ((((((((rhs)->exp.operands[1]))->exp.operands[1]))->decl.size))->int_cst.int_cst_low) == 1)
   {
     rtx label = gen_label_rtx ();

     do_jump (((rhs)->exp.operands[1]),
       ((n64_enum_tree_code) (rhs)->common.code) == BIT_IOR_EXPR ? label : 0,
       ((n64_enum_tree_code) (rhs)->common.code) == BIT_AND_EXPR ? label : 0);
     expand_assignment (lhs, convert (((rhs)->common.type),
          (((n64_enum_tree_code) (rhs)->common.code) == BIT_IOR_EXPR
           ? integer_one_node
           : integer_zero_node)),
          0, 0);
     do_pending_stack_adjust ();
     emit_label (label);
     return const0_rtx;
   }

 if (((lhs_type)->type.noncopied_parts) != 0
     && ! (fixed_type_p (lhs) && fixed_type_p (rhs)))
   noncopied_parts = save_noncopied_parts (stabilize_reference (lhs),
        ((lhs_type)->type.noncopied_parts));

 temp = expand_assignment (lhs, rhs, ! ignore, original_target != 0);
 while (noncopied_parts != 0)
   {
     expand_assignment (((noncopied_parts)->list.purpose),
          ((noncopied_parts)->list.value), 0, 0);
     noncopied_parts = ((noncopied_parts)->common.chain);
   }
 return temp;
      }

    case PREINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
      return expand_increment (exp, 0);

    case POSTINCREMENT_EXPR:
    case POSTDECREMENT_EXPR:

      return expand_increment (exp, ! ignore);

    case ADDR_EXPR:


      temp = 0;


      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == FUNCTION_DECL
   && decl_function_context (((exp)->exp.operands[0])) != 0)
 {
   op0 = trampoline_address (((exp)->exp.operands[0]));
   op0 = force_operand (op0, target);
 }


      else if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == ERROR_MARK)
 return const0_rtx;
      else
 {


   op0 = expand_expr (((exp)->exp.operands[0]),
        ignore ? const0_rtx : (rtx) 0, VOIDmode,
        (modifier == EXPAND_INITIALIZER
         ? modifier : EXPAND_CONST_ADDRESS));




   if (ignore)
     return op0;






   if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
     op0 = force_const_mem (((((((exp)->exp.operands[0]))->common.type))->type.mode),
       op0);
   else if (((op0)->code) == MEM)
     {
       mark_temp_addr_taken (op0);
       temp = ((op0)->fld[0].rtx);
     }

   else if (((op0)->code) == REG || ((op0)->code) == SUBREG
     || ((op0)->code) == CONCAT)
     {


       tree inner_type = ((((exp)->exp.operands[0]))->common.type);
       n64_enum_machine_mode inner_mode = ((inner_type)->type.mode);
       rtx memloc
  = assign_stack_temp (inner_mode,
         int_size_in_bytes (inner_type), 1);
       ((memloc)->in_struct) = (((n64_enum_tree_code) (inner_type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (inner_type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (inner_type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (inner_type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (inner_type)->common.code) == SET_TYPE);

       mark_temp_addr_taken (memloc);
       emit_move_insn (memloc, op0);
       op0 = memloc;
     }

   if (((op0)->code) != MEM)
     abort ();

   if (modifier == EXPAND_SUM || modifier == EXPAND_INITIALIZER)
     {
       temp = ((op0)->fld[0].rtx);





       return temp;
     }

   op0 = force_operand (((op0)->fld[0].rtx), target);
 }

      if (flag_force_addr && ((op0)->code) != REG)
 op0 = force_reg (((target_flags & 0x00000002) ? DImode : SImode), op0);

      if (((op0)->code) == REG)
 mark_reg_pointer (op0);



      if (temp != 0)
 update_temp_slot_address (temp, op0);







      return op0;

    case ENTRY_VALUE_EXPR:
      abort ();


    case COMPLEX_EXPR:
      {
 n64_enum_machine_mode mode = ((((((exp)->common.type))->common.type))->type.mode);
 rtx insns;


 op0 = expand_expr (((exp)->exp.operands[0]), 0, VOIDmode, 0);
 op1 = expand_expr (((exp)->exp.operands[1]), 0, VOIDmode, 0);

 if (! target)
   target = gen_reg_rtx (((((exp)->common.type))->type.mode));

 start_sequence ();


 emit_move_insn (gen_realpart (mode, target), op0);
 emit_move_insn (gen_imagpart (mode, target), op1);

 insns = get_insns ();
 end_sequence ();





 if (((target)->code) != CONCAT)
   emit_no_conflict_block (insns, target, op0, op1, (rtx) 0);
 else
   emit_insns (insns);

 return target;
      }

    case REALPART_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), 0, VOIDmode, 0);
      return gen_realpart (mode, op0);

    case IMAGPART_EXPR:
      op0 = expand_expr (((exp)->exp.operands[0]), 0, VOIDmode, 0);
      return gen_imagpart (mode, op0);

    case CONJ_EXPR:
      {
 n64_enum_machine_mode partmode = ((((((exp)->common.type))->common.type))->type.mode);
 rtx imag_t;
 rtx insns;

 op0 = expand_expr (((exp)->exp.operands[0]), 0, VOIDmode, 0);

 if (! target)
   target = gen_reg_rtx (mode);

 start_sequence ();


 emit_move_insn (gen_realpart (partmode, target),
   gen_realpart (partmode, op0));

 imag_t = gen_imagpart (partmode, target);
 temp = expand_unop (partmode, neg_optab,
          gen_imagpart (partmode, op0), imag_t, 0);
 if (temp != imag_t)
   emit_move_insn (imag_t, temp);

 insns = get_insns ();
 end_sequence ();





 if (((target)->code) != CONCAT)
   emit_no_conflict_block (insns, target, op0, (rtx) 0, (rtx) 0);
 else
   emit_insns (insns);

 return target;
      }

    case ERROR_MARK:
      op0 = (const_tiny_rtx[0][(int) (tmode)]);
      if (op0 != 0)
 return op0;
      return const0_rtx;

    default:
      return (*lang_expand_expr) (exp, original_target, tmode, modifier);
    }



 binop:
  preexpand_calls (exp);
  if (! safe_from_p (subtarget, ((exp)->exp.operands[1])))
    subtarget = 0;
  op0 = expand_expr (((exp)->exp.operands[0]), subtarget, VOIDmode, 0);
  op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
 binop2:
  temp = expand_binop (mode, this_optab, op0, op1, target,
         unsignedp, OPTAB_LIB_WIDEN);
  if (temp == 0)
    abort ();
  return temp;
}



void
bc_expand_expr(tree exp) asm("_bc_expand_expr");
void
bc_expand_expr(tree exp)
{
  n64_enum_tree_code code;
  tree type, arg0;
  rtx r;
  struct n64_tag_binary_operator *binoptab;
  struct n64_tag_unary_operator *unoptab;
  struct n64_tag_increment_operator *incroptab;
  struct n64_tag_bc_label *lab, *lab1;
  n64_enum_bytecode_opcode opcode;


  code = ((n64_enum_tree_code) (exp)->common.code);

  switch (code)
    {
    case PARM_DECL:

      if (((exp)->decl.rtl) == 0)
 {
   error_with_decl (exp, "prior parameter's size depends on `%s'");
   return;
 }

      bc_load_parmaddr (((exp)->decl.rtl));
      bc_load_memory (((exp)->common.type), exp);

      return;

    case VAR_DECL:

      if (((exp)->decl.rtl) == 0)
 abort ();







      if (((exp)->common.public_flag))
 bc_load_externaddr_id (((exp)->decl.assembler_name),
          (*(struct n64_tag_bc_label **) &(((((exp)->decl.rtl)))->fld[1].rtx))->offset);
      else
 bc_load_localaddr (((exp)->decl.rtl));

      bc_load_memory (((exp)->common.type), exp);
      return;

    case INTEGER_CST:




      bc_emit_instruction (mode_to_const_map[(int) (((exp)->decl.bit_field_flag)
          ? SImode
          : ((((exp)->common.type))->type.mode))],
      (int) ((exp)->int_cst.int_cst_low));
      return;

    case REAL_CST:
      abort ();


      return;

    case CALL_EXPR:
      {
 tree calldesc = 0, arg;
 int nargs = 0, i;
 rtx retval;





 ((exp)->exp.operands[1]) = nreverse (((exp)->exp.operands[1]));

 for (arg = ((exp)->exp.operands[1]); arg; arg = ((arg)->common.chain))
   {
     ++nargs;
     bc_expand_expr (((arg)->list.value));

     calldesc = tree_cons ((tree) 0,
      size_in_bytes (((((arg)->list.value))->common.type)),
      calldesc);
     calldesc = tree_cons ((tree) 0,
      bc_runtime_type_code (((((arg)->list.value))->common.type)),
      calldesc);
   }

 ((exp)->exp.operands[1]) = nreverse (((exp)->exp.operands[1]));





 type = ((((((((exp)->exp.operands[0]))->common.type))->common.type))->common.type);
 retval = bc_allocate_local (int_size_in_bytes (type), ((type)->type.align));
 bc_load_localaddr (retval);

 calldesc = tree_cons ((tree) 0, size_in_bytes (type), calldesc);
 calldesc = tree_cons ((tree) 0, bc_runtime_type_code (type), calldesc);


 calldesc = tree_cons ((tree) 0,
         build_int_2_wide ((int) (nargs), (int) (0)),
         calldesc);


 calldesc = build_nt (CONSTRUCTOR, (tree) 0, calldesc);
 ((calldesc)->common.type) = build_array_type (integer_type_node,
       build_index_type (build_int_2_wide ((int) (nargs * 2), (int) (0))));
 r = output_constant_def (calldesc);
 bc_load_externaddr (r);


 bc_expand_expr (((exp)->exp.operands[0]));



 bc_emit_instruction (call);


 bc_adjust_stack (nargs);


 bc_load_localaddr (retval);
 bc_load_memory (type, ((exp)->exp.operands[0]));
      }
      return;

    case SAVE_EXPR:

      if (!(*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]))
 {

   (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) = bc_allocate_local (int_size_in_bytes (((exp)->common.type)),
         ((((exp)->common.type))->type.align));
   bc_expand_expr (((exp)->exp.operands[0]));
   bc_emit_instruction (duplicate);

   bc_load_localaddr ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]));
   bc_store_memory (((exp)->common.type), ((exp)->exp.operands[0]));
 }
      else
 {

   bc_load_localaddr ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]));
   bc_load_memory (((exp)->common.type), ((exp)->exp.operands[0]));
 }
      return;
    case NOP_EXPR:
    case CONVERT_EXPR:

      bc_expand_expr (((exp)->exp.operands[0]));
      bc_expand_conversion (((((exp)->exp.operands[0]))->common.type), ((exp)->common.type));
      return;

    case MODIFY_EXPR:

      expand_assignment (((exp)->exp.operands[0]), ((exp)->exp.operands[1]), 0, 0);
      return;

    case ADDR_EXPR:

      bc_expand_address (((exp)->exp.operands[0]));
      return;

    case INDIRECT_REF:

      bc_expand_expr (((exp)->exp.operands[0]));
      bc_load_memory (((exp)->common.type), ((exp)->exp.operands[0]));
      return;

    case ARRAY_REF:

      bc_expand_expr (bc_canonicalize_array_ref (exp));
      return;

    case COMPONENT_REF:

      bc_expand_component_address (exp);


      bc_load_memory (((((exp)->exp.operands[1]))->common.type), ((exp)->exp.operands[1]));
      return;

    case COMPOUND_EXPR:

      bc_expand_expr (((exp)->exp.operands[0]));
      bc_emit_instruction (drop);
      bc_expand_expr (((exp)->exp.operands[1]));
      return;

    case COND_EXPR:

      bc_expand_expr (((exp)->exp.operands[0]));
      bc_expand_truth_conversion (((((exp)->exp.operands[0]))->common.type));
      lab = bc_get_bytecode_label ();
      bc_emit_bytecode (xjumpifnot);
      bc_emit_bytecode_labelref (lab);




      bc_expand_expr (((exp)->exp.operands[1]));
      lab1 = bc_get_bytecode_label ();
      bc_emit_bytecode (jump);
      bc_emit_bytecode_labelref (lab1);





      bc_emit_bytecode_labeldef (lab);
      bc_expand_expr (((exp)->exp.operands[2]));
      bc_emit_bytecode_labeldef (lab1);
      return;

    case TRUTH_ANDIF_EXPR:

      opcode = xjumpifnot;
      goto andorif;

    case TRUTH_ORIF_EXPR:

      opcode = xjumpif;
      goto andorif;

    case PLUS_EXPR:

      binoptab = optab_plus_expr;
      goto binop;

    case MINUS_EXPR:

      binoptab = optab_minus_expr;
      goto binop;

    case MULT_EXPR:

      binoptab = optab_mult_expr;
      goto binop;

    case TRUNC_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case EXACT_DIV_EXPR:

      binoptab = optab_trunc_div_expr;
      goto binop;

    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
    case CEIL_MOD_EXPR:
    case ROUND_MOD_EXPR:

      binoptab = optab_trunc_mod_expr;
      goto binop;

    case FIX_ROUND_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_CEIL_EXPR:
      abort ();

    case FIX_TRUNC_EXPR:
    case FLOAT_EXPR:
    case MAX_EXPR:
    case MIN_EXPR:
    case FFS_EXPR:
    case LROTATE_EXPR:
    case RROTATE_EXPR:
      abort ();

    case RDIV_EXPR:

      binoptab = optab_rdiv_expr;
      goto binop;

    case BIT_AND_EXPR:

      binoptab = optab_bit_and_expr;
      goto binop;

    case BIT_IOR_EXPR:

      binoptab = optab_bit_ior_expr;
      goto binop;

    case BIT_XOR_EXPR:

      binoptab = optab_bit_xor_expr;
      goto binop;

    case LSHIFT_EXPR:

      binoptab = optab_lshift_expr;
      goto binop;

    case RSHIFT_EXPR:

      binoptab = optab_rshift_expr;
      goto binop;

    case TRUTH_AND_EXPR:

      binoptab = optab_truth_and_expr;
      goto binop;

    case TRUTH_OR_EXPR:

      binoptab = optab_truth_or_expr;
      goto binop;

    case LT_EXPR:

      binoptab = optab_lt_expr;
      goto binop;

    case LE_EXPR:

      binoptab = optab_le_expr;
      goto binop;

    case GE_EXPR:

      binoptab = optab_ge_expr;
      goto binop;

    case GT_EXPR:

      binoptab = optab_gt_expr;
      goto binop;

    case EQ_EXPR:

      binoptab = optab_eq_expr;
      goto binop;

    case NE_EXPR:

      binoptab = optab_ne_expr;
      goto binop;

    case NEGATE_EXPR:

      unoptab = optab_negate_expr;
      goto unop;

    case BIT_NOT_EXPR:

      unoptab = optab_bit_not_expr;
      goto unop;

    case TRUTH_NOT_EXPR:

      unoptab = optab_truth_not_expr;
      goto unop;

    case PREDECREMENT_EXPR:

      incroptab = optab_predecrement_expr;
      goto increment;

    case PREINCREMENT_EXPR:

      incroptab = optab_preincrement_expr;
      goto increment;

    case POSTDECREMENT_EXPR:

      incroptab = optab_postdecrement_expr;
      goto increment;

    case POSTINCREMENT_EXPR:

      incroptab = optab_postincrement_expr;
      goto increment;

    case CONSTRUCTOR:

      bc_expand_constructor (exp);
      return;

    case ERROR_MARK:
    case RTL_EXPR:

      return;

    case BIND_EXPR:
      {
 tree vars = ((exp)->exp.operands[0]);
 int vars_need_expansion = 0;



 expand_start_bindings (0);


 if (((exp)->exp.operands[2]) != 0)
   ((((exp)->exp.operands[2]))->common.used_flag) = 1;


 while (vars)
   {
     if (((vars)->decl.rtl) == 0)
       {
  vars_need_expansion = 1;
  expand_decl (vars);
       }
     expand_decl_init (vars);
     vars = ((vars)->common.chain);
   }

 bc_expand_expr (((exp)->exp.operands[1]));

 expand_end_bindings (((exp)->exp.operands[0]), 0, 0);

 return;
      }
    }

  abort ();

 binop:

  bc_expand_binary_operation (binoptab, ((exp)->common.type),
         ((exp)->exp.operands[0]), ((exp)->exp.operands[1]));
  return;


 unop:

  bc_expand_unary_operation (unoptab, ((exp)->common.type), ((exp)->exp.operands[0]));
  return;


 andorif:

  bc_expand_expr (((exp)->exp.operands[0]));
  bc_expand_truth_conversion (((((exp)->exp.operands[0]))->common.type));
  lab = bc_get_bytecode_label ();

  bc_emit_instruction (duplicate);
  bc_emit_bytecode (opcode);
  bc_emit_bytecode_labelref (lab);





  bc_emit_instruction (drop);

  bc_expand_expr (((exp)->exp.operands[1]));
  bc_expand_truth_conversion (((((exp)->exp.operands[1]))->common.type));
  bc_emit_bytecode_labeldef (lab);
  return;


 increment:

  type = ((((exp)->exp.operands[0]))->common.type);


  bc_expand_expr (((exp)->exp.operands[1]));


  bc_expand_conversion (((((exp)->exp.operands[1]))->common.type), type);


  bc_expand_expr (build1 (ADDR_EXPR, ((type)->type.pointer_to), ((exp)->exp.operands[0])));


  bc_expand_increment (incroptab, type);
  return;
}
static int
get_pointer_alignment(tree exp, unsigned int max_align) asm("_get_pointer_alignment");
static int
get_pointer_alignment(tree exp, unsigned int max_align)
{
  unsigned align, inner;

  if (((n64_enum_tree_code) (((exp)->common.type))->common.code) != POINTER_TYPE)
    return 0;

  align = ((((((exp)->common.type))->common.type))->type.align);
  align = ((align) < (max_align) ? (align) : (max_align));

  while (1)
    {
      switch (((n64_enum_tree_code) (exp)->common.code))
 {
 case NOP_EXPR:
 case CONVERT_EXPR:
 case NON_LVALUE_EXPR:
   exp = ((exp)->exp.operands[0]);
   if (((n64_enum_tree_code) (((exp)->common.type))->common.code) != POINTER_TYPE)
     return align;
   inner = ((((((exp)->common.type))->common.type))->type.align);
   align = ((inner) < (max_align) ? (inner) : (max_align));
   break;

 case PLUS_EXPR:



   if (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) != INTEGER_CST)
     return align;

   while (((((((exp)->exp.operands[1]))->int_cst.int_cst_low) * 8)
    & (max_align - 1))
   != 0)
     max_align >>= 1;

   exp = ((exp)->exp.operands[0]);
   break;

 case ADDR_EXPR:

   exp = ((exp)->exp.operands[0]);
   if (((n64_enum_tree_code) (exp)->common.code) == FUNCTION_DECL)
     align = 32;
   else if ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd')
     align = ((exp)->decl.frame_size.u);

   else if ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'c')
     align = ((((n64_enum_tree_code) (exp)->common.code) == STRING_CST || ((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR) && (align) < ((target_flags & 0x00002000) ? 64 : 32) ? ((target_flags & 0x00002000) ? 64 : 32) : (align));

   return ((align) < (max_align) ? (align) : (max_align));

 default:
   return align;
 }
    }
}




static tree
string_constant(tree arg, tree *ptr_offset) asm("_string_constant");
static tree
string_constant(tree arg, tree *ptr_offset)
{
  while ((((n64_enum_tree_code) (arg)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg)->common.code) == NON_LVALUE_EXPR) && (((((arg)->common.type))->type.mode) == ((((((arg)->exp.operands[0]))->common.type))->type.mode))) (arg) = ((arg)->exp.operands[0]);;

  if (((n64_enum_tree_code) (arg)->common.code) == ADDR_EXPR
      && ((n64_enum_tree_code) (((arg)->exp.operands[0]))->common.code) == STRING_CST)
    {
      *ptr_offset = integer_zero_node;
      return ((arg)->exp.operands[0]);
    }
  else if (((n64_enum_tree_code) (arg)->common.code) == PLUS_EXPR)
    {
      tree arg0 = ((arg)->exp.operands[0]);
      tree arg1 = ((arg)->exp.operands[1]);

      while ((((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == NON_LVALUE_EXPR) && (((((arg0)->common.type))->type.mode) == ((((((arg0)->exp.operands[0]))->common.type))->type.mode))) (arg0) = ((arg0)->exp.operands[0]);;
      while ((((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == NON_LVALUE_EXPR) && (((((arg1)->common.type))->type.mode) == ((((((arg1)->exp.operands[0]))->common.type))->type.mode))) (arg1) = ((arg1)->exp.operands[0]);;

      if (((n64_enum_tree_code) (arg0)->common.code) == ADDR_EXPR
   && ((n64_enum_tree_code) (((arg0)->exp.operands[0]))->common.code) == STRING_CST)
 {
   *ptr_offset = arg1;
   return ((arg0)->exp.operands[0]);
 }
      else if (((n64_enum_tree_code) (arg1)->common.code) == ADDR_EXPR
        && ((n64_enum_tree_code) (((arg1)->exp.operands[0]))->common.code) == STRING_CST)
 {
   *ptr_offset = arg0;
   return ((arg1)->exp.operands[0]);
 }
    }

  return 0;
}
static tree
c_strlen(tree src) asm("_c_strlen");
static tree
c_strlen(tree src)
{
  tree offset_node;
  int offset, max;
  char *ptr;

  src = string_constant (src, &offset_node);
  if (src == 0)
    return 0;
  max = ((src)->string.length);
  ptr = ((src)->string.pointer);
  if (offset_node && ((n64_enum_tree_code) (offset_node)->common.code) != INTEGER_CST)
    {



      int i;
      for (i = 0; i < max; i++)
 if (ptr[i] == 0)
   return 0;







      return size_binop (MINUS_EXPR, size_int (max), offset_node);
    }



  if (offset_node == 0)
    offset = 0;
  else
    {

      if (((offset_node)->int_cst.int_cst_high) != 0)
 return 0;
      offset = ((offset_node)->int_cst.int_cst_low);
    }


  if (offset < 0 || offset > max)
    {
      warning ("offset outside bounds of constant string");
      return 0;
    }






  return size_int (strlen (ptr + offset));
}

rtx
expand_builtin_return_addr(n64_enum_built_in_function fndecl_code, int count, rtx tem) asm("_expand_builtin_return_addr");
rtx
expand_builtin_return_addr(n64_enum_built_in_function fndecl_code, int count, rtx tem)
{
  int i;
  for (i = 0; i < count; i++)
    {





      tem = memory_address (((target_flags & 0x00000002) ? DImode : SImode), tem);
      tem = copy_to_reg (gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), tem));
    }


  if (fndecl_code == BUILT_IN_FRAME_ADDRESS)
    return tem;






  tem = memory_address (((target_flags & 0x00000002) ? DImode : SImode),
   plus_constant_wide (tem, (int) ((mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]))));
  tem = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), tem);

  return tem;
}
static rtx
expand_builtin(tree exp, rtx target, rtx subtarget, n64_enum_machine_mode mode, int ignore) asm("_expand_builtin");
static rtx
expand_builtin(tree exp, rtx target, rtx subtarget, n64_enum_machine_mode mode, int ignore)
{
  tree fndecl = ((((exp)->exp.operands[0]))->exp.operands[0]);
  tree arglist = ((exp)->exp.operands[1]);
  rtx op0;
  rtx lab1, insns;
  n64_enum_machine_mode value_mode = ((((exp)->common.type))->type.mode);
  optab builtin_optab;

  switch (((fndecl)->decl.frame_size.f))
    {
    case BUILT_IN_ABS:
    case BUILT_IN_LABS:
    case BUILT_IN_FABS:

      abort ();

    case BUILT_IN_SIN:
    case BUILT_IN_COS:

      if (! flag_fast_math)
 break;
    case BUILT_IN_FSQRT:

      if (! optimize)
 break;

      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != REAL_TYPE)
 break;


      if (((n64_enum_tree_code) (((arglist)->list.value))->common.code) != VAR_DECL
   && ((n64_enum_tree_code) (((arglist)->list.value))->common.code) != PARM_DECL)
 {
   exp = copy_node (exp);
   arglist = copy_node (arglist);
   ((exp)->exp.operands[1]) = arglist;
   ((arglist)->list.value) = save_expr (((arglist)->list.value));
 }
      op0 = expand_expr (((arglist)->list.value), subtarget, VOIDmode, 0);


      target = gen_reg_rtx (((((exp)->common.type))->type.mode));

      emit_queue ();
      start_sequence ();

      switch (((fndecl)->decl.frame_size.f))
 {
 case BUILT_IN_SIN:
   builtin_optab = sin_optab; break;
 case BUILT_IN_COS:
   builtin_optab = cos_optab; break;
 case BUILT_IN_FSQRT:
   builtin_optab = sqrt_optab; break;
 default:
   abort ();
 }



      target = expand_unop (((((((arglist)->list.value))->common.type))->type.mode),
       builtin_optab, op0, target, 0);




      if (target == 0)
 {
   end_sequence ();
   break;
        }




      if (! flag_fast_math)
 {


   if (1 != 1)
     abort ();

   lab1 = gen_label_rtx ();



   emit_cmp_insn (target, target, EQ, 0, ((target)->mode), 0, 0);
   emit_jump_insn (gen_beq (lab1));
   (inhibit_defer_pop += 1);
   expand_call (exp, target, 0);
   (inhibit_defer_pop -= 1);


   emit_label (lab1);
 }


      insns = get_insns ();
      end_sequence ();
      emit_insns (insns);

      return target;







    case BUILT_IN_APPLY_ARGS:


      if (apply_args_value != 0)
 return apply_args_value;
      {



 rtx temp;
 rtx seq;

 start_sequence ();
 temp = expand_builtin_apply_args ();
 seq = get_insns ();
 end_sequence ();

 apply_args_value = temp;





 push_topmost_sequence ();
 emit_insns_before (seq, ((get_insns ())->fld[2].rtx));
 pop_topmost_sequence ();
 return temp;
      }
    case BUILT_IN_APPLY:
      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != POINTER_TYPE
   || ((arglist)->common.chain) == 0
   || ((n64_enum_tree_code) (((((((arglist)->common.chain))->list.value))->common.type))->common.code) != POINTER_TYPE
   || ((((arglist)->common.chain))->common.chain) == 0
   || ((n64_enum_tree_code) (((((((((arglist)->common.chain))->common.chain))->list.value))->common.type))->common.code) != INTEGER_TYPE)
 return const0_rtx;
      else
 {
   int i;
   tree t;
   rtx ops[3];

   for (t = arglist, i = 0; t; t = ((t)->common.chain), i++)
     ops[i] = expand_expr (((t)->list.value), (rtx) 0, VOIDmode, 0);

   return expand_builtin_apply (ops[0], ops[1], ops[2]);
 }




    case BUILT_IN_RETURN:
      if (arglist

   && ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) == POINTER_TYPE)
 expand_builtin_return (expand_expr (((arglist)->list.value),
         (rtx) 0, VOIDmode, 0));
      return const0_rtx;

    case BUILT_IN_SAVEREGS:


      if (saveregs_value != 0)
 return saveregs_value;
      {



 rtx temp;
 rtx seq;



 start_sequence ();
 if (value_mode != VOIDmode)
   {
     rtx valreg = hard_libcall_value (value_mode);
     rtx saved_valreg = gen_reg_rtx (value_mode);

     emit_move_insn (saved_valreg, valreg);
     temp = expand_call (exp, target, ignore);
     emit_move_insn (valreg, saved_valreg);
   }
 else

   temp = expand_call (exp, target, ignore);


 seq = get_insns ();
 end_sequence ();

 saveregs_value = temp;





 push_topmost_sequence ();
 emit_insns_before (seq, ((get_insns ())->fld[2].rtx));
 pop_topmost_sequence ();
 return temp;
      }




    case BUILT_IN_ARGS_INFO:
      {
 int nwords = sizeof (CUMULATIVE_ARGS) / sizeof (int);
 int i;
 int *word_ptr = (int *) &current_function_args_info;
 tree type, elts, result;

 if (sizeof (CUMULATIVE_ARGS) % sizeof (int) != 0)
   fatal ("CUMULATIVE_ARGS type defined badly; see %s, line %d",
   "expr.c", 7484);

 if (arglist != 0)
   {
     tree arg = ((arglist)->list.value);
     if (((n64_enum_tree_code) (arg)->common.code) != INTEGER_CST)
       error ("argument of `__builtin_args_info' must be constant");
     else
       {
  int wordnum = ((arg)->int_cst.int_cst_low);

  if (wordnum < 0 || wordnum >= nwords || ((arg)->int_cst.int_cst_high))
    error ("argument of `__builtin_args_info' out of range");
  else
    return gen_rtx (CONST_INT, VOIDmode, (int) (word_ptr[wordnum]));
       }
   }
 else
   error ("missing argument in `__builtin_args_info'");

 return const0_rtx;
      }


    case BUILT_IN_NEXT_ARG:
      {
 tree fntype = ((current_function_decl)->common.type);

 if ((((fntype)->type.values) == 0
      || (((tree_last (((fntype)->type.values)))->list.value)
   == void_type_node))
     && ! current_function_varargs)
   {
     error ("`va_start' used in function with fixed args");
     return const0_rtx;
   }

 if (arglist)
   {
     tree last_parm = tree_last (((current_function_decl)->decl.arguments));
     tree arg = ((arglist)->list.value);



     while (((n64_enum_tree_code) (arg)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (arg)->common.code) == CONVERT_EXPR
     || ((n64_enum_tree_code) (arg)->common.code) == NON_LVALUE_EXPR)
       arg = ((arg)->exp.operands[0]);
     if (arg != last_parm)
       warning ("second parameter of `va_start' not last named argument");
   }
 else if (! current_function_varargs)


   warning ("`__builtin_next_arg' called without an argument");
      }

      return expand_binop (((target_flags & 0x00000002) ? DImode : SImode), add_optab,
      current_function_internal_arg_pointer,
      current_function_arg_offset_rtx,
      (rtx) 0, 0, OPTAB_LIB_WIDEN);

    case BUILT_IN_CLASSIFY_TYPE:
      if (arglist != 0)
 {
   tree type = ((((arglist)->list.value))->common.type);
   n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
   if (code == VOID_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (void_type_class));
   if (code == INTEGER_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (integer_type_class));
   if (code == CHAR_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (char_type_class));
   if (code == ENUMERAL_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (enumeral_type_class));
   if (code == BOOLEAN_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (boolean_type_class));
   if (code == POINTER_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (pointer_type_class));
   if (code == REFERENCE_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (reference_type_class));
   if (code == OFFSET_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (offset_type_class));
   if (code == REAL_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (real_type_class));
   if (code == COMPLEX_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (complex_type_class));
   if (code == FUNCTION_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (function_type_class));
   if (code == METHOD_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (method_type_class));
   if (code == RECORD_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (record_type_class));
   if (code == UNION_TYPE || code == QUAL_UNION_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (union_type_class));
   if (code == ARRAY_TYPE)
     {
       if (((type)->type.string_flag))
  return gen_rtx (CONST_INT, VOIDmode, (int) (string_type_class));
       else
  return gen_rtx (CONST_INT, VOIDmode, (int) (array_type_class));
     }
   if (code == SET_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (set_type_class));
   if (code == FILE_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (file_type_class));
   if (code == LANG_TYPE)
     return gen_rtx (CONST_INT, VOIDmode, (int) (lang_type_class));
 }
      return gen_rtx (CONST_INT, VOIDmode, (int) (no_type_class));

    case BUILT_IN_CONSTANT_P:
      if (arglist == 0)
 return const0_rtx;
      else
 {
   tree arg = ((arglist)->list.value);

   while ((((n64_enum_tree_code) (arg)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg)->common.code) == NON_LVALUE_EXPR) && (((((arg)->common.type))->type.mode) == ((((((arg)->exp.operands[0]))->common.type))->type.mode))) (arg) = ((arg)->exp.operands[0]);;
   return ((*tree_code_type[(int) (((n64_enum_tree_code) (arg)->common.code))]) == 'c'
    || (((n64_enum_tree_code) (arg)->common.code) == ADDR_EXPR
        && ((n64_enum_tree_code) (((arg)->exp.operands[0]))->common.code) == STRING_CST)
    ? const1_rtx : const0_rtx);
 }

    case BUILT_IN_FRAME_ADDRESS:



    case BUILT_IN_RETURN_ADDRESS:



      if (arglist == 0)

 return const0_rtx;
      else if (((n64_enum_tree_code) (((arglist)->list.value))->common.code) != INTEGER_CST)
 {
   error ("invalid arg to `__builtin_return_address'");
   return const0_rtx;
 }
      else if (tree_int_cst_sgn (((arglist)->list.value)) < 0)
 {
   error ("invalid arg to `__builtin_return_address'");
   return const0_rtx;
 }
      else
 {
   rtx tem = expand_builtin_return_addr (((fndecl)->decl.frame_size.f),
      ((((arglist)->list.value))->int_cst.int_cst_low),
      hard_frame_pointer_rtx);


   if (((fndecl)->decl.frame_size.f) == BUILT_IN_FRAME_ADDRESS)
     return tem;

   if (((tem)->code) != REG)
     tem = copy_to_reg (tem);
   return tem;
 }

    case BUILT_IN_ALLOCA:
      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != INTEGER_TYPE)
 break;


      op0 = expand_expr (((arglist)->list.value), (rtx) 0, VOIDmode, 0);


      return allocate_dynamic_stack_space (op0, target, 8);

    case BUILT_IN_FFS:

      if (!optimize && ! (!strncmp (((((fndecl)->decl.name))->identifier.pointer), "__builtin_", 10)))
 break;

      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != INTEGER_TYPE)
 break;


      op0 = expand_expr (((arglist)->list.value), subtarget, VOIDmode, 0);


      target = expand_unop (((((((arglist)->list.value))->common.type))->type.mode),
       ffs_optab, op0, target, 1);
      if (target == 0)
 abort ();
      return target;

    case BUILT_IN_STRLEN:

      if (!optimize && ! (!strncmp (((((fndecl)->decl.name))->identifier.pointer), "__builtin_", 10)))
 break;

      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != POINTER_TYPE)
 break;
      else
 {
   tree src = ((arglist)->list.value);
   tree len = c_strlen (src);

   int align
     = get_pointer_alignment (src, 64) / 8;

   rtx result, src_rtx, char_rtx;
   n64_enum_machine_mode insn_mode = value_mode, char_mode;
   n64_enum_insn_code icode;


   if (len != 0)
     return expand_expr (len, target, mode, 0);


   if (align == 0)
     break;



   while (insn_mode != VOIDmode)
     {
       icode = strlen_optab->handlers[(int) insn_mode].insn_code;
       if (icode != CODE_FOR_nothing)
  break;

       insn_mode = (mode_wider_mode[(int)(insn_mode)]);
     }
   if (insn_mode == VOIDmode)
     break;


   result = target;
   if (! (result != 0
   && ((result)->code) == REG
   && ((result)->mode) == insn_mode
   && ((result)->fld[0].rtint) >= 68))
     result = gen_reg_rtx (insn_mode);



   if (! (*insn_operand_predicate[(int)icode][0]) (result, insn_mode))
     result = gen_reg_rtx (insn_mode);

   src_rtx = memory_address (BLKmode,
        expand_expr (src, (rtx) 0, ptr_mode,
       EXPAND_NORMAL));
   if (! (*insn_operand_predicate[(int)icode][1]) (src_rtx, ((target_flags & 0x00000002) ? DImode : SImode)))
     src_rtx = copy_to_mode_reg (((target_flags & 0x00000002) ? DImode : SImode), src_rtx);

   char_rtx = const0_rtx;
   char_mode = insn_operand_mode[(int)icode][2];
   if (! (*insn_operand_predicate[(int)icode][2]) (char_rtx, char_mode))
     char_rtx = copy_to_mode_reg (char_mode, char_rtx);

   emit_insn ((*insn_gen_function[(int) (icode)]) (result,
          gen_rtx (MEM, BLKmode, src_rtx),
          char_rtx, gen_rtx (CONST_INT, VOIDmode, (int) (align))));


   if (((result)->mode) == value_mode)
     return result;
   else if (target != 0)
     {
       convert_move (target, result, 0);
       return target;
     }
   else
     return convert_to_mode (value_mode, result, 0);
 }

    case BUILT_IN_STRCPY:

      if (!optimize && ! (!strncmp (((((fndecl)->decl.name))->identifier.pointer), "__builtin_", 10)))
 break;

      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != POINTER_TYPE
   || ((arglist)->common.chain) == 0
   || ((n64_enum_tree_code) (((((((arglist)->common.chain))->list.value))->common.type))->common.code) != POINTER_TYPE)
 break;
      else
 {
   tree len = c_strlen (((((arglist)->common.chain))->list.value));

   if (len == 0)
     break;

   len = size_binop (PLUS_EXPR, len, integer_one_node);

   chainon (arglist, build_tree_list ((tree) 
                                     ((void *)0)
                                              , len));
 }


    case BUILT_IN_MEMCPY:

      if (!optimize && ! (!strncmp (((((fndecl)->decl.name))->identifier.pointer), "__builtin_", 10)))
 break;

      if (arglist == 0

   || ((n64_enum_tree_code) (((((arglist)->list.value))->common.type))->common.code) != POINTER_TYPE
   || ((arglist)->common.chain) == 0
   || ((n64_enum_tree_code) (((((((arglist)->common.chain))->list.value))->common.type))->common.code) != POINTER_TYPE
   || ((((arglist)->common.chain))->common.chain) == 0
   || ((n64_enum_tree_code) (((((((((arglist)->common.chain))->common.chain))->list.value))->common.type))->common.code) != INTEGER_TYPE)
 break;
      else
 {
   tree dest = ((arglist)->list.value);
   tree src = ((((arglist)->common.chain))->list.value);
   tree len = ((((((arglist)->common.chain))->common.chain))->list.value);
   tree type;

   int src_align
     = get_pointer_alignment (src, 64) / 8;
   int dest_align
     = get_pointer_alignment (dest, 64) / 8;
   rtx dest_rtx, dest_mem, src_mem;



   if (src_align == 0 || dest_align == 0)
     {
       if (((fndecl)->decl.frame_size.f) == BUILT_IN_STRCPY)
  ((((arglist)->common.chain))->common.chain) = 0;
       break;
     }

   dest_rtx = expand_expr (dest, (rtx) 0, ptr_mode, EXPAND_SUM);
   dest_mem = gen_rtx (MEM, BLKmode,
         memory_address (BLKmode, dest_rtx));

   while (((n64_enum_tree_code) (dest)->common.code) == NOP_EXPR)
     dest = ((dest)->exp.operands[0]);
   type = ((((dest)->common.type))->common.type);
   ((dest_mem)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
   src_mem = gen_rtx (MEM, BLKmode,
        memory_address (BLKmode,
          expand_expr (src, (rtx) 0,
         ptr_mode,
         EXPAND_SUM)));

   while (((n64_enum_tree_code) (src)->common.code) == NOP_EXPR)
     src = ((src)->exp.operands[0]);
   type = ((((src)->common.type))->common.type);
   ((src_mem)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);


   emit_block_move (dest_mem, src_mem,
      expand_expr (len, (rtx) 0, VOIDmode, 0),
      ((src_align) < (dest_align) ? (src_align) : (dest_align)));
   return force_operand (dest_rtx, (rtx) 0);
 }
    case BUILT_IN_STRCMP:
    case BUILT_IN_MEMCMP:
      break;


    default:
      error ("built-in function `%s' not currently supported",
      ((((fndecl)->decl.name))->identifier.pointer));
    }




  return expand_call (exp, target, ignore);
}
static n64_enum_machine_mode apply_args_mode[68];






static n64_enum_machine_mode apply_result_mode[68];





static int apply_args_reg_offset[68];





int
apply_args_register_offset(int regno) asm("_apply_args_register_offset");
int
apply_args_register_offset(int regno)
{
  apply_args_size ();




  regno = (regno);

  return apply_args_reg_offset[regno];
}




static int
apply_args_size(void) asm("_apply_args_size");
static int
apply_args_size(void)
{
  static int size = -1;
  int align, regno;
  n64_enum_machine_mode mode;


  if (size < 0)
    {

      size = (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);



      if (struct_value_rtx)
 size += (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);

      for (regno = 0; regno < 68; regno++)
 if ((((regno) >= (0 + 4) && (regno) <= (0 + 7)) || ((regno) >= (32 + 12) && (regno) <= (32 + 15) && (0 == (regno) % 2))))
   {


     n64_enum_machine_mode best_mode = VOIDmode;

     for (mode = class_narrowest_mode[(int)(MODE_INT)];
   mode != VOIDmode;
   mode = (mode_wider_mode[(int)(mode)]))
       if (mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ]
    && (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) == 1)
  best_mode = mode;

     if (best_mode == VOIDmode)
       for (mode = class_narrowest_mode[(int)(MODE_FLOAT)];
     mode != VOIDmode;
     mode = (mode_wider_mode[(int)(mode)]))
  if (mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ]
      && (mov_optab->handlers[(int) mode].insn_code
   != CODE_FOR_nothing))
    best_mode = mode;

     mode = best_mode;
     if (mode == VOIDmode)
       abort ();

     align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
     if (size % align != 0)
       size = (((size) + (align) - 1) / (align)) * align;
     apply_args_reg_offset[regno] = size;
     size += (mode_size[(int)(mode)]);
     apply_args_mode[regno] = mode;
   }
 else
   {
     apply_args_mode[regno] = VOIDmode;
     apply_args_reg_offset[regno] = 0;
   }
    }
  return size;
}




static int
apply_result_size(void) asm("_apply_result_size");
static int
apply_result_size(void)
{
  static int size = -1;
  int align, regno;
  n64_enum_machine_mode mode;


  if (size < 0)
    {
      size = 0;

      for (regno = 0; regno < 68; regno++)
 if (((regno) == (0 + 2) || (regno) == (((target_flags & 0x00000100)) ? (0 + 2) : (32 + 0))))
   {


     n64_enum_machine_mode best_mode = VOIDmode;

     for (mode = class_narrowest_mode[(int)(MODE_INT)];
   mode != TImode;
   mode = (mode_wider_mode[(int)(mode)]))
       if (mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
  best_mode = mode;

     if (best_mode == VOIDmode)
       for (mode = class_narrowest_mode[(int)(MODE_FLOAT)];
     mode != VOIDmode;
     mode = (mode_wider_mode[(int)(mode)]))
  if (mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ]
      && (mov_optab->handlers[(int) mode].insn_code
   != CODE_FOR_nothing))
    best_mode = mode;

     mode = best_mode;
     if (mode == VOIDmode)
       abort ();

     align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
     if (size % align != 0)
       size = (((size) + (align) - 1) / (align)) * align;
     size += (mode_size[(int)(mode)]);
     apply_result_mode[regno] = mode;
   }
 else
   apply_result_mode[regno] = VOIDmode;






    }
  return size;
}






static rtx
result_vector(int savep, rtx result) asm("_result_vector");
static rtx
result_vector(int savep, rtx result)
{
  int regno, size, align, nelts;
  n64_enum_machine_mode mode;
  rtx reg, mem;
  rtx *savevec = (rtx *) 
                        __builtin_alloca((
                        68 * sizeof (rtx)
                        ))
                                                                     ;

  size = nelts = 0;
  for (regno = 0; regno < 68; regno++)
    if ((mode = apply_result_mode[regno]) != VOIDmode)
      {
 align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
 if (size % align != 0)
   size = (((size) + (align) - 1) / (align)) * align;
 reg = gen_rtx (REG, mode, savep ? regno : (regno));
 mem = change_address (result, mode,
         plus_constant_wide (((result)->fld[0].rtx), (int) (size)));
 savevec[nelts++] = (savep
       ? gen_rtx (SET, VOIDmode, mem, reg)
       : gen_rtx (SET, VOIDmode, reg, mem));
 size += (mode_size[(int)(mode)]);
      }
  return gen_rtx (PARALLEL, VOIDmode, gen_rtvec_v (nelts, savevec));
}





static rtx
expand_builtin_apply_args(void) asm("_expand_builtin_apply_args");
static rtx
expand_builtin_apply_args(void)
{
  rtx registers;
  int size, align, regno;
  n64_enum_machine_mode mode;



  registers = assign_stack_local (BLKmode, apply_args_size (), -1);


  size = (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);
  if (struct_value_rtx)
    size += (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);


  for (regno = 0; regno < 68; regno++)
    if ((mode = apply_args_mode[regno]) != VOIDmode)
      {
 rtx tem;

 align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
 if (size % align != 0)
   size = (((size) + (align) - 1) / (align)) * align;

 tem = gen_rtx (REG, mode, (regno));
 emit_move_insn (change_address (registers, mode,
     plus_constant_wide (((registers)->fld[0].rtx), (int) (size))
                  ),
   tem);
 size += (mode_size[(int)(mode)]);
      }


  emit_move_insn (change_address (registers, ((target_flags & 0x00000002) ? DImode : SImode), ((registers)->fld[0].rtx)),
    copy_to_reg (virtual_incoming_args_rtx));
  size = (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);



  if (struct_value_incoming_rtx)
    {
      emit_move_insn (change_address (registers, ((target_flags & 0x00000002) ? DImode : SImode),
          plus_constant_wide (((registers)->fld[0].rtx), (int) (size))
                ),
        copy_to_reg (struct_value_incoming_rtx));
      size += (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);
    }


  return copy_addr_to_reg (((registers)->fld[0].rtx));
}




static rtx
expand_builtin_apply(rtx function, rtx arguments, rtx argsize) asm("_expand_builtin_apply");
static rtx
expand_builtin_apply(rtx function, rtx arguments, rtx argsize)
{
  int size, align, regno;
  n64_enum_machine_mode mode;
  rtx incoming_args, result, reg, dest, call_insn;
  rtx old_stack_level = 0;
  rtx call_fusage = 0;


  result = assign_stack_local (BLKmode, apply_result_size (), -1);




  incoming_args = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
  emit_move_insn (incoming_args,
    gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), arguments));






  emit_queue ();


  do_pending_stack_adjust ();
  emit_stack_save (SAVE_BLOCK, &old_stack_level, (rtx) 0);






  dest = copy_addr_to_reg (push_block (argsize, 0, 0));
  emit_block_move (gen_rtx (MEM, BLKmode, dest),
     gen_rtx (MEM, BLKmode, incoming_args),
     argsize,
     ((target_flags & 0x00002000) ? 64 : 32) / 8);


  apply_args_size ();
  arguments = gen_rtx (MEM, BLKmode, arguments);


  size = (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);
  if (struct_value_rtx)
    size += (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);



  for (regno = 0; regno < 68; regno++)
    if ((mode = apply_args_mode[regno]) != VOIDmode)
      {
 align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
 if (size % align != 0)
   size = (((size) + (align) - 1) / (align)) * align;
 reg = gen_rtx (REG, mode, regno);
 emit_move_insn (reg,
   change_address (arguments, mode,
     plus_constant_wide (((arguments)->fld[0].rtx), (int) (size))
                  ));

 use_reg (&call_fusage, reg);
 size += (mode_size[(int)(mode)]);
      }



  size = (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);
  if (struct_value_rtx)
    {
      rtx value = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
      emit_move_insn (value,
        change_address (arguments, ((target_flags & 0x00000002) ? DImode : SImode),
          plus_constant_wide (((arguments)->fld[0].rtx), (int) (size))
                ));
      emit_move_insn (struct_value_rtx, value);
      if (((struct_value_rtx)->code) == REG)
   use_reg (&call_fusage, struct_value_rtx);
      size += (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]);
    }


  function = prepare_call_address (function, (tree) 
                                            ((void *)0)
                                                     , &call_fusage, 0);




  if (((function)->code) != SYMBOL_REF)
    function = memory_address (((target_flags & 0x00000002) ? DImode : SImode), function);



  if (1)
    emit_call_insn (gen_untyped_call (gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), function),
          result, result_vector (1, result)));
  else


  if (1)
    {
      rtx valreg = 0;





      for (regno = 0; regno < 68; regno++)
 if ((mode = apply_result_mode[regno]) != VOIDmode)
   {
     if (valreg)
       abort ();
     valreg = gen_rtx (REG, mode, regno);
   }

      emit_call_insn (gen_call_value (valreg,
          gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), function),
          const0_rtx, (rtx) 0, const0_rtx));

      emit_move_insn (change_address (result, ((valreg)->mode),
          ((result)->fld[0].rtx)),
        valreg);
    }
  else

    abort ();


  for (call_insn = get_last_insn ();
       call_insn && ((call_insn)->code) != CALL_INSN;
       call_insn = ((call_insn)->fld[1].rtx))
    ;

  if (! call_insn)
    abort ();



  if (((call_insn)->fld[7].rtx))
    {
      rtx link;

      for (link = ((call_insn)->fld[7].rtx); ((link)->fld[1].rtx) != 0;
    link = ((link)->fld[1].rtx))
 ;

      ((link)->fld[1].rtx) = call_fusage;
    }
  else
    ((call_insn)->fld[7].rtx) = call_fusage;


  emit_stack_restore (SAVE_BLOCK, old_stack_level, (rtx) 0);


  return copy_addr_to_reg (((result)->fld[0].rtx));
}



static void
expand_builtin_return(rtx result) asm("_expand_builtin_return");
static void
expand_builtin_return(rtx result)
{
  int size, align, regno;
  n64_enum_machine_mode mode;
  rtx reg;
  rtx call_fusage = 0;

  apply_result_size ();
  result = gen_rtx (MEM, BLKmode, result);
  size = 0;
  for (regno = 0; regno < 68; regno++)
    if ((mode = apply_result_mode[regno]) != VOIDmode)
      {
 align = ((64) < (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(mode)]) * 8)) ? (1) : (((mode_unit_size[(int)(mode)]) * 8))))) / 8;
 if (size % align != 0)
   size = (((size) + (align) - 1) / (align)) * align;
 reg = gen_rtx (REG, mode, (regno));
 emit_move_insn (reg,
   change_address (result, mode,
     plus_constant_wide (((result)->fld[0].rtx), (int) (size))
                  ));

 push_to_sequence (call_fusage);
 emit_insn (gen_rtx (USE, VOIDmode, reg));
 call_fusage = get_insns ();
 end_sequence ();
 size += (mode_size[(int)(mode)]);
      }


  emit_insns (call_fusage);



  expand_null_return ();
}





static rtx
expand_increment(register tree exp, int post) asm("_expand_increment");
static rtx
expand_increment(register tree exp, int post)
{
  register rtx op0, op1;
  register rtx temp, value;
  register tree incremented = ((exp)->exp.operands[0]);
  optab this_optab = add_optab;
  int icode;
  n64_enum_machine_mode mode = ((((exp)->common.type))->type.mode);
  int op0_is_copy = 0;
  int single_insn = 0;



  int bad_subreg = 0;

  if (output_bytecode)
    {
      bc_expand_expr (exp);
      return (rtx) 0;
    }



  if (!post
      || ((n64_enum_tree_code) (incremented)->common.code) == BIT_FIELD_REF
      || (((n64_enum_tree_code) (incremented)->common.code) == COMPONENT_REF
   && (((n64_enum_tree_code) (((incremented)->exp.operands[0]))->common.code) != INDIRECT_REF
       || ((((incremented)->exp.operands[1]))->decl.bit_field_flag))))
    incremented = stabilize_reference (incremented);



  if (((n64_enum_tree_code) (incremented)->common.code) == PREINCREMENT_EXPR
      || ((n64_enum_tree_code) (incremented)->common.code) == PREDECREMENT_EXPR)
    incremented = save_expr (incremented);






  temp = get_last_insn ();
  op0 = expand_expr (incremented, (rtx) 0, VOIDmode, 0);
  if (((op0)->code) == SUBREG && ((op0)->in_struct))
    {
      if (post)
 ((op0)->fld[0].rtx) = copy_to_reg (((op0)->fld[0].rtx));
      else
 bad_subreg = 1;
    }
  else if (((op0)->code) == SUBREG
    && (8 * mode_size[(int)(((op0)->mode))]) < ((target_flags & 0x00002000) ? 64 : 32))
    {



      if (post)
 op0 = copy_to_reg (op0);
      else
 bad_subreg = 1;
    }

  op0_is_copy = ((((op0)->code) == SUBREG || ((op0)->code) == REG)
   && temp != get_last_insn ());
  op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);


  if (((n64_enum_tree_code) (exp)->common.code) == POSTDECREMENT_EXPR
      || ((n64_enum_tree_code) (exp)->common.code) == PREDECREMENT_EXPR)
    this_optab = sub_optab;


  if (this_optab == sub_optab
      && ((op1)->code) == CONST_INT)
    {
      op1 = gen_rtx (CONST_INT, VOIDmode, (int) (- ((op1)->fld[0].rtwint)));
      this_optab = add_optab;
    }


  if (!post)
    {
      icode = (int) this_optab->handlers[(int) mode].insn_code;
      if (icode != (int) CODE_FOR_nothing


   && (*insn_operand_predicate[icode][0]) (op0, mode)
   && (*insn_operand_predicate[icode][1]) (op0, mode)
   && (*insn_operand_predicate[icode][2]) (op1, mode))
 single_insn = 1;
    }
  if (op0_is_copy || (!post && !single_insn) || bad_subreg)
    {






      tree newexp = build (((((n64_enum_tree_code) (exp)->common.code) == POSTDECREMENT_EXPR
        || ((n64_enum_tree_code) (exp)->common.code) == PREDECREMENT_EXPR)
       ? MINUS_EXPR : PLUS_EXPR),
      ((exp)->common.type),
      incremented,
      ((exp)->exp.operands[1]));

      while (((n64_enum_tree_code) (incremented)->common.code) == NOP_EXPR
      || ((n64_enum_tree_code) (incremented)->common.code) == CONVERT_EXPR)
 {
   newexp = convert (((incremented)->common.type), newexp);
   incremented = ((incremented)->exp.operands[0]);
 }

      temp = expand_assignment (incremented, newexp, ! post, 0);
      return post ? op0 : temp;
    }

  if (post)
    {
      icode = (int) this_optab->handlers[(int) mode].insn_code;
      if (icode != (int) CODE_FOR_nothing


   && (*insn_operand_predicate[icode][0]) (op0, mode)
   && (*insn_operand_predicate[icode][1]) (op0, mode))
 {
   if (! (*insn_operand_predicate[icode][2]) (op1, mode))
     op1 = force_reg (mode, op1);

   return enqueue_insn (op0, (*insn_gen_function[(int) (icode)]) (op0, op0, op1));
 }
    }


  if (post)

    temp = value = copy_to_reg (op0);
  else




    temp = copy_rtx (value = op0);


  op1 = expand_binop (mode, this_optab, value, op1, op0,
        ((((exp)->common.type))->common.unsigned_flag), OPTAB_LIB_WIDEN);

  if (op1 != op0)
    emit_move_insn (op0, op1);

  return temp;
}






static void
preexpand_calls(tree exp) asm("_preexpand_calls");
static void
preexpand_calls(tree exp)
{
  register int nops, i;
  int type = (*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]);

  if (! do_preexpand_calls)
    return;



  if (type != 'e' && type != '<' && type != '1' && type != '2' && type != 'r')
    return;

  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case CALL_EXPR:

      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) != 0)
 return;


      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) != ADDR_EXPR
   || ((n64_enum_tree_code) (((((exp)->exp.operands[0]))->exp.operands[0]))->common.code) != FUNCTION_DECL
   || ! ((((((exp)->exp.operands[0]))->exp.operands[0]))->decl.bit_field_flag)

   || ((n64_enum_tree_code) (((((exp)->common.type))->type.size))->common.code) != INTEGER_CST)
 (*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) = expand_call (exp, (rtx) 0, 0);
      return;

    case COMPOUND_EXPR:
    case COND_EXPR:
    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:





      do_pending_stack_adjust ();
      return;

    case BLOCK:
    case RTL_EXPR:
    case WITH_CLEANUP_EXPR:
    case CLEANUP_POINT_EXPR:
      return;

    case SAVE_EXPR:
      if ((*(struct n64_tag_rtx_def **) &(exp)->exp.operands[2]) != 0)
 return;
    }

  nops = tree_code_length[(int) ((n64_enum_tree_code) (exp)->common.code)];
  for (i = 0; i < nops; i++)
    if (((exp)->exp.operands[i]) != 0)
      {
 type = (*tree_code_type[(int) (((n64_enum_tree_code) (((exp)->exp.operands[i]))->common.code))]);
 if (type == 'e' || type == '<' || type == '1' || type == '2'
     || type == 'r')
   preexpand_calls (((exp)->exp.operands[i]));
      }
}




void
init_pending_stack_adjust(void) asm("_init_pending_stack_adjust");
void
init_pending_stack_adjust(void)
{
  pending_stack_adjust = 0;
}




void
clear_pending_stack_adjust(void) asm("_clear_pending_stack_adjust");
void
clear_pending_stack_adjust(void)
{

  if (! flag_omit_frame_pointer && 1
      && ! (((current_function_decl)->decl.inline_flag) && ! flag_no_inline)
      && ! flag_inline_functions)
    pending_stack_adjust = 0;

}



void
do_pending_stack_adjust(void) asm("_do_pending_stack_adjust");
void
do_pending_stack_adjust(void)
{
  if (inhibit_defer_pop == 0)
    {
      if (pending_stack_adjust != 0)
 adjust_stack (gen_rtx (CONST_INT, VOIDmode, (int) (pending_stack_adjust)));
      pending_stack_adjust = 0;
    }
}




static tree
defer_cleanups_to(tree old_cleanups) asm("_defer_cleanups_to");
static tree
defer_cleanups_to(tree old_cleanups)
{
  tree new_cleanups = (tree) 
                     ((void *)0)
                              ;
  tree cleanups = cleanups_this_call;
  tree last = (tree) 
             ((void *)0)
                      ;

  while (cleanups_this_call != old_cleanups)
    {
      (*interim_eh_hook) (((cleanups_this_call)->list.value));
      last = cleanups_this_call;
      cleanups_this_call = ((cleanups_this_call)->common.chain);
    }

  if (last)
    {

      ((last)->common.chain) = (tree) 
                         ((void *)0)
                                  ;


      cleanups = nreverse (cleanups);

      while (cleanups)
 {
   if (new_cleanups)
     new_cleanups = build (COMPOUND_EXPR, ((new_cleanups)->common.type),
      ((cleanups)->list.value), new_cleanups);
   else
     new_cleanups = ((cleanups)->list.value);

   cleanups = ((cleanups)->common.chain);
 }
    }

  return new_cleanups;
}




void
expand_cleanups_to(tree old_cleanups) asm("_expand_cleanups_to");
void
expand_cleanups_to(tree old_cleanups)
{
  while (cleanups_this_call != old_cleanups)
    {
      (*interim_eh_hook) (((cleanups_this_call)->list.value));
      expand_expr (((cleanups_this_call)->list.value), const0_rtx, VOIDmode, 0);
      cleanups_this_call = ((cleanups_this_call)->common.chain);
    }
}







void
jumpifnot(tree exp, rtx label) asm("_jumpifnot");
void
jumpifnot(tree exp, rtx label)
{
  do_jump (exp, label, (rtx) 0);
}



void
jumpif(tree exp, rtx label) asm("_jumpif");
void
jumpif(tree exp, rtx label)
{
  do_jump (exp, (rtx) 0, label);
}
void
do_jump(tree exp, rtx if_false_label, rtx if_true_label) asm("_do_jump");
void
do_jump(tree exp, rtx if_false_label, rtx if_true_label)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (exp)->common.code);



  rtx drop_through_label = 0;
  rtx temp;
  rtx comparison = 0;
  int i;
  tree type;
  n64_enum_machine_mode mode;

  emit_queue ();

  switch (code)
    {
    case ERROR_MARK:
      break;

    case INTEGER_CST:
      temp = integer_zerop (exp) ? if_false_label : if_true_label;
      if (temp)
 emit_jump (temp);
      break;
    case NOP_EXPR:
      if (((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == COMPONENT_REF
   || ((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == BIT_FIELD_REF
   || ((n64_enum_tree_code) (((exp)->exp.operands[0]))->common.code) == ARRAY_REF)
 goto normal;
    case CONVERT_EXPR:


      if ((((((exp)->common.type))->type.precision)
    < ((((((exp)->exp.operands[0]))->common.type))->type.precision)))
 goto normal;
    case NON_LVALUE_EXPR:
    case REFERENCE_EXPR:
    case ABS_EXPR:
    case NEGATE_EXPR:
    case LROTATE_EXPR:
    case RROTATE_EXPR:

      do_jump (((exp)->exp.operands[0]), if_false_label, if_true_label);
      break;
    case MINUS_EXPR:

      comparison = compare (build (NE_EXPR, ((exp)->common.type),
       ((exp)->exp.operands[0]),
       ((exp)->exp.operands[1])),
       NE, NE);
      break;

    case BIT_AND_EXPR:







      if (! 1
   && ((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == INTEGER_CST
   && ((((exp)->common.type))->type.precision) <= 32
   && (i = floor_log2_wide ((int) (((((exp)->exp.operands[1]))->int_cst.int_cst_low)))) >= 0
   && (mode = mode_for_size (i + 1, MODE_INT, 0)) != BLKmode
   && (type = type_for_mode (mode, 1)) != 0
   && ((type)->type.precision) < ((((exp)->common.type))->type.precision)
   && (cmp_optab->handlers[(int) ((type)->type.mode)].insn_code
       != CODE_FOR_nothing))
 {
   do_jump (convert (type, exp), if_false_label, if_true_label);
   break;
 }
      goto normal;

    case TRUTH_NOT_EXPR:
      do_jump (((exp)->exp.operands[0]), if_true_label, if_false_label);
      break;

    case TRUTH_ANDIF_EXPR:
      {
 rtx seq1, seq2;
 tree cleanups, old_cleanups;

 if (if_false_label == 0)
   if_false_label = drop_through_label = gen_label_rtx ();
 start_sequence ();
 do_jump (((exp)->exp.operands[0]), if_false_label, (rtx) 0);
 seq1 = get_insns ();
 end_sequence ();

 old_cleanups = cleanups_this_call;
 start_sequence ();
 do_jump (((exp)->exp.operands[1]), if_false_label, if_true_label);
 seq2 = get_insns ();
 end_sequence ();

 cleanups = defer_cleanups_to (old_cleanups);
 if (cleanups)
   {
     rtx flag = gen_reg_rtx (word_mode);
     tree new_cleanups;
     tree cond;


     emit_move_insn (flag, const0_rtx);
     emit_insns (seq1);


     emit_move_insn (flag, const1_rtx);
     emit_insns (seq2);


     cond = make_node (RTL_EXPR);
     ((cond)->common.type) = integer_type_node;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[1]) = flag;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[0]) = (rtx) 0;
     cond = save_expr (cond);

     new_cleanups = build (COND_EXPR, void_type_node,
      truthvalue_conversion (cond),
      cleanups, integer_zero_node);
     new_cleanups = fold (new_cleanups);


     cleanups_this_call
       = tree_cons ((tree) 
                   ((void *)0)
                            , new_cleanups, cleanups_this_call);
     (*interim_eh_hook) ((tree) 
                        ((void *)0)
                                 );
   }
 else
   {
     emit_insns (seq1);
     emit_insns (seq2);
   }
      }
      break;

    case TRUTH_ORIF_EXPR:
      {
 rtx seq1, seq2;
 tree cleanups, old_cleanups;

 if (if_true_label == 0)
   if_true_label = drop_through_label = gen_label_rtx ();
 start_sequence ();
 do_jump (((exp)->exp.operands[0]), (rtx) 0, if_true_label);
 seq1 = get_insns ();
 end_sequence ();

 old_cleanups = cleanups_this_call;
 start_sequence ();
 do_jump (((exp)->exp.operands[1]), if_false_label, if_true_label);
 seq2 = get_insns ();
 end_sequence ();

 cleanups = defer_cleanups_to (old_cleanups);
 if (cleanups)
   {
     rtx flag = gen_reg_rtx (word_mode);
     tree new_cleanups;
     tree cond;


     emit_move_insn (flag, const0_rtx);
     emit_insns (seq1);


     emit_move_insn (flag, const1_rtx);
     emit_insns (seq2);


     cond = make_node (RTL_EXPR);
     ((cond)->common.type) = integer_type_node;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[1]) = flag;
     (*(struct n64_tag_rtx_def **) &(cond)->exp.operands[0]) = (rtx) 0;
     cond = save_expr (cond);

     new_cleanups = build (COND_EXPR, void_type_node,
      truthvalue_conversion (cond),
      cleanups, integer_zero_node);
     new_cleanups = fold (new_cleanups);


     cleanups_this_call
       = tree_cons ((tree) 
                   ((void *)0)
                            , new_cleanups, cleanups_this_call);
     (*interim_eh_hook) ((tree) 
                        ((void *)0)
                                 );
   }
 else
   {
     emit_insns (seq1);
     emit_insns (seq2);
   }
      }
      break;

    case COMPOUND_EXPR:
      push_temp_slots ();
      expand_expr (((exp)->exp.operands[0]), const0_rtx, VOIDmode, 0);
      free_temp_slots ();
      pop_temp_slots ();
      emit_queue ();
      do_pending_stack_adjust ();
      do_jump (((exp)->exp.operands[1]), if_false_label, if_true_label);
      break;

    case COMPONENT_REF:
    case BIT_FIELD_REF:
    case ARRAY_REF:
      {
 int bitsize, bitpos, unsignedp;
 n64_enum_machine_mode mode;
 tree type;
 tree offset;
 int volatilep = 0;



 get_inner_reference (exp, &bitsize, &bitpos, &offset,
        &mode, &unsignedp, &volatilep);

 type = type_for_size (bitsize, unsignedp);
 if (! 1
     && type != 0 && bitsize >= 0
     && ((type)->type.precision) < ((((exp)->common.type))->type.precision)
     && (cmp_optab->handlers[(int) ((type)->type.mode)].insn_code
  != CODE_FOR_nothing))
   {
     do_jump (convert (type, exp), if_false_label, if_true_label);
     break;
   }
 goto normal;
      }

    case COND_EXPR:

      if (integer_onep (((exp)->exp.operands[1]))
   && integer_zerop (((exp)->exp.operands[2])))
 do_jump (((exp)->exp.operands[0]), if_false_label, if_true_label);

      else if (integer_zerop (((exp)->exp.operands[1]))
        && integer_onep (((exp)->exp.operands[2])))
 do_jump (((exp)->exp.operands[0]), if_true_label, if_false_label);

      else
 {
   register rtx label1 = gen_label_rtx ();
   drop_through_label = gen_label_rtx ();
   do_jump (((exp)->exp.operands[0]), label1, (rtx) 0);

   do_jump (((exp)->exp.operands[1]),
     if_false_label ? if_false_label : drop_through_label,
     if_true_label ? if_true_label : drop_through_label);

   do_pending_stack_adjust ();
   emit_label (label1);

   do_jump (((exp)->exp.operands[2]),
     if_false_label ? if_false_label : drop_through_label,
     if_true_label ? if_true_label : drop_through_label);
 }
      break;

    case EQ_EXPR:
      {
 tree inner_type = ((((exp)->exp.operands[0]))->common.type);

 if (integer_zerop (((exp)->exp.operands[1])))
   do_jump (((exp)->exp.operands[0]), if_true_label, if_false_label);
 else if ((mode_class[(int)(((inner_type)->type.mode))]) == MODE_COMPLEX_FLOAT
   || (mode_class[(int)(((inner_type)->type.mode))]) == MODE_COMPLEX_INT)
   do_jump
     (fold
      (build (TRUTH_ANDIF_EXPR, ((exp)->common.type),
       fold (build (EQ_EXPR, ((exp)->common.type),
      fold (build1 (REALPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[0]))),
      fold (build1 (REALPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[1]))))),
       fold (build (EQ_EXPR, ((exp)->common.type),
      fold (build1 (IMAGPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[0]))),
      fold (build1 (IMAGPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[1]))))))),
      if_false_label, if_true_label);
 else if ((mode_class[(int)(((inner_type)->type.mode))]) == MODE_INT
   && !can_compare_p (((inner_type)->type.mode)))
   do_jump_by_parts_equality (exp, if_false_label, if_true_label);
 else
   comparison = compare (exp, EQ, EQ);
 break;
      }

    case NE_EXPR:
      {
 tree inner_type = ((((exp)->exp.operands[0]))->common.type);

 if (integer_zerop (((exp)->exp.operands[1])))
   do_jump (((exp)->exp.operands[0]), if_false_label, if_true_label);
 else if ((mode_class[(int)(((inner_type)->type.mode))]) == MODE_COMPLEX_FLOAT
   || (mode_class[(int)(((inner_type)->type.mode))]) == MODE_COMPLEX_INT)
   do_jump
     (fold
      (build (TRUTH_ORIF_EXPR, ((exp)->common.type),
       fold (build (NE_EXPR, ((exp)->common.type),
      fold (build1 (REALPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[0]))),
      fold (build1 (REALPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[1]))))),
       fold (build (NE_EXPR, ((exp)->common.type),
      fold (build1 (IMAGPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[0]))),
      fold (build1 (IMAGPART_EXPR,
      ((inner_type)->common.type),
      ((exp)->exp.operands[1]))))))),
      if_false_label, if_true_label);
 else if ((mode_class[(int)(((inner_type)->type.mode))]) == MODE_INT
   && !can_compare_p (((inner_type)->type.mode)))
   do_jump_by_parts_equality (exp, if_true_label, if_false_label);
 else
   comparison = compare (exp, NE, NE);
 break;
      }

    case LT_EXPR:
      if (((mode_class[(int)(((((((exp)->exp.operands[0]))->common.type))->type.mode))])
    == MODE_INT)
   && !can_compare_p (((((((exp)->exp.operands[0]))->common.type))->type.mode)))
 do_jump_by_parts_greater (exp, 1, if_false_label, if_true_label);
      else
 comparison = compare (exp, LT, LTU);
      break;

    case LE_EXPR:
      if (((mode_class[(int)(((((((exp)->exp.operands[0]))->common.type))->type.mode))])
    == MODE_INT)
   && !can_compare_p (((((((exp)->exp.operands[0]))->common.type))->type.mode)))
 do_jump_by_parts_greater (exp, 0, if_true_label, if_false_label);
      else
 comparison = compare (exp, LE, LEU);
      break;

    case GT_EXPR:
      if (((mode_class[(int)(((((((exp)->exp.operands[0]))->common.type))->type.mode))])
    == MODE_INT)
   && !can_compare_p (((((((exp)->exp.operands[0]))->common.type))->type.mode)))
 do_jump_by_parts_greater (exp, 0, if_false_label, if_true_label);
      else
 comparison = compare (exp, GT, GTU);
      break;

    case GE_EXPR:
      if (((mode_class[(int)(((((((exp)->exp.operands[0]))->common.type))->type.mode))])
    == MODE_INT)
   && !can_compare_p (((((((exp)->exp.operands[0]))->common.type))->type.mode)))
 do_jump_by_parts_greater (exp, 1, if_true_label, if_false_label);
      else
 comparison = compare (exp, GE, GEU);
      break;

    default:
    normal:
      temp = expand_expr (exp, (rtx) 0, VOIDmode, 0);
      do_pending_stack_adjust ();
      if (((temp)->code) == CONST_INT)
 comparison = (temp == const0_rtx ? const0_rtx : const_true_rtx);
      else if (((temp)->code) == LABEL_REF)
 comparison = const_true_rtx;
      else if ((mode_class[(int)(((temp)->mode))]) == MODE_INT
        && !can_compare_p (((temp)->mode)))

 do_jump_by_parts_equality_rtx (temp, if_true_label, if_false_label);
      else if (((temp)->mode) != VOIDmode)
 comparison = compare_from_rtx (temp, (const_tiny_rtx[0][(int) (((temp)->mode))]),
           NE, ((((exp)->common.type))->common.unsigned_flag),
           ((temp)->mode), (rtx) 0, 0);
      else
 abort ();
    }


  emit_queue ();





  if (comparison == const_true_rtx)
    {
      if (if_true_label)
 emit_jump (if_true_label);
    }
  else if (comparison == const0_rtx)
    {
      if (if_false_label)
 emit_jump (if_false_label);
    }
  else if (comparison)
    do_jump_for_compare (comparison, if_false_label, if_true_label);

  if (drop_through_label)
    {



      do_pending_stack_adjust ();
      emit_label (drop_through_label);
    }
}






static void
do_jump_by_parts_greater(tree exp, int swap, rtx if_false_label, rtx if_true_label) asm("_do_jump_by_parts_greater");
static void
do_jump_by_parts_greater(tree exp, int swap, rtx if_false_label, rtx if_true_label)
{
  rtx op0 = expand_expr (((exp)->exp.operands[swap]), (rtx) 0, VOIDmode, 0);
  rtx op1 = expand_expr (((exp)->exp.operands[!swap]), (rtx) 0, VOIDmode, 0);
  n64_enum_machine_mode mode = ((((((exp)->exp.operands[0]))->common.type))->type.mode);
  int nwords = ((mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 8 : 4));
  rtx drop_through_label = 0;
  int unsignedp = ((((((exp)->exp.operands[0]))->common.type))->common.unsigned_flag);
  int i;

  if (! if_true_label || ! if_false_label)
    drop_through_label = gen_label_rtx ();
  if (! if_true_label)
    if_true_label = drop_through_label;
  if (! if_false_label)
    if_false_label = drop_through_label;


  for (i = 0; i < nwords; i++)
    {
      rtx comp;
      rtx op0_word, op1_word;

      if (((target_flags & 0x00010000) != 0))
 {
   op0_word = operand_subword_force (op0, i, mode);
   op1_word = operand_subword_force (op1, i, mode);
 }
      else
 {
   op0_word = operand_subword_force (op0, nwords - 1 - i, mode);
   op1_word = operand_subword_force (op1, nwords - 1 - i, mode);
 }


      comp = compare_from_rtx (op0_word, op1_word,
          (unsignedp || i > 0) ? GTU : GT,
          unsignedp, word_mode, (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_true_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, (rtx) 0, if_true_label);


      comp = compare_from_rtx (op0_word, op1_word, NE, unsignedp, word_mode,
          (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_false_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, (rtx) 0, if_false_label);
    }

  if (if_false_label)
    emit_jump (if_false_label);
  if (drop_through_label)
    emit_label (drop_through_label);
}





void
do_jump_by_parts_greater_rtx(n64_enum_machine_mode mode, int unsignedp, rtx op0, rtx op1, rtx if_false_label, rtx if_true_label) asm("_do_jump_by_parts_greater_rtx");
void
do_jump_by_parts_greater_rtx(n64_enum_machine_mode mode, int unsignedp, rtx op0, rtx op1, rtx if_false_label, rtx if_true_label)
{
  int nwords = ((mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 8 : 4));
  rtx drop_through_label = 0;
  int i;

  if (! if_true_label || ! if_false_label)
    drop_through_label = gen_label_rtx ();
  if (! if_true_label)
    if_true_label = drop_through_label;
  if (! if_false_label)
    if_false_label = drop_through_label;


  for (i = 0; i < nwords; i++)
    {
      rtx comp;
      rtx op0_word, op1_word;

      if (((target_flags & 0x00010000) != 0))
 {
   op0_word = operand_subword_force (op0, i, mode);
   op1_word = operand_subword_force (op1, i, mode);
 }
      else
 {
   op0_word = operand_subword_force (op0, nwords - 1 - i, mode);
   op1_word = operand_subword_force (op1, nwords - 1 - i, mode);
 }


      comp = compare_from_rtx (op0_word, op1_word,
          (unsignedp || i > 0) ? GTU : GT,
          unsignedp, word_mode, (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_true_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, (rtx) 0, if_true_label);


      comp = compare_from_rtx (op0_word, op1_word, NE, unsignedp, word_mode,
          (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_false_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, (rtx) 0, if_false_label);
    }

  if (if_false_label)
    emit_jump (if_false_label);
  if (drop_through_label)
    emit_label (drop_through_label);
}




static void
do_jump_by_parts_equality(tree exp, rtx if_false_label, rtx if_true_label) asm("_do_jump_by_parts_equality");
static void
do_jump_by_parts_equality(tree exp, rtx if_false_label, rtx if_true_label)
{
  rtx op0 = expand_expr (((exp)->exp.operands[0]), (rtx) 0, VOIDmode, 0);
  rtx op1 = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
  n64_enum_machine_mode mode = ((((((exp)->exp.operands[0]))->common.type))->type.mode);
  int nwords = ((mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 8 : 4));
  int i;
  rtx drop_through_label = 0;

  if (! if_false_label)
    drop_through_label = if_false_label = gen_label_rtx ();

  for (i = 0; i < nwords; i++)
    {
      rtx comp = compare_from_rtx (operand_subword_force (op0, i, mode),
       operand_subword_force (op1, i, mode),
       EQ, ((((exp)->common.type))->common.unsigned_flag),
       word_mode, (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_false_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, if_false_label, (rtx) 0);
    }

  if (if_true_label)
    emit_jump (if_true_label);
  if (drop_through_label)
    emit_label (drop_through_label);
}





static void
do_jump_by_parts_equality_rtx(rtx op0, rtx if_false_label, rtx if_true_label) asm("_do_jump_by_parts_equality_rtx");
static void
do_jump_by_parts_equality_rtx(rtx op0, rtx if_false_label, rtx if_true_label)
{
  int nwords = (mode_size[(int)(((op0)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4);
  int i;
  rtx drop_through_label = 0;

  if (! if_false_label)
    drop_through_label = if_false_label = gen_label_rtx ();

  for (i = 0; i < nwords; i++)
    {
      rtx comp = compare_from_rtx (operand_subword_force (op0, i,
         ((op0)->mode)),
       const0_rtx, EQ, 1, word_mode, (rtx) 0, 0);
      if (comp == const_true_rtx)
 emit_jump (if_false_label);
      else if (comp != const0_rtx)
 do_jump_for_compare (comp, if_false_label, (rtx) 0);
    }

  if (if_true_label)
    emit_jump (if_true_label);
  if (drop_through_label)
    emit_label (drop_through_label);
}




static void
do_jump_for_compare(rtx comparison, rtx if_false_label, rtx if_true_label) asm("_do_jump_for_compare");
static void
do_jump_for_compare(rtx comparison, rtx if_false_label, rtx if_true_label)
{
  if (if_true_label)
    {
      if (bcc_gen_fctn[(int) ((comparison)->code)] != 0)
 emit_jump_insn ((*bcc_gen_fctn[(int) ((comparison)->code)]) (if_true_label));
      else
 abort ();

      if (if_false_label)
 emit_jump (if_false_label);
    }
  else if (if_false_label)
    {
      rtx insn;
      rtx prev = get_last_insn ();
      rtx branch = 0;







      if (bcc_gen_fctn[(int) ((comparison)->code)] != 0)
 emit_jump_insn ((*bcc_gen_fctn[(int) ((comparison)->code)])(if_false_label));
      else
 abort ();






      if (prev == 0)
 insn = get_insns ();
      else if (((prev)->volatil))
 abort ();
      else
 insn = ((prev)->fld[2].rtx);

      for (; insn; insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == JUMP_INSN)
   {
     if (branch)
       abort ();
     branch = insn;
   }

      if (branch != get_last_insn ())
 abort ();

      ((branch)->fld[7].rtx) = if_false_label;
      if (! invert_jump (branch, if_false_label))
 {
   if_true_label = gen_label_rtx ();
   redirect_jump (branch, if_true_label);
   emit_jump (if_false_label);
   emit_label (if_true_label);
 }
    }
}
static rtx
compare(register tree exp, n64_enum_rtx_code signed_code, n64_enum_rtx_code unsigned_code) asm("_compare");
static rtx
compare(register tree exp, n64_enum_rtx_code signed_code, n64_enum_rtx_code unsigned_code)
{
  register rtx op0
    = expand_expr (((exp)->exp.operands[0]), (rtx) 0, VOIDmode, 0);
  register rtx op1
    = expand_expr (((exp)->exp.operands[1]), (rtx) 0, VOIDmode, 0);
  register tree type = ((((exp)->exp.operands[0]))->common.type);
  register n64_enum_machine_mode mode = ((type)->type.mode);
  int unsignedp = ((type)->common.unsigned_flag);
  n64_enum_rtx_code code = unsignedp ? unsigned_code : signed_code;

  return compare_from_rtx (op0, op1, code, unsignedp, mode,
      ((mode == BLKmode)
       ? expr_size (((exp)->exp.operands[0])) : (rtx) 0),
      ((((exp)->common.type))->type.align) / 8);
}
rtx
compare_from_rtx(register rtx op0, register rtx op1, n64_enum_rtx_code code, int unsignedp, n64_enum_machine_mode mode, rtx size, int align) asm("_compare_from_rtx");
rtx
compare_from_rtx(register rtx op0, register rtx op1, n64_enum_rtx_code code, int unsignedp, n64_enum_machine_mode mode, rtx size, int align)
{
  rtx tem;




  if (((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ! (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH))
      || (((op0)->code) == CONST_INT && ((op1)->code) != CONST_INT))
    {
      tem = op0;
      op0 = op1;
      op1 = tem;
      code = swap_condition (code);
    }

  if (flag_force_mem)
    {
      op0 = force_not_mem (op0);
      op1 = force_not_mem (op1);
    }

  do_pending_stack_adjust ();

  if (((op0)->code) == CONST_INT && ((op1)->code) == CONST_INT
      && (tem = simplify_relational_operation (code, mode, op0, op1)) != 0)
    return tem;
  emit_cmp_insn (op0, op1, code, size, mode, unsignedp, align);

  return gen_rtx (code, VOIDmode, cc0_rtx, const0_rtx);
}
static rtx
do_store_flag(tree exp, rtx target, n64_enum_machine_mode mode, int only_cheap) asm("_do_store_flag");
static rtx
do_store_flag(tree exp, rtx target, n64_enum_machine_mode mode, int only_cheap)
{
  n64_enum_rtx_code code;
  tree arg0, arg1, type;
  tree tem;
  n64_enum_machine_mode operand_mode;
  int invert = 0;
  int unsignedp;
  rtx op0, op1;
  n64_enum_insn_code icode;
  rtx subtarget = target;
  rtx result, label, pattern, jump_pat;






  if (((n64_enum_tree_code) (exp)->common.code) == TRUTH_NOT_EXPR)
    invert = 1, exp = ((exp)->exp.operands[0]);

  arg0 = ((exp)->exp.operands[0]);
  arg1 = ((exp)->exp.operands[1]);
  type = ((arg0)->common.type);
  operand_mode = ((type)->type.mode);
  unsignedp = ((type)->common.unsigned_flag);



  if (operand_mode == BLKmode)
    return 0;

  while ((((n64_enum_tree_code) (arg0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg0)->common.code) == NON_LVALUE_EXPR) && (((((arg0)->common.type))->type.mode) == ((((((arg0)->exp.operands[0]))->common.type))->type.mode))) (arg0) = ((arg0)->exp.operands[0]);;
  while ((((n64_enum_tree_code) (arg1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (arg1)->common.code) == NON_LVALUE_EXPR) && (((((arg1)->common.type))->type.mode) == ((((((arg1)->exp.operands[0]))->common.type))->type.mode))) (arg1) = ((arg1)->exp.operands[0]);;
  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case EQ_EXPR:
      code = EQ;
      break;
    case NE_EXPR:
      code = NE;
      break;
    case LT_EXPR:
      if (integer_onep (arg1))
 arg1 = integer_zero_node, code = unsignedp ? LEU : LE;
      else
 code = unsignedp ? LTU : LT;
      break;
    case LE_EXPR:
      if (! unsignedp && integer_all_onesp (arg1))
 arg1 = integer_zero_node, code = LT;
      else
 code = unsignedp ? LEU : LE;
      break;
    case GT_EXPR:
      if (! unsignedp && integer_all_onesp (arg1))
 arg1 = integer_zero_node, code = GE;
      else
 code = unsignedp ? GTU : GT;
      break;
    case GE_EXPR:
      if (integer_onep (arg1))
 arg1 = integer_zero_node, code = unsignedp ? GTU : GT;
      else
 code = unsignedp ? GEU : GE;
      break;
    default:
      abort ();
    }


  if (((n64_enum_tree_code) (arg0)->common.code) == REAL_CST || ((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST)
    {
      tem = arg0; arg0 = arg1; arg1 = tem;
      code = swap_condition (code);
    }







  if ((code == NE || code == EQ)
      && ((n64_enum_tree_code) (arg0)->common.code) == BIT_AND_EXPR && integer_zerop (arg1)
      && integer_pow2p (((arg0)->exp.operands[1]))
      && ((type)->type.precision) <= 32)
    {
      tree inner = ((arg0)->exp.operands[0]);
      int bitnum = exact_log2_wide ((int) (((expand_expr (((arg0)->exp.operands[1]), (rtx) 0, VOIDmode, 0))->fld[0].rtwint)))
                                  ;
      int ops_unsignedp;




      if (((n64_enum_tree_code) (inner)->common.code) == RSHIFT_EXPR
   && ((n64_enum_tree_code) (((inner)->exp.operands[1]))->common.code) == INTEGER_CST
   && ((((inner)->exp.operands[1]))->int_cst.int_cst_high) == 0
   && (bitnum + ((((inner)->exp.operands[1]))->int_cst.int_cst_low)
       < ((type)->type.precision)))
 {
   bitnum +=((((inner)->exp.operands[1]))->int_cst.int_cst_low);
   inner = ((inner)->exp.operands[0]);
 }




      ops_unsignedp = (bitnum == ((type)->type.precision) - 1 ? 1

         : (ZERO_EXTEND == SIGN_EXTEND ? 0 : 1)



         );

      if (subtarget == 0 || ((subtarget)->code) != REG
   || ((subtarget)->mode) != operand_mode
   || ! safe_from_p (subtarget, inner))
 subtarget = 0;

      op0 = expand_expr (inner, subtarget, VOIDmode, 0);

      if (bitnum != 0)
 op0 = expand_shift (RSHIFT_EXPR, ((op0)->mode), op0,
       size_int (bitnum), subtarget, ops_unsignedp);

      if (((op0)->mode) != mode)
 op0 = convert_to_mode (mode, op0, ops_unsignedp);

      if ((code == EQ && ! invert) || (code == NE && invert))
 op0 = expand_binop (mode, xor_optab, op0, const1_rtx, subtarget,
       ops_unsignedp, OPTAB_LIB_WIDEN);


      if (bitnum != ((type)->type.precision) - 1)
 op0 = expand_and (op0, const1_rtx, subtarget);

      return op0;
    }


  if (! can_compare_p (operand_mode))
    return 0;
  icode = setcc_gen_code[(int) code];
  if (icode == CODE_FOR_nothing
      || (only_cheap && insn_operand_mode[(int) icode][0] != mode))
    {


      if ((code == LT && integer_zerop (arg1))
   || (! only_cheap && code == GE && integer_zerop (arg1)))
 ;
      else if (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 0
        && ! only_cheap && (code == NE || code == EQ)
        && ((n64_enum_tree_code) (type)->common.code) != REAL_TYPE
        && ((abs_optab->handlers[(int) operand_mode].insn_code
      != CODE_FOR_nothing)
     || (ffs_optab->handlers[(int) operand_mode].insn_code
         != CODE_FOR_nothing)))
 ;
      else
 return 0;
    }

  preexpand_calls (exp);
  if (subtarget == 0 || ((subtarget)->code) != REG
      || ((subtarget)->mode) != operand_mode
      || ! safe_from_p (subtarget, arg1))
    subtarget = 0;

  op0 = expand_expr (arg0, subtarget, VOIDmode, 0);
  op1 = expand_expr (arg1, (rtx) 0, VOIDmode, 0);

  if (target == 0)
    target = gen_reg_rtx (mode);





  result = emit_store_flag (target, code,
       queued_subexp_p (op0) ? copy_rtx (op0) : op0,
       queued_subexp_p (op1) ? copy_rtx (op1) : op1,
       operand_mode, unsignedp, 1);

  if (result)
    {
      if (invert)
 result = expand_binop (mode, xor_optab, result, const1_rtx,
          result, 0, OPTAB_LIB_WIDEN);
      return result;
    }


  if (target == 0 || ((target)->code) != REG
      || reg_mentioned_p (target, op0) || reg_mentioned_p (target, op1))
    target = gen_reg_rtx (((target)->mode));

  emit_move_insn (target, invert ? const0_rtx : const1_rtx);
  result = compare_from_rtx (op0, op1, code, unsignedp,
        operand_mode, (rtx) 0, 0);
  if (((result)->code) == CONST_INT)
    return (((result == const0_rtx && ! invert)
      || (result != const0_rtx && invert))
     ? const0_rtx : const1_rtx);

  label = gen_label_rtx ();
  if (bcc_gen_fctn[(int) code] == 0)
    abort ();

  emit_jump_insn ((*bcc_gen_fctn[(int) code]) (label));
  emit_move_insn (target, invert ? const1_rtx : const0_rtx);
  emit_label (label);

  return target;
}
void
do_tablejump(rtx strchr, n64_enum_machine_mode mode, rtx range, rtx table_label, rtx default_label) asm("_do_tablejump");
void
do_tablejump(rtx strchr, n64_enum_machine_mode mode, rtx range, rtx table_label, rtx default_label)
{
  register rtx temp, vector;
  emit_cmp_insn (strchr, range, GTU, (rtx) 0, mode, 1, 0);
  emit_jump_insn (gen_bgtu (default_label));



  if (mode != ((target_flags & 0x00000002) ? DImode : SImode))
    strchr = convert_to_mode (((target_flags & 0x00000002) ? DImode : SImode), strchr, 1);
  strchr = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode),
     gen_rtx (MULT, ((target_flags & 0x00000002) ? DImode : SImode), strchr,
       gen_rtx (CONST_INT, VOIDmode, (int) ((mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))])))),
     gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), table_label));





    strchr = memory_address_noforce (((target_flags & 0x00000002) ? DImode : SImode), strchr);
  temp = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
  vector = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), strchr);
  ((vector)->unchanging) = 1;
  convert_move (temp, vector, 0);

  emit_jump_insn (gen_tablejump (temp, table_label));




  if (! flag_pic)
    emit_barrier ();

}
void
bc_load_memory(tree type, tree decl) asm("_bc_load_memory");
void
bc_load_memory(tree type, tree decl)
{
  n64_enum_bytecode_opcode opcode;






  if (((decl)->decl.bit_field_flag))
    if (((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
 || ((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE)
      opcode = ((type)->common.unsigned_flag) ? zxloadBI : sxloadBI;
    else
      abort ();
  else

    if (((type)->type.mode) == BLKmode
 || ((type)->type.mode) == VOIDmode)
      return;
    else
      opcode = mode_to_load_map [(int) ((type)->type.mode)];

  if (opcode == neverneverland)
    abort ();

  bc_emit_bytecode (opcode);




}






void
bc_store_memory(tree type, tree decl) asm("_bc_store_memory");
void
bc_store_memory(tree type, tree decl)
{
  n64_enum_bytecode_opcode opcode;


  if (((decl)->decl.bit_field_flag))
    {
      if (((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
   || ((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE)
 opcode = sstoreBI;
      else
 abort ();
    }
  else
    if (((type)->type.mode) == BLKmode)
      {
 bc_expand_expr (((type)->type.size));
 opcode = storeBLK;
      }
    else
      opcode = mode_to_store_map [(int) ((type)->type.mode)];

  if (opcode == neverneverland)
    abort ();

  bc_emit_bytecode (opcode);




}
rtx
bc_allocate_local(int size, int alignment) asm("_bc_allocate_local");
rtx
bc_allocate_local(int size, int alignment)
{
  rtx retval;
  int byte_alignment;

  if (size < 0)
    abort ();


  if (!size)
    size = ((target_flags & 0x00002000) ? 8 : 4);

  if (alignment < 8)
    byte_alignment = 1 << (1 - 1);
  else

    byte_alignment = alignment / 8;

  if (local_vars_size & (byte_alignment - 1))
    local_vars_size += byte_alignment - (local_vars_size & (byte_alignment - 1));

  retval = bc_gen_rtx ((char *) 0, local_vars_size, (struct n64_tag_bc_label *) 0);
  local_vars_size += size;

  return retval;
}





rtx
bc_allocate_variable_array(tree size) asm("_bc_allocate_variable_array");
rtx
bc_allocate_variable_array(tree size)
{
  rtx retval;
  const int ptralign = (1 << (1 - 1));


  if (local_vars_size & ptralign)
    local_vars_size += ptralign - (local_vars_size & ptralign);




  retval = bc_gen_rtx ((char *) 0, local_vars_size, (struct n64_tag_bc_label *) 0);
  local_vars_size += ((target_flags & 0x00000002) ? 64 : 32) / 8;
  return retval;
}



void
bc_load_externaddr(rtx externaddr) asm("_bc_load_externaddr");
void
bc_load_externaddr(rtx externaddr)
{
  bc_emit_bytecode (constP);
  bc_emit_code_labelref (((((externaddr))->fld[0].rtx)),
    (*(struct n64_tag_bc_label **) &(((externaddr))->fld[1].rtx))->offset);




}


static char *
bc_strdup(char *s) asm("_bc_strdup");
static char *
bc_strdup(char *s)
{
  char *cxx_new = (char *) xmalloc ((strlen (s) + 1) * sizeof *s);
  strcpy (cxx_new, s);
  return cxx_new;
}



void
bc_load_externaddr_id(tree id, int offset) asm("_bc_load_externaddr_id");
void
bc_load_externaddr_id(tree id, int offset)
{
  if (!((id)->identifier.pointer))
    abort ();

  bc_emit_bytecode (constP);
  bc_emit_code_labelref (bc_xstrdup (((id)->identifier.pointer)), offset);




}



void
bc_load_localaddr(rtx localaddr) asm("_bc_load_localaddr");
void
bc_load_localaddr(rtx localaddr)
{
  bc_emit_instruction (localP, (int) (*(struct n64_tag_bc_label **) &(((localaddr))->fld[1].rtx))->offset);
}




void
bc_load_parmaddr(rtx parmaddr) asm("_bc_load_parmaddr");
void
bc_load_parmaddr(rtx parmaddr)
{
  bc_emit_instruction (argP, ((int) (*(struct n64_tag_bc_label **) &(((parmaddr))->fld[1].rtx))->offset
         / 8));
}



tree
bc_canonicalize_array_ref(tree exp) asm("_bc_canonicalize_array_ref");
tree
bc_canonicalize_array_ref(tree exp)
{
  tree type = ((exp)->common.type);
  tree array_adr = build1 (ADDR_EXPR, ((type)->type.pointer_to),
      ((exp)->exp.operands[0]));
  tree strchr = ((exp)->exp.operands[1]);





  if (((((strchr)->common.type))->type.precision) != ((target_flags & 0x00000002) ? 64 : 32))
    strchr = convert (type_for_size (((target_flags & 0x00000002) ? 64 : 32), 0), strchr);




  ((array_adr)->common.volatile_flag) = 0;

  return build1 (INDIRECT_REF, type,
   fold (build (PLUS_EXPR,
         ((type)->type.pointer_to),
         array_adr,
         fold (build (MULT_EXPR,
        ((type)->type.pointer_to),
        strchr,
        size_in_bytes (type))))));
}







tree
bc_expand_component_address(tree exp) asm("_bc_expand_component_address");
tree
bc_expand_component_address(tree exp)
{
  tree tem, chain;
  n64_enum_machine_mode mode;
  int bitpos = 0;
  int SIval;


  tem = ((exp)->exp.operands[1]);
  mode = ((tem)->decl.mode);





  for (tem = exp;; tem = ((tem)->exp.operands[0]))
    {
      if (((n64_enum_tree_code) (tem)->common.code) == COMPONENT_REF)
 bitpos += ((((((tem)->exp.operands[1]))->decl.arguments))->int_cst.int_cst_low);
      else
 if (((n64_enum_tree_code) (tem)->common.code) == ARRAY_REF
     && ((n64_enum_tree_code) (((tem)->exp.operands[1]))->common.code) == INTEGER_CST
     && ((n64_enum_tree_code) (((((tem)->common.type))->type.size))->common.code) == INTEGER_CST)

   bitpos += (((((tem)->exp.operands[1]))->int_cst.int_cst_low)
       * ((((((tem)->common.type))->type.size))->int_cst.int_cst_low)
                                               );
 else
   break;
    }

  bc_expand_expr (tem);



  if (((((exp)->exp.operands[1]))->decl.bit_field_flag))
    bc_push_offset_and_size (bitpos, (((exp)->exp.operands[1])));
  else
    if (SIval = bitpos / 8)
      bc_emit_instruction (addconstPSI, SIval);

  return (((exp)->exp.operands[1]));
}



void
bc_push_offset_and_size(int offset, int size) asm("_bc_push_offset_and_size");
void
bc_push_offset_and_size(int offset, int size)
{
  bc_emit_instruction (constSI, offset);
  bc_emit_instruction (constSI, size);
}
tree
bc_expand_address(tree exp) asm("_bc_expand_address");
tree
bc_expand_address(tree exp)
{

  if (!exp || ((n64_enum_tree_code) (exp)->common.code) == ERROR_MARK)
    return (exp);


  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case ARRAY_REF:

      return (bc_expand_address (bc_canonicalize_array_ref (exp)));

    case COMPONENT_REF:

      return (bc_expand_component_address (exp));

    case INDIRECT_REF:

      bc_expand_expr (((exp)->exp.operands[0]));





      if (((exp)->exp.operands[0])
   && ((((((exp)->exp.operands[0]))->common.type))->type.size)
   && ((n64_enum_tree_code) (((((((exp)->exp.operands[0]))->common.type))->type.size))->common.code) != INTEGER_CST)
 bc_emit_instruction (loadP);


      if (((((exp)->exp.operands[0]))->decl.bit_field_flag))

 bc_push_offset_and_size (((((((exp)->exp.operands[0]))->decl.arguments))->int_cst.int_cst_low),
     ((((((exp)->exp.operands[0]))->decl.size))->int_cst.int_cst_low));

      return (((exp)->exp.operands[0]));

    case FUNCTION_DECL:

      bc_load_externaddr_id (((exp)->decl.assembler_name),
        (*(struct n64_tag_bc_label **) &(((((exp)->decl.rtl)))->fld[1].rtx))->offset);
      break;

    case PARM_DECL:

      bc_load_parmaddr (((exp)->decl.rtl));


      if (((((exp)->common.type))->type.size)
   && ((n64_enum_tree_code) (((((exp)->common.type))->type.size))->common.code) != INTEGER_CST)
 bc_emit_instruction (loadP);


      if (((exp)->decl.bit_field_flag))
 bc_push_offset_and_size (((((exp)->decl.arguments))->int_cst.int_cst_low),
     ((((exp)->decl.size))->int_cst.int_cst_low));

      break;

    case RESULT_DECL:

      bc_emit_instruction (returnP);
      break;

    case VAR_DECL:






      if (((exp)->decl.external_flag))
 bc_load_externaddr_id (((exp)->decl.assembler_name),
          ((*(struct n64_tag_bc_label **) &(((((exp)->decl.rtl)))->fld[1].rtx)))->offset);
      else
 bc_load_localaddr (((exp)->decl.rtl));


      if (((((exp)->common.type))->type.size)
   && ((n64_enum_tree_code) (((((exp)->common.type))->type.size))->common.code) != INTEGER_CST)
 bc_emit_instruction (loadP);


      if (((exp)->decl.bit_field_flag))
 bc_push_offset_and_size (((((exp)->decl.arguments))->int_cst.int_cst_low),
     ((((exp)->decl.size))->int_cst.int_cst_low));

      break;

    case STRING_CST:
      {
 rtx r;

 bc_emit_bytecode (constP);
 r = output_constant_def (exp);
 bc_emit_code_labelref (((((r))->fld[0].rtx)), (*(struct n64_tag_bc_label **) &(((r))->fld[1].rtx))->offset);




      }
      break;

    default:

      abort();
      break;
    }


  return (exp);
}






tree
bc_runtime_type_code(tree type) asm("_bc_runtime_type_code");
tree
bc_runtime_type_code(tree type)
{
  int val;

  switch (((n64_enum_tree_code) (type)->common.code))
    {
    case VOID_TYPE:
    case INTEGER_TYPE:
    case REAL_TYPE:
    case COMPLEX_TYPE:
    case ENUMERAL_TYPE:
    case POINTER_TYPE:
    case RECORD_TYPE:

      val = (int) ((type)->type.mode) | ((type)->type.align) << 8;
      break;

    case ERROR_MARK:

      val = 0;
      break;

    default:

      abort ();
    }
  return build_int_2_wide ((int) (val), (int) (0));
}



char *
bc_gen_constr_label(void) asm("_bc_gen_constr_label");
char *
bc_gen_constr_label(void)
{
  static int label_counter;
  static char label[20];

  sprintf (label, "*LR%d", label_counter++);

  return (__extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((strlen (label))); if (__o->next_free + __len + 1 > __o->chunk_limit) _obstack_newchunk (__o, __len + 1); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((label)),__len); __o->next_free += __len; *(__o->next_free)++ = 0; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); }));
}
void
bc_expand_constructor(tree constr) asm("_bc_expand_constructor");
void
bc_expand_constructor(tree constr)
{
  char *l;
  int ptroffs;
  rtx constr_rtx;
  l = bc_gen_constr_label ();

  if (((constr)->common.constant_flag))
    {
      text_section ();

      bc_emit_const_labeldef (l);
      bc_output_constructor (constr, int_size_in_bytes (((constr)->common.type)));
    }
  else
    {
      data_section ();

      bc_emit_data_labeldef (l);
      bc_output_data_constructor (constr);
    }






  ptroffs = bc_define_pointer (l);
  bc_emit_instruction (constP, ptroffs);


  if (((constr)->common.constant_flag))
    return;






  if (((n64_enum_tree_code) (((constr)->common.type))->common.code) == RECORD_TYPE)
    {
      register tree elt;




      if (list_length (((constr)->exp.operands[1]))
   != list_length (((((constr)->common.type))->type.values)))
 {
   bc_emit_instruction (duplicate);
   bc_emit_instruction (constSI, (int) int_size_in_bytes (((constr)->common.type)));
   bc_emit_instruction (clearBLK);
 }




      for (elt = ((constr)->exp.operands[1]); elt; elt = ((elt)->common.chain))
 {
   register tree field = ((elt)->list.purpose);
   register n64_enum_machine_mode mode;
   int bitsize;
   int bitpos;
   int unsignedp;

   bitsize = ((((field)->decl.size))->int_cst.int_cst_low) ;
   mode = ((field)->decl.mode);
   unsignedp = ((field)->common.unsigned_flag);

   bitpos = ((((field)->decl.arguments))->int_cst.int_cst_low);

   bc_store_field (elt, bitsize, bitpos, mode, ((elt)->list.value), ((((elt)->list.value))->common.type),


     VOIDmode, 0,
     ((((constr)->common.type))->type.align) / 8,
     int_size_in_bytes (((constr)->common.type)));
 }
    }
  else


    if (((n64_enum_tree_code) (((constr)->common.type))->common.code) == ARRAY_TYPE)
      {
 register tree elt;
 register int i;
 tree domain = ((((constr)->common.type))->type.values);
 int minelt = ((((domain)->type.minval))->int_cst.int_cst_low);
 int maxelt = ((((domain)->type.maxval))->int_cst.int_cst_low);
 tree elttype = ((((constr)->common.type))->common.type);




 if (list_length (((constr)->exp.operands[1])) < maxelt - minelt + 1)
   {
     bc_emit_instruction (duplicate);
     bc_emit_instruction (constSI, (int) int_size_in_bytes (((constr)->common.type)));
     bc_emit_instruction (clearBLK);
   }





 for (elt = ((constr)->exp.operands[1]), i = 0;
      elt;
      elt = ((elt)->common.chain), i++)
   {
     register n64_enum_machine_mode mode;
     int bitsize;
     int bitpos;
     int unsignedp;

     mode = ((elttype)->type.mode);
     bitsize = (8 * mode_size[(int)(mode)]);
     unsignedp = ((elttype)->common.unsigned_flag);

     bitpos = (i * ((((elttype)->type.size))->int_cst.int_cst_low)
                                         );

     bc_store_field (elt, bitsize, bitpos, mode,
       ((elt)->list.value), ((((elt)->list.value))->common.type),


       VOIDmode, 0,
       ((((constr)->common.type))->type.align) / 8,
       int_size_in_bytes (((constr)->common.type)));
   }

      }
}
void
bc_store_field(tree field, int bitsize, int bitpos, n64_enum_machine_mode mode, tree exp, tree type, n64_enum_machine_mode value_mode, int unsignedp, int align, int total_size) asm("_bc_store_field");
void
bc_store_field(tree field, int bitsize, int bitpos, n64_enum_machine_mode mode, tree exp, tree type, n64_enum_machine_mode value_mode, int unsignedp, int align, int total_size)
{


  bc_expand_expr (exp);
  bc_emit_instruction (over);





  if (((field)->decl.bit_field_flag))
    {
      bc_store_bit_field (bitpos, bitsize, unsignedp);
      return;
    }
  else

    {
      int offset = bitpos / 8;


      if (offset)
 bc_emit_instruction (addconstPSI, offset);


      bc_store_memory (type, field);
    }
}



void
bc_store_bit_field(int offset, int size, int unsignedp) asm("_bc_store_bit_field");
void
bc_store_bit_field(int offset, int size, int unsignedp)
{

  bc_push_offset_and_size (offset, size);


  bc_emit_instruction (sstoreBI);
}



void
bc_load_bit_field(int offset, int size, int unsignedp) asm("_bc_load_bit_field");
void
bc_load_bit_field(int offset, int size, int unsignedp)
{

  bc_push_offset_and_size (offset, size);


  bc_emit_instruction (unsignedp ? zxloadBI : sxloadBI);
}







void
bc_adjust_stack(int nlevels) asm("_bc_adjust_stack");
void
bc_adjust_stack(int nlevels)
{
  switch (nlevels)
    {
    case 0:
      break;

    case 2:
      bc_emit_instruction (drop);

    case 1:
      bc_emit_instruction (drop);
      break;

    default:

      bc_emit_instruction (adjstackSI, (int) nlevels);
      stack_depth -= nlevels;
    }




}

