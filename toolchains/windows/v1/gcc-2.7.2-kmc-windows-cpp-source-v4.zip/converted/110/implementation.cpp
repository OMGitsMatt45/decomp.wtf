// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/linker.c
/* linker.c -- BFD linker routines
   Copyright (C) 1993, 1994, 1995 Free Software Foundation, Inc.
   Written by Steve Chamberlain and Ian Lance Taylor, Cygnus Support

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_archive_hash_entry;
struct n64_tag_archive_hash_table;
struct n64_tag_archive_list;
struct n64_tag_areltdata;
struct n64_tag_artdata;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_generic_link_hash_entry;
struct n64_tag_generic_link_hash_table;
struct n64_tag_generic_write_global_symbol_info;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct ecoff_debug_info * const, const struct ecoff_debug_swap * const, struct ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");
enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
struct n64_tag_generic_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;

  boolean written;

  asymbol *sym;
};



struct n64_tag_generic_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;
};
extern boolean _bfd_generic_link_output_symbols
  (bfd *output_bfd, bfd *input_bfd, struct n64_tag_bfd_link_info *, size_t *psymalloc) asm("__bfd_generic_link_output_symbols")
                       ;





struct n64_tag_generic_write_global_symbol_info
{
  struct n64_tag_bfd_link_info *info;
  bfd *output_bfd;
  size_t *psymalloc;
};




extern boolean _bfd_generic_link_write_global_symbol
  (struct n64_tag_generic_link_hash_entry *, void *) asm("__bfd_generic_link_write_global_symbol");
static struct n64_tag_bfd_hash_entry *generic_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_generic_link_hash_newfunc")
                  ;
static boolean generic_link_read_symbols
  (bfd *) asm("_generic_link_read_symbols");
static boolean generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean collect) asm("_generic_link_add_symbols");
static boolean generic_link_add_object_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean collect) asm("_generic_link_add_object_symbols");
static boolean generic_link_check_archive_element_no_collect
  (bfd *, struct n64_tag_bfd_link_info *, boolean *pneeded) asm("_generic_link_check_archive_element_no_collect");
static boolean generic_link_check_archive_element_collect
  (bfd *, struct n64_tag_bfd_link_info *, boolean *pneeded) asm("_generic_link_check_archive_element_collect");
static boolean generic_link_check_archive_element
  (bfd *, struct n64_tag_bfd_link_info *, boolean *pneeded, boolean collect) asm("_generic_link_check_archive_element");
static boolean generic_link_add_symbol_list
  (bfd *, struct n64_tag_bfd_link_info *, bfd_size_type count, asymbol **, boolean collect) asm("_generic_link_add_symbol_list")
                     ;
static bfd *hash_entry_bfd (struct n64_tag_bfd_link_hash_entry *) asm("_hash_entry_bfd");
static void set_symbol_from_hash
  (asymbol *, struct n64_tag_bfd_link_hash_entry *) asm("_set_symbol_from_hash");
static boolean generic_add_output_symbol
  (bfd *, size_t *psymalloc, asymbol *) asm("_generic_add_output_symbol");
static boolean default_fill_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("_default_fill_link_order")
                             ;
static boolean default_indirect_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *, boolean) asm("_default_indirect_link_order")
                                      ;







struct n64_tag_bfd_hash_entry *
_bfd_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc");
struct n64_tag_bfd_hash_entry *
_bfd_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string)
{
  struct n64_tag_bfd_link_hash_entry *ret = (struct n64_tag_bfd_link_hash_entry *) entry;



  if (ret == (struct n64_tag_bfd_link_hash_entry *) 
                                           ((void *)0)
                                               )
    ret = ((struct n64_tag_bfd_link_hash_entry *)
    bfd_hash_allocate (table, sizeof (struct n64_tag_bfd_link_hash_entry)));
  if (ret == (struct n64_tag_bfd_link_hash_entry *) 
                                           ((void *)0)
                                               )
    return 
          ((void *)0)
              ;


  ret = ((struct n64_tag_bfd_link_hash_entry *)
  bfd_hash_newfunc ((struct n64_tag_bfd_hash_entry *) ret, table, string));

  if (ret)
    {

      ret->type = bfd_link_hash_new;
      ret->next = 
                 ((void *)0)
                     ;
    }

  return (struct n64_tag_bfd_hash_entry *) ret;
}




boolean
_bfd_link_hash_table_init(struct n64_tag_bfd_link_hash_table *table, bfd *abfd, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init");
boolean
_bfd_link_hash_table_init(struct n64_tag_bfd_link_hash_table *table, bfd *abfd, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *))
{
  table->creator = abfd->xvec;
  table->undefs = 
                 ((void *)0)
                     ;
  table->undefs_tail = 
                      ((void *)0)
                          ;
  return bfd_hash_table_init (&table->table, newfunc);
}





struct n64_tag_bfd_link_hash_entry *
bfd_link_hash_lookup(struct n64_tag_bfd_link_hash_table *table, const char *string, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup");
struct n64_tag_bfd_link_hash_entry *
bfd_link_hash_lookup(struct n64_tag_bfd_link_hash_table *table, const char *string, boolean create, boolean copy, boolean follow)
{
  struct n64_tag_bfd_link_hash_entry *ret;

  ret = ((struct n64_tag_bfd_link_hash_entry *)
  bfd_hash_lookup (&table->table, string, create, copy));

  if (follow && ret != (struct n64_tag_bfd_link_hash_entry *) 
                                                     ((void *)0)
                                                         )
    {
      while (ret->type == bfd_link_hash_indirect
      || ret->type == bfd_link_hash_warning)
 ret = ret->u.i.link;
    }

  return ret;
}







void
bfd_link_hash_traverse(struct n64_tag_bfd_link_hash_table *table, boolean (*func) (struct n64_tag_bfd_link_hash_entry *, void *), void *info) asm("_bfd_link_hash_traverse");
void
bfd_link_hash_traverse(struct n64_tag_bfd_link_hash_table *table, boolean (*func) (struct n64_tag_bfd_link_hash_entry *, void *), void *info)
{
  bfd_hash_traverse (&table->table,
       ((boolean (*) (struct n64_tag_bfd_hash_entry *, void *))
        func),
       info);
}



 void
bfd_link_add_undef(struct n64_tag_bfd_link_hash_table *table, struct n64_tag_bfd_link_hash_entry *h) asm("_bfd_link_add_undef");
 void
bfd_link_add_undef(struct n64_tag_bfd_link_hash_table *table, struct n64_tag_bfd_link_hash_entry *h)
{
  { if (!(h->next == 
 ((void *)0)
 )) bfd_assert("linker.c",544); };
  if (table->undefs_tail != (struct n64_tag_bfd_link_hash_entry *) 
                                                          ((void *)0)
                                                              )
    table->undefs_tail->next = h;
  if (table->undefs == (struct n64_tag_bfd_link_hash_entry *) 
                                                     ((void *)0)
                                                         )
    table->undefs = h;
  table->undefs_tail = h;
}



static struct n64_tag_bfd_hash_entry *
generic_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("_generic_link_hash_newfunc");
static struct n64_tag_bfd_hash_entry *
generic_link_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string)
{
  struct n64_tag_generic_link_hash_entry *ret =
    (struct n64_tag_generic_link_hash_entry *) entry;



  if (ret == (struct n64_tag_generic_link_hash_entry *) 
                                               ((void *)0)
                                                   )
    ret = ((struct n64_tag_generic_link_hash_entry *)
    bfd_hash_allocate (table, sizeof (struct n64_tag_generic_link_hash_entry)));
  if (ret == (struct n64_tag_generic_link_hash_entry *) 
                                               ((void *)0)
                                                   )
    return 
          ((void *)0)
              ;


  ret = ((struct n64_tag_generic_link_hash_entry *)
  _bfd_link_hash_newfunc ((struct n64_tag_bfd_hash_entry *) ret,
     table, string));

  if (ret)
    {

      ret->written = cxx_false;
      ret->sym = 
                ((void *)0)
                    ;
    }

  return (struct n64_tag_bfd_hash_entry *) ret;
}



struct n64_tag_bfd_link_hash_table *
_bfd_generic_link_hash_table_create(bfd *abfd) asm("__bfd_generic_link_hash_table_create");
struct n64_tag_bfd_link_hash_table *
_bfd_generic_link_hash_table_create(bfd *abfd)
{
  struct n64_tag_generic_link_hash_table *ret;

  ret = ((struct n64_tag_generic_link_hash_table *)
  bfd_alloc (abfd, sizeof (struct n64_tag_generic_link_hash_table)));
  if (ret == 
            ((void *)0)
                )
    {
      bfd_set_error (bfd_error_no_memory);
      return (struct n64_tag_bfd_link_hash_table *) 
                                           ((void *)0)
                                               ;
    }
  if (! _bfd_link_hash_table_init (&ret->root, abfd,
       generic_link_hash_newfunc))
    {
      free (ret);
      return (struct n64_tag_bfd_link_hash_table *) 
                                           ((void *)0)
                                               ;
    }
  return &ret->root;
}
static boolean
generic_link_read_symbols(bfd *abfd) asm("_generic_link_read_symbols");
static boolean
generic_link_read_symbols(bfd *abfd)
{
  if (abfd->outsymbols == (asymbol **) 
                                      ((void *)0)
                                          )
    {
      long symsize;
      long symcount;

      symsize = ((*((abfd)->xvec->_bfd_get_symtab_upper_bound)) (abfd));
      if (symsize < 0)
 return cxx_false;
      abfd->outsymbols = (asymbol **) bfd_alloc (abfd, symsize);
      if (abfd->outsymbols == 
                             ((void *)0) 
                                  && symsize != 0)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      symcount = ((*((abfd)->xvec->_bfd_canonicalize_symtab)) (abfd, abfd->outsymbols));
      if (symcount < 0)
 return cxx_false;
      abfd->symcount = symcount;
    }

  return cxx_true;
}





boolean
_bfd_generic_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("__bfd_generic_link_add_symbols");
boolean
_bfd_generic_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  return generic_link_add_symbols (abfd, info, cxx_false);
}
boolean
_bfd_generic_link_add_symbols_collect(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("__bfd_generic_link_add_symbols_collect");
boolean
_bfd_generic_link_add_symbols_collect(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  return generic_link_add_symbols (abfd, info, cxx_true);
}



static boolean
generic_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean collect) asm("_generic_link_add_symbols");
static boolean
generic_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean collect)
{
  boolean ret;

  switch (((abfd)->format))
    {
    case bfd_object:
      ret = generic_link_add_object_symbols (abfd, info, collect);
      break;
    case bfd_archive:
      ret = (_bfd_generic_link_add_archive_symbols
      (abfd, info,
       (collect
        ? generic_link_check_archive_element_collect
        : generic_link_check_archive_element_no_collect)));
      break;
    default:
      bfd_set_error (bfd_error_wrong_format);
      ret = cxx_false;
    }

  return ret;
}



static boolean
generic_link_add_object_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean collect) asm("_generic_link_add_object_symbols");
static boolean
generic_link_add_object_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean collect)
{
  if (! generic_link_read_symbols (abfd))
    return cxx_false;
  return generic_link_add_symbol_list (abfd, info,
           ((abfd)->symcount),
           ((abfd)->outsymbols),
           collect);
}






struct n64_tag_archive_list
{
  struct n64_tag_archive_list *next;
  int indx;
};



struct n64_tag_archive_hash_entry
{
  struct n64_tag_bfd_hash_entry root;

  struct n64_tag_archive_list *defs;
};



struct n64_tag_archive_hash_table
{
  struct n64_tag_bfd_hash_table table;
};

static struct n64_tag_bfd_hash_entry *archive_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_archive_hash_newfunc");
static boolean archive_hash_table_init
  (struct n64_tag_archive_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_archive_hash_table_init")


                          ;



static struct n64_tag_bfd_hash_entry *
archive_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("_archive_hash_newfunc");
static struct n64_tag_bfd_hash_entry *
archive_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string)
{
  struct n64_tag_archive_hash_entry *ret = (struct n64_tag_archive_hash_entry *) entry;



  if (ret == (struct n64_tag_archive_hash_entry *) 
                                          ((void *)0)
                                              )
    ret = ((struct n64_tag_archive_hash_entry *)
    bfd_hash_allocate (table, sizeof (struct n64_tag_archive_hash_entry)));
  if (ret == (struct n64_tag_archive_hash_entry *) 
                                          ((void *)0)
                                              )
    return 
          ((void *)0)
              ;


  ret = ((struct n64_tag_archive_hash_entry *)
  bfd_hash_newfunc ((struct n64_tag_bfd_hash_entry *) ret, table, string));

  if (ret)
    {

      ret->defs = (struct n64_tag_archive_list *) 
                                         ((void *)0)
                                             ;
    }

  return (struct n64_tag_bfd_hash_entry *) ret;
}



static boolean
archive_hash_table_init(struct n64_tag_archive_hash_table *table, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_archive_hash_table_init");
static boolean
archive_hash_table_init(struct n64_tag_archive_hash_table *table, struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *))
{
  return bfd_hash_table_init (&table->table, newfunc);
}
boolean
_bfd_generic_link_add_archive_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols");
boolean
_bfd_generic_link_add_archive_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *))
{
  carsym *arsyms;
  carsym *arsym_end;
  register carsym *arsym;
  int pass;
  struct n64_tag_archive_hash_table arsym_hash;
  int indx;
  struct n64_tag_bfd_link_hash_entry **pundef;

  if (! ((abfd)->has_armap))
    {

      if (bfd_openr_next_archived_file (abfd, (bfd *) 
                                                     ((void *)0)
                                                         ) == 
                                                              ((void *)0)
                                                                  )
 return cxx_true;
      bfd_set_error (bfd_error_no_armap);
      return cxx_false;
    }

  arsyms = ((abfd)->tdata.aout_ar_data)->symdefs;
  arsym_end = arsyms + ((abfd)->tdata.aout_ar_data)->symdef_count;



  if (! archive_hash_table_init (&arsym_hash, archive_hash_newfunc))
    return cxx_false;
  for (arsym = arsyms, indx = 0; arsym < arsym_end; arsym++, indx++)
    {
      struct n64_tag_archive_hash_entry *arh;
      struct n64_tag_archive_list *l, **pp;

      arh = ((struct n64_tag_archive_hash_entry *) bfd_hash_lookup (&(&arsym_hash)->table, (arsym->name), (cxx_true), (cxx_false)));
      if (arh == (struct n64_tag_archive_hash_entry *) 
                                              ((void *)0)
                                                  )
 goto error_return;
      l = ((struct n64_tag_archive_list *)
    bfd_hash_allocate (&(&arsym_hash)->table, (sizeof (struct n64_tag_archive_list))));
      if (l == 
              ((void *)0)
                  )
 goto error_return;
      l->indx = indx;
      for (pp = &arh->defs;
    *pp != (struct n64_tag_archive_list *) 
                                  ((void *)0)
                                      ;
    pp = &(*pp)->next)
 ;
      *pp = l;
      l->next = 
               ((void *)0)
                   ;
    }




  pass = abfd->archive_pass + 1;



  pundef = &info->hash->undefs;
  while (*pundef != (struct n64_tag_bfd_link_hash_entry *) 
                                                  ((void *)0)
                                                      )
    {
      struct n64_tag_bfd_link_hash_entry *h;
      struct n64_tag_archive_hash_entry *arh;
      struct n64_tag_archive_list *l;

      h = *pundef;



      if (h->type != bfd_link_hash_undefined
   && h->type != bfd_link_hash_common)
 {







   if (*pundef != info->hash->undefs_tail)
     *pundef = (*pundef)->next;
   else
     pundef = &(*pundef)->next;
   continue;
 }


      arh = ((struct n64_tag_archive_hash_entry *) bfd_hash_lookup (&(&arsym_hash)->table, (h->root.string), (cxx_false), (cxx_false)));
      if (arh == (struct n64_tag_archive_hash_entry *) 
                                              ((void *)0)
                                                  )
 {
   pundef = &(*pundef)->next;
   continue;
 }


      for (l = arh->defs; l != (struct n64_tag_archive_list *) 
                                                      ((void *)0)
                                                          ; l = l->next)
 {
   bfd *element;
   boolean needed;


   if (h->type != bfd_link_hash_undefined
       && h->type != bfd_link_hash_common)
     break;

   element = bfd_get_elt_at_index (abfd, l->indx);
   if (element == (bfd *) 
                         ((void *)0)
                             )
     goto error_return;



   if (element->archive_pass == -1
       || element->archive_pass == pass)
     continue;


   if (! bfd_check_format (element, bfd_object))
     {
       element->archive_pass = -1;
       continue;
     }



   if (! (*checkfn) (element, info, &needed))
     goto error_return;

   if (! needed)
     element->archive_pass = pass;
   else
     {
       element->archive_pass = -1;



       ++pass;
     }
 }

      pundef = &(*pundef)->next;
    }

  bfd_hash_table_free (&(&arsym_hash)->table);


  abfd->archive_pass = pass;

  return cxx_true;

 error_return:
  bfd_hash_table_free (&(&arsym_hash)->table);
  return cxx_false;
}






static boolean
generic_link_check_archive_element_no_collect(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded) asm("_generic_link_check_archive_element_no_collect");
static boolean
generic_link_check_archive_element_no_collect(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded)
{
  return generic_link_check_archive_element (abfd, info, pneeded, cxx_false);
}





static boolean
generic_link_check_archive_element_collect(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded) asm("_generic_link_check_archive_element_collect");
static boolean
generic_link_check_archive_element_collect(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded)
{
  return generic_link_check_archive_element (abfd, info, pneeded, cxx_true);
}




static boolean
generic_link_check_archive_element(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded, boolean collect) asm("_generic_link_check_archive_element");
static boolean
generic_link_check_archive_element(bfd *abfd, struct n64_tag_bfd_link_info *info, boolean *pneeded, boolean collect)
{
  asymbol **pp, **ppend;

  *pneeded = cxx_false;

  if (! generic_link_read_symbols (abfd))
    return cxx_false;

  pp = ((abfd)->outsymbols);
  ppend = pp + ((abfd)->symcount);
  for (; pp < ppend; pp++)
    {
      asymbol *p;
      struct n64_tag_bfd_link_hash_entry *h;

      p = *pp;


      if (! (((p->section)->flags & 0x8000) != 0)
   && (p->flags & (0x02 | 0x2000 | 0x80)) == 0)
 continue;






      h = bfd_link_hash_lookup (info->hash, ((p)->name), cxx_false,
    cxx_false, cxx_true);
      if (h == (struct n64_tag_bfd_link_hash_entry *) 
                                             ((void *)0)
   
  || (h->type != bfd_link_hash_undefined
       && h->type != bfd_link_hash_common))
 continue;



      if (! (((p->section)->flags & 0x8000) != 0))
 {
   bfd_size_type symcount;
   asymbol **symbols;


   if (! (*info->callbacks->add_archive_element) (info, abfd,
        ((p)->name)))
     return cxx_false;
   symcount = ((abfd)->symcount);
   symbols = ((abfd)->outsymbols);
   if (! generic_link_add_symbol_list (abfd, info, symcount,
           symbols, collect))
     return cxx_false;
   *pneeded = cxx_true;
   return cxx_true;
 }



      if (h->type == bfd_link_hash_undefined)
 {
   bfd *symbfd;
   bfd_vma size;
   unsigned int power;

   symbfd = h->u.undef.abfd;
   if (symbfd == (bfd *) 
                        ((void *)0)
                            )
     {



       if (! (*info->callbacks->add_archive_element)
    (info, abfd, ((p)->name)))
  return cxx_false;
       *pneeded = cxx_true;
       return cxx_true;
     }
   h->type = bfd_link_hash_common;
   h->u.c.p =
     ((struct n64_tag_bfd_link_hash_common_entry *)
      bfd_hash_allocate (&info->hash->table,
    sizeof (struct n64_tag_bfd_link_hash_common_entry)));
   if (h->u.c.p == 
                  ((void *)0)
                      )
     return cxx_false;

   size = (((p)->section->vma) + (p)->value);
   h->u.c.size = size;

   power = bfd_log2 (size);
   if (power > 4)
     power = 4;
   h->u.c.p->alignment_power = power;

   if (p->section == ((asection *) &bfd_com_section))
     h->u.c.p->section = bfd_make_section_old_way (symbfd, "COMMON");
   else
     h->u.c.p->section = bfd_make_section_old_way (symbfd,
         p->section->name);
   h->u.c.p->section->flags = 0x001;
 }
      else
 {




   if ((((p)->section->vma) + (p)->value) > h->u.c.size)
     h->u.c.size = (((p)->section->vma) + (p)->value);
 }
    }


  return cxx_true;
}







static boolean
generic_link_add_symbol_list(bfd *abfd, struct n64_tag_bfd_link_info *info, bfd_size_type symbol_count, asymbol **symbols, boolean collect) asm("_generic_link_add_symbol_list");
static boolean
generic_link_add_symbol_list(bfd *abfd, struct n64_tag_bfd_link_info *info, bfd_size_type symbol_count, asymbol **symbols, boolean collect)
{
  asymbol **pp, **ppend;

  pp = symbols;
  ppend = symbols + symbol_count;
  for (; pp < ppend; pp++)
    {
      asymbol *p;

      p = *pp;

      if ((p->flags & (0x2000
         | 0x1000
         | 0x02
         | 0x800
         | 0x80)) != 0
   || ((((p)->section)) == ((asection *) &bfd_und_section))
   || (((((p)->section))->flags & 0x8000) != 0)
   || ((((p)->section)) == ((asection *) &bfd_ind_section)))
 {
   const char *name;
   const char *string;
   struct n64_tag_generic_link_hash_entry *h;

   name = ((p)->name);
   if (((p->flags & 0x2000) != 0
        || ((p->section) == ((asection *) &bfd_ind_section)))
       && pp + 1 < ppend)
     {
       pp++;
       string = ((*pp)->name);
     }
   else if ((p->flags & 0x1000) != 0
     && pp + 1 < ppend)
     {


       string = name;
       pp++;
       name = ((*pp)->name);
     }
   else
     string = 
             ((void *)0)
                 ;

   h = 
      ((void *)0)
          ;
   if (! (_bfd_generic_link_add_one_symbol
   (info, abfd, name, p->flags, ((p)->section),
    p->value, string, cxx_false, collect,
    (struct n64_tag_bfd_link_hash_entry **) &h)))
     return cxx_false;





   if ((p->flags & 0x800) != 0
       && (h == 
               ((void *)0) 
                    || h->root.type == bfd_link_hash_new))
     {
       p->udata.p = 
                   ((void *)0)
                       ;
       continue;
     }
   if (info->hash->creator == abfd->xvec)
     {
       if (h->sym == (asymbol *) 
                                ((void *)0)
    
   || (! ((((p)->section)) == ((asection *) &bfd_und_section))
        && (! (((((p)->section))->flags & 0x8000) != 0)
     || ((((h->sym)->section)) == ((asection *) &bfd_und_section)))))
  {
    h->sym = p;



    if ((((((p)->section))->flags & 0x8000) != 0))
      p->flags |= 0x200;
  }






       p->udata.p = (void *) h;
     }
 }
    }

  return cxx_true;
}
enum n64_cpp_enum_link_row{
  UNDEF_ROW,
  UNDEFW_ROW,
  DEF_ROW,
  DEFW_ROW,
  COMMON_ROW,
  INDR_ROW,
  WARN_ROW,
  SET_ROW
};
typedef __underlying_type(enum n64_cpp_enum_link_row) n64_enum_link_row;







enum n64_cpp_enum_link_action{
  FAIL,
  UND,
  WEAK,
  DEF,
  DEFW,
  COM,
  REF,
  CREF,
  CDEF,
  NOACT,
  BIG,
  MDEF,
  MIND,
  IND,
  CIND,
  SET,
  MWARN,
  WARN,
  CWARN,
  CYCLE,
  REFC,
  WARNC
};
typedef __underlying_type(enum n64_cpp_enum_link_action) n64_enum_link_action;





static const n64_enum_link_action link_action[8][8] =
{

                    {UND, NOACT, UND, REF, REF, NOACT, REFC, WARNC },
                    {WEAK, NOACT, NOACT, REF, REF, NOACT, REFC, WARNC },
                  {DEF, DEF, DEF, MDEF, DEF, CDEF, MDEF, CYCLE },
                   {DEFW, DEFW, DEFW, NOACT, NOACT, NOACT, NOACT, CYCLE },
                    {COM, COM, COM, CREF, CREF, BIG, CREF, WARNC },
                  {IND, IND, IND, MDEF, IND, CIND, MIND, CYCLE },
                    {MWARN, WARN, WARN, CWARN, CWARN, WARN, CWARN, CYCLE },
                 {SET, SET, SET, SET, SET, SET, CYCLE, CYCLE }
};
static bfd *
hash_entry_bfd(struct n64_tag_bfd_link_hash_entry *h) asm("_hash_entry_bfd");
static bfd *
hash_entry_bfd(struct n64_tag_bfd_link_hash_entry *h)
{
  while (h->type == bfd_link_hash_warning)
    h = h->u.i.link;
  switch (h->type)
    {
    default:
      return 
            ((void *)0)
                ;
    case bfd_link_hash_undefined:
    case bfd_link_hash_undefweak:
      return h->u.undef.abfd;
    case bfd_link_hash_defined:
    case bfd_link_hash_defweak:
      return h->u.def.section->owner;
    case bfd_link_hash_common:
      return h->u.c.p->section->owner;
    }

}
boolean
_bfd_generic_link_add_one_symbol(struct n64_tag_bfd_link_info *info, bfd *abfd, const char *name, flagword flags, asection *section, bfd_vma value, const char *string, boolean copy, boolean collect, struct n64_tag_bfd_link_hash_entry **hashp) asm("__bfd_generic_link_add_one_symbol");
boolean
_bfd_generic_link_add_one_symbol(struct n64_tag_bfd_link_info *info, bfd *abfd, const char *name, flagword flags, asection *section, bfd_vma value, const char *string, boolean copy, boolean collect, struct n64_tag_bfd_link_hash_entry **hashp)
{
  n64_enum_link_row row;
  struct n64_tag_bfd_link_hash_entry *h;
  boolean cycle;

  if (((section) == ((asection *) &bfd_ind_section))
      || (flags & 0x2000) != 0)
    row = INDR_ROW;
  else if ((flags & 0x1000) != 0)
    row = WARN_ROW;
  else if ((flags & 0x800) != 0)
    row = SET_ROW;
  else if (((section) == ((asection *) &bfd_und_section)))
    {
      if ((flags & 0x80) != 0)
 row = UNDEFW_ROW;
      else
 row = UNDEF_ROW;
    }
  else if ((flags & 0x80) != 0)
    row = DEFW_ROW;
  else if ((((section)->flags & 0x8000) != 0))
    row = COMMON_ROW;
  else
    row = DEF_ROW;

  if (hashp != 
              ((void *)0) 
                   && *hashp != 
                                ((void *)0)
                                    )
    {
      h = *hashp;
      { if (!(strcmp (h->root.string, name) == 0)) bfd_assert("linker.c",1438); };
    }
  else
    {
      h = bfd_link_hash_lookup (info->hash, name, cxx_true, copy, cxx_false);
      if (h == 
              ((void *)0)
                  )
 {
   if (hashp != 
               ((void *)0)
                   )
     *hashp = 
             ((void *)0)
                 ;
   return cxx_false;
 }
    }

  if (info->notice_hash != (struct n64_tag_bfd_hash_table *) 
                                                    ((void *)0)
      
     && (bfd_hash_lookup (info->notice_hash, name, cxx_false, cxx_false)
   != (struct n64_tag_bfd_hash_entry *) 
                               ((void *)0)
                                   ))
    {
      if (! (*info->callbacks->notice) (info, name, abfd, section, value))
 return cxx_false;
    }

  if (hashp != (struct n64_tag_bfd_link_hash_entry **) 
                                              ((void *)0)
                                                  )
    *hashp = h;

  do
    {
      n64_enum_link_action action;

      cycle = cxx_false;
      action = link_action[(int) row][(int) h->type];
      switch (action)
 {
 case FAIL:
   abort ();

 case NOACT:

   break;

 case UND:

   h->type = bfd_link_hash_undefined;
   h->u.undef.abfd = abfd;
   bfd_link_add_undef (info->hash, h);
   break;

 case WEAK:

   h->type = bfd_link_hash_undefweak;
   h->u.undef.abfd = abfd;
   break;

 case CDEF:


   { if (!(h->type == bfd_link_hash_common)) bfd_assert("linker.c",1493); };
   if (! ((*info->callbacks->multiple_common)
   (info, name,
    h->u.c.p->section->owner, bfd_link_hash_common, h->u.c.size,
    abfd, bfd_link_hash_defined, (bfd_vma) 0)))
     return cxx_false;

 case DEF:
 case DEFW:
   {
     n64_enum_bfd_link_hash_type oldtype;


     oldtype = h->type;
     if (action == DEFW)
       h->type = bfd_link_hash_defweak;
     else
       h->type = bfd_link_hash_defined;
     h->u.def.section = section;
     h->u.def.value = value;







     if (collect && name[0] == '_')
       {
  const char *s;
  s = name + 1;
  while (*s == '_')
    ++s;
  if (s[0] == 'G'
      && strncmp (s, "GLOBAL_", (sizeof "GLOBAL_" - 1) - 1) == 0)
    {
      char c;

      c = s[(sizeof "GLOBAL_" - 1) + 1];
      if ((c == 'I' || c == 'D')
   && s[(sizeof "GLOBAL_" - 1)] == s[(sizeof "GLOBAL_" - 1) + 2])
        {







   if (oldtype == bfd_link_hash_defweak)
     abort ();

   if (! ((*info->callbacks->constructor)
          (info,
    c == 'I' ? cxx_true : cxx_false,
    name, abfd, section, value)))
     return cxx_false;
        }
    }
       }
   }

   break;

 case COM:

   if (h->type == bfd_link_hash_new)
     bfd_link_add_undef (info->hash, h);
   h->type = bfd_link_hash_common;
   h->u.c.p =
     ((struct n64_tag_bfd_link_hash_common_entry *)
      bfd_hash_allocate (&info->hash->table,
    sizeof (struct n64_tag_bfd_link_hash_common_entry)));
   if (h->u.c.p == 
                  ((void *)0)
                      )
     return cxx_false;

   h->u.c.size = value;



   {
     unsigned int power;

     power = bfd_log2 (value);
     if (power > 4)
       power = 4;
     h->u.c.p->alignment_power = power;
   }
   if (section == ((asection *) &bfd_com_section))
     {
       h->u.c.p->section = bfd_make_section_old_way (abfd, "COMMON");
       h->u.c.p->section->flags = 0x001;
     }
   else if (section->owner != abfd)
     {
       h->u.c.p->section = bfd_make_section_old_way (abfd,
           section->name);
       h->u.c.p->section->flags = 0x001;
     }
   else
     h->u.c.p->section = section;
   break;

 case REF:

   if (h->next == 
                 ((void *)0) 
                      && info->hash->undefs_tail != h)
     h->next = h;
   break;

 case BIG:



   { if (!(h->type == bfd_link_hash_common)) bfd_assert("linker.c",1627); };
   if (! ((*info->callbacks->multiple_common)
   (info, name,
    h->u.c.p->section->owner, bfd_link_hash_common, h->u.c.size,
    abfd, bfd_link_hash_common, value)))
     return cxx_false;
   if (value > h->u.c.size)
     {
       unsigned int power;

       h->u.c.size = value;



       power = bfd_log2 (value);
       if (power > 4)
  power = 4;
       h->u.c.p->alignment_power = power;
     }
   break;

 case CREF:
   {
     bfd *obfd;





     if (h->type == bfd_link_hash_defined
  || h->type == bfd_link_hash_defweak)
       obfd = h->u.def.section->owner;
     else
       obfd = 
             ((void *)0)
                 ;
     if (! ((*info->callbacks->multiple_common)
     (info, name, obfd, h->type, (bfd_vma) 0,
      abfd, bfd_link_hash_common, value)))
       return cxx_false;
   }
   break;

 case MIND:


   if (strcmp (h->u.i.link->root.string, string) == 0)
     break;

 case MDEF:

   {
     asection *msec;
     bfd_vma mval;

     switch (h->type)
       {
       case bfd_link_hash_defined:
  msec = h->u.def.section;
  mval = h->u.def.value;
  break;
       case bfd_link_hash_indirect:
  msec = ((asection *) &bfd_ind_section);
  mval = 0;
  break;
       default:
  abort ();
       }



     if (h->type == bfd_link_hash_defined
  && ((msec) == ((asection *) &bfd_abs_section))
  && ((section) == ((asection *) &bfd_abs_section))
  && value == mval)
       break;

     if (! ((*info->callbacks->multiple_definition)
     (info, name, msec->owner, msec, mval, abfd, section,
      value)))
       return cxx_false;
   }
   break;

 case CIND:

   { if (!(h->type == bfd_link_hash_common)) bfd_assert("linker.c",1711); };
   if (! ((*info->callbacks->multiple_common)
   (info, name,
    h->u.c.p->section->owner, bfd_link_hash_common, h->u.c.size,
    abfd, bfd_link_hash_indirect, (bfd_vma) 0)))
     return cxx_false;

 case IND:

   {
     struct n64_tag_bfd_link_hash_entry *inh;



     inh = bfd_link_hash_lookup (info->hash, string, cxx_true, copy,
     cxx_false);
     if (inh == (struct n64_tag_bfd_link_hash_entry *) 
                                              ((void *)0)
                                                  )
       return cxx_false;
     if (inh->type == bfd_link_hash_new)
       {
  inh->type = bfd_link_hash_undefined;
  inh->u.undef.abfd = abfd;
  bfd_link_add_undef (info->hash, inh);
       }




     if (h->type != bfd_link_hash_new)
       {
  row = UNDEF_ROW;
  cycle = cxx_true;
       }

     h->type = bfd_link_hash_indirect;
     h->u.i.link = inh;
   }
   break;

 case SET:

   if (! (*info->callbacks->add_to_set) (info, h, BFD_RELOC_CTOR,
      abfd, section, value))
     return cxx_false;
   break;

 case WARNC:

   if (h->u.i.warning != 
                        ((void *)0)
                            )
     {
       if (! (*info->callbacks->warning) (info, h->u.i.warning, name,
       abfd, (asection *) 
                         ((void *)0)
                             ,
       (bfd_vma) 0))
  return cxx_false;

       h->u.i.warning = 
                       ((void *)0)
                           ;
     }

 case CYCLE:

   h = h->u.i.link;
   cycle = cxx_true;
   break;

 case REFC:

   if (h->next == 
                 ((void *)0) 
                      && info->hash->undefs_tail != h)
     h->next = h;
   h = h->u.i.link;
   cycle = cxx_true;
   break;

 case WARN:

   if (! (*info->callbacks->warning) (info, string, name,
          hash_entry_bfd (h),
          (asection *) 
                      ((void *)0)
                          , (bfd_vma) 0))
     return cxx_false;
   break;

 case CWARN:





   if (h->next != 
                 ((void *)0) 
                      || info->hash->undefs_tail == h)
     {
       if (! (*info->callbacks->warning) (info, string, name,
       hash_entry_bfd (h),
       (asection *) 
                   ((void *)0)
                       ,
       (bfd_vma) 0))
  return cxx_false;
       break;
     }

 case MWARN:

   {
     struct n64_tag_bfd_link_hash_entry *sub;


     sub = ((struct n64_tag_bfd_link_hash_entry *)
     ((*info->hash->table.newfunc)
      ((struct n64_tag_bfd_hash_entry *) 
                                ((void *)0)
                                    , &info->hash->table,
       h->root.string)));
     if (sub == 
               ((void *)0)
                   )
       return cxx_false;
     *sub = *h;
     sub->type = bfd_link_hash_warning;
     sub->u.i.link = h;
     if (! copy)
       sub->u.i.warning = string;
     else
       {
  char *w;

  w = bfd_hash_allocate (&info->hash->table,
           strlen (string) + 1);
  if (w == 
          ((void *)0)
              )
    return cxx_false;
  strcpy (w, string);
  sub->u.i.warning = w;
       }

     bfd_hash_replace (&info->hash->table,
         (struct n64_tag_bfd_hash_entry *) h,
         (struct n64_tag_bfd_hash_entry *) sub);
     if (hashp != 
                 ((void *)0)
                     )
       *hashp = sub;
   }
   break;
 }
    }
  while (cycle);

  return cxx_true;
}



boolean
_bfd_generic_final_link(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("__bfd_generic_final_link");
boolean
_bfd_generic_final_link(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  bfd *sub;
  asection *o;
  struct n64_tag_bfd_link_order *p;
  size_t outsymalloc;
  struct n64_tag_generic_write_global_symbol_info wginfo;

  abfd->outsymbols = (asymbol **) 
                                 ((void *)0)
                                     ;
  abfd->symcount = 0;
  outsymalloc = 0;


  for (sub = info->input_bfds; sub != (bfd *) 
                                             ((void *)0)
                                                 ; sub = sub->link_next)
    if (! _bfd_generic_link_output_symbols (abfd, sub, info, &outsymalloc))
      return cxx_false;


  wginfo.info = info;
  wginfo.output_bfd = abfd;
  wginfo.psymalloc = &outsymalloc;
  (bfd_link_hash_traverse (&(((struct n64_tag_generic_link_hash_table *) ((info)->hash)))->root, (boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *)) (_bfd_generic_link_write_global_symbol), ((void *) &wginfo)))

                     ;

  if (info->relocateable)
    {

      for (o = abfd->sections;
    o != (asection *) 
                     ((void *)0)
                         ;
    o = o->next)
 {
   o->reloc_count = 0;
   for (p = o->link_order_head;
        p != (struct n64_tag_bfd_link_order *) 
                                      ((void *)0)
                                          ;
        p = p->next)
     {
       if (p->type == bfd_section_reloc_link_order
    || p->type == bfd_symbol_reloc_link_order)
  ++o->reloc_count;
       else if (p->type == bfd_indirect_link_order)
  {
    asection *input_section;
    bfd *input_bfd;
    long relsize;
    arelent **relocs;
    asymbol **symbols;
    long reloc_count;

    input_section = p->u.indirect.section;
    input_bfd = input_section->owner;
    relsize = bfd_get_reloc_upper_bound (input_bfd,
             input_section);
    if (relsize < 0)
      return cxx_false;
    relocs = (arelent **) malloc ((size_t) relsize);
    if (!relocs && relsize != 0)
      {
        bfd_set_error (bfd_error_no_memory);
        return cxx_false;
      }
    symbols = ((input_bfd)->outsymbols);
    reloc_count = bfd_canonicalize_reloc (input_bfd,
       input_section,
       relocs,
       symbols);
    if (reloc_count < 0)
      return cxx_false;
    { if (!((unsigned long) reloc_count == input_section->reloc_count)) bfd_assert("linker.c",1923); }
                                       ;
    o->reloc_count += reloc_count;
    free (relocs);
  }
     }
   if (o->reloc_count > 0)
     {
       o->orelocation = ((arelent **)
    bfd_alloc (abfd,
        (o->reloc_count
         * sizeof (arelent *))));
       if (!o->orelocation)
  {
    bfd_set_error (bfd_error_no_memory);
    return cxx_false;
  }
       o->flags |= 0x004;


       o->reloc_count = 0;
     }
 }
    }


  for (o = abfd->sections;
       o != (asection *) 
                        ((void *)0)
                            ;
       o = o->next)
    {
      for (p = o->link_order_head;
    p != (struct n64_tag_bfd_link_order *) 
                                  ((void *)0)
                                      ;
    p = p->next)
 {
   switch (p->type)
     {
     case bfd_section_reloc_link_order:
     case bfd_symbol_reloc_link_order:
       if (! _bfd_generic_reloc_link_order (abfd, info, o, p))
  return cxx_false;
       break;
     case bfd_indirect_link_order:
       if (! default_indirect_link_order (abfd, info, o, p, cxx_true))
  return cxx_false;
       break;
     default:
       if (! _bfd_default_link_order (abfd, info, o, p))
  return cxx_false;
       break;
     }
 }
    }

  return cxx_true;
}



static boolean
generic_add_output_symbol(bfd *output_bfd, size_t *psymalloc, asymbol *sym) asm("_generic_add_output_symbol");
static boolean
generic_add_output_symbol(bfd *output_bfd, size_t *psymalloc, asymbol *sym)
{
  if (output_bfd->symcount >= *psymalloc)
    {
      asymbol **newsyms;

      if (*psymalloc == 0)
 *psymalloc = 124;
      else
 *psymalloc *= 2;
      if (output_bfd->outsymbols == (asymbol **) 
                                                ((void *)0)
                                                    )
 newsyms = (asymbol **) malloc (*psymalloc * sizeof (asymbol *));
      else
 newsyms = (asymbol **) realloc (output_bfd->outsymbols,
     *psymalloc * sizeof (asymbol *));
      if (newsyms == (asymbol **) 
                                 ((void *)0)
                                     )
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      output_bfd->outsymbols = newsyms;
    }

  output_bfd->outsymbols[output_bfd->symcount] = sym;
  ++output_bfd->symcount;

  return cxx_true;
}



boolean
_bfd_generic_link_output_symbols(bfd *output_bfd, bfd *input_bfd, struct n64_tag_bfd_link_info *info, size_t *psymalloc) asm("__bfd_generic_link_output_symbols");
boolean
_bfd_generic_link_output_symbols(bfd *output_bfd, bfd *input_bfd, struct n64_tag_bfd_link_info *info, size_t *psymalloc)
{
  asymbol **sym_ptr;
  asymbol **sym_end;

  if (! generic_link_read_symbols (input_bfd))
    return cxx_false;


  if (info->create_object_symbols_section != (asection *) 
                                                         ((void *)0)
                                                             )
    {
      asection *sec;

      for (sec = input_bfd->sections;
    sec != (asection *) 
                       ((void *)0)
                           ;
    sec = sec->next)
 {
   if (sec->output_section == info->create_object_symbols_section)
     {
       asymbol *newsym;

       newsym = ((*((input_bfd)->xvec->_bfd_make_empty_symbol)) (input_bfd));
       if (!newsym)
  return cxx_false;
       newsym->name = input_bfd->filename;
       newsym->value = 0;
       newsym->flags = 0x01 | 0x4000;
       newsym->section = sec;

       if (! generic_add_output_symbol (output_bfd, psymalloc,
            newsym))
  return cxx_false;

       break;
     }
 }
    }



  sym_ptr = ((input_bfd)->outsymbols);
  sym_end = sym_ptr + ((input_bfd)->symcount);
  for (; sym_ptr < sym_end; sym_ptr++)
    {
      asymbol *sym;
      struct n64_tag_generic_link_hash_entry *h;
      boolean output;

      h = (struct n64_tag_generic_link_hash_entry *) 
                                            ((void *)0)
                                                ;
      sym = *sym_ptr;
      if ((sym->flags & (0x2000
    | 0x1000
    | 0x02
    | 0x800
    | 0x80)) != 0
   || ((((sym)->section)) == ((asection *) &bfd_und_section))
   || (((((sym)->section))->flags & 0x8000) != 0)
   || ((((sym)->section)) == ((asection *) &bfd_ind_section)))
 {
   if (sym->udata.p != 
                      ((void *)0)
                          )
     h = (struct n64_tag_generic_link_hash_entry *) sym->udata.p;
   else if ((sym->flags & 0x800) != 0)
     {
       h = 
          ((void *)0)
              ;
     }
   else
     h = ((struct n64_tag_generic_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_generic_link_hash_table *) ((info)->hash)))->root, (((sym)->name)), (cxx_false), (cxx_false), (cxx_true)))

                               ;

   if (h != (struct n64_tag_generic_link_hash_entry *) 
                                              ((void *)0)
                                                  )
     {





       if (info->hash->creator == input_bfd->xvec)
  {
    if (h->sym != (asymbol *) 
                             ((void *)0)
                                 )
      *sym_ptr = sym = h->sym;
  }

       switch (h->root.type)
  {
  default:
  case bfd_link_hash_new:
    abort ();
  case bfd_link_hash_undefined:
    break;
  case bfd_link_hash_undefweak:
    sym->flags |= 0x80;
    break;
  case bfd_link_hash_indirect:
    h = (struct n64_tag_generic_link_hash_entry *) h->root.u.i.link;

  case bfd_link_hash_defined:
    sym->flags |= 0x02;
    sym->flags &=~ 0x800;
    sym->value = h->root.u.def.value;
    sym->section = h->root.u.def.section;
    break;
  case bfd_link_hash_defweak:
    sym->flags |= 0x80;
    sym->flags &=~ 0x800;
    sym->value = h->root.u.def.value;
    sym->section = h->root.u.def.section;
    break;
  case bfd_link_hash_common:
    sym->value = h->root.u.c.size;
    sym->flags |= 0x02;
    if (! (((sym->section)->flags & 0x8000) != 0))
      {
        { if (!(((sym->section) == ((asection *) &bfd_und_section)))) bfd_assert("linker.c",2142); };
        sym->section = ((asection *) &bfd_com_section);
      }






    break;
  }
     }
 }



      if (info->strip == strip_some
   && (bfd_hash_lookup (info->keep_hash, ((sym)->name),
          cxx_false, cxx_false)
       == (struct n64_tag_bfd_hash_entry *) 
                                   ((void *)0)
                                       ))
 output = cxx_false;
      else if ((sym->flags & (0x02 | 0x80)) != 0)
 {




   if (((sym)->the_bfd) == input_bfd
       && (sym->flags & 0x400) != 0)
     output = cxx_true;
   else
     output = cxx_false;
 }
      else if (((sym->section) == ((asection *) &bfd_ind_section)))
 output = cxx_false;
      else if ((sym->flags & 0x08) != 0)
 {
   if (info->strip == strip_none)
     output = cxx_true;
   else
     output = cxx_false;
 }
      else if (((sym->section) == ((asection *) &bfd_und_section))
        || (((sym->section)->flags & 0x8000) != 0))
 output = cxx_false;
      else if ((sym->flags & 0x01) != 0)
 {
   if ((sym->flags & 0x1000) != 0)
     output = cxx_false;
   else
     {
       switch (info->discard)
  {
  default:
  case discard_all:
    output = cxx_false;
    break;
  case discard_l:
    if (((sym)->name)[0] == info->lprefix[0]
        && (info->lprefix_len == 1
     || strncmp (((sym)->name), info->lprefix,
          info->lprefix_len) == 0))
      output = cxx_false;
    else
      output = cxx_true;
    break;
  case discard_none:
    output = cxx_true;
    break;
  }
     }
 }
      else if ((sym->flags & 0x800))
 {
   if (info->strip != strip_all)
     output = cxx_true;
   else
     output = cxx_false;
 }
      else
 abort ();

      if (output)
 {
   if (! generic_add_output_symbol (output_bfd, psymalloc, sym))
     return cxx_false;
   if (h != (struct n64_tag_generic_link_hash_entry *) 
                                              ((void *)0)
                                                  )
     h->written = cxx_true;
 }
    }

  return cxx_true;
}




static void
set_symbol_from_hash(asymbol *sym, struct n64_tag_bfd_link_hash_entry *h) asm("_set_symbol_from_hash");
static void
set_symbol_from_hash(asymbol *sym, struct n64_tag_bfd_link_hash_entry *h)
{
  switch (h->type)
    {
    default:
      abort ();
      break;
    case bfd_link_hash_new:


      if (sym->section != 
                         ((void *)0)
                             )
 {
   { if (!((sym->flags & 0x800) != 0)) bfd_assert("linker.c",2254); };
 }
      else
 {
   sym->flags |= 0x800;
   sym->section = ((asection *) &bfd_abs_section);
   sym->value = 0;
 }
      break;
    case bfd_link_hash_undefined:
      sym->section = ((asection *) &bfd_und_section);
      sym->value = 0;
      break;
    case bfd_link_hash_undefweak:
      sym->section = ((asection *) &bfd_und_section);
      sym->value = 0;
      sym->flags |= 0x80;
      break;
    case bfd_link_hash_defined:
      sym->section = h->u.def.section;
      sym->value = h->u.def.value;
      break;
    case bfd_link_hash_defweak:
      sym->flags |= 0x80;
      sym->section = h->u.def.section;
      sym->value = h->u.def.value;
      break;
    case bfd_link_hash_common:
      sym->value = h->u.c.size;
      if (sym->section == 
                         ((void *)0)
                             )
 sym->section = ((asection *) &bfd_com_section);
      else if (! (((sym->section)->flags & 0x8000) != 0))
 {
   { if (!(((sym->section) == ((asection *) &bfd_und_section)))) bfd_assert("linker.c",2287); };
   sym->section = ((asection *) &bfd_com_section);
 }

      break;
    case bfd_link_hash_indirect:
    case bfd_link_hash_warning:

      break;
    }
}




boolean
_bfd_generic_link_write_global_symbol(struct n64_tag_generic_link_hash_entry *h, void *data) asm("__bfd_generic_link_write_global_symbol");
boolean
_bfd_generic_link_write_global_symbol(struct n64_tag_generic_link_hash_entry *h, void *data)
{
  struct n64_tag_generic_write_global_symbol_info *wginfo =
    (struct n64_tag_generic_write_global_symbol_info *) data;
  asymbol *sym;

  if (h->written)
    return cxx_true;

  h->written = cxx_true;

  if (wginfo->info->strip == strip_all
      || (wginfo->info->strip == strip_some
   && bfd_hash_lookup (wginfo->info->keep_hash, h->root.root.string,
         cxx_false, cxx_false) == 
                         ((void *)0)
                             ))
    return cxx_true;

  if (h->sym != (asymbol *) 
                           ((void *)0)
                               )
    {
      sym = h->sym;
      { if (!(strcmp (((sym)->name), h->root.root.string) == 0)) bfd_assert("linker.c",2325); };
    }
  else
    {
      sym = ((*((wginfo->output_bfd)->xvec->_bfd_make_empty_symbol)) (wginfo->output_bfd));
      if (!sym)
 return cxx_false;
      sym->name = h->root.root.string;
      sym->flags = 0;
    }

  set_symbol_from_hash (sym, &h->root);

  sym->flags |= 0x02;

  if (! generic_add_output_symbol (wginfo->output_bfd, wginfo->psymalloc,
       sym))
    {

      abort ();
    }

  return cxx_true;
}



boolean
_bfd_generic_reloc_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order) asm("__bfd_generic_reloc_link_order");
boolean
_bfd_generic_reloc_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order)
{
  arelent *r;

  if (! info->relocateable)
    abort ();
  if (sec->orelocation == (arelent **) 
                                      ((void *)0)
                                          )
    abort ();

  r = (arelent *) bfd_alloc (abfd, sizeof (arelent));
  if (r == (arelent *) 
                      ((void *)0)
                          )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  r->address = link_order->offset;
  r->howto = bfd_reloc_type_lookup (abfd, link_order->u.reloc.p->reloc);
  if (r->howto == 0)
    {
      bfd_set_error (bfd_error_bad_value);
      return cxx_false;
    }


  if (link_order->type == bfd_section_reloc_link_order)
    r->sym_ptr_ptr = link_order->u.reloc.p->u.section->symbol_ptr_ptr;
  else
    {
      struct n64_tag_generic_link_hash_entry *h;

      h = ((struct n64_tag_generic_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_generic_link_hash_table *) ((info)->hash)))->root, (link_order->u.reloc.p->u.name), (cxx_false), (cxx_false), (cxx_true)))

                         ;
      if (h == (struct n64_tag_generic_link_hash_entry *) 
                                                 ((void *)0)
   
  || ! h->written)
 {
   if (! ((*info->callbacks->unattached_reloc)
   (info, link_order->u.reloc.p->u.name,
    (bfd *) 
           ((void *)0)
               , (asection *) 
                              ((void *)0)
                                  , (bfd_vma) 0)))
     return cxx_false;
   bfd_set_error (bfd_error_bad_value);
   return cxx_false;
 }
      r->sym_ptr_ptr = &h->sym;
    }



  if (! r->howto->partial_inplace)
    r->addend = link_order->u.reloc.p->addend;
  else
    {
      bfd_size_type size;
      bfd_reloc_status_type rstat;
      bfd_byte *buf;
      boolean ok;

      size = bfd_get_reloc_size (r->howto);
      buf = (bfd_byte *) bfd_zmalloc (size);
      if (buf == (bfd_byte *) 
                             ((void *)0)
                                 )
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      rstat = _bfd_relocate_contents (r->howto, abfd,
          link_order->u.reloc.p->addend, buf);
      switch (rstat)
 {
 case bfd_reloc_ok:
   break;
 default:
 case bfd_reloc_outofrange:
   abort ();
 case bfd_reloc_overflow:
   if (! ((*info->callbacks->reloc_overflow)
   (info,
    (link_order->type == bfd_section_reloc_link_order
     ? ((link_order->u.reloc.p->u.section)->name)
     : link_order->u.reloc.p->u.name),
    r->howto->name, link_order->u.reloc.p->addend,
    (bfd *) 
           ((void *)0)
               , (asection *) 
                              ((void *)0)
                                  , (bfd_vma) 0)))
     {
       free (buf);
       return cxx_false;
     }
   break;
 }
      ok = bfd_set_section_contents (abfd, sec, (void *) buf,
         (file_ptr) link_order->offset, size);
      free (buf);
      if (! ok)
 return cxx_false;

      r->addend = 0;
    }

  sec->orelocation[sec->reloc_count] = r;
  ++sec->reloc_count;

  return cxx_true;
}



struct n64_tag_bfd_link_order *
bfd_new_link_order(bfd *abfd, asection *section) asm("_bfd_new_link_order");
struct n64_tag_bfd_link_order *
bfd_new_link_order(bfd *abfd, asection *section)
{
  struct n64_tag_bfd_link_order *cxx_new;

  cxx_new = ((struct n64_tag_bfd_link_order *)
  bfd_alloc_by_size_t (abfd, sizeof (struct n64_tag_bfd_link_order)));
  if (!cxx_new)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }

  cxx_new->type = bfd_undefined_link_order;
  cxx_new->offset = 0;
  cxx_new->size = 0;
  cxx_new->next = (struct n64_tag_bfd_link_order *) 
                                       ((void *)0)
                                           ;

  if (section->link_order_tail != (struct n64_tag_bfd_link_order *) 
                                                           ((void *)0)
                                                               )
    section->link_order_tail->next = cxx_new;
  else
    section->link_order_head = cxx_new;
  section->link_order_tail = cxx_new;

  return cxx_new;
}





boolean
_bfd_default_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order) asm("__bfd_default_link_order");
boolean
_bfd_default_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order)
{
  switch (link_order->type)
    {
    case bfd_undefined_link_order:
    case bfd_section_reloc_link_order:
    case bfd_symbol_reloc_link_order:
    default:
      abort ();
    case bfd_indirect_link_order:
      return default_indirect_link_order (abfd, info, sec, link_order,
       cxx_false);
    case bfd_fill_link_order:
      return default_fill_link_order (abfd, info, sec, link_order);
    case bfd_data_link_order:
      return bfd_set_section_contents (abfd, sec,
           (void *) link_order->u.data.contents,
           (file_ptr) link_order->offset,
           link_order->size);
    }
}




static boolean
default_fill_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order) asm("_default_fill_link_order");
static boolean
default_fill_link_order(bfd *abfd, struct n64_tag_bfd_link_info *info, asection *sec, struct n64_tag_bfd_link_order *link_order)
{
  size_t size;
  char *space;
  size_t i;
  int fill;
  boolean result;

  { if (!((sec->flags & 0x200) != 0)) bfd_assert("linker.c",2538); };

  size = (size_t) link_order->size;
  space = (char *) malloc (size);
  if (space == 
              ((void *)0) 
                   && size != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  fill = link_order->u.fill.value;
  for (i = 0; i < size; i += 2)
    space[i] = fill >> 8;
  for (i = 1; i < size; i += 2)
    space[i] = fill;
  result = bfd_set_section_contents (abfd, sec, space,
         (file_ptr) link_order->offset,
         link_order->size);
  free (space);
  return result;
}



static boolean
default_indirect_link_order(bfd *output_bfd, struct n64_tag_bfd_link_info *info, asection *output_section, struct n64_tag_bfd_link_order *link_order, boolean generic_linker) asm("_default_indirect_link_order");
static boolean
default_indirect_link_order(bfd *output_bfd, struct n64_tag_bfd_link_info *info, asection *output_section, struct n64_tag_bfd_link_order *link_order, boolean generic_linker)
{
  asection *input_section;
  bfd *input_bfd;
  bfd_byte *contents = 
                      ((void *)0)
                          ;
  bfd_byte *new_contents;

  { if (!((output_section->flags & 0x200) != 0)) bfd_assert("linker.c",2576); };

  if (link_order->size == 0)
    return cxx_true;

  input_section = link_order->u.indirect.section;
  input_bfd = input_section->owner;

  { if (!(input_section->output_section == output_section)) bfd_assert("linker.c",2584); };
  { if (!(input_section->output_offset == link_order->offset)) bfd_assert("linker.c",2585); };
  { if (!(input_section->_cooked_size == link_order->size)) bfd_assert("linker.c",2586); };

  if (info->relocateable
      && input_section->reloc_count > 0
      && output_section->orelocation == (arelent **) 
                                                    ((void *)0)
                                                        )
    {





      abort ();
    }

  if (! generic_linker)
    {
      asymbol **sympp;
      asymbol **symppend;





      if (! generic_link_read_symbols (input_bfd))
 return cxx_false;






      sympp = ((input_bfd)->outsymbols);
      symppend = sympp + ((input_bfd)->symcount);
      for (; sympp < symppend; sympp++)
 {
   asymbol *sym;
   struct n64_tag_bfd_link_hash_entry *h;

   sym = *sympp;

   if ((sym->flags & (0x2000
        | 0x1000
        | 0x02
        | 0x800
        | 0x80)) != 0
       || ((((sym)->section)) == ((asection *) &bfd_und_section))
       || (((((sym)->section))->flags & 0x8000) != 0)
       || ((((sym)->section)) == ((asection *) &bfd_ind_section)))
     {


       if (sym->udata.p != 
                          ((void *)0)
                              )
  h = (struct n64_tag_bfd_link_hash_entry *) sym->udata.p;
       else
  h = bfd_link_hash_lookup (info->hash,
       ((sym)->name),
       cxx_false, cxx_false, cxx_true);
       if (h != 
               ((void *)0)
                   )
  set_symbol_from_hash (sym, h);
     }
 }
    }


  contents = ((bfd_byte *)
       malloc ((size_t) ((input_section->reloc_done ? (abort(),1): (input_section)->_raw_size))));
  if (contents == 
                 ((void *)0) 
                      && ((input_section->reloc_done ? (abort(),1): (input_section)->_raw_size)) != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }
  new_contents = (bfd_get_relocated_section_contents
    (output_bfd, info, link_order, contents, info->relocateable,
     ((input_bfd)->outsymbols)));
  if (!new_contents)
    goto error_return;


  if (! bfd_set_section_contents (output_bfd, output_section,
      (void *) new_contents,
      link_order->offset, link_order->size))
    goto error_return;

  if (contents != 
                 ((void *)0)
                     )
    free (contents);
  return cxx_true;

 error_return:
  if (contents != 
                 ((void *)0)
                     )
    free (contents);
  return cxx_false;
}




unsigned int
_bfd_count_link_order_relocs(struct n64_tag_bfd_link_order *link_order) asm("__bfd_count_link_order_relocs");
unsigned int
_bfd_count_link_order_relocs(struct n64_tag_bfd_link_order *link_order)
{
  register unsigned int c;
  register struct n64_tag_bfd_link_order *l;

  c = 0;
  for (l = link_order; l != (struct n64_tag_bfd_link_order *) 
                                                     ((void *)0)
                                                         ; l = l->next)
    {
      if (l->type == bfd_section_reloc_link_order
   || l->type == bfd_symbol_reloc_link_order)
 ++c;
    }

  return c;
}
boolean
_bfd_generic_link_split_section(bfd *abfd, asection *sec) asm("__bfd_generic_link_split_section");
boolean
_bfd_generic_link_split_section(bfd *abfd, asection *sec)
{
  return cxx_false;
}

