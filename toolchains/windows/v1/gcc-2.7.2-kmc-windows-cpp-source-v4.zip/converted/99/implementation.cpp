// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/coffgen.c
/* Support for the generic parts of COFF, for BFD.
   Copyright 1990, 91, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Written by Cygnus Support.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__IMAGE_DATA_DIRECTORY;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_areltdata;
struct n64_tag_artdata;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_coff_link_hash_entry;
struct n64_tag_coff_link_hash_table;
struct n64_tag_coff_ptr_struct;
struct n64_tag_coff_section_tdata;
struct n64_tag_coff_symbol_struct;
struct n64_tag_coff_tdata;
struct n64_tag_foo;
struct n64_tag_internal_aouthdr;
union n64_tag_internal_auxent;
struct n64_tag_internal_extra_pe_aouthdr;
struct n64_tag_internal_extra_pe_filehdr;
struct n64_tag_internal_filehdr;
struct n64_tag_internal_lineno;
struct n64_tag_internal_reloc;
struct n64_tag_internal_scnhdr;
struct n64_tag_internal_syment;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_pe_tdata;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;
struct n64_tag_xcoff_section_tdata;
struct n64_tag_xcoff_tdata;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct n64_tag_coff_tdata *coff_obj_data;
      struct n64_tag_pe_tdata *pe_obj_data;
      struct n64_tag_xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct ecoff_debug_info * const, const struct ecoff_debug_swap * const, struct ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");
struct n64_tag_internal_extra_pe_filehdr
{

  unsigned short e_magic;
  unsigned short e_cblp;
  unsigned short e_cp;
  unsigned short e_crlc;
  unsigned short e_cparhdr;
  unsigned short e_minalloc;
  unsigned short e_maxalloc;
  unsigned short e_ss;
  unsigned short e_sp;
  unsigned short e_csum;
  unsigned short e_ip;
  unsigned short e_cs;
  unsigned short e_lfarlc;
  unsigned short e_ovno;
  unsigned short e_res[4];
  unsigned short e_oemid;
  unsigned short e_oeminfo;
  unsigned short e_res2[10];
  bfd_vma e_lfanew;
  unsigned long dos_message[16];
  bfd_vma nt_signature;
};

struct n64_tag_internal_filehdr
{
  struct n64_tag_internal_extra_pe_filehdr pe;


  unsigned short f_magic;
  unsigned short f_nscns;
  long f_timdat;
  bfd_vma f_symptr;
  long f_nsyms;
  unsigned short f_opthdr;
  unsigned short f_flags;
};
typedef struct n64_tag__IMAGE_DATA_DIRECTORY
{
  bfd_vma VirtualAddress;
  long Size;
} IMAGE_DATA_DIRECTORY;
struct n64_tag_internal_extra_pe_aouthdr
{

  bfd_vma ImageBase;


  bfd_vma SectionAlignment;
  bfd_vma FileAlignment;
  short MajorOperatingSystemVersion;
  short MinorOperatingSystemVersion;
  short MajorImageVersion;
  short MinorImageVersion;
  short MajorSubsystemVersion;
  short MinorSubsystemVersion;
  long Reserved1;
  long SizeOfImage;
  long SizeOfHeaders;
  long CheckSum;
  short Subsystem;
  short DllCharacteristics;
  bfd_vma SizeOfStackReserve;
  bfd_vma SizeOfStackCommit;

  bfd_vma SizeOfHeapReserve;
  bfd_vma SizeOfHeapCommit;
  long LoaderFlags;
  long NumberOfRvaAndSizes;
  IMAGE_DATA_DIRECTORY DataDirectory[16];
};


struct n64_tag_internal_aouthdr
{
  short magic;
  short vstamp;
  bfd_vma tsize;
  bfd_vma dsize;
  bfd_vma bsize;
  bfd_vma entry;
  bfd_vma text_start;
  bfd_vma data_start;


  unsigned long tagentries;


  unsigned long o_toc;
  short o_snentry;
  short o_sntext;
  short o_sndata;
  short o_sntoc;
  short o_snloader;
  short o_snbss;
  short o_algntext;
  short o_algndata;
  short o_modtype;
  short o_cputype;
  unsigned long o_maxstack;
  unsigned long o_maxdata;


  bfd_vma bss_start;
  bfd_vma gp_value;
  unsigned long gprmask;
  unsigned long cprmask[4];
  unsigned long fprmask;


  long o_inlib;
  long o_sri;
  long vid[2];


  struct n64_tag_internal_extra_pe_aouthdr pe;

};
struct n64_tag_internal_scnhdr
{
  char s_name[8];
  bfd_vma s_paddr;
  bfd_vma s_vaddr;
  bfd_vma s_size;
  bfd_vma s_scnptr;
  bfd_vma s_relptr;
  bfd_vma s_lnnoptr;
  unsigned long s_nreloc;
  unsigned long s_nlnno;
  long s_flags;
  long s_align;
};
struct n64_tag_internal_lineno
{
  union
  {
    long l_symndx;
    long l_paddr;
  } l_addr;
  unsigned long l_lnno;
};







struct n64_tag_internal_syment
{
  union
  {
    char _n_name[8];
    struct
    {
      long _n_zeroes;
      long _n_offset;
    } _n_n;
    char *_n_nptr[2];
  } _n;
  long n_value;
  short n_scnum;
  unsigned short n_flags;
  unsigned short n_type;
  unsigned char n_sclass;
  unsigned char n_numaux;
};
union n64_tag_internal_auxent
{
  struct
  {

    union
    {
      long l;
      struct n64_tag_coff_ptr_struct *p;
    } x_tagndx;

    union
    {
      struct
      {
 unsigned short x_lnno;
 unsigned short x_size;
      } x_lnsz;
      long x_fsize;
    } x_misc;

    union
    {
      struct
      {
 long x_lnnoptr;
 union
 {
   long l;
   struct n64_tag_coff_ptr_struct *p;
 } x_endndx;
      } x_fcn;

      struct
      {
 unsigned short x_dimen[4];
      } x_ary;
    } x_fcnary;

    unsigned short x_tvndx;
  } x_sym;

  union
  {
    char x_fname[14];
    struct
    {
      long x_zeroes;
      long x_offset;
    } x_n;
  } x_file;

  struct
  {
    long x_scnlen;
    unsigned short x_nreloc;
    unsigned short x_nlinno;
  } x_scn;

  struct
  {
    long x_tvfill;
    unsigned short x_tvlen;
    unsigned short x_tvran[2];
  } x_tv;




  struct
  {
    union
      {
 long l;
 struct n64_tag_coff_ptr_struct *p;
      } x_scnlen;
    long x_parmhash;
    unsigned short x_snhash;
    unsigned char x_smtyp;


    unsigned char x_smclas;
    long x_stab;
    unsigned short x_snstab;
  } x_csect;
  struct
  {


    long x_stindx;
  } x_sc;

  struct
  {
    unsigned long x_balntry;
  } x_bal;

  struct
  {
    unsigned long x_timestamp;
    char x_idstring[20];
  } x_ident;

};



struct n64_tag_internal_reloc
{
  bfd_vma r_vaddr;
  long r_symndx;
  unsigned short r_type;
  unsigned char r_size;
  unsigned char r_extern;
  unsigned long r_offset;
};
enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
typedef struct n64_tag_coff_tdata
{
  struct n64_tag_coff_symbol_struct *symbols;
  unsigned int *conversion_table;
  int conv_table_size;
  file_ptr sym_filepos;

  struct n64_tag_coff_ptr_struct *raw_syments;
  unsigned int raw_syment_count;


  long int relocbase;




  unsigned local_n_btmask;
  unsigned local_n_btshft;
  unsigned local_n_tmask;
  unsigned local_n_tshift;
  unsigned local_symesz;
  unsigned local_auxesz;
  unsigned local_linesz;



  void * external_syms;

  boolean keep_syms;



  char *strings;

  boolean keep_strings;


  int pe;

  struct n64_tag_coff_link_hash_entry **sym_hashes;


  int *local_toc_sym_map;

  struct n64_tag_bfd_link_info *link_info;
} coff_data_type;


typedef struct n64_tag_pe_tdata
{
  coff_data_type coff;
  struct n64_tag_internal_extra_pe_aouthdr pe_opthdr;
  int dll;
  int has_reloc_section;
  boolean (*in_reloc_p) (bfd *, reloc_howto_type *);
  flagword real_flags;
} pe_data_type;





struct n64_tag_xcoff_tdata
{

  coff_data_type coff;


  boolean full_aouthdr;


  bfd_vma toc;


  asection *toc_section;


  asection *entry_section;


  int text_align_power;


  int data_align_power;


  short modtype;


  short cputype;


  bfd_size_type maxdata;


  bfd_size_type maxstack;


  asection **csects;
  unsigned long *debug_indices;
  unsigned int import_file_id;
};
struct n64_tag_coff_section_tdata
{

  struct n64_tag_internal_reloc *relocs;

  boolean keep_relocs;

  bfd_byte *contents;

  boolean keep_contents;

  bfd_vma offset;
  unsigned int i;
  const char *function;
  int line_base;

  void * tdata;
};







struct n64_tag_xcoff_section_tdata
{


  asection *enclosing;


  unsigned int lineno_count;


  unsigned long first_symndx;
  unsigned long last_symndx;
};







struct n64_tag_coff_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  unsigned short type;


  unsigned char cxx_class;


  char numaux;


  bfd *auxbfd;


  union n64_tag_internal_auxent *aux;
};



struct n64_tag_coff_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;
};
extern const bfd_target *coff_object_p (bfd *) asm("_coff_object_p");
extern struct n64_tag_sec *coff_section_from_bfd_index (bfd *, int) asm("_coff_section_from_bfd_index");
extern long coff_get_symtab_upper_bound (bfd *) asm("_coff_get_symtab_upper_bound");
extern long coff_get_symtab (bfd *, asymbol **) asm("_coff_get_symtab");
extern int coff_count_linenumbers (bfd *) asm("_coff_count_linenumbers");
extern struct n64_tag_coff_symbol_struct *coff_symbol_from (bfd *, asymbol *) asm("_coff_symbol_from");
extern boolean coff_renumber_symbols (bfd *, int *) asm("_coff_renumber_symbols");
extern void coff_mangle_symbols (bfd *) asm("_coff_mangle_symbols");
extern boolean coff_write_symbols (bfd *) asm("_coff_write_symbols");
extern boolean coff_write_linenumbers (bfd *) asm("_coff_write_linenumbers");
extern alent *coff_get_lineno (bfd *, asymbol *) asm("_coff_get_lineno");
extern asymbol *coff_section_symbol (bfd *, char *) asm("_coff_section_symbol");
extern boolean _bfd_coff_get_external_symbols (bfd *) asm("__bfd_coff_get_external_symbols");
extern const char *_bfd_coff_read_string_table (bfd *) asm("__bfd_coff_read_string_table");
extern boolean _bfd_coff_free_symbols (bfd *) asm("__bfd_coff_free_symbols");
extern struct n64_tag_coff_ptr_struct *coff_get_normalized_symtab (bfd *) asm("_coff_get_normalized_symtab");
extern long coff_get_reloc_upper_bound (bfd *, sec_ptr) asm("_coff_get_reloc_upper_bound");
extern asymbol *coff_make_empty_symbol (bfd *) asm("_coff_make_empty_symbol");
extern void coff_print_symbol (bfd *, void * filep, asymbol *, bfd_print_symbol_type how) asm("_coff_print_symbol")
                                      ;
extern void coff_get_symbol_info (bfd *, asymbol *, symbol_info *ret) asm("_coff_get_symbol_info")
                         ;
extern asymbol *coff_bfd_make_debug_symbol (bfd *, void *, unsigned long) asm("_coff_bfd_make_debug_symbol")
                         ;
extern boolean coff_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr) asm("_coff_find_nearest_line")





                                    ;
extern int coff_sizeof_headers (bfd *, boolean reloc) asm("_coff_sizeof_headers");
extern boolean bfd_coff_reloc16_relax_section
  (bfd *, asection *, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_coff_reloc16_relax_section");
extern bfd_byte *bfd_coff_reloc16_get_relocated_section_contents
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean relocateable, asymbol **) asm("_bfd_coff_reloc16_get_relocated_section_contents")
                                                  ;
extern bfd_vma bfd_coff_reloc16_get_value (arelent *, struct n64_tag_bfd_link_info *, asection *) asm("_bfd_coff_reloc16_get_value")

                     ;
extern void bfd_perform_slip (bfd *abfd, unsigned int slip, asection *input_section, bfd_vma val) asm("_bfd_perform_slip")

                       ;



extern struct n64_tag_bfd_hash_entry *_bfd_coff_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_coff_link_hash_newfunc");
extern boolean _bfd_coff_link_hash_table_init
  (struct n64_tag_coff_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_coff_link_hash_table_init")


                          ;
extern struct n64_tag_bfd_link_hash_table *_bfd_coff_link_hash_table_create
  (bfd *) asm("__bfd_coff_link_hash_table_create");
extern const char *_bfd_coff_internal_syment_name
  (bfd *, const struct n64_tag_internal_syment *, char *) asm("__bfd_coff_internal_syment_name");
extern boolean _bfd_coff_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_coff_link_add_symbols");
extern boolean _bfd_coff_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_coff_final_link");
extern struct n64_tag_internal_reloc *_bfd_coff_read_internal_relocs
  (bfd *, asection *, boolean, bfd_byte *, boolean, struct n64_tag_internal_reloc *) asm("__bfd_coff_read_internal_relocs")
                             ;
extern boolean _bfd_coff_generic_relocate_section
  (bfd *, struct n64_tag_bfd_link_info *, bfd *, asection *, bfd_byte *, struct n64_tag_internal_reloc *, struct n64_tag_internal_syment *, asection **) asm("__bfd_coff_generic_relocate_section")
                                                                    ;






extern struct n64_tag_bfd_link_hash_table *_bfd_xcoff_bfd_link_hash_table_create
  (bfd *) asm("__bfd_xcoff_bfd_link_hash_table_create");
extern boolean _bfd_xcoff_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_xcoff_bfd_link_add_symbols");
extern boolean _bfd_xcoff_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_xcoff_bfd_final_link");
extern boolean _bfd_ppc_xcoff_relocate_section
  (bfd *, struct n64_tag_bfd_link_info *, bfd *, asection *, bfd_byte *, struct n64_tag_internal_reloc *, struct n64_tag_internal_syment *, asection **) asm("__bfd_ppc_xcoff_relocate_section")
                                                                    ;



typedef struct n64_tag_coff_ptr_struct
{



unsigned int offset;



unsigned int fix_value : 1;



unsigned int fix_tag : 1;



unsigned int fix_end : 1;



unsigned int fix_scnlen : 1;




unsigned int fix_line : 1;




union {
   union n64_tag_internal_auxent auxent;
   struct n64_tag_internal_syment syment;
 } u;
} combined_entry_type;




typedef struct n64_tag_coff_symbol_struct
{

asymbol symbol;


combined_entry_type *native;


struct n64_tag_lineno_cache_entry *lineno;


boolean done_lineno;
} coff_symbol_type;
typedef struct
{
  void (*_bfd_coff_swap_aux_in) ( bfd *abfd, void * ext, int type, int cxx_class, int indaux, int numaux, void * in)






                           ;

  void (*_bfd_coff_swap_sym_in) ( bfd *abfd , void * ext, void * in)


                           ;

  void (*_bfd_coff_swap_lineno_in) ( bfd *abfd, void * ext, void * in)


                           ;

 unsigned int (*_bfd_coff_swap_aux_out) ( bfd *abfd, void * in, int type, int cxx_class, int indaux, int numaux, void * ext)






                    ;

 unsigned int (*_bfd_coff_swap_sym_out) ( bfd *abfd, void * in, void * ext)


               ;

 unsigned int (*_bfd_coff_swap_lineno_out) ( bfd *abfd, void * in, void * ext)


          ;

 unsigned int (*_bfd_coff_swap_reloc_out) ( bfd *abfd, void * src, void * dst)


          ;

 unsigned int (*_bfd_coff_swap_filehdr_out) ( bfd *abfd, void * in, void * out)


           ;

 unsigned int (*_bfd_coff_swap_aouthdr_out) ( bfd *abfd, void * in, void * out)


          ;

 unsigned int (*_bfd_coff_swap_scnhdr_out) ( bfd *abfd, void * in, void * out)


          ;

 unsigned int _bfd_filhsz;
 unsigned int _bfd_aoutsz;
 unsigned int _bfd_scnhsz;
 unsigned int _bfd_symesz;
 unsigned int _bfd_auxesz;
 unsigned int _bfd_relsz;
 unsigned int _bfd_linesz;
 boolean _bfd_coff_long_filenames;
 void (*_bfd_coff_swap_filehdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_aouthdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_scnhdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_reloc_in) ( bfd *abfd, void * ext, void * in)


                   ;
 boolean (*_bfd_coff_bad_format_hook) ( bfd *abfd, void * internal_filehdr)

                                 ;
 boolean (*_bfd_coff_set_arch_mach_hook) ( bfd *abfd, void * internal_filehdr)

                                 ;
 void * (*_bfd_coff_mkobject_hook) ( bfd *abfd, void * internal_filehdr, void * internal_aouthdr)


                                 ;
 flagword (*_bfd_styp_to_sec_flags_hook) ( bfd *abfd, void * internal_scnhdr, const char *name)


                         ;
 void (*_bfd_set_alignment_hook) ( bfd *abfd, asection *sec, void * internal_scnhdr)


                                ;
 boolean (*_bfd_coff_slurp_symbol_table) ( bfd *abfd)
                      ;
 boolean (*_bfd_coff_symname_in_debug) ( bfd *abfd, struct n64_tag_internal_syment *sym)

                                    ;
 boolean (*_bfd_coff_pointerize_aux_hook) ( bfd *abfd, combined_entry_type *table_base, combined_entry_type *symbol, unsigned int indaux, combined_entry_type *aux)




                                 ;
 boolean (*_bfd_coff_print_aux) ( bfd *abfd, FILE *file, combined_entry_type *table_base, combined_entry_type *symbol, combined_entry_type *aux, unsigned int indaux)





                            ;
 void (*_bfd_coff_reloc16_extra_cases) ( bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, arelent *reloc, bfd_byte *data, unsigned int *src_ptr, unsigned int *dst_ptr)






                              ;
 int (*_bfd_coff_reloc16_estimate) ( bfd *abfd, asection *input_section, arelent *r, unsigned int shrink, struct n64_tag_bfd_link_info *link_info)




                                        ;
 boolean (*_bfd_coff_sym_is_global) ( bfd *abfd, struct n64_tag_internal_syment *)

                                 ;
 void (*_bfd_coff_compute_section_file_positions) ( bfd *abfd)
                  ;
 boolean (*_bfd_coff_start_final_link) ( bfd *output_bfd, struct n64_tag_bfd_link_info *info)

                                   ;
 boolean (*_bfd_coff_relocate_section) ( bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, struct n64_tag_internal_reloc *relocs, struct n64_tag_internal_syment *syms, asection **sections)







                            ;
 reloc_howto_type *(*_bfd_coff_rtype_to_howto) ( bfd *abfd, asection *sec, struct n64_tag_internal_reloc *rel, struct n64_tag_coff_link_hash_entry *h, struct n64_tag_internal_syment *sym, bfd_vma *addendp)





                         ;
 boolean (*_bfd_coff_adjust_symndx) ( bfd *obfd, struct n64_tag_bfd_link_info *info, bfd *ibfd, asection *sec, struct n64_tag_internal_reloc *reloc, boolean *adjustedp)





                           ;

} bfd_coff_backend_data;

static void coff_fix_symbol_name
  (bfd *, asymbol *, combined_entry_type *, bfd_size_type *, asection **, bfd_size_type *) asm("_coff_fix_symbol_name")
                                  ;
static boolean coff_write_symbol
  (bfd *, asymbol *, combined_entry_type *, unsigned int *, bfd_size_type *, asection **, bfd_size_type *) asm("_coff_write_symbol")
                                                   ;
static boolean coff_write_alien_symbol
  (bfd *, asymbol *, unsigned int *, bfd_size_type *, asection **, bfd_size_type *) asm("_coff_write_alien_symbol")
                                  ;
static boolean coff_write_native_symbol
  (bfd *, coff_symbol_type *, unsigned int *, bfd_size_type *, asection **, bfd_size_type *) asm("_coff_write_native_symbol")
                                  ;
static void coff_pointerize_aux
  (bfd *, combined_entry_type *, combined_entry_type *, unsigned int, combined_entry_type *) asm("_coff_pointerize_aux")
                                         ;





static boolean
make_a_section_from_file(bfd *abfd, struct n64_tag_internal_scnhdr *hdr, unsigned int target_index) asm("_make_a_section_from_file");
static boolean
make_a_section_from_file(bfd *abfd, struct n64_tag_internal_scnhdr *hdr, unsigned int target_index)
{
  asection *return_section;
  char *name;


  name = bfd_alloc (abfd, sizeof (hdr->s_name) + 1);
  if (name == 
             ((void *)0)
                 )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  strncpy (name, (char *) &hdr->s_name[0], sizeof (hdr->s_name));
  name[sizeof (hdr->s_name)] = 0;

  return_section = bfd_make_section_anyway (abfd, name);
  if (return_section == 
                       ((void *)0)
                           )
    return cxx_false;



  return_section->vma = hdr->s_vaddr;
  return_section->lma = return_section->vma;
  return_section->_raw_size = hdr->s_size;
  return_section->filepos = hdr->s_scnptr;
  return_section->rel_filepos = hdr->s_relptr;
  return_section->reloc_count = hdr->s_nreloc;

  ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_set_alignment_hook) (abfd, return_section, hdr));

  return_section->line_filepos = hdr->s_lnnoptr;

  return_section->lineno_count = hdr->s_nlnno;
  return_section->userdata = 
                            ((void *)0)
                                ;
  return_section->next = (asection *) 
                                     ((void *)0)
                                         ;
  return_section->flags = ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_styp_to_sec_flags_hook) (abfd, hdr, name));

  return_section->target_index = target_index;



  if ((return_section->flags & 0x800) != 0)
    return_section->lineno_count = 0;

  if (hdr->s_nreloc != 0)
    return_section->flags |= 0x004;

  if (hdr->s_scnptr != 0)
    return_section->flags |= 0x200;
  return cxx_true;
}




static const bfd_target *
coff_real_object_p(bfd *abfd, unsigned int nscns, struct n64_tag_internal_filehdr *internal_f, struct n64_tag_internal_aouthdr *internal_a) asm("_coff_real_object_p");
static const bfd_target *
coff_real_object_p(bfd *abfd, unsigned int nscns, struct n64_tag_internal_filehdr *internal_f, struct n64_tag_internal_aouthdr *internal_a)
{
  flagword oflags = abfd->flags;
  bfd_vma ostart = ((abfd)->start_address);
  void * tdata;
  size_t readsize;
  unsigned int scnhsz;
  char *external_sections;

  if (!(internal_f->f_flags & (0x0001)))
    abfd->flags |= 0x01;
  if ((internal_f->f_flags & (0x0002)))
    abfd->flags |= 0x02;
  if (!(internal_f->f_flags & (0x0004)))
    abfd->flags |= 0x04;
  if (!(internal_f->f_flags & (0x0008)))
    abfd->flags |= 0x20;


  if ((internal_f->f_flags & (0x0002)) != 0)
    abfd->flags |= 0x100;

  ((abfd)->symcount) = internal_f->f_nsyms;
  if (internal_f->f_nsyms)
    abfd->flags |= 0x10;

  if (internal_a != (struct n64_tag_internal_aouthdr *) 
                                               ((void *)0)
                                                   )
    ((abfd)->start_address) = internal_a->entry;
  else
    ((abfd)->start_address) = 0;



  tdata = ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_mkobject_hook) (abfd, (void *) internal_f, (void *) internal_a));
  if (tdata == 
              ((void *)0)
                  )
    return 0;

  scnhsz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_scnhsz);
  readsize = nscns * scnhsz;
  external_sections = (char *) bfd_alloc (abfd, readsize);
  if (!external_sections)
    {
      bfd_set_error (bfd_error_no_memory);
      goto fail;
    }

  if (bfd_read ((void *) external_sections, 1, readsize, abfd) != readsize)
    goto fail;


  if (nscns != 0)
    {
      unsigned int i;
      for (i = 0; i < nscns; i++)
 {
   struct n64_tag_internal_scnhdr tmp;
   ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_scnhdr_in) (abfd, (void *) (external_sections + i * scnhsz), (void *) & tmp))

                   ;
   make_a_section_from_file (abfd, &tmp, i + 1);
 }
    }



  if (((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_set_arch_mach_hook) (abfd, (void *) internal_f)) == cxx_false)
    goto fail;

  return abfd->xvec;

 fail:
  (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (tdata); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  abfd->flags = oflags;
  ((abfd)->start_address) = ostart;
  return (const bfd_target *) 
                             ((void *)0)
                                 ;
}




const bfd_target *
coff_object_p(bfd *abfd) asm("_coff_object_p");
const bfd_target *
coff_object_p(bfd *abfd)
{
  unsigned int filhsz;
  unsigned int aoutsz;
  int nscns;
  void * filehdr;
  struct n64_tag_internal_filehdr internal_f;
  struct n64_tag_internal_aouthdr internal_a;


  filhsz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_filhsz);
  aoutsz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_aoutsz);

  filehdr = bfd_alloc (abfd, filhsz);
  if (filehdr == 
                ((void *)0)
                    )
    return 0;
  if (bfd_read (filehdr, 1, filhsz, abfd) != filhsz)
    {
      if (bfd_get_error () != bfd_error_system_call)
 bfd_set_error (bfd_error_wrong_format);
      return 0;
    }
  ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_filehdr_in) (abfd, filehdr, &internal_f));
  (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (filehdr); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  if (((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_bad_format_hook) (abfd, &internal_f)) == cxx_false)
    {
      bfd_set_error (bfd_error_wrong_format);
      return 0;
    }
  nscns = internal_f.f_nscns;

  if (internal_f.f_opthdr)
    {
      void * opthdr;

      opthdr = bfd_alloc (abfd, aoutsz);
      if (opthdr == 
                   ((void *)0)
                       )
 return 0;;
      if (bfd_read (opthdr, 1, aoutsz, abfd) != aoutsz)
 {
   return 0;
 }
      ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_aouthdr_in) (abfd, opthdr, (void *) & internal_a));
    }


  if (bfd_seek (abfd, (file_ptr) (internal_f.f_opthdr + filhsz), 
                                                                0
                                                                        )
      != 0)
    return 
          ((void *)0)
              ;

  return coff_real_object_p (abfd, nscns, &internal_f,
        (internal_f.f_opthdr != 0
         ? &internal_a
         : (struct n64_tag_internal_aouthdr *) 
                                      ((void *)0)
                                          ));
}



asection *
coff_section_from_bfd_index(bfd *abfd, int index) asm("_coff_section_from_bfd_index");
asection *
coff_section_from_bfd_index(bfd *abfd, int index)
{
  struct n64_tag_sec *answer = abfd->sections;

  if (index == ((short)-1))
    return ((asection *) &bfd_abs_section);
  if (index == ((short)0))
    return ((asection *) &bfd_und_section);
  if (index == ((short)-2))
    return ((asection *) &bfd_abs_section);

  while (answer)
    {
      if (answer->target_index == index)
 return answer;
      answer = answer->next;
    }



  return ((asection *) &bfd_und_section);
}



long
coff_get_symtab_upper_bound(bfd *abfd) asm("_coff_get_symtab_upper_bound");
long
coff_get_symtab_upper_bound(bfd *abfd)
{
  if (!((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_slurp_symbol_table) (abfd)))
    return -1;

  return (((abfd)->symcount) + 1) * (sizeof (coff_symbol_type *));
}




long
coff_get_symtab(bfd *abfd, asymbol **alocation) asm("_coff_get_symtab");
long
coff_get_symtab(bfd *abfd, asymbol **alocation)
{
  unsigned int counter;
  coff_symbol_type *symbase;
  coff_symbol_type **location = (coff_symbol_type **) alocation;

  if (!((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_slurp_symbol_table) (abfd)))
    return -1;

  symbase = (((abfd)->tdata.coff_obj_data)->symbols);
  counter = ((abfd)->symcount);
  while (counter-- > 0)
    *location++ = symbase++;

  *location = 
             ((void *)0)
                 ;

  return ((abfd)->symcount);
}




const char *
_bfd_coff_internal_syment_name(bfd *abfd, const struct n64_tag_internal_syment *sym, char *buf) asm("__bfd_coff_internal_syment_name");
const char *
_bfd_coff_internal_syment_name(bfd *abfd, const struct n64_tag_internal_syment *sym, char *buf)
{


  if (sym->_n._n_n._n_zeroes != 0
      || sym->_n._n_n._n_offset == 0)
    {
      memcpy (buf, sym->_n._n_name, 8);
      buf[8] = '\0';
      return buf;
    }
  else
    {
      const char *strings;

      { if (!(sym->_n._n_n._n_offset >= (4))) bfd_assert("coffgen.c",354); };
      strings = (((abfd)->tdata.coff_obj_data)->strings);
      if (strings == 
                    ((void *)0)
                        )
 {
   strings = _bfd_coff_read_string_table (abfd);
   if (strings == 
                 ((void *)0)
                     )
     return 
           ((void *)0)
               ;
 }
      return strings + sym->_n._n_n._n_offset;
    }
}
struct n64_tag_internal_reloc *
_bfd_coff_read_internal_relocs(bfd *abfd, asection *sec, boolean cache, bfd_byte *external_relocs, boolean require_internal, struct n64_tag_internal_reloc *internal_relocs) asm("__bfd_coff_read_internal_relocs");
struct n64_tag_internal_reloc *
_bfd_coff_read_internal_relocs(bfd *abfd, asection *sec, boolean cache, bfd_byte *external_relocs, boolean require_internal, struct n64_tag_internal_reloc *internal_relocs)
{
  bfd_size_type relsz;
  bfd_byte *free_external = 
                           ((void *)0)
                               ;
  struct n64_tag_internal_reloc *free_internal = 
                                        ((void *)0)
                                            ;
  bfd_byte *erel;
  bfd_byte *erel_end;
  struct n64_tag_internal_reloc *irel;

  if (((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd) != 
                                      ((void *)0)
      
     && ((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd)->relocs != 
                                                 ((void *)0)
                                                     )
    {
      if (! require_internal)
 return ((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd)->relocs;
      memcpy (internal_relocs, ((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd)->relocs,
       sec->reloc_count * sizeof (struct n64_tag_internal_reloc));
      return internal_relocs;
    }

  relsz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_relsz);

  if (external_relocs == 
                        ((void *)0)
                            )
    {
      free_external = (bfd_byte *) malloc (sec->reloc_count * relsz);
      if (free_external == 
                          ((void *)0) 
                               && sec->reloc_count > 0)
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }
      external_relocs = free_external;
    }

  if (bfd_seek (abfd, sec->rel_filepos, 
                                       0
                                               ) != 0
      || (bfd_read (external_relocs, relsz, sec->reloc_count, abfd)
   != relsz * sec->reloc_count))
    goto error_return;

  if (internal_relocs == 
                        ((void *)0)
                            )
    {
      free_internal = ((struct n64_tag_internal_reloc *)
         malloc (sec->reloc_count
          * sizeof (struct n64_tag_internal_reloc)));
      if (free_internal == 
                          ((void *)0) 
                               && sec->reloc_count > 0)
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }
      internal_relocs = free_internal;
    }


  erel = external_relocs;
  erel_end = erel + relsz * sec->reloc_count;
  irel = internal_relocs;
  for (; erel < erel_end; erel += relsz, irel++)
    ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_reloc_in) (abfd, (void *) erel, (void *) irel));

  if (free_external != 
                      ((void *)0)
                          )
    {
      free (free_external);
      free_external = 
                     ((void *)0)
                         ;
    }

  if (cache && free_internal != 
                               ((void *)0)
                                   )
    {
      if (((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd) == 
                                          ((void *)0)
                                              )
 {
   sec->used_by_bfd =
     (void *) bfd_zalloc (abfd,
         sizeof (struct n64_tag_coff_section_tdata));
   if (sec->used_by_bfd == 
                          ((void *)0)
                              )
     {
       bfd_set_error (bfd_error_no_memory);
       goto error_return;
     }
   ((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd)->contents = 
                                            ((void *)0)
                                                ;
 }
      ((struct n64_tag_coff_section_tdata *) (sec)->used_by_bfd)->relocs = free_internal;
    }

  return internal_relocs;

 error_return:
  if (free_external != 
                      ((void *)0)
                          )
    free (free_external);
  if (free_internal != 
                      ((void *)0)
                          )
    free (free_internal);
  return 
        ((void *)0)
            ;
}



int
coff_count_linenumbers(bfd *abfd) asm("_coff_count_linenumbers");
int
coff_count_linenumbers(bfd *abfd)
{
  unsigned int limit = ((abfd)->symcount);
  unsigned int i;
  int total = 0;
  asymbol **p;
  asection *s;

  if (limit == 0)
    {


      for (s = abfd->sections; s != 
                                   ((void *)0)
                                       ; s = s->next)
 total += s->lineno_count;
      return total;
    }

  for (s = abfd->sections; s != 
                               ((void *)0)
                                   ; s = s->next)
    { if (!(s->lineno_count == 0)) bfd_assert("coffgen.c",495); };

  for (p = abfd->outsymbols, i = 0; i < limit; i++, p++)
    {
      asymbol *q_maybe = *p;

      if ((((q_maybe)->the_bfd)->xvec->flavour) == bfd_target_coff_flavour)
 {
   coff_symbol_type *q = ((coff_symbol_type *)(&((q_maybe)->the_bfd)));




   if (q->lineno != 
                   ((void *)0)
       
      && q->symbol.section->owner != 
                                     ((void *)0)
                                         )
     {


       alent *l = q->lineno;

       ++q->symbol.section->output_section->lineno_count;
       ++total;
       ++l;
       while (l->line_number != 0)
  {
    ++total;
    ++q->symbol.section->output_section->lineno_count;
    ++l;
  }
     }
 }
    }

  return total;
}





coff_symbol_type *
coff_symbol_from(bfd *ignore_abfd, asymbol *symbol) asm("_coff_symbol_from");
coff_symbol_type *
coff_symbol_from(bfd *ignore_abfd, asymbol *symbol)
{
  if ((((symbol)->the_bfd)->xvec->flavour) != bfd_target_coff_flavour)
    return (coff_symbol_type *) 
                               ((void *)0)
                                   ;

  if (((symbol)->the_bfd)->tdata.coff_obj_data == (coff_data_type *) 
                                                                         ((void *)0)
                                                                             )
    return (coff_symbol_type *) 
                               ((void *)0)
                                   ;

  return (coff_symbol_type *) symbol;
}

static void
fixup_symbol_value(coff_symbol_type *coff_symbol_ptr, struct n64_tag_internal_syment *syment) asm("_fixup_symbol_value");
static void
fixup_symbol_value(coff_symbol_type *coff_symbol_ptr, struct n64_tag_internal_syment *syment)
{


  if ((((coff_symbol_ptr->symbol.section)->flags & 0x8000) != 0))
    {

      syment->n_scnum = ((short)0);
      syment->n_value = coff_symbol_ptr->symbol.value;
    }
  else if (coff_symbol_ptr->symbol.flags & 0x08)
    {
      syment->n_value = coff_symbol_ptr->symbol.value;
    }
  else if (((coff_symbol_ptr->symbol.section) == ((asection *) &bfd_und_section)))
    {
      syment->n_scnum = ((short)0);
      syment->n_value = 0;
    }
  else
    {
      if (coff_symbol_ptr->symbol.section)
 {
   syment->n_scnum =
     coff_symbol_ptr->symbol.section->output_section->target_index;

   syment->n_value =
     coff_symbol_ptr->symbol.value +
     coff_symbol_ptr->symbol.section->output_offset +
     coff_symbol_ptr->symbol.section->output_section->vma;
 }
      else
 {
   { if (!(0)) bfd_assert("coffgen.c",585); };

   syment->n_scnum = ((short)-1);
   syment->n_value = coff_symbol_ptr->symbol.value;
 }
    }
}
boolean
coff_renumber_symbols(bfd *bfd_ptr, int *first_undef) asm("_coff_renumber_symbols");
boolean
coff_renumber_symbols(bfd *bfd_ptr, int *first_undef)
{
  unsigned int symbol_count = ((bfd_ptr)->symcount);
  asymbol **symbol_ptr_ptr = bfd_ptr->outsymbols;
  unsigned int native_index = 0;
  struct n64_tag_internal_syment *last_file = (struct n64_tag_internal_syment *) 
                                                                ((void *)0)
                                                                    ;
  unsigned int symbol_index;
  {
    asymbol **newsyms;
    unsigned int i;

    newsyms = (asymbol **) bfd_alloc_by_size_t (bfd_ptr,
      sizeof (asymbol *)
      * (symbol_count + 1));
    if (!newsyms)
      {
 bfd_set_error (bfd_error_no_memory);
 return cxx_false;
      }
    bfd_ptr->outsymbols = newsyms;
    for (i = 0; i < symbol_count; i++)
      if ((symbol_ptr_ptr[i]->flags & 0x400) != 0
   || (!((symbol_ptr_ptr[i]->section) == ((asection *) &bfd_und_section))
       && ((symbol_ptr_ptr[i]->flags & (0x02 | 0x10))
    != 0x02)))
 *newsyms++ = symbol_ptr_ptr[i];

    for (i = 0; i < symbol_count; i++)
      if (!((symbol_ptr_ptr[i]->section) == ((asection *) &bfd_und_section))
   && ((symbol_ptr_ptr[i]->flags & (0x02
        | 0x400
        | 0x10))
       == 0x02))
 *newsyms++ = symbol_ptr_ptr[i];

    *first_undef = newsyms - bfd_ptr->outsymbols;

    for (i = 0; i < symbol_count; i++)
      if ((symbol_ptr_ptr[i]->flags & 0x400) == 0
   && ((symbol_ptr_ptr[i]->section) == ((asection *) &bfd_und_section)))
 *newsyms++ = symbol_ptr_ptr[i];
    *newsyms = (asymbol *) 
                          ((void *)0)
                              ;
    symbol_ptr_ptr = bfd_ptr->outsymbols;
  }

  for (symbol_index = 0; symbol_index < symbol_count; symbol_index++)
    {
      coff_symbol_type *coff_symbol_ptr = coff_symbol_from (bfd_ptr, symbol_ptr_ptr[symbol_index]);
      symbol_ptr_ptr[symbol_index]->udata.i = symbol_index;
      if (coff_symbol_ptr && coff_symbol_ptr->native)
 {
   combined_entry_type *s = coff_symbol_ptr->native;
   int i;

   if (s->u.syment.n_sclass == 103)
     {
       if (last_file != (struct n64_tag_internal_syment *) 
                                                  ((void *)0)
                                                      )
  last_file->n_value = native_index;
       last_file = &(s->u.syment);
     }
   else
     {




       fixup_symbol_value (coff_symbol_ptr, &(s->u.syment));
     }
   for (i = 0; i < s->u.syment.n_numaux + 1; i++)
     s[i].offset = native_index++;
 }
      else
 {
   native_index++;
 }
    }
  (((bfd_ptr)->tdata.coff_obj_data)->conv_table_size) = native_index;

  return cxx_true;
}





void
coff_mangle_symbols(bfd *bfd_ptr) asm("_coff_mangle_symbols");
void
coff_mangle_symbols(bfd *bfd_ptr)
{
  unsigned int symbol_count = ((bfd_ptr)->symcount);
  asymbol **symbol_ptr_ptr = bfd_ptr->outsymbols;
  unsigned int symbol_index;

  for (symbol_index = 0; symbol_index < symbol_count; symbol_index++)
    {
      coff_symbol_type *coff_symbol_ptr =
      coff_symbol_from (bfd_ptr, symbol_ptr_ptr[symbol_index]);

      if (coff_symbol_ptr && coff_symbol_ptr->native)
 {
   int i;
   combined_entry_type *s = coff_symbol_ptr->native;

   if (s->fix_value)
     {

       s->u.syment.n_value =
  ((combined_entry_type *) s->u.syment.n_value)->offset;
       s->fix_value = 0;
     }
   if (s->fix_line)
     {



       s->u.syment.n_value =
  (coff_symbol_ptr->symbol.section->output_section->line_filepos
   + s->u.syment.n_value * (((bfd_coff_backend_data *) (bfd_ptr)->xvec->backend_data)->_bfd_linesz));
       coff_symbol_ptr->symbol.section =
  coff_section_from_bfd_index (bfd_ptr, ((short)-2));
       { if (!(coff_symbol_ptr->symbol.flags & 0x08)) bfd_assert("coffgen.c",734); };
     }
   for (i = 0; i < s->u.syment.n_numaux; i++)
     {
       combined_entry_type *a = s + i + 1;
       if (a->fix_tag)
  {
    a->u.auxent.x_sym.x_tagndx.l =
      a->u.auxent.x_sym.x_tagndx.p->offset;
    a->fix_tag = 0;
  }
       if (a->fix_end)
  {
    a->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.l =
      a->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.p->offset;
    a->fix_end = 0;
  }
       if (a->fix_scnlen)
  {
    a->u.auxent.x_csect.x_scnlen.l =
      a->u.auxent.x_csect.x_scnlen.p->offset;
    a->fix_scnlen = 0;
  }
     }
 }
    }
}

static void
coff_fix_symbol_name(bfd *abfd, asymbol *symbol, combined_entry_type *native, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p) asm("_coff_fix_symbol_name");
static void
coff_fix_symbol_name(bfd *abfd, asymbol *symbol, combined_entry_type *native, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p)
{
  unsigned int name_length;
  union n64_tag_internal_auxent *auxent;
  char *name = (char *) (symbol->name);

  if (name == (char *) 
                      ((void *)0)
                          )
    {

      symbol->name = "strange";
      name = (char *) symbol->name;
    }
  name_length = strlen (name);

  if (native->u.syment.n_sclass == 103
      && native->u.syment.n_numaux > 0)
    {
      strncpy (native->u.syment._n._n_name, ".file", 8);
      auxent = &(native + 1)->u.auxent;

      if ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_long_filenames))
 {
   if (name_length <= 14)
     {
       strncpy (auxent->x_file.x_fname, name, 14);
     }
   else
     {
       auxent->x_file.x_n.x_offset = *string_size_p + (4);
       auxent->x_file.x_n.x_zeroes = 0;
       *string_size_p += name_length + 1;
     }
 }
      else
 {
   strncpy (auxent->x_file.x_fname, name, 14);
   if (name_length > 14)
     {
       name[14] = '\0';
     }
 }
    }
  else
    {
      if (name_length <= 8)
 {

   strncpy (native->u.syment._n._n_name, symbol->name, 8);
 }
      else if (!((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_symname_in_debug) (abfd, &native->u.syment)))
 {
   native->u.syment._n._n_n._n_offset = (*string_size_p
      + (4));
   native->u.syment._n._n_n._n_zeroes = 0;
   *string_size_p += name_length + 1;
 }
      else
 {
   long filepos;
   bfd_byte buf[2];






   if (*debug_string_section_p == (asection *) 
                                              ((void *)0)
                                                  )
     *debug_string_section_p = bfd_get_section_by_name (abfd, ".debug");
   filepos = bfd_tell (abfd);
   ((*((abfd)->xvec->bfd_putx16)) ((name_length + 1),(buf)));
   if (!bfd_set_section_contents (abfd,
      *debug_string_section_p,
      (void *) buf,
      (file_ptr) *debug_string_size_p,
      (bfd_size_type) 2)
       || !bfd_set_section_contents (abfd,
         *debug_string_section_p,
         (void *) symbol->name,
         ((file_ptr) *debug_string_size_p
          + 2),
         (bfd_size_type) name_length + 1))
     abort ();
   if (bfd_seek (abfd, filepos, 
                               0
                                       ) != 0)
     abort ();
   native->u.syment._n._n_n._n_offset = *debug_string_size_p + 2;
   native->u.syment._n._n_n._n_zeroes = 0;
   *debug_string_size_p += name_length + 3;
 }
    }
}
static boolean
coff_write_symbol(bfd *abfd, asymbol *symbol, combined_entry_type *native, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p) asm("_coff_write_symbol");
static boolean
coff_write_symbol(bfd *abfd, asymbol *symbol, combined_entry_type *native, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p)
{
  unsigned int numaux = native->u.syment.n_numaux;
  int type = native->u.syment.n_type;
  int cxx_class = native->u.syment.n_sclass;
  void * buf;
  bfd_size_type symesz;

  if (native->u.syment.n_sclass == 103)
    symbol->flags |= 0x08;

  if (symbol->flags & 0x08
      && ((symbol->section) == ((asection *) &bfd_abs_section)))
    {
      native->u.syment.n_scnum = ((short)-2);
    }
  else if (((symbol->section) == ((asection *) &bfd_abs_section)))
    {
      native->u.syment.n_scnum = ((short)-1);
    }
  else if (((symbol->section) == ((asection *) &bfd_und_section)))
    {
      native->u.syment.n_scnum = ((short)0);
    }
  else
    {
      native->u.syment.n_scnum =
 symbol->section->output_section->target_index;
    }

  coff_fix_symbol_name (abfd, symbol, native, string_size_p,
   debug_string_section_p, debug_string_size_p);

  symesz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_symesz);
  buf = bfd_alloc (abfd, symesz);
  if (!buf)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_sym_out) (abfd, &native->u.syment, buf));
  if (bfd_write (buf, 1, symesz, abfd) != symesz)
    return cxx_false;
  (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (buf); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  if (native->u.syment.n_numaux > 0)
    {
      bfd_size_type auxesz;
      unsigned int j;

      auxesz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_auxesz);
      buf = bfd_alloc (abfd, auxesz);
      if (!buf)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      for (j = 0; j < native->u.syment.n_numaux; j++)
 {
   ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_aux_out) (abfd,&((native + j + 1)->u.auxent),type,cxx_class,j,native->u.syment.n_numaux,buf))





         ;
   if (bfd_write (buf, 1, auxesz, abfd) != auxesz)
     return cxx_false;
 }
      (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (buf); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
    }


  ((symbol)->udata.i = (*written));

  *written += numaux + 1;
  return cxx_true;
}





static boolean
coff_write_alien_symbol(bfd *abfd, asymbol *symbol, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p) asm("_coff_write_alien_symbol");
static boolean
coff_write_alien_symbol(bfd *abfd, asymbol *symbol, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p)
{
  combined_entry_type *native;
  combined_entry_type dummy;

  native = &dummy;
  native->u.syment.n_type = 0;
  native->u.syment.n_flags = 0;
  if (((symbol->section) == ((asection *) &bfd_und_section)))
    {
      native->u.syment.n_scnum = ((short)0);
      native->u.syment.n_value = symbol->value;
    }
  else if ((((symbol->section)->flags & 0x8000) != 0))
    {
      native->u.syment.n_scnum = ((short)0);
      native->u.syment.n_value = symbol->value;
    }
  else if (symbol->flags & 0x08)
    {




      symbol->name = "";
      return cxx_true;
    }
  else
    {
      native->u.syment.n_scnum =
 symbol->section->output_section->target_index;
      native->u.syment.n_value = (symbol->value
      + symbol->section->output_section->vma
      + symbol->section->output_offset);



      {
 coff_symbol_type *c = coff_symbol_from (abfd, symbol);
 if (c != (coff_symbol_type *) 
                              ((void *)0)
                                  )
   native->u.syment.n_flags = ((&c->symbol)->the_bfd)->flags;
      }
    }

  native->u.syment.n_type = 0;
  if (symbol->flags & 0x01)
    native->u.syment.n_sclass = 3;
  else
    native->u.syment.n_sclass = 2;
  native->u.syment.n_numaux = 0;

  return coff_write_symbol (abfd, symbol, native, written, string_size_p,
       debug_string_section_p, debug_string_size_p);
}



static boolean
coff_write_native_symbol(bfd *abfd, coff_symbol_type *symbol, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p) asm("_coff_write_native_symbol");
static boolean
coff_write_native_symbol(bfd *abfd, coff_symbol_type *symbol, unsigned int *written, bfd_size_type *string_size_p, asection **debug_string_section_p, bfd_size_type *debug_string_size_p)
{
  combined_entry_type *native = symbol->native;
  alent *lineno = symbol->lineno;




  if (lineno && !symbol->done_lineno && symbol->symbol.section->owner != 
                                                                        ((void *)0)
                                                                            )
    {
      unsigned int count = 0;
      lineno[count].u.offset = *written;
      if (native->u.syment.n_numaux)
 {
   union n64_tag_internal_auxent *a = &((native + 1)->u.auxent);

   a->x_sym.x_fcnary.x_fcn.x_lnnoptr =
     symbol->symbol.section->output_section->moving_line_filepos;
 }


      count++;
      while (lineno[count].line_number != 0)
 {
   lineno[count].u.offset +=
     (symbol->symbol.section->output_section->vma
      + symbol->symbol.section->output_offset);

   count++;
 }
      symbol->done_lineno = cxx_true;

      symbol->symbol.section->output_section->moving_line_filepos +=
 count * (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_linesz);
    }

  return coff_write_symbol (abfd, &(symbol->symbol), native, written,
       string_size_p, debug_string_section_p,
       debug_string_size_p);
}



boolean
coff_write_symbols(bfd *abfd) asm("_coff_write_symbols");
boolean
coff_write_symbols(bfd *abfd)
{
  bfd_size_type string_size;
  asection *debug_string_section;
  bfd_size_type debug_string_size;
  unsigned int i;
  unsigned int limit = ((abfd)->symcount);
  unsigned int written = 0;
  asymbol **p;

  string_size = 0;
  debug_string_section = 
                        ((void *)0)
                            ;
  debug_string_size = 0;


  if (bfd_seek (abfd, (((abfd)->tdata.coff_obj_data)->sym_filepos), 
                                             0
                                                     ) != 0)
    return cxx_false;



  written = 0;
  for (p = abfd->outsymbols, i = 0; i < limit; i++, p++)
    {
      asymbol *symbol = *p;
      coff_symbol_type *c_symbol = coff_symbol_from (abfd, symbol);

      if (c_symbol == (coff_symbol_type *) 
                                          ((void *)0)
   
  || c_symbol->native == (combined_entry_type *) 
                                                 ((void *)0)
                                                     )
 {
   if (!coff_write_alien_symbol (abfd, symbol, &written, &string_size,
     &debug_string_section,
     &debug_string_size))
     return cxx_false;
 }
      else
 {
   if (!coff_write_native_symbol (abfd, c_symbol, &written,
      &string_size, &debug_string_section,
      &debug_string_size))
     return cxx_false;
 }
    }

  (((abfd)->tdata.coff_obj_data)->raw_syment_count) = written;



  if (string_size != 0)
    {
      unsigned int size = string_size + (4);
      bfd_byte buffer[(4)];


      ((*((abfd)->xvec->bfd_h_putx32)) (size,buffer));



      if (bfd_write ((void *) buffer, 1, sizeof (buffer), abfd) != sizeof (buffer))
 return cxx_false;
      for (p = abfd->outsymbols, i = 0;
    i < limit;
    i++, p++)
 {
   asymbol *q = *p;
   size_t name_length = strlen (q->name);
   coff_symbol_type *c_symbol = coff_symbol_from (abfd, q);
   size_t maxlen;
   if (c_symbol == 
                  ((void *)0)
       
      || c_symbol->native == 
                             ((void *)0)
                                 )
     {


       maxlen = 8;
     }
   else if (((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_symname_in_debug) (abfd, &c_symbol->native->u.syment))
                                       )
     {


       maxlen = name_length;
     }
   else if (c_symbol->native->u.syment.n_sclass == 103
     && c_symbol->native->u.syment.n_numaux > 0)
     maxlen = 14;
   else
     maxlen = 8;

   if (name_length > maxlen)
     {
       if (bfd_write ((void *) (q->name), 1, name_length + 1, abfd)
    != name_length + 1)
  return cxx_false;
     }
 }
    }
  else
    {



      unsigned int size = (4);
      bfd_byte buffer[(4)];


      ((*((abfd)->xvec->bfd_h_putx32)) (size,buffer));



      if (bfd_write ((void *) buffer, 1, (4), abfd)
   != (4))
 return cxx_false;
    }






  { if (!(debug_string_size == 0 || (debug_string_section != (asection *) 
 ((void *)0) 
 && (((( (debug_string_size) + ((1 << debug_string_section->alignment_power) -1)) & (~((1 << debug_string_section->alignment_power)-1)))) == ((debug_string_section->reloc_done ? (abort(),1): (debug_string_section)->_raw_size)))))) bfd_assert("coffgen.c",1223); }



                                                           ;

  return cxx_true;
}

boolean
coff_write_linenumbers(bfd *abfd) asm("_coff_write_linenumbers");
boolean
coff_write_linenumbers(bfd *abfd)
{
  asection *s;
  bfd_size_type linesz;
  void * buff;

  linesz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_linesz);
  buff = bfd_alloc (abfd, linesz);
  if (!buff)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  for (s = abfd->sections; s != (asection *) 
                                            ((void *)0)
                                                ; s = s->next)
    {
      if (s->lineno_count)
 {
   asymbol **q = abfd->outsymbols;
   if (bfd_seek (abfd, s->line_filepos, 
                                       0
                                               ) != 0)
     return cxx_false;

   while (*q)
     {
       asymbol *p = *q;
       if (p->section->output_section == s)
  {
    alent *l =
    ((*((((p)->the_bfd))->xvec->_get_lineno)) (((p)->the_bfd), p))
                                ;
    if (l)
      {

        struct n64_tag_internal_lineno out;
        memset ((void *) & out, 0, sizeof (out));
        out.l_lnno = 0;
        out.l_addr.l_symndx = l->u.offset;
        ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_lineno_out) (abfd, &out, buff));
        if (bfd_write (buff, 1, linesz, abfd) != linesz)
   return cxx_false;
        l++;
        while (l->line_number)
   {
     out.l_lnno = l->line_number;
     out.l_addr.l_symndx = l->u.offset;
     ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_lineno_out) (abfd, &out, buff));
     if (bfd_write (buff, 1, linesz, abfd) != linesz)
       return cxx_false;
     l++;
   }
      }
  }
       q++;
     }
 }
    }
  (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (buff); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  return cxx_true;
}


alent *
coff_get_lineno(bfd *ignore_abfd, asymbol *symbol) asm("_coff_get_lineno");
alent *
coff_get_lineno(bfd *ignore_abfd, asymbol *symbol)
{
  return ((coff_symbol_type *)(&((symbol)->the_bfd)))->lineno;
}

asymbol *
coff_section_symbol(bfd *abfd, char *name) asm("_coff_section_symbol");
asymbol *
coff_section_symbol(bfd *abfd, char *name)
{
  asection *sec = bfd_make_section_old_way (abfd, name);
  asymbol *sym;
  combined_entry_type *csym;

  sym = sec->symbol;
  csym = coff_symbol_from (abfd, sym)->native;

  if (csym == 0)
    {
      struct n64_tag_foo
 {
   coff_symbol_type sym;

   combined_entry_type e[10];
 };
      struct n64_tag_foo *f;
      f = (struct n64_tag_foo *) bfd_alloc_by_size_t (abfd, sizeof (*f));
      if (!f)
 {
   bfd_set_error (bfd_error_no_error);
   return 
         ((void *)0)
             ;
 }
      memset ((char *) f, 0, sizeof (*f));
      coff_symbol_from (abfd, sym)->native = csym = f->e;
    }
  csym[0].u.syment.n_sclass = 3;
  csym[0].u.syment.n_numaux = 1;

  csym[1].u.auxent.x_scn.x_scnlen = sec->_raw_size;
  csym[1].u.auxent.x_scn.x_nreloc = sec->reloc_count;
  csym[1].u.auxent.x_scn.x_nlinno = sec->lineno_count;

  if (sec->output_section == 
                            ((void *)0)
                                )
    {
      sec->output_section = sec;
      sec->output_offset = 0;
    }

  return sym;
}




static void
coff_pointerize_aux(bfd *abfd, combined_entry_type *table_base, combined_entry_type *symbol, unsigned int indaux, combined_entry_type *auxent) asm("_coff_pointerize_aux");
static void
coff_pointerize_aux(bfd *abfd, combined_entry_type *table_base, combined_entry_type *symbol, unsigned int indaux, combined_entry_type *auxent)
{
  int type = symbol->u.syment.n_type;
  int cxx_class = symbol->u.syment.n_sclass;

  if (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_pointerize_aux_hook)
    {
      if ((*((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_pointerize_aux_hook)
   (abfd, table_base, symbol, indaux, auxent))
 return;
    }


  if (cxx_class == 3 && type == 0)
    return;
  if (cxx_class == 103)
    return;




  if (((((type) & ((abfd)->tdata.coff_obj_data)->local_n_tmask) == ((2) << ((abfd)->tdata.coff_obj_data)->local_n_btshft)) || ((cxx_class)==10||(cxx_class)==12||(cxx_class)==15) || cxx_class == 100)
      && auxent->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.l > 0)
    {
      auxent->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.p =
 table_base + auxent->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.l;
      auxent->fix_end = 1;
    }


  if (auxent->u.auxent.x_sym.x_tagndx.l > 0)
    {
      auxent->u.auxent.x_sym.x_tagndx.p =
 table_base + auxent->u.auxent.x_sym.x_tagndx.l;
      auxent->fix_tag = 1;
    }
}





static char *
build_debug_section(bfd *abfd) asm("_build_debug_section");
static char *
build_debug_section(bfd *abfd)
{
  char *debug_section;
  long position;

  asection *sect = bfd_get_section_by_name (abfd, ".debug");

  if (!sect)
    {
      bfd_set_error (bfd_error_no_debug_section);
      return 
            ((void *)0)
                ;
    }

  debug_section = (void *) bfd_alloc (abfd,
       (sect->reloc_done ? (abort(),1): (sect)->_raw_size));
  if (debug_section == 
                      ((void *)0)
                          )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }





  position = bfd_tell (abfd);
  if (bfd_seek (abfd, sect->filepos, 
                                    0
                                            ) != 0
      || (bfd_read (debug_section,
      (sect->reloc_done ? (abort(),1): (sect)->_raw_size), 1, abfd)
   != (sect->reloc_done ? (abort(),1): (sect)->_raw_size))
      || bfd_seek (abfd, position, 
                                  0
                                          ) != 0)
    return 
          ((void *)0)
              ;
  return debug_section;
}





static char *
copy_name(bfd *abfd, char *name, int maxlen) asm("_copy_name");
static char *
copy_name(bfd *abfd, char *name, int maxlen)
{
  int len;
  char *newname;

  for (len = 0; len < maxlen; ++len)
    {
      if (name[len] == '\0')
 {
   break;
 }
    }

  if ((newname = (void *) bfd_alloc (abfd, len + 1)) == 
                                                    ((void *)0)
                                                        )
    {
      bfd_set_error (bfd_error_no_memory);
      return (
             ((void *)0)
                 );
    }
  strncpy (newname, name, len);
  newname[len] = '\0';
  return newname;
}



boolean
_bfd_coff_get_external_symbols(bfd *abfd) asm("__bfd_coff_get_external_symbols");
boolean
_bfd_coff_get_external_symbols(bfd *abfd)
{
  bfd_size_type symesz;
  size_t size;
  void * syms;

  if ((((abfd)->tdata.coff_obj_data)->external_syms) != 
                                      ((void *)0)
                                          )
    return cxx_true;

  symesz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_symesz);

  size = (((abfd)->tdata.coff_obj_data)->raw_syment_count) * symesz;

  syms = malloc (size);
  if (syms == 
             ((void *)0) 
                  && size != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  if (bfd_seek (abfd, (((abfd)->tdata.coff_obj_data)->sym_filepos), 
                                             0
                                                     ) != 0
      || bfd_read (syms, size, 1, abfd) != size)
    {
      if (syms != 
                 ((void *)0)
                     )
 free (syms);
      return cxx_false;
    }

  (((abfd)->tdata.coff_obj_data)->external_syms) = syms;

  return cxx_true;
}





const char *
_bfd_coff_read_string_table(bfd *abfd) asm("__bfd_coff_read_string_table");
const char *
_bfd_coff_read_string_table(bfd *abfd)
{
  char extstrsize[(4)];
  size_t strsize;
  char *strings;

  if ((((abfd)->tdata.coff_obj_data)->strings) != 
                                ((void *)0)
                                    )
    return (((abfd)->tdata.coff_obj_data)->strings);

  if (bfd_seek (abfd,
  ((((abfd)->tdata.coff_obj_data)->sym_filepos)
   + (((abfd)->tdata.coff_obj_data)->raw_syment_count) * (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_symesz)),
  
 0
         ) != 0)
    return 
          ((void *)0)
              ;

  if (bfd_read (extstrsize, sizeof extstrsize, 1, abfd) != sizeof extstrsize)
    {
      if (bfd_get_error () != bfd_error_file_truncated)
 return 
       ((void *)0)
           ;


      strsize = (4);
    }
  else
    {

      strsize = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) extstrsize));



    }

  if (strsize < (4))
    {
      (*_bfd_error_handler)
 ("%s: bad string table size %lu", ((char *) (abfd)->filename),
  (unsigned long) strsize);
      bfd_set_error (bfd_error_bad_value);
      return 
            ((void *)0)
                ;
    }

  strings = malloc (strsize);
  if (strings == 
                ((void *)0)
                    )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }

  if (bfd_read (strings + (4),
  strsize - (4), 1, abfd)
      != strsize - (4))
    {
      free (strings);
      return 
            ((void *)0)
                ;
    }

  (((abfd)->tdata.coff_obj_data)->strings) = strings;

  return strings;
}



boolean
_bfd_coff_free_symbols(bfd *abfd) asm("__bfd_coff_free_symbols");
boolean
_bfd_coff_free_symbols(bfd *abfd)
{
  if ((((abfd)->tdata.coff_obj_data)->external_syms) != 
                                      ((void *)0)
      
     && ! (((abfd)->tdata.coff_obj_data)->keep_syms))
    {
      free ((((abfd)->tdata.coff_obj_data)->external_syms));
      (((abfd)->tdata.coff_obj_data)->external_syms) = 
                                     ((void *)0)
                                         ;
    }
  if ((((abfd)->tdata.coff_obj_data)->strings) != 
                                ((void *)0)
      
     && ! (((abfd)->tdata.coff_obj_data)->keep_strings))
    {
      free ((((abfd)->tdata.coff_obj_data)->strings));
      (((abfd)->tdata.coff_obj_data)->strings) = 
                               ((void *)0)
                                   ;
    }
  return cxx_true;
}






combined_entry_type *
coff_get_normalized_symtab(bfd *abfd) asm("_coff_get_normalized_symtab");
combined_entry_type *
coff_get_normalized_symtab(bfd *abfd)
{
  combined_entry_type *internal;
  combined_entry_type *internal_ptr;
  combined_entry_type *symbol_ptr;
  combined_entry_type *internal_end;
  bfd_size_type symesz;
  char *raw_src;
  char *raw_end;
  const char *string_table = 
                            ((void *)0)
                                ;
  char *debug_section = 
                       ((void *)0)
                           ;
  unsigned long size;

  if ((((abfd)->tdata.coff_obj_data)->raw_syments) != 
                               ((void *)0)
                                   )
    return (((abfd)->tdata.coff_obj_data)->raw_syments);

  size = (((abfd)->tdata.coff_obj_data)->raw_syment_count) * sizeof (combined_entry_type);
  internal = (combined_entry_type *) bfd_alloc (abfd, size);
  if (internal == 
                 ((void *)0) 
                      && size != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  internal_end = internal + (((abfd)->tdata.coff_obj_data)->raw_syment_count);

  if (! _bfd_coff_get_external_symbols (abfd))
    return 
          ((void *)0)
              ;

  raw_src = (char *) (((abfd)->tdata.coff_obj_data)->external_syms);


  symesz = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_symesz);
  raw_end = (char *) raw_src + (((abfd)->tdata.coff_obj_data)->raw_syment_count) * symesz;





  for (internal_ptr = internal;
       raw_src < raw_end;
       raw_src += symesz, internal_ptr++)
    {

      unsigned int i;
      ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_sym_in) (abfd,(void *) raw_src,(void *) & internal_ptr->u.syment))
                                      ;
      internal_ptr->fix_value = 0;
      internal_ptr->fix_tag = 0;
      internal_ptr->fix_end = 0;
      internal_ptr->fix_scnlen = 0;
      symbol_ptr = internal_ptr;

      for (i = 0;
    i < symbol_ptr->u.syment.n_numaux;
    i++)
 {
   internal_ptr++;
   raw_src += symesz;

   internal_ptr->fix_value = 0;
   internal_ptr->fix_tag = 0;
   internal_ptr->fix_end = 0;
   internal_ptr->fix_scnlen = 0;
   ((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_swap_aux_in) (abfd,(void *) raw_src,symbol_ptr->u.syment.n_type,symbol_ptr->u.syment.n_sclass,i,symbol_ptr->u.syment.n_numaux,&(internal_ptr->u.auxent)))



                              ;
   coff_pointerize_aux (abfd, internal, symbol_ptr, i,
          internal_ptr);
 }
    }


  (((abfd)->tdata.coff_obj_data)->keep_strings) = cxx_true;
  if (! _bfd_coff_free_symbols (abfd))
    return 
          ((void *)0)
              ;

  for (internal_ptr = internal; internal_ptr < internal_end;
       internal_ptr++)
    {
      if (internal_ptr->u.syment.n_sclass == 103
   && internal_ptr->u.syment.n_numaux > 0)
 {


   if ((internal_ptr + 1)->u.auxent.x_file.x_n.x_zeroes == 0)
     {

       if (string_table == 
                          ((void *)0)
                              )
  {
    string_table = _bfd_coff_read_string_table (abfd);
    if (string_table == 
                       ((void *)0)
                           )
      return 
            ((void *)0)
                ;
  }

       internal_ptr->u.syment._n._n_n._n_offset =
  ((long)
   (string_table
    + (internal_ptr + 1)->u.auxent.x_file.x_n.x_offset));
     }
   else
     {

       internal_ptr->u.syment._n._n_n._n_offset = (long)
  copy_name (abfd, (internal_ptr + 1)->u.auxent.x_file.x_fname,
      14);
     }
 }
      else
 {
   if (internal_ptr->u.syment._n._n_n._n_zeroes != 0)
     {

       unsigned long i = 0;
       char *newstring = 
                        ((void *)0)
                            ;



       for (i = 0; i < 8; ++i)
  {
    if (internal_ptr->u.syment._n._n_name[i] == '\0')
      {
        break;
      }
  }

       if ((newstring = (void *) bfd_alloc (abfd, ++i)) == 
                                                       ((void *)0)
                                                           )
  {
    bfd_set_error (bfd_error_no_memory);
    return (
           ((void *)0)
               );
  }
       memset (newstring, 0, i);
       strncpy (newstring, internal_ptr->u.syment._n._n_name, i - 1);
       internal_ptr->u.syment._n._n_n._n_offset = (long int) newstring;
       internal_ptr->u.syment._n._n_n._n_zeroes = 0;
     }
   else if (internal_ptr->u.syment._n._n_n._n_offset == 0)
     internal_ptr->u.syment._n._n_n._n_offset = (long int) "";
   else if (!((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_symname_in_debug) (abfd, &internal_ptr->u.syment)))
     {


       if (string_table == 
                          ((void *)0)
                              )
  {
    string_table = _bfd_coff_read_string_table (abfd);
    if (string_table == 
                       ((void *)0)
                           )
      return 
            ((void *)0)
                ;
  }
       internal_ptr->u.syment._n._n_n._n_offset =
  ((long int)
   (string_table
    + internal_ptr->u.syment._n._n_n._n_offset));
     }
   else
     {

       if (debug_section == 
                           ((void *)0)
                               )
  debug_section = build_debug_section (abfd);
       internal_ptr->u.syment._n._n_n._n_offset = (long int)
  (debug_section + internal_ptr->u.syment._n._n_n._n_offset);
     }
 }
      internal_ptr += internal_ptr->u.syment.n_numaux;
    }

  (((abfd)->tdata.coff_obj_data)->raw_syments) = internal;
  { if (!((((abfd)->tdata.coff_obj_data)->raw_syment_count) == (unsigned int) (internal_ptr - internal))) bfd_assert("coffgen.c",1766); }
                                                   ;

  return (internal);
}

long
coff_get_reloc_upper_bound(bfd *abfd, sec_ptr asect) asm("_coff_get_reloc_upper_bound");
long
coff_get_reloc_upper_bound(bfd *abfd, sec_ptr asect)
{
  if (((abfd)->format) != bfd_object)
    {
      bfd_set_error (bfd_error_invalid_operation);
      return -1;
    }
  return (asect->reloc_count + 1) * sizeof (arelent *);
}

asymbol *
coff_make_empty_symbol(bfd *abfd) asm("_coff_make_empty_symbol");
asymbol *
coff_make_empty_symbol(bfd *abfd)
{
  coff_symbol_type *cxx_new = (coff_symbol_type *) bfd_alloc (abfd, sizeof (coff_symbol_type));
  if (cxx_new == 
            ((void *)0)
                )
    {
      bfd_set_error (bfd_error_no_memory);
      return (
             ((void *)0)
                 );
    }
  memset (cxx_new, 0, sizeof *cxx_new);
  cxx_new->symbol.section = 0;
  cxx_new->native = 0;
  cxx_new->lineno = (alent *) 
                         ((void *)0)
                             ;
  cxx_new->done_lineno = cxx_false;
  cxx_new->symbol.the_bfd = abfd;
  return &cxx_new->symbol;
}



asymbol *
coff_bfd_make_debug_symbol(bfd *abfd, void *ptr, long unsigned int sz) asm("_coff_bfd_make_debug_symbol");
asymbol *
coff_bfd_make_debug_symbol(bfd *abfd, void *ptr, long unsigned int sz)
{
  coff_symbol_type *cxx_new = (coff_symbol_type *) bfd_alloc (abfd, sizeof (coff_symbol_type));
  if (cxx_new == 
            ((void *)0)
                )
    {
      bfd_set_error (bfd_error_no_memory);
      return (
             ((void *)0)
                 );
    }

  cxx_new->native = (combined_entry_type *) bfd_zalloc (abfd, sizeof (combined_entry_type) * 10);
  if (!cxx_new->native)
    {
      bfd_set_error (bfd_error_no_memory);
      return (
             ((void *)0)
                 );
    }
  cxx_new->symbol.section = ((asection *) &bfd_abs_section);
  cxx_new->symbol.flags = 0x08;
  cxx_new->lineno = (alent *) 
                         ((void *)0)
                             ;
  cxx_new->done_lineno = cxx_false;
  cxx_new->symbol.the_bfd = abfd;
  return &cxx_new->symbol;
}


void
coff_get_symbol_info(bfd *abfd, asymbol *symbol, symbol_info *ret) asm("_coff_get_symbol_info");
void
coff_get_symbol_info(bfd *abfd, asymbol *symbol, symbol_info *ret)
{
  bfd_symbol_info (symbol, ret);
  if (((coff_symbol_type *)(&((symbol)->the_bfd)))->native != 
                                    ((void *)0)
      
     && ((coff_symbol_type *)(&((symbol)->the_bfd)))->native->fix_value)
    {
      combined_entry_type *psym;

      psym = ((combined_entry_type *)
       ((coff_symbol_type *)(&((symbol)->the_bfd)))->native->u.syment.n_value);
      ret->value = (bfd_vma) (psym - (((abfd)->tdata.coff_obj_data)->raw_syments));
    }
}



void
coff_print_symbol(bfd *abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how) asm("_coff_print_symbol");
void
coff_print_symbol(bfd *abfd, void *filep, asymbol *symbol, bfd_print_symbol_type how)
{
  FILE *file = (FILE *) filep;

  switch (how)
    {
    case bfd_print_symbol_name:
      fprintf (file, "%s", symbol->name);
      break;

    case bfd_print_symbol_more:
      fprintf (file, "coff %s %s",
        ((coff_symbol_type *)(&((symbol)->the_bfd)))->native ? "n" : "g",
        ((coff_symbol_type *)(&((symbol)->the_bfd)))->lineno ? "l" : " ");
      break;

    case bfd_print_symbol_all:
      if (((coff_symbol_type *)(&((symbol)->the_bfd)))->native)
 {
   unsigned long val;
   unsigned int aux;
   combined_entry_type *combined = ((coff_symbol_type *)(&((symbol)->the_bfd)))->native;
   combined_entry_type *root = (((abfd)->tdata.coff_obj_data)->raw_syments);
   struct n64_tag_lineno_cache_entry *l = ((coff_symbol_type *)(&((symbol)->the_bfd)))->lineno;

   fprintf (file, "[%3ld]", (long) (combined - root));

   if (! combined->fix_value)
     val = (unsigned long) combined->u.syment.n_value;
   else
     val = ((unsigned long)
     ((combined_entry_type *) combined->u.syment.n_value
      - root));

   fprintf (file,
     "(sec %2d)(fl 0x%02x)(ty %3x)(scl %3d) (nx %d) 0x%08lx %s",
     combined->u.syment.n_scnum,
     combined->u.syment.n_flags,
     combined->u.syment.n_type,
     combined->u.syment.n_sclass,
     combined->u.syment.n_numaux,
     val,
     symbol->name);

   for (aux = 0; aux < combined->u.syment.n_numaux; aux++)
     {
       combined_entry_type *auxp = combined + aux + 1;
       long tagndx;

       if (auxp->fix_tag)
  tagndx = auxp->u.auxent.x_sym.x_tagndx.p - root;
       else
  tagndx = auxp->u.auxent.x_sym.x_tagndx.l;

       fprintf (file, "\n");

       if (((((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_coff_print_aux) (abfd, file, root, combined, auxp, aux)))
  continue;

       switch (combined->u.syment.n_sclass)
  {
  case 103:
    fprintf (file, "File ");
    break;

  case 3:
    if (combined->u.syment.n_type == 0)

      {
        fprintf (file, "AUX scnlen 0x%lx nreloc %d nlnno %d",
          (long) auxp->u.auxent.x_scn.x_scnlen,
          auxp->u.auxent.x_scn.x_nreloc,
          auxp->u.auxent.x_scn.x_nlinno);
        break;
      }


  default:
    fprintf (file, "AUX lnno %d size 0x%x tagndx %ld",
      auxp->u.auxent.x_sym.x_misc.x_lnsz.x_lnno,
      auxp->u.auxent.x_sym.x_misc.x_lnsz.x_size,
      tagndx);
    if (auxp->fix_end)
      fprintf (file, " endndx %ld",
        ((long)
         (auxp->u.auxent.x_sym.x_fcnary.x_fcn.x_endndx.p
          - root)));
    break;
  }
     }

   if (l)
     {
       fprintf (file, "\n%s :", l->u.sym->name);
       l++;
       while (l->line_number)
  {
    fprintf (file, "\n%4d : 0x%lx",
      l->line_number,
      ((unsigned long)
       (l->u.offset + symbol->section->vma)));
    l++;
  }
     }
 }
      else
 {
   bfd_print_symbol_vandf ((void *) file, symbol);
   fprintf (file, " %-5s %s %s %s",
     symbol->section->name,
     ((coff_symbol_type *)(&((symbol)->the_bfd)))->native ? "n" : "g",
     ((coff_symbol_type *)(&((symbol)->the_bfd)))->lineno ? "l" : " ",
     symbol->name);
 }
    }
}






boolean
coff_find_nearest_line(bfd *abfd, asection *section, asymbol **ignore_symbols, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr) asm("_coff_find_nearest_line");
boolean
coff_find_nearest_line(bfd *abfd, asection *section, asymbol **ignore_symbols, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr)
{
  unsigned int i;
  unsigned int line_base;
  coff_data_type *cof = ((abfd)->tdata.coff_obj_data);

  combined_entry_type *p;
  combined_entry_type *pend;
  alent *l;
  struct n64_tag_coff_section_tdata *sec_data;

  *filename_ptr = 0;
  *functionname_ptr = 0;
  *line_ptr = 0;


  if (abfd->xvec->flavour != bfd_target_coff_flavour)
    return cxx_false;

  if (cof == 
            ((void *)0)
                )
    return cxx_false;


  p = cof->raw_syments;
  pend = p + cof->raw_syment_count;
  while (p < pend)
    {
      if (p->u.syment.n_sclass == 103)
 break;
      p += 1 + p->u.syment.n_numaux;
    }

  if (p < pend)
    {
      bfd_vma maxdiff;


      *filename_ptr = (char *) p->u.syment._n._n_n._n_offset;
      maxdiff = (bfd_vma) 0 - (bfd_vma) 1;
      while (1)
 {
   combined_entry_type *p2;

   for (p2 = p + 1 + p->u.syment.n_numaux;
        p2 < pend;
        p2 += 1 + p2->u.syment.n_numaux)
     {
       if (p2->u.syment.n_scnum > 0
    && (section
        == coff_section_from_bfd_index (abfd,
            p2->u.syment.n_scnum)))
  break;
       if (p2->u.syment.n_sclass == 103)
  {
    p2 = pend;
    break;
  }
     }

   if (p2 < pend
       && offset >= (bfd_vma) p2->u.syment.n_value
       && offset - (bfd_vma) p2->u.syment.n_value < maxdiff)
     {
       *filename_ptr = (char *) p->u.syment._n._n_n._n_offset;
       maxdiff = offset - p2->u.syment.n_value;
     }



   if (p - cof->raw_syments >= p->u.syment.n_value)
     break;

   p = cof->raw_syments + p->u.syment.n_value;
   if (p > pend || p->u.syment.n_sclass != 103)
     break;
 }
    }




  sec_data = ((struct n64_tag_coff_section_tdata *) (section)->used_by_bfd);
  if (sec_data != 
                 ((void *)0)
      
     && sec_data->i > 0
      && offset >= sec_data->offset)
    {
      i = sec_data->i;
      *functionname_ptr = sec_data->function;
      line_base = sec_data->line_base;
    }
  else
    {
      i = 0;
      line_base = 0;
    }

  l = &section->lineno[i];

  for (; i < section->lineno_count; i++)
    {
      if (l->line_number == 0)
 {

   coff_symbol_type *coff = (coff_symbol_type *) (l->u.sym);
   if (coff->symbol.value > offset)
     break;
   *functionname_ptr = coff->symbol.name;
   if (coff->native)
     {
       combined_entry_type *s = coff->native;
       s = s + 1 + s->u.syment.n_numaux;



       if (s->u.syment.n_scnum == ((short)-2))
  s = s + 1 + s->u.syment.n_numaux;




       if (s->u.syment.n_numaux)
  {



    union n64_tag_internal_auxent *a = &((s + 1)->u.auxent);
    line_base = a->x_sym.x_misc.x_lnsz.x_lnno;
    *line_ptr = line_base;
  }
     }
 }
      else
 {
   if (l->u.offset + ((section)->vma + 0) > offset)
     break;
   *line_ptr = l->line_number + line_base - 1;
 }
      l++;
    }


  if (sec_data == 
                 ((void *)0)
                     )
    {
      section->used_by_bfd =
 ((void *) bfd_zalloc (abfd,
      sizeof (struct n64_tag_coff_section_tdata)));
      sec_data = (struct n64_tag_coff_section_tdata *) section->used_by_bfd;
    }
  if (sec_data != 
                 ((void *)0)
                     )
    {
      sec_data->offset = offset;
      sec_data->i = i;
      sec_data->function = *functionname_ptr;
      sec_data->line_base = line_base;
    }

  return cxx_true;
}

int
coff_sizeof_headers(bfd *abfd, boolean reloc) asm("_coff_sizeof_headers");
int
coff_sizeof_headers(bfd *abfd, boolean reloc)
{
  size_t size;

  if (reloc == cxx_false)
    {
      size = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_filhsz) + (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_aoutsz);
    }
  else
    {
      size = (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_filhsz);
    }

  size += abfd->section_count * (((bfd_coff_backend_data *) (abfd)->xvec->backend_data)->_bfd_scnhsz);
  return size;
}

