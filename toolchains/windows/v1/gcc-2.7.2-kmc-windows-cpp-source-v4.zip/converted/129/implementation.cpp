// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/libiberty/fdmatch.c
/* Compare two open file descriptors to see if they refer to the same file.
   Copyright (C) 1991 Free Software Foundation, Inc.

This file is part of the libiberty library.
Libiberty is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

Libiberty is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with libiberty; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");


int fdmatch(int fd1, int fd2) asm("_fdmatch");
int fdmatch(int fd1, int fd2)
{
  struct stat sbuf1;
  struct stat sbuf2;

  if ((fstat (fd1, &sbuf1) == 0) &&
      (fstat (fd2, &sbuf2) == 0) &&
      (sbuf1.st_dev == sbuf2.st_dev) &&
      (sbuf1.st_ino == sbuf2.st_ino))
    {
      return (1);
    }
  else
    {
      return (0);
    }
}

