// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_qelem;
struct n64_tag_qelem {
  struct n64_tag_qelem *q_forw;
  struct n64_tag_qelem *q_back;
};


void
insque(struct n64_tag_qelem *elem, struct n64_tag_qelem *pred) asm("_insque");
void
insque(struct n64_tag_qelem *elem, struct n64_tag_qelem *pred)
{
  elem -> q_forw = pred -> q_forw;
  pred -> q_forw -> q_back = elem;
  elem -> q_back = pred;
  pred -> q_forw = elem;
}


void
remque(struct n64_tag_qelem *elem) asm("_remque");
void
remque(struct n64_tag_qelem *elem)
{
  elem -> q_forw -> q_back = elem -> q_back;
  elem -> q_back -> q_forw = elem -> q_forw;
}

