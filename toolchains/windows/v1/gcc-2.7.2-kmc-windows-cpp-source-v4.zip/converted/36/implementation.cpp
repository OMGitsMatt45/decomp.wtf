// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/jump.c
/* Optimize jump instructions, for GNU compiler.
   Copyright (C) 1987, 88, 89, 91-94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int remove_note(...) asm("_remove_note");
extern int simplejump_p(...) asm("_simplejump_p");
extern int true_regnum(...) asm("_true_regnum");
extern int remove_death(...) asm("_remove_death");
extern int side_effects_p(...) asm("_side_effects_p");
extern int condjump_p(...) asm("_condjump_p");
extern int condjump_in_parallel_p(...) asm("_condjump_in_parallel_p");
extern int redirect_jump(...) asm("_redirect_jump");
extern int no_labels_between_p(...) asm("_no_labels_between_p");
extern int reg_referenced_between_p(...) asm("_reg_referenced_between_p");
extern int reg_set_between_p(...) asm("_reg_set_between_p");
extern int emit_insn_after_with_line_notes(...) asm("_emit_insn_after_with_line_notes");
extern int may_trap_p(...) asm("_may_trap_p");
extern int rtx_cost(...) asm("_rtx_cost");
extern int validate_change(...) asm("_validate_change");
extern int can_reverse_comparison_p(...) asm("_can_reverse_comparison_p");
extern int preserve_subexpressions_p(...) asm("_preserve_subexpressions_p");
extern int invert_jump(...) asm("_invert_jump");
extern int max_reg_num(...) asm("_max_reg_num");
extern int replace_regs(...) asm("_replace_regs");
extern int rtx_renumbered_equal_p(...) asm("_rtx_renumbered_equal_p");
extern int cancel_changes(...) asm("_cancel_changes");
extern int apply_change_group(...) asm("_apply_change_group");
extern int reg_set_p(...) asm("_reg_set_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int set_last_insn(...) asm("_set_last_insn");
extern int invert_exp(...) asm("_invert_exp");
extern int redirect_exp(...) asm("_redirect_exp");
extern int note_stores(...) asm("_note_stores");
extern int rtx_equal_for_thread_p(...) asm("_rtx_equal_for_thread_p");
extern int recog_memoized(...) asm("_recog_memoized");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
static rtx *jump_chain;



rtx forced_labels;



static int max_jump_chain;



int can_reach_end;







static int cross_jump_death_matters = 0;

static int duplicate_loop_exit_test (rtx) asm("_duplicate_loop_exit_test");
static void find_cross_jump (rtx, rtx, int, rtx *, rtx *) asm("_find_cross_jump");
static void do_cross_jump (rtx, rtx, rtx) asm("_do_cross_jump");
static int jump_back_p (rtx, rtx) asm("_jump_back_p");
static int tension_vector_labels (rtx, int) asm("_tension_vector_labels");
static void mark_jump_label (rtx, rtx, int) asm("_mark_jump_label");
static void delete_computation (rtx) asm("_delete_computation");
static void delete_from_jump_chain (rtx) asm("_delete_from_jump_chain");
static int delete_labelref_insn (rtx, rtx, int) asm("_delete_labelref_insn");
static void redirect_tablejump (rtx, rtx) asm("_redirect_tablejump");
void
jump_optimize(rtx f, int cross_jump, int noop_moves, int after_regscan) asm("_jump_optimize");
void
jump_optimize(rtx f, int cross_jump, int noop_moves, int after_regscan)
{
  register rtx insn, next, note;
  int changed;
  int first = 1;
  int max_uid = 0;
  rtx last_insn;

  cross_jump_death_matters = (cross_jump == 2);




  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == CODE_LABEL)
 ((insn)->fld[5].rtint) = (((insn)->in_struct) != 0);
      else if (((insn)->code) == JUMP_INSN)
 ((insn)->fld[7].rtx) = 0;
      else if (((insn)->code) == INSN || ((insn)->code) == CALL_INSN)
 for (note = ((insn)->fld[6].rtx); note; note = next)
   {
     next = ((note)->fld[1].rtx);
     if (((n64_enum_reg_note) ((note)->mode)) == REG_LABEL
  && ! reg_mentioned_p (((note)->fld[0].rtx), ((insn)->fld[3].rtx)))
       remove_note (insn, note);
   }

      if (((insn)->fld[0].rtint) > max_uid)
 max_uid = ((insn)->fld[0].rtint);
    }

  max_uid++;



  for (insn = f; insn;)
    {
      if (((insn)->code) == BARRIER)
 {
   insn = ((insn)->fld[2].rtx);
   while (insn != 0 && ((insn)->code) != CODE_LABEL)
     {
       if (((insn)->code) == NOTE
    && ((insn)->fld[4].rtint) != -6)
  insn = ((insn)->fld[2].rtx);
       else
  insn = delete_insn (insn);
     }

 }
      else
 insn = ((insn)->fld[2].rtx);
    }



  max_jump_chain = max_uid * 14 / 10;
  jump_chain = (rtx *) 
                      __builtin_alloca((
                      max_jump_chain * sizeof (rtx)
                      ))
                                                            ;
  memset ((char *) jump_chain,0,max_jump_chain * sizeof (rtx));
  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && ! ((insn)->volatil))
      {
 mark_jump_label (((insn)->fld[3].rtx), insn, cross_jump);
 if (((insn)->code) == JUMP_INSN)
   {
     if (((insn)->fld[7].rtx) != 0 && simplejump_p (insn))
       {
  jump_chain[((insn)->fld[0].rtint)]
    = jump_chain[((((insn)->fld[7].rtx))->fld[0].rtint)];
  jump_chain[((((insn)->fld[7].rtx))->fld[0].rtint)] = insn;
       }
     if (((((insn)->fld[3].rtx))->code) == RETURN)
       {
  jump_chain[((insn)->fld[0].rtint)] = jump_chain[0];
  jump_chain[0] = insn;
       }
   }
      }




  for (insn = forced_labels; insn; insn = ((insn)->fld[1].rtx))
    ((((insn)->fld[0].rtx))->fld[5].rtint)++;




  last_insn = 0;
  for (insn = f; insn; )
    {
      if (((insn)->code) == CODE_LABEL && ((insn)->fld[5].rtint) == 0)
 insn = delete_insn (insn);
      else
 {
   last_insn = insn;
   insn = ((insn)->fld[2].rtx);
 }
    }

  if (!optimize)
    {



      insn = last_insn;
      {
 int n_labels = 1;
 while (insn

        && ((((insn)->code) == CODE_LABEL && n_labels-- > 0)

     || ((insn)->code) == INSN


     || (((insn)->code) == JUMP_INSN
         && ((((insn)->fld[3].rtx))->code) == RETURN)

     || ((insn)->code) == BARRIER

     || (((insn)->code) == NOTE
         && ((insn)->fld[4].rtint) != -6)))
   insn = ((insn)->fld[1].rtx);
      }


      if (insn && ((insn)->code) == NOTE
   && ((insn)->fld[4].rtint) == -6
   && ! ((insn)->volatil))
 can_reach_end = 1;


      for (insn = f; insn; insn = ((insn)->fld[2].rtx))
 ((insn)->volatil) = 0;
      return;
    }


  if ((simple_epilogue_p ()))
    {




      insn = get_last_insn ();
      while (insn && ((insn)->code) == NOTE)
 insn = ((insn)->fld[1].rtx);

      if (insn && ((insn)->code) != BARRIER)
 {
   emit_jump_insn (gen_return ());
   emit_barrier ();
 }
    }


  if (noop_moves)
    for (insn = f; insn; )
      {
 next = ((insn)->fld[2].rtx);

 if (((insn)->code) == INSN)
   {
     register rtx body = ((insn)->fld[3].rtx);
     if (((body)->code) == SET
  && (((body)->fld[0].rtx) == ((body)->fld[1].rtx)
      || (((((body)->fld[0].rtx))->code) == MEM
   && ((((body)->fld[1].rtx))->code) == MEM
   && rtx_equal_p (((body)->fld[1].rtx), ((body)->fld[0].rtx))))
  && ! (((((body)->fld[0].rtx))->code) == MEM
        && ((((body)->fld[0].rtx))->volatil))
  && ! (((((body)->fld[1].rtx))->code) == MEM
        && ((((body)->fld[1].rtx))->volatil)))
       delete_computation (insn);




     else if (((body)->code) == SET)
       {
  int sreg = true_regnum (((body)->fld[1].rtx));
  int dreg = true_regnum (((body)->fld[0].rtx));

  if (sreg == dreg && sreg >= 0)
    delete_insn (insn);
  else if (sreg >= 0 && dreg >= 0)
    {
      rtx trial;
      rtx tem = find_equiv_reg ((rtx) 0, insn, 0,
           sreg, ((void *)0), dreg,
           ((((body)->fld[1].rtx))->mode));







        {




   for (trial = prev_nonnote_insn (insn);
        trial && ((trial)->code) != CODE_LABEL;
        trial = prev_nonnote_insn (trial))
     if (find_regno_note (trial, REG_DEAD, dreg))
       {
         remove_death (dreg, trial);
         break;
       }

   if (tem != 0
       && ((tem)->mode) == ((((body)->fld[0].rtx))->mode))
     delete_insn (insn);
        }
    }
  else if (dreg >= 0 && (((((body)->fld[1].rtx))->code) == LABEL_REF || ((((body)->fld[1].rtx))->code) == SYMBOL_REF || ((((body)->fld[1].rtx))->code) == CONST_INT || ((((body)->fld[1].rtx))->code) == CONST_DOUBLE || ((((body)->fld[1].rtx))->code) == CONST || ((((body)->fld[1].rtx))->code) == HIGH)
    && find_equiv_reg (((body)->fld[1].rtx), insn, 0, dreg,
         ((void *)0), 0,
         ((((body)->fld[0].rtx))->mode)))
    {
      rtx in_insn = insn;



      while (in_insn && ((in_insn)->code) != CODE_LABEL)
        {
   if ((((in_insn)->code) == INSN
        || ((in_insn)->code) == JUMP_INSN)
       && find_regno_note (in_insn, REG_DEAD, dreg))
     {
       remove_death (dreg, in_insn);
       break;
     }
   in_insn = ((in_insn)->fld[1].rtx);
        }


      delete_insn (insn);
    }
       }
     else if (((body)->code) == PARALLEL)
       {


  int i, sreg, dreg;
  rtx tem;

  for (i = ((body)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
    {
      tem = ((body)->fld[0].rtvec->elem[i].rtx);
      if (((tem)->code) == USE || ((tem)->code) == CLOBBER)
        continue;

      if (((tem)->code) != SET
       || (sreg = true_regnum (((tem)->fld[1].rtx))) < 0
       || (dreg = true_regnum (((tem)->fld[0].rtx))) < 0
       || dreg != sreg)
        break;
    }

  if (i < 0)
    delete_insn (insn);
       }


     else if (! ((target_flags & 0x00010000) != 0)
       && ((body)->code) == SET
       && ((((body)->fld[0].rtx))->code) == ZERO_EXTRACT
       && ((((body)->fld[0].rtx))->fld[2].rtx) == const0_rtx
       && ((((body)->fld[0].rtx))->fld[0].rtx) == ((body)->fld[1].rtx)
       && ! (((((body)->fld[1].rtx))->code) == MEM
      && ((((body)->fld[1].rtx))->volatil)))
       delete_insn (insn);
   }
      insn = next;
    }






  if (! reload_completed && after_regscan)
    for (insn = f; insn; insn = next)
      {
 rtx set = single_set (insn);

 next = ((insn)->fld[2].rtx);

 if (set && ((((set)->fld[0].rtx))->code) == REG
     && ((((set)->fld[0].rtx))->fld[0].rtint) >= 68
     && regno_first_uid[((((set)->fld[0].rtx))->fld[0].rtint)] == ((insn)->fld[0].rtint)



     && regno_last_note_uid[((((set)->fld[0].rtx))->fld[0].rtint)] == ((insn)->fld[0].rtint)
     && ! side_effects_p (((set)->fld[1].rtx))
     && ! find_reg_note (insn, REG_RETVAL, 0))
   delete_insn (insn);
      }


  changed = 1;
  while (changed)
    {
      changed = 0;

      for (insn = f; insn; insn = next)
 {
   rtx reallabelprev;
   rtx temp, temp1, temp2, temp3, temp4, temp5, temp6;
   rtx nlabel;
   int this_is_simplejump, this_is_condjump, reversep;
   int this_is_condjump_in_parallel;
   next = ((insn)->fld[2].rtx);





   if (after_regscan && ((insn)->code) == NOTE
       && ((insn)->fld[4].rtint) == -4
       && (temp1 = next_nonnote_insn (insn)) != 0
       && simplejump_p (temp1))
     {
       temp = ((insn)->fld[1].rtx);
       if (duplicate_loop_exit_test (insn))
  {
    changed = 1;
    next = ((temp)->fld[2].rtx);
    continue;
  }
     }

   if (((insn)->code) != JUMP_INSN)
     continue;

   this_is_simplejump = simplejump_p (insn);
   this_is_condjump = condjump_p (insn);
   this_is_condjump_in_parallel = condjump_in_parallel_p (insn);



   if (((((insn)->fld[3].rtx))->code) == ADDR_VEC)
     changed |= tension_vector_labels (((insn)->fld[3].rtx), 0);
   if (((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC)
     changed |= tension_vector_labels (((insn)->fld[3].rtx), 1);




   if (((((insn)->fld[3].rtx))->code) == ADDR_VEC
       || ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC)
     {
       int i;
       rtx pat = ((insn)->fld[3].rtx);
       int diff_vec_p = ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC;
       int len = ((pat)->fld[diff_vec_p].rtvec->num_elem);
       rtx dispatch = prev_real_insn (insn);

       for (i = 0; i < len; i++)
  if (((((pat)->fld[diff_vec_p].rtvec->elem[i].rtx))->fld[0].rtx)
      != ((((pat)->fld[diff_vec_p].rtvec->elem[0].rtx))->fld[0].rtx))
    break;
       if (i == len
    && dispatch != 0
    && ((dispatch)->code) == JUMP_INSN
    && ((dispatch)->fld[7].rtx) != 0

    && !(((((dispatch)->fld[3].rtx))->code) == SET
         && (((((((dispatch)->fld[3].rtx))->fld[1].rtx))->code)
      == IF_THEN_ELSE))
    && next_real_insn (((dispatch)->fld[7].rtx)) == insn)
  {
    redirect_tablejump (dispatch,
          ((((pat)->fld[diff_vec_p].rtvec->elem[0].rtx))->fld[0].rtx));
    changed = 1;
  }
     }

   reallabelprev = prev_active_insn (((insn)->fld[7].rtx));



   if (((insn)->fld[7].rtx)
       && (next_active_insn (((insn)->fld[7].rtx)) == 0
    || ((((next_active_insn (((insn)->fld[7].rtx)))->fld[3].rtx))->code)
        == RETURN))
     changed |= redirect_jump (insn, (rtx) 0);


   if (reallabelprev == insn && condjump_p (insn))
     {
       next = next_real_insn (((insn)->fld[7].rtx));
       delete_jump (insn);
       changed = 1;
       continue;
     }
   if (this_is_simplejump
       && (temp = prev_nonnote_insn (insn)) != 0
       && ((temp)->code) == INSN && ((((temp)->fld[3].rtx))->code) == USE
       && (temp1 = prev_nonnote_insn (((insn)->fld[7].rtx))) != 0
       && (((temp1)->code) == BARRIER
    || (((temp1)->code) == INSN
        && rtx_equal_p (((temp)->fld[3].rtx), ((temp1)->fld[3].rtx)))))
     {
       if (((temp1)->code) == BARRIER)
  {
    emit_insn_after (((temp)->fld[3].rtx), temp1);
    temp1 = ((temp1)->fld[2].rtx);
  }

       delete_insn (temp);
       redirect_jump (insn, get_label_before (temp1));
       reallabelprev = prev_real_insn (temp1);
       changed = 1;
     }
   if (this_is_simplejump
       && (temp3 = prev_active_insn (insn)) != 0
       && ((temp3)->code) == INSN
       && (temp4 = single_set (temp3)) != 0
       && ((temp1 = ((temp4)->fld[0].rtx))->code) == REG



       && (temp2 = next_active_insn (insn)) != 0
       && ((temp2)->code) == INSN
       && (temp4 = single_set (temp2)) != 0
       && rtx_equal_p (((temp4)->fld[0].rtx), temp1)
       && (((((temp4)->fld[1].rtx))->code) == REG
    || ((((temp4)->fld[1].rtx))->code) == SUBREG
    || (((((temp4)->fld[1].rtx))->code) == LABEL_REF || ((((temp4)->fld[1].rtx))->code) == SYMBOL_REF || ((((temp4)->fld[1].rtx))->code) == CONST_INT || ((((temp4)->fld[1].rtx))->code) == CONST_DOUBLE || ((((temp4)->fld[1].rtx))->code) == CONST || ((((temp4)->fld[1].rtx))->code) == HIGH))
       && (((temp2)->fld[6].rtx) == 0
    || ((((n64_enum_reg_note) ((((temp2)->fld[6].rtx))->mode)) == REG_EQUAL
         || ((n64_enum_reg_note) ((((temp2)->fld[6].rtx))->mode)) == REG_EQUIV)
        && ((((temp2)->fld[6].rtx))->fld[1].rtx) == 0
        && rtx_equal_p (((((temp2)->fld[6].rtx))->fld[0].rtx),
          ((temp4)->fld[1].rtx))))
       && (temp = prev_active_insn (temp3)) != 0
       && condjump_p (temp) && ! simplejump_p (temp)

       && prev_real_insn (((temp)->fld[7].rtx)) == insn
       && no_labels_between_p (insn, ((temp)->fld[7].rtx))

       && no_labels_between_p (((temp)->fld[7].rtx), temp2)


       && (reallabelprev == temp2
    || ((temp5 = next_active_insn (temp2)) != 0
        && simplejump_p (temp5)
        && ((temp5)->fld[7].rtx) == ((insn)->fld[7].rtx))))
     {




       rtx target = ((temp)->fld[7].rtx);
       int nuses = ((target)->fld[5].rtint);
       rtx p, q;


       for (p = temp; nuses && p; p = prev_nonnote_insn (p))
  {
    if (((p)->code) == JUMP_INSN)
      {
        if (condjump_p (p) && ! simplejump_p (p)
     && ((p)->fld[7].rtx) == target)
   {
     nuses--;
     if (nuses == 0)
       break;
   }
        else
   break;
      }
    else if (((p)->code) == CALL_INSN)
      break;
  }
       if (p)
  p = ((p)->fld[1].rtx);




       if (nuses == 0 && p
    && no_labels_between_p (p, insn)
    && ! reg_referenced_between_p (temp1, p, ((temp3)->fld[2].rtx))
    && ! reg_set_between_p (temp1, p, temp3)
    && (((((temp4)->fld[1].rtx))->code) == CONST_INT
        || ! reg_set_between_p (((temp4)->fld[1].rtx), p, temp2)))
  {
    emit_insn_after_with_line_notes (((temp2)->fld[3].rtx), p, temp2);
    delete_insn (temp2);


    next = next_active_insn (insn);






    delete_insn (insn);




    for (p = ((p)->fld[2].rtx); p != next; p = ((p)->fld[2].rtx))
      if (((p)->code) == JUMP_INSN)
        redirect_jump (p, target);

    changed = 1;
    continue;
  }
     }
   if (! reload_completed
       && this_is_condjump && ! this_is_simplejump
       && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 3
       && (temp = next_nonnote_insn (insn)) != 0
       && ((temp)->code) == INSN
       && ((temp)->fld[6].rtx) == 0
       && (reallabelprev == temp
    || ((temp2 = next_active_insn (temp)) != 0
        && simplejump_p (temp2)
        && ((temp2)->fld[7].rtx) == ((insn)->fld[7].rtx)))
       && (temp1 = single_set (temp)) != 0
       && (temp2 = ((temp1)->fld[0].rtx), ((temp2)->code) == REG)
       && (mode_class[(int)(((temp2)->mode))]) == MODE_INT



       && ((((temp1)->fld[1].rtx))->code) != REG
       && ((((temp1)->fld[1].rtx))->code) != SUBREG
       && ((((temp1)->fld[1].rtx))->code) != CONST_INT
       && ! side_effects_p (((temp1)->fld[1].rtx))
       && ! may_trap_p (((temp1)->fld[1].rtx))
       && rtx_cost (((temp1)->fld[1].rtx), SET) < 10)
     {
       rtx cxx_new = gen_reg_rtx (((temp2)->mode));

       if (validate_change (temp, &((temp1)->fld[0].rtx), cxx_new, 0))
  {
    next = emit_insn_after (gen_move_insn (temp2, cxx_new), insn);
    emit_insn_after_with_line_notes (((temp)->fld[3].rtx),
         ((insn)->fld[1].rtx), temp);
    delete_insn (temp);
    reallabelprev = prev_active_insn (((insn)->fld[7].rtx));
  }
     }





   if (! reload_completed
       && this_is_condjump && ! this_is_simplejump
       && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 4
       && (temp = next_nonnote_insn (insn)) != 0
       && ((temp)->code) == INSN
       && ((temp)->fld[6].rtx) == 0
       && (temp3 = next_nonnote_insn (temp)) != 0
       && ((temp3)->code) == INSN
       && ((temp3)->fld[6].rtx) == 0
       && (reallabelprev == temp3
    || ((temp2 = next_active_insn (temp3)) != 0
        && simplejump_p (temp2)
        && ((temp2)->fld[7].rtx) == ((insn)->fld[7].rtx)))
       && (temp1 = single_set (temp)) != 0
       && (temp2 = ((temp1)->fld[0].rtx), ((temp2)->code) == REG)
       && (mode_class[(int)(((temp2)->mode))]) == MODE_INT



       && ! side_effects_p (((temp1)->fld[1].rtx))
       && ! may_trap_p (((temp1)->fld[1].rtx))
       && rtx_cost (((temp1)->fld[1].rtx), SET) < 10
       && (temp4 = single_set (temp3)) != 0
       && rtx_equal_p (((temp4)->fld[0].rtx), temp2)
       && ! side_effects_p (((temp4)->fld[1].rtx))
       && ! may_trap_p (((temp4)->fld[1].rtx))
       && rtx_cost (((temp4)->fld[1].rtx), SET) < 10)
     {
       rtx cxx_new = gen_reg_rtx (((temp2)->mode));

       if (validate_change (temp, &((temp1)->fld[0].rtx), cxx_new, 0))
  {
    next = emit_insn_after (gen_move_insn (temp2, cxx_new), insn);
    emit_insn_after_with_line_notes (((temp)->fld[3].rtx),
         ((insn)->fld[1].rtx), temp);
    emit_insn_after_with_line_notes
      (replace_rtx (((temp3)->fld[3].rtx), temp2, cxx_new),
       ((insn)->fld[1].rtx), temp3);
    delete_insn (temp);
    delete_insn (temp3);
    reallabelprev = prev_active_insn (((insn)->fld[7].rtx));
  }
     }





   if (! reload_completed
       && after_regscan
       && this_is_condjump && ! this_is_simplejump
       && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 4
       && (temp = next_nonnote_insn (insn)) != 0
       && ((temp)->code) == INSN
       && ((temp)->fld[6].rtx) == 0
       && (temp3 = next_nonnote_insn (temp)) != 0
       && ((temp3)->code) == INSN
       && ((temp3)->fld[6].rtx) == 0
       && (reallabelprev == temp3
    || ((temp2 = next_active_insn (temp3)) != 0
        && simplejump_p (temp2)
        && ((temp2)->fld[7].rtx) == ((insn)->fld[7].rtx)))
       && (temp1 = single_set (temp)) != 0
       && (temp5 = ((temp1)->fld[0].rtx),
    (((temp5)->code) == REG
     || (((temp5)->code) == SUBREG
         && (temp5 = ((temp5)->fld[0].rtx),
      ((temp5)->code) == REG))))
       && ((temp5)->fld[0].rtint) >= 68
       && regno_first_uid[((temp5)->fld[0].rtint)] == ((temp)->fld[0].rtint)
       && regno_last_uid[((temp5)->fld[0].rtint)] == ((temp3)->fld[0].rtint)
       && ! side_effects_p (((temp1)->fld[1].rtx))
       && ! may_trap_p (((temp1)->fld[1].rtx))
       && rtx_cost (((temp1)->fld[1].rtx), SET) < 10
       && (temp4 = single_set (temp3)) != 0
       && (temp2 = ((temp4)->fld[0].rtx), ((temp2)->code) == REG)
       && (mode_class[(int)(((temp2)->mode))]) == MODE_INT



       && rtx_equal_p (((temp4)->fld[0].rtx), temp2)
       && ! side_effects_p (((temp4)->fld[1].rtx))
       && ! may_trap_p (((temp4)->fld[1].rtx))
       && rtx_cost (((temp4)->fld[1].rtx), SET) < 10)
     {
       rtx cxx_new = gen_reg_rtx (((temp2)->mode));

       if (validate_change (temp3, &((temp4)->fld[0].rtx), cxx_new, 0))
  {
    next = emit_insn_after (gen_move_insn (temp2, cxx_new), insn);
    emit_insn_after_with_line_notes (((temp)->fld[3].rtx),
         ((insn)->fld[1].rtx), temp);
    emit_insn_after_with_line_notes (((temp3)->fld[3].rtx),
         ((insn)->fld[1].rtx), temp3);
    delete_insn (temp);
    delete_insn (temp3);
    reallabelprev = prev_active_insn (((insn)->fld[7].rtx));
  }
     }
   if (
       ! reload_completed
       && this_is_condjump && ! this_is_simplejump

       && (temp = next_nonnote_insn (insn)) != 0
       && ((temp)->code) == INSN
       && ((((temp)->fld[3].rtx))->code) == SET
       && ((temp1 = ((((temp)->fld[3].rtx))->fld[0].rtx))->code) == REG



       && (((temp2 = ((((temp)->fld[3].rtx))->fld[1].rtx))->code) == REG
    || ((temp2)->code) == SUBREG

    || ((temp2)->code) == CONST_INT)





       && (((temp3 = reg_set_last (temp1, insn)) != 0)

    || (temp3 = temp1, 1))


       && (reallabelprev == temp
    || ((temp4 = next_active_insn (temp)) != 0
        && simplejump_p (temp4)
        && ((temp4)->fld[7].rtx) == ((insn)->fld[7].rtx)))
       && (temp4 = get_condition (insn, &temp5)) != 0



       && ((((temp4)->fld[0].rtx))->mode) != BLKmode


       && (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2

    || 1

    )
       )
     {


       {
  n64_enum_rtx_code code = ((temp4)->code);
  rtx var = temp1;
  rtx cond0, cond1, aval, bval;
  rtx target;
  cond0 = gen_reg_rtx (((((temp4)->fld[0].rtx))->mode));



  if (((((temp4)->fld[1].rtx))->code) == CONST_INT
      || ((((temp4)->fld[1].rtx))->code) == CONST_DOUBLE)
    cond1 = ((temp4)->fld[1].rtx);
  else
    cond1 = gen_reg_rtx (((((temp4)->fld[1].rtx))->mode));

  aval = temp3;
  bval = temp2;

  start_sequence ();
  target = emit_conditional_move (var, code,
      cond0, cond1, VOIDmode,
      aval, bval, ((var)->mode),
      (code == LTU || code == GEU
       || code == LEU || code == GTU));

  if (target)
    {
      rtx seq1,seq2;






      seq2 = get_insns ();
      end_sequence ();



      start_sequence ();
      emit_move_insn (cond0, ((temp4)->fld[0].rtx));
      if (cond1 != ((temp4)->fld[1].rtx))
        emit_move_insn (cond1, ((temp4)->fld[1].rtx));
      seq1 = get_insns ();
      end_sequence ();

      emit_insns_before (seq1, temp5);
      emit_insns_before (seq2, insn);



      delete_insn (temp);
      next = ((insn)->fld[2].rtx);
      delete_jump (insn);
      changed = 1;
      continue;
    }
  else
    end_sequence ();
       }
       if ((mode_class[(int)(((temp1)->mode))]) == MODE_INT
    && ((((temp3)->code) == CONST_INT)


        || (temp3 = temp1,
     ((((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2
       && temp2 == const0_rtx)
      || ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 3)))




    && ((reversep = 0, temp2 == const0_rtx)
        || (temp3 == const0_rtx
     && (reversep = can_reverse_comparison_p (temp4, insn)))
        || (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2
     && ((temp2)->code) == CONST_INT
     && ((temp3)->code) == CONST_INT
     && ((((temp2)->fld[0].rtwint) & ((temp3)->fld[0].rtwint)) == ((temp2)->fld[0].rtwint)
         || ((((temp2)->fld[0].rtwint) & ((temp3)->fld[0].rtwint)) == ((temp3)->fld[0].rtwint)
      && (reversep = can_reverse_comparison_p (temp4,
            insn)))))
        || ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 3)
    )
  {
    n64_enum_rtx_code code = ((temp4)->code);
    rtx uval, cval, var = temp1;
    int normalizep;
    rtx target;


    if (reversep)
      code = reverse_condition (code), uval = temp2, cval = temp3;
    else
      uval = temp3, cval = temp2;







    normalizep = (cval != const0_rtx ? -1
    : (uval == const1_rtx ? 1
       : (((uval)->code) == CONST_INT
          && (((uval)->fld[0].rtwint) & ~1) == 0)
       ? 0 : -1));
    start_sequence ();
    target = emit_store_flag (gen_reg_rtx (((var)->mode)), code,
         ((temp4)->fld[0].rtx), ((temp4)->fld[1].rtx),
         VOIDmode,
         (code == LTU || code == LEU
          || code == GEU || code == GTU),
         normalizep);
    if (target)
      {
        rtx seq;
        rtx before = insn;

        seq = get_insns ();
        end_sequence ();
        emit_insns_before (seq, temp5);

        start_sequence ();


        if (cval != const0_rtx && uval != const0_rtx)
   {
     rtx tem1, tem2;

     tem1 = expand_and (uval, target, (rtx) 0);
     if (((cval)->code) == CONST_INT
         && ((uval)->code) == CONST_INT
         && (((cval)->fld[0].rtwint) & ((uval)->fld[0].rtwint)) == ((cval)->fld[0].rtwint))
       tem2 = cval;
     else
       {
         tem2 = expand_unop (((var)->mode), one_cmpl_optab,
        target, (rtx) 0, 0);
         tem2 = expand_and (cval, tem2,
       (((tem2)->code) == REG
        ? tem2 : 0));
       }







     if (flag_expensive_optimizations)
       target = 0;

     target = expand_binop (((var)->mode), ior_optab,
       tem1, tem2, target,
       1, OPTAB_WIDEN);
   }
        else if (normalizep != 1)
   {



     if (uval == const0_rtx)
       {
         target = expand_unop (((var)->mode), one_cmpl_optab,
          target, (rtx) 0, 0);
         uval = cval;
       }

     target = expand_and (uval, target,
            (((target)->code) == REG
      && ! preserve_subexpressions_p ()
      ? target : (rtx) 0));
   }

        emit_move_insn (var, target);
        seq = get_insns ();
        end_sequence ();






        emit_insns_before (seq, before);

        delete_insn (temp);
        next = ((insn)->fld[2].rtx);
        delete_jump (insn);
        changed = 1;
        continue;
      }
    else
      end_sequence ();
  }
     }
   if ((((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) >= 2






       )
       && ! reload_completed
       && this_is_condjump && ! this_is_simplejump
       && (temp = next_nonnote_insn (insn)) != 0
       && (temp1 = single_set (temp)) != 0
       && (temp2 = ((temp1)->fld[0].rtx),
    (mode_class[(int)(((temp2)->mode))]) == MODE_INT)
       && ((((temp1)->fld[1].rtx))->code) == PLUS
       && (((((temp1)->fld[1].rtx))->fld[1].rtx) == const1_rtx
    || ((((temp1)->fld[1].rtx))->fld[1].rtx) == constm1_rtx)
       && rtx_equal_p (temp2, ((((temp1)->fld[1].rtx))->fld[0].rtx))
       && ! side_effects_p (temp2)
       && ! may_trap_p (temp2)


       && (reallabelprev == temp
    || ((temp3 = next_active_insn (temp)) != 0
        && simplejump_p (temp3)
        && ((temp3)->fld[7].rtx) == ((insn)->fld[7].rtx)))
       && (temp3 = get_condition (insn, &temp4)) != 0



       && ((((temp3)->fld[0].rtx))->mode) != BLKmode
       && can_reverse_comparison_p (temp3, insn))
     {
       rtx temp6, target = 0, seq, init_insn = 0, init = temp2;
       n64_enum_rtx_code code = reverse_condition (((temp3)->code));

       start_sequence ();







       if ((temp5 = prev_active_insn (insn)) != 0
    && ((temp5)->code) == INSN
    && (temp6 = single_set (temp5)) != 0
    && rtx_equal_p (temp2, ((temp6)->fld[0].rtx))
    && ((((((temp6)->fld[1].rtx))->code) == LABEL_REF || ((((temp6)->fld[1].rtx))->code) == SYMBOL_REF || ((((temp6)->fld[1].rtx))->code) == CONST_INT || ((((temp6)->fld[1].rtx))->code) == CONST_DOUBLE || ((((temp6)->fld[1].rtx))->code) == CONST || ((((temp6)->fld[1].rtx))->code) == HIGH)
        || ((((temp6)->fld[1].rtx))->code) == REG
        || ((((temp6)->fld[1].rtx))->code) == SUBREG))
  {
    emit_insn (((temp5)->fld[3].rtx));
    init_insn = temp5;
    init = ((temp6)->fld[1].rtx);
  }

       if ((((init)->code) == LABEL_REF || ((init)->code) == SYMBOL_REF || ((init)->code) == CONST_INT || ((init)->code) == CONST_DOUBLE || ((init)->code) == CONST || ((init)->code) == HIGH)
    || ! reg_set_between_p (init, ((temp4)->fld[1].rtx), insn))
  target = emit_store_flag (gen_reg_rtx (((temp2)->mode)), code,
       ((temp3)->fld[0].rtx), ((temp3)->fld[1].rtx),
       VOIDmode,
       (code == LTU || code == LEU
        || code == GTU || code == GEU), 1);




       if (target)
  target = expand_binop (((temp2)->mode),
           (((((temp1)->fld[1].rtx))->fld[1].rtx) == const1_rtx
     ? add_optab : sub_optab),
           temp2, target, temp2, 0, OPTAB_WIDEN);

       if (target != 0)
  {





    if (target != temp2)
      emit_move_insn (temp2, target);

    seq = get_insns ();
    end_sequence ();

    emit_insns_before (seq, temp4);
    delete_insn (temp);

    if (init_insn)
      delete_insn (init_insn);

    next = ((insn)->fld[2].rtx);



    delete_insn (insn);
    changed = 1;
    continue;
  }
       else
  end_sequence ();
     }
   else if (this_is_condjump
     && (temp = next_active_insn (insn)) != 0
     && simplejump_p (temp)
     && (next_active_insn (((insn)->fld[7].rtx))
         == next_active_insn (((temp)->fld[7].rtx))))
     {
       delete_jump (insn);
       changed = 1;
       continue;
     }


   else if ((this_is_condjump || this_is_condjump_in_parallel)
     && ! this_is_simplejump
     && reallabelprev != 0
     && ((reallabelprev)->code) == JUMP_INSN
     && prev_active_insn (reallabelprev) == insn
     && no_labels_between_p (insn, reallabelprev)
     && simplejump_p (reallabelprev))
     {




       rtx prev_uses = prev_nonnote_insn (reallabelprev);
       rtx prev_label = ((insn)->fld[7].rtx);

       if (prev_label)
  ++((prev_label)->fld[5].rtint);

       if (invert_jump (insn, ((reallabelprev)->fld[7].rtx)))
  {
    while (prev_uses && ((prev_uses)->code) == INSN
    && ((((prev_uses)->fld[3].rtx))->code) == USE)
      {
        rtx useless = prev_uses;
        prev_uses = prev_nonnote_insn (prev_uses);
        delete_insn (useless);
      }

    delete_insn (reallabelprev);
    next = insn;
    changed = 1;
  }



       if (prev_label && --((prev_label)->fld[5].rtint) == 0)
  delete_insn (prev_label);
       continue;
     }
   else
     {


       nlabel = follow_jumps (((insn)->fld[7].rtx));
       if (nlabel != ((insn)->fld[7].rtx)
    && redirect_jump (insn, nlabel))
  {
    changed = 1;
    next = insn;
  }
       {
  rtx label1 = next_label (insn);
  rtx range1end = label1 ? prev_active_insn (label1) : 0;






  if (! first
      && (reload_completed ? ! flag_delayed_branch : 1)

      && condjump_p (insn)
      && label1 != 0
      && ((insn)->fld[7].rtx) == label1
      && ((label1)->fld[5].rtint) == 1
      && ((range1end)->code) == JUMP_INSN
      && simplejump_p (range1end))
    {
      rtx label2 = next_label (label1);
      rtx range2end = label2 ? prev_active_insn (label2) : 0;
      if (range1end != range2end
   && ((range1end)->fld[7].rtx) == label2
   && ((range2end)->code) == JUMP_INSN
   && ((((range2end)->fld[2].rtx))->code) == BARRIER


   && invert_jump (insn, label1))
        {
   rtx range1beg = next_active_insn (insn);
   rtx range2beg = next_active_insn (label1);
   rtx range1after, range2after;
   rtx range1before, range2before;
   rtx rangenext;




   while (((range1beg)->fld[1].rtx)
          && ((((range1beg)->fld[1].rtx))->code) == NOTE)
     range1beg = ((range1beg)->fld[1].rtx);

   while (((range2beg)->fld[1].rtx)
          && ((((range2beg)->fld[1].rtx))->code) == NOTE)
     range2beg = ((range2beg)->fld[1].rtx);



   range1beg = squeeze_notes (range1beg, range1end);
   range2beg = squeeze_notes (range2beg, range2end);


   range1before = ((range1beg)->fld[1].rtx);
   range2before = ((range2beg)->fld[1].rtx);
   range1after = ((range1end)->fld[2].rtx);
   range2after = ((range2end)->fld[2].rtx);


   ((range1before)->fld[2].rtx) = range2beg;
   ((range2beg)->fld[1].rtx) = range1before;
   ((range2end)->fld[2].rtx) = range1after;
   ((range1after)->fld[1].rtx) = range2end;

   ((range2before)->fld[2].rtx) = range1beg;
   ((range1beg)->fld[1].rtx) = range2before;
   ((range1end)->fld[2].rtx) = range2after;
   ((range2after)->fld[1].rtx) = range1end;
   for (;range2after != label2; range2after = rangenext)
     {
       rangenext = ((range2after)->fld[2].rtx);
       if (((range2after)->code) == NOTE)
         {
    if (((range2after)->fld[4].rtint)
        == -5)
      {
        ((((range2after)->fld[1].rtx))->fld[2].rtx)
          = rangenext;
        ((rangenext)->fld[1].rtx)
          = ((range2after)->fld[1].rtx);
        ((range2after)->fld[1].rtx)
          = ((range1beg)->fld[1].rtx);
        ((range2after)->fld[2].rtx) = range1beg;
        ((((range1beg)->fld[1].rtx))->fld[2].rtx)
          = range2after;
        ((range1beg)->fld[1].rtx) = range2after;
      }
    else if (((range2after)->fld[4].rtint)
      == -4)
      break;
         }
     }
   changed = 1;
   continue;
        }
    }
       }







       if (cross_jump && condjump_p (insn))
  {
    rtx newjpos, newlpos;
    rtx x = prev_real_insn (((insn)->fld[7].rtx));





    if (x != 0 && ! jump_back_p (x, insn))


      x = 0;

    newjpos = 0;


    if (x != 0)
      find_cross_jump (insn, x, 2,
         &newjpos, &newlpos);

    if (newjpos != 0)
      {
        do_cross_jump (insn, newjpos, newlpos);


        ((((insn)->fld[3].rtx))->fld[1].rtx)
   = gen_rtx (LABEL_REF, VOIDmode, ((insn)->fld[7].rtx));
        ((insn)->fld[4].rtint) = -1;
        emit_barrier_after (insn);


        if (((((insn)->fld[7].rtx))->fld[0].rtint) < max_jump_chain)
   {
     jump_chain[((insn)->fld[0].rtint)]
       = jump_chain[((((insn)->fld[7].rtx))->fld[0].rtint)];
     jump_chain[((((insn)->fld[7].rtx))->fld[0].rtint)] = insn;
   }
        changed = 1;
        next = insn;
      }
  }




       if (cross_jump && simplejump_p (insn))
  {
    rtx newjpos, newlpos;
    rtx target;

    newjpos = 0;



    find_cross_jump (insn, ((insn)->fld[7].rtx), 1,
       &newjpos, &newlpos);





    if (((((insn)->fld[7].rtx))->fld[0].rtint) < max_uid)
      for (target = jump_chain[((((insn)->fld[7].rtx))->fld[0].rtint)];
    target != 0 && newjpos == 0;
    target = jump_chain[((target)->fld[0].rtint)])
        if (target != insn
     && ((target)->fld[7].rtx) == ((insn)->fld[7].rtx)

     && ! ((target)->volatil))
   find_cross_jump (insn, target, 2,
      &newjpos, &newlpos);

    if (newjpos != 0)
      {
        do_cross_jump (insn, newjpos, newlpos);
        changed = 1;
        next = insn;
      }
  }


       if (cross_jump && ((((insn)->fld[3].rtx))->code) == RETURN)
  {



    rtx newjpos, newlpos, target;

    newjpos = 0;





    for (target = jump_chain[0];
         target != 0 && newjpos == 0;
         target = jump_chain[((target)->fld[0].rtint)])
      if (target != insn
   && ! ((target)->volatil)
   && ((((target)->fld[3].rtx))->code) == RETURN)
        find_cross_jump (insn, target, 2,
           &newjpos, &newlpos);

    if (newjpos != 0)
      {
        do_cross_jump (insn, newjpos, newlpos);
        changed = 1;
        next = insn;
      }
  }
     }
 }

      first = 0;
    }






  {
    rtx last_note = 0;

    for (insn = f; insn; insn = ((insn)->fld[2].rtx))
      if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) >= 0)
 {

   if (last_note
       && ((insn)->fld[3].rtstr) == ((last_note)->fld[3].rtstr)
       && ((insn)->fld[4].rtint) == ((last_note)->fld[4].rtint))
     {
       delete_insn (insn);
       continue;
     }

   last_note = insn;
 }
  }


  if ((simple_epilogue_p ()))
    {





      insn = get_last_insn ();
      while (insn && ((insn)->code) == NOTE)
 insn = ((insn)->fld[1].rtx);

      if (insn && ((insn)->code) != BARRIER)
 {
   emit_jump_insn (gen_return ());
   emit_barrier ();
 }
    }





  insn = last_insn;
  {
    int n_labels = 1;
    while (insn

    && ((((insn)->code) == CODE_LABEL && n_labels-- > 0)

        || ((insn)->code) == INSN


        || (((insn)->code) == JUMP_INSN
     && ((((insn)->fld[3].rtx))->code) == RETURN)

        || ((insn)->code) == BARRIER

        || (((insn)->code) == NOTE
     && ((insn)->fld[4].rtint) != -6)))
      insn = ((insn)->fld[1].rtx);
  }


  if (insn && ((insn)->code) == NOTE
      && ((insn)->fld[4].rtint) == -6)
    {
      can_reach_end = 1;
      delete_insn (insn);
    }


  jump_chain = 0;
}
static int
duplicate_loop_exit_test(rtx loop_start) asm("_duplicate_loop_exit_test");
static int
duplicate_loop_exit_test(rtx loop_start)
{
  rtx insn, set, reg, p, link;
  rtx copy = 0;
  int num_insns = 0;
  rtx exitcode = ((((next_nonnote_insn (loop_start))->fld[7].rtx))->fld[2].rtx);
  rtx lastexit;
  int max_reg = max_reg_num ();
  rtx *reg_map = 0;
  for (insn = exitcode;
       insn
       && ! (((insn)->code) == NOTE
      && ((insn)->fld[4].rtint) == -5);
       insn = ((insn)->fld[2].rtx))
    {
      switch (((insn)->code))
 {
 case CODE_LABEL:
 case CALL_INSN:
   return 0;
 case NOTE:
   if (((insn)->fld[4].rtint) == -4
       || ((insn)->fld[4].rtint) == -2
       || ((insn)->fld[4].rtint) == -3
       || ((insn)->fld[4].rtint) == -8)
     return 0;
   break;
 case JUMP_INSN:
 case INSN:
   if (++num_insns > 20
       || find_reg_note (insn, REG_RETVAL, (rtx) 0)
       || find_reg_note (insn, REG_LIBCALL, (rtx) 0))
     return 0;
   break;
 }
    }


  if (insn == 0)
    return 0;

  lastexit = insn;



  for (insn = exitcode; insn != lastexit; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == INSN
 && (set = single_set (insn)) != 0
 && ((reg = ((set)->fld[0].rtx), ((reg)->code) == REG)
     || (((reg)->code) == SUBREG
  && (reg = ((reg)->fld[0].rtx), ((reg)->code) == REG)))
 && ((reg)->fld[0].rtint) >= 68
 && regno_first_uid[((reg)->fld[0].rtint)] == ((insn)->fld[0].rtint))
      {
 for (p = ((insn)->fld[2].rtx); p != lastexit; p = ((p)->fld[2].rtx))
   if (regno_last_uid[((reg)->fld[0].rtint)] == ((p)->fld[0].rtint))
     break;

 if (p != lastexit)
   {


     if (reg_map == 0)
       {
  reg_map = (rtx *) 
                   __builtin_alloca((
                   max_reg * sizeof (rtx)
                   ))
                                                  ;
  memset ((char *) reg_map,0,max_reg * sizeof (rtx));
       }

     ((reg)->in_struct) = 1;

     reg_map[((reg)->fld[0].rtint)] = gen_reg_rtx (((reg)->mode));
   }
      }


  for (insn = exitcode; insn != lastexit; insn = ((insn)->fld[2].rtx))
    switch (((insn)->code))
      {
      case BARRIER:
 copy = emit_barrier_before (loop_start);
 break;
      case NOTE:

 if (((insn)->fld[4].rtint) >= 0)
   {
     copy = emit_note_before (((insn)->fld[4].rtint), loop_start);
     ((copy)->fld[3].rtstr) = ((insn)->fld[3].rtstr);
   }
 break;

      case INSN:
 copy = emit_insn_before (copy_rtx (((insn)->fld[3].rtx)), loop_start);
 if (reg_map)
   replace_regs (((copy)->fld[3].rtx), reg_map, max_reg, 1);

 mark_jump_label (((copy)->fld[3].rtx), copy, 0);



 for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
   if (((n64_enum_reg_note) ((link)->mode)) != REG_LABEL)
     ((copy)->fld[6].rtx)
       = copy_rtx (gen_rtx (EXPR_LIST, ((n64_enum_reg_note) ((link)->mode)),
       ((link)->fld[0].rtx), ((copy)->fld[6].rtx)));
 if (reg_map && ((copy)->fld[6].rtx))
   replace_regs (((copy)->fld[6].rtx), reg_map, max_reg, 1);
 break;

      case JUMP_INSN:
 copy = emit_jump_insn_before (copy_rtx (((insn)->fld[3].rtx)), loop_start);
 if (reg_map)
   replace_regs (((copy)->fld[3].rtx), reg_map, max_reg, 1);
 mark_jump_label (((copy)->fld[3].rtx), copy, 0);
 if (((insn)->fld[6].rtx))
   {
     ((copy)->fld[6].rtx) = copy_rtx (((insn)->fld[6].rtx));
     if (reg_map)
       replace_regs (((copy)->fld[6].rtx), reg_map, max_reg, 1);
   }



 if (((copy)->fld[0].rtint) < max_jump_chain && ((copy)->fld[7].rtx)
     && simplejump_p (copy))
   {
     jump_chain[((copy)->fld[0].rtint)]
       = jump_chain[((((copy)->fld[7].rtx))->fld[0].rtint)];
     jump_chain[((((copy)->fld[7].rtx))->fld[0].rtint)] = copy;
   }
 break;

      default:
 abort ();
      }



  if (! copy || ((copy)->code) != BARRIER)
    {
      copy = emit_jump_insn_before (gen_jump (get_label_after (insn)),
        loop_start);
      mark_jump_label (((copy)->fld[3].rtx), copy, 0);
      if (((copy)->fld[0].rtint) < max_jump_chain
   && ((((copy)->fld[7].rtx))->fld[0].rtint) < max_jump_chain)
 {
   jump_chain[((copy)->fld[0].rtint)]
     = jump_chain[((((copy)->fld[7].rtx))->fld[0].rtint)];
   jump_chain[((((copy)->fld[7].rtx))->fld[0].rtint)] = copy;
 }
      emit_barrier_before (loop_start);
    }


  emit_note_before (-9, exitcode);

  delete_insn (next_nonnote_insn (loop_start));

  return 1;
}







rtx
squeeze_notes(rtx start, rtx end) asm("_squeeze_notes");
rtx
squeeze_notes(rtx start, rtx end)
{
  rtx insn;
  rtx next;

  for (insn = start; insn != end; insn = next)
    {
      next = ((insn)->fld[2].rtx);
      if (((insn)->code) == NOTE
   && (((insn)->fld[4].rtint) == -3
       || ((insn)->fld[4].rtint) == -2
       || ((insn)->fld[4].rtint) == -4
       || ((insn)->fld[4].rtint) == -5
       || ((insn)->fld[4].rtint) == -8
       || ((insn)->fld[4].rtint) == -9))
 {
   if (insn == start)
     start = next;
   else
     {
       rtx prev = ((insn)->fld[1].rtx);
       ((insn)->fld[1].rtx) = ((start)->fld[1].rtx);
       ((insn)->fld[2].rtx) = start;
       ((((insn)->fld[1].rtx))->fld[2].rtx) = insn;
       ((((insn)->fld[2].rtx))->fld[1].rtx) = insn;
       ((prev)->fld[2].rtx) = next;
       ((next)->fld[1].rtx) = prev;
     }
 }
    }

  return start;
}
static void
find_cross_jump(rtx e1, rtx e2, int minimum, rtx *f1, rtx *f2) asm("_find_cross_jump");
static void
find_cross_jump(rtx e1, rtx e2, int minimum, rtx *f1, rtx *f2)
{
  register rtx i1 = e1, i2 = e2;
  register rtx p1, p2;
  int lose = 0;

  rtx last1 = 0, last2 = 0;
  rtx afterlast1 = 0, afterlast2 = 0;
  rtx prev1;

  *f1 = 0;
  *f2 = 0;

  while (1)
    {
      i1 = prev_nonnote_insn (i1);

      i2 = ((i2)->fld[1].rtx);
      while (i2 && (((i2)->code) == NOTE || ((i2)->code) == CODE_LABEL))
 i2 = ((i2)->fld[1].rtx);

      if (i1 == 0)
 break;



      if (i2 == e1 || i1 == e2)
 break;




      if (((i1)->code) == CODE_LABEL)
 {
   --minimum;
   break;
 }

      if (i2 == 0 || ((i1)->code) != ((i2)->code))
 break;

      p1 = ((i1)->fld[3].rtx);
      p2 = ((i2)->fld[3].rtx);
      if (((i1)->code) == CALL_INSN
   && ! rtx_equal_p (((i1)->fld[7].rtx),
       ((i2)->fld[7].rtx)))
 lose = 1;
      if (lose || ((p1)->code) != ((p2)->code)
   || ! rtx_renumbered_equal_p (p1, p2))
 {

   rtx equiv1;
   rtx equiv2;

   if (!lose && ((p1)->code) == ((p2)->code)
       && ((equiv1 = find_reg_note (i1, REG_EQUAL, (rtx) 0)) != 0
    || (equiv1 = find_reg_note (i1, REG_EQUIV, (rtx) 0)) != 0)
       && ((equiv2 = find_reg_note (i2, REG_EQUAL, (rtx) 0)) != 0
    || (equiv2 = find_reg_note (i2, REG_EQUIV, (rtx) 0)) != 0)



       && (((((equiv1)->fld[0].rtx))->code) == LABEL_REF || ((((equiv1)->fld[0].rtx))->code) == SYMBOL_REF || ((((equiv1)->fld[0].rtx))->code) == CONST_INT || ((((equiv1)->fld[0].rtx))->code) == CONST_DOUBLE || ((((equiv1)->fld[0].rtx))->code) == CONST || ((((equiv1)->fld[0].rtx))->code) == HIGH)
       && rtx_equal_p (((equiv1)->fld[0].rtx), ((equiv2)->fld[0].rtx)))
     {
       rtx s1 = single_set (i1);
       rtx s2 = single_set (i2);
       if (s1 != 0 && s2 != 0
    && rtx_renumbered_equal_p (((s1)->fld[0].rtx), ((s2)->fld[0].rtx)))
  {
    validate_change (i1, &((s1)->fld[1].rtx), ((equiv1)->fld[0].rtx), 1);
    validate_change (i2, &((s2)->fld[1].rtx), ((equiv2)->fld[0].rtx), 1);
    if (! rtx_renumbered_equal_p (p1, p2))
      cancel_changes (0);
    else if (apply_change_group ())
      goto win;
  }
     }
   if (((i1)->code) == JUMP_INSN
       && ((i1)->fld[7].rtx)
       && prev_real_insn (((i1)->fld[7].rtx)) == e1)
     --minimum;
   break;
 }

    win:
      if (((p1)->code) != USE && ((p1)->code) != CLOBBER)
 {

   afterlast1 = last1, afterlast2 = last2;
   last1 = i1, last2 = i2, --minimum;
 }
    }

  if (minimum <= 0 && last1 != 0 && last1 != e1)
    *f1 = last1, *f2 = last2;
}

static void
do_cross_jump(rtx insn, rtx newjpos, rtx newlpos) asm("_do_cross_jump");
static void
do_cross_jump(rtx insn, rtx newjpos, rtx newlpos)
{


  register rtx label = get_label_before (newlpos);


  if (((((insn)->fld[3].rtx))->code) == RETURN)
    {

      delete_from_jump_chain (insn);

      ((insn)->fld[3].rtx) = gen_jump (label);
      ((insn)->fld[4].rtint) = -1;
      ((insn)->fld[7].rtx) = label;
      ((label)->fld[5].rtint)++;

      if (((label)->fld[0].rtint) < max_jump_chain
   && ((insn)->fld[0].rtint) < max_jump_chain)
 {
   jump_chain[((insn)->fld[0].rtint)] = jump_chain[((label)->fld[0].rtint)];
   jump_chain[((label)->fld[0].rtint)] = insn;
 }
    }
  else
    redirect_jump (insn, label);





  while (newjpos != insn)
    {
      rtx lnote;

      for (lnote = ((newlpos)->fld[6].rtx); lnote; lnote = ((lnote)->fld[1].rtx))
 if ((((n64_enum_reg_note) ((lnote)->mode)) == REG_EQUAL
      || ((n64_enum_reg_note) ((lnote)->mode)) == REG_EQUIV)
     && ! find_reg_note (newjpos, REG_EQUAL, ((lnote)->fld[0].rtx))
     && ! find_reg_note (newjpos, REG_EQUIV, ((lnote)->fld[0].rtx)))
   remove_note (newlpos, lnote);

      delete_insn (newjpos);
      newjpos = next_real_insn (newjpos);
      newlpos = next_real_insn (newlpos);
    }
}



rtx
get_label_before(rtx insn) asm("_get_label_before");
rtx
get_label_before(rtx insn)
{
  rtx label;



  label = prev_nonnote_insn (insn);

  if (label == 0 || ((label)->code) != CODE_LABEL)
    {
      rtx prev = ((insn)->fld[1].rtx);

      label = gen_label_rtx ();
      emit_label_after (label, prev);
      ((label)->fld[5].rtint) = 0;
    }
  return label;
}



rtx
get_label_after(rtx insn) asm("_get_label_after");
rtx
get_label_after(rtx insn)
{
  rtx label;



  label = next_nonnote_insn (insn);

  if (label == 0 || ((label)->code) != CODE_LABEL)
    {
      label = gen_label_rtx ();
      emit_label_after (label, insn);
      ((label)->fld[5].rtint) = 0;
    }
  return label;
}





static int
jump_back_p(rtx insn, rtx target) asm("_jump_back_p");
static int
jump_back_p(rtx insn, rtx target)
{
  rtx cinsn, ctarget;
  n64_enum_rtx_code codei, codet;

  if (simplejump_p (insn) || ! condjump_p (insn)
      || simplejump_p (target)
      || target != prev_real_insn (((insn)->fld[7].rtx)))
    return 0;

  cinsn = ((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx);
  ctarget = ((((((target)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx);

  codei = ((cinsn)->code);
  codet = ((ctarget)->code);

  if (((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) == pc_rtx)
    {
      if (! can_reverse_comparison_p (cinsn, insn))
 return 0;
      codei = reverse_condition (codei);
    }

  if (((((((target)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx) == pc_rtx)
    {
      if (! can_reverse_comparison_p (ctarget, target))
 return 0;
      codet = reverse_condition (codet);
    }

  return (codei == codet
   && rtx_renumbered_equal_p (((cinsn)->fld[0].rtx), ((ctarget)->fld[0].rtx))
   && rtx_renumbered_equal_p (((cinsn)->fld[1].rtx), ((ctarget)->fld[1].rtx)));
}






int
can_reverse_comparison_p(rtx comparison, rtx insn) asm("_can_reverse_comparison_p");
int
can_reverse_comparison_p(rtx comparison, rtx insn)
{
  rtx arg0;


  if ((rtx_class[(int)(((comparison)->code))]) != '<')
    return 0;

  if (1 != 1




      || flag_fast_math
      || ((comparison)->code) == NE
      || ((comparison)->code) == EQ)
    return 1;

  arg0 = ((comparison)->fld[0].rtx);





  if ((((arg0)->code) == REG && (mode_class[(int)(((arg0)->mode))]) == MODE_CC)



      )
    {
      rtx prev = prev_nonnote_insn (insn);
      rtx set = single_set (prev);

      if (set == 0 || ((set)->fld[0].rtx) != arg0)
 return 0;

      arg0 = ((set)->fld[1].rtx);

      if (((arg0)->code) == COMPARE)
 arg0 = ((arg0)->fld[0].rtx);
    }



  return (((arg0)->code) == CONST_INT
   || (((arg0)->mode) != VOIDmode
       && (mode_class[(int)(((arg0)->mode))]) != MODE_CC
       && (mode_class[(int)(((arg0)->mode))]) != MODE_FLOAT));
}
n64_enum_rtx_code
reverse_condition(n64_enum_rtx_code code) asm("_reverse_condition");
n64_enum_rtx_code
reverse_condition(n64_enum_rtx_code code)
{
  switch (code)
    {
    case EQ:
      return NE;

    case NE:
      return EQ;

    case GT:
      return LE;

    case GE:
      return LT;

    case LT:
      return GE;

    case LE:
      return GT;

    case GTU:
      return LEU;

    case GEU:
      return LTU;

    case LTU:
      return GEU;

    case LEU:
      return GTU;

    default:
      abort ();
      return UNKNOWN;
    }
}




n64_enum_rtx_code
swap_condition(n64_enum_rtx_code code) asm("_swap_condition");
n64_enum_rtx_code
swap_condition(n64_enum_rtx_code code)
{
  switch (code)
    {
    case EQ:
    case NE:
      return code;

    case GT:
      return LT;

    case GE:
      return LE;

    case LT:
      return GT;

    case LE:
      return GE;

    case GTU:
      return LTU;

    case GEU:
      return LEU;

    case LTU:
      return GTU;

    case LEU:
      return GEU;

    default:
      abort ();
      return UNKNOWN;
    }
}





n64_enum_rtx_code
unsigned_condition(n64_enum_rtx_code code) asm("_unsigned_condition");
n64_enum_rtx_code
unsigned_condition(n64_enum_rtx_code code)
{
  switch (code)
    {
    case EQ:
    case NE:
    case GTU:
    case GEU:
    case LTU:
    case LEU:
      return code;

    case GT:
      return GTU;

    case GE:
      return GEU;

    case LT:
      return LTU;

    case LE:
      return LEU;

    default:
      abort ();
    }
}



n64_enum_rtx_code
signed_condition(n64_enum_rtx_code code) asm("_signed_condition");
n64_enum_rtx_code
signed_condition(n64_enum_rtx_code code)
{
  switch (code)
    {
    case EQ:
    case NE:
    case GT:
    case GE:
    case LT:
    case LE:
      return code;

    case GTU:
      return GT;

    case GEU:
      return GE;

    case LTU:
      return LT;

    case LEU:
      return LE;

    default:
      abort ();
    }
}




int
comparison_dominates_p(n64_enum_rtx_code code1, n64_enum_rtx_code code2) asm("_comparison_dominates_p");
int
comparison_dominates_p(n64_enum_rtx_code code1, n64_enum_rtx_code code2)
{
  if (code1 == code2)
    return 1;

  switch (code1)
    {
    case EQ:
      if (code2 == LE || code2 == LEU || code2 == GE || code2 == GEU)
 return 1;
      break;

    case LT:
      if (code2 == LE || code2 == NE)
 return 1;
      break;

    case GT:
      if (code2 == GE || code2 == NE)
 return 1;
      break;

    case LTU:
      if (code2 == LEU || code2 == NE)
 return 1;
      break;

    case GTU:
      if (code2 == GEU || code2 == NE)
 return 1;
      break;
    }

  return 0;
}



int
simplejump_p(rtx insn) asm("_simplejump_p");
int
simplejump_p(rtx insn)
{
  return (((insn)->code) == JUMP_INSN
   && ((((insn)->fld[3].rtx))->code) == SET
   && ((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == PC
   && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == LABEL_REF);
}




int
condjump_p(rtx insn) asm("_condjump_p");
int
condjump_p(rtx insn)
{
  register rtx x = ((insn)->fld[3].rtx);
  if (((x)->code) != SET)
    return 0;
  if (((((x)->fld[0].rtx))->code) != PC)
    return 0;
  if (((((x)->fld[1].rtx))->code) == LABEL_REF)
    return 1;
  if (((((x)->fld[1].rtx))->code) != IF_THEN_ELSE)
    return 0;
  if (((((x)->fld[1].rtx))->fld[2].rtx) == pc_rtx
      && (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF
   || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == RETURN))
    return 1;
  if (((((x)->fld[1].rtx))->fld[1].rtx) == pc_rtx
      && (((((((x)->fld[1].rtx))->fld[2].rtx))->code) == LABEL_REF
   || ((((((x)->fld[1].rtx))->fld[2].rtx))->code) == RETURN))
    return 1;
  return 0;
}




int
condjump_in_parallel_p(rtx insn) asm("_condjump_in_parallel_p");
int
condjump_in_parallel_p(rtx insn)
{
  register rtx x = ((insn)->fld[3].rtx);

  if (((x)->code) != PARALLEL)
    return 0;
  else
    x = ((x)->fld[0].rtvec->elem[0].rtx);

  if (((x)->code) != SET)
    return 0;
  if (((((x)->fld[0].rtx))->code) != PC)
    return 0;
  if (((((x)->fld[1].rtx))->code) == LABEL_REF)
    return 1;
  if (((((x)->fld[1].rtx))->code) != IF_THEN_ELSE)
    return 0;
  if (((((x)->fld[1].rtx))->fld[2].rtx) == pc_rtx
      && (((((((x)->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF
   || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) == RETURN))
    return 1;
  if (((((x)->fld[1].rtx))->fld[1].rtx) == pc_rtx
      && (((((((x)->fld[1].rtx))->fld[2].rtx))->code) == LABEL_REF
   || ((((((x)->fld[1].rtx))->fld[2].rtx))->code) == RETURN))
    return 1;
  return 0;
}






int
sets_cc0_p(rtx x) asm("_sets_cc0_p");
int
sets_cc0_p(rtx x)
{
  abort ();

}
rtx
follow_jumps(rtx label) asm("_follow_jumps");
rtx
follow_jumps(rtx label)
{
  register rtx insn;
  register rtx next;
  register rtx value = label;
  register int depth;

  for (depth = 0;
       (depth < 10
 && (insn = next_active_insn (value)) != 0
 && ((insn)->code) == JUMP_INSN
 && (((insn)->fld[7].rtx) != 0 || ((((insn)->fld[3].rtx))->code) == RETURN)
 && (next = ((insn)->fld[2].rtx))
 && ((next)->code) == BARRIER);
       depth++)
    {




      rtx tem;
      if (!reload_completed)
 for (tem = value; tem != insn; tem = ((tem)->fld[2].rtx))
   if (((tem)->code) == NOTE
       && ((tem)->fld[4].rtint) == -4)
     return value;


      if (((insn)->fld[7].rtx) == label)
 return label;

      tem = next_active_insn (((insn)->fld[7].rtx));
      if (tem && (((((tem)->fld[3].rtx))->code) == ADDR_VEC
    || ((((tem)->fld[3].rtx))->code) == ADDR_DIFF_VEC))
 break;

      value = ((insn)->fld[7].rtx);
    }
  if (depth == 10)
    return label;
  return value;
}






static int
tension_vector_labels(register rtx x, register int idx) asm("_tension_vector_labels");
static int
tension_vector_labels(register rtx x, register int idx)
{
  int changed = 0;
  register int i;
  for (i = ((x)->fld[idx].rtvec->num_elem) - 1; i >= 0; i--)
    {
      register rtx olabel = ((((x)->fld[idx].rtvec->elem[i].rtx))->fld[0].rtx);
      register rtx nlabel = follow_jumps (olabel);
      if (nlabel && nlabel != olabel)
 {
   ((((x)->fld[idx].rtvec->elem[i].rtx))->fld[0].rtx) = nlabel;
   ++((nlabel)->fld[5].rtint);
   if (--((olabel)->fld[5].rtint) == 0)
     delete_insn (olabel);
   changed = 1;
 }
    }
  return changed;
}
static void
mark_jump_label(register rtx x, rtx insn, int cross_jump) asm("_mark_jump_label");
static void
mark_jump_label(register rtx x, rtx insn, int cross_jump)
{
  register n64_enum_rtx_code code = ((x)->code);
  register int i;
  register char *fmt;

  switch (code)
    {
    case PC:
    case CC0:
    case REG:
    case SUBREG:
    case CONST_INT:
    case SYMBOL_REF:
    case CONST_DOUBLE:
    case CLOBBER:
    case CALL:
      return;

    case MEM:

      if (((((x)->fld[0].rtx))->code) == SYMBOL_REF
   && ((((x)->fld[0].rtx))->unchanging))
 mark_jump_label (get_pool_constant (((x)->fld[0].rtx)), insn, cross_jump);
      break;

    case LABEL_REF:
      {
 rtx label = ((x)->fld[0].rtx);
 rtx olabel = label;
 rtx note;
 rtx next;

 if (((label)->code) != CODE_LABEL)
   abort ();


 if (((x)->volatil))
   break;



 for (next = ((label)->fld[2].rtx); next; next = ((next)->fld[2].rtx))
   {
     if (((next)->code) == CODE_LABEL)
       label = next;
     else if (cross_jump && ((next)->code) == INSN
       && (((((next)->fld[3].rtx))->code) == USE
    || ((((next)->fld[3].rtx))->code) == CLOBBER))
       continue;
     else if (((next)->code) != NOTE)
       break;
     else if (! cross_jump
       && (((next)->fld[4].rtint) == -4
    || ((next)->fld[4].rtint) == -6))
       break;
   }

 ((x)->fld[0].rtx) = label;
 ++((label)->fld[5].rtint);

 if (insn)
   {
     if (((insn)->code) == JUMP_INSN)
       ((insn)->fld[7].rtx) = label;



     else if (label != olabel
       && (note = find_reg_note (insn, REG_LABEL, olabel)) != 0)
       ((note)->fld[0].rtx) = label;



     else if (! find_reg_note (insn, REG_LABEL, label))
       {
  rtx next = next_real_insn (label);




  if (next == 0
      || ! (((next)->code) == JUMP_INSN
     && (((((next)->fld[3].rtx))->code) == ADDR_VEC
         || ((((next)->fld[3].rtx))->code) == ADDR_DIFF_VEC)))
    ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_LABEL, label,
           ((insn)->fld[6].rtx));
       }
   }
 return;
      }



    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      {
 int eltnum = code == ADDR_DIFF_VEC ? 1 : 0;

 for (i = 0; i < ((x)->fld[eltnum].rtvec->num_elem); i++)
   mark_jump_label (((x)->fld[eltnum].rtvec->elem[i].rtx), (rtx) 0, cross_jump);
 return;
      }
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 mark_jump_label (((x)->fld[i].rtx), insn, cross_jump);
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     mark_jump_label (((x)->fld[i].rtvec->elem[j].rtx), insn, cross_jump);
 }
    }
}





void
delete_jump(rtx insn) asm("_delete_jump");
void
delete_jump(rtx insn)
{
  register rtx set = single_set (insn);

  if (set && ((((set)->fld[0].rtx))->code) == PC)
    delete_computation (insn);
}
static void
delete_computation(rtx insn) asm("_delete_computation");
static void
delete_computation(rtx insn)
{
  rtx note, next;
  for (note = ((insn)->fld[6].rtx); note; note = next)
    {
      rtx our_prev;

      next = ((note)->fld[1].rtx);

      if (((n64_enum_reg_note) ((note)->mode)) != REG_DEAD

   || ((((note)->fld[0].rtx))->code) != REG)
 continue;

      for (our_prev = prev_nonnote_insn (insn);
    our_prev && ((our_prev)->code) == INSN;
    our_prev = prev_nonnote_insn (our_prev))
 {


   if (((((our_prev)->fld[3].rtx))->code) == SEQUENCE)
     break;

   if (((((our_prev)->fld[3].rtx))->code) == USE
       && ((((((our_prev)->fld[3].rtx))->fld[0].rtx))->code) == INSN)


     break;

   if (reg_set_p (((note)->fld[0].rtx), ((our_prev)->fld[3].rtx)))
     {
       if (0)
  break;

       if (((((our_prev)->fld[3].rtx))->code) == PARALLEL)
  {



    int i;

    for (i = 0; i < ((((our_prev)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
      {
        rtx part = ((((our_prev)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);

        if (((part)->code) == SET
     && ((part)->fld[0].rtx) != ((note)->fld[0].rtx))
   break;
      }

    if (i == ((((our_prev)->fld[3].rtx))->fld[0].rtvec->num_elem))
      delete_computation (our_prev);
  }
       else if (((((our_prev)->fld[3].rtx))->code) == SET
         && ((((our_prev)->fld[3].rtx))->fld[0].rtx) == ((note)->fld[0].rtx))
  delete_computation (our_prev);

       break;
     }




   if (reg_overlap_mentioned_p (((note)->fld[0].rtx),
           ((our_prev)->fld[3].rtx)))
     {
       ((note)->fld[1].rtx) = ((our_prev)->fld[6].rtx);
       ((our_prev)->fld[6].rtx) = note;
       break;
     }
 }
    }

  delete_insn (insn);
}







rtx
delete_insn(register rtx insn) asm("_delete_insn");
rtx
delete_insn(register rtx insn)
{
  register rtx next = ((insn)->fld[2].rtx);
  register rtx prev = ((insn)->fld[1].rtx);
  register int was_code_label = (((insn)->code) == CODE_LABEL);
  register int dont_really_delete = 0;

  while (next && ((next)->volatil))
    next = ((next)->fld[2].rtx);


  if (((insn)->volatil))
    return next;



  if (was_code_label && ((insn)->fld[4].rtstr) != 0
      && optimize && ! dont_really_delete)
    {
      ((insn)->code = (NOTE));
      ((insn)->fld[4].rtint) = -12;
      ((insn)->fld[3].rtstr) = 0;
      dont_really_delete = 1;
    }
  else

    ((insn)->volatil) = 1;


  if (simplejump_p (insn))
    delete_from_jump_chain (insn);




  if (next != 0 && ((next)->code) == BARRIER)
    {
      ((next)->volatil) = 1;
      next = ((next)->fld[2].rtx);
    }



  if (optimize && ! dont_really_delete)
    {
      if (prev)
 {
   ((prev)->fld[2].rtx) = next;
   if (((prev)->code) == INSN && ((((prev)->fld[3].rtx))->code) == SEQUENCE)
     ((((((prev)->fld[3].rtx))->fld[0].rtvec->elem[((((prev)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1].rtx))->fld[2].rtx)
                                      = next;
 }

      if (next)
 {
   ((next)->fld[1].rtx) = prev;
   if (((next)->code) == INSN && ((((next)->fld[3].rtx))->code) == SEQUENCE)
     ((((((next)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx) = prev;
 }

      if (prev && ((prev)->fld[2].rtx) == 0)
 set_last_insn (prev);
    }




  if (((insn)->code) == JUMP_INSN && ((insn)->fld[7].rtx))
    if (--((((insn)->fld[7].rtx))->fld[5].rtint) == 0)
      {



 delete_insn (((insn)->fld[7].rtx));




 while (next && ((next)->volatil))
   next = ((next)->fld[2].rtx);
 return next;
      }



  if (((insn)->code) == JUMP_INSN
      && (((((insn)->fld[3].rtx))->code) == ADDR_VEC
   || ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC))
    {
      rtx pat = ((insn)->fld[3].rtx);
      int i, diff_vec_p = ((pat)->code) == ADDR_DIFF_VEC;
      int len = ((pat)->fld[diff_vec_p].rtvec->num_elem);

      for (i = 0; i < len; i++)
 if (--((((((pat)->fld[diff_vec_p].rtvec->elem[i].rtx))->fld[0].rtx))->fld[5].rtint) == 0)
   delete_insn (((((pat)->fld[diff_vec_p].rtvec->elem[i].rtx))->fld[0].rtx));
      while (next && ((next)->volatil))
 next = ((next)->fld[2].rtx);
      return next;
    }

  while (prev && (((prev)->volatil) || ((prev)->code) == NOTE))
    prev = ((prev)->fld[1].rtx);





  if (was_code_label
      && ((insn)->fld[2].rtx) != 0
      && ((((insn)->fld[2].rtx))->code) == JUMP_INSN
      && (((((((insn)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_VEC
   || ((((((insn)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_DIFF_VEC))
    next = delete_insn (((insn)->fld[2].rtx));



  if (was_code_label && prev && ((prev)->code) == BARRIER)
    {
      register n64_enum_rtx_code code;
      while (next != 0
      && ((rtx_class[(int)(code = ((next)->code))]) == 'i'
   || code == NOTE || code == BARRIER
   || (code == CODE_LABEL && ((next)->volatil))))
 {
   if (code == NOTE
       && ((next)->fld[4].rtint) != -6)
     next = ((next)->fld[2].rtx);

   else if (code == CODE_LABEL && ((next)->volatil))
     next = ((next)->fld[2].rtx);
   else




     next = delete_insn (next);
 }
    }

  return next;
}




rtx
next_nondeleted_insn(rtx insn) asm("_next_nondeleted_insn");
rtx
next_nondeleted_insn(rtx insn)
{
  while (((insn)->volatil))
    insn = ((insn)->fld[2].rtx);
  return insn;
}






void
delete_for_peephole(register rtx from, register rtx to) asm("_delete_for_peephole");
void
delete_for_peephole(register rtx from, register rtx to)
{
  register rtx insn = from;

  while (1)
    {
      register rtx next = ((insn)->fld[2].rtx);
      register rtx prev = ((insn)->fld[1].rtx);

      if (((insn)->code) != NOTE)
 {
   ((insn)->volatil) = 1;




   if (prev)
     ((prev)->fld[2].rtx) = next;

   if (next)
     ((next)->fld[1].rtx) = prev;
 }

      if (insn == to)
 break;
      insn = next;
    }





}




int
invert_jump(rtx jump, rtx nlabel) asm("_invert_jump");
int
invert_jump(rtx jump, rtx nlabel)
{





  if (! invert_exp (((jump)->fld[3].rtx), jump))
    return 0;

  if (redirect_jump (jump, nlabel))
    return 1;

  if (! invert_exp (((jump)->fld[3].rtx), jump))

    abort ();

  return 0;
}






int
invert_exp(rtx x, rtx insn) asm("_invert_exp");
int
invert_exp(rtx x, rtx insn)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;

  code = ((x)->code);

  if (code == IF_THEN_ELSE)
    {
      register rtx comp = ((x)->fld[0].rtx);
      register rtx tem;






      if (can_reverse_comparison_p (comp, insn)
   && validate_change (insn, &((x)->fld[0].rtx),
         gen_rtx (reverse_condition (((comp)->code)),
           ((comp)->mode), ((comp)->fld[0].rtx),
           ((comp)->fld[1].rtx)), 0))
 return 1;

      tem = ((x)->fld[1].rtx);
      validate_change (insn, &((x)->fld[1].rtx), ((x)->fld[2].rtx), 1);
      validate_change (insn, &((x)->fld[2].rtx), tem, 1);
      return apply_change_group ();
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 if (! invert_exp (((x)->fld[i].rtx), insn))
   return 0;
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (!invert_exp (((x)->fld[i].rtvec->elem[j].rtx), insn))
       return 0;
 }
    }

  return 1;
}
int
redirect_jump(rtx jump, rtx nlabel) asm("_redirect_jump");
int
redirect_jump(rtx jump, rtx nlabel)
{
  register rtx olabel = ((jump)->fld[7].rtx);

  if (nlabel == olabel)
    return 1;

  if (! redirect_exp (&((jump)->fld[3].rtx), olabel, nlabel, jump))
    return 0;




  if (jump_chain && (simplejump_p (jump)
       || ((((jump)->fld[3].rtx))->code) == RETURN))
    {
      int label_index = nlabel ? ((nlabel)->fld[0].rtint) : 0;

      delete_from_jump_chain (jump);
      if (label_index < max_jump_chain
   && ((jump)->fld[0].rtint) < max_jump_chain)
 {
   jump_chain[((jump)->fld[0].rtint)] = jump_chain[label_index];
   jump_chain[label_index] = jump;
 }
    }

  ((jump)->fld[7].rtx) = nlabel;
  if (nlabel)
    ++((nlabel)->fld[5].rtint);

  if (olabel && --((olabel)->fld[5].rtint) == 0)
    delete_insn (olabel);

  return 1;
}



static void
delete_from_jump_chain(rtx jump) asm("_delete_from_jump_chain");
static void
delete_from_jump_chain(rtx jump)
{
  int strchr;
  rtx olabel = ((jump)->fld[7].rtx);


  if (jump_chain && olabel != 0
      && ((olabel)->fld[0].rtint) < max_jump_chain
      && simplejump_p (jump))
    strchr = ((olabel)->fld[0].rtint);

  else if (jump_chain && ((((jump)->fld[3].rtx))->code) == RETURN)
    strchr = 0;
  else return;

  if (jump_chain[strchr] == jump)
    jump_chain[strchr] = jump_chain[((jump)->fld[0].rtint)];
  else
    {
      rtx insn;

      for (insn = jump_chain[strchr];
    insn != 0;
    insn = jump_chain[((insn)->fld[0].rtint)])
 if (jump_chain[((insn)->fld[0].rtint)] == jump)
   {
     jump_chain[((insn)->fld[0].rtint)] = jump_chain[((jump)->fld[0].rtint)];
     break;
   }
    }
}
int
redirect_exp(rtx *loc, rtx olabel, rtx nlabel, rtx insn) asm("_redirect_exp");
int
redirect_exp(rtx *loc, rtx olabel, rtx nlabel, rtx insn)
{
  register rtx x = *loc;
  register n64_enum_rtx_code code = ((x)->code);
  register int i;
  register char *fmt;

  if (code == LABEL_REF)
    {
      if (((x)->fld[0].rtx) == olabel)
 {
   if (nlabel)
     ((x)->fld[0].rtx) = nlabel;
   else
     return validate_change (insn, loc, gen_rtx (RETURN, VOIDmode), 0);
   return 1;
 }
    }
  else if (code == RETURN && olabel == 0)
    {
      x = gen_rtx (LABEL_REF, VOIDmode, nlabel);
      if (loc == &((insn)->fld[3].rtx))
 x = gen_rtx (SET, VOIDmode, pc_rtx, x);
      return validate_change (insn, loc, x, 0);
    }

  if (code == SET && nlabel == 0 && ((x)->fld[0].rtx) == pc_rtx
      && ((((x)->fld[1].rtx))->code) == LABEL_REF
      && ((((x)->fld[1].rtx))->fld[0].rtx) == olabel)
    return validate_change (insn, loc, gen_rtx (RETURN, VOIDmode), 0);

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 if (! redirect_exp (&((x)->fld[i].rtx), olabel, nlabel, insn))
   return 0;
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (! redirect_exp (&((x)->fld[i].rtvec->elem[j].rtx), olabel, nlabel, insn))
       return 0;
 }
    }

  return 1;
}
static void
redirect_tablejump(rtx jump, rtx nlabel) asm("_redirect_tablejump");
static void
redirect_tablejump(rtx jump, rtx nlabel)
{
  register rtx olabel = ((jump)->fld[7].rtx);


  if (jump_chain && ((nlabel)->fld[0].rtint) < max_jump_chain
      && ((jump)->fld[0].rtint) < max_jump_chain)
    {
      jump_chain[((jump)->fld[0].rtint)] = jump_chain[((nlabel)->fld[0].rtint)];
      jump_chain[((nlabel)->fld[0].rtint)] = jump;
    }

  ((jump)->fld[3].rtx) = gen_jump (nlabel);
  ((jump)->fld[7].rtx) = nlabel;
  ++((nlabel)->fld[5].rtint);
  ((jump)->fld[4].rtint) = -1;

  if (--((olabel)->fld[5].rtint) == 0)
    {
      delete_labelref_insn (jump, olabel, 0);
      delete_insn (olabel);
    }
}





static int
delete_labelref_insn(rtx insn, rtx label, int delete_this) asm("_delete_labelref_insn");
static int
delete_labelref_insn(rtx insn, rtx label, int delete_this)
{
  int deleted = 0;
  rtx link;

  if (((insn)->code) != NOTE
      && reg_mentioned_p (label, ((insn)->fld[3].rtx)))
    {
      if (delete_this)
 {
   delete_insn (insn);
   deleted = 1;
 }
      else
 return 1;
    }

  for (link = ((insn)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
    if (delete_labelref_insn (((link)->fld[0].rtx), label, 1))
      {
 if (delete_this)
   {
     delete_insn (insn);
     deleted = 1;
   }
 else
   return 1;
      }

  return deleted;
}






int
rtx_renumbered_equal_p(rtx x, rtx y) asm("_rtx_renumbered_equal_p");
int
rtx_renumbered_equal_p(rtx x, rtx y)
{
  register int i;
  register n64_enum_rtx_code code = ((x)->code);
  register char *fmt;

  if (x == y)
    return 1;

  if ((code == REG || (code == SUBREG && ((((x)->fld[0].rtx))->code) == REG))
      && (((y)->code) == REG || (((y)->code) == SUBREG
      && ((((y)->fld[0].rtx))->code) == REG)))
    {
      int reg_x = -1, reg_y = -1;
      int word_x = 0, word_y = 0;

      if (((x)->mode) != ((y)->mode))
 return 0;



      if (reg_renumber == 0)
 return rtx_equal_p (x, y);

      if (code == SUBREG)
 {
   reg_x = ((((x)->fld[0].rtx))->fld[0].rtint);
   word_x = ((x)->fld[1].rtint);

   if (reg_renumber[reg_x] >= 0)
     {
       reg_x = reg_renumber[reg_x] + word_x;
       word_x = 0;
     }
 }

      else
 {
   reg_x = ((x)->fld[0].rtint);
   if (reg_renumber[reg_x] >= 0)
     reg_x = reg_renumber[reg_x];
 }

      if (((y)->code) == SUBREG)
 {
   reg_y = ((((y)->fld[0].rtx))->fld[0].rtint);
   word_y = ((y)->fld[1].rtint);

   if (reg_renumber[reg_y] >= 0)
     {
       reg_y = reg_renumber[reg_y];
       word_y = 0;
     }
 }

      else
 {
   reg_y = ((y)->fld[0].rtint);
   if (reg_renumber[reg_y] >= 0)
     reg_y = reg_renumber[reg_y];
 }

      return reg_x >= 0 && reg_x == reg_y && word_x == word_y;
    }



  if (code != ((y)->code))
    return 0;

  switch (code)
    {
    case PC:
    case CC0:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return 0;

    case CONST_INT:
      return ((x)->fld[0].rtwint) == ((y)->fld[0].rtwint);

    case LABEL_REF:

      if (((x)->volatil) || ((y)->volatil))
 return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);



      return (next_real_insn (((x)->fld[0].rtx))
       == next_real_insn (((y)->fld[0].rtx)));

    case SYMBOL_REF:
      return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);
    }



  if (((x)->mode) != ((y)->mode))
    return 0;



  if (code == EQ || code == NE || (rtx_class[(int)(code)]) == 'c')
    return ((rtx_renumbered_equal_p (((x)->fld[0].rtx), ((y)->fld[0].rtx))
      && rtx_renumbered_equal_p (((x)->fld[1].rtx), ((y)->fld[1].rtx)))
     || (rtx_renumbered_equal_p (((x)->fld[0].rtx), ((y)->fld[1].rtx))
  && rtx_renumbered_equal_p (((x)->fld[1].rtx), ((y)->fld[0].rtx))));
  else if ((rtx_class[(int)(code)]) == '<' || (rtx_class[(int)(code)]) == '2')
    return (rtx_renumbered_equal_p (((x)->fld[0].rtx), ((y)->fld[0].rtx))
     && rtx_renumbered_equal_p (((x)->fld[1].rtx), ((y)->fld[1].rtx)));
  else if ((rtx_class[(int)(code)]) == '1')
    return rtx_renumbered_equal_p (((x)->fld[0].rtx), ((y)->fld[0].rtx));




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      register int j;
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'e':
   if (! rtx_renumbered_equal_p (((x)->fld[i].rtx), ((y)->fld[i].rtx)))
     return 0;
   break;

 case 'u':
   if (((x)->fld[i].rtx) != ((y)->fld[i].rtx))
     return 0;

 case '0':
   break;

 case 'E':
   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     if (!rtx_renumbered_equal_p (((x)->fld[i].rtvec->elem[j].rtx), ((y)->fld[i].rtvec->elem[j].rtx)))
       return 0;
   break;

 default:
   abort ();
 }
    }
  return 1;
}






int
true_regnum(rtx x) asm("_true_regnum");
int
true_regnum(rtx x)
{
  if (((x)->code) == REG)
    {
      if (((x)->fld[0].rtint) >= 68 && reg_renumber[((x)->fld[0].rtint)] >= 0)
 return reg_renumber[((x)->fld[0].rtint)];
      return ((x)->fld[0].rtint);
    }
  if (((x)->code) == SUBREG)
    {
      int base = true_regnum (((x)->fld[0].rtx));
      if (base >= 0 && base < 68)
 return ((x)->fld[1].rtint) + base;
    }
  return -1;
}
static int *same_regs;

static int num_same_regs;




static char *modified_regs;



static int modified_mem;




static void
mark_modified_reg(rtx dest, rtx x) asm("_mark_modified_reg");
static void
mark_modified_reg(rtx dest, rtx x)
{
  int regno, i;

  if (((dest)->code) == SUBREG)
    dest = ((dest)->fld[0].rtx);

  if (((dest)->code) == MEM)
    modified_mem = 1;

  if (((dest)->code) != REG)
    return;

  regno = ((dest)->fld[0].rtint);
  if (regno >= 68)
    modified_regs[regno] = 1;
  else
    for (i = 0; i < (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))); i++)
      modified_regs[regno + i] = 1;
}



void
thread_jumps(rtx f, int max_reg, int flag_before_loop) asm("_thread_jumps");
void
thread_jumps(rtx f, int max_reg, int flag_before_loop)
{
  rtx label, b1, b2, t1, t2;
  n64_enum_rtx_code code1, code2;
  rtx b1op0, b1op1, b2op0, b2op1;
  int changed = 1;
  int i;
  int *all_reset;


  modified_regs = (char *) 
                          __builtin_alloca((
                          max_reg * sizeof (char)
                          ))
                                                          ;
  same_regs = (int *) 
                     __builtin_alloca((
                     max_reg * sizeof (int)
                     ))
                                                    ;
  all_reset = (int *) 
                     __builtin_alloca((
                     max_reg * sizeof (int)
                     ))
                                                    ;
  for (i = 0; i < max_reg; i++)
    all_reset[i] = -1;

  while (changed)
    {
      changed = 0;

      for (b1 = f; b1; b1 = ((b1)->fld[2].rtx))
 {

   if (((b1)->code) != JUMP_INSN
       || ! condjump_p (b1) || simplejump_p (b1)
       || ((b1)->fld[7].rtx) == 0)
     continue;

   memset (modified_regs,0,max_reg * sizeof (char));
   modified_mem = 0;

   memcpy ((char *) same_regs,(char *) all_reset,max_reg * sizeof (int))
                          ;
   num_same_regs = 0;

   label = ((b1)->fld[7].rtx);




   for (b2 = ((label)->fld[2].rtx); b2; b2 = ((b2)->fld[2].rtx))
     {
       if (((b2)->code) == CODE_LABEL)
  break;

       else if (((b2)->code) == JUMP_INSN)
  {


    if (simplejump_p (b2)
        && ((b2)->fld[7].rtx) != 0
        && ((((b2)->fld[7].rtx))->fld[5].rtint) == 1)
      {
        b2 = ((b2)->fld[7].rtx);
        continue;
      }
    else
      break;
  }

       if (((b2)->code) != CALL_INSN && ((b2)->code) != INSN)
  continue;

       if (((b2)->code) == CALL_INSN)
  {
    modified_mem = 1;
    for (i = 0; i < 68; i++)
      if (call_used_regs[i] && ! fixed_regs[i]
   && i != (0 + 29)
   && i != (0 + 30)
   && i != (0 + 30)
   && i != 0)
        modified_regs[i] = 1;
  }

       note_stores (((b2)->fld[3].rtx), mark_modified_reg);
     }



   if (b2 == 0
       || ((b2)->code) != JUMP_INSN
       || b2 == b1
       || ! condjump_p (b2)
       || simplejump_p (b2))
     continue;




   b1op0 = ((((((((b1)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[0].rtx);
   b1op1 = ((((((((b1)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx);
   code1 = ((((((((b1)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->code);
   if (((((((b1)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) == pc_rtx)
     code1 = reverse_condition (code1);

   b2op0 = ((((((((b2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[0].rtx);
   b2op1 = ((((((((b2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx);
   code2 = ((((((((b2)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->code);
   if (((((((b2)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) == pc_rtx)
     code2 = reverse_condition (code2);




   if (rtx_equal_for_thread_p (b1op0, b2op0, b2)
       && rtx_equal_for_thread_p (b1op1, b2op1, b2)
       && (comparison_dominates_p (code1, code2)
    || comparison_dominates_p (code1, reverse_condition (code2))))
     {
       t1 = prev_nonnote_insn (b1);
       t2 = prev_nonnote_insn (b2);

       while (t1 != 0 && t2 != 0)
  {
    if (t2 == label)
      {





        rtx new_label;

        if (num_same_regs != 0)
   break;

        if (comparison_dominates_p (code1, code2))
         new_label = ((b2)->fld[7].rtx);
        else
   new_label = get_label_after (b2);

        if (((b1)->fld[7].rtx) != new_label)
   {
     rtx prev = ((new_label)->fld[1].rtx);

     if (flag_before_loop
         && ((prev)->fld[4].rtint) == -4)
       {



         new_label = gen_label_rtx ();
         emit_label_after (new_label, ((prev)->fld[1].rtx));
       }
     changed |= redirect_jump (b1, new_label);
   }
        break;
      }





    if (((t1)->code) != INSN || ((t2)->code) != INSN
        || recog_memoized (t1) != recog_memoized (t2)
        || ! rtx_equal_for_thread_p (((t1)->fld[3].rtx),
         ((t2)->fld[3].rtx), t2))
      break;

    t1 = prev_nonnote_insn (t1);
    t2 = prev_nonnote_insn (t2);
  }
     }
 }
    }
}







int
rtx_equal_for_thread_p(rtx x, rtx y, rtx yinsn) asm("_rtx_equal_for_thread_p");
int
rtx_equal_for_thread_p(rtx x, rtx y, rtx yinsn)
{
  register int i;
  register int j;
  register n64_enum_rtx_code code;
  register char *fmt;

  code = ((x)->code);

  if (code != ((y)->code))
    return 0;




  if (((x)->mode) != ((y)->mode))
    return 0;



  if (code == EQ || code == NE || (rtx_class[(int)(code)]) == 'c')
    return ((rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), yinsn)
      && rtx_equal_for_thread_p (((x)->fld[1].rtx), ((y)->fld[1].rtx), yinsn))
     || (rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[1].rtx), yinsn)
  && rtx_equal_for_thread_p (((x)->fld[1].rtx), ((y)->fld[0].rtx), yinsn)));
  else if ((rtx_class[(int)(code)]) == '<' || (rtx_class[(int)(code)]) == '2')
    return (rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), yinsn)
     && rtx_equal_for_thread_p (((x)->fld[1].rtx), ((y)->fld[1].rtx), yinsn));
  else if ((rtx_class[(int)(code)]) == '1')
    return rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), yinsn);


  switch (code)
    {
    case REG:
      if (((x)->fld[0].rtint) == ((y)->fld[0].rtint) && ! modified_regs[((x)->fld[0].rtint)])
        return 1;



      if (((x)->volatil) || ((y)->volatil)
   || ((x)->fld[0].rtint) < 68
   || ((y)->fld[0].rtint) < 68)
 return 0;

      if (same_regs[((x)->fld[0].rtint)] == -1)
 {
   same_regs[((x)->fld[0].rtint)] = ((y)->fld[0].rtint);
   num_same_regs++;




   if (regno_last_uid[((y)->fld[0].rtint)] != ((yinsn)->fld[0].rtint))
     return 0;

   return 1;
 }
      else
 return (same_regs[((x)->fld[0].rtint)] == ((y)->fld[0].rtint));

      break;

    case MEM:


      if (modified_mem || ((x)->volatil) || ((y)->volatil))
 return 0;

      return rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), yinsn);

    case ASM_INPUT:
      if (((x)->volatil) || ((y)->volatil))
 return 0;

      break;

    case SET:


      if (((((x)->fld[0].rtx))->code) == REG
          && ((((y)->fld[0].rtx))->code) == REG)
 {
          if (same_regs[((((x)->fld[0].rtx))->fld[0].rtint)] == ((((y)->fld[0].rtx))->fld[0].rtint))
     {
       same_regs[((((x)->fld[0].rtx))->fld[0].rtint)] = -1;
       num_same_regs--;
     }
   else if (((((x)->fld[0].rtx))->fld[0].rtint) != ((((y)->fld[0].rtx))->fld[0].rtint))
     return 0;
 }
      else
 if (rtx_equal_for_thread_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), yinsn) == 0)
   return 0;

      return rtx_equal_for_thread_p (((x)->fld[1].rtx), ((y)->fld[1].rtx), yinsn);

    case LABEL_REF:
      return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);

    case SYMBOL_REF:
      return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);
    }

  if (x == y)
    return 1;

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'n':
 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'V':
 case 'E':

   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;


   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (rtx_equal_for_thread_p (((x)->fld[i].rtvec->elem[j].rtx),
                ((y)->fld[i].rtvec->elem[j].rtx), yinsn) == 0)
       return 0;
   break;

 case 'e':
   if (rtx_equal_for_thread_p (((x)->fld[i].rtx), ((y)->fld[i].rtx), yinsn) == 0)
     return 0;
   break;

 case 'S':
 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'u':

   break;

 case '0':
   break;




 default:
   abort ();
 }
    }
  return 1;
}

