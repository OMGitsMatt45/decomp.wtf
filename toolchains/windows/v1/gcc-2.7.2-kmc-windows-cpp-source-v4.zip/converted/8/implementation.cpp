// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/c-typeck.c
/* Build expressions with type checking for C compiler.
   Copyright (C) 1987, 88, 91, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int error(...) asm("_error");
extern int pedwarn(...) asm("_pedwarn");
extern int warning(...) asm("_warning");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int put_var_into_stack(...) asm("_put_var_into_stack");
extern int error_with_decl(...) asm("_error_with_decl");
extern int expand_asm_operands(...) asm("_expand_asm_operands");
extern int expand_expr(...) asm("_expand_expr");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int emit_queue(...) asm("_emit_queue");
struct n64_tag_constructor_stack;
struct n64_tag_initializer_stack;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_spelling;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");

enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus, limbo_value;
};
extern int pedantic;
struct n64_tag_lang_type
{
  int len;
  tree elts[1];
};
extern tree lookup_interface (tree) asm("_lookup_interface");
extern tree is_class_name (tree) asm("_is_class_name");
extern void maybe_objc_check_decl (tree) asm("_maybe_objc_check_decl");
extern int maybe_objc_comptypes (tree, tree, int) asm("_maybe_objc_comptypes");
extern tree maybe_building_objc_message_expr (void) asm("_maybe_building_objc_message_expr");
extern tree maybe_objc_method_name (tree) asm("_maybe_objc_method_name");
extern int recognize_objc_keyword (void) asm("_recognize_objc_keyword");
extern tree build_objc_string (int, char *) asm("_build_objc_string");


extern void gen_aux_info_record (tree, int, int, int) asm("_gen_aux_info_record");


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree convert (tree, tree) asm("_convert");



extern tree char_array_type_node;
extern tree char_type_node;
extern tree const_ptr_type_node;
extern tree const_string_type_node;
extern tree default_function_type;
extern tree double_ftype_double;
extern tree double_ftype_double_double;
extern tree double_type_node;
extern tree float_type_node;
extern tree intDI_type_node;
extern tree intHI_type_node;
extern tree intQI_type_node;
extern tree intSI_type_node;
extern tree int_array_type_node;
extern tree int_ftype_cptr_cptr_sizet;
extern tree int_ftype_int;
extern tree int_ftype_ptr_ptr_int;
extern tree int_ftype_string_string;
extern tree integer_type_node;
extern tree long_double_type_node;
extern tree long_ftype_long;
extern tree long_integer_type_node;
extern tree long_long_integer_type_node;
extern tree long_long_unsigned_type_node;
extern tree long_unsigned_type_node;
extern tree complex_integer_type_node;
extern tree complex_float_type_node;
extern tree complex_double_type_node;
extern tree complex_long_double_type_node;
extern tree ptr_type_node;
extern tree ptrdiff_type_node;
extern tree short_integer_type_node;
extern tree short_unsigned_type_node;
extern tree signed_char_type_node;
extern tree signed_wchar_type_node;
extern tree string_ftype_ptr_ptr;
extern tree string_type_node;
extern tree unsigned_char_type_node;
extern tree unsigned_intDI_type_node;
extern tree unsigned_intHI_type_node;
extern tree unsigned_intQI_type_node;
extern tree unsigned_intSI_type_node;
extern tree unsigned_type_node;
extern tree unsigned_wchar_type_node;
extern tree void_ftype_ptr_int_int;
extern tree void_ftype_ptr_ptr_int;
extern tree void_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node;
extern tree boolean_type_node;
extern tree boolean_true_node;
extern tree boolean_false_node;

extern tree build_enumerator (tree, tree) asm("_build_enumerator");

extern tree builtin_function (char *, tree, n64_enum_built_in_function function_, char *) asm("_builtin_function");

extern tree c_build_type_variant (tree, int, int) asm("_c_build_type_variant");
extern int c_decode_option (char *) asm("_c_decode_option");
extern void c_mark_varargs (void) asm("_c_mark_varargs");
extern tree check_identifier (tree, tree) asm("_check_identifier");
extern void clear_parm_order (void) asm("_clear_parm_order");
extern tree combine_parm_decls (tree, tree, int) asm("_combine_parm_decls");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern void declare_parm_level (int) asm("_declare_parm_level");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void delete_block (tree) asm("_delete_block");
extern void finish_decl (tree, tree, tree) asm("_finish_decl");
extern void finish_decl_top_level (tree, tree, tree) asm("_finish_decl_top_level");
extern tree finish_enum (tree, tree, tree) asm("_finish_enum");
extern void finish_function (int) asm("_finish_function");
extern tree finish_struct (tree, tree, tree) asm("_finish_struct");
extern tree get_parm_info (int) asm("_get_parm_info");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern int global_bindings_p (void) asm("_global_bindings_p");
extern tree grokfield (char *, int, tree, tree, tree) asm("_grokfield");
extern tree groktypename (tree) asm("_groktypename");
extern tree groktypename_in_parm_context (tree) asm("_groktypename_in_parm_context");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern int in_parm_level_p (void) asm("_in_parm_level_p");
extern void init_decl_processing (void) asm("_init_decl_processing");
extern void insert_block (tree) asm("_insert_block");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree lookup_name (tree) asm("_lookup_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern tree lookup_name_current_level_global (tree) asm("_lookup_name_current_level_global");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void parmlist_tags_warning (void) asm("_parmlist_tags_warning");
extern void pending_xref_error (void) asm("_pending_xref_error");
extern void pop_c_function_context (void) asm("_pop_c_function_context");
extern void pop_label_level (void) asm("_pop_label_level");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void print_lang_decl (FILE *, tree, int) asm("_print_lang_decl")
                 ;
extern void print_lang_identifier (FILE *, tree, int) asm("_print_lang_identifier")
                 ;
extern void print_lang_type (FILE *, tree, int) asm("_print_lang_type")
                 ;
extern void push_c_function_context (void) asm("_push_c_function_context");
extern void push_label_level (void) asm("_push_label_level");
extern void push_parm_decl (tree) asm("_push_parm_decl");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void pushlevel (int) asm("_pushlevel");
extern void pushtag (tree, tree) asm("_pushtag");
extern void set_block (tree) asm("_set_block");
extern tree shadow_label (tree) asm("_shadow_label");
extern void shadow_record_fields (tree) asm("_shadow_record_fields");
extern void shadow_tag (tree) asm("_shadow_tag");
extern void shadow_tag_warned (tree, int) asm("_shadow_tag_warned");
extern tree start_enum (tree) asm("_start_enum");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function")
                        ;
extern tree start_decl (tree, tree, int, tree, tree) asm("_start_decl")
                         ;
extern tree start_struct (n64_enum_tree_code, tree) asm("_start_struct");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern tree xref_tag (n64_enum_tree_code, tree) asm("_xref_tag");


extern tree require_complete_type (tree) asm("_require_complete_type");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");


extern tree common_type (tree, tree) asm("_common_type");
extern int comptypes (tree, tree) asm("_comptypes");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_size_in_bytes (tree) asm("_c_size_in_bytes");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree c_alignof_expr (tree) asm("_c_alignof_expr");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_component_ref (tree, tree) asm("_build_component_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree parser_build_binary_op (n64_enum_tree_code, tree, tree) asm("_parser_build_binary_op")
                         ;
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op")
                              ;
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op")
                        ;
extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern void readonly_warning (tree, char *) asm("_readonly_warning");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_c_cast (tree, tree) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr")
                   ;
extern tree initializer_constant_valid_p (tree, tree) asm("_initializer_constant_valid_p");
extern void store_init_value (tree, tree) asm("_store_init_value");
extern void error_init (char *, char *, char *) asm("_error_init")
                     ;
extern void pedwarn_init (char *, char *, char *) asm("_pedwarn_init")
                     ;
extern void start_init (tree, tree, int) asm("_start_init");
extern void finish_init (void) asm("_finish_init");
extern void really_start_incremental_init (tree) asm("_really_start_incremental_init");
extern void push_init_level (int) asm("_push_init_level");
extern tree pop_init_level (int) asm("_pop_init_level");
extern void set_init_index (tree, tree) asm("_set_init_index");
extern void set_init_label (tree) asm("_set_init_label");
extern void process_init_element (tree) asm("_process_init_element");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands")
                               ;
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");


extern void iterator_expand (tree) asm("_iterator_expand");
extern void iterator_for_loop_start (tree) asm("_iterator_for_loop_start");
extern void iterator_for_loop_end (tree) asm("_iterator_for_loop_end");
extern void iterator_for_loop_record (tree) asm("_iterator_for_loop_record");
extern void push_iterator_stack (void) asm("_push_iterator_stack");
extern void pop_iterator_stack (void) asm("_pop_iterator_stack");




extern int current_function_returns_value;




extern int current_function_returns_null;



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_no_ident;



extern int warn_implicit;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;




extern int warn_redundant_decls;







extern int warn_nested_externs;




extern int warn_cast_qual;





extern int warn_bad_function_cast;



extern int warn_traditional;



extern int warn_format;



extern int warn_char_subscripts;



extern int warn_conversion;



extern int flag_traditional;



extern int flag_allow_single_precision;



extern int warn_parentheses;



extern int warn_missing_braces;




extern int (*comptypes_record_hook)(...);



extern int system_header_p;



extern int doing_objc_thang;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");
extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");
extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;
extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;



static int missing_braces_mentioned;

extern char *strchr(...) asm("_strchr");
extern char *strrchr(...) asm("_strrchr");

static tree quality_type (tree, tree) asm("_quality_type");
static int comp_target_types (tree, tree) asm("_comp_target_types");
static int function_types_compatible_p (tree, tree) asm("_function_types_compatible_p");
static int type_lists_compatible_p (tree, tree) asm("_type_lists_compatible_p");
static int self_promoting_type_p (tree) asm("_self_promoting_type_p");
static tree decl_constant_value (tree) asm("_decl_constant_value");
static tree lookup_field (tree, tree, tree *) asm("_lookup_field");
static tree convert_arguments (tree, tree, tree, tree) asm("_convert_arguments");
static tree pointer_int_sum (n64_enum_tree_code, tree, tree) asm("_pointer_int_sum");
static tree pointer_diff (tree, tree) asm("_pointer_diff");
static tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
static void pedantic_lvalue_warning (n64_enum_tree_code) asm("_pedantic_lvalue_warning");
static tree internal_build_compound_expr (tree, int) asm("_internal_build_compound_expr");
static tree convert_for_assignment (tree, tree, char *, tree, tree, int) asm("_convert_for_assignment")
                       ;
static void warn_for_assignment (char *, char *, tree, int) asm("_warn_for_assignment");
static tree valid_compound_expr_initializer (tree, tree) asm("_valid_compound_expr_initializer");
static void push_string (char *) asm("_push_string");
static void push_member_name (tree) asm("_push_member_name");
static void push_array_bounds (int) asm("_push_array_bounds");
static int spelling_length (void) asm("_spelling_length");
static char *print_spelling (char *) asm("_print_spelling");
static char *get_spelling (char *) asm("_get_spelling");
static void warning_init (char *, char *, char *) asm("_warning_init")
                    ;
static tree digest_init (tree, tree, int, int) asm("_digest_init");
static void check_init_type_bitfields (tree) asm("_check_init_type_bitfields");
static void output_init_element (tree, tree, tree, int) asm("_output_init_element");
static void output_pending_init_elements (int) asm("_output_pending_init_elements");




tree
require_complete_type(tree value) asm("_require_complete_type");
tree
require_complete_type(tree value)
{
  tree type = ((value)->common.type);


  if (((type)->type.size) != 0
      && type != void_type_node)
    return value;

  incomplete_type_error (value, type);
  return error_mark_node;
}





void
incomplete_type_error(tree value, tree type) asm("_incomplete_type_error");
void
incomplete_type_error(tree value, tree type)
{
  char *errmsg;


  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return;

  if (value != 0 && (((n64_enum_tree_code) (value)->common.code) == VAR_DECL
       || ((n64_enum_tree_code) (value)->common.code) == PARM_DECL))
    error ("`%s' has an incomplete type",
    ((((value)->decl.name))->identifier.pointer));
  else
    {
    retry:


      switch (((n64_enum_tree_code) (type)->common.code))
 {
 case RECORD_TYPE:
   errmsg = "invalid use of undefined type `struct %s'";
   break;

 case UNION_TYPE:
   errmsg = "invalid use of undefined type `union %s'";
   break;

 case ENUMERAL_TYPE:
   errmsg = "invalid use of undefined type `enum %s'";
   break;

 case VOID_TYPE:
   error ("invalid use of void expression");
   return;

 case ARRAY_TYPE:
   if (((type)->type.values))
     {
       type = ((type)->common.type);
       goto retry;
     }
   error ("invalid use of array with unspecified bounds");
   return;

 default:
   abort ();
 }

      if (((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE)
 error (errmsg, ((((type)->type.name))->identifier.pointer));
      else

 error ("invalid use of incomplete typedef `%s'",
        ((((((type)->type.name))->decl.name))->identifier.pointer));
    }
}




static tree
qualify_type(tree type, tree like) asm("_qualify_type");
static tree
qualify_type(tree type, tree like)
{
  int constflag = ((type)->common.readonly_flag) || ((like)->common.readonly_flag);
  int volflag = ((type)->common.volatile_flag) || ((like)->common.volatile_flag);
  return c_build_type_variant (type, constflag, volflag);
}
tree
common_type(tree t1, tree t2) asm("_common_type");
tree
common_type(tree t1, tree t2)
{
  register n64_enum_tree_code code1;
  register n64_enum_tree_code code2;
  tree attributes;



  if (t1 == t2) return t1;


  if (t1 == error_mark_node)
    return t2;
  if (t2 == error_mark_node)
    return t1;



  { register tree a1, a2;
    a1 = ((t1)->type.attributes);
    a2 = ((t2)->type.attributes);



    if (!(attributes = a1))
       attributes = a2;



    else if (a2 && !attribute_list_contained (a1, a2))
       if (attribute_list_contained (a2, a1))
   attributes = a2;
       else
 {



   if (list_length (a1) < list_length (a2))
      attributes = a2, a2 = a1;

   for (; a2; a2 = ((a2)->common.chain))
     if (lookup_attribute (((((a2)->list.purpose))->identifier.pointer),
      attributes) == (tree) 
                    ((void *)0)
                             )
       {
  a1 = copy_node (a2);
  ((a1)->common.chain) = attributes;
  attributes = a1;
       }
 }
  }



  if (((n64_enum_tree_code) (t1)->common.code) == ENUMERAL_TYPE)
    t1 = type_for_size (((t1)->type.precision), 1);
  if (((n64_enum_tree_code) (t2)->common.code) == ENUMERAL_TYPE)
    t2 = type_for_size (((t2)->type.precision), 1);

  code1 = ((n64_enum_tree_code) (t1)->common.code);
  code2 = ((n64_enum_tree_code) (t2)->common.code);




  if (code1 == COMPLEX_TYPE || code2 == COMPLEX_TYPE)
    {
      tree subtype1 = code1 == COMPLEX_TYPE ? ((t1)->common.type) : t1;
      tree subtype2 = code2 == COMPLEX_TYPE ? ((t2)->common.type) : t2;
      tree subtype = common_type (subtype1, subtype2);

      if (code1 == COMPLEX_TYPE && ((t1)->common.type) == subtype)
 return build_type_attribute_variant (t1, attributes);
      else if (code2 == COMPLEX_TYPE && ((t2)->common.type) == subtype)
 return build_type_attribute_variant (t2, attributes);
      else
 return build_type_attribute_variant (build_complex_type (subtype),
          attributes);
    }

  switch (code1)
    {
    case INTEGER_TYPE:
    case REAL_TYPE:


      if (code1 == REAL_TYPE && code2 != REAL_TYPE)
 return build_type_attribute_variant (t1, attributes);

      if (code2 == REAL_TYPE && code1 != REAL_TYPE)
 return build_type_attribute_variant (t2, attributes);



      if (((t1)->type.precision) > ((t2)->type.precision))
 return build_type_attribute_variant (t1, attributes);
      else if (((t2)->type.precision) > ((t1)->type.precision))
 return build_type_attribute_variant (t2, attributes);



      if (((t1)->type.main_variant) == long_unsigned_type_node
   || ((t2)->type.main_variant) == long_unsigned_type_node)
 return build_type_attribute_variant (long_unsigned_type_node,
          attributes);

      if (((t1)->type.main_variant) == long_integer_type_node
   || ((t2)->type.main_variant) == long_integer_type_node)
 {


   if (((t1)->common.unsigned_flag) || ((t2)->common.unsigned_flag))
      t1 = long_unsigned_type_node;
   else
      t1 = long_integer_type_node;
   return build_type_attribute_variant (t1, attributes);
 }



      if (((t1)->common.unsigned_flag))
 return build_type_attribute_variant (t1, attributes);
      else
 return build_type_attribute_variant (t2, attributes);

    case POINTER_TYPE:





      {
 tree target = common_type (((((t1)->common.type))->type.main_variant),
       ((((t2)->common.type))->type.main_variant));
 int constp
   = ((((t1)->common.type))->common.readonly_flag) || ((((t2)->common.type))->common.readonly_flag);
 int volatilep
   = ((((t1)->common.type))->common.volatile_flag) || ((((t2)->common.type))->common.volatile_flag);
 t1 = build_pointer_type (c_build_type_variant (target, constp,
     volatilep));
 return build_type_attribute_variant (t1, attributes);
      }





    case ARRAY_TYPE:
      {
 tree elt = common_type (((t1)->common.type), ((t2)->common.type));

 if (elt == ((t1)->common.type) && ((t1)->type.values))
   return build_type_attribute_variant (t1, attributes);
 if (elt == ((t2)->common.type) && ((t2)->type.values))
   return build_type_attribute_variant (t2, attributes);

 t1 = build_array_type (elt, ((((t1)->type.values) ? t1 : t2)->type.values));
 return build_type_attribute_variant (t1, attributes);
      }

    case FUNCTION_TYPE:


      {
 tree valtype = common_type (((t1)->common.type), ((t2)->common.type));
 tree p1 = ((t1)->type.values);
 tree p2 = ((t2)->type.values);
 int len;
 tree newargs, n;
 int i;


 if (valtype == ((t1)->common.type) && ! ((t2)->type.values))
   return build_type_attribute_variant (t1, attributes);
 if (valtype == ((t2)->common.type) && ! ((t1)->type.values))
   return build_type_attribute_variant (t2, attributes);


 if (((t1)->type.values) == 0)
  {
    t1 = build_function_type (valtype, ((t2)->type.values));
    return build_type_attribute_variant (t1, attributes);
  }
 if (((t2)->type.values) == 0)
  {
    t1 = build_function_type (valtype, ((t1)->type.values));
    return build_type_attribute_variant (t1, attributes);
  }




 len = list_length (p1);
 newargs = 0;

 for (i = 0; i < len; i++)
   newargs = tree_cons ((tree) 
                       ((void *)0)
                                , (tree) 
                                  ((void *)0)
                                           , newargs);

 n = newargs;

 for (; p1;
      p1 = ((p1)->common.chain), p2 = ((p2)->common.chain), n = ((n)->common.chain))
   {


     if (((p1)->list.value) == 0)
       {
  ((n)->list.value) = ((p2)->list.value);
  goto parm_done;
       }
     if (((p2)->list.value) == 0)
       {
  ((n)->list.value) = ((p1)->list.value);
  goto parm_done;
       }




     if (((n64_enum_tree_code) (((p1)->list.value))->common.code) == UNION_TYPE
  && ((p1)->list.value) != ((p2)->list.value))
       {
  tree memb;
  for (memb = ((((p1)->list.value))->type.values);
       memb; memb = ((memb)->common.chain))
    if (comptypes (((memb)->common.type), ((p2)->list.value)))
      {
        ((n)->list.value) = ((p2)->list.value);
        if (pedantic)
   pedwarn ("function types not truly compatible in ANSI C");
        goto parm_done;
      }
       }
     if (((n64_enum_tree_code) (((p2)->list.value))->common.code) == UNION_TYPE
  && ((p2)->list.value) != ((p1)->list.value))
       {
  tree memb;
  for (memb = ((((p2)->list.value))->type.values);
       memb; memb = ((memb)->common.chain))
    if (comptypes (((memb)->common.type), ((p1)->list.value)))
      {
        ((n)->list.value) = ((p1)->list.value);
        if (pedantic)
   pedwarn ("function types not truly compatible in ANSI C");
        goto parm_done;
      }
       }
     ((n)->list.value) = common_type (((p1)->list.value), ((p2)->list.value));
   parm_done: ;
   }

 t1 = build_function_type (valtype, newargs);

      }

    default:
      return build_type_attribute_variant (t1, attributes);
    }

}





int
comptypes(tree type1, tree type2) asm("_comptypes");
int
comptypes(tree type1, tree type2)
{
  register tree t1 = type1;
  register tree t2 = type2;
  int attrval, val;



  if (t1 == t2 || ((n64_enum_tree_code) (t1)->common.code) == ERROR_MARK || ((n64_enum_tree_code) (t2)->common.code) == ERROR_MARK)
    return 1;




  if (((n64_enum_tree_code) (t1)->common.code) == ENUMERAL_TYPE)
    t1 = type_for_size (((t1)->type.precision), ((t1)->common.unsigned_flag));
  if (((n64_enum_tree_code) (t2)->common.code) == ENUMERAL_TYPE)
    t2 = type_for_size (((t2)->type.precision), ((t2)->common.unsigned_flag));

  if (t1 == t2)
    return 1;



  if (((n64_enum_tree_code) (t1)->common.code) != ((n64_enum_tree_code) (t2)->common.code)) return 0;



  if (((t1)->common.readonly_flag) != ((t2)->common.readonly_flag))
    return 0;
  if (((t1)->common.volatile_flag) != ((t2)->common.volatile_flag))
    return 0;





  if (((t1)->type.main_variant) == ((t2)->type.main_variant))
    return 1;






  if (! (attrval = 1))
     return 0;


  val = 0;

  switch (((n64_enum_tree_code) (t1)->common.code))
    {
    case POINTER_TYPE:
      val = (((t1)->common.type) == ((t2)->common.type)
       ? 1 : comptypes (((t1)->common.type), ((t2)->common.type)));
      break;

    case FUNCTION_TYPE:
      val = function_types_compatible_p (t1, t2);
      break;

    case ARRAY_TYPE:
      {
 tree d1 = ((t1)->type.values);
 tree d2 = ((t2)->type.values);
 val = 1;


 if (((t1)->common.type) != ((t2)->common.type)
     && 0 == (val = comptypes (((t1)->common.type), ((t2)->common.type))))
   return 0;


 if (d1 == 0 || d2 == 0 || d1 == d2
     || ((n64_enum_tree_code) (((d1)->type.minval))->common.code) != INTEGER_CST
     || ((n64_enum_tree_code) (((d2)->type.minval))->common.code) != INTEGER_CST
     || ((n64_enum_tree_code) (((d1)->type.maxval))->common.code) != INTEGER_CST
     || ((n64_enum_tree_code) (((d2)->type.maxval))->common.code) != INTEGER_CST)
   break;

 if (! ((((((d1)->type.minval))->int_cst.int_cst_low)
    == ((((d2)->type.minval))->int_cst.int_cst_low))
   && (((((d1)->type.minval))->int_cst.int_cst_high)
       == ((((d2)->type.minval))->int_cst.int_cst_high))
   && (((((d1)->type.maxval))->int_cst.int_cst_low)
       == ((((d2)->type.maxval))->int_cst.int_cst_low))
   && (((((d1)->type.maxval))->int_cst.int_cst_high)
       == ((((d2)->type.maxval))->int_cst.int_cst_high))))
    val = 0;
        break;
      }

    case RECORD_TYPE:
      if (maybe_objc_comptypes (t1, t2, 0) == 1)
 val = 1;
      break;
    }
  return attrval == 2 && val == 1 ? 2 : val;
}




static int
comp_target_types(tree ttl, tree ttr) asm("_comp_target_types");
static int
comp_target_types(tree ttl, tree ttr)
{
  int val;


  if (val = maybe_objc_comptypes (ttl, ttr, 1) >= 0)
    return val;

  val = comptypes (((((ttl)->common.type))->type.main_variant),
     ((((ttr)->common.type))->type.main_variant));

  if (val == 2 && pedantic)
    pedwarn ("types are not quite compatible");
  return val;
}
static int
function_types_compatible_p(tree f1, tree f2) asm("_function_types_compatible_p");
static int
function_types_compatible_p(tree f1, tree f2)
{
  tree args1, args2;

  int val = 1;
  int val1;

  if (!(((f1)->common.type) == ((f2)->common.type)
 || (val = comptypes (((f1)->common.type), ((f2)->common.type)))))
    return 0;

  args1 = ((f1)->type.values);
  args2 = ((f2)->type.values);




  if (args1 == 0)
    {
      if (!self_promoting_args_p (args2))
 return 0;



      if (((f1)->type.noncopied_parts)
   && 1 != type_lists_compatible_p (args2, ((f1)->type.noncopied_parts)))
 val = 2;
      return val;
    }
  if (args2 == 0)
    {
      if (!self_promoting_args_p (args1))
 return 0;
      if (((f2)->type.noncopied_parts)
   && 1 != type_lists_compatible_p (args1, ((f2)->type.noncopied_parts)))
 val = 2;
      return val;
    }


  val1 = type_lists_compatible_p (args1, args2);
  return val1 != 1 ? val1 : val;
}





static int
type_lists_compatible_p(tree args1, tree args2) asm("_type_lists_compatible_p");
static int
type_lists_compatible_p(tree args1, tree args2)
{

  int val = 1;
  int newval = 0;

  while (1)
    {
      if (args1 == 0 && args2 == 0)
 return val;


      if (args1 == 0 || args2 == 0)
 return 0;




      if (((args1)->list.value) == 0)
 {
   if (! self_promoting_type_p (((args2)->list.value)))
     return 0;
 }
      else if (((args2)->list.value) == 0)
 {
   if (! self_promoting_type_p (((args1)->list.value)))
     return 0;
 }
      else if (! (newval = comptypes (((args1)->list.value), ((args2)->list.value))))
 {


   if (((n64_enum_tree_code) (((args1)->list.value))->common.code) == UNION_TYPE
       && (((((args1)->list.value))->type.name) == 0
    || ((((args1)->list.value))->type.transparent_union_flag))
       && ((n64_enum_tree_code) (((((args1)->list.value))->type.size))->common.code) == INTEGER_CST
       && tree_int_cst_equal (((((args1)->list.value))->type.size),
         ((((args2)->list.value))->type.size)))
     {
       tree memb;
       for (memb = ((((args1)->list.value))->type.values);
     memb; memb = ((memb)->common.chain))
  if (comptypes (((memb)->common.type), ((args2)->list.value)))
    break;
       if (memb == 0)
  return 0;
     }
   else if (((n64_enum_tree_code) (((args2)->list.value))->common.code) == UNION_TYPE
     && (((((args2)->list.value))->type.name) == 0
         || ((((args2)->list.value))->type.transparent_union_flag))
     && ((n64_enum_tree_code) (((((args2)->list.value))->type.size))->common.code) == INTEGER_CST
     && tree_int_cst_equal (((((args2)->list.value))->type.size),
       ((((args1)->list.value))->type.size)))
     {
       tree memb;
       for (memb = ((((args2)->list.value))->type.values);
     memb; memb = ((memb)->common.chain))
  if (comptypes (((memb)->common.type), ((args1)->list.value)))
    break;
       if (memb == 0)
  return 0;
     }
   else
     return 0;
 }


      if (newval > val)
 val = newval;

      args1 = ((args1)->common.chain);
      args2 = ((args2)->common.chain);
    }
}




int
self_promoting_args_p(tree parms) asm("_self_promoting_args_p");
int
self_promoting_args_p(tree parms)
{
  register tree t;
  for (t = parms; t; t = ((t)->common.chain))
    {
      register tree type = ((t)->list.value);

      if (((t)->common.chain) == 0 && type != void_type_node)
 return 0;

      if (type == 0)
 return 0;

      if (((type)->type.main_variant) == float_type_node)
 return 0;

      if ((((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
 return 0;
    }
  return 1;
}



static int
self_promoting_type_p(tree type) asm("_self_promoting_type_p");
static int
self_promoting_type_p(tree type)
{
  if (((type)->type.main_variant) == float_type_node)
    return 0;

  if ((((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
    return 0;

  return 1;
}



tree
unsigned_type(tree type) asm("_unsigned_type");
tree
unsigned_type(tree type)
{
  tree type1 = ((type)->type.main_variant);
  if (type1 == signed_char_type_node || type1 == char_type_node)
    return unsigned_char_type_node;
  if (type1 == integer_type_node)
    return unsigned_type_node;
  if (type1 == short_integer_type_node)
    return short_unsigned_type_node;
  if (type1 == long_integer_type_node)
    return long_unsigned_type_node;
  if (type1 == long_long_integer_type_node)
    return long_long_unsigned_type_node;
  if (type1 == intDI_type_node)
    return unsigned_intDI_type_node;
  if (type1 == intSI_type_node)
    return unsigned_intSI_type_node;
  if (type1 == intHI_type_node)
    return unsigned_intHI_type_node;
  if (type1 == intQI_type_node)
    return unsigned_intQI_type_node;
  return type;
}



tree
signed_type(tree type) asm("_signed_type");
tree
signed_type(tree type)
{
  tree type1 = ((type)->type.main_variant);
  if (type1 == unsigned_char_type_node || type1 == char_type_node)
    return signed_char_type_node;
  if (type1 == unsigned_type_node)
    return integer_type_node;
  if (type1 == short_unsigned_type_node)
    return short_integer_type_node;
  if (type1 == long_unsigned_type_node)
    return long_integer_type_node;
  if (type1 == long_long_unsigned_type_node)
    return long_long_integer_type_node;
  if (type1 == unsigned_intDI_type_node)
    return intDI_type_node;
  if (type1 == unsigned_intSI_type_node)
    return intSI_type_node;
  if (type1 == unsigned_intHI_type_node)
    return intHI_type_node;
  if (type1 == unsigned_intQI_type_node)
    return intQI_type_node;
  return type;
}




tree
signed_or_unsigned_type(int unsignedp, tree type) asm("_signed_or_unsigned_type");
tree
signed_or_unsigned_type(int unsignedp, tree type)
{
  if (! (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE))
    return type;
  if (((type)->type.precision) == ((signed_char_type_node)->type.precision))
    return unsignedp ? unsigned_char_type_node : signed_char_type_node;
  if (((type)->type.precision) == ((integer_type_node)->type.precision))
    return unsignedp ? unsigned_type_node : integer_type_node;
  if (((type)->type.precision) == ((short_integer_type_node)->type.precision))
    return unsignedp ? short_unsigned_type_node : short_integer_type_node;
  if (((type)->type.precision) == ((long_integer_type_node)->type.precision))
    return unsignedp ? long_unsigned_type_node : long_integer_type_node;
  if (((type)->type.precision) == ((long_long_integer_type_node)->type.precision))
    return (unsignedp ? long_long_unsigned_type_node
     : long_long_integer_type_node);
  return type;
}



tree
c_sizeof(tree type) asm("_c_sizeof");
tree
c_sizeof(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("sizeof applied to a function type");
      return size_int (1);
    }
  if (code == VOID_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("sizeof applied to a void type");
      return size_int (1);
    }
  if (code == ERROR_MARK)
    return size_int (1);
  if (((type)->type.size) == 0)
    {
      error ("sizeof applied to an incomplete type");
      return size_int (0);
    }


  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
    size_int (((char_type_node)->type.precision)));

  if (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST && force_fit_type (t, 0))
    ((t)->common.static_flag) = ((t)->common.public_flag) = 1;
  return t;
}

tree
c_sizeof_nowarn(tree type) asm("_c_sizeof_nowarn");
tree
c_sizeof_nowarn(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE
      || code == VOID_TYPE
      || code == ERROR_MARK)
    return size_int (1);
  if (((type)->type.size) == 0)
    return size_int (0);


  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
    size_int (((char_type_node)->type.precision)));
  force_fit_type (t, 0);
  return t;
}



tree
c_size_in_bytes(tree type) asm("_c_size_in_bytes");
tree
c_size_in_bytes(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE)
    return size_int (1);
  if (code == VOID_TYPE)
    return size_int (1);
  if (code == ERROR_MARK)
    return size_int (1);
  if (((type)->type.size) == 0)
    {
      error ("arithmetic on pointer to an incomplete type");
      return size_int (1);
    }


  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
       size_int (8));
  force_fit_type (t, 0);
  return t;
}




tree
c_alignof(tree type) asm("_c_alignof");
tree
c_alignof(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);

  if (code == FUNCTION_TYPE)
    return size_int (32 / 8);

  if (code == VOID_TYPE || code == ERROR_MARK)
    return size_int (1);

  return size_int (((type)->type.align) / 8);
}






tree
c_alignof_expr(tree expr) asm("_c_alignof_expr");
tree
c_alignof_expr(tree expr)
{
  if (((n64_enum_tree_code) (expr)->common.code) == VAR_DECL)
    return size_int (((expr)->decl.frame_size.u) / 8);

  if (((n64_enum_tree_code) (expr)->common.code) == COMPONENT_REF
      && ((((expr)->exp.operands[1]))->decl.bit_field_flag))
    {
      error ("`__alignof' applied to a bit-field");
      return size_int (1);
    }
  else if (((n64_enum_tree_code) (expr)->common.code) == COMPONENT_REF
      && ((n64_enum_tree_code) (((expr)->exp.operands[1]))->common.code) == FIELD_DECL)
    return size_int (((((expr)->exp.operands[1]))->decl.frame_size.u) / 8);

  if (((n64_enum_tree_code) (expr)->common.code) == INDIRECT_REF)
    {
      tree t = ((expr)->exp.operands[0]);
      tree best = t;
      int bestalign = ((((((t)->common.type))->common.type))->type.align);

      while (((n64_enum_tree_code) (t)->common.code) == NOP_EXPR
       && ((n64_enum_tree_code) (((((t)->exp.operands[0]))->common.type))->common.code) == POINTER_TYPE)
 {
   int thisalign;

   t = ((t)->exp.operands[0]);
   thisalign = ((((((t)->common.type))->common.type))->type.align);
   if (thisalign > bestalign)
     best = t, bestalign = thisalign;
 }
      return c_alignof (((((best)->common.type))->common.type));
    }
  else
    return c_alignof (((expr)->common.type));
}


static tree
decl_constant_value(tree decl) asm("_decl_constant_value");
static tree
decl_constant_value(tree decl)
{
  if (! ((decl)->common.public_flag)


      && current_function_decl != 0
      && ! pedantic
      && ! ((decl)->common.volatile_flag)
      && ((decl)->common.readonly_flag) && ! (((decl)->decl.lang_flag_4))
      && ((decl)->decl.initial) != 0
      && ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) != ERROR_MARK



      && ((((decl)->decl.initial))->common.constant_flag)

      && ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) != CONSTRUCTOR
      && ((decl)->decl.mode) != BLKmode)
    return ((decl)->decl.initial);
  return decl;
}






tree
default_conversion(tree exp) asm("_default_conversion");
tree
default_conversion(tree exp)
{
  register tree type = ((exp)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);


  if (((n64_enum_tree_code) (exp)->common.code) == CONST_DECL)
    exp = ((exp)->decl.initial);




  else if (optimize && ((n64_enum_tree_code) (exp)->common.code) == VAR_DECL && code != ARRAY_TYPE)
    {
      exp = decl_constant_value (exp);
      type = ((exp)->common.type);
    }





  while (((n64_enum_tree_code) (exp)->common.code) == NON_LVALUE_EXPR
  || (((n64_enum_tree_code) (exp)->common.code) == NOP_EXPR
      && ((((exp)->exp.operands[0]))->common.type) == ((exp)->common.type)))
    exp = ((exp)->exp.operands[0]);



  if (code == ENUMERAL_TYPE)
    {
      type = type_for_size (((((type)->type.precision)) > (((integer_type_node)->type.precision)) ? (((type)->type.precision)) : (((integer_type_node)->type.precision)))
                                        ,
       ((flag_traditional
         || ((type)->type.precision) >= ((integer_type_node)->type.precision))
        && ((type)->common.unsigned_flag)));
      return convert (type, exp);
    }

  if ((((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
    {


      if (((type)->common.unsigned_flag)
   && (flag_traditional
       || ((type)->type.precision) == ((integer_type_node)->type.precision)))
 return convert (unsigned_type_node, exp);
      return convert (integer_type_node, exp);
    }
  if (flag_traditional && !flag_allow_single_precision
      && ((type)->type.main_variant) == float_type_node)
    return convert (double_type_node, exp);
  if (code == VOID_TYPE)
    {
      error ("void value not ignored as it ought to be");
      return error_mark_node;
    }
  if (code == FUNCTION_TYPE)
    {
      return build_unary_op (ADDR_EXPR, exp, 0);
    }
  if (code == ARRAY_TYPE)
    {
      register tree adr;
      tree restype = ((type)->common.type);
      tree ptrtype;
      int constp = 0;
      int volatilep = 0;

      if ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'r'
   || (*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd')
 {
   constp = ((exp)->common.readonly_flag);
   volatilep = ((exp)->common.volatile_flag);
 }

      if (((type)->common.readonly_flag) || ((type)->common.volatile_flag)
   || constp || volatilep)
 restype = c_build_type_variant (restype,
     ((type)->common.readonly_flag) || constp,
     ((type)->common.volatile_flag) || volatilep);

      if (((n64_enum_tree_code) (exp)->common.code) == INDIRECT_REF)
 return convert (((restype)->type.pointer_to),
   ((exp)->exp.operands[0]));

      if (((n64_enum_tree_code) (exp)->common.code) == COMPOUND_EXPR)
 {
   tree op1 = default_conversion (((exp)->exp.operands[1]));
   return build (COMPOUND_EXPR, ((op1)->common.type),
   ((exp)->exp.operands[0]), op1);
 }

      if (!lvalue_p (exp)
   && ! (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR && ((exp)->common.static_flag)))
 {
   error ("invalid use of non-lvalue array");
   return error_mark_node;
 }

      ptrtype = build_pointer_type (restype);

      if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL)
 {




   adr = build1 (ADDR_EXPR, ptrtype, exp);
   if (mark_addressable (exp) == 0)
     return error_mark_node;
   ((adr)->common.constant_flag) = staticp (exp);
   ((adr)->common.side_effects_flag) = 0;
   return adr;
 }


      adr = build_unary_op (ADDR_EXPR, exp, 1);
      return convert (ptrtype, adr);
    }
  return exp;
}







static tree
lookup_field(tree type, tree component, tree *indirect) asm("_lookup_field");
static tree
lookup_field(tree type, tree component, tree *indirect)
{
  tree field;






  if (((type)->type.lang_specific))
    {
      int bot, top, half;
      tree *field_array = &((type)->type.lang_specific)->elts[0];

      field = ((type)->type.values);
      bot = 0;
      top = ((type)->type.lang_specific)->len;
      while (top - bot > 1)
 {
   half = (top - bot + 1) >> 1;
   field = field_array[bot+half];

   if (((field)->decl.name) == (tree) 
                           ((void *)0)
                                    )
     {

       while (((field_array[bot])->decl.name) == (tree) 
                                             ((void *)0)
                                                      )
  {
    tree anon, junk;

    field = field_array[bot++];
    anon = lookup_field (((field)->common.type), component, &junk);
    if (anon != (tree) 
               ((void *)0)
                        )
      {
        *indirect = field;
        return anon;
      }
  }


       if (bot > top)
  return (tree) 
        ((void *)0)
                 ;


       continue;
     }

   if (((field)->decl.name) == component)
     break;
   if (((field)->decl.name) < component)
     bot += half;
   else
     top = bot + half;
 }

      if (((field_array[bot])->decl.name) == component)
 field = field_array[bot];
      else if (((field)->decl.name) != component)
 field = 0;
    }
  else
    {
      for (field = ((type)->type.values); field; field = ((field)->common.chain))
 {
   if (((field)->decl.name) == (tree) 
                           ((void *)0)
                                    )
     {
       tree junk;
       tree anon = lookup_field (((field)->common.type), component, &junk);
       if (anon != (tree) 
                  ((void *)0)
                           )
  {
    *indirect = field;
    return anon;
  }
     }

   if (((field)->decl.name) == component)
     break;
 }
    }

  *indirect = (tree) 
             ((void *)0)
                      ;
  return field;
}




tree
build_component_ref(tree datum, tree component) asm("_build_component_ref");
tree
build_component_ref(tree datum, tree component)
{
  register tree type = ((datum)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  register tree field = 
                       ((void *)0)
                           ;
  register tree ref;



  switch (((n64_enum_tree_code) (datum)->common.code))
    {
    case COMPOUND_EXPR:
      {
 tree value = build_component_ref (((datum)->exp.operands[1]), component);
 return build (COMPOUND_EXPR, ((value)->common.type),
        ((datum)->exp.operands[0]), value);
      }
    case COND_EXPR:
      return build_conditional_expr
 (((datum)->exp.operands[0]),
  build_component_ref (((datum)->exp.operands[1]), component),
  build_component_ref (((datum)->exp.operands[2]), component));
    }



  if (code == RECORD_TYPE || code == UNION_TYPE)
    {
      tree indirect = 0;

      if (((type)->type.size) == 0)
 {
   incomplete_type_error ((tree) 
                         ((void *)0)
                                  , type);
   return error_mark_node;
 }

      field = lookup_field (type, component, &indirect);

      if (!field)
 {
   error (code == RECORD_TYPE
   ? "structure has no member named `%s'"
   : "union has no member named `%s'",
   ((component)->identifier.pointer));
   return error_mark_node;
 }
      if (((field)->common.type) == error_mark_node)
 return error_mark_node;




      if (indirect != 0)
 {
   ref = build (COMPONENT_REF, ((indirect)->common.type), datum, indirect);
   if (((datum)->common.readonly_flag) || ((indirect)->common.readonly_flag))
     ((ref)->common.readonly_flag) = 1;
   if (((datum)->common.volatile_flag) || ((indirect)->common.volatile_flag))
     ((ref)->common.volatile_flag) = 1;
   datum = ref;
 }

      ref = build (COMPONENT_REF, ((field)->common.type), datum, field);

      if (((datum)->common.readonly_flag) || ((field)->common.readonly_flag))
 ((ref)->common.readonly_flag) = 1;
      if (((datum)->common.volatile_flag) || ((field)->common.volatile_flag))
 ((ref)->common.volatile_flag) = 1;

      return ref;
    }
  else if (code != ERROR_MARK)
    error ("request for member `%s' in something not a structure or union",
     ((component)->identifier.pointer));

  return error_mark_node;
}





tree
build_indirect_ref(tree ptr, char *errorstring) asm("_build_indirect_ref");
tree
build_indirect_ref(tree ptr, char *errorstring)
{
  register tree pointer = default_conversion (ptr);
  register tree type = ((pointer)->common.type);

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE)
    {
      if (((n64_enum_tree_code) (pointer)->common.code) == ADDR_EXPR
   && !flag_volatile
   && (((((pointer)->exp.operands[0]))->common.type)
       == ((type)->common.type)))
 return ((pointer)->exp.operands[0]);
      else
 {
   tree t = ((type)->common.type);
   register tree ref = build1 (INDIRECT_REF,
          ((t)->type.main_variant), pointer);

   if (((t)->type.size) == 0 && ((n64_enum_tree_code) (t)->common.code) != ARRAY_TYPE)
     {
       error ("dereferencing pointer to incomplete type");
       return error_mark_node;
     }
   if (((n64_enum_tree_code) (t)->common.code) == VOID_TYPE)
     warning ("dereferencing `void *' pointer");
   ((ref)->common.readonly_flag) = ((t)->common.readonly_flag);
   ((ref)->common.side_effects_flag)
     = ((t)->common.volatile_flag) || ((pointer)->common.side_effects_flag) || flag_volatile;
   ((ref)->common.volatile_flag) = ((t)->common.volatile_flag);
   return ref;
 }
    }
  else if (((n64_enum_tree_code) (pointer)->common.code) != ERROR_MARK)
    error ("invalid type argument of `%s'", errorstring);
  return error_mark_node;
}
tree
build_array_ref(tree array, tree strchr) asm("_build_array_ref");
tree
build_array_ref(tree array, tree strchr)
{
  if (strchr == 0)
    {
      error ("subscript missing in array reference");
      return error_mark_node;
    }

  if (((array)->common.type) == error_mark_node
      || ((strchr)->common.type) == error_mark_node)
    return error_mark_node;

  if (((n64_enum_tree_code) (((array)->common.type))->common.code) == ARRAY_TYPE
      && ((n64_enum_tree_code) (array)->common.code) != INDIRECT_REF)
    {
      tree rval, type;







      if (warn_char_subscripts
   && ((((strchr)->common.type))->type.main_variant) == char_type_node)
 warning ("array subscript has type `char'");


      strchr = default_conversion (strchr);


      if (((n64_enum_tree_code) (((strchr)->common.type))->common.code) != INTEGER_TYPE)
 {
   error ("array subscript is not an integer");
   return error_mark_node;
 }





      if (((n64_enum_tree_code) (strchr)->common.code) != INTEGER_CST
   || (((((((array)->common.type))->common.type))->type.size) != 0
       && ((n64_enum_tree_code) (((((((array)->common.type))->common.type))->type.size))->common.code) != INTEGER_CST))
 {
   if (mark_addressable (array) == 0)
     return error_mark_node;
 }




      if (((n64_enum_tree_code) (strchr)->common.code) == INTEGER_CST
   && ((((array)->common.type))->type.values)
   && ! int_fits_type_p (strchr, ((((array)->common.type))->type.values)))
 {
   if (mark_addressable (array) == 0)
     return error_mark_node;
 }

      if (pedantic && !lvalue_p (array))
 {
   if (((array)->decl.regdecl_flag))
     pedwarn ("ANSI C forbids subscripting `register' array");
   else
     pedwarn ("ANSI C forbids subscripting non-lvalue array");
 }

      if (pedantic)
 {
   tree foo = array;
   while (((n64_enum_tree_code) (foo)->common.code) == COMPONENT_REF)
     foo = ((foo)->exp.operands[0]);
   if (((n64_enum_tree_code) (foo)->common.code) == VAR_DECL && ((foo)->decl.regdecl_flag))
     pedwarn ("ANSI C forbids subscripting non-lvalue array");
 }

      type = ((((((array)->common.type))->common.type))->type.main_variant);
      rval = build (ARRAY_REF, type, array, strchr);


      ((rval)->common.readonly_flag)
 |= (((((((array)->common.type))->common.type))->common.readonly_flag)
     | ((array)->common.readonly_flag));
      ((rval)->common.side_effects_flag)
 |= (((((((array)->common.type))->common.type))->common.volatile_flag)
     | ((array)->common.side_effects_flag));
      ((rval)->common.volatile_flag)
 |= (((((((array)->common.type))->common.type))->common.volatile_flag)




     | ((array)->common.volatile_flag));
      return require_complete_type (fold (rval));
    }

  {
    tree ar = default_conversion (array);
    tree ind = default_conversion (strchr);


    if (((n64_enum_tree_code) (((ar)->common.type))->common.code) == INTEGER_TYPE)
      {
 tree temp = ar;
 ar = ind;
 ind = temp;
      }

    if (ar == error_mark_node)
      return ar;

    if (((n64_enum_tree_code) (((ar)->common.type))->common.code) != POINTER_TYPE)
      {
 error ("subscripted value is neither array nor pointer");
 return error_mark_node;
      }
    if (((n64_enum_tree_code) (((ind)->common.type))->common.code) != INTEGER_TYPE)
      {
 error ("array subscript is not an integer");
 return error_mark_node;
      }

    return build_indirect_ref (build_binary_op (PLUS_EXPR, ar, ind, 0),
          "array indexing");
  }
}






tree
build_function_call(tree function, tree params) asm("_build_function_call");
tree
build_function_call(tree function, tree params)
{
  register tree fntype, fundecl = 0;
  register tree coerced_params;
  tree name = (tree) 
             ((void *)0)
                      , assembler_name = (tree) 
                                         ((void *)0)
                                                  ;


  while ((((n64_enum_tree_code) (function)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (function)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (function)->common.code) == NON_LVALUE_EXPR) && (((function)->common.type) == ((((function)->exp.operands[0]))->common.type))) (function) = ((function)->exp.operands[0]);;


  if (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL)
    {
      name = ((function)->decl.name);
      assembler_name = ((function)->decl.assembler_name);




      fntype = build_type_variant (((function)->common.type),
       ((function)->common.readonly_flag),
       ((function)->common.volatile_flag));
      fundecl = function;
      function = build1 (ADDR_EXPR, build_pointer_type (fntype), function);
    }
  else
    function = default_conversion (function);

  fntype = ((function)->common.type);

  if (((n64_enum_tree_code) (fntype)->common.code) == ERROR_MARK)
    return error_mark_node;

  if (!(((n64_enum_tree_code) (fntype)->common.code) == POINTER_TYPE
 && ((n64_enum_tree_code) (((fntype)->common.type))->common.code) == FUNCTION_TYPE))
    {
      error ("called object is not a function");
      return error_mark_node;
    }


  fntype = ((fntype)->common.type);




  coerced_params
    = convert_arguments (((fntype)->type.values), params, name, fundecl);



  if (warn_format && (name || assembler_name))
    check_function_format (name, assembler_name, coerced_params);





  if (((n64_enum_tree_code) (function)->common.code) == ADDR_EXPR
      && ((n64_enum_tree_code) (((function)->exp.operands[0]))->common.code) == FUNCTION_DECL
      && ((((function)->exp.operands[0]))->decl.bit_field_flag))
    switch (((((function)->exp.operands[0]))->decl.frame_size.f))
      {
      case BUILT_IN_ABS:
      case BUILT_IN_LABS:
      case BUILT_IN_FABS:
 if (coerced_params == 0)
   return integer_zero_node;
 return build_unary_op (ABS_EXPR, ((coerced_params)->list.value), 0);
      }

  {
    register tree result
      = build (CALL_EXPR, ((fntype)->common.type),
        function, coerced_params, (tree) 
                                 ((void *)0)
                                          );

    ((result)->common.side_effects_flag) = 1;
    if (((result)->common.type) == void_type_node)
      return result;
    return require_complete_type (result);
  }
}
static tree
convert_arguments(tree typelist, tree values, tree name, tree fundecl) asm("_convert_arguments");
static tree
convert_arguments(tree typelist, tree values, tree name, tree fundecl)
{
  register tree typetail, valtail;
  register tree result = 
                        ((void *)0)
                            ;
  int parmnum;




  for (valtail = values, typetail = typelist, parmnum = 0;
       valtail;
       valtail = ((valtail)->common.chain), parmnum++)
    {
      register tree type = typetail ? ((typetail)->list.value) : 0;
      register tree val = ((valtail)->list.value);

      if (type == void_type_node)
 {
   if (name)
     error ("too many arguments to function `%s'",
     ((name)->identifier.pointer));
   else
     error ("too many arguments to function");
   break;
 }




      if (((n64_enum_tree_code) (val)->common.code) == NON_LVALUE_EXPR)
 val = ((val)->exp.operands[0]);

      if (((n64_enum_tree_code) (((val)->common.type))->common.code) == ARRAY_TYPE
   || ((n64_enum_tree_code) (((val)->common.type))->common.code) == FUNCTION_TYPE)
 val = default_conversion (val);

      val = require_complete_type (val);

      if (type != 0)
 {

   tree parmval;

   if (((type)->type.size) == 0)
     {
       error ("type of formal parameter %d is incomplete", parmnum + 1);
       parmval = val;
     }
   else
     {


       if (warn_conversion)
  {
    int formal_prec = ((type)->type.precision);

    if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE)
        && ((n64_enum_tree_code) (((val)->common.type))->common.code) == REAL_TYPE)
      warn_for_assignment ("%s as integer rather than floating due to prototype", (char *) 0, name, parmnum + 1);
    else if (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE
      && ((n64_enum_tree_code) (((val)->common.type))->common.code) == REAL_TYPE)
      warn_for_assignment ("%s as complex rather than floating due to prototype", (char *) 0, name, parmnum + 1);
    else if (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE
      && (((n64_enum_tree_code) (((val)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == CHAR_TYPE))
      warn_for_assignment ("%s as floating rather than integer due to prototype", (char *) 0, name, parmnum + 1);
    else if (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE
      && ((n64_enum_tree_code) (((val)->common.type))->common.code) == COMPLEX_TYPE)
      warn_for_assignment ("%s as floating rather than complex due to prototype", (char *) 0, name, parmnum + 1);



    else if (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE
      && ((n64_enum_tree_code) (((val)->common.type))->common.code) == REAL_TYPE)
      {


        if (formal_prec == ((float_type_node)->type.precision))
   warn_for_assignment ("%s as `float' rather than `double' due to prototype", (char *) 0, name, parmnum + 1);
      }

    else if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE)
      && (((n64_enum_tree_code) (((val)->common.type))->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (((val)->common.type))->common.code) == CHAR_TYPE))
      {
        tree would_have_been = default_conversion (val);
        tree type1 = ((would_have_been)->common.type);

        if (((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE
     && type == ((val)->common.type))


   ;
        else if (formal_prec != ((type1)->type.precision))
   warn_for_assignment ("%s with different width due to prototype", (char *) 0, name, parmnum + 1);
        else if (((type)->common.unsigned_flag) == ((type1)->common.unsigned_flag))
   ;



        else if (((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
   ;
        else if (((n64_enum_tree_code) (val)->common.code) == INTEGER_CST
          && int_fits_type_p (val, type))


   ;

        else if (((n64_enum_tree_code) (val)->common.code) == NOP_EXPR
          && ((n64_enum_tree_code) (((val)->exp.operands[0]))->common.code) == INTEGER_CST
          && int_fits_type_p (((val)->exp.operands[0]), type))
   ;
        else if (((((val)->common.type))->type.precision) < ((type)->type.precision)
          && ((((val)->common.type))->common.unsigned_flag))
   ;
        else if (((type)->common.unsigned_flag))
   warn_for_assignment ("%s as unsigned due to prototype", (char *) 0, name, parmnum + 1);
        else
   warn_for_assignment ("%s as signed due to prototype", (char *) 0, name, parmnum + 1);
      }
  }

       parmval = convert_for_assignment (type, val,
             (char *)0,
      fundecl, name, parmnum + 1);


       if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
     || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
    && (((type)->type.precision) < ((integer_type_node)->type.precision)))
  parmval = default_conversion (parmval);

     }
   result = tree_cons ((tree) 
                      ((void *)0)
                               , parmval, result);
 }
      else if (((n64_enum_tree_code) (((val)->common.type))->common.code) == REAL_TYPE
               && (((((val)->common.type))->type.precision)
            < ((double_type_node)->type.precision)))

 result = tree_cons ((tree) 
                    ((void *)0)
                             , convert (double_type_node, val), result);
      else

 result = tree_cons ((tree) 
                    ((void *)0)
                             , default_conversion (val), result);

      if (typetail)
 typetail = ((typetail)->common.chain);
    }

  if (typetail != 0 && ((typetail)->list.value) != void_type_node)
    {
      if (name)
 error ("too few arguments to function `%s'",
        ((name)->identifier.pointer));
      else
 error ("too few arguments to function");
    }

  return nreverse (result);
}







tree
parser_build_binary_op(n64_enum_tree_code code, tree arg1, tree arg2) asm("_parser_build_binary_op");
tree
parser_build_binary_op(n64_enum_tree_code code, tree arg1, tree arg2)
{
  tree result = build_binary_op (code, arg1, arg2, 1);

  char cxx_class;
  char class1 = (*tree_code_type[(int) (((n64_enum_tree_code) (arg1)->common.code))]);
  char class2 = (*tree_code_type[(int) (((n64_enum_tree_code) (arg2)->common.code))]);
  n64_enum_tree_code code1 = ERROR_MARK;
  n64_enum_tree_code code2 = ERROR_MARK;

  if (class1 == 'e' || class1 == '1'
      || class1 == '2' || class1 == '<')
    code1 = ((n64_enum_tree_code) ((arg1)->exp.complexity));
  if (class2 == 'e' || class2 == '1'
      || class2 == '2' || class2 == '<')
    code2 = ((n64_enum_tree_code) ((arg2)->exp.complexity));




  if (warn_parentheses)
    {
      if (code == LSHIFT_EXPR || code == RSHIFT_EXPR)
 {
   if (code1 == PLUS_EXPR || code1 == MINUS_EXPR
       || code2 == PLUS_EXPR || code2 == MINUS_EXPR)
     warning ("suggest parentheses around + or - inside shift");
 }

      if (code == TRUTH_ORIF_EXPR)
 {
   if (code1 == TRUTH_ANDIF_EXPR
       || code2 == TRUTH_ANDIF_EXPR)
     warning ("suggest parentheses around && within ||");
 }

      if (code == BIT_IOR_EXPR)
 {
   if (code1 == BIT_AND_EXPR || code1 == BIT_XOR_EXPR
       || code1 == PLUS_EXPR || code1 == MINUS_EXPR
       || code2 == BIT_AND_EXPR || code2 == BIT_XOR_EXPR
       || code2 == PLUS_EXPR || code2 == MINUS_EXPR)
     warning ("suggest parentheses around arithmetic in operand of |");

   if ((*tree_code_type[(int) (code1)]) == '<' || (*tree_code_type[(int) (code2)]) == '<')
     warning ("suggest parentheses around comparison in operand of |");
 }

      if (code == BIT_XOR_EXPR)
 {
   if (code1 == BIT_AND_EXPR
       || code1 == PLUS_EXPR || code1 == MINUS_EXPR
       || code2 == BIT_AND_EXPR
       || code2 == PLUS_EXPR || code2 == MINUS_EXPR)
     warning ("suggest parentheses around arithmetic in operand of ^");

   if ((*tree_code_type[(int) (code1)]) == '<' || (*tree_code_type[(int) (code2)]) == '<')
     warning ("suggest parentheses around comparison in operand of ^");
 }

      if (code == BIT_AND_EXPR)
 {
   if (code1 == PLUS_EXPR || code1 == MINUS_EXPR
       || code2 == PLUS_EXPR || code2 == MINUS_EXPR)
     warning ("suggest parentheses around + or - in operand of &");

   if ((*tree_code_type[(int) (code1)]) == '<' || (*tree_code_type[(int) (code2)]) == '<')
     warning ("suggest parentheses around comparison in operand of &");
 }
    }


  if ((*tree_code_type[(int) (code)]) == '<' && extra_warnings
      && ((*tree_code_type[(int) (code1)]) == '<' || (*tree_code_type[(int) (code2)]) == '<'))
    warning ("comparisons like X<=Y<=Z do not have their mathematical meaning");

  unsigned_conversion_warning (result, arg1);
  unsigned_conversion_warning (result, arg2);
  overflow_warning (result);

  cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (result)->common.code))]);



  if (cxx_class == 'e' || cxx_class == '1'
      || cxx_class == '2' || cxx_class == '<')
    (((result)->exp.complexity) = (int)(code));
  else
    {
      int flag = ((result)->common.constant_flag);




      result = build1 (NON_LVALUE_EXPR, ((result)->common.type), result);
      (((result)->exp.complexity) = (int)(code));
      ((result)->common.constant_flag) = flag;
    }

  return result;
}
tree
build_binary_op(n64_enum_tree_code code, tree orig_op0, tree orig_op1, int convert_p) asm("_build_binary_op");
tree
build_binary_op(n64_enum_tree_code code, tree orig_op0, tree orig_op1, int convert_p)
{
  tree type0, type1;
  register n64_enum_tree_code code0, code1;
  tree op0, op1;




  register n64_enum_tree_code resultcode = code;



  register tree result_type = 
                             ((void *)0)
                                 ;




  int converted = 0;



  tree build_type = 0;



  tree final_type = 0;







  int shorten = 0;




  int short_compare = 0;



  int short_shift = 0;


  int common = 0;

  if (convert_p)
    {
      op0 = default_conversion (orig_op0);
      op1 = default_conversion (orig_op1);
    }
  else
    {
      op0 = orig_op0;
      op1 = orig_op1;
    }

  type0 = ((op0)->common.type);
  type1 = ((op1)->common.type);



  code0 = ((n64_enum_tree_code) (type0)->common.code);
  code1 = ((n64_enum_tree_code) (type1)->common.code);


  while ((((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op0)->common.code) == NON_LVALUE_EXPR) && (((op0)->common.type) == ((((op0)->exp.operands[0]))->common.type))) (op0) = ((op0)->exp.operands[0]);;
  while ((((n64_enum_tree_code) (op1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op1)->common.code) == NON_LVALUE_EXPR) && (((op1)->common.type) == ((((op1)->exp.operands[0]))->common.type))) (op1) = ((op1)->exp.operands[0]);;




  if (code0 == ERROR_MARK || code1 == ERROR_MARK)
    return error_mark_node;

  switch (code)
    {
    case PLUS_EXPR:

      if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 return pointer_int_sum (PLUS_EXPR, op0, op1);
      else if (code1 == POINTER_TYPE && code0 == INTEGER_TYPE)
 return pointer_int_sum (PLUS_EXPR, op1, op0);
      else
 common = 1;
      break;

    case MINUS_EXPR:


      if (code0 == POINTER_TYPE && code1 == POINTER_TYPE
   && comp_target_types (type0, type1))
 return pointer_diff (op0, op1);

      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 return pointer_int_sum (MINUS_EXPR, op0, op1);
      else
 common = 1;
      break;

    case MULT_EXPR:
      common = 1;
      break;

    case TRUNC_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case EXACT_DIV_EXPR:
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE
    || code0 == COMPLEX_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE
       || code1 == COMPLEX_TYPE))
 {
   if (!(code0 == INTEGER_TYPE && code1 == INTEGER_TYPE))
     resultcode = RDIV_EXPR;
   else
     {





       shorten = (((((orig_op0)->common.type))->common.unsigned_flag)
    || (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && (((op1)->int_cst.int_cst_low) != -1
     || ((op1)->int_cst.int_cst_high) != -1)));
     }
   common = 1;
 }
      break;

    case BIT_AND_EXPR:
    case BIT_ANDTC_EXPR:
    case BIT_IOR_EXPR:
    case BIT_XOR_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 shorten = -1;





      if (((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (op1)->common.code) == NOP_EXPR
   && ((type1)->type.precision) > ((((((op1)->exp.operands[0]))->common.type))->type.precision)
   && ((((((op1)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   final_type = result_type;
   op1 = ((op1)->exp.operands[0]);
   result_type = ((op1)->common.type);
 }
      if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR
   && ((type0)->type.precision) > ((((((op0)->exp.operands[0]))->common.type))->type.precision)
   && ((((((op0)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   final_type = result_type;
   op0 = ((op0)->exp.operands[0]);
   result_type = ((op0)->common.type);
 }
      break;

    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {




   shorten = (((((orig_op0)->common.type))->common.unsigned_flag)
       || (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
    && (((op1)->int_cst.int_cst_low) != -1
        || ((op1)->int_cst.int_cst_high) != -1)));
   common = 1;
 }
      break;

    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
    case TRUTH_AND_EXPR:
    case TRUTH_OR_EXPR:
    case TRUTH_XOR_EXPR:
      if ((code0 == INTEGER_TYPE || code0 == POINTER_TYPE
    || code0 == REAL_TYPE || code0 == COMPLEX_TYPE)
   && (code1 == INTEGER_TYPE || code1 == POINTER_TYPE
       || code1 == REAL_TYPE || code1 == COMPLEX_TYPE))
 {



   result_type = integer_type_node;
   op0 = truthvalue_conversion (op0);
   op1 = truthvalue_conversion (op1);
   converted = 1;
 }
      break;





    case RSHIFT_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_sgn (op1) < 0)
  warning ("right shift count is negative");
       else
  {
    if (((op1)->int_cst.int_cst_low) | ((op1)->int_cst.int_cst_high))
      short_shift = 1;
    if (((op1)->int_cst.int_cst_high) != 0
        || ((unsigned int) ((op1)->int_cst.int_cst_low)
     >= ((type0)->type.precision)))
      warning ("right shift count >= width of type");
  }
     }


   result_type = type0;


   if (! flag_traditional)
     {
       if (((((op1)->common.type))->type.main_variant) != integer_type_node)
  op1 = convert (integer_type_node, op1);

       converted = 1;
     }
 }
      break;

    case LSHIFT_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_sgn (op1) < 0)
  warning ("left shift count is negative");
       else if (((op1)->int_cst.int_cst_high) != 0
         || ((unsigned int) ((op1)->int_cst.int_cst_low)
      >= ((type0)->type.precision)))
  warning ("left shift count >= width of type");
     }


   result_type = type0;


   if (! flag_traditional)
     {
       if (((((op1)->common.type))->type.main_variant) != integer_type_node)
  op1 = convert (integer_type_node, op1);

       converted = 1;
     }
 }
      break;

    case RROTATE_EXPR:
    case LROTATE_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_sgn (op1) < 0)
  warning ("shift count is negative");
       else if (((op1)->int_cst.int_cst_high) != 0
         || ((unsigned int) ((op1)->int_cst.int_cst_low)
      >= ((type0)->type.precision)))
  warning ("shift count >= width of type");
     }


   result_type = type0;


   if (! flag_traditional)
     {
       if (((((op1)->common.type))->type.main_variant) != integer_type_node)
  op1 = convert (integer_type_node, op1);

       converted = 1;
     }
 }
      break;

    case EQ_EXPR:
    case NE_EXPR:


      build_type = integer_type_node;
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE
    || code0 == COMPLEX_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE
       || code1 == COMPLEX_TYPE))
 short_compare = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   register tree tt0 = ((type0)->common.type);
   register tree tt1 = ((type1)->common.type);



   if (comp_target_types (type0, type1))
     result_type = common_type (type0, type1);
   else if (((tt0)->type.main_variant) == void_type_node)
     {


       if (pedantic && (!integer_zerop (op0) || op0 != orig_op0)
    && ((n64_enum_tree_code) (tt1)->common.code) == FUNCTION_TYPE)
  pedwarn ("ANSI C forbids comparison of `void *' with function pointer");
     }
   else if (((tt1)->type.main_variant) == void_type_node)
     {
       if (pedantic && (!integer_zerop (op1) || op1 != orig_op1)
    && ((n64_enum_tree_code) (tt0)->common.code) == FUNCTION_TYPE)
  pedwarn ("ANSI C forbids comparison of `void *' with function pointer");
     }
   else
     pedwarn ("comparison of distinct pointer types lacks a cast");

   if (result_type == (tree) 
                     ((void *)0)
                              )
     result_type = ptr_type_node;
 }
      else if (code0 == POINTER_TYPE && ((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && integer_zerop (op1))
 result_type = type0;
      else if (code1 == POINTER_TYPE && ((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
        && integer_zerop (op0))
 result_type = type1;
      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (! flag_traditional)
     pedwarn ("comparison between pointer and integer");
 }
      else if (code0 == INTEGER_TYPE && code1 == POINTER_TYPE)
 {
   result_type = type1;
   if (! flag_traditional)
     pedwarn ("comparison between pointer and integer");
 }
      break;

    case MAX_EXPR:
    case MIN_EXPR:
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 shorten = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   if (comp_target_types (type0, type1))
     {
       result_type = common_type (type0, type1);
       if (pedantic
    && ((n64_enum_tree_code) (((type0)->common.type))->common.code) == FUNCTION_TYPE)
  pedwarn ("ANSI C forbids ordered comparisons of pointers to functions");
     }
   else
     {
       result_type = ptr_type_node;
       pedwarn ("comparison of distinct pointer types lacks a cast");
     }
 }
      break;

    case LE_EXPR:
    case GE_EXPR:
    case LT_EXPR:
    case GT_EXPR:
      build_type = integer_type_node;
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 short_compare = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   if (comp_target_types (type0, type1))
     {
       result_type = common_type (type0, type1);
       if ((((((type0)->common.type))->type.size) != 0)
    != (((((type1)->common.type))->type.size) != 0))
  pedwarn ("comparison of complete and incomplete pointers");
       else if (pedantic
         && ((n64_enum_tree_code) (((type0)->common.type))->common.code) == FUNCTION_TYPE)
  pedwarn ("ANSI C forbids ordered comparisons of pointers to functions");
     }
   else
     {
       result_type = ptr_type_node;
       pedwarn ("comparison of distinct pointer types lacks a cast");
     }
 }
      else if (code0 == POINTER_TYPE && ((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && integer_zerop (op1))
 {
   result_type = type0;
   if (pedantic || extra_warnings)
     pedwarn ("ordered comparison of pointer with integer zero");
 }
      else if (code1 == POINTER_TYPE && ((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
        && integer_zerop (op0))
 {
   result_type = type1;
   if (pedantic)
     pedwarn ("ordered comparison of pointer with integer zero");
 }
      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (! flag_traditional)
     pedwarn ("comparison between pointer and integer");
 }
      else if (code0 == INTEGER_TYPE && code1 == POINTER_TYPE)
 {
   result_type = type1;
   if (! flag_traditional)
     pedwarn ("comparison between pointer and integer");
 }
      break;
    }

  if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE || code0 == COMPLEX_TYPE)
      &&
      (code1 == INTEGER_TYPE || code1 == REAL_TYPE || code1 == COMPLEX_TYPE))
    {
      int none_complex = (code0 != COMPLEX_TYPE && code1 != COMPLEX_TYPE);

      if (shorten || common || short_compare)
 result_type = common_type (type0, type1);
      if (shorten && none_complex)
 {
   int unsigned0, unsigned1;
   tree arg0 = get_narrower (op0, &unsigned0);
   tree arg1 = get_narrower (op1, &unsigned1);

   int uns = ((result_type)->common.unsigned_flag);
   tree type;

   final_type = result_type;




   if ((((((op0)->common.type))->type.precision)
        == ((((arg0)->common.type))->type.precision))
       && ((op0)->common.type) != final_type)
     unsigned0 = ((((op0)->common.type))->common.unsigned_flag);
   if ((((((op1)->common.type))->type.precision)
        == ((((arg1)->common.type))->type.precision))
       && ((op1)->common.type) != final_type)
     unsigned1 = ((((op1)->common.type))->common.unsigned_flag);





   if (shorten == -1)
     uns = unsigned0;
   if ((((((arg0)->common.type))->type.precision)
        < ((result_type)->type.precision))
       && (((((arg1)->common.type))->type.precision)
    == ((((arg0)->common.type))->type.precision))
       && unsigned0 == unsigned1
       && (unsigned0 || !uns))
     result_type
       = signed_or_unsigned_type (unsigned0,
      common_type (((arg0)->common.type), ((arg1)->common.type)));
   else if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST
     && (unsigned1 || !uns)
     && (((((arg1)->common.type))->type.precision)
         < ((result_type)->type.precision))
     && (type = signed_or_unsigned_type (unsigned1,
             ((arg1)->common.type)),
         int_fits_type_p (arg0, type)))
     result_type = type;
   else if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
     && (unsigned0 || !uns)
     && (((((arg0)->common.type))->type.precision)
         < ((result_type)->type.precision))
     && (type = signed_or_unsigned_type (unsigned0,
             ((arg0)->common.type)),
         int_fits_type_p (arg1, type)))
     result_type = type;
 }



      if (short_shift)
 {
   int unsigned_arg;
   tree arg0 = get_narrower (op0, &unsigned_arg);

   final_type = result_type;

   if (arg0 == op0 && final_type == ((op0)->common.type))
     unsigned_arg = ((((op0)->common.type))->common.unsigned_flag);

   if (((((arg0)->common.type))->type.precision) < ((result_type)->type.precision)


       && ((op1)->int_cst.int_cst_high) == 0
       && ((((arg0)->common.type))->type.precision) > ((op1)->int_cst.int_cst_low)







       && (!((final_type)->common.unsigned_flag)
    || unsigned_arg
    || 2 * ((((arg0)->common.type))->type.precision) <= ((result_type)->type.precision)))
     {

       result_type
  = signed_or_unsigned_type (unsigned_arg,
        ((arg0)->common.type));

       if (((op0)->common.type) != result_type)
  op0 = convert (result_type, op0);
       converted = 1;
     }
 }




      if (short_compare)
 {




   tree xop0 = op0, xop1 = op1, xresult_type = result_type;
   n64_enum_tree_code xresultcode = resultcode;
   tree val
     = shorten_compare (&xop0, &xop1, &xresult_type, &xresultcode);
   if (val != 0)
     return val;
   op0 = xop0, op1 = xop1;
   converted = 1;
   resultcode = xresultcode;

   if (extra_warnings)
     {
       int op0_signed = ! ((((orig_op0)->common.type))->common.unsigned_flag);
       int op1_signed = ! ((((orig_op1)->common.type))->common.unsigned_flag);

       int unsignedp0, unsignedp1;
       tree primop0 = get_narrower (op0, &unsignedp0);
       tree primop1 = get_narrower (op1, &unsignedp1);



       xop0 = orig_op0;
       xop1 = orig_op1;
       while ((((n64_enum_tree_code) (xop0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (xop0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (xop0)->common.code) == NON_LVALUE_EXPR) && (((xop0)->common.type) == ((((xop0)->exp.operands[0]))->common.type))) (xop0) = ((xop0)->exp.operands[0]);;
       while ((((n64_enum_tree_code) (xop1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (xop1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (xop1)->common.code) == NON_LVALUE_EXPR) && (((xop1)->common.type) == ((((xop1)->exp.operands[0]))->common.type))) (xop1) = ((xop1)->exp.operands[0]);;
       if (! ((result_type)->common.unsigned_flag))
          ;

              else if (op0_signed == op1_signed)
                        ;



       else if ((op0_signed && ((n64_enum_tree_code) (xop0)->common.code) == INTEGER_CST
   && tree_int_cst_sgn (xop0) >= 0)
         || (op1_signed && ((n64_enum_tree_code) (xop1)->common.code) == INTEGER_CST
      && tree_int_cst_sgn (xop1) >= 0))
          ;



       else if ((resultcode == EQ_EXPR || resultcode == NE_EXPR)
         && ((op0_signed && ((n64_enum_tree_code) (xop1)->common.code) == INTEGER_CST
       && int_fits_type_p (xop1, signed_type (result_type))
      || (op1_signed && ((n64_enum_tree_code) (xop0)->common.code) == INTEGER_CST
          && int_fits_type_p (xop0, signed_type (result_type))))))
          ;
       else
  warning ("comparison between signed and unsigned");
       if ((((n64_enum_tree_code) (primop0)->common.code) == BIT_NOT_EXPR)
    != (((n64_enum_tree_code) (primop1)->common.code) == BIT_NOT_EXPR))
  {
    if (((n64_enum_tree_code) (primop0)->common.code) == BIT_NOT_EXPR)
      primop0 = get_narrower (((primop0)->exp.operands[0]),
         &unsignedp0);
    else
      primop1 = get_narrower (((primop1)->exp.operands[0]),
         &unsignedp1);

    if (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST
        || ((n64_enum_tree_code) (primop1)->common.code) == INTEGER_CST)
      {
        tree primop;
        long constant, mask;
        int unsignedp, bits;

        if (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST)
   {
     primop = primop1;
     unsignedp = unsignedp1;
     constant = ((primop0)->int_cst.int_cst_low);
   }
        else
   {
     primop = primop0;
     unsignedp = unsignedp0;
     constant = ((primop1)->int_cst.int_cst_low);
   }

        bits = ((((primop)->common.type))->type.precision);
        if (bits < ((result_type)->type.precision)
     && bits < 32 && unsignedp)
   {
     mask = (~0L) << bits;
     if ((mask & constant) != mask)
       warning ("comparison of promoted ~unsigned with constant");
   }
      }
    else if (unsignedp0 && unsignedp1
      && (((((primop0)->common.type))->type.precision)
          < ((result_type)->type.precision))
      && (((((primop1)->common.type))->type.precision)
          < ((result_type)->type.precision)))
      warning ("comparison of promoted ~unsigned with unsigned");
  }
     }
 }
    }







  if (!result_type)
    {
      binary_op_error (code);
      return error_mark_node;
    }

  if (! converted)
    {
      if (((op0)->common.type) != result_type)
 op0 = convert (result_type, op0);
      if (((op1)->common.type) != result_type)
 op1 = convert (result_type, op1);
    }

  if (build_type == (tree) 
                   ((void *)0)
                            )
    build_type = result_type;

  {
    register tree result = build (resultcode, build_type, op0, op1);
    register tree folded;

    folded = fold (result);
    if (folded == result)
      ((folded)->common.constant_flag) = ((op0)->common.constant_flag) & ((op1)->common.constant_flag);
    if (final_type != 0)
      return convert (final_type, folded);
    return folded;
  }
}




static tree
pointer_int_sum(n64_enum_tree_code resultcode, register tree ptrop, register tree intop) asm("_pointer_int_sum");
static tree
pointer_int_sum(n64_enum_tree_code resultcode, register tree ptrop, register tree intop)
{
  tree size_exp;

  register tree result;
  register tree folded;



  register tree result_type = ((ptrop)->common.type);

  if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == VOID_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("pointer of type `void *' used in arithmetic");
      size_exp = integer_one_node;
    }
  else if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == FUNCTION_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("pointer to a function used in arithmetic");
      size_exp = integer_one_node;
    }
  else
    size_exp = c_size_in_bytes (((result_type)->common.type));






  if ((((n64_enum_tree_code) (intop)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (intop)->common.code) == MINUS_EXPR)
      && ! ((intop)->common.constant_flag)
      && ((((intop)->exp.operands[1]))->common.constant_flag)
      && ((size_exp)->common.constant_flag)


      && ((n64_enum_tree_code) (((((intop)->exp.operands[0]))->common.type))->common.code) == INTEGER_TYPE



      && (! ((((intop)->common.type))->common.unsigned_flag)
   || (((((intop)->common.type))->type.precision)
       == ((((ptrop)->common.type))->type.precision))))
    {
      n64_enum_tree_code subcode = resultcode;
      tree int_type = ((intop)->common.type);
      if (((n64_enum_tree_code) (intop)->common.code) == MINUS_EXPR)
 subcode = (subcode == PLUS_EXPR ? MINUS_EXPR : PLUS_EXPR);



      ptrop = build_binary_op (subcode, ptrop,
          convert (int_type, ((intop)->exp.operands[1])), 1);
      intop = convert (int_type, ((intop)->exp.operands[0]));
    }




  if (((((intop)->common.type))->type.precision) != ((target_flags & 0x00000002) ? 64 : 32))
    intop = convert (type_for_size (((target_flags & 0x00000002) ? 64 : 32), 0), intop);





  intop = convert (result_type,
     build_binary_op (MULT_EXPR, intop,
        convert (((intop)->common.type), size_exp), 1));



  result = build (resultcode, result_type, ptrop, intop);

  folded = fold (result);
  if (folded == result)
    ((folded)->common.constant_flag) = ((ptrop)->common.constant_flag) & ((intop)->common.constant_flag);
  return folded;
}




static tree
pointer_diff(register tree op0, register tree op1) asm("_pointer_diff");
static tree
pointer_diff(register tree op0, register tree op1)
{
  register tree result, folded;
  tree restype = ptrdiff_type_node;

  tree target_type = ((((op0)->common.type))->common.type);

  if (pedantic || warn_pointer_arith)
    {
      if (((n64_enum_tree_code) (target_type)->common.code) == VOID_TYPE)
 pedwarn ("pointer of type `void *' used in subtraction");
      if (((n64_enum_tree_code) (target_type)->common.code) == FUNCTION_TYPE)
 pedwarn ("pointer to a function used in subtraction");
    }




  op0 = build_binary_op (MINUS_EXPR, convert (restype, op0),
    convert (restype, op1), 1);

  if (((((((op1)->common.type))->common.type))->type.size) == 0)
    error ("arithmetic on pointer to an incomplete type");


  op1 = c_size_in_bytes (target_type);



  result = build (EXACT_DIV_EXPR, restype, op0, convert (restype, op1));

  folded = fold (result);
  if (folded == result)
    ((folded)->common.constant_flag) = ((op0)->common.constant_flag) & ((op1)->common.constant_flag);
  return folded;
}






tree
build_unary_op(n64_enum_tree_code code, tree xarg, int noconvert) asm("_build_unary_op");
tree
build_unary_op(n64_enum_tree_code code, tree xarg, int noconvert)
{

  register tree arg = xarg;
  register tree argtype = 0;
  register n64_enum_tree_code typecode = ((n64_enum_tree_code) (((arg)->common.type))->common.code);
  char *errstring = 
                   ((void *)0)
                       ;
  tree val;

  if (typecode == ERROR_MARK)
    return error_mark_node;
  if (typecode == ENUMERAL_TYPE)
    typecode = INTEGER_TYPE;

  switch (code)
    {
    case CONVERT_EXPR:



      if (!(typecode == INTEGER_TYPE || typecode == REAL_TYPE
     || typecode == COMPLEX_TYPE))
        errstring = "wrong type argument to unary plus";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case NEGATE_EXPR:
      if (!(typecode == INTEGER_TYPE || typecode == REAL_TYPE
     || typecode == COMPLEX_TYPE))
        errstring = "wrong type argument to unary minus";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case BIT_NOT_EXPR:
      if (typecode == COMPLEX_TYPE)
 {
   code = CONJ_EXPR;
   if (!noconvert)
     arg = default_conversion (arg);
 }
      else if (typecode != INTEGER_TYPE)
        errstring = "wrong type argument to bit-complement";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case ABS_EXPR:
      if (!(typecode == INTEGER_TYPE || typecode == REAL_TYPE
     || typecode == COMPLEX_TYPE))
        errstring = "wrong type argument to abs";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case CONJ_EXPR:

      if (!(typecode == INTEGER_TYPE || typecode == REAL_TYPE
     || typecode == COMPLEX_TYPE))
 errstring = "wrong type argument to conjugation";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case TRUTH_NOT_EXPR:
      if (typecode != INTEGER_TYPE
   && typecode != REAL_TYPE && typecode != POINTER_TYPE
   && typecode != COMPLEX_TYPE

   && typecode != ARRAY_TYPE && typecode != FUNCTION_TYPE)
 {
   errstring = "wrong type argument to unary exclamation mark";
   break;
 }
      arg = truthvalue_conversion (arg);
      return invert_truthvalue (arg);

    case NOP_EXPR:
      break;

    case REALPART_EXPR:
      if (((n64_enum_tree_code) (arg)->common.code) == COMPLEX_CST)
 return ((arg)->complex.real);
      else if (((n64_enum_tree_code) (((arg)->common.type))->common.code) == COMPLEX_TYPE)
 return fold (build1 (REALPART_EXPR, ((((arg)->common.type))->common.type), arg));
      else
 return arg;

    case IMAGPART_EXPR:
      if (((n64_enum_tree_code) (arg)->common.code) == COMPLEX_CST)
 return ((arg)->complex.imag);
      else if (((n64_enum_tree_code) (((arg)->common.type))->common.code) == COMPLEX_TYPE)
 return fold (build1 (IMAGPART_EXPR, ((((arg)->common.type))->common.type), arg));
      else
 return convert (((arg)->common.type), integer_zero_node);

    case PREINCREMENT_EXPR:
    case POSTINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case POSTDECREMENT_EXPR:



      val = unary_complex_lvalue (code, arg);
      if (val != 0)
 return val;



      if (typecode == COMPLEX_TYPE)
 {
   tree real, imag;

   arg = stabilize_reference (arg);
   real = build_unary_op (REALPART_EXPR, arg, 1);
   imag = build_unary_op (IMAGPART_EXPR, arg, 1);
   return build (COMPLEX_EXPR, ((arg)->common.type),
   build_unary_op (code, real, 1), imag);
 }



      if (typecode != POINTER_TYPE
   && typecode != INTEGER_TYPE && typecode != REAL_TYPE)
 {
   if (code == PREINCREMENT_EXPR || code == POSTINCREMENT_EXPR)
     errstring ="wrong type argument to increment";
   else
     errstring ="wrong type argument to decrement";
   break;
 }

      {
 register tree inc;
 tree result_type = ((arg)->common.type);

 arg = get_unwidened (arg, 0);
 argtype = ((arg)->common.type);



 if (typecode == POINTER_TYPE)
   {


     if (((((result_type)->common.type))->type.size) == 0)
       error ("%s of pointer to unknown structure",
         ((code == PREINCREMENT_EXPR
    || code == POSTINCREMENT_EXPR)
   ? "increment" : "decrement"));
     else if ((pedantic || warn_pointer_arith)
       && (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == FUNCTION_TYPE
    || ((n64_enum_tree_code) (((result_type)->common.type))->common.code) == VOID_TYPE))
       pedwarn ("wrong type argument to %s",
         ((code == PREINCREMENT_EXPR
    || code == POSTINCREMENT_EXPR)
   ? "increment" : "decrement"));
     inc = c_size_in_bytes (((result_type)->common.type));
   }
 else
   inc = integer_one_node;

 inc = convert (argtype, inc);



 while (1)
   switch (((n64_enum_tree_code) (arg)->common.code))
     {
     case NOP_EXPR:
     case CONVERT_EXPR:
     case FLOAT_EXPR:
     case FIX_TRUNC_EXPR:
     case FIX_FLOOR_EXPR:
     case FIX_ROUND_EXPR:
     case FIX_CEIL_EXPR:
       pedantic_lvalue_warning (CONVERT_EXPR);



       if ((((n64_enum_tree_code) (((arg)->common.type))->common.code)
     == ((n64_enum_tree_code) (((((arg)->exp.operands[0]))->common.type))->common.code))
    && (((((arg)->common.type))->type.mode)
        == ((((((arg)->exp.operands[0]))->common.type))->type.mode)))
  arg = ((arg)->exp.operands[0]);
       else
  {
    tree incremented, modify, value;
    arg = stabilize_reference (arg);
    if (code == PREINCREMENT_EXPR || code == PREDECREMENT_EXPR)
      value = arg;
    else
      value = save_expr (arg);
    incremented = build (((code == PREINCREMENT_EXPR
      || code == POSTINCREMENT_EXPR)
     ? PLUS_EXPR : MINUS_EXPR),
           argtype, value, inc);
    ((incremented)->common.side_effects_flag) = 1;
    modify = build_modify_expr (arg, NOP_EXPR, incremented);
    value = build (COMPOUND_EXPR, ((arg)->common.type), modify, value);
    ((value)->common.used_flag) = 1;
    return value;
  }
       break;

     default:
       goto give_up;
     }
      give_up:


 if (!lvalue_or_else (arg, ((code == PREINCREMENT_EXPR
        || code == POSTINCREMENT_EXPR)
       ? "increment" : "decrement")))
   return error_mark_node;


 if (((arg)->common.readonly_flag))
   readonly_warning (arg,
       ((code == PREINCREMENT_EXPR
         || code == POSTINCREMENT_EXPR)
        ? "increment" : "decrement"));

 val = build (code, ((arg)->common.type), arg, inc);
 ((val)->common.side_effects_flag) = 1;
 val = convert (result_type, val);
 if (((n64_enum_tree_code) (val)->common.code) != code)
   ((val)->common.static_flag) = 1;
 return val;
      }

    case ADDR_EXPR:




      if (((n64_enum_tree_code) (arg)->common.code) == INDIRECT_REF)
 {

   if (lvalue_p (((arg)->exp.operands[0])))
     return non_lvalue (((arg)->exp.operands[0]));
   return ((arg)->exp.operands[0]);
 }


      if (((n64_enum_tree_code) (arg)->common.code) == ARRAY_REF)
 {
   if (mark_addressable (((arg)->exp.operands[0])) == 0)
     return error_mark_node;
   return build_binary_op (PLUS_EXPR, ((arg)->exp.operands[0]),
      ((arg)->exp.operands[1]), 1);
 }



      val = unary_complex_lvalue (code, arg);
      if (val != 0)
 return val;
      if (((n64_enum_tree_code) (arg)->common.code) == CONSTRUCTOR && ((arg)->common.constant_flag))
 ;


      else if (typecode != FUNCTION_TYPE && !lvalue_or_else (arg, "unary `&'"))
 return error_mark_node;


      argtype = ((arg)->common.type);


      if ((*tree_code_type[(int) (((n64_enum_tree_code) (arg)->common.code))]) == 'd'
   || (*tree_code_type[(int) (((n64_enum_tree_code) (arg)->common.code))]) == 'r')
 {
   if (((arg)->common.readonly_flag) || ((arg)->common.volatile_flag))
     argtype = c_build_type_variant (argtype,
         ((arg)->common.readonly_flag),
         ((arg)->common.volatile_flag));
 }

      argtype = build_pointer_type (argtype);

      if (mark_addressable (arg) == 0)
 return error_mark_node;

      {
 tree addr;

 if (((n64_enum_tree_code) (arg)->common.code) == COMPONENT_REF)
   {
     tree field = ((arg)->exp.operands[1]);

     addr = build_unary_op (ADDR_EXPR, ((arg)->exp.operands[0]), 0);

     if (((field)->decl.bit_field_flag))
       {
  error ("attempt to take address of bit-field structure member `%s'",
         ((((field)->decl.name))->identifier.pointer));
  return error_mark_node;
       }

     addr = convert (argtype, addr);

     if (! integer_zerop (((field)->decl.arguments)))
       {
  tree offset
    = size_binop (TRUNC_DIV_EXPR, ((field)->decl.arguments),
    size_int (8));
  int flag = ((addr)->common.constant_flag);
  addr = fold (build (PLUS_EXPR, argtype,
        addr, convert (argtype, offset)));
  ((addr)->common.constant_flag) = flag;
       }
   }
 else
   addr = build1 (code, argtype, arg);



 if (staticp (arg)
     && ! (((n64_enum_tree_code) (arg)->common.code) == FUNCTION_DECL
    && ((arg)->decl.context) != 0))
   ((addr)->common.constant_flag) = 1;
 return addr;
      }
    }

  if (!errstring)
    {
      if (argtype == 0)
 argtype = ((arg)->common.type);
      return fold (build1 (code, argtype, arg));
    }

  error (errstring);
  return error_mark_node;
}
int
lvalue_p(tree ref) asm("_lvalue_p");
int
lvalue_p(tree ref)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (ref)->common.code);

  switch (code)
    {
    case REALPART_EXPR:
    case IMAGPART_EXPR:
    case COMPONENT_REF:
      return lvalue_p (((ref)->exp.operands[0]));

    case STRING_CST:
      return 1;

    case INDIRECT_REF:
    case ARRAY_REF:
    case VAR_DECL:
    case PARM_DECL:
    case RESULT_DECL:
    case ERROR_MARK:
      if (((n64_enum_tree_code) (((ref)->common.type))->common.code) != FUNCTION_TYPE
   && ((n64_enum_tree_code) (((ref)->common.type))->common.code) != METHOD_TYPE)
 return 1;
      break;
    }
  return 0;
}




int
lvalue_or_else(tree ref, char *string) asm("_lvalue_or_else");
int
lvalue_or_else(tree ref, char *string)
{
  int win = lvalue_p (ref);
  if (! win)
    error ("invalid lvalue in %s", string);
  return win;
}







static tree
unary_complex_lvalue(n64_enum_tree_code code, tree arg) asm("_unary_complex_lvalue");
static tree
unary_complex_lvalue(n64_enum_tree_code code, tree arg)
{

  if (((n64_enum_tree_code) (arg)->common.code) == COMPOUND_EXPR)
    {
      tree real_result = build_unary_op (code, ((arg)->exp.operands[1]), 0);
      pedantic_lvalue_warning (COMPOUND_EXPR);
      return build (COMPOUND_EXPR, ((real_result)->common.type),
      ((arg)->exp.operands[0]), real_result);
    }


  if (((n64_enum_tree_code) (arg)->common.code) == COND_EXPR)
    {
      pedantic_lvalue_warning (COND_EXPR);
      return (build_conditional_expr
       (((arg)->exp.operands[0]),
        build_unary_op (code, ((arg)->exp.operands[1]), 0),
        build_unary_op (code, ((arg)->exp.operands[2]), 0)));
    }

  return 0;
}




static void
pedantic_lvalue_warning(n64_enum_tree_code code) asm("_pedantic_lvalue_warning");
static void
pedantic_lvalue_warning(n64_enum_tree_code code)
{
  if (pedantic)
    pedwarn ("ANSI C forbids use of %s expressions as lvalues",
      code == COND_EXPR ? "conditional"
      : code == COMPOUND_EXPR ? "compound" : "cast");
}



void
readonly_warning(tree arg, char *string) asm("_readonly_warning");
void
readonly_warning(tree arg, char *string)
{
  char buf[80];
  strcpy (buf, string);


  if (((n64_enum_tree_code) (arg)->common.code) == VAR_DECL && (((arg)->decl.lang_flag_4)))
    {
      strcat (buf, " of iterator `%s'");
      pedwarn (buf, ((((arg)->decl.name))->identifier.pointer));
    }

  if (((n64_enum_tree_code) (arg)->common.code) == COMPONENT_REF)
    {
      if (((((((arg)->exp.operands[0]))->common.type))->common.readonly_flag))
 readonly_warning (((arg)->exp.operands[0]), string);
      else
 {
   strcat (buf, " of read-only member `%s'");
   pedwarn (buf, ((((((arg)->exp.operands[1]))->decl.name))->identifier.pointer));
 }
    }
  else if (((n64_enum_tree_code) (arg)->common.code) == VAR_DECL)
    {
      strcat (buf, " of read-only variable `%s'");
      pedwarn (buf, ((((arg)->decl.name))->identifier.pointer));
    }
  else
    {
      pedwarn ("%s of read-only location", buf);
    }
}





int
mark_addressable(tree exp) asm("_mark_addressable");
int
mark_addressable(tree exp)
{
  register tree x = exp;
  while (1)
    switch (((n64_enum_tree_code) (x)->common.code))
      {
      case ADDR_EXPR:
      case COMPONENT_REF:
      case ARRAY_REF:
      case REALPART_EXPR:
      case IMAGPART_EXPR:
 x = ((x)->exp.operands[0]);
 break;

      case CONSTRUCTOR:
 ((x)->common.addressable_flag) = 1;
 return 1;

      case VAR_DECL:
      case CONST_DECL:
      case PARM_DECL:
      case RESULT_DECL:
 if (((x)->decl.regdecl_flag) && !((x)->common.addressable_flag)
     && ((x)->decl.nonlocal_flag))
   {
     if (((x)->common.public_flag))
       {
  error ("global register variable `%s' used in nested function",
         ((((x)->decl.name))->identifier.pointer));
  return 0;
       }
     pedwarn ("register variable `%s' used in nested function",
       ((((x)->decl.name))->identifier.pointer));
   }
 else if (((x)->decl.regdecl_flag) && !((x)->common.addressable_flag))
   {
     if (((x)->common.public_flag))
       {
  error ("address of global register variable `%s' requested",
         ((((x)->decl.name))->identifier.pointer));
  return 0;
       }






     else if (((((x)->common.type))->common.lang_flag_2))
       {
  error ("cannot put object with volatile field into register");
  return 0;
       }

     pedwarn ("address of register variable `%s' requested",
       ((((x)->decl.name))->identifier.pointer));
   }
 put_var_into_stack (x);


      case FUNCTION_DECL:
 ((x)->common.addressable_flag) = 1;





      default:
 return 1;
    }
}



tree
build_conditional_expr(tree ifexp, tree op1, tree op2) asm("_build_conditional_expr");
tree
build_conditional_expr(tree ifexp, tree op1, tree op2)
{
  register tree type1;
  register tree type2;
  register n64_enum_tree_code code1;
  register n64_enum_tree_code code2;
  register tree result_type = 
                             ((void *)0)
                                 ;
  tree orig_op1 = op1, orig_op2 = op2;



  if (op1 == 0)
    {
      if (pedantic)
 pedwarn ("ANSI C forbids omitting the middle term of a ?: expression");
      ifexp = op1 = save_expr (ifexp);
    }

  ifexp = truthvalue_conversion (default_conversion (ifexp));
  if (((n64_enum_tree_code) (((op1)->common.type))->common.code) != VOID_TYPE)
    op1 = default_conversion (op1);
  if (((n64_enum_tree_code) (((op2)->common.type))->common.code) != VOID_TYPE)
    op2 = default_conversion (op2);

  if (((n64_enum_tree_code) (ifexp)->common.code) == ERROR_MARK
      || ((n64_enum_tree_code) (((op1)->common.type))->common.code) == ERROR_MARK
      || ((n64_enum_tree_code) (((op2)->common.type))->common.code) == ERROR_MARK)
    return error_mark_node;

  type1 = ((op1)->common.type);
  code1 = ((n64_enum_tree_code) (type1)->common.code);
  type2 = ((op2)->common.type);
  code2 = ((n64_enum_tree_code) (type2)->common.code);



  if (((type1)->type.main_variant) == ((type2)->type.main_variant))
    {
      if (type1 == type2)
 result_type = type1;
      else
 result_type = ((type1)->type.main_variant);
    }
  else if ((code1 == INTEGER_TYPE || code1 == REAL_TYPE)
           && (code2 == INTEGER_TYPE || code2 == REAL_TYPE))
    {
      result_type = common_type (type1, type2);
    }
  else if (code1 == VOID_TYPE || code2 == VOID_TYPE)
    {
      if (pedantic && (code1 != VOID_TYPE || code2 != VOID_TYPE))
 pedwarn ("ANSI C forbids conditional expr with only one void side");
      result_type = void_type_node;
    }
  else if (code1 == POINTER_TYPE && code2 == POINTER_TYPE)
    {
      if (comp_target_types (type1, type2))
 result_type = common_type (type1, type2);
      else if (integer_zerop (op1) && ((type1)->common.type) == void_type_node
        && ((n64_enum_tree_code) (orig_op1)->common.code) != NOP_EXPR)
 result_type = qualify_type (type2, type1);
      else if (integer_zerop (op2) && ((type2)->common.type) == void_type_node
        && ((n64_enum_tree_code) (orig_op2)->common.code) != NOP_EXPR)
 result_type = qualify_type (type1, type2);
      else if (((((type1)->common.type))->type.main_variant) == void_type_node)
 {
   if (pedantic && ((n64_enum_tree_code) (((type2)->common.type))->common.code) == FUNCTION_TYPE)
     pedwarn ("ANSI C forbids conditional expr between `void *' and function pointer");
   result_type = qualify_type (type1, type2);
 }
      else if (((((type2)->common.type))->type.main_variant) == void_type_node)
 {
   if (pedantic && ((n64_enum_tree_code) (((type1)->common.type))->common.code) == FUNCTION_TYPE)
     pedwarn ("ANSI C forbids conditional expr between `void *' and function pointer");
   result_type = qualify_type (type2, type1);
 }
      else
 {
   pedwarn ("pointer type mismatch in conditional expression");
   result_type = build_pointer_type (void_type_node);
 }
    }
  else if (code1 == POINTER_TYPE && code2 == INTEGER_TYPE)
    {
      if (! integer_zerop (op2))
 pedwarn ("pointer/integer type mismatch in conditional expression");
      else
 {
   op2 = null_pointer_node;




 }
      result_type = type1;
    }
  else if (code2 == POINTER_TYPE && code1 == INTEGER_TYPE)
    {
      if (!integer_zerop (op1))
 pedwarn ("pointer/integer type mismatch in conditional expression");
      else
 {
   op1 = null_pointer_node;




 }
      result_type = type2;
    }

  if (!result_type)
    {
      if (flag_cond_mismatch)
 result_type = void_type_node;
      else
 {
   error ("type mismatch in conditional expression");
   return error_mark_node;
 }
    }


  result_type
    = build_type_variant (result_type,
     ((op1)->common.readonly_flag) || ((op2)->common.readonly_flag),
     ((op1)->common.volatile_flag) || ((op2)->common.volatile_flag));

  if (result_type != ((op1)->common.type))
    op1 = convert_and_check (result_type, op1);
  if (result_type != ((op2)->common.type))
    op2 = convert_and_check (result_type, op2);
  if (((n64_enum_tree_code) (ifexp)->common.code) == INTEGER_CST)
    return pedantic_non_lvalue (integer_zerop (ifexp) ? op2 : op1);

  return fold (build (COND_EXPR, result_type, ifexp, op1, op2));
}




tree
build_compound_expr(tree list) asm("_build_compound_expr");
tree
build_compound_expr(tree list)
{
  return internal_build_compound_expr (list, 1);
}

static tree
internal_build_compound_expr(tree list, int first_p) asm("_internal_build_compound_expr");
static tree
internal_build_compound_expr(tree list, int first_p)
{
  register tree rest;

  if (((list)->common.chain) == 0)
    {
      if (!first_p && integer_zerop (((list)->list.value)))
 return non_lvalue (((list)->list.value));
      return ((list)->list.value);
    }

  if (((list)->common.chain) != 0 && ((((list)->common.chain))->common.chain) == 0)
    {

      if (((n64_enum_tree_code) (((((((list)->common.chain))->list.value))->common.type))->common.code) == ARRAY_TYPE)
 ((((list)->common.chain))->list.value)
   = default_conversion (((((list)->common.chain))->list.value));
    }

  rest = internal_build_compound_expr (((list)->common.chain), 0);

  if (! ((((list)->list.value))->common.side_effects_flag))
    {



      if ((extra_warnings || warn_unused)
           && ! (((n64_enum_tree_code) (((list)->list.value))->common.code) == CONVERT_EXPR
                && ((((list)->list.value))->common.type) == void_type_node))
        warning ("left-hand operand of comma expression has no effect");



      if (! pedantic)
        return rest;
    }





  else if (warn_unused)
    warn_if_unused_value (((list)->list.value));

  return build (COMPOUND_EXPR, ((rest)->common.type), ((list)->list.value), rest);
}



tree
build_c_cast(register tree type, tree expr) asm("_build_c_cast");
tree
build_c_cast(register tree type, tree expr)
{
  register tree value = expr;

  if (type == error_mark_node || expr == error_mark_node)
    return error_mark_node;
  type = ((type)->type.main_variant);







  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
      error ("cast specifies array type");
      return error_mark_node;
    }

  if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
    {
      error ("cast specifies function type");
      return error_mark_node;
    }

  if (type == ((value)->common.type))
    {
      if (pedantic)
 {
   if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
       || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
     pedwarn ("ANSI C forbids casting nonscalar to the same type");
 }
    }
  else if (((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
    {
      tree field;
      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == ARRAY_TYPE
   || ((n64_enum_tree_code) (((value)->common.type))->common.code) == FUNCTION_TYPE)
 value = default_conversion (value);

      for (field = ((type)->type.values); field; field = ((field)->common.chain))
 if (comptypes (((((field)->common.type))->type.main_variant),
         ((((value)->common.type))->type.main_variant)))
   break;

      if (field)
 {
   char *name;
   tree t;

   if (pedantic)
     pedwarn ("ANSI C forbids casts to union type");
   if (((type)->type.name) != 0)
     {
       if (((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE)
  name = ((((type)->type.name))->identifier.pointer);
       else
  name = ((((((type)->type.name))->decl.name))->identifier.pointer);
     }
   else
     name = "";
   t = digest_init (type, build (CONSTRUCTOR, type, (tree) 
                                                   ((void *)0)
                                                            ,
     build_tree_list (field, value)),
      0, 0);
   ((t)->common.constant_flag) = ((value)->common.constant_flag);
   return t;
 }
      error ("cast to union type from type not present in union");
      return error_mark_node;
    }
  else
    {
      tree otype, ovalue;



      if (type == void_type_node)
 return build1 (CONVERT_EXPR, type, value);



      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == FUNCTION_TYPE
   || ((n64_enum_tree_code) (((value)->common.type))->common.code) == ARRAY_TYPE)
 value = default_conversion (value);
      otype = ((value)->common.type);



      if (warn_cast_qual
   && ((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == POINTER_TYPE)
 {
   if (((((otype)->common.type))->common.volatile_flag)
       && ! ((((type)->common.type))->common.volatile_flag))
     pedwarn ("cast discards `volatile' from pointer target type");
   if (((((otype)->common.type))->common.readonly_flag)
       && ! ((((type)->common.type))->common.readonly_flag))
     pedwarn ("cast discards `const' from pointer target type");
 }


      if (1 && warn_cast_align
   && ((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (((otype)->common.type))->common.code) != VOID_TYPE
   && ((n64_enum_tree_code) (((otype)->common.type))->common.code) != FUNCTION_TYPE
   && ((((type)->common.type))->type.align) > ((((otype)->common.type))->type.align))
 warning ("cast increases required alignment of target type");

      if (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == POINTER_TYPE
   && ((type)->type.precision) != ((otype)->type.precision)
   && !((value)->common.constant_flag))
 warning ("cast from pointer to integer of different size");

      if (warn_bad_function_cast
   && ((n64_enum_tree_code) (value)->common.code) == CALL_EXPR
   && ((n64_enum_tree_code) (type)->common.code) != ((n64_enum_tree_code) (otype)->common.code))
 warning ("cast does not match function type");

      if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == INTEGER_TYPE
   && ((type)->type.precision) != ((otype)->type.precision)






   && !((value)->common.constant_flag))
 warning ("cast to pointer from integer of different size");

      ovalue = value;
      value = convert (type, value);


      if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST)
 {
   ((value)->common.public_flag) = ((ovalue)->common.public_flag);
   ((value)->common.static_flag) = ((ovalue)->common.static_flag);
 }
    }


  if (pedantic && ((n64_enum_tree_code) (value)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (expr)->common.code) == INTEGER_CST
      && ((n64_enum_tree_code) (((expr)->common.type))->common.code) != INTEGER_TYPE)
    value = non_lvalue (value);


  if (value == expr && pedantic)
    value = non_lvalue (value);

  return value;
}






tree
build_modify_expr(tree lhs, n64_enum_tree_code modifycode, tree rhs) asm("_build_modify_expr");
tree
build_modify_expr(tree lhs, n64_enum_tree_code modifycode, tree rhs)
{
  register tree result;
  tree newrhs;
  tree lhstype = ((lhs)->common.type);
  tree olhstype = lhstype;


  lhs = require_complete_type (lhs);


  if (((n64_enum_tree_code) (lhs)->common.code) == ERROR_MARK || ((n64_enum_tree_code) (rhs)->common.code) == ERROR_MARK)
    return error_mark_node;




  if (((n64_enum_tree_code) (rhs)->common.code) == NON_LVALUE_EXPR)
    rhs = ((rhs)->exp.operands[0]);

  newrhs = rhs;



  switch (((n64_enum_tree_code) (lhs)->common.code))
    {

    case COMPOUND_EXPR:
      pedantic_lvalue_warning (COMPOUND_EXPR);
      newrhs = build_modify_expr (((lhs)->exp.operands[1]),
      modifycode, rhs);
      if (((n64_enum_tree_code) (newrhs)->common.code) == ERROR_MARK)
 return error_mark_node;
      return build (COMPOUND_EXPR, lhstype,
      ((lhs)->exp.operands[0]), newrhs);


    case COND_EXPR:
      pedantic_lvalue_warning (COND_EXPR);
      rhs = save_expr (rhs);
      {



 tree cond
   = build_conditional_expr (((lhs)->exp.operands[0]),
        build_modify_expr (((lhs)->exp.operands[1]),
             modifycode, rhs),
        build_modify_expr (((lhs)->exp.operands[2]),
             modifycode, rhs));
 if (((n64_enum_tree_code) (cond)->common.code) == ERROR_MARK)
   return cond;


 return build (COMPOUND_EXPR, ((lhs)->common.type),

        convert (void_type_node, rhs), cond);
      }
    }




  if (modifycode != NOP_EXPR)
    {
      lhs = stabilize_reference (lhs);
      newrhs = build_binary_op (modifycode, lhs, rhs, 1);
    }
  switch (((n64_enum_tree_code) (lhs)->common.code))
    {
    case NOP_EXPR:
    case CONVERT_EXPR:
    case FLOAT_EXPR:
    case FIX_TRUNC_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_ROUND_EXPR:
    case FIX_CEIL_EXPR:
      if (((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == ARRAY_TYPE
   || ((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == FUNCTION_TYPE)
 newrhs = default_conversion (newrhs);
      {
 tree inner_lhs = ((lhs)->exp.operands[0]);
 tree result;
 result = build_modify_expr (inner_lhs, NOP_EXPR,
        convert (((inner_lhs)->common.type),
          convert (lhstype, newrhs)));
 if (((n64_enum_tree_code) (result)->common.code) == ERROR_MARK)
   return result;
 pedantic_lvalue_warning (CONVERT_EXPR);
 return convert (((lhs)->common.type), result);
      }
    }




  if (!lvalue_or_else (lhs, "assignment"))
    return error_mark_node;



  if (((lhs)->common.readonly_flag) || ((lhstype)->common.readonly_flag)
      || ((((n64_enum_tree_code) (lhstype)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (lhstype)->common.code) == UNION_TYPE)
   && ((lhstype)->common.lang_flag_1)))
    readonly_warning (lhs, "assignment");






  if (((n64_enum_tree_code) (lhs)->common.code) == COMPONENT_REF
      && (((n64_enum_tree_code) (lhstype)->common.code) == INTEGER_TYPE
   || ((n64_enum_tree_code) (lhstype)->common.code) == REAL_TYPE
   || ((n64_enum_tree_code) (lhstype)->common.code) == ENUMERAL_TYPE))
    lhstype = ((get_unwidened (lhs, 0))->common.type);




  if (lhstype != ((lhs)->common.type))
    {
      lhs = copy_node (lhs);
      ((lhs)->common.type) = lhstype;
    }



  newrhs = convert_for_assignment (lhstype, newrhs, "assignment",
       (tree) 
      ((void *)0)
               , (tree) 
                 ((void *)0)
                          , 0);
  if (((n64_enum_tree_code) (newrhs)->common.code) == ERROR_MARK)
    return error_mark_node;

  result = build (MODIFY_EXPR, lhstype, lhs, newrhs);
  ((result)->common.side_effects_flag) = 1;






  if (olhstype == ((result)->common.type))
    return result;
  return convert_for_assignment (olhstype, result, "assignment",
     (tree) 
    ((void *)0)
             , (tree) 
               ((void *)0)
                        , 0);
}
static tree
convert_for_assignment(tree type, tree rhs, char *errtype, tree fundecl, tree funname, int parmnum) asm("_convert_for_assignment");
static tree
convert_for_assignment(tree type, tree rhs, char *errtype, tree fundecl, tree funname, int parmnum)
{
  register n64_enum_tree_code codel = ((n64_enum_tree_code) (type)->common.code);
  register tree rhstype;
  register n64_enum_tree_code coder;




  if (((n64_enum_tree_code) (rhs)->common.code) == NON_LVALUE_EXPR)
    rhs = ((rhs)->exp.operands[0]);

  if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == ARRAY_TYPE
      || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == FUNCTION_TYPE)
    rhs = default_conversion (rhs);
  else if (optimize && ((n64_enum_tree_code) (rhs)->common.code) == VAR_DECL)
    rhs = decl_constant_value (rhs);

  rhstype = ((rhs)->common.type);
  coder = ((n64_enum_tree_code) (rhstype)->common.code);

  if (coder == ERROR_MARK)
    return error_mark_node;

  if (((type)->type.main_variant) == ((rhstype)->type.main_variant))
    {
      overflow_warning (rhs);


      maybe_objc_comptypes (type, rhstype, 0);
      return rhs;
    }

  if (coder == VOID_TYPE)
    {
      error ("void value not ignored as it ought to be");
      return error_mark_node;
    }

  if ((codel == INTEGER_TYPE || codel == REAL_TYPE || codel == ENUMERAL_TYPE
       || codel == COMPLEX_TYPE)
      && (coder == INTEGER_TYPE || coder == REAL_TYPE || coder == ENUMERAL_TYPE
   || coder == COMPLEX_TYPE))
    return convert_and_check (type, rhs);


  else if (codel == UNION_TYPE)
    {
      tree memb_types;

      for (memb_types = ((type)->type.values); memb_types;
    memb_types = ((memb_types)->common.chain))
 {
   if (comptypes (((memb_types)->common.type), ((rhs)->common.type)))
     {
       if (pedantic
    && !(fundecl != 0 && ((fundecl)->decl.in_system_header_flag)))
  pedwarn ("ANSI C prohibits argument conversion to union type");
       return build1 (NOP_EXPR, type, rhs);
     }

   else if (coder == POINTER_TYPE
     && ((n64_enum_tree_code) (((memb_types)->common.type))->common.code) == POINTER_TYPE)
     {
       tree memb_type = ((memb_types)->common.type);
       register tree ttl = ((memb_type)->common.type);
       register tree ttr = ((rhstype)->common.type);





       if (((ttl)->type.main_variant) == void_type_node
    || ((ttr)->type.main_variant) == void_type_node
    || comp_target_types (memb_type, rhstype))
  {


    if (((n64_enum_tree_code) (ttr)->common.code) != FUNCTION_TYPE
        || ((n64_enum_tree_code) (ttl)->common.code) != FUNCTION_TYPE)
      {
        if (! ((ttl)->common.readonly_flag) && ((ttr)->common.readonly_flag))
   warn_for_assignment ("%s discards `const' from pointer target type",
          get_spelling (errtype), funname,
          parmnum);
        if (! ((ttl)->common.volatile_flag) && ((ttr)->common.volatile_flag))
   warn_for_assignment ("%s discards `volatile' from pointer target type",
          get_spelling (errtype), funname,
          parmnum);
      }
    else
      {





        if (((ttl)->common.readonly_flag) && ! ((ttr)->common.readonly_flag))
   warn_for_assignment ("%s makes `const *' function pointer from non-const",
          get_spelling (errtype), funname,
          parmnum);
        if (((ttl)->common.volatile_flag) && ! ((ttr)->common.volatile_flag))
   warn_for_assignment ("%s makes `volatile *' function pointer from non-volatile",
          get_spelling (errtype), funname,
          parmnum);
      }

    if (pedantic
        && !(fundecl != 0 && ((fundecl)->decl.in_system_header_flag)))
      pedwarn ("ANSI C prohibits argument conversion to union type");
    return build1 (NOP_EXPR, type, rhs);
  }
     }


   else if (((n64_enum_tree_code) (((memb_types)->common.type))->common.code) == POINTER_TYPE
     && (integer_zerop (rhs)
         || (((n64_enum_tree_code) (rhs)->common.code) == NOP_EXPR
      && integer_zerop (((rhs)->exp.operands[0])))))
     return build1 (NOP_EXPR, type, null_pointer_node);
 }
    }


  else if (codel == POINTER_TYPE && coder == POINTER_TYPE)
    {
      register tree ttl = ((type)->common.type);
      register tree ttr = ((rhstype)->common.type);




      if (((ttl)->type.main_variant) == void_type_node
   || ((ttr)->type.main_variant) == void_type_node
   || comp_target_types (type, rhstype)
   || (unsigned_type (((ttl)->type.main_variant))
       == unsigned_type (((ttr)->type.main_variant))))
 {
   if (pedantic
       && ((((ttl)->type.main_variant) == void_type_node
     && ((n64_enum_tree_code) (ttr)->common.code) == FUNCTION_TYPE)
    ||
    (((ttr)->type.main_variant) == void_type_node


     && (!integer_zerop (rhs) || ((n64_enum_tree_code) (rhs)->common.code) == NOP_EXPR)
     && ((n64_enum_tree_code) (ttl)->common.code) == FUNCTION_TYPE)))
     warn_for_assignment ("ANSI forbids %s between function pointer and `void *'",
     get_spelling (errtype), funname, parmnum);


   else if (((n64_enum_tree_code) (ttr)->common.code) != FUNCTION_TYPE
     && ((n64_enum_tree_code) (ttl)->common.code) != FUNCTION_TYPE)
     {
       if (! ((ttl)->common.readonly_flag) && ((ttr)->common.readonly_flag))
  warn_for_assignment ("%s discards `const' from pointer target type",
         get_spelling (errtype), funname, parmnum);
       else if (! ((ttl)->common.volatile_flag) && ((ttr)->common.volatile_flag))
  warn_for_assignment ("%s discards `volatile' from pointer target type",
         get_spelling (errtype), funname, parmnum);


       else if (((ttl)->type.main_variant) == void_type_node
         || ((ttr)->type.main_variant) == void_type_node
         || comp_target_types (type, rhstype))
  ;

       else if (pedantic)
  warn_for_assignment ("pointer targets in %s differ in signedness",
         get_spelling (errtype), funname, parmnum);
     }
   else if (((n64_enum_tree_code) (ttl)->common.code) == FUNCTION_TYPE
     && ((n64_enum_tree_code) (ttr)->common.code) == FUNCTION_TYPE)
     {




       if (((ttl)->common.readonly_flag) && ! ((ttr)->common.readonly_flag))
  warn_for_assignment ("%s makes `const *' function pointer from non-const",
         get_spelling (errtype), funname, parmnum);
       if (((ttl)->common.volatile_flag) && ! ((ttr)->common.volatile_flag))
  warn_for_assignment ("%s makes `volatile *' function pointer from non-volatile",
         get_spelling (errtype), funname, parmnum);
     }
 }
      else
 warn_for_assignment ("%s from incompatible pointer type",
        get_spelling (errtype), funname, parmnum);
      return convert (type, rhs);
    }
  else if (codel == POINTER_TYPE && coder == INTEGER_TYPE)
    {



      if (! (((n64_enum_tree_code) (rhs)->common.code) == INTEGER_CST && integer_zerop (rhs))
   &&
   ! (((n64_enum_tree_code) (rhs)->common.code) == NOP_EXPR
      && ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == INTEGER_TYPE
      && ((n64_enum_tree_code) (((rhs)->exp.operands[0]))->common.code) == INTEGER_CST
      && integer_zerop (((rhs)->exp.operands[0]))))
 {
   warn_for_assignment ("%s makes pointer from integer without a cast",
          get_spelling (errtype), funname, parmnum);
   return convert (type, rhs);
 }
      return null_pointer_node;
    }
  else if (codel == INTEGER_TYPE && coder == POINTER_TYPE)
    {
      warn_for_assignment ("%s makes integer from pointer without a cast",
      get_spelling (errtype), funname, parmnum);
      return convert (type, rhs);
    }

  if (!errtype)
    {
      if (funname)
  {
    tree selector = maybe_building_objc_message_expr ();

    if (selector && parmnum > 2)
      error ("incompatible type for argument %d of `%s'",
     parmnum - 2, ((selector)->identifier.pointer));
    else
     error ("incompatible type for argument %d of `%s'",
     parmnum, ((funname)->identifier.pointer));
 }
      else
 error ("incompatible type for argument %d of indirect function call",
        parmnum);
    }
  else
    error ("incompatible types in %s", get_spelling (errtype));

  return error_mark_node;
}







static void
warn_for_assignment(char *msg, char *opname, tree function, int argnum) asm("_warn_for_assignment");
static void
warn_for_assignment(char *msg, char *opname, tree function, int argnum)
{
  static char argstring[] = "passing arg %d of `%s'";
  static char argnofun[] = "passing arg %d";

  if (opname == 0)
    {
      tree selector = maybe_building_objc_message_expr ();

      if (selector && argnum > 2)
 {
   function = selector;
   argnum -= 2;
 }
      if (function)
 {

   opname = (char *) 
                    __builtin_alloca((
                    ((function)->identifier.length) + sizeof (argstring) + 25 + 1
                    ))
                                             
                                            ;
   sprintf (opname, argstring, argnum, ((function)->identifier.pointer));
 }
      else
 {

   opname = (char *) 
                    __builtin_alloca((
                    sizeof (argnofun) + 25 + 1
                    ))
                                                              ;
   sprintf (opname, argnofun, argnum);
 }
    }
  pedwarn (msg, opname);
}
tree
initializer_constant_valid_p(tree value, tree endtype) asm("_initializer_constant_valid_p");
tree
initializer_constant_valid_p(tree value, tree endtype)
{
  switch (((n64_enum_tree_code) (value)->common.code))
    {
    case CONSTRUCTOR:
      if ((((n64_enum_tree_code) (((value)->common.type))->common.code) == UNION_TYPE
    || ((n64_enum_tree_code) (((value)->common.type))->common.code) == RECORD_TYPE)
   && ((value)->common.constant_flag))
 return
   initializer_constant_valid_p (((((value)->exp.operands[1]))->list.value),
     endtype);

      return ((value)->common.static_flag) ? null_pointer_node : 0;

    case INTEGER_CST:
    case REAL_CST:
    case STRING_CST:
    case COMPLEX_CST:
      return null_pointer_node;

    case ADDR_EXPR:
      return ((value)->exp.operands[0]);

    case NON_LVALUE_EXPR:
      return initializer_constant_valid_p (((value)->exp.operands[0]), endtype);

    case CONVERT_EXPR:
    case NOP_EXPR:

      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == POINTER_TYPE)
 return initializer_constant_valid_p (((value)->exp.operands[0]), endtype);


      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == REAL_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == REAL_TYPE)
 return initializer_constant_valid_p (((value)->exp.operands[0]), endtype);


      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == INTEGER_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == INTEGER_TYPE
   && (((((value)->common.type))->type.precision)
       == ((((((value)->exp.operands[0]))->common.type))->type.precision)))
 return initializer_constant_valid_p (((value)->exp.operands[0]), endtype);



      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == INTEGER_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == INTEGER_TYPE)
 {
   tree inner = initializer_constant_valid_p (((value)->exp.operands[0]),
           endtype);
   if (inner == null_pointer_node)
     return null_pointer_node;
   return 0;
 }


      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == INTEGER_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == POINTER_TYPE
   && (((((value)->common.type))->type.precision)
       >= ((((((value)->exp.operands[0]))->common.type))->type.precision)))
 return initializer_constant_valid_p (((value)->exp.operands[0]),
          endtype);


      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (((((value)->exp.operands[0]))->common.type))->common.code) == INTEGER_TYPE
   && (((((value)->common.type))->type.precision)
       <= ((((((value)->exp.operands[0]))->common.type))->type.precision)))
 return initializer_constant_valid_p (((value)->exp.operands[0]),
          endtype);


      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == UNION_TYPE)
 return initializer_constant_valid_p (((value)->exp.operands[0]),
          endtype);
      return 0;

    case PLUS_EXPR:
      if (((n64_enum_tree_code) (endtype)->common.code) == INTEGER_TYPE
   && ((endtype)->type.precision) < ((target_flags & 0x00000002) ? 64 : 32))
 return 0;
      {
 tree valid0 = initializer_constant_valid_p (((value)->exp.operands[0]),
          endtype);
 tree valid1 = initializer_constant_valid_p (((value)->exp.operands[1]),
          endtype);

 if (valid0 == null_pointer_node)
   return valid1;
 if (valid1 == null_pointer_node)
   return valid0;
 return 0;
      }

    case MINUS_EXPR:
      if (((n64_enum_tree_code) (endtype)->common.code) == INTEGER_TYPE
   && ((endtype)->type.precision) < ((target_flags & 0x00000002) ? 64 : 32))
 return 0;
      {
 tree valid0 = initializer_constant_valid_p (((value)->exp.operands[0]),
          endtype);
 tree valid1 = initializer_constant_valid_p (((value)->exp.operands[1]),
          endtype);

 if (valid1 == null_pointer_node)
   return valid0;


 if (valid0 == valid1)
   return null_pointer_node;
 return 0;
      }
    }

  return 0;
}







static tree
valid_compound_expr_initializer(tree value, tree endtype) asm("_valid_compound_expr_initializer");
static tree
valid_compound_expr_initializer(tree value, tree endtype)
{
  if (((n64_enum_tree_code) (value)->common.code) == COMPOUND_EXPR)
    {
      if (valid_compound_expr_initializer (((value)->exp.operands[0]), endtype)
   == error_mark_node)
 return error_mark_node;
      return valid_compound_expr_initializer (((value)->exp.operands[1]),
           endtype);
    }
  else if (! ((value)->common.constant_flag)
    && ! initializer_constant_valid_p (value, endtype))
    return error_mark_node;
  else
    return value;
}






void
store_init_value(tree decl, tree init) asm("_store_init_value");
void
store_init_value(tree decl, tree init)
{
  register tree value, type;



  type = ((decl)->common.type);
  if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
    return;



  value = digest_init (type, init, ((decl)->common.static_flag),
         ((decl)->common.static_flag) || pedantic);
  ((decl)->decl.initial) = value;


  while ((((n64_enum_tree_code) (value)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (value)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR) && (((value)->common.type) == ((((value)->exp.operands[0]))->common.type))) (value) = ((value)->exp.operands[0]);;
  constant_expression_warning (value);
}






struct n64_tag_spelling
{
  int kind;
  union
    {
      int i;
      char *s;
    } u;
};





static struct n64_tag_spelling *spelling;
static struct n64_tag_spelling *spelling_base;
static int spelling_size;
static void
push_string(char *string) asm("_push_string");
static void
push_string(char *string)
{
  { int depth = (spelling - spelling_base); if (depth >= spelling_size) { spelling_size += 10; if (spelling_base == 0) spelling_base = (struct n64_tag_spelling *) xmalloc (spelling_size * sizeof (struct n64_tag_spelling)); else spelling_base = (struct n64_tag_spelling *) xrealloc (spelling_base, spelling_size * sizeof (struct n64_tag_spelling)); (spelling = spelling_base + depth); } spelling->kind = (1); spelling->u.s = (string); spelling++; };
}



static void
push_member_name(tree decl) asm("_push_member_name");
static void
push_member_name(tree decl)
{
  char *string
    = ((decl)->decl.name) ? ((((decl)->decl.name))->identifier.pointer) : "<anonymous>";
  { int depth = (spelling - spelling_base); if (depth >= spelling_size) { spelling_size += 10; if (spelling_base == 0) spelling_base = (struct n64_tag_spelling *) xmalloc (spelling_size * sizeof (struct n64_tag_spelling)); else spelling_base = (struct n64_tag_spelling *) xrealloc (spelling_base, spelling_size * sizeof (struct n64_tag_spelling)); (spelling = spelling_base + depth); } spelling->kind = (2); spelling->u.s = (string); spelling++; };
}



static void
push_array_bounds(int bounds) asm("_push_array_bounds");
static void
push_array_bounds(int bounds)
{
  { int depth = (spelling - spelling_base); if (depth >= spelling_size) { spelling_size += 10; if (spelling_base == 0) spelling_base = (struct n64_tag_spelling *) xmalloc (spelling_size * sizeof (struct n64_tag_spelling)); else spelling_base = (struct n64_tag_spelling *) xrealloc (spelling_base, spelling_size * sizeof (struct n64_tag_spelling)); (spelling = spelling_base + depth); } spelling->kind = (3); spelling->u.i = (bounds); spelling++; };
}



static int
spelling_length(void) asm("_spelling_length");
static int
spelling_length(void)
{
  register int size = 0;
  register struct n64_tag_spelling *p;

  for (p = spelling_base; p < spelling; p++)
    {
      if (p->kind == 3)
 size += 25;
      else
 size += strlen (p->u.s) + 1;
    }

  return size;
}



static char *
print_spelling(register char *buffer) asm("_print_spelling");
static char *
print_spelling(register char *buffer)
{
  register char *d = buffer;
  register char *s;
  register struct n64_tag_spelling *p;

  for (p = spelling_base; p < spelling; p++)
    if (p->kind == 3)
      {
 sprintf (d, "[%d]", p->u.i);
 d += strlen (d);
      }
    else
      {
 if (p->kind == 2)
   *d++ = '.';
 for (s = p->u.s; *d = *s++; d++)
   ;
      }
  *d++ = '\0';
  return buffer;
}



char initialization_message;



static char *
get_spelling(char *errtype) asm("_get_spelling");
static char *
get_spelling(char *errtype)
{
  static char *buffer;
  static int size = -1;

  if (errtype == &initialization_message)
    {

      static char message[] = "initialization of `%s'";
      register int needed = sizeof (message) + spelling_length () + 1;
      char *temp;

      if (size < 0)
 buffer = (char *) xmalloc (size = needed);
      if (needed > size)
 buffer = (char *) xrealloc (buffer, size = needed);

      temp = (char *) 
                     __builtin_alloca((
                     needed
                     ))
                                    ;
      sprintf (buffer, message, print_spelling (temp));
      return buffer;
    }

  return errtype;
}
void
error_init(char *format, char *local, char *ofwhat) asm("_error_init");
void
error_init(char *format, char *local, char *ofwhat)
{
  char *buffer;

  if (ofwhat == 0)
    ofwhat = print_spelling ((char *) 
                                     __builtin_alloca((
                                     spelling_length () + 1
                                     ))
                                                                    );
  buffer = (char *) 
                   __builtin_alloca((
                   strlen (local) + strlen (ofwhat) + 2
                   ))
                                                                ;

  if (*ofwhat)
    sprintf (buffer, local, ofwhat);
  else
    buffer[0] = 0;

  error (format, buffer);
}
void
pedwarn_init(char *format, char *local, char *ofwhat) asm("_pedwarn_init");
void
pedwarn_init(char *format, char *local, char *ofwhat)
{
  char *buffer;

  if (ofwhat == 0)
    ofwhat = print_spelling ((char *) 
                                     __builtin_alloca((
                                     spelling_length () + 1
                                     ))
                                                                    );
  buffer = (char *) 
                   __builtin_alloca((
                   strlen (local) + strlen (ofwhat) + 2
                   ))
                                                                ;

  if (*ofwhat)
    sprintf (buffer, local, ofwhat);
  else
    buffer[0] = 0;

  pedwarn (format, buffer);
}
static void
warning_init(char *format, char *local, char *ofwhat) asm("_warning_init");
static void
warning_init(char *format, char *local, char *ofwhat)
{
  char *buffer;

  if (ofwhat == 0)
    ofwhat = print_spelling ((char *) 
                                     __builtin_alloca((
                                     spelling_length () + 1
                                     ))
                                                                    );
  buffer = (char *) 
                   __builtin_alloca((
                   strlen (local) + strlen (ofwhat) + 2
                   ))
                                                                ;

  if (*ofwhat)
    sprintf (buffer, local, ofwhat);
  else
    buffer[0] = 0;

  warning (format, buffer);
}
static tree
digest_init(tree type, tree init, int require_constant, int constructor_constant) asm("_digest_init");
static tree
digest_init(tree type, tree init, int require_constant, int constructor_constant)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree inside_init = init;

  if (init == error_mark_node)
    return init;




  if (((n64_enum_tree_code) (init)->common.code) == NON_LVALUE_EXPR)
    inside_init = ((init)->exp.operands[0]);




  if (code == ARRAY_TYPE)
    {
      tree typ1 = ((((type)->common.type))->type.main_variant);
      if ((typ1 == char_type_node
    || typ1 == signed_char_type_node
    || typ1 == unsigned_char_type_node
    || typ1 == unsigned_wchar_type_node
    || typ1 == signed_wchar_type_node)
   && ((inside_init && ((n64_enum_tree_code) (inside_init)->common.code) == STRING_CST)))
 {
   if (comptypes (((((inside_init)->common.type))->type.main_variant),
    ((type)->type.main_variant)))
     return inside_init;

   if ((((((((inside_init)->common.type))->common.type))->type.main_variant)
        != char_type_node)
       && ((typ1)->type.precision) == ((char_type_node)->type.precision))
     {
       error_init ("char-array%s initialized from wide string",
     " `%s'", 
             ((void *)0)
                 );
       return error_mark_node;
     }
   if ((((((((inside_init)->common.type))->common.type))->type.main_variant)
        == char_type_node)
       && ((typ1)->type.precision) != ((char_type_node)->type.precision))
     {
       error_init ("int-array%s initialized from non-wide string",
     " `%s'", 
             ((void *)0)
                 );
       return error_mark_node;
     }

   ((inside_init)->common.type) = type;
   if (((type)->type.values) != 0
       && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST)
     {
       register int size = ((((type)->type.size))->int_cst.int_cst_low);
       size = (size + 8 - 1) / 8;



       if (size < ((inside_init)->string.length)
    - (((typ1)->type.precision) != ((char_type_node)->type.precision)
       ? ((wchar_type_node)->type.precision) / 8
       : 1))
  pedwarn_init (
    "initializer-string for array of chars%s is too long",
    " `%s'", 
            ((void *)0)
                );
     }
   return inside_init;
 }
    }




  if (inside_init && ((inside_init)->common.type) != 0
      && (comptypes (((((inside_init)->common.type))->type.main_variant),
       ((type)->type.main_variant))
   || (code == ARRAY_TYPE
       && comptypes (((inside_init)->common.type), type))
   || (code == POINTER_TYPE
       && (((n64_enum_tree_code) (((inside_init)->common.type))->common.code) == ARRAY_TYPE
    || ((n64_enum_tree_code) (((inside_init)->common.type))->common.code) == FUNCTION_TYPE)
       && comptypes (((((inside_init)->common.type))->common.type),
       ((type)->common.type)))))
    {
      if (code == POINTER_TYPE
   && (((n64_enum_tree_code) (((inside_init)->common.type))->common.code) == ARRAY_TYPE
       || ((n64_enum_tree_code) (((inside_init)->common.type))->common.code) == FUNCTION_TYPE))
 inside_init = default_conversion (inside_init);
      else if (code == ARRAY_TYPE && ((n64_enum_tree_code) (inside_init)->common.code) != STRING_CST
        && ((n64_enum_tree_code) (inside_init)->common.code) != CONSTRUCTOR)
 {
   error_init ("array%s initialized from non-constant array expression",
        " `%s'", 
                ((void *)0)
                    );
   return error_mark_node;
 }

      if (optimize && ((n64_enum_tree_code) (inside_init)->common.code) == VAR_DECL)
 inside_init = decl_constant_value (inside_init);




      if (require_constant && pedantic
   && ((n64_enum_tree_code) (inside_init)->common.code) == COMPOUND_EXPR)
 {
   inside_init
     = valid_compound_expr_initializer (inside_init,
            ((inside_init)->common.type));
   if (inside_init == error_mark_node)
     error_init ("initializer element%s is not constant",
   " for `%s'", 
               ((void *)0)
                   );
   else
     pedwarn_init ("initializer element%s is not constant",
     " for `%s'", 
                 ((void *)0)
                     );
   if (flag_pedantic_errors)
     inside_init = error_mark_node;
 }
      else if (require_constant && ! ((inside_init)->common.constant_flag))
 {
   error_init ("initializer element%s is not constant",
        " for `%s'", 
                    ((void *)0)
                        );
   inside_init = error_mark_node;
 }
      else if (require_constant
        && initializer_constant_valid_p (inside_init, ((inside_init)->common.type)) == 0)
 {
   error_init ("initializer element%s is not computable at load time",
        " for `%s'", 
                    ((void *)0)
                        );
   inside_init = error_mark_node;
 }

      return inside_init;
    }



  if (code == INTEGER_TYPE || code == REAL_TYPE || code == POINTER_TYPE
      || code == ENUMERAL_TYPE || code == COMPLEX_TYPE)
    {



      inside_init
 = convert_for_assignment (type, init, "initialization",
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         , 0);

      if (require_constant && ! ((inside_init)->common.constant_flag))
 {
   error_init ("initializer element%s is not constant",
        " for `%s'", 
                    ((void *)0)
                        );
   inside_init = error_mark_node;
 }
      else if (require_constant
        && initializer_constant_valid_p (inside_init, ((inside_init)->common.type)) == 0)
 {
   error_init ("initializer element%s is not computable at load time",
        " for `%s'", 
                    ((void *)0)
                        );
   inside_init = error_mark_node;
 }

      return inside_init;
    }



  if (((type)->type.size) && ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
    {
      error_init ("variable-sized object%s may not be initialized",
    " `%s'", 
            ((void *)0)
                );
      return error_mark_node;
    }



  if (flag_traditional)
    {
      tree top = 0, prev = 0, otype = type;
      while (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
 {
   tree temp = build (CONSTRUCTOR, type, (tree) 
                                        ((void *)0)
                                                 , (tree) 
                                                   ((void *)0)
                                                            );
   if (prev == 0)
     top = temp;
   else
     ((prev)->exp.operands[1]) = build_tree_list ((tree) 
                                              ((void *)0)
                                                       , temp);
   prev = temp;
   if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
     type = ((type)->common.type);
   else if (((type)->type.values))
     type = ((((type)->type.values))->common.type);
   else
     {
       error_init ("invalid initializer%s", " for `%s'", 
                                                        ((void *)0)
                                                            );
       return error_mark_node;
     }
 }

      if (otype != type)
 {
   ((prev)->exp.operands[1])
     = build_tree_list ((tree) 
                       ((void *)0)
                                ,
          digest_init (type, init, require_constant,
         constructor_constant));
   return top;
 }
      else
 return error_mark_node;
    }
  error_init ("invalid initializer%s", " for `%s'", 
                                                   ((void *)0)
                                                       );
  return error_mark_node;
}





static tree constructor_type;



static tree constructor_fields;




static tree constructor_index;




static tree constructor_range_end;


static tree constructor_max_index;


static tree constructor_unfilled_fields;




static tree constructor_unfilled_index;




static tree constructor_bit_index;




static tree constructor_elements;


static int constructor_constant;


static int constructor_simple;


static int constructor_erroneous;


static int constructor_subconstants_deferred;





static tree constructor_pending_elts;


static int constructor_depth;


int constructor_no_implicit = 0;


static int constructor_implicit;

static int require_constant_value;
static int require_constant_elements;



static int constructor_incremental;




static tree constructor_decl;


static char *constructor_asmspec;


static int constructor_top_level;



static tree constructor_result;





struct n64_tag_constructor_stack
{
  struct n64_tag_constructor_stack *next;
  tree type;
  tree fields;
  tree strchr;
  tree range_end;
  tree max_index;
  tree unfilled_index;
  tree unfilled_fields;
  tree bit_index;
  tree elements;
  int offset;
  tree pending_elts;
  int depth;


  tree replacement_value;
  char constant;
  char simple;
  char implicit;
  char incremental;
  char erroneous;
  char outer;
};

struct n64_tag_constructor_stack *constructor_stack;





struct n64_tag_initializer_stack
{
  struct n64_tag_initializer_stack *next;
  tree decl;
  char *asmspec;
  struct n64_tag_constructor_stack *constructor_stack;
  tree elements;
  struct n64_tag_spelling *spelling;
  struct n64_tag_spelling *spelling_base;
  int spelling_size;
  char top_level;
  char incremental;
  char require_constant_value;
  char require_constant_elements;
  char deferred;
};

struct n64_tag_initializer_stack *initializer_stack;



void
start_init(tree decl, tree asmspec_tree, int top_level) asm("_start_init");
void
start_init(tree decl, tree asmspec_tree, int top_level)
{
  char *locus;
  struct n64_tag_initializer_stack *p
    = (struct n64_tag_initializer_stack *) xmalloc (sizeof (struct n64_tag_initializer_stack));
  char *asmspec = 0;

  if (asmspec_tree)
    asmspec = ((asmspec_tree)->string.pointer);

  p->decl = constructor_decl;
  p->asmspec = constructor_asmspec;
  p->incremental = constructor_incremental;
  p->require_constant_value = require_constant_value;
  p->require_constant_elements = require_constant_elements;
  p->constructor_stack = constructor_stack;
  p->elements = constructor_elements;
  p->spelling = spelling;
  p->spelling_base = spelling_base;
  p->spelling_size = spelling_size;
  p->deferred = constructor_subconstants_deferred;
  p->top_level = constructor_top_level;
  p->next = initializer_stack;
  initializer_stack = p;

  constructor_decl = decl;
  constructor_incremental = top_level;
  constructor_asmspec = asmspec;
  constructor_subconstants_deferred = 0;
  constructor_top_level = top_level;

  if (decl != 0)
    {
      require_constant_value = ((decl)->common.static_flag);
      require_constant_elements
 = ((((decl)->common.static_flag) || pedantic)


    && (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE
        || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE
        || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE
        || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE));
      locus = ((((decl)->decl.name))->identifier.pointer);
      constructor_incremental |= ((decl)->common.static_flag);
    }
  else
    {
      require_constant_value = 0;
      require_constant_elements = 0;
      locus = "(anonymous)";
    }

  constructor_stack = 0;

  missing_braces_mentioned = 0;

  spelling_base = 0;
  spelling_size = 0;
  (spelling = spelling_base + 0);

  if (locus)
    push_string (locus);
}

void
finish_init(void) asm("_finish_init");
void
finish_init(void)
{
  struct n64_tag_initializer_stack *p = initializer_stack;




  if (constructor_subconstants_deferred)
    output_deferred_addressed_constants ();


  while (constructor_stack)
    {
      struct n64_tag_constructor_stack *q = constructor_stack;
      constructor_stack = q->next;
      free (q);
    }


  constructor_decl = p->decl;
  constructor_asmspec = p->asmspec;
  constructor_incremental = p->incremental;
  require_constant_value = p->require_constant_value;
  require_constant_elements = p->require_constant_elements;
  constructor_stack = p->constructor_stack;
  constructor_elements = p->elements;
  spelling = p->spelling;
  spelling_base = p->spelling_base;
  spelling_size = p->spelling_size;
  constructor_subconstants_deferred = p->deferred;
  constructor_top_level = p->top_level;
  initializer_stack = p->next;
  free (p);
}
void
really_start_incremental_init(tree type) asm("_really_start_incremental_init");
void
really_start_incremental_init(tree type)
{
  struct n64_tag_constructor_stack *p
    = (struct n64_tag_constructor_stack *) xmalloc (sizeof (struct n64_tag_constructor_stack));

  if (type == 0)
    type = ((constructor_decl)->common.type);




  check_init_type_bitfields (type);

  p->type = constructor_type;
  p->fields = constructor_fields;
  p->strchr = constructor_index;
  p->range_end = constructor_range_end;
  p->max_index = constructor_max_index;
  p->unfilled_index = constructor_unfilled_index;
  p->unfilled_fields = constructor_unfilled_fields;
  p->bit_index = constructor_bit_index;
  p->elements = constructor_elements;
  p->constant = constructor_constant;
  p->simple = constructor_simple;
  p->erroneous = constructor_erroneous;
  p->pending_elts = constructor_pending_elts;
  p->depth = constructor_depth;
  p->replacement_value = 0;
  p->implicit = 0;
  p->incremental = constructor_incremental;
  p->outer = 0;
  p->next = 0;
  constructor_stack = p;

  constructor_constant = 1;
  constructor_simple = 1;
  constructor_depth = (spelling - spelling_base);
  constructor_elements = 0;
  constructor_pending_elts = 0;
  constructor_type = type;

  if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
      || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
    {
      constructor_fields = ((constructor_type)->type.values);

      while (constructor_fields != 0 && ((constructor_fields)->decl.bit_field_flag)
      && ((constructor_fields)->decl.name) == 0)
 constructor_fields = ((constructor_fields)->common.chain);
      constructor_unfilled_fields = constructor_fields;
      constructor_bit_index = copy_node (integer_zero_node);
    }
  else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
    {
      constructor_range_end = 0;
      if (((constructor_type)->type.values))
 {
   constructor_max_index
     = ((((constructor_type)->type.values))->type.maxval);
   constructor_index
     = copy_node (((((constructor_type)->type.values))->type.minval));
 }
      else
 constructor_index = copy_node (integer_zero_node);
      constructor_unfilled_index = copy_node (constructor_index);
    }
  else
    {

      constructor_fields = constructor_type;
      constructor_unfilled_fields = constructor_type;
    }

  if (constructor_incremental)
    {
      int momentary = suspend_momentary ();
      push_obstacks_nochange ();
      if (((constructor_decl)->common.permanent_flag))
 end_temporary_allocation ();
      make_decl_rtl (constructor_decl, constructor_asmspec,
       constructor_top_level);
      assemble_variable (constructor_decl, constructor_top_level, 0, 1);
      pop_obstacks ();
      resume_momentary (momentary);
    }

  if (constructor_incremental)
    {
      defer_addressed_constants ();
      constructor_subconstants_deferred = 1;
    }
}






void
push_init_level(int implicit) asm("_push_init_level");
void
push_init_level(int implicit)
{
  struct n64_tag_constructor_stack *p;



  while (constructor_stack->implicit)
    {
      if ((((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
   && constructor_fields == 0)
 process_init_element (pop_init_level (1));
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
        && tree_int_cst_lt (constructor_max_index, constructor_index))
 process_init_element (pop_init_level (1));
      else
 break;
    }



  if (constructor_incremental && constructor_type != 0
      && ((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE && constructor_fields)
    {

      if (! tree_int_cst_equal (constructor_bit_index,
    ((constructor_fields)->decl.arguments)))
 {
   int next = (((((constructor_fields)->decl.arguments))->int_cst.int_cst_low)

        / 8);
   int here = (((constructor_bit_index)->int_cst.int_cst_low)
        / 8);

   assemble_zeros (next - here);
 }
    }

  p = (struct n64_tag_constructor_stack *) xmalloc (sizeof (struct n64_tag_constructor_stack));
  p->type = constructor_type;
  p->fields = constructor_fields;
  p->strchr = constructor_index;
  p->range_end = constructor_range_end;
  p->max_index = constructor_max_index;
  p->unfilled_index = constructor_unfilled_index;
  p->unfilled_fields = constructor_unfilled_fields;
  p->bit_index = constructor_bit_index;
  p->elements = constructor_elements;
  p->constant = constructor_constant;
  p->simple = constructor_simple;
  p->erroneous = constructor_erroneous;
  p->pending_elts = constructor_pending_elts;
  p->depth = constructor_depth;
  p->replacement_value = 0;
  p->implicit = implicit;
  p->incremental = constructor_incremental;
  p->outer = 0;
  p->next = constructor_stack;
  constructor_stack = p;

  constructor_constant = 1;
  constructor_simple = 1;
  constructor_depth = (spelling - spelling_base);
  constructor_elements = 0;
  constructor_pending_elts = 0;



  if (constructor_type == 0)
    ;
  else if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
    {

      if (constructor_fields == 0)
 constructor_type = 0;
      else
 {
   constructor_type = ((constructor_fields)->common.type);
   push_member_name (constructor_fields);
   constructor_depth++;
   if (constructor_fields != constructor_unfilled_fields)
     constructor_incremental = 0;
 }
    }
  else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
    {
      constructor_type = ((constructor_type)->common.type);
      push_array_bounds (((constructor_index)->int_cst.int_cst_low));
      constructor_depth++;
      if (! tree_int_cst_equal (constructor_index, constructor_unfilled_index)
   || constructor_range_end != 0)
 constructor_incremental = 0;
    }

  if (constructor_type == 0)
    {
      error_init ("extra brace group at end of initializer%s",
    " for `%s'", 
                ((void *)0)
                    );
      constructor_fields = 0;
      constructor_unfilled_fields = 0;
      return;
    }


  check_init_type_bitfields (constructor_type);

  if (implicit && warn_missing_braces && !missing_braces_mentioned)
    {
      missing_braces_mentioned = 1;
      warning_init ("missing braces around initializer%s", " for `%s'", 
                                                                       ((void *)0)
                                                                           );
    }

  if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
    {
      constructor_fields = ((constructor_type)->type.values);

      while (constructor_fields != 0 && ((constructor_fields)->decl.bit_field_flag)
      && ((constructor_fields)->decl.name) == 0)
 constructor_fields = ((constructor_fields)->common.chain);
      constructor_unfilled_fields = constructor_fields;
      constructor_bit_index = copy_node (integer_zero_node);
    }
  else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
    {
      constructor_range_end = 0;
      if (((constructor_type)->type.values))
 {
   constructor_max_index
     = ((((constructor_type)->type.values))->type.maxval);
   constructor_index
     = copy_node (((((constructor_type)->type.values))->type.minval));
 }
      else
 constructor_index = copy_node (integer_zero_node);
      constructor_unfilled_index = copy_node (constructor_index);
    }
  else
    {
      warning_init ("braces around scalar initializer%s", " for `%s'", 
                                                                      ((void *)0)
                                                                          );
      constructor_fields = constructor_type;
      constructor_unfilled_fields = constructor_type;
    }
}





static void
check_init_type_bitfields(tree type) asm("_check_init_type_bitfields");
static void
check_init_type_bitfields(tree type)
{
  if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE)
    {
      tree tail;
      for (tail = ((type)->type.values); tail;
    tail = ((tail)->common.chain))
 {
   if (((tail)->decl.bit_field_flag)

       || ((tail)->decl.mode) != ((((tail)->common.type))->type.mode))
     {
       constructor_incremental = 0;
       break;
     }

   check_init_type_bitfields (((tail)->common.type));
 }
    }

  else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    check_init_type_bitfields (((type)->common.type));
}
tree
pop_init_level(int implicit) asm("_pop_init_level");
tree
pop_init_level(int implicit)
{
  struct n64_tag_constructor_stack *p;
  int size = 0;
  tree constructor = 0;

  if (implicit == 0)
    {


      while (constructor_stack->implicit)
 process_init_element (pop_init_level (1));
    }

  p = constructor_stack;

  if (constructor_type != 0)
    size = int_size_in_bytes (constructor_type);


  output_pending_init_elements (1);
  if (p->replacement_value)
    {


      constructor = p->replacement_value;



      if (p->next == 0 && constructor_decl != 0
   && constructor_incremental)
 {
   constructor = digest_init (constructor_type, constructor,
         require_constant_value,
         require_constant_elements);



   if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
       && ((constructor_type)->type.values) == 0)
     {
       int failure;
       int momentary_p;

       push_obstacks_nochange ();
       if (((constructor_type)->common.permanent_flag))
  end_temporary_allocation ();

       momentary_p = suspend_momentary ();



       if (constructor_stack->next)
  abort ();

       failure
  = complete_array_type (constructor_type,
           constructor, 0);
       if (failure)
  abort ();

       size = int_size_in_bytes (constructor_type);
       resume_momentary (momentary_p);
       pop_obstacks ();
     }

   output_constant (constructor, size);
 }
    }
  else if (constructor_type == 0)
    ;
  else if (((n64_enum_tree_code) (constructor_type)->common.code) != RECORD_TYPE
    && ((n64_enum_tree_code) (constructor_type)->common.code) != UNION_TYPE
    && ((n64_enum_tree_code) (constructor_type)->common.code) != ARRAY_TYPE
    && ! constructor_incremental)
    {


      if (constructor_elements == 0)
 {
   error_init ("empty scalar initializer%s",
        " for `%s'", 
                    ((void *)0)
                        );
   constructor = error_mark_node;
 }
      else if (((constructor_elements)->common.chain) != 0)
 {
   error_init ("extra elements in scalar initializer%s",
        " for `%s'", 
                    ((void *)0)
                        );
   constructor = ((constructor_elements)->list.value);
 }
      else
 constructor = ((constructor_elements)->list.value);
    }
  else if (! constructor_incremental)
    {
      if (constructor_erroneous)
 constructor = error_mark_node;
      else
 {
   int momentary = suspend_momentary ();

   constructor = build (CONSTRUCTOR, constructor_type, (tree) 
                                                      ((void *)0)
                                                               ,
          nreverse (constructor_elements));
   if (constructor_constant)
     ((constructor)->common.constant_flag) = 1;
   if (constructor_constant && constructor_simple)
     ((constructor)->common.static_flag) = 1;

   resume_momentary (momentary);
 }
    }
  else
    {
      tree filled;
      int momentary = suspend_momentary ();

      if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 {

   filled = size_binop (CEIL_DIV_EXPR,
          constructor_bit_index,
          size_int (8));
 }
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {


   if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
       && ((constructor_type)->type.values) == 0)
     {
       tree maxindex
  = size_binop (MINUS_EXPR,
         constructor_unfilled_index,
         integer_one_node);

       push_obstacks_nochange ();
       if (((constructor_type)->common.permanent_flag))
  end_temporary_allocation ();
       maxindex = copy_node (maxindex);
       ((constructor_type)->type.values) = build_index_type (maxindex);
       ((maxindex)->common.type) = ((constructor_type)->type.values);




       if (pedantic
    && (tree_int_cst_sgn (((((constructor_type)->type.values))->type.maxval))
        < 0))
  error_with_decl (constructor_decl,
     "zero or negative array size `%s'");
       layout_type (constructor_type);
       size = int_size_in_bytes (constructor_type);
       pop_obstacks ();
     }

   filled = size_binop (MULT_EXPR, constructor_unfilled_index,
          size_in_bytes (((constructor_type)->common.type)));
 }
      else
 filled = 0;

      if (filled != 0)
 assemble_zeros (size - ((filled)->int_cst.int_cst_low));

      resume_momentary (momentary);
    }


  constructor_type = p->type;
  constructor_fields = p->fields;
  constructor_index = p->strchr;
  constructor_range_end = p->range_end;
  constructor_max_index = p->max_index;
  constructor_unfilled_index = p->unfilled_index;
  constructor_unfilled_fields = p->unfilled_fields;
  constructor_bit_index = p->bit_index;
  constructor_elements = p->elements;
  constructor_constant = p->constant;
  constructor_simple = p->simple;
  constructor_erroneous = p->erroneous;
  constructor_pending_elts = p->pending_elts;
  constructor_depth = p->depth;
  constructor_incremental = p->incremental;
  (spelling = spelling_base + constructor_depth);

  constructor_stack = p->next;
  free (p);

  if (constructor == 0)
    {
      if (constructor_stack == 0)
 return error_mark_node;
      return (tree) 
            ((void *)0)
                     ;
    }
  return constructor;
}





void
set_init_index(tree first, tree last) asm("_set_init_index");
void
set_init_index(tree first, tree last)
{
  while ((((n64_enum_tree_code) (first)->common.code) == NOP_EXPR
   || ((n64_enum_tree_code) (first)->common.code) == CONVERT_EXPR
   || ((n64_enum_tree_code) (first)->common.code) == NON_LVALUE_EXPR)
  && (((((first)->common.type))->type.mode)
      == ((((((first)->exp.operands[0]))->common.type))->type.mode)))
    (first) = ((first)->exp.operands[0]);
  if (last)
    while ((((n64_enum_tree_code) (last)->common.code) == NOP_EXPR
     || ((n64_enum_tree_code) (last)->common.code) == CONVERT_EXPR
     || ((n64_enum_tree_code) (last)->common.code) == NON_LVALUE_EXPR)
    && (((((last)->common.type))->type.mode)
        == ((((((last)->exp.operands[0]))->common.type))->type.mode)))
      (last) = ((last)->exp.operands[0]);

  if (((n64_enum_tree_code) (first)->common.code) != INTEGER_CST)
    error_init ("nonconstant array index in initializer%s", " for `%s'", 
                                                                        ((void *)0)
                                                                            );
  else if (last != 0 && ((n64_enum_tree_code) (last)->common.code) != INTEGER_CST)
    error_init ("nonconstant array index in initializer%s", " for `%s'", 
                                                                        ((void *)0)
                                                                            );
  else if (tree_int_cst_lt (first, constructor_unfilled_index))
    error_init ("duplicate array index in initializer%s", " for `%s'", 
                                                                      ((void *)0)
                                                                          );
  else
    {
      ((constructor_index)->int_cst.int_cst_low)
 = ((first)->int_cst.int_cst_low);
      ((constructor_index)->int_cst.int_cst_high)
 = ((first)->int_cst.int_cst_high);

      if (last != 0 && tree_int_cst_lt (last, first))
 error_init ("empty index range in initializer%s", " for `%s'", 
                                                               ((void *)0)
                                                                   );
      else
 {
   if (pedantic)
     pedwarn ("ANSI C forbids specifying element to initialize");
   constructor_range_end = last;
 }
    }
}



void
set_init_label(tree fieldname) asm("_set_init_label");
void
set_init_label(tree fieldname)
{
  tree tail;
  int passed = 0;



  if (constructor_type == 0)
    return;

  for (tail = ((constructor_type)->type.values); tail;
       tail = ((tail)->common.chain))
    {
      if (tail == constructor_unfilled_fields)
 passed = 1;
      if (((tail)->decl.name) == fieldname)
 break;
    }

  if (tail == 0)
    error ("unknown field `%s' specified in initializer",
    ((fieldname)->identifier.pointer));
  else if (!passed)
    error ("field `%s' already initialized",
    ((fieldname)->identifier.pointer));
  else
    {
      constructor_fields = tail;
      if (pedantic)
 pedwarn ("ANSI C forbids specifying structure member to initialize");
    }
}
static void
output_init_element(tree value, tree type, tree field, int pending) asm("_output_init_element");
static void
output_init_element(tree value, tree type, tree field, int pending)
{
  int duplicate = 0;

  if (((n64_enum_tree_code) (((value)->common.type))->common.code) == FUNCTION_TYPE
      || (((n64_enum_tree_code) (((value)->common.type))->common.code) == ARRAY_TYPE
   && !(((n64_enum_tree_code) (value)->common.code) == STRING_CST
        && ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
        && ((n64_enum_tree_code) (((type)->common.type))->common.code) == INTEGER_TYPE)
   && !comptypes (((((value)->common.type))->type.main_variant),
    ((type)->type.main_variant))))
    value = default_conversion (value);

  if (value == error_mark_node)
    constructor_erroneous = 1;
  else if (!((value)->common.constant_flag))
    constructor_constant = 0;
  else if (initializer_constant_valid_p (value, ((value)->common.type)) == 0
    || ((((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
  || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
        && ((field)->decl.bit_field_flag) && ((n64_enum_tree_code) (value)->common.code) != INTEGER_CST))
    constructor_simple = 0;

  if (require_constant_value && ! ((value)->common.constant_flag))
    {
      error_init ("initializer element%s is not constant",
    " for `%s'", 
                ((void *)0)
                    );
      value = error_mark_node;
    }
  else if (require_constant_elements
    && initializer_constant_valid_p (value, ((value)->common.type)) == 0)
    {
      error_init ("initializer element%s is not computable at load time",
    " for `%s'", 
                ((void *)0)
                    );
      value = error_mark_node;
    }





  if (pending)
    {
      if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 {
   if (purpose_member (field, constructor_pending_elts))
     {
       error_init ("duplicate initializer%s", " for `%s'", 
                                                          ((void *)0)
                                                              );
       duplicate = 1;
     }
 }
      if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   tree tail;
   for (tail = constructor_pending_elts; tail;
        tail = ((tail)->common.chain))
     if (((tail)->list.purpose) != 0
  && ((n64_enum_tree_code) (((tail)->list.purpose))->common.code) == INTEGER_CST
  && tree_int_cst_equal (((tail)->list.purpose), constructor_index))
       break;

   if (tail != 0)
     {
       error_init ("duplicate initializer%s", " for `%s'", 
                                                          ((void *)0)
                                                              );
       duplicate = 1;
     }
 }
    }



  if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
      && !tree_int_cst_equal (field, constructor_unfilled_index))
    {
      if (! duplicate)


 constructor_pending_elts
   = tree_cons (copy_node (field),
         digest_init (type, value, require_constant_value,
        require_constant_elements),
         constructor_pending_elts);
    }
  else if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    && field != constructor_unfilled_fields)
    {



      if (!duplicate)
 constructor_pending_elts
   = tree_cons (field,
         digest_init (type, value, require_constant_value,
        require_constant_elements),
         constructor_pending_elts);
    }
  else
    {



      if (!duplicate)
 {
   if (! constructor_incremental)
     {
       if (field && ((n64_enum_tree_code) (field)->common.code) == INTEGER_CST)
  field = copy_node (field);
       constructor_elements
  = tree_cons (field, digest_init (type, value,
       require_constant_value,
       require_constant_elements),
        constructor_elements);
     }
   else
     {


       if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE)
  {

    if (! tree_int_cst_equal (constructor_bit_index,
         ((field)->decl.arguments)))
      {
        int next = (((((field)->decl.arguments))->int_cst.int_cst_low)
      / 8);
        int here = (((constructor_bit_index)->int_cst.int_cst_low)
      / 8);

        assemble_zeros (next - here);
      }
  }
       output_constant (digest_init (type, value,
         require_constant_value,
         require_constant_elements),
          int_size_in_bytes (type));



       if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
  {
    tree temp = size_binop (PLUS_EXPR, ((field)->decl.arguments),
       ((field)->decl.size));
    ((constructor_bit_index)->int_cst.int_cst_low)
      = ((temp)->int_cst.int_cst_low);
    ((constructor_bit_index)->int_cst.int_cst_high)
      = ((temp)->int_cst.int_cst_high);
  }
     }
 }


      if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   tree tem = size_binop (PLUS_EXPR, constructor_unfilled_index,
     integer_one_node);
   ((constructor_unfilled_index)->int_cst.int_cst_low)
     = ((tem)->int_cst.int_cst_low);
   ((constructor_unfilled_index)->int_cst.int_cst_high)
     = ((tem)->int_cst.int_cst_high);
 }
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE)
 constructor_unfilled_fields = ((constructor_unfilled_fields)->common.chain);
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 constructor_unfilled_fields = 0;


      if (pending)
 output_pending_init_elements (0);
    }
}
static void
output_pending_init_elements(int all) asm("_output_pending_init_elements");
static void
output_pending_init_elements(int all)
{
  tree tail;
  tree next;

 retry:






  next = 0;
  for (tail = constructor_pending_elts; tail;
       tail = ((tail)->common.chain))
    {
      if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   if (tree_int_cst_equal (((tail)->list.purpose),
      constructor_unfilled_index))
     {
       output_init_element (((tail)->list.value),
       ((constructor_type)->common.type),
       constructor_unfilled_index, 0);
       goto retry;
     }
   else if (tree_int_cst_lt (((tail)->list.purpose),
        constructor_unfilled_index))
     ;
   else if (next == 0
     || tree_int_cst_lt (((tail)->list.purpose), next))
     next = ((tail)->list.purpose);
 }
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
        || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 {
   if (((tail)->list.purpose) == constructor_unfilled_fields)
     {
       output_init_element (((tail)->list.value),
       ((constructor_unfilled_fields)->common.type),
       constructor_unfilled_fields,
       0);
       goto retry;
     }
   else if (constructor_unfilled_fields == 0
     || tree_int_cst_lt (((((tail)->list.purpose))->decl.arguments),
           ((constructor_unfilled_fields)->decl.arguments)))
     ;
   else if (next == 0
     || tree_int_cst_lt (((((tail)->list.purpose))->decl.arguments),
           ((next)->decl.arguments)))
     next = ((tail)->list.purpose);
 }
    }



  if (! (all && next != 0))
    return;


  if (constructor_incremental)
    {
      tree filled;
      tree nextpos_tree = size_int (0);

      if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 {

   for (tail = ((constructor_type)->type.values); tail;
        tail = ((tail)->common.chain))
     if (((tail)->common.chain) == constructor_unfilled_fields)
       break;

   if (tail)

     filled = size_binop (CEIL_DIV_EXPR,
     size_binop (PLUS_EXPR,
          ((tail)->decl.arguments),
          ((tail)->decl.size)),
     size_int (8));
   else
     filled = size_int (0);

   nextpos_tree = size_binop (CEIL_DIV_EXPR,
         ((next)->decl.arguments),
         size_int (8));

   ((constructor_bit_index)->int_cst.int_cst_high)
     = ((((next)->decl.arguments))->int_cst.int_cst_high);
   ((constructor_bit_index)->int_cst.int_cst_low)
     = ((((next)->decl.arguments))->int_cst.int_cst_low);
   constructor_unfilled_fields = next;
 }
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   filled = size_binop (MULT_EXPR, constructor_unfilled_index,
          size_in_bytes (((constructor_type)->common.type)));
   nextpos_tree
     = size_binop (MULT_EXPR, next,
     size_in_bytes (((constructor_type)->common.type)));
   ((constructor_unfilled_index)->int_cst.int_cst_low)
     = ((next)->int_cst.int_cst_low);
   ((constructor_unfilled_index)->int_cst.int_cst_high)
     = ((next)->int_cst.int_cst_high);
 }
      else
 filled = 0;

      if (filled)
 {
   int nextpos = ((nextpos_tree)->int_cst.int_cst_low);

   assemble_zeros (nextpos - ((filled)->int_cst.int_cst_low));
 }
    }
  else
    {



      if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
   || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 constructor_unfilled_fields = next;
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   ((constructor_unfilled_index)->int_cst.int_cst_low)
     = ((next)->int_cst.int_cst_low);
   ((constructor_unfilled_index)->int_cst.int_cst_high)
     = ((next)->int_cst.int_cst_high);
 }
    }

  goto retry;
}
void
process_init_element(tree value) asm("_process_init_element");
void
process_init_element(tree value)
{
  tree orig_value = value;
  int string_flag = value != 0 && ((n64_enum_tree_code) (value)->common.code) == STRING_CST;



  if (string_flag
      && constructor_type
      && ((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
      && ((n64_enum_tree_code) (((constructor_type)->common.type))->common.code) == INTEGER_TYPE
      && integer_zerop (constructor_unfilled_index))
    {
      constructor_stack->replacement_value = value;
      return;
    }

  if (constructor_stack->replacement_value != 0)
    {
      error_init ("excess elements in struct initializer%s",
    " after `%s'", ((void *)0));
      return;
    }



  if (constructor_type == 0)
    return;



  while (constructor_stack->implicit)
    {
      if ((((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE
    || ((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
   && constructor_fields == 0)
 process_init_element (pop_init_level (1));
      else if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE
        && tree_int_cst_lt (constructor_max_index, constructor_index))
 process_init_element (pop_init_level (1));
      else
 break;
    }

  while (1)
    {
      if (((n64_enum_tree_code) (constructor_type)->common.code) == RECORD_TYPE)
 {
   tree fieldtype;
   n64_enum_tree_code fieldcode;

   if (constructor_fields == 0)
     {
       pedwarn_init ("excess elements in struct initializer%s",
       " after `%s'", ((void *)0));
       break;
     }

   fieldtype = ((constructor_fields)->common.type);
   if (fieldtype != error_mark_node)
     fieldtype = ((fieldtype)->type.main_variant);
   fieldcode = ((n64_enum_tree_code) (fieldtype)->common.code);


   if (value != 0
       && fieldcode == ARRAY_TYPE
       && ((n64_enum_tree_code) (((fieldtype)->common.type))->common.code) == INTEGER_TYPE
       && string_flag)
     value = orig_value;


   else if (value != 0 && !constructor_no_implicit
     && value != error_mark_node
     && ((((value)->common.type))->type.main_variant) != fieldtype
     && (fieldcode == RECORD_TYPE || fieldcode == ARRAY_TYPE
         || fieldcode == UNION_TYPE))
     {
       push_init_level (1);
       continue;
     }

   if (value)
     {
       push_member_name (constructor_fields);
       output_init_element (value, fieldtype, constructor_fields, 1);
       (spelling = spelling_base + constructor_depth);
     }
   else


     {

       tree temp = size_binop (PLUS_EXPR,
          ((constructor_fields)->decl.arguments),
          ((constructor_fields)->decl.size));
       ((constructor_bit_index)->int_cst.int_cst_low)
  = ((temp)->int_cst.int_cst_low);
       ((constructor_bit_index)->int_cst.int_cst_high)
  = ((temp)->int_cst.int_cst_high);

       constructor_unfilled_fields = ((constructor_fields)->common.chain);
     }

   constructor_fields = ((constructor_fields)->common.chain);

   while (constructor_fields != 0 && ((constructor_fields)->decl.bit_field_flag)
   && ((constructor_fields)->decl.name) == 0)
     constructor_fields = ((constructor_fields)->common.chain);
   break;
 }
      if (((n64_enum_tree_code) (constructor_type)->common.code) == UNION_TYPE)
 {
   tree fieldtype;
   n64_enum_tree_code fieldcode;

   if (constructor_fields == 0)
     {
       pedwarn_init ("excess elements in union initializer%s",
       " after `%s'", ((void *)0));
       break;
     }

   fieldtype = ((constructor_fields)->common.type);
   if (fieldtype != error_mark_node)
     fieldtype = ((fieldtype)->type.main_variant);
   fieldcode = ((n64_enum_tree_code) (fieldtype)->common.code);


   if (value != 0
       && fieldcode == ARRAY_TYPE
       && ((n64_enum_tree_code) (((fieldtype)->common.type))->common.code) == INTEGER_TYPE
       && string_flag)
     value = orig_value;


   else if (value != 0 && !constructor_no_implicit
     && value != error_mark_node
     && ((((value)->common.type))->type.main_variant) != fieldtype
     && (fieldcode == RECORD_TYPE || fieldcode == ARRAY_TYPE
         || fieldcode == UNION_TYPE))
     {
       push_init_level (1);
       continue;
     }

   if (value)
     {
       push_member_name (constructor_fields);
       output_init_element (value, fieldtype, constructor_fields, 1);
       (spelling = spelling_base + constructor_depth);
     }
   else


     {
       ((constructor_bit_index)->int_cst.int_cst_low)
  = ((((constructor_fields)->decl.size))->int_cst.int_cst_low);
       ((constructor_bit_index)->int_cst.int_cst_high)
  = ((((constructor_fields)->decl.size))->int_cst.int_cst_high);

       constructor_unfilled_fields = ((constructor_fields)->common.chain);
     }

   constructor_fields = 0;
   break;
 }
      if (((n64_enum_tree_code) (constructor_type)->common.code) == ARRAY_TYPE)
 {
   tree elttype = ((((constructor_type)->common.type))->type.main_variant);
   n64_enum_tree_code eltcode = ((n64_enum_tree_code) (elttype)->common.code);


   if (value != 0
       && eltcode == ARRAY_TYPE
       && ((n64_enum_tree_code) (((elttype)->common.type))->common.code) == INTEGER_TYPE
       && string_flag)
     value = orig_value;


   else if (value != 0 && !constructor_no_implicit
     && value != error_mark_node
     && ((((value)->common.type))->type.main_variant) != elttype
     && (eltcode == RECORD_TYPE || eltcode == ARRAY_TYPE
         || eltcode == UNION_TYPE))
     {
       push_init_level (1);
       continue;
     }

   if (constructor_max_index != 0
       && tree_int_cst_lt (constructor_max_index, constructor_index))
     {
       pedwarn_init ("excess elements in array initializer%s",
       " after `%s'", ((void *)0));
       break;
     }


   if (constructor_range_end)
     value = save_expr (value);




   do
     {
       tree tem;

       if (value)
  {
    push_array_bounds (((constructor_index)->int_cst.int_cst_low));
    output_init_element (value, elttype, constructor_index, 1);
    (spelling = spelling_base + constructor_depth);
  }

       tem = size_binop (PLUS_EXPR, constructor_index,
    integer_one_node);
       ((constructor_index)->int_cst.int_cst_low)
  = ((tem)->int_cst.int_cst_low);
       ((constructor_index)->int_cst.int_cst_high)
  = ((tem)->int_cst.int_cst_high);

       if (!value)



  {
    ((constructor_unfilled_index)->int_cst.int_cst_low)
      = ((constructor_index)->int_cst.int_cst_low);
    ((constructor_unfilled_index)->int_cst.int_cst_high)
      = ((constructor_index)->int_cst.int_cst_high);
  }
     }
   while (! (constructor_range_end == 0
      || tree_int_cst_lt (constructor_range_end,
     constructor_index)));

   break;
 }



      if (constructor_fields == 0)
 {
   pedwarn_init ("excess elements in scalar initializer%s",
   " after `%s'", ((void *)0));
   break;
 }

      if (value)
 output_init_element (value, constructor_type, (tree) 
                                              ((void *)0)
                                                       , 1);
      constructor_fields = 0;
      break;
    }



  if (constructor_incremental && constructor_pending_elts == 0 && value != 0
      && constructor_stack == 0)
    clear_momentary ();
}







void
c_expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line) asm("_c_expand_asm_operands");
void
c_expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line)
{
  int noutputs = list_length (outputs);
  register int i;

  register tree *o = (tree *) 
                             __builtin_alloca((
                             noutputs * sizeof (tree)
                             ))
                                                              ;
  register tree tail;

  if (((n64_enum_tree_code) (string)->common.code) == ADDR_EXPR)
    string = ((string)->exp.operands[0]);
  if (((n64_enum_tree_code) (string)->common.code) != STRING_CST)
    {
      error ("asm template is not a string constant");
      return;
    }


  for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
    o[i] = ((tail)->list.value);




  for (i = 0, tail = inputs; tail; tail = ((tail)->common.chain), i++)
    if (((n64_enum_tree_code) (((((tail)->list.value))->common.type))->common.code) == ARRAY_TYPE
 || ((n64_enum_tree_code) (((((tail)->list.value))->common.type))->common.code) == FUNCTION_TYPE)
      ((tail)->list.value) = default_conversion (((tail)->list.value));




  expand_asm_operands (string, outputs, inputs, clobbers, vol, filename, line);


  for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
    {
      if (o[i] != ((tail)->list.value))
 {
   expand_expr (build_modify_expr (o[i], NOP_EXPR, ((tail)->list.value)),
         0, VOIDmode, 0);
   free_temp_slots ();
 }


      else
 {
   tree type = ((o[i])->common.type);
   if (((o[i])->common.readonly_flag)
       || ((type)->common.readonly_flag)
       || ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
     || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
    && ((type)->common.lang_flag_1)))
     readonly_warning (o[i], "modification by `asm'");
 }
    }


  emit_queue ();
}





void
c_expand_return(tree retval) asm("_c_expand_return");
void
c_expand_return(tree retval)
{
  tree valtype = ((((current_function_decl)->common.type))->common.type);

  if (((current_function_decl)->common.volatile_flag))
    warning ("function declared `noreturn' has a `return' statement");

  if (!retval)
    {
      current_function_returns_null = 1;
      if (warn_return_type && valtype != 0 && ((n64_enum_tree_code) (valtype)->common.code) != VOID_TYPE)
 warning ("`return' with no value, in function returning non-void");
      expand_null_return ();
    }
  else if (valtype == 0 || ((n64_enum_tree_code) (valtype)->common.code) == VOID_TYPE)
    {
      current_function_returns_null = 1;
      if (pedantic || ((n64_enum_tree_code) (((retval)->common.type))->common.code) != VOID_TYPE)
 pedwarn ("`return' with a value, in function returning void");
      expand_return (retval);
    }
  else
    {
      tree t = convert_for_assignment (valtype, retval, "return",
           (tree) 
          ((void *)0)
                   , (tree) 
                     ((void *)0)
                              , 0);
      tree res = ((current_function_decl)->decl.result);
      tree inner;

      if (t == error_mark_node)
 return;

      inner = t = convert (((res)->common.type), t);



      while (1)
 {
   switch (((n64_enum_tree_code) (inner)->common.code))
     {
     case NOP_EXPR: case NON_LVALUE_EXPR: case CONVERT_EXPR:
     case PLUS_EXPR:
       inner = ((inner)->exp.operands[0]);
       continue;

     case MINUS_EXPR:



       {
  tree op1 = ((inner)->exp.operands[1]);

  while (! (((n64_enum_tree_code) (((op1)->common.type))->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (((op1)->common.type))->common.code) == REFERENCE_TYPE)
         && (((n64_enum_tree_code) (op1)->common.code) == NOP_EXPR
      || ((n64_enum_tree_code) (op1)->common.code) == NON_LVALUE_EXPR
      || ((n64_enum_tree_code) (op1)->common.code) == CONVERT_EXPR))
    op1 = ((op1)->exp.operands[0]);

  if ((((n64_enum_tree_code) (((op1)->common.type))->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (((op1)->common.type))->common.code) == REFERENCE_TYPE))
    break;

  inner = ((inner)->exp.operands[0]);
  continue;
       }

     case ADDR_EXPR:
       inner = ((inner)->exp.operands[0]);

       while ((*tree_code_type[(int) (((n64_enum_tree_code) (inner)->common.code))]) == 'r')
  inner = ((inner)->exp.operands[0]);

       if (((n64_enum_tree_code) (inner)->common.code) == VAR_DECL
    && ! ((inner)->decl.external_flag)
    && ! ((inner)->common.static_flag)
    && ((inner)->decl.context) == current_function_decl)
  warning ("function returns address of local variable");
       break;
     }

   break;
 }

      t = build (MODIFY_EXPR, ((res)->common.type), res, t);
      ((t)->common.side_effects_flag) = 1;
      expand_return (t);
      current_function_returns_value = 1;
    }
}




tree
c_expand_start_case(tree exp) asm("_c_expand_start_case");
tree
c_expand_start_case(tree exp)
{
  register n64_enum_tree_code code = ((n64_enum_tree_code) (((exp)->common.type))->common.code);
  tree type = ((exp)->common.type);

  if (code != INTEGER_TYPE && code != ENUMERAL_TYPE && code != ERROR_MARK)
    {
      error ("switch quantity not an integer");
      exp = error_mark_node;
    }
  else
    {
      tree strchr;
      type = ((((exp)->common.type))->type.main_variant);

      if (warn_traditional
   && (type == long_integer_type_node
       || type == long_unsigned_type_node))
 pedwarn ("`long' switch expression not converted to `int' in ANSI C");

      exp = default_conversion (exp);
      type = ((exp)->common.type);
      strchr = get_unwidened (exp, (tree) 
                                 ((void *)0)
                                          );




      if (((((exp)->common.type))->common.unsigned_flag)
   == ((((strchr)->common.type))->common.unsigned_flag))
 exp = strchr;
    }

  expand_start_case (1, exp, type, "switch statement");

  return exp;
}

