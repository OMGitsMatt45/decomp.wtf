// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/unroll.c
/* Try to unroll loops, and split induction variables.
   Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by James E. Wilson, Cygnus Support/UC Berkeley.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int max_label_num(...) asm("_max_label_num");
extern int get_max_uid(...) asm("_get_max_uid");
extern int max_reg_num(...) asm("_max_reg_num");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int invert_exp(...) asm("_invert_exp");
extern int redirect_exp(...) asm("_redirect_exp");
extern int condjump_p(...) asm("_condjump_p");
extern int simplejump_p(...) asm("_simplejump_p");
extern int validate_change(...) asm("_validate_change");
extern int recog_memoized(...) asm("_recog_memoized");
extern int reg_referenced_p(...) asm("_reg_referenced_p");
extern int reg_set_p(...) asm("_reg_set_p");
struct n64_tag__factor;
struct n64_tag_equiv_table;
struct n64_tag_induction;
struct n64_tag_inline_remap;
struct n64_tag_iv_class;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag__factor { int factor, count; } factors[4]
  = { {2, 0}, {3, 0}, {5, 0}, {7, 0}};



enum n64_cpp_enum_unroll_types{ UNROLL_COMPLETELY, UNROLL_MODULO, UNROLL_NAIVE };
typedef __underlying_type(enum n64_cpp_enum_unroll_types) n64_enum_unroll_types;



extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
struct n64_tag_equiv_table
    {
      rtx dest;
      rtx equiv;
    };
struct n64_tag_inline_remap
{



  int integrating;

  union tree_node *fndecl;

  rtx insns_at_start;


  rtx *reg_map;


  rtx *label_map;





  rtx *insn_map;
  int min_insnno, max_insnno;
  rtx *const_equiv_map;

  int const_equiv_map_size;






  unsigned int const_age;


  unsigned int *const_age_map;

  rtx inline_target;



  rtvec orig_asm_operands_vector;



  rtvec copy_asm_operands_vector;

  rtvec copy_asm_constraints_vector;



  int num_sets;
  struct n64_tag_equiv_table equiv_sets[10];


  rtx last_pc_value;




};



extern rtx copy_rtx_and_substitute (rtx, struct n64_tag_inline_remap *) asm("_copy_rtx_and_substitute");

extern void try_constants (rtx, struct n64_tag_inline_remap *) asm("_try_constants");

extern void mark_stores (rtx, rtx) asm("_mark_stores");





extern rtx *global_const_equiv_map;
extern int global_const_equiv_map_size;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);

enum n64_cpp_enum_g_types{ DEST_ADDR, DEST_REG };
typedef __underlying_type(enum n64_cpp_enum_g_types) n64_enum_g_types;





struct n64_tag_induction
{
  rtx insn;
  rtx new_reg;

  rtx src_reg;

  n64_enum_g_types giv_type;
  rtx dest_reg;



  rtx *location;

  n64_enum_machine_mode mode;
  n64_enum_machine_mode mem_mode;
  rtx mult_val;
  rtx add_val;
  int benefit;
  rtx final_value;



  unsigned replaceable : 1;




  unsigned not_replaceable : 1;





  unsigned ignore : 1;
  unsigned always_computable : 1;
  unsigned maybe_multiple : 1;


  unsigned cant_derive : 1;



  unsigned combined_with : 1;

  unsigned maybe_dead : 1;


  int lifetime;
  int times_used;
  rtx derive_adjustment;



  struct n64_tag_induction *next_iv;



  struct n64_tag_induction *same;


  int const_adjust;



  struct n64_tag_induction *same_insn;



};



struct n64_tag_iv_class {
  int regno;
  int biv_count;
  struct n64_tag_induction *biv;
  int giv_count;


  struct n64_tag_induction *giv;

  int total_benefit;
  rtx initial_value;
  rtx initial_test;
  struct n64_tag_iv_class *next;
  rtx init_insn;
  rtx init_set;
  unsigned incremented : 1;
  unsigned eliminable : 1;
  unsigned nonneg : 1;
  unsigned reversed : 1;

};


enum n64_cpp_enum_iv_mode{ UNKNOWN_INDUCT, BASIC_INDUCT, NOT_BASIC_INDUCT,
   GENERAL_INDUCT };
typedef __underlying_type(enum n64_cpp_enum_iv_mode) n64_enum_iv_mode;




extern int *uid_luid;
extern int max_uid_for_loop;
extern int *uid_loop_num;
extern int *loop_outer_loop;
extern rtx *loop_number_exit_labels;
extern int *loop_number_exit_count;
extern unsigned int loop_n_iterations;
extern int max_reg_before_loop;

extern FILE *loop_dump_stream;

extern n64_enum_iv_mode *reg_iv_type;
extern struct n64_tag_induction **reg_iv_info;
extern struct n64_tag_iv_class **reg_biv_class;
extern struct n64_tag_iv_class *loop_iv_list;



int invariant_p (rtx) asm("_invariant_p");
rtx get_condition_for_loop (rtx) asm("_get_condition_for_loop");
void emit_iv_add_mult (rtx, rtx, rtx, rtx, rtx) asm("_emit_iv_add_mult");


void find_loop_tree_blocks (void) asm("_find_loop_tree_blocks");
void unroll_block_trees (void) asm("_unroll_block_trees");

void unroll_loop (rtx, int, rtx, rtx, int) asm("_unroll_loop");
rtx biv_total_increment (struct n64_tag_iv_class *, rtx, rtx) asm("_biv_total_increment");
unsigned int loop_iterations (rtx, rtx) asm("_loop_iterations");
rtx final_biv_value (struct n64_tag_iv_class *, rtx, rtx) asm("_final_biv_value");
rtx final_giv_value (struct n64_tag_induction *, rtx, rtx) asm("_final_giv_value");
void emit_unrolled_add (rtx, rtx, rtx) asm("_emit_unrolled_add");
int back_branch_in_range_p (rtx, rtx, rtx) asm("_back_branch_in_range_p");
static struct n64_tag_induction **addr_combined_regs;





static rtx *splittable_regs;






static int *splittable_regs_updates;




static rtx loop_iteration_var;
static rtx loop_initial_value;
static rtx loop_increment;
static rtx loop_final_value;



static void init_reg_map (struct n64_tag_inline_remap *, int) asm("_init_reg_map");
static int precondition_loop_p (rtx *, rtx *, rtx *, rtx, rtx) asm("_precondition_loop_p");
static rtx calculate_giv_inc (rtx, rtx, int) asm("_calculate_giv_inc");
static rtx initial_reg_note_copy (rtx, struct n64_tag_inline_remap *) asm("_initial_reg_note_copy");
static void final_reg_note_copy (rtx, struct n64_tag_inline_remap *) asm("_final_reg_note_copy");
static void copy_loop_body (rtx, rtx, struct n64_tag_inline_remap *, rtx, int, n64_enum_unroll_types, rtx, rtx, rtx, rtx) asm("_copy_loop_body")
                                             ;
static void iteration_info (rtx, rtx *, rtx *, rtx, rtx) asm("_iteration_info");
static rtx approx_final_value (n64_enum_rtx_code, rtx, int *, int *) asm("_approx_final_value");
static int find_splittable_regs (n64_enum_unroll_types, rtx, rtx, rtx, int) asm("_find_splittable_regs");
static int find_splittable_givs (struct n64_tag_iv_class *,n64_enum_unroll_types, rtx, rtx, rtx, int) asm("_find_splittable_givs")
                               ;
static int reg_dead_after_loop (rtx, rtx, rtx) asm("_reg_dead_after_loop");
static rtx fold_rtx_mult_add (rtx, rtx, rtx, n64_enum_machine_mode) asm("_fold_rtx_mult_add");
static rtx remap_split_bivs (rtx) asm("_remap_split_bivs");
void
unroll_loop(rtx loop_end, int insn_count, rtx loop_start, rtx end_insert_before, int strength_reduce_p) asm("_unroll_loop");
void
unroll_loop(rtx loop_end, int insn_count, rtx loop_start, rtx end_insert_before, int strength_reduce_p)
{
  int i, j, temp;
  int unroll_number = 1;
  rtx copy_start, copy_end;
  rtx insn, copy, sequence, pattern, tem;
  int max_labelno, max_insnno;
  rtx insert_before;
  struct n64_tag_inline_remap *map;
  char *local_label;
  char *local_regno;
  int maxregnum;
  int new_maxregnum;
  rtx exit_label = 0;
  rtx start_label;
  struct n64_tag_iv_class *bl;
  int splitting_not_safe = 0;
  n64_enum_unroll_types unroll_type;
  int loop_preconditioned = 0;
  rtx safety_label;



  rtx last_loop_insn;




  if (insn_count > 100 / 2)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream, "Unrolling failure: Loop too big.\n");
      return;
    }






  if (write_symbols != NO_DEBUG)
    {
      int block_begins = 0;
      int block_ends = 0;

      for (insn = loop_start; insn != loop_end; insn = ((insn)->fld[2].rtx))
 {
   if (((insn)->code) == NOTE)
     {
       if (((insn)->fld[4].rtint) == -2)
  block_begins++;
       else if (((insn)->fld[4].rtint) == -3)
  block_ends++;
     }
 }

      if (block_begins != block_ends)
 {
   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Unrolling failure: Unbalanced block notes.\n");
   return;
 }
    }
  if (! strength_reduce_p)
    loop_n_iterations = 0;

  if (loop_dump_stream && loop_n_iterations > 0)
    fprintf (loop_dump_stream,
      "Loop unrolling: %d iterations.\n", loop_n_iterations);



  last_loop_insn = prev_nonnote_insn (loop_end);




  if (loop_n_iterations == 1)
    {







      if (((last_loop_insn)->code) == BARRIER)
 {

   delete_insn (((last_loop_insn)->fld[1].rtx));
 }
      else if (((last_loop_insn)->code) == JUMP_INSN)
 {
   delete_insn (last_loop_insn);

 }
      return;
    }
  else if (loop_n_iterations > 0
      && loop_n_iterations * insn_count < 100)
    {
      unroll_number = loop_n_iterations;
      unroll_type = UNROLL_COMPLETELY;
    }
  else if (loop_n_iterations > 0)
    {




      for (i = 0; i < 4; i++)
 factors[i].count = 0;

      temp = loop_n_iterations;
      for (i = 4 - 1; i >= 0; i--)
 while (temp % factors[i].factor == 0)
   {
     factors[i].count++;
     temp = temp / factors[i].factor;
   }




      unroll_number = 1;
      temp = insn_count;
      for (i = 3; i >= 0; i--)
 while (factors[i].count--)
   {
     if (temp * factors[i].factor < 100)
       {
  unroll_number *= factors[i].factor;
  temp *= factors[i].factor;
       }
     else
       break;
   }



      if (unroll_number == 1)
 {
   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Loop unrolling: No factors found.\n");
 }
      else
 unroll_type = UNROLL_MODULO;
    }




  if (unroll_number == 1)
    {
      if (8 * insn_count < 100)
 unroll_number = 8;
      else if (4 * insn_count < 100)
 unroll_number = 4;
      else
 unroll_number = 2;

      unroll_type = UNROLL_NAIVE;
    }



  if (loop_dump_stream)
    fprintf (loop_dump_stream,
      "Unrolling loop %d times.\n", unroll_number);


  if (unroll_type == UNROLL_COMPLETELY || unroll_type == UNROLL_MODULO)
    {




      insn = loop_start;
      while (((insn)->code) != CODE_LABEL && ((insn)->code) != JUMP_INSN)
 insn = ((insn)->fld[2].rtx);
      if (((insn)->code) == JUMP_INSN)
 abort ();
    }

  if (unroll_type == UNROLL_COMPLETELY)
    {







      copy_start = loop_start;




      insert_before = ((last_loop_insn)->fld[2].rtx);


      if (((last_loop_insn)->code) == BARRIER)
 copy_end = ((((last_loop_insn)->fld[1].rtx))->fld[1].rtx);
      else if (((last_loop_insn)->code) == JUMP_INSN)
 {







   copy_end = ((last_loop_insn)->fld[1].rtx);

 }
      else
 {




   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Unrolling failure: loop does not end with a JUMP_INSN.\n");
   return;
 }
    }
  else if (unroll_type == UNROLL_MODULO)
    {






      copy_start = loop_start;



      if (((last_loop_insn)->code) == BARRIER)
 {
   insert_before = ((last_loop_insn)->fld[1].rtx);
   copy_end = ((insert_before)->fld[1].rtx);
 }
      else if (((last_loop_insn)->code) == JUMP_INSN)
 {
   insert_before = last_loop_insn;
   copy_end = ((last_loop_insn)->fld[1].rtx);

 }
      else
 {




   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Unrolling failure: loop does not end with a JUMP_INSN.\n");
   return;
 }
    }
  else
    {



      if (((last_loop_insn)->code) == BARRIER)
 {
   insert_before = ((last_loop_insn)->fld[1].rtx);
   copy_end = ((insert_before)->fld[1].rtx);
 }
      else if (((last_loop_insn)->code) == JUMP_INSN)
 {



   insert_before = ((last_loop_insn)->fld[2].rtx);
   copy_end = last_loop_insn;
 }
      else
 {




   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Unrolling failure: loop does not end with a JUMP_INSN.\n");
   return;
 }
      exit_label = gen_label_rtx ();

      insn = loop_start;
      while (((insn)->code) != CODE_LABEL && ((insn)->code) != JUMP_INSN)
 insn = ((insn)->fld[2].rtx);

      if (((insn)->code) == JUMP_INSN)
 {



   copy_start = ((insn)->fld[2].rtx);






   splitting_not_safe = 1;
   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Splitting not safe, because loop not entered at top.\n");
 }
      else
 copy_start = loop_start;
    }


  start_label = ((copy_start)->fld[2].rtx);

  while (((start_label)->code) == NOTE)
    start_label = ((start_label)->fld[2].rtx);
  if (((start_label)->code) != CODE_LABEL)
    {







      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Unrolling failure: unknown insns between BEG note and loop label.\n");
      return;
    }
  if (((start_label)->fld[4].rtstr))
    {





      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Unrolling failure: loop start label is gone\n");
      return;
    }

  if (unroll_type == UNROLL_NAIVE
      && ((last_loop_insn)->code) == BARRIER
      && start_label != ((((last_loop_insn)->fld[1].rtx))->fld[7].rtx))
    {



      insert_before = ((last_loop_insn)->fld[2].rtx);
      copy_end = last_loop_insn;
    }




  max_labelno = max_label_num ();
  max_insnno = get_max_uid ();

  map = (struct n64_tag_inline_remap *) 
                               __builtin_alloca((
                               sizeof (struct n64_tag_inline_remap)
                               ))
                                                                    ;

  map->integrating = 0;



  if (max_labelno > 0)
    {
      map->label_map = (rtx *) 
                              __builtin_alloca((
                              max_labelno * sizeof (rtx)
                              ))
                                                                 ;

      local_label = (char *) 
                            __builtin_alloca((
                            max_labelno
                            ))
                                                ;
      memset (local_label,0,max_labelno);
    }
  else
    map->label_map = 0;
  for (insn = copy_start; insn != loop_end; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) == CODE_LABEL)
 local_label[((insn)->fld[3].rtint)] = 1;
      else if (((insn)->code) == JUMP_INSN)
 {
   if (((insn)->fld[7].rtx))
     map->label_map[((((insn)->fld[7].rtx))->fld[3].rtint)]
       = ((insn)->fld[7].rtx);
   else if (((((insn)->fld[3].rtx))->code) == ADDR_VEC
     || ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC)
     {
       rtx pat = ((insn)->fld[3].rtx);
       int diff_vec_p = ((((insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC;
       int len = ((pat)->fld[diff_vec_p].rtvec->num_elem);
       rtx label;

       for (i = 0; i < len; i++)
  {
    label = ((((pat)->fld[diff_vec_p].rtvec->elem[i].rtx))->fld[0].rtx);
    map->label_map[((label)->fld[3].rtint)] = label;
  }
     }
 }
    }



  map->insn_map = (rtx *) 
                         __builtin_alloca((
                         max_insnno * sizeof (rtx)
                         ))
                                                           ;



  map->inline_target = 0;
  maxregnum = max_reg_num ();
  splittable_regs = (rtx *) 
                           __builtin_alloca((
                           maxregnum * sizeof (rtx)
                           ))
                                                            ;
  memset ((char *) splittable_regs,0,maxregnum * sizeof (rtx));
  splittable_regs_updates = (int *) 
                                   __builtin_alloca((
                                   maxregnum * sizeof (int)
                                   ))
                                                                    ;
  memset ((char *) splittable_regs_updates,0,maxregnum * sizeof (int));
  addr_combined_regs
    = (struct n64_tag_induction **) 
                           __builtin_alloca((
                           maxregnum * sizeof (struct n64_tag_induction *)
                           ))
                                                                           ;
  memset ((char *) addr_combined_regs,0,maxregnum * sizeof (struct n64_tag_induction *));



  local_regno = (char *) 
                        __builtin_alloca((
                        max_reg_before_loop
                        ))
                                                    ;
  memset (local_regno,0,max_reg_before_loop);



  if (((copy_end)->fld[0].rtint) < max_uid_for_loop)
  {
    int copy_start_luid = (((copy_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((copy_start)->fld[0].rtint)] : (abort (), -1));
    int copy_end_luid = (((copy_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((copy_end)->fld[0].rtint)] : (abort (), -1));



    if (((copy_end)->code) == JUMP_INSN)
      copy_end_luid--;




    if (copy_start == loop_start)
      copy_start_luid++;

    for (j = 68; j < max_reg_before_loop; ++j)
      if (regno_first_uid[j] > 0 && regno_first_uid[j] <= max_uid_for_loop
   && uid_luid[regno_first_uid[j]] >= copy_start_luid
   && regno_last_uid[j] > 0 && regno_last_uid[j] <= max_uid_for_loop
   && uid_luid[regno_last_uid[j]] <= copy_end_luid)
 local_regno[j] = 1;
  }
  if (unroll_type == UNROLL_NAIVE && ! splitting_not_safe && strength_reduce_p)
    {
      rtx initial_value, final_value, increment;

      if (precondition_loop_p (&initial_value, &final_value, &increment,
          loop_start, loop_end))
 {
   register rtx diff, temp;
   n64_enum_machine_mode mode;
   rtx *labels;
   int abs_inc, neg_inc;

   map->reg_map = (rtx *) 
                         __builtin_alloca((
                         maxregnum * sizeof (rtx)
                         ))
                                                          ;

   map->const_equiv_map = (rtx *) 
                                 __builtin_alloca((
                                 maxregnum * sizeof (rtx)
                                 ))
                                                                  ;
   map->const_age_map = (unsigned *) 
                                    __builtin_alloca((
                                    maxregnum * sizeof (unsigned)
                                    ))
                              
                             ;
   map->const_equiv_map_size = maxregnum;
   global_const_equiv_map = map->const_equiv_map;
   global_const_equiv_map_size = maxregnum;

   init_reg_map (map, maxregnum);



   if (unroll_number > 4)
     unroll_number = 4;



   neg_inc = 0;
   abs_inc = ((increment)->fld[0].rtwint);
   if (abs_inc < 0)
     {
       abs_inc = - abs_inc;
       neg_inc = 1;
     }

   start_sequence ();




   mode = ((final_value)->mode);
   if (mode == VOIDmode)
     {
       mode = ((initial_value)->mode);
       if (mode == VOIDmode)
  mode = word_mode;
     }
   else if (mode != ((initial_value)->mode)
     && ((mode_size[(int)(mode)])
         < (mode_size[(int)(((initial_value)->mode))])))
     mode = ((initial_value)->mode);
   diff = expand_binop (mode, sub_optab, copy_rtx (final_value),
          copy_rtx (initial_value), (rtx) 0, 0,
          OPTAB_LIB_WIDEN);



   diff = expand_binop (((diff)->mode), and_optab, diff,
          gen_rtx (CONST_INT, VOIDmode, (int) (unroll_number * abs_inc - 1)),
          (rtx) 0, 0, OPTAB_LIB_WIDEN);




   labels = (rtx *) 
                   __builtin_alloca((
                   sizeof (rtx) * unroll_number
                   ))
                                                        ;
   for (i = 0; i < unroll_number; i++)
     labels[i] = gen_label_rtx ();





   emit_cmp_insn (initial_value, final_value, neg_inc ? LE : GE,
    (rtx) 0, mode, 0, 0);
   if (neg_inc)
     emit_jump_insn (gen_ble (labels[1]));
   else
     emit_jump_insn (gen_bge (labels[1]));
   ((get_last_insn ())->fld[7].rtx) = labels[1];
   ((labels[1])->fld[5].rtint)++;
   for (i = 0; i < unroll_number - 1; i++)
     {
       int cmp_const;
       n64_enum_rtx_code cmp_code;



       if (i == 0)
  {
    cmp_const = 0;
    cmp_code = EQ;
  }
       else if (neg_inc)
  {
    cmp_const = unroll_number - i;
    cmp_code = GE;
  }
       else
  {
    cmp_const = i;
    cmp_code = LE;
  }

       emit_cmp_insn (diff, gen_rtx (CONST_INT, VOIDmode, (int) (abs_inc * cmp_const)),
        cmp_code, (rtx) 0, mode, 0, 0);

       if (i == 0)
  emit_jump_insn (gen_beq (labels[i]));
       else if (neg_inc)
  emit_jump_insn (gen_bge (labels[i]));
       else
  emit_jump_insn (gen_ble (labels[i]));
       ((get_last_insn ())->fld[7].rtx) = labels[i];
       ((labels[i])->fld[5].rtint)++;
     }
   if (abs_inc != 1)
     {
       int cmp_const;
       n64_enum_rtx_code cmp_code;

       if (neg_inc)
  {
    cmp_const = abs_inc - 1;
    cmp_code = LE;
  }
       else
  {
    cmp_const = abs_inc * (unroll_number - 1) + 1;
    cmp_code = GE;
  }

       emit_cmp_insn (diff, gen_rtx (CONST_INT, VOIDmode, (int) (cmp_const)), cmp_code, (rtx) 0,
        mode, 0, 0);

       if (neg_inc)
  emit_jump_insn (gen_ble (labels[0]));
       else
  emit_jump_insn (gen_bge (labels[0]));
       ((get_last_insn ())->fld[7].rtx) = labels[0];
       ((labels[0])->fld[5].rtint)++;
     }

   sequence = gen_sequence ();
   end_sequence ();
   emit_insn_before (sequence, loop_start);






   if (((last_loop_insn)->code) == BARRIER)
     copy_end = ((((last_loop_insn)->fld[1].rtx))->fld[1].rtx);
   else if (((last_loop_insn)->code) == JUMP_INSN)
     {







       copy_end = ((last_loop_insn)->fld[1].rtx);

     }
   else
     abort ();

   for (i = 1; i < unroll_number; i++)
     {
       emit_label_after (labels[unroll_number - i],
    ((loop_start)->fld[1].rtx));

       memset ((char *) map->insn_map,0,max_insnno * sizeof (rtx));
       memset ((char *) map->const_equiv_map,0,maxregnum * sizeof (rtx));
       memset ((char *) map->const_age_map,0,maxregnum * sizeof (unsigned))
                                     ;
       map->const_age = 0;

       for (j = 0; j < max_labelno; j++)
  if (local_label[j])
    map->label_map[j] = gen_label_rtx ();

       for (j = 68; j < max_reg_before_loop; j++)
  if (local_regno[j])
    map->reg_map[j] = gen_reg_rtx (((regno_reg_rtx[j])->mode));





       if (i == unroll_number - 1)
  {
    if (((last_loop_insn)->code) == BARRIER)
      copy_end = ((((last_loop_insn)->fld[1].rtx))->fld[1].rtx);
    else
      copy_end = last_loop_insn;
  }



       copy_loop_body (copy_start, copy_end, map, exit_label, 0,
         unroll_type, start_label, loop_end,
         loop_start, copy_end);
     }
   emit_label_after (labels[0], ((loop_start)->fld[1].rtx));

   if (((last_loop_insn)->code) == BARRIER)
     {
       insert_before = ((last_loop_insn)->fld[1].rtx);
       copy_end = ((insert_before)->fld[1].rtx);
     }
   else
     {
       insert_before = last_loop_insn;
       copy_end = ((last_loop_insn)->fld[1].rtx);

     }


   unroll_type = UNROLL_MODULO;
   loop_preconditioned = 1;
 }
    }



  if (unroll_type == UNROLL_NAIVE && ! flag_unroll_all_loops)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream, "Unrolling failure: Naive unrolling not being done.\n");
      return;
    }
  if (splitting_not_safe)
    temp = 0;
  else
    temp = find_splittable_regs (unroll_type, loop_start, loop_end,
    end_insert_before, unroll_number);





  maxregnum = max_reg_num ();
  map->reg_map = (rtx *) 
                        __builtin_alloca((
                        maxregnum * sizeof (rtx)
                        ))
                                                         ;

  init_reg_map (map, maxregnum);



  new_maxregnum = maxregnum + (temp * unroll_number * 2);




  map->const_equiv_map = (rtx *) 
                                __builtin_alloca((
                                new_maxregnum * sizeof (rtx)
                                ))
                                                                     ;
  map->const_age_map = (unsigned *) 
                                   __builtin_alloca((
                                   new_maxregnum * sizeof (unsigned)
                                   ))
                                                                             ;

  map->const_equiv_map_size = new_maxregnum;
  global_const_equiv_map = map->const_equiv_map;
  global_const_equiv_map_size = new_maxregnum;




  for (bl = loop_iv_list; bl; bl = bl->next)
    {
      if (((bl->biv->src_reg)->fld[0].rtint) != bl->regno)
 map->reg_map[bl->regno] = bl->biv->src_reg;






    }







  if (unroll_type == UNROLL_MODULO)
    {
      insn = ((copy_end)->fld[2].rtx);
      if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN)
 ((insn)->fld[3].rtx) = remap_split_bivs (((insn)->fld[3].rtx));
    }





  for (i = 0; i < unroll_number; i++)
    {
      memset ((char *) map->insn_map,0,max_insnno * sizeof (rtx));
      memset ((char *) map->const_equiv_map,0,new_maxregnum * sizeof (rtx));
      memset ((char *) map->const_age_map,0,new_maxregnum * sizeof (unsigned));
      map->const_age = 0;

      for (j = 0; j < max_labelno; j++)
 if (local_label[j])
   map->label_map[j] = gen_label_rtx ();

      for (j = 68; j < max_reg_before_loop; j++)
 if (local_regno[j])
   map->reg_map[j] = gen_reg_rtx (((regno_reg_rtx[j])->mode));



      if (i == 0 && loop_start != copy_start)
 {
   insn = ((copy_start)->fld[1].rtx);
   pattern = ((insn)->fld[3].rtx);

   tem = map->label_map[((((((pattern)->fld[1].rtx))->fld[0].rtx))->fld[3].rtint)
                                       ];
   ((pattern)->fld[1].rtx) = gen_rtx (LABEL_REF, VOIDmode, tem);



   ((insn)->fld[7].rtx) = tem;
   ((tem)->fld[5].rtint)++;
 }

      copy_loop_body (copy_start, copy_end, map, exit_label,
        i == unroll_number - 1, unroll_type, start_label,
        loop_end, insert_before, insert_before);
    }
  if (unroll_type == UNROLL_COMPLETELY)
    safety_label = emit_label_after (gen_label_rtx (), last_loop_insn);
  else
    safety_label = emit_label_after (gen_label_rtx (), copy_end);




  insn = ((copy_start)->fld[2].rtx);
  while (insn != safety_label)
    {
      if (insn != start_label)
 insn = delete_insn (insn);
      else
 insn = ((insn)->fld[2].rtx);
    }



  if (((safety_label)->volatil))
    abort ();
  delete_insn (safety_label);






  if (exit_label)
    emit_label_after (exit_label, loop_end);
}
static int
precondition_loop_p(rtx *initial_value, rtx *final_value, rtx *increment, rtx loop_start, rtx loop_end) asm("_precondition_loop_p");
static int
precondition_loop_p(rtx *initial_value, rtx *final_value, rtx *increment, rtx loop_start, rtx loop_end)
{

  if (loop_n_iterations > 0)
    {
      *initial_value = const0_rtx;
      *increment = const1_rtx;
      *final_value = gen_rtx (CONST_INT, VOIDmode, (int) (loop_n_iterations));

      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Success, number of iterations known, %d.\n",
   loop_n_iterations);
      return 1;
    }

  if (loop_initial_value == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Could not find initial value.\n");
      return 0;
    }
  else if (loop_increment == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Could not find increment value.\n");
      return 0;
    }
  else if (((loop_increment)->code) != CONST_INT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Increment not a constant.\n");
      return 0;
    }
  else if ((exact_log2_wide ((int) (((loop_increment)->fld[0].rtwint))) < 0)
    && (exact_log2_wide ((int) (- ((loop_increment)->fld[0].rtwint))) < 0))
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Increment not a constant power of 2.\n");
      return 0;
    }




  if (loop_final_value == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: EQ comparison loop.\n");
      return 0;
    }






  if ((((loop_final_value)->code) == REG
       && ((loop_final_value)->fld[0].rtint) >= max_reg_before_loop)
      || (((loop_final_value)->code) == PLUS
   && ((((loop_final_value)->fld[0].rtx))->fld[0].rtint) >= max_reg_before_loop)
      || ! invariant_p (loop_final_value))
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Final value not invariant.\n");
      return 0;
    }



  if ((mode_class[(int)(((loop_final_value)->mode))]) == MODE_FLOAT
      || (mode_class[(int)(((loop_initial_value)->mode))]) == MODE_FLOAT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Floating point final or initial value.\n");
      return 0;
    }
  if (uid_luid[regno_first_uid[((loop_iteration_var)->fld[0].rtint)]]
      > (((loop_start)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_start)->fld[0].rtint)] : (abort (), -1)))
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Preconditioning: Iteration var not live before loop start.\n");
      return 0;
    }

  *initial_value = loop_iteration_var;
  *increment = loop_increment;
  *final_value = loop_final_value;


  if (loop_dump_stream)
    fprintf (loop_dump_stream, "Preconditioning: Successful.\n");
  return 1;
}
static void
init_reg_map(struct n64_tag_inline_remap *map, int maxregnum) asm("_init_reg_map");
static void
init_reg_map(struct n64_tag_inline_remap *map, int maxregnum)
{
  int i;

  for (i = maxregnum - 1; i > (((68)) + 3); i--)
    map->reg_map[i] = regno_reg_rtx[i];

  for (i = (((68)) + 3); i >= 0; i--)
    map->reg_map[i] = 0;

  map->reg_map[(((68)) + 1)]
    = regno_reg_rtx[(((68)) + 1)];
  map->reg_map[((68))]
    = regno_reg_rtx[((68))];
}
static rtx
calculate_giv_inc(rtx pattern, rtx src_insn, int regno) asm("_calculate_giv_inc");
static rtx
calculate_giv_inc(rtx pattern, rtx src_insn, int regno)
{
  rtx increment;
  rtx increment_total = 0;
  int tries = 0;

 retry:


  if (((((pattern)->fld[1].rtx))->code) != PLUS)
    {


      src_insn = ((src_insn)->fld[1].rtx);
      pattern = ((src_insn)->fld[3].rtx);
      if (((((pattern)->fld[1].rtx))->code) != PLUS)
 abort ();



      delete_insn (get_last_insn ());
    }


  increment = ((((pattern)->fld[1].rtx))->fld[1].rtx);
  if (((increment)->code) != CONST_INT)
    {


      src_insn = ((src_insn)->fld[1].rtx);
      increment = ((((src_insn)->fld[3].rtx))->fld[1].rtx);




      if (((increment)->code) == LO_SUM)
 increment = ((increment)->fld[1].rtx);
      else if (((increment)->code) == IOR
        || ((increment)->code) == ASHIFT)
 {


   rtx second_part = ((increment)->fld[1].rtx);
   n64_enum_rtx_code code = ((increment)->code);

   src_insn = ((src_insn)->fld[1].rtx);
   increment = ((((src_insn)->fld[3].rtx))->fld[1].rtx);

   delete_insn (get_last_insn ());

   if (((second_part)->code) != CONST_INT
       || ((increment)->code) != CONST_INT)
     abort ();

   if (code == IOR)
     increment = gen_rtx (CONST_INT, VOIDmode, (int) (((increment)->fld[0].rtwint) | ((second_part)->fld[0].rtwint)));
   else
     increment = gen_rtx (CONST_INT, VOIDmode, (int) (((increment)->fld[0].rtwint) << ((second_part)->fld[0].rtwint)));
 }

      if (((increment)->code) != CONST_INT)
 abort ();



      delete_insn (get_last_insn ());
    }

  if (increment_total)
    increment_total = gen_rtx (CONST_INT, VOIDmode, (int) (((increment_total)->fld[0].rtwint) + ((increment)->fld[0].rtwint)));
  else
    increment_total = increment;



  if (((((((pattern)->fld[1].rtx))->fld[0].rtx))->code) != REG
      || ((((((pattern)->fld[1].rtx))->fld[0].rtx))->fld[0].rtint) != regno)
    {




      if (tries == 0)
 {
   tries++;

   src_insn = ((src_insn)->fld[1].rtx);
   pattern = ((src_insn)->fld[3].rtx);

   delete_insn (get_last_insn ());

   goto retry;
 }

      abort ();
    }

  return increment_total;
}





static rtx
initial_reg_note_copy(rtx notes, struct n64_tag_inline_remap *map) asm("_initial_reg_note_copy");
static rtx
initial_reg_note_copy(rtx notes, struct n64_tag_inline_remap *map)
{
  rtx copy;

  if (notes == 0)
    return 0;

  copy = rtx_alloc (((notes)->code));
  ((copy)->mode = (((notes)->mode)));

  if (((notes)->code) == EXPR_LIST)
    ((copy)->fld[0].rtx) = copy_rtx_and_substitute (((notes)->fld[0].rtx), map);
  else if (((notes)->code) == INSN_LIST)

    ((copy)->fld[0].rtx) = ((notes)->fld[0].rtx);
  else
    abort ();

  ((copy)->fld[1].rtx) = initial_reg_note_copy (((notes)->fld[1].rtx), map);

  return copy;
}



static void
final_reg_note_copy(rtx notes, struct n64_tag_inline_remap *map) asm("_final_reg_note_copy");
static void
final_reg_note_copy(rtx notes, struct n64_tag_inline_remap *map)
{
  rtx note;

  for (note = notes; note; note = ((note)->fld[1].rtx))
    if (((note)->code) == INSN_LIST)
      ((note)->fld[0].rtx) = map->insn_map[((((note)->fld[0].rtx))->fld[0].rtint)];
}




static void
copy_loop_body(rtx copy_start, rtx copy_end, struct n64_tag_inline_remap *map, rtx exit_label, int last_iteration, n64_enum_unroll_types unroll_type, rtx start_label, rtx loop_end, rtx insert_before, rtx copy_notes_from) asm("_copy_loop_body");
static void
copy_loop_body(rtx copy_start, rtx copy_end, struct n64_tag_inline_remap *map, rtx exit_label, int last_iteration, n64_enum_unroll_types unroll_type, rtx start_label, rtx loop_end, rtx insert_before, rtx copy_notes_from)
{
  rtx insn, pattern;
  rtx tem, copy;
  int dest_reg_was_split, i;
  rtx cc0_insn = 0;
  rtx final_label = 0;
  rtx giv_inc, giv_dest_reg, giv_src_reg;







  if (! last_iteration)
    {
      final_label = gen_label_rtx ();
      map->label_map[((start_label)->fld[3].rtint)] = final_label;
    }
  else
    map->label_map[((start_label)->fld[3].rtint)] = start_label;

  start_sequence ();

  insn = copy_start;
  do
    {
      insn = ((insn)->fld[2].rtx);

      map->orig_asm_operands_vector = 0;

      switch (((insn)->code))
 {
 case INSN:
   pattern = ((insn)->fld[3].rtx);
   copy = 0;
   giv_inc = 0;
   if (((pattern)->code) == SET
       && ((((pattern)->fld[0].rtx))->code) == REG
       && addr_combined_regs[((((pattern)->fld[0].rtx))->fld[0].rtint)])
     {
       struct n64_tag_iv_class *bl;
       struct n64_tag_induction *v, *tv;
       int regno = ((((pattern)->fld[0].rtx))->fld[0].rtint);

       v = addr_combined_regs[((((pattern)->fld[0].rtx))->fld[0].rtint)];
       bl = reg_biv_class[((v->src_reg)->fld[0].rtint)];







       giv_inc = calculate_giv_inc (pattern, insn, regno);



       for (tv = bl->giv; tv; tv = tv->next_iv)
  if (tv->giv_type == DEST_ADDR && tv->same == v)
    {
      int this_giv_inc = ((giv_inc)->fld[0].rtwint);



      if (tv->mult_val != v->mult_val)
        this_giv_inc = (this_giv_inc / ((v->mult_val)->fld[0].rtwint)
          * ((tv->mult_val)->fld[0].rtwint));

      tv->dest_reg = plus_constant_wide (tv->dest_reg, (int) (this_giv_inc));
      *tv->location = tv->dest_reg;

      if (last_iteration && unroll_type != UNROLL_COMPLETELY)
        {



   rtx value, dest_reg;



   if (((tv->dest_reg)->code) == REG)
     dest_reg = tv->dest_reg;
   else
     dest_reg = ((tv->dest_reg)->fld[0].rtx);




   if (! tv->same_insn)
     {




       value = plus_constant_wide (tv->dest_reg, (int) (tv->const_adjust))
                          ;




       emit_unrolled_add (dest_reg, ((value)->fld[0].rtx),
            ((value)->fld[1].rtx));
     }





   tv->dest_reg = plus_constant_wide (dest_reg, (int) (- tv->const_adjust))
                               ;
   *tv->location = tv->dest_reg;
        }
    }
     }






   dest_reg_was_split = 0;

   if (((pattern)->code) == SET
       && ((((pattern)->fld[0].rtx))->code) == REG
       && splittable_regs[((((pattern)->fld[0].rtx))->fld[0].rtint)])
     {
       int regno = ((((pattern)->fld[0].rtx))->fld[0].rtint);

       dest_reg_was_split = 1;




       if (giv_inc == 0)
  giv_inc = calculate_giv_inc (pattern, insn, regno);
       giv_dest_reg = ((pattern)->fld[0].rtx);
       giv_src_reg = ((pattern)->fld[0].rtx);

       if (unroll_type == UNROLL_COMPLETELY)
  {





    splittable_regs[regno]
      = plus_constant_wide (splittable_regs[regno], (int) (((giv_inc)->fld[0].rtwint)));

    if (((splittable_regs[regno])->code) == PLUS)
      {
        giv_src_reg = ((splittable_regs[regno])->fld[0].rtx);
        giv_inc = ((splittable_regs[regno])->fld[1].rtx);
      }
    else
      {



        giv_src_reg = splittable_regs[regno];
        giv_inc = const0_rtx;
      }
  }
       else
  {
    if (regno < max_reg_before_loop
        && reg_iv_type[regno] == BASIC_INDUCT)
      {
        giv_src_reg = reg_biv_class[regno]->biv->src_reg;
        giv_dest_reg = giv_src_reg;
      }







    splittable_regs[regno]
      = gen_rtx (CONST_INT, VOIDmode, (int) (((giv_inc)->fld[0].rtwint) + ((splittable_regs[regno])->fld[0].rtwint)))
                                            ;
    giv_inc = splittable_regs[regno];
    if (! last_iteration
        || (splittable_regs_updates[regno]-- != 1))
      {
        tem = gen_reg_rtx (((giv_src_reg)->mode));
        giv_dest_reg = tem;
        map->reg_map[regno] = tem;
      }
    else
      map->reg_map[regno] = giv_src_reg;
  }



       emit_unrolled_add (giv_dest_reg, giv_src_reg, giv_inc);
       copy = get_last_insn ();
       pattern = ((copy)->fld[3].rtx);
     }
   else
     {
       pattern = copy_rtx_and_substitute (pattern, map);
       copy = emit_insn (pattern);
     }
   ((copy)->fld[6].rtx) = initial_reg_note_copy (((insn)->fld[6].rtx), map);
   try_constants (copy, map);





   if (dest_reg_was_split)
     {
       int regno = ((((pattern)->fld[0].rtx))->fld[0].rtint);

       if (regno < map->const_equiv_map_size
    && map->const_age_map[regno] == map->const_age)
  map->const_age_map[regno] = -1;
     }
   break;

 case JUMP_INSN:
   pattern = copy_rtx_and_substitute (((insn)->fld[3].rtx), map);
   copy = emit_jump_insn (pattern);
   ((copy)->fld[6].rtx) = initial_reg_note_copy (((insn)->fld[6].rtx), map);

   if (((insn)->fld[7].rtx) == start_label && insn == copy_end
       && ! last_iteration)
     {






       if (invert_exp (pattern, copy))
  {
    if (! redirect_exp (&pattern,
          map->label_map[((((insn)->fld[7].rtx))->fld[3].rtint)
                              ],
          exit_label, copy))
      abort ();
  }
       else
  {
    rtx jmp;
    rtx lab = gen_label_rtx ();




    jmp = emit_jump_insn_after (gen_jump (exit_label), copy);
    jmp = emit_barrier_after (jmp);
    emit_label_after (lab, jmp);
    ((lab)->fld[5].rtint) = 0;
    if (! redirect_exp (&pattern,
          map->label_map[((((insn)->fld[7].rtx))->fld[3].rtint)
                              ],
          lab, copy))
      abort ();
  }
     }






   try_constants (copy, map);



   if (((insn)->fld[7].rtx))
     {
       rtx label = 0;



       if (((pattern)->code) == SET)
  {
    tem = ((pattern)->fld[1].rtx);
    if (((tem)->code) == LABEL_REF)
      label = ((tem)->fld[0].rtx);
    else if (((tem)->code) == IF_THEN_ELSE)
      {
        if (((tem)->fld[1].rtx) != pc_rtx)
   label = ((((tem)->fld[1].rtx))->fld[0].rtx);
        else
   label = ((((tem)->fld[2].rtx))->fld[0].rtx);
      }
  }

       if (label && ((label)->code) == CODE_LABEL)
  ((copy)->fld[7].rtx) = label;
       else
  {



    ((copy)->fld[7].rtx)
      = map->label_map[((((insn)->fld[7].rtx))->fld[3].rtint)];
  }




       ((((copy)->fld[7].rtx))->fld[5].rtint)++;
     }
   else if (((((copy)->fld[3].rtx))->code) == ADDR_VEC
     || ((((copy)->fld[3].rtx))->code) == ADDR_DIFF_VEC)
     {
       rtx pat = ((copy)->fld[3].rtx);
       int diff_vec_p = ((pat)->code) == ADDR_DIFF_VEC;
       int len = ((pat)->fld[diff_vec_p].rtvec->num_elem);
       int i;

       for (i = 0; i < len; i++)
  ((((((pat)->fld[diff_vec_p].rtvec->elem[i].rtx))->fld[0].rtx))->fld[5].rtint)++;
     }



   if (condjump_p (insn) && !simplejump_p (insn) && map->last_pc_value)
     {






       if (map->last_pc_value == pc_rtx)
  {



    if (((copy)->fld[7].rtx))
      ((((copy)->fld[7].rtx))->fld[5].rtint)++;
    delete_insn (copy);
    if (((copy)->fld[7].rtx))
      ((((copy)->fld[7].rtx))->fld[5].rtint)--;
    copy = 0;
  }
       else



  emit_barrier ();
     }
   break;

 case CALL_INSN:
   pattern = copy_rtx_and_substitute (((insn)->fld[3].rtx), map);
   copy = emit_call_insn (pattern);
   ((copy)->fld[6].rtx) = initial_reg_note_copy (((insn)->fld[6].rtx), map);



   ((copy)->fld[7].rtx) =
      copy_rtx_and_substitute (((insn)->fld[7].rtx), map);






   try_constants (copy, map);


   for (i = 0; i < 68; i++)
     map->const_equiv_map[i] = 0;
   break;

 case CODE_LABEL:



   if (insn != start_label)
     {
       copy = emit_label (map->label_map[((insn)->fld[3].rtint)]);
       map->const_age++;
     }
   break;

 case BARRIER:
   copy = emit_barrier ();
   break;

 case NOTE:



   if (((insn)->fld[4].rtint) != -1
       && (((insn)->fld[4].rtint) != -9
    || (last_iteration && unroll_type != UNROLL_COMPLETELY)))
     copy = emit_note (((insn)->fld[3].rtstr),
         ((insn)->fld[4].rtint));
   else
     copy = 0;
   break;

 default:
   abort ();
   break;
 }

      map->insn_map[((insn)->fld[0].rtint)] = copy;
    }
  while (insn != copy_end);


  insn = copy_start;
  do
    {
      insn = ((insn)->fld[2].rtx);
      if ((((insn)->code) == INSN || ((insn)->code) == JUMP_INSN
    || ((insn)->code) == CALL_INSN)
   && map->insn_map[((insn)->fld[0].rtint)])
 final_reg_note_copy (((map->insn_map[((insn)->fld[0].rtint)])->fld[6].rtx), map);
    }
  while (insn != copy_end);
  if (! last_iteration)
    {
      for (insn = copy_notes_from; insn != loop_end; insn = ((insn)->fld[2].rtx))
 {
   if (((insn)->code) == NOTE
       && ((insn)->fld[4].rtint) != -1)
     emit_note (((insn)->fld[3].rtstr), ((insn)->fld[4].rtint));
 }
    }

  if (final_label && ((final_label)->fld[5].rtint) > 0)
    emit_label (final_label);

  tem = gen_sequence ();
  end_sequence ();
  emit_insn_before (tem, insert_before);
}





void
emit_unrolled_add(rtx dest_reg, rtx src_reg, rtx increment) asm("_emit_unrolled_add");
void
emit_unrolled_add(rtx dest_reg, rtx src_reg, rtx increment)
{
  rtx result;

  result = expand_binop (((dest_reg)->mode), add_optab, src_reg, increment,
    dest_reg, 0, OPTAB_LIB_WIDEN);

  if (dest_reg != result)
    emit_move_insn (dest_reg, result);
}
int
back_branch_in_range_p(rtx insn, rtx loop_start, rtx loop_end) asm("_back_branch_in_range_p");
int
back_branch_in_range_p(rtx insn, rtx loop_start, rtx loop_end)
{
  rtx p, q, target_insn;


  loop_end = prev_nonnote_insn (loop_end);
  if (((loop_end)->code) == BARRIER)
    loop_end = ((loop_end)->fld[1].rtx);



  while (((insn)->volatil))
    insn = ((insn)->fld[2].rtx);


  if (insn == loop_end)
    return 0;

  for (p = ((insn)->fld[2].rtx); p != loop_end; p = ((p)->fld[2].rtx))
    {
      if (((p)->code) == JUMP_INSN)
 {
   target_insn = ((p)->fld[7].rtx);




   for (q = loop_start; q != insn; q = ((q)->fld[2].rtx))
     if (q == target_insn)
       return 1;
 }
    }

  return 0;
}





static rtx
fold_rtx_mult_add(rtx mult1, rtx mult2, rtx add1, n64_enum_machine_mode mode) asm("_fold_rtx_mult_add");
static rtx
fold_rtx_mult_add(rtx mult1, rtx mult2, rtx add1, n64_enum_machine_mode mode)
{
  rtx temp, mult_res;
  rtx result;



  if ((((mult1)->mode) != mode && ((mult1)->mode) != VOIDmode)
      || (((mult2)->mode) != mode && ((mult2)->mode) != VOIDmode)
      || (((add1)->mode) != mode && ((add1)->mode) != VOIDmode))
    abort ();



  if (((mult1)->code) == CONST_INT)
    {
      temp = mult2;
      mult2 = mult1;
      mult1 = temp;
    }

  mult_res = simplify_binary_operation (MULT, mode, mult1, mult2);
  if (! mult_res)
    mult_res = gen_rtx (MULT, mode, mult1, mult2);


  if (((add1)->code) == CONST_INT)
    {
      temp = add1;
      add1 = mult_res;
      mult_res = temp;
    }

  result = simplify_binary_operation (PLUS, mode, add1, mult_res);
  if (! result)
    result = gen_rtx (PLUS, mode, add1, mult_res);

  return result;
}







rtx
biv_total_increment(struct n64_tag_iv_class *bl, rtx loop_start, rtx loop_end) asm("_biv_total_increment");
rtx
biv_total_increment(struct n64_tag_iv_class *bl, rtx loop_start, rtx loop_end)
{
  struct n64_tag_induction *v;
  rtx result;
  result = const0_rtx;
  for (v = bl->biv; v; v = v->next_iv)
    {
      if (v->always_computable && v->mult_val == const1_rtx
   && ! back_branch_in_range_p (v->insn, loop_start, loop_end))
 result = fold_rtx_mult_add (result, const1_rtx, v->add_val, v->mode);
      else
 return 0;
    }

  return result;
}
static void
iteration_info(rtx iteration_var, rtx *initial_value, rtx *increment, rtx loop_start, rtx loop_end) asm("_iteration_info");
static void
iteration_info(rtx iteration_var, rtx *initial_value, rtx *increment, rtx loop_start, rtx loop_end)
{
  struct n64_tag_iv_class *bl;
  struct n64_tag_induction *v, *b;


  *initial_value = 0;
  *increment = 0;







  if (((iteration_var)->fld[0].rtint) >= max_reg_before_loop)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: No reg_iv_type entry for iteration var.\n");
      return;
    }



  else if ((8 * mode_size[(int)(((iteration_var)->mode))]) > 32)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Iteration var rejected because mode larger than host long.\n");
      return;
    }
  else if ((mode_class[(int)(((iteration_var)->mode))]) != MODE_INT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Iteration var not an integer.\n");
      return;
    }
  else if (reg_iv_type[((iteration_var)->fld[0].rtint)] == BASIC_INDUCT)
    {

      bl = reg_biv_class[((iteration_var)->fld[0].rtint)];
      *initial_value = bl->initial_value;

      *increment = biv_total_increment (bl, loop_start, loop_end);
    }
  else if (reg_iv_type[((iteration_var)->fld[0].rtint)] == GENERAL_INDUCT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Giv iterators are not handled.\n");
      return;
    }
  else
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Not basic or general induction var.\n");
      return;
    }
}







static rtx
approx_final_value(n64_enum_rtx_code comparison_code, rtx comparison_value, int *unsigned_p, int *compare_dir) asm("_approx_final_value");
static rtx
approx_final_value(n64_enum_rtx_code comparison_code, rtx comparison_value, int *unsigned_p, int *compare_dir)
{






  *unsigned_p = 0;
  switch (comparison_code)
    {
    case LEU:
      *unsigned_p = 1;
    case LE:
      *compare_dir = 1;
      return plus_constant_wide (comparison_value, (int) (1));
    case GEU:
      *unsigned_p = 1;
    case GE:
      *compare_dir = -1;
      return plus_constant_wide (comparison_value, (int) (-1));
    case EQ:

      *compare_dir = 0;
      return 0;
    case LTU:
      *unsigned_p = 1;
    case LT:
      *compare_dir = 1;
      return comparison_value;
      break;
    case GTU:
      *unsigned_p = 1;
    case GT:
      *compare_dir = -1;
      return comparison_value;
    case NE:
      *compare_dir = 0;
      return comparison_value;
    default:
      abort ();
    }
}
static int
find_splittable_regs(n64_enum_unroll_types unroll_type, rtx loop_start, rtx loop_end, rtx end_insert_before, int unroll_number) asm("_find_splittable_regs");
static int
find_splittable_regs(n64_enum_unroll_types unroll_type, rtx loop_start, rtx loop_end, rtx end_insert_before, int unroll_number)
{
  struct n64_tag_iv_class *bl;
  struct n64_tag_induction *v;
  rtx increment, tem;
  rtx biv_final_value;
  int biv_splittable;
  int result = 0;

  for (bl = loop_iv_list; bl; bl = bl->next)
    {



      increment = biv_total_increment (bl, loop_start, loop_end);
      if (! increment || ((increment)->code) != CONST_INT)
 continue;
      biv_splittable = 1;
      biv_final_value = 0;
      if (unroll_type != UNROLL_COMPLETELY
   && (loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]]
       || unroll_type == UNROLL_NAIVE)
   && (uid_luid[regno_last_uid[bl->regno]] >= (((loop_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_end)->fld[0].rtint)] : (abort (), -1))
       || ! bl->init_insn
       || ((bl->init_insn)->fld[0].rtint) >= max_uid_for_loop
       || (uid_luid[regno_first_uid[bl->regno]]
    < (((bl->init_insn)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((bl->init_insn)->fld[0].rtint)] : (abort (), -1)))
       || reg_mentioned_p (bl->biv->dest_reg, ((bl->init_set)->fld[1].rtx)))
   && ! (biv_final_value = final_biv_value (bl, loop_start, loop_end)))
 biv_splittable = 0;



      for (v = bl->biv; biv_splittable && v; v = v->next_iv)
 if ((tem = single_set (v->insn)) == 0
     || ((((tem)->fld[0].rtx))->code) != REG
     || ((((tem)->fld[0].rtx))->fld[0].rtint) != bl->regno
     || ((((tem)->fld[1].rtx))->code) != PLUS)
   biv_splittable = 0;
      if (biv_splittable == 1)
 {
   if (unroll_type == UNROLL_COMPLETELY)
     {





       if (((bl->initial_value)->code) == REG
    && (((bl->initial_value)->fld[0].rtint) == bl->regno
        || ((bl->initial_value)->fld[0].rtint) < 68
        || ! invariant_p (bl->initial_value)))
  {
    rtx tem = gen_reg_rtx (bl->biv->mode);

    emit_insn_before (gen_move_insn (tem, bl->biv->src_reg),
        loop_start);

    if (loop_dump_stream)
      fprintf (loop_dump_stream, "Biv %d initial value remapped to %d.\n",
        bl->regno, ((tem)->fld[0].rtint));

    splittable_regs[bl->regno] = tem;
  }
       else
  splittable_regs[bl->regno] = bl->initial_value;
     }
   else
     splittable_regs[bl->regno] = const0_rtx;




   splittable_regs_updates[bl->regno] = bl->biv_count;
   result += bl->biv_count;

   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Biv %d safe to split.\n", bl->regno);
 }






      result += find_splittable_givs (bl, unroll_type, loop_start, loop_end,
         increment, unroll_number);





      if (biv_final_value)
 {




   if (! loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]])
     emit_insn_before (gen_move_insn (bl->biv->src_reg,
          biv_final_value),
         end_insert_before);
   else
     {





       rtx tem = gen_reg_rtx (bl->biv->mode);
       emit_insn_before (gen_move_insn (tem, bl->biv->src_reg),
    loop_start);
       emit_insn_before (gen_move_insn (bl->biv->src_reg,
            biv_final_value),
    loop_start);

       if (loop_dump_stream)
  fprintf (loop_dump_stream, "Biv %d mapped to %d for split.\n",
    ((bl->biv->src_reg)->fld[0].rtint), ((tem)->fld[0].rtint));



       bl->biv->src_reg = tem;
     }
 }
    }
  return result;
}





static int
verify_addresses(struct n64_tag_induction *v, rtx giv_inc, int unroll_number) asm("_verify_addresses");
static int
verify_addresses(struct n64_tag_induction *v, rtx giv_inc, int unroll_number)
{
  int ret = 1;
  rtx orig_addr = *v->location;
  rtx last_addr = plus_constant_wide (v->dest_reg, (int) (((giv_inc)->fld[0].rtwint) * (unroll_number - 1)))
                                            ;


  if (! validate_change (v->insn, v->location, v->dest_reg, 0)
      || ! validate_change (v->insn, v->location, last_addr, 0))
    ret = 0;



  validate_change (v->insn, v->location, orig_addr, 0);

  return ret;
}






static int
find_splittable_givs(struct n64_tag_iv_class *bl, n64_enum_unroll_types unroll_type, rtx loop_start, rtx loop_end, rtx increment, int unroll_number) asm("_find_splittable_givs");
static int
find_splittable_givs(struct n64_tag_iv_class *bl, n64_enum_unroll_types unroll_type, rtx loop_start, rtx loop_end, rtx increment, int unroll_number)
{
  struct n64_tag_induction *v, *v2;
  rtx final_value;
  rtx tem;
  int result = 0;



  for (v = bl->giv; v; v = v->next_iv)
    for (v2 = v->next_iv; v2; v2 = v2->next_iv)
      if (v->insn == v2->insn && rtx_equal_p (v->new_reg, v2->new_reg)
   && ! v2->same_insn)
 v2->same_insn = v;

  for (v = bl->giv; v; v = v->next_iv)
    {
      rtx giv_inc, value;



      if (unroll_type != UNROLL_COMPLETELY && v->ignore)
 continue;







      if (v->giv_type != DEST_ADDR
   && (! v->always_computable
       || back_branch_in_range_p (v->insn, loop_start, loop_end)))
 continue;


      giv_inc = fold_rtx_mult_add (v->mult_val, increment, const0_rtx,
       v->mode);
      if (! giv_inc || ((giv_inc)->code) != CONST_INT)
 continue;
      final_value = 0;
      if (unroll_type != UNROLL_COMPLETELY
   && (loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]]
       || unroll_type == UNROLL_NAIVE)
   && v->giv_type != DEST_ADDR
   && ((regno_first_uid[((v->dest_reg)->fld[0].rtint)] != ((v->insn)->fld[0].rtint)



        && (! (tem = find_reg_note (v->insn, REG_RETVAL, (rtx) 0))
     || (regno_first_uid[((v->dest_reg)->fld[0].rtint)]
         != ((((tem)->fld[0].rtx))->fld[0].rtint))))

       || (uid_luid[regno_last_uid[((v->dest_reg)->fld[0].rtint)]]
    >= (((loop_end)->fld[0].rtint) < max_uid_for_loop ? uid_luid[((loop_end)->fld[0].rtint)] : (abort (), -1))))
   && ! (final_value = v->final_value))
 continue;
      if (unroll_type == UNROLL_COMPLETELY)
 {





   rtx biv_initial_value;

   if (splittable_regs[bl->regno])
     biv_initial_value = splittable_regs[bl->regno];
   else if (((bl->initial_value)->code) != REG
     || (((bl->initial_value)->fld[0].rtint) != bl->regno
         && ((bl->initial_value)->fld[0].rtint) >= 68))
     biv_initial_value = bl->initial_value;
   else
     {
       rtx tem = gen_reg_rtx (bl->biv->mode);

       emit_insn_before (gen_move_insn (tem, bl->biv->src_reg),
    loop_start);
       biv_initial_value = tem;
     }
   value = fold_rtx_mult_add (v->mult_val, biv_initial_value,
         v->add_val, v->mode);
 }
      else
 value = const0_rtx;

      if (v->new_reg)
 {




   if (v->same && ! v->same->new_reg)
     {
       if (loop_dump_stream)
  fprintf (loop_dump_stream,
    "giv combined with unreduced giv not split.\n");
       continue;
     }


   else if (v->giv_type == DEST_REG)
     {






       if (unroll_type == UNROLL_COMPLETELY
    && ((value)->code) != CONST_INT
    && ((value)->code) != REG
    && (((value)->code) != PLUS
        || ((((value)->fld[0].rtx))->code) != REG
        || ((((value)->fld[1].rtx))->code) != CONST_INT))
  {
    rtx tem = gen_reg_rtx (v->mode);
    emit_iv_add_mult (bl->initial_value, v->mult_val,
        v->add_val, tem, loop_start);
    value = tem;
  }

       splittable_regs[((v->new_reg)->fld[0].rtint)] = value;
     }
   else
     {
       v->const_adjust = 0;

       if (v->same_insn)
  {
    v->dest_reg = v->same_insn->dest_reg;
    if (loop_dump_stream)
      fprintf (loop_dump_stream,
        "Sharing address givs in insn %d\n",
        ((v->insn)->fld[0].rtint));
  }
       else if (unroll_type != UNROLL_COMPLETELY)
  {



    tem = gen_reg_rtx (v->mode);





    if (((v->new_reg)->code) == PLUS
        && ((((v->new_reg)->fld[1].rtx))->code) == CONST_INT)
      {
        v->dest_reg
   = plus_constant_wide (tem, (int) (((((v->new_reg)->fld[1].rtx))->fld[0].rtwint)));





        if (! verify_addresses (v, giv_inc, unroll_number))
   {



     v->const_adjust = - ((((v->new_reg)->fld[1].rtx))->fld[0].rtwint);

     v->new_reg = ((v->new_reg)->fld[0].rtx);
     if (loop_dump_stream)
       fprintf (loop_dump_stream,
         "Eliminating constant from giv %d\n",
         ((tem)->fld[0].rtint));
   }
        else
   v->dest_reg = tem;
      }
    else
      v->dest_reg = tem;





    if (v->dest_reg == tem
        && ! verify_addresses (v, giv_inc, unroll_number))
      {
        if (loop_dump_stream)
   fprintf (loop_dump_stream,
     "Invalid address for giv at insn %d\n",
     ((v->insn)->fld[0].rtint));
        continue;
      }






    emit_insn_before (gen_rtx (SET, VOIDmode, tem,
          copy_rtx (v->new_reg)),
        loop_start);
    if (recog_memoized (((loop_start)->fld[1].rtx)) < 0)
      {
        rtx sequence, ret;





        delete_insn (((loop_start)->fld[1].rtx));

        start_sequence ();
        ret = force_operand (v->new_reg, tem);
        if (ret != tem)
   emit_move_insn (tem, ret);
        sequence = gen_sequence ();
        end_sequence ();
        emit_insn_before (sequence, loop_start);

        if (loop_dump_stream)
   fprintf (loop_dump_stream,
     "Invalid init insn, rewritten.\n");
      }
  }
       else
  {
    v->dest_reg = value;



    if (! verify_addresses (v, giv_inc, unroll_number))
      {
        if (loop_dump_stream)
   fprintf (loop_dump_stream,
     "Invalid address for giv at insn %d\n",
     ((v->insn)->fld[0].rtint));
        continue;
      }
  }





       *v->location = v->dest_reg;






       if (v->same && v->same->giv_type == DEST_REG)
  addr_combined_regs[((v->same->new_reg)->fld[0].rtint)] = v->same;

       if (((v->new_reg)->code) == REG)
  {



    splittable_regs[((v->new_reg)->fld[0].rtint)] = value;



    if (! v->same)
      {
        v->same = v;
        addr_combined_regs[((v->new_reg)->fld[0].rtint)] = v;
      }
  }

       if (loop_dump_stream)
  fprintf (loop_dump_stream, "DEST_ADDR giv being split.\n");
     }
 }
      else
 {
   continue;

 }





      if (((v->new_reg)->code) == REG)
 splittable_regs_updates[((v->new_reg)->fld[0].rtint)] = 1;

      result++;

      if (loop_dump_stream)
 {
   int regnum;

   if (((v->dest_reg)->code) == CONST_INT)
     regnum = -1;
   else if (((v->dest_reg)->code) != REG)
     regnum = ((((v->dest_reg)->fld[0].rtx))->fld[0].rtint);
   else
     regnum = ((v->dest_reg)->fld[0].rtint);
   fprintf (loop_dump_stream, "Giv %d at insn %d safe to split.\n",
     regnum, ((v->insn)->fld[0].rtint));
 }
    }

  return result;
}
static int
reg_dead_after_loop(rtx reg, rtx loop_start, rtx loop_end) asm("_reg_dead_after_loop");
static int
reg_dead_after_loop(rtx reg, rtx loop_start, rtx loop_end)
{
  rtx insn, label;
  n64_enum_rtx_code code;
  int jump_count = 0;
  int label_count = 0;
  int this_loop_num = uid_loop_num[((loop_start)->fld[0].rtint)];






  for (label = loop_number_exit_labels[this_loop_num]; label;
       label = ((label)->fld[1].rtx))
    label_count++;

  if (label_count != loop_number_exit_count[this_loop_num])
    return 0;




  label = gen_rtx (LABEL_REF, VOIDmode, loop_end);
  ((label)->fld[1].rtx) = loop_number_exit_labels[this_loop_num];

  for ( ; label; label = ((label)->fld[1].rtx))
    {




      insn = ((((label)->fld[0].rtx))->fld[2].rtx);
      while (insn)
 {
   code = ((insn)->code);
   if ((rtx_class[(int)(code)]) == 'i')
     {
       rtx set;

       if (reg_referenced_p (reg, ((insn)->fld[3].rtx)))
  return 0;

       set = single_set (insn);
       if (set && rtx_equal_p (((set)->fld[0].rtx), reg))
  break;
     }

   if (code == JUMP_INSN)
     {
       if (((((insn)->fld[3].rtx))->code) == RETURN)
  break;
       else if (! simplejump_p (insn)

         || jump_count++ > 20)
  return 0;
       else
  insn = ((insn)->fld[7].rtx);
     }

   insn = ((insn)->fld[2].rtx);
 }
    }


  return 1;
}




rtx
final_biv_value(struct n64_tag_iv_class *bl, rtx loop_start, rtx loop_end) asm("_final_biv_value");
rtx
final_biv_value(struct n64_tag_iv_class *bl, rtx loop_start, rtx loop_end)
{
  rtx increment, tem;



  if ((mode_class[(int)(bl->biv->mode)]) != MODE_INT)
    return 0;





  if (bl->reversed)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Final biv value for %d, reversed biv.\n", bl->regno);

      return const0_rtx;
    }







  if (loop_n_iterations != 0
      && ! loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]]
      && invariant_p (bl->initial_value))
    {
      increment = biv_total_increment (bl, loop_start, loop_end);

      if (increment && invariant_p (increment))
 {




   tem = gen_reg_rtx (bl->biv->mode);

   if (((loop_end)->fld[2].rtx) == 0)
     emit_note_after (-1, loop_end);
   emit_iv_add_mult (increment, gen_rtx (CONST_INT, VOIDmode, (int) (loop_n_iterations)),
       bl->initial_value, tem, ((loop_end)->fld[2].rtx));

   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Final biv value for %d, calculated.\n", bl->regno);

   return tem;
 }
    }


  if (reg_dead_after_loop (bl->biv->src_reg, loop_start, loop_end))
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Final biv value for %d, biv dead after loop exit.\n",
   bl->regno);

      return const0_rtx;
    }

  return 0;
}




rtx
final_giv_value(struct n64_tag_induction *v, rtx loop_start, rtx loop_end) asm("_final_giv_value");
rtx
final_giv_value(struct n64_tag_induction *v, rtx loop_start, rtx loop_end)
{
  struct n64_tag_iv_class *bl;
  rtx insn;
  rtx increment, tem;
  rtx insert_before, seq;

  bl = reg_biv_class[((v->src_reg)->fld[0].rtint)];





  if (bl->reversed)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Final giv value for %d, depends on reversed biv\n",
   ((v->dest_reg)->fld[0].rtint));
      return const0_rtx;
    }
  if (loop_n_iterations != 0
      && ! loop_number_exit_count[uid_loop_num[((loop_start)->fld[0].rtint)]])
    {







      increment = biv_total_increment (bl, loop_start, loop_end);

      if (increment && invariant_p (increment))
 {
   insert_before = ((loop_end)->fld[2].rtx);


   tem = gen_reg_rtx (bl->biv->mode);
   emit_iv_add_mult (increment, gen_rtx (CONST_INT, VOIDmode, (int) (loop_n_iterations)),
       bl->initial_value, tem, insert_before);


   for (insn = ((v->insn)->fld[2].rtx); insn != loop_end;
        insn = ((insn)->fld[2].rtx))
     {
       struct n64_tag_induction *biv;

       for (biv = bl->biv; biv; biv = biv->next_iv)
  if (biv->insn == insn)
    {
      start_sequence ();
      tem = expand_binop (((tem)->mode), sub_optab, tem,
     biv->add_val, (rtx) 0, 0,
     OPTAB_LIB_WIDEN);
      seq = gen_sequence ();
      end_sequence ();
      emit_insn_before (seq, insert_before);
    }
     }


   emit_iv_add_mult (tem, v->mult_val, v->add_val, tem,
       insert_before);

   if (loop_dump_stream)
     fprintf (loop_dump_stream,
       "Final giv value for %d, calc from biv's value.\n",
       ((v->dest_reg)->fld[0].rtint));

   return tem;
 }
    }


  if (v->replaceable)
    abort ();


  if (reg_dead_after_loop (v->dest_reg, loop_start, loop_end))
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Final giv value for %d, giv dead after loop exit.\n",
   ((v->dest_reg)->fld[0].rtint));

      return const0_rtx;
    }

  return 0;
}





unsigned int
loop_iterations(rtx loop_start, rtx loop_end) asm("_loop_iterations");
unsigned int
loop_iterations(rtx loop_start, rtx loop_end)
{
  rtx comparison, comparison_value;
  rtx iteration_var, initial_value, increment, final_value;
  n64_enum_rtx_code comparison_code;
  int i;
  int increment_dir;
  int unsigned_compare, compare_dir, final_larger;
  unsigned long tempu;
  rtx last_loop_insn;





  loop_initial_value = 0;
  loop_increment = 0;
  loop_final_value = 0;
  loop_iteration_var = 0;





  last_loop_insn = ((loop_end)->fld[1].rtx);

  comparison = get_condition_for_loop (last_loop_insn);
  if (comparison == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: No final conditional branch found.\n");
      return 0;
    }




  comparison_code = ((comparison)->code);
  iteration_var = ((comparison)->fld[0].rtx);
  comparison_value = ((comparison)->fld[1].rtx);

  if (((iteration_var)->code) != REG)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Comparison not against register.\n");
      return 0;
    }




  if (((iteration_var)->fld[0].rtint) >= max_reg_before_loop)
    abort ();

  iteration_info (iteration_var, &initial_value, &increment,
    loop_start, loop_end);
  if (initial_value == 0)

    return 0;




  if (((comparison_value)->code) == REG && invariant_p (comparison_value))
    {
      rtx insn, set;

      for (insn = ((loop_start)->fld[1].rtx); insn ; insn = ((insn)->fld[1].rtx))
 {
   if (((insn)->code) == CODE_LABEL)
     break;

   else if ((rtx_class[(int)(((insn)->code))]) == 'i'
     && reg_set_p (comparison_value, insn))
     {



       if ((set = single_set (insn))
    && (((set)->fld[0].rtx) == comparison_value))
  {
    rtx note = find_reg_note (insn, REG_EQUAL, (rtx) 0);




    if (note && ((((note)->fld[0].rtx))->code) != EXPR_LIST
        && (((((note)->fld[0].rtx))->code) == LABEL_REF || ((((note)->fld[0].rtx))->code) == SYMBOL_REF || ((((note)->fld[0].rtx))->code) == CONST_INT || ((((note)->fld[0].rtx))->code) == CONST_DOUBLE || ((((note)->fld[0].rtx))->code) == CONST || ((((note)->fld[0].rtx))->code) == HIGH))
      comparison_value = ((note)->fld[0].rtx);
  }
       break;
     }
 }
    }

  final_value = approx_final_value (comparison_code, comparison_value,
        &unsigned_compare, &compare_dir);






  loop_iteration_var = iteration_var;
  loop_initial_value = initial_value;
  loop_increment = increment;
  loop_final_value = final_value;

  if (increment == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Increment value can't be calculated.\n");
      return 0;
    }
  else if (((increment)->code) != CONST_INT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Increment value not constant.\n");
      return 0;
    }
  else if (((initial_value)->code) != CONST_INT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Initial value not constant.\n");
      return 0;
    }
  else if (final_value == 0)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: EQ comparison loop.\n");
      return 0;
    }
  else if (((final_value)->code) != CONST_INT)
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Final value not constant.\n");
      return 0;
    }
  if (unsigned_compare)
    final_larger
      = ((unsigned int) ((final_value)->fld[0].rtwint)
  > (unsigned int) ((initial_value)->fld[0].rtwint))
 - ((unsigned int) ((final_value)->fld[0].rtwint)
    < (unsigned int) ((initial_value)->fld[0].rtwint));
  else
    final_larger = (((final_value)->fld[0].rtwint) > ((initial_value)->fld[0].rtwint))
      - (((final_value)->fld[0].rtwint) < ((initial_value)->fld[0].rtwint));

  if (((increment)->fld[0].rtwint) > 0)
    increment_dir = 1;
  else if (((increment)->fld[0].rtwint) == 0)
    increment_dir = 0;
  else
    increment_dir = -1;
  if (final_larger == increment_dir && final_larger != 0
      && (final_larger == compare_dir || compare_dir == 0))

    ;
  else
    {
      if (loop_dump_stream)
 fprintf (loop_dump_stream,
   "Loop unrolling: Not normal loop.\n");
      return 0;
    }





  i = ((increment)->fld[0].rtwint);
  if (i > 0)
    tempu = ((final_value)->fld[0].rtwint) - ((initial_value)->fld[0].rtwint);
  else if (i < 0)
    {
      tempu = ((initial_value)->fld[0].rtwint) - ((final_value)->fld[0].rtwint);
      i = -i;
    }
  else
    abort ();





  if (compare_dir == 0 && (tempu % i) != 0)
    return 0;

  return tempu / i + ((tempu % i) != 0);
}





static rtx
remap_split_bivs(rtx x) asm("_remap_split_bivs");
static rtx
remap_split_bivs(rtx x)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;

  if (x == 0)
    return x;

  code = ((x)->code);
  switch (code)
    {
    case SCRATCH:
    case PC:
    case CC0:
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
      return x;

    case REG:




      if (((x)->fld[0].rtint) < max_reg_before_loop
   && reg_iv_type[((x)->fld[0].rtint)] == BASIC_INDUCT)
 return reg_biv_class[((x)->fld[0].rtint)]->biv->src_reg;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 ((x)->fld[i].rtx) = remap_split_bivs (((x)->fld[i].rtx));
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     ((x)->fld[i].rtvec->elem[j].rtx) = remap_split_bivs (((x)->fld[i].rtvec->elem[j].rtx));
 }
    }
  return x;
}

