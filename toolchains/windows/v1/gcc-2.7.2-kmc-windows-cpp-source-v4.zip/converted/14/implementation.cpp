// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/stor-layout.c
/* C-compiler utilities for types and variables storage layout
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int global_bindings_p(...) asm("_global_bindings_p");
extern int error(...) asm("_error");
extern int expand_expr(...) asm("_expand_expr");
extern int push_obstacks(...) asm("_push_obstacks");
extern int saveable_allocation(...) asm("_saveable_allocation");
struct n64_tag_function;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");


enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_var_refs_queue
{
  int * modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  int * first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  int * nonlocal_goto_handler_slot;
  int * nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  int * arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  int * *parm_reg_stack_loc;
  int outgoing_args_size;
  int * return_rtx;
  int * cleanup_label;
  int * return_label;
  int * save_expr_regs;
  int * stack_slot_list;
  int * parm_birth_insn;
  int frame_offset;
  int * tail_recursion_label;
  int * tail_recursion_reentry;
  int * internal_arg_pointer;
  int * arg_pointer_save_area;
  tree rtl_expr_chain;
  int * last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  int * last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  int * saveregs_value;
  int * apply_args_value;
  int * forced_labels;


  int reg_rtx_no;
  int first_label_num;
  int * first_insn;
  int * last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  int * *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct obstack *current_obstack;
  struct obstack *function_obstack;
  struct obstack *function_maybepermanent_obstack;
  struct obstack *expression_obstack;
  struct obstack *saveable_obstack;
  struct obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  int * epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern int * return_label;



extern int * stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, int *) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");







tree sizetype;



tree size_zero_node;



tree size_one_node;



int maximum_field_alignment;



int set_alignment = 0;





static n64_enum_machine_mode smallest_mode_for_size (unsigned int, n64_enum_mode_class) asm("_smallest_mode_for_size")
                        ;
static tree layout_record (tree) asm("_layout_record");
static void layout_union (tree) asm("_layout_union");



static tree pending_sizes;




int immediate_size_expand;

tree
get_pending_sizes(void) asm("_get_pending_sizes");
tree
get_pending_sizes(void)
{
  tree chain = pending_sizes;
  tree t;


  for (t = chain; t; t = ((t)->common.chain))
    ((((t)->list.value))->exp.operands[1]) = current_function_decl;
  pending_sizes = 0;
  return chain;
}

void
put_pending_sizes(tree chain) asm("_put_pending_sizes");
void
put_pending_sizes(tree chain)
{
  if (pending_sizes)
    abort ();

  pending_sizes = chain;
}




tree
variable_size(tree size) asm("_variable_size");
tree
variable_size(tree size)
{



  if (((size)->common.constant_flag)
      || global_bindings_p () < 0 || contains_placeholder_p (size))
    return size;

  size = save_expr (size);

  if (global_bindings_p ())
    {
      if (((size)->common.constant_flag))
 error ("type size can't be explicitly evaluated");
      else
 error ("variable-size type declared outside of any function");

      return size_int (1);
    }

  if (immediate_size_expand)


    expand_expr (size, expand_expr (integer_zero_node, ((void *)0), VOIDmode, 0),
   VOIDmode, 0);
  else
    pending_sizes = tree_cons ((tree) 
                              ((void *)0)
                                       , size, pending_sizes);

  return size;
}
n64_enum_machine_mode
mode_for_size(unsigned int size, n64_enum_mode_class cxx_class, int limit) asm("_mode_for_size");
n64_enum_machine_mode
mode_for_size(unsigned int size, n64_enum_mode_class cxx_class, int limit)
{
  register n64_enum_machine_mode mode;

  if (limit && size > (8 * mode_size[(int)(DImode)]))
    return BLKmode;


  for (mode = class_narrowest_mode[(int)(cxx_class)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    if ((8 * mode_size[(int)(mode)]) == size)
      return mode;

  return BLKmode;
}




static n64_enum_machine_mode
smallest_mode_for_size(unsigned int size, n64_enum_mode_class cxx_class) asm("_smallest_mode_for_size");
static n64_enum_machine_mode
smallest_mode_for_size(unsigned int size, n64_enum_mode_class cxx_class)
{
  register n64_enum_machine_mode mode;



  for (mode = class_narrowest_mode[(int)(cxx_class)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    if ((8 * mode_size[(int)(mode)]) >= size)
      return mode;

  abort ();
}



tree
round_up(tree value, int divisor) asm("_round_up");
tree
round_up(tree value, int divisor)
{
  return size_binop (MULT_EXPR,
       size_binop (CEIL_DIV_EXPR, value, size_int (divisor)),
       size_int (divisor));
}
void
layout_decl(tree decl, unsigned int known_align) asm("_layout_decl");
void
layout_decl(tree decl, unsigned int known_align)
{
  register tree type = ((decl)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (decl)->common.code);
  int spec_size = ((decl)->decl.saved_insns.i);

  if (code == CONST_DECL)
    return;

  if (code != VAR_DECL && code != PARM_DECL && code != RESULT_DECL
      && code != FIELD_DECL && code != TYPE_DECL)
    abort ();

  if (type == error_mark_node)
    {
      type = void_type_node;
      spec_size = 0;
    }



  ((decl)->decl.mode) = ((type)->type.mode);
  ((decl)->common.unsigned_flag) = ((type)->common.unsigned_flag);
  if (((decl)->decl.size) == 0)
    ((decl)->decl.size) = ((type)->type.size);

  if (code == FIELD_DECL && ((decl)->decl.bit_field_flag))
    {
      if (spec_size == 0 && ((decl)->decl.name) != 0)
 abort ();


      ((decl)->decl.size) = size_int (spec_size);
    }



  else if (((decl)->decl.frame_size.u) == 0
    || (! ((decl)->decl.regdecl_flag) && ((type)->type.align) > ((decl)->decl.frame_size.u)))
    ((decl)->decl.frame_size.u) = ((type)->type.align);




  if (code == FIELD_DECL)
    {
      ((decl)->decl.result) = ((decl)->decl.bit_field_flag) ? type : 0;
      if (maximum_field_alignment != 0)
 ((decl)->decl.frame_size.u) = ((((decl)->decl.frame_size.u)) < (maximum_field_alignment) ? (((decl)->decl.frame_size.u)) : (maximum_field_alignment));
      else if (flag_pack_struct)
 ((decl)->decl.frame_size.u) = ((((decl)->decl.frame_size.u)) < (8) ? (((decl)->decl.frame_size.u)) : (8));
    }

  if (((decl)->decl.bit_field_flag)
      && ((type)->type.size) != 0
      && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST)
    {
      register n64_enum_machine_mode xmode
 = mode_for_size (((((decl)->decl.size))->int_cst.int_cst_low), MODE_INT, 1);

      if (xmode != BLKmode
   && known_align % ((64) < (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8))))) == 0)
 {
   ((decl)->decl.frame_size.u) = ((((64) < (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8)))))) > (((decl)->decl.frame_size.u)) ? (((64) < (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(xmode)]) * 8)) ? (1) : (((mode_unit_size[(int)(xmode)]) * 8)))))) : (((decl)->decl.frame_size.u)))
                         ;
   ((decl)->decl.mode) = xmode;
   ((decl)->decl.size) = size_int ((8 * mode_size[(int)(xmode)]));

   ((decl)->decl.bit_field_flag) = 0;
 }
    }


  if (((decl)->decl.size) != 0 && ((n64_enum_tree_code) (((decl)->decl.size))->common.code) != INTEGER_CST)
    ((decl)->decl.size) = variable_size (((decl)->decl.size));
}
static tree
layout_record(tree rec) asm("_layout_record");
static tree
layout_record(tree rec)
{
  register tree field;

  unsigned record_align = ((8) > (((rec)->type.align)) ? (8) : (((rec)->type.align)));




  tree pending_statics = (tree) 
                        ((void *)0)
                                 ;





  register int const_size = 0;
  register tree var_size = 0;


  register int var_align = 8;


  for (field = ((rec)->type.values); field; field = ((field)->common.chain))
    {
      register int known_align = var_size ? var_align : const_size;
      register int desired_align;







      if (((field)->common.static_flag))
 {
   pending_statics = tree_cons ((tree) 
                               ((void *)0)
                                        , field, pending_statics);
   continue;
 }


      if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
 continue;




      if (((field)->decl.regdecl_flag))
 desired_align = ((field)->decl.frame_size.u);
      layout_decl (field, known_align);
      if (! ((field)->decl.regdecl_flag))
 desired_align = ((field)->decl.frame_size.u);



      desired_align = ((desired_align) < (64) ? (desired_align) : (64));
      if (1 && ((field)->common.type) != error_mark_node
   && ((field)->decl.result)
   && ! integer_zerop (((((field)->common.type))->type.size)))
 {




   if (! integer_zerop (((field)->decl.size)))
     record_align = ((record_align) > (desired_align) ? (record_align) : (desired_align));
   else if (! ((field)->decl.regdecl_flag))
     desired_align = ((((field)->common.type))->type.align);


   if (((field)->decl.name) != 0)
     {
       int type_align = ((((field)->common.type))->type.align);
       if (maximum_field_alignment != 0)
  type_align = ((type_align) < (maximum_field_alignment) ? (type_align) : (maximum_field_alignment));
       else if (flag_pack_struct)
  type_align = ((type_align) < (8) ? (type_align) : (8));

       record_align = ((record_align) > (type_align) ? (record_align) : (type_align));
     }
 }
      else
 record_align = ((record_align) > (desired_align) ? (record_align) : (desired_align));






      if (const_size % desired_align != 0
   || (var_align % desired_align != 0
       && var_size != 0))
 {



   if (var_size == 0
       || var_align % desired_align == 0)
     const_size
       = (((const_size) + (desired_align) - 1) / (desired_align)) * desired_align;
   else
     {
       if (const_size > 0)
  var_size = size_binop (PLUS_EXPR, var_size,
           size_int (const_size));
       const_size = 0;
       var_size = round_up (var_size, desired_align);
       var_align = ((var_align) < (desired_align) ? (var_align) : (desired_align));
     }
 }


      if (1
   && ((n64_enum_tree_code) (field)->common.code) == FIELD_DECL
   && ((field)->common.type) != error_mark_node
   && ((field)->decl.result)
   && !((field)->decl.regdecl_flag)

   && maximum_field_alignment == 0
   && !flag_pack_struct
   && !integer_zerop (((field)->decl.size)))
 {
   int type_align = ((((field)->common.type))->type.align);
   register tree dsize = ((field)->decl.size);
   int field_size = ((dsize)->int_cst.int_cst_low);







   if (const_size / type_align
       != (const_size + field_size - 1) / type_align)
     const_size = (((const_size) + (type_align) - 1) / (type_align)) * type_align;
 }
      if (var_size && const_size)
 ((field)->decl.arguments)
   = size_binop (PLUS_EXPR, var_size, size_int (const_size));
      else if (var_size)
 ((field)->decl.arguments) = var_size;
      else
 {
   ((field)->decl.arguments) = size_int (const_size);





   if (known_align != const_size)
     layout_decl (field, const_size);
 }



      {
        register tree dsize = ((field)->decl.size);




 if (dsize == 0)
                     ;
 else if (((n64_enum_tree_code) (dsize)->common.code) == INTEGER_CST
   && ((dsize)->int_cst.int_cst_high) == 0
   && ((dsize)->int_cst.int_cst_low) + const_size > const_size)

   const_size += ((dsize)->int_cst.int_cst_low);
 else
   {
     if (var_size == 0)
       var_size = dsize;
     else
       var_size = size_binop (PLUS_EXPR, var_size, dsize);
   }
      }
    }





  if (var_size == 0)
    {
      ((rec)->type.size) = size_int (const_size);
    }
  else
    {
      if (const_size)
 var_size
   = size_binop (PLUS_EXPR, var_size, size_int (const_size));
      ((rec)->type.size) = var_size;
    }





  ((rec)->type.align) = ((((rec)->type.align)) > (record_align) ? (((rec)->type.align)) : (record_align));






  ((rec)->type.size) = round_up (((rec)->type.size), ((rec)->type.align));


  return pending_statics;
}







static void
layout_union(tree rec) asm("_layout_union");
static void
layout_union(tree rec)
{
  register tree field;

  unsigned union_align = 8;







  register int const_size = 0;
  register tree var_size = 0;




  if (((n64_enum_tree_code) (rec)->common.code) == QUAL_UNION_TYPE)
    ((rec)->type.values) = nreverse (((rec)->type.values));

  for (field = ((rec)->type.values); field; field = ((field)->common.chain))
    {

      if (((n64_enum_tree_code) (field)->common.code) == CONST_DECL || ((n64_enum_tree_code) (field)->common.code) == TYPE_DECL)
 continue;

      layout_decl (field, 0);
      ((field)->decl.arguments) = size_int (0);



      union_align = ((union_align) > (((field)->decl.frame_size.u)) ? (union_align) : (((field)->decl.frame_size.u)));




      if (1 && ((field)->decl.result))
 union_align = ((union_align) > (((((field)->common.type))->type.align)) ? (union_align) : (((((field)->common.type))->type.align)));


      if (((n64_enum_tree_code) (rec)->common.code) == UNION_TYPE)
 {




   if (((n64_enum_tree_code) (((field)->decl.size))->common.code) == INTEGER_CST)
     const_size
       = ((const_size) > (((((field)->decl.size))->int_cst.int_cst_low)) ? (const_size) : (((((field)->decl.size))->int_cst.int_cst_low)));
   else if (var_size == 0)
     var_size = ((field)->decl.size);
   else
     var_size = size_binop (MAX_EXPR, var_size, ((field)->decl.size));
 }
      else if (((n64_enum_tree_code) (rec)->common.code) == QUAL_UNION_TYPE)
 var_size = fold (build (COND_EXPR, sizetype, ((field)->decl.initial),
    ((field)->decl.size),
    var_size ? var_size : integer_zero_node));
      }

  if (((n64_enum_tree_code) (rec)->common.code) == QUAL_UNION_TYPE)
    ((rec)->type.values) = nreverse (((rec)->type.values));


  if (
     ((void *)0) 
          == var_size)
    ((rec)->type.size) = size_int ((((const_size) + (8) - 1) / (8))
    * 8);
  else if (const_size == 0)
    ((rec)->type.size) = var_size;
  else
    ((rec)->type.size) = size_binop (MAX_EXPR, var_size,
      round_up (size_int (const_size),
         8));





  ((rec)->type.align) = ((((rec)->type.align)) > (union_align) ? (((rec)->type.align)) : (union_align));






  ((rec)->type.size) = round_up (((rec)->type.size), ((rec)->type.align));

}
void
layout_type(tree type) asm("_layout_type");
void
layout_type(tree type)
{
  int old;
  tree pending_statics;

  if (type == 0)
    abort ();


  if (((type)->type.size))
    return;



  old = suspend_momentary ();




  push_obstacks (((type)->type.obstack), ((type)->type.obstack));
  saveable_allocation ();

  switch (((n64_enum_tree_code) (type)->common.code))
    {
    case LANG_TYPE:


      abort ();

    case INTEGER_TYPE:
    case ENUMERAL_TYPE:
      if (((n64_enum_tree_code) (((type)->type.minval))->common.code) == INTEGER_CST
   && tree_int_cst_sgn (((type)->type.minval)) >= 0)
 ((type)->common.unsigned_flag) = 1;

      ((type)->type.mode) = smallest_mode_for_size (((type)->type.precision),
       MODE_INT);
      ((type)->type.size) = size_int ((8 * mode_size[(int)(((type)->type.mode))]));
      break;

    case REAL_TYPE:
      ((type)->type.mode) = mode_for_size (((type)->type.precision), MODE_FLOAT, 0);
      ((type)->type.size) = size_int ((8 * mode_size[(int)(((type)->type.mode))]));
      break;

    case COMPLEX_TYPE:
      ((type)->common.unsigned_flag) = ((((type)->common.type))->common.unsigned_flag);
      ((type)->type.mode)
 = mode_for_size (2 * ((((type)->common.type))->type.precision),
    (((n64_enum_tree_code) (((type)->common.type))->common.code) == INTEGER_TYPE
     ? MODE_COMPLEX_INT : MODE_COMPLEX_FLOAT),
    0);
      ((type)->type.size) = size_int ((8 * mode_size[(int)(((type)->type.mode))]));
      break;

    case VOID_TYPE:
      ((type)->type.size) = size_zero_node;
      ((type)->type.align) = 1;
      ((type)->type.mode) = VOIDmode;
      break;

    case OFFSET_TYPE:
      ((type)->type.size) = size_int (((target_flags & 0x00000002) ? 64 : 32));
      ((type)->type.mode) = ptr_mode;
      break;

    case FUNCTION_TYPE:
    case METHOD_TYPE:
      ((type)->type.mode) = mode_for_size (2 * ((target_flags & 0x00000002) ? 64 : 32), MODE_INT, 0);
      ((type)->type.size) = size_int (2 * ((target_flags & 0x00000002) ? 64 : 32));
      break;

    case POINTER_TYPE:
    case REFERENCE_TYPE:
      ((type)->type.mode) = ptr_mode;
      ((type)->type.size) = size_int (((target_flags & 0x00000002) ? 64 : 32));
      ((type)->common.unsigned_flag) = 1;
      ((type)->type.precision) = ((target_flags & 0x00000002) ? 64 : 32);
      break;

    case ARRAY_TYPE:
      {
 register tree strchr = ((type)->type.values);
 register tree element = ((type)->common.type);

 build_pointer_type (element);


 if (strchr && ((strchr)->type.maxval) && ((strchr)->type.minval)
     && ((element)->type.size))
   {
     tree ub = ((strchr)->type.maxval);
     tree lb = ((strchr)->type.minval);
     tree length;



     if (((n64_enum_tree_code) (ub)->common.code) == MAX_EXPR
  && ((n64_enum_tree_code) (((ub)->exp.operands[0]))->common.code) == MINUS_EXPR
  && integer_onep (((((ub)->exp.operands[0]))->exp.operands[1]))
  && operand_equal_p (((((ub)->exp.operands[0]))->exp.operands[0]),
        lb, 0))
       ub = ((ub)->exp.operands[1]);
     else if (((n64_enum_tree_code) (ub)->common.code) == MAX_EXPR
       && ((n64_enum_tree_code) (((ub)->exp.operands[1]))->common.code) == MINUS_EXPR
       && integer_onep (((((ub)->exp.operands[1]))->exp.operands[1]))
       && operand_equal_p (((((ub)->exp.operands[1]))->exp.operands[0])
               ,
      lb, 0))
       ub = ((ub)->exp.operands[0]);

     length = size_binop (PLUS_EXPR, size_one_node,
     size_binop (MINUS_EXPR, ub, lb));





     if (! ((sizetype)->common.unsigned_flag)
  && ((n64_enum_tree_code) (((strchr)->type.minval))->common.code) != INTEGER_CST
  && ((n64_enum_tree_code) (((strchr)->type.maxval))->common.code) != INTEGER_CST)
       length = size_binop (MAX_EXPR, length, size_zero_node);

     ((type)->type.size) = size_binop (MULT_EXPR, length,
        ((element)->type.size));
   }
 ((type)->type.align) = ((((element)->type.align)) > (8) ? (((element)->type.align)) : (8));
 ((type)->type.mode) = BLKmode;
 if (((type)->type.size) != 0
     && ((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST


     && (((((type)->common.type))->type.mode) != BLKmode
  || ((((type)->common.type))->type.no_force_blk_flag)))
   {
     ((type)->type.mode)
       = mode_for_size (((((type)->type.size))->int_cst.int_cst_low),
          MODE_INT, 1);

     if (1 && ((type)->type.align) < 64
  && ((type)->type.align) < ((((type)->type.size))->int_cst.int_cst_low)
  && ((type)->type.mode) != BLKmode)
       {
  ((type)->type.no_force_blk_flag) = 1;
  ((type)->type.mode) = BLKmode;
       }
   }
 break;
      }

    case RECORD_TYPE:
      pending_statics = layout_record (type);
      ((type)->type.mode) = BLKmode;
      if (((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST)
 {
   tree field;



   for (field = ((type)->type.values); field; field = ((field)->common.chain))
     {
       int bitpos;

       if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
  continue;

       if (((((field)->common.type))->type.mode) == BLKmode
    && ! ((((field)->common.type))->type.no_force_blk_flag))
  goto record_lose;

       if (((n64_enum_tree_code) (((field)->decl.arguments))->common.code) != INTEGER_CST)
  goto record_lose;

       bitpos = ((((field)->decl.arguments))->int_cst.int_cst_low);



       if (bitpos / ((target_flags & 0x00002000) ? 64 : 32)
    != ((((((field)->decl.size))->int_cst.int_cst_low) + bitpos - 1)
        / ((target_flags & 0x00002000) ? 64 : 32))

    && ((((field)->decl.size))->int_cst.int_cst_low) % ((target_flags & 0x00002000) ? 64 : 32) == 0)
  goto record_lose;
     }

   ((type)->type.mode)
     = mode_for_size (((((type)->type.size))->int_cst.int_cst_low),
        MODE_INT, 1);




   if (1
       && ! (((type)->type.align) >= 64
      || (((type)->type.align)
   >= ((((type)->type.size))->int_cst.int_cst_low))))
     {
       if (((type)->type.mode) != BLKmode)


  ((type)->type.no_force_blk_flag) = 1;
       ((type)->type.mode) = BLKmode;
     }

 record_lose: ;
 }



      while (pending_statics)
 {
   layout_decl (((pending_statics)->list.value), 0);
   pending_statics = ((pending_statics)->common.chain);
 }
      break;

    case UNION_TYPE:
    case QUAL_UNION_TYPE:
      layout_union (type);
      ((type)->type.mode) = BLKmode;
      if (((n64_enum_tree_code) (((type)->type.size))->common.code) == INTEGER_CST



   && (! 1
       || ((type)->type.align) >= 64
       || ((type)->type.align) >= ((((type)->type.size))->int_cst.int_cst_low)))
 {
   tree field;



   for (field = ((type)->type.values); field; field = ((field)->common.chain))
     {
       if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
  continue;

       if (((((field)->common.type))->type.mode) == BLKmode
    && ! ((((field)->common.type))->type.no_force_blk_flag))
  goto union_lose;
     }

   ((type)->type.mode)
     = mode_for_size (((((type)->type.size))->int_cst.int_cst_low),
        MODE_INT, 1);

 union_lose: ;
 }
      break;


    case BOOLEAN_TYPE:
      ((type)->type.mode) = QImode;
      ((type)->type.size) = size_int ((8 * mode_size[(int)(((type)->type.mode))]));
      ((type)->type.precision) = 1;
      ((type)->type.align) = ((64) < (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))));
      if (((n64_enum_tree_code) (((type)->type.minval))->common.code) == INTEGER_CST
   && tree_int_cst_sgn (((type)->type.minval)) >= 0)
  ((type)->common.unsigned_flag) = 1;
      break;

    case CHAR_TYPE:
      ((type)->type.mode) = QImode;
      ((type)->type.size) = size_int ((8 * mode_size[(int)(((type)->type.mode))]));
      ((type)->type.precision) = (8 * mode_size[(int)(((type)->type.mode))]);
      ((type)->type.align) = ((64) < (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))));
      break;

    case SET_TYPE:
      if (((n64_enum_tree_code) (((((type)->type.values))->type.maxval))->common.code) != INTEGER_CST
   || ((n64_enum_tree_code) (((((type)->type.values))->type.minval))->common.code) != INTEGER_CST)
 abort();
      else
 {



   int alignment = set_alignment ? set_alignment : ((target_flags & 0x00002000) ? 64 : 32);
   int size_in_bits =
     ((((((type)->type.values))->type.maxval))->int_cst.int_cst_low)
       - ((((((type)->type.values))->type.minval))->int_cst.int_cst_low) + 1;
   int rounded_size
     = ((size_in_bits + alignment - 1) / alignment) * alignment;
   if (rounded_size > alignment)
     ((type)->type.mode) = BLKmode;
   else
     ((type)->type.mode) = mode_for_size (alignment, MODE_INT, 1);
   ((type)->type.size) = size_int (rounded_size);
   ((type)->type.align) = alignment;
   ((type)->type.precision) = size_in_bits;
 }
      break;

    case FILE_TYPE:


      ((type)->type.align) = 64;
      ((type)->type.mode) = BLKmode;
      break;

    default:
      abort ();
    }






  if (((type)->type.mode) != BLKmode && ((type)->type.mode) != VOIDmode
      && (1
   || (((n64_enum_tree_code) (type)->common.code) != RECORD_TYPE && ((n64_enum_tree_code) (type)->common.code) != UNION_TYPE
       && ((n64_enum_tree_code) (type)->common.code) != QUAL_UNION_TYPE
       && ((n64_enum_tree_code) (type)->common.code) != ARRAY_TYPE)))
    ((type)->type.align) = ((64) < (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))) ? (64) : (((1) > (((mode_unit_size[(int)(((type)->type.mode))]) * 8)) ? (1) : (((mode_unit_size[(int)(((type)->type.mode))]) * 8)))));


  if (((type)->type.size) != 0 && ((n64_enum_tree_code) (((type)->type.size))->common.code) != INTEGER_CST)
    ((type)->type.size) = variable_size (((type)->type.size));


  if (((type)->type.next_variant)
      || type != ((type)->type.main_variant))
    {
      tree variant;

      tree size = ((type)->type.size);
      int align = ((type)->type.align);
      n64_enum_machine_mode mode = ((type)->type.mode);


      for (variant = ((type)->type.main_variant);
    variant;
    variant = ((variant)->type.next_variant))
 {
   ((variant)->type.size) = size;
   ((variant)->type.align) = align;
   ((variant)->type.mode) = mode;
 }
    }

  pop_obstacks ();
  resume_momentary (old);
}



tree
make_signed_type(int precision) asm("_make_signed_type");
tree
make_signed_type(int precision)
{
  register tree type = make_node (INTEGER_TYPE);

  ((type)->type.precision) = precision;



  ((type)->type.minval)
    = build_int_2_wide ((int) ((precision - 32 > 0 ? 0 : (int) (-1) << (precision - 1))), (int) ((((int) (-1) << (precision - 32 - 1 > 0 ? precision - 32 - 1 : 0)))))




           ;
  ((type)->type.maxval)
    = build_int_2_wide ((int) ((precision - 32 > 0 ? -1 : ((int) 1 << (precision - 1)) - 1)), (int) ((precision - 32 - 1 > 0 ? (((int) 1 << (precision - 32 - 1))) - 1 : 0)))




           ;



  ((((type)->type.minval))->common.type) = type;
  ((((type)->type.maxval))->common.type) = type;




  if (sizetype == 0)
    {
      sizetype = type;
    }



  layout_type (type);

  return type;
}



tree
make_unsigned_type(int precision) asm("_make_unsigned_type");
tree
make_unsigned_type(int precision)
{
  register tree type = make_node (INTEGER_TYPE);

  ((type)->type.precision) = precision;




  if (sizetype == 0)
    {
      sizetype = type;
    }

  fixup_unsigned_type (type);
  return type;
}






void
fixup_signed_type(tree type) asm("_fixup_signed_type");
void
fixup_signed_type(tree type)
{
  register int precision = ((type)->type.precision);

  ((type)->type.minval)
    = build_int_2_wide ((int) ((precision - 32 > 0 ? 0 : (int) (-1) << (precision - 1))), (int) ((((int) (-1) << (precision - 32 - 1 > 0 ? precision - 32 - 1 : 0)))))




           ;
  ((type)->type.maxval)
    = build_int_2_wide ((int) ((precision - 32 > 0 ? -1 : ((int) 1 << (precision - 1)) - 1)), (int) ((precision - 32 - 1 > 0 ? (((int) 1 << (precision - 32 - 1))) - 1 : 0)))




           ;

  ((((type)->type.minval))->common.type) = type;
  ((((type)->type.maxval))->common.type) = type;



  layout_type (type);
}





void
fixup_unsigned_type(tree type) asm("_fixup_unsigned_type");
void
fixup_unsigned_type(tree type)
{
  register int precision = ((type)->type.precision);

  ((type)->type.minval) = build_int_2_wide ((int) (0), (int) (0));
  ((type)->type.maxval)
    = build_int_2_wide ((int) (precision - 32 >= 0 ? -1 : ((int) 1 << precision) - 1), (int) (precision - 32 > 0 ? ((unsigned int) ~0 >> (32 - (precision - 32))) : 0))





         ;
  ((((type)->type.minval))->common.type) = type;
  ((((type)->type.maxval))->common.type) = type;



  layout_type (type);
}
n64_enum_machine_mode
get_best_mode(int bitsize, int bitpos, int align, n64_enum_machine_mode largest_mode, int volatilep) asm("_get_best_mode");
n64_enum_machine_mode
get_best_mode(int bitsize, int bitpos, int align, n64_enum_machine_mode largest_mode, int volatilep)
{
  n64_enum_machine_mode mode;
  int unit;


  for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    {
      unit = (8 * mode_size[(int)(mode)]);
      if (bitpos / unit == (bitpos + bitsize - 1) / unit)
 break;
    }

  if (mode == MAX_MACHINE_MODE







      || ((unit) < (64) ? (unit) : (64)) > align
      || (largest_mode != VOIDmode && unit > (8 * mode_size[(int)(largest_mode)])))
    return VOIDmode;

  if (1 && ! volatilep)
    {
      n64_enum_machine_mode wide_mode = VOIDmode, tmode;

      for (tmode = class_narrowest_mode[(int)(MODE_INT)]; tmode != VOIDmode;
    tmode = (mode_wider_mode[(int)(tmode)]))
 {
   unit = (8 * mode_size[(int)(tmode)]);
   if (bitpos / unit == (bitpos + bitsize - 1) / unit
       && unit <= ((target_flags & 0x00002000) ? 64 : 32)
       && unit <= ((align) < (64) ? (align) : (64))
       && (largest_mode == VOIDmode
    || unit <= (8 * mode_size[(int)(largest_mode)])))
     wide_mode = tmode;
 }

      if (wide_mode != VOIDmode)
 return wide_mode;
    }

  return mode;
}




void
save_storage_status(struct n64_tag_function *p) asm("_save_storage_status");
void
save_storage_status(struct n64_tag_function *p)
{




}




void
restore_storage_status(struct n64_tag_function *p) asm("_restore_storage_status");
void
restore_storage_status(struct n64_tag_function *p)
{




}

