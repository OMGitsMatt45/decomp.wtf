// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/integrate.c
/* Procedure integration for GNU CC.
   Copyright (C) 1988, 1991, 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int get_max_uid(...) asm("_get_max_uid");
extern int aggregate_value_p(...) asm("_aggregate_value_p");
extern int max_label_num(...) asm("_max_label_num");
extern int get_first_label_num(...) asm("_get_first_label_num");
extern int max_reg_num(...) asm("_max_reg_num");
extern int max_parm_reg_num(...) asm("_max_parm_reg_num");
extern int preserve_data(...) asm("_preserve_data");
extern int set_new_first_and_last_insn(...) asm("_set_new_first_and_last_insn");
extern int note_stores(...) asm("_note_stores");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int apply_change_group(...) asm("_apply_change_group");
extern int volatile_refs_p(...) asm("_volatile_refs_p");
extern int condjump_p(...) asm("_condjump_p");
extern int simplejump_p(...) asm("_simplejump_p");
extern int saveable_allocation(...) asm("_saveable_allocation");
extern int subreg_realpart_p(...) asm("_subreg_realpart_p");
extern int num_validated_changes(...) asm("_num_validated_changes");
extern int validate_change(...) asm("_validate_change");
extern int cancel_changes(...) asm("_cancel_changes");
extern int warning(...) asm("_warning");
extern int temporary_allocation(...) asm("_temporary_allocation");
extern int init_function_start(...) asm("_init_function_start");
extern int assign_parms(...) asm("_assign_parms");
extern int restore_reg_data(...) asm("_restore_reg_data");
extern int set_new_first_and_last_label_num(...) asm("_set_new_first_and_last_label_num");
extern int rest_of_compilation(...) asm("_rest_of_compilation");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_equiv_table;
struct n64_tag_function;
struct n64_tag_inline_remap;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_var_refs_queue;


extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
struct n64_tag_equiv_table
    {
      rtx dest;
      rtx equiv;
    };
struct n64_tag_inline_remap
{



  int integrating;

  union n64_tag_tree_node *fndecl;

  rtx insns_at_start;


  rtx *reg_map;


  rtx *label_map;





  rtx *insn_map;
  int min_insnno, max_insnno;
  rtx *const_equiv_map;

  int const_equiv_map_size;






  unsigned int const_age;


  unsigned int *const_age_map;

  rtx inline_target;



  rtvec orig_asm_operands_vector;



  rtvec copy_asm_operands_vector;

  rtvec copy_asm_constraints_vector;



  int num_sets;
  struct n64_tag_equiv_table equiv_sets[10];


  rtx last_pc_value;




};



extern rtx copy_rtx_and_substitute (rtx, struct n64_tag_inline_remap *) asm("_copy_rtx_and_substitute");

extern void try_constants (rtx, struct n64_tag_inline_remap *) asm("_try_constants");

extern void mark_stores (rtx, rtx) asm("_mark_stores");





extern rtx *global_const_equiv_map;
extern int global_const_equiv_map_size;

struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");



extern struct n64_tag_obstack *function_maybepermanent_obstack;

extern tree pushdecl(...) asm("_pushdecl");
extern tree poplevel(...) asm("_poplevel");
static rtx initialize_for_inline (tree, int, int, int, int) asm("_initialize_for_inline");
static void finish_inline (tree, rtx) asm("_finish_inline");
static void adjust_copied_decl_tree (tree) asm("_adjust_copied_decl_tree");
static tree copy_decl_list (tree) asm("_copy_decl_list");
static tree copy_decl_tree (tree) asm("_copy_decl_tree");
static void copy_decl_rtls (tree) asm("_copy_decl_rtls");
static void save_constants (rtx *) asm("_save_constants");
static void note_modified_parmregs (rtx, rtx) asm("_note_modified_parmregs");
static rtx copy_for_inline (rtx) asm("_copy_for_inline");
static void integrate_parm_decls (tree, struct n64_tag_inline_remap *, rtvec) asm("_integrate_parm_decls");
static void integrate_decl_tree (tree, int, struct n64_tag_inline_remap *) asm("_integrate_decl_tree");
static void subst_constants (rtx *, rtx, struct n64_tag_inline_remap *) asm("_subst_constants");
static void restore_constants (rtx *) asm("_restore_constants");
static void set_block_origin_self (tree) asm("_set_block_origin_self");
static void set_decl_origin_self (tree) asm("_set_decl_origin_self");
static void set_block_abstract_flags (tree, int) asm("_set_block_abstract_flags");

void set_decl_abstract_flags (tree, int) asm("_set_decl_abstract_flags");






char *
function_cannot_inline_p(register tree fndecl) asm("_function_cannot_inline_p");
char *
function_cannot_inline_p(register tree fndecl)
{
  register rtx insn;
  tree last = tree_last (((((fndecl)->common.type))->type.values));
  int max_insns = (8 * (8 + list_length (((fndecl)->decl.arguments))));
  register int ninsns = 0;
  register tree parms;




  if ((last && ((last)->list.value) != void_type_node)
      || current_function_varargs)
    return "varargs function cannot be inline";

  if (current_function_calls_alloca)
    return "function using alloca cannot be inline";

  if (current_function_contains_functions)
    return "function with nested functions cannot be inline";


  if (!((fndecl)->decl.inline_flag) && get_max_uid () > 3 * max_insns)
    return "function too large to be inline";
  if (current_function_returns_pcc_struct)
    return "inline functions not supported for this return value type";


  if (((((((fndecl)->common.type))->common.type))->type.mode) == BLKmode
      && ! aggregate_value_p (((((fndecl)->common.type))->common.type)))
    return "inline functions not supported for this return value type";


  if (int_size_in_bytes (((((fndecl)->common.type))->common.type)) < 0)
    return "function with varying-size return value cannot be inline";



  for (parms = ((fndecl)->decl.arguments); parms; parms = ((parms)->common.chain))
    {
      if (int_size_in_bytes (((parms)->common.type)) < 0)
 return "function with varying-size parameter cannot be inline";
      else if (((((parms)->common.type))->type.transparent_union_flag))
 return "function with transparent unit parameter cannot be inline";
    }

  if (!((fndecl)->decl.inline_flag) && get_max_uid () > max_insns)
    {
      for (ninsns = 0, insn = get_first_nonparm_insn (); insn && ninsns < max_insns;
    insn = ((insn)->fld[2].rtx))
 {
   if ((rtx_class[(int)(((insn)->code))]) == 'i')
     ninsns++;
 }

      if (ninsns >= max_insns)
 return "function too large to be inline";
    }
  if (forced_labels)
    return "function with label addresses used in initializers cannot inline";


  if (current_function_has_nonlocal_goto)
    return "function with nonlocal goto cannot be inline";

  return 0;
}







static rtx *reg_map;





static rtx *label_map;




static rtx *insn_map;




static tree *parmdecl_map;


static int max_parm_reg;




static rtvec orig_asm_operands_vector;




static rtvec copy_asm_operands_vector;


static rtvec copy_asm_constraints_vector;


static int in_nonparm_insns;




static rtx
initialize_for_inline(tree fndecl, int min_labelno, int max_labelno, int max_reg, int copy) asm("_initialize_for_inline");
static rtx
initialize_for_inline(tree fndecl, int min_labelno, int max_labelno, int max_reg, int copy)
{
  int function_flags, i;
  rtvec arg_vector;
  tree parms;



  function_flags
    = (current_function_calls_alloca * 01
       + current_function_calls_setjmp * 02
       + current_function_calls_longjmp * 0400
       + current_function_returns_struct * 04
       + current_function_returns_pcc_struct * 010
       + current_function_needs_context * 020
       + current_function_has_nonlocal_label * 040
       + current_function_returns_pointer * 0100
       + current_function_uses_const_pool * 0200
       + current_function_uses_pic_offset_table * 01000);


  memset ((char *) parmdecl_map,0,max_parm_reg * sizeof (tree));
  arg_vector = rtvec_alloc (list_length (((fndecl)->decl.arguments)));

  for (parms = ((fndecl)->decl.arguments), i = 0;
       parms;
       parms = ((parms)->common.chain), i++)
    {
      rtx p = ((parms)->decl.rtl);

      if (((p)->code) == MEM && copy)
 {




   rtx cxx_new = copy_rtx (p);


   if (((parms)->decl.rtl) == ((parms)->decl.saved_insns.r)
       || (((((parms)->decl.rtl))->code) == MEM
    && ((((parms)->decl.saved_insns.r))->code) == MEM
    && (((((parms)->decl.rtl))->fld[0].rtx)
        == ((((parms)->decl.saved_insns.r))->fld[0].rtx))))
     ((parms)->decl.saved_insns.r) = cxx_new;
   ((parms)->decl.rtl) = cxx_new;
 }

      ((arg_vector)->elem[(i)].rtx) = p;

      if (((p)->code) == REG)
 parmdecl_map[((p)->fld[0].rtint)] = parms;
      else if (((p)->code) == CONCAT)
 {
   rtx preal = gen_realpart (((((p)->fld[0].rtx))->mode), p);
   rtx pimag = gen_imagpart (((preal)->mode), p);

   if (((preal)->code) == REG)
     parmdecl_map[((preal)->fld[0].rtint)] = parms;
   if (((pimag)->code) == REG)
     parmdecl_map[((pimag)->fld[0].rtint)] = parms;
 }



      ((parms)->common.readonly_flag) = 1;
    }


  in_nonparm_insns = 0;
  return gen_inline_header_rtx ((rtx) 0, (rtx) 0, min_labelno, max_labelno,
    max_parm_reg, max_reg,
    current_function_args_size,
    current_function_pops_args,
    stack_slot_list, forced_labels, function_flags,
    current_function_outgoing_args_size,
    arg_vector, (rtx) ((fndecl)->decl.initial));
}





static void
finish_inline(tree fndecl, rtx head) asm("_finish_inline");
static void
finish_inline(tree fndecl, rtx head)
{
  ((head)->fld[2].rtx) = get_first_nonparm_insn ();
  ((head)->fld[3].rtx) = get_insns ();
  ((fndecl)->decl.saved_insns.r) = head;
  ((fndecl)->decl.frame_size.i) = get_frame_size ();
}




static void
adjust_copied_decl_tree(register tree block) asm("_adjust_copied_decl_tree");
static void
adjust_copied_decl_tree(register tree block)
{
  register tree subblock;
  register rtx original_end;

  original_end = ((block)->block.end_note);
  if (original_end)
    {
      ((block)->block.end_note) = (rtx) ((original_end)->fld[3].rtstr);
      ((original_end)->fld[3].rtstr) = 0;
    }


  for (subblock = ((block)->block.subblocks);
       subblock;
       subblock = ((subblock)->common.chain))
    adjust_copied_decl_tree (subblock);
}
void
save_for_inline_copying(tree fndecl) asm("_save_for_inline_copying");
void
save_for_inline_copying(tree fndecl)
{
  rtx first_insn, last_insn, insn;
  rtx head, copy;
  int max_labelno, min_labelno, i, len;
  int max_reg;
  int max_uid;
  rtx first_nonparm_insn;




  if (return_label == 0)
    {
      return_label = gen_label_rtx ();
      emit_label (return_label);
    }



  max_labelno = max_label_num ();
  min_labelno = get_first_label_num ();
  max_reg = max_reg_num ();







  max_parm_reg = max_parm_reg_num ();
  parmdecl_map = (tree *) 
                         __builtin_alloca((
                         max_parm_reg * sizeof (tree)
                         ))
                                                              ;

  head = initialize_for_inline (fndecl, min_labelno, max_labelno, max_reg, 1);

  if (current_function_uses_const_pool)
    {


      for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
 if ((rtx_class[(int)(((insn)->code))]) == 'i')
   {
     save_constants (&((insn)->fld[3].rtx));
     if (((insn)->fld[6].rtx))
       save_constants (&((insn)->fld[6].rtx));
   }



      init_const_rtx_hash_table ();
      clear_const_double_mem ();
    }

  max_uid = ((head)->fld[0].rtint);





  preserve_data ();
  insn = get_insns ();
  if (((insn)->code) != NOTE)
    abort ();
  first_insn = rtx_alloc (NOTE);
  ((first_insn)->fld[3].rtstr) = ((insn)->fld[3].rtstr);
  ((first_insn)->fld[4].rtint) = ((insn)->fld[4].rtint);
  ((first_insn)->fld[0].rtint) = ((insn)->fld[0].rtint);
  ((first_insn)->fld[1].rtx) = 
                          ((void *)0)
                              ;
  ((first_insn)->fld[2].rtx) = 
                          ((void *)0)
                              ;
  last_insn = first_insn;





  reg_map = (rtx *) 
                   __builtin_alloca((
                   (max_reg + 1) * sizeof (rtx)
                   ))
                                                        ;

  len = sizeof (struct n64_tag_rtx_def) + ((rtx_length[(int)(REG)]) - 1) * sizeof (rtunion);
  for (i = max_reg - 1; i > (((68)) + 3); i--)
    reg_map[i] = (rtx)__extension__ ({ struct n64_tag_obstack *__h = (function_maybepermanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((len)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((regno_reg_rtx[i])),__len); __o->next_free += __len; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                              ;

  memcpy ((char *) (regno_reg_rtx + (((68)) + 3) + 1),(char *) (reg_map + (((68)) + 3) + 1),(max_reg - ((((68)) + 3) + 1)) * sizeof (rtx))

                                                         ;



  label_map = (rtx *)
                    __builtin_alloca((
                    (max_labelno - min_labelno) * sizeof (rtx)
                    ))
                                                                       ;
  label_map -= min_labelno;

  for (i = min_labelno; i < max_labelno; i++)
    label_map[i] = gen_label_rtx ();



  insn_map = (rtx *) 
                    __builtin_alloca((
                    max_uid * sizeof (rtx)
                    ))
                                                   ;
  memset ((char *) insn_map,0,max_uid * sizeof (rtx));


  first_nonparm_insn = get_first_nonparm_insn ();






  for (i = (((68)) + 3) + 1; i < max_reg; i++)
    if (((regno_reg_rtx[i])->code) == MEM)
      ((regno_reg_rtx[i])->fld[0].rtx)
 = copy_for_inline (((regno_reg_rtx[i])->fld[0].rtx));
  ((fndecl)->decl.initial) = copy_decl_tree (((fndecl)->decl.initial));
  ((fndecl)->decl.arguments) = copy_decl_list (((fndecl)->decl.arguments));



  copy_decl_rtls (((fndecl)->decl.initial));


  ((fndecl)->decl.abstract_origin) = fndecl;





  for (insn = ((insn)->fld[2].rtx); insn; insn = ((insn)->fld[2].rtx))
    {
      orig_asm_operands_vector = 0;

      if (insn == first_nonparm_insn)
 in_nonparm_insns = 1;

      switch (((insn)->code))
 {
 case NOTE:

   if (((insn)->fld[4].rtint) == -1)
     continue;

   copy = rtx_alloc (NOTE);
   ((copy)->fld[4].rtint) = ((insn)->fld[4].rtint);
   if (((insn)->fld[4].rtint) != -3)
     ((copy)->fld[3].rtstr) = ((insn)->fld[3].rtstr);
   else
     {
       ((insn)->fld[3].rtstr) = (char *) copy;
       ((copy)->fld[3].rtstr) = 0;
     }
   break;

 case INSN:
 case JUMP_INSN:
 case CALL_INSN:
   copy = rtx_alloc (((insn)->code));

   if (((insn)->code) == CALL_INSN)
     ((copy)->fld[7].rtx) =
            copy_for_inline (((insn)->fld[7].rtx));

   ((copy)->fld[3].rtx) = copy_for_inline (((insn)->fld[3].rtx));
   ((copy)->fld[4].rtint) = -1;
   ((copy)->fld[5].rtx) = (rtx) 0;
   ((copy)->integrated) = ((insn)->integrated);
   break;

 case CODE_LABEL:
   copy = label_map[((insn)->fld[3].rtint)];
   ((copy)->fld[4].rtstr) = ((insn)->fld[4].rtstr);
   break;

 case BARRIER:
   copy = rtx_alloc (BARRIER);
   break;

 default:
   abort ();
 }
      ((copy)->fld[0].rtint) = ((insn)->fld[0].rtint);
      insn_map[((insn)->fld[0].rtint)] = copy;
      ((last_insn)->fld[2].rtx) = copy;
      ((copy)->fld[1].rtx) = last_insn;
      last_insn = copy;
    }

  adjust_copied_decl_tree (((fndecl)->decl.initial));


  for (insn = ((get_insns ())->fld[2].rtx); insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && insn_map[((insn)->fld[0].rtint)])
      ((insn_map[((insn)->fld[0].rtint)])->fld[6].rtx)
 = copy_for_inline (((insn)->fld[6].rtx));

  ((last_insn)->fld[2].rtx) = 
                         ((void *)0)
                             ;

  finish_inline (fndecl, head);

  set_new_first_and_last_insn (first_insn, last_insn);
}







static tree
copy_decl_list(tree list) asm("_copy_decl_list");
static tree
copy_decl_list(tree list)
{
  tree head;
  register tree prev, next;

  if (list == 0)
    return 0;

  head = prev = copy_node (list);
  if (((head)->decl.abstract_origin) == (tree) 
                                    ((void *)0)
                                             )
    ((head)->decl.abstract_origin) = list;
  next = ((list)->common.chain);
  while (next)
    {
      register tree copy;

      copy = copy_node (next);
      if (((copy)->decl.abstract_origin) == (tree) 
                                        ((void *)0)
                                                 )
 ((copy)->decl.abstract_origin) = next;
      ((prev)->common.chain) = copy;
      prev = copy;
      next = ((next)->common.chain);
    }
  return head;
}



static tree
copy_decl_tree(tree block) asm("_copy_decl_tree");
static tree
copy_decl_tree(tree block)
{
  tree t, vars, subblocks;

  vars = copy_decl_list (((block)->block.vars));
  subblocks = 0;


  for (t = ((block)->block.subblocks); t; t = ((t)->common.chain))
    {
      tree copy = copy_decl_tree (t);
      ((copy)->common.chain) = subblocks;
      subblocks = copy;
    }

  t = copy_node (block);
  ((t)->block.vars) = vars;
  ((t)->block.subblocks) = nreverse (subblocks);



  if (((t)->block.abstract_origin) == (tree) 
                                  ((void *)0)
                                           )
    ((t)->block.abstract_origin) = block;
  return t;
}



static void
copy_decl_rtls(tree block) asm("_copy_decl_rtls");
static void
copy_decl_rtls(tree block)
{
  tree t;

  for (t = ((block)->block.vars); t; t = ((t)->common.chain))
    if (((t)->decl.rtl) && ((((t)->decl.rtl))->code) == MEM)
      ((t)->decl.rtl) = copy_for_inline (((t)->decl.rtl));


  for (t = ((block)->block.subblocks); t; t = ((t)->common.chain))
    copy_decl_rtls (t);
}
void
save_for_inline_nocopy(tree fndecl) asm("_save_for_inline_nocopy");
void
save_for_inline_nocopy(tree fndecl)
{
  rtx insn;
  rtx head;
  rtx first_nonparm_insn;







  max_parm_reg = max_parm_reg_num ();
  parmdecl_map = (tree *) 
                         __builtin_alloca((
                         max_parm_reg * sizeof (tree)
                         ))
                                                              ;



  if (return_label == 0)
    {
      return_label = gen_label_rtx ();
      emit_label (return_label);
    }

  head = initialize_for_inline (fndecl, get_first_label_num (),
    max_label_num (), max_reg_num (), 0);





  insn = get_insns ();
  if (((insn)->code) != NOTE)
    abort ();


  first_nonparm_insn = get_first_nonparm_insn ();
  for (insn = ((insn)->fld[2].rtx); insn; insn = ((insn)->fld[2].rtx))
    {
      if (insn == first_nonparm_insn)
 in_nonparm_insns = 1;

      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   if (current_function_uses_const_pool)
     {



       save_constants (&((insn)->fld[3].rtx));
       if (((insn)->fld[6].rtx))
  save_constants (&((insn)->fld[6].rtx));
     }


   note_stores (((insn)->fld[3].rtx), note_modified_parmregs);
 }
    }





  preserve_data ();

  finish_inline (fndecl, head);
}
static void
save_constants(rtx *px) asm("_save_constants");
static void
save_constants(rtx *px)
{
  rtx x;
  int i, j;

 again:
  x = *px;



  if (((x)->code) == CONST_DOUBLE)
    return;
  else if (((x)->code) == MEM && ((((x)->fld[0].rtx))->code) == SYMBOL_REF
    && ((((x)->fld[0].rtx))->unchanging))
    {
      n64_enum_machine_mode const_mode = get_pool_mode (((x)->fld[0].rtx));
      rtx cxx_new = gen_rtx (CONST, const_mode, get_pool_constant (((x)->fld[0].rtx)));
      ((cxx_new)->integrated) = 1;





      if (((x)->mode) != const_mode)
 {
   cxx_new = gen_rtx (SUBREG, ((x)->mode), cxx_new, 0);
   ((cxx_new)->integrated) = 1;
 }

      *px = cxx_new;
      save_constants (&((*px)->fld[0].rtx));
    }
  else if (((x)->code) == SYMBOL_REF
    && ((x)->unchanging))
    {
      *px = gen_rtx (ADDRESS, get_pool_mode (x), get_pool_constant (x));
      save_constants (&((*px)->fld[0].rtx));
      ((*px)->integrated) = 1;
    }

  else
    {
      char *fmt = (rtx_format[(int)(((x)->code))]);
      int len = (rtx_length[(int)(((x)->code))]);

      for (i = len-1; i >= 0; i--)
 {
   switch (fmt[i])
     {
     case 'E':
       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  save_constants (&((x)->fld[i].rtvec->elem[j].rtx));
       break;

     case 'e':
       if (((x)->fld[i].rtx) == 0)
  continue;
       if (i == 0)
  {

    px = &((x)->fld[0].rtx);
    goto again;
  }
       save_constants (&((x)->fld[i].rtx));
       break;
     }
 }
    }
}



static void
note_modified_parmregs(rtx reg, rtx x) asm("_note_modified_parmregs");
static void
note_modified_parmregs(rtx reg, rtx x)
{
  if (((reg)->code) == REG && in_nonparm_insns
      && ((reg)->fld[0].rtint) < max_parm_reg
      && ((reg)->fld[0].rtint) >= 68
      && parmdecl_map[((reg)->fld[0].rtint)] != 0)
    ((parmdecl_map[((reg)->fld[0].rtint)])->common.readonly_flag) = 0;
}
static rtx
copy_for_inline(rtx orig) asm("_copy_for_inline");
static rtx
copy_for_inline(rtx orig)
{
  register rtx x = orig;
  register int i;
  register n64_enum_rtx_code code;
  register char *format_ptr;

  if (x == 0)
    return x;

  code = ((x)->code);



  switch (code)
    {
    case QUEUED:
    case CONST_INT:
    case SYMBOL_REF:
    case PC:
    case CC0:
      return x;

    case CONST_DOUBLE:


      if ((mode_class[(int)(((x)->mode))]) == MODE_FLOAT)
 {
   double d;

   do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((x))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((x))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
   return immed_real_const_1 (d, ((x)->mode));
 }
      else
 return immed_double_const (((x)->fld[2].rtwint), ((x)->fld[3].rtwint),
       VOIDmode);

    case CONST:

      if (((x)->integrated))
 return validize_mem (force_const_mem (((x)->mode),
           copy_for_inline (((x)->fld[0].rtx))));
      break;

    case SUBREG:

      if (((x)->integrated))
 {
   rtx cxx_new
     = force_const_mem (((((x)->fld[0].rtx))->mode),
          copy_for_inline (((((x)->fld[0].rtx))->fld[0].rtx)));

   ((cxx_new)->mode = (((x)->mode)));
   return validize_mem (cxx_new);
 }
      break;

    case ADDRESS:


      if (! ((x)->integrated))
 abort ();

      return ((force_const_mem (((x)->mode), copy_for_inline (((x)->fld[0].rtx))))->fld[0].rtx)
                                          ;

    case ASM_OPERANDS:



      if (orig_asm_operands_vector == ((orig)->fld[3].rtvec))
 {
   x = rtx_alloc (ASM_OPERANDS);
   x->volatil = orig->volatil;
   ((x)->fld[0].rtstr) = ((orig)->fld[0].rtstr);
   ((x)->fld[1].rtstr) = ((orig)->fld[1].rtstr);
   ((x)->fld[2].rtint) = ((orig)->fld[2].rtint);
   ((x)->fld[3].rtvec) = copy_asm_operands_vector;
   ((x)->fld[4].rtvec) = copy_asm_constraints_vector;
   ((x)->fld[5].rtstr) = ((orig)->fld[5].rtstr);
   ((x)->fld[6].rtint) = ((orig)->fld[6].rtint);
   return x;
 }
      break;

    case MEM:
      if (((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == HIGH || (((((x)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((x)->fld[0].rtx))) && ! 0)) && (!0 || !0))
   && ((((x)->fld[0].rtx))->code) != LABEL_REF
   && ! (((((x)->fld[0].rtx))->code) == CONST
  && (((((((x)->fld[0].rtx))->fld[0].rtx))->code) == PLUS
      && ((((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->code)
   == LABEL_REF)
   || (((((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtx))->code)
       == ADDRESS)))))
 return x;
      break;

    case LABEL_REF:


      x = gen_rtx (LABEL_REF, ((orig)->mode),
     ((orig)->volatil) ? ((orig)->fld[0].rtx)
     : label_map[((((orig)->fld[0].rtx))->fld[3].rtint)]);
      ((x)->volatil) = ((orig)->volatil);
      ((x)->in_struct) = ((orig)->in_struct);
      return x;

    case REG:
      if (((x)->fld[0].rtint) > (((68)) + 3))
 return reg_map [((x)->fld[0].rtint)];
      else
 return x;

    case SET:


      {
 rtx dest = ((x)->fld[0].rtx);

 while (((dest)->code) == STRICT_LOW_PART
        || ((dest)->code) == ZERO_EXTRACT
        || ((dest)->code) == SUBREG)
   dest = ((dest)->fld[0].rtx);

 if (((dest)->code) == REG
     && ((dest)->fld[0].rtint) < max_parm_reg
     && ((dest)->fld[0].rtint) >= 68
     && parmdecl_map[((dest)->fld[0].rtint)] != 0


     && in_nonparm_insns)
   ((parmdecl_map[((dest)->fld[0].rtint)])->common.readonly_flag) = 0;
      }
      break;
    }



  x = rtx_alloc (code);
  memcpy ((char *) x,(char *) orig,(sizeof (*x) - sizeof (x->fld) + sizeof (x->fld[0]) * (rtx_length[(int)(code)])))

                                                 ;






  format_ptr = (rtx_format[(int)(code)]);

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   ((x)->fld[i].rtx) = copy_for_inline (((x)->fld[i].rtx));
   break;

 case 'u':


   ((x)->fld[i].rtx) = insn_map[((((x)->fld[i].rtx))->fld[0].rtint)];
   break;

 case 'E':
   if (((x)->fld[i].rtvec) != 
                     ((void *)0) 
                          && ((x)->fld[i].rtvec->num_elem) != 0)
     {
       register int j;

       ((x)->fld[i].rtvec) = gen_rtvec_v (((x)->fld[i].rtvec->num_elem), &((x)->fld[i].rtvec->elem[0].rtx));
       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  ((x)->fld[i].rtvec->elem[j].rtx)
    = copy_for_inline (((x)->fld[i].rtvec->elem[j].rtx));
     }
   break;
 }
    }

  if (code == ASM_OPERANDS && orig_asm_operands_vector == 0)
    {
      orig_asm_operands_vector = ((orig)->fld[3].rtvec);
      copy_asm_operands_vector = ((x)->fld[3].rtvec);
      copy_asm_constraints_vector = ((x)->fld[4].rtvec);
    }

  return x;
}





rtx *global_const_equiv_map;
int global_const_equiv_map_size;
rtx
expand_inline_function(tree fndecl, tree parms, rtx target, int ignore, tree type, rtx structure_value_addr) asm("_expand_inline_function");
rtx
expand_inline_function(tree fndecl, tree parms, rtx target, int ignore, tree type, rtx structure_value_addr)
{
  tree formal, actual, block;
  rtx header = ((fndecl)->decl.saved_insns.r);
  rtx insns = ((header)->fld[2].rtx);
  rtx parm_insns = ((header)->fld[3].rtx);
  tree *arg_trees;
  rtx *arg_vals;
  rtx insn;
  int max_regno;
  register int i;
  int min_labelno = ((header)->fld[4].rtint);
  int max_labelno = ((header)->fld[5].rtint);
  int nargs;
  rtx local_return_label = 0;
  rtx loc;
  rtx stack_save = 0;
  rtx temp;
  struct n64_tag_inline_remap *map;
  rtx cc0_insn = 0;
  rtvec arg_vector = ((header)->fld[14].rtvec);
  rtx static_chain_value = 0;


  max_regno = ((header)->fld[7].rtint) + 3;
  if (max_regno < 68)
    abort ();

  nargs = list_length (((fndecl)->decl.arguments));





  for (formal = ((fndecl)->decl.arguments),
       actual = parms;
       formal;
       formal = ((formal)->common.chain),
       actual = ((actual)->common.chain))
    {
      tree arg;
      n64_enum_machine_mode mode;

      if (actual == 0)
 return (rtx) (int) -1;

      arg = ((actual)->list.value);
      mode= ((((formal)->decl.initial))->type.mode);

      if (mode != ((((arg)->common.type))->type.mode)



   || (mode == BLKmode && ((arg)->common.type) != ((formal)->common.type)))
 return (rtx) (int) -1;
    }



  for (; actual; actual = ((actual)->common.chain))
    expand_expr (((actual)->list.value), const0_rtx,
   ((((((actual)->list.value))->common.type))->type.mode), 0);




  pushlevel (0);


  pushlevel (0);
  expand_start_bindings (0);




  arg_vals = (rtx *) 
                    __builtin_alloca((
                    nargs * sizeof (rtx)
                    ))
                                                 ;
  arg_trees = (tree *) 
                      __builtin_alloca((
                      nargs * sizeof (tree)
                      ))
                                                    ;

  for (formal = ((fndecl)->decl.arguments), actual = parms, i = 0;
       formal;
       formal = ((formal)->common.chain), actual = ((actual)->common.chain), i++)
    {


      tree arg = convert (((formal)->common.type), ((actual)->list.value));

      n64_enum_machine_mode mode = ((((formal)->common.type))->type.mode);
      int invisiref = 0;

      arg_trees[i] = arg;
      loc = ((arg_vector)->elem[(i)].rtx);





      if (((loc)->code) == MEM && ((((loc)->fld[0].rtx))->code) == REG
   && ((((loc)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3))
 {
   rtx stack_slot
     = assign_stack_temp (((((arg)->common.type))->type.mode),
     int_size_in_bytes (((arg)->common.type)), 1);
   ((stack_slot)->in_struct) = (((n64_enum_tree_code) (((arg)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == SET_TYPE);

   store_expr (arg, stack_slot, 0);

   arg_vals[i] = ((stack_slot)->fld[0].rtx);
   invisiref = 1;
 }
      else if (((loc)->code) != MEM)
 {
   if (((loc)->mode) != ((((arg)->common.type))->type.mode))


     arg_vals[i] = convert_modes (((loc)->mode),
      ((((arg)->common.type))->type.mode),
      expand_expr (arg, (rtx) 0, mode,
            EXPAND_SUM),
      ((((formal)->common.type))->common.unsigned_flag));
   else
     arg_vals[i] = expand_expr (arg, (rtx) 0, mode, EXPAND_SUM);
 }
      else
 arg_vals[i] = 0;

      if (arg_vals[i] != 0
   && (! ((formal)->common.readonly_flag)
       || (target != 0
    && ! invisiref
    && (((arg_vals[i])->code) == REG
        || ((arg_vals[i])->code) == SUBREG
        || ((arg_vals[i])->code) == MEM)
    && reg_overlap_mentioned_p (arg_vals[i], target))



       || (((arg_vals[i])->code) == SUBREG)))
 arg_vals[i] = copy_to_mode_reg (((loc)->mode), arg_vals[i]);
    }



  map = (struct n64_tag_inline_remap *) 
                               __builtin_alloca((
                               sizeof (struct n64_tag_inline_remap)
                               ))
                                                                    ;
  map->fndecl = fndecl;

  map->reg_map = (rtx *) 
                        __builtin_alloca((
                        max_regno * sizeof (rtx)
                        ))
                                                         ;
  memset ((char *) map->reg_map,0,max_regno * sizeof (rtx));

  map->label_map = (rtx *)
                         __builtin_alloca((
                         (max_labelno - min_labelno) * sizeof (rtx)
                         ))
                                                                            ;
  map->label_map -= min_labelno;

  map->insn_map = (rtx *) 
                         __builtin_alloca((
                         ((header)->fld[0].rtint) * sizeof (rtx)
                         ))
                                                                  ;
  memset ((char *) map->insn_map,0,((header)->fld[0].rtint) * sizeof (rtx));
  map->min_insnno = 0;
  map->max_insnno = ((header)->fld[0].rtint);

  map->integrating = 1;
  map->const_equiv_map_size
    = max_reg_num () + (max_regno - 68) + 15 * nargs + 10;

  map->const_equiv_map
    = (rtx *)
            __builtin_alloca((
            map->const_equiv_map_size * sizeof (rtx)
            ))
                                                             ;
  memset ((char *) map->const_equiv_map,0,map->const_equiv_map_size * sizeof (rtx))
                                           ;

  map->const_age_map
    = (unsigned *)
                 __builtin_alloca((
                 map->const_equiv_map_size * sizeof (unsigned)
                 ))
                                                                       ;
  memset ((char *) map->const_age_map,0,map->const_equiv_map_size * sizeof (unsigned))
                                                ;
  map->const_age = 0;



  map->insns_at_start = get_last_insn ();



  if (((header)->fld[13].rtint) > current_function_outgoing_args_size)
    current_function_outgoing_args_size = ((header)->fld[13].rtint);



  if (((header)->fld[12].rtint) & 01000)
    current_function_uses_pic_offset_table = 1;


  if (((header)->fld[12].rtint) & 020)
    static_chain_value = lookup_static_chain (fndecl);

  if (((parm_insns)->code) == NOTE
      && ((parm_insns)->fld[4].rtint) > 0)
    {
      rtx note = emit_note (((parm_insns)->fld[3].rtstr),
       ((parm_insns)->fld[4].rtint));
      if (note)
 ((note)->integrated) = 1;
    }
  for (i = 0; i < nargs; i++)
    {
      rtx copy = arg_vals[i];

      loc = ((arg_vector)->elem[(i)].rtx);


      if (((loc)->code) == MEM && ((((loc)->fld[0].rtx))->code) == REG
   && ((((loc)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3))
 {







   if (((copy)->code) != REG)
     {
       temp = copy_addr_to_reg (copy);
       if (((((copy)->code) == LABEL_REF || ((copy)->code) == SYMBOL_REF || ((copy)->code) == CONST_INT || ((copy)->code) == CONST_DOUBLE || ((copy)->code) == CONST || ((copy)->code) == HIGH) || (((copy)->code) == PLUS && ((((copy)->fld[1].rtx))->code) == CONST_INT && ((((copy)->fld[0].rtx))->code) == REG && ((((copy)->fld[0].rtx))->fld[0].rtint) >= (68) && ((((copy)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3)))
    && ((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = copy;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }
       copy = temp;
     }
   map->reg_map[((((loc)->fld[0].rtx))->fld[0].rtint)] = copy;
 }
      else if (((loc)->code) == MEM)
 {




   ;
 }
      else if (((loc)->code) == REG)
 {
   if ((((copy)->code) != REG && ((copy)->code) != SUBREG)
       || (((copy)->code) == REG && ((loc)->volatil)
    && ! ((copy)->volatil))
       || (((copy)->code) == REG
    && ((copy)->fld[0].rtint) < 68))
     {
       temp = copy_to_mode_reg (((loc)->mode), copy);
       ((temp)->volatil) = ((loc)->volatil);
       if (((((copy)->code) == LABEL_REF || ((copy)->code) == SYMBOL_REF || ((copy)->code) == CONST_INT || ((copy)->code) == CONST_DOUBLE || ((copy)->code) == CONST || ((copy)->code) == HIGH) || (((copy)->code) == PLUS && ((((copy)->fld[1].rtx))->code) == CONST_INT && ((((copy)->fld[0].rtx))->code) == REG && ((((copy)->fld[0].rtx))->fld[0].rtint) >= (68) && ((((copy)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3)))
    && ((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = copy;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }
       copy = temp;
     }
   map->reg_map[((loc)->fld[0].rtint)] = copy;
 }
      else if (((loc)->code) == CONCAT)
 {
   rtx locreal = gen_realpart (((((loc)->fld[0].rtx))->mode), loc);
   rtx locimag = gen_imagpart (((((loc)->fld[0].rtx))->mode), loc);
   rtx copyreal = gen_realpart (((locreal)->mode), copy);
   rtx copyimag = gen_imagpart (((locimag)->mode), copy);

   if ((((copyreal)->code) != REG && ((copyreal)->code) != SUBREG)
       || (((copyreal)->code) == REG && ((locreal)->volatil)
    && ! ((copyreal)->volatil))
       || (((copyreal)->code) == REG
    && ((copyreal)->fld[0].rtint) < 68))
     {
       temp = copy_to_mode_reg (((locreal)->mode), copyreal);
       ((temp)->volatil) = ((locreal)->volatil);
       if (((((copyreal)->code) == LABEL_REF || ((copyreal)->code) == SYMBOL_REF || ((copyreal)->code) == CONST_INT || ((copyreal)->code) == CONST_DOUBLE || ((copyreal)->code) == CONST || ((copyreal)->code) == HIGH) || (((copyreal)->code) == PLUS && ((((copyreal)->fld[1].rtx))->code) == CONST_INT && ((((copyreal)->fld[0].rtx))->code) == REG && ((((copyreal)->fld[0].rtx))->fld[0].rtint) >= (68) && ((((copyreal)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3)))
    && ((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = copyreal;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }
       copyreal = temp;
     }
   map->reg_map[((locreal)->fld[0].rtint)] = copyreal;

   if ((((copyimag)->code) != REG && ((copyimag)->code) != SUBREG)
       || (((copyimag)->code) == REG && ((locimag)->volatil)
    && ! ((copyimag)->volatil))
       || (((copyimag)->code) == REG
    && ((copyimag)->fld[0].rtint) < 68))
     {
       temp = copy_to_mode_reg (((locimag)->mode), copyimag);
       ((temp)->volatil) = ((locimag)->volatil);
       if (((((copyimag)->code) == LABEL_REF || ((copyimag)->code) == SYMBOL_REF || ((copyimag)->code) == CONST_INT || ((copyimag)->code) == CONST_DOUBLE || ((copyimag)->code) == CONST || ((copyimag)->code) == HIGH) || (((copyimag)->code) == PLUS && ((((copyimag)->fld[1].rtx))->code) == CONST_INT && ((((copyimag)->fld[0].rtx))->code) == REG && ((((copyimag)->fld[0].rtx))->fld[0].rtint) >= (68) && ((((copyimag)->fld[0].rtx))->fld[0].rtint) <= (((68)) + 3)))
    && ((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = copyimag;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }
       copyimag = temp;
     }
   map->reg_map[((locimag)->fld[0].rtint)] = copyimag;
 }
      else
 abort ();
    }



  for (formal = ((fndecl)->decl.arguments), i = 0;
       formal; formal = ((formal)->common.chain), i++)
    {
      loc = ((arg_vector)->elem[(i)].rtx);

      if (((loc)->code) == MEM

   && ! (((((loc)->fld[0].rtx))->code) == REG
  && ((((loc)->fld[0].rtx))->fld[0].rtint) > (((68)) + 3)))
 {
   rtx note = emit_note (((formal)->decl.filename),
    ((formal)->decl.linenum));
   if (note)
     ((note)->integrated) = 1;



   temp = copy_rtx_and_substitute (loc, map);
   subst_constants (&temp, (rtx) 0, map);
   apply_change_group ();
   if (! memory_address_p (((temp)->mode), ((temp)->fld[0].rtx)))
     temp = change_address (temp, VOIDmode, ((temp)->fld[0].rtx));
   store_expr (arg_trees[i], temp, 0);
 }
    }







  map->inline_target = 0;
  loc = ((((fndecl)->decl.result))->decl.rtl);
  if (((type)->type.mode) == VOIDmode)

    ;
  else if (((loc)->code) == MEM)
    {
      if (! structure_value_addr || ! aggregate_value_p (((fndecl)->decl.result)))
 abort ();
      if (((((loc)->fld[0].rtx))->code) == REG)
 {
   temp = force_reg (((target_flags & 0x00000002) ? DImode : SImode), structure_value_addr);
   map->reg_map[((((loc)->fld[0].rtx))->fld[0].rtint)] = temp;
   if (((((structure_value_addr)->code) == LABEL_REF || ((structure_value_addr)->code) == SYMBOL_REF || ((structure_value_addr)->code) == CONST_INT || ((structure_value_addr)->code) == CONST_DOUBLE || ((structure_value_addr)->code) == CONST || ((structure_value_addr)->code) == HIGH)
        || (((structure_value_addr)->code) == PLUS
     && ((structure_value_addr)->fld[0].rtx) == virtual_stack_vars_rtx
     && ((((structure_value_addr)->fld[1].rtx))->code) == CONST_INT))
       && ((temp)->fld[0].rtint) < map->const_equiv_map_size)
     {
       map->const_equiv_map[((temp)->fld[0].rtint)] = structure_value_addr;
       map->const_age_map[((temp)->fld[0].rtint)] = (-1);
     }
 }
      else
 {
   temp = copy_rtx_and_substitute (loc, map);
   subst_constants (&temp, (rtx) 0, map);
   apply_change_group ();
   emit_move_insn (temp, structure_value_addr);
 }
    }
  else if (ignore)



    ;
  else if (((loc)->code) == REG)
    {




      n64_enum_machine_mode departing_mode = ((type)->type.mode);


      n64_enum_machine_mode arriving_mode
 = ((((((fndecl)->decl.result))->common.type))->type.mode);
      rtx reg_to_map;




      if (target == 0 || ((target)->code) != REG
   || ((target)->mode) != departing_mode)
 target = gen_reg_rtx (departing_mode);




      if (arriving_mode != departing_mode)
 reg_to_map = gen_rtx (SUBREG, arriving_mode, target, 0);
      else
 reg_to_map = target;



      if (((loc)->integrated))
 map->inline_target = reg_to_map;
      else
 map->reg_map[((loc)->fld[0].rtint)] = reg_to_map;
    }


  for (i = min_labelno; i < max_labelno; i++)
    map->label_map[i] = gen_label_rtx ();


  emit_queue ();


  do_pending_stack_adjust ();



  global_const_equiv_map = map->const_equiv_map;
  global_const_equiv_map_size = map->const_equiv_map_size;





  if (((header)->fld[12].rtint) & 01)
    emit_stack_save (SAVE_BLOCK, &stack_save, (rtx) 0);






  for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
    {
      rtx copy, pattern, set;

      map->orig_asm_operands_vector = 0;

      switch (((insn)->code))
 {
 case INSN:
   pattern = ((insn)->fld[3].rtx);
   set = single_set (insn);
   copy = 0;
   if (((pattern)->code) == USE
       && ((((pattern)->fld[0].rtx))->code) == REG
       && ((((pattern)->fld[0].rtx))->integrated))



     break;


   if (map->inline_target == 0
       && set != 0
       && ((((set)->fld[0].rtx))->code) == REG
       && ((((set)->fld[0].rtx))->integrated))
     {
       if (volatile_refs_p (((set)->fld[1].rtx)))
  {
    rtx new_set;



    copy = emit_insn (copy_rtx_and_substitute (pattern, map));

    new_set = single_set (copy);
    if (new_set == 0)
      abort ();

    ((new_set)->fld[0].rtx)
      = gen_reg_rtx (((((new_set)->fld[0].rtx))->mode));
  }


       else if (rtx_equal_p (((set)->fld[0].rtx), ((set)->fld[1].rtx))
         && ((insn)->fld[6].rtx) != 0)
  copy = emit_insn (copy_rtx_and_substitute (pattern, map));
       else
  break;
     }


   else if (static_chain_value != 0
     && set != 0
     && ((((set)->fld[0].rtx))->code) == REG
     && rtx_equal_p (((set)->fld[0].rtx),
       static_chain_incoming_rtx))
     break;



   else if (static_chain_value != 0
     && set != 0
     && rtx_equal_p (((set)->fld[1].rtx),
       static_chain_incoming_rtx))
     {
       rtx newdest = copy_rtx_and_substitute (((set)->fld[0].rtx), map);

       copy = emit_move_insn (newdest, static_chain_value);
       static_chain_value = 0;
     }
   else
     copy = emit_insn (copy_rtx_and_substitute (pattern, map));
   try_constants (copy, map);

   break;

 case JUMP_INSN:
   if (((((insn)->fld[3].rtx))->code) == RETURN)
     {
       if (local_return_label == 0)
  local_return_label = gen_label_rtx ();
       pattern = gen_jump (local_return_label);
     }
   else
     pattern = copy_rtx_and_substitute (((insn)->fld[3].rtx), map);

   copy = emit_jump_insn (pattern);






   try_constants (copy, map);



   if (condjump_p (insn) && ! simplejump_p (insn) && map->last_pc_value)
     {






       if (map->last_pc_value == pc_rtx)
  {
    delete_insn (copy);
    copy = 0;
  }
       else



  emit_barrier ();
     }
   break;

 case CALL_INSN:
   pattern = copy_rtx_and_substitute (((insn)->fld[3].rtx), map);
   copy = emit_call_insn (pattern);



   ((copy)->fld[7].rtx) =
      copy_rtx_and_substitute (((insn)->fld[7].rtx), map);






   try_constants (copy, map);


   for (i = 0; i < 68; i++)
     map->const_equiv_map[i] = 0;
   break;

 case CODE_LABEL:
   copy = emit_label (map->label_map[((insn)->fld[3].rtint)]);
   ((copy)->fld[4].rtstr) = ((insn)->fld[4].rtstr);
   map->const_age++;
   break;

 case BARRIER:
   copy = emit_barrier ();
   break;

 case NOTE:





   if (((insn)->fld[4].rtint) != -6
       && ((insn)->fld[4].rtint) != -13
       && ((insn)->fld[4].rtint) != -1)
     copy = emit_note (((insn)->fld[3].rtstr), ((insn)->fld[4].rtint));
   else
     copy = 0;
   break;

 default:
   abort ();
   break;
 }

      if (copy)
 ((copy)->integrated) = 1;

      map->insn_map[((insn)->fld[0].rtint)] = copy;
    }




  map->const_age++;
  for (insn = insns; insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && map->insn_map[((insn)->fld[0].rtint)]
 && ((insn)->fld[6].rtx))
      {
 rtx tem = copy_rtx_and_substitute (((insn)->fld[6].rtx), map);


 subst_constants (&tem, (rtx) 0, map);
 apply_change_group ();
 ((map->insn_map[((insn)->fld[0].rtint)])->fld[6].rtx) = tem;
      }

  if (local_return_label)
    emit_label (local_return_label);


  if (((header)->fld[12].rtint) & 01)
    emit_stack_restore (SAVE_BLOCK, stack_save, (rtx) 0);






  inline_function_decl = fndecl;
  integrate_parm_decls (((fndecl)->decl.arguments), map, arg_vector);
  integrate_decl_tree ((tree) ((header)->fld[15].rtx), 0, map);
  inline_function_decl = 0;




  expand_end_bindings (getdecls (), 1, 1);
  block = poplevel (1, 1, 0);
  ((block)->block.abstract_origin) = (((fndecl)->decl.abstract_origin) == 
                                                                   ((void *)0)
       
      ? fndecl : ((fndecl)->decl.abstract_origin));
  poplevel (0, 0, 0);
  emit_line_note (input_filename, lineno);

  if (structure_value_addr)
    {
      target = gen_rtx (MEM, ((type)->type.mode),
   memory_address (((type)->type.mode), structure_value_addr));
      ((target)->in_struct) = 1;
    }
  return target;
}




static void
integrate_parm_decls(tree args, struct n64_tag_inline_remap *map, rtvec arg_vector) asm("_integrate_parm_decls");
static void
integrate_parm_decls(tree args, struct n64_tag_inline_remap *map, rtvec arg_vector)
{
  register tree tail;
  register int i;

  for (tail = args, i = 0; tail; tail = ((tail)->common.chain), i++)
    {
      register tree decl = build_decl (VAR_DECL, ((tail)->decl.name),
           ((tail)->common.type));
      rtx new_decl_rtl
 = copy_rtx_and_substitute (((arg_vector)->elem[(i)].rtx), map);

      ((decl)->decl.initial) = ((tail)->decl.initial);




      ((decl)->common.used_flag) = 1;

      ((decl)->decl.abstract_origin) = tail;
      pushdecl (decl);




      subst_constants (&new_decl_rtl, (rtx) 0, map);
      apply_change_group ();
      ((decl)->decl.rtl) = new_decl_rtl;
    }
}
static void
integrate_decl_tree(tree let, int level, struct n64_tag_inline_remap *map) asm("_integrate_decl_tree");
static void
integrate_decl_tree(tree let, int level, struct n64_tag_inline_remap *map)
{
  tree t, node;

  if (level > 0)
    pushlevel (0);

  for (t = ((let)->block.vars); t; t = ((t)->common.chain))
    {
      tree d;
      tree newd;

      push_obstacks_nochange ();
      saveable_allocation ();
      d = copy_node (t);
      pop_obstacks ();

      if (((t)->decl.rtl) != 0)
 {
   ((d)->decl.rtl) = copy_rtx_and_substitute (((t)->decl.rtl), map);




   subst_constants (&((d)->decl.rtl), (rtx) 0, map);
   apply_change_group ();
 }

      ((d)->common.used_flag) = 1;

      if (((d)->decl.lang_specific))
 copy_lang_decl (d);





      if (! ((d)->decl.external_flag) || ! ((d)->common.public_flag))

 ((d)->decl.abstract_origin) = t;

      newd = pushdecl (d);







      if (newd == d)
 ((d)->decl.abstract_origin) = t;
    }

  for (t = ((let)->block.subblocks); t; t = ((t)->common.chain))
    integrate_decl_tree (t, level + 1, map);

  if (level > 0)
    {
      node = poplevel (1, 0, 0);
      if (node)
 {
   ((node)->common.used_flag) = ((let)->common.used_flag);
   ((node)->block.abstract_origin) = let;
 }
    }
}
rtx
copy_rtx_and_substitute(register rtx orig, struct n64_tag_inline_remap *map) asm("_copy_rtx_and_substitute");
rtx
copy_rtx_and_substitute(register rtx orig, struct n64_tag_inline_remap *map)
{
  register rtx copy, temp;
  register int i, j;
  register n64_enum_rtx_code code;
  register n64_enum_machine_mode mode;
  register char *format_ptr;
  int regno;

  if (orig == 0)
    return 0;

  code = ((orig)->code);
  mode = ((orig)->mode);

  switch (code)
    {
    case REG:




      regno = ((orig)->fld[0].rtint);
      if (regno <= (((68)) + 3))
 {


   if (map->reg_map[regno] != 0)
     return map->reg_map[regno];
   if (regno == (((68)) + 1))
     {
       rtx loc, seq;
       int size = ((map->fndecl)->decl.frame_size.i);
       int rounded;

       start_sequence ();
       loc = assign_stack_temp (BLKmode, size, 1);
       loc = ((loc)->fld[0].rtx);
       map->reg_map[regno] = temp
  = force_reg (((target_flags & 0x00000002) ? DImode : SImode), force_operand (loc, (rtx) 0));

       if (((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = loc;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }

       seq = gen_sequence ();
       end_sequence ();
       emit_insn_after (seq, map->insns_at_start);
       return temp;
     }
   else if (regno == ((68)))
     {


       rtx loc, seq;
       int size = ((((map->fndecl)->decl.saved_insns.r))->fld[8].rtint);

       start_sequence ();
       loc = assign_stack_temp (BLKmode, size, 1);
       loc = ((loc)->fld[0].rtx);






       map->reg_map[regno] = temp
  = force_reg (((target_flags & 0x00000002) ? DImode : SImode), force_operand (loc, (rtx) 0));

       if (((temp)->fld[0].rtint) < map->const_equiv_map_size)
  {
    map->const_equiv_map[((temp)->fld[0].rtint)] = loc;
    map->const_age_map[((temp)->fld[0].rtint)] = (-1);
  }

       seq = gen_sequence ();
       end_sequence ();
       emit_insn_after (seq, map->insns_at_start);
       return temp;
     }
   else if (((orig)->integrated))
     {



       if (map->inline_target == 0)


  return orig;
       else if (mode != ((map->inline_target)->mode))
  return gen_lowpart (mode, map->inline_target);
       else
  return map->inline_target;
     }
   return orig;
 }
      if (map->reg_map[regno] == 
                                ((void *)0)
                                    )
 {
   map->reg_map[regno] = gen_reg_rtx (mode);
   ((map->reg_map[regno])->volatil) = ((orig)->volatil);
   ((map->reg_map[regno])->in_struct) = ((orig)->in_struct);
   ((map->reg_map[regno])->unchanging) = ((orig)->unchanging);

 }
      return map->reg_map[regno];

    case SUBREG:
      copy = copy_rtx_and_substitute (((orig)->fld[0].rtx), map);

      if (((copy)->code) == SUBREG)
 return gen_rtx (SUBREG, ((orig)->mode), ((copy)->fld[0].rtx),
   ((orig)->fld[1].rtint) + ((copy)->fld[1].rtint));
      else if (((copy)->code) == CONCAT)
 return (subreg_realpart_p (orig) ? ((copy)->fld[0].rtx) : ((copy)->fld[1].rtx));
      else
 return gen_rtx (SUBREG, ((orig)->mode), copy,
   ((orig)->fld[1].rtint));

    case USE:
    case CLOBBER:




      copy = copy_rtx_and_substitute (((orig)->fld[0].rtx), map);
      if (((copy)->code) == SUBREG && ((((orig)->fld[0].rtx))->code) != SUBREG)
 copy = ((copy)->fld[0].rtx);
      return gen_rtx (code, VOIDmode, copy);

    case CODE_LABEL:
      ((map->label_map[((orig)->fld[3].rtint)])->in_struct)
 = ((orig)->in_struct);
      return map->label_map[((orig)->fld[3].rtint)];

    case LABEL_REF:
      copy = gen_rtx (LABEL_REF, mode,
        ((orig)->volatil) ? ((orig)->fld[0].rtx)
        : map->label_map[((((orig)->fld[0].rtx))->fld[3].rtint)]);
      ((copy)->in_struct) = ((orig)->in_struct);




      ((copy)->volatil)
 = (((orig)->volatil)
    && ! (((((copy)->fld[0].rtx))->fld[3].rtint) >= get_first_label_num ()
   && ((((copy)->fld[0].rtx))->fld[3].rtint) < max_label_num ()));





      if (((orig)->volatil) && ! ((copy)->volatil))
 function_call_count++;

      return copy;

    case PC:
    case CC0:
    case CONST_INT:
      return orig;

    case SYMBOL_REF:



      if (((orig)->unchanging))
 {
   rtx constant = get_pool_constant (orig);
   if (((constant)->code) == LABEL_REF)
     return ((force_const_mem (((target_flags & 0x00000002) ? DImode : SImode), copy_rtx_and_substitute (constant, map)))->fld[0].rtx)


      ;
 }

      return orig;

    case CONST_DOUBLE:



      if ((mode_class[(int)(((orig)->mode))]) == MODE_FLOAT)
 {
   double d;

   do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((orig))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((orig))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
   return immed_real_const_1 (d, ((orig)->mode));
 }
      else
 return immed_double_const (((orig)->fld[2].rtwint),
       ((orig)->fld[3].rtwint), VOIDmode);

    case CONST:


      if (((orig)->integrated))
 {






   temp = copy_rtx_and_substitute (((orig)->fld[0].rtx), map);
   if (! (((temp)->code) == LABEL_REF || ((temp)->code) == SYMBOL_REF || ((temp)->code) == CONST_INT || ((temp)->code) == CONST_DOUBLE || ((temp)->code) == CONST || ((temp)->code) == HIGH))
     return temp;
   return validize_mem (force_const_mem (((orig)->mode), temp));
 }
      break;

    case ADDRESS:


      if (! ((orig)->integrated))
 abort ();

      temp = force_const_mem (((orig)->mode),
         copy_rtx_and_substitute (((orig)->fld[0].rtx), map));
      return ((temp)->fld[0].rtx);

    case ASM_OPERANDS:



      if (map->orig_asm_operands_vector == ((orig)->fld[3].rtvec))
 {
   copy = rtx_alloc (ASM_OPERANDS);
   copy->volatil = orig->volatil;
   ((copy)->fld[0].rtstr) = ((orig)->fld[0].rtstr);
   ((copy)->fld[1].rtstr) = ((orig)->fld[1].rtstr);
   ((copy)->fld[2].rtint) = ((orig)->fld[2].rtint);
   ((copy)->fld[3].rtvec) = map->copy_asm_operands_vector;
   ((copy)->fld[4].rtvec) = map->copy_asm_constraints_vector;
   ((copy)->fld[5].rtstr) = ((orig)->fld[5].rtstr);
   ((copy)->fld[6].rtint) = ((orig)->fld[6].rtint);
   return copy;
 }
      break;

    case CALL:







 return gen_rtx (CALL, ((orig)->mode),
   gen_rtx (MEM, ((((orig)->fld[0].rtx))->mode),
     copy_rtx_and_substitute (((((orig)->fld[0].rtx))->fld[0].rtx), map)),
   copy_rtx_and_substitute (((orig)->fld[1].rtx), map));
      break;







    case SET:




      if (((orig)->fld[0].rtx) == virtual_stack_vars_rtx
   || ((orig)->fld[0].rtx) == virtual_incoming_args_rtx)
 return gen_rtx (SET, VOIDmode, ((orig)->fld[0].rtx),
   copy_rtx_and_substitute (((orig)->fld[1].rtx), map));
      break;

    case MEM:
      copy = rtx_alloc (MEM);
      ((copy)->mode = (mode));
      ((copy)->fld[0].rtx) = copy_rtx_and_substitute (((orig)->fld[0].rtx), map);
      ((copy)->in_struct) = ((orig)->in_struct);
      ((copy)->volatil) = ((orig)->volatil);






      if (! map->integrating)
 ((copy)->unchanging) = ((orig)->unchanging);

      return copy;
    }

  copy = rtx_alloc (code);
  ((copy)->mode = (mode));
  copy->in_struct = orig->in_struct;
  copy->volatil = orig->volatil;
  copy->unchanging = orig->unchanging;

  format_ptr = (rtx_format[(int)(((copy)->code))]);

  for (i = 0; i < (rtx_length[(int)(((copy)->code))]); i++)
    {
      switch (*format_ptr++)
 {
 case '0':
   break;

 case 'e':
   ((copy)->fld[i].rtx) = copy_rtx_and_substitute (((orig)->fld[i].rtx), map);
   break;

 case 'u':


   ((copy)->fld[i].rtx) = map->insn_map[((((orig)->fld[i].rtx))->fld[0].rtint)];
   break;

 case 'E':
   ((copy)->fld[i].rtvec) = ((orig)->fld[i].rtvec);
   if (((orig)->fld[i].rtvec) != 
                        ((void *)0) 
                             && ((orig)->fld[i].rtvec->num_elem) != 0)
     {
       ((copy)->fld[i].rtvec) = rtvec_alloc (((orig)->fld[i].rtvec->num_elem));
       for (j = 0; j < ((copy)->fld[i].rtvec->num_elem); j++)
  ((copy)->fld[i].rtvec->elem[j].rtx)
    = copy_rtx_and_substitute (((orig)->fld[i].rtvec->elem[j].rtx), map);
     }
   break;

 case 'w':
   ((copy)->fld[i].rtwint) = ((orig)->fld[i].rtwint);
   break;

 case 'i':
   ((copy)->fld[i].rtint) = ((orig)->fld[i].rtint);
   break;

 case 's':
   ((copy)->fld[i].rtstr) = ((orig)->fld[i].rtstr);
   break;

 default:
   abort ();
 }
    }

  if (code == ASM_OPERANDS && map->orig_asm_operands_vector == 0)
    {
      map->orig_asm_operands_vector = ((orig)->fld[3].rtvec);
      map->copy_asm_operands_vector = ((copy)->fld[3].rtvec);
      map->copy_asm_constraints_vector = ((copy)->fld[4].rtvec);
    }

  return copy;
}



void
try_constants(rtx insn, struct n64_tag_inline_remap *map) asm("_try_constants");
void
try_constants(rtx insn, struct n64_tag_inline_remap *map)
{
  int i;

  map->num_sets = 0;
  subst_constants (&((insn)->fld[3].rtx), insn, map);


  apply_change_group ();


  note_stores (((insn)->fld[3].rtx), mark_stores);
  map->last_pc_value = 0;





  for (i = 0; i < map->num_sets; i++)
    {
      if (((map->equiv_sets[i].dest)->code) == REG)
 {
   int regno = ((map->equiv_sets[i].dest)->fld[0].rtint);

   if (regno < map->const_equiv_map_size
       && (map->const_equiv_map[regno] == 0


    || ! rtx_equal_p (map->const_equiv_map[regno],
        map->equiv_sets[i].equiv)))
     {
       map->const_equiv_map[regno] = map->equiv_sets[i].equiv;
       map->const_age_map[regno] = map->const_age;
     }
 }
      else if (map->equiv_sets[i].dest == pc_rtx)
 map->last_pc_value = map->equiv_sets[i].equiv;




    }
}
static void
subst_constants(rtx *loc, rtx insn, struct n64_tag_inline_remap *map) asm("_subst_constants");
static void
subst_constants(rtx *loc, rtx insn, struct n64_tag_inline_remap *map)
{
  rtx x = *loc;
  register int i;
  register n64_enum_rtx_code code;
  register char *format_ptr;
  int num_changes = num_validated_changes ();
  rtx cxx_new = 0;
  n64_enum_machine_mode op0_mode;

  code = ((x)->code);

  switch (code)
    {
    case PC:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CONST:
    case LABEL_REF:
    case ADDRESS:
      return;







    case USE:
    case CLOBBER:


      if (((((x)->fld[0].rtx))->code) == MEM)
 subst_constants (&((((x)->fld[0].rtx))->fld[0].rtx), insn, map);
      return;

    case REG:


      {
 int regno = ((x)->fld[0].rtint);

 if (! (regno < 68 && ((x)->volatil))
     && regno < map->const_equiv_map_size
     && map->const_equiv_map[regno] != 0
     && map->const_age_map[regno] >= map->const_age)
   validate_change (insn, loc, map->const_equiv_map[regno], 1);
 return;
      }

    case SUBREG:





      if (((((x)->fld[0].rtx))->code) == REG)
 {
   rtx inner = ((x)->fld[0].rtx);
   rtx cxx_new = 0;






   subst_constants (&inner, (rtx) 0, map);

   if ((mode_class[(int)(((x)->mode))]) == MODE_INT
       && (mode_size[(int)(((x)->mode))]) == ((target_flags & 0x00002000) ? 8 : 4)
       && ((((x)->fld[0].rtx))->mode) != VOIDmode)
     cxx_new = operand_subword (inner, ((x)->fld[1].rtint), 0,
       ((((x)->fld[0].rtx))->mode));

   if (cxx_new == 0 && subreg_lowpart_p (x))
     cxx_new = gen_lowpart_common (((x)->mode), inner);

   if (cxx_new)
     validate_change (insn, loc, cxx_new, 1);

   return;
 }
      break;

    case MEM:
      subst_constants (&((x)->fld[0].rtx), insn, map);


      if (insn != 0 && num_validated_changes () != num_changes
   && !memory_address_p (((x)->mode), ((x)->fld[0].rtx)))
 cancel_changes (num_changes);
      return;

    case SET:
      {



 rtx *dest_loc = &((x)->fld[0].rtx);
 rtx dest = *dest_loc;
 rtx src, tem;

 subst_constants (&((x)->fld[1].rtx), insn, map);
 src = ((x)->fld[1].rtx);

 while (((*dest_loc)->code) == ZERO_EXTRACT


        || ((*dest_loc)->code) == SUBREG
        || ((*dest_loc)->code) == STRICT_LOW_PART)
   {
     if (((*dest_loc)->code) == ZERO_EXTRACT)
       {
  subst_constants (&((*dest_loc)->fld[1].rtx), insn, map);
  subst_constants (&((*dest_loc)->fld[2].rtx), insn, map);
       }
     dest_loc = &((*dest_loc)->fld[0].rtx);
   }


 if (((*dest_loc)->code) == MEM)
   subst_constants (&((*dest_loc)->fld[0].rtx), insn, map);





 if (((dest)->code) == SUBREG
     && (mode_size[(int)(((dest)->mode))]) <= ((target_flags & 0x00002000) ? 8 : 4)
     && (mode_size[(int)(((((dest)->fld[0].rtx))->mode))]) <= ((target_flags & 0x00002000) ? 8 : 4)
     && ((mode_size[(int)(((((dest)->fld[0].rtx))->mode))])
        <= (mode_size[(int)(((dest)->mode))]))
     && (tem = gen_lowpart_if_possible (((((dest)->fld[0].rtx))->mode),
            src)))
   src = tem, dest = ((dest)->fld[0].rtx);


 if ((map->num_sets < 10)
     && ((((src)->code) == LABEL_REF || ((src)->code) == SYMBOL_REF || ((src)->code) == CONST_INT || ((src)->code) == CONST_DOUBLE || ((src)->code) == CONST || ((src)->code) == HIGH)
  || (((src)->code) == REG
      && (((src)->fld[0].rtint) == ((68))
   || ((src)->fld[0].rtint) == (((68)) + 1)))
  || (((src)->code) == PLUS
      && ((((src)->fld[0].rtx))->code) == REG
      && (((((src)->fld[0].rtx))->fld[0].rtint) == ((68))
   || ((((src)->fld[0].rtx))->fld[0].rtint) == (((68)) + 1))
      && (((((src)->fld[1].rtx))->code) == LABEL_REF || ((((src)->fld[1].rtx))->code) == SYMBOL_REF || ((((src)->fld[1].rtx))->code) == CONST_INT || ((((src)->fld[1].rtx))->code) == CONST_DOUBLE || ((((src)->fld[1].rtx))->code) == CONST || ((((src)->fld[1].rtx))->code) == HIGH))
  || ((src)->code) == COMPARE



  || (dest == pc_rtx
      && (src == pc_rtx || ((src)->code) == RETURN
   || ((src)->code) == LABEL_REF))))
   {



     map->equiv_sets[map->num_sets].equiv = copy_rtx (src);
     map->equiv_sets[map->num_sets++].dest = dest;
   }

 return;
      }
    }

  format_ptr = (rtx_format[(int)(code)]);


  if (*format_ptr == 'e')
    op0_mode = ((((x)->fld[0].rtx))->mode);

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case '0':
   break;

 case 'e':
   if (((x)->fld[i].rtx))
     subst_constants (&((x)->fld[i].rtx), insn, map);
   break;

 case 'u':
 case 'i':
 case 's':
 case 'w':
   break;

 case 'E':
   if (((x)->fld[i].rtvec) != 
                     ((void *)0) 
                          && ((x)->fld[i].rtvec->num_elem) != 0)
     {
       int j;
       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  subst_constants (&((x)->fld[i].rtvec->elem[j].rtx), insn, map);
     }
   break;

 default:
   abort ();
 }
    }



  if (((rtx_class[(int)(code)]) == 'c' || code == NE || code == EQ)
      && (((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH) && ((((x)->fld[1].rtx))->code) != CONST_INT)
    {
      rtx tem = ((x)->fld[0].rtx);
      validate_change (insn, &((x)->fld[0].rtx), ((x)->fld[1].rtx), 1);
      validate_change (insn, &((x)->fld[1].rtx), tem, 1);
    }


  switch ((rtx_class[(int)(code)]))
    {
    case '1':
      cxx_new = simplify_unary_operation (code, ((x)->mode),
          ((x)->fld[0].rtx), op0_mode);
      break;

    case '<':
      {
 n64_enum_machine_mode op_mode = ((((x)->fld[0].rtx))->mode);
 if (op_mode == VOIDmode)
   op_mode = ((((x)->fld[1].rtx))->mode);
 cxx_new = simplify_relational_operation (code, op_mode,
          ((x)->fld[0].rtx), ((x)->fld[1].rtx));






 break;
      }

    case '2':
    case 'c':
      cxx_new = simplify_binary_operation (code, ((x)->mode),
           ((x)->fld[0].rtx), ((x)->fld[1].rtx));
      break;

    case 'b':
    case '3':
      cxx_new = simplify_ternary_operation (code, ((x)->mode), op0_mode,
     ((x)->fld[0].rtx), ((x)->fld[1].rtx), ((x)->fld[2].rtx));
      break;
    }

  if (cxx_new)
    validate_change (insn, loc, cxx_new, 1);
}




void
mark_stores(rtx dest, rtx x) asm("_mark_stores");
void
mark_stores(rtx dest, rtx x)
{
  int regno = -1;
  n64_enum_machine_mode mode;




  if (((dest)->code) == REG)
    regno = ((dest)->fld[0].rtint), mode = ((dest)->mode);
  else if (((dest)->code) == SUBREG && ((((dest)->fld[0].rtx))->code) == REG)
    {
      regno = ((((dest)->fld[0].rtx))->fld[0].rtint) + ((dest)->fld[1].rtint);
      mode = ((((dest)->fld[0].rtx))->mode);
    }

  if (regno >= 0)
    {
      int last_reg = (regno >= 68 ? regno
        : regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1);
      int i;

      for (i = regno; i <= last_reg; i++)
 if (i < global_const_equiv_map_size)
   global_const_equiv_map[i] = 0;
    }
}
static void
restore_constants(rtx *px) asm("_restore_constants");
static void
restore_constants(rtx *px)
{
  rtx x = *px;
  int i, j;
  char *fmt;

  if (x == 0)
    return;

  if (((x)->code) == CONST_DOUBLE)
    {


      if ((mode_class[(int)(((x)->mode))]) == MODE_FLOAT)
 {
   double d;

   do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((x))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((x))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
   *px = immed_real_const_1 (d, ((x)->mode));
 }
      else
 *px = immed_double_const (((x)->fld[2].rtwint), ((x)->fld[3].rtwint),
      VOIDmode);
    }

  else if (((x)->integrated) && ((x)->code) == CONST)
    {
      restore_constants (&((x)->fld[0].rtx));
      *px = validize_mem (force_const_mem (((x)->mode), ((x)->fld[0].rtx)));
    }
  else if (((x)->integrated) && ((x)->code) == SUBREG)
    {

      rtx cxx_new = ((((x)->fld[0].rtx))->fld[0].rtx);

      restore_constants (&cxx_new);
      cxx_new = force_const_mem (((((x)->fld[0].rtx))->mode), cxx_new);
      ((cxx_new)->mode = (((x)->mode)));
      *px = validize_mem (cxx_new);
    }
  else if (((x)->integrated) && ((x)->code) == ADDRESS)
    {
      restore_constants (&((x)->fld[0].rtx));
      *px = ((force_const_mem (((x)->mode), ((x)->fld[0].rtx)))->fld[0].rtx);
    }
  else
    {
      fmt = (rtx_format[(int)(((x)->code))]);
      for (i = 0; i < (rtx_length[(int)(((x)->code))]); i++)
 {
   switch (*fmt++)
     {
     case 'E':
       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  restore_constants (&((x)->fld[i].rtvec->elem[j].rtx));
       break;

     case 'e':
       restore_constants (&((x)->fld[i].rtx));
       break;
     }
 }
    }
}
static void
set_block_origin_self(register tree stmt) asm("_set_block_origin_self");
static void
set_block_origin_self(register tree stmt)
{
  if (((stmt)->block.abstract_origin) == (tree) 
                                     ((void *)0)
                                              )
    {
      ((stmt)->block.abstract_origin) = stmt;

      {
        register tree local_decl;

        for (local_decl = ((stmt)->block.vars);
      local_decl != (tree) 
                   ((void *)0)
                            ;
      local_decl = ((local_decl)->common.chain))
          set_decl_origin_self (local_decl);
      }

      {
        register tree subblock;

        for (subblock = ((stmt)->block.subblocks);
      subblock != (tree) 
                 ((void *)0)
                          ;
      subblock = ((subblock)->common.chain))
          set_block_origin_self (subblock);
      }
    }
}
static void
set_decl_origin_self(register tree decl) asm("_set_decl_origin_self");
static void
set_decl_origin_self(register tree decl)
{
  if (((decl)->decl.abstract_origin) == (tree) 
                                    ((void *)0)
                                             )
    {
      ((decl)->decl.abstract_origin) = decl;
      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 {
   register tree arg;

   for (arg = ((decl)->decl.arguments); arg; arg = ((arg)->common.chain))
     ((arg)->decl.abstract_origin) = arg;
   if (((decl)->decl.initial) != (tree) 
                             ((void *)0)
       
      && ((decl)->decl.initial) != error_mark_node)
     set_block_origin_self (((decl)->decl.initial));
 }
    }
}






static void
set_block_abstract_flags(register tree stmt, register int setting) asm("_set_block_abstract_flags");
static void
set_block_abstract_flags(register tree stmt, register int setting)
{
  ((stmt)->block.abstract_flag) = setting;

  {
    register tree local_decl;

    for (local_decl = ((stmt)->block.vars);
  local_decl != (tree) 
               ((void *)0)
                        ;
  local_decl = ((local_decl)->common.chain))
      set_decl_abstract_flags (local_decl, setting);
  }

  {
    register tree subblock;

    for (subblock = ((stmt)->block.subblocks);
  subblock != (tree) 
             ((void *)0)
                      ;
  subblock = ((subblock)->common.chain))
      set_block_abstract_flags (subblock, setting);
  }
}







void
set_decl_abstract_flags(register tree decl, register int setting) asm("_set_decl_abstract_flags");
void
set_decl_abstract_flags(register tree decl, register int setting)
{
  ((decl)->decl.abstract_flag) = setting;
  if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    {
      register tree arg;

      for (arg = ((decl)->decl.arguments); arg; arg = ((arg)->common.chain))
 ((arg)->decl.abstract_flag) = setting;
      if (((decl)->decl.initial) != (tree) 
                                ((void *)0)
   
  && ((decl)->decl.initial) != error_mark_node)
 set_block_abstract_flags (((decl)->decl.initial), setting);
    }
}





void
output_inline_function(tree fndecl) asm("_output_inline_function");
void
output_inline_function(tree fndecl)
{
  rtx head;
  rtx last;
  int save_flag_no_inline = flag_no_inline;

  if (output_bytecode)
    {
      warning ("`inline' ignored for bytecode output");
      return;
    }



  temporary_allocation ();

  head = ((fndecl)->decl.saved_insns.r);
  current_function_decl = fndecl;


  init_function_start (fndecl, "lossage", 1);



  assign_parms (fndecl, 1);


  assign_stack_local (BLKmode, ((fndecl)->decl.frame_size.i), 0);

  restore_reg_data (((head)->fld[3].rtx));

  stack_slot_list = ((head)->fld[10].rtx);
  forced_labels = ((head)->fld[11].rtx);

  if (((head)->fld[12].rtint) & 01)
    current_function_calls_alloca = 1;

  if (((head)->fld[12].rtint) & 02)
    current_function_calls_setjmp = 1;

  if (((head)->fld[12].rtint) & 0400)
    current_function_calls_longjmp = 1;

  if (((head)->fld[12].rtint) & 04)
    current_function_returns_struct = 1;

  if (((head)->fld[12].rtint) & 010)
    current_function_returns_pcc_struct = 1;

  if (((head)->fld[12].rtint) & 020)
    current_function_needs_context = 1;

  if (((head)->fld[12].rtint) & 040)
    current_function_has_nonlocal_label = 1;

  if (((head)->fld[12].rtint) & 0100)
    current_function_returns_pointer = 1;

  if (((head)->fld[12].rtint) & 0200)
    current_function_uses_const_pool = 1;

  if (((head)->fld[12].rtint) & 01000)
    current_function_uses_pic_offset_table = 1;

  current_function_outgoing_args_size = ((head)->fld[13].rtint);
  current_function_pops_args = ((head)->fld[9].rtint);



  immediate_size_expand--;


  for (last = ((head)->fld[3].rtx);
       ((last)->fld[2].rtx); last = ((last)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((last)->code))]) == 'i')
 {
   restore_constants (&((last)->fld[3].rtx));
   restore_constants (&((last)->fld[6].rtx));
 }
    }

  set_new_first_and_last_insn (((head)->fld[3].rtx), last);
  set_new_first_and_last_label_num (((head)->fld[4].rtint), ((head)->fld[5].rtint));
  set_decl_origin_self (fndecl);


  ((fndecl)->decl.defer_output) = 0;



  flag_no_inline = 1;


  rest_of_compilation (fndecl);


  flag_no_inline = save_flag_no_inline;

  current_function_decl = 0;
}

