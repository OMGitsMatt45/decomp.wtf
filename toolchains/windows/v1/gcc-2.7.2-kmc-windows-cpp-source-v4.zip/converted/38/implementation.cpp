// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cse.c
/* Common subexpression elimination for GNU compiler.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <setjmp.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int split_double(...) asm("_split_double");
extern int refers_to_regno_p(...) asm("_refers_to_regno_p");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int rtx_addr_varies_p(...) asm("_rtx_addr_varies_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int neg_double(...) asm("_neg_double");
extern int set_float_handler(...) asm("_set_float_handler");
extern int target_negative(...) asm("_target_negative");
extern int add_double(...) asm("_add_double");
extern int mul_double(...) asm("_mul_double");
extern int rshift_double(...) asm("_rshift_double");
extern int lshift_double(...) asm("_lshift_double");
extern int lrotate_double(...) asm("_lrotate_double");
extern int rrotate_double(...) asm("_rrotate_double");
extern int side_effects_p(...) asm("_side_effects_p");
extern int comparison_dominates_p(...) asm("_comparison_dominates_p");
extern int condjump_p(...) asm("_condjump_p");
extern int simplejump_p(...) asm("_simplejump_p");
extern int remove_note(...) asm("_remove_note");
extern int note_stores(...) asm("_note_stores");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int init_recog(...) asm("_init_recog");
extern int get_max_uid(...) asm("_get_max_uid");
struct n64_tag_branch_path;
struct n64_tag_cse_basic_block_data;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_set;
struct n64_tag_table_elt;
struct n64_tag_write_data;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");



enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];


static int max_reg;




static int max_qty;




static int next_qty;




static int *qty_first_reg;
static int *qty_last_reg;



static n64_enum_machine_mode *qty_mode;






static rtx *qty_const;




static rtx *qty_const_insn;
static n64_enum_rtx_code *qty_comparison_code;





static rtx *qty_comparison_const;





static int *qty_comparison_qty;
static rtx prev_insn;



static rtx this_insn;




static int *reg_qty;
static int *reg_next_eqv;
static int *reg_prev_eqv;




static int *reg_tick;
static int *reg_in_table;






static HARD_REG_SET hard_regs_in_table;




static HARD_REG_SET regs_invalidated_by_call;






static int *all_minus_one;
static int *consec_ints;



static int cse_basic_block_start;



static int cse_basic_block_end;





static int *uid_cuid;


static int max_uid;
static int cse_jumps_altered;




static int recorded_label_ref;





static int do_not_record;




static rtx memory_extend_rtx;





static int hash_arg_in_memory;




static int hash_arg_in_struct;
struct n64_tag_table_elt
{
  rtx exp;
  struct n64_tag_table_elt *next_same_hash;
  struct n64_tag_table_elt *prev_same_hash;
  struct n64_tag_table_elt *next_same_value;
  struct n64_tag_table_elt *prev_same_value;
  struct n64_tag_table_elt *first_same_value;
  struct n64_tag_table_elt *related_value;
  int cost;
  n64_enum_machine_mode mode;
  char in_memory;
  char in_struct;
  char is_const;
  char flag;
};
static struct n64_tag_table_elt *table[31];




static struct n64_tag_table_elt *free_element_chain;



static int n_elements_made;




static int max_elements_made;





static struct n64_tag_table_elt *last_jump_equiv_class;






static int constant_pool_entries_cost;
struct n64_tag_write_data
{
  int sp : 1;
  int var : 1;
  int nonscalar : 1;
  int all : 1;
};







enum n64_cpp_enum_taken{TAKEN, NOT_TAKEN, AROUND};
typedef __underlying_type(enum n64_cpp_enum_taken) n64_enum_taken;
struct n64_tag_branch_path {

    rtx branch;



    n64_enum_taken status;
  };
struct n64_tag_cse_basic_block_data {

  int low_cuid;

  int high_cuid;

  int nsets;

  rtx last;

  int path_size;

  struct n64_tag_branch_path path[10];
};
static void new_basic_block (void) asm("_new_basic_block");
static void make_new_qty (int) asm("_make_new_qty");
static void make_regs_eqv (int, int) asm("_make_regs_eqv");
static void delete_reg_equiv (int) asm("_delete_reg_equiv");
static int mention_regs (rtx) asm("_mention_regs");
static int insert_regs (rtx, struct n64_tag_table_elt *, int) asm("_insert_regs");
static void free_element (struct n64_tag_table_elt *) asm("_free_element");
static void remove_from_table (struct n64_tag_table_elt *, unsigned) asm("_remove_from_table");
static struct n64_tag_table_elt *get_element (void) asm("_get_element");
static struct n64_tag_table_elt *lookup (rtx, unsigned, n64_enum_machine_mode),
       *lookup_for_remove (rtx, unsigned, n64_enum_machine_mode);
static rtx lookup_as_function (rtx, n64_enum_rtx_code) asm("_lookup_as_function");
static struct n64_tag_table_elt *insert (rtx, struct n64_tag_table_elt *, unsigned, n64_enum_machine_mode) asm("_insert")
                              ;
static void merge_equiv_classes (struct n64_tag_table_elt *, struct n64_tag_table_elt *) asm("_merge_equiv_classes")
                               ;
static void invalidate (rtx, n64_enum_machine_mode) asm("_invalidate");
static void remove_invalid_refs (int) asm("_remove_invalid_refs");
static void rehash_using_reg (rtx) asm("_rehash_using_reg");
static void invalidate_memory (struct n64_tag_write_data *) asm("_invalidate_memory");
static void invalidate_for_call (void) asm("_invalidate_for_call");
static rtx use_related_value (rtx, struct n64_tag_table_elt *) asm("_use_related_value");
static unsigned canon_hash (rtx, n64_enum_machine_mode) asm("_canon_hash");
static unsigned safe_hash (rtx, n64_enum_machine_mode) asm("_safe_hash");
static int exp_equiv_p (rtx, rtx, int, int) asm("_exp_equiv_p");
static void set_nonvarying_address_components (rtx, int, rtx *, int *, int *) asm("_set_nonvarying_address_components")

                            ;
static int refers_to_p (rtx, rtx) asm("_refers_to_p");
static int refers_to_mem_p (rtx, rtx, int, int) asm("_refers_to_mem_p")
                          ;
static int cse_rtx_addr_varies_p (rtx) asm("_cse_rtx_addr_varies_p");
static rtx canon_reg (rtx, rtx) asm("_canon_reg");
static void find_best_addr (rtx, rtx *) asm("_find_best_addr");
static n64_enum_rtx_code find_comparison_args (n64_enum_rtx_code, rtx *, rtx *, n64_enum_machine_mode *, n64_enum_machine_mode *) asm("_find_comparison_args")

                            ;
static rtx cse_gen_binary (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_cse_gen_binary")
                     ;
static rtx simplify_plus_minus (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_plus_minus")
                     ;
static rtx fold_rtx (rtx, rtx) asm("_fold_rtx");
static rtx equiv_constant (rtx) asm("_equiv_constant");
static void record_jump_equiv (rtx, int) asm("_record_jump_equiv");
static void record_jump_cond (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx, int) asm("_record_jump_cond")
                          ;
static void cse_insn (rtx, int) asm("_cse_insn");
static void note_mem_written (rtx, struct n64_tag_write_data *) asm("_note_mem_written");
static void invalidate_from_clobbers (struct n64_tag_write_data *, rtx) asm("_invalidate_from_clobbers");
static rtx cse_process_notes (rtx, rtx) asm("_cse_process_notes");
static void cse_around_loop (rtx) asm("_cse_around_loop");
static void invalidate_skipped_set (rtx, rtx) asm("_invalidate_skipped_set");
static void invalidate_skipped_block (rtx) asm("_invalidate_skipped_block");
static void cse_check_loop_start (rtx, rtx) asm("_cse_check_loop_start");
static void cse_set_around_loop (rtx, rtx, rtx) asm("_cse_set_around_loop");
static rtx cse_basic_block (rtx, rtx, struct n64_tag_branch_path *, int) asm("_cse_basic_block");
static void count_reg_usage (rtx, int *, rtx, int) asm("_count_reg_usage");

extern int rtx_equal_function_value_matters;
int
rtx_cost(rtx x, n64_enum_rtx_code outer_code) asm("_rtx_cost");
int
rtx_cost(rtx x, n64_enum_rtx_code outer_code)
{
  register int i, j;
  register n64_enum_rtx_code code;
  register char *fmt;
  register int total;

  if (x == 0)
    return 0;




  code = ((x)->code);
  switch (code)
    {
    case MULT:


      if (((((x)->fld[1].rtx))->code) == CONST_INT
   && exact_log2_wide ((int) (((((x)->fld[1].rtx))->fld[0].rtwint))) >= 0)
 total = 2;
      else
 total = ((5) * 4 - 2);
      break;
    case DIV:
    case UDIV:
    case MOD:
    case UMOD:
      total = ((7) * 4 - 2);
      break;
    case USE:

      total = 0;
      break;
    case ASM_OPERANDS:



      total = 1000;
      break;
    default:
      total = 2;
    }

  switch (code)
    {
    case REG:
      return ! ((((x)->volatil) && ((x)->fld[0].rtint) < 68) || ((((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 29) || (((x)->fld[0].rtint)) == 0 || ((((x)->fld[0].rtint)) >= (68) && (((x)->fld[0].rtint)) <= (((68)) + 3)) || ((((x)->fld[0].rtint)) < 68 && ((((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 30) || fixed_regs[((x)->fld[0].rtint)] || global_regs[((x)->fld[0].rtint)]) && mips_regno_to_class[ (((x)->fld[0].rtint)) ] != NO_REGS)));

    case SUBREG:


      if (! (((mode_class[(int)(((x)->mode))]) == MODE_FLOAT || (mode_class[(int)(((x)->mode))]) == MODE_COMPLEX_FLOAT) == ((mode_class[(int)(((((x)->fld[0].rtx))->mode))]) == MODE_FLOAT || (mode_class[(int)(((((x)->fld[0].rtx))->mode))]) == MODE_COMPLEX_FLOAT)))
 return ((2 + (mode_size[(int)(((x)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4)) * 4 - 2)
                                                         ;
      return 2;

      case MEM: { int num_words = ((mode_size[(int)(((x)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4)) ? 2 : 1; if (simple_memory_operand (x, ((x)->mode))) return ((num_words) * 4 - 2); return ((2*num_words) * 4 - 2); } case FFS: return ((6) * 4 - 2); case NOT: return (((((x)->mode) == DImode && !(target_flags & 0x00002000)) ? 2 : 1) * 4 - 2); case AND: case IOR: case XOR: if (((x)->mode) == DImode && !(target_flags & 0x00002000)) return ((2) * 4 - 2); return ((1) * 4 - 2); case ASHIFT: case ASHIFTRT: case LSHIFTRT: if (((x)->mode) == DImode && !(target_flags & 0x00002000)) return (((((((x)->fld[1].rtx))->code) == CONST_INT) ? 4 : 12) * 4 - 2); return ((1) * 4 - 2); case ABS: { n64_enum_machine_mode xmode = ((x)->mode); if (xmode == SFmode || xmode == DFmode) return ((1) * 4 - 2); return ((4) * 4 - 2); } case PLUS: case MINUS: { n64_enum_machine_mode xmode = ((x)->mode); if (xmode == SFmode || xmode == DFmode) { if (mips_cpu == PROCESSOR_R3000) return ((2) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((3) * 4 - 2); else return ((6) * 4 - 2); } if (xmode == DImode && !(target_flags & 0x00002000)) return ((4) * 4 - 2); return ((1) * 4 - 2); } case NEG: return (((((x)->mode) == DImode && !(target_flags & 0x00002000)) ? 4 : 1) * 4 - 2); case MULT: { n64_enum_machine_mode xmode = ((x)->mode); if (xmode == SFmode) { if (mips_cpu == PROCESSOR_R3000) return ((4) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((5) * 4 - 2); else return ((7) * 4 - 2); } if (xmode == DFmode) { if (mips_cpu == PROCESSOR_R3000) return ((5) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((6) * 4 - 2); else return ((8) * 4 - 2); } if (mips_cpu == PROCESSOR_R3000) return ((12) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((17) * 4 - 2); else return ((10) * 4 - 2); } case DIV: case MOD: { n64_enum_machine_mode xmode = ((x)->mode); if (xmode == SFmode) { if (mips_cpu == PROCESSOR_R3000) return ((12) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((15) * 4 - 2); else return ((23) * 4 - 2); } if (xmode == DFmode) { if (mips_cpu == PROCESSOR_R3000) return ((19) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((16) * 4 - 2); else return ((36) * 4 - 2); } } case UDIV: case UMOD: if (mips_cpu == PROCESSOR_R3000) return ((35) * 4 - 2); else if (mips_cpu == PROCESSOR_R6000) return ((38) * 4 - 2); else return ((69) * 4 - 2);;

      case CONST_INT: return 0; case LABEL_REF: return ((2) * 4 - 2); case CONST: { rtx offset = const0_rtx; rtx symref = eliminate_constant_term (((x)->fld[0].rtx), &offset); if (((symref)->code) == LABEL_REF) return ((2) * 4 - 2); if (((symref)->code) != SYMBOL_REF) return ((4) * 4 - 2); if (((offset)->fld[0].rtwint) < -32768 || ((offset)->fld[0].rtwint) > 32767) return ((2) * 4 - 2); return ((((symref)->volatil) ? 1 : 2) * 4 - 2); } case SYMBOL_REF: return ((((x)->volatil) ? 1 : 2) * 4 - 2); case CONST_DOUBLE: { rtx high, low; split_double (x, &high, &low); return (((high == (const_tiny_rtx[0][(int) (((high)->mode))]) || low == (const_tiny_rtx[0][(int) (((low)->mode))])) ? 2 : 4) * 4 - 2); };
    }




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      total += rtx_cost (((x)->fld[i].rtx), code);
    else if (fmt[i] == 'E')
      for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
 total += rtx_cost (((x)->fld[i].rtvec->elem[j].rtx), code);

  return total;
}




static void
new_basic_block(void) asm("_new_basic_block");
static void
new_basic_block(void)
{
  register int i;

  next_qty = max_reg;

  memset ((char *) reg_tick,0,max_reg * sizeof (int));

  memcpy ((char *) reg_in_table,(char *) all_minus_one,max_reg * sizeof (int))
                         ;
  memcpy ((char *) reg_qty,(char *) consec_ints,max_reg * sizeof (int));
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_regs_in_table); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);




  for (i = 0; i < 31; i++)
    {
      register struct n64_tag_table_elt *cxx_this, *next;
      for (cxx_this = table[i]; cxx_this; cxx_this = next)
 {
   next = cxx_this->next_same_hash;
   free_element (cxx_this);
 }
    }

  memset ((char *) table,0,sizeof table);

  prev_insn = 0;




}




static void
make_new_qty(register int reg) asm("_make_new_qty");
static void
make_new_qty(register int reg)
{
  register int q;

  if (next_qty >= max_qty)
    abort ();

  q = reg_qty[reg] = next_qty++;
  qty_first_reg[q] = reg;
  qty_last_reg[q] = reg;
  qty_const[q] = qty_const_insn[q] = 0;
  qty_comparison_code[q] = UNKNOWN;

  reg_next_eqv[reg] = reg_prev_eqv[reg] = -1;
}




static void
make_regs_eqv(register int cxx_new, register int old) asm("_make_regs_eqv");
static void
make_regs_eqv(register int cxx_new, register int old)
{
  register int lastr, firstr;
  register int q = reg_qty[old];


  if (! (reg_qty[old] != (old)))
    abort ();

  reg_qty[cxx_new] = q;
  firstr = qty_first_reg[q];
  lastr = qty_last_reg[q];





  if (! (firstr < 68 && ((firstr) == (0 + 30) || (firstr) == (0 + 30) || fixed_regs[firstr] || global_regs[firstr]))




      && (cxx_new >= 68 || mips_regno_to_class[ (cxx_new) ] != NO_REGS)
      && ((cxx_new < 68 && ((cxx_new) == (0 + 30) || (cxx_new) == (0 + 30) || fixed_regs[cxx_new] || global_regs[cxx_new]))
   || (cxx_new >= 68
       && (firstr < 68
    || ((uid_cuid[regno_last_uid[cxx_new]] > cse_basic_block_end
         || (uid_cuid[regno_first_uid[cxx_new]]
      < cse_basic_block_start))
        && (uid_cuid[regno_last_uid[cxx_new]]
     > uid_cuid[regno_last_uid[firstr]]))))))
    {
      reg_prev_eqv[firstr] = cxx_new;
      reg_next_eqv[cxx_new] = firstr;
      reg_prev_eqv[cxx_new] = -1;
      qty_first_reg[q] = cxx_new;
    }
  else
    {




      while (lastr < 68 && reg_prev_eqv[lastr] >= 0
      && (mips_regno_to_class[ (lastr) ] == NO_REGS || ! ((lastr) == (0 + 30) || (lastr) == (0 + 30) || fixed_regs[lastr] || global_regs[lastr]))
      && cxx_new >= 68)
 lastr = reg_prev_eqv[lastr];
      reg_next_eqv[cxx_new] = reg_next_eqv[lastr];
      if (reg_next_eqv[lastr] >= 0)
 reg_prev_eqv[reg_next_eqv[lastr]] = cxx_new;
      else
 qty_last_reg[q] = cxx_new;
      reg_next_eqv[lastr] = cxx_new;
      reg_prev_eqv[cxx_new] = lastr;
    }
}



static void
delete_reg_equiv(register int reg) asm("_delete_reg_equiv");
static void
delete_reg_equiv(register int reg)
{
  register int q = reg_qty[reg];
  register int p, n;


  if (q == reg)
    return;

  p = reg_prev_eqv[reg];
  n = reg_next_eqv[reg];

  if (n != -1)
    reg_prev_eqv[n] = p;
  else
    qty_last_reg[q] = p;
  if (p != -1)
    reg_next_eqv[p] = n;
  else
    qty_first_reg[q] = n;

  reg_qty[reg] = reg;
}
static int
mention_regs(rtx x) asm("_mention_regs");
static int
mention_regs(rtx x)
{
  register n64_enum_rtx_code code;
  register int i, j;
  register char *fmt;
  register int changed = 0;

  if (x == 0)
    return 0;

  code = ((x)->code);
  if (code == REG)
    {
      register int regno = ((x)->fld[0].rtint);
      register int endregno
 = regno + (regno >= 68 ? 1
     : (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))));
      int i;

      for (i = regno; i < endregno; i++)
 {
   if (reg_in_table[i] >= 0 && reg_in_table[i] != reg_tick[i])
     remove_invalid_refs (i);

   reg_in_table[i] = reg_tick[i];
 }

      return 0;
    }
  if (code == COMPARE || (rtx_class[(int)(code)]) == '<')
    {
      if (((((x)->fld[0].rtx))->code) == REG
   && ! (reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)] != (((((x)->fld[0].rtx))->fld[0].rtint))))
 if (insert_regs (((x)->fld[0].rtx), ((void *)0), 0))
   {
     rehash_using_reg (((x)->fld[0].rtx));
     changed = 1;
   }

      if (((((x)->fld[1].rtx))->code) == REG
   && ! (reg_qty[((((x)->fld[1].rtx))->fld[0].rtint)] != (((((x)->fld[1].rtx))->fld[0].rtint))))
 if (insert_regs (((x)->fld[1].rtx), ((void *)0), 0))
   {
     rehash_using_reg (((x)->fld[1].rtx));
     changed = 1;
   }
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      changed |= mention_regs (((x)->fld[i].rtx));
    else if (fmt[i] == 'E')
      for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
 changed |= mention_regs (((x)->fld[i].rtvec->elem[j].rtx));

  return changed;
}
static int
insert_regs(rtx x, struct n64_tag_table_elt *classp, int modified) asm("_insert_regs");
static int
insert_regs(rtx x, struct n64_tag_table_elt *classp, int modified)
{
  if (((x)->code) == REG)
    {
      register int regno = ((x)->fld[0].rtint);




      if ((reg_qty[regno] != (regno))
   && qty_mode[reg_qty[regno]] != ((x)->mode))
 return 0;

      if (modified || ! (reg_qty[regno] != (regno)))
 {
   if (classp)
     for (classp = classp->first_same_value;
   classp != 0;
   classp = classp->next_same_value)
       if (((classp->exp)->code) == REG
    && ((classp->exp)->mode) == ((x)->mode))
  {
    make_regs_eqv (regno, ((classp->exp)->fld[0].rtint));
    return 1;
  }

   make_new_qty (regno);
   qty_mode[reg_qty[regno]] = ((x)->mode);
   return 1;
 }

      return 0;
    }







  else if (((x)->code) == SUBREG && ((((x)->fld[0].rtx))->code) == REG
    && ! (reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)] != (((((x)->fld[0].rtx))->fld[0].rtint))))
    {
      insert_regs (((x)->fld[0].rtx), ((void *)0), 0);
      mention_regs (((x)->fld[0].rtx));
      return 1;
    }
  else
    return mention_regs (x);
}





static void
free_element(struct n64_tag_table_elt *elt) asm("_free_element");
static void
free_element(struct n64_tag_table_elt *elt)
{
  elt->next_same_hash = free_element_chain;
  free_element_chain = elt;
}



static struct n64_tag_table_elt *
get_element(void) asm("_get_element");
static struct n64_tag_table_elt *
get_element(void)
{
  struct n64_tag_table_elt *elt = free_element_chain;
  if (elt)
    {
      free_element_chain = elt->next_same_hash;
      return elt;
    }
  n_elements_made++;
  return (struct n64_tag_table_elt *) oballoc (sizeof (struct n64_tag_table_elt));
}






static void
remove_from_table(register struct n64_tag_table_elt *elt, unsigned int hash) asm("_remove_from_table");
static void
remove_from_table(register struct n64_tag_table_elt *elt, unsigned int hash)
{
  if (elt == 0)
    return;


  elt->first_same_value = 0;



  {
    register struct n64_tag_table_elt *prev = elt->prev_same_value;
    register struct n64_tag_table_elt *next = elt->next_same_value;

    if (next) next->prev_same_value = prev;

    if (prev)
      prev->next_same_value = next;
    else
      {
 register struct n64_tag_table_elt *newfirst = next;
 while (next)
   {
     next->first_same_value = newfirst;
     next = next->next_same_value;
   }
      }
  }



  {
    register struct n64_tag_table_elt *prev = elt->prev_same_hash;
    register struct n64_tag_table_elt *next = elt->next_same_hash;

    if (next) next->prev_same_hash = prev;

    if (prev)
      prev->next_same_hash = next;
    else if (table[hash] == elt)
      table[hash] = next;
    else
      {




 for (hash = 0; hash < 31; hash++)
   if (table[hash] == elt)
     table[hash] = next;
      }
  }



  if (elt->related_value != 0 && elt->related_value != elt)
    {
      register struct n64_tag_table_elt *p = elt->related_value;
      while (p->related_value != elt)
 p = p->related_value;
      p->related_value = elt->related_value;
      if (p->related_value == p)
 p->related_value = 0;
    }

  free_element (elt);
}
static struct n64_tag_table_elt *
lookup(rtx x, unsigned int hash, n64_enum_machine_mode mode) asm("_lookup");
static struct n64_tag_table_elt *
lookup(rtx x, unsigned int hash, n64_enum_machine_mode mode)
{
  register struct n64_tag_table_elt *p;

  for (p = table[hash]; p; p = p->next_same_hash)
    if (mode == p->mode && ((x == p->exp && ((x)->code) == REG)
       || exp_equiv_p (x, p->exp, ((x)->code) != REG, 0)))
      return p;

  return 0;
}




static struct n64_tag_table_elt *
lookup_for_remove(rtx x, unsigned int hash, n64_enum_machine_mode mode) asm("_lookup_for_remove");
static struct n64_tag_table_elt *
lookup_for_remove(rtx x, unsigned int hash, n64_enum_machine_mode mode)
{
  register struct n64_tag_table_elt *p;

  if (((x)->code) == REG)
    {
      int regno = ((x)->fld[0].rtint);


      for (p = table[hash]; p; p = p->next_same_hash)
 if (((p->exp)->code) == REG
     && ((p->exp)->fld[0].rtint) == regno)
   return p;
    }
  else
    {
      for (p = table[hash]; p; p = p->next_same_hash)
 if (mode == p->mode && (x == p->exp || exp_equiv_p (x, p->exp, 0, 0)))
   return p;
    }

  return 0;
}




static rtx
lookup_as_function(rtx x, n64_enum_rtx_code code) asm("_lookup_as_function");
static rtx
lookup_as_function(rtx x, n64_enum_rtx_code code)
{
  register struct n64_tag_table_elt *p = lookup (x, safe_hash (x, VOIDmode) % 31,
      ((x)->mode));
  if (p == 0)
    return 0;

  for (p = p->first_same_value; p; p = p->next_same_value)
    {
      if (((p->exp)->code) == code

   && exp_equiv_p (p->exp, p->exp, 1, 0))
 return p->exp;
    }

  return 0;
}
static struct n64_tag_table_elt *
insert(register rtx x, register struct n64_tag_table_elt *classp, unsigned int hash, n64_enum_machine_mode mode) asm("_insert");
static struct n64_tag_table_elt *
insert(register rtx x, register struct n64_tag_table_elt *classp, unsigned int hash, n64_enum_machine_mode mode)
{
  register struct n64_tag_table_elt *elt;



  if (((x)->code) == REG && ! (reg_qty[((x)->fld[0].rtint)] != (((x)->fld[0].rtint))))
    abort ();


  if (((x)->code) == REG && ((x)->fld[0].rtint) < 68)
    {
      int regno = ((x)->fld[0].rtint);
      int endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      int i;

      for (i = regno; i < endregno; i++)
     ((hard_regs_in_table)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
    }


  if (((x)->code) == LABEL_REF
      || (((x)->code) == CONST && ((((x)->fld[0].rtx))->code) == PLUS
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == LABEL_REF))
    recorded_label_ref = 1;



  elt = get_element ();
  elt->exp = x;
  elt->cost = (((x)->code) == REG ? (((((x)->volatil) && ((x)->fld[0].rtint) < 68) || ((((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 29) || (((x)->fld[0].rtint)) == 0 || ((((x)->fld[0].rtint)) >= (68) && (((x)->fld[0].rtint)) <= (((68)) + 3)) || ((((x)->fld[0].rtint)) < 68 && ((((x)->fld[0].rtint)) == (0 + 30) || (((x)->fld[0].rtint)) == (0 + 30) || fixed_regs[((x)->fld[0].rtint)] || global_regs[((x)->fld[0].rtint)]) && mips_regno_to_class[ (((x)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((x)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (x, SET) * 2);
  elt->next_same_value = 0;
  elt->prev_same_value = 0;
  elt->next_same_hash = table[hash];
  elt->prev_same_hash = 0;
  elt->related_value = 0;
  elt->in_memory = 0;
  elt->mode = mode;
  elt->is_const = ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH)


     || (((x)->unchanging)
         && ((x)->code) == REG
         && ((x)->fld[0].rtint) >= 68)
     || ((x) == frame_pointer_rtx || (x) == hard_frame_pointer_rtx || (x) == arg_pointer_rtx || (x) == virtual_stack_vars_rtx || (x) == virtual_incoming_args_rtx || (((x)->code) == PLUS && ((((x)->fld[1].rtx))->code) == CONST_INT && (((x)->fld[0].rtx) == frame_pointer_rtx || ((x)->fld[0].rtx) == hard_frame_pointer_rtx || ((x)->fld[0].rtx) == arg_pointer_rtx || ((x)->fld[0].rtx) == virtual_stack_vars_rtx || ((x)->fld[0].rtx) == virtual_incoming_args_rtx))));

  if (table[hash])
    table[hash]->prev_same_hash = elt;
  table[hash] = elt;


  if (classp)
    {
      classp = classp->first_same_value;
      if (((elt)->cost < (classp)->cost))

 {
   register struct n64_tag_table_elt *p;
   elt->next_same_value = classp;
   classp->prev_same_value = elt;
   elt->first_same_value = elt;

   for (p = classp; p; p = p->next_same_value)
     p->first_same_value = elt;
 }
      else
 {


   register struct n64_tag_table_elt *p, *next;
   for (p = classp; (next = p->next_same_value) && ((next)->cost < (elt)->cost);
        p = next);

   elt->next_same_value = next;
   if (next)
     next->prev_same_value = elt;
   elt->prev_same_value = p;
   p->next_same_value = elt;
   elt->first_same_value = classp;
 }
    }
  else
    elt->first_same_value = elt;
  if (elt->is_const && classp && ((classp->exp)->code) == REG
      && ((x)->code) != REG)
    {
      qty_const[reg_qty[((classp->exp)->fld[0].rtint)]]
 = gen_lowpart_if_possible (qty_mode[reg_qty[((classp->exp)->fld[0].rtint)]], x);
      qty_const_insn[reg_qty[((classp->exp)->fld[0].rtint)]] = this_insn;
    }

  else if (((x)->code) == REG && classp && ! qty_const[reg_qty[((x)->fld[0].rtint)]]
    && ! elt->is_const)
    {
      register struct n64_tag_table_elt *p;

      for (p = classp; p != 0; p = p->next_same_value)
 {
   if (p->is_const && ((p->exp)->code) != REG)
     {
       qty_const[reg_qty[((x)->fld[0].rtint)]]
  = gen_lowpart_if_possible (((x)->mode), p->exp);
       qty_const_insn[reg_qty[((x)->fld[0].rtint)]] = this_insn;
       break;
     }
 }
    }

  else if (((x)->code) == REG && qty_const[reg_qty[((x)->fld[0].rtint)]]
    && ((x)->mode) == qty_mode[reg_qty[((x)->fld[0].rtint)]])
    qty_const_insn[reg_qty[((x)->fld[0].rtint)]] = this_insn;




  if (((x)->code) == CONST)
    {
      rtx subexp = get_related_value (x);
      unsigned subhash;
      struct n64_tag_table_elt *subelt, *subelt_prev;

      if (subexp != 0)
 {

   subhash = safe_hash (subexp, mode) % 31;
   subelt = lookup (subexp, subhash, mode);
   if (subelt == 0)
     subelt = insert (subexp, ((void *)0), subhash, mode);

   if (subelt->related_value == 0)
     subelt->related_value = subelt;

   subelt_prev = subelt;
   while (subelt_prev->related_value != subelt)
     subelt_prev = subelt_prev->related_value;


   elt->related_value = subelt_prev->related_value;
   subelt_prev->related_value = elt;
 }
    }

  return elt;
}
static void
merge_equiv_classes(struct n64_tag_table_elt *class1, struct n64_tag_table_elt *class2) asm("_merge_equiv_classes");
static void
merge_equiv_classes(struct n64_tag_table_elt *class1, struct n64_tag_table_elt *class2)
{
  struct n64_tag_table_elt *elt, *next, *cxx_new;


  class1 = class1->first_same_value;
  class2 = class2->first_same_value;


  if (class1 == class2)
    return;

  for (elt = class2; elt; elt = next)
    {
      unsigned hash;
      rtx exp = elt->exp;
      n64_enum_machine_mode mode = elt->mode;

      next = elt->next_same_value;




      if (((exp)->code) == REG || exp_equiv_p (exp, exp, 1, 0))
 {
   hash_arg_in_memory = 0;
   hash_arg_in_struct = 0;
   hash = (((exp)->code) == REG && ((exp)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((exp)->fld[0].rtint)]) % 31 : canon_hash (exp, mode) % 31);

   if (((exp)->code) == REG)
     delete_reg_equiv (((exp)->fld[0].rtint));

   remove_from_table (elt, hash);

   if (insert_regs (exp, class1, 0))
     {
       rehash_using_reg (exp);
       hash = (((exp)->code) == REG && ((exp)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((exp)->fld[0].rtint)]) % 31 : canon_hash (exp, mode) % 31);
     }
   cxx_new = insert (exp, class1, hash, mode);
   cxx_new->in_memory = hash_arg_in_memory;
   cxx_new->in_struct = hash_arg_in_struct;
 }
    }
}
static void
invalidate(rtx x, n64_enum_machine_mode full_mode) asm("_invalidate");
static void
invalidate(rtx x, n64_enum_machine_mode full_mode)
{
  register int i;
  register struct n64_tag_table_elt *p;
  rtx base;
  int start, end;







  if (((x)->code) == REG)
    {
      register int regno = ((x)->fld[0].rtint);
      register unsigned hash = (((x)->code) == REG && ((x)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((x)->fld[0].rtint)]) % 31 : canon_hash (x, ((x)->mode)) % 31);
      delete_reg_equiv (regno);
      reg_tick[regno]++;

      if (regno >= 68)
 {



   struct n64_tag_table_elt *elt;

   while (elt = lookup_for_remove (x, hash, ((x)->mode)))
     remove_from_table (elt, hash);
 }
      else
 {
   int in_table
     = ((hard_regs_in_table)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));
   int endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   int tregno, tendregno;
   register struct n64_tag_table_elt *p, *next;

   ((hard_regs_in_table)[(regno) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));

   for (i = regno + 1; i < endregno; i++)
     {
       in_table |= ((hard_regs_in_table)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
       ((hard_regs_in_table)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
       delete_reg_equiv (i);
       reg_tick[i]++;
     }

   if (in_table)
     for (hash = 0; hash < 31; hash++)
       for (p = table[hash]; p; p = next)
  {
    next = p->next_same_hash;

    if (((p->exp)->code) != REG
        || ((p->exp)->fld[0].rtint) >= 68)
      continue;

    tregno = ((p->exp)->fld[0].rtint);
    tendregno
      = tregno + (! ((unsigned) ((tregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((p->exp)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((p->exp)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
    if (tendregno > regno && tregno < endregno)
    remove_from_table (p, hash);
  }
 }

      return;
    }

  if (((x)->code) == SUBREG)
    {
      if (((((x)->fld[0].rtx))->code) != REG)
 abort ();
      invalidate (((x)->fld[0].rtx), VOIDmode);
      return;
    }





  if (((x)->code) != MEM)
    abort ();

  if (full_mode == VOIDmode)
    full_mode = ((x)->mode);

  set_nonvarying_address_components (((x)->fld[0].rtx), (mode_size[(int)(full_mode)]),
         &base, &start, &end);

  for (i = 0; i < 31; i++)
    {
      register struct n64_tag_table_elt *next;
      for (p = table[i]; p; p = next)
 {
   next = p->next_same_hash;
   if (refers_to_mem_p (p->exp, base, start, end))
     remove_from_table (p, i);
 }
    }
}






static void
remove_invalid_refs(int regno) asm("_remove_invalid_refs");
static void
remove_invalid_refs(int regno)
{
  register int i;
  register struct n64_tag_table_elt *p, *next;

  for (i = 0; i < 31; i++)
    for (p = table[i]; p; p = next)
      {
 next = p->next_same_hash;
 if (((p->exp)->code) != REG
     && refers_to_regno_p (regno, regno + 1, p->exp, ((void *)0)))
   remove_from_table (p, i);
      }
}






static void
rehash_using_reg(rtx x) asm("_rehash_using_reg");
static void
rehash_using_reg(rtx x)
{
  int i;
  struct n64_tag_table_elt *p, *next;
  unsigned hash;

  if (((x)->code) == SUBREG)
    x = ((x)->fld[0].rtx);




  if (((x)->code) != REG
      || reg_in_table[((x)->fld[0].rtint)] < 0
      || reg_in_table[((x)->fld[0].rtint)] != reg_tick[((x)->fld[0].rtint)])
    return;





  for (i = 0; i < 31; i++)
    for (p = table[i]; p; p = next)
      {
 next = p->next_same_hash;
 if (((p->exp)->code) != REG && reg_mentioned_p (x, p->exp)
     && exp_equiv_p (p->exp, p->exp, 1, 0)
     && i != (hash = safe_hash (p->exp, p->mode) % 31))
   {
     if (p->next_same_hash)
       p->next_same_hash->prev_same_hash = p->prev_same_hash;

     if (p->prev_same_hash)
       p->prev_same_hash->next_same_hash = p->next_same_hash;
     else
       table[i] = p->next_same_hash;

     p->next_same_hash = table[hash];
     p->prev_same_hash = 0;
     if (table[hash])
       table[hash]->prev_same_hash = p;
     table[hash] = p;
   }
      }
}




static void
invalidate_memory(struct n64_tag_write_data *writes) asm("_invalidate_memory");
static void
invalidate_memory(struct n64_tag_write_data *writes)
{
  register int i;
  register struct n64_tag_table_elt *p, *next;
  int all = writes->all;
  int nonscalar = writes->nonscalar;

  for (i = 0; i < 31; i++)
    for (p = table[i]; p; p = next)
      {
 next = p->next_same_hash;
 if (p->in_memory
     && (all
  || (nonscalar && p->in_struct)
  || cse_rtx_addr_varies_p (p->exp)))
   remove_from_table (p, i);
      }
}




static void
invalidate_for_call(void) asm("_invalidate_for_call");
static void
invalidate_for_call(void)
{
  int regno, endregno;
  int i;
  unsigned hash;
  struct n64_tag_table_elt *p, *next;
  int in_table = 0;






  for (regno = 0; regno < 68; regno++)
    if (((regs_invalidated_by_call)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
      {
 delete_reg_equiv (regno);
 if (reg_tick[regno] >= 0)
   reg_tick[regno]++;

 in_table |= (((hard_regs_in_table)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))) != 0);
      }





  if (in_table)
    for (hash = 0; hash < 31; hash++)
      for (p = table[hash]; p; p = next)
 {
   next = p->next_same_hash;

   if (((p->exp)->code) != REG
       || ((p->exp)->fld[0].rtint) >= 68)
     continue;

   regno = ((p->exp)->fld[0].rtint);
   endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((p->exp)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((p->exp)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

   for (i = regno; i < endregno; i++)
     if (((regs_invalidated_by_call)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)))))
       {
  remove_from_table (p, hash);
  break;
       }
 }
}







static rtx
use_related_value(rtx x, struct n64_tag_table_elt *elt) asm("_use_related_value");
static rtx
use_related_value(rtx x, struct n64_tag_table_elt *elt)
{
  register struct n64_tag_table_elt *relt = 0;
  register struct n64_tag_table_elt *p, *q;
  int offset;





  if (elt != 0 && elt->related_value != 0)
    relt = elt;
  else if (elt == 0 && ((x)->code) == CONST)
    {
      rtx subexp = get_related_value (x);
      if (subexp != 0)
 relt = lookup (subexp,
         safe_hash (subexp, ((subexp)->mode)) % 31,
         ((subexp)->mode));
    }

  if (relt == 0)
    return 0;




  p = relt;
  while (1)
    {
      if (rtx_equal_p (x, p->exp))
 q = 0;
      else
 for (q = p->first_same_value; q; q = q->next_same_value)
   if (((q->exp)->code) == REG)
     break;

      if (q)
 break;

      p = p->related_value;




      if (p == relt || p == 0)
 break;
    }

  if (q == 0)
    return 0;

  offset = (get_integer_term (x) - get_integer_term (p->exp));

  return plus_constant_wide (q->exp, (int) (offset));
}
static unsigned
canon_hash(rtx x, n64_enum_machine_mode mode) asm("_canon_hash");
static unsigned
canon_hash(rtx x, n64_enum_machine_mode mode)
{
  register int i, j;
  register unsigned hash = 0;
  register n64_enum_rtx_code code;
  register char *fmt;


 repeat:
  if (x == 0)
    return hash;

  code = ((x)->code);
  switch (code)
    {
    case REG:
      {
 register int regno = ((x)->fld[0].rtint);






 if (regno < 68
     && (global_regs[regno]







  ))
   {
     do_not_record = 1;
     return 0;
   }
 hash += ((unsigned) REG << 7) + (unsigned) reg_qty[regno];
 return hash;
      }

    case CONST_INT:
      {
 unsigned int tem = ((x)->fld[0].rtwint);
 hash += ((unsigned) CONST_INT << 7) + (unsigned) mode + tem;
 return hash;
      }

    case CONST_DOUBLE:


      hash += (unsigned) code + (unsigned) ((x)->mode);
      if (((x)->mode) != VOIDmode)
 for (i = 2; i < (rtx_length[(int)(CONST_DOUBLE)]); i++)
   {
     unsigned tem = ((x)->fld[i].rtint);
     hash += tem;
   }
      else
 hash += ((unsigned) ((x)->fld[2].rtwint)
   + (unsigned) ((x)->fld[3].rtwint));
      return hash;


    case LABEL_REF:
      hash
 += ((unsigned) LABEL_REF << 7) + (unsigned int) ((x)->fld[0].rtx);
      return hash;

    case SYMBOL_REF:
      hash
 += ((unsigned) SYMBOL_REF << 7) + (unsigned int) ((x)->fld[0].rtstr);
      return hash;

    case MEM:
      if (((x)->volatil))
 {
   do_not_record = 1;
   return 0;
 }
      if (! ((x)->unchanging))
 {
   hash_arg_in_memory = 1;
   if (((x)->in_struct)) hash_arg_in_struct = 1;
 }


      hash += (unsigned) MEM;
      x = ((x)->fld[0].rtx);
      goto repeat;

    case PRE_DEC:
    case PRE_INC:
    case POST_DEC:
    case POST_INC:
    case PC:
    case CC0:
    case CALL:
    case UNSPEC_VOLATILE:
      do_not_record = 1;
      return 0;

    case ASM_OPERANDS:
      if (((x)->volatil))
 {
   do_not_record = 1;
   return 0;
 }
    }

  i = (rtx_length[(int)(code)]) - 1;
  hash += (unsigned) code + (unsigned) ((x)->mode);
  fmt = (rtx_format[(int)(code)]);
  for (; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   rtx tem = ((x)->fld[i].rtx);




   if (i == 0)
     {
       x = tem;
       goto repeat;
     }
   hash += canon_hash (tem, 0);
 }
      else if (fmt[i] == 'E')
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   hash += canon_hash (((x)->fld[i].rtvec->elem[j].rtx), 0);
      else if (fmt[i] == 's')
 {
   register unsigned char *p = (unsigned char *) ((x)->fld[i].rtstr);
   if (p)
     while (*p)
       hash += *p++;
 }
      else if (fmt[i] == 'i')
 {
   register unsigned tem = ((x)->fld[i].rtint);
   hash += tem;
 }
      else
 abort ();
    }
  return hash;
}



static unsigned
safe_hash(rtx x, n64_enum_machine_mode mode) asm("_safe_hash");
static unsigned
safe_hash(rtx x, n64_enum_machine_mode mode)
{
  int save_do_not_record = do_not_record;
  int save_hash_arg_in_memory = hash_arg_in_memory;
  int save_hash_arg_in_struct = hash_arg_in_struct;
  unsigned hash = canon_hash (x, mode);
  hash_arg_in_memory = save_hash_arg_in_memory;
  hash_arg_in_struct = save_hash_arg_in_struct;
  do_not_record = save_do_not_record;
  return hash;
}
static int
exp_equiv_p(rtx x, rtx y, int validate, int equal_values) asm("_exp_equiv_p");
static int
exp_equiv_p(rtx x, rtx y, int validate, int equal_values)
{
  register int i, j;
  register n64_enum_rtx_code code;
  register char *fmt;



  if (x == y && !validate)
    return 1;
  if (x == 0 || y == 0)
    return x == y;

  code = ((x)->code);
  if (code != ((y)->code))
    {
      if (!equal_values)
 return 0;



      if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH) && ((y)->code) == REG
   && (reg_qty[((y)->fld[0].rtint)] != (((y)->fld[0].rtint)))
   && ((y)->mode) == qty_mode[reg_qty[((y)->fld[0].rtint)]]
   && rtx_equal_p (x, qty_const[reg_qty[((y)->fld[0].rtint)]])
   && (! validate || reg_in_table[((y)->fld[0].rtint)] == reg_tick[((y)->fld[0].rtint)]))
 return 1;

      if ((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH) && code == REG
   && (reg_qty[((x)->fld[0].rtint)] != (((x)->fld[0].rtint)))
   && ((x)->mode) == qty_mode[reg_qty[((x)->fld[0].rtint)]]
   && rtx_equal_p (y, qty_const[reg_qty[((x)->fld[0].rtint)]]))
 return 1;

      return 0;
    }


  if (((x)->mode) != ((y)->mode))
    return 0;

  switch (code)
    {
    case PC:
    case CC0:
      return x == y;

    case CONST_INT:
      return ((x)->fld[0].rtwint) == ((y)->fld[0].rtwint);

    case LABEL_REF:
      return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);

    case SYMBOL_REF:
      return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);

    case REG:
      {
 int regno = ((y)->fld[0].rtint);
 int endregno
   = regno + (regno >= 68 ? 1
       : (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((y)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((y)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))));
 int i;





 if (reg_qty[((x)->fld[0].rtint)] != reg_qty[regno])
   return 0;

 if (! validate)
   return 1;

 for (i = regno; i < endregno; i++)
   if (reg_in_table[i] != reg_tick[i])
     return 0;

 return 1;
      }


    case PLUS:
    case MULT:
    case AND:
    case IOR:
    case XOR:
    case NE:
    case EQ:
      return ((exp_equiv_p (((x)->fld[0].rtx), ((y)->fld[0].rtx), validate, equal_values)
        && exp_equiv_p (((x)->fld[1].rtx), ((y)->fld[1].rtx),
          validate, equal_values))
       || (exp_equiv_p (((x)->fld[0].rtx), ((y)->fld[1].rtx),
          validate, equal_values)
    && exp_equiv_p (((x)->fld[1].rtx), ((y)->fld[0].rtx),
      validate, equal_values)));
    }




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'e':
   if (! exp_equiv_p (((x)->fld[i].rtx), ((y)->fld[i].rtx), validate, equal_values))
     return 0;
   break;

 case 'E':
   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (! exp_equiv_p (((x)->fld[i].rtvec->elem[j].rtx), ((y)->fld[i].rtvec->elem[j].rtx),
          validate, equal_values))
       return 0;
   break;

 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
 break;

 case '0':
   break;

 default:
   abort ();
 }
      }

  return 1;
}





static int
refers_to_p(rtx x, rtx y) asm("_refers_to_p");
static int
refers_to_p(rtx x, rtx y)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

 repeat:
  if (x == y)
    return 1;
  if (x == 0 || y == 0)
    return 0;

  code = ((x)->code);


  if (code == ((y)->code))
    {
      if (exp_equiv_p (x, y, 0, 1))
 return 1;
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      {
 if (i == 0)
   {
     x = ((x)->fld[0].rtx);
     goto repeat;
   }
 else
   if (refers_to_p (((x)->fld[i].rtx), y))
     return 1;
      }
    else if (fmt[i] == 'E')
      {
 int j;
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   if (refers_to_p (((x)->fld[i].rtvec->elem[j].rtx), y))
     return 1;
      }

  return 0;
}
static void
set_nonvarying_address_components(rtx addr, int size, rtx *pbase, int *pstart, int *pend) asm("_set_nonvarying_address_components");
static void
set_nonvarying_address_components(rtx addr, int size, rtx *pbase, int *pstart, int *pend)
{
  rtx base;
  int start, end;

  base = addr;
  start = 0;
  end = 0;



  if (((base)->code) == REG
      && qty_const != 0
      && (reg_qty[((base)->fld[0].rtint)] != (((base)->fld[0].rtint)))
      && qty_mode[reg_qty[((base)->fld[0].rtint)]] == ((base)->mode)
      && qty_const[reg_qty[((base)->fld[0].rtint)]] != 0)
    base = qty_const[reg_qty[((base)->fld[0].rtint)]];
  else if (((base)->code) == PLUS
    && ((((base)->fld[1].rtx))->code) == CONST_INT
    && ((((base)->fld[0].rtx))->code) == REG
    && qty_const != 0
    && (reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)] != (((((base)->fld[0].rtx))->fld[0].rtint)))
    && (qty_mode[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]]
        == ((((base)->fld[0].rtx))->mode))
    && qty_const[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]])
    {
      start = ((((base)->fld[1].rtx))->fld[0].rtwint);
      base = qty_const[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]];
    }


  else if (((base)->code) == PLUS
    && ((((base)->fld[0].rtx))->code) == REG
    && ((((base)->fld[1].rtx))->code) == REG
    && qty_const != 0
    && (reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)] != (((((base)->fld[0].rtx))->fld[0].rtint)))
    && (qty_mode[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]]
        == ((((base)->fld[0].rtx))->mode))
    && qty_const[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]]
    && (reg_qty[((((base)->fld[1].rtx))->fld[0].rtint)] != (((((base)->fld[1].rtx))->fld[0].rtint)))
    && (qty_mode[reg_qty[((((base)->fld[1].rtx))->fld[0].rtint)]]
        == ((((base)->fld[1].rtx))->mode))
    && qty_const[reg_qty[((((base)->fld[1].rtx))->fld[0].rtint)]])
    {
      rtx tem = qty_const[reg_qty[((((base)->fld[1].rtx))->fld[0].rtint)]];
      base = qty_const[reg_qty[((((base)->fld[0].rtx))->fld[0].rtint)]];


      if (((base)->code) != CONST_INT)
 {
   if (((tem)->code) != CONST_INT)
     abort ();
   start = ((tem)->fld[0].rtwint);
 }
      else
 {
   start = ((base)->fld[0].rtwint);
   base = tem;
 }
    }




  while (1)
    {



      switch (((base)->code))
 {
 case LO_SUM:



   base = ((base)->fld[1].rtx);
   continue;

 case CONST:

   base = ((base)->fld[0].rtx);
   continue;

 case PLUS:
   if (((((base)->fld[1].rtx))->code) == CONST_INT)
     {
       start += ((((base)->fld[1].rtx))->fld[0].rtwint);
       base = ((base)->fld[0].rtx);
       continue;
     }
   break;

 case AND:


   if (((((base)->fld[1].rtx))->code) == CONST_INT
       && exact_log2_wide ((int) (- ((((base)->fld[1].rtx))->fld[0].rtwint))) > 0)
     {
       set_nonvarying_address_components (((base)->fld[0].rtx), size,
       pbase, pstart, pend);





       size = *pend - *pstart - ((((base)->fld[1].rtx))->fld[0].rtwint) - 1;
       start += *pstart + ((((base)->fld[1].rtx))->fld[0].rtwint) + 1;
       end += *pend;
       base = *pbase;
     }
   break;
 }

      break;
    }

  if (((base)->code) == CONST_INT)
    {
      start += ((base)->fld[0].rtwint);
      base = const0_rtx;
    }

  end = start + size;


  *pbase = base;
  *pstart = start;
  *pend = end;
}
static int
refers_to_mem_p(rtx x, rtx base, int start, int end) asm("_refers_to_mem_p");
static int
refers_to_mem_p(rtx x, rtx base, int start, int end)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

 repeat:
  if (x == 0)
    return 0;

  code = ((x)->code);
  if (code == MEM)
    {
      register rtx addr = ((x)->fld[0].rtx);
      rtx mybase;
      int mystart, myend;

      set_nonvarying_address_components (addr, (mode_size[(int)(((x)->mode))]),
      &mybase, &mystart, &myend);





      if (! rtx_equal_p (mybase, base))
 return 0;

      return myend > start && mystart < end;
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      {
 if (i == 0)
   {
     x = ((x)->fld[0].rtx);
     goto repeat;
   }
 else
   if (refers_to_mem_p (((x)->fld[i].rtx), base, start, end))
     return 1;
      }
    else if (fmt[i] == 'E')
      {
 int j;
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   if (refers_to_mem_p (((x)->fld[i].rtvec->elem[j].rtx), base, start, end))
     return 1;
      }

  return 0;
}





static int
cse_rtx_addr_varies_p(rtx x) asm("_cse_rtx_addr_varies_p");
static int
cse_rtx_addr_varies_p(rtx x)
{




  if (((x)->code) == MEM
      && ((((x)->fld[0].rtx))->code) == REG
      && (reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)] != (((((x)->fld[0].rtx))->fld[0].rtint)))
      && ((((x)->fld[0].rtx))->mode) == qty_mode[reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)]]
      && qty_const[reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)]] != 0)
    return 0;

  if (((x)->code) == MEM
      && ((((x)->fld[0].rtx))->code) == PLUS
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
      && (reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)] != (((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)))
      && (((((((x)->fld[0].rtx))->fld[0].rtx))->mode)
   == qty_mode[reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)]])
      && qty_const[reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)]])
    return 0;






  if (((x)->code) == MEM
      && ((((x)->fld[0].rtx))->code) == PLUS
      && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == REG
      && (reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)] != (((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)))
      && (((((((x)->fld[0].rtx))->fld[0].rtx))->mode)
   == qty_mode[reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)]])
      && qty_const[reg_qty[((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)]]
      && (reg_qty[((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtint)] != (((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtint)))
      && (((((((x)->fld[0].rtx))->fld[1].rtx))->mode)
   == qty_mode[reg_qty[((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtint)]])
      && qty_const[reg_qty[((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtint)]])
    return 0;

  return rtx_addr_varies_p (x);
}
static rtx
canon_reg(rtx x, rtx insn) asm("_canon_reg");
static rtx
canon_reg(rtx x, rtx insn)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0)
    return x;

  code = ((x)->code);
  switch (code)
    {
    case PC:
    case CC0:
    case CONST:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
      return x;

    case REG:
      {
 register int first;






 if (((x)->fld[0].rtint) < 68
     || ! (reg_qty[((x)->fld[0].rtint)] != (((x)->fld[0].rtint))))
   return x;

 first = qty_first_reg[reg_qty[((x)->fld[0].rtint)]];
 return (first >= 68 ? regno_reg_rtx[first]
  : mips_regno_to_class[ (first) ] == NO_REGS ? x
  : gen_rtx (REG, qty_mode[reg_qty[((x)->fld[0].rtint)]], first));
      }
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      register int j;

      if (fmt[i] == 'e')
 {
   rtx cxx_new = canon_reg (((x)->fld[i].rtx), insn);



   if (insn != 0 && cxx_new != 0
       && ((cxx_new)->code) == REG && ((((x)->fld[i].rtx))->code) == REG
       && (((((cxx_new)->fld[0].rtint) < 68)
     != (((((x)->fld[i].rtx))->fld[0].rtint) < 68))
    || insn_n_dups[recog_memoized (insn)] > 0))
     validate_change (insn, &((x)->fld[i].rtx), cxx_new, 1);
   else
     ((x)->fld[i].rtx) = cxx_new;
 }
      else if (fmt[i] == 'E')
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   ((x)->fld[i].rtvec->elem[j].rtx) = canon_reg (((x)->fld[i].rtvec->elem[j].rtx), insn);
    }

  return x;
}
static void
find_best_addr(rtx insn, rtx *loc) asm("_find_best_addr");
static void
find_best_addr(rtx insn, rtx *loc)
{
  struct n64_tag_table_elt *elt, *p;
  rtx addr = *loc;
  int our_cost;
  int found_better = 1;
  int save_do_not_record = do_not_record;
  int save_hash_arg_in_memory = hash_arg_in_memory;
  int save_hash_arg_in_struct = hash_arg_in_struct;
  int addr_volatile;
  int regno;
  unsigned hash;
  if ((((addr)->code) == PLUS
       && ((((addr)->fld[0].rtx))->code) == REG
       && ((((addr)->fld[1].rtx))->code) == CONST_INT
       && (regno = ((((addr)->fld[0].rtx))->fld[0].rtint),
    regno == (0 + 30) || regno == (0 + 30)
    || regno == 0))
      || (((addr)->code) == REG
   && (regno = ((addr)->fld[0].rtint), regno == (0 + 30)
       || regno == (0 + 30)
       || regno == 0))
      || ((((addr)->code) == LABEL_REF || ((addr)->code) == SYMBOL_REF || ((addr)->code) == CONST_INT || ((addr)->code) == HIGH || (((addr)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (addr)) && ! 0)) && (!0 || !0)))
    return;





  if (((addr)->code) != REG
      && validate_change (insn, loc, fold_rtx (addr, insn), 0))
    addr = *loc;




  do_not_record = 0;
  hash = (((addr)->code) == REG && ((addr)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((addr)->fld[0].rtint)]) % 31 : canon_hash (addr, ((target_flags & 0x00000002) ? DImode : SImode)) % 31);
  addr_volatile = do_not_record;
  do_not_record = save_do_not_record;
  hash_arg_in_memory = save_hash_arg_in_memory;
  hash_arg_in_struct = save_hash_arg_in_struct;

  if (addr_volatile)
    return;

  elt = lookup (addr, hash, ((target_flags & 0x00000002) ? DImode : SImode));
  if (elt)
    {





      for (p = elt->first_same_value; p; p = p->next_same_value)
 p->flag = 0;

      while (found_better)
 {
   int best_addr_cost = ((((*loc)->code) == REG) ? 1 : mips_address_cost (*loc));
   int best_rtx_cost = (elt->cost + 1) >> 1;
   struct n64_tag_table_elt *best_elt = elt;

   found_better = 0;
   for (p = elt->first_same_value; p; p = p->next_same_value)
     if (! p->flag
  && (((p->exp)->code) == REG
      || exp_equiv_p (p->exp, p->exp, 1, 0))
  && (((((p->exp)->code) == REG) ? 1 : mips_address_cost (p->exp)) < best_addr_cost
      || (((((p->exp)->code) == REG) ? 1 : mips_address_cost (p->exp)) == best_addr_cost
   && (p->cost + 1) >> 1 > best_rtx_cost)))
       {
  found_better = 1;
  best_addr_cost = ((((p->exp)->code) == REG) ? 1 : mips_address_cost (p->exp));
  best_rtx_cost = (p->cost + 1) >> 1;
  best_elt = p;
       }

   if (found_better)
     {
       if (validate_change (insn, loc,
       canon_reg (copy_rtx (best_elt->exp),
           (rtx) 0), 0))
  return;
       else
  best_elt->flag = 1;
     }
 }
    }
  if (flag_expensive_optimizations
      && ((rtx_class[(int)(((*loc)->code))]) == '2'
   || (rtx_class[(int)(((*loc)->code))]) == 'c')
      && ((((*loc)->fld[0].rtx))->code) == REG
      && ((((*loc)->fld[1].rtx))->code) == CONST_INT)
    {
      rtx c = ((*loc)->fld[1].rtx);

      do_not_record = 0;
      hash = (((((*loc)->fld[0].rtx))->code) == REG && ((((*loc)->fld[0].rtx))->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((((*loc)->fld[0].rtx))->fld[0].rtint)]) % 31 : canon_hash (((*loc)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode)) % 31);
      do_not_record = save_do_not_record;
      hash_arg_in_memory = save_hash_arg_in_memory;
      hash_arg_in_struct = save_hash_arg_in_struct;

      elt = lookup (((*loc)->fld[0].rtx), hash, ((target_flags & 0x00000002) ? DImode : SImode));
      if (elt == 0)
 return;






      for (p = elt->first_same_value; p; p = p->next_same_value)
 p->flag = 0;

      while (found_better)
 {
   int best_addr_cost = ((((*loc)->code) == REG) ? 1 : mips_address_cost (*loc));
   int best_rtx_cost = ((((*loc)->code) == REG ? (((((*loc)->volatil) && ((*loc)->fld[0].rtint) < 68) || ((((*loc)->fld[0].rtint)) == (0 + 30) || (((*loc)->fld[0].rtint)) == (0 + 30) || (((*loc)->fld[0].rtint)) == (0 + 29) || (((*loc)->fld[0].rtint)) == 0 || ((((*loc)->fld[0].rtint)) >= (68) && (((*loc)->fld[0].rtint)) <= (((68)) + 3)) || ((((*loc)->fld[0].rtint)) < 68 && ((((*loc)->fld[0].rtint)) == (0 + 30) || (((*loc)->fld[0].rtint)) == (0 + 30) || fixed_regs[((*loc)->fld[0].rtint)] || global_regs[((*loc)->fld[0].rtint)]) && mips_regno_to_class[ (((*loc)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((*loc)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (*loc, SET) * 2) + 1) >> 1;
   struct n64_tag_table_elt *best_elt = elt;
   rtx best_rtx = *loc;
   int count;






   found_better = 0;
   for (p = elt->first_same_value, count = 0;
        p && count < 32;
        p = p->next_same_value, count++)
     if (! p->flag
  && (((p->exp)->code) == REG
      || exp_equiv_p (p->exp, p->exp, 1, 0)))
       {
  rtx cxx_new = cse_gen_binary (((*loc)->code), ((target_flags & 0x00000002) ? DImode : SImode), p->exp, c);

  if ((((((cxx_new)->code) == REG) ? 1 : mips_address_cost (cxx_new)) < best_addr_cost
      || (((((cxx_new)->code) == REG) ? 1 : mips_address_cost (cxx_new)) == best_addr_cost
   && ((((cxx_new)->code) == REG ? (((((cxx_new)->volatil) && ((cxx_new)->fld[0].rtint) < 68) || ((((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 29) || (((cxx_new)->fld[0].rtint)) == 0 || ((((cxx_new)->fld[0].rtint)) >= (68) && (((cxx_new)->fld[0].rtint)) <= (((68)) + 3)) || ((((cxx_new)->fld[0].rtint)) < 68 && ((((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 30) || fixed_regs[((cxx_new)->fld[0].rtint)] || global_regs[((cxx_new)->fld[0].rtint)]) && mips_regno_to_class[ (((cxx_new)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((cxx_new)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (cxx_new, SET) * 2) + 1) >> 1 > best_rtx_cost)))
    {
      found_better = 1;
      best_addr_cost = ((((cxx_new)->code) == REG) ? 1 : mips_address_cost (cxx_new));
      best_rtx_cost = ((((cxx_new)->code) == REG ? (((((cxx_new)->volatil) && ((cxx_new)->fld[0].rtint) < 68) || ((((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 29) || (((cxx_new)->fld[0].rtint)) == 0 || ((((cxx_new)->fld[0].rtint)) >= (68) && (((cxx_new)->fld[0].rtint)) <= (((68)) + 3)) || ((((cxx_new)->fld[0].rtint)) < 68 && ((((cxx_new)->fld[0].rtint)) == (0 + 30) || (((cxx_new)->fld[0].rtint)) == (0 + 30) || fixed_regs[((cxx_new)->fld[0].rtint)] || global_regs[((cxx_new)->fld[0].rtint)]) && mips_regno_to_class[ (((cxx_new)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((cxx_new)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (cxx_new, SET) * 2) + 1) >> 1;
      best_elt = p;
      best_rtx = cxx_new;
    }
       }

   if (found_better)
     {
       if (validate_change (insn, loc,
       canon_reg (copy_rtx (best_rtx),
           (rtx) 0), 0))
  return;
       else
  best_elt->flag = 1;
     }
 }
    }

}
static n64_enum_rtx_code
find_comparison_args(n64_enum_rtx_code code, rtx *parg1, rtx *parg2, n64_enum_machine_mode *pmode1, n64_enum_machine_mode *pmode2) asm("_find_comparison_args");
static n64_enum_rtx_code
find_comparison_args(n64_enum_rtx_code code, rtx *parg1, rtx *parg2, n64_enum_machine_mode *pmode1, n64_enum_machine_mode *pmode2)
{
  rtx arg1, arg2;

  arg1 = *parg1, arg2 = *parg2;



  while (arg2 == (const_tiny_rtx[0][(int) (((arg1)->mode))]))
    {

      rtx x = 0;
      int reverse_code = 0;
      struct n64_tag_table_elt *p = 0;






      if (((arg1)->code) == COMPARE && arg2 == const0_rtx)
 x = arg1;




      else if ((rtx_class[(int)(((arg1)->code))]) == '<')
 {
   if (code == NE
       || ((mode_class[(int)(((arg1)->mode))]) == MODE_INT
    && code == LT && 1 == -1)




       )
     x = arg1;
   else if (code == EQ
     || ((mode_class[(int)(((arg1)->mode))]) == MODE_INT
         && code == GE && 1 == -1)




     )
     x = arg1, reverse_code = 1;
 }







      if (x == 0)


 p = lookup (arg1, safe_hash (arg1, ((arg1)->mode)) % 31,
      ((arg1)->mode));
      if (p) p = p->first_same_value;

      for (; p; p = p->next_same_value)
 {
   n64_enum_machine_mode inner_mode = ((p->exp)->mode);


   if (! exp_equiv_p (p->exp, p->exp, 1, 0))
     continue;

   if (((p->exp)->code) == COMPARE







       || ((code == NE
     || (code == LT
         && (mode_class[(int)(inner_mode)]) == MODE_INT
         && ((8 * mode_size[(int)(inner_mode)])
      <= 32)
         && (1
      & ((int) 1
         << ((8 * mode_size[(int)(inner_mode)]) - 1))))





     )
    && (rtx_class[(int)(((p->exp)->code))]) == '<'))
     {
       x = p->exp;
       break;
     }
   else if ((code == EQ
      || (code == GE
   && (mode_class[(int)(inner_mode)]) == MODE_INT
   && ((8 * mode_size[(int)(inner_mode)])
       <= 32)
   && (1
       & ((int) 1
          << ((8 * mode_size[(int)(inner_mode)]) - 1))))





      )
     && (rtx_class[(int)(((p->exp)->code))]) == '<')
     {
       reverse_code = 1;
       x = p->exp;
       break;
     }



   else if (((p->exp) == frame_pointer_rtx || (p->exp) == hard_frame_pointer_rtx || (p->exp) == virtual_stack_vars_rtx || (p->exp) == virtual_incoming_args_rtx || (((p->exp)->code) == PLUS && ((((p->exp)->fld[1].rtx))->code) == CONST_INT && (((p->exp)->fld[0].rtx) == frame_pointer_rtx || ((p->exp)->fld[0].rtx) == hard_frame_pointer_rtx || ((p->exp)->fld[0].rtx) == arg_pointer_rtx || ((p->exp)->fld[0].rtx) == virtual_stack_vars_rtx || ((p->exp)->fld[0].rtx) == virtual_incoming_args_rtx)) || (p->exp) == stack_pointer_rtx || (p->exp) == virtual_stack_dynamic_rtx || (p->exp) == virtual_outgoing_args_rtx || (((p->exp)->code) == PLUS && ((((p->exp)->fld[1].rtx))->code) == CONST_INT && (((p->exp)->fld[0].rtx) == stack_pointer_rtx || ((p->exp)->fld[0].rtx) == virtual_stack_dynamic_rtx || ((p->exp)->fld[0].rtx) == virtual_outgoing_args_rtx))))
     {
       arg1 = p->exp;
       continue;
     }
 }



      if (x == 0)
 break;

      arg1 = ((x)->fld[0].rtx), arg2 = ((x)->fld[1].rtx);
      if ((rtx_class[(int)(((x)->code))]) == '<')
 code = ((x)->code);

      if (reverse_code)
 code = reverse_condition (code);
    }



  *pmode1 = ((arg1)->mode), *pmode2 = ((arg2)->mode);
  *parg1 = fold_rtx (arg1, 0), *parg2 = fold_rtx (arg2, 0);

  return code;
}





rtx
simplify_unary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op, n64_enum_machine_mode op_mode) asm("_simplify_unary_operation");
rtx
simplify_unary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op, n64_enum_machine_mode op_mode)
{
  register int width = (8 * mode_size[(int)(mode)]);







  if (code == FLOAT && ((op)->mode) == VOIDmode
      && (((op)->code) == CONST_DOUBLE || ((op)->code) == CONST_INT))
    {
      int hv, lv;
      double d;

      if (((op)->code) == CONST_INT)
 lv = ((op)->fld[0].rtwint), hv = ((op)->fld[0].rtwint) < 0 ? -1 : 0;
      else
 lv = ((op)->fld[2].rtwint), hv = ((op)->fld[3].rtwint);


      ereal_from_int (&d, (int) (lv), (int) (hv));
      d = real_value_truncate (mode, d);
      return immed_real_const_1 (d, mode);
    }
  else if (code == UNSIGNED_FLOAT && ((op)->mode) == VOIDmode
    && (((op)->code) == CONST_DOUBLE || ((op)->code) == CONST_INT))
    {
      int hv, lv;
      double d;

      if (((op)->code) == CONST_INT)
 lv = ((op)->fld[0].rtwint), hv = ((op)->fld[0].rtwint) < 0 ? -1 : 0;
      else
 lv = ((op)->fld[2].rtwint), hv = ((op)->fld[3].rtwint);

      if (op_mode == VOIDmode)
 {


   if (hv < 0)
     return 0;
 }
      else if ((8 * mode_size[(int)(op_mode)]) >= 32 * 2)
 ;
      else
 hv = 0, lv &= (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1));


      (ereal_from_uint (&d, lv, hv));







      d = real_value_truncate (mode, d);
      return immed_real_const_1 (d, mode);
    }


  if (((op)->code) == CONST_INT
      && width <= 32 && width > 0)
    {
      register int arg0 = ((op)->fld[0].rtwint);
      register int val;

      switch (code)
 {
 case NOT:
   val = ~ arg0;
   break;

 case NEG:
   val = - arg0;
   break;

 case ABS:
   val = (arg0 >= 0 ? arg0 : - arg0);
   break;

 case FFS:


   arg0 &= (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1));
   val = exact_log2_wide ((int) (arg0 & (- arg0))) + 1;
   break;

 case TRUNCATE:
   val = arg0;
   break;

 case ZERO_EXTEND:
   if (op_mode == VOIDmode)
     op_mode = mode;
   if ((8 * mode_size[(int)(op_mode)]) == 32)
     {



       if (width != (8 * mode_size[(int)(op_mode)]))
  abort ();
       val = arg0;
     }
   else if ((8 * mode_size[(int)(op_mode)]) < 32)
     val = arg0 & ~((int) (-1) << (8 * mode_size[(int)(op_mode)]));
   else
     return 0;
   break;

 case SIGN_EXTEND:
   if (op_mode == VOIDmode)
     op_mode = mode;
   if ((8 * mode_size[(int)(op_mode)]) == 32)
     {



       if (width != (8 * mode_size[(int)(op_mode)]))
  abort ();
       val = arg0;
     }
   else if ((8 * mode_size[(int)(op_mode)]) < 32)
     {
       val
  = arg0 & ~((int) (-1) << (8 * mode_size[(int)(op_mode)]));
       if (val
    & ((int) 1 << ((8 * mode_size[(int)(op_mode)]) - 1)))
  val -= (int) 1 << (8 * mode_size[(int)(op_mode)]);
     }
   else
     return 0;
   break;

 case SQRT:
   return 0;

 default:
   abort ();
 }





      if (width < 32
   && ((val & ((int) (-1) << (width - 1)))
       != ((int) (-1) << (width - 1))))
 val &= ((int) 1 << width) - 1;

      return gen_rtx (CONST_INT, VOIDmode, (int) (val));
    }



  else if (((op)->mode) == VOIDmode && width <= 32 * 2
    && (((op)->code) == CONST_DOUBLE || ((op)->code) == CONST_INT))
    {
      int l1, h1, lv, hv;

      if (((op)->code) == CONST_DOUBLE)
 l1 = ((op)->fld[2].rtwint), h1 = ((op)->fld[3].rtwint);
      else
 l1 = ((op)->fld[0].rtwint), h1 = l1 < 0 ? -1 : 0;

      switch (code)
 {
 case NOT:
   lv = ~ l1;
   hv = ~ h1;
   break;

 case NEG:
   neg_double (l1, h1, &lv, &hv);
   break;

 case ABS:
   if (h1 < 0)
     neg_double (l1, h1, &lv, &hv);
   else
     lv = l1, hv = h1;
   break;

 case FFS:
   hv = 0;
   if (l1 == 0)
     lv = 32 + exact_log2_wide ((int) (h1 & (-h1))) + 1;
   else
     lv = exact_log2_wide ((int) (l1 & (-l1))) + 1;
   break;

 case TRUNCATE:

   lv = l1, hv = h1;
   break;

 case ZERO_EXTEND:
   if (op_mode == VOIDmode
       || (8 * mode_size[(int)(op_mode)]) > 32)
     return 0;

   hv = 0;
   lv = l1 & (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1));
   break;

 case SIGN_EXTEND:
   if (op_mode == VOIDmode
       || (8 * mode_size[(int)(op_mode)]) > 32)
     return 0;
   else
     {
       lv = l1 & (((8 * mode_size[(int)(op_mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(op_mode)])) - 1));
       if ((8 * mode_size[(int)(op_mode)]) < 32
    && (lv & ((int) 1
       << ((8 * mode_size[(int)(op_mode)]) - 1))) != 0)
  lv -= (int) 1 << (8 * mode_size[(int)(op_mode)]);

       hv = (lv < 0) ? ~ (int) 0 : 0;
     }
   break;

 case SQRT:
   return 0;

 default:
   return 0;
 }

      return immed_double_const (lv, hv, mode);
    }


  else if (((op)->code) == CONST_DOUBLE
    && (mode_class[(int)(mode)]) == MODE_FLOAT)
    {
      double d;
      jmp_buf handler;
      rtx x;

      if (
         _setjmp3((
         handler
         ), ((void *)0))
                         )



 return 0;

      set_float_handler (handler);

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);

      switch (code)
 {
 case NEG:
   d = ereal_negate (d);
   break;

 case ABS:
   if ((target_negative (d)))
     d = ereal_negate (d);
   break;

 case FLOAT_TRUNCATE:
   d = real_value_truncate (mode, d);
   break;

 case FLOAT_EXTEND:

   break;

 case FIX:
   d = (etrunci (d));
   break;

 case UNSIGNED_FIX:
   d = (etruncui (d));
   break;

 case SQRT:
   return 0;

 default:
   abort ();
 }

      x = immed_real_const_1 (d, mode);
      set_float_handler (((void *)0));
      return x;
    }

  else if (((op)->code) == CONST_DOUBLE
    && (mode_class[(int)(((op)->mode))]) == MODE_FLOAT
    && (mode_class[(int)(mode)]) == MODE_INT
    && width <= 32 && width > 0)
    {
      double d;
      jmp_buf handler;
      int val;

      if (
         _setjmp3((
         handler
         ), ((void *)0))
                         )
 return 0;

      set_float_handler (handler);

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);

      switch (code)
 {
 case FIX:
   val = (efixi (d));
   break;

 case UNSIGNED_FIX:
   val = (efixui (d));
   break;

 default:
   abort ();
 }

      set_float_handler (((void *)0));





      if (width < 32
   && ((val & ((int) (-1) << (width - 1)))
       != ((int) (-1) << (width - 1))))
 val &= ((int) 1 << width) - 1;
      if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
   && (val & ((int) 1 << (width - 1))))
 val |= ((int) (-1) << width);

      return gen_rtx (CONST_INT, VOIDmode, (int) (val));
    }



  else
    {


      switch (code)
 {
 case NEG:
 case NOT:

   if (((op)->code) == code)
     return ((op)->fld[0].rtx);
   break;

 case SIGN_EXTEND:




   if (((op)->code) == TRUNCATE
       && ((((op)->fld[0].rtx))->mode) == mode
       && ((((op)->fld[0].rtx))->code) == MINUS
       && ((((((op)->fld[0].rtx))->fld[0].rtx))->code) == LABEL_REF
       && ((((((op)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF)
     return ((op)->fld[0].rtx);







   break;
 }

      return 0;
    }
}







rtx
simplify_binary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1) asm("_simplify_binary_operation");
rtx
simplify_binary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1)
{
  register int arg0, arg1, arg0s, arg1s;
  int val;
  int width = (8 * mode_size[(int)(mode)]);
  rtx tem;






  if ((rtx_class[(int)(code)]) == '<')
    abort ();


  if ((mode_class[(int)(mode)]) == MODE_FLOAT
      && ((op0)->code) == CONST_DOUBLE && ((op1)->code) == CONST_DOUBLE
      && mode == ((op0)->mode) && mode == ((op1)->mode))
    {
      double f0, f1, value;
      jmp_buf handler;

      if (
         _setjmp3((
         handler
         ), ((void *)0))
                         )
 return 0;

      set_float_handler (handler);

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op0))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op0))->fld[3].rtwint),(sizeof u) / 2); f0 = u.d; } while (0);
      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op1))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op1))->fld[3].rtwint),(sizeof u) / 2); f1 = u.d; } while (0);
      f0 = real_value_truncate (mode, f0);
      f1 = real_value_truncate (mode, f1);


      earith (&(value), (rtx_to_tree_code (code)), &(f0), &(f1));
      value = real_value_truncate (mode, value);
      set_float_handler (((void *)0));
      return immed_real_const_1 (value, mode);
    }



  if ((mode_class[(int)(mode)]) == MODE_INT
      && width == 32 * 2
      && (((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST_INT)
      && (((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST_INT))
    {
      int l1, l2, h1, h2, lv, hv;

      if (((op0)->code) == CONST_DOUBLE)
 l1 = ((op0)->fld[2].rtwint), h1 = ((op0)->fld[3].rtwint);
      else
 l1 = ((op0)->fld[0].rtwint), h1 = l1 < 0 ? -1 : 0;

      if (((op1)->code) == CONST_DOUBLE)
 l2 = ((op1)->fld[2].rtwint), h2 = ((op1)->fld[3].rtwint);
      else
 l2 = ((op1)->fld[0].rtwint), h2 = l2 < 0 ? -1 : 0;

      switch (code)
 {
 case MINUS:

   neg_double (l2, h2, &lv, &hv);
   l2 = lv, h2 = hv;



 case PLUS:
   add_double (l1, h1, l2, h2, &lv, &hv);
   break;

 case MULT:
   mul_double (l1, h1, l2, h2, &lv, &hv);
   break;

 case DIV: case MOD: case UDIV: case UMOD:


   return 0;

 case AND:
   lv = l1 & l2, hv = h1 & h2;
   break;

 case IOR:
   lv = l1 | l2, hv = h1 | h2;
   break;

 case XOR:
   lv = l1 ^ l2, hv = h1 ^ h2;
   break;

 case SMIN:
   if (h1 < h2
       || (h1 == h2
    && ((unsigned int) l1
        < (unsigned int) l2)))
     lv = l1, hv = h1;
   else
     lv = l2, hv = h2;
   break;

 case SMAX:
   if (h1 > h2
       || (h1 == h2
    && ((unsigned int) l1
        > (unsigned int) l2)))
     lv = l1, hv = h1;
   else
     lv = l2, hv = h2;
   break;

 case UMIN:
   if ((unsigned int) h1 < (unsigned int) h2
       || (h1 == h2
    && ((unsigned int) l1
        < (unsigned int) l2)))
     lv = l1, hv = h1;
   else
     lv = l2, hv = h2;
   break;

 case UMAX:
   if ((unsigned int) h1 > (unsigned int) h2
       || (h1 == h2
    && ((unsigned int) l1
        > (unsigned int) l2)))
     lv = l1, hv = h1;
   else
     lv = l2, hv = h2;
   break;

 case LSHIFTRT: case ASHIFTRT:
 case ASHIFT:
 case ROTATE: case ROTATERT:

   if (1)
     l2 &= ((8 * mode_size[(int)(mode)]) - 1), h2 = 0;


   if (h2 != 0 || l2 < 0 || l2 >= (8 * mode_size[(int)(mode)]))
     return 0;

   if (code == LSHIFTRT || code == ASHIFTRT)
     rshift_double (l1, h1, l2, (8 * mode_size[(int)(mode)]), &lv, &hv,
      code == ASHIFTRT);
   else if (code == ASHIFT)
     lshift_double (l1, h1, l2, (8 * mode_size[(int)(mode)]), &lv, &hv, 1);
   else if (code == ROTATE)
     lrotate_double (l1, h1, l2, (8 * mode_size[(int)(mode)]), &lv, &hv);
   else
     rrotate_double (l1, h1, l2, (8 * mode_size[(int)(mode)]), &lv, &hv);
   break;

 default:
   return 0;
 }

      return immed_double_const (lv, hv, mode);
    }

  if (((op0)->code) != CONST_INT || ((op1)->code) != CONST_INT
      || width > 32 || width == 0)
    {



      switch (code)
 {
 case PLUS:


   if (1 == 1
       && ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) && ! flag_fast_math)
     break;

   if (op1 == (const_tiny_rtx[0][(int) (mode)]))
     return op0;


   if (((op0)->code) == NEG)
     return cse_gen_binary (MINUS, mode, op1, ((op0)->fld[0].rtx));
   else if (((op1)->code) == NEG)
     return cse_gen_binary (MINUS, mode, op0, ((op1)->fld[0].rtx));







   if ((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ((op0)->mode) != VOIDmode
       && ((op1)->code) == CONST_INT)
     return plus_constant_wide (op0, (int) (((op1)->fld[0].rtwint)));
   else if ((((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH) && ((op1)->mode) != VOIDmode
     && ((op0)->code) == CONST_INT)
     return plus_constant_wide (op1, (int) (((op0)->fld[0].rtwint)));







   if (! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT))
     {
       int coeff0 = 1, coeff1 = 1;
       rtx lhs = op0, rhs = op1;
       int had_mult = 0;

       if (((lhs)->code) == NEG)
  coeff0 = -1, lhs = ((lhs)->fld[0].rtx);
       else if (((lhs)->code) == MULT
         && ((((lhs)->fld[1].rtx))->code) == CONST_INT)
  {
    coeff0 = ((((lhs)->fld[1].rtx))->fld[0].rtwint), lhs = ((lhs)->fld[0].rtx);
    had_mult = 1;
  }
       else if (((lhs)->code) == ASHIFT
         && ((((lhs)->fld[1].rtx))->code) == CONST_INT
         && ((((lhs)->fld[1].rtx))->fld[0].rtwint) >= 0
         && ((((lhs)->fld[1].rtx))->fld[0].rtwint) < 32)
  {
    coeff0 = ((int) 1) << ((((lhs)->fld[1].rtx))->fld[0].rtwint);
    lhs = ((lhs)->fld[0].rtx);
  }

       if (((rhs)->code) == NEG)
  coeff1 = -1, rhs = ((rhs)->fld[0].rtx);
       else if (((rhs)->code) == MULT
         && ((((rhs)->fld[1].rtx))->code) == CONST_INT)
  {
    coeff1 = ((((rhs)->fld[1].rtx))->fld[0].rtwint), rhs = ((rhs)->fld[0].rtx);
    had_mult = 1;
  }
       else if (((rhs)->code) == ASHIFT
         && ((((rhs)->fld[1].rtx))->code) == CONST_INT
         && ((((rhs)->fld[1].rtx))->fld[0].rtwint) >= 0
         && ((((rhs)->fld[1].rtx))->fld[0].rtwint) < 32)
  {
    coeff1 = ((int) 1) << ((((rhs)->fld[1].rtx))->fld[0].rtwint);
    rhs = ((rhs)->fld[0].rtx);
  }

       if (rtx_equal_p (lhs, rhs))
  {
    tem = cse_gen_binary (MULT, mode, lhs,
     gen_rtx (CONST_INT, VOIDmode, (int) (coeff0 + coeff1)));
    return (((tem)->code) == MULT && ! had_mult) ? 0 : tem;
  }
     }







   if (((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT)
       && (((op0)->code) == PLUS || ((op0)->code) == MINUS
    || ((op1)->code) == PLUS || ((op1)->code) == MINUS)
       && (tem = simplify_plus_minus (code, mode, op0, op1)) != 0)
     return tem;
   break;

 case COMPARE:
   break;

 case MINUS:


   if (1 == 1
       && ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) && ! flag_fast_math)
     break;




   if (rtx_equal_p (op0, op1)
       && ! side_effects_p (op0)
       && (! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) || flag_fast_math))
     return (const_tiny_rtx[0][(int) (mode)]);


   if (op0 == (const_tiny_rtx[0][(int) (mode)]))
     return gen_rtx (NEG, mode, op1);


   if (op0 == constm1_rtx)
     return gen_rtx (NOT, mode, op1);


   if (op1 == (const_tiny_rtx[0][(int) (mode)]))
     return op0;







   if (! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT))
     {
       int coeff0 = 1, coeff1 = 1;
       rtx lhs = op0, rhs = op1;
       int had_mult = 0;

       if (((lhs)->code) == NEG)
  coeff0 = -1, lhs = ((lhs)->fld[0].rtx);
       else if (((lhs)->code) == MULT
         && ((((lhs)->fld[1].rtx))->code) == CONST_INT)
  {
    coeff0 = ((((lhs)->fld[1].rtx))->fld[0].rtwint), lhs = ((lhs)->fld[0].rtx);
    had_mult = 1;
  }
       else if (((lhs)->code) == ASHIFT
         && ((((lhs)->fld[1].rtx))->code) == CONST_INT
         && ((((lhs)->fld[1].rtx))->fld[0].rtwint) >= 0
         && ((((lhs)->fld[1].rtx))->fld[0].rtwint) < 32)
  {
    coeff0 = ((int) 1) << ((((lhs)->fld[1].rtx))->fld[0].rtwint);
    lhs = ((lhs)->fld[0].rtx);
  }

       if (((rhs)->code) == NEG)
  coeff1 = - 1, rhs = ((rhs)->fld[0].rtx);
       else if (((rhs)->code) == MULT
         && ((((rhs)->fld[1].rtx))->code) == CONST_INT)
  {
    coeff1 = ((((rhs)->fld[1].rtx))->fld[0].rtwint), rhs = ((rhs)->fld[0].rtx);
    had_mult = 1;
  }
       else if (((rhs)->code) == ASHIFT
         && ((((rhs)->fld[1].rtx))->code) == CONST_INT
         && ((((rhs)->fld[1].rtx))->fld[0].rtwint) >= 0
         && ((((rhs)->fld[1].rtx))->fld[0].rtwint) < 32)
  {
    coeff1 = ((int) 1) << ((((rhs)->fld[1].rtx))->fld[0].rtwint);
    rhs = ((rhs)->fld[0].rtx);
  }

       if (rtx_equal_p (lhs, rhs))
  {
    tem = cse_gen_binary (MULT, mode, lhs,
     gen_rtx (CONST_INT, VOIDmode, (int) (coeff0 - coeff1)));
    return (((tem)->code) == MULT && ! had_mult) ? 0 : tem;
  }
     }


   if (((op1)->code) == NEG)
     return cse_gen_binary (PLUS, mode, op0, ((op1)->fld[0].rtx));







   if (((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT)
       && (((op0)->code) == PLUS || ((op0)->code) == MINUS
    || ((op1)->code) == PLUS || ((op1)->code) == MINUS)
       && (tem = simplify_plus_minus (code, mode, op0, op1)) != 0)
     return tem;


   if (((op1)->code) == CONST_INT && ((op0)->mode) != VOIDmode)
     return plus_constant_wide (op0, (int) (- ((op1)->fld[0].rtwint)));


   if (((op1)->code) == AND)
     {
      if (rtx_equal_p (op0, ((op1)->fld[0].rtx)))
        return cse_gen_binary (AND, mode, op0, gen_rtx (NOT, mode, ((op1)->fld[1].rtx)));
      if (rtx_equal_p (op0, ((op1)->fld[1].rtx)))
        return cse_gen_binary (AND, mode, op0, gen_rtx (NOT, mode, ((op1)->fld[0].rtx)));
    }
   break;

 case MULT:
   if (op1 == constm1_rtx)
     {
       tem = simplify_unary_operation (NEG, mode, op0, mode);

       return tem ? tem : gen_rtx (NEG, mode, op0);
     }


   if ((1 != 1
        || ! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) || flag_fast_math)
       && op1 == (const_tiny_rtx[0][(int) (mode)])
       && ! side_effects_p (op0))
     return op1;




   if (op1 == (const_tiny_rtx[1][(int) (mode)]))
     return op0;



   if (((op1)->code) == CONST_INT
       && (val = exact_log2_wide ((int) (((op1)->fld[0].rtwint)))) >= 0
       && ! rtx_equal_function_value_matters)
     return gen_rtx (ASHIFT, mode, op0, gen_rtx (CONST_INT, VOIDmode, (int) (val)));

   if (((op1)->code) == CONST_DOUBLE
       && (mode_class[(int)(((op1)->mode))]) == MODE_FLOAT)
     {
       double d;
       jmp_buf handler;
       int op1is2, op1ism1;

       if (
          _setjmp3((
          handler
          ), ((void *)0))
                          )
  return 0;

       set_float_handler (handler);
       do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op1))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op1))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
       op1is2 = (ereal_cmp ((d), (dconst2)) == 0);
       op1ism1 = (ereal_cmp ((d), (dconstm1)) == 0);
       set_float_handler (((void *)0));


       if (op1is2 && ((op0)->mode) == mode)
  return gen_rtx (PLUS, mode, op0, copy_rtx (op0));

       else if (op1ism1 && ((op0)->mode) == mode)
  return gen_rtx (NEG, mode, op0);
     }
   break;

 case IOR:
   if (op1 == const0_rtx)
     return op0;
   if (((op1)->code) == CONST_INT
       && (((op1)->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
     return op1;
   if (rtx_equal_p (op0, op1) && ! side_effects_p (op0))
     return op0;

   if (((((op0)->code) == NOT && rtx_equal_p (((op0)->fld[0].rtx), op1))
        || (((op1)->code) == NOT && rtx_equal_p (((op1)->fld[0].rtx), op0)))
       && ! side_effects_p (op0)
       && (mode_class[(int)(mode)]) != MODE_CC)
     return constm1_rtx;
   break;

 case XOR:
   if (op1 == const0_rtx)
     return op0;
   if (((op1)->code) == CONST_INT
       && (((op1)->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
     return gen_rtx (NOT, mode, op0);
   if (op0 == op1 && ! side_effects_p (op0)
       && (mode_class[(int)(mode)]) != MODE_CC)
     return const0_rtx;
   break;

 case AND:
   if (op1 == const0_rtx && ! side_effects_p (op0))
     return const0_rtx;
   if (((op1)->code) == CONST_INT
       && (((op1)->fld[0].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)))
     return op0;
   if (op0 == op1 && ! side_effects_p (op0)
       && (mode_class[(int)(mode)]) != MODE_CC)
     return op0;

   if (((((op0)->code) == NOT && rtx_equal_p (((op0)->fld[0].rtx), op1))
        || (((op1)->code) == NOT && rtx_equal_p (((op1)->fld[0].rtx), op0)))
       && ! side_effects_p (op0)
       && (mode_class[(int)(mode)]) != MODE_CC)
     return const0_rtx;
   break;

 case UDIV:


   if (((op1)->code) == CONST_INT
       && (arg1 = exact_log2_wide ((int) (((op1)->fld[0].rtwint)))) > 0)
     return gen_rtx (LSHIFTRT, mode, op0, gen_rtx (CONST_INT, VOIDmode, (int) (arg1)));



 case DIV:
   if (op1 == (const_tiny_rtx[1][(int) (mode)]))
     return op0;


   if ((1 != 1
        || ! ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT) || flag_fast_math)
       && op0 == (const_tiny_rtx[0][(int) (mode)])
       && ! side_effects_p (op1))
     return op0;





   else if (((op1)->code) == CONST_DOUBLE
     && (mode_class[(int)(((op1)->mode))]) == MODE_FLOAT
     && op1 != (const_tiny_rtx[0][(int) (mode)])
     && flag_fast_math)
     {
       double d;
       do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op1))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op1))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);

       if (! (ereal_cmp ((d), (dconst0)) == 0))
  {

    earith (&(d), (rtx_to_tree_code (DIV)), &(dconst1), &(d));
    return gen_rtx (MULT, mode, op0,
      immed_real_const_1 (d, mode));




  }
     }

   break;

 case UMOD:

   if (((op1)->code) == CONST_INT
       && exact_log2_wide ((int) (((op1)->fld[0].rtwint))) > 0)
     return gen_rtx (AND, mode, op0, gen_rtx (CONST_INT, VOIDmode, (int) (((op1)->fld[0].rtwint) - 1)));



 case MOD:
   if ((op0 == const0_rtx || op1 == const1_rtx)
       && ! side_effects_p (op0) && ! side_effects_p (op1))
     return const0_rtx;
   break;

 case ROTATERT:
 case ROTATE:

   if (((op0)->code) == CONST_INT && width <= 32
       && ((op0)->fld[0].rtwint) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
       && ! side_effects_p (op1))
     return op0;



 case ASHIFT:
 case ASHIFTRT:
 case LSHIFTRT:
   if (op1 == const0_rtx)
     return op0;
   if (op0 == const0_rtx && ! side_effects_p (op1))
     return op0;
   break;

 case SMIN:
   if (width <= 32 && ((op1)->code) == CONST_INT
       && ((op1)->fld[0].rtwint) == (int) 1 << (width -1)
       && ! side_effects_p (op0))
     return op1;
   else if (rtx_equal_p (op0, op1) && ! side_effects_p (op0))
     return op0;
   break;

 case SMAX:
   if (width <= 32 && ((op1)->code) == CONST_INT
       && (((op1)->fld[0].rtwint)
    == (unsigned int) (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)) >> 1)
       && ! side_effects_p (op0))
     return op1;
   else if (rtx_equal_p (op0, op1) && ! side_effects_p (op0))
     return op0;
   break;

 case UMIN:
   if (op1 == const0_rtx && ! side_effects_p (op0))
     return op1;
   else if (rtx_equal_p (op0, op1) && ! side_effects_p (op0))
     return op0;
   break;

 case UMAX:
   if (op1 == constm1_rtx && ! side_effects_p (op0))
     return op1;
   else if (rtx_equal_p (op0, op1) && ! side_effects_p (op0))
     return op0;
   break;

 default:
   abort ();
 }

      return 0;
    }




  arg0 = ((op0)->fld[0].rtwint);
  arg1 = ((op1)->fld[0].rtwint);

  if (width < 32)
    {
      arg0 &= ((int) 1 << width) - 1;
      arg1 &= ((int) 1 << width) - 1;

      arg0s = arg0;
      if (arg0s & ((int) 1 << (width - 1)))
 arg0s |= ((int) (-1) << width);

      arg1s = arg1;
      if (arg1s & ((int) 1 << (width - 1)))
 arg1s |= ((int) (-1) << width);
    }
  else
    {
      arg0s = arg0;
      arg1s = arg1;
    }



  switch (code)
    {
    case PLUS:
      val = arg0s + arg1s;
      break;

    case MINUS:
      val = arg0s - arg1s;
      break;

    case MULT:
      val = arg0s * arg1s;
      break;

    case DIV:
      if (arg1s == 0)
 return 0;
      val = arg0s / arg1s;
      break;

    case MOD:
      if (arg1s == 0)
 return 0;
      val = arg0s % arg1s;
      break;

    case UDIV:
      if (arg1 == 0)
 return 0;
      val = (unsigned int) arg0 / arg1;
      break;

    case UMOD:
      if (arg1 == 0)
 return 0;
      val = (unsigned int) arg0 % arg1;
      break;

    case AND:
      val = arg0 & arg1;
      break;

    case IOR:
      val = arg0 | arg1;
      break;

    case XOR:
      val = arg0 ^ arg1;
      break;

    case LSHIFTRT:


      if (arg1 < 0)
 return 0;


      if (1)
 arg1 %= width;


      val = ((unsigned int) arg0) >> arg1;
      break;

    case ASHIFT:
      if (arg1 < 0)
 return 0;


      if (1)
 arg1 %= width;


      val = ((unsigned int) arg0) << arg1;
      break;

    case ASHIFTRT:
      if (arg1 < 0)
 return 0;


      if (1)
 arg1 %= width;


      val = arg0s >> arg1;



      if (arg0s < 0 && arg1 > 0)
 val |= ((int) -1) << (32 - arg1);

      break;

    case ROTATERT:
      if (arg1 < 0)
 return 0;

      arg1 %= width;
      val = ((((unsigned int) arg0) << (width - arg1))
      | (((unsigned int) arg0) >> arg1));
      break;

    case ROTATE:
      if (arg1 < 0)
 return 0;

      arg1 %= width;
      val = ((((unsigned int) arg0) << arg1)
      | (((unsigned int) arg0) >> (width - arg1)));
      break;

    case COMPARE:

      return 0;

    case SMIN:
      val = arg0s <= arg1s ? arg0s : arg1s;
      break;

    case UMIN:
      val = ((unsigned int) arg0
      <= (unsigned int) arg1 ? arg0 : arg1);
      break;

    case SMAX:
      val = arg0s > arg1s ? arg0s : arg1s;
      break;

    case UMAX:
      val = ((unsigned int) arg0
      > (unsigned int) arg1 ? arg0 : arg1);
      break;

    default:
      abort ();
    }




  if (width < 32
      && ((val & ((int) (-1) << (width - 1)))
   != ((int) (-1) << (width - 1))))
    val &= ((int) 1 << width) - 1;
  if (((target_flags & 0x00002000) ? 64 : 32) < 32 && ((target_flags & 0x00002000) ? 64 : 32) == width
      && (val & ((int) 1 << (width - 1))))
    val |= ((int) (-1) << width);

  return gen_rtx (CONST_INT, VOIDmode, (int) (val));
}
static rtx
simplify_plus_minus(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1) asm("_simplify_plus_minus");
static rtx
simplify_plus_minus(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1)
{
  rtx ops[8];
  int negs[8];
  rtx result, tem;
  int n_ops = 2, input_ops = 2, input_consts = 0, n_consts = 0;
  int first = 1, negate = 0, changed;
  int i, j;

  memset ((char *) ops,0,sizeof ops);





  ops[0] = op0, ops[1] = op1, negs[0] = 0, negs[1] = (code == MINUS);

  changed = 1;
  while (changed)
    {
      changed = 0;

      for (i = 0; i < n_ops; i++)
 switch (((ops[i])->code))
   {
   case PLUS:
   case MINUS:
     if (n_ops == 7)
       return 0;

     ops[n_ops] = ((ops[i])->fld[1].rtx);
     negs[n_ops++] = ((ops[i])->code) == MINUS ? !negs[i] : negs[i];
     ops[i] = ((ops[i])->fld[0].rtx);
     input_ops++;
     changed = 1;
     break;

   case NEG:
     ops[i] = ((ops[i])->fld[0].rtx);
     negs[i] = ! negs[i];
     changed = 1;
     break;

   case CONST:
     ops[i] = ((ops[i])->fld[0].rtx);
     input_consts++;
     changed = 1;
     break;

   case NOT:

     if (n_ops != 7)
       {
  ops[n_ops] = constm1_rtx;
  negs[n_ops++] = negs[i];
  ops[i] = ((ops[i])->fld[0].rtx);
  negs[i] = ! negs[i];
  changed = 1;
       }
     break;

   case CONST_INT:
     if (negs[i])
       ops[i] = gen_rtx (CONST_INT, VOIDmode, (int) (- ((ops[i])->fld[0].rtwint))), negs[i] = 0, changed = 1;
     break;
   }
    }


  if (n_ops <= 2)
    return 0;




  changed = 1;
  while (changed)
    {
      changed = first;

      for (i = 0; i < n_ops - 1; i++)
 for (j = i + 1; j < n_ops; j++)
   if (ops[i] != 0 && ops[j] != 0
       && (! first || ((((ops[i])->code) == LABEL_REF || ((ops[i])->code) == SYMBOL_REF || ((ops[i])->code) == CONST_INT || ((ops[i])->code) == CONST_DOUBLE || ((ops[i])->code) == CONST || ((ops[i])->code) == HIGH) && (((ops[j])->code) == LABEL_REF || ((ops[j])->code) == SYMBOL_REF || ((ops[j])->code) == CONST_INT || ((ops[j])->code) == CONST_DOUBLE || ((ops[j])->code) == CONST || ((ops[j])->code) == HIGH))))
     {
       rtx lhs = ops[i], rhs = ops[j];
       n64_enum_rtx_code ncode = PLUS;

       if (negs[i] && ! negs[j])
  lhs = ops[j], rhs = ops[i], ncode = MINUS;
       else if (! negs[i] && negs[j])
  ncode = MINUS;

       tem = simplify_binary_operation (ncode, mode, lhs, rhs);
       if (tem)
  {
    ops[i] = tem, ops[j] = 0;
    negs[i] = negs[i] && negs[j];
    if (((tem)->code) == NEG)
      ops[i] = ((tem)->fld[0].rtx), negs[i] = ! negs[i];

    if (((ops[i])->code) == CONST_INT && negs[i])
      ops[i] = gen_rtx (CONST_INT, VOIDmode, (int) (- ((ops[i])->fld[0].rtwint))), negs[i] = 0;
    changed = 1;
  }
     }

      first = 0;
    }







  for (i = 0, j = 0; j < n_ops; j++)
    if (ops[j] != 0)
      {
 ops[i] = ops[j], negs[i++] = negs[j];
 if (((ops[j])->code) == CONST)
   n_consts++;
      }

  if (i + n_consts > input_ops
      || (i + n_consts == input_ops && n_consts <= input_consts))
    return 0;

  n_ops = i;


  for (i = 0; i < n_ops - 1; i++)
    if (((ops[i])->code) == CONST_INT)
      {
 tem = ops[n_ops - 1], ops[n_ops - 1] = ops[i] , ops[i] = tem;
 j = negs[n_ops - 1], negs[n_ops - 1] = negs[i], negs[i] = j;
      }



  for (i = 0; i < n_ops && negs[i]; i++)
    ;

  if (i == n_ops)
    {
      for (i = 0; i < n_ops; i++)
 negs[i] = 0;
      negate = 1;
    }
  else if (i != 0)
    {
      tem = ops[0], ops[0] = ops[i], ops[i] = tem;
      j = negs[0], negs[0] = negs[i], negs[i] = j;
    }


  result = ops[0];
  for (i = 1; i < n_ops; i++)
    result = cse_gen_binary (negs[i] ? MINUS : PLUS, mode, result, ops[i]);

  return negate ? gen_rtx (NEG, mode, result) : result;
}




static rtx
cse_gen_binary(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1) asm("_cse_gen_binary");
static rtx
cse_gen_binary(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1)
{
  rtx tem;


  if ((rtx_class[(int)(code)]) == 'c'
      && (((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ((op1)->code) != CONST_INT)
   || ((rtx_class[(int)(((op0)->code))]) == 'o'
       && (rtx_class[(int)(((op1)->code))]) != 'o')
   || (((op0)->code) == SUBREG
       && (rtx_class[(int)(((((op0)->fld[0].rtx))->code))]) == 'o'
       && (rtx_class[(int)(((op1)->code))]) != 'o')))
    tem = op0, op0 = op1, op1 = tem;


  tem = simplify_binary_operation (code, mode, op0, op1);

  if (tem)
    return tem;




  if (code == PLUS && ((op1)->code) == CONST_INT
      && ((op0)->mode) != VOIDmode)
    return plus_constant_wide (op0, (int) (((op1)->fld[0].rtwint)));
  else if (code == MINUS && ((op1)->code) == CONST_INT
    && ((op0)->mode) != VOIDmode)
    return plus_constant_wide (op0, (int) (- ((op1)->fld[0].rtwint)));
  else
    return gen_rtx (code, mode, op0, op1);
}
rtx
simplify_relational_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1) asm("_simplify_relational_operation");
rtx
simplify_relational_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1)
{
  int equal, op0lt, op0ltu, op1lt, op1ltu;
  rtx tem;


  if (((op0)->code) == COMPARE && op1 == const0_rtx)
    op1 = ((op0)->fld[1].rtx), op0 = ((op0)->fld[0].rtx);



  if ((mode_class[(int)(((op0)->mode))]) == MODE_CC



      )
    return 0;
  if (((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT) && op1 != const0_rtx
      && ! ((((op0)->code) == REG || ((op0)->code) == CONST_INT)
     && (((op1)->code) == REG || ((op1)->code) == CONST_INT))
      && 0 != (tem = simplify_binary_operation (MINUS, mode, op0, op1))
      && code != GTU && code != GEU && code != LTU && code != LEU)
    return simplify_relational_operation (signed_condition (code),
       mode, tem, const0_rtx);



  if (rtx_equal_p (op0, op1)
      && (1 != 1
   || ! ((mode_class[(int)(((op0)->mode))]) == MODE_FLOAT || (mode_class[(int)(((op0)->mode))]) == MODE_COMPLEX_FLOAT) || flag_fast_math))
    equal = 1, op0lt = 0, op0ltu = 0, op1lt = 0, op1ltu = 0;




  else if (((op0)->code) == CONST_DOUBLE && ((op1)->code) == CONST_DOUBLE
    && (mode_class[(int)(((op0)->mode))]) == MODE_FLOAT)
    {
      double d0, d1;
      jmp_buf handler;

      if (
         _setjmp3((
         handler
         ), ((void *)0))
                         )
 return 0;

      set_float_handler (handler);
      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op0))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op0))->fld[3].rtwint),(sizeof u) / 2); d0 = u.d; } while (0);
      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op1))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op1))->fld[3].rtwint),(sizeof u) / 2); d1 = u.d; } while (0);
      equal = (ereal_cmp ((d0), (d1)) == 0);
      op0lt = op0ltu = (ereal_cmp ((d0), (d1)) == -1);
      op1lt = op1ltu = (ereal_cmp ((d1), (d0)) == -1);
      set_float_handler (((void *)0));
    }



  else if (((mode_class[(int)(mode)]) == MODE_INT || mode == VOIDmode)
    && (((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST_INT)
    && (((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST_INT))
    {
      int width = (8 * mode_size[(int)(mode)]);
      int l0s, h0s, l1s, h1s;
      unsigned int l0u, h0u, l1u, h1u;


      if (((op0)->code) == CONST_DOUBLE)
 {
   l0u = l0s = ((op0)->fld[2].rtwint);
   h0u = h0s = ((op0)->fld[3].rtwint);
 }
      else
 {
   l0u = l0s = ((op0)->fld[0].rtwint);
   h0u = 0, h0s = l0s < 0 ? -1 : 0;
 }

      if (((op1)->code) == CONST_DOUBLE)
 {
   l1u = l1s = ((op1)->fld[2].rtwint);
   h1u = h1s = ((op1)->fld[3].rtwint);
 }
      else
 {
   l1u = l1s = ((op1)->fld[0].rtwint);
   h1u = 0, h1s = l1s < 0 ? -1 : 0;
 }



      if (width != 0 && width <= 32)
 h0u = h1u = 0, h0s = l0s < 0 ? -1 : 0, h1s = l1s < 0 ? -1 : 0;

      if (width != 0 && width < 32)
 {
   l0u &= ((int) 1 << width) - 1;
   l1u &= ((int) 1 << width) - 1;

   if (l0s & ((int) 1 << (width - 1)))
     l0s |= ((int) (-1) << width);

   if (l1s & ((int) 1 << (width - 1)))
     l1s |= ((int) (-1) << width);
 }

      equal = (h0u == h1u && l0u == l1u);
      op0lt = (h0s < h1s || (h0s == h1s && l0s < l1s));
      op1lt = (h1s < h0s || (h1s == h0s && l1s < l0s));
      op0ltu = (h0u < h1u || (h0u == h1u && l0u < l1u));
      op1ltu = (h1u < h0u || (h1u == h0u && l1u < l0u));
    }


  else
    {
      switch (code)
 {
 case EQ:


   if (((((op0) == frame_pointer_rtx || (op0) == hard_frame_pointer_rtx || (op0) == virtual_stack_vars_rtx || (op0) == virtual_incoming_args_rtx || (((op0)->code) == PLUS && ((((op0)->fld[1].rtx))->code) == CONST_INT && (((op0)->fld[0].rtx) == frame_pointer_rtx || ((op0)->fld[0].rtx) == hard_frame_pointer_rtx || ((op0)->fld[0].rtx) == arg_pointer_rtx || ((op0)->fld[0].rtx) == virtual_stack_vars_rtx || ((op0)->fld[0].rtx) == virtual_incoming_args_rtx)) || (op0) == stack_pointer_rtx || (op0) == virtual_stack_dynamic_rtx || (op0) == virtual_outgoing_args_rtx || (((op0)->code) == PLUS && ((((op0)->fld[1].rtx))->code) == CONST_INT && (((op0)->fld[0].rtx) == stack_pointer_rtx || ((op0)->fld[0].rtx) == virtual_stack_dynamic_rtx || ((op0)->fld[0].rtx) == virtual_outgoing_args_rtx))) && op1 == const0_rtx)
        || ((op0)->code) == LABEL_REF)


       && op0 != arg_pointer_rtx

  )
     return const0_rtx;
   break;

 case NE:
   if (((((op0) == frame_pointer_rtx || (op0) == hard_frame_pointer_rtx || (op0) == virtual_stack_vars_rtx || (op0) == virtual_incoming_args_rtx || (((op0)->code) == PLUS && ((((op0)->fld[1].rtx))->code) == CONST_INT && (((op0)->fld[0].rtx) == frame_pointer_rtx || ((op0)->fld[0].rtx) == hard_frame_pointer_rtx || ((op0)->fld[0].rtx) == arg_pointer_rtx || ((op0)->fld[0].rtx) == virtual_stack_vars_rtx || ((op0)->fld[0].rtx) == virtual_incoming_args_rtx)) || (op0) == stack_pointer_rtx || (op0) == virtual_stack_dynamic_rtx || (op0) == virtual_outgoing_args_rtx || (((op0)->code) == PLUS && ((((op0)->fld[1].rtx))->code) == CONST_INT && (((op0)->fld[0].rtx) == stack_pointer_rtx || ((op0)->fld[0].rtx) == virtual_stack_dynamic_rtx || ((op0)->fld[0].rtx) == virtual_outgoing_args_rtx))) && op1 == const0_rtx)
        || ((op0)->code) == LABEL_REF)

       && op0 != arg_pointer_rtx

       )
     return const_true_rtx;
   break;

 case GEU:

   if (op1 == const0_rtx)
     return const_true_rtx;
   break;

 case LTU:
   if (op1 == const0_rtx)
     return const0_rtx;
   break;

 case LEU:


   if (((op1)->code) == CONST_INT
       && ((op1)->fld[0].rtwint) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
     && ((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT))
   return const_true_rtx;
   break;

 case GTU:
   if (((op1)->code) == CONST_INT
       && ((op1)->fld[0].rtwint) == (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1))
       && ((mode_class[(int)(mode)]) == MODE_INT || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT))
     return const0_rtx;
   break;
 }

      return 0;
    }



  switch (code)
    {
    case EQ:
      return equal ? const_true_rtx : const0_rtx;
    case NE:
      return ! equal ? const_true_rtx : const0_rtx;
    case LT:
      return op0lt ? const_true_rtx : const0_rtx;
    case GT:
      return op1lt ? const_true_rtx : const0_rtx;
    case LTU:
      return op0ltu ? const_true_rtx : const0_rtx;
    case GTU:
      return op1ltu ? const_true_rtx : const0_rtx;
    case LE:
      return equal || op0lt ? const_true_rtx : const0_rtx;
    case GE:
      return equal || op1lt ? const_true_rtx : const0_rtx;
    case LEU:
      return equal || op0ltu ? const_true_rtx : const0_rtx;
    case GEU:
      return equal || op1ltu ? const_true_rtx : const0_rtx;
    }

  abort ();
}





rtx
simplify_ternary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, n64_enum_machine_mode op0_mode, rtx op0, rtx op1, rtx op2) asm("_simplify_ternary_operation");
rtx
simplify_ternary_operation(n64_enum_rtx_code code, n64_enum_machine_mode mode, n64_enum_machine_mode op0_mode, rtx op0, rtx op1, rtx op2)
{
  int width = (8 * mode_size[(int)(mode)]);


  if (width == 0)
    width = 32;

  switch (code)
    {
    case SIGN_EXTRACT:
    case ZERO_EXTRACT:
      if (((op0)->code) == CONST_INT
   && ((op1)->code) == CONST_INT
   && ((op2)->code) == CONST_INT
   && ((op1)->fld[0].rtwint) + ((op2)->fld[0].rtwint) <= (8 * mode_size[(int)(op0_mode)])
   && width <= 32)
 {

   int val = ((op0)->fld[0].rtwint);

   if (0)
     val >>= ((8 * mode_size[(int)(op0_mode)])
       - ((op2)->fld[0].rtwint) - ((op1)->fld[0].rtwint));
   else
     val >>= ((op2)->fld[0].rtwint);

   if (32 != ((op1)->fld[0].rtwint))
     {

       val &= ((int) 1 << ((op1)->fld[0].rtwint)) - 1;

       if (code == SIGN_EXTRACT
    && (val & ((int) 1 << (((op1)->fld[0].rtwint) - 1))))
  val |= ~ (((int) 1 << ((op1)->fld[0].rtwint)) - 1);
     }





   if (width < 32
       && ((val & ((int) (-1) << (width - 1)))
    != ((int) (-1) << (width - 1))))
     val &= ((int) 1 << width) - 1;

   return gen_rtx (CONST_INT, VOIDmode, (int) (val));
 }
      break;

    case IF_THEN_ELSE:
      if (((op0)->code) == CONST_INT)
 return op0 != const0_rtx ? op1 : op2;
      break;

    default:
      abort ();
    }

  return 0;
}
static rtx
fold_rtx(rtx x, rtx insn) asm("_fold_rtx");
static rtx
fold_rtx(rtx x, rtx insn)
{
  register n64_enum_rtx_code code;
  register n64_enum_machine_mode mode;
  register char *fmt;
  register int i;
  rtx cxx_new = 0;
  int copied = 0;
  int must_swap = 0;


  rtx folded_arg0;
  rtx folded_arg1;



  rtx const_arg0;
  rtx const_arg1;
  rtx const_arg2;



  n64_enum_machine_mode mode_arg0;

  if (x == 0)
    return x;

  mode = ((x)->mode);
  code = ((x)->code);
  switch (code)
    {
    case CONST:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case REG:



    case EXPR_LIST:
      return x;






    case PC:



      if (insn && ((insn)->code) == JUMP_INSN)
 {
   rtx next = next_nonnote_insn (insn);

   if (next && ((next)->code) == CODE_LABEL
       && ((next)->fld[2].rtx) != 0
       && ((((next)->fld[2].rtx))->code) == JUMP_INSN
       && (((((((next)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_VEC
    || ((((((next)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_DIFF_VEC))
     return gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), next);
 }
      break;

    case SUBREG:

      if ((cxx_new = lookup_as_function (x, CONST_INT)) != 0
   || (cxx_new = lookup_as_function (x, CONST_DOUBLE)) != 0)
 return cxx_new;
      if ((mode_size[(int)(mode)]) > (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
 {
   n64_enum_machine_mode imode = ((((x)->fld[0].rtx))->mode);
   struct n64_tag_table_elt *elt;

   if ((mode_size[(int)(mode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
       && (mode_size[(int)(imode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
       && (elt = lookup (((x)->fld[0].rtx), (((((x)->fld[0].rtx))->code) == REG && ((((x)->fld[0].rtx))->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((((x)->fld[0].rtx))->fld[0].rtint)]) % 31 : canon_hash (((x)->fld[0].rtx), imode) % 31),
    imode)) != 0)
     for (elt = elt->first_same_value;
   elt; elt = elt->next_same_value)
       {
  if ((((elt->exp)->code) == LABEL_REF || ((elt->exp)->code) == SYMBOL_REF || ((elt->exp)->code) == CONST_INT || ((elt->exp)->code) == CONST_DOUBLE || ((elt->exp)->code) == CONST || ((elt->exp)->code) == HIGH)
      && ((elt->exp)->mode) == VOIDmode)
    return elt->exp;

  if (((elt->exp)->code) == SUBREG
      && ((((elt->exp)->fld[0].rtx))->mode) == mode
      && exp_equiv_p (elt->exp, elt->exp, 1, 0))
    return copy_rtx (((elt->exp)->fld[0].rtx));
     }

   return x;
 }





      folded_arg0 = fold_rtx (((x)->fld[0].rtx), insn);
      const_arg0 = equiv_constant (folded_arg0);
      if (const_arg0)
 folded_arg0 = const_arg0;

      if (folded_arg0 != ((x)->fld[0].rtx))
 {
   cxx_new = 0;

   if ((mode_class[(int)(mode)]) == MODE_INT
       && (mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 8 : 4)
       && ((((x)->fld[0].rtx))->mode) != VOIDmode)
     cxx_new = operand_subword (folded_arg0, ((x)->fld[1].rtint), 0,
       ((((x)->fld[0].rtx))->mode));
   if (cxx_new == 0 && subreg_lowpart_p (x))
     cxx_new = gen_lowpart_if_possible (mode, folded_arg0);
   if (cxx_new)
     return cxx_new;
 }
      if (((folded_arg0)->code) == REG
   && (mode_size[(int)(mode)]) < (mode_size[(int)(((folded_arg0)->mode))])
   && subreg_lowpart_p (x))
 {
   struct n64_tag_table_elt *elt;



   elt = lookup (folded_arg0,
   (((folded_arg0)->code) == REG && ((folded_arg0)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((folded_arg0)->fld[0].rtint)]) % 31 : canon_hash (folded_arg0, ((folded_arg0)->mode)) % 31),
   ((folded_arg0)->mode));

   if (elt)
     elt = elt->first_same_value;

   for (; elt; elt = elt->next_same_value)
     {
       n64_enum_rtx_code eltcode = ((elt->exp)->code);


       if ((rtx_class[(int)(((elt->exp)->code))]) == '1'
    && ((elt->exp)->code) != SIGN_EXTEND
    && ((elt->exp)->code) != ZERO_EXTEND
    && ((((elt->exp)->fld[0].rtx))->code) == SUBREG
    && ((((((elt->exp)->fld[0].rtx))->fld[0].rtx))->mode) == mode)
  {
    rtx op0 = ((((elt->exp)->fld[0].rtx))->fld[0].rtx);

    if (((op0)->code) != REG && ! (((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
      op0 = fold_rtx (op0, (rtx) 0);

    op0 = equiv_constant (op0);
    if (op0)
      cxx_new = simplify_unary_operation (((elt->exp)->code), mode,
          op0, mode);
  }
       else if (((rtx_class[(int)(((elt->exp)->code))]) == '2'
   || (rtx_class[(int)(((elt->exp)->code))]) == 'c')
         && eltcode != DIV && eltcode != MOD
         && eltcode != UDIV && eltcode != UMOD
         && eltcode != ASHIFTRT && eltcode != LSHIFTRT
         && eltcode != ROTATE && eltcode != ROTATERT
         && ((((((elt->exp)->fld[0].rtx))->code) == SUBREG
       && (((((((elt->exp)->fld[0].rtx))->fld[0].rtx))->mode)
    == mode))
      || (((((elt->exp)->fld[0].rtx))->code) == LABEL_REF || ((((elt->exp)->fld[0].rtx))->code) == SYMBOL_REF || ((((elt->exp)->fld[0].rtx))->code) == CONST_INT || ((((elt->exp)->fld[0].rtx))->code) == CONST_DOUBLE || ((((elt->exp)->fld[0].rtx))->code) == CONST || ((((elt->exp)->fld[0].rtx))->code) == HIGH))
         && ((((((elt->exp)->fld[1].rtx))->code) == SUBREG
       && (((((((elt->exp)->fld[1].rtx))->fld[0].rtx))->mode)
    == mode))
      || (((((elt->exp)->fld[1].rtx))->code) == LABEL_REF || ((((elt->exp)->fld[1].rtx))->code) == SYMBOL_REF || ((((elt->exp)->fld[1].rtx))->code) == CONST_INT || ((((elt->exp)->fld[1].rtx))->code) == CONST_DOUBLE || ((((elt->exp)->fld[1].rtx))->code) == CONST || ((((elt->exp)->fld[1].rtx))->code) == HIGH)))
  {
    rtx op0 = gen_lowpart_common (mode, ((elt->exp)->fld[0].rtx));
    rtx op1 = gen_lowpart_common (mode, ((elt->exp)->fld[1].rtx));

    if (op0 && ((op0)->code) != REG && ! (((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH))
      op0 = fold_rtx (op0, (rtx) 0);

    if (op0)
      op0 = equiv_constant (op0);

    if (op1 && ((op1)->code) != REG && ! (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH))
      op1 = fold_rtx (op1, (rtx) 0);

    if (op1)
      op1 = equiv_constant (op1);





    if (op0 && op1
        && ((elt->exp)->code) == ASHIFT
        && ((op1)->code) == CONST_INT
        && ((op1)->fld[0].rtwint) >= (8 * mode_size[(int)(mode)]))
      {
        if (((op1)->fld[0].rtwint) < (8 * mode_size[(int)(((elt->exp)->mode))]))





   cxx_new = const0_rtx;
        else


   cxx_new = 0;
      }
    else if (op0 && op1)
      cxx_new = simplify_binary_operation (((elt->exp)->code), mode,
           op0, op1);
  }

       else if (((elt->exp)->code) == SUBREG
         && ((((elt->exp)->fld[0].rtx))->mode) == mode
         && ((mode_size[(int)(((folded_arg0)->mode))])
      <= ((target_flags & 0x00002000) ? 8 : 4))
         && exp_equiv_p (elt->exp, elt->exp, 1, 0))
  cxx_new = copy_rtx (((elt->exp)->fld[0].rtx));

       if (cxx_new)
  return cxx_new;
     }
 }

      return x;

    case NOT:
    case NEG:


      cxx_new = lookup_as_function (((x)->fld[0].rtx), code);
      if (cxx_new)
 return fold_rtx (copy_rtx (((cxx_new)->fld[0].rtx)), insn);
      break;

    case MEM:



      if (insn != 0)
 find_best_addr (insn, &((x)->fld[0].rtx));

      {


 rtx addr = fold_rtx (((x)->fld[0].rtx), (rtx) 0);
 rtx base = 0;
 int offset = 0;

 if (((addr)->code) == REG
     && (reg_qty[((addr)->fld[0].rtint)] != (((addr)->fld[0].rtint)))
     && ((addr)->mode) == qty_mode[reg_qty[((addr)->fld[0].rtint)]]
     && qty_const[reg_qty[((addr)->fld[0].rtint)]] != 0)
   addr = qty_const[reg_qty[((addr)->fld[0].rtint)]];


 if (((addr)->code) == SYMBOL_REF || ((addr)->code) == LABEL_REF)
   base = addr;
 else if (((addr)->code) == CONST && ((((addr)->fld[0].rtx))->code) == PLUS
   && ((((((addr)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT)
   {
     base = ((((addr)->fld[0].rtx))->fld[0].rtx);
     offset = ((((((addr)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint);
   }
 else if (((addr)->code) == LO_SUM
   && ((((addr)->fld[1].rtx))->code) == SYMBOL_REF)
   base = ((addr)->fld[1].rtx);



 if (base && ((base)->code) == SYMBOL_REF
     && ((base)->unchanging))
   {
     rtx constant = get_pool_constant (base);
     n64_enum_machine_mode const_mode = get_pool_mode (base);
     rtx cxx_new;

     if ((((constant)->code) == LABEL_REF || ((constant)->code) == SYMBOL_REF || ((constant)->code) == CONST_INT || ((constant)->code) == CONST_DOUBLE || ((constant)->code) == CONST || ((constant)->code) == HIGH) && ((constant)->code) != CONST_INT)
       constant_pool_entries_cost = (((constant)->code) == REG ? (((((constant)->volatil) && ((constant)->fld[0].rtint) < 68) || ((((constant)->fld[0].rtint)) == (0 + 30) || (((constant)->fld[0].rtint)) == (0 + 30) || (((constant)->fld[0].rtint)) == (0 + 29) || (((constant)->fld[0].rtint)) == 0 || ((((constant)->fld[0].rtint)) >= (68) && (((constant)->fld[0].rtint)) <= (((68)) + 3)) || ((((constant)->fld[0].rtint)) < 68 && ((((constant)->fld[0].rtint)) == (0 + 30) || (((constant)->fld[0].rtint)) == (0 + 30) || fixed_regs[((constant)->fld[0].rtint)] || global_regs[((constant)->fld[0].rtint)]) && mips_regno_to_class[ (((constant)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((constant)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (constant, SET) * 2);


     if (offset == 0 && mode == const_mode)
       return constant;






     if (! (((constant)->code) == LABEL_REF || ((constant)->code) == SYMBOL_REF || ((constant)->code) == CONST_INT || ((constant)->code) == CONST_DOUBLE || ((constant)->code) == CONST || ((constant)->code) == HIGH))
       return x;

     if ((mode_class[(int)(mode)]) == MODE_INT
  && (mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 8 : 4)
  && offset % ((target_flags & 0x00002000) ? 8 : 4) == 0
  && (cxx_new = operand_subword (constant,
        offset / ((target_flags & 0x00002000) ? 8 : 4),
        0, const_mode)) != 0)
       return cxx_new;

     if (((((target_flags & 0x00010000) != 0)
    && offset == (mode_size[(int)(((constant)->mode))]) - 1)
   || (! ((target_flags & 0x00010000) != 0) && offset == 0))
  && (cxx_new = gen_lowpart_if_possible (mode, constant)) != 0)
       return cxx_new;
   }



 if (base && ((base)->code) == LABEL_REF)
   {
     rtx label = ((base)->fld[0].rtx);
     rtx table_insn = ((label)->fld[2].rtx);

     if (table_insn && ((table_insn)->code) == JUMP_INSN
  && ((((table_insn)->fld[3].rtx))->code) == ADDR_VEC)
       {
  rtx table = ((table_insn)->fld[3].rtx);

  if (offset >= 0
      && (offset / (mode_size[(int)(((table)->mode))])
   < ((table)->fld[0].rtvec->num_elem)))
    return ((table)->fld[0].rtvec->elem[offset / (mode_size[(int)(((table)->mode))])].rtx)
                                                ;
       }
     if (table_insn && ((table_insn)->code) == JUMP_INSN
  && ((((table_insn)->fld[3].rtx))->code) == ADDR_DIFF_VEC)
       {
  rtx table = ((table_insn)->fld[3].rtx);

  if (offset >= 0
      && (offset / (mode_size[(int)(((table)->mode))])
   < ((table)->fld[1].rtvec->num_elem)))
    {
      offset /= (mode_size[(int)(((table)->mode))]);
      cxx_new = gen_rtx (MINUS, ((target_flags & 0x00000002) ? DImode : SImode), ((table)->fld[1].rtvec->elem[offset].rtx),
       ((table)->fld[0].rtx));

      if (((table)->mode) != ((target_flags & 0x00000002) ? DImode : SImode))
        cxx_new = gen_rtx (TRUNCATE, ((table)->mode), cxx_new);





      return gen_rtx (CONST, ((cxx_new)->mode), cxx_new);
    }
       }
   }

 return x;
      }
    }

  const_arg0 = 0;
  const_arg1 = 0;
  const_arg2 = 0;
  mode_arg0 = VOIDmode;




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    if (fmt[i] == 'e')
      {
 rtx arg = ((x)->fld[i].rtx);
 rtx folded_arg = arg, const_arg = 0;
 n64_enum_machine_mode mode_arg = ((arg)->mode);
 rtx cheap_arg, expensive_arg;
 rtx replacements[2];
 int j;


 switch (((arg)->code))
   {
   case REG:


     if ((reg_qty[((arg)->fld[0].rtint)] != (((arg)->fld[0].rtint)))
  && qty_const[reg_qty[((arg)->fld[0].rtint)]] != 0
  && ((qty_const[reg_qty[((arg)->fld[0].rtint)]])->code) != REG
  && ((qty_const[reg_qty[((arg)->fld[0].rtint)]])->code) != PLUS)
       const_arg
  = gen_lowpart_if_possible (((arg)->mode),
        qty_const[reg_qty[((arg)->fld[0].rtint)]]);
     break;

   case CONST:
   case CONST_INT:
   case SYMBOL_REF:
   case LABEL_REF:
   case CONST_DOUBLE:
     const_arg = arg;
     break;
   default:
     folded_arg = fold_rtx (arg, insn);
     const_arg = equiv_constant (folded_arg);
   }



 switch (i)
   {
   case 0:
     folded_arg0 = folded_arg;
     const_arg0 = const_arg;
     mode_arg0 = mode_arg;
     break;
   case 1:
     folded_arg1 = folded_arg;
     const_arg1 = const_arg;
     break;
   case 2:
     const_arg2 = const_arg;
     break;
   }



 if (const_arg == 0 || const_arg == folded_arg
     || (((const_arg)->code) == REG ? (((((const_arg)->volatil) && ((const_arg)->fld[0].rtint) < 68) || ((((const_arg)->fld[0].rtint)) == (0 + 30) || (((const_arg)->fld[0].rtint)) == (0 + 30) || (((const_arg)->fld[0].rtint)) == (0 + 29) || (((const_arg)->fld[0].rtint)) == 0 || ((((const_arg)->fld[0].rtint)) >= (68) && (((const_arg)->fld[0].rtint)) <= (((68)) + 3)) || ((((const_arg)->fld[0].rtint)) < 68 && ((((const_arg)->fld[0].rtint)) == (0 + 30) || (((const_arg)->fld[0].rtint)) == (0 + 30) || fixed_regs[((const_arg)->fld[0].rtint)] || global_regs[((const_arg)->fld[0].rtint)]) && mips_regno_to_class[ (((const_arg)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((const_arg)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (const_arg, SET) * 2) > (((folded_arg)->code) == REG ? (((((folded_arg)->volatil) && ((folded_arg)->fld[0].rtint) < 68) || ((((folded_arg)->fld[0].rtint)) == (0 + 30) || (((folded_arg)->fld[0].rtint)) == (0 + 30) || (((folded_arg)->fld[0].rtint)) == (0 + 29) || (((folded_arg)->fld[0].rtint)) == 0 || ((((folded_arg)->fld[0].rtint)) >= (68) && (((folded_arg)->fld[0].rtint)) <= (((68)) + 3)) || ((((folded_arg)->fld[0].rtint)) < 68 && ((((folded_arg)->fld[0].rtint)) == (0 + 30) || (((folded_arg)->fld[0].rtint)) == (0 + 30) || fixed_regs[((folded_arg)->fld[0].rtint)] || global_regs[((folded_arg)->fld[0].rtint)]) && mips_regno_to_class[ (((folded_arg)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((folded_arg)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (folded_arg, SET) * 2))
   cheap_arg = folded_arg, expensive_arg = const_arg;
 else
   cheap_arg = const_arg, expensive_arg = folded_arg;







 if (cheap_arg == ((x)->fld[i].rtx))
   continue;

 if (insn == 0 && ! copied)
   {
     x = copy_rtx (x);
     copied = 1;
   }

 replacements[0] = cheap_arg, replacements[1] = expensive_arg;
 for (j = 0;
      j < 2 && replacements[j]
      && (((replacements[j])->code) == REG ? (((((replacements[j])->volatil) && ((replacements[j])->fld[0].rtint) < 68) || ((((replacements[j])->fld[0].rtint)) == (0 + 30) || (((replacements[j])->fld[0].rtint)) == (0 + 30) || (((replacements[j])->fld[0].rtint)) == (0 + 29) || (((replacements[j])->fld[0].rtint)) == 0 || ((((replacements[j])->fld[0].rtint)) >= (68) && (((replacements[j])->fld[0].rtint)) <= (((68)) + 3)) || ((((replacements[j])->fld[0].rtint)) < 68 && ((((replacements[j])->fld[0].rtint)) == (0 + 30) || (((replacements[j])->fld[0].rtint)) == (0 + 30) || fixed_regs[((replacements[j])->fld[0].rtint)] || global_regs[((replacements[j])->fld[0].rtint)]) && mips_regno_to_class[ (((replacements[j])->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((replacements[j])->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (replacements[j], SET) * 2) < (((((x)->fld[i].rtx))->code) == REG ? (((((((x)->fld[i].rtx))->volatil) && ((((x)->fld[i].rtx))->fld[0].rtint) < 68) || ((((((x)->fld[i].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[i].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[i].rtx))->fld[0].rtint)) == (0 + 29) || (((((x)->fld[i].rtx))->fld[0].rtint)) == 0 || ((((((x)->fld[i].rtx))->fld[0].rtint)) >= (68) && (((((x)->fld[i].rtx))->fld[0].rtint)) <= (((68)) + 3)) || ((((((x)->fld[i].rtx))->fld[0].rtint)) < 68 && ((((((x)->fld[i].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[i].rtx))->fld[0].rtint)) == (0 + 30) || fixed_regs[((((x)->fld[i].rtx))->fld[0].rtint)] || global_regs[((((x)->fld[i].rtx))->fld[0].rtint)]) && mips_regno_to_class[ (((((x)->fld[i].rtx))->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((((x)->fld[i].rtx))->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (((x)->fld[i].rtx), SET) * 2);
      j++)
   {
     if (validate_change (insn, &((x)->fld[i].rtx), replacements[j], 0))
       break;

     if (code == NE || code == EQ || (rtx_class[(int)(code)]) == 'c')
       {
  validate_change (insn, &((x)->fld[i].rtx), ((x)->fld[1 - i].rtx), 1);
  validate_change (insn, &((x)->fld[1 - i].rtx), replacements[j], 1);

  if (apply_change_group ())
    {


      rtx tem;

      tem = ((x)->fld[0].rtx); ((x)->fld[0].rtx) = ((x)->fld[1].rtx);
           ((x)->fld[1].rtx) = tem;
      must_swap = 1;
      break;
    }
       }
   }
      }

    else if (fmt[i] == 'E')


      ;





  if (code == EQ || code == NE || (rtx_class[(int)(code)]) == 'c')
    {
      if (must_swap || (const_arg0
     && (const_arg1 == 0
             || (((const_arg0)->code) == CONST_INT
           && ((const_arg1)->code) != CONST_INT))))
 {
   register rtx tem = ((x)->fld[0].rtx);

   if (insn == 0 && ! copied)
     {
       x = copy_rtx (x);
       copied = 1;
     }

   validate_change (insn, &((x)->fld[0].rtx), ((x)->fld[1].rtx), 1);
   validate_change (insn, &((x)->fld[1].rtx), tem, 1);
   if (apply_change_group ())
     {
       tem = const_arg0, const_arg0 = const_arg1, const_arg1 = tem;
       tem = folded_arg0, folded_arg0 = folded_arg1, folded_arg1 = tem;
     }
 }
    }



  switch ((rtx_class[(int)(code)]))
    {
    case '1':
      {
 int is_const = 0;



 if ((code == ZERO_EXTEND || code == SIGN_EXTEND)
     && mode_arg0 == VOIDmode)
   break;



 if (const_arg0 != 0 && ((const_arg0)->code) == CONST)
   is_const = 1, const_arg0 = ((const_arg0)->fld[0].rtx);

 cxx_new = simplify_unary_operation (code, mode,
     const_arg0 ? const_arg0 : folded_arg0,
     mode_arg0);
 if (cxx_new != 0 && is_const)
   cxx_new = gen_rtx (CONST, mode, cxx_new);
      }
      break;

    case '<':





      if (const_arg0 == 0 || const_arg1 == 0)
 {
   struct n64_tag_table_elt *p0, *p1;
   rtx cxx_true = const_true_rtx, cxx_false = const0_rtx;
   n64_enum_machine_mode mode_arg1;
   code = find_comparison_args (code, &folded_arg0, &folded_arg1,
           &mode_arg0, &mode_arg1);
   const_arg0 = equiv_constant (folded_arg0);
   const_arg1 = equiv_constant (folded_arg1);





   if (mode_arg0 == VOIDmode || (mode_class[(int)(mode_arg0)]) == MODE_CC)
     break;



   if (const_arg0 == 0 || const_arg1 == 0)
     {


       if (const_arg1 == const0_rtx
    && (((folded_arg0) == frame_pointer_rtx || (folded_arg0) == hard_frame_pointer_rtx || (folded_arg0) == virtual_stack_vars_rtx || (folded_arg0) == virtual_incoming_args_rtx || (((folded_arg0)->code) == PLUS && ((((folded_arg0)->fld[1].rtx))->code) == CONST_INT && (((folded_arg0)->fld[0].rtx) == frame_pointer_rtx || ((folded_arg0)->fld[0].rtx) == hard_frame_pointer_rtx || ((folded_arg0)->fld[0].rtx) == arg_pointer_rtx || ((folded_arg0)->fld[0].rtx) == virtual_stack_vars_rtx || ((folded_arg0)->fld[0].rtx) == virtual_incoming_args_rtx)) || (folded_arg0) == stack_pointer_rtx || (folded_arg0) == virtual_stack_dynamic_rtx || (folded_arg0) == virtual_outgoing_args_rtx || (((folded_arg0)->code) == PLUS && ((((folded_arg0)->fld[1].rtx))->code) == CONST_INT && (((folded_arg0)->fld[0].rtx) == stack_pointer_rtx || ((folded_arg0)->fld[0].rtx) == virtual_stack_dynamic_rtx || ((folded_arg0)->fld[0].rtx) == virtual_outgoing_args_rtx)))




        || ((folded_arg0)->code) == LABEL_REF
        || ((folded_arg0)->code) == CONST))
  {
    if (code == EQ)
      return cxx_false;
    else if (code == NE)
      return cxx_true;
  }





       if ((1 != 1
     || ! ((mode_class[(int)(mode_arg0)]) == MODE_FLOAT || (mode_class[(int)(mode_arg0)]) == MODE_COMPLEX_FLOAT) || flag_fast_math)
    && (folded_arg0 == folded_arg1
        || (((folded_arg0)->code) == REG
     && ((folded_arg1)->code) == REG
     && (reg_qty[((folded_arg0)->fld[0].rtint)]
         == reg_qty[((folded_arg1)->fld[0].rtint)]))
        || ((p0 = lookup (folded_arg0,
     (safe_hash (folded_arg0, mode_arg0)
      % 31), mode_arg0))
     && (p1 = lookup (folded_arg1,
        (safe_hash (folded_arg1, mode_arg0)
         % 31), mode_arg0))
     && p0->first_same_value == p1->first_same_value)))
  return ((code == EQ || code == LE || code == GE
    || code == LEU || code == GEU)
   ? cxx_true : cxx_false);




       else if (((folded_arg0)->code) == REG)
  {
    int qty = reg_qty[((folded_arg0)->fld[0].rtint)];

    if ((reg_qty[((folded_arg0)->fld[0].rtint)] != (((folded_arg0)->fld[0].rtint)))
        && (comparison_dominates_p (qty_comparison_code[qty], code)
     || (comparison_dominates_p (qty_comparison_code[qty],
            reverse_condition (code))
         && ! ((mode_class[(int)(mode_arg0)]) == MODE_FLOAT || (mode_class[(int)(mode_arg0)]) == MODE_COMPLEX_FLOAT)))
        && (rtx_equal_p (qty_comparison_const[qty], folded_arg1)
     || (const_arg1
         && rtx_equal_p (qty_comparison_const[qty],
           const_arg1))
     || (((folded_arg1)->code) == REG
         && (reg_qty[((folded_arg1)->fld[0].rtint)]
      == qty_comparison_qty[qty]))))
      return (comparison_dominates_p (qty_comparison_code[qty],
          code)
       ? cxx_true : cxx_false);
  }
     }
 }





      if (const_arg1 == const0_rtx)
 {
   rtx y = lookup_as_function (folded_arg0, IOR);
   rtx inner_const;

   if (y != 0
       && (inner_const = equiv_constant (((y)->fld[1].rtx))) != 0
       && ((inner_const)->code) == CONST_INT
       && ((inner_const)->fld[0].rtwint) != 0)
     {
       int sign_bitnum = (8 * mode_size[(int)(mode_arg0)]) - 1;
       int has_sign = (32 >= sign_bitnum
         && (((inner_const)->fld[0].rtwint)
      & ((int) 1 << sign_bitnum)));
       rtx cxx_true = const_true_rtx, cxx_false = const0_rtx;
       switch (code)
  {
  case EQ:
    return cxx_false;
  case NE:
    return cxx_true;
  case LT: case LE:
    if (has_sign)
      return cxx_true;
    break;
  case GT: case GE:
    if (has_sign)
      return cxx_false;
    break;
  }
     }
 }

      cxx_new = simplify_relational_operation (code, mode_arg0,
        const_arg0 ? const_arg0 : folded_arg0,
        const_arg1 ? const_arg1 : folded_arg1);





      break;

    case '2':
    case 'c':
      switch (code)
 {
 case PLUS:




   if (const_arg1 && ((const_arg1)->code) == LABEL_REF)
     {
       rtx y
  = ((folded_arg0)->code) == MINUS ? folded_arg0
    : lookup_as_function (folded_arg0, MINUS);

       if (y != 0 && ((((y)->fld[1].rtx))->code) == LABEL_REF
    && ((((y)->fld[1].rtx))->fld[0].rtx) == ((const_arg1)->fld[0].rtx))
  return ((y)->fld[0].rtx);


       if ((y = (((folded_arg0)->code) == CONST ? folded_arg0
   : lookup_as_function (folded_arg0, CONST))) != 0
    && ((((y)->fld[0].rtx))->code) == MINUS
    && ((((((y)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF
    && ((((((y)->fld[0].rtx))->fld[1].rtx))->fld[0].rtx) == ((const_arg1)->fld[0].rtx))
  return ((((y)->fld[0].rtx))->fld[0].rtx);
     }


   if (const_arg0 && ((const_arg0)->code) == LABEL_REF)
     {
       rtx y
  = ((folded_arg1)->code) == MINUS ? folded_arg1
    : lookup_as_function (folded_arg1, MINUS);

       if (y != 0 && ((((y)->fld[1].rtx))->code) == LABEL_REF
    && ((((y)->fld[1].rtx))->fld[0].rtx) == ((const_arg0)->fld[0].rtx))
  return ((y)->fld[0].rtx);


       if ((y = (((folded_arg1)->code) == CONST ? folded_arg1
   : lookup_as_function (folded_arg1, CONST))) != 0
    && ((((y)->fld[0].rtx))->code) == MINUS
    && ((((((y)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF
    && ((((((y)->fld[0].rtx))->fld[1].rtx))->fld[0].rtx) == ((const_arg0)->fld[0].rtx))
  return ((((y)->fld[0].rtx))->fld[0].rtx);
     }







   if (const_arg1 && ((const_arg1)->code) == CONST_INT
       && ((const_arg1)->fld[0].rtwint) < 0 && ((folded_arg1)->code) == REG)
     {
       rtx new_const = gen_rtx (CONST_INT, VOIDmode, (int) (- ((const_arg1)->fld[0].rtwint)));
       struct n64_tag_table_elt *p
  = lookup (new_const, safe_hash (new_const, mode) % 31,
     mode);

       if (p)
  for (p = p->first_same_value; p; p = p->next_same_value)
    if (((p->exp)->code) == REG)
      return cse_gen_binary (MINUS, mode, folded_arg0,
        canon_reg (p->exp, (rtx) 0));
     }
   goto from_plus;

 case MINUS:


   if (const_arg1 != 0 && ((const_arg1)->code) == CONST_INT)
     {
       rtx y = lookup_as_function (((x)->fld[0].rtx), PLUS);
       if (y && ((((y)->fld[1].rtx))->code) == CONST_INT)
  return fold_rtx (plus_constant_wide (copy_rtx (y), (int) (-((const_arg1)->fld[0].rtwint)))
                           ,
     (rtx) 0);
     }



 from_plus:
 case SMIN: case SMAX: case UMIN: case UMAX:
 case IOR: case AND: case XOR:
 case MULT: case DIV: case UDIV:
 case ASHIFT: case LSHIFTRT: case ASHIFTRT:







   if (((folded_arg0)->code) == REG
       && const_arg1 && ((const_arg1)->code) == CONST_INT)
     {
       int is_shift
  = (code == ASHIFT || code == ASHIFTRT || code == LSHIFTRT);
       rtx y = lookup_as_function (folded_arg0, code);
       rtx inner_const;
       n64_enum_rtx_code associate_code;
       rtx new_const;

       if (y == 0
    || 0 == (inner_const
      = equiv_constant (fold_rtx (((y)->fld[1].rtx), 0)))
    || ((inner_const)->code) != CONST_INT





    || ((y)->fld[0].rtx) == folded_arg0)
  break;






       if (code == PLUS && ((const_arg1)->fld[0].rtwint) == ((inner_const)->fld[0].rtwint)
    && (0






    ))
  break;




       associate_code
  = (code == MULT || code == DIV || code == UDIV ? MULT
     : is_shift || code == PLUS || code == MINUS ? PLUS : code);

       new_const = simplify_binary_operation (associate_code, mode,
           const_arg1, inner_const);

       if (new_const == 0)
  break;







       if (is_shift && ((new_const)->code) == CONST_INT
    && ((new_const)->fld[0].rtwint) >= (8 * mode_size[(int)(mode)]))
  {


    if (code == ASHIFTRT)
      new_const = gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(mode)]) - 1));
    else
      break;
  }

       y = copy_rtx (((y)->fld[0].rtx));





       if (! reg_mentioned_p (folded_arg0, y))
  y = fold_rtx (y, insn);

       return cse_gen_binary (code, mode, y, new_const);
     }
 }

      cxx_new = simplify_binary_operation (code, mode,
           const_arg0 ? const_arg0 : folded_arg0,
           const_arg1 ? const_arg1 : folded_arg1);
      break;

    case 'o':

      if (code == LO_SUM && const_arg0 != 0
   && ((const_arg0)->code) == HIGH
   && rtx_equal_p (((const_arg0)->fld[0].rtx), const_arg1))
 return const_arg1;
      break;

    case '3':
    case 'b':
      cxx_new = simplify_ternary_operation (code, mode, mode_arg0,
     const_arg0 ? const_arg0 : folded_arg0,
     const_arg1 ? const_arg1 : folded_arg1,
     const_arg2 ? const_arg2 : ((x)->fld[2].rtx));
      break;
    }

  return cxx_new ? cxx_new : x;
}




static rtx
equiv_constant(rtx x) asm("_equiv_constant");
static rtx
equiv_constant(rtx x)
{
  if (((x)->code) == REG
      && (reg_qty[((x)->fld[0].rtint)] != (((x)->fld[0].rtint)))
      && qty_const[reg_qty[((x)->fld[0].rtint)]])
    x = gen_lowpart_if_possible (((x)->mode), qty_const[reg_qty[((x)->fld[0].rtint)]]);

  if (x != 0 && (((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    return x;






  if (((x)->code) == MEM)
    {
      struct n64_tag_table_elt *elt;

      x = fold_rtx (x, (rtx) 0);
      if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
 return x;

      elt = lookup (x, safe_hash (x, ((x)->mode)) % 31, ((x)->mode));
      if (elt == 0)
 return 0;

      for (elt = elt->first_same_value; elt; elt = elt->next_same_value)
 if (elt->is_const && (((elt->exp)->code) == LABEL_REF || ((elt->exp)->code) == SYMBOL_REF || ((elt->exp)->code) == CONST_INT || ((elt->exp)->code) == CONST_DOUBLE || ((elt->exp)->code) == CONST || ((elt->exp)->code) == HIGH))
   return elt->exp;
    }

  return 0;
}
rtx
gen_lowpart_if_possible(n64_enum_machine_mode mode, register rtx x) asm("_gen_lowpart_if_possible");
rtx
gen_lowpart_if_possible(n64_enum_machine_mode mode, register rtx x)
{
  rtx result = gen_lowpart_common (mode, x);

  if (result)
    return result;
  else if (((x)->code) == MEM)
    {

      register int offset = 0;
      rtx cxx_new;

      if (((target_flags & 0x00010000) != 0))
 offset = ((((mode_size[(int)(((x)->mode))])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(((x)->mode))])) : (((target_flags & 0x00002000) ? 8 : 4)))
    - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))));
      if (((target_flags & 0x00010000) != 0))


 offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)])))
     - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((x)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((x)->mode))]))));
      cxx_new = gen_rtx (MEM, mode, plus_constant_wide (((x)->fld[0].rtx), (int) (offset)));
      if (! memory_address_p (mode, ((cxx_new)->fld[0].rtx)))
 return 0;
      ((cxx_new)->volatil) = ((x)->volatil);
      ((cxx_new)->unchanging) = ((x)->unchanging);
      ((cxx_new)->in_struct) = ((x)->in_struct);
      return cxx_new;
    }
  else
    return 0;
}
static void
record_jump_equiv(rtx insn, int taken) asm("_record_jump_equiv");
static void
record_jump_equiv(rtx insn, int taken)
{
  int cond_known_true;
  rtx op0, op1;
  n64_enum_machine_mode mode, mode0, mode1;
  int reversed_nonequality = 0;
  n64_enum_rtx_code code;


  if (! condjump_p (insn) || simplejump_p (insn))
    return;


  if (taken)
    cond_known_true = (((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx) == pc_rtx);
  else
    cond_known_true = (((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) == pc_rtx);




  code = ((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->code);
  op0 = fold_rtx (((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[0].rtx), insn);
  op1 = fold_rtx (((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx), insn);

  code = find_comparison_args (code, &op0, &op1, &mode0, &mode1);
  if (! cond_known_true)
    {
      reversed_nonequality = (code != EQ && code != NE);
      code = reverse_condition (code);
    }


  mode = mode0;
  if (mode1 != VOIDmode)
    mode = mode1;

  record_jump_cond (code, mode, op0, op1, reversed_nonequality);
}






static void
record_jump_cond(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1, int reversed_nonequality) asm("_record_jump_cond");
static void
record_jump_cond(n64_enum_rtx_code code, n64_enum_machine_mode mode, rtx op0, rtx op1, int reversed_nonequality)
{
  unsigned op0_hash, op1_hash;
  int op0_in_memory, op0_in_struct, op1_in_memory, op1_in_struct;
  struct n64_tag_table_elt *op0_elt, *op1_elt;







  if (code == EQ && ((op0)->code) == SUBREG
      && ((mode_size[(int)(((op0)->mode))])
   > (mode_size[(int)(((((op0)->fld[0].rtx))->mode))])))
    {
      n64_enum_machine_mode inner_mode = ((((op0)->fld[0].rtx))->mode);
      rtx tem = gen_lowpart_if_possible (inner_mode, op1);

      record_jump_cond (code, mode, ((op0)->fld[0].rtx),
   tem ? tem : gen_rtx (SUBREG, inner_mode, op1, 0),
   reversed_nonequality);
    }

  if (code == EQ && ((op1)->code) == SUBREG
      && ((mode_size[(int)(((op1)->mode))])
   > (mode_size[(int)(((((op1)->fld[0].rtx))->mode))])))
    {
      n64_enum_machine_mode inner_mode = ((((op1)->fld[0].rtx))->mode);
      rtx tem = gen_lowpart_if_possible (inner_mode, op0);

      record_jump_cond (code, mode, ((op1)->fld[0].rtx),
   tem ? tem : gen_rtx (SUBREG, inner_mode, op0, 0),
   reversed_nonequality);
    }
  if (code == NE && ((op0)->code) == SUBREG
      && subreg_lowpart_p (op0)
      && ((mode_size[(int)(((op0)->mode))])
   < (mode_size[(int)(((((op0)->fld[0].rtx))->mode))])))
    {
      n64_enum_machine_mode inner_mode = ((((op0)->fld[0].rtx))->mode);
      rtx tem = gen_lowpart_if_possible (inner_mode, op1);

      record_jump_cond (code, mode, ((op0)->fld[0].rtx),
   tem ? tem : gen_rtx (SUBREG, inner_mode, op1, 0),
   reversed_nonequality);
    }

  if (code == NE && ((op1)->code) == SUBREG
      && subreg_lowpart_p (op1)
      && ((mode_size[(int)(((op1)->mode))])
   < (mode_size[(int)(((((op1)->fld[0].rtx))->mode))])))
    {
      n64_enum_machine_mode inner_mode = ((((op1)->fld[0].rtx))->mode);
      rtx tem = gen_lowpart_if_possible (inner_mode, op0);

      record_jump_cond (code, mode, ((op1)->fld[0].rtx),
   tem ? tem : gen_rtx (SUBREG, inner_mode, op0, 0),
   reversed_nonequality);
    }



  do_not_record = 0;
  hash_arg_in_memory = 0;
  hash_arg_in_struct = 0;
  op0_hash = (((op0)->code) == REG && ((op0)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op0)->fld[0].rtint)]) % 31 : canon_hash (op0, mode) % 31);
  op0_in_memory = hash_arg_in_memory;
  op0_in_struct = hash_arg_in_struct;

  if (do_not_record)
    return;

  do_not_record = 0;
  hash_arg_in_memory = 0;
  hash_arg_in_struct = 0;
  op1_hash = (((op1)->code) == REG && ((op1)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op1)->fld[0].rtint)]) % 31 : canon_hash (op1, mode) % 31);
  op1_in_memory = hash_arg_in_memory;
  op1_in_struct = hash_arg_in_struct;

  if (do_not_record)
    return;


  op0_elt = lookup (op0, op0_hash, mode);
  op1_elt = lookup (op1, op1_hash, mode);



  if ((op0_elt != 0 && op1_elt != 0
       && op0_elt->first_same_value == op1_elt->first_same_value)
      || op0 == op1 || rtx_equal_p (op0, op1))
    return;







  if (code != EQ || ((mode_class[(int)(((op0)->mode))]) == MODE_FLOAT || (mode_class[(int)(((op0)->mode))]) == MODE_COMPLEX_FLOAT))
    {




      if (((op1)->code) != REG)
 op1 = equiv_constant (op1);

      if ((reversed_nonequality && ((mode_class[(int)(mode)]) == MODE_FLOAT || (mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT))
   || ((op0)->code) != REG || op1 == 0)
 return;



      if (op0_elt == 0)
 {
   if (insert_regs (op0, ((void *)0), 0))
     {
       rehash_using_reg (op0);
       op0_hash = (((op0)->code) == REG && ((op0)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op0)->fld[0].rtint)]) % 31 : canon_hash (op0, mode) % 31);




       if (! (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH))
  op1_hash = (((op1)->code) == REG && ((op1)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op1)->fld[0].rtint)]) % 31 : canon_hash (op1, mode) % 31);
     }

   op0_elt = insert (op0, ((void *)0), op0_hash, mode);
   op0_elt->in_memory = op0_in_memory;
   op0_elt->in_struct = op0_in_struct;
 }

      qty_comparison_code[reg_qty[((op0)->fld[0].rtint)]] = code;
      if (((op1)->code) == REG)
 {

   op1_elt = lookup (op1, op1_hash, mode);


   if (op1_elt == 0)
     {
       if (insert_regs (op1, ((void *)0), 0))
  {
    rehash_using_reg (op1);
    op1_hash = (((op1)->code) == REG && ((op1)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op1)->fld[0].rtint)]) % 31 : canon_hash (op1, mode) % 31);
  }

       op1_elt = insert (op1, ((void *)0), op1_hash, mode);
       op1_elt->in_memory = op1_in_memory;
       op1_elt->in_struct = op1_in_struct;
     }

   qty_comparison_qty[reg_qty[((op0)->fld[0].rtint)]] = reg_qty[((op1)->fld[0].rtint)];
   qty_comparison_const[reg_qty[((op0)->fld[0].rtint)]] = 0;
 }
      else
 {
   qty_comparison_qty[reg_qty[((op0)->fld[0].rtint)]] = -1;
   qty_comparison_const[reg_qty[((op0)->fld[0].rtint)]] = op1;
 }

      return;
    }




  if (op0_elt == 0)
    {
      if (insert_regs (op0, ((void *)0), 0))
 {
   rehash_using_reg (op0);
   op0_hash = (((op0)->code) == REG && ((op0)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op0)->fld[0].rtint)]) % 31 : canon_hash (op0, mode) % 31);
 }

      op0_elt = insert (op0, ((void *)0), op0_hash, mode);
      op0_elt->in_memory = op0_in_memory;
      op0_elt->in_struct = op0_in_struct;
    }

  if (op1_elt == 0)
    {
      if (insert_regs (op1, ((void *)0), 0))
 {
   rehash_using_reg (op1);
   op1_hash = (((op1)->code) == REG && ((op1)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((op1)->fld[0].rtint)]) % 31 : canon_hash (op1, mode) % 31);
 }

      op1_elt = insert (op1, ((void *)0), op1_hash, mode);
      op1_elt->in_memory = op1_in_memory;
      op1_elt->in_struct = op1_in_struct;
    }

  merge_equiv_classes (op0_elt, op1_elt);
  last_jump_equiv_class = op0_elt;
}
struct n64_tag_set
{

  rtx rtl;

  rtx src;

  struct n64_tag_table_elt *src_elt;

  unsigned src_hash;

  unsigned dest_hash;

  rtx inner_dest;

  rtx *inner_dest_loc;

  char src_in_memory;

  char src_in_struct;


  char src_volatile;

  n64_enum_machine_mode mode;

  rtx src_const;

  unsigned src_const_hash;

  struct n64_tag_table_elt *src_const_elt;
};

static void
cse_insn(rtx insn, int in_libcall_block) asm("_cse_insn");
static void
cse_insn(rtx insn, int in_libcall_block)
{
  register rtx x = ((insn)->fld[3].rtx);
  register int i;
  rtx tem;
  register int n_sets = 0;


  rtx this_insn_cc0 = 0;
  n64_enum_machine_mode this_insn_cc0_mode;
  struct n64_tag_write_data writes_memory;
  static struct n64_tag_write_data init = {0, 0, 0, 0};

  rtx src_eqv = 0;
  struct n64_tag_table_elt *src_eqv_elt = 0;
  int src_eqv_volatile;
  int src_eqv_in_memory;
  int src_eqv_in_struct;
  unsigned src_eqv_hash;

  struct n64_tag_set *sets;

  this_insn = insn;
  writes_memory = init;






  if (((insn)->code) == CALL_INSN)
    {
      for (tem = ((insn)->fld[7].rtx); tem; tem = ((tem)->fld[1].rtx))
 if (((((tem)->fld[0].rtx))->code) == CLOBBER)
          invalidate (((((tem)->fld[0].rtx))->fld[0].rtx), VOIDmode);
    }

  if (((x)->code) == SET)
    {
      sets = (struct n64_tag_set *) 
                           __builtin_alloca((
                           sizeof (struct n64_tag_set)
                           ))
                                                       ;
      sets[0].rtl = x;
      if (((x)->fld[0].rtx) == pc_rtx
   && ((((x)->fld[1].rtx))->code) == LABEL_REF)
 ;
      else if (((((x)->fld[1].rtx))->code) == CALL)
 {
   canon_reg (((x)->fld[1].rtx), insn);
   apply_change_group ();
   fold_rtx (((x)->fld[1].rtx), insn);
   invalidate (((x)->fld[0].rtx), VOIDmode);
 }
      else
 n_sets = 1;
    }
  else if (((x)->code) == PARALLEL)
    {
      register int lim = ((x)->fld[0].rtvec->num_elem);

      sets = (struct n64_tag_set *) 
                           __builtin_alloca((
                           lim * sizeof (struct n64_tag_set)
                           ))
                                                             ;
      for (i = 0; i < lim; i++)
 {
   register rtx y = ((x)->fld[0].rtvec->elem[i].rtx);
   if (((y)->code) == CLOBBER)
     {
       rtx clobbered = ((y)->fld[0].rtx);

       if (((clobbered)->code) == REG
    || ((clobbered)->code) == SUBREG)
  invalidate (clobbered, VOIDmode);
       else if (((clobbered)->code) == STRICT_LOW_PART
         || ((clobbered)->code) == ZERO_EXTRACT)
  invalidate (((clobbered)->fld[0].rtx), ((clobbered)->mode));
     }
 }

      for (i = 0; i < lim; i++)
 {
   register rtx y = ((x)->fld[0].rtvec->elem[i].rtx);
   if (((y)->code) == SET)
     {


       if (((((y)->fld[1].rtx))->code) == CALL)
  {
    canon_reg (((y)->fld[1].rtx), insn);
    apply_change_group ();
    fold_rtx (((y)->fld[1].rtx), insn);
    invalidate (((y)->fld[0].rtx), VOIDmode);
  }
       else if (((y)->fld[0].rtx) == pc_rtx
         && ((((y)->fld[1].rtx))->code) == LABEL_REF)
  ;
       else
  sets[n_sets++].rtl = y;
     }
   else if (((y)->code) == CLOBBER)
     {




       if (((((y)->fld[0].rtx))->code) == MEM)
  {
    canon_reg (((y)->fld[0].rtx), (rtx) 0);
    note_mem_written (((y)->fld[0].rtx), &writes_memory);
  }
     }
   else if (((y)->code) == USE
     && ! (((((y)->fld[0].rtx))->code) == REG
    && ((((y)->fld[0].rtx))->fld[0].rtint) < 68))
     canon_reg (y, (rtx) 0);
   else if (((y)->code) == CALL)
     {


       canon_reg (y, insn);
       apply_change_group ();
       fold_rtx (y, insn);
     }
 }
    }
  else if (((x)->code) == CLOBBER)
    {
      if (((((x)->fld[0].rtx))->code) == MEM)
 {
   canon_reg (((x)->fld[0].rtx), (rtx) 0);
   note_mem_written (((x)->fld[0].rtx), &writes_memory);
 }
    }


  else if (((x)->code) == USE
    && ! (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68))
    canon_reg (((x)->fld[0].rtx), (rtx) 0);
  else if (((x)->code) == CALL)
    {

      canon_reg (x, insn);
      apply_change_group ();
      fold_rtx (x, insn);
    }





  if (n_sets == 1 && ((insn)->fld[6].rtx) != 0
      && (tem = find_reg_note (insn, REG_EQUAL, (rtx) 0)) != 0
      && (! rtx_equal_p (((tem)->fld[0].rtx), ((sets[0].rtl)->fld[1].rtx))
   || ((((sets[0].rtl)->fld[0].rtx))->code) == STRICT_LOW_PART))
    src_eqv = canon_reg (((tem)->fld[0].rtx), (rtx) 0);
  for (i = 0; i < n_sets; i++)
    {
      rtx dest = ((sets[i].rtl)->fld[0].rtx);
      rtx src = ((sets[i].rtl)->fld[1].rtx);
      rtx cxx_new = canon_reg (src, insn);

      if ((((cxx_new)->code) == REG && ((src)->code) == REG
    && ((((cxx_new)->fld[0].rtint) < 68)
        != (((src)->fld[0].rtint) < 68)))
   || insn_n_dups[recog_memoized (insn)] > 0)
 validate_change (insn, &((sets[i].rtl)->fld[1].rtx), cxx_new, 1);
      else
 ((sets[i].rtl)->fld[1].rtx) = cxx_new;

      if (((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SIGN_EXTRACT)
 {
   validate_change (insn, &((dest)->fld[1].rtx),
      canon_reg (((dest)->fld[1].rtx), insn), 1);
   validate_change (insn, &((dest)->fld[2].rtx),
      canon_reg (((dest)->fld[2].rtx), insn), 1);
 }

      while (((dest)->code) == SUBREG || ((dest)->code) == STRICT_LOW_PART
      || ((dest)->code) == ZERO_EXTRACT
      || ((dest)->code) == SIGN_EXTRACT)
 dest = ((dest)->fld[0].rtx);

      if (((dest)->code) == MEM)
 canon_reg (dest, insn);
    }
  apply_change_group ();
  for (i = 0; i < n_sets; i++)
    {
      register rtx src, dest;
      register rtx src_folded;
      register struct n64_tag_table_elt *elt = 0, *p;
      n64_enum_machine_mode mode;
      rtx src_eqv_here;
      rtx src_const = 0;
      rtx src_related = 0;
      struct n64_tag_table_elt *src_const_elt = 0;
      int src_cost = 10000, src_eqv_cost = 10000, src_folded_cost = 10000;
      int src_related_cost = 10000, src_elt_cost = 10000;


      int src_folded_force_flag = 0;

      dest = ((sets[i].rtl)->fld[0].rtx);
      src = ((sets[i].rtl)->fld[1].rtx);





      mode = ((src)->mode) == VOIDmode ? ((dest)->mode) : ((src)->mode);
      sets[i].mode = mode;

      if (src_eqv)
 {
   n64_enum_machine_mode eqvmode = mode;
   if (((dest)->code) == STRICT_LOW_PART)
     eqvmode = ((((((dest)->fld[0].rtx))->fld[0].rtx))->mode);
   do_not_record = 0;
   hash_arg_in_memory = 0;
   hash_arg_in_struct = 0;
   src_eqv = fold_rtx (src_eqv, insn);
   src_eqv_hash = (((src_eqv)->code) == REG && ((src_eqv)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_eqv)->fld[0].rtint)]) % 31 : canon_hash (src_eqv, eqvmode) % 31);



   if (!do_not_record)
     src_eqv_elt = lookup (src_eqv, src_eqv_hash, eqvmode);

   src_eqv_volatile = do_not_record;
   src_eqv_in_memory = hash_arg_in_memory;
   src_eqv_in_struct = hash_arg_in_struct;
 }




      if (((dest)->code) == STRICT_LOW_PART)
 src_eqv_here = 0;
      else
 src_eqv_here = src_eqv;



      src_folded = fold_rtx (src, insn);
      do_not_record = 0;
      hash_arg_in_memory = 0;
      hash_arg_in_struct = 0;

      sets[i].src = src;
      sets[i].src_hash = (((src)->code) == REG && ((src)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src)->fld[0].rtint)]) % 31 : canon_hash (src, mode) % 31);
      sets[i].src_volatile = do_not_record;
      sets[i].src_in_memory = hash_arg_in_memory;
      sets[i].src_in_struct = hash_arg_in_struct;
      if (!sets[i].src_volatile)
 elt = lookup (src, sets[i].src_hash, mode);

      sets[i].src_elt = elt;

      if (elt && src_eqv_here && src_eqv_elt)
        {
          if (elt->first_same_value != src_eqv_elt->first_same_value)
     {


       merge_equiv_classes (elt, src_eqv_elt);
       src_eqv_hash = (((src_eqv)->code) == REG && ((src_eqv)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_eqv)->fld[0].rtint)]) % 31 : canon_hash (src_eqv, elt->mode) % 31);
       src_eqv_elt = lookup (src_eqv, src_eqv_hash, elt->mode);
     }

          src_eqv_here = 0;
        }

      else if (src_eqv_elt)
        elt = src_eqv_elt;





      if (elt)
        for (p = elt->first_same_value; p; p = p->next_same_value)
   if (p->is_const)
     {
       src_const = p->exp;
       src_const_elt = elt;
       break;
     }

      if (src_const == 0
   && ((((src_folded)->code) == LABEL_REF || ((src_folded)->code) == SYMBOL_REF || ((src_folded)->code) == CONST_INT || ((src_folded)->code) == CONST_DOUBLE || ((src_folded)->code) == CONST || ((src_folded)->code) == HIGH)



       || (((src_folded)->code) == MINUS
    && ((((src_folded)->fld[0].rtx))->code) == LABEL_REF
    && ((((src_folded)->fld[1].rtx))->code) == LABEL_REF)))
 src_const = src_folded, src_const_elt = elt;
      else if (src_const == 0 && src_eqv_here && (((src_eqv_here)->code) == LABEL_REF || ((src_eqv_here)->code) == SYMBOL_REF || ((src_eqv_here)->code) == CONST_INT || ((src_eqv_here)->code) == CONST_DOUBLE || ((src_eqv_here)->code) == CONST || ((src_eqv_here)->code) == HIGH))
 src_const = src_eqv_here, src_const_elt = src_eqv_elt;



      if (src_const && src_const_elt == 0)
 {
   sets[i].src_const_hash = (((src_const)->code) == REG && ((src_const)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_const)->fld[0].rtint)]) % 31 : canon_hash (src_const, mode) % 31);
   src_const_elt = lookup (src_const, sets[i].src_const_hash, mode);
 }

      sets[i].src_const = src_const;
      sets[i].src_const_elt = src_const_elt;




      if (src_const_elt && elt
   && src_const_elt->first_same_value != elt->first_same_value)
 merge_equiv_classes (elt, src_const_elt);
      else if (src_const_elt && elt == 0)
 elt = src_const_elt;



      if (src_const
   && (((src_const)->code) == CONST
       || (src_const_elt && src_const_elt->related_value != 0)))
        {
          src_related = use_related_value (src_const, src_const_elt);
          if (src_related)
            {
       struct n64_tag_table_elt *src_related_elt
      = lookup (src_related, (((src_related)->code) == REG && ((src_related)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_related)->fld[0].rtint)]) % 31 : canon_hash (src_related, mode) % 31), mode);
       if (src_related_elt && elt)
         {
    if (elt->first_same_value
        != src_related_elt->first_same_value)



      merge_equiv_classes (elt, src_related_elt);

           src_related = 0;
    src_related_elt = 0;
         }
              else if (src_related_elt && elt == 0)
         elt = src_related_elt;
     }
        }




      if (src_const && src_related == 0 && ((src_const)->code) == CONST_INT
   && (mode_class[(int)(mode)]) == MODE_INT
   && (8 * mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 64 : 32))
 {
   n64_enum_machine_mode wider_mode;

   for (wider_mode = (mode_wider_mode[(int)(mode)]);
        (8 * mode_size[(int)(wider_mode)]) <= ((target_flags & 0x00002000) ? 64 : 32)
        && src_related == 0;
        wider_mode = (mode_wider_mode[(int)(wider_mode)]))
     {
       struct n64_tag_table_elt *const_elt
  = lookup (src_const, (((src_const)->code) == REG && ((src_const)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_const)->fld[0].rtint)]) % 31 : canon_hash (src_const, wider_mode) % 31), wider_mode);

       if (const_elt == 0)
  continue;

       for (const_elt = const_elt->first_same_value;
     const_elt; const_elt = const_elt->next_same_value)
  if (((const_elt->exp)->code) == REG)
    {
      src_related = gen_lowpart_if_possible (mode,
          const_elt->exp);
      break;
    }
     }
 }







      if (flag_expensive_optimizations && ! src_related
   && ((src)->code) == AND && ((((src)->fld[1].rtx))->code) == CONST_INT
   && (mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4))
 {
   n64_enum_machine_mode tmode;
   rtx new_and = gen_rtx (AND, VOIDmode, (rtx) 0, ((src)->fld[1].rtx));

   for (tmode = (mode_wider_mode[(int)(mode)]);
        (mode_size[(int)(tmode)]) <= ((target_flags & 0x00002000) ? 8 : 4);
        tmode = (mode_wider_mode[(int)(tmode)]))
     {
       rtx inner = gen_lowpart_if_possible (tmode, ((src)->fld[0].rtx));
       struct n64_tag_table_elt *larger_elt;

       if (inner)
  {
    ((new_and)->mode = (tmode));
    ((new_and)->fld[0].rtx) = inner;
    larger_elt = lookup (new_and, (((new_and)->code) == REG && ((new_and)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((new_and)->fld[0].rtint)]) % 31 : canon_hash (new_and, tmode) % 31), tmode);
    if (larger_elt == 0)
      continue;

    for (larger_elt = larger_elt->first_same_value;
         larger_elt; larger_elt = larger_elt->next_same_value)
      if (((larger_elt->exp)->code) == REG)
        {
   src_related
     = gen_lowpart_if_possible (mode, larger_elt->exp);
   break;
        }

    if (src_related)
      break;
  }
     }
 }







      if (flag_expensive_optimizations && src_related == 0
   && ((mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4))
   && (mode_class[(int)(mode)]) == MODE_INT
   && ((src)->code) == MEM && ! do_not_record
   && ZERO_EXTEND != NIL)
 {
   n64_enum_machine_mode tmode;



   ((memory_extend_rtx)->code = (ZERO_EXTEND));
   ((memory_extend_rtx)->fld[0].rtx) = src;

   for (tmode = (mode_wider_mode[(int)(mode)]);
        (mode_size[(int)(tmode)]) <= ((target_flags & 0x00002000) ? 8 : 4);
        tmode = (mode_wider_mode[(int)(tmode)]))
     {
       struct n64_tag_table_elt *larger_elt;

       ((memory_extend_rtx)->mode = (tmode));
       larger_elt = lookup (memory_extend_rtx,
       (((memory_extend_rtx)->code) == REG && ((memory_extend_rtx)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((memory_extend_rtx)->fld[0].rtint)]) % 31 : canon_hash (memory_extend_rtx, tmode) % 31), tmode);
       if (larger_elt == 0)
  continue;

       for (larger_elt = larger_elt->first_same_value;
     larger_elt; larger_elt = larger_elt->next_same_value)
  if (((larger_elt->exp)->code) == REG)
    {
      src_related = gen_lowpart_if_possible (mode,
          larger_elt->exp);
      break;
    }

       if (src_related)
  break;
     }
 }


      if (src == src_folded)
        src_folded = 0;
      if (elt) elt = elt->first_same_value;
      for (p = elt; p; p = p->next_same_value)
        {
   n64_enum_rtx_code code = ((p->exp)->code);




   if (code != REG && ! exp_equiv_p (p->exp, p->exp, 1, 0))
     continue;

          if (src && ((src)->code) == code && rtx_equal_p (src, p->exp))
     src = 0;
          else if (src_folded && ((src_folded)->code) == code
     && rtx_equal_p (src_folded, p->exp))
     src_folded = 0;
          else if (src_eqv_here && ((src_eqv_here)->code) == code
     && rtx_equal_p (src_eqv_here, p->exp))
     src_eqv_here = 0;
          else if (src_related && ((src_related)->code) == code
     && rtx_equal_p (src_related, p->exp))
     src_related = 0;




   if (((dest)->code) == code && rtx_equal_p (p->exp, dest))
     src_related = dest;

        }







      if (src)
 {
   if (rtx_equal_p (src, dest))
     src_cost = -1;
   else
     src_cost = (((src)->code) == REG ? (((((src)->volatil) && ((src)->fld[0].rtint) < 68) || ((((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 29) || (((src)->fld[0].rtint)) == 0 || ((((src)->fld[0].rtint)) >= (68) && (((src)->fld[0].rtint)) <= (((68)) + 3)) || ((((src)->fld[0].rtint)) < 68 && ((((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src)->fld[0].rtint)] || global_regs[((src)->fld[0].rtint)]) && mips_regno_to_class[ (((src)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src, SET) * 2);
 }

      if (src_eqv_here)
 {
   if (rtx_equal_p (src_eqv_here, dest))
     src_eqv_cost = -1;
   else
     src_eqv_cost = (((src_eqv_here)->code) == REG ? (((((src_eqv_here)->volatil) && ((src_eqv_here)->fld[0].rtint) < 68) || ((((src_eqv_here)->fld[0].rtint)) == (0 + 30) || (((src_eqv_here)->fld[0].rtint)) == (0 + 30) || (((src_eqv_here)->fld[0].rtint)) == (0 + 29) || (((src_eqv_here)->fld[0].rtint)) == 0 || ((((src_eqv_here)->fld[0].rtint)) >= (68) && (((src_eqv_here)->fld[0].rtint)) <= (((68)) + 3)) || ((((src_eqv_here)->fld[0].rtint)) < 68 && ((((src_eqv_here)->fld[0].rtint)) == (0 + 30) || (((src_eqv_here)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src_eqv_here)->fld[0].rtint)] || global_regs[((src_eqv_here)->fld[0].rtint)]) && mips_regno_to_class[ (((src_eqv_here)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src_eqv_here)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src_eqv_here, SET) * 2);
 }

      if (src_folded)
 {
   if (rtx_equal_p (src_folded, dest))
     src_folded_cost = -1;
   else
     src_folded_cost = (((src_folded)->code) == REG ? (((((src_folded)->volatil) && ((src_folded)->fld[0].rtint) < 68) || ((((src_folded)->fld[0].rtint)) == (0 + 30) || (((src_folded)->fld[0].rtint)) == (0 + 30) || (((src_folded)->fld[0].rtint)) == (0 + 29) || (((src_folded)->fld[0].rtint)) == 0 || ((((src_folded)->fld[0].rtint)) >= (68) && (((src_folded)->fld[0].rtint)) <= (((68)) + 3)) || ((((src_folded)->fld[0].rtint)) < 68 && ((((src_folded)->fld[0].rtint)) == (0 + 30) || (((src_folded)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src_folded)->fld[0].rtint)] || global_regs[((src_folded)->fld[0].rtint)]) && mips_regno_to_class[ (((src_folded)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src_folded)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src_folded, SET) * 2);
 }

      if (src_related)
 {
   if (rtx_equal_p (src_related, dest))
     src_related_cost = -1;
   else
     src_related_cost = (((src_related)->code) == REG ? (((((src_related)->volatil) && ((src_related)->fld[0].rtint) < 68) || ((((src_related)->fld[0].rtint)) == (0 + 30) || (((src_related)->fld[0].rtint)) == (0 + 30) || (((src_related)->fld[0].rtint)) == (0 + 29) || (((src_related)->fld[0].rtint)) == 0 || ((((src_related)->fld[0].rtint)) >= (68) && (((src_related)->fld[0].rtint)) <= (((68)) + 3)) || ((((src_related)->fld[0].rtint)) < 68 && ((((src_related)->fld[0].rtint)) == (0 + 30) || (((src_related)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src_related)->fld[0].rtint)] || global_regs[((src_related)->fld[0].rtint)]) && mips_regno_to_class[ (((src_related)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src_related)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src_related, SET) * 2);
 }



      if (dest == pc_rtx && src_const && ((src_const)->code) == LABEL_REF)
 src_folded = src_const, src_folded_cost = -1;



      while (1)
        {
          rtx trial;


          while (elt && ((elt->exp)->code) != REG
          && ! exp_equiv_p (elt->exp, elt->exp, 1, 0))
     elt = elt->next_same_value;

          if (elt) src_elt_cost = elt->cost;




          if (src_folded_cost <= src_cost
       && src_folded_cost <= src_eqv_cost
       && src_folded_cost <= src_related_cost
       && src_folded_cost <= src_elt_cost)
     {
       trial = src_folded, src_folded_cost = 10000;
       if (src_folded_force_flag)
  trial = force_const_mem (mode, trial);
     }
          else if (src_cost <= src_eqv_cost
            && src_cost <= src_related_cost
            && src_cost <= src_elt_cost)
     trial = src, src_cost = 10000;
          else if (src_eqv_cost <= src_related_cost
            && src_eqv_cost <= src_elt_cost)
     trial = copy_rtx (src_eqv_here), src_eqv_cost = 10000;
          else if (src_related_cost <= src_elt_cost)
     trial = copy_rtx (src_related), src_related_cost = 10000;
          else
     {
       trial = copy_rtx (elt->exp);
       elt = elt->next_same_value;
       src_elt_cost = 10000;
     }
   if (n_sets == 1 && dest == pc_rtx
       && (trial == pc_rtx
    || (((trial)->code) == LABEL_REF
        && ! condjump_p (insn))))
     {



       if (((trial)->code) == CODE_LABEL
    && ((trial)->fld[2].rtx) != 0
    && ((((trial)->fld[2].rtx))->code) == JUMP_INSN
    && (((((((trial)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_DIFF_VEC
        || ((((((trial)->fld[2].rtx))->fld[3].rtx))->code) == ADDR_VEC))

  trial = gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), get_label_after (trial));

       ((sets[i].rtl)->fld[1].rtx) = trial;
        cse_jumps_altered = 1;
       break;
     }


          else if (validate_change (insn, &((sets[i].rtl)->fld[1].rtx), trial, 0))
     {



       validate_change (insn, &((sets[i].rtl)->fld[1].rtx),
          canon_reg (((sets[i].rtl)->fld[1].rtx), insn),
          1);
       apply_change_group ();
       break;
     }






   else if (constant_pool_entries_cost
     && (((trial)->code) == LABEL_REF || ((trial)->code) == SYMBOL_REF || ((trial)->code) == CONST_INT || ((trial)->code) == CONST_DOUBLE || ((trial)->code) == CONST || ((trial)->code) == HIGH)
     && ! (((trial)->code) == CONST
    && ((((trial)->fld[0].rtx))->code) == TRUNCATE)
     && (src_folded == 0
         || (((src_folded)->code) != MEM
      && ! src_folded_force_flag))
     && (mode_class[(int)(mode)]) != MODE_CC)
     {
       src_folded_force_flag = 1;
       src_folded = trial;
       src_folded_cost = constant_pool_entries_cost;
     }
        }

      src = ((sets[i].rtl)->fld[1].rtx);







      if (((dest)->code) == REG
   && (reg_qty[((dest)->fld[0].rtint)] != (((dest)->fld[0].rtint)))
   && qty_mode[reg_qty[((dest)->fld[0].rtint)]] == ((dest)->mode)
   && qty_first_reg[reg_qty[((dest)->fld[0].rtint)]] != ((dest)->fld[0].rtint)
   && ((src)->code) == REG && ((src)->fld[0].rtint) == ((dest)->fld[0].rtint)


   && (((sets[i].src)->code) != REG
       || ((sets[i].src)->fld[0].rtint) >= 68))


 {
   int first = qty_first_reg[reg_qty[((src)->fld[0].rtint)]];

   src = ((sets[i].rtl)->fld[1].rtx)
     = first >= 68 ? regno_reg_rtx[first]
       : gen_rtx (REG, ((src)->mode), first);




   if (src_const && (((src_const)->code) == REG ? (((((src_const)->volatil) && ((src_const)->fld[0].rtint) < 68) || ((((src_const)->fld[0].rtint)) == (0 + 30) || (((src_const)->fld[0].rtint)) == (0 + 30) || (((src_const)->fld[0].rtint)) == (0 + 29) || (((src_const)->fld[0].rtint)) == 0 || ((((src_const)->fld[0].rtint)) >= (68) && (((src_const)->fld[0].rtint)) <= (((68)) + 3)) || ((((src_const)->fld[0].rtint)) < 68 && ((((src_const)->fld[0].rtint)) == (0 + 30) || (((src_const)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src_const)->fld[0].rtint)] || global_regs[((src_const)->fld[0].rtint)]) && mips_regno_to_class[ (((src_const)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src_const)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src_const, SET) * 2) < (((src)->code) == REG ? (((((src)->volatil) && ((src)->fld[0].rtint) < 68) || ((((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 29) || (((src)->fld[0].rtint)) == 0 || ((((src)->fld[0].rtint)) >= (68) && (((src)->fld[0].rtint)) <= (((68)) + 3)) || ((((src)->fld[0].rtint)) < 68 && ((((src)->fld[0].rtint)) == (0 + 30) || (((src)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src)->fld[0].rtint)] || global_regs[((src)->fld[0].rtint)]) && mips_regno_to_class[ (((src)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src, SET) * 2)
       && validate_change (insn, &((sets[i].rtl)->fld[1].rtx), src_const, 0))
     src = src_const;
 }


      if (src != sets[i].src)
        {
          do_not_record = 0;
          hash_arg_in_memory = 0;
          hash_arg_in_struct = 0;
   sets[i].src = src;
          sets[i].src_hash = (((src)->code) == REG && ((src)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src)->fld[0].rtint)]) % 31 : canon_hash (src, mode) % 31);
          sets[i].src_volatile = do_not_record;
          sets[i].src_in_memory = hash_arg_in_memory;
          sets[i].src_in_struct = hash_arg_in_struct;
          sets[i].src_elt = lookup (src, sets[i].src_hash, mode);
        }






      if (n_sets == 1 && src_const && ((dest)->code) == REG
   && ((src_const)->code) != REG)
 {
   tem = find_reg_note (insn, REG_EQUAL, (rtx) 0);



   if (tem)
     ((tem)->fld[0].rtx) = src_const;
   else
     ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_EQUAL,
            src_const, ((insn)->fld[6].rtx));
   if ((reg_qty[((dest)->fld[0].rtint)] != (((dest)->fld[0].rtint)))
       && qty_const[reg_qty[((dest)->fld[0].rtint)]] == const0_rtx)
     {

       rtx note = find_reg_note (insn, REG_WAS_0, (rtx) 0);
       rtx const_insn = qty_const_insn[reg_qty[((dest)->fld[0].rtint)]];

       if ((tem = single_set (const_insn)) != 0
    && rtx_equal_p (((tem)->fld[0].rtx), dest))
  {
    if (note)
      ((note)->fld[0].rtx) = const_insn;
    else
      ((insn)->fld[6].rtx) = gen_rtx (INSN_LIST, REG_WAS_0,
      const_insn, ((insn)->fld[6].rtx));
  }
     }
 }


      do_not_record = 0;
      sets[i].inner_dest_loc = &((sets[0].rtl)->fld[0].rtx);



      while (((dest)->code) == SIGN_EXTRACT
      || ((dest)->code) == ZERO_EXTRACT
      || ((dest)->code) == SUBREG
      || ((dest)->code) == STRICT_LOW_PART)
 {
   sets[i].inner_dest_loc = &((dest)->fld[0].rtx);
   dest = ((dest)->fld[0].rtx);
 }

      sets[i].inner_dest = dest;

      if (((dest)->code) == MEM)
 {
   dest = fold_rtx (dest, insn);





   note_mem_written (dest, &writes_memory);
 }





      sets[i].dest_hash = (((dest)->code) == REG && ((dest)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((dest)->fld[0].rtint)]) % 31 : canon_hash (dest, mode) % 31);





      if (((((sets[i].rtl)->fld[0].rtx))->code) == ZERO_EXTRACT
   || ((((sets[i].rtl)->fld[0].rtx))->code) == SIGN_EXTRACT)
 {
   rtx width = ((((sets[i].rtl)->fld[0].rtx))->fld[1].rtx);

   if (src_const != 0 && ((src_const)->code) == CONST_INT
       && ((width)->code) == CONST_INT
       && ((width)->fld[0].rtwint) < 32
       && ! (((src_const)->fld[0].rtwint)
      & ((int) (-1) << ((width)->fld[0].rtwint))))


     ;
   else
     {




       sets[i].src_elt = 0;
       sets[i].src_volatile = 1;
       src_eqv = 0;
       src_eqv_elt = 0;
     }
 }



      else if (n_sets == 1 && dest == pc_rtx && src == pc_rtx)
 {
   ((insn)->code = (NOTE));
   ((insn)->fld[4].rtint) = -1;
   ((insn)->fld[3].rtstr) = 0;
   cse_jumps_altered = 1;

   --((((insn)->fld[7].rtx))->fld[5].rtint);

   sets[i].rtl = 0;
 }




      else if (dest == pc_rtx && ((src)->code) == LABEL_REF)
 {
   rtx p;



   if (! simplejump_p (insn) && n_sets == 1)
     {
       rtx cxx_new = emit_jump_insn_before (gen_jump (((src)->fld[0].rtx)), insn);
       ((cxx_new)->fld[7].rtx) = ((src)->fld[0].rtx);
       ((((src)->fld[0].rtx))->fld[5].rtint)++;
       delete_insn (insn);
       insn = cxx_new;
     }
   else





     ((insn)->fld[4].rtint) = -1;







   p = insn;

   while (((p)->fld[2].rtx) != 0
   && ((((p)->fld[2].rtx))->code) != BARRIER
   && ((((p)->fld[2].rtx))->code) != CODE_LABEL)
     {
       if (((((p)->fld[2].rtx))->code) != NOTE
    || ((((p)->fld[2].rtx))->fld[4].rtint) == -1)
  delete_insn (((p)->fld[2].rtx));
       else
  p = ((p)->fld[2].rtx);
     }





   if (((insn)->fld[2].rtx) == 0
       || ((((insn)->fld[2].rtx))->code) != BARRIER)
     emit_barrier_before (((insn)->fld[2].rtx));




   if (p != insn && ((p)->fld[2].rtx) != 0
       && ((((p)->fld[2].rtx))->code) == BARRIER)
     delete_insn (((p)->fld[2].rtx));

   cse_jumps_altered = 1;
   sets[i].rtl = 0;
 }




      else if (do_not_record)
 {
   if (((dest)->code) == REG || ((dest)->code) == SUBREG
       || ((dest)->code) == MEM)
     invalidate (dest, VOIDmode);
   else if (((dest)->code) == STRICT_LOW_PART
     || ((dest)->code) == ZERO_EXTRACT)
     invalidate (((dest)->fld[0].rtx), ((dest)->mode));
   sets[i].rtl = 0;
 }

      if (sets[i].rtl != 0 && dest != ((sets[i].rtl)->fld[0].rtx))
 sets[i].dest_hash = (((((sets[i].rtl)->fld[0].rtx))->code) == REG && ((((sets[i].rtl)->fld[0].rtx))->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((((sets[i].rtl)->fld[0].rtx))->fld[0].rtint)]) % 31 : canon_hash (((sets[i].rtl)->fld[0].rtx), mode) % 31);
    }
  if (src_eqv && src_eqv_elt == 0 && sets[0].rtl != 0 && ! src_eqv_volatile
      && ! rtx_equal_p (src_eqv, ((sets[0].rtl)->fld[0].rtx)))
    {
      register struct n64_tag_table_elt *elt;
      register struct n64_tag_table_elt *classp = sets[0].src_elt;
      rtx dest = ((sets[0].rtl)->fld[0].rtx);
      n64_enum_machine_mode eqvmode = ((dest)->mode);

      if (((dest)->code) == STRICT_LOW_PART)
 {
   eqvmode = ((((((dest)->fld[0].rtx))->fld[0].rtx))->mode);
   classp = 0;
 }
      if (insert_regs (src_eqv, classp, 0))
 {
   rehash_using_reg (src_eqv);
   src_eqv_hash = (((src_eqv)->code) == REG && ((src_eqv)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src_eqv)->fld[0].rtint)]) % 31 : canon_hash (src_eqv, eqvmode) % 31);
 }
      elt = insert (src_eqv, classp, src_eqv_hash, eqvmode);
      elt->in_memory = src_eqv_in_memory;
      elt->in_struct = src_eqv_in_struct;
      src_eqv_elt = elt;




      for (i = 0; i < n_sets; i++)
 if (sets[i].rtl && sets[i].src_elt == 0
     && rtx_equal_p (((sets[i].rtl)->fld[1].rtx), src_eqv))
   sets[i].src_elt = src_eqv_elt;
    }

  for (i = 0; i < n_sets; i++)
    if (sets[i].rtl && ! sets[i].src_volatile
 && ! rtx_equal_p (((sets[i].rtl)->fld[1].rtx), ((sets[i].rtl)->fld[0].rtx)))
      {
 if (((((sets[i].rtl)->fld[0].rtx))->code) == STRICT_LOW_PART)
   {





     sets[i].src_elt = src_eqv_elt;
     sets[i].src_hash = src_eqv_hash;
   }
 else
   {


     register struct n64_tag_table_elt *classp = src_eqv_elt;
     register rtx src = sets[i].src;
     register rtx dest = ((sets[i].rtl)->fld[0].rtx);
     n64_enum_machine_mode mode
       = ((src)->mode) == VOIDmode ? ((dest)->mode) : ((src)->mode);

     if (sets[i].src_elt == 0)
       {
  register struct n64_tag_table_elt *elt;




  if (insert_regs (src, classp, 0))
    {
      rehash_using_reg (src);
      sets[i].src_hash = (((src)->code) == REG && ((src)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((src)->fld[0].rtint)]) % 31 : canon_hash (src, mode) % 31);
    }
  elt = insert (src, classp, sets[i].src_hash, mode);
  elt->in_memory = sets[i].src_in_memory;
  elt->in_struct = sets[i].src_in_struct;
  sets[i].src_elt = classp = elt;
       }

     if (sets[i].src_const && sets[i].src_const_elt == 0
  && src != sets[i].src_const
  && ! rtx_equal_p (sets[i].src_const, src))
       sets[i].src_elt = insert (sets[i].src_const, classp,
     sets[i].src_const_hash, mode);
   }
      }
    else if (sets[i].src_elt == 0)



      sets[i].src_elt = src_eqv_elt;

  invalidate_from_clobbers (&writes_memory, x);




  if (((insn)->code) == CALL_INSN)
    {
      static struct n64_tag_write_data everything = {0, 1, 1, 1};

      if (! ((insn)->unchanging))
 invalidate_memory (&everything);
      invalidate_for_call ();
    }






  for (i = 0; i < n_sets; i++)
    if (sets[i].rtl)
      {


 register rtx dest = ((sets[i].rtl)->fld[0].rtx);





 if (((dest)->code) == REG || ((dest)->code) == SUBREG
     || (((dest)->code) == MEM && ! writes_memory.all
  && ! cse_rtx_addr_varies_p (dest)))
   invalidate (dest, VOIDmode);
 else if (((dest)->code) == STRICT_LOW_PART
   || ((dest)->code) == ZERO_EXTRACT)
   invalidate (((dest)->fld[0].rtx), ((dest)->mode));
      }
  for (i = 0; i < n_sets; i++)
    if (sets[i].rtl && ((((sets[i].rtl)->fld[0].rtx))->code) != REG)
      mention_regs (((sets[i].rtl)->fld[0].rtx));




  for (i = 0; i < n_sets; i++)
    if (sets[i].rtl)
      {
 if (sets[i].src_elt && sets[i].src_elt->first_same_value == 0)


   {
     register struct n64_tag_table_elt *elt = sets[i].src_elt;

     while (elt && elt->prev_same_value)
       elt = elt->prev_same_value;

     while (elt && elt->first_same_value == 0)
       elt = elt->next_same_value;
     sets[i].src_elt = elt ? elt->first_same_value : 0;
   }
      }



  for (i = 0; i < n_sets; i++)
    if (sets[i].rtl)
      {
 register rtx dest = ((sets[i].rtl)->fld[0].rtx);
 register struct n64_tag_table_elt *elt;




 if ((flag_float_store
      && ((dest)->code) == MEM
      && ((mode_class[(int)(((dest)->mode))]) == MODE_FLOAT || (mode_class[(int)(((dest)->mode))]) == MODE_COMPLEX_FLOAT))




     || in_libcall_block


     || sets[i].src_elt == 0





     || (((dest)->code) == SUBREG
  && ((mode_size[(int)(((dest)->mode))])
      > (mode_size[(int)(((((dest)->fld[0].rtx))->mode))]))
  && (((sets[i].src)->code) == SIGN_EXTEND
      || ((sets[i].src)->code) == ZERO_EXTEND)))
   continue;




 if (((dest)->code) == STRICT_LOW_PART)
   dest = ((((dest)->fld[0].rtx))->fld[0].rtx);

 if (((dest)->code) == REG || ((dest)->code) == SUBREG)

   if (insert_regs (dest, sets[i].src_elt, 1))
     {


       rehash_using_reg (dest);
       sets[i].dest_hash = (((dest)->code) == REG && ((dest)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((dest)->fld[0].rtint)]) % 31 : canon_hash (dest, ((dest)->mode)) % 31);
     }

 elt = insert (dest, sets[i].src_elt,
        sets[i].dest_hash, ((dest)->mode));
 elt->in_memory = (((sets[i].inner_dest)->code) == MEM
     && ! ((sets[i].inner_dest)->unchanging));

 if (elt->in_memory)
   {



     elt->in_struct = (((sets[i].inner_dest)->in_struct)
         || sets[i].inner_dest != ((sets[i].rtl)->fld[0].rtx));
   }
 if (((dest)->code) == SUBREG
     && ((((mode_size[(int)(((((dest)->fld[0].rtx))->mode))]) - 1)
   / ((target_flags & 0x00002000) ? 8 : 4))
  == ((mode_size[(int)(((dest)->mode))]) - 1)/ ((target_flags & 0x00002000) ? 8 : 4))
     && ((mode_size[(int)(((dest)->mode))])
  >= (mode_size[(int)(((((dest)->fld[0].rtx))->mode))]))
     && sets[i].src_elt != 0)
   {
     n64_enum_machine_mode new_mode = ((((dest)->fld[0].rtx))->mode);
     struct n64_tag_table_elt *elt, *classp = 0;

     for (elt = sets[i].src_elt->first_same_value; elt;
   elt = elt->next_same_value)
       {
  rtx new_src = 0;
  unsigned src_hash;
  struct n64_tag_table_elt *src_elt;


  if (((elt->exp)->code) != REG
      && ! exp_equiv_p (elt->exp, elt->exp, 1, 0))
    continue;

  new_src = gen_lowpart_if_possible (new_mode, elt->exp);
  if (new_src == 0)
    new_src = gen_rtx (SUBREG, new_mode, elt->exp, 0);

  src_hash = (((new_src)->code) == REG && ((new_src)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((new_src)->fld[0].rtint)]) % 31 : canon_hash (new_src, new_mode) % 31);
  src_elt = lookup (new_src, src_hash, new_mode);



  if (src_elt == 0)
    {
      if (insert_regs (new_src, classp, 0))
        {
   rehash_using_reg (new_src);
   src_hash = (((new_src)->code) == REG && ((new_src)->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((new_src)->fld[0].rtint)]) % 31 : canon_hash (new_src, new_mode) % 31);
        }
      src_elt = insert (new_src, classp, src_hash, new_mode);
      src_elt->in_memory = elt->in_memory;
      src_elt->in_struct = elt->in_struct;
    }
  else if (classp && classp != src_elt->first_same_value)


    merge_equiv_classes (src_elt, classp);

  classp = src_elt->first_same_value;
       }
   }
      }
  if (n_sets == 1 && sets[0].rtl && ((((sets[0].rtl)->fld[0].rtx))->code) == REG
      && ((((insn)->fld[1].rtx))->fld[2].rtx) == insn
      && ((((sets[0].rtl)->fld[1].rtx))->code) == REG
      && ((((sets[0].rtl)->fld[1].rtx))->fld[0].rtint) >= 68
      && (reg_qty[((((sets[0].rtl)->fld[1].rtx))->fld[0].rtint)] != (((((sets[0].rtl)->fld[1].rtx))->fld[0].rtint)))
      && (qty_first_reg[reg_qty[((((sets[0].rtl)->fld[1].rtx))->fld[0].rtint)]]
   == ((((sets[0].rtl)->fld[0].rtx))->fld[0].rtint)))
    {
      rtx prev = ((insn)->fld[1].rtx);
      while (prev && ((prev)->code) == NOTE)
 prev = ((prev)->fld[1].rtx);

      if (prev && ((prev)->code) == INSN && ((((prev)->fld[3].rtx))->code) == SET
   && ((((prev)->fld[3].rtx))->fld[0].rtx) == ((sets[0].rtl)->fld[1].rtx))
 {
   rtx dest = ((sets[0].rtl)->fld[0].rtx);
   rtx note = find_reg_note (prev, REG_EQUIV, (rtx) 0);

   validate_change (prev, & ((((prev)->fld[3].rtx))->fld[0].rtx), dest, 1);
   validate_change (insn, & ((sets[0].rtl)->fld[0].rtx),
      ((sets[0].rtl)->fld[1].rtx), 1);
   validate_change (insn, & ((sets[0].rtl)->fld[1].rtx), dest, 1);
   apply_change_group ();


   if (note)
     ((note)->mode = ((n64_enum_machine_mode) (REG_EQUAL)));



   note = find_reg_note (prev, REG_WAS_0, (rtx) 0);
   if (note)
     remove_note (prev, note);

   note = find_reg_note (insn, REG_WAS_0, (rtx) 0);
   if (note)
     {
       remove_note (insn, note);
       ((note)->fld[1].rtx) = ((prev)->fld[6].rtx);
       ((prev)->fld[6].rtx) = note;
     }



   note = find_reg_note (insn, REG_EQUAL, (rtx) 0);
   if (note && reg_mentioned_p (dest, ((note)->fld[0].rtx)))
     remove_note (insn, note);
 }
    }




  last_jump_equiv_class = 0;
  if (((insn)->code) == JUMP_INSN
      && n_sets == 1 && ((x)->code) == SET
      && ((((x)->fld[1].rtx))->code) == IF_THEN_ELSE)
    record_jump_equiv (insn, 0);
  prev_insn = insn;
}





static void
note_mem_written(rtx written, struct n64_tag_write_data *writes_ptr) asm("_note_mem_written");
static void
note_mem_written(rtx written, struct n64_tag_write_data *writes_ptr)
{
  static struct n64_tag_write_data everything = {0, 1, 1, 1};

  if (written == 0)
    *writes_ptr = everything;
  else if (((written)->code) == MEM)
    {

      rtx addr = ((written)->fld[0].rtx);
      if ((((addr)->code) == PRE_DEC || ((addr)->code) == PRE_INC
    || ((addr)->code) == POST_DEC || ((addr)->code) == POST_INC)
   && ((((addr)->fld[0].rtx))->code) == REG
   && ((((addr)->fld[0].rtx))->fld[0].rtint) == (0 + 29))
 {
   writes_ptr->sp = 1;
   return;
 }
      else if (((written)->mode) == BLKmode)
 *writes_ptr = everything;

      else if (((addr)->code) == SCRATCH)
 *writes_ptr = everything;
      else if (cse_rtx_addr_varies_p (written))
 {





   if (! ((((written)->in_struct)
    || ((((written)->fld[0].rtx))->code) == PLUS)
   && ((written)->mode) != QImode))
     writes_ptr->all = 1;
   writes_ptr->nonscalar = 1;
 }
      writes_ptr->var = 1;
    }
}
static void
invalidate_from_clobbers(struct n64_tag_write_data *w, rtx x) asm("_invalidate_from_clobbers");
static void
invalidate_from_clobbers(struct n64_tag_write_data *w, rtx x)
{



  if (w->var)
    invalidate_memory (w);

  if (w->sp)
    {
      if (reg_tick[(0 + 29)] >= 0)
 reg_tick[(0 + 29)]++;


      if (((hard_regs_in_table)[((0 + 29)) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << (((0 + 29)) % ((unsigned) 32)))))
 invalidate (stack_pointer_rtx, VOIDmode);
    }

  if (((x)->code) == CLOBBER)
    {
      rtx ref = ((x)->fld[0].rtx);
      if (ref)
 {
   if (((ref)->code) == REG || ((ref)->code) == SUBREG
       || (((ref)->code) == MEM && ! w->all))
     invalidate (ref, VOIDmode);
   else if (((ref)->code) == STRICT_LOW_PART
     || ((ref)->code) == ZERO_EXTRACT)
     invalidate (((ref)->fld[0].rtx), ((ref)->mode));
 }
    }
  else if (((x)->code) == PARALLEL)
    {
      register int i;
      for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   register rtx y = ((x)->fld[0].rtvec->elem[i].rtx);
   if (((y)->code) == CLOBBER)
     {
       rtx ref = ((y)->fld[0].rtx);
       if (ref)
  {
    if (((ref)->code) == REG || ((ref)->code) == SUBREG
        || (((ref)->code) == MEM && !w->all))
      invalidate (ref, VOIDmode);
    else if (((ref)->code) == STRICT_LOW_PART
      || ((ref)->code) == ZERO_EXTRACT)
      invalidate (((ref)->fld[0].rtx), ((ref)->mode));
  }
     }
 }
    }
}
static rtx
cse_process_notes(rtx x, rtx object) asm("_cse_process_notes");
static rtx
cse_process_notes(rtx x, rtx object)
{
  n64_enum_rtx_code code = ((x)->code);
  char *fmt = (rtx_format[(int)(code)]);
  int i;

  switch (code)
    {
    case CONST_INT:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
    case CONST_DOUBLE:
    case PC:
    case CC0:
    case LO_SUM:
      return x;

    case MEM:
      ((x)->fld[0].rtx) = cse_process_notes (((x)->fld[0].rtx), x);
      return x;

    case EXPR_LIST:
    case INSN_LIST:
      if (((n64_enum_reg_note) ((x)->mode)) == REG_EQUAL)
 ((x)->fld[0].rtx) = cse_process_notes (((x)->fld[0].rtx), (rtx) 0);
      if (((x)->fld[1].rtx))
 ((x)->fld[1].rtx) = cse_process_notes (((x)->fld[1].rtx), (rtx) 0);
      return x;

    case SIGN_EXTEND:
    case ZERO_EXTEND:
      {
 rtx cxx_new = cse_process_notes (((x)->fld[0].rtx), object);


 if (((cxx_new)->mode) != VOIDmode)
   validate_change (object, &((x)->fld[0].rtx), cxx_new, 0);
 return x;
      }

    case REG:
      i = reg_qty[((x)->fld[0].rtint)];


      if ((reg_qty[((x)->fld[0].rtint)] != (((x)->fld[0].rtint)))
   && qty_const[i] != 0
   && ((((qty_const[i])->code) == LABEL_REF || ((qty_const[i])->code) == SYMBOL_REF || ((qty_const[i])->code) == CONST_INT || ((qty_const[i])->code) == CONST_DOUBLE || ((qty_const[i])->code) == CONST || ((qty_const[i])->code) == HIGH)
       || ((qty_const[i])->code) == REG))
 {
   rtx cxx_new = gen_lowpart_if_possible (((x)->mode), qty_const[i]);
   if (cxx_new)
     return cxx_new;
 }


      return canon_reg (x, (rtx) 0);
    }

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    if (fmt[i] == 'e')
      validate_change (object, &((x)->fld[i].rtx),
         cse_process_notes (((x)->fld[i].rtx), object), 0);

  return x;
}
static void
cse_around_loop(rtx loop_start) asm("_cse_around_loop");
static void
cse_around_loop(rtx loop_start)
{
  rtx insn;
  int i;
  struct n64_tag_table_elt *p;



  for (insn = ((loop_start)->fld[1].rtx);
       insn && (((insn)->code) == NOTE && ((insn)->fld[4].rtint) >= 0);
       insn = ((insn)->fld[1].rtx))
    ;

  if (insn == 0
      || ((insn)->code) != NOTE
      || ((insn)->fld[4].rtint) != -4)
    return;





  if (last_jump_equiv_class)
    for (p = last_jump_equiv_class->first_same_value; p;
  p = p->next_same_value)
      if (((p->exp)->code) == MEM || ((p->exp)->code) == REG
   || (((p->exp)->code) == SUBREG
       && ((((p->exp)->fld[0].rtx))->code) == REG))
 invalidate (p->exp, VOIDmode);
      else if (((p->exp)->code) == STRICT_LOW_PART
        || ((p->exp)->code) == ZERO_EXTRACT)
 invalidate (((p->exp)->fld[0].rtx), ((p->exp)->mode));
  for (insn = ((loop_start)->fld[2].rtx);
       ((insn)->code) != CALL_INSN && ((insn)->code) != CODE_LABEL
       && ! (((insn)->code) == NOTE
      && ((insn)->fld[4].rtint) == -5);
       insn = ((insn)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((insn)->code))]) == 'i'
   && (((((insn)->fld[3].rtx))->code) == SET
       || ((((insn)->fld[3].rtx))->code) == CLOBBER))
 cse_set_around_loop (((insn)->fld[3].rtx), insn, loop_start);
      else if ((rtx_class[(int)(((insn)->code))]) == 'i'
        && ((((insn)->fld[3].rtx))->code) == PARALLEL)
 for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
   if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) == SET
       || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx))->code) == CLOBBER)
     cse_set_around_loop (((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx), insn,
     loop_start);
    }
}



static struct n64_tag_write_data skipped_writes_memory;




static void
invalidate_skipped_set(rtx dest, rtx set) asm("_invalidate_skipped_set");
static void
invalidate_skipped_set(rtx dest, rtx set)
{
  if (((set)->code) == CLOBBER



      || dest == pc_rtx)
    return;

  if (((dest)->code) == MEM)
    note_mem_written (dest, &skipped_writes_memory);




  if (skipped_writes_memory.nonscalar)
    skipped_writes_memory.all = 1;

  if (((dest)->code) == REG || ((dest)->code) == SUBREG
      || (! skipped_writes_memory.all && ! cse_rtx_addr_varies_p (dest)))
    invalidate (dest, VOIDmode);
  else if (((dest)->code) == STRICT_LOW_PART
    || ((dest)->code) == ZERO_EXTRACT)
    invalidate (((dest)->fld[0].rtx), ((dest)->mode));
}





static void
invalidate_skipped_block(rtx start) asm("_invalidate_skipped_block");
static void
invalidate_skipped_block(rtx start)
{
  rtx insn;
  static struct n64_tag_write_data init = {0, 0, 0, 0};
  static struct n64_tag_write_data everything = {0, 1, 1, 1};

  for (insn = start; insn && ((insn)->code) != CODE_LABEL;
       insn = ((insn)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((insn)->code))]) != 'i')
 continue;

      skipped_writes_memory = init;

      if (((insn)->code) == CALL_INSN)
 {
   invalidate_for_call ();
   skipped_writes_memory = everything;
 }

      note_stores (((insn)->fld[3].rtx), invalidate_skipped_set);
      invalidate_from_clobbers (&skipped_writes_memory, ((insn)->fld[3].rtx));
    }
}




static rtx cse_check_loop_start_value;




static void
cse_check_loop_start(rtx x, rtx set) asm("_cse_check_loop_start");
static void
cse_check_loop_start(rtx x, rtx set)
{
  if (cse_check_loop_start_value == 0
      || ((x)->code) == CC0 || ((x)->code) == PC)
    return;

  if ((((x)->code) == MEM && ((cse_check_loop_start_value)->code) == MEM)
      || reg_overlap_mentioned_p (x, cse_check_loop_start_value))
    cse_check_loop_start_value = 0;
}
static void
cse_set_around_loop(rtx x, rtx insn, rtx loop_start) asm("_cse_set_around_loop");
static void
cse_set_around_loop(rtx x, rtx insn, rtx loop_start)
{
  struct n64_tag_table_elt *src_elt;
  static struct n64_tag_write_data init = {0, 0, 0, 0};
  struct n64_tag_write_data writes_memory;

  writes_memory = init;



  if (((x)->code) == SET
      && ((((x)->fld[0].rtx))->code) != PC && ((((x)->fld[0].rtx))->code) != CC0
      && ((((x)->fld[1].rtx))->code) != REG)
    {
      src_elt = lookup (((x)->fld[1].rtx),
   (((((x)->fld[1].rtx))->code) == REG && ((((x)->fld[1].rtx))->fld[0].rtint) >= 68 ? (((unsigned) REG << 7) + (unsigned) reg_qty[((((x)->fld[1].rtx))->fld[0].rtint)]) % 31 : canon_hash (((x)->fld[1].rtx), ((((x)->fld[0].rtx))->mode)) % 31),
   ((((x)->fld[0].rtx))->mode));

      if (src_elt)
 for (src_elt = src_elt->first_same_value; src_elt;
      src_elt = src_elt->next_same_value)
   if (((src_elt->exp)->code) == REG && ((src_elt->exp)->in_struct)
       && (((src_elt->exp)->code) == REG ? (((((src_elt->exp)->volatil) && ((src_elt->exp)->fld[0].rtint) < 68) || ((((src_elt->exp)->fld[0].rtint)) == (0 + 30) || (((src_elt->exp)->fld[0].rtint)) == (0 + 30) || (((src_elt->exp)->fld[0].rtint)) == (0 + 29) || (((src_elt->exp)->fld[0].rtint)) == 0 || ((((src_elt->exp)->fld[0].rtint)) >= (68) && (((src_elt->exp)->fld[0].rtint)) <= (((68)) + 3)) || ((((src_elt->exp)->fld[0].rtint)) < 68 && ((((src_elt->exp)->fld[0].rtint)) == (0 + 30) || (((src_elt->exp)->fld[0].rtint)) == (0 + 30) || fixed_regs[((src_elt->exp)->fld[0].rtint)] || global_regs[((src_elt->exp)->fld[0].rtint)]) && mips_regno_to_class[ (((src_elt->exp)->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((src_elt->exp)->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (src_elt->exp, SET) * 2) < (((((x)->fld[1].rtx))->code) == REG ? (((((((x)->fld[1].rtx))->volatil) && ((((x)->fld[1].rtx))->fld[0].rtint) < 68) || ((((((x)->fld[1].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[1].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[1].rtx))->fld[0].rtint)) == (0 + 29) || (((((x)->fld[1].rtx))->fld[0].rtint)) == 0 || ((((((x)->fld[1].rtx))->fld[0].rtint)) >= (68) && (((((x)->fld[1].rtx))->fld[0].rtint)) <= (((68)) + 3)) || ((((((x)->fld[1].rtx))->fld[0].rtint)) < 68 && ((((((x)->fld[1].rtx))->fld[0].rtint)) == (0 + 30) || (((((x)->fld[1].rtx))->fld[0].rtint)) == (0 + 30) || fixed_regs[((((x)->fld[1].rtx))->fld[0].rtint)] || global_regs[((((x)->fld[1].rtx))->fld[0].rtint)]) && mips_regno_to_class[ (((((x)->fld[1].rtx))->fld[0].rtint)) ] != NO_REGS))) ? 0 : ((((x)->fld[1].rtx))->fld[0].rtint) >= 68 ? 1 : 2) : rtx_cost (((x)->fld[1].rtx), SET) * 2))
     {
       rtx p, set;





       for (p = prev_nonnote_insn (loop_start);
     p && ((p)->code) != CALL_INSN
     && ((p)->code) != CODE_LABEL;
     p = prev_nonnote_insn (p))
  if ((set = single_set (p)) != 0
      && ((((set)->fld[0].rtx))->code) == REG
      && ((((set)->fld[0].rtx))->mode) == src_elt->mode
      && rtx_equal_p (((set)->fld[1].rtx), ((x)->fld[1].rtx)))
    {





      rtx q;

      cse_check_loop_start_value = ((x)->fld[1].rtx);
      for (q = p; q != loop_start; q = ((q)->fld[2].rtx))
        if ((rtx_class[(int)(((q)->code))]) == 'i')
   note_stores (((q)->fld[3].rtx), cse_check_loop_start);




      if (cse_check_loop_start_value
   && validate_change (insn, &((x)->fld[1].rtx),
         src_elt->exp, 0))
        emit_insn_after (gen_move_insn (src_elt->exp,
            ((set)->fld[0].rtx)),
           p);
      break;
    }
     }
    }


  note_mem_written (((x)->fld[0].rtx), &writes_memory);

  if (writes_memory.var)
    invalidate_memory (&writes_memory);


  if (((((x)->fld[0].rtx))->code) == REG || ((((x)->fld[0].rtx))->code) == SUBREG
      || (((((x)->fld[0].rtx))->code) == MEM && ! writes_memory.all
   && ! cse_rtx_addr_varies_p (((x)->fld[0].rtx))))
    invalidate (((x)->fld[0].rtx), VOIDmode);
  else if (((((x)->fld[0].rtx))->code) == STRICT_LOW_PART
    || ((((x)->fld[0].rtx))->code) == ZERO_EXTRACT)
    invalidate (((((x)->fld[0].rtx))->fld[0].rtx), ((((x)->fld[0].rtx))->mode));
}
void
cse_end_of_basic_block(rtx insn, struct n64_tag_cse_basic_block_data *data, int follow_jumps, int after_loop, int skip_blocks) asm("_cse_end_of_basic_block");
void
cse_end_of_basic_block(rtx insn, struct n64_tag_cse_basic_block_data *data, int follow_jumps, int after_loop, int skip_blocks)
{
  rtx p = insn, q;
  int nsets = 0;
  int low_cuid = (uid_cuid[((insn)->fld[0].rtint)]), high_cuid = (uid_cuid[((insn)->fld[0].rtint)]);
  rtx next = (rtx_class[(int)(((insn)->code))]) == 'i' ? insn : next_real_insn (insn);
  int path_size = data->path_size;
  int path_entry = 0;
  int i;





  while (path_size > 0)
    {
      if (data->path[path_size - 1].status != NOT_TAKEN)
 {
   data->path[path_size - 1].status = NOT_TAKEN;
   break;
 }
      else
 path_size--;
    }


  while (p && ((p)->code) != CODE_LABEL)
    {
      if (! after_loop && ((p)->code) == NOTE
   && ((p)->fld[4].rtint) == -5)
 break;




      if (((p)->code) == NOTE
   && ((p)->fld[4].rtint) == -7)
 break;



      if ((rtx_class[(int)(((p)->code))]) == 'i'
   && ((((p)->fld[3].rtx))->code) == PARALLEL)
 nsets += ((((p)->fld[3].rtx))->fld[0].rtvec->num_elem);
      else if (((p)->code) != NOTE)
 nsets += 1;




      if (((p)->fld[0].rtint) <= max_uid && (uid_cuid[((p)->fld[0].rtint)]) > high_cuid)
 high_cuid = (uid_cuid[((p)->fld[0].rtint)]);
      if (((p)->fld[0].rtint) <= max_uid && (uid_cuid[((p)->fld[0].rtint)]) < low_cuid)
 low_cuid = (uid_cuid[((p)->fld[0].rtint)]);



      if (path_entry < path_size && data->path[path_entry].branch == p)
 {
   if (data->path[path_entry].status != NOT_TAKEN)
     p = ((p)->fld[7].rtx);


   path_entry++;
 }
      else if ((follow_jumps || skip_blocks) && path_size < 10 - 1
        && ((p)->code) == JUMP_INSN
              && ((((p)->fld[3].rtx))->code) == SET
        && ((((((p)->fld[3].rtx))->fld[1].rtx))->code) == IF_THEN_ELSE
        && ((((p)->fld[7].rtx))->fld[5].rtint) == 1
        && ((((p)->fld[7].rtx))->fld[2].rtx) != 0)
 {
   for (q = ((((p)->fld[7].rtx))->fld[1].rtx); q; q = ((q)->fld[1].rtx))
     if ((((q)->code) != NOTE
          || ((q)->fld[4].rtint) == -5
          || ((q)->fld[4].rtint) == -7)
         && (((q)->code) != CODE_LABEL || ((q)->fld[5].rtint) != 0))
       break;



   if (follow_jumps && q != 0 && ((q)->code) == BARRIER)
     {


       if (next_real_insn (q) == next)
  {
    p = ((p)->fld[2].rtx);
    continue;
  }


       for (i = 0; i < path_entry; i++)
  if (data->path[i].branch == p)
    break;

       if (i != path_entry)
  break;

       data->path[path_entry].branch = p;
       data->path[path_entry++].status = TAKEN;





       path_size = path_entry;

       p = ((p)->fld[7].rtx);

       ((((p)->fld[2].rtx))->mode = (QImode));
     }

   else if (skip_blocks && q != 0 && ((q)->code) != CODE_LABEL)
     {
       register rtx tmp;

       if (next_real_insn (q) == next)
  {
    p = ((p)->fld[2].rtx);
    continue;
  }

       for (i = 0; i < path_entry; i++)
  if (data->path[i].branch == p)
    break;

       if (i != path_entry)
  break;



       for (tmp = ((p)->fld[2].rtx); tmp && tmp != q; tmp = ((tmp)->fld[2].rtx))
  if (((tmp)->code) == CODE_LABEL)
    break;

       if (tmp == q)
  {
    data->path[path_entry].branch = p;
    data->path[path_entry++].status = AROUND;

    path_size = path_entry;

    p = ((p)->fld[7].rtx);

    ((((p)->fld[2].rtx))->mode = (QImode));
  }
     }
 }
      p = ((p)->fld[2].rtx);
    }

  data->low_cuid = low_cuid;
  data->high_cuid = high_cuid;
  data->nsets = nsets;
  data->last = p;



  for (i = path_size - 1; i >= 0; i--)
    if (data->path[i].status != NOT_TAKEN)
      break;

  if (i == -1)
    data->path_size = 0;
  else
    data->path_size = path_size;


  data->path[path_size].branch = 0;
}
int
cse_main(rtx f, int nregs, int after_loop, FILE *file) asm("_cse_main");
int
cse_main(rtx f, int nregs, int after_loop, FILE *file)
{
  struct n64_tag_cse_basic_block_data val;
  register rtx insn = f;
  register int i;

  cse_jumps_altered = 0;
  recorded_label_ref = 0;
  constant_pool_entries_cost = 0;
  val.path_size = 0;

  init_recog ();

  max_reg = nregs;

  all_minus_one = (int *) 
                         __builtin_alloca((
                         nregs * sizeof (int)
                         ))
                                                      ;
  consec_ints = (int *) 
                       __builtin_alloca((
                       nregs * sizeof (int)
                       ))
                                                    ;

  for (i = 0; i < nregs; i++)
    {
      all_minus_one[i] = -1;
      consec_ints[i] = i;
    }

  reg_next_eqv = (int *) 
                        __builtin_alloca((
                        nregs * sizeof (int)
                        ))
                                                     ;
  reg_prev_eqv = (int *) 
                        __builtin_alloca((
                        nregs * sizeof (int)
                        ))
                                                     ;
  reg_qty = (int *) 
                   __builtin_alloca((
                   nregs * sizeof (int)
                   ))
                                                ;
  reg_in_table = (int *) 
                        __builtin_alloca((
                        nregs * sizeof (int)
                        ))
                                                     ;
  reg_tick = (int *) 
                    __builtin_alloca((
                    nregs * sizeof (int)
                    ))
                                                 ;





  memory_extend_rtx = gen_rtx (ZERO_EXTEND, VOIDmode, 0);




  memset ((char *) table,0,sizeof table);
  free_element_chain = 0;
  n_elements_made = 0;



  max_uid = get_max_uid ();
  uid_cuid = (int *) 
                    __builtin_alloca((
                    (max_uid + 1) * sizeof (int)
                    ))
                                                         ;
  memset ((char *) uid_cuid,0,(max_uid + 1) * sizeof (int));







  for (insn = f, i = 0; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->code) != NOTE
   || ((insn)->fld[4].rtint) < 0)
 (uid_cuid[((insn)->fld[0].rtint)]) = ++i;
      else

 (uid_cuid[((insn)->fld[0].rtint)]) = i;
    }



  do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_invalidated_by_call); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

  for (i = 0; i < 68; i++)
    if ((call_used_regs[i]
  && i != (0 + 29)
  && i != (0 + 30)




  && ! (i == 0 && fixed_regs[i])


  && ! (i == (0 + 28) && flag_pic)

  )
 || global_regs[i])
      ((regs_invalidated_by_call)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));




  insn = f;
  while (insn)
    {
      cse_end_of_basic_block (insn, &val, flag_cse_follow_jumps, after_loop,
         flag_cse_skip_blocks);


      if (val.nsets == 0 || ((insn)->mode) == QImode)
 {
   ((insn)->mode = (VOIDmode));
   insn = (val.last ? ((val.last)->fld[2].rtx) : 0);
   val.path_size = 0;
   continue;
 }

      cse_basic_block_start = val.low_cuid;
      cse_basic_block_end = val.high_cuid;
      max_qty = val.nsets * 2;

      if (file)
 fprintf (file, ";; Processing block from %d to %d, %d sets.\n",
   ((insn)->fld[0].rtint), val.last ? ((val.last)->fld[0].rtint) : 0,
   val.nsets);



      if (max_qty < 500)
 max_qty = 500;

      max_qty += max_reg;




      if (val.path_size > 0)
        cse_basic_block (insn, val.last, val.path, 0);
      else
 {
   int old_cse_jumps_altered = cse_jumps_altered;
   rtx temp;




   cse_jumps_altered = 0;
   temp = cse_basic_block (insn, val.last, val.path, ! after_loop);
   if (cse_jumps_altered == 0
       || (flag_cse_follow_jumps == 0 && flag_cse_skip_blocks == 0))
     insn = temp;

   cse_jumps_altered |= old_cse_jumps_altered;
 }




    }


  qty_const = 0;

  if (max_elements_made < n_elements_made)
    max_elements_made = n_elements_made;

  return cse_jumps_altered || recorded_label_ref;
}
static rtx
cse_basic_block(register rtx from, register rtx to, struct n64_tag_branch_path *next_branch, int around_loop) asm("_cse_basic_block");
static rtx
cse_basic_block(register rtx from, register rtx to, struct n64_tag_branch_path *next_branch, int around_loop)
{
  register rtx insn;
  int to_usage = 0;
  int in_libcall_block = 0;




  qty_first_reg = (int *) 
                         __builtin_alloca((
                         (max_qty - max_reg) * sizeof (int)
                         ))
                                                                    ;
  qty_last_reg = (int *) 
                        __builtin_alloca((
                        (max_qty - max_reg) * sizeof (int)
                        ))
                                                                   ;
  qty_mode= (n64_enum_machine_mode *) 
                                 __builtin_alloca((
                                 (max_qty - max_reg) * sizeof (n64_enum_machine_mode)
                                 ))
                                                                                          ;
  qty_const = (rtx *) 
                     __builtin_alloca((
                     (max_qty - max_reg) * sizeof (rtx)
                     ))
                                                                ;
  qty_const_insn = (rtx *) 
                          __builtin_alloca((
                          (max_qty - max_reg) * sizeof (rtx)
                          ))
                                                                     ;
  qty_comparison_code
    = (n64_enum_rtx_code *) 
                       __builtin_alloca((
                       (max_qty - max_reg) * sizeof (n64_enum_rtx_code)
                       ))
                                                                            ;
  qty_comparison_qty = (int *) 
                              __builtin_alloca((
                              (max_qty - max_reg) * sizeof (int)
                              ))
                                                                         ;
  qty_comparison_const = (rtx *) 
                                __builtin_alloca((
                                (max_qty - max_reg) * sizeof (rtx)
                                ))
                                                                           ;

  qty_first_reg -= max_reg;
  qty_last_reg -= max_reg;
  qty_mode -= max_reg;
  qty_const -= max_reg;
  qty_const_insn -= max_reg;
  qty_comparison_code -= max_reg;
  qty_comparison_qty -= max_reg;
  qty_comparison_const -= max_reg;

  new_basic_block ();


  if (to != 0 && ((to)->code) == CODE_LABEL)
    ++((to)->fld[5].rtint);

  for (insn = from; insn != to; insn = ((insn)->fld[2].rtx))
    {
      register n64_enum_rtx_code code;



      if (next_branch->branch == insn)
 {
   n64_enum_taken status = next_branch++->status;
   if (status != NOT_TAKEN)
     {
       if (status == TAKEN)
  record_jump_equiv (insn, 1);
       else
  invalidate_skipped_block (((insn)->fld[2].rtx));






       prev_insn = insn;
       insn = ((insn)->fld[7].rtx);
       continue;
     }
 }

      code = ((insn)->code);
      if (((insn)->mode) == QImode)
 ((insn)->mode = (VOIDmode));

      if ((rtx_class[(int)(code)]) == 'i')
 {



   if (((insn)->fld[6].rtx))
     ((insn)->fld[6].rtx) = cse_process_notes (((insn)->fld[6].rtx), (rtx) 0);







   if (find_reg_note (insn, REG_LIBCALL, (rtx) 0))
     in_libcall_block = 1;
   else if (find_reg_note (insn, REG_RETVAL, (rtx) 0))
     in_libcall_block = 0;

   cse_insn (insn, in_libcall_block);
 }






      if (simplejump_p (insn))
 {
   if (to == 0)
     return 0;

   if (((insn)->fld[7].rtx) == to)
     to_usage = 1;






   if (((to)->volatil))
     break;

   insn = ((to)->fld[1].rtx);
 }







      if (to != 0 && ((insn)->fld[2].rtx) == to
   && ((to)->code) == CODE_LABEL && --((to)->fld[5].rtint) == to_usage)
 {
   struct n64_tag_cse_basic_block_data val;
   rtx prev;

   insn = ((to)->fld[2].rtx);

   if (((to)->fld[5].rtint) == 0)
     insn = delete_insn (to);


   if (insn == 0)
     return 0;



   prev = prev_nonnote_insn (to);
   if (prev && ((prev)->code) == BARRIER)
     return insn;



   to_usage = 0;
   val.path_size = 0;
   cse_end_of_basic_block (insn, &val, 0, 0, 0);





   if (val.nsets * 2 + next_qty > max_qty)
     break;

   cse_basic_block_start = val.low_cuid;
   cse_basic_block_end = val.high_cuid;
   to = val.last;


   if (to != 0 && ((to)->code) == CODE_LABEL)
     ++((to)->fld[5].rtint);


   insn = ((insn)->fld[1].rtx);
 }
    }

  if (next_qty > max_qty)
    abort ();






  if ((cse_jumps_altered == 0
       || (flag_cse_follow_jumps == 0 && flag_cse_skip_blocks == 0))
      && around_loop && to != 0
      && ((to)->code) == NOTE && ((to)->fld[4].rtint) == -5
      && ((((to)->fld[1].rtx))->code) == JUMP_INSN
      && ((((to)->fld[1].rtx))->fld[7].rtx) != 0
      && ((((((to)->fld[1].rtx))->fld[7].rtx))->fld[5].rtint) == 1)
    cse_around_loop (((((to)->fld[1].rtx))->fld[7].rtx));

  return to ? ((to)->fld[2].rtx) : 0;
}
static void
count_reg_usage(rtx x, int *counts, rtx dest, int incr) asm("_count_reg_usage");
static void
count_reg_usage(rtx x, int *counts, rtx dest, int incr)
{
  n64_enum_rtx_code code;
  char *fmt;
  int i, j;

  if (x == 0)
    return;

  switch (code = ((x)->code))
    {
    case REG:
      if (x != dest)
 counts[((x)->fld[0].rtint)] += incr;
      return;

    case PC:
    case CC0:
    case CONST:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case LABEL_REF:
    case CLOBBER:
      return;

    case SET:

      if (((((x)->fld[0].rtx))->code) != REG)
 count_reg_usage (((x)->fld[0].rtx), counts, (rtx) 0, incr);







      count_reg_usage (((x)->fld[1].rtx), counts,
         side_effects_p (((x)->fld[1].rtx)) ? (rtx) 0 : ((x)->fld[0].rtx),
         incr);
      return;

    case CALL_INSN:
      count_reg_usage (((x)->fld[7].rtx), counts, (rtx) 0, incr);


    case INSN:
    case JUMP_INSN:
      count_reg_usage (((x)->fld[3].rtx), counts, (rtx) 0, incr);




      count_reg_usage (((x)->fld[6].rtx), counts, (rtx) 0, incr);
      return;

    case EXPR_LIST:
    case INSN_LIST:
      if (((n64_enum_reg_note) ((x)->mode)) == REG_EQUAL
   || ((((x)->fld[0].rtx))->code) == USE)
 count_reg_usage (((x)->fld[0].rtx), counts, (rtx) 0, incr);
      count_reg_usage (((x)->fld[1].rtx), counts, (rtx) 0, incr);
      return;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 count_reg_usage (((x)->fld[i].rtx), counts, dest, incr);
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   count_reg_usage (((x)->fld[i].rtvec->elem[j].rtx), counts, dest, incr);
    }
}
void
delete_dead_from_cse(rtx insns, int nreg) asm("_delete_dead_from_cse");
void
delete_dead_from_cse(rtx insns, int nreg)
{
  int *counts = (int *) 
                       __builtin_alloca((
                       nreg * sizeof (int)
                       ))
                                                   ;
  rtx insn, prev;
  rtx tem;
  int i;
  int in_libcall = 0;


  memset ((char *) counts,0,sizeof (int) * nreg);
  for (insn = next_real_insn (insns); insn; insn = next_real_insn (insn))
    count_reg_usage (insn, counts, (rtx) 0, 1);




  for (insn = prev_real_insn (get_last_insn ()); insn; insn = prev)
    {
      int live_insn = 0;

      prev = prev_real_insn (insn);




      if (find_reg_note (insn, REG_RETVAL, (rtx) 0))
 in_libcall = 1;

      if (in_libcall)
 live_insn = 1;
      else if (((((insn)->fld[3].rtx))->code) == SET)
 {
   if (((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == REG
       && ((((insn)->fld[3].rtx))->fld[0].rtx) == ((((insn)->fld[3].rtx))->fld[1].rtx))
     ;
   else if (((((((insn)->fld[3].rtx))->fld[0].rtx))->code) != REG
     || ((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtint) < 68
     || counts[((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtint)] != 0
     || side_effects_p (((((insn)->fld[3].rtx))->fld[1].rtx)))
     live_insn = 1;
 }
      else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
 for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
   {
     rtx elt = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);

     if (((elt)->code) == SET)
       {
  if (((((elt)->fld[0].rtx))->code) == REG
      && ((elt)->fld[0].rtx) == ((elt)->fld[1].rtx))
    ;
  else if (((((elt)->fld[0].rtx))->code) != REG
    || ((((elt)->fld[0].rtx))->fld[0].rtint) < 68
    || counts[((((elt)->fld[0].rtx))->fld[0].rtint)] != 0
    || side_effects_p (((elt)->fld[1].rtx)))
    live_insn = 1;
       }
     else if (((elt)->code) != CLOBBER && ((elt)->code) != USE)
       live_insn = 1;
   }
      else
 live_insn = 1;




      if (! live_insn)
 {
   count_reg_usage (insn, counts, (rtx) 0, -1);
   delete_insn (insn);
 }

      if (find_reg_note (insn, REG_LIBCALL, (rtx) 0))
 in_libcall = 0;
    }
}

