// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/global.c
/* Allocate registers for pseudo-registers that span basic blocks.
   Copyright (C) 1987, 1988, 1991, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int reload(...) asm("_reload");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int note_stores(...) asm("_note_stores");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int reg_class_subset_p(...) asm("_reg_class_subset_p");
extern int mark_home_live(...) asm("_mark_home_live");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
static int max_allocno;




static int *reg_allocno;



static int *allocno_reg;




static int *allocno_order;




static int *allocno_size;





static int *reg_may_share;
static int *conflicts;




static int allocno_row_words;
static HARD_REG_SET hard_regs_live;



static HARD_REG_SET *hard_reg_conflicts;





static HARD_REG_SET *hard_reg_preferences;






static HARD_REG_SET *hard_reg_copy_preferences;





static HARD_REG_SET *hard_reg_full_preferences;




static HARD_REG_SET *regs_someone_prefers;



static HARD_REG_SET no_global_alloc_regs;



static HARD_REG_SET regs_used_so_far;



static int *allocno_calls_crossed;



static int *allocno_n_refs;




static int *allocno_live_length;




static int local_reg_n_refs[68];




static int local_reg_live_length[68];
static int *allocnos_live;
static rtx *regs_set;
static int n_regs_set;



static HARD_REG_SET eliminable_regset;

static int allocno_compare (int *, int *) asm("_allocno_compare");
static void global_conflicts (void) asm("_global_conflicts");
static void expand_preferences (void) asm("_expand_preferences");
static void prune_preferences (void) asm("_prune_preferences");
static void find_reg (int, HARD_REG_SET, int, int, int) asm("_find_reg");
static void record_one_conflict (int) asm("_record_one_conflict");
static void record_conflicts (short *, int) asm("_record_conflicts");
static void mark_reg_store (rtx, rtx) asm("_mark_reg_store");
static void mark_reg_clobber (rtx, rtx) asm("_mark_reg_clobber");
static void mark_reg_conflicts (rtx) asm("_mark_reg_conflicts");
static void mark_reg_death (rtx) asm("_mark_reg_death");
static void mark_reg_live_nc (int, n64_enum_machine_mode) asm("_mark_reg_live_nc");
static void set_preference (rtx, rtx) asm("_set_preference");
static void dump_conflicts (FILE *) asm("_dump_conflicts");
int
global_alloc(FILE *file) asm("_global_alloc");
int
global_alloc(FILE *file)
{

  static struct {int from, to; } eliminables[] = {{ 0, (0 + 29)}, { 0, (0 + 30)}, { (0 + 30), (0 + 29)}};

  int need_fp
    = (! flag_omit_frame_pointer

       || (current_function_calls_alloca && 1)

       || (current_function_calls_alloca));

  register int i;
  rtx x;

  max_allocno = 0;




  do { register HARD_REG_ELT_TYPE *scan_tp_ = (no_global_alloc_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  for (i = 0; i < sizeof eliminables / sizeof eliminables[0]; i++)
    {
      ((eliminable_regset)[(eliminables[i].from) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((eliminables[i].from) % ((unsigned) 32)));

      if (! (!frame_pointer_needed || ((eliminables[i].from) == 0 && (eliminables[i].to) == (0 + 30)))
   || (eliminables[i].to == (0 + 29) && need_fp))
 ((no_global_alloc_regs)[(eliminables[i].from) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((eliminables[i].from) % ((unsigned) 32)));
    }
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_used_so_far); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  for (i = 0; i < 68; i++)
    if (regs_ever_live[i] || call_used_regs[i])
      ((regs_used_so_far)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));


  for (i = 68; i < max_regno; i++)
    if (reg_renumber[i] >= 0)
      ((regs_used_so_far)[(reg_renumber[i]) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((reg_renumber[i]) % ((unsigned) 32)));




  reg_allocno = (int *) 
                       __builtin_alloca((
                       max_regno * sizeof (int)
                       ))
                                                        ;

  for (i = 0; i < 68; i++)
    reg_allocno[i] = -1;



  reg_may_share = (int *) 
                         __builtin_alloca((
                         max_regno * sizeof (int)
                         ))
                                                          ;
  memset ((char *) reg_may_share,0,max_regno * sizeof (int));
  for (x = regs_may_share; x; x = ((((x)->fld[1].rtx))->fld[1].rtx))
    {
      int r1 = ((((x)->fld[0].rtx))->fld[0].rtint);
      int r2 = ((((((x)->fld[1].rtx))->fld[0].rtx))->fld[0].rtint);
      if (r1 > r2)
 reg_may_share[r1] = r2;
      else
 reg_may_share[r2] = r1;
    }

  for (i = 68; i < max_regno; i++)



    if (reg_n_refs[i] != 0 && reg_renumber[i] < 0 && reg_live_length[i] != -1


 && (! current_function_has_nonlocal_label
     || reg_n_calls_crossed[i] == 0))
      {
 if (reg_may_share[i] && reg_allocno[reg_may_share[i]] >= 0)
   reg_allocno[i] = reg_allocno[reg_may_share[i]];
 else
   reg_allocno[i] = max_allocno++;
 if (reg_live_length[i] == 0)
   abort ();
      }
    else
      reg_allocno[i] = -1;

  allocno_reg = (int *) 
                       __builtin_alloca((
                       max_allocno * sizeof (int)
                       ))
                                                          ;
  allocno_size = (int *) 
                        __builtin_alloca((
                        max_allocno * sizeof (int)
                        ))
                                                           ;
  allocno_calls_crossed = (int *) 
                                 __builtin_alloca((
                                 max_allocno * sizeof (int)
                                 ))
                                                                    ;
  allocno_n_refs = (int *) 
                          __builtin_alloca((
                          max_allocno * sizeof (int)
                          ))
                                                             ;
  allocno_live_length = (int *) 
                               __builtin_alloca((
                               max_allocno * sizeof (int)
                               ))
                                                                  ;
  memset ((char *) allocno_size,0,max_allocno * sizeof (int));
  memset ((char *) allocno_calls_crossed,0,max_allocno * sizeof (int));
  memset ((char *) allocno_n_refs,0,max_allocno * sizeof (int));
  memset ((char *) allocno_live_length,0,max_allocno * sizeof (int));

  for (i = 68; i < max_regno; i++)
    if (reg_allocno[i] >= 0)
      {
 int allocno = reg_allocno[i];
 allocno_reg[allocno] = i;
 allocno_size[allocno] = (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4));
 allocno_calls_crossed[allocno] += reg_n_calls_crossed[i];
 allocno_n_refs[allocno] += reg_n_refs[i];
 if (allocno_live_length[allocno] < reg_live_length[i])
   allocno_live_length[allocno] = reg_live_length[i];
      }




  memset ((char *) local_reg_live_length,0,sizeof local_reg_live_length);
  memset ((char *) local_reg_n_refs,0,sizeof local_reg_n_refs);
  for (i = 68; i < max_regno; i++)
    if (reg_allocno[i] < 0 && reg_renumber[i] >= 0)
      {
 int regno = reg_renumber[i];
 int endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
 int j;

 for (j = regno; j < endregno; j++)
   {
     local_reg_n_refs[j] += reg_n_refs[i];
     local_reg_live_length[j] += reg_live_length[i];
   }
      }


  for (i = 0; i < 68; i++)
    if (regs_ever_live[i])
      local_reg_n_refs[i] = 0;


  for (i = 0; i < scratch_list_length; i++)
    if (scratch_list[i])
      {
 int regno = ((scratch_list[i])->fld[0].rtint);
 int lim = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((scratch_list[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((scratch_list[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
 int j;

 for (j = regno; j < lim; j++)
   local_reg_n_refs[j] = 0;
      }




  hard_reg_conflicts
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_allocno * sizeof (HARD_REG_SET)
                      ))
                                                                  ;
  memset ((char *) hard_reg_conflicts,0,max_allocno * sizeof (HARD_REG_SET));

  hard_reg_preferences
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_allocno * sizeof (HARD_REG_SET)
                      ))
                                                                  ;
  memset ((char *) hard_reg_preferences,0,max_allocno * sizeof (HARD_REG_SET));

  hard_reg_copy_preferences
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_allocno * sizeof (HARD_REG_SET)
                      ))
                                                                  ;
  memset ((char *) hard_reg_copy_preferences,0,max_allocno * sizeof (HARD_REG_SET))
                                      ;

  hard_reg_full_preferences
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_allocno * sizeof (HARD_REG_SET)
                      ))
                                                                  ;
  memset ((char *) hard_reg_full_preferences,0,max_allocno * sizeof (HARD_REG_SET))
                                      ;

  regs_someone_prefers
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_allocno * sizeof (HARD_REG_SET)
                      ))
                                                                  ;
  memset ((char *) regs_someone_prefers,0,max_allocno * sizeof (HARD_REG_SET));

  allocno_row_words = (max_allocno + 32 - 1) / 32;

  conflicts = (int *) 
                          __builtin_alloca((
                          max_allocno * allocno_row_words * sizeof (int)
                          ))
                           
                          ;
  memset ((char *) conflicts,0,max_allocno * allocno_row_words * sizeof (int))
                                                      ;

  allocnos_live = (int *) 
                              __builtin_alloca((
                              allocno_row_words * sizeof (int)
                              ))
                                                                            ;




  if (max_allocno > 0)
    {



      global_conflicts ();
      for (i = 0; i < max_allocno; i++)
 {
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_conflicts[i]), *scan_fp_ = (eliminable_regset); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_copy_preferences[i]), *scan_fp_ = (eliminable_regset); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0)
                        ;
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_preferences[i]), *scan_fp_ = (eliminable_regset); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
 }



      expand_preferences ();



      allocno_order = (int *) 
                             __builtin_alloca((
                             max_allocno * sizeof (int)
                             ))
                                                                ;
      for (i = 0; i < max_allocno; i++)
 allocno_order[i] = i;
      for (i = 0; i < max_allocno; i++)
 {
   if (allocno_size[i] == 0)
     allocno_size[i] = 1;
   if (allocno_live_length[i] == 0)
     allocno_live_length[i] = -1;
 }

      qsort (allocno_order, max_allocno, sizeof (int), allocno_compare);

      prune_preferences ();

      if (file)
 dump_conflicts (file);




      for (i = 0; i < max_allocno; i++)
 if (reg_live_length[allocno_reg[allocno_order[i]]] >= 0)
   {



     if ((int) LIM_REG_CLASSES > 1)
       {
  find_reg (allocno_order[i], ((HARD_REG_ELT_TYPE) (0)), 0, 0, 0);
  if (reg_renumber[allocno_reg[allocno_order[i]]] >= 0)
    continue;
       }
     if (reg_alternate_class (allocno_reg[allocno_order[i]]) != NO_REGS)
       find_reg (allocno_order[i], ((HARD_REG_ELT_TYPE) (0)), 1, 0, 0);
   }
    }
    return reload (get_insns (), 1, file);
}




static int
allocno_compare(int *v1, int *v2) asm("_allocno_compare");
static int
allocno_compare(int *v1, int *v2)
{




  register int pri1
    = (((double) (floor_log2_wide ((int) (allocno_n_refs[*v1])) * allocno_n_refs[*v1])
 / allocno_live_length[*v1])
       * 10000 * allocno_size[*v1]);
  register int pri2
    = (((double) (floor_log2_wide ((int) (allocno_n_refs[*v2])) * allocno_n_refs[*v2])
 / allocno_live_length[*v2])
       * 10000 * allocno_size[*v2]);
  if (pri2 - pri1)
    return pri2 - pri1;



  return *v1 - *v2;
}




static void
global_conflicts(void) asm("_global_conflicts");
static void
global_conflicts(void)
{
  register int b, i;
  register rtx insn;
  short *block_start_allocnos;


  regs_set = (rtx *) 
                    __builtin_alloca((
                    max_parallel * sizeof (rtx) * 2
                    ))
                                                            ;

  block_start_allocnos = (short *) 
                                  __builtin_alloca((
                                  max_allocno * sizeof (short)
                                  ))
                                                                       ;

  for (b = 0; b < n_basic_blocks; b++)
    {
      memset ((char *) allocnos_live,0,allocno_row_words * sizeof (int));
      {
 register int offset;
 unsigned int bit;
 register regset old = basic_block_live_at_start[b];
 int ax = 0;




 do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_regs_live), *scan_fp_ = (old); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);

 for (offset = 0, i = 0; offset < regset_size; offset++)
   if (old[offset] == 0)
     i += 32;
   else
     for (bit = 1; bit; bit <<= 1, i++)
       {
  if (i >= max_regno)
    break;
  if (old[offset] & bit)
    {
      register int a = reg_allocno[i];
      if (a >= 0)
        {
   (allocnos_live[(a) / 32] |= ((int) 1 << ((a) % 32)));
   block_start_allocnos[ax++] = a;
        }
      else if ((a = reg_renumber[i]) >= 0)
        mark_reg_live_nc (a, ((regno_reg_rtx[i])->mode));
    }
       }




 record_conflicts (block_start_allocnos, ax);
      }

      insn = basic_block_head[b];





      while (1)
 {
   register n64_enum_rtx_code code = ((insn)->code);
   register rtx link;



   n_regs_set = 0;

   if (code == INSN || code == CALL_INSN || code == JUMP_INSN)
     {
       note_stores (((insn)->fld[3].rtx), mark_reg_clobber);



       for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
  if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD)
    mark_reg_death (((link)->fld[0].rtx));






       note_stores (((insn)->fld[3].rtx), mark_reg_store);
       if (((((insn)->fld[3].rtx))->code) == PARALLEL && !single_set (insn))
  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD)
      {
        int used_in_output = 0;
        int i;
        rtx reg = ((link)->fld[0].rtx);

        for (i = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
   {
     rtx set = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
     if (((set)->code) == SET
         && ((((set)->fld[0].rtx))->code) != REG
         && !rtx_equal_p (reg, ((set)->fld[0].rtx))
         && reg_overlap_mentioned_p (reg, ((set)->fld[0].rtx)))
       used_in_output = 1;
   }
        if (used_in_output)
   mark_reg_conflicts (reg);
      }



       while (n_regs_set > 0)
  if (find_regno_note (insn, REG_UNUSED,
         ((regs_set[--n_regs_set])->fld[0].rtint)))
    mark_reg_death (regs_set[n_regs_set]);
     }

   if (insn == basic_block_end[b])
     break;
   insn = ((insn)->fld[2].rtx);
 }
    }
}




static void
expand_preferences(void) asm("_expand_preferences");
static void
expand_preferences(void)
{
  rtx insn;
  rtx link;
  rtx set;




  for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && (set = single_set (insn)) != 0
 && ((((set)->fld[0].rtx))->code) == REG
 && reg_allocno[((((set)->fld[0].rtx))->fld[0].rtint)] >= 0)
      for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
 if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
     && ((((link)->fld[0].rtx))->code) == REG
     && reg_allocno[((((link)->fld[0].rtx))->fld[0].rtint)] >= 0
     && ! (conflicts[(reg_allocno[((((set)->fld[0].rtx))->fld[0].rtint)]) * allocno_row_words + (reg_allocno[((((link)->fld[0].rtx))->fld[0].rtint)]) / 32] & ((int) 1 << ((reg_allocno[((((link)->fld[0].rtx))->fld[0].rtint)]) % 32)))

     && ! (conflicts[(reg_allocno[((((link)->fld[0].rtx))->fld[0].rtint)]) * allocno_row_words + (reg_allocno[((((set)->fld[0].rtx))->fld[0].rtint)]) / 32] & ((int) 1 << ((reg_allocno[((((set)->fld[0].rtx))->fld[0].rtint)]) % 32)))
                                           )
   {
     int a1 = reg_allocno[((((set)->fld[0].rtx))->fld[0].rtint)];
     int a2 = reg_allocno[((((link)->fld[0].rtx))->fld[0].rtint)];

     if (((link)->fld[0].rtx) == ((set)->fld[1].rtx))
       {
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_copy_preferences[a1]), *scan_fp_ = (hard_reg_copy_preferences[a2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                    ;
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_copy_preferences[a2]), *scan_fp_ = (hard_reg_copy_preferences[a1]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                    ;
       }

     do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_preferences[a1]), *scan_fp_ = (hard_reg_preferences[a2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                  ;
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_preferences[a2]), *scan_fp_ = (hard_reg_preferences[a1]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                  ;
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_full_preferences[a1]), *scan_fp_ = (hard_reg_full_preferences[a2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                       ;
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_full_preferences[a2]), *scan_fp_ = (hard_reg_full_preferences[a1]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0)
                                       ;
   }
}
static void
prune_preferences(void) asm("_prune_preferences");
static void
prune_preferences(void)
{
  int i, j;
  int allocno;






  for (i = max_allocno - 1; i >= 0; i--)
    {
      HARD_REG_SET temp;

      allocno = allocno_order[i];
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (hard_reg_conflicts[allocno]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);

      if (allocno_calls_crossed[allocno] == 0)
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
      else
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (call_used_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (reg_class_contents[(int) reg_preferred_class (allocno_reg[allocno])]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0)

                                                                       ;

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_preferences[allocno]), *scan_fp_ = (temp); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_copy_preferences[allocno]), *scan_fp_ = (temp); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_full_preferences[allocno]), *scan_fp_ = (temp); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);

      do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_someone_prefers[allocno]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);






      for (j = i + 1; j < max_allocno; j++)
 if ((conflicts[(allocno) * allocno_row_words + (allocno_order[j]) / 32] & ((int) 1 << ((allocno_order[j]) % 32))))
   {
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (hard_reg_full_preferences[allocno_order[j]]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                                      ;
     if (allocno_size[allocno_order[j]] <= allocno_size[allocno])
       do { register HARD_REG_ELT_TYPE *scan_tp_ = (temp), *scan_fp_ = (hard_reg_full_preferences[allocno]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0)
                                             ;

     do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_someone_prefers[allocno]), *scan_fp_ = (temp); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
   }
    }
}
static void
find_reg(int allocno, HARD_REG_ELT_TYPE *losers, int alt_regs_p, int accept_call_clobbered, int retrying) asm("_find_reg");
static void
find_reg(int allocno, HARD_REG_ELT_TYPE *losers, int alt_regs_p, int accept_call_clobbered, int retrying)
{
  register int i, best_reg, pass;



    HARD_REG_SET used, used1, used2;

  n64_enum_reg_class cxx_class = (alt_regs_p
     ? reg_alternate_class (allocno_reg[allocno])
     : reg_preferred_class (allocno_reg[allocno]));
  n64_enum_machine_mode mode = ((regno_reg_rtx[allocno_reg[allocno]])->mode);

  if (accept_call_clobbered)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (call_fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  else if (allocno_calls_crossed[allocno] == 0)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  else
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (call_used_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);


  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (no_global_alloc_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
  if (losers)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (losers); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (reg_class_contents[(int) cxx_class]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used2), *scan_fp_ = (used1); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used1), *scan_fp_ = (hard_reg_conflicts[allocno]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (used1); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (regs_used_so_far); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (regs_someone_prefers[allocno]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

  best_reg = -1;
  for (i = 68, pass = 0;
       pass <= 1 && i >= 68;
       pass++)
    {
      if (pass == 1)
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (used1); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
      for (i = 0; i < 68; i++)
 {



   int regno = i;

   if (! ((used)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
     {
       register int j;
       register int lim = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       for (j = regno + 1;
     (j < lim
      && ! ((used)[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)))));
     j++);
       if (j == lim)
  {
    best_reg = regno;
    break;
  }

       i = j;

     }
   }
      }
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_copy_preferences[allocno]), *scan_fp_ = (used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_xp_ = (hard_reg_copy_preferences[allocno]), *scan_yp_ = (reg_class_contents[(int) NO_REGS]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto no_copy_prefs; } while (0)
                                                     ;

  if (best_reg >= 0)
    {
      for (i = 0; i < 68; i++)
 if (((hard_reg_copy_preferences[allocno])[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
     && mips_hard_regno_mode_ok[ (int)(mode) ][ (i) ]
     && (mips_regno_to_class[ (i) ] == mips_regno_to_class[ (best_reg) ]
  || reg_class_subset_p (mips_regno_to_class[ (i) ],
           mips_regno_to_class[ (best_reg) ])
  || reg_class_subset_p (mips_regno_to_class[ (best_reg) ],
           mips_regno_to_class[ (i) ])))
     {
       register int j;
       register int lim = i + (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       for (j = i + 1;
     (j < lim
      && ! ((used)[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
      && (mips_regno_to_class[ (j) ]
       == mips_regno_to_class[ (best_reg + (j - i)) ]
   || reg_class_subset_p (mips_regno_to_class[ (j) ],
            mips_regno_to_class[ (best_reg + (j - i)) ])
   || reg_class_subset_p (mips_regno_to_class[ (best_reg + (j - i)) ],
            mips_regno_to_class[ (j) ])));
     j++);
       if (j == lim)
  {
    best_reg = i;
    goto no_prefs;
  }
     }
    }
 no_copy_prefs:

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_preferences[allocno]), *scan_fp_ = (used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_xp_ = (hard_reg_preferences[allocno]), *scan_yp_ = (reg_class_contents[(int) NO_REGS]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto no_prefs; } while (0)
                                                ;

  if (best_reg >= 0)
    {
      for (i = 0; i < 68; i++)
 if (((hard_reg_preferences[allocno])[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
     && mips_hard_regno_mode_ok[ (int)(mode) ][ (i) ]
     && (mips_regno_to_class[ (i) ] == mips_regno_to_class[ (best_reg) ]
  || reg_class_subset_p (mips_regno_to_class[ (i) ],
           mips_regno_to_class[ (best_reg) ])
  || reg_class_subset_p (mips_regno_to_class[ (best_reg) ],
           mips_regno_to_class[ (i) ])))
     {
       register int j;
       register int lim = i + (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       for (j = i + 1;
     (j < lim
      && ! ((used)[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
      && (mips_regno_to_class[ (j) ]
       == mips_regno_to_class[ (best_reg + (j - i)) ]
   || reg_class_subset_p (mips_regno_to_class[ (j) ],
            mips_regno_to_class[ (best_reg + (j - i)) ])
   || reg_class_subset_p (mips_regno_to_class[ (best_reg + (j - i)) ],
            mips_regno_to_class[ (j) ])));
     j++);
       if (j == lim)
  {
    best_reg = i;
    break;
  }
     }
    }
 no_prefs:






  if (flag_caller_saves && best_reg < 0)
    {



      if (! accept_call_clobbered
   && allocno_calls_crossed[allocno] != 0
   && (4 * (allocno_calls_crossed[allocno]) < (allocno_n_refs[allocno]))
                                        )
 {
   find_reg (allocno, losers, alt_regs_p, 1, retrying);
   if (reg_renumber[allocno_reg[allocno]] >= 0)
     {
       caller_save_needed = 1;
       return;
     }
 }
    }






  if (best_reg < 0 && !retrying

      && allocno_size[allocno] == 1)
    {

      for (i = 68 - 1; i >= 0; i--)
 {



   int regno = i;


   if (local_reg_n_refs[regno] != 0

       && ! ((used2)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ]






       )
     {




       double tmp1 = ((double) local_reg_n_refs[regno]
       / local_reg_live_length[regno]);
       double tmp2 = ((double) allocno_n_refs[allocno]
        / allocno_live_length[allocno]);

       if (tmp1 < tmp2)
  {


    int k;
    for (k = 0; k < max_regno; k++)
      if (reg_renumber[k] >= 0)
        {
   int r = reg_renumber[k];
   int endregno
     = r + (! ((unsigned) ((r) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[k])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[k])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

   if (regno >= r && regno < endregno)
     reg_renumber[k] = -1;
        }

    best_reg = regno;
    break;
  }
     }
 }
    }



  if (best_reg >= 0)
    {
      register int lim, j;
      HARD_REG_SET this_reg;


      reg_renumber[allocno_reg[allocno]] = best_reg;

      if (reg_may_share[allocno_reg[allocno]])
 for (j = 68; j < max_regno; j++)
   if (reg_allocno[j] == allocno)
     reg_renumber[j] = best_reg;


      do { register HARD_REG_ELT_TYPE *scan_tp_ = (this_reg); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
      lim = best_reg + (! ((unsigned) ((best_reg) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      for (j = best_reg; j < lim; j++)
 {
   ((this_reg)[(j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)));
   ((regs_used_so_far)[(j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)));

   local_reg_n_refs[j] = 0;
 }


      lim = allocno;
      for (j = 0; j < max_allocno; j++)
 if ((conflicts[(lim) * allocno_row_words + (j) / 32] & ((int) 1 << ((j) % 32))) || (conflicts[(j) * allocno_row_words + (lim) / 32] & ((int) 1 << ((lim) % 32))))
   {
     do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_conflicts[j]), *scan_fp_ = (this_reg); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
   }
    }
}
void
retry_global_alloc(int regno, HARD_REG_ELT_TYPE *forbidden_regs) asm("_retry_global_alloc");
void
retry_global_alloc(int regno, HARD_REG_ELT_TYPE *forbidden_regs)
{
  int allocno = reg_allocno[regno];
  if (allocno >= 0)
    {



      if ((int) LIM_REG_CLASSES > 1)
 find_reg (allocno, forbidden_regs, 0, 0, 1);
      if (reg_renumber[regno] < 0
   && reg_alternate_class (regno) != NO_REGS)
 find_reg (allocno, forbidden_regs, 1, 0, 1);



      if (reg_renumber[regno] >= 0)
 {
   ((regno_reg_rtx[regno])->fld[0].rtint) = reg_renumber[regno];
   mark_home_live (regno);
 }
    }
}







static void
record_one_conflict(int regno) asm("_record_one_conflict");
static void
record_one_conflict(int regno)
{
  register int j;

  if (regno < 68)


    for (j = 0; j < max_allocno; j++)
      {
 if ((allocnos_live[(j) / 32] & ((int) 1 << ((j) % 32))))
   ((hard_reg_conflicts[j])[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));
      }
  else



    {
      register int ialloc = reg_allocno[regno];
      register int ialloc_prod = ialloc * allocno_row_words;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_conflicts[ialloc]), *scan_fp_ = (hard_regs_live); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
      for (j = allocno_row_words - 1; j >= 0; j--)
 {
       conflicts[ialloc_prod + j] |= allocnos_live[j];
 }
    }
}






static void
record_conflicts(register short int *allocno_vec, register int len) asm("_record_conflicts");
static void
record_conflicts(register short int *allocno_vec, register int len)
{
  register int allocno;
  register int j;
  register int ialloc_prod;

  while (--len >= 0)
    {
      allocno = allocno_vec[len];
      ialloc_prod = allocno * allocno_row_words;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (hard_reg_conflicts[allocno]), *scan_fp_ = (hard_regs_live); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
      for (j = allocno_row_words - 1; j >= 0; j--)
 conflicts[ialloc_prod + j] |= allocnos_live[j];
    }
}
static void
mark_reg_store(rtx orig_reg, rtx setter) asm("_mark_reg_store");
static void
mark_reg_store(rtx orig_reg, rtx setter)
{
  register int regno;
  register rtx reg = orig_reg;





  int word = 0;

  if (((reg)->code) == SUBREG)
    {
      word = ((reg)->fld[1].rtint);
      reg = ((reg)->fld[0].rtx);
    }

  if (((reg)->code) != REG)
    return;

  if (setter && ((setter)->code) == CLOBBER)
    {

      mark_reg_clobber (orig_reg, setter);
      return;
    }

  regs_set[n_regs_set++] = reg;

  if (setter)
    set_preference (reg, ((setter)->fld[1].rtx));

  regno = ((reg)->fld[0].rtint);

  if (reg_renumber[regno] >= 0)
    regno = reg_renumber[regno] ;



  if (regno >= 68)
    {
      if (reg_allocno[regno] >= 0)
 {
   (allocnos_live[(reg_allocno[regno]) / 32] |= ((int) 1 << ((reg_allocno[regno]) % 32)));
   record_one_conflict (regno);
 }
    }

  else if (! fixed_regs[regno])
    {
      register int last = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      while (regno < last)
 {
   record_one_conflict (regno);
   ((hard_regs_live)[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));
   regno++;
 }
    }
}



static void
mark_reg_clobber(rtx reg, rtx setter) asm("_mark_reg_clobber");
static void
mark_reg_clobber(rtx reg, rtx setter)
{
  register int regno;





  int word = 0;

  if (((setter)->code) != CLOBBER)
    return;

  if (((reg)->code) == SUBREG)
    {
      word = ((reg)->fld[1].rtint);
      reg = ((reg)->fld[0].rtx);
    }

  if (((reg)->code) != REG)
    return;

  regs_set[n_regs_set++] = reg;

  regno = ((reg)->fld[0].rtint);

  if (reg_renumber[regno] >= 0)
    regno = reg_renumber[regno] ;



  if (regno >= 68)
    {
      if (reg_allocno[regno] >= 0)
 {
   (allocnos_live[(reg_allocno[regno]) / 32] |= ((int) 1 << ((reg_allocno[regno]) % 32)));
   record_one_conflict (regno);
 }
    }

  else if (! fixed_regs[regno])
    {
      register int last = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      while (regno < last)
 {
   record_one_conflict (regno);
   ((hard_regs_live)[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));
   regno++;
 }
    }
}




static void
mark_reg_conflicts(rtx reg) asm("_mark_reg_conflicts");
static void
mark_reg_conflicts(rtx reg)
{
  register int regno;

  if (((reg)->code) == SUBREG)
    reg = ((reg)->fld[0].rtx);

  if (((reg)->code) != REG)
    return;

  regno = ((reg)->fld[0].rtint);

  if (reg_renumber[regno] >= 0)
    regno = reg_renumber[regno];



  if (regno >= 68)
    {
      if (reg_allocno[regno] >= 0)
 record_one_conflict (regno);
    }

  else if (! fixed_regs[regno])
    {
      register int last = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      while (regno < last)
 {
   record_one_conflict (regno);
   regno++;
 }
    }
}




static void
mark_reg_death(rtx reg) asm("_mark_reg_death");
static void
mark_reg_death(rtx reg)
{
  register int regno = ((reg)->fld[0].rtint);


  if (reg_renumber[regno] >= 0)
    regno = reg_renumber[regno];



  if (regno >= 68)
    {
      if (reg_allocno[regno] >= 0)
 (allocnos_live[(reg_allocno[regno]) / 32] &= ~((int) 1 << ((reg_allocno[regno]) % 32)));
    }

  else if (! fixed_regs[regno])
    {


      register int last = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      while (regno < last)
 {
   ((hard_regs_live)[(regno) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));
   regno++;
 }
    }
}






static void
mark_reg_live_nc(register int regno, n64_enum_machine_mode mode) asm("_mark_reg_live_nc");
static void
mark_reg_live_nc(register int regno, n64_enum_machine_mode mode)
{
  register int last = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  while (regno < last)
    {
      ((hard_regs_live)[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));
      regno++;
    }
}
static void
set_preference(rtx dest, rtx src) asm("_set_preference");
static void
set_preference(rtx dest, rtx src)
{
  int src_regno, dest_regno;


  int offset = 0;
  int i;
  int copy = 1;

  if ((rtx_format[(int)(((src)->code))])[0] == 'e')
    src = ((src)->fld[0].rtx), copy = 0;




  if (((src)->code) == REG)
    src_regno = ((src)->fld[0].rtint);
  else if (((src)->code) == SUBREG && ((((src)->fld[0].rtx))->code) == REG)
    {
      src_regno = ((((src)->fld[0].rtx))->fld[0].rtint);
      offset += ((src)->fld[1].rtint);
    }
  else
    return;

  if (((dest)->code) == REG)
    dest_regno = ((dest)->fld[0].rtint);
  else if (((dest)->code) == SUBREG && ((((dest)->fld[0].rtx))->code) == REG)
    {
      dest_regno = ((((dest)->fld[0].rtx))->fld[0].rtint);
      offset -= ((dest)->fld[1].rtint);
    }
  else
    return;



  if (reg_renumber[src_regno] >= 0)
    src_regno = reg_renumber[src_regno];

  if (reg_renumber[dest_regno] >= 0)
    dest_regno = reg_renumber[dest_regno];




  if (dest_regno < 68 && src_regno >= 68
      && reg_allocno[src_regno] >= 0)
    {
      dest_regno -= offset;
      if (dest_regno >= 0 && dest_regno < 68)
 {
   if (copy)
     ((hard_reg_copy_preferences[reg_allocno[src_regno]])[(dest_regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((dest_regno) % ((unsigned) 32)))
                                      ;

   ((hard_reg_preferences[reg_allocno[src_regno]])[(dest_regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((dest_regno) % ((unsigned) 32)))
                                           ;
   for (i = dest_regno;
        i < dest_regno + (! ((unsigned) ((dest_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
        i++)
     ((hard_reg_full_preferences[reg_allocno[src_regno]])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
 }
    }

  if (src_regno < 68 && dest_regno >= 68
      && reg_allocno[dest_regno] >= 0)
    {
      src_regno += offset;
      if (src_regno >= 0 && src_regno < 68)
 {
   if (copy)
     ((hard_reg_copy_preferences[reg_allocno[dest_regno]])[(src_regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((src_regno) % ((unsigned) 32)))
                                      ;

   ((hard_reg_preferences[reg_allocno[dest_regno]])[(src_regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((src_regno) % ((unsigned) 32)))
                                           ;
   for (i = src_regno;
        i < src_regno + (! ((unsigned) ((src_regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((src)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((src)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
        i++)
     ((hard_reg_full_preferences[reg_allocno[dest_regno]])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
 }
    }
}






void
mark_elimination(int from, int to) asm("_mark_elimination");
void
mark_elimination(int from, int to)
{
  int i;

  for (i = 0; i < n_basic_blocks; i++)
    if ((basic_block_live_at_start[i][from / 32]
  & ((unsigned int) 1 << (from % 32))) != 0)
      {
 basic_block_live_at_start[i][from / 32]
   &= ~ ((unsigned int) 1 << (from % 32));
 basic_block_live_at_start[i][to / 32]
   |= ((unsigned int) 1 << (to % 32));
      }
}




static void
dump_conflicts(FILE *file) asm("_dump_conflicts");
static void
dump_conflicts(FILE *file)
{
  register int i;
  register int has_preferences;
  fprintf (file, ";; %d regs to allocate:", max_allocno);
  for (i = 0; i < max_allocno; i++)
    {
      int j;
      fprintf (file, " %d", allocno_reg[allocno_order[i]]);
      for (j = 0; j < max_regno; j++)
 if (reg_allocno[j] == allocno_order[i]
     && j != allocno_reg[allocno_order[i]])
   fprintf (file, "+%d", j);
      if (allocno_size[allocno_order[i]] != 1)
 fprintf (file, " (%d)", allocno_size[allocno_order[i]]);
    }
  fprintf (file, "\n");

  for (i = 0; i < max_allocno; i++)
    {
      register int j;
      fprintf (file, ";; %d conflicts:", allocno_reg[i]);
      for (j = 0; j < max_allocno; j++)
 if ((conflicts[(i) * allocno_row_words + (j) / 32] & ((int) 1 << ((j) % 32))) || (conflicts[(j) * allocno_row_words + (i) / 32] & ((int) 1 << ((i) % 32))))
   fprintf (file, " %d", allocno_reg[j]);
      for (j = 0; j < 68; j++)
 if (((hard_reg_conflicts[i])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)))))
   fprintf (file, " %d", j);
      fprintf (file, "\n");

      has_preferences = 0;
      for (j = 0; j < 68; j++)
 if (((hard_reg_preferences[i])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)))))
   has_preferences = 1;

      if (! has_preferences)
 continue;
      fprintf (file, ";; %d preferences:", allocno_reg[i]);
      for (j = 0; j < 68; j++)
 if (((hard_reg_preferences[i])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)))))
   fprintf (file, " %d", j);
      fprintf (file, "\n");
    }
  fprintf (file, "\n");
}

void
dump_global_regs(FILE *file) asm("_dump_global_regs");
void
dump_global_regs(FILE *file)
{
  register int i, j;

  fprintf (file, ";; Register dispositions:\n");
  for (i = 68, j = 0; i < max_regno; i++)
    if (reg_renumber[i] >= 0)
      {
 fprintf (file, "%d in %d  ", i, reg_renumber[i]);
        if (++j % 6 == 0)
   fprintf (file, "\n");
      }

  fprintf (file, "\n\n;; Hard regs used: ");
  for (i = 0; i < 68; i++)
    if (regs_ever_live[i])
      fprintf (file, " %d", i);
  fprintf (file, "\n\n");
}

