// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/parse.c
/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int do_pending_lang_change(...) asm("_do_pending_lang_change");
extern int push_namespace(...) asm("_push_namespace");
extern int pop_namespace(...) asm("_pop_namespace");
extern int do_namespace_alias(...) asm("_do_namespace_alias");
extern int do_using_directive(...) asm("_do_using_directive");
extern int sorry(...) asm("_sorry");
extern int pedwarn(...) asm("_pedwarn");
extern int warning(...) asm("_warning");
extern int split_specs_attrs(...) asm("_split_specs_attrs");
extern int error(...) asm("_error");
extern int push_obstacks(...) asm("_push_obstacks");
extern int repo_template_used(...) asm("_repo_template_used");
extern int pop_tinst_level(...) asm("_pop_tinst_level");
extern int emit_line_note(...) asm("_emit_line_note");
extern int declare_nonlocal_label(...) asm("_declare_nonlocal_label");
extern int emit_nop(...) asm("_emit_nop");
extern int note_level_for_for(...) asm("_note_level_for_for");
extern int push_switch(...) asm("_push_switch");
extern int pop_switch(...) asm("_pop_switch");
extern int error_with_decl(...) asm("_error_with_decl");
extern int expand_computed_goto(...) asm("_expand_computed_goto");
extern int expand_end_catch_block(...) asm("_expand_end_catch_block");
extern int expand_start_catch_block(...) asm("_expand_start_catch_block");
struct n64_tag_file_stack;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_yyltype;





extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");




enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *input_filename;


extern char *main_input_filename;


extern int lineno;


extern FILE *finput;

struct n64_tag_file_stack
  {
    char *name;
    struct n64_tag_file_stack *next;
    int line;
  };



extern struct n64_tag_file_stack *input_file_stack;


extern int input_file_stack_tick;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_BOOL,
  RID_CHAR,
  RID_WCHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,


  RID_CLASS,
  RID_RECORD,
  RID_UNION,
  RID_ENUM,
  RID_LONGLONG,





  RID_EXTERN,
  RID_CONST,
  RID_LONG,
  RID_TYPEDEF,
  RID_UNSIGNED,
  RID_SHORT,
  RID_INLINE,

  RID_STATIC,

  RID_REGISTER,
  RID_VOLATILE,
  RID_FRIEND,
  RID_VIRTUAL,
  RID_EXPLICIT,
  RID_SIGNED,
  RID_AUTO,
  RID_MUTABLE,



  RID_PUBLIC,
  RID_PRIVATE,
  RID_PROTECTED,
  RID_EXCEPTION,
  RID_TEMPLATE,
  RID_SIGNATURE,


  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

typedef struct { unsigned long idata[2]; }
     RID_BIT_TYPE;
extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;


extern int looking_for_typename;
extern int looking_for_template;


extern tree got_scope;
extern tree got_object;



extern int pending_lang_change;

extern tree make_pointer_declarator (...) asm("_make_pointer_declarator"), make_reference_declarator (...) asm("_make_reference_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern void reinit_parse_for_method(...) asm("_reinit_parse_for_method");
extern int yylex(void) asm("_yylex");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct rtx_def *, struct rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");
extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");
extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;
extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;



char *language_string = "GNU C++";

extern tree void_list_node;
extern struct obstack permanent_obstack;





extern int end_of_file;
extern int current_class_depth;


extern tree strip_attrs (tree) asm("_strip_attrs");


void yyerror(...) asm("_yyerror");
static char *cond_stmt_keyword;


int have_extern_spec;
int used_extern_spec;

void yyhook(...) asm("_yyhook");





static tree
empty_parms(void) asm("_empty_parms");
static tree
empty_parms(void)
{
  tree parms;

  if (strict_prototype)
    parms = void_list_node;
  else
    parms = (tree) 
           ((void *)0)
                    ;
  return parms;
}
typedef union {long itype; tree ttype; char *strtype; n64_enum_tree_code code; } YYSTYPE;


static tree current_declspecs;





static tree prefix_attributes;


static tree current_aggr;




extern void yyprint(...) asm("_yyprint");
extern tree combine_strings (tree) asm("_combine_strings");


typedef
  struct n64_tag_yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
static const char yytranslate[] = { 0,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 107, 2, 2, 2, 80, 68, 2, 91,
   105, 78, 76, 57, 77, 90, 79, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 60, 58, 72,
    62, 73, 63, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    92, 2, 108, 67, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 56, 66, 106, 86, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 1, 2, 3, 4, 5,
     6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
    36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    59, 61, 64, 65, 69, 70, 71, 74, 75, 81,
    82, 83, 84, 85, 87, 88, 89, 93, 94, 95,
    96, 97, 98, 99, 100, 101, 102, 103, 104
};


static const short yyprhs[] = { 0,
     0, 1, 3, 4, 7, 10, 12, 13, 14, 15,
    17, 19, 20, 23, 25, 27, 29, 31, 37, 42,
    47, 52, 53, 60, 61, 67, 73, 76, 81, 84,
    88, 92, 94, 96, 99, 102, 104, 107, 108, 114,
   116, 120, 122, 125, 127, 130, 132, 136, 138, 142,
   144, 148, 149, 155, 156, 162, 163, 169, 170, 176,
   180, 184, 191, 199, 204, 208, 212, 214, 216, 218,
   220, 222, 225, 229, 233, 237, 241, 244, 247, 250,
   253, 256, 258, 260, 262, 263, 265, 268, 269, 271,
   276, 277, 283, 287, 291, 294, 298, 302, 305, 307,
   314, 319, 323, 327, 330, 333, 336, 341, 344, 348,
   349, 350, 352, 356, 359, 363, 365, 370, 373, 378,
   381, 386, 389, 391, 393, 395, 397, 399, 401, 403,
   405, 407, 409, 413, 417, 420, 425, 430, 434, 438,
   443, 447, 452, 453, 455, 459, 461, 463, 464, 471,
   472, 474, 475, 478, 480, 482, 484, 486, 488, 490,
   492, 494, 498, 500, 504, 505, 507, 509, 510, 519,
   521, 523, 527, 532, 536, 539, 541, 545, 549, 553,
   557, 559, 561, 563, 564, 568, 571, 574, 577, 580,
   583, 586, 591, 594, 599, 602, 606, 610, 615, 620,
   626, 632, 639, 642, 647, 653, 657, 661, 665, 667,
   671, 674, 678, 683, 685, 688, 694, 696, 700, 704,
   708, 712, 716, 720, 724, 728, 732, 736, 740, 744,
   748, 752, 756, 760, 764, 768, 772, 778, 782, 786,
   788, 791, 795, 797, 799, 801, 803, 805, 807, 809,
   812, 815, 819, 821, 823, 827, 829, 831, 833, 835,
   839, 843, 847, 848, 853, 854, 861, 864, 869, 872,
   875, 877, 882, 884, 885, 886, 896, 897, 898, 908,
   909, 910, 920, 921, 922, 932, 937, 942, 945, 948,
   950, 955, 958, 961, 964, 970, 974, 980, 984, 989,
   996, 999, 1001, 1004, 1006, 1009, 1011, 1013, 1015, 1018,
  1019, 1022, 1025, 1029, 1033, 1037, 1041, 1045, 1048, 1051,
  1053, 1055, 1057, 1060, 1063, 1066, 1069, 1071, 1073, 1075,
  1077, 1080, 1083, 1087, 1091, 1095, 1100, 1102, 1105, 1108,
  1111, 1113, 1115, 1117, 1120, 1123, 1126, 1128, 1130, 1133,
  1136, 1140, 1142, 1145, 1147, 1149, 1151, 1156, 1161, 1166,
  1171, 1173, 1175, 1177, 1179, 1183, 1185, 1189, 1191, 1195,
  1196, 1201, 1202, 1210, 1215, 1216, 1224, 1229, 1230, 1238,
  1243, 1244, 1252, 1257, 1258, 1260, 1262, 1265, 1272, 1274,
  1278, 1279, 1281, 1286, 1293, 1298, 1300, 1302, 1304, 1306,
  1308, 1312, 1313, 1316, 1318, 1321, 1325, 1330, 1332, 1334,
  1338, 1343, 1350, 1354, 1360, 1361, 1369, 1374, 1375, 1382,
  1386, 1389, 1392, 1395, 1400, 1402, 1403, 1405, 1406, 1408,
  1410, 1413, 1416, 1419, 1422, 1426, 1429, 1431, 1434, 1438,
  1442, 1446, 1449, 1450, 1452, 1456, 1459, 1462, 1464, 1466,
  1467, 1470, 1474, 1476, 1481, 1483, 1487, 1489, 1494, 1499,
  1502, 1505, 1509, 1513, 1515, 1516, 1518, 1523, 1527, 1529,
  1532, 1535, 1538, 1541, 1544, 1547, 1550, 1552, 1555, 1558,
  1564, 1567, 1569, 1579, 1587, 1589, 1590, 1592, 1596, 1597,
  1599, 1603, 1605, 1607, 1609, 1611, 1617, 1622, 1628, 1633,
  1637, 1643, 1648, 1654, 1659, 1663, 1665, 1669, 1671, 1675,
  1678, 1680, 1687, 1688, 1691, 1693, 1696, 1697, 1700, 1705,
  1710, 1713, 1718, 1722, 1726, 1729, 1732, 1736, 1738, 1740,
  1742, 1745, 1749, 1754, 1758, 1762, 1765, 1767, 1771, 1775,
  1778, 1781, 1785, 1787, 1791, 1795, 1798, 1801, 1805, 1807,
  1811, 1815, 1820, 1824, 1826, 1829, 1832, 1834, 1837, 1842,
  1847, 1850, 1852, 1854, 1856, 1859, 1862, 1865, 1868, 1870,
  1873, 1875, 1878, 1881, 1885, 1887, 1891, 1894, 1898, 1901,
  1904, 1908, 1910, 1914, 1919, 1923, 1926, 1929, 1931, 1935,
  1938, 1941, 1943, 1946, 1950, 1952, 1956, 1958, 1964, 1968,
  1973, 1977, 1982, 1985, 1988, 1992, 1995, 1997, 1999, 2002,
  2005, 2008, 2009, 2010, 2011, 2013, 2015, 2018, 2022, 2024,
  2027, 2032, 2033, 2034, 2041, 2043, 2047, 2049, 2051, 2053,
  2056, 2057, 2058, 2065, 2067, 2068, 2069, 2077, 2078, 2079,
  2087, 2088, 2089, 2090, 2091, 2106, 2107, 2108, 2118, 2119,
  2125, 2126, 2134, 2135, 2140, 2143, 2146, 2149, 2153, 2160,
  2169, 2180, 2193, 2198, 2202, 2205, 2208, 2210, 2212, 2213,
  2214, 2221, 2222, 2223, 2229, 2230, 2231, 2232, 2233, 2243,
  2245, 2247, 2251, 2255, 2258, 2261, 2264, 2267, 2269, 2272,
  2273, 2275, 2276, 2278, 2280, 2281, 2283, 2285, 2289, 2294,
  2296, 2300, 2301, 2303, 2305, 2307, 2310, 2313, 2316, 2318,
  2320, 2323, 2326, 2329, 2332, 2334, 2338, 2341, 2344, 2349,
  2352, 2355, 2358, 2361, 2364, 2367, 2369, 2372, 2375, 2377,
  2379, 2380, 2381, 2383, 2384, 2389, 2392, 2394, 2396, 2400,
  2401, 2405, 2409, 2413, 2415, 2418, 2421, 2424, 2427, 2430,
  2433, 2436, 2439, 2442, 2445, 2448, 2451, 2454, 2457, 2460,
  2463, 2466, 2469, 2472, 2475, 2478, 2481, 2484, 2488, 2491,
  2494, 2497, 2500, 2504, 2507, 2510, 2515, 2520, 2524
};

static const short yyrhs[] = { -1,
   110, 0, 0, 111, 116, 0, 110, 116, 0, 110,
     0, 0, 0, 0, 25, 0, 26, 0, 0, 117,
   118, 0, 141, 0, 137, 0, 131, 0, 129, 0,
   115, 91, 200, 105, 58, 0, 123, 56, 112, 106,
     0, 123, 113, 141, 114, 0, 123, 113, 137, 114,
     0, 0, 42, 151, 56, 119, 112, 106, 0, 0,
    42, 56, 120, 112, 106, 0, 42, 151, 62, 122,
    58, 0, 121, 58, 0, 44, 42, 122, 58, 0,
    44, 284, 0, 44, 294, 284, 0, 44, 294, 183,
     0, 183, 0, 284, 0, 294, 284, 0, 294, 183,
     0, 97, 0, 123, 97, 0, 0, 46, 72, 125,
   126, 73, 0, 128, 0, 126, 57, 128, 0, 242,
     0, 242, 151, 0, 43, 0, 43, 151, 0, 127,
     0, 127, 62, 213, 0, 354, 0, 37, 130, 58,
     0, 3, 0, 130, 57, 3, 0, 0, 124, 244,
    56, 132, 58, 0, 0, 124, 245, 56, 133, 58,
     0, 0, 124, 244, 60, 134, 58, 0, 0, 124,
   245, 60, 135, 58, 0, 124, 244, 58, 0, 124,
   245, 58, 0, 124, 281, 358, 218, 227, 136, 0,
   124, 207, 204, 358, 218, 227, 136, 0, 124, 210,
   281, 136, 0, 124, 1, 106, 0, 124, 1, 58,
     0, 56, 0, 60, 0, 58, 0, 62, 0, 23,
     0, 217, 58, 0, 210, 216, 58, 0, 210, 281,
    58, 0, 207, 215, 58, 0, 207, 204, 58, 0,
   210, 58, 0, 154, 58, 0, 207, 58, 0, 1,
    58, 0, 1, 106, 0, 58, 0, 201, 0, 147,
     0, 0, 146, 0, 146, 58, 0, 0, 104, 0,
   143, 139, 138, 306, 0, 0, 143, 139, 329, 142,
   140, 0, 207, 204, 1, 0, 210, 281, 1, 0,
   281, 1, 0, 207, 204, 358, 0, 210, 281, 358,
     0, 281, 358, 0, 96, 0, 207, 91, 349, 105,
   272, 358, 0, 207, 45, 272, 358, 0, 207, 204,
   358, 0, 210, 281, 358, 0, 281, 358, 0, 23,
     3, 0, 145, 234, 0, 145, 91, 174, 105, 0,
   145, 45, 0, 60, 148, 149, 0, 0, 0, 150,
     0, 149, 57, 150, 0, 149, 1, 0, 91, 174,
   105, 0, 45, 0, 152, 91, 174, 105, 0, 152,
    45, 0, 291, 91, 174, 105, 0, 291, 45, 0,
   285, 91, 174, 105, 0, 285, 45, 0, 3, 0,
     4, 0, 54, 0, 55, 0, 3, 0, 54, 0,
    55, 0, 101, 0, 100, 0, 102, 0, 46, 243,
   162, 0, 46, 207, 204, 0, 46, 281, 0, 5,
    46, 243, 162, 0, 5, 46, 207, 204, 0, 5,
    46, 281, 0, 156, 157, 162, 0, 54, 72, 158,
    73, 0, 54, 72, 73, 0, 4, 72, 158, 73,
     0, 0, 159, 0, 158, 57, 159, 0, 206, 0,
   181, 0, 0, 99, 251, 161, 256, 257, 106, 0,
     0, 160, 0, 0, 160, 163, 0, 77, 0, 76,
     0, 84, 0, 85, 0, 107, 0, 173, 0, 181,
     0, 45, 0, 91, 165, 105, 0, 45, 0, 91,
   169, 105, 0, 0, 169, 0, 1, 0, 0, 339,
   204, 358, 218, 227, 62, 170, 235, 0, 165, 0,
   106, 0, 303, 299, 106, 0, 303, 299, 1, 106,
     0, 303, 1, 106, 0, 56, 171, 0, 313, 0,
   181, 57, 181, 0, 181, 57, 1, 0, 173, 57,
   181, 0, 173, 57, 1, 0, 181, 0, 173, 0,
   186, 0, 0, 31, 176, 180, 0, 78, 180, 0,
    68, 180, 0, 86, 180, 0, 164, 180, 0, 65,
   151, 0, 11, 175, 0, 11, 91, 206, 105, 0,
    28, 175, 0, 28, 91, 206, 105, 0, 197, 271,
     0, 197, 271, 178, 0, 197, 177, 271, 0, 197,
   177, 271, 178, 0, 197, 91, 206, 105, 0, 197,
    91, 206, 105, 178, 0, 197, 177, 91, 206, 105,
     0, 197, 177, 91, 206, 105, 178, 0, 198, 180,
     0, 198, 92, 108, 180, 0, 198, 92, 165, 108,
   180, 0, 91, 174, 105, 0, 56, 174, 106, 0,
    91, 174, 105, 0, 45, 0, 91, 213, 105, 0,
    62, 235, 0, 91, 206, 105, 0, 179, 91, 206,
   105, 0, 175, 0, 179, 175, 0, 179, 56, 236,
   240, 106, 0, 180, 0, 181, 81, 181, 0, 181,
    82, 181, 0, 181, 76, 181, 0, 181, 77, 181,
     0, 181, 78, 181, 0, 181, 79, 181, 0, 181,
    80, 181, 0, 181, 74, 181, 0, 181, 75, 181,
     0, 181, 71, 181, 0, 181, 72, 181, 0, 181,
    73, 181, 0, 181, 70, 181, 0, 181, 69, 181,
     0, 181, 68, 181, 0, 181, 66, 181, 0, 181,
    67, 181, 0, 181, 65, 181, 0, 181, 64, 181,
     0, 181, 63, 344, 60, 181, 0, 181, 62, 181,
     0, 181, 61, 181, 0, 59, 0, 59, 181, 0,
    86, 356, 151, 0, 363, 0, 3, 0, 54, 0,
    55, 0, 182, 0, 4, 0, 182, 0, 78, 184,
     0, 68, 184, 0, 91, 184, 105, 0, 283, 0,
   182, 0, 91, 184, 105, 0, 182, 0, 8, 0,
   199, 0, 200, 0, 91, 165, 105, 0, 91, 184,
   105, 0, 91, 1, 105, 0, 0, 91, 187, 307,
   105, 0, 0, 186, 91, 174, 105, 188, 163, 0,
   186, 45, 0, 186, 92, 165, 108, 0, 186, 84,
     0, 186, 85, 0, 38, 0, 7, 91, 174, 105,
     0, 287, 0, 0, 0, 48, 72, 189, 206, 73,
   190, 91, 165, 105, 0, 0, 0, 49, 72, 191,
   206, 73, 192, 91, 165, 105, 0, 0, 0, 50,
    72, 193, 206, 73, 194, 91, 165, 105, 0, 0,
     0, 51, 72, 195, 206, 73, 196, 91, 165, 105,
     0, 47, 91, 165, 105, 0, 47, 91, 206, 105,
     0, 294, 3, 0, 294, 363, 0, 286, 0, 286,
    91, 174, 105, 0, 286, 45, 0, 202, 183, 0,
   202, 286, 0, 202, 183, 91, 174, 105, 0, 202,
   183, 45, 0, 202, 286, 91, 174, 105, 0, 202,
   286, 45, 0, 202, 86, 6, 45, 0, 202, 6,
    52, 86, 6, 45, 0, 202, 1, 0, 36, 0,
   294, 36, 0, 35, 0, 294, 198, 0, 40, 0,
    41, 0, 9, 0, 200, 9, 0, 0, 186, 90,
     0, 186, 89, 0, 213, 204, 58, 0, 207, 204,
    58, 0, 213, 215, 58, 0, 207, 215, 58, 0,
   210, 216, 58, 0, 207, 58, 0, 210, 58, 0,
   277, 0, 281, 0, 45, 0, 205, 45, 0, 211,
   297, 0, 273, 297, 0, 213, 297, 0, 211, 0,
   273, 0, 211, 0, 208, 0, 210, 213, 0, 213,
   209, 0, 213, 212, 209, 0, 210, 213, 209, 0,
   210, 213, 212, 0, 210, 213, 212, 209, 0, 5,
     0, 209, 214, 0, 209, 5, 0, 209, 228, 0,
   228, 0, 273, 0, 5, 0, 210, 7, 0, 210,
     5, 0, 210, 228, 0, 228, 0, 213, 0, 273,
   213, 0, 213, 212, 0, 273, 213, 212, 0, 214,
     0, 212, 214, 0, 237, 0, 6, 0, 291, 0,
    27, 91, 165, 105, 0, 27, 91, 206, 105, 0,
    29, 91, 165, 105, 0, 29, 91, 206, 105, 0,
     6, 0, 7, 0, 237, 0, 219, 0, 215, 57,
   221, 0, 223, 0, 216, 57, 221, 0, 225, 0,
   217, 57, 221, 0, 0, 115, 91, 200, 105, 0,
     0, 204, 358, 218, 227, 62, 220, 235, 0, 204,
   358, 218, 227, 0, 0, 204, 358, 218, 227, 62,
   222, 235, 0, 204, 358, 218, 227, 0, 0, 281,
   358, 218, 227, 62, 224, 235, 0, 281, 358, 218,
   227, 0, 0, 281, 358, 218, 227, 62, 226, 235,
     0, 281, 358, 218, 227, 0, 0, 228, 0, 229,
     0, 228, 229, 0, 30, 91, 91, 230, 105, 105,
     0, 231, 0, 230, 57, 231, 0, 0, 232, 0,
   232, 91, 3, 105, 0, 232, 91, 3, 57, 174,
   105, 0, 232, 91, 174, 105, 0, 151, 0, 5,
     0, 6, 0, 7, 0, 151, 0, 233, 57, 151,
     0, 0, 62, 235, 0, 181, 0, 56, 106, 0,
    56, 236, 106, 0, 56, 236, 57, 106, 0, 1,
     0, 235, 0, 236, 57, 235, 0, 92, 181, 108,
   235, 0, 236, 57, 19, 181, 60, 235, 0, 151,
    60, 235, 0, 236, 57, 151, 60, 235, 0, 0,
    12, 151, 56, 238, 269, 241, 106, 0, 12, 151,
    56, 106, 0, 0, 12, 56, 239, 269, 241, 106,
     0, 12, 56, 106, 0, 12, 151, 0, 12, 292,
     0, 43, 292, 0, 250, 256, 257, 106, 0, 250,
     0, 0, 57, 0, 0, 57, 0, 33, 0, 242,
     5, 0, 242, 6, 0, 242, 7, 0, 242, 33,
     0, 242, 156, 58, 0, 242, 151, 0, 243, 0,
   242, 153, 0, 242, 156, 56, 0, 242, 156, 60,
     0, 242, 289, 151, 0, 242, 155, 0, 0, 244,
     0, 245, 247, 251, 0, 246, 251, 0, 242, 56,
     0, 249, 0, 248, 0, 0, 60, 356, 0, 60,
   356, 252, 0, 253, 0, 252, 57, 356, 253, 0,
   254, 0, 255, 356, 254, 0, 291, 0, 29, 91,
   165, 105, 0, 29, 91, 206, 105, 0, 34, 356,
     0, 5, 356, 0, 255, 34, 356, 0, 255, 5,
   356, 0, 56, 0, 0, 258, 0, 257, 34, 60,
   258, 0, 257, 34, 60, 0, 259, 0, 258, 259,
     0, 260, 58, 0, 260, 106, 0, 144, 60, 0,
   144, 93, 0, 144, 23, 0, 144, 56, 0, 58,
     0, 207, 261, 0, 210, 262, 0, 281, 358, 218,
   227, 234, 0, 60, 181, 0, 1, 0, 207, 91,
   349, 105, 272, 358, 218, 227, 234, 0, 207, 45,
   272, 358, 218, 227, 234, 0, 121, 0, 0, 263,
     0, 261, 57, 264, 0, 0, 266, 0, 262, 57,
   268, 0, 265, 0, 266, 0, 267, 0, 268, 0,
   277, 358, 218, 227, 234, 0, 4, 60, 181, 227,
     0, 281, 358, 218, 227, 234, 0, 3, 60, 181,
   227, 0, 60, 181, 227, 0, 277, 358, 218, 227,
   234, 0, 4, 60, 181, 227, 0, 281, 358, 218,
   227, 234, 0, 3, 60, 181, 227, 0, 60, 181,
   227, 0, 270, 0, 269, 57, 270, 0, 151, 0,
   151, 62, 181, 0, 339, 295, 0, 339, 0, 91,
   206, 105, 92, 165, 108, 0, 0, 272, 7, 0,
     7, 0, 273, 7, 0, 0, 274, 165, 0, 274,
    91, 174, 105, 0, 274, 91, 349, 105, 0, 274,
    45, 0, 274, 91, 1, 105, 0, 78, 273, 277,
     0, 68, 273, 277, 0, 78, 277, 0, 68, 277,
     0, 293, 272, 277, 0, 280, 0, 288, 0, 279,
     0, 289, 288, 0, 280, 276, 272, 0, 280, 92,
   275, 108, 0, 280, 92, 108, 0, 91, 277, 105,
     0, 289, 288, 0, 288, 0, 78, 273, 281, 0,
    68, 273, 281, 0, 78, 281, 0, 68, 281, 0,
   293, 272, 281, 0, 185, 0, 78, 273, 281, 0,
    68, 273, 281, 0, 78, 282, 0, 68, 282, 0,
   293, 272, 281, 0, 283, 0, 185, 276, 272, 0,
    91, 282, 105, 0, 185, 92, 275, 108, 0, 185,
    92, 108, 0, 285, 0, 289, 183, 0, 289, 182,
     0, 285, 0, 294, 285, 0, 213, 91, 174, 105,
     0, 213, 91, 184, 105, 0, 213, 205, 0, 4,
     0, 155, 0, 290, 0, 289, 290, 0, 4, 52,
     0, 55, 52, 0, 155, 52, 0, 278, 0, 294,
   278, 0, 279, 0, 294, 278, 0, 289, 78, 0,
   294, 289, 78, 0, 52, 0, 78, 272, 295, 0,
    78, 272, 0, 68, 272, 295, 0, 68, 272, 0,
   293, 272, 0, 293, 272, 295, 0, 296, 0, 92,
   165, 108, 0, 296, 92, 275, 108, 0, 78, 273,
   297, 0, 78, 297, 0, 78, 273, 0, 78, 0,
    68, 273, 297, 0, 68, 297, 0, 68, 273, 0,
    68, 0, 293, 272, 0, 293, 272, 297, 0, 298,
     0, 91, 297, 105, 0, 88, 0, 298, 91, 349,
   105, 272, 0, 298, 45, 272, 0, 298, 92, 275,
   108, 0, 298, 92, 108, 0, 91, 350, 105, 272,
     0, 179, 272, 0, 205, 272, 0, 92, 275, 108,
     0, 92, 108, 0, 312, 0, 300, 0, 299, 312,
     0, 299, 300, 0, 1, 58, 0, 0, 0, 0,
   304, 0, 305, 0, 304, 305, 0, 32, 233, 58,
     0, 307, 0, 1, 307, 0, 56, 301, 171, 302,
     0, 0, 0, 13, 309, 301, 167, 310, 311, 0,
   307, 0, 301, 313, 302, 0, 307, 0, 313, 0,
   203, 0, 165, 58, 0, 0, 0, 308, 14, 314,
   311, 315, 302, 0, 308, 0, 0, 0, 15, 316,
   301, 167, 317, 172, 302, 0, 0, 0, 16, 318,
   311, 15, 319, 166, 58, 0, 0, 0, 0, 0,
    17, 320, 91, 342, 321, 301, 168, 58, 322, 344,
   105, 323, 172, 302, 0, 0, 0, 18, 301, 91,
   169, 105, 324, 311, 325, 302, 0, 0, 19, 181,
    60, 326, 312, 0, 0, 19, 181, 10, 181, 60,
   327, 312, 0, 0, 20, 60, 328, 312, 0, 21,
    58, 0, 22, 58, 0, 23, 58, 0, 23, 165,
    58, 0, 115, 343, 91, 200, 105, 58, 0, 115,
   343, 91, 200, 60, 345, 105, 58, 0, 115, 343,
    91, 200, 60, 345, 60, 345, 105, 58, 0, 115,
   343, 91, 200, 60, 345, 60, 345, 60, 348, 105,
    58, 0, 24, 78, 165, 58, 0, 24, 151, 58,
     0, 341, 312, 0, 341, 106, 0, 58, 0, 332,
     0, 0, 0, 93, 330, 138, 306, 331, 335, 0,
     0, 0, 93, 333, 307, 334, 335, 0, 0, 0,
     0, 0, 335, 94, 301, 336, 340, 337, 307, 338,
   302, 0, 211, 0, 273, 0, 91, 10, 105, 0,
    91, 355, 105, 0, 3, 60, 0, 54, 60, 0,
     4, 60, 0, 344, 58, 0, 203, 0, 56, 171,
     0, 0, 7, 0, 0, 165, 0, 1, 0, 0,
   346, 0, 347, 0, 346, 57, 347, 0, 9, 91,
   165, 105, 0, 9, 0, 348, 57, 9, 0, 0,
   350, 0, 206, 0, 351, 0, 352, 10, 0, 351,
    10, 0, 206, 10, 0, 10, 0, 95, 0, 351,
    95, 0, 206, 95, 0, 351, 60, 0, 206, 60,
     0, 353, 0, 355, 62, 235, 0, 352, 354, 0,
   352, 357, 0, 352, 357, 62, 235, 0, 351, 57,
     0, 206, 57, 0, 208, 204, 0, 211, 204, 0,
   213, 204, 0, 208, 297, 0, 208, 0, 210, 281,
     0, 355, 234, 0, 353, 0, 206, 0, 0, 0,
   281, 0, 0, 59, 91, 360, 105, 0, 59, 45,
     0, 206, 0, 359, 0, 360, 57, 359, 0, 0,
    78, 272, 361, 0, 68, 272, 361, 0, 293, 272,
   361, 0, 39, 0, 362, 78, 0, 362, 79, 0,
   362, 80, 0, 362, 76, 0, 362, 77, 0, 362,
    68, 0, 362, 66, 0, 362, 67, 0, 362, 86,
     0, 362, 57, 0, 362, 71, 0, 362, 72, 0,
   362, 73, 0, 362, 70, 0, 362, 61, 0, 362,
    62, 0, 362, 74, 0, 362, 75, 0, 362, 84,
     0, 362, 85, 0, 362, 65, 0, 362, 64, 0,
   362, 107, 0, 362, 63, 60, 0, 362, 69, 0,
   362, 89, 0, 362, 81, 0, 362, 45, 0, 362,
    92, 108, 0, 362, 36, 0, 362, 35, 0, 362,
    36, 92, 108, 0, 362, 35, 92, 108, 0, 362,
   339, 361, 0, 362, 1, 0
};




static const short yyrline[] = { 0,
   299, 300, 314, 316, 317, 321, 323, 326, 331, 335,
   337, 340, 343, 347, 350, 352, 354, 355, 358, 360,
   363, 366, 368, 370, 372, 374, 376, 378, 382, 385,
   387, 391, 393, 394, 396, 400, 403, 409, 412, 416,
   419, 423, 433, 435, 437, 441, 451, 453, 456, 461,
   463, 467, 473, 473, 476, 476, 479, 479, 492, 492,
   497, 502, 519, 540, 553, 554, 557, 558, 559, 560,
   561, 564, 567, 570, 577, 582, 590, 592, 593, 613,
   614, 615, 618, 621, 625, 627, 628, 631, 633, 636,
   642, 647, 647, 649, 651, 655, 663, 669, 674, 682,
   693, 700, 703, 706, 710, 718, 720, 722, 726, 739,
   759, 762, 764, 765, 768, 774, 780, 782, 784, 786,
   789, 793, 799, 801, 802, 803, 806, 808, 809, 812,
   814, 815, 818, 821, 824, 826, 828, 831, 835, 840,
   843, 845, 849, 854, 857, 861, 864, 867, 901, 919,
   922, 926, 929, 933, 935, 937, 939, 941, 945, 947,
   950, 955, 959, 964, 968, 971, 973, 977, 997, 1004,
  1007, 1009, 1010, 1011, 1014, 1017, 1021, 1025, 1028, 1030,
  1034, 1037, 1040, 1049, 1052, 1055, 1057, 1059, 1061, 1068,
  1079, 1101, 1103, 1105, 1110, 1112, 1114, 1116, 1118, 1121,
  1123, 1125, 1128, 1130, 1134, 1140, 1143, 1150, 1153, 1155,
  1163, 1172, 1178, 1184, 1186, 1188, 1201, 1204, 1206, 1208,
  1210, 1212, 1214, 1216, 1218, 1220, 1222, 1224, 1226, 1228,
  1230, 1232, 1234, 1236, 1238, 1240, 1242, 1244, 1247, 1254,
  1256, 1273, 1276, 1277, 1278, 1279, 1282, 1284, 1287, 1289,
  1291, 1293, 1297, 1299, 1300, 1304, 1324, 1325, 1326, 1328,
  1336, 1344, 1346, 1354, 1375, 1380, 1387, 1394, 1396, 1405,
  1410, 1433, 1477, 1478, 1480, 1482, 1485, 1487, 1489, 1492,
  1494, 1496, 1499, 1501, 1503, 1506, 1508, 1511, 1550, 1557,
  1559, 1561, 1563, 1566, 1569, 1585, 1601, 1613, 1626, 1635,
  1645, 1690, 1692, 1696, 1698, 1702, 1705, 1710, 1712, 1716,
  1729, 1731, 1738, 1749, 1760, 1766, 1771, 1773, 1778, 1785,
  1787, 1791, 1795, 1801, 1804, 1806, 1808, 1810, 1819, 1821,
  1824, 1827, 1829, 1831, 1833, 1835, 1840, 1846, 1848, 1853,
  1855, 1864, 1867, 1869, 1872, 1878, 1880, 1890, 1893, 1895,
  1897, 1901, 1904, 1912, 1913, 1914, 1915, 1919, 1923, 1937,
  1955, 1956, 1957, 1960, 1962, 1965, 1967, 1970, 1972, 1975,
  1978, 1982, 2000, 2002, 2021, 2027, 2028, 2034, 2043, 2045,
  2055, 2064, 2066, 2078, 2081, 2085, 2088, 2092, 2097, 2100,
  2104, 2107, 2109, 2111, 2113, 2120, 2122, 2123, 2124, 2128,
  2131, 2135, 2138, 2141, 2143, 2146, 2149, 2152, 2158, 2161,
  2164, 2166, 2168, 2170, 2174, 2178, 2182, 2185, 2188, 2192,
  2195, 2197, 2199, 2202, 2250, 2260, 2262, 2265, 2267, 2271,
  2272, 2274, 2276, 2278, 2282, 2291, 2294, 2297, 2300, 2306,
  2310, 2313, 2317, 2321, 2324, 2331, 2339, 2344, 2344, 2346,
  2349, 2351, 2355, 2357, 2361, 2388, 2418, 2420, 2442, 2466,
  2468, 2472, 2498, 2507, 2573, 2576, 2583, 2594, 2603, 2607,
  2622, 2625, 2630, 2632, 2634, 2636, 2638, 2642, 2648, 2650,
  2653, 2655, 2666, 2673, 2680, 2686, 2689, 2690, 2701, 2704,
  2705, 2716, 2718, 2721, 2723, 2726, 2733, 2741, 2748, 2754,
  2762, 2766, 2771, 2775, 2778, 2787, 2789, 2793, 2796, 2801,
  2804, 2808, 2817, 2820, 2824, 2827, 2834, 2838, 2844, 2847,
  2849, 2851, 2857, 2860, 2862, 2864, 2866, 2870, 2873, 2887,
  2890, 2895, 2898, 2900, 2902, 2904, 2908, 2914, 2917, 2919,
  2921, 2923, 2927, 2930, 2933, 2935, 2937, 2939, 2943, 2946,
  2949, 2951, 2953, 2955, 2964, 2970, 2976, 2978, 2982, 2985,
  2987, 2991, 2993, 2996, 2998, 3004, 3007, 3009, 3023, 3025,
  3029, 3031, 3035, 3038, 3044, 3050, 3053, 3055, 3057, 3059,
  3063, 3067, 3071, 3074, 3079, 3082, 3084, 3086, 3088, 3090,
  3092, 3094, 3096, 3100, 3104, 3108, 3112, 3113, 3115, 3117,
  3119, 3121, 3123, 3125, 3127, 3129, 3137, 3139, 3140, 3141,
  3144, 3151, 3159, 3167, 3169, 3174, 3176, 3179, 3193, 3196,
  3199, 3203, 3206, 3210, 3212, 3215, 3219, 3222, 3225, 3228,
  3241, 3244, 3246, 3247, 3253, 3258, 3260, 3263, 3267, 3270,
  3276, 3288, 3292, 3295, 3299, 3312, 3320, 3324, 3325, 3350,
  3350, 3382, 3382, 3398, 3398, 3402, 3406, 3409, 3414, 3421,
  3430, 3439, 3448, 3451, 3457, 3459, 3463, 3465, 3468, 3475,
  3479, 3485, 3489, 3492, 3495, 3497, 3500, 3502, 3504, 3506,
  3508, 3511, 3524, 3529, 3537, 3539, 3543, 3546, 3547, 3552,
  3556, 3560, 3563, 3564, 3570, 3572, 3575, 3577, 3581, 3586,
  3589, 3599, 3606, 3607, 3614, 3620, 3625, 3629, 3634, 3641,
  3645, 3649, 3654, 3665, 3679, 3682, 3684, 3686, 3688, 3692,
  3694, 3702, 3722, 3724, 3726, 3729, 3732, 3737, 3742, 3744,
  3747, 3769, 3775, 3782, 3785, 3787, 3791, 3796, 3798, 3805,
  3808, 3810, 3812, 3818, 3822, 3825, 3827, 3829, 3831, 3833,
  3835, 3837, 3839, 3841, 3843, 3845, 3847, 3849, 3851, 3853,
  3855, 3857, 3859, 3861, 3863, 3865, 3867, 3869, 3871, 3873,
  3875, 3877, 3879, 3881, 3883, 3885, 3887, 3890, 3892
};

static const char * const yytname[] = { "$","error","$illegal.","IDENTIFIER",
"TYPENAME","SCSPEC","TYPESPEC","TYPE_QUAL","CONSTANT","STRING","ELLIPSIS","SIZEOF",
"ENUM","IF","ELSE","WHILE","DO","FOR","SWITCH","CASE","DEFAULT","BREAK","CONTINUE",
"RETURN","GOTO","ASM_KEYWORD","GCC_ASM_KEYWORD","TYPEOF","ALIGNOF","SIGOF","ATTRIBUTE",
"EXTENSION","LABEL","AGGR","VISSPEC","DELETE","NEW","OVERLOAD","THIS","OPERATOR",
"CXX_TRUE","CXX_FALSE","NAMESPACE","TYPENAME_KEYWORD","USING","LEFT_RIGHT","TEMPLATE",
"TYPEID","DYNAMIC_CAST","STATIC_CAST","REINTERPRET_CAST","CONST_CAST","SCOPE",
"EMPTY","PTYPENAME","NSNAME","'{'","','","';'","THROW","':'","ASSIGN","'='",
"'?'","OROR","ANDAND","'|'","'^'","'&'","MIN_MAX","EQCOMPARE","ARITHCOMPARE",
"'<'","'>'","LSHIFT","RSHIFT","'+'","'-'","'*'","'/'","'%'","POINTSAT_STAR",
"DOT_STAR","UNARY","PLUSPLUS","MINUSMINUS","'~'","HYPERUNARY","PAREN_STAR_PAREN",
"POINTSAT","'.'","'('","'['","TRY","CATCH","TYPENAME_ELLIPSIS","PRE_PARSED_FUNCTION_DECL",
"EXTERN_LANG_STRING","ALL","PRE_PARSED_CLASS_DECL","TYPENAME_DEFN","IDENTIFIER_DEFN",
"PTYPENAME_DEFN","END_OF_LINE","END_OF_SAVED_INPUT","')'","'}'","'!'","']'",
"program","extdefs","@1","extdefs_opt",".hush_warning",".warning_ok","asm_keyword",
"lang_extdef","@2","extdef","@3","@4","using_decl","any_id","extern_lang_string",
"template_header","@5","template_parm_list","template_type_parm","template_parm",
"overloaddef","ov_identifiers","template_def","@6","@7","@8","@9","fn_tmpl_end",
"datadef","ctor_initializer_opt","maybe_return_init","eat_saved_input","fndef",
"@10","fn.def1","fn.def2","return_id","return_init","base_init",".set_base_init",
"member_init_list","member_init","identifier","notype_identifier","identifier_defn",
"explicit_instantiation","template_type","template_type_name","tmpl.2","template_arg_list",
"template_arg","template_instantiate_once","@11","template_instantiation","template_instantiate_some",
"unop","expr","paren_expr_or_null","paren_cond_or_null","xcond","condition",
"@12","compstmtend","already_scoped_stmt","nontrivial_exprlist","nonnull_exprlist",
"unary_expr","@13","new_placement","new_initializer","regcast_or_absdcl","cast_expr",
"expr_no_commas","notype_unqualified_id","unqualified_id","expr_or_declarator",
"direct_notype_declarator","primary","@14","@15","@16","@17","@18","@19","@20",
"@21","@22","@23","new","delete","boolean.literal","string","nodecls","object",
"decl","declarator","fcast_or_absdcl","type_id","typed_declspecs","typed_declspecs1",
"reserved_declspecs","declmods","typed_typespecs","reserved_typespecquals","typespec",
"typespecqual_reserved","initdecls","notype_initdecls","nomods_initdecls","maybeasm",
"initdcl0","@24","initdcl","@25","notype_initdcl0","@26","nomods_initdcl0","@27",
"maybe_attribute","attributes","attribute","attribute_list","attrib","any_word",
"identifiers_or_typenames","maybe_init","init","initlist","structsp","@28","@29",
"maybecomma","maybecomma_warn","aggr","specialization","named_class_head_sans_basetype",
"named_class_head_sans_basetype_defn","named_complex_class_head_sans_basetype",
"do_xref_defn","named_class_head","unnamed_class_head","class_head","maybe_base_class_list",
"base_class_list","base_class","base_class.1","base_class_access_list","left_curly",
"opt.component_decl_list","component_decl_list","component_decl","component_decl_1",
"components","notype_components","component_declarator0","component_declarator",
"after_type_component_declarator0","notype_component_declarator0","after_type_component_declarator",
"notype_component_declarator","enumlist","enumerator","new_type_id","type_quals",
"nonempty_type_quals","suspend_mom","nonmomentary_expr","maybe_parmlist","after_type_declarator",
"qualified_type_name","nested_type","direct_after_type_declarator","notype_declarator",
"complex_notype_declarator","complex_direct_notype_declarator","qualified_id",
"notype_qualified_id","overqualified_id","functional_cast","type_name","nested_name_specifier",
"nested_name_specifier_1","complete_type_name","complex_type_name","ptr_to_mem",
"global_scope","new_declarator","direct_new_declarator","absdcl","direct_abstract_declarator",
"stmts","errstmt",".pushlevel",".poplevel","maybe_label_decls","label_decls",
"label_decl","compstmt_or_error","compstmt","simple_if","@30","@31","implicitly_scoped_stmt",
"stmt","simple_stmt","@32","@33","@34","@35","@36","@37","@38","@39","@40","@41",
"@42","@43","@44","@45","@46","function_try_block","@47","@48","try_block","@49",
"@50","handler_seq","@51","@52","@53","type_specifier_seq","handler_args","label_colon",
"for.init.statement","maybe_type_qual","xexpr","asm_operands","nonnull_asm_operands",
"asm_operand","asm_clobbers","parmlist","complex_parmlist","parms","parms_comma",
"named_parm","full_parm","parm","see_typename","bad_parm","exception_specification_opt",
"ansi_raise_identifier","ansi_raise_identifiers","conversion_declarator","operator",
"operator_name",""
};


static const short yyr1[] = { 0,
   109, 109, 111, 110, 110, 112, 112, 113, 114, 115,
   115, 117, 116, 118, 118, 118, 118, 118, 118, 118,
   118, 119, 118, 120, 118, 118, 118, 118, 121, 121,
   121, 122, 122, 122, 122, 123, 123, 125, 124, 126,
   126, 127, 127, 127, 127, 128, 128, 128, 129, 130,
   130, 132, 131, 133, 131, 134, 131, 135, 131, 131,
   131, 131, 131, 131, 131, 131, 136, 136, 136, 136,
   136, 137, 137, 137, 137, 137, 137, 137, 137, 137,
   137, 137, 138, 138, 139, 139, 139, 140, 140, 141,
   142, 141, 141, 141, 141, 143, 143, 143, 143, 144,
   144, 144, 144, 144, 145, 146, 146, 146, 147, 148,
   149, 149, 149, 149, 150, 150, 150, 150, 150, 150,
   150, 150, 151, 151, 151, 151, 152, 152, 152, 153,
   153, 153, 154, 154, 154, 154, 154, 154, 155, 156,
   156, 156, 157, 158, 158, 159, 159, 161, 160, 162,
   162, 163, 163, 164, 164, 164, 164, 164, 165, 165,
   166, 166, 167, 167, 168, 168, 168, 170, 169, 169,
   171, 171, 171, 171, 172, 172, 173, 173, 173, 173,
   174, 174, 175, 176, 175, 175, 175, 175, 175, 175,
   175, 175, 175, 175, 175, 175, 175, 175, 175, 175,
   175, 175, 175, 175, 175, 177, 177, 178, 178, 178,
   178, 179, 179, 180, 180, 180, 181, 181, 181, 181,
   181, 181, 181, 181, 181, 181, 181, 181, 181, 181,
   181, 181, 181, 181, 181, 181, 181, 181, 181, 181,
   181, 182, 182, 182, 182, 182, 183, 183, 184, 184,
   184, 184, 185, 185, 185, 186, 186, 186, 186, 186,
   186, 186, 187, 186, 188, 186, 186, 186, 186, 186,
   186, 186, 186, 189, 190, 186, 191, 192, 186, 193,
   194, 186, 195, 196, 186, 186, 186, 186, 186, 186,
   186, 186, 186, 186, 186, 186, 186, 186, 186, 186,
   186, 197, 197, 198, 198, 199, 199, 200, 200, 201,
   202, 202, 203, 203, 203, 203, 203, 203, 203, 204,
   204, 205, 205, 206, 206, 206, 206, 206, 207, 207,
   208, 208, 208, 208, 208, 208, 209, 209, 209, 209,
   209, 210, 210, 210, 210, 210, 210, 211, 211, 211,
   211, 212, 212, 213, 213, 213, 213, 213, 213, 213,
   214, 214, 214, 215, 215, 216, 216, 217, 217, 218,
   218, 220, 219, 219, 222, 221, 221, 224, 223, 223,
   226, 225, 225, 227, 227, 228, 228, 229, 230, 230,
   231, 231, 231, 231, 231, 232, 232, 232, 232, 233,
   233, 234, 234, 235, 235, 235, 235, 235, 236, 236,
   236, 236, 236, 236, 238, 237, 237, 239, 237, 237,
   237, 237, 237, 237, 237, 240, 240, 241, 241, 242,
   242, 242, 242, 242, 243, 244, 244, 245, 245, 245,
   246, 246, 247, 248, 248, 248, 249, 250, 250, 251,
   251, 251, 252, 252, 253, 253, 254, 254, 254, 255,
   255, 255, 255, 256, 257, 257, 257, 257, 258, 258,
   259, 259, 259, 259, 259, 259, 259, 260, 260, 260,
   260, 260, 260, 260, 260, 261, 261, 261, 262, 262,
   262, 263, 263, 264, 264, 265, 265, 266, 266, 266,
   267, 267, 268, 268, 268, 269, 269, 270, 270, 271,
   271, 271, 272, 272, 273, 273, 274, 275, 276, 276,
   276, 276, 277, 277, 277, 277, 277, 277, 278, 278,
   279, 280, 280, 280, 280, 280, 280, 281, 281, 281,
   281, 281, 281, 282, 282, 282, 282, 282, 282, 283,
   283, 283, 283, 283, 284, 285, 286, 286, 287, 287,
   287, 288, 288, 289, 289, 290, 290, 290, 291, 291,
   292, 292, 293, 293, 294, 295, 295, 295, 295, 295,
   295, 295, 296, 296, 297, 297, 297, 297, 297, 297,
   297, 297, 297, 297, 297, 298, 298, 298, 298, 298,
   298, 298, 298, 298, 298, 298, 299, 299, 299, 299,
   300, 301, 302, 303, 303, 304, 304, 305, 306, 306,
   307, 309, 310, 308, 311, 311, 312, 312, 313, 313,
   314, 315, 313, 313, 316, 317, 313, 318, 319, 313,
   320, 321, 322, 323, 313, 324, 325, 313, 326, 313,
   327, 313, 328, 313, 313, 313, 313, 313, 313, 313,
   313, 313, 313, 313, 313, 313, 313, 313, 330, 331,
   329, 333, 334, 332, 335, 336, 337, 338, 335, 339,
   339, 340, 340, 341, 341, 341, 342, 342, 342, 343,
   343, 344, 344, 344, 345, 345, 346, 346, 347, 348,
   348, 349, 349, 349, 350, 350, 350, 350, 350, 350,
   350, 350, 350, 350, 351, 351, 351, 351, 351, 352,
   352, 353, 353, 353, 353, 353, 353, 354, 355, 355,
   356, 357, 357, 358, 358, 358, 359, 360, 360, 361,
   361, 361, 361, 362, 363, 363, 363, 363, 363, 363,
   363, 363, 363, 363, 363, 363, 363, 363, 363, 363,
   363, 363, 363, 363, 363, 363, 363, 363, 363, 363,
   363, 363, 363, 363, 363, 363, 363, 363, 363
};

static const short yyr2[] = { 0,
     0, 1, 0, 2, 2, 1, 0, 0, 0, 1,
     1, 0, 2, 1, 1, 1, 1, 5, 4, 4,
     4, 0, 6, 0, 5, 5, 2, 4, 2, 3,
     3, 1, 1, 2, 2, 1, 2, 0, 5, 1,
     3, 1, 2, 1, 2, 1, 3, 1, 3, 1,
     3, 0, 5, 0, 5, 0, 5, 0, 5, 3,
     3, 6, 7, 4, 3, 3, 1, 1, 1, 1,
     1, 2, 3, 3, 3, 3, 2, 2, 2, 2,
     2, 1, 1, 1, 0, 1, 2, 0, 1, 4,
     0, 5, 3, 3, 2, 3, 3, 2, 1, 6,
     4, 3, 3, 2, 2, 2, 4, 2, 3, 0,
     0, 1, 3, 2, 3, 1, 4, 2, 4, 2,
     4, 2, 1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 3, 3, 2, 4, 4, 3, 3, 4,
     3, 4, 0, 1, 3, 1, 1, 0, 6, 0,
     1, 0, 2, 1, 1, 1, 1, 1, 1, 1,
     1, 3, 1, 3, 0, 1, 1, 0, 8, 1,
     1, 3, 4, 3, 2, 1, 3, 3, 3, 3,
     1, 1, 1, 0, 3, 2, 2, 2, 2, 2,
     2, 4, 2, 4, 2, 3, 3, 4, 4, 5,
     5, 6, 2, 4, 5, 3, 3, 3, 1, 3,
     2, 3, 4, 1, 2, 5, 1, 3, 3, 3,
     3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
     3, 3, 3, 3, 3, 3, 5, 3, 3, 1,
     2, 3, 1, 1, 1, 1, 1, 1, 1, 2,
     2, 3, 1, 1, 3, 1, 1, 1, 1, 3,
     3, 3, 0, 4, 0, 6, 2, 4, 2, 2,
     1, 4, 1, 0, 0, 9, 0, 0, 9, 0,
     0, 9, 0, 0, 9, 4, 4, 2, 2, 1,
     4, 2, 2, 2, 5, 3, 5, 3, 4, 6,
     2, 1, 2, 1, 2, 1, 1, 1, 2, 0,
     2, 2, 3, 3, 3, 3, 3, 2, 2, 1,
     1, 1, 2, 2, 2, 2, 1, 1, 1, 1,
     2, 2, 3, 3, 3, 4, 1, 2, 2, 2,
     1, 1, 1, 2, 2, 2, 1, 1, 2, 2,
     3, 1, 2, 1, 1, 1, 4, 4, 4, 4,
     1, 1, 1, 1, 3, 1, 3, 1, 3, 0,
     4, 0, 7, 4, 0, 7, 4, 0, 7, 4,
     0, 7, 4, 0, 1, 1, 2, 6, 1, 3,
     0, 1, 4, 6, 4, 1, 1, 1, 1, 1,
     3, 0, 2, 1, 2, 3, 4, 1, 1, 3,
     4, 6, 3, 5, 0, 7, 4, 0, 6, 3,
     2, 2, 2, 4, 1, 0, 1, 0, 1, 1,
     2, 2, 2, 2, 3, 2, 1, 2, 3, 3,
     3, 2, 0, 1, 3, 2, 2, 1, 1, 0,
     2, 3, 1, 4, 1, 3, 1, 4, 4, 2,
     2, 3, 3, 1, 0, 1, 4, 3, 1, 2,
     2, 2, 2, 2, 2, 2, 1, 2, 2, 5,
     2, 1, 9, 7, 1, 0, 1, 3, 0, 1,
     3, 1, 1, 1, 1, 5, 4, 5, 4, 3,
     5, 4, 5, 4, 3, 1, 3, 1, 3, 2,
     1, 6, 0, 2, 1, 2, 0, 2, 4, 4,
     2, 4, 3, 3, 2, 2, 3, 1, 1, 1,
     2, 3, 4, 3, 3, 2, 1, 3, 3, 2,
     2, 3, 1, 3, 3, 2, 2, 3, 1, 3,
     3, 4, 3, 1, 2, 2, 1, 2, 4, 4,
     2, 1, 1, 1, 2, 2, 2, 2, 1, 2,
     1, 2, 2, 3, 1, 3, 2, 3, 2, 2,
     3, 1, 3, 4, 3, 2, 2, 1, 3, 2,
     2, 1, 2, 3, 1, 3, 1, 5, 3, 4,
     3, 4, 2, 2, 3, 2, 1, 1, 2, 2,
     2, 0, 0, 0, 1, 1, 2, 3, 1, 2,
     4, 0, 0, 6, 1, 3, 1, 1, 1, 2,
     0, 0, 6, 1, 0, 0, 7, 0, 0, 7,
     0, 0, 0, 0, 14, 0, 0, 9, 0, 5,
     0, 7, 0, 4, 2, 2, 2, 3, 6, 8,
    10, 12, 4, 3, 2, 2, 1, 1, 0, 0,
     6, 0, 0, 5, 0, 0, 0, 0, 9, 1,
     1, 3, 3, 2, 2, 2, 2, 1, 2, 0,
     1, 0, 1, 1, 0, 1, 1, 3, 4, 1,
     3, 0, 1, 1, 1, 2, 2, 2, 1, 1,
     2, 2, 2, 2, 1, 3, 2, 2, 4, 2,
     2, 2, 2, 2, 2, 1, 2, 2, 1, 1,
     0, 0, 1, 0, 4, 2, 1, 1, 3, 0,
     3, 3, 3, 1, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 3, 2, 2,
     2, 2, 3, 2, 2, 4, 4, 3, 2
};

static const short yydefact[] = { 3,
    12, 12, 5, 0, 4, 0, 244, 562, 343, 355,
   515, 0, 10, 11, 0, 0, 0, 430, 0, 744,
     0, 0, 0, 0, 575, 245, 246, 82, 0, 0,
   731, 0, 99, 36, 0, 13, 0, 8, 0, 17,
    16, 15, 14, 85, 0, 563, 143, 254, 543, 0,
   330, 0, 329, 348, 0, 368, 347, 386, 354, 0,
   437, 444, 443, 450, 449, 448, 425, 342, 569, 530,
     0, 253, 554, 529, 0, 564, 356, 513, 0, 0,
   243, 80, 81, 566, 0, 0, 123, 124, 125, 126,
   418, 421, 0, 571, 0, 422, 0, 0, 0, 0,
    50, 0, 124, 125, 126, 24, 0, 0, 0, 0,
   423, 0, 29, 0, 0, 343, 38, 0, 0, 437,
   135, 0, 567, 0, 541, 0, 0, 0, 540, 0,
     0, 0, 0, 254, 0, 517, 0, 253, 513, 0,
    27, 3, 37, 0, 0, 0, 0, 444, 443, 734,
     0, 310, 402, 86, 78, 568, 150, 517, 0, 513,
    79, 0, 0, 0, 0, 0, 364, 320, 528, 321,
   537, 0, 513, 345, 344, 77, 331, 0, 366, 346,
     0, 337, 361, 362, 332, 350, 352, 341, 363, 0,
    72, 387, 431, 432, 433, 434, 447, 131, 130, 132,
   436, 438, 442, 143, 0, 450, 731, 446, 464, 0,
   516, 349, 0, 95, 0, 98, 573, 556, 531, 565,
     0, 570, 0, 779, 775, 774, 772, 754, 759, 760,
     0, 766, 765, 751, 752, 750, 769, 758, 755, 756,
   757, 761, 762, 748, 749, 745, 746, 747, 771, 763,
   764, 753, 770, 0, 767, 680, 348, 681, 740, 515,
   257, 308, 0, 0, 184, 304, 302, 271, 306, 307,
     0, 0, 0, 0, 0, 240, 0, 0, 155, 154,
     0, 156, 157, 0, 0, 158, 0, 144, 0, 214,
     0, 217, 147, 256, 183, 0, 0, 258, 259, 0,
   146, 327, 348, 328, 557, 290, 273, 0, 0, 0,
   437, 138, 420, 0, 415, 572, 0, 159, 160, 0,
     0, 0, 391, 0, 49, 3, 22, 0, 248, 0,
   247, 32, 33, 0, 555, 31, 30, 0, 134, 450,
   151, 133, 141, 0, 539, 0, 538, 242, 251, 0,
   547, 250, 0, 546, 0, 255, 551, 0, 0, 12,
     0, 0, 9, 9, 66, 65, 734, 0, 52, 60,
    56, 54, 61, 58, 370, 105, 110, 669, 0, 84,
    83, 91, 108, 0, 0, 106, 87, 139, 553, 0,
     0, 521, 0, 550, 0, 526, 0, 525, 0, 0,
     0, 0, 513, 93, 76, 96, 0, 75, 517, 513,
   536, 0, 334, 335, 0, 73, 94, 74, 97, 339,
   338, 340, 333, 353, 734, 369, 439, 435, 440, 441,
   445, 451, 482, 0, 477, 0, 485, 0, 486, 489,
     0, 0, 469, 0, 734, 351, 736, 0, 0, 384,
   514, 542, 574, 0, 0, 768, 773, 350, 513, 513,
     0, 513, 778, 0, 0, 0, 191, 0, 0, 193,
     0, 0, 274, 277, 280, 283, 241, 190, 187, 186,
   188, 0, 0, 0, 0, 0, 256, 0, 0, 0,
     0, 142, 189, 0, 0, 215, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 267, 269,
   270, 312, 311, 0, 0, 0, 0, 0, 195, 511,
     0, 203, 309, 301, 0, 731, 293, 294, 0, 0,
   322, 592, 588, 597, 0, 517, 513, 513, 513, 324,
   595, 0, 561, 326, 0, 325, 292, 0, 288, 303,
   305, 558, 0, 289, 137, 136, 508, 428, 506, 417,
     0, 357, 0, 0, 358, 359, 360, 397, 398, 399,
   396, 0, 389, 392, 51, 0, 3, 0, 28, 35,
    34, 44, 0, 46, 40, 730, 726, 0, 327, 348,
    42, 328, 729, 48, 402, 148, 140, 545, 544, 255,
   548, 0, 19, 21, 20, 370, 71, 67, 69, 68,
    70, 64, 0, 0, 0, 0, 384, 111, 310, 0,
   612, 90, 619, 88, 408, 0, 404, 403, 182, 0,
   181, 518, 552, 0, 709, 710, 0, 704, 348, 0,
   703, 705, 732, 715, 0, 524, 523, 0, 0, 535,
     0, 384, 365, 534, 0, 532, 527, 336, 367, 384,
   370, 731, 0, 731, 452, 453, 455, 731, 457, 481,
   475, 476, 473, 474, 244, 562, 513, 0, 702, 734,
   478, 487, 492, 493, 734, 734, 479, 490, 734, 0,
   424, 470, 471, 472, 104, 737, 348, 738, 0, 0,
   383, 385, 777, 776, 740, 740, 740, 0, 0, 0,
   561, 0, 185, 0, 0, 0, 0, 0, 0, 262,
     0, 260, 261, 0, 212, 145, 244, 562, 245, 246,
     0, 0, 409, 426, 0, 239, 238, 694, 693, 0,
   236, 235, 233, 234, 232, 231, 230, 227, 228, 229,
   225, 226, 220, 221, 222, 223, 224, 218, 219, 0,
     0, 0, 0, 0, 0, 197, 209, 0, 0, 196,
   513, 513, 0, 513, 510, 582, 0, 0, 0, 0,
   296, 0, 298, 0, 591, 590, 587, 586, 730, 0,
     0, 606, 0, 0, 603, 323, 604, 593, 513, 702,
   517, 592, 588, 0, 0, 513, 0, 0, 0, 0,
   429, 0, 428, 180, 179, 178, 177, 391, 0, 0,
    25, 0, 26, 45, 0, 39, 0, 592, 588, 0,
   722, 513, 725, 727, 723, 724, 436, 728, 0, 18,
   384, 53, 57, 55, 59, 0, 127, 116, 128, 129,
     0, 109, 112, 0, 0, 0, 0, 620, 614, 89,
    92, 405, 0, 107, 522, 519, 708, 721, 714, 712,
     0, 520, 707, 720, 713, 711, 706, 733, 717, 718,
     0, 374, 533, 380, 384, 461, 0, 460, 731, 731,
   731, 0, 0, 0, 734, 384, 529, 0, 0, 102,
     0, 370, 370, 0, 370, 0, 384, 0, 735, 0,
   381, 742, 741, 743, 272, 192, 194, 286, 287, 0,
     0, 0, 0, 261, 264, 0, 0, 0, 0, 213,
     0, 265, 268, 207, 206, 199, 0, 198, 211, 0,
     0, 579, 577, 0, 580, 517, 204, 0, 0, 299,
     0, 0, 589, 585, 596, 513, 605, 594, 599, 0,
   601, 0, 559, 560, 0, 291, 509, 507, 419, 0,
   390, 388, 244, 0, 23, 41, 47, 591, 587, 592,
   588, 0, 513, 593, 0, 0, 62, 0, 114, 0,
   118, 0, 122, 0, 120, 0, 670, 0, 171, 613,
     0, 615, 616, 0, 406, 592, 588, 0, 256, 0,
   557, 0, 716, 372, 378, 377, 0, 0, 0, 463,
   462, 456, 384, 384, 101, 500, 531, 513, 244, 562,
     0, 488, 494, 495, 734, 734, 384, 384, 491, 0,
   402, 739, 371, 0, 275, 278, 281, 284, 0, 413,
     0, 0, 410, 216, 237, 152, 0, 200, 201, 208,
   210, 578, 576, 583, 581, 0, 205, 0, 295, 297,
   602, 513, 600, 416, 0, 393, 395, 591, 587, 593,
     0, 63, 115, 113, 0, 0, 0, 675, 400, 0,
   621, 0, 244, 562, 622, 635, 638, 641, 612, 0,
     0, 0, 0, 0, 0, 245, 667, 672, 690, 0,
   629, 0, 0, 348, 0, 608, 627, 634, 607, 628,
   668, 0, 617, 407, 0, 560, 719, 0, 0, 375,
   458, 459, 454, 499, 497, 384, 734, 0, 0, 384,
   370, 370, 402, 402, 480, 382, 0, 0, 0, 0,
   411, 0, 0, 152, 266, 0, 202, 584, 300, 598,
     0, 149, 117, 121, 119, 671, 0, 618, 611, 174,
   684, 686, 612, 612, 612, 0, 0, 0, 653, 655,
   656, 657, 0, 0, 0, 685, 0, 691, 0, 630,
   318, 734, 0, 319, 0, 734, 0, 734, 0, 0,
   172, 610, 609, 631, 666, 665, 261, 373, 379, 0,
   402, 100, 384, 384, 505, 384, 384, 496, 498, 0,
     0, 0, 0, 0, 414, 153, 512, 394, 612, 401,
     0, 0, 0, 625, 0, 0, 0, 0, 649, 0,
   658, 0, 664, 673, 0, 314, 370, 316, 317, 370,
     0, 0, 0, 313, 315, 173, 612, 376, 484, 384,
   504, 502, 402, 402, 0, 0, 0, 0, 412, 676,
   163, 0, 623, 636, 613, 639, 614, 688, 642, 0,
   170, 0, 348, 0, 0, 0, 654, 663, 675, 0,
   632, 402, 501, 503, 276, 279, 282, 285, 0, 0,
   612, 0, 626, 0, 689, 612, 687, 646, 734, 651,
   650, 674, 695, 0, 613, 483, 0, 677, 164, 624,
   614, 613, 176, 161, 0, 0, 0, 612, 370, 0,
     0, 0, 696, 697, 659, 633, 0, 0, 0, 175,
   637, 0, 640, 167, 0, 166, 647, 384, 652, 0,
   695, 0, 0, 682, 683, 678, 162, 643, 613, 0,
     0, 0, 660, 698, 613, 0, 648, 168, 699, 0,
     0, 679, 0, 0, 700, 0, 661, 644, 169, 0,
     0, 0, 701, 662, 613, 645, 0, 0, 0
};

static const short yydefgoto[] = { 1397,
   360, 2, 361, 144, 614, 449, 3, 4, 36, 587,
   326, 437, 330, 38, 39, 338, 593, 594, 595, 40,
   102, 41, 623, 625, 624, 626, 622, 42, 379, 152,
   871, 43, 634, 44, 438, 153, 154, 380, 628, 862,
   863, 567, 864, 202, 45, 46, 47, 157, 287, 288,
   341, 849, 342, 1165, 289, 1120, 1336, 1283, 1355, 1292,
  1384, 1010, 1332, 318, 815, 290, 471, 528, 780, 291,
   292, 319, 294, 332, 349, 49, 295, 489, 1066, 726,
  1157, 727, 1158, 728, 1159, 729, 1160, 296, 297, 298,
   299, 381, 300, 1121, 425, 548, 799, 1122, 51, 185,
   598, 302, 186, 468, 187, 166, 178, 55, 662, 167,
  1138, 426, 1220, 179, 1139, 56, 1054, 711, 57, 58,
   582, 583, 584, 1100, 386, 743, 744, 59, 571, 314,
   939, 822, 60, 61, 62, 63, 64, 206, 65, 66,
    67, 208, 675, 676, 677, 678, 210, 441, 442, 443,
   444, 691, 697, 692, 1042, 693, 694, 1043, 1044, 568,
   569, 529, 805, 304, 390, 391, 160, 168, 69, 70,
   169, 170, 137, 72, 113, 305, 306, 307, 74, 308,
    76, 77, 111, 78, 309, 785, 786, 800, 551, 1125,
  1126, 1243, 1101, 1011, 1012, 1013, 632, 1127, 1128, 1183,
  1311, 1245, 1129, 1130, 1267, 1325, 1184, 1312, 1185, 1314,
  1186, 1316, 1376, 1392, 1338, 1369, 1296, 1340, 1250, 382,
   629, 1098, 1131, 1197, 1299, 1176, 1309, 1349, 1375, 1294,
  1328, 1132, 1289, 1199, 750, 1342, 1343, 1344, 1386, 650,
   801, 652, 653, 654, 604, 655, 130, 890, 1257, 708,
   709, 463, 80, 81
};

static const short yypact[] = { 97,
   116,-32768,-32768, 8850,-32768, 40,-32768, 288, 73,-32768,
-32768, 624,-32768,-32768, 296, 300, 313,-32768, 229,-32768,
   835, 612, 1146, 4474,-32768, 164, 228,-32768, 2545, 2545,
-32768, 1682,-32768,-32768, 317,-32768, 183, 182, 2615,-32768,
-32768,-32768,-32768, 389, 243, 383,-32768,-32768, 414, 1529,
-32768, 3016,-32768, 1349, 217,-32768, 431,-32768,-32768, 1163,
-32768,-32768,-32768, 406,-32768,-32768, 420, 1796,-32768,-32768,
   471,-32768,-32768,-32768, 359,-32768,-32768,-32768, 122, 5657,
-32768,-32768,-32768,-32768, 7811, 9178,-32768, 288, 164, 228,
   382, 436, 383,-32768, 122,-32768, 122, 7811, 7811, 423,
-32768, 240,-32768,-32768,-32768,-32768, 395, 288, 164, 228,
-32768, 569,-32768, 644, 644,-32768,-32768, 3469, 4823, 250,
-32768, 7639,-32768, 2622,-32768, 786, 366, 2622,-32768, 685,
  3130, 3130, 1682, 412, 415, 450, 442, 463,-32768, 572,
-32768, 472,-32768, 8910, 65, 3469, 9222, 603, 756, 543,
   609, 177, 136, 548,-32768,-32768, 534, 537, 38,-32768,
-32768, 3202, 3202, 4066, 1043, 298,-32768,-32768, 445,-32768,
-32768, 359,-32768,-32768,-32768,-32768, 1349, 320,-32768, 431,
  1739,-32768,-32768,-32768, 1424, 1349,-32768, 431,-32768, 3469,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768, 383, 800, 1016, 406,-32768,-32768,-32768, 1925,
-32768, 925, 122,-32768, 270, 885,-32768,-32768,-32768,-32768,
  3282,-32768, 81,-32768, 547, 550,-32768,-32768,-32768,-32768,
   598,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768, 562,-32768,-32768, 925, 1796, 506, 586,
-32768,-32768, 8417, 8503,-32768,-32768,-32768,-32768,-32768,-32768,
   590, 601, 614, 618, 625, 7897, 685, 8589,-32768,-32768,
  8589,-32768,-32768, 8589, 6100,-32768, 140,-32768, 8589,-32768,
  7983,-32768, 9443,-32768, 1195, 704, 8069,-32768, 675, 1417,
-32768, 689, 2013, 3730,-32768, 338,-32768, 1008, 1105, 3469,
   250,-32768,-32768, 685, 597,-32768, 604, 655, 9375, 633,
   637, 640, 847, 745,-32768, 472,-32768, 569, 288, 692,
-32768,-32768,-32768, 644,-32768,-32768,-32768, 9332,-32768, 406,
-32768,-32768,-32768, 231,-32768, 218,-32768,-32768,-32768, 2622,
-32768,-32768, 2622,-32768, 665,-32768,-32768, 3282, 59, 695,
   698, 9178,-32768,-32768,-32768,-32768, 543, 1176,-32768,-32768,
-32768,-32768,-32768,-32768, 457,-32768,-32768,-32768, 105,-32768,
-32768,-32768,-32768, 6186, 7897,-32768,-32768,-32768,-32768, 7897,
   683,-32768, 5492, 801, 3787,-32768, 3787,-32768, 3853, 3853,
  4066, 706,-32768,-32768,-32768, 885, 3469,-32768, 705,-32768,
-32768, 4278, 1424, 1349, 3469,-32768,-32768,-32768, 885,-32768,
-32768, 431, 1424,-32768, 543,-32768,-32768,-32768,-32768,-32768,
-32768, 1158,-32768, 612,-32768, 7897,-32768, 367, 881, 9014,
    35, 4006,-32768, 124, 543, 925,-32768, 2527, 727, 431,
-32768,-32768,-32768, 724, 729,-32768,-32768, 925,-32768,-32768,
   399,-32768,-32768, 7897, 586, 6100,-32768, 348, 6100,-32768,
  8589, 7811,-32768,-32768,-32768,-32768, 9349,-32768,-32768,-32768,
-32768, 738, 8675, 8675, 6100, 757, 412, 766, 823, 778,
  7811,-32768,-32768, 6008, 6100,-32768, 7897, 7897, 6272, 7897,
  7897, 7897, 7897, 7897, 7897, 7897, 7897, 7897, 7897, 7897,
  7897, 7897, 7897, 7897, 7897, 7897, 7897, 7897,-32768,-32768,
-32768,-32768,-32768, 7897, 7897, 7897, 7811, 4343, 284, 731,
  6788,-32768,-32768,-32768, 840, 888, 424, 441, 1037, 366,
-32768, 2302, 2302,-32768, 3076, 791, 822, 872,-32768,-32768,
   499, 7276, 1606,-32768, 444,-32768,-32768, 7897,-32768,-32768,
-32768,-32768, 57,-32768,-32768,-32768, 856, 862,-32768,-32768,
   685,-32768, 6616, 6702,-32768,-32768,-32768,-32768,-32768,-32768,
-32768, 138,-32768, 838,-32768, 828, 472, 880,-32768,-32768,
-32768, 870, 308, 895,-32768,-32768, 1567, 9222, 1567, 2459,
  1163, 2362,-32768,-32768, 898,-32768,-32768,-32768,-32768, 857,
-32768, 912,-32768,-32768,-32768, 457,-32768,-32768,-32768,-32768,
-32768,-32768, 913, 915, 917, 929, 431, 76, 930, 823,
-32768,-32768,-32768, 891,-32768, 5744, 9349,-32768, 655, 884,
  9375,-32768,-32768, 896,-32768,-32768, 901, 189, 2792, 903,
-32768, 204, 9074, 943, 948,-32768,-32768, 3787, 3787,-32768,
  4278, 431,-32768,-32768, 907, 801,-32768, 1424,-32768, 431,
   457,-32768, 944,-32768, 964,-32768,-32768, 261,-32768, 9349,
-32768,-32768,-32768,-32768, 977, 622,-32768, 7897, 4673, 543,
   986,-32768,-32768,-32768, 279, 452, 988,-32768, 543, 989,
-32768,-32768,-32768,-32768, 286,-32768, 4121,-32768, 145, 572,
   992, 431,-32768,-32768, 364, 364, 364, 967, 972, 8159,
   872, 973,-32768, 974, 976, 2527, 2527, 2527, 2527,-32768,
   979,-32768,-32768, 980,-32768,-32768, 996, 712, 39, 328,
  7897, 1022,-32768, 991, 984, 9349, 9349,-32768,-32768, 1033,
  9461, 4349, 3589, 2144, 2250, 4153, 3772, 1437, 1437, 1437,
   951, 951, 673, 673, 20, 20, 20,-32768,-32768, 990,
   998, 1001, 993, 1005, 2527, 284,-32768, 6186, 7897,-32768,
-32768,-32768, 7897,-32768,-32768, 1021, 8589, 1006, 1029, 1072,
-32768, 7897,-32768, 7897, 2962,-32768, 2962,-32768, 115, 1017,
  1020,-32768, 1018, 2527, 801,-32768, 801, 3172,-32768, 1854,
  1023, 7459, 7459, 5294, 1028, 7983, 1030, 1105, 1041, 7897,
   685, 1032, 862,-32768, 9349,-32768, 9349, 847, 1042, 8245,
-32768, 1036,-32768,-32768, 9332,-32768, 2560, 2025, 2025, 8970,
-32768,-32768,-32768,-32768,-32768,-32768, 337,-32768, 420,-32768,
   431,-32768,-32768,-32768,-32768, 1176,-32768,-32768, 164, 228,
  7897, 1092,-32768, 448, 464, 512, 105,-32768, 42,-32768,
-32768,-32768, 18,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  7369,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768, 1102,
  6186, 1103,-32768, 1109, 431,-32768, 7811,-32768,-32768,-32768,
-32768, 1154, 7897, 7897, 101, 9253,-32768, 359, 1049,-32768,
  1932, 457, 457, 2678, 1027, 4779, 431, 2527,-32768, 63,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768, 1101,
  1107, 1108, 1116, 857,-32768, 9327, 6186, 5836, 1076,-32768,
  7897,-32768,-32768,-32768,-32768, 379, 1085,-32768,-32768, 1086,
    51, 255, 255, 1097, 255,-32768,-32768, 8589, 1187,-32768,
  1106, 1110,-32768,-32768,-32768,-32768,-32768,-32768, 801, 1111,
-32768, 1099,-32768,-32768, 900,-32768, 9349,-32768,-32768, 1114,
-32768,-32768, 151, 1117,-32768,-32768,-32768, 2226, 2226, 2817,
  2817, 8970,-32768, 2861, 1925, 1176,-32768, 1118,-32768, 76,
-32768, 7897,-32768, 7897,-32768, 7897,-32768, 685,-32768,-32768,
  4927, 1182,-32768, 5922,-32768, 7549, 7549, 5387, 462, 1119,
   552, 6186,-32768,-32768,-32768, 1159, 1121, 1122, 1158,-32768,
-32768,-32768, 9253, 9253, 286,-32768,-32768,-32768, 1169, 716,
  7897,-32768,-32768,-32768, 543, 543, 431, 431,-32768, 5052,
   898,-32768,-32768, 6186,-32768,-32768,-32768,-32768, 6186,-32768,
  7897, 1170,-32768,-32768, 9349, 534, 7897,-32768, 379,-32768,
-32768,-32768,-32768,-32768,-32768, 1125,-32768, 1190,-32768,-32768,
   801,-32768,-32768,-32768, 7897,-32768,-32768, 2226, 2226, 2861,
    44,-32768,-32768,-32768, 1136, 1139, 1142,-32768,-32768, 468,
-32768, 149, 1189, 892,-32768,-32768,-32768,-32768,-32768, 7897,
  1196, 1203, 1204, 7725, 150, 371,-32768,-32768, 1259, 1209,
-32768, 3379, 9118, 3564, 5203,-32768,-32768, 1256,-32768,-32768,
-32768, 6894,-32768,-32768, 1167, 1532,-32768, 6186, 6186,-32768,
-32768,-32768,-32768,-32768,-32768, 431, 101, 7897, 7897, 9253,
   457, 457, 898, 898,-32768,-32768, 1183, 1184, 1185, 1186,
-32768, 9398, 6186, 534,-32768, 1165,-32768,-32768,-32768, 801,
  1177,-32768,-32768,-32768,-32768, 1194, 685,-32768,-32768,-32768,
-32768,-32768,-32768,-32768, 823, 1192, 1200, 5113,-32768,-32768,
-32768,-32768, 1237, 7897, 1241,-32768, 823,-32768, 1211,-32768,
-32768, 559, 662,-32768, 740, 543, 8331, 776, 808, 154,
-32768,-32768,-32768,-32768,-32768,-32768, 560,-32768,-32768, 6186,
   898, 286, 9253, 9253,-32768, 431, 431,-32768,-32768, 7897,
  7897, 7897, 7897, 6186,-32768,-32768,-32768,-32768,-32768,-32768,
   531, 531, 7185,-32768, 1285, 5597, 7811, 7897,-32768, 6999,
-32768, 1246,-32768,-32768, 572,-32768, 457,-32768,-32768, 457,
  8761, 8761, 6358,-32768,-32768,-32768, 823,-32768,-32768, 431,
-32768,-32768, 898, 898, 1201, 1202, 1205, 1208,-32768,-32768,
-32768, 7811,-32768,-32768,-32768,-32768, 42,-32768,-32768, 1247,
-32768, 1213, 178, 3469, 9421, 6999,-32768,-32768,-32768, 50,
-32768, 898,-32768,-32768,-32768,-32768,-32768,-32768, 1218, 1215,
   823, 7092,-32768, 555,-32768,-32768,-32768,-32768, 543,-32768,
-32768, 1194, 1307, 1266,-32768,-32768, 4597,-32768,-32768,-32768,
    42,-32768,-32768,-32768, 7897, 1269, 6444, 823, 457, 6999,
  1239, 143, 1271,-32768,-32768,-32768, 1227, 1230, 823,-32768,
-32768, 1232,-32768,-32768, 1282,-32768,-32768, 431,-32768, 7897,
  1307, 1283, 1307,-32768,-32768,-32768,-32768,-32768,-32768, 1284,
  1244, 208,-32768,-32768,-32768, 6530,-32768,-32768,-32768, 1343,
  1295,-32768, 1252, 6186,-32768, 162,-32768,-32768,-32768, 1351,
  1304, 7092,-32768,-32768,-32768,-32768, 1363, 1365,-32768
};

static const short yypgoto[] = {-32768,
  1366,-32768, -294,-32768, 1003, 2, 1369,-32768,-32768,-32768,
-32768, 1368, 1045,-32768,-32768,-32768,-32768,-32768, 542,-32768,
-32768,-32768,-32768,-32768,-32768,-32768, -809, 1236, 752,-32768,
-32768, 1242,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   390, 223,-32768,-32768,-32768, 4560, -58,-32768, 1261, 904,
 -1001,-32768, -118, 227,-32768, 297,-32768, 161,-32768, -1205,
-32768, -1165, 13, 1398, -199, -239,-32768,-32768, -715, 2893,
   672, 2474, 3277, -48, 508, 186,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768, -305,-32768,
  -139,-32768,-32768, 163, -34, -276, 141, 14, -231, -132,
     5, 47, -169, -4, -72, -672, 285,-32768, -186,-32768,
-32768, -206,-32768,-32768,-32768,-32768,-32768, 669, 278, -43,
-32768, 579,-32768,-32768, -500, -159, 774, -12,-32768,-32768,
-32768, 592, -319, 4, 1374, 1377,-32768,-32768,-32768,-32768,
-32768, -144,-32768, 388, 517,-32768, 578, 439, 519, -439,
-32768,-32768,-32768,-32768,-32768,-32768, 997,-32768, 524, 869,
   620, 914, 1273, 7, 11, -394, 1275, 1799, -56, 28,
-32768, 1690, -110, 582, -57, 3151, 1145,-32768, 3909, 1346,
   210, -399, 1438, 3783, 2123, -126,-32768, 3654,-32768,-32768,
   326, -614, -1038,-32768,-32768, 440, 588, -163,-32768,-32768,
-32768, -1194, -1062, -1209,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768, 167,-32768,-32768,-32768, -54,
-32768,-32768,-32768,-32768, -1197, 92,-32768, 99,-32768, -632,
  -337,-32768,-32768, -333, 807, -331, -194,-32768, -61, 557,
-32768, 181,-32768, -297
};





static const short yytable[] = { 54,
   359, 204, 702, 561, 603, 35, 605, 414, 52, 216,
    68, 564, 432, 192, 665, 165, 869, 50, 601, 54,
   351, 354, 222, 467, 470, 259, 553, 120, 119, 450,
    68, 586, 679, 1285, 54, 124, 128, 118, 388, 94,
   316, 189, 446, 147, 413, 68, 997, 177, 1290, 94,
    53, 496, 146, 423, 333, 651, 909, 337, 533, 159,
   948, 431, 1213, 212, 1164, 335, 336, 533, 700, 1216,
    53, 533, 1301, 1008, 1014, 257, 1310, 700, 857, 8,
   303, 54, 392, 339, 8, 53, 258, 458, 375, 311,
   119, 266, 68, 303, 303, 541, -1, 82, -125, 310,
   517, 518, 1333, 406, 848, 630, 597, 451, 25, 1323,
   122, 367, 421, 424, 177, -2, 1330, 303, 86, 419,
   858, 1315, 365, 1015, 877, 8, 256, 25, 393, 859,
   860, 1356, 53, 458, 109, 110, 192, 350, 353, 54,
   701, 720, 177, 1357, 192, 83, 159, 1009, 52, 1172,
    68, 803, 87, 103, 1324, 1071, 222, 50, 453, 215,
   631, 597, 1164, 612, 189, 1350, 861, 1053, 395, 397,
   366, 878, 189, 189, 879, 109, 110, 970, 1383, 159,
   383, 703, 1333, 183, 184, 640, 1092, 1297, 627, 12,
    53, 721, 566, 647, 828, 606, 491, 384, 877, 189,
   663, 918, 1361, 104, 105, 54, 1179, 1085, 669, 880,
    18, 1179, 492, 883, 440, 633, 68, 136, 1390, 735,
    22, 108, 541, 439, 638, 301, 385, 1194, 866, 704,
  1068, 101, 670, 1321, 92, 122, 377, 142, 320, 322,
   141, 530, 829, 107, 189, 878, 1313, 1362, 879, 919,
  -730, 537, 222, 212, 1180, 1086, 53, 561, 108, 1266,
   884, 451, 301, 885, 718, 900, 1391, 1380, 720, 378,
   333, 109, 110, 190, 191, 565, 591, 1359, 143, 123,
   303, 668, 201, 880, 220, 590, 1346, 491, 351, 354,
   189, 257, 832, 1351, 901, 453, 324, 325, 886, 212,
   155, -320, 258, 607, 220, 616, 25, -150, 109, 110,
    13, 14, 1381, 597, 447, -370, 136, 136, 136, 603,
   597, 605, 781, 220, 770, 734, 772, 773, 777, 180,
  1377, 188, 782, 600, -320, 220, 1382, 215, -320, 84,
   421, 424, 256, -370, 602, 778, 783, -370, 340, 136,
   421, 651, 348, 1167, 407, 408, 1396, 54, 819, 85,
   448, 7, 8, 671, 835, 120, 119, 108, 68, 108,
   451, -320, 553, 424, 779, 118, 415, 416, 192, 123,
   836, 220, 557, 705, 599, 424, 98, -126, 649, 681,
    99, -370, 541, -43, 317, 321, 180, 20, -43, 602,
   189, 189, 108, 100, 690, 658, 659, 140, 53, -43,
   189, 151, 26, 27, 220, 25, 972, 109, 110, 109,
   110, 597, 682, 777, 180, 490, 683, 430, 558, 851,
  1196, 459, 220, 189, 156, 177, 217, 54, 720, 599,
   778, 460, 122, 707, 31, 189, 440, 8, 68, 1203,
   327, 1209, 109, 110, 188, 439, 328, 597, -517, 684,
    17, 303, 422, 188, 303, 207, 868, 303, 791, 779,
  1067, 214, 651, 530, -321, 209, 217, 896, 596, 898,
   303, 13, 14, 902, 895, 793, 303, 313, 53, -517,
   303, 315, 1001, -734, 1187, -734, -734, 109, 110, 478,
  -734, 603, 679, 605, -517, 158, -254, -321, 1003, 108,
   215, -321, 561, 323, 792, 601, -249, 220, 917, 356,
   564, 217, 303, 257, 1177, 1178, -734, -734, -734, 215,
  -734, 794, -734, 648, 258, -517, 409, 458, 1002, 135,
   600, 158, 204, 809, -321, 581, 357, 649, 795, 797,
  1155, 602, -254, -254, 1004, 220, 1005, 25, 602, 109,
   110, 1076, 841, -734, 845, 846, -249, -549, 1241, 1242,
   920, 7, 329, 459, 256, 1281, 496, -7, 597, 950,
   262, 486, 597, 460, 136, 136, 136, 189, 706, 810,
   811, 599, 961, 177, 962, 421, -554, 212, 599, 1334,
   866, 215, 1006, 597, -255, 387, 719, 20, 597, 722,
   702, 376, 725, 138, 846, 108, 1256, 215, 949, 94,
    25, 1282, 26, 27, 1280, 490, 87, 88, 910, 679,
   984, 301, 340, 912, 913, 745, 189, 915, 454, 352,
   355, 455, -554, -554, 389, 1335, 7, 329, 600, 597,
  -255, -255, 1228, 1229, 31, 189, -554, 456, 369, 602,
   370, 998, 371, 25, -252, 109, 110, 774, 192, 457,
   220, 135, 473, 84, 721, 25, 464, 89, 90, 91,
   472, 904, 20, 533, 600, 474, 642, 87, 103, 475,
   422, 188, 108, 85, 189, 602, 476, 26, 27, 599,
   422, 1337, 570, 633, 1029, 1030, 1031, 8, 572, 10,
    11, 573, 138, 138, 138, 12, 742, 180, 407, 1258,
  1269, 707, 707, 707, 707, 1047, 1048, 712, 1048, 31,
    15, 1023, 16, 541, 108, 599, 18, 575, 104, 105,
    25, 576, 109, 110, 577, 138, 22, 585, 220, 589,
   514, 515, 516, 517, 518, 25, 542, 109, 110, 526,
   597, 222, 486, 84, 220, 486, 543, 84, 724, 610,
   707, -124, 1303, 1304, 951, 1149, 544, 1060, 1063, 545,
   546, 486, 25, 85, 109, 110, 597, 85, 7, 108,
   643, 486, 488, 596, 527, 749, 415, 1259, 781, 707,
    -6, 1326, 1095, 613, 1096, 600, 1097, 451, 782, 649,
   660, 372, 664, 373, 834, 374, 602, 710, 795, 797,
   602, 771, 783, 847, 20, 1072, 1073, 788, 1075, 648,
   600, 713, 987, 1264, 215, 600, 714, 87, 103, 26,
    27, 602, 730, 1035, 988, 989, 602, 721, 1146, 87,
   103, 578, 579, 580, 1063, 427, 599, 428, 742, 429,
   599, 732, 1137, 217, 407, 1265, 930, 931, 932, 933,
   733, 31, 87, 88, 136, 180, 649, 188, 631, 351,
   354, 599, 735, 685, 686, 1171, 599, 602, 104, 105,
   106, 789, 303, 790, 1156, 922, 923, 924, 802, 1161,
   104, 105, 7, 8, 712, 351, 354, 352, 355, 13,
    14, 54, 804, 707, -370, 947, 806, 820, 821, 20,
   440, 25, 68, 89, 90, 687, 188, 599, 830, 439,
   183, 184, 25, 831, 26, 27, 12, 833, 20, 712,
   688, -370, -370, 84, 745, 422, -370, 712, 162, 479,
   648, 1182, 480, 26, 27, 481, 837, 18, 163, 384,
   493, -252, 53, 85, 1226, 1227, 31, 22, 532, 850,
   852, 689, 853, 488, 854, 596, 488, 453, 1218, 1219,
   138, 138, 138, 1151, 1152, 31, 855, 600, 874, 377,
    54, 352, 731, 603, 870, 1348, 1088, 1089, 602, 440,
   875, 68, 488, 1235, -729, 876, 1124, 882, 439, 891,
     7, 8, 1119, 649, 893, 1123, 721, 68, 87, 88,
   899, 1244, 1088, 1089, 602, 136, 512, 513, 514, 515,
   516, 517, 518, 1254, 897, 1270, 903, 1028, 599, 7,
   108, 53, 911, 404, 914, 54, 20, 938, 916, -103,
   581, 13, 14, 921, 440, -123, 68, 53, 706, 817,
  1268, 26, 27, 439, 599, -734, 136, -734, -734, 89,
    90, 925, -734, 670, 1279, 20, 926, 927, 928, 954,
   929, 937, -103, 934, 935, 1222, -103, 1202, 940, 1208,
    26, 27, 941, 31, 942, 597, 53, 945, -734, -734,
   405, 215, -734, 1244, -734, 943, 944, 559, 8, 946,
   486, 189, 956, 958, 959, 1300, 960, 220, 177, -103,
  1124, 965, 31, 458, 966, 967, 1119, 1124, 712, 1123,
   971, 68, 973, 1119, 974, -734, 1123, 979, 68, 266,
   560, 985, 723, 20, 1260, 976, 982, 1244, 1000, 108,
   351, 354, 1358, 1038, 479, 480, 25, 8, 109, 110,
  1062, 8, 672, 1022, 1024, 87, 88, 193, 194, 195,
  1025, 53, 712, 1055, 1244, 136, 136, 136, 53, 1056,
  1057, 1064, 673, 712, 220, 1366, 673, 112, 1058, 1069,
  1070, 674, 1078, 1027, 712, 196, 135, 25, 617, 109,
   110, 136, 136, 136, 1074, 25, 1083, 109, 110, 25,
  1079, 109, 110, 1008, 1080, 1082, 89, 90, 197, 1084,
  1140, 1087, 1093, 1136, 1389, 1141, 1142, 817, 1148, 1163,
  1099, 618, 1168, 619, 1169, 620, 1062, 621, 1124, 519,
  1173, 1124, 1293, 1174, 1119, 1124, 1175, 1123, 1181, 68,
  1123, 1119, 68, 258, 1123, 1189, 68, 1339, 303, 1319,
  1190, 1191, 198, 199, 200, 1198, 1200, 658, 659, 1214,
   138, 1217, 1237, 1230, 1231, 1232, 1233, 1293, 520, 521,
   189, 1238, 1246, 522, 523, 524, 525, 1239, 258, 53,
  1247, 1124, 53, 256, 1251, 856, 53, 1119, 1253, 1286,
  1123, 1255, 68, 1298, 1317, 1305, 1306, 1124, 1327, 1307,
   712, 712, 1308, 1119, 486, 1341, 1123, 1318, 68, 1329,
   352, 731, 600, 1345, 712, 712, 1353, 1363, 256, 1360,
   892, 1364, 1293, 602, 1365, 1124, 1367, 1195, 894, 1368,
  1373, 1119, 53, 258, 1123, 1378, 68, 135, 1379, 75,
   221, 1385, 1387, 182, 183, 184, 1388, 95, 53, 1393,
    12, 1394, 1398, 1166, 1399, 1, 615, 95, 114, 75,
     5, 37, 588, 599, 126, 126, 986, 126, 17, 363,
   867, 18, 344, 256, 75, 364, 53, 1124, 1020, 1094,
  1236, 22, 136, 1119, 736, 172, 1123, 75, 68, 1240,
   180, 188, 1284, 490, 1395, 205, 981, 1205, 1288, 873,
  1193, 358, 148, 95, 980, 149, 1143, 534, 1032, 7,
   329, 138, 535, 712, 223, 95, 995, 712, 420, 183,
   184, 75, 394, 1091, 1050, 12, 698, 1049, 53, 823,
   978, 776, 95, 410, 538, 412, 136, 136, 136, 96,
  1212, 1133, 1372, 17, 1007, 20, 18, 114, 957, 889,
   114, 1374, 138, 172, 95, 1322, 22, 596, 25, 126,
    26, 27, 346, 126, 1052, 0, 126, 126, 126, 0,
     0, 0, 0, 479, 480, 0, 0, 0, 0, 75,
  1252, 172, 75, 0, 0, 0, 0, 0, 352, 355,
   712, 712, 536, 712, 712, 0, 0, 172, 172, 172,
   510, 511, 512, 513, 514, 515, 516, 517, 518, 996,
     0, 0, 0, 0, 352, 1135, 1275, 1276, 1277, 1278,
     0, 7, 8, 0, 0, 172, 0, 0, 0, 0,
     0, -255, 749, 1291, 0, 0, 0, 712, 0, 0,
     0, 0, 0, 0, 0, 75, -255, -255, 95, 486,
     0, -255, 0, 1026, 0, 0, 126, 20, 0, 7,
     8, 138, 138, 138, 1036, 0, -255, 0, 1291, 0,
    25, 0, 26, 27, 0, 1051, 161, 0, -255, -255,
  -255, -255, 0, -255, 0, 0, 162, 138, 138, 138,
     0, 0, 0, 95, 461, 20, 163, 0, 0, 0,
     0, 541, -513, 0, 31, -513, 0, 0, 25, 164,
    26, 27, -255, -255, 0, 0, -255, 0, 0, 1077,
     0, 1352, 0, 1291, 838, 712, -255, 0, 0, 0,
     0, 95, 0, 0, 839, 539, 0, 461, 461, 555,
   806, 0, 31, 0, 544, 172, 1371, 840, 546, 0,
     0, 0, -513, 0, 0, -513, 0, -513, 0, 0,
     0, 0, 749, 114, 0, 661, 0, 0, -513, 114,
     0, 0, 666, 95, 7, 108, 0, 479, 480, 0,
     0, 0, 0, 71, 0, 126, -513, -513, 126, 0,
  -513, 1144, 1145, 126, 0, 0, 0, 75, 0, 0,
  -513, 0, 0, 121, 1020, 1153, 1154, 0, 125, 129,
    20, 0, 0, 0, 0, 0, 0, 0, 150, 0,
     0, 715, 716, 25, 717, 26, 27, 0, 0, 417,
   172, 181, 172, 0, 172, 172, 172, 0, 0, 131,
     0, 0, 172, 0, 0, 0, 0, 172, 0, 132,
   172, -734, 0, -734, -734, 0, 0, 31, -734, 352,
  1135, 0, 133, 0, 0, 312, 0, 95, 0, 114,
     0, 0, 639, 0, 172, 75, 0, 75, 138, 0,
   639, 0, 0, 95, -734, -734, 418, 215, -734, 8,
  -734, 10, 211, 0, 0, 0, 0, 12, 0, 0,
     0, 0, 0, 345, 1221, 0, 0, 347, 1225, 0,
   807, 808, 15, 0, 16, 807, 0, 0, 18, 0,
     0, -734, 0, 71, 0, 0, 368, 0, 22, 0,
     0, 0, 138, 138, 138, 0, 0, 25, 0, 109,
   110, 125, 129, 0, 0, 0, 0, 8, 116, 10,
    11, 639, 0, 645, 0, 12, 0, 0, 0, 0,
     0, 0, 0, 95, 0, 461, 0, 0, 0, 0,
    15, 0, 16, 17, 0, 539, 18, 461, 461, 0,
   555, 1271, 1272, 0, 1273, 1274, 22, 75, 0, 445,
     0, 0, 0, 0, 0, 25, 0, 109, 110, 0,
   452, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 639, 0, 639, 639, 433, 0, 7, 8, 116,
    10, 11, 479, 480, 1039, 1040, 12, 95, 1302, 0,
     0, 0, 172, 75, 172, 172, 205, 555, 646, 639,
     0, 15, 0, 16, 17, 639, 0, 18, -465, 905,
   396, 398, 402, 20, 0, 0, 0, 22, 434, 0,
    20, 0, 0, 0, 0, 0, 25, 0, 26, 27,
     0, 0, 435, 25, 436, 26, 27, 0, 0, 0,
     0, 1041, 29, 0, 172, 0, 0, 0, 75, 162,
     0, 0, 30, 172, 172, 0, 172, 0, 0, 163,
    31, 0, 0, 0, 0, 32, 108, 31, 183, 184,
     0, 0, 164, 0, 12, 0, 1370, 7, 8, 0,
  -465, 11, 0, 0, 908, 0, 0, 0, 0, 608,
     0, 0, 609, 0, 0, 18, 0, 611, 0, 0,
     0, 121, 461, 952, 953, 22, 955, 541, 0, 0,
   461, 461, 461, 20, 25, 0, 109, 110, 0, 541,
     0, 95, 95, 95, 95, 0, 25, 0, 26, 27,
   542, 969, 0, 0, 345, 0, 347, 0, 0, 0,
   543, 0, 838, 0, 0, 0, 0, 0, 0, 0,
   544, 452, 839, 552, 546, 0, 0, 0, 0, 0,
    31, 0, 544, 0, 994, 840, 546, 639, 0, 0,
    95, 0, 0, 0, 0, 0, 79, 0, 696, 699,
     0, 445, 0, 0, 97, 0, 0, 0, 0, 0,
   461, 0, 461, 0, 97, 115, 79, 0, 0, 95,
     0, 127, 127, 461, 127, 95, 0, 75, 75, 75,
     0, 79, 0, 975, 0, 0, 0, 0, 0, 0,
     0, 0, 127, 0, 79, 0, 639, 0, 0, 0,
    95, 0, 95, 172, 172, 908, 0, 0, 0, 639,
   213, 639, 0, 656, 0, 657, 0, 396, 398, 402,
     0, 0, 213, 0, 0, 0, 0, 0, 79, 0,
   667, 504, 505, 506, 507, 508, 509, 510, 511, 512,
   513, 514, 515, 516, 517, 518, 908, 639, 7, 8,
     0, 0, 211, 0, 334, 0, 0, 695, 1081, 0,
   127, 213, 0, 0, 0, 0, 127, 95, 0, 0,
   127, 0, 0, 127, 127, 127, 172, 0, 639, 126,
     0, 75, 0, 95, 20, 1090, 79, 0, 127, 79,
   541, 0, 0, 0, 0, 0, 0, 25, 639, 26,
    27, 0, 0, 0, 127, 127, 127, 844, 0, 0,
     0, 0, 0, 838, 0, 0, 0, 461, 461, 0,
   461, 0, 0, 839, 0, 108, 0, 0, 11, 0,
  1147, 31, 127, 544, 0, 0, 840, 546, 505, 506,
   507, 508, 509, 510, 511, 512, 513, 514, 515, 516,
   517, 518, 79, 172, 172, 172, 172, 908, 0, 172,
    75, 0, 888, 127, 0, 0, 541, 608, 609, 0,
   611, 0, 0, 25, 1170, 109, 110, 0, 0, 0,
     0, 908, 908, 908, -342, 8, -342, 10, 211, 542,
     0, 0, 0, 12, 95, 0, 0, 0, 0, 543,
   213, 127, 0, 0, 0, 0, 0, 0, 15, 544,
    16, -342, 545, 546, 18, 75, 0, 0, 0, 639,
  -342, 639, 0, 639, 22, 0, 541, 0, 0, 0,
     0, 0, 0, 25, 0, 109, 110, 0, 213, 0,
     0, 0, 540, 0, 127, 127, 79, 0, 0, 542,
     0, 563, 127, 172, 172, 172, 0, 0, 0, 543,
     0, 0, 0, 0, 0, 0, 0, -342, 0, 544,
   334, 0, 545, 546, 0, 0, 656, 657, 0, 667,
   213, 7, 8, 182, 183, 184, 0, 172, 75, 172,
    12, 0, 127, 0, 0, 127, 0, 0, 0, 0,
   127, 0, 639, 0, 79, 0, 0, 402, 17, 0,
     0, 18, 0, 0, 0, 0, 0, 20, 0, 0,
     0, 22, 0, 541, 0, 0, 0, 0, 0, 0,
    25, 0, 26, 27, 0, 0, 0, 127, 0, 127,
     0, 127, 127, 127, 0, 0, 838, 125, 129, 127,
     8, 0, 10, 11, 127, 0, 839, 127, 12, 0,
     0, 0, 0, 0, 31, 0, 544, 7, 108, 840,
   546, 11, 908, 15, 213, 16, 115, 0, 293, 18,
     0, 127, 79, 8, 79, 10, 0, 0, 0, 22,
   213, 12, 0, 0, 0, 0, 0, 0, 25, 0,
   109, 110, 0, 20, 0, 0, 15, 0, 16, 0,
     0, 0, 18, 0, 0, 293, 25, 0, 26, 27,
  1046, 0, 22, 1046, 639, 445, 908, 908, 908, 0,
     0, 25, 29, 109, 110, 145, 0, 7, 8, 116,
    10, 11, 30, 0, 7, 108, 12, 0, 211, 0,
    31, 0, 0, 0, 0, 32, 396, 398, 402, 172,
     0, 15, 0, 16, 17, 0, 0, 18, 0, 0,
   213, 0, 127, 20, 0, 0, 0, 22, 0, 0,
    20, 0, 0, 0, 127, 127, 25, 79, 26, 27,
     0, 0, 95, 25, 818, 26, 27, 345, 347, 402,
  1039, 108, 29, 452, 445, 563, 0, 0, 0, 29,
     0, 0, 30, 0, 0, 0, 0, 0, 0, 30,
    31, 0, 0, 0, 0, 32, 0, 31, 0, 1045,
     0, 0, 32, 0, 97, 0, 20, 0, 0, 127,
    79, 127, 127, 0, 79, 0, 0, 0, 0, 25,
     0, 26, 27, 0, 0, 0, 0, 1041, 0, 445,
     0, 0, 0, 0, 0, 29, 0, 0, 0, 477,
   213, 0, 0, 0, 0, 30, 0, 0, 0, 0,
     0, 0, 0, 31, 0, 0, 0, 0, 32, 0,
     0, 127, 0, 0, 0, 79, 0, 608, 609, 611,
   127, 127, 0, 127, 0, 0, 656, 657, 396, 398,
   402, 0, 667, 0, 7, 8, 182, 183, 184, 0,
     0, 0, 0, 12, 0, 0, 0, 0, 0, 0,
     0, 79, 1206, 0, 396, 398, 402, 0, 0, 7,
     8, 17, 0, 11, 18, 0, 0, 0, 0, 127,
    20, 0, 0, 0, 22, 0, 541, 127, 127, 127,
     0, 0, 0, 25, 0, 26, 27, 0, 213, 213,
   213, 213, 0, 0, 0, 20, 0, 637, 641, 838,
     0, 541, 0, 7, 8, 0, 641, 451, 25, 839,
    26, 27, 0, 0, 0, 0, 0, 31, 0, 544,
     0, 0, 881, 546, 990, 0, 656, 657, 667, 0,
     0, 0, 0, 0, 991, 0, 0, 213, 0, 20,
     0, 0, 31, 0, 544, 541, 0, 992, 546, 680,
     0, 0, 25, 0, 26, 27, 0, 127, 0, 127,
     0, 0, 0, 0, 0, 0, 213, 0, 838, 0,
   127, 0, 213, 0, 818, 818, 818, 641, 839, 0,
   563, 0, 0, 0, 0, 0, 31, 0, 544, 0,
     0, 840, 546, 0, 0, 0, 0, 213, 0, 213,
   127, 127, 79, 0, 293, 108, 0, 637, 211, 0,
   746, 747, 0, 751, 752, 753, 754, 755, 756, 757,
   758, 759, 760, 761, 762, 763, 764, 765, 766, 767,
   768, 769, 0, 0, 0, 0, 0, 641, 0, 641,
   641, 0, 0, 818, 0, 402, 541, 0, 0, 0,
     0, 0, 0, 25, 0, 109, 110, 0, 7, 8,
   174, 10, 175, 0, 213, 641, 0, 12, 0, 542,
     0, 641, 0, 127, 0, 0, 127, 0, 79, 543,
   213, 0, 15, 0, 16, 17, 825, 827, 18, 544,
     0, 0, 545, 546, 20, 0, 0, 0, 22, 396,
   398, 402, 0, 0, 0, 0, 0, 25, 0, 26,
    27, 0, 0, 176, 127, 127, 0, 127, 0, 8,
   116, 10, 11, 29, 0, 645, 0, 12, 0, 0,
     0, 0, 0, 30, 0, 0, 0, 0, 0, 0,
     0, 31, 15, 0, 16, 17, 32, 0, 18, 637,
   127, 127, 127, 127, 79, 0, 127, 79, 22, 0,
   541, 0, 213, 0, 0, 0, 0, 25, 0, 109,
   110, 0, 7, 108, 0, 0, 11, 0, 818, 818,
   818, 0, 0, 542, 0, 0, 0, 0, 0, 0,
     0, 213, 0, 543, 73, 0, 0, 0, 0, 0,
     0, 906, 0, 544, 0, 0, 545, 546, 20, 0,
   646, 0, 79, 0, 73, 108, 0, 0, 451, 73,
    73, 25, 73, 26, 27, 0, 0, 0, 0, 73,
     0, 0, 0, 641, 547, 547, 547, 131, 0, 0,
    73, 0, 73, 0, 7, 8, 0, 132, 11, 0,
   127, 127, 127, 0, 936, 31, 541, 0, 0, 0,
   133, 0, 0, 25, 0, 109, 110, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 73, 0, 0, 542,
    20, 0, 0, 0, 127, 79, 127, 0, 0, 543,
     0, 637, 641, 25, 0, 26, 27, 0, 0, 544,
     0, 0, 545, 546, 0, 641, 0, 641, 73, 162,
     0, 0, 0, 0, 73, 0, 0, 0, 73, 163,
    48, 73, 73, 73, 7, 108, 0, 31, 451, 0,
     0, 0, 164, 977, 73, 0, 73, 73, 0, 0,
    48, 0, 0, 641, 0, 48, 48, 0, 134, 0,
     0, 0, 73, 73, 73, 48, 0, 0, 0, 0,
    20, 0, 0, 0, 0, 0, 48, 0, 48, 818,
     0, 0, 0, 25, 641, 26, 27, 0, 0, 0,
    73, 0, 0, 0, 0, 0, 0, 0, 0, 29,
     0, 218, 0, 0, 641, 0, 0, 0, 0, 30,
    73, 0, 48, 0, 637, 0, 0, 31, 0, 0,
     0, 73, 32, 0, 0, 0, 1033, 1034, 0, 0,
     0, 7, 8, 818, 818, 818, 0, 0, 331, 0,
   331, 331, 0, 0, 48, 0, 0, 0, 0, 0,
    48, 0, 218, 0, 48, 0, 0, 134, 134, 134,
   637, 637, 0, 0, 1065, 0, 127, 20, 0, 0,
    48, 0, 48, 48, 0, 0, 0, 0, 0, 0,
    25, 0, 26, 27, 547, 547, 1201, 547, 48, 48,
   134, 0, 0, 0, 816, 0, 162, 0, 218, 213,
     0, 0, 0, 0, 0, 0, 163, 0, 0, 562,
    73, 0, 0, 0, 31, 0, 48, 0, 0, 164,
     0, 7, 8, 0, 0, 641, 0, 641, 0, 641,
     0, 0, 0, 0, 0, 0, 48, 637, 0, 547,
     0, 547, 547, 0, 547, 637, 0, 48, 0, 0,
    73, 0, 0, 73, 0, 0, 0, 20, 73, 0,
     0, 0, 73, 0, 1150, 0, 0, 0, 0, 0,
    25, 0, 26, 27, 0, 0, 0, 637, 0, 0,
     0, 0, 637, 0, 1162, 0, 162, 0, 0, 0,
     0, 547, 0, 0, 0, 73, 163, 73, 0, 73,
    73, 73, 0, 0, 31, 0, 0, 73, 641, 164,
     0, 487, 73, 0, 0, 73, 7, 8, 182, 183,
   184, 0, 0, 0, 0, 12, 331, 0, 0, 0,
     0, 0, 0, 1188, 218, 0, 48, 0, 0, 73,
    73, 0, 73, 17, 0, 0, 18, 0, 0, 547,
     0, 0, 20, 0, 331, 0, 22, 0, 541, 0,
   331, 637, 637, 0, 0, 25, 0, 26, 27, 0,
     0, 1223, 1224, 0, 0, 0, 48, 0, 0, 48,
     0, 162, 0, 0, 48, 0, 637, 0, 48, 0,
     0, 163, 0, 0, 0, 0, 0, 0, 0, 31,
     0, 0, 0, 0, 1207, 503, 504, 505, 506, 507,
   508, 509, 510, 511, 512, 513, 514, 515, 516, 517,
   518, 48, 0, 48, 0, 134, 134, 134, 0, 0,
   641, 0, 0, 48, 0, 0, 0, 547, 48, 547,
   562, 48, 0, 637, 0, 0, 0, 0, 0, 0,
   547, 0, 0, 0, 816, 816, 816, 637, 0, 0,
     0, 0, 0, 0, 0, 48, 48, 0, 48, 0,
     0, 1295, 0, 0, 0, 0, 0, 0, 0, 0,
   547, 547, 547, 8, 0, 10, 211, 0, 0, 0,
     0, 12, 487, 0, 0, 487, 0, 73, 73, 73,
    73, 0, 0, 0, 0, 0, 15, 0, 16, 487,
   487, 487, 18, 0, 0, 0, 0, 0, 0, 0,
     0, 487, 22, 816, 541, 0, 0, 0, 865, 0,
     0, 25, 0, 109, 110, 0, 0, 0, 0, 7,
     8, 0, 0, 211, 0, 0, 0, 542, 0, 73,
     0, 0, 0, 73, 0, 0, 0, 543, 73, 73,
     0, 73, 0, 0, 139, 218, 0, 544, 0, 0,
   545, 546, 0, 0, 0, 20, 0, 0, 487, 0,
     0, 0, 173, 0, 0, 0, 0, 0, 25, 73,
    26, 27, 507, 508, 509, 510, 511, 512, 513, 514,
   515, 516, 517, 518, 162, 7, 8, 637, 0, 11,
     0, 0, 0, 0, 163, 0, 0, 0, 0, 0,
     0, 0, 31, 48, 48, 48, 48, 164, 0, 0,
   547, 547, 547, 547, 547, 0, 547, 0, 0, 0,
     0, 20, 0, 0, 0, 0, 0, 0, 0, 0,
   173, 0, 0, 0, 25, 0, 26, 27, 816, 816,
   816, 0, 0, 139, 139, 139, 0, 0, 0, 0,
   399, 0, 0, 0, 0, 48, 0, 0, 173, 48,
   400, 0, 0, 0, 48, 48, 0, 48, 31, 0,
     0, 0, 0, 401, 173, 173, 403, 0, 0, 0,
     0, 0, 0, 0, 0, 550, 554, 556, 171, 0,
     0, 0, 0, 0, 0, 134, 0, 0, 562, 0,
     0, 0, 173, 0, 0, 0, 0, 0, 0, 0,
   547, 547, 547, 219, 0, 0, 0, 0, 73, 73,
    73, 0, 0, 0, 0, 0, 487, 0, 0, 0,
     0, 0, 0, 219, 0, 0, 433, 0, 7, 8,
   116, 10, 11, 0, 0, 0, 0, 12, 0, 0,
     0, 0, 0, 0, 0, 0, 171, 0, 0, 0,
     0, 1021, 15, 0, 16, 17, 0, 0, 18, -466,
     0, 462, 0, 0, 20, 0, 0, 0, 22, 434,
     0, 0, 0, 0, 171, 0, 0, 25, 0, 26,
    27, 73, 0, 435, 73, 436, 73, 0, 7, 8,
   171, 171, 171, 29, 0, 0, 0, 0, 0, 0,
   411, 0, 0, 30, 549, 549, 549, 0, 487, 487,
   487, 31, 173, 0, 0, 0, 32, 0, 171, 0,
     0, 0, 0, 0, 20, 0, 0, 0, 0, 0,
     0, -466, 0, 0, 48, 48, 134, 25, 0, 26,
    27, 0, 0, 0, 108, 0, 183, 184, 0, 0,
     0, 219, 12, 399, 0, 0, 0, 0, 73, 73,
    73, 73, 73, 400, 73, 73, 0, 0, 0, 0,
   865, 31, 0, 18, 0, 0, 401, 1019, 0, 0,
     0, 0, 0, 22, 0, 541, 1021, 1021, 1021, 0,
     0, 0, 25, 0, 109, 110, 0, 173, 0, 173,
     0, 403, 403, 403, 218, 0, 0, 48, 542, 173,
    48, 0, 48, 0, 173, 796, 798, 173, 543, 0,
    73, 0, 0, 0, 0, 0, 0, 0, 544, 0,
     0, 545, 546, 0, 0, 0, 219, 0, 171, 0,
     0, 173, 506, 507, 508, 509, 510, 511, 512, 513,
   514, 515, 516, 517, 518, 0, 0, 0, 73, 73,
    73, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   843, 218, 550, 554, 0, 556, 0, 0, 0, 0,
     0, 0, 0, 0, 48, 48, 134, 134, 134, 0,
    48, 48, 73, 73, 73, 0, 0, 0, 0, 0,
     7, 8, 0, 0, 451, 0, 0, 0, 0, 0,
     0, 0, 1019, 1019, 1019, 0, 0, 0, 0, 0,
     0, 0, 554, 171, 0, 171, 0, 171, 171, 171,
     0, 0, 784, 0, 0, 171, 20, 0, 0, 0,
   171, 0, 0, 171, 549, 549, 48, 549, 0, 25,
     0, 26, 27, 0, 549, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 162, 8, 171, 10, 11,
     0, 0, 0, 0, 12, 163, 0, 1021, 0, 0,
   554, 0, 0, 31, 48, 48, 48, 0, 164, 15,
     0, 16, 0, 0, 0, 18, 0, 0, 0, 842,
     0, 842, 842, 0, 549, 22, 0, 0, 0, 0,
     0, 0, 0, 0, 25, 0, 109, 110, 48, 48,
    48, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 1021, 1021, 1021, 502, 503, 504, 505, 506, 507,
   508, 509, 510, 511, 512, 513, 514, 515, 516, 517,
   518, 842, 0, 775, 0, 0, 0, 0, 0, 0,
   173, 173, 0, 173, 73, 0, 0, 0, 963, 0,
   964, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 968, 0, 219, 0, 796, 798, 0, 0, 0,
     0, 403, 0, 0, 0, 0, 7, 8, 116, 10,
    11, 0, 0, 1019, 0, 12, 0, 0, 0, 549,
     0, 796, 798, 0, 0, 0, 0, 462, 462, 462,
    15, 0, 16, 17, 0, 171, 18, 171, 171, 0,
     0, 0, 20, 0, 0, 0, 22, 0, 0, 0,
     0, 0, 0, 0, 0, 25, 0, 26, 27, 0,
     0, 0, 0, 0, 0, 0, 0, 1019, 1019, 1019,
     0, 29, 0, 0, 0, 117, 0, 0, 0, 0,
     0, 30, 0, 0, 0, 0, 0, 171, 0, 31,
     0, 0, 0, 0, 32, 0, 171, 171, 0, 171,
    48, 93, 0, 0, 0, 0, 0, 549, 0, 549,
     0, 93, 93, 0, 0, 0, 0, 0, 93, 93,
   549, 93, 0, 0, 549, 549, 549, 907, 0, 0,
     8, 116, 10, 11, 0, 0, 1347, 0, 12, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 203,
   842, 842, 993, 15, 0, 16, 17, 0, 0, 18,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 22,
     0, 963, 964, 796, 798, 0, 0, 968, 25, 0,
   109, 110, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 993, 0, 0, 0, 0, 0, 796,
   798, 93, 0, 93, 93, 7, 8, 116, 10, 11,
     0, 0, 645, 93, 12, 93, 93, 93, 0, 0,
    93, 93, 93, 173, 0, 0, 0, 0, 0, 15,
     0, 16, 17, 0, 0, 18, 0, 0, 0, 0,
     0, 20, 0, 0, 0, 22, 0, 0, 0, 0,
     0, 0, 0, 0, 25, 0, 26, 27, 0, 0,
     0, 0, 0, 0, 784, 784, 0, 784, 0, 0,
   399, 963, 964, 968, 0, 0, 171, 171, 907, 0,
   400, 0, 0, 0, 0, 0, 0, 0, 31, 0,
     0, 0, 0, 401, 93, 0, 0, 646, 0, 0,
   842, 842, 993, 993, 993, 0, 842, 0, 0, 433,
    93, 7, 8, 116, 10, 11, 0, 0, 0, 907,
    12, 0, 0, 0, 0, 0, 0, 0, 993, 993,
   993, 0, 0, 0, 0, 15, 0, 16, 17, 0,
     0, 18, -468, 0, 0, 0, 1037, 20, 93, 171,
     0, 22, 434, 0, 0, 0, 8, 174, 10, 175,
    25, 0, 26, 27, 12, 0, 435, 0, 436, 0,
     0, 0, 0, 0, 0, 0, 29, 0, 0, 15,
     0, 16, 17, 0, 0, 18, 30, 0, 0, 93,
     0, 93, 93, 0, 31, 22, 0, 0, 0, 32,
   842, 842, 842, 0, 25, 0, 109, 110, 0, 0,
     0, 0, 0, 219, -468, 0, 0, 93, 0, 0,
     0, 0, 0, 93, 0, 0, 171, 171, 171, 171,
   907, 0, 171, 0, 173, 93, 173, 0, 0, 93,
     0, 0, 93, 0, 0, 0, 0, 93, 0, 0,
     0, 0, 0, 0, 907, 907, 907, 1102, 0, 1103,
  1104, 116, 10, 260, 261, 262, 0, 263, 12, 1105,
     0, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114,
  1115, 13, 14, 15, 264, 16, 17, 265, 0, 18,
     0, 266, 267, 0, 268, 20, 269, 270, 0, 22,
     0, 0, 0, 271, 272, 273, 274, 275, 25, 0,
  1116, 27, 631, 0, 1117, 276, 0, 0, 0, 403,
     0, 277, 0, 93, 278, 0, 171, 171, 171, 0,
     0, 0, 279, 280, 281, 0, 0, 0, 0, 0,
   282, 283, 284, 0, 0, 0, 0, 285, 0, 1118,
    93, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   171, 0, 171, 286, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 403, 403, 403, 0, 0, 0, 0,
     0, 0, 433, 0, 7, 8, 116, 10, 11, 0,
     0, 0, 0, 12, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 173, 0, 15, 0,
    16, 17, 0, 0, 18, -467, 0, 0, 0, 93,
    20, 0, 0, 0, 22, 434, 0, 0, 93, 93,
     0, 93, 93, 25, 0, 26, 27, 0, 0, 435,
     0, 436, 0, 0, 0, 907, 0, 0, 0, 29,
     0, 0, 1248, 0, 0, 0, 0, 0, 0, 30,
     0, 0, 0, 0, 0, 0, 0, 31, 0, 0,
     0, 0, 32, 0, 0, 0, 0, 0, 0, 0,
     0, 93, 0, 0, 0, 0, 0, -467, 0, 0,
   203, 0, 0, 0, 0, 0, 0, 0, 0, 907,
   907, 907, 1249, 497, 498, 499, 500, 501, 502, 503,
   504, 505, 506, 507, 508, 509, 510, 511, 512, 513,
   514, 515, 516, 517, 518, 0, 0, 0, 0, 0,
     0, 0, 171, 1210, 0, 1103, 1104, 116, 10, 260,
   261, 262, 0, 263, 12, 1105, 0, 1106, 1107, 1108,
  1109, 1110, 1111, 1112, 1113, 1114, 1115, 13, 14, 15,
   264, 16, 17, 265, 0, 18, 0, 266, 267, 0,
   268, 20, 269, 270, 0, 22, 0, 0, 0, 271,
   272, 273, 274, 275, 25, 0, 1116, 27, 631, 0,
  1117, 276, 0, 0, 0, 0, 93, 277, 0, 0,
   278, 0, 0, 0, 93, 93, 93, 0, 279, 280,
   281, 0, 0, 0, 0, 0, 282, 283, 284, 0,
     0, 0, 0, 285, 482, 1118, 7, 8, 116, 10,
   260, 261, 262, 645, 263, 12, 0, 0, 1211, 286,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    15, 264, 16, 17, 265, 0, 18, 0, 266, 267,
     0, 268, 20, 269, 270, 0, 22, 0, 541, 0,
   271, 272, 273, 274, 275, 25, 0, 26, 27, -263,
     0, 0, 276, 0, 93, 0, 93, 0, 277, 0,
     0, 812, 0, 0, 0, 0, 0, 93, 0, 279,
   280, 813, 0, 0, 0, 0, 0, 282, 283, 284,
     0, 544, 0, 0, 814, 546, 0, 482, 646, 7,
     8, 116, 10, 260, 261, 262, 645, 263, 12, 0,
   286, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 15, 264, 16, 17, 265, 0, 18,
     0, 266, 267, 0, 268, 20, 269, 270, 0, 22,
     0, 541, 0, 271, 272, 273, 274, 275, 25, 0,
    26, 27, -263, 0, 0, 276, 0, 0, 0, 0,
     0, 277, 0, 0, 1016, 0, 0, 0, 0, 0,
     0, 0, 279, 280, 1017, 0, 0, 0, 0, 0,
   282, 283, 284, 93, 544, 0, 0, 1018, 546, 0,
     0, 646, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 644, 286, 7, 8, 116, 10, 260, 261,
   262, 645, 263, 12, 0, 0, 0, 0, 0, 0,
     0, 93, 93, 0, 93, 0, 0, 0, 15, 264,
    16, 17, 265, 0, 18, 0, 266, 267, 0, 268,
    20, 269, 270, 0, 22, 0, 0, 0, 271, 272,
   273, 274, 275, 25, 0, 26, 27, 0, 0, 0,
   276, 0, 0, 0, 0, 0, 277, 0, 0, 278,
     0, 0, 0, 0, 0, 0, 0, 279, 280, 281,
     0, 0, 0, 0, 0, 282, 283, 284, 0, 0,
     0, 0, 285, 0, 0, 0, 646, 0, 0, 0,
     0, 0, 0, 0, 0, 0, -702, 748, 286, 7,
     8, 116, 10, 260, 261, 262, 0, 263, 12, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 15, 264, 16, 17, 265, 0, 18,
     0, 266, 267, 0, 268, 20, 269, 270, 0, 22,
     0, 0, 0, 271, 272, 273, 274, 275, 25, 0,
    26, 27, 1287, 0, -692, 276, 0, 224, 0, 0,
     8, 277, 10, 11, 278, 0, 0, 0, 12, 0,
     0, 0, 279, 280, 281, 0, 0, 0, 0, 0,
   282, 283, 284, 15, 0, 16, 0, 285, 0, 18,
     0, 225, 226, 0, 0, 0, 0, 0, 0, 22,
     0, 227, 0, 286, 0, 0, 0, 0, 25, 0,
   109, 110, 0, 228, 0, 0, 0, 229, 230, 231,
   232, 233, 234, 235, 236, 237, 238, 239, 240, 241,
   242, 243, 244, 245, 246, 247, 248, 249, 0, 0,
   250, 251, 252, 0, 635, 253, 737, 738, 254, 10,
   465, 261, 262, 0, 263, 12, 0, 0, 0, 0,
     0, 0, 0, 255, 0, 0, 0, 0, 0, 0,
    15, 264, 16, 0, 265, 0, 18, 0, 266, 267,
     0, 268, 20, 269, 270, 0, 22, 0, 0, 0,
   271, 272, 273, 274, 275, 25, 0, 739, 740, 636,
     0, 0, 276, 0, 0, 0, 0, 0, 277, 0,
     0, 278, 0, 0, 0, 0, 0, 0, 0, 279,
   280, 281, 0, 0, 0, 0, 0, 282, 283, 284,
     0, 0, 0, 0, 285, 741, 635, 0, 737, 738,
     0, 10, 465, 261, 262, 0, 263, 12, 0, 872,
   286, 0, 0, 0, 1061, 0, 0, 0, 0, 0,
     0, 0, 15, 264, 16, 0, 265, 0, 18, 0,
   266, 267, 0, 268, 20, 269, 270, 0, 22, 0,
     0, 0, 271, 272, 273, 274, 275, 25, 0, 739,
   740, 636, 0, 0, 276, 0, 0, 0, 0, 0,
   277, 0, 0, 278, 0, 0, 0, 0, 0, 0,
     0, 279, 280, 281, 0, 0, 0, 0, 0, 282,
   283, 284, 635, 0, 737, 738, 285, 10, 465, 261,
   262, 0, 263, 12, 0, 0, 0, 0, 0, 0,
  1061, -427, 286, 0, 0, 0, 0, 0, 15, 264,
    16, 0, 265, 0, 18, 0, 266, 267, 0, 268,
    20, 269, 270, 0, 22, 0, 0, 0, 271, 272,
   273, 274, 275, 25, 0, 739, 740, 636, 0, 0,
   276, 0, 0, 0, 0, 0, 277, 0, 0, 278,
     0, 0, 0, 0, 0, 0, 0, 279, 280, 281,
     0, 0, 0, 0, 0, 282, 283, 284, 635, 0,
   737, 738, 285, 10, 465, 261, 262, 0, 263, 12,
     0, 0, 0, 0, 0, 0, 0, 1134, 286, 0,
     0, 0, 0, 0, 15, 264, 16, 0, 265, 0,
    18, 0, 266, 267, 0, 268, 20, 269, 270, 0,
    22, 0, 0, 0, 271, 272, 273, 274, 275, 25,
     0, 739, 740, 636, 0, 0, 276, 0, 0, 0,
     0, 0, 277, 0, 0, 278, 0, 0, 0, 0,
     0, 0, 0, 279, 280, 281, 0, 0, 0, 0,
     0, 282, 283, 284, 0, 0, 0, 0, 285, 741,
   482, 0, 7, 8, 0, 10, 260, 261, 262, 0,
   263, 12, 0, 0, 286, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 15, 264, 16, 0,
   265, 0, 18, 0, 266, 267, 0, 268, 20, 269,
   270, 0, 22, 0, 0, 0, 271, 272, 273, 274,
   275, 25, 0, 26, 27, -263, 0, 0, 276, 0,
     0, 0, 0, 0, 277, 0, 0, 483, 0, 0,
     0, 0, 0, 0, 0, 279, 280, 484, 0, 0,
     0, 0, 0, 282, 283, 284, 635, 0, 7, 8,
   485, 10, 465, 261, 262, 0, 263, 12, 0, 0,
     0, 0, 0, 0, 0, 0, 286, 0, 0, 0,
     0, 0, 15, 264, 16, 0, 265, 0, 18, 0,
   266, 267, 0, 268, 20, 269, 270, 0, 22, 0,
     0, 0, 271, 272, 273, 274, 275, 25, 0, 26,
    27, 636, 0, 0, 276, 0, 0, 0, 0, 0,
   277, 0, 0, 278, 0, 0, 0, 0, 0, 0,
     0, 279, 280, 281, 0, 0, 0, 0, 0, 282,
   283, 284, 748, 0, 7, 8, 285, 10, 465, 261,
   262, 0, 263, 12, 0, 0, 0, 0, 0, 0,
     0, 0, 286, 0, 0, 0, 0, 0, 15, 264,
    16, 0, 265, 0, 18, 0, 266, 267, 0, 268,
    20, 269, 270, 0, 22, 0, 0, 0, 271, 272,
   273, 274, 275, 25, 0, 26, 27, 0, 0, 0,
   276, -692, 0, 0, 0, 0, 277, 0, 0, 278,
     0, 0, 0, 0, 0, 0, 0, 279, 280, 281,
     0, 0, 0, 0, 0, 282, 283, 284, 482, 0,
     7, 8, 285, 10, 260, 261, 262, 0, 263, 12,
     0, 0, 0, 0, 0, 0, 0, 0, 286, 0,
     0, 0, 0, 0, 15, 264, 16, 0, 265, 0,
    18, 0, 266, 267, 0, 268, 20, 269, 270, 0,
    22, 0, 0, 0, 271, 272, 273, 274, 275, 25,
     0, 26, 27, -263, 0, 0, 276, 0, 0, 0,
     0, 0, 277, 0, 0, 1261, 0, 0, 0, 0,
     0, 0, 0, 279, 280, 1262, 0, 0, 0, 0,
     0, 282, 283, 284, 1354, 0, 7, 8, 1263, 10,
   260, 261, 262, 0, 263, 12, 0, 0, 0, 0,
     0, 0, 0, 0, 286, 0, 0, 0, 0, 0,
    15, 264, 16, 0, 265, 0, 18, 0, 266, 267,
     0, 268, 20, 269, 270, 0, 22, 0, 0, 0,
   271, 272, 273, 274, 275, 25, 0, 26, 27, 0,
     0, -165, 276, 0, 0, 0, 0, 0, 277, 0,
     0, 278, 0, 0, 0, 0, 0, 0, 0, 279,
   280, 281, 0, 0, 0, 0, 0, 282, 283, 284,
   748, 0, 7, 8, 285, 10, 465, 261, 262, 0,
   263, 12, 0, 0, 0, 0, 0, 0, 0, 0,
   286, 0, 0, 0, 0, 0, 15, 264, 16, 0,
   265, 0, 18, 0, 266, 267, 0, 268, 20, 269,
   270, 0, 22, 0, 0, 0, 271, 272, 273, 274,
   275, 25, 0, 26, 27, 0, 0, 0, 276, 0,
     0, 0, 0, 0, 277, 0, 0, 278, 0, 0,
     0, 0, 0, 0, 0, 279, 280, 281, 0, 0,
     0, 0, 0, 282, 283, 284, 824, 0, 7, 8,
   285, 10, 465, 261, 262, 0, 263, 12, 0, 0,
     0, 0, 0, 0, -692, 0, 286, 0, 0, 0,
     0, 0, 15, 264, 16, 0, 265, 0, 18, 0,
   266, 267, 0, 268, 20, 269, 270, 0, 22, 0,
     0, 0, 271, 272, 273, 274, 275, 25, 0, 26,
    27, 0, 0, 0, 276, 0, 0, 0, 0, 0,
   277, 0, 0, 278, 0, 0, 0, 0, 0, 0,
     0, 279, 280, 281, 0, 0, 0, 0, 0, 282,
   283, 284, 826, 0, 7, 8, 285, 10, 465, 261,
   262, 0, 263, 12, 0, 0, 0, 0, 0, 0,
     0, 0, 286, 0, 0, 0, 0, 0, 15, 264,
    16, 0, 265, 0, 18, 0, 266, 267, 0, 268,
    20, 269, 270, 0, 22, 0, 0, 0, 271, 272,
   273, 274, 275, 25, 0, 26, 27, 0, 0, 0,
   276, 0, 0, 0, 0, 0, 277, 0, 0, 278,
     0, 0, 0, 0, 0, 0, 0, 279, 280, 281,
     0, 0, 0, 0, 0, 282, 283, 284, 0, 0,
     7, 8, 285, 10, 465, 261, 262, 0, 263, 12,
     0, 0, 0, 0, 0, 0, 0, 0, 286, 0,
     0, 0, 0, 0, 15, 264, 16, 0, 265, 0,
    18, 0, 266, 267, 0, 268, 20, 269, 270, 0,
    22, 0, 0, 0, 271, 272, 273, 274, 275, 25,
     0, 26, 27, 0, 0, 0, 276, 0, 0, 0,
     0, 0, 277, 0, 0, 278, 0, 0, 0, 0,
     0, 0, 0, 279, 280, 281, 0, 0, 0, 0,
     0, 282, 283, 284, 0, 0, 0, 0, 285, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 286, 787, 1103, 1104, 116, 10,
   260, 261, 262, 0, 263, 12, 1105, 0, 1106, 1107,
  1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 13, 14,
    15, 264, 16, 17, 265, 0, 18, 0, 266, 267,
     0, 268, 20, 269, 270, 0, 22, 0, 0, 0,
   271, 272, 273, 274, 275, 25, 0, 1116, 27, 631,
     0, 1117, 276, 0, 0, 0, 0, 0, 277, 0,
     0, 278, 0, 0, 0, 0, 0, 0, 0, 279,
   280, 281, 0, 0, 0, 0, 0, 282, 283, 284,
     0, 0, 0, 0, 285, 0, 1118, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 1215,
   286, 1103, 1104, 116, 10, 260, 261, 262, 0, 263,
    12, 1105, 0, 1106, 1107, 1108, 1109, 1110, 1111, 1112,
  1113, 1114, 1115, 13, 14, 15, 264, 16, 17, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 0, 0, 271, 272, 273, 274, 275,
    25, 0, 1116, 27, 631, 0, 1117, 276, 0, 0,
     0, 0, 0, 277, 0, 0, 278, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 281, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 0, 0, 0, 285,
     0, 1118, 0, 0, 1103, 1104, 116, 10, 260, 261,
   262, 0, 263, 12, 1105, 286, 1106, 1107, 1108, 1109,
  1110, 1111, 1112, 1113, 1114, 1115, 13, 14, 15, 264,
    16, 17, 265, 0, 18, 0, 266, 267, 0, 268,
    20, 269, 270, 0, 22, 0, 0, 0, 271, 272,
   273, 274, 275, 25, 0, 1116, 27, 1331, 0, 1117,
   276, 0, 0, 0, 0, 0, 277, 0, 0, 278,
     0, 0, 0, 0, 0, 0, 0, 279, 280, 281,
     0, 0, 0, 0, 0, 282, 283, 284, 0, 0,
     0, 0, 285, 0, 1118, 0, 0, 1103, 1104, 116,
    10, 260, 261, 262, 0, 263, 12, 1105, 286, 1106,
  1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 13,
    14, 15, 264, 16, 17, 265, 0, 18, 0, 266,
   267, 0, 268, 20, 269, 270, 0, 22, 0, 0,
     0, 271, 272, 273, 274, 275, 25, 0, 1116, 27,
     0, 0, 1117, 276, 0, 0, 0, 0, 0, 277,
     0, 0, 278, 0, 0, 0, 0, 0, 0, 0,
   279, 280, 281, 0, 0, 0, 0, 0, 282, 283,
   284, 0, 0, 0, 0, 285, 0, 1118, 7, 8,
   116, 10, 260, 261, 262, 645, 263, 12, 0, 0,
     0, 286, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 15, 264, 16, 17, 265, 0, 18, 0,
   266, 267, 0, 268, 20, 269, 270, 0, 22, 0,
   541, 0, 271, 272, 273, 274, 275, 25, 0, 26,
    27, 0, 0, 0, 276, 0, 0, 0, 0, 0,
   277, 0, 0, 812, 0, 0, 0, 0, 0, 0,
     0, 279, 280, 813, 0, 0, 0, 0, 0, 282,
   283, 284, 0, 544, 0, 0, 814, 546, 0, 0,
   646, 7, 8, 116, 10, 260, 261, 262, 645, 263,
    12, 0, 286, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 15, 264, 16, 17, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 541, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 276, 0, 0,
     0, 0, 0, 277, 0, 0, 1016, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 1017, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 544, 0, 0, 1018,
   546, 7, 8, 646, 10, 260, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 541, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 277, 0, 0, 812, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 813, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 544, 0, 0, 814,
   546, 7, 8, 0, 10, 260, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 541, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 277, 0, 0, 1016, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 1017, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 544, 0, 0, 1018,
   546, 7, 8, 0, 10, 260, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 0, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 276, 0, 0,
     0, 0, 0, 277, 0, 0, 278, 0, 0, 0,
     0, 343, 0, 0, 279, 280, 281, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 0, 7, 8, 285,
    10, 465, 261, 262, 0, 263, 12, 0, 0, 0,
     0, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 15, 264, 16, 0, 265, 0, 18, 0, 266,
   267, 0, 268, 20, 269, 270, 0, 22, 0, 0,
     0, 271, 272, 273, 274, 275, 25, 0, 26, 27,
     0, 0, 1192, 276, 0, 0, 0, 0, 0, 277,
     0, 0, 278, 0, 0, 0, 0, 0, 0, 0,
   279, 280, 281, 0, 0, 0, 0, 0, 282, 283,
   284, 0, 0, 7, 8, 285, 10, 260, 261, 262,
     0, 263, 12, 0, 0, 0, 0, 0, 0, 0,
     0, 286, 0, 0, 0, 0, 0, 15, 264, 16,
     0, 265, 0, 18, 0, 266, 267, 0, 268, 20,
   269, 270, 0, 22, 0, 0, 0, 271, 272, 273,
   274, 275, 25, 0, 26, 27, 0, 0, 0, 276,
     0, 0, 0, 0, 0, 277, 0, 0, 278, 0,
     0, 0, 0, 0, 0, 0, 279, 280, 281, 0,
     0, 0, 0, 0, 282, 283, 284, 0, 0, 7,
     8, 285, 10, 465, 261, 262, 0, 263, 12, 0,
     0, 0, 0, 0, 0, 0, 0, 286, 0, 0,
     0, 0, 0, 15, 264, 16, 0, 265, 0, 18,
     0, 266, 267, 0, 268, 20, 269, 270, 0, 22,
     0, 0, 0, 271, 272, 273, 274, 275, 25, 0,
    26, 27, 0, 0, 0, 276, 0, 0, 0, 0,
     0, 277, 0, 0, 278, 0, 0, 0, 0, 0,
     0, 0, 279, 280, 281, 0, 0, 0, 0, 0,
   282, 283, 284, 0, 0, 7, 8, 285, 10, 465,
   261, 262, 0, 263, 12, 0, 0, 0, 0, 0,
     0, 0, 0, 286, 0, 0, 0, 0, 0, 15,
   264, 16, 0, 265, 0, 18, 0, 266, 267, 0,
   268, 20, 269, 270, 0, 22, 0, 0, 0, 271,
   272, 273, 274, 275, 25, 0, 26, 27, 494, 0,
     0, 0, 0, 0, 0, 0, 0, 277, 0, 0,
   278, 0, 0, 0, 0, 0, 0, 0, 279, 280,
   281, 0, 0, 0, 0, 0, 282, 283, 284, 0,
     0, 7, 8, 495, 10, 465, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 0, 0, 0, 0, 286,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 0, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 277, 0, 0, 278, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 281, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 0, 0, 0, 285,
   531, 7, 8, 0, 10, 465, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 0, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 276, 0, 0,
     0, 0, 0, 277, 0, 0, 483, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 484, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 0, 983, 8, 485,
    10, 465, 261, 262, 0, 263, 12, 0, 0, 0,
     0, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 15, 264, 16, 0, 265, 0, 18, 0, 266,
   267, 0, 268, 20, 269, 270, 0, 22, 0, 0,
     0, 271, 272, 273, 274, 275, 25, 0, 26, 27,
     0, 0, 0, 276, 0, 0, 0, 0, 0, 277,
     0, 0, 278, 0, 0, 0, 0, 0, 0, 0,
   279, 280, 281, 0, 0, 0, 0, 0, 282, 283,
   284, 0, 0, 7, 8, 285, 10, 465, 261, 262,
     0, 263, 12, 0, 0, 0, 0, 0, 0, 0,
     0, 286, 0, 0, 0, 0, 0, 15, 264, 16,
     0, 265, 0, 18, 0, 266, 267, 0, 268, 20,
   269, 270, 0, 22, 0, 0, 0, 271, 272, 273,
   274, 275, 25, 0, 26, 27, 0, 0, 0, 276,
     0, 0, 0, 0, 0, 277, 0, 0, 1261, 0,
     0, 0, 0, 0, 0, 0, 279, 280, 1262, 0,
     0, 0, 0, 0, 282, 283, 284, 0, 0, 7,
     8, 1263, 10, 465, 261, 262, 0, 263, 12, 0,
     0, 0, 0, 0, 0, 0, 0, 286, 0, 0,
     0, 0, 0, 15, 264, 16, 0, 265, 0, 18,
     0, 266, 267, 0, 268, 20, 269, 270, 0, 22,
     0, 0, 0, 271, 272, 273, 274, 275, 25, 0,
    26, 27, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 277, 0, 0, 278, 0, 0, 0, 0, 0,
     0, 0, 279, 280, 281, 0, 0, 0, 0, 0,
   282, 283, 284, 0, 0, 7, 8, 466, 10, 465,
   261, 262, 0, 263, 12, 0, 0, 0, 0, 0,
     0, 0, 0, 286, 0, 0, 0, 0, 0, 15,
   264, 16, 0, 265, 0, 18, 0, 266, 267, 0,
   268, 20, 269, 270, 0, 22, 0, 0, 0, 271,
   272, 273, 274, 275, 25, 0, 26, 27, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 277, 0, 0,
   278, 0, 0, 0, 0, 0, 0, 0, 279, 280,
   281, 0, 0, 0, 0, 0, 282, 283, 284, 0,
     0, 7, 8, 469, 10, 465, 261, 262, 0, 263,
    12, 0, 0, 0, 0, 0, 0, 0, 0, 286,
     0, 0, 0, 0, 0, 15, 264, 16, 0, 265,
     0, 18, 0, 266, 267, 0, 268, 20, 269, 270,
     0, 22, 0, 0, 0, 271, 272, 273, 274, 275,
    25, 0, 26, 27, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 277, 0, 0, 278, 0, 0, 0,
     0, 0, 0, 0, 279, 280, 281, 0, 0, 0,
     0, 0, 282, 283, 284, 0, 0, 7, 8, 285,
    10, 465, 261, 262, 0, 263, 12, 0, 0, 0,
     0, 0, 0, 0, 0, 286, 0, 0, 0, 0,
     0, 15, 264, 16, 0, 265, 0, 18, 0, 266,
   267, 0, 268, 20, 269, 270, 0, 22, 0, 0,
     0, 271, 272, 273, 274, 275, 25, 0, 26, 27,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 277,
     0, 0, 483, 0, 0, 0, 0, 0, 0, 0,
   279, 280, 484, 0, 0, 0, 0, 0, 282, 283,
   284, 0, 0, 7, 8, 485, 10, 260, 261, 262,
     0, 263, 12, 0, 0, 0, 0, 0, 0, 0,
     0, 286, 0, 0, 0, 0, 0, 15, 264, 16,
     0, 265, 0, 18, 0, 266, 267, 0, 268, 20,
   269, 270, 0, 22, 0, 0, 0, 271, 272, 273,
   274, 275, 25, 0, 26, 27, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 277, 0, 0, 1261, 0,
     0, 0, 0, 0, 0, 0, 279, 280, 1262, 0,
     0, 0, 0, 0, 282, 283, 284, 0, 0, 0,
     6, 1263, 7, 8, 9, 10, 11, 0, 0, 0,
     0, 12, 0, 0, 0, 0, 0, 286, 0, 0,
     0, 0, 0, 0, 13, 14, 15, 0, 16, 17,
     0, 0, 18, 0, 0, 0, 19, 0, 20, 0,
     0, 21, 22, 23, 0, 24, 0, 0, 0, 0,
     0, 25, 0, 26, 27, 0, 0, 28, 0, 0,
     6, 0, 7, 8, 9, 10, 11, 29, 0, 0,
     0, 12, 0, 0, 0, 0, 0, 30, 0, 0,
     0, 0, 0, 0, 0, 31, 15, 0, 16, 17,
    32, 0, 18, 0, 0, 33, 34, 0, 20, 0,
     0, 0, 22, 0, 0, 362, 0, 0, 0, 0,
     0, 25, 0, 26, 27, 0, 0, 28, 0, 0,
     0, 0, 7, 8, 116, 10, 11, 29, 0, 645,
     0, 12, 0, 0, 0, 0, 0, 30, 0, 0,
     0, 0, 0, 0, 0, 31, 15, 0, 16, 17,
    32, 0, 18, 0, 0, 33, 0, 0, 20, 0,
     0, 0, 22, 0, 541, 0, 685, 8, 174, 10,
   175, 25, 0, 26, 27, 12, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 990, 0, 0,
    15, 0, 16, 17, 0, 0, 18, 991, 0, 0,
     0, 0, 20, 0, 0, 31, 22, 544, 0, 0,
   992, 546, 0, 0, 646, 25, 0, 26, 27, 0,
     0, 0, 0, 688, 0, 0, 7, 8, 116, 10,
    11, 29, 0, 887, 0, 12, 0, 0, 0, 0,
     0, 30, 0, 0, 0, 0, 0, 0, 0, 31,
    15, 0, 16, 17, 32, 0, 18, 0, 0, 0,
     0, 0, 20, 0, 0, 0, 22, 0, 0, 0,
     7, 8, 174, 10, 175, 25, 0, 26, 27, 12,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 29, 0, 0, 15, 0, 16, 17, 0, 0,
    18, 30, 0, 0, 0, 0, 20, 0, 0, 31,
    22, 0, 0, 0, 32, 0, 0, 0, 0, 25,
     0, 26, 27, 0, 0, 1204, 0, 0, 0, 0,
     7, 8, 116, 10, 11, 29, 0, 0, 0, 12,
     0, 0, 0, 0, 0, 30, 0, 0, 0, 0,
     0, 0, 0, 31, 15, 0, 16, 17, 32, 0,
    18, 0, 0, 0, 0, 0, 20, 0, 0, 0,
    22, 0, 0, 0, 7, 8, 174, 10, 175, 25,
     0, 26, 27, 12, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 29, 0, 0, 15, 0,
    16, 17, 0, 0, 18, 30, 0, 0, 0, 0,
    20, 0, 0, 31, 22, 0, 0, 0, 32, 0,
     0, 0, 0, 25, 0, 26, 27, 0, 0, 0,
     0, 0, 17, 0, 0, 0, 0, 0, 0, 29,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 30,
     0, 0, 0, 0, 0, 0, 0, 31, 0, 0,
     0, 0, 32, 497, 498, 499, 500, 501, 502, 503,
   504, 505, 506, 507, 508, 509, 510, 511, 512, 513,
   514, 515, 516, 517, 518, 8, 116, 10, 11, 0,
     0, 0, 0, 12, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 15, 0,
    16, 17, 0, 0, 18, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 592, 0, 0, 0, 0, 0,
     0, 0, 0, 25, 0, 109, 110, 497, 498, 499,
   500, 501, 502, 503, 504, 505, 506, 507, 508, 509,
   510, 511, 512, 513, 514, 515, 516, 517, 518, 497,
   498, 499, 500, 501, 502, 503, 504, 505, 506, 507,
   508, 509, 510, 511, 512, 513, 514, 515, 516, 517,
   518, 574, 0, 0, 1059, 497, 498, 499, 500, 501,
   502, 503, 504, 505, 506, 507, 508, 509, 510, 511,
   512, 513, 514, 515, 516, 517, 518, 1234, 497, 498,
   499, 500, 501, 502, 503, 504, 505, 506, 507, 508,
   509, 510, 511, 512, 513, 514, 515, 516, 517, 518,
  1320, 497, 498, 499, 500, 501, 502, 503, 504, 505,
   506, 507, 508, 509, 510, 511, 512, 513, 514, 515,
   516, 517, 518, 497, 498, 499, 500, 501, 502, 503,
   504, 505, 506, 507, 508, 0, 510, 511, 512, 513,
   514, 515, 516, 517, 518, 501, 502, 503, 504, 505,
   506, 507, 508, 509, 510, 511, 512, 513, 514, 515,
   516, 517, 518
};

static const short yycheck[] = { 4,
   140, 60, 442, 309, 338, 4, 338, 177, 4, 71,
     4, 309, 207, 57, 409, 50, 631, 4, 338, 24,
   131, 132, 79, 263, 264, 80, 303, 24, 24, 216,
    24, 326, 432, 1243, 39, 29, 30, 24, 157, 12,
    97, 54, 212, 39, 177, 39, 856, 52, 1246, 22,
     4, 291, 39, 186, 112, 393, 689, 115, 9, 49,
   776, 206, 1125, 68, 1066, 114, 115, 9, 34, 1132,
    24, 9, 1267, 32, 57, 80, 1282, 34, 3, 4,
    85, 86, 45, 118, 4, 39, 80, 257, 150, 86,
    86, 35, 86, 98, 99, 45, 0, 58, 60, 86,
    81, 82, 1312, 165, 605, 1, 338, 7, 52, 60,
    72, 146, 185, 186, 119, 0, 1311, 122, 46, 181,
    45, 1287, 58, 106, 10, 4, 80, 52, 91, 54,
    55, 1337, 86, 303, 54, 55, 180, 131, 132, 144,
   106, 91, 147, 1338, 188, 106, 136, 106, 144, 106,
   144, 546, 3, 4, 105, 105, 213, 144, 78, 59,
    56, 393, 1164, 105, 177, 1331, 91, 105, 162, 163,
   106, 57, 185, 186, 60, 54, 55, 810, 1376, 169,
    45, 58, 1392, 6, 7, 385, 996, 1250, 375, 12,
   144, 468, 311, 393, 57, 340, 57, 62, 10, 212,
   407, 57, 60, 54, 55, 210, 58, 57, 415, 95,
    33, 58, 73, 10, 210, 379, 210, 32, 57, 105,
    43, 4, 45, 210, 384, 85, 91, 78, 628, 106,
   946, 3, 419, 1296, 12, 72, 60, 56, 98, 99,
    58, 296, 105, 21, 257, 57, 1285, 105, 60, 105,
    62, 300, 309, 258, 106, 105, 210, 563, 4, 106,
    57, 7, 122, 60, 464, 5, 105, 60, 91, 93,
   328, 54, 55, 57, 58, 310, 334, 1340, 97, 52,
   285, 414, 60, 95, 75, 334, 1325, 57, 399, 400,
   303, 296, 587, 1332, 34, 78, 57, 58, 95, 304,
    58, 23, 296, 73, 95, 367, 52, 58, 54, 55,
    25, 26, 105, 545, 45, 30, 131, 132, 133, 653,
   552, 653, 68, 114, 524, 489, 526, 527, 45, 52,
  1369, 54, 78, 338, 56, 126, 1375, 59, 60, 52,
   413, 414, 296, 58, 338, 62, 92, 62, 99, 164,
   423, 689, 130, 1069, 57, 58, 1395, 362, 558, 72,
    91, 3, 4, 425, 57, 362, 362, 4, 362, 4,
     7, 93, 649, 446, 91, 362, 57, 58, 422, 52,
    73, 172, 45, 445, 338, 458, 91, 60, 393, 23,
    91, 106, 45, 57, 98, 99, 119, 39, 62, 393,
   413, 414, 4, 91, 439, 399, 400, 91, 362, 73,
   423, 23, 54, 55, 205, 52, 811, 54, 55, 54,
    55, 653, 56, 45, 147, 285, 60, 205, 91, 616,
    60, 68, 223, 446, 52, 440, 78, 442, 91, 393,
    62, 78, 72, 448, 86, 458, 442, 4, 442, 1122,
    56, 1124, 54, 55, 177, 442, 62, 689, 45, 93,
    30, 466, 185, 186, 469, 60, 630, 472, 45, 91,
    92, 1, 810, 528, 23, 56, 78, 672, 338, 674,
   485, 25, 26, 678, 671, 45, 491, 106, 442, 45,
   495, 56, 45, 23, 1109, 25, 26, 54, 55, 277,
    30, 835, 902, 835, 91, 92, 45, 56, 45, 4,
    59, 60, 818, 91, 91, 835, 105, 308, 705, 105,
   818, 78, 527, 528, 57, 58, 56, 57, 58, 59,
    60, 91, 62, 393, 528, 91, 92, 707, 91, 32,
   545, 92, 601, 45, 93, 323, 105, 552, 542, 543,
  1051, 545, 91, 92, 91, 346, 45, 52, 552, 54,
    55, 956, 597, 93, 599, 600, 105, 105, 1183, 1184,
   710, 3, 4, 68, 528, 45, 816, 106, 810, 779,
     9, 285, 814, 78, 399, 400, 401, 600, 448, 91,
    92, 545, 792, 598, 794, 668, 45, 602, 552, 45,
  1000, 59, 91, 835, 45, 58, 466, 39, 840, 469,
  1050, 3, 472, 32, 649, 4, 58, 59, 778, 592,
    52, 91, 54, 55, 1239, 485, 3, 4, 690, 1029,
   830, 491, 99, 695, 696, 495, 649, 699, 92, 132,
   133, 92, 91, 92, 108, 91, 3, 4, 653, 881,
    91, 92, 1153, 1154, 86, 668, 105, 60, 56, 653,
    58, 861, 60, 52, 105, 54, 55, 527, 712, 108,
   461, 164, 72, 52, 951, 52, 91, 54, 55, 56,
    91, 60, 39, 9, 689, 72, 390, 3, 4, 72,
   413, 414, 4, 72, 707, 689, 72, 54, 55, 653,
   423, 1316, 106, 867, 899, 900, 901, 4, 105, 6,
     7, 57, 131, 132, 133, 12, 494, 440, 57, 58,
  1221, 726, 727, 728, 729, 912, 913, 450, 915, 86,
    27, 891, 29, 45, 4, 689, 33, 105, 54, 55,
    52, 105, 54, 55, 105, 164, 43, 3, 539, 58,
    78, 79, 80, 81, 82, 52, 68, 54, 55, 56,
   992, 818, 466, 52, 555, 469, 78, 52, 472, 105,
   775, 60, 1273, 1274, 779, 60, 88, 937, 938, 91,
    92, 485, 52, 72, 54, 55, 1018, 72, 3, 4,
   108, 495, 285, 653, 91, 499, 57, 58, 68, 804,
   106, 1302, 1002, 106, 1004, 810, 1006, 7, 78, 814,
   105, 56, 108, 58, 592, 60, 810, 91, 812, 813,
   814, 525, 92, 601, 39, 952, 953, 531, 955, 689,
   835, 108, 837, 58, 59, 840, 108, 3, 4, 54,
    55, 835, 105, 905, 838, 839, 840, 1124, 1035, 3,
     4, 5, 6, 7, 1014, 56, 810, 58, 636, 60,
   814, 105, 1022, 78, 57, 58, 726, 727, 728, 729,
   105, 86, 3, 4, 689, 598, 881, 600, 56, 990,
   991, 835, 105, 3, 4, 1085, 840, 881, 54, 55,
    56, 52, 897, 6, 1054, 715, 716, 717, 108, 1059,
    54, 55, 3, 4, 627, 1016, 1017, 400, 401, 25,
    26, 916, 91, 918, 30, 775, 45, 62, 57, 39,
   916, 52, 916, 54, 55, 45, 649, 881, 91, 916,
     6, 7, 52, 106, 54, 55, 12, 58, 39, 662,
    60, 57, 58, 52, 804, 668, 62, 670, 68, 278,
   810, 60, 281, 54, 55, 284, 62, 33, 78, 62,
   289, 105, 916, 72, 1151, 1152, 86, 43, 297, 58,
    58, 91, 58, 466, 58, 835, 469, 78, 1138, 1139,
   399, 400, 401, 1045, 1046, 86, 58, 992, 105, 60,
   995, 484, 485, 1327, 104, 1327, 990, 991, 992, 995,
   105, 995, 495, 1163, 62, 105, 1011, 105, 995, 62,
     3, 4, 1011, 1018, 108, 1011, 1293, 1011, 3, 4,
    57, 1185, 1016, 1017, 1018, 840, 76, 77, 78, 79,
    80, 81, 82, 1197, 91, 1222, 60, 897, 992, 3,
     4, 995, 57, 1, 57, 1050, 39, 57, 60, 23,
   828, 25, 26, 62, 1050, 60, 1050, 1011, 918, 552,
  1220, 54, 55, 1050, 1018, 23, 881, 25, 26, 54,
    55, 105, 30, 1260, 1234, 39, 105, 105, 105, 783,
   105, 60, 56, 105, 105, 1147, 60, 1122, 105, 1124,
    54, 55, 60, 86, 105, 1327, 1050, 105, 56, 57,
    58, 59, 60, 1267, 62, 108, 106, 3, 4, 105,
   814, 1124, 92, 108, 86, 1255, 45, 908, 1123, 93,
  1125, 105, 86, 1293, 105, 108, 1125, 1132, 851, 1125,
   108, 1125, 105, 1132, 105, 93, 1132, 106, 1132, 35,
    36, 106, 471, 39, 1206, 105, 105, 1311, 57, 4,
  1261, 1262, 1339, 105, 483, 484, 52, 4, 54, 55,
   938, 4, 5, 62, 62, 3, 4, 5, 6, 7,
    62, 1125, 895, 73, 1338, 990, 991, 992, 1132, 73,
    73, 106, 29, 906, 975, 1349, 29, 42, 73, 105,
   105, 34, 6, 897, 917, 33, 689, 52, 23, 54,
    55, 1016, 1017, 1018, 108, 52, 108, 54, 55, 52,
   105, 54, 55, 32, 105, 105, 54, 55, 56, 106,
    62, 105, 105, 105, 1384, 105, 105, 720, 60, 60,
  1008, 56, 108, 58, 45, 60, 1014, 62, 1243, 45,
   105, 1246, 1247, 105, 1243, 1250, 105, 1243, 60, 1243,
  1246, 1250, 1246, 1247, 1250, 60, 1250, 1319, 1263, 1294,
    58, 58, 100, 101, 102, 7, 58, 1261, 1262, 14,
   689, 105, 108, 91, 91, 91, 91, 1282, 84, 85,
  1293, 105, 91, 89, 90, 91, 92, 94, 1282, 1243,
    91, 1296, 1246, 1247, 58, 627, 1250, 1296, 58, 15,
  1296, 91, 1296, 58, 58, 105, 105, 1312, 91, 105,
  1033, 1034, 105, 1312, 1018, 9, 1312, 105, 1312, 105,
   813, 814, 1327, 58, 1047, 1048, 58, 57, 1282, 91,
   662, 105, 1337, 1327, 105, 1340, 105, 1115, 670, 58,
    58, 1340, 1296, 1337, 1340, 62, 1340, 840, 105, 4,
    78, 9, 58, 5, 6, 7, 105, 12, 1312, 9,
    12, 58, 0, 1067, 0, 0, 364, 22, 23, 24,
     2, 4, 328, 1327, 29, 30, 835, 32, 30, 144,
   629, 33, 122, 1337, 39, 144, 1340, 1392, 881, 1000,
  1164, 43, 1207, 1392, 491, 50, 1392, 52, 1392, 1177,
  1123, 1124, 1242, 1263, 1392, 60, 828, 1123, 1246, 636,
  1114, 139, 39, 68, 823, 39, 1029, 1, 902, 3,
     4, 840, 6, 1146, 79, 80, 849, 1150, 5, 6,
     7, 86, 160, 995, 916, 12, 440, 914, 1392, 571,
   821, 528, 97, 169, 300, 173, 1261, 1262, 1263, 12,
  1125, 1012, 1361, 30, 867, 39, 33, 112, 787, 653,
   115, 1363, 881, 118, 119, 1299, 43, 1327, 52, 124,
    54, 55, 127, 128, 918, -1, 131, 132, 133, -1,
    -1, -1, -1, 812, 813, -1, -1, -1, -1, 144,
  1194, 146, 147, -1, -1, -1, -1, -1, 991, 992,
  1223, 1224, 86, 1226, 1227, -1, -1, 162, 163, 164,
    74, 75, 76, 77, 78, 79, 80, 81, 82, 851,
    -1, -1, -1, -1, 1017, 1018, 1230, 1231, 1232, 1233,
    -1, 3, 4, -1, -1, 190, -1, -1, -1, -1,
    -1, 10, 1246, 1247, -1, -1, -1, 1270, -1, -1,
    -1, -1, -1, -1, -1, 210, 25, 26, 213, 1263,
    -1, 30, -1, 895, -1, -1, 221, 39, -1, 3,
     4, 990, 991, 992, 906, -1, 45, -1, 1282, -1,
    52, -1, 54, 55, -1, 917, 58, -1, 57, 58,
    59, 60, -1, 62, -1, -1, 68, 1016, 1017, 1018,
    -1, -1, -1, 258, 259, 39, 78, -1, -1, -1,
    -1, 45, 7, -1, 86, 10, -1, -1, 52, 91,
    54, 55, 91, 92, -1, -1, 95, -1, -1, 958,
    -1, 1335, -1, 1337, 68, 1358, 105, -1, -1, -1,
    -1, 296, -1, -1, 78, 300, -1, 302, 303, 304,
    45, -1, 86, -1, 88, 310, 1360, 91, 92, -1,
    -1, -1, 57, -1, -1, 60, -1, 62, -1, -1,
    -1, -1, 1376, 328, -1, 403, -1, -1, 73, 334,
    -1, -1, 410, 338, 3, 4, -1, 1016, 1017, -1,
    -1, -1, -1, 4, -1, 350, 91, 92, 353, -1,
    95, 1033, 1034, 358, -1, -1, -1, 362, -1, -1,
   105, -1, -1, 24, 1207, 1047, 1048, -1, 29, 30,
    39, -1, -1, -1, -1, -1, -1, -1, 39, -1,
    -1, 459, 460, 52, 462, 54, 55, -1, -1, 1,
   395, 52, 397, -1, 399, 400, 401, -1, -1, 68,
    -1, -1, 407, -1, -1, -1, -1, 412, -1, 78,
   415, 23, -1, 25, 26, -1, -1, 86, 30, 1262,
  1263, -1, 91, -1, -1, 86, -1, 432, -1, 434,
    -1, -1, 385, -1, 439, 440, -1, 442, 1207, -1,
   393, -1, -1, 448, 56, 57, 58, 59, 60, 4,
    62, 6, 7, -1, -1, -1, -1, 12, -1, -1,
    -1, -1, -1, 124, 1146, -1, -1, 128, 1150, -1,
   548, 549, 27, -1, 29, 553, -1, -1, 33, -1,
    -1, 93, -1, 144, -1, -1, 147, -1, 43, -1,
    -1, -1, 1261, 1262, 1263, -1, -1, 52, -1, 54,
    55, 162, 163, -1, -1, -1, -1, 4, 5, 6,
     7, 464, -1, 10, -1, 12, -1, -1, -1, -1,
    -1, -1, -1, 528, -1, 530, -1, -1, -1, -1,
    27, -1, 29, 30, -1, 540, 33, 542, 543, -1,
   545, 1223, 1224, -1, 1226, 1227, 43, 552, -1, 210,
    -1, -1, -1, -1, -1, 52, -1, 54, 55, -1,
   221, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, 524, -1, 526, 527, 1, -1, 3, 4, 5,
     6, 7, 1261, 1262, 3, 4, 12, 592, 1270, -1,
    -1, -1, 597, 598, 599, 600, 601, 602, 95, 552,
    -1, 27, -1, 29, 30, 558, -1, 33, 34, 687,
   162, 163, 164, 39, -1, -1, -1, 43, 44, -1,
    39, -1, -1, -1, -1, -1, 52, -1, 54, 55,
    -1, -1, 58, 52, 60, 54, 55, -1, -1, -1,
    -1, 60, 68, -1, 649, -1, -1, -1, 653, 68,
    -1, -1, 78, 658, 659, -1, 661, -1, -1, 78,
    86, -1, -1, -1, -1, 91, 4, 86, 6, 7,
    -1, -1, 91, -1, 12, -1, 1358, 3, 4, -1,
   106, 7, -1, -1, 689, -1, -1, -1, -1, 350,
    -1, -1, 353, -1, -1, 33, -1, 358, -1, -1,
    -1, 362, 707, 781, 782, 43, 784, 45, -1, -1,
   715, 716, 717, 39, 52, -1, 54, 55, -1, 45,
    -1, 726, 727, 728, 729, -1, 52, -1, 54, 55,
    68, 809, -1, -1, 395, -1, 397, -1, -1, -1,
    78, -1, 68, -1, -1, -1, -1, -1, -1, -1,
    88, 412, 78, 91, 92, -1, -1, -1, -1, -1,
    86, -1, 88, -1, 842, 91, 92, 720, -1, -1,
   775, -1, -1, -1, -1, -1, 4, -1, 439, 440,
    -1, 442, -1, -1, 12, -1, -1, -1, -1, -1,
   795, -1, 797, -1, 22, 23, 24, -1, -1, 804,
    -1, 29, 30, 808, 32, 810, -1, 812, 813, 814,
    -1, 39, -1, 818, -1, -1, -1, -1, -1, -1,
    -1, -1, 50, -1, 52, -1, 779, -1, -1, -1,
   835, -1, 837, 838, 839, 840, -1, -1, -1, 792,
    68, 794, -1, 395, -1, 397, -1, 399, 400, 401,
    -1, -1, 80, -1, -1, -1, -1, -1, 86, -1,
   412, 68, 69, 70, 71, 72, 73, 74, 75, 76,
    77, 78, 79, 80, 81, 82, 881, 830, 3, 4,
    -1, -1, 7, -1, 112, -1, -1, 439, 966, -1,
   118, 119, -1, -1, -1, -1, 124, 902, -1, -1,
   128, -1, -1, 131, 132, 133, 911, -1, 861, 914,
    -1, 916, -1, 918, 39, 993, 144, -1, 146, 147,
    45, -1, -1, -1, -1, -1, -1, 52, 881, 54,
    55, -1, -1, -1, 162, 163, 164, 598, -1, -1,
    -1, -1, -1, 68, -1, -1, -1, 952, 953, -1,
   955, -1, -1, 78, -1, 4, -1, -1, 7, -1,
  1038, 86, 190, 88, -1, -1, 91, 92, 69, 70,
    71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 210, 988, 989, 990, 991, 992, -1, 994,
   995, -1, 653, 221, -1, -1, 45, 658, 659, -1,
   661, -1, -1, 52, 1082, 54, 55, -1, -1, -1,
    -1, 1016, 1017, 1018, 3, 4, 5, 6, 7, 68,
    -1, -1, -1, 12, 1029, -1, -1, -1, -1, 78,
   258, 259, -1, -1, -1, -1, -1, -1, 27, 88,
    29, 30, 91, 92, 33, 1050, -1, -1, -1, 1002,
    39, 1004, -1, 1006, 43, -1, 45, -1, -1, -1,
    -1, -1, -1, 52, -1, 54, 55, -1, 296, -1,
    -1, -1, 300, -1, 302, 303, 304, -1, -1, 68,
    -1, 309, 310, 1088, 1089, 1090, -1, -1, -1, 78,
    -1, -1, -1, -1, -1, -1, -1, 86, -1, 88,
   328, -1, 91, 92, -1, -1, 658, 659, -1, 661,
   338, 3, 4, 5, 6, 7, -1, 1122, 1123, 1124,
    12, -1, 350, -1, -1, 353, -1, -1, -1, -1,
   358, -1, 1085, -1, 362, -1, -1, 689, 30, -1,
    -1, 33, -1, -1, -1, -1, -1, 39, -1, -1,
    -1, 43, -1, 45, -1, -1, -1, -1, -1, -1,
    52, -1, 54, 55, -1, -1, -1, 395, -1, 397,
    -1, 399, 400, 401, -1, -1, 68, 838, 839, 407,
     4, -1, 6, 7, 412, -1, 78, 415, 12, -1,
    -1, -1, -1, -1, 86, -1, 88, 3, 4, 91,
    92, 7, 1207, 27, 432, 29, 434, -1, 85, 33,
    -1, 439, 440, 4, 442, 6, -1, -1, -1, 43,
   448, 12, -1, -1, -1, -1, -1, -1, 52, -1,
    54, 55, -1, 39, -1, -1, 27, -1, 29, -1,
    -1, -1, 33, -1, -1, 122, 52, -1, 54, 55,
   911, -1, 43, 914, 1207, 916, 1261, 1262, 1263, -1,
    -1, 52, 68, 54, 55, 1, -1, 3, 4, 5,
     6, 7, 78, -1, 3, 4, 12, -1, 7, -1,
    86, -1, -1, -1, -1, 91, 838, 839, 840, 1294,
    -1, 27, -1, 29, 30, -1, -1, 33, -1, -1,
   528, -1, 530, 39, -1, -1, -1, 43, -1, -1,
    39, -1, -1, -1, 542, 543, 52, 545, 54, 55,
    -1, -1, 1327, 52, 552, 54, 55, 988, 989, 881,
     3, 4, 68, 994, 995, 563, -1, -1, -1, 68,
    -1, -1, 78, -1, -1, -1, -1, -1, -1, 78,
    86, -1, -1, -1, -1, 91, -1, 86, -1, 911,
    -1, -1, 91, -1, 592, -1, 39, -1, -1, 597,
   598, 599, 600, -1, 602, -1, -1, -1, -1, 52,
    -1, 54, 55, -1, -1, -1, -1, 60, -1, 1050,
    -1, -1, -1, -1, -1, 68, -1, -1, -1, 276,
   628, -1, -1, -1, -1, 78, -1, -1, -1, -1,
    -1, -1, -1, 86, -1, -1, -1, -1, 91, -1,
    -1, 649, -1, -1, -1, 653, -1, 1088, 1089, 1090,
   658, 659, -1, 661, -1, -1, 988, 989, 990, 991,
   992, -1, 994, -1, 3, 4, 5, 6, 7, -1,
    -1, -1, -1, 12, -1, -1, -1, -1, -1, -1,
    -1, 689, 1123, -1, 1016, 1017, 1018, -1, -1, 3,
     4, 30, -1, 7, 33, -1, -1, -1, -1, 707,
    39, -1, -1, -1, 43, -1, 45, 715, 716, 717,
    -1, -1, -1, 52, -1, 54, 55, -1, 726, 727,
   728, 729, -1, -1, -1, 39, -1, 384, 385, 68,
    -1, 45, -1, 3, 4, -1, 393, 7, 52, 78,
    54, 55, -1, -1, -1, -1, -1, 86, -1, 88,
    -1, -1, 91, 92, 68, -1, 1088, 1089, 1090, -1,
    -1, -1, -1, -1, 78, -1, -1, 775, -1, 39,
    -1, -1, 86, -1, 88, 45, -1, 91, 92, 436,
    -1, -1, 52, -1, 54, 55, -1, 795, -1, 797,
    -1, -1, -1, -1, -1, -1, 804, -1, 68, -1,
   808, -1, 810, -1, 812, 813, 814, 464, 78, -1,
   818, -1, -1, -1, -1, -1, 86, -1, 88, -1,
    -1, 91, 92, -1, -1, -1, -1, 835, -1, 837,
   838, 839, 840, -1, 491, 4, -1, 494, 7, -1,
   497, 498, -1, 500, 501, 502, 503, 504, 505, 506,
   507, 508, 509, 510, 511, 512, 513, 514, 515, 516,
   517, 518, -1, -1, -1, -1, -1, 524, -1, 526,
   527, -1, -1, 881, -1, 1207, 45, -1, -1, -1,
    -1, -1, -1, 52, -1, 54, 55, -1, 3, 4,
     5, 6, 7, -1, 902, 552, -1, 12, -1, 68,
    -1, 558, -1, 911, -1, -1, 914, -1, 916, 78,
   918, -1, 27, -1, 29, 30, 573, 574, 33, 88,
    -1, -1, 91, 92, 39, -1, -1, -1, 43, 1261,
  1262, 1263, -1, -1, -1, -1, -1, 52, -1, 54,
    55, -1, -1, 58, 952, 953, -1, 955, -1, 4,
     5, 6, 7, 68, -1, 10, -1, 12, -1, -1,
    -1, -1, -1, 78, -1, -1, -1, -1, -1, -1,
    -1, 86, 27, -1, 29, 30, 91, -1, 33, 636,
   988, 989, 990, 991, 992, -1, 994, 995, 43, -1,
    45, -1, 1000, -1, -1, -1, -1, 52, -1, 54,
    55, -1, 3, 4, -1, -1, 7, -1, 1016, 1017,
  1018, -1, -1, 68, -1, -1, -1, -1, -1, -1,
    -1, 1029, -1, 78, 4, -1, -1, -1, -1, -1,
    -1, 688, -1, 88, -1, -1, 91, 92, 39, -1,
    95, -1, 1050, -1, 24, 4, -1, -1, 7, 29,
    30, 52, 32, 54, 55, -1, -1, -1, -1, 39,
    -1, -1, -1, 720, 302, 303, 304, 68, -1, -1,
    50, -1, 52, -1, 3, 4, -1, 78, 7, -1,
  1088, 1089, 1090, -1, 741, 86, 45, -1, -1, -1,
    91, -1, -1, 52, -1, 54, 55, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, 86, -1, -1, 68,
    39, -1, -1, -1, 1122, 1123, 1124, -1, -1, 78,
    -1, 778, 779, 52, -1, 54, 55, -1, -1, 88,
    -1, -1, 91, 92, -1, 792, -1, 794, 118, 68,
    -1, -1, -1, -1, 124, -1, -1, -1, 128, 78,
     4, 131, 132, 133, 3, 4, -1, 86, 7, -1,
    -1, -1, 91, 820, 144, -1, 146, 147, -1, -1,
    24, -1, -1, 830, -1, 29, 30, -1, 32, -1,
    -1, -1, 162, 163, 164, 39, -1, -1, -1, -1,
    39, -1, -1, -1, -1, -1, 50, -1, 52, 1207,
    -1, -1, -1, 52, 861, 54, 55, -1, -1, -1,
   190, -1, -1, -1, -1, -1, -1, -1, -1, 68,
    -1, 75, -1, -1, 881, -1, -1, -1, -1, 78,
   210, -1, 86, -1, 891, -1, -1, 86, -1, -1,
    -1, 221, 91, -1, -1, -1, 903, 904, -1, -1,
    -1, 3, 4, 1261, 1262, 1263, -1, -1, 112, -1,
   114, 115, -1, -1, 118, -1, -1, -1, -1, -1,
   124, -1, 126, -1, 128, -1, -1, 131, 132, 133,
   937, 938, -1, -1, 941, -1, 1294, 39, -1, -1,
   144, -1, 146, 147, -1, -1, -1, -1, -1, -1,
    52, -1, 54, 55, 542, 543, 58, 545, 162, 163,
   164, -1, -1, -1, 552, -1, 68, -1, 172, 1327,
    -1, -1, -1, -1, -1, -1, 78, -1, -1, 309,
   310, -1, -1, -1, 86, -1, 190, -1, -1, 91,
    -1, 3, 4, -1, -1, 1002, -1, 1004, -1, 1006,
    -1, -1, -1, -1, -1, -1, 210, 1014, -1, 597,
    -1, 599, 600, -1, 602, 1022, -1, 221, -1, -1,
   350, -1, -1, 353, -1, -1, -1, 39, 358, -1,
    -1, -1, 362, -1, 1041, -1, -1, -1, -1, -1,
    52, -1, 54, 55, -1, -1, -1, 1054, -1, -1,
    -1, -1, 1059, -1, 1061, -1, 68, -1, -1, -1,
    -1, 649, -1, -1, -1, 395, 78, 397, -1, 399,
   400, 401, -1, -1, 86, -1, -1, 407, 1085, 91,
    -1, 285, 412, -1, -1, 415, 3, 4, 5, 6,
     7, -1, -1, -1, -1, 12, 300, -1, -1, -1,
    -1, -1, -1, 1110, 308, -1, 310, -1, -1, 439,
   440, -1, 442, 30, -1, -1, 33, -1, -1, 707,
    -1, -1, 39, -1, 328, -1, 43, -1, 45, -1,
   334, 1138, 1139, -1, -1, 52, -1, 54, 55, -1,
    -1, 1148, 1149, -1, -1, -1, 350, -1, -1, 353,
    -1, 68, -1, -1, 358, -1, 1163, -1, 362, -1,
    -1, 78, -1, -1, -1, -1, -1, -1, -1, 86,
    -1, -1, -1, -1, 91, 67, 68, 69, 70, 71,
    72, 73, 74, 75, 76, 77, 78, 79, 80, 81,
    82, 395, -1, 397, -1, 399, 400, 401, -1, -1,
  1207, -1, -1, 407, -1, -1, -1, 795, 412, 797,
   540, 415, -1, 1220, -1, -1, -1, -1, -1, -1,
   808, -1, -1, -1, 812, 813, 814, 1234, -1, -1,
    -1, -1, -1, -1, -1, 439, 440, -1, 442, -1,
    -1, 1248, -1, -1, -1, -1, -1, -1, -1, -1,
   838, 839, 840, 4, -1, 6, 7, -1, -1, -1,
    -1, 12, 466, -1, -1, 469, -1, 597, 598, 599,
   600, -1, -1, -1, -1, -1, 27, -1, 29, 483,
   484, 485, 33, -1, -1, -1, -1, -1, -1, -1,
    -1, 495, 43, 881, 45, -1, -1, -1, 628, -1,
    -1, 52, -1, 54, 55, -1, -1, -1, -1, 3,
     4, -1, -1, 7, -1, -1, -1, 68, -1, 649,
    -1, -1, -1, 653, -1, -1, -1, 78, 658, 659,
    -1, 661, -1, -1, 32, 539, -1, 88, -1, -1,
    91, 92, -1, -1, -1, 39, -1, -1, 552, -1,
    -1, -1, 50, -1, -1, -1, -1, -1, 52, 689,
    54, 55, 71, 72, 73, 74, 75, 76, 77, 78,
    79, 80, 81, 82, 68, 3, 4, 1384, -1, 7,
    -1, -1, -1, -1, 78, -1, -1, -1, -1, -1,
    -1, -1, 86, 597, 598, 599, 600, 91, -1, -1,
   988, 989, 990, 991, 992, -1, 994, -1, -1, -1,
    -1, 39, -1, -1, -1, -1, -1, -1, -1, -1,
   118, -1, -1, -1, 52, -1, 54, 55, 1016, 1017,
  1018, -1, -1, 131, 132, 133, -1, -1, -1, -1,
    68, -1, -1, -1, -1, 649, -1, -1, 146, 653,
    78, -1, -1, -1, 658, 659, -1, 661, 86, -1,
    -1, -1, -1, 91, 162, 163, 164, -1, -1, -1,
    -1, -1, -1, -1, -1, 302, 303, 304, 50, -1,
    -1, -1, -1, -1, -1, 689, -1, -1, 818, -1,
    -1, -1, 190, -1, -1, -1, -1, -1, -1, -1,
  1088, 1089, 1090, 75, -1, -1, -1, -1, 838, 839,
   840, -1, -1, -1, -1, -1, 720, -1, -1, -1,
    -1, -1, -1, 95, -1, -1, 1, -1, 3, 4,
     5, 6, 7, -1, -1, -1, -1, 12, -1, -1,
    -1, -1, -1, -1, -1, -1, 118, -1, -1, -1,
    -1, 881, 27, -1, 29, 30, -1, -1, 33, 34,
    -1, 259, -1, -1, 39, -1, -1, -1, 43, 44,
    -1, -1, -1, -1, 146, -1, -1, 52, -1, 54,
    55, 911, -1, 58, 914, 60, 916, -1, 3, 4,
   162, 163, 164, 68, -1, -1, -1, -1, -1, -1,
   172, -1, -1, 78, 302, 303, 304, -1, 812, 813,
   814, 86, 310, -1, -1, -1, 91, -1, 190, -1,
    -1, -1, -1, -1, 39, -1, -1, -1, -1, -1,
    -1, 106, -1, -1, 838, 839, 840, 52, -1, 54,
    55, -1, -1, -1, 4, -1, 6, 7, -1, -1,
    -1, 223, 12, 68, -1, -1, -1, -1, 988, 989,
   990, 991, 992, 78, 994, 995, -1, -1, -1, -1,
  1000, 86, -1, 33, -1, -1, 91, 881, -1, -1,
    -1, -1, -1, 43, -1, 45, 1016, 1017, 1018, -1,
    -1, -1, 52, -1, 54, 55, -1, 395, -1, 397,
    -1, 399, 400, 401, 908, -1, -1, 911, 68, 407,
   914, -1, 916, -1, 412, 542, 543, 415, 78, -1,
  1050, -1, -1, -1, -1, -1, -1, -1, 88, -1,
    -1, 91, 92, -1, -1, -1, 308, -1, 310, -1,
    -1, 439, 70, 71, 72, 73, 74, 75, 76, 77,
    78, 79, 80, 81, 82, -1, -1, -1, 1088, 1089,
  1090, -1, -1, -1, -1, -1, -1, -1, -1, -1,
   597, 975, 599, 600, -1, 602, -1, -1, -1, -1,
    -1, -1, -1, -1, 988, 989, 990, 991, 992, -1,
   994, 995, 1122, 1123, 1124, -1, -1, -1, -1, -1,
     3, 4, -1, -1, 7, -1, -1, -1, -1, -1,
    -1, -1, 1016, 1017, 1018, -1, -1, -1, -1, -1,
    -1, -1, 649, 395, -1, 397, -1, 399, 400, 401,
    -1, -1, 530, -1, -1, 407, 39, -1, -1, -1,
   412, -1, -1, 415, 542, 543, 1050, 545, -1, 52,
    -1, 54, 55, -1, 552, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 68, 4, 439, 6, 7,
    -1, -1, -1, -1, 12, 78, -1, 1207, -1, -1,
   707, -1, -1, 86, 1088, 1089, 1090, -1, 91, 27,
    -1, 29, -1, -1, -1, 33, -1, -1, -1, 597,
    -1, 599, 600, -1, 602, 43, -1, -1, -1, -1,
    -1, -1, -1, -1, 52, -1, 54, 55, 1122, 1123,
  1124, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, 1261, 1262, 1263, 66, 67, 68, 69, 70, 71,
    72, 73, 74, 75, 76, 77, 78, 79, 80, 81,
    82, 649, -1, 91, -1, -1, -1, -1, -1, -1,
   658, 659, -1, 661, 1294, -1, -1, -1, 795, -1,
   797, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, 808, -1, 555, -1, 812, 813, -1, -1, -1,
    -1, 689, -1, -1, -1, -1, 3, 4, 5, 6,
     7, -1, -1, 1207, -1, 12, -1, -1, -1, 707,
    -1, 838, 839, -1, -1, -1, -1, 715, 716, 717,
    27, -1, 29, 30, -1, 597, 33, 599, 600, -1,
    -1, -1, 39, -1, -1, -1, 43, -1, -1, -1,
    -1, -1, -1, -1, -1, 52, -1, 54, 55, -1,
    -1, -1, -1, -1, -1, -1, -1, 1261, 1262, 1263,
    -1, 68, -1, -1, -1, 72, -1, -1, -1, -1,
    -1, 78, -1, -1, -1, -1, -1, 649, -1, 86,
    -1, -1, -1, -1, 91, -1, 658, 659, -1, 661,
  1294, 12, -1, -1, -1, -1, -1, 795, -1, 797,
    -1, 22, 23, -1, -1, -1, -1, -1, 29, 30,
   808, 32, -1, -1, 812, 813, 814, 689, -1, -1,
     4, 5, 6, 7, -1, -1, 10, -1, 12, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 60,
   838, 839, 840, 27, -1, 29, 30, -1, -1, 33,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 43,
    -1, 988, 989, 990, 991, -1, -1, 994, 52, -1,
    54, 55, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 881, -1, -1, -1, -1, -1, 1016,
  1017, 112, -1, 114, 115, 3, 4, 5, 6, 7,
    -1, -1, 10, 124, 12, 126, 127, 128, -1, -1,
   131, 132, 133, 911, -1, -1, -1, -1, -1, 27,
    -1, 29, 30, -1, -1, 33, -1, -1, -1, -1,
    -1, 39, -1, -1, -1, 43, -1, -1, -1, -1,
    -1, -1, -1, -1, 52, -1, 54, 55, -1, -1,
    -1, -1, -1, -1, 952, 953, -1, 955, -1, -1,
    68, 1088, 1089, 1090, -1, -1, 838, 839, 840, -1,
    78, -1, -1, -1, -1, -1, -1, -1, 86, -1,
    -1, -1, -1, 91, 205, -1, -1, 95, -1, -1,
   988, 989, 990, 991, 992, -1, 994, -1, -1, 1,
   221, 3, 4, 5, 6, 7, -1, -1, -1, 881,
    12, -1, -1, -1, -1, -1, -1, -1, 1016, 1017,
  1018, -1, -1, -1, -1, 27, -1, 29, 30, -1,
    -1, 33, 34, -1, -1, -1, 908, 39, 259, 911,
    -1, 43, 44, -1, -1, -1, 4, 5, 6, 7,
    52, -1, 54, 55, 12, -1, 58, -1, 60, -1,
    -1, -1, -1, -1, -1, -1, 68, -1, -1, 27,
    -1, 29, 30, -1, -1, 33, 78, -1, -1, 300,
    -1, 302, 303, -1, 86, 43, -1, -1, -1, 91,
  1088, 1089, 1090, -1, 52, -1, 54, 55, -1, -1,
    -1, -1, -1, 975, 106, -1, -1, 328, -1, -1,
    -1, -1, -1, 334, -1, -1, 988, 989, 990, 991,
   992, -1, 994, -1, 1122, 346, 1124, -1, -1, 350,
    -1, -1, 353, -1, -1, -1, -1, 358, -1, -1,
    -1, -1, -1, -1, 1016, 1017, 1018, 1, -1, 3,
     4, 5, 6, 7, 8, 9, -1, 11, 12, 13,
    -1, 15, 16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27, 28, 29, 30, 31, -1, 33,
    -1, 35, 36, -1, 38, 39, 40, 41, -1, 43,
    -1, -1, -1, 47, 48, 49, 50, 51, 52, -1,
    54, 55, 56, -1, 58, 59, -1, -1, -1, 1207,
    -1, 65, -1, 434, 68, -1, 1088, 1089, 1090, -1,
    -1, -1, 76, 77, 78, -1, -1, -1, -1, -1,
    84, 85, 86, -1, -1, -1, -1, 91, -1, 93,
   461, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  1122, -1, 1124, 107, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 1261, 1262, 1263, -1, -1, -1, -1,
    -1, -1, 1, -1, 3, 4, 5, 6, 7, -1,
    -1, -1, -1, 12, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, 1294, -1, 27, -1,
    29, 30, -1, -1, 33, 34, -1, -1, -1, 530,
    39, -1, -1, -1, 43, 44, -1, -1, 539, 540,
    -1, 542, 543, 52, -1, 54, 55, -1, -1, 58,
    -1, 60, -1, -1, -1, 1207, -1, -1, -1, 68,
    -1, -1, 10, -1, -1, -1, -1, -1, -1, 78,
    -1, -1, -1, -1, -1, -1, -1, 86, -1, -1,
    -1, -1, 91, -1, -1, -1, -1, -1, -1, -1,
    -1, 592, -1, -1, -1, -1, -1, 106, -1, -1,
   601, -1, -1, -1, -1, -1, -1, -1, -1, 1261,
  1262, 1263, 60, 61, 62, 63, 64, 65, 66, 67,
    68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
    78, 79, 80, 81, 82, -1, -1, -1, -1, -1,
    -1, -1, 1294, 1, -1, 3, 4, 5, 6, 7,
     8, 9, -1, 11, 12, 13, -1, 15, 16, 17,
    18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
    28, 29, 30, 31, -1, 33, -1, 35, 36, -1,
    38, 39, 40, 41, -1, 43, -1, -1, -1, 47,
    48, 49, 50, 51, 52, -1, 54, 55, 56, -1,
    58, 59, -1, -1, -1, -1, 707, 65, -1, -1,
    68, -1, -1, -1, 715, 716, 717, -1, 76, 77,
    78, -1, -1, -1, -1, -1, 84, 85, 86, -1,
    -1, -1, -1, 91, 1, 93, 3, 4, 5, 6,
     7, 8, 9, 10, 11, 12, -1, -1, 106, 107,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    27, 28, 29, 30, 31, -1, 33, -1, 35, 36,
    -1, 38, 39, 40, 41, -1, 43, -1, 45, -1,
    47, 48, 49, 50, 51, 52, -1, 54, 55, 56,
    -1, -1, 59, -1, 795, -1, 797, -1, 65, -1,
    -1, 68, -1, -1, -1, -1, -1, 808, -1, 76,
    77, 78, -1, -1, -1, -1, -1, 84, 85, 86,
    -1, 88, -1, -1, 91, 92, -1, 1, 95, 3,
     4, 5, 6, 7, 8, 9, 10, 11, 12, -1,
   107, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 27, 28, 29, 30, 31, -1, 33,
    -1, 35, 36, -1, 38, 39, 40, 41, -1, 43,
    -1, 45, -1, 47, 48, 49, 50, 51, 52, -1,
    54, 55, 56, -1, -1, 59, -1, -1, -1, -1,
    -1, 65, -1, -1, 68, -1, -1, -1, -1, -1,
    -1, -1, 76, 77, 78, -1, -1, -1, -1, -1,
    84, 85, 86, 914, 88, -1, -1, 91, 92, -1,
    -1, 95, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, 1, 107, 3, 4, 5, 6, 7, 8,
     9, 10, 11, 12, -1, -1, -1, -1, -1, -1,
    -1, 952, 953, -1, 955, -1, -1, -1, 27, 28,
    29, 30, 31, -1, 33, -1, 35, 36, -1, 38,
    39, 40, 41, -1, 43, -1, -1, -1, 47, 48,
    49, 50, 51, 52, -1, 54, 55, -1, -1, -1,
    59, -1, -1, -1, -1, -1, 65, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, 76, 77, 78,
    -1, -1, -1, -1, -1, 84, 85, 86, -1, -1,
    -1, -1, 91, -1, -1, -1, 95, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, 105, 1, 107, 3,
     4, 5, 6, 7, 8, 9, -1, 11, 12, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 27, 28, 29, 30, 31, -1, 33,
    -1, 35, 36, -1, 38, 39, 40, 41, -1, 43,
    -1, -1, -1, 47, 48, 49, 50, 51, 52, -1,
    54, 55, 56, -1, 58, 59, -1, 1, -1, -1,
     4, 65, 6, 7, 68, -1, -1, -1, 12, -1,
    -1, -1, 76, 77, 78, -1, -1, -1, -1, -1,
    84, 85, 86, 27, -1, 29, -1, 91, -1, 33,
    -1, 35, 36, -1, -1, -1, -1, -1, -1, 43,
    -1, 45, -1, 107, -1, -1, -1, -1, 52, -1,
    54, 55, -1, 57, -1, -1, -1, 61, 62, 63,
    64, 65, 66, 67, 68, 69, 70, 71, 72, 73,
    74, 75, 76, 77, 78, 79, 80, 81, -1, -1,
    84, 85, 86, -1, 1, 89, 3, 4, 92, 6,
     7, 8, 9, -1, 11, 12, -1, -1, -1, -1,
    -1, -1, -1, 107, -1, -1, -1, -1, -1, -1,
    27, 28, 29, -1, 31, -1, 33, -1, 35, 36,
    -1, 38, 39, 40, 41, -1, 43, -1, -1, -1,
    47, 48, 49, 50, 51, 52, -1, 54, 55, 56,
    -1, -1, 59, -1, -1, -1, -1, -1, 65, -1,
    -1, 68, -1, -1, -1, -1, -1, -1, -1, 76,
    77, 78, -1, -1, -1, -1, -1, 84, 85, 86,
    -1, -1, -1, -1, 91, 92, 1, -1, 3, 4,
    -1, 6, 7, 8, 9, -1, 11, 12, -1, 106,
   107, -1, -1, -1, 19, -1, -1, -1, -1, -1,
    -1, -1, 27, 28, 29, -1, 31, -1, 33, -1,
    35, 36, -1, 38, 39, 40, 41, -1, 43, -1,
    -1, -1, 47, 48, 49, 50, 51, 52, -1, 54,
    55, 56, -1, -1, 59, -1, -1, -1, -1, -1,
    65, -1, -1, 68, -1, -1, -1, -1, -1, -1,
    -1, 76, 77, 78, -1, -1, -1, -1, -1, 84,
    85, 86, 1, -1, 3, 4, 91, 6, 7, 8,
     9, -1, 11, 12, -1, -1, -1, -1, -1, -1,
    19, 106, 107, -1, -1, -1, -1, -1, 27, 28,
    29, -1, 31, -1, 33, -1, 35, 36, -1, 38,
    39, 40, 41, -1, 43, -1, -1, -1, 47, 48,
    49, 50, 51, 52, -1, 54, 55, 56, -1, -1,
    59, -1, -1, -1, -1, -1, 65, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, 76, 77, 78,
    -1, -1, -1, -1, -1, 84, 85, 86, 1, -1,
     3, 4, 91, 6, 7, 8, 9, -1, 11, 12,
    -1, -1, -1, -1, -1, -1, -1, 106, 107, -1,
    -1, -1, -1, -1, 27, 28, 29, -1, 31, -1,
    33, -1, 35, 36, -1, 38, 39, 40, 41, -1,
    43, -1, -1, -1, 47, 48, 49, 50, 51, 52,
    -1, 54, 55, 56, -1, -1, 59, -1, -1, -1,
    -1, -1, 65, -1, -1, 68, -1, -1, -1, -1,
    -1, -1, -1, 76, 77, 78, -1, -1, -1, -1,
    -1, 84, 85, 86, -1, -1, -1, -1, 91, 92,
     1, -1, 3, 4, -1, 6, 7, 8, 9, -1,
    11, 12, -1, -1, 107, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, 27, 28, 29, -1,
    31, -1, 33, -1, 35, 36, -1, 38, 39, 40,
    41, -1, 43, -1, -1, -1, 47, 48, 49, 50,
    51, 52, -1, 54, 55, 56, -1, -1, 59, -1,
    -1, -1, -1, -1, 65, -1, -1, 68, -1, -1,
    -1, -1, -1, -1, -1, 76, 77, 78, -1, -1,
    -1, -1, -1, 84, 85, 86, 1, -1, 3, 4,
    91, 6, 7, 8, 9, -1, 11, 12, -1, -1,
    -1, -1, -1, -1, -1, -1, 107, -1, -1, -1,
    -1, -1, 27, 28, 29, -1, 31, -1, 33, -1,
    35, 36, -1, 38, 39, 40, 41, -1, 43, -1,
    -1, -1, 47, 48, 49, 50, 51, 52, -1, 54,
    55, 56, -1, -1, 59, -1, -1, -1, -1, -1,
    65, -1, -1, 68, -1, -1, -1, -1, -1, -1,
    -1, 76, 77, 78, -1, -1, -1, -1, -1, 84,
    85, 86, 1, -1, 3, 4, 91, 6, 7, 8,
     9, -1, 11, 12, -1, -1, -1, -1, -1, -1,
    -1, -1, 107, -1, -1, -1, -1, -1, 27, 28,
    29, -1, 31, -1, 33, -1, 35, 36, -1, 38,
    39, 40, 41, -1, 43, -1, -1, -1, 47, 48,
    49, 50, 51, 52, -1, 54, 55, -1, -1, -1,
    59, 60, -1, -1, -1, -1, 65, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, 76, 77, 78,
    -1, -1, -1, -1, -1, 84, 85, 86, 1, -1,
     3, 4, 91, 6, 7, 8, 9, -1, 11, 12,
    -1, -1, -1, -1, -1, -1, -1, -1, 107, -1,
    -1, -1, -1, -1, 27, 28, 29, -1, 31, -1,
    33, -1, 35, 36, -1, 38, 39, 40, 41, -1,
    43, -1, -1, -1, 47, 48, 49, 50, 51, 52,
    -1, 54, 55, 56, -1, -1, 59, -1, -1, -1,
    -1, -1, 65, -1, -1, 68, -1, -1, -1, -1,
    -1, -1, -1, 76, 77, 78, -1, -1, -1, -1,
    -1, 84, 85, 86, 1, -1, 3, 4, 91, 6,
     7, 8, 9, -1, 11, 12, -1, -1, -1, -1,
    -1, -1, -1, -1, 107, -1, -1, -1, -1, -1,
    27, 28, 29, -1, 31, -1, 33, -1, 35, 36,
    -1, 38, 39, 40, 41, -1, 43, -1, -1, -1,
    47, 48, 49, 50, 51, 52, -1, 54, 55, -1,
    -1, 58, 59, -1, -1, -1, -1, -1, 65, -1,
    -1, 68, -1, -1, -1, -1, -1, -1, -1, 76,
    77, 78, -1, -1, -1, -1, -1, 84, 85, 86,
     1, -1, 3, 4, 91, 6, 7, 8, 9, -1,
    11, 12, -1, -1, -1, -1, -1, -1, -1, -1,
   107, -1, -1, -1, -1, -1, 27, 28, 29, -1,
    31, -1, 33, -1, 35, 36, -1, 38, 39, 40,
    41, -1, 43, -1, -1, -1, 47, 48, 49, 50,
    51, 52, -1, 54, 55, -1, -1, -1, 59, -1,
    -1, -1, -1, -1, 65, -1, -1, 68, -1, -1,
    -1, -1, -1, -1, -1, 76, 77, 78, -1, -1,
    -1, -1, -1, 84, 85, 86, 1, -1, 3, 4,
    91, 6, 7, 8, 9, -1, 11, 12, -1, -1,
    -1, -1, -1, -1, 105, -1, 107, -1, -1, -1,
    -1, -1, 27, 28, 29, -1, 31, -1, 33, -1,
    35, 36, -1, 38, 39, 40, 41, -1, 43, -1,
    -1, -1, 47, 48, 49, 50, 51, 52, -1, 54,
    55, -1, -1, -1, 59, -1, -1, -1, -1, -1,
    65, -1, -1, 68, -1, -1, -1, -1, -1, -1,
    -1, 76, 77, 78, -1, -1, -1, -1, -1, 84,
    85, 86, 1, -1, 3, 4, 91, 6, 7, 8,
     9, -1, 11, 12, -1, -1, -1, -1, -1, -1,
    -1, -1, 107, -1, -1, -1, -1, -1, 27, 28,
    29, -1, 31, -1, 33, -1, 35, 36, -1, 38,
    39, 40, 41, -1, 43, -1, -1, -1, 47, 48,
    49, 50, 51, 52, -1, 54, 55, -1, -1, -1,
    59, -1, -1, -1, -1, -1, 65, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, 76, 77, 78,
    -1, -1, -1, -1, -1, 84, 85, 86, -1, -1,
     3, 4, 91, 6, 7, 8, 9, -1, 11, 12,
    -1, -1, -1, -1, -1, -1, -1, -1, 107, -1,
    -1, -1, -1, -1, 27, 28, 29, -1, 31, -1,
    33, -1, 35, 36, -1, 38, 39, 40, 41, -1,
    43, -1, -1, -1, 47, 48, 49, 50, 51, 52,
    -1, 54, 55, -1, -1, -1, 59, -1, -1, -1,
    -1, -1, 65, -1, -1, 68, -1, -1, -1, -1,
    -1, -1, -1, 76, 77, 78, -1, -1, -1, -1,
    -1, 84, 85, 86, -1, -1, -1, -1, 91, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, 107, 108, 3, 4, 5, 6,
     7, 8, 9, -1, 11, 12, 13, -1, 15, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
    27, 28, 29, 30, 31, -1, 33, -1, 35, 36,
    -1, 38, 39, 40, 41, -1, 43, -1, -1, -1,
    47, 48, 49, 50, 51, 52, -1, 54, 55, 56,
    -1, 58, 59, -1, -1, -1, -1, -1, 65, -1,
    -1, 68, -1, -1, -1, -1, -1, -1, -1, 76,
    77, 78, -1, -1, -1, -1, -1, 84, 85, 86,
    -1, -1, -1, -1, 91, -1, 93, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 106,
   107, 3, 4, 5, 6, 7, 8, 9, -1, 11,
    12, 13, -1, 15, 16, 17, 18, 19, 20, 21,
    22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, -1, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, 56, -1, 58, 59, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, -1, -1, -1, 91,
    -1, 93, -1, -1, 3, 4, 5, 6, 7, 8,
     9, -1, 11, 12, 13, 107, 15, 16, 17, 18,
    19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
    29, 30, 31, -1, 33, -1, 35, 36, -1, 38,
    39, 40, 41, -1, 43, -1, -1, -1, 47, 48,
    49, 50, 51, 52, -1, 54, 55, 56, -1, 58,
    59, -1, -1, -1, -1, -1, 65, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, 76, 77, 78,
    -1, -1, -1, -1, -1, 84, 85, 86, -1, -1,
    -1, -1, 91, -1, 93, -1, -1, 3, 4, 5,
     6, 7, 8, 9, -1, 11, 12, 13, 107, 15,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, -1, 33, -1, 35,
    36, -1, 38, 39, 40, 41, -1, 43, -1, -1,
    -1, 47, 48, 49, 50, 51, 52, -1, 54, 55,
    -1, -1, 58, 59, -1, -1, -1, -1, -1, 65,
    -1, -1, 68, -1, -1, -1, -1, -1, -1, -1,
    76, 77, 78, -1, -1, -1, -1, -1, 84, 85,
    86, -1, -1, -1, -1, 91, -1, 93, 3, 4,
     5, 6, 7, 8, 9, 10, 11, 12, -1, -1,
    -1, 107, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, 27, 28, 29, 30, 31, -1, 33, -1,
    35, 36, -1, 38, 39, 40, 41, -1, 43, -1,
    45, -1, 47, 48, 49, 50, 51, 52, -1, 54,
    55, -1, -1, -1, 59, -1, -1, -1, -1, -1,
    65, -1, -1, 68, -1, -1, -1, -1, -1, -1,
    -1, 76, 77, 78, -1, -1, -1, -1, -1, 84,
    85, 86, -1, 88, -1, -1, 91, 92, -1, -1,
    95, 3, 4, 5, 6, 7, 8, 9, 10, 11,
    12, -1, 107, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 27, 28, 29, 30, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, 45, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, 59, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, 88, -1, -1, 91,
    92, 3, 4, 95, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, 45, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, 88, -1, -1, 91,
    92, 3, 4, -1, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, 45, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, 88, -1, -1, 91,
    92, 3, 4, -1, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, -1, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, 59, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, 73, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, -1, 3, 4, 91,
     6, 7, 8, 9, -1, 11, 12, -1, -1, -1,
    -1, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, 27, 28, 29, -1, 31, -1, 33, -1, 35,
    36, -1, 38, 39, 40, 41, -1, 43, -1, -1,
    -1, 47, 48, 49, 50, 51, 52, -1, 54, 55,
    -1, -1, 58, 59, -1, -1, -1, -1, -1, 65,
    -1, -1, 68, -1, -1, -1, -1, -1, -1, -1,
    76, 77, 78, -1, -1, -1, -1, -1, 84, 85,
    86, -1, -1, 3, 4, 91, 6, 7, 8, 9,
    -1, 11, 12, -1, -1, -1, -1, -1, -1, -1,
    -1, 107, -1, -1, -1, -1, -1, 27, 28, 29,
    -1, 31, -1, 33, -1, 35, 36, -1, 38, 39,
    40, 41, -1, 43, -1, -1, -1, 47, 48, 49,
    50, 51, 52, -1, 54, 55, -1, -1, -1, 59,
    -1, -1, -1, -1, -1, 65, -1, -1, 68, -1,
    -1, -1, -1, -1, -1, -1, 76, 77, 78, -1,
    -1, -1, -1, -1, 84, 85, 86, -1, -1, 3,
     4, 91, 6, 7, 8, 9, -1, 11, 12, -1,
    -1, -1, -1, -1, -1, -1, -1, 107, -1, -1,
    -1, -1, -1, 27, 28, 29, -1, 31, -1, 33,
    -1, 35, 36, -1, 38, 39, 40, 41, -1, 43,
    -1, -1, -1, 47, 48, 49, 50, 51, 52, -1,
    54, 55, -1, -1, -1, 59, -1, -1, -1, -1,
    -1, 65, -1, -1, 68, -1, -1, -1, -1, -1,
    -1, -1, 76, 77, 78, -1, -1, -1, -1, -1,
    84, 85, 86, -1, -1, 3, 4, 91, 6, 7,
     8, 9, -1, 11, 12, -1, -1, -1, -1, -1,
    -1, -1, -1, 107, -1, -1, -1, -1, -1, 27,
    28, 29, -1, 31, -1, 33, -1, 35, 36, -1,
    38, 39, 40, 41, -1, 43, -1, -1, -1, 47,
    48, 49, 50, 51, 52, -1, 54, 55, 56, -1,
    -1, -1, -1, -1, -1, -1, -1, 65, -1, -1,
    68, -1, -1, -1, -1, -1, -1, -1, 76, 77,
    78, -1, -1, -1, -1, -1, 84, 85, 86, -1,
    -1, 3, 4, 91, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, -1, -1, -1, -1, 107,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, -1, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, -1, -1, -1, 91,
    92, 3, 4, -1, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, -1, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, 59, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, -1, 3, 4, 91,
     6, 7, 8, 9, -1, 11, 12, -1, -1, -1,
    -1, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, 27, 28, 29, -1, 31, -1, 33, -1, 35,
    36, -1, 38, 39, 40, 41, -1, 43, -1, -1,
    -1, 47, 48, 49, 50, 51, 52, -1, 54, 55,
    -1, -1, -1, 59, -1, -1, -1, -1, -1, 65,
    -1, -1, 68, -1, -1, -1, -1, -1, -1, -1,
    76, 77, 78, -1, -1, -1, -1, -1, 84, 85,
    86, -1, -1, 3, 4, 91, 6, 7, 8, 9,
    -1, 11, 12, -1, -1, -1, -1, -1, -1, -1,
    -1, 107, -1, -1, -1, -1, -1, 27, 28, 29,
    -1, 31, -1, 33, -1, 35, 36, -1, 38, 39,
    40, 41, -1, 43, -1, -1, -1, 47, 48, 49,
    50, 51, 52, -1, 54, 55, -1, -1, -1, 59,
    -1, -1, -1, -1, -1, 65, -1, -1, 68, -1,
    -1, -1, -1, -1, -1, -1, 76, 77, 78, -1,
    -1, -1, -1, -1, 84, 85, 86, -1, -1, 3,
     4, 91, 6, 7, 8, 9, -1, 11, 12, -1,
    -1, -1, -1, -1, -1, -1, -1, 107, -1, -1,
    -1, -1, -1, 27, 28, 29, -1, 31, -1, 33,
    -1, 35, 36, -1, 38, 39, 40, 41, -1, 43,
    -1, -1, -1, 47, 48, 49, 50, 51, 52, -1,
    54, 55, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, 65, -1, -1, 68, -1, -1, -1, -1, -1,
    -1, -1, 76, 77, 78, -1, -1, -1, -1, -1,
    84, 85, 86, -1, -1, 3, 4, 91, 6, 7,
     8, 9, -1, 11, 12, -1, -1, -1, -1, -1,
    -1, -1, -1, 107, -1, -1, -1, -1, -1, 27,
    28, 29, -1, 31, -1, 33, -1, 35, 36, -1,
    38, 39, 40, 41, -1, 43, -1, -1, -1, 47,
    48, 49, 50, 51, 52, -1, 54, 55, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, 65, -1, -1,
    68, -1, -1, -1, -1, -1, -1, -1, 76, 77,
    78, -1, -1, -1, -1, -1, 84, 85, 86, -1,
    -1, 3, 4, 91, 6, 7, 8, 9, -1, 11,
    12, -1, -1, -1, -1, -1, -1, -1, -1, 107,
    -1, -1, -1, -1, -1, 27, 28, 29, -1, 31,
    -1, 33, -1, 35, 36, -1, 38, 39, 40, 41,
    -1, 43, -1, -1, -1, 47, 48, 49, 50, 51,
    52, -1, 54, 55, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 65, -1, -1, 68, -1, -1, -1,
    -1, -1, -1, -1, 76, 77, 78, -1, -1, -1,
    -1, -1, 84, 85, 86, -1, -1, 3, 4, 91,
     6, 7, 8, 9, -1, 11, 12, -1, -1, -1,
    -1, -1, -1, -1, -1, 107, -1, -1, -1, -1,
    -1, 27, 28, 29, -1, 31, -1, 33, -1, 35,
    36, -1, 38, 39, 40, 41, -1, 43, -1, -1,
    -1, 47, 48, 49, 50, 51, 52, -1, 54, 55,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 65,
    -1, -1, 68, -1, -1, -1, -1, -1, -1, -1,
    76, 77, 78, -1, -1, -1, -1, -1, 84, 85,
    86, -1, -1, 3, 4, 91, 6, 7, 8, 9,
    -1, 11, 12, -1, -1, -1, -1, -1, -1, -1,
    -1, 107, -1, -1, -1, -1, -1, 27, 28, 29,
    -1, 31, -1, 33, -1, 35, 36, -1, 38, 39,
    40, 41, -1, 43, -1, -1, -1, 47, 48, 49,
    50, 51, 52, -1, 54, 55, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 65, -1, -1, 68, -1,
    -1, -1, -1, -1, -1, -1, 76, 77, 78, -1,
    -1, -1, -1, -1, 84, 85, 86, -1, -1, -1,
     1, 91, 3, 4, 5, 6, 7, -1, -1, -1,
    -1, 12, -1, -1, -1, -1, -1, 107, -1, -1,
    -1, -1, -1, -1, 25, 26, 27, -1, 29, 30,
    -1, -1, 33, -1, -1, -1, 37, -1, 39, -1,
    -1, 42, 43, 44, -1, 46, -1, -1, -1, -1,
    -1, 52, -1, 54, 55, -1, -1, 58, -1, -1,
     1, -1, 3, 4, 5, 6, 7, 68, -1, -1,
    -1, 12, -1, -1, -1, -1, -1, 78, -1, -1,
    -1, -1, -1, -1, -1, 86, 27, -1, 29, 30,
    91, -1, 33, -1, -1, 96, 97, -1, 39, -1,
    -1, -1, 43, -1, -1, 46, -1, -1, -1, -1,
    -1, 52, -1, 54, 55, -1, -1, 58, -1, -1,
    -1, -1, 3, 4, 5, 6, 7, 68, -1, 10,
    -1, 12, -1, -1, -1, -1, -1, 78, -1, -1,
    -1, -1, -1, -1, -1, 86, 27, -1, 29, 30,
    91, -1, 33, -1, -1, 96, -1, -1, 39, -1,
    -1, -1, 43, -1, 45, -1, 3, 4, 5, 6,
     7, 52, -1, 54, 55, 12, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, 68, -1, -1,
    27, -1, 29, 30, -1, -1, 33, 78, -1, -1,
    -1, -1, 39, -1, -1, 86, 43, 88, -1, -1,
    91, 92, -1, -1, 95, 52, -1, 54, 55, -1,
    -1, -1, -1, 60, -1, -1, 3, 4, 5, 6,
     7, 68, -1, 10, -1, 12, -1, -1, -1, -1,
    -1, 78, -1, -1, -1, -1, -1, -1, -1, 86,
    27, -1, 29, 30, 91, -1, 33, -1, -1, -1,
    -1, -1, 39, -1, -1, -1, 43, -1, -1, -1,
     3, 4, 5, 6, 7, 52, -1, 54, 55, 12,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, 68, -1, -1, 27, -1, 29, 30, -1, -1,
    33, 78, -1, -1, -1, -1, 39, -1, -1, 86,
    43, -1, -1, -1, 91, -1, -1, -1, -1, 52,
    -1, 54, 55, -1, -1, 58, -1, -1, -1, -1,
     3, 4, 5, 6, 7, 68, -1, -1, -1, 12,
    -1, -1, -1, -1, -1, 78, -1, -1, -1, -1,
    -1, -1, -1, 86, 27, -1, 29, 30, 91, -1,
    33, -1, -1, -1, -1, -1, 39, -1, -1, -1,
    43, -1, -1, -1, 3, 4, 5, 6, 7, 52,
    -1, 54, 55, 12, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, 68, -1, -1, 27, -1,
    29, 30, -1, -1, 33, 78, -1, -1, -1, -1,
    39, -1, -1, 86, 43, -1, -1, -1, 91, -1,
    -1, -1, -1, 52, -1, 54, 55, -1, -1, -1,
    -1, -1, 30, -1, -1, -1, -1, -1, -1, 68,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 78,
    -1, -1, -1, -1, -1, -1, -1, 86, -1, -1,
    -1, -1, 91, 61, 62, 63, 64, 65, 66, 67,
    68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
    78, 79, 80, 81, 82, 4, 5, 6, 7, -1,
    -1, -1, -1, 12, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, 27, -1,
    29, 30, -1, -1, 33, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, 43, -1, -1, -1, -1, -1,
    -1, -1, -1, 52, -1, 54, 55, 61, 62, 63,
    64, 65, 66, 67, 68, 69, 70, 71, 72, 73,
    74, 75, 76, 77, 78, 79, 80, 81, 82, 61,
    62, 63, 64, 65, 66, 67, 68, 69, 70, 71,
    72, 73, 74, 75, 76, 77, 78, 79, 80, 81,
    82, 57, -1, -1, 108, 61, 62, 63, 64, 65,
    66, 67, 68, 69, 70, 71, 72, 73, 74, 75,
    76, 77, 78, 79, 80, 81, 82, 60, 61, 62,
    63, 64, 65, 66, 67, 68, 69, 70, 71, 72,
    73, 74, 75, 76, 77, 78, 79, 80, 81, 82,
    60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
    70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
    80, 81, 82, 61, 62, 63, 64, 65, 66, 67,
    68, 69, 70, 71, 72, -1, 74, 75, 76, 77,
    78, 79, 80, 81, 82, 65, 66, 67, 68, 69,
    70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
    80, 81, 82
};
int yychar;
YYSTYPE yylval;







int yynerrs;



int yydebug;
int yyparse (void) asm("_yyparse");
int
yyparse(void) asm("_yyparse");
int
yyparse(void)
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;
  int yychar1 = 0;

  short yyssa[200];
  YYSTYPE yyvsa[200];

  short *yyss = yyssa;
  YYSTYPE *yyvs = yyvsa;
  int yystacksize = 200;
  YYSTYPE yyval;



  int yylen;


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Starting parse\n");


  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = -2;






  yyssp = yyss - 1;
  yyvsp = yyvs;







yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {


      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;





      int size = yyssp - yyss + 1;
      if (yystacksize >= 10000)
 {
   yyerror("parser stack overflow");
   return 2;
 }
      yystacksize *= 2;
      if (yystacksize > 10000)
 yystacksize = 10000;
      yyss = (short *) 
                      __builtin_alloca((
                      yystacksize * sizeof (*yyssp)
                      ))
                                                            ;
      __builtin_memcpy((char *)yyss,(char *)yyss1,size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) 
                        __builtin_alloca((
                        yystacksize * sizeof (*yyvsp)
                        ))
                                                              ;
      __builtin_memcpy((char *)yyvs,(char *)yyvs1,size * sizeof (*yyvsp));






      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;





      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Stack size increased to %d\n", yystacksize);


      if (yyssp >= yyss + yystacksize - 1)
 return(1);
    }


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Entering state %d\n", yystate);


  goto yybackup;
 yybackup:







  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yydefault;






  if (yychar == -2)
    {

      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Reading a token: ");

      yychar = yylex();
    }



  if (yychar <= 0)
    {
      yychar1 = 0;
      yychar = 0;


      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Now at end of input.\n");

    }
  else
    {
      yychar1 = ((unsigned)(yychar) <= 339 ? yytranslate[yychar] : 364);


      if (yydebug)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "Next token is %d (%s", yychar, yytname[yychar1]);



   yyprint(
  (__acrt_iob_func(2))
  ,yychar,yylval);

   fprintf (
           (__acrt_iob_func(2))
                 , ")\n");
 }

    }

  yyn += yychar1;
  if (yyn < 0 || yyn > 9543 || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == 1399)
    return(0);




  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Shifting token %d (%s), ", yychar, yytname[yychar1]);



  if (yychar != 0)
    yychar = -2;

  *++yyvsp = yylval;





  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;


yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen];


  if (yydebug)
    {
      int i;

      fprintf (
              (__acrt_iob_func(2))
                    , "Reducing via rule %d (line %d), ",
        yyn, yyrline[yyn]);


      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
 fprintf (
         (__acrt_iob_func(2))
               , "%s ", yytname[yyrhs[i]]);
      fprintf (
              (__acrt_iob_func(2))
                    , " -> %s\n", yytname[yyr1[yyn]]);
    }



  switch (yyn) {

case 2:
{


    while (! global_bindings_p ())
      poplevel (0, 0, 0);
    finish_file ();
  ;
    break;}
case 3:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 4:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 5:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 8:
{ have_extern_spec = 1;
    used_extern_spec = 0;
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 9:
{ have_extern_spec = 0; ;
    break;}
case 12:
{ if (pending_lang_change) do_pending_lang_change(); ;
    break;}
case 13:
{ if (! toplevel_bindings_p () && ! pseudo_global_level_p())
       pop_everything (); ;
    break;}
case 14:
{ if (pending_inlines) do_pending_inlines (); ;
    break;}
case 15:
{ if (pending_inlines) do_pending_inlines (); ;
    break;}
case 16:
{ if (pending_inlines) do_pending_inlines (); ;
    break;}
case 18:
{ if (((yyvsp[-2].ttype)->common.chain)) yyvsp[-2].ttype = combine_strings (yyvsp[-2].ttype);
    assemble_asm (yyvsp[-2].ttype); ;
    break;}
case 19:
{ pop_lang_context (); ;
    break;}
case 20:
{ if (pending_inlines) do_pending_inlines ();
    pop_lang_context (); ;
    break;}
case 21:
{ if (pending_inlines) do_pending_inlines ();
    pop_lang_context (); ;
    break;}
case 22:
{ push_namespace (yyvsp[-1].ttype); ;
    break;}
case 23:
{ pop_namespace (); ;
    break;}
case 24:
{ push_namespace ((tree) 
                 ((void *)0)
                          ); ;
    break;}
case 25:
{ pop_namespace (); ;
    break;}
case 26:
{ do_namespace_alias (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 27:
{ do_toplevel_using_decl (yyvsp[-1].ttype); ;
    break;}
case 28:
{ do_using_directive (yyvsp[-1].ttype); ;
    break;}
case 29:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 30:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 31:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 34:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 35:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 36:
{ push_lang_context (yyvsp[0].ttype); ;
    break;}
case 37:
{ if (current_lang_name != yyvsp[0].ttype)
      cp_error ("use of linkage spec `%D' is different from previous spec `%D'", yyvsp[0].ttype, current_lang_name);
    pop_lang_context (); push_lang_context (yyvsp[0].ttype); ;
    break;}
case 38:
{ begin_template_parm_list (); ;
    break;}
case 39:
{ yyval.ttype = end_template_parm_list (yyvsp[-1].ttype); ;
    break;}
case 40:
{ yyval.ttype = process_template_parm ((tree) 
                                      ((void *)0)
                                               , yyvsp[0].ttype); ;
    break;}
case 41:
{ yyval.ttype = process_template_parm (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 42:
{
    yyval.ttype = build_tree_list (yyvsp[0].ttype, (tree) 
                                                  ((void *)0)
                                                           );
   ttpa:
    if (((yyval.ttype)->list.purpose) == signature_type_node)
      sorry ("signature as template type parameter");
    else if (((yyval.ttype)->list.purpose) != class_type_node)
      pedwarn ("template type parameters must use the keyword `class'");
  ;
    break;}
case 43:
{ yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype); goto ttpa; ;
    break;}
case 44:
{ yyval.ttype = build_tree_list (class_type_node, (tree) 
                                                 ((void *)0)
                                                          ); ;
    break;}
case 45:
{ yyval.ttype = build_tree_list (class_type_node, yyvsp[0].ttype); ;
    break;}
case 46:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 47:
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 49:
{ warning ("use of `overload' is an anachronism"); ;
    break;}
case 50:
{ declare_overloaded (yyvsp[0].ttype); ;
    break;}
case 51:
{ declare_overloaded (yyvsp[0].ttype); ;
    break;}
case 52:
{ yychar = '{'; goto template1; ;
    break;}
case 54:
{ yychar = '{'; goto template1; ;
    break;}
case 56:
{ yychar = ':'; goto template1; ;
    break;}
case 58:
{
    yychar = ':';
  template1:
    if (current_aggr == signature_type_node)
      sorry ("template type defining a signature");


    end_template_decl (yyvsp[-2].ttype, yyvsp[-1].ttype, current_aggr, 1);
    reinit_parse_for_template (yychar, yyvsp[-2].ttype, yyvsp[-1].ttype);
    yychar = -2;
  ;
    break;}
case 60:
{
    end_template_decl (yyvsp[-2].ttype, yyvsp[-1].ttype, current_aggr, 0);

  ;
    break;}
case 61:
{
    end_template_decl (yyvsp[-2].ttype, yyvsp[-1].ttype, current_aggr, 0);

  ;
    break;}
case 62:
{
    tree d;
    int momentary;
    int def = (yyvsp[0].itype != ';');
    momentary = suspend_momentary ();
    d = start_decl (yyvsp[-4].ttype, (tree) 
                                                         ((void *)0)
                                                                  , 0,
      yyvsp[-3].ttype);
    cplus_decl_attributes (d, yyvsp[-1].ttype, (tree) 
                                                                   ((void *)0)
                                                                            );
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , yyvsp[-2].ttype, 0, 0);
    end_template_decl (yyvsp[-5].ttype, d, 0, def);
    if (def)
      reinit_parse_for_template ((int) yyvsp[0].itype, yyvsp[-5].ttype, d);
    resume_momentary (momentary);
  ;
    break;}
case 63:
{
    tree d, specs, attrs;
    int momentary;
    int def = (yyvsp[0].itype != ';');
    split_specs_attrs (yyvsp[-5].ttype, &specs, &attrs);
    momentary = suspend_momentary ();
    d = start_decl (yyvsp[-4].ttype, specs, 0, yyvsp[-3].ttype);
    cplus_decl_attributes (d, yyvsp[-1].ttype, attrs);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , yyvsp[-2].ttype, 0, 0);
    end_template_decl (yyvsp[-6].ttype, d, 0, def);
    if (def)
      {
        reinit_parse_for_template ((int) yyvsp[0].itype, yyvsp[-6].ttype, d);
        yychar = -2;
      }
    note_list_got_semicolon (yyvsp[-5].ttype);
    resume_momentary (momentary);
  ;
    break;}
case 64:
{
    tree d, specs, attrs;
    int def = (yyvsp[0].itype != ';');
    split_specs_attrs (yyvsp[-2].ttype, &specs, &attrs);
    d = start_decl (yyvsp[-1].ttype, specs, 0, (tree) 
                                              ((void *)0)
                                                       );
    cplus_decl_attributes (d, (tree) 
                             ((void *)0)
                                      , attrs);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , (tree) 
                                 ((void *)0)
                                          , 0, 0);
    end_template_decl (yyvsp[-3].ttype, d, 0, def);
    if (def)
      reinit_parse_for_template ((int) yyvsp[0].itype, yyvsp[-3].ttype, d);
  ;
    break;}
case 65:
{ end_template_decl (yyvsp[-2].ttype, 0, 0, 0); ;
    break;}
case 66:
{ end_template_decl (yyvsp[-2].ttype, 0, 0, 0); ;
    break;}
case 67:
{ yyval.itype = '{'; ;
    break;}
case 68:
{ yyval.itype = ':'; ;
    break;}
case 69:
{ yyval.itype = ';'; ;
    break;}
case 70:
{ yyval.itype = '='; ;
    break;}
case 71:
{ yyval.itype = 278; ;
    break;}
case 72:
{;
    break;}
case 73:
{;
    break;}
case 74:
{ tree d, specs, attrs;
    split_specs_attrs (yyvsp[-2].ttype, &specs, &attrs);
    d = start_decl (yyvsp[-1].ttype, specs, 0, (tree) 
                                              ((void *)0)
                                                       );
    cplus_decl_attributes (d, (tree) 
                             ((void *)0)
                                      , attrs);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , (tree) 
                                 ((void *)0)
                                          , 0, 0);
  ;
    break;}
case 75:
{
    note_list_got_semicolon (yyval.ttype);
  ;
    break;}
case 76:
{ tree d, specs, attrs;
    split_specs_attrs (yyvsp[-2].ttype, &specs, &attrs);
    d = start_decl (yyvsp[-1].ttype, specs, 0, (tree) 
                                              ((void *)0)
                                                       );
    cplus_decl_attributes (d, (tree) 
                             ((void *)0)
                                      , attrs);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , (tree) 
                                 ((void *)0)
                                          , 0, 0);
    note_list_got_semicolon (yyval.ttype);
  ;
    break;}
case 77:
{ pedwarn ("empty declaration"); ;
    break;}
case 79:
{
     tree t, attrs;
     split_specs_attrs (yyvsp[-1].ttype, &t, &attrs);
     shadow_tag (t);
     if (((n64_enum_tree_code) (t)->common.code) == TREE_LIST
  && ((t)->list.purpose) == (tree) 
                        ((void *)0)
                                 )
       {
  t = ((t)->list.value);
  if ((((t)->type.lang_flag_5))
      && (((struct n64_tag_lang_identifier *)((((((t)->type.name))->decl.name))))->class_template_info))
    {
      if ((((t)->type.lang_specific)->type_flags.use_template) == 0)
        ((((t)->type.lang_specific)->type_flags.use_template) = 2);
      else if (((((t)->type.lang_specific)->type_flags.use_template) & 1))
        error ("override declaration for already-expanded template");
    }
       }
     note_list_got_semicolon (yyval.ttype);
   ;
    break;}
case 83:
{ yyval.itype = 0; ;
    break;}
case 84:
{ yyval.itype = 1; ;
    break;}
case 90:
{
    finish_function (lineno, (int)yyvsp[-1].itype, 0);
    if (yyval.ttype) process_next_inline (yyval.ttype);
  ;
    break;}
case 91:
{
    if (yyval.ttype) process_next_inline (yyval.ttype);
  ;
    break;}
case 93:
{;
    break;}
case 94:
{;
    break;}
case 95:
{;
    break;}
case 96:
{ tree specs, attrs;
    split_specs_attrs (yyvsp[-2].ttype, &specs, &attrs);
    if (! start_function (specs, yyvsp[-1].ttype, yyvsp[0].ttype, attrs, 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function ();
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 97:
{ tree specs = strip_attrs (yyvsp[-2].ttype);
    if (! start_function (specs, yyvsp[-1].ttype, yyvsp[0].ttype, (tree) 
                                                                 ((void *)0)
                                                                          , 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function ();
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 98:
{ if (! start_function ((tree) 
                       ((void *)0)
                                , yyval.ttype, yyvsp[0].ttype, (tree) 
                                                               ((void *)0)
                                                                        , 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function ();
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 99:
{ start_function ((tree) 
                 ((void *)0)
                          , ((yyval.ttype)->list.value),
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         , 1);
    reinit_parse_for_function (); ;
    break;}
case 100:
{ tree specs = strip_attrs (yyvsp[-5].ttype);
    yyval.ttype = build_parse_node (CALL_EXPR, ((specs)->list.value), yyvsp[-3].ttype, yyvsp[-1].ttype);
    yyval.ttype = start_method (((specs)->common.chain), yyval.ttype, yyvsp[0].ttype);
   rest_of_mdef:
    if (! yyval.ttype)
      { yyerror ("syntax error"); goto yyerrlab1; };
    if (yychar == -2)
      yychar = yylex();
    reinit_parse_for_method (yychar, yyval.ttype); ;
    break;}
case 101:
{ tree specs = strip_attrs (yyvsp[-3].ttype);
    yyval.ttype = build_parse_node (CALL_EXPR, ((specs)->list.value),
      empty_parms (), yyvsp[-1].ttype);
    yyval.ttype = start_method (((specs)->common.chain), yyval.ttype, yyvsp[0].ttype);
    goto rest_of_mdef;
  ;
    break;}
case 102:
{ tree specs = strip_attrs (yyvsp[-2].ttype);
    yyval.ttype = start_method (specs, yyvsp[-1].ttype, yyvsp[0].ttype); goto rest_of_mdef; ;
    break;}
case 103:
{ tree specs = strip_attrs (yyvsp[-2].ttype);
    yyval.ttype = start_method (specs, yyvsp[-1].ttype, yyvsp[0].ttype); goto rest_of_mdef; ;
    break;}
case 104:
{ yyval.ttype = start_method ((tree) 
                             ((void *)0)
                                      , yyval.ttype, yyvsp[0].ttype); goto rest_of_mdef; ;
    break;}
case 105:
{
    if (! current_function_parms_stored)
      store_parm_decls ();
    yyval.ttype = yyvsp[0].ttype;
  ;
    break;}
case 106:
{ store_return_init (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 107:
{ store_return_init (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 108:
{ store_return_init (yyval.ttype, (tree) 
                                 ((void *)0)
                                          ); ;
    break;}
case 109:
{
    if (yyvsp[0].itype == 0)
      error ("no base initializers given following ':'");
    setup_vtbl_ptr ();



    keep_next_level ();
  ;
    break;}
case 110:
{
    if (! current_function_parms_stored)
      store_parm_decls ();

    if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
      {

        pushlevel (0);
        clear_last_expr ();
        expand_start_bindings (0);
      }
    else if (current_class_type == (tree) 
                                  ((void *)0)
                                           )
      error ("base initializers not allowed for non-member functions");
    else if (! (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
      error ("only constructors take base initializers");
  ;
    break;}
case 111:
{ yyval.itype = 0; ;
    break;}
case 112:
{ yyval.itype = 1; ;
    break;}
case 115:
{
    if (current_class_name && !flag_traditional)
      pedwarn ("anachronistic old style base class initializer");
    expand_member_init (C_C_D, (tree) 
                              ((void *)0)
                                       , yyvsp[-1].ttype);
  ;
    break;}
case 116:
{
    if (current_class_name && !flag_traditional)
      pedwarn ("anachronistic old style base class initializer");
    expand_member_init (C_C_D, (tree) 
                              ((void *)0)
                                       , void_type_node);
  ;
    break;}
case 117:
{ expand_member_init (C_C_D, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 118:
{ expand_member_init (C_C_D, yyval.ttype, void_type_node); ;
    break;}
case 119:
{ expand_member_init (C_C_D, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 120:
{ expand_member_init (C_C_D, yyval.ttype, void_type_node); ;
    break;}
case 121:
{
    do_member_init ((((yyvsp[-3].ttype)->exp.operands[0])), (((yyvsp[-3].ttype)->exp.operands[1])), yyvsp[-1].ttype);
  ;
    break;}
case 122:
{
    do_member_init ((((yyvsp[-1].ttype)->exp.operands[0])), (((yyvsp[-1].ttype)->exp.operands[1])), void_type_node);
  ;
    break;}
case 133:
{ do_type_instantiation (yyvsp[0].ttype ? yyvsp[0].ttype : yyvsp[-1].ttype, (tree) 
                                                                           ((void *)0)
                                                                                    ); ;
    break;}
case 134:
{ tree specs = strip_attrs (yyvsp[-1].ttype);
    do_function_instantiation (specs, yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 135:
{ do_function_instantiation ((tree) 
                            ((void *)0)
                                     , yyvsp[0].ttype, (tree) 
                                                       ((void *)0)
                                                                ); ;
    break;}
case 136:
{ do_type_instantiation (yyvsp[0].ttype ? yyvsp[0].ttype : yyvsp[-1].ttype, yyvsp[-3].ttype); ;
    break;}
case 137:
{ tree specs = strip_attrs (yyvsp[-1].ttype);
    do_function_instantiation (specs, yyvsp[0].ttype, yyvsp[-3].ttype); ;
    break;}
case 138:
{ do_function_instantiation ((tree) 
                            ((void *)0)
                                     , yyvsp[0].ttype, yyvsp[-2].ttype); ;
    break;}
case 139:
{ if (yyvsp[0].ttype) yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 140:
{ yyval.ttype = lookup_template_class (yyval.ttype, yyvsp[-1].ttype, (tree) 
                                                                    ((void *)0)
                                                                             ); ;
    break;}
case 141:
{ yyval.ttype = lookup_template_class (yyval.ttype, (tree) 
                                                   ((void *)0)
                                                            , (tree) 
                                                              ((void *)0)
                                                                       ); ;
    break;}
case 142:
{ yyval.ttype = lookup_template_class (yyval.ttype, yyvsp[-1].ttype, (tree) 
                                                                    ((void *)0)
                                                                             ); ;
    break;}
case 143:
{ yyval.ttype = instantiate_class_template (yyvsp[0].ttype, 1); ;
    break;}
case 144:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 145:
{ yyval.ttype = chainon (yyval.ttype, build_tree_list ((tree) 
                                                      ((void *)0)
                                                               , yyvsp[0].ttype)); ;
    break;}
case 146:
{ yyval.ttype = groktypename (yyval.ttype); ;
    break;}
case 148:
{
    tree t, decl, tmpl;

    tmpl = (((((struct n64_tag_lang_identifier *)(yyvsp[-1].ttype))->class_template_info))->list.purpose);
    t = xref_tag ((((tmpl)->decl.lang_specific)->template_info)->aggr, yyvsp[-1].ttype, yyvsp[0].ttype, 0);
    set_current_level_tags_transparency (1);
    my_friendly_assert (((n64_enum_tree_code) (t)->common.code) == RECORD_TYPE
          || ((n64_enum_tree_code) (t)->common.code) == UNION_TYPE, 257);
    yyval.ttype = t;



    decl = (((struct n64_tag_lang_identifier *)(yyvsp[-1].ttype))->local_value);
    if (!decl)
      decl = (((struct n64_tag_lang_identifier *)(yyvsp[-1].ttype))->class_value);


                  if (decl)
                    {


                      my_friendly_assert (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL, 258);
        push_obstacks (&permanent_obstack, &permanent_obstack);
                      decl = copy_node (decl);
        if (((decl)->decl.lang_specific))
   copy_lang_decl (decl);
        pop_obstacks ();
        pushdecl_top_level (decl);
      }

    (((t)->type.lang_specific)->type_flags.being_defined) = 0;
  ;
    break;}
case 149:
{
    tree t = finish_struct (yyvsp[-3].ttype, yyvsp[-1].ttype, 0);

    pop_obstacks ();
    end_template_instantiation (yyvsp[-5].ttype);

    repo_template_used (t);


                  instantiate_member_templates (yyvsp[-5].ttype);

    pop_tinst_level();

    (((t)->type.lang_specific)->type_flags.got_semicolon) = 1;
  ;
    break;}
case 150:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 151:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 152:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 153:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 154:
{ yyval.code = NEGATE_EXPR; ;
    break;}
case 155:
{ yyval.code = CONVERT_EXPR; ;
    break;}
case 156:
{ yyval.code = PREINCREMENT_EXPR; ;
    break;}
case 157:
{ yyval.code = PREDECREMENT_EXPR; ;
    break;}
case 158:
{ yyval.code = TRUTH_NOT_EXPR; ;
    break;}
case 159:
{ yyval.ttype = build_x_compound_expr (yyval.ttype); ;
    break;}
case 161:
{ error ("ANSI C++ forbids an empty condition for `%s'",
    cond_stmt_keyword);
    yyval.ttype = integer_zero_node; ;
    break;}
case 162:
{ yyval.ttype = condition_conversion (yyvsp[-1].ttype); ;
    break;}
case 163:
{ error ("ANSI C++ forbids an empty condition for `%s'",
    cond_stmt_keyword);
    yyval.ttype = integer_zero_node; ;
    break;}
case 164:
{ yyval.ttype = condition_conversion (yyvsp[-1].ttype); ;
    break;}
case 165:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 166:
{ yyval.ttype = condition_conversion (yyval.ttype); ;
    break;}
case 167:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 168:
{ {
    tree d;
    for (d = getdecls (); d; d = ((d)->common.chain))
      if (((n64_enum_tree_code) (d)->common.code) == TYPE_DECL) {
        tree s = ((d)->common.type);
        if (((n64_enum_tree_code) (s)->common.code) == RECORD_TYPE)
   cp_error ("definition of class `%T' in condition", s);
        else if (((n64_enum_tree_code) (s)->common.code) == ENUMERAL_TYPE)
   cp_error ("definition of enum `%T' in condition", s);
      }
    }
    current_declspecs = yyvsp[-5].ttype;
    yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_decl (yyvsp[-4].ttype, current_declspecs, 1, yyvsp[-3].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[-1].ttype,
                            (tree) 
                           ((void *)0)
                                    );
  ;
    break;}
case 169:
{
    cp_finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-3].ttype, 0, (128));
    resume_momentary (yyvsp[-2].itype);
    yyval.ttype = yyvsp[-1].ttype;
    if (((n64_enum_tree_code) (((yyval.ttype)->common.type))->common.code) == ARRAY_TYPE)
      cp_error ("definition of array `%#D' in condition", yyval.ttype);
  ;
    break;}
case 175:
{ finish_stmt (); ;
    break;}
case 177:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyval.ttype,
                    build_tree_list ((tree) 
                                    ((void *)0)
                                             , yyvsp[0].ttype)); ;
    break;}
case 178:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyval.ttype,
                    build_tree_list ((tree) 
                                    ((void *)0)
                                             , error_mark_node)); ;
    break;}
case 179:
{ chainon (yyval.ttype, build_tree_list ((tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype)); ;
    break;}
case 180:
{ chainon (yyval.ttype, build_tree_list ((tree) 
                                        ((void *)0)
                                                 , error_mark_node)); ;
    break;}
case 181:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 183:
{




  ;
    break;}
case 184:
{ yyvsp[0].itype = pedantic;
    pedantic = 0; ;
    break;}
case 185:
{ yyval.ttype = yyvsp[0].ttype;
    pedantic = yyvsp[-2].itype; ;
    break;}
case 186:
{ yyval.ttype = build_x_indirect_ref (yyvsp[0].ttype, "unary *"); ;
    break;}
case 187:
{ yyval.ttype = build_x_unary_op (ADDR_EXPR, yyvsp[0].ttype); ;
    break;}
case 188:
{ yyval.ttype = build_x_unary_op (BIT_NOT_EXPR, yyvsp[0].ttype); ;
    break;}
case 189:
{ yyval.ttype = build_x_unary_op (yyvsp[-1].code, yyvsp[0].ttype);
    if (yyvsp[-1].code == NEGATE_EXPR && ((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == INTEGER_CST)
      (((yyval.ttype)->common.lang_flag_0)) = 1;
    overflow_warning (yyval.ttype);
  ;
    break;}
case 190:
{ tree label = lookup_label (yyvsp[0].ttype);
    if (label == (tree) 
                ((void *)0)
                         )
      yyval.ttype = null_pointer_node;
    else
      {
        ((label)->common.used_flag) = 1;
        yyval.ttype = build1 (ADDR_EXPR, ptr_type_node, label);
        ((yyval.ttype)->common.constant_flag) = 1;
      }
  ;
    break;}
case 191:
{ if (((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == COMPONENT_REF
        && ((((yyvsp[0].ttype)->exp.operands[1]))->decl.bit_field_flag))
      error ("sizeof applied to a bit-field");




    if (((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == COMPOUND_EXPR
        && (((n64_enum_tree_code) (((yyvsp[0].ttype)->common.type))->common.code) == ARRAY_TYPE
     || ((n64_enum_tree_code) (((yyvsp[0].ttype)->common.type))->common.code) == FUNCTION_TYPE))
      yyvsp[0].ttype = default_conversion (yyvsp[0].ttype);
    else if (((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == TREE_LIST)
             {
        tree t = ((yyvsp[0].ttype)->list.value);
        if (t != (tree) 
                ((void *)0)
     
    && ((((t)->common.type)
         && ((n64_enum_tree_code) (((t)->common.type))->common.code) == FUNCTION_TYPE)
         || is_overloaded_fn (t)))
   pedwarn ("ANSI C++ forbids taking the sizeof a function type");
      }
    yyval.ttype = c_sizeof (((yyvsp[0].ttype)->common.type)); ;
    break;}
case 192:
{ yyval.ttype = c_sizeof (groktypename (yyvsp[-1].ttype)); ;
    break;}
case 193:
{ yyval.ttype = grok_alignof (yyvsp[0].ttype); ;
    break;}
case 194:
{ yyval.ttype = c_alignof (groktypename (yyvsp[-1].ttype)); ;
    break;}
case 195:
{ yyval.ttype = build_new ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              , yyvsp[-1].itype); ;
    break;}
case 196:
{ yyval.ttype = build_new ((tree) 
                          ((void *)0)
                                   , yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-2].itype); ;
    break;}
case 197:
{ yyval.ttype = build_new (yyvsp[-1].ttype, yyvsp[0].ttype, (tree) 
                                                           ((void *)0)
                                                                    , yyvsp[-2].itype); ;
    break;}
case 198:
{ yyval.ttype = build_new (yyvsp[-2].ttype, yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-3].itype); ;
    break;}
case 199:
{ yyval.ttype = build_new ((tree) 
                          ((void *)0)
                                   , groktypename(yyvsp[-1].ttype),
      (tree) 
     ((void *)0)
              , yyvsp[-3].itype); ;
    break;}
case 200:
{ yyval.ttype = build_new ((tree) 
                          ((void *)0)
                                   , groktypename(yyvsp[-2].ttype), yyvsp[0].ttype, yyvsp[-4].itype); ;
    break;}
case 201:
{ yyval.ttype = build_new (yyvsp[-3].ttype, groktypename(yyvsp[-1].ttype), (tree) 
                                                                          ((void *)0)
                                                                                   , yyvsp[-4].itype); ;
    break;}
case 202:
{ yyval.ttype = build_new (yyvsp[-4].ttype, groktypename(yyvsp[-2].ttype), yyvsp[0].ttype, yyvsp[-5].itype); ;
    break;}
case 203:
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, (tree) 
                                              ((void *)0)
                                                       , 0, yyvsp[-1].itype); ;
    break;}
case 204:
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, (tree) 
                                              ((void *)0)
                                                       , 1, yyvsp[-3].itype);
    if (yychar == -2)
      yychar = yylex(); ;
    break;}
case 205:
{ yyval.ttype = delete_sanity (yyvsp[0].ttype, yyvsp[-2].ttype, 2, yyvsp[-4].itype);
    if (yychar == -2)
      yychar = yylex(); ;
    break;}
case 206:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 207:
{
    yyval.ttype = yyvsp[-1].ttype;
    pedwarn ("old style placement syntax, use () instead");
  ;
    break;}
case 208:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 209:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 210:
{
    cp_error ("`%T' is not a valid expression", yyvsp[-1].ttype);
    yyval.ttype = error_mark_node;
  ;
    break;}
case 211:
{
    if (pedantic)
      pedwarn ("ANSI C++ forbids initialization of new expression with `='");
    yyval.ttype = yyvsp[0].ttype;
  ;
    break;}
case 212:
{ yyvsp[-1].ttype = tree_cons ((tree) 
                              ((void *)0)
                                       , yyvsp[-1].ttype, void_list_node);
    ((yyvsp[-1].ttype)->common.unsigned_flag) = 1;
    yyval.ttype = build_parse_node (CALL_EXPR, (tree) 
                                              ((void *)0)
                                                       , yyvsp[-1].ttype,
      (tree) 
     ((void *)0)
              ); ;
    break;}
case 213:
{ yyvsp[-1].ttype = tree_cons ((tree) 
                              ((void *)0)
                                       , yyvsp[-1].ttype, void_list_node);
    ((yyvsp[-1].ttype)->common.unsigned_flag) = 1;
    yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, yyvsp[-1].ttype, (tree) 
                                                                            ((void *)0)
                                                                                     ); ;
    break;}
case 215:
{ yyval.ttype = reparse_absdcl_as_casts (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 216:
{
    tree init = build_nt (CONSTRUCTOR, (tree) 
                                      ((void *)0)
                                               ,
     nreverse (yyvsp[-2].ttype));
    if (pedantic)
      pedwarn ("ANSI C++ forbids constructor-expressions");

    (((init)->common.lang_flag_4)) = 1;

    yyval.ttype = reparse_absdcl_as_casts (yyval.ttype, init);
  ;
    break;}
case 218:
{ yyval.ttype = build_x_binary_op (MEMBER_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 219:
{ yyval.ttype = build_m_component_ref (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 220:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 221:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 222:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 223:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 224:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 225:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 226:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 227:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 228:
{ yyval.ttype = build_x_binary_op (LT_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 229:
{ yyval.ttype = build_x_binary_op (GT_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 230:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 231:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 232:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 233:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 234:
{ yyval.ttype = build_x_binary_op (yyvsp[-1].code, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 235:
{ yyval.ttype = build_x_binary_op (TRUTH_ANDIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 236:
{ yyval.ttype = build_x_binary_op (TRUTH_ORIF_EXPR, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 237:
{ yyval.ttype = build_x_conditional_expr (yyval.ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 238:
{ yyval.ttype = build_modify_expr (yyval.ttype, NOP_EXPR, yyvsp[0].ttype);
                  (((yyval.ttype)->exp.complexity) = (int)(MODIFY_EXPR)); ;
    break;}
case 239:
{ register tree rval;
    if ((rval = build_opfncall (MODIFY_EXPR, (3), yyval.ttype, yyvsp[0].ttype,
          make_node (yyvsp[-1].code))))
      yyval.ttype = rval;
    else
      yyval.ttype = build_modify_expr (yyval.ttype, yyvsp[-1].code, yyvsp[0].ttype); ;
    break;}
case 240:
{ yyval.ttype = build_throw ((tree) 
                            ((void *)0)
                                     ); ;
    break;}
case 241:
{ yyval.ttype = build_throw (yyvsp[0].ttype); ;
    break;}
case 242:
{ yyval.ttype = build_parse_node (BIT_NOT_EXPR, yyvsp[0].ttype); ;
    break;}
case 250:
{ yyval.ttype = build_parse_node (INDIRECT_REF, yyvsp[0].ttype); ;
    break;}
case 251:
{ yyval.ttype = build_parse_node (ADDR_EXPR, yyvsp[0].ttype); ;
    break;}
case 252:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 255:
{ yyval.ttype = finish_decl_parsing (yyvsp[-1].ttype); ;
    break;}
case 256:
{
    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == BIT_NOT_EXPR)
      yyval.ttype = build_x_unary_op (BIT_NOT_EXPR, ((yyval.ttype)->exp.operands[0]));
    else if (((yyval.ttype)->common.lang_flag_2))
      {
        tree op = yyval.ttype;
        yyval.ttype = lookup_name (op, 0);
        if (yyval.ttype == (tree) 
                          ((void *)0)
                                   )
   {
     if (op != ansi_opname[ERROR_MARK])
       error ("operator %s not defined",
       operator_name_string (op));
     yyval.ttype = error_mark_node;
   }
      }
    else
      yyval.ttype = do_identifier (yyval.ttype);
  ;
    break;}
case 259:
{ yyval.ttype = combine_strings (yyval.ttype); ;
    break;}
case 260:
{ char cxx_class;
    yyval.ttype = yyvsp[-1].ttype;
    cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (yyval.ttype)->common.code))]);
    if (cxx_class == 'e' || cxx_class == '1'
        || cxx_class == '2' || cxx_class == '<')

      (((yyval.ttype)->exp.complexity) = (int)(ERROR_MARK)); ;
    break;}
case 261:
{ char cxx_class;
    yyval.ttype = reparse_decl_as_expr ((tree) 
                                       ((void *)0)
                                                , yyvsp[-1].ttype);
    cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (yyval.ttype)->common.code))]);
    if (cxx_class == 'e' || cxx_class == '1'
        || cxx_class == '2' || cxx_class == '<')

      (((yyval.ttype)->exp.complexity) = (int)(ERROR_MARK)); ;
    break;}
case 262:
{ yyval.ttype = error_mark_node; ;
    break;}
case 263:
{ if (current_function_decl == 0)
      {
        error ("braced-group within expression allowed only inside a function");
        goto yyerrlab1;
      }
    keep_next_level ();
    yyval.ttype = expand_start_stmt_expr (); ;
    break;}
case 264:
{ tree rtl_exp;
    if (pedantic)
      pedwarn ("ANSI C++ forbids braced-groups within expressions");
    rtl_exp = expand_end_stmt_expr (yyvsp[-2].ttype);

    ((rtl_exp)->common.side_effects_flag) = 1;

    if (((n64_enum_tree_code) (yyvsp[-1].ttype)->common.code) == BLOCK)
      {

        yyval.ttype = build (BIND_EXPR, ((rtl_exp)->common.type),
      (tree) 
     ((void *)0)
              , rtl_exp, yyvsp[-1].ttype);



        delete_block (yyvsp[-1].ttype);
      }
    else
      yyval.ttype = yyvsp[-1].ttype;
  ;
    break;}
case 265:
{
                  yyval.ttype = build_x_function_call (yyvsp[-3].ttype, yyvsp[-1].ttype, current_class_decl);

                  do_pending_templates ();
                ;
    break;}
case 266:
{
                  if (((n64_enum_tree_code) (yyvsp[-1].ttype)->common.code) == CALL_EXPR
                      && ((yyvsp[-1].ttype)->common.type) != void_type_node)
             yyval.ttype = require_complete_type (yyvsp[-1].ttype);
                  else
                    yyval.ttype = yyvsp[-1].ttype;
                ;
    break;}
case 267:
{
    yyval.ttype = build_x_function_call (yyval.ttype, (tree) 
                                                     ((void *)0)
                                                              , current_class_decl);
    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == CALL_EXPR
        && ((yyval.ttype)->common.type) != void_type_node)
      yyval.ttype = require_complete_type (yyval.ttype);
                ;
    break;}
case 268:
{ yyval.ttype = grok_array_decl (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 269:
{




    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == CP_OFFSET_REF)
      yyval.ttype = resolve_offset_ref (yyval.ttype);
    yyval.ttype = build_x_unary_op (POSTINCREMENT_EXPR, yyval.ttype); ;
    break;}
case 270:
{ if (((n64_enum_tree_code) (yyval.ttype)->common.code) == CP_OFFSET_REF)
      yyval.ttype = resolve_offset_ref (yyval.ttype);
    yyval.ttype = build_x_unary_op (POSTDECREMENT_EXPR, yyval.ttype); ;
    break;}
case 271:
{ if (current_class_decl)
      {



        yyval.ttype = current_class_decl;
      }
    else if (current_function_decl
      && (((current_function_decl)->decl.lang_specific)->decl_flags.static_function))
      {
        error ("`this' is unavailable for static member functions");
        yyval.ttype = error_mark_node;
      }
    else
      {
        if (current_function_decl)
   error ("invalid use of `this' in non-member function");
        else
   error ("invalid use of `this' at top level");
        yyval.ttype = error_mark_node;
      }
  ;
    break;}
case 272:
{
    tree type;
    tree id = yyval.ttype;


    if (yyvsp[-1].ttype == error_mark_node)
      {
        yyval.ttype = error_mark_node;
        break;
      }
      {
        if (id == ridpointers[(int) RID_CONST])
          type = build_type_variant (integer_type_node, 1, 0);
        else if (id == ridpointers[(int) RID_VOLATILE])
          type = build_type_variant (integer_type_node, 0, 1);
        else my_friendly_abort (79);
        yyval.ttype = build_c_cast (type, build_compound_expr (yyvsp[-1].ttype), 1);
      }
  ;
    break;}
case 274:
{ dont_allow_type_definitions = "inside dynamic_cast"; ;
    break;}
case 275:
{ dont_allow_type_definitions = 0; ;
    break;}
case 276:
{ tree type = groktypename (yyvsp[-5].ttype);
    yyval.ttype = build_dynamic_cast (type, yyvsp[-1].ttype); ;
    break;}
case 277:
{ dont_allow_type_definitions = "inside static_cast"; ;
    break;}
case 278:
{ dont_allow_type_definitions = 0; ;
    break;}
case 279:
{ tree type = groktypename (yyvsp[-5].ttype);
    yyval.ttype = build_static_cast (type, yyvsp[-1].ttype); ;
    break;}
case 280:
{ dont_allow_type_definitions = "inside reinterpret_cast"; ;
    break;}
case 281:
{ dont_allow_type_definitions = 0; ;
    break;}
case 282:
{ tree type = groktypename (yyvsp[-5].ttype);
    yyval.ttype = build_reinterpret_cast (type, yyvsp[-1].ttype); ;
    break;}
case 283:
{ dont_allow_type_definitions = "inside const_cast"; ;
    break;}
case 284:
{ dont_allow_type_definitions = 0; ;
    break;}
case 285:
{ tree type = groktypename (yyvsp[-5].ttype);
    yyval.ttype = build_const_cast (type, yyvsp[-1].ttype); ;
    break;}
case 286:
{ yyval.ttype = build_typeid (yyvsp[-1].ttype); ;
    break;}
case 287:
{ tree type = groktypename (yyvsp[-1].ttype);
    yyval.ttype = get_typeid (((type)->type.main_variant)); ;
    break;}
case 288:
{
  do_scoped_id:
    yyval.ttype = (((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->global_value);
    if (yychar == -2)
      yychar = yylex();
    if (! yyval.ttype)
      {
        if (yychar == '(' || yychar == 300)
   yyval.ttype = implicitly_declare (yyvsp[0].ttype);
        else
   {
     if ((((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->global_value) != error_mark_node)
       error ("undeclared variable `%s' (first use here)",
       ((yyvsp[0].ttype)->identifier.pointer));
     yyval.ttype = error_mark_node;

     (((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->global_value) = error_mark_node;
   }
      }
    else
      {
        if (((n64_enum_tree_code) (yyval.ttype)->common.code) == ADDR_EXPR)
   assemble_external (((yyval.ttype)->exp.operands[0]));
        else
   assemble_external (yyval.ttype);
        ((yyval.ttype)->common.used_flag) = 1;
      }
    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == CONST_DECL)
      {

        yyval.ttype = ((yyval.ttype)->decl.initial);


        yyval.ttype = build1 (NOP_EXPR, ((yyval.ttype)->common.type), yyval.ttype);
        ((yyval.ttype)->common.constant_flag) = 1;
      }

  ;
    break;}
case 289:
{
    got_scope = (tree) 
               ((void *)0)
                        ;
    if (((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == IDENTIFIER_NODE)
      goto do_scoped_id;
    yyval.ttype = yyvsp[0].ttype;
  ;
    break;}
case 290:
{ yyval.ttype = build_offset_ref ((((yyval.ttype)->exp.operands[0])), (((yyval.ttype)->exp.operands[1]))); ;
    break;}
case 291:
{ yyval.ttype = build_member_call ((((yyval.ttype)->exp.operands[0])), (((yyval.ttype)->exp.operands[1])), yyvsp[-1].ttype); ;
    break;}
case 292:
{ yyval.ttype = build_member_call ((((yyval.ttype)->exp.operands[0])), (((yyval.ttype)->exp.operands[1])), (tree) 
                                                                        ((void *)0)
                                                                                 ); ;
    break;}
case 293:
{ got_object = (tree) 
              ((void *)0)
                       ;
    yyval.ttype = build_component_ref (yyval.ttype, yyvsp[0].ttype, (tree) 
                                                                   ((void *)0)
                                                                            , 1); ;
    break;}
case 294:
{ got_object = (tree) 
              ((void *)0)
                       ;
    yyval.ttype = build_object_ref (yyval.ttype, (((yyvsp[0].ttype)->exp.operands[0])), (((yyvsp[0].ttype)->exp.operands[1]))); ;
    break;}
case 295:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    yyval.ttype = build_method_call (yyval.ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, (tree) 
                                                                                   ((void *)0)
                                                                                            ,
       ((3)|(4)));

  ;
    break;}
case 296:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    yyval.ttype = build_method_call (yyval.ttype, yyvsp[-1].ttype, (tree) 
                                                                  ((void *)0)
                                                                           , (tree) 
                                                                             ((void *)0)
                                                                                      ,
       ((3)|(4)));

  ;
    break;}
case 297:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    if ((((((((((yyvsp[-3].ttype)->exp.operands[0])))->common.type)))->type.lang_specific)?((((((((yyvsp[-3].ttype)->exp.operands[0])))->common.type)))->type.lang_specific)->type_flags.is_signature:0))
      {
        warning ("signature name in scope resolution ignored");
        yyval.ttype = build_method_call (yyval.ttype, (((yyvsp[-3].ttype)->exp.operands[1])), yyvsp[-1].ttype, (tree) 
                                                                                             ((void *)0)
                                                                                                      ,
           ((3)|(4)));
      }
    else
      yyval.ttype = build_scoped_method_call (yyval.ttype, (((yyvsp[-3].ttype)->exp.operands[0])), (((yyvsp[-3].ttype)->exp.operands[1])), yyvsp[-1].ttype);
  ;
    break;}
case 298:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    if ((((((((((yyvsp[-1].ttype)->exp.operands[0])))->common.type)))->type.lang_specific)?((((((((yyvsp[-1].ttype)->exp.operands[0])))->common.type)))->type.lang_specific)->type_flags.is_signature:0))
      {
        warning ("signature name in scope resolution ignored");
        yyval.ttype = build_method_call (yyval.ttype, (((yyvsp[-1].ttype)->exp.operands[1])), (tree) 
                                                                            ((void *)0)
                                                                                     , (tree) 
                                                                                       ((void *)0)
                                                                                                ,
           ((3)|(4)));
      }
    else
      yyval.ttype = build_scoped_method_call (yyval.ttype, (((yyvsp[-1].ttype)->exp.operands[0])), (((yyvsp[-1].ttype)->exp.operands[1])), (tree) 
                                                                                                        ((void *)0)
                                                                                                                 );
  ;
    break;}
case 299:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    if ((((struct n64_tag_lang_identifier *)(yyvsp[-1].ttype))->global_value)
        && (((n64_enum_tree_code) (((yyvsp[-3].ttype)->common.type))->common.code)
     != ((n64_enum_tree_code) ((((((struct n64_tag_lang_identifier *)(yyvsp[-1].ttype))->global_value))->common.type))->common.code)))
      cp_error ("`%E' is not of type `%T'", yyvsp[-3].ttype, yyvsp[-1].ttype);
    yyval.ttype = convert (void_type_node, yyvsp[-3].ttype);
  ;
    break;}
case 300:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    if (yyvsp[-4].ttype != yyvsp[-1].ttype)
      cp_error ("destructor specifier `%T::~%T()' must have matching names", yyvsp[-4].ttype, yyvsp[-1].ttype);
    if (((n64_enum_tree_code) (((yyvsp[-5].ttype)->common.type))->common.code)
        != ((n64_enum_tree_code) ((((((struct n64_tag_lang_identifier *)(yyvsp[-4].ttype))->global_value))->common.type))->common.code))
      cp_error ("`%E' is not of type `%T'", yyvsp[-5].ttype, yyvsp[-4].ttype);
    yyval.ttype = convert (void_type_node, yyvsp[-5].ttype);
  ;
    break;}
case 301:
{
    got_object = (tree) 
                ((void *)0)
                         ;
    yyval.ttype = error_mark_node;
  ;
    break;}
case 302:
{ yyval.itype = 0; ;
    break;}
case 303:
{ got_scope = (tree) 
             ((void *)0)
                      ; yyval.itype = 1; ;
    break;}
case 304:
{ yyval.itype = 0; ;
    break;}
case 305:
{ got_scope = (tree) 
             ((void *)0)
                      ; yyval.itype = 1; ;
    break;}
case 306:
{ yyval.ttype = boolean_true_node; ;
    break;}
case 307:
{ yyval.ttype = boolean_false_node; ;
    break;}
case 309:
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 310:
{
    if (! current_function_parms_stored)
      store_parm_decls ();
    setup_vtbl_ptr ();



    keep_next_level ();
  ;
    break;}
case 311:
{ got_object = ((yyval.ttype)->common.type); ;
    break;}
case 312:
{
    yyval.ttype = build_x_arrow (yyval.ttype);
    got_object = ((yyval.ttype)->common.type);
  ;
    break;}
case 313:
{ tree d = get_decl_list (yyvsp[-2].ttype);
    int yes = suspend_momentary ();
    d = start_decl (yyvsp[-1].ttype, d, 0, (tree) 
                                          ((void *)0)
                                                   );
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , (tree) 
                                 ((void *)0)
                                          , 0, 0);
    resume_momentary (yes);
    if ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == UNINSTANTIATED_P_TYPE))
      note_got_semicolon (yyvsp[-2].ttype);
  ;
    break;}
case 314:
{ tree d, specs, attrs;
    int yes;
    split_specs_attrs (yyvsp[-2].ttype, &specs, &attrs);
    yes = suspend_momentary ();
    d = start_decl (yyvsp[-1].ttype, specs, 0, (tree) 
                                              ((void *)0)
                                                       );
    cplus_decl_attributes (d, (tree) 
                             ((void *)0)
                                      , attrs);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , (tree) 
                                 ((void *)0)
                                          , 0, 0);
    resume_momentary (yes);
    note_list_got_semicolon (yyvsp[-2].ttype);
  ;
    break;}
case 315:
{
    resume_momentary (yyvsp[-1].itype);
    if ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == UNINSTANTIATED_P_TYPE))
      note_got_semicolon (yyvsp[-2].ttype);
  ;
    break;}
case 316:
{
    resume_momentary (yyvsp[-1].itype);
    note_list_got_semicolon (yyvsp[-2].ttype);
  ;
    break;}
case 317:
{ resume_momentary (yyvsp[-1].itype); ;
    break;}
case 318:
{
    shadow_tag (yyvsp[-1].ttype);
    note_list_got_semicolon (yyvsp[-1].ttype);
  ;
    break;}
case 319:
{ warning ("empty declaration"); ;
    break;}
case 322:
{ yyval.ttype = build_parse_node (CALL_EXPR, (tree) 
                                            ((void *)0)
                                                     , empty_parms (),
      (tree) 
     ((void *)0)
              ); ;
    break;}
case 323:
{ yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, empty_parms (),
      (tree) 
     ((void *)0)
              ); ;
    break;}
case 324:
{ yyval.ttype = build_decl_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 325:
{ yyval.ttype = build_decl_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 326:
{ yyval.ttype = build_decl_list (get_decl_list (yyval.ttype), yyvsp[0].ttype); ;
    break;}
case 327:
{ yyval.ttype = build_decl_list (yyval.ttype, (tree) 
                                             ((void *)0)
                                                      ); ;
    break;}
case 328:
{ yyval.ttype = build_decl_list (yyval.ttype, (tree) 
                                             ((void *)0)
                                                      ); ;
    break;}
case 331:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 332:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 333:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyval.ttype, chainon (yyvsp[-1].ttype, yyvsp[0].ttype)); ;
    break;}
case 334:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[-1].ttype, chainon (yyvsp[0].ttype, yyval.ttype)); ;
    break;}
case 335:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[-1].ttype, chainon (yyvsp[0].ttype, yyval.ttype)); ;
    break;}
case 336:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[-2].ttype,
           chainon (yyvsp[-1].ttype, chainon (yyvsp[0].ttype, yyval.ttype))); ;
    break;}
case 337:
{ if (extra_warnings)
      warning ("`%s' is not at beginning of declaration",
        ((yyval.ttype)->identifier.pointer));
    yyval.ttype = build_decl_list ((tree) 
                                  ((void *)0)
                                           , yyval.ttype); ;
    break;}
case 338:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 339:
{ if (extra_warnings)
      warning ("`%s' is not at beginning of declaration",
        ((yyvsp[0].ttype)->identifier.pointer));
    yyval.ttype = decl_tree_cons ((tree) 
                                 ((void *)0)
                                          , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 340:
{ yyval.ttype = decl_tree_cons (yyvsp[0].ttype, (tree) 
                                               ((void *)0)
                                                        , yyvsp[-1].ttype); ;
    break;}
case 341:
{ yyval.ttype = decl_tree_cons (yyvsp[0].ttype, (tree) 
                                               ((void *)0)
                                                        , (tree) 
                                                          ((void *)0)
                                                                   ); ;
    break;}
case 342:
{ ((yyval.ttype)->common.static_flag) = 1; ;
    break;}
case 343:
{ yyval.ttype = (((struct n64_tag_lang_identifier *)(yyval.ttype))->x ? ((struct n64_tag_lang_identifier *)(yyval.ttype))->x->as_list : 0); ;
    break;}
case 344:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype);
    ((yyval.ttype)->common.static_flag) = 1; ;
    break;}
case 345:
{ if (extra_warnings && ((yyval.ttype)->common.static_flag))
      warning ("`%s' is not at beginning of declaration",
        ((yyvsp[0].ttype)->identifier.pointer));
    yyval.ttype = decl_tree_cons ((tree) 
                                 ((void *)0)
                                          , yyvsp[0].ttype, yyval.ttype);
    ((yyval.ttype)->common.static_flag) = ((yyvsp[-1].ttype)->common.static_flag); ;
    break;}
case 346:
{ yyval.ttype = decl_tree_cons (yyvsp[0].ttype, (tree) 
                                               ((void *)0)
                                                        , yyvsp[-1].ttype); ;
    break;}
case 347:
{ yyval.ttype = decl_tree_cons (yyvsp[0].ttype, (tree) 
                                               ((void *)0)
                                                        , (tree) 
                                                          ((void *)0)
                                                                   ); ;
    break;}
case 348:
{ yyval.ttype = get_decl_list (yyval.ttype); ;
    break;}
case 349:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 350:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 351:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[-1].ttype, chainon (yyvsp[0].ttype, yyval.ttype)); ;
    break;}
case 352:
{ yyval.ttype = build_decl_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 353:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 357:
{ yyval.ttype = ((yyvsp[-1].ttype)->common.type);
    if (pedantic && !in_system_header)
      pedwarn ("ANSI C++ forbids `typeof'"); ;
    break;}
case 358:
{ yyval.ttype = groktypename (yyvsp[-1].ttype);
    if (pedantic && !in_system_header)
      pedwarn ("ANSI C++ forbids `typeof'"); ;
    break;}
case 359:
{ tree type = ((yyvsp[-1].ttype)->common.type);

    if ((((type)->type.lang_flag_5)))
      {
        sorry ("sigof type specifier");
        yyval.ttype = type;
      }
    else
      {
        error ("`sigof' applied to non-aggregate expression");
        yyval.ttype = error_mark_node;
      }
  ;
    break;}
case 360:
{ tree type = groktypename (yyvsp[-1].ttype);

    if ((((type)->type.lang_flag_5)))
      {
        sorry ("sigof type specifier");
        yyval.ttype = type;
      }
    else
      {
        error("`sigof' applied to non-aggregate type");
        yyval.ttype = error_mark_node;
      }
  ;
    break;}
case 370:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 371:
{ if (((yyvsp[-1].ttype)->common.chain)) yyvsp[-1].ttype = combine_strings (yyvsp[-1].ttype); yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 372:
{ split_specs_attrs (yyvsp[-5].ttype, &current_declspecs,
         &prefix_attributes);
    if (((n64_enum_tree_code) (current_declspecs)->common.code) != TREE_LIST)
      current_declspecs = get_decl_list (current_declspecs);
    if (have_extern_spec && !used_extern_spec)
      {
        current_declspecs = decl_tree_cons
   ((tree) 
   ((void *)0)
            , get_identifier ("extern"),
    current_declspecs);
        used_extern_spec = 1;
      }
    yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_decl (yyvsp[-4].ttype, current_declspecs, 1, yyvsp[-3].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[-1].ttype, prefix_attributes); ;
    break;}
case 373:
{ cp_finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype, 0, (128));
    yyval.itype = yyvsp[-2].itype; ;
    break;}
case 374:
{ tree d;
    split_specs_attrs (yyvsp[-4].ttype, &current_declspecs,
         &prefix_attributes);
    if (((n64_enum_tree_code) (current_declspecs)->common.code) != TREE_LIST)
      current_declspecs = get_decl_list (current_declspecs);
    if (have_extern_spec && !used_extern_spec)
      {
        current_declspecs = decl_tree_cons
   ((tree) 
   ((void *)0)
            , get_identifier ("extern"),
    current_declspecs);
        used_extern_spec = 1;
      }
    yyval.itype = suspend_momentary ();
    d = start_decl (yyvsp[-3].ttype, current_declspecs, 0, yyvsp[-2].ttype);
    cplus_decl_attributes (d, yyvsp[0].ttype, prefix_attributes);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , yyvsp[-1].ttype, 0, 0); ;
    break;}
case 375:
{ yyval.ttype = start_decl (yyvsp[-4].ttype, current_declspecs, 1, yyvsp[-3].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[-1].ttype, prefix_attributes); ;
    break;}
case 376:
{ cp_finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype, 0, (128)); ;
    break;}
case 377:
{ yyval.ttype = start_decl (yyvsp[-3].ttype, current_declspecs, 0, yyvsp[-2].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes);
    cp_finish_decl (yyval.ttype, (tree) 
                                ((void *)0)
                                         , yyvsp[-1].ttype, 0, 0); ;
    break;}
case 378:
{ split_specs_attrs (yyvsp[-5].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_decl (yyvsp[-4].ttype, current_declspecs, 1, yyvsp[-3].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[-1].ttype, prefix_attributes); ;
    break;}
case 379:
{ cp_finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype, 0, (128));
    yyval.itype = yyvsp[-2].itype; ;
    break;}
case 380:
{ tree d;
    split_specs_attrs (yyvsp[-4].ttype, &current_declspecs,
         &prefix_attributes);
    yyval.itype = suspend_momentary ();
    d = start_decl (yyvsp[-3].ttype, current_declspecs, 0, yyvsp[-2].ttype);
    cplus_decl_attributes (d, yyvsp[0].ttype, prefix_attributes);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , yyvsp[-1].ttype, 0, 0); ;
    break;}
case 381:
{ current_declspecs = (tree) 
                     ((void *)0)
                              ;
    prefix_attributes = (tree) 
                       ((void *)0)
                                ;
    yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_decl (yyvsp[-4].ttype, current_declspecs, 1, yyvsp[-3].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[-1].ttype, prefix_attributes); ;
    break;}
case 382:
{ cp_finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype, 0, (128));
    yyval.itype = yyvsp[-2].itype; ;
    break;}
case 383:
{ tree d;
    current_declspecs = (tree) 
                       ((void *)0)
                                ;
    prefix_attributes = (tree) 
                       ((void *)0)
                                ;
    yyval.itype = suspend_momentary ();
    d = start_decl (yyvsp[-3].ttype, current_declspecs, 0, yyvsp[-2].ttype);
    cplus_decl_attributes (d, yyvsp[0].ttype, prefix_attributes);
    cp_finish_decl (d, (tree) 
                      ((void *)0)
                               , yyvsp[-1].ttype, 0, 0); ;
    break;}
case 384:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 385:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 386:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 387:
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 388:
{ yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 389:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 390:
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 391:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 392:
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, (tree) 
                                                ((void *)0)
                                                         ); ;
    break;}
case 393:
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, build_tree_list ((tree) 
                                                                  ((void *)0)
                                                                           , yyvsp[-1].ttype)); ;
    break;}
case 394:
{ yyval.ttype = build_tree_list (yyvsp[-5].ttype, tree_cons ((tree) 
                                                            ((void *)0)
                                                                     , yyvsp[-3].ttype, yyvsp[-1].ttype)); ;
    break;}
case 395:
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 400:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyvsp[0].ttype); ;
    break;}
case 401:
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list ((tree) 
                                                          ((void *)0)
                                                                   , yyvsp[0].ttype)); ;
    break;}
case 402:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 403:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 405:
{ yyval.ttype = build_nt (CONSTRUCTOR, (tree) 
                                      ((void *)0)
                                               , (tree) 
                                                 ((void *)0)
                                                          );
    (((yyval.ttype)->common.lang_flag_4)) = 1; ;
    break;}
case 406:
{ yyval.ttype = build_nt (CONSTRUCTOR, (tree) 
                                      ((void *)0)
                                               , nreverse (yyvsp[-1].ttype));
    (((yyval.ttype)->common.lang_flag_4)) = 1; ;
    break;}
case 407:
{ yyval.ttype = build_nt (CONSTRUCTOR, (tree) 
                                      ((void *)0)
                                               , nreverse (yyvsp[-2].ttype));
    (((yyval.ttype)->common.lang_flag_4)) = 1; ;
    break;}
case 408:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 409:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 410:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 411:
{ yyval.ttype = build_tree_list (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 412:
{ yyval.ttype = tree_cons (yyvsp[-2].ttype, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 413:
{ yyval.ttype = build_tree_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 414:
{ yyval.ttype = tree_cons (yyvsp[-2].ttype, yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 415:
{ yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_enum (yyvsp[-1].ttype); ;
    break;}
case 416:
{ yyval.ttype = finish_enum (yyvsp[-3].ttype, yyvsp[-2].ttype);
    resume_momentary ((int) yyvsp[-4].itype);
    check_for_missing_semicolon (yyvsp[-3].ttype); ;
    break;}
case 417:
{ yyval.ttype = finish_enum (start_enum (yyvsp[-2].ttype), (tree) 
                                                          ((void *)0)
                                                                   );
    check_for_missing_semicolon (yyval.ttype); ;
    break;}
case 418:
{ yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_enum (make_anon_name ()); ;
    break;}
case 419:
{ yyval.ttype = finish_enum (yyvsp[-3].ttype, yyvsp[-2].ttype);
    resume_momentary ((int) yyvsp[-5].itype);
    check_for_missing_semicolon (yyvsp[-3].ttype); ;
    break;}
case 420:
{ yyval.ttype = finish_enum (start_enum (make_anon_name()), (tree) 
                                                           ((void *)0)
                                                                    );
    check_for_missing_semicolon (yyval.ttype); ;
    break;}
case 421:
{ yyval.ttype = xref_tag (enum_type_node, yyvsp[0].ttype, (tree) 
                                                         ((void *)0)
                                                                  , 1); ;
    break;}
case 422:
{ yyval.ttype = xref_tag (enum_type_node, yyvsp[0].ttype, (tree) 
                                                         ((void *)0)
                                                                  , 1); ;
    break;}
case 423:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 424:
{
    int semi;
    tree id;






    if (yychar == -2)
      yychar = yylex();
    semi = yychar == ';';


    if (semi)
      note_got_semicolon (yyval.ttype);

    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == ENUMERAL_TYPE)
                                       ;
    else
      {
        yyval.ttype = finish_struct (yyval.ttype, yyvsp[-1].ttype, semi);
        if (semi) note_got_semicolon (yyval.ttype);
      }

    pop_obstacks ();

    id = (((((yyval.ttype)->type.name))->decl.name));
    if (id && (((struct n64_tag_lang_identifier *)(id))->class_template_info))
      {
        tree decl;






        push_obstacks (&permanent_obstack, &permanent_obstack);
        decl = copy_node (lookup_name (id, 0));
        if (((decl)->decl.lang_specific))
   copy_lang_decl (decl);
        pop_obstacks ();
        undo_template_name_overload (id, 0);
        pushdecl_top_level (decl);
      }
    if (! semi)
      check_for_missing_semicolon (yyval.ttype); ;
    break;}
case 425:
{

    if (((((yyval.ttype)->type.binfo))->vec.a[4]) && !((yyval.ttype)->type.size)
        && ! (((yyval.ttype)->type.lang_specific)->type_flags.being_defined))
      cp_error ("base clause without member specification for `%#T'",
         yyval.ttype);
  ;
    break;}
case 429:
{ if (pedantic) pedwarn ("comma at end of enumerator list"); ;
    break;}
case 431:
{ error ("storage class specifier `%s' not allowed after struct or class", ((yyvsp[0].ttype)->identifier.pointer)); ;
    break;}
case 432:
{ error ("type specifier `%s' not allowed after struct or class", ((yyvsp[0].ttype)->identifier.pointer)); ;
    break;}
case 433:
{ error ("type qualifier `%s' not allowed after struct or class", ((yyvsp[0].ttype)->identifier.pointer)); ;
    break;}
case 434:
{ error ("no body nor ';' separates two class, struct or union declarations"); ;
    break;}
case 435:
{
    yyungetc (';', 1); current_aggr = yyval.ttype; yyval.ttype = yyvsp[-1].ttype;
    if (yyvsp[-3].ttype == ridpointers[(int) RID_TEMPLATE])
      instantiate_class_template (yyval.ttype, 2);
  ;
    break;}
case 436:
{ current_aggr = yyval.ttype; yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 438:
{ current_aggr = yyval.ttype; yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 439:
{ yyungetc ('{', 1);
  aggr2:
    current_aggr = yyval.ttype;
    yyval.ttype = yyvsp[-1].ttype;
    overload_template_name (yyval.ttype, 0); ;
    break;}
case 440:
{ yyungetc (':', 1); goto aggr2; ;
    break;}
case 441:
{ current_aggr = yyval.ttype; yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 442:
{ current_aggr = yyval.ttype; yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 443:
{ yyval.ttype = xref_tag (current_aggr, yyvsp[0].ttype, (tree) 
                                                       ((void *)0)
                                                                , 0); ;
    break;}
case 444:
{ yyval.ttype = xref_tag (current_aggr, yyvsp[0].ttype, (tree) 
                                                       ((void *)0)
                                                                , 1); ;
    break;}
case 445:
{
    yyval.ttype = yyvsp[-1].ttype;
    if (yyvsp[0].ttype)
                    xref_basetypes (current_aggr, yyvsp[-2].ttype, yyvsp[-1].ttype, yyvsp[0].ttype);
  ;
    break;}
case 446:
{
    yyval.ttype = ((yyvsp[-1].ttype)->common.type);
    if (yyvsp[0].ttype)
      xref_basetypes (current_aggr, yyvsp[-1].ttype, ((yyvsp[-1].ttype)->common.type), yyvsp[0].ttype);
  ;
    break;}
case 447:
{ yyval.ttype = xref_tag (yyval.ttype, make_anon_name (), (tree) 
                                                         ((void *)0)
                                                                  , 0);
    yyungetc ('{', 1); ;
    break;}
case 450:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 451:
{ yyungetc(':', 1); yyval.ttype = (tree) 
                                 ((void *)0)
                                          ; ;
    break;}
case 452:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 454:
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 455:
{
    tree type;
    type = (((yyval.ttype)->common.type));
    if (! is_aggr_typedef (yyval.ttype, 1))
      yyval.ttype = (tree) 
                   ((void *)0)
                            ;
    else if (current_aggr == signature_type_node
      && (! type) && (! (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0)))
      {
        error ("class name not allowed as base signature");
        yyval.ttype = (tree) 
                     ((void *)0)
                              ;
      }
    else if (current_aggr == signature_type_node)
      {
        sorry ("signature inheritance, base type `%s' ignored",
        ((yyval.ttype)->identifier.pointer));
        yyval.ttype = build_tree_list ((tree)access_public, yyval.ttype);
      }
    else if (type && (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
      {
        error ("signature name not allowed as base class");
        yyval.ttype = (tree) 
                     ((void *)0)
                              ;
      }
    else
      yyval.ttype = build_tree_list ((tree)access_default, yyval.ttype);
  ;
    break;}
case 456:
{
    tree type;
    type = (((yyvsp[0].ttype)->common.type));
    if (current_aggr == signature_type_node)
      error ("access and source specifiers not allowed in signature");
    if (! is_aggr_typedef (yyvsp[0].ttype, 1))
      yyval.ttype = (tree) 
                   ((void *)0)
                            ;
    else if (current_aggr == signature_type_node
      && (! type) && (! (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0)))
      {
        error ("class name not allowed as base signature");
        yyval.ttype = (tree) 
                     ((void *)0)
                              ;
      }
    else if (current_aggr == signature_type_node)
      {
        sorry ("signature inheritance, base type `%s' ignored",
        ((yyval.ttype)->identifier.pointer));
        yyval.ttype = build_tree_list ((tree)access_public, yyvsp[0].ttype);
      }
    else if (type && (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
      {
        error ("signature name not allowed as base class");
        yyval.ttype = (tree) 
                     ((void *)0)
                              ;
      }
    else
      yyval.ttype = build_tree_list ((tree) yyval.ttype, yyvsp[0].ttype);
  ;
    break;}
case 458:
{
    if (current_aggr == signature_type_node)
      {
        if ((((((yyvsp[-1].ttype)->common.type))->type.lang_flag_5)))
   {
     sorry ("`sigof' as base signature specifier");

     yyval.ttype = yyvsp[-1].ttype;
   }
        else
   {
     error ("`sigof' applied to non-aggregate expression");
     yyval.ttype = error_mark_node;
   }
      }
    else
      {
        error ("`sigof' in struct or class declaration");
        yyval.ttype = error_mark_node;
      }
  ;
    break;}
case 459:
{
    if (current_aggr == signature_type_node)
      {
        if ((((groktypename (yyvsp[-1].ttype))->type.lang_flag_5)))
   {
     sorry ("`sigof' as base signature specifier");

     yyval.ttype = yyvsp[-1].ttype;
   }
        else
   {
     error ("`sigof' applied to non-aggregate expression");
     yyval.ttype = error_mark_node;
   }
      }
    else
      {
        error ("`sigof' in struct or class declaration");
        yyval.ttype = error_mark_node;
      }
  ;
    break;}
case 461:
{ if (yyval.ttype != ridpointers[(int)RID_VIRTUAL])
      sorry ("non-virtual access");
    yyval.itype = access_default_virtual; ;
    break;}
case 462:
{ int err = 0;
    if (yyvsp[-1].itype == access_protected)
      {
        warning ("`protected' access not implemented");
        yyvsp[-1].itype = access_public;
        err++;
      }
    else if (yyvsp[-1].itype == access_public)
      {
        if (yyvsp[-2].itype == access_private)
   {
   mixed:
     error ("base class cannot be public and private");
   }
        else if (yyvsp[-2].itype == access_default_virtual)
   yyval.itype = access_public_virtual;
      }
    else
      {
        if (yyvsp[-2].itype == access_public)
   goto mixed;
        else if (yyvsp[-2].itype == access_default_virtual)
   yyval.itype = access_private_virtual;
      }
  ;
    break;}
case 463:
{ if (yyvsp[-1].ttype != ridpointers[(int)RID_VIRTUAL])
      sorry ("non-virtual access");
    if (yyval.itype == access_public)
      yyval.itype = access_public_virtual;
    else if (yyval.itype == access_private)
      yyval.itype = access_private_virtual; ;
    break;}
case 464:
{ tree t = yyvsp[-1].ttype;
    push_obstacks_nochange ();
    end_temporary_allocation ();

    if (! (((t)->type.lang_flag_5)))
      {
        t = yyvsp[-1].ttype = make_lang_type (RECORD_TYPE);
        ((t)->type.name) = get_identifier ("erroneous type");
      }
    if (((t)->type.size))
      duplicate_tag_error (t);
                  if (((t)->type.size) || (((t)->type.lang_specific)->type_flags.being_defined))
                    {
                      t = make_lang_type (((n64_enum_tree_code) (t)->common.code));
                      pushtag ((((((yyvsp[-1].ttype)->type.name))->decl.name)), t, 0);
                      yyvsp[-1].ttype = t;
                    }
    pushclass (t, 0);
    (((t)->type.lang_specific)->type_flags.being_defined) = 1;




    if (! (((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
      {
        extern tree pending_vtables;
        int needs_writing;
        tree name = (((((t)->type.name))->decl.name));

        if (! (((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
   {
     (((t)->type.lang_specific)->type_flags.interface_only) = interface_only;
     (((t)->type.lang_specific)->type_flags.interface_unknown = !!(interface_unknown))
                             ;
   }




        switch (write_virtuals)
   {
   case 0:
   case 1:
     needs_writing = 1;
     break;
   case 2:
     needs_writing = !! value_member (name, pending_vtables);
     break;
   case 3:
     needs_writing = ! (((t)->type.lang_specific)->type_flags.interface_only)
       && (((t)->type.lang_specific)->type_flags.interface_unknown == 0);
     break;
   default:
     needs_writing = 0;
   }
        (((t)->type.lang_specific)->type_flags.vtable_needs_writing) = needs_writing;
      }





  ;
    break;}
case 465:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 466:
{
    if (current_aggr == signature_type_node)
      yyval.ttype = build_tree_list ((tree) access_public, yyval.ttype);
    else
      yyval.ttype = build_tree_list ((tree) access_default, yyval.ttype);
  ;
    break;}
case 467:
{
    tree visspec = (tree) yyvsp[-2].itype;

    if (current_aggr == signature_type_node)
      {
        error ("access specifier not allowed in signature");
        visspec = (tree) access_public;
      }
    yyval.ttype = chainon (yyval.ttype, build_tree_list (visspec, yyvsp[0].ttype));
  ;
    break;}
case 468:
{
    if (current_aggr == signature_type_node)
      error ("access specifier not allowed in signature");
  ;
    break;}
case 469:
{ if (yyval.ttype == void_type_node) yyval.ttype = (tree) 
                                                  ((void *)0)
                                                           ;
  ;
    break;}
case 470:
{



    if (yyvsp[0].ttype != (tree) 
                         ((void *)0) 
                                   && yyvsp[0].ttype != void_type_node)
      {
        if (((yyvsp[0].ttype)->common.chain) != yyval.ttype)
   yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype);
        else
   yyval.ttype = yyvsp[0].ttype;
      }
  ;
    break;}
case 471:
{ ;
    break;}
case 472:
{ error ("missing ';' before right brace");
    yyungetc ('}', 0); ;
    break;}
case 473:
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 474:
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 475:
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 476:
{ yyval.ttype = finish_method (yyval.ttype); ;
    break;}
case 477:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 478:
{ yyval.ttype = grok_x_components (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 479:
{ yyval.ttype = grok_x_components (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 480:
{ yyval.ttype = grokfield (yyval.ttype, (tree) 
                                       ((void *)0)
                                                , yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, (tree) 
                                       ((void *)0)
                                                )); ;
    break;}
case 481:
{ yyval.ttype = grokbitfield ((tree) 
                             ((void *)0)
                                      , (tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype); ;
    break;}
case 482:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 483:
{ tree specs, attrs;
    split_specs_attrs (yyvsp[-8].ttype, &specs, &attrs);
    yyval.ttype = build_parse_node (CALL_EXPR, ((specs)->list.value),
      yyvsp[-6].ttype, yyvsp[-4].ttype);
    yyval.ttype = grokfield (yyval.ttype, ((specs)->common.chain), yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, attrs)); ;
    break;}
case 484:
{ tree specs, attrs;
    split_specs_attrs (yyvsp[-6].ttype, &specs, &attrs);
    yyval.ttype = build_parse_node (CALL_EXPR, ((specs)->list.value),
      empty_parms (), yyvsp[-4].ttype);
    yyval.ttype = grokfield (yyval.ttype, ((specs)->common.chain), yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, attrs)); ;
    break;}
case 485:
{ yyval.ttype = do_class_using_decl (yyvsp[0].ttype); ;
    break;}
case 486:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 488:
{


    if (yyval.ttype == void_type_node)
      yyval.ttype = yyvsp[0].ttype;
    else
      yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype);
  ;
    break;}
case 489:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 491:
{


    if (yyval.ttype == void_type_node)
      yyval.ttype = yyvsp[0].ttype;
    else
      yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype);
  ;
    break;}
case 496:
{ split_specs_attrs (yyvsp[-5].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[-5].ttype = current_declspecs;
    yyval.ttype = grokfield (yyval.ttype, current_declspecs, yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, prefix_attributes)); ;
    break;}
case 497:
{ split_specs_attrs (yyvsp[-4].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[-4].ttype = current_declspecs;
    yyval.ttype = grokbitfield (yyval.ttype, current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 498:
{ split_specs_attrs (yyvsp[-5].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[-5].ttype = current_declspecs;
    yyval.ttype = grokfield (yyval.ttype, current_declspecs, yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, prefix_attributes)); ;
    break;}
case 499:
{ split_specs_attrs (yyvsp[-4].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[-4].ttype = current_declspecs;
    yyval.ttype = grokbitfield (yyval.ttype, current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 500:
{ split_specs_attrs (yyvsp[-3].ttype, &current_declspecs,
         &prefix_attributes);
    yyvsp[-3].ttype = current_declspecs;
    yyval.ttype = grokbitfield ((tree) 
                               ((void *)0)
                                        , current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 501:
{ yyval.ttype = grokfield (yyval.ttype, current_declspecs, yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, prefix_attributes)); ;
    break;}
case 502:
{ yyval.ttype = grokbitfield (yyval.ttype, current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 503:
{ yyval.ttype = grokfield (yyval.ttype, current_declspecs, yyvsp[-3].ttype, yyvsp[0].ttype, yyvsp[-2].ttype,
      build_tree_list (yyvsp[-1].ttype, prefix_attributes)); ;
    break;}
case 504:
{ yyval.ttype = grokbitfield (yyval.ttype, current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 505:
{ yyval.ttype = grokbitfield ((tree) 
                             ((void *)0)
                                      , current_declspecs, yyvsp[-1].ttype);
    cplus_decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 507:
{ ((yyvsp[0].ttype)->common.chain) = yyval.ttype; yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 508:
{ yyval.ttype = build_enumerator (yyval.ttype, (tree) 
                                              ((void *)0)
                                                       ); ;
    break;}
case 509:
{ yyval.ttype = build_enumerator (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 510:
{ yyval.ttype = build_decl_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 511:
{ yyval.ttype = build_decl_list (yyval.ttype, (tree) 
                                             ((void *)0)
                                                      ); ;
    break;}
case 512:
{
    if (pedantic)
      pedwarn ("ANSI C++ forbids array dimensions with parenthesized type in new");
    yyval.ttype = build_parse_node (ARRAY_REF, ((yyvsp[-4].ttype)->list.value), yyvsp[-1].ttype);
    yyval.ttype = build_decl_list (((yyvsp[-4].ttype)->list.purpose), yyval.ttype);
  ;
    break;}
case 513:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 514:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 515:
{ yyval.ttype = (((struct n64_tag_lang_identifier *)(yyval.ttype))->x ? ((struct n64_tag_lang_identifier *)(yyval.ttype))->x->as_list : 0); ;
    break;}
case 516:
{ yyval.ttype = decl_tree_cons ((tree) 
                               ((void *)0)
                                        , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 517:
{ yyval.itype = suspend_momentary (); ;
    break;}
case 518:
{ resume_momentary ((int) yyvsp[-1].itype); yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 519:
{ resume_momentary ((int) yyvsp[-3].itype); yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 520:
{ resume_momentary ((int) yyvsp[-3].itype); yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 521:
{ resume_momentary ((int) yyvsp[-1].itype); yyval.ttype = empty_parms (); ;
    break;}
case 522:
{ resume_momentary ((int) yyvsp[-3].itype); yyval.ttype = (tree) 
                                                         ((void *)0)
                                                                  ; ;
    break;}
case 523:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 524:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 525:
{ yyval.ttype = make_pointer_declarator ((tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype); ;
    break;}
case 526:
{ yyval.ttype = make_reference_declarator ((tree) 
                                          ((void *)0)
                                                   , yyvsp[0].ttype); ;
    break;}
case 527:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 529:
{


    if (current_class_type
        && (((current_class_type)->type.lang_specific)->type_flags.being_defined)
        && ! (((struct n64_tag_lang_identifier *)(yyval.ttype))->class_value))
      {
        tree t = lookup_name (yyval.ttype, -2);
        if (t)
   pushdecl_class_level (t);
      }
  ;
    break;}
case 531:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 532:
{ yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 533:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 534:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, (tree) 
                                                         ((void *)0)
                                                                  ); ;
    break;}
case 535:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 536:
{ push_nested_class (((yyval.ttype)->common.type), 3);
    yyval.ttype = build_parse_node (SCOPE_REF, yyval.ttype, yyvsp[0].ttype);
    ((yyval.ttype)->exp.complexity) = current_class_depth; ;
    break;}
case 538:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 539:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 540:
{ yyval.ttype = make_pointer_declarator ((tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype); ;
    break;}
case 541:
{ yyval.ttype = make_reference_declarator ((tree) 
                                          ((void *)0)
                                                   , yyvsp[0].ttype); ;
    break;}
case 542:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 544:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 545:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 546:
{ yyval.ttype = make_pointer_declarator ((tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype); ;
    break;}
case 547:
{ yyval.ttype = make_reference_declarator ((tree) 
                                          ((void *)0)
                                                   , yyvsp[0].ttype); ;
    break;}
case 548:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 550:
{ yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 551:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 552:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 553:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, (tree) 
                                                         ((void *)0)
                                                                  ); ;
    break;}
case 554:
{ if ((((((yyval.ttype)->exp.operands[0])))->common.type) != current_class_type)
      {
        push_nested_class ((((((yyval.ttype)->exp.operands[0])))->common.type), 3);
        ((yyval.ttype)->exp.complexity) = current_class_depth;
      }
  ;
    break;}
case 555:
{ got_scope = (tree) 
             ((void *)0)
                      ;
    yyval.ttype = build_parse_node (SCOPE_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 556:
{ got_scope = (tree) 
             ((void *)0)
                      ;
    yyval.ttype = build_parse_node (SCOPE_REF, yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 558:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 559:
{ yyval.ttype = build_functional_cast (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 560:
{ yyval.ttype = reparse_decl_as_expr (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 561:
{ yyval.ttype = reparse_absdcl_as_expr (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 565:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 566:
{ got_scope = ((yyval.ttype)->common.type); ;
    break;}
case 567:
{ got_scope = yyval.ttype; ;
    break;}
case 568:
{ got_scope = ((yyval.ttype)->common.type); ;
    break;}
case 570:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 572:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 573:
{ got_scope = (tree) 
             ((void *)0)
                      ; ;
    break;}
case 574:
{ yyval.ttype = yyvsp[-1].ttype; got_scope = (tree) 
                                            ((void *)0)
                                                     ; ;
    break;}
case 575:
{ got_scope = void_type_node; ;
    break;}
case 576:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 577:
{ yyval.ttype = make_pointer_declarator (yyvsp[0].ttype, (tree) 
                                                        ((void *)0)
                                                                 ); ;
    break;}
case 578:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 579:
{ yyval.ttype = make_reference_declarator (yyvsp[0].ttype, (tree) 
                                                          ((void *)0)
                                                                   ); ;
    break;}
case 580:
{ tree arg = make_pointer_declarator (yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              );
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-1].ttype, arg);
  ;
    break;}
case 581:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 583:
{ yyval.ttype = build_parse_node (ARRAY_REF, (tree) 
                                            ((void *)0)
                                                     , yyvsp[-1].ttype); ;
    break;}
case 584:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 585:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 586:
{ yyval.ttype = make_pointer_declarator ((tree) 
                                        ((void *)0)
                                                 , yyvsp[0].ttype); ;
    break;}
case 587:
{ yyval.ttype = make_pointer_declarator (yyvsp[0].ttype, (tree) 
                                                        ((void *)0)
                                                                 ); ;
    break;}
case 588:
{ yyval.ttype = make_pointer_declarator ((tree) 
                                        ((void *)0)
                                                 , (tree) 
                                                   ((void *)0)
                                                            ); ;
    break;}
case 589:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 590:
{ yyval.ttype = make_reference_declarator ((tree) 
                                          ((void *)0)
                                                   , yyvsp[0].ttype); ;
    break;}
case 591:
{ yyval.ttype = make_reference_declarator (yyvsp[0].ttype, (tree) 
                                                          ((void *)0)
                                                                   ); ;
    break;}
case 592:
{ yyval.ttype = make_reference_declarator ((tree) 
                                          ((void *)0)
                                                   , (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 593:
{ tree arg = make_pointer_declarator (yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              );
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-1].ttype, arg);
  ;
    break;}
case 594:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 596:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 598:
{ yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 599:
{ yyval.ttype = build_parse_node (CALL_EXPR, yyval.ttype, empty_parms (), yyvsp[0].ttype); ;
    break;}
case 600:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 601:
{ yyval.ttype = build_parse_node (ARRAY_REF, yyval.ttype, (tree) 
                                                         ((void *)0)
                                                                  ); ;
    break;}
case 602:
{ yyval.ttype = build_parse_node (CALL_EXPR, (tree) 
                                            ((void *)0)
                                                     , yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 603:
{ ((yyval.ttype)->exp.operands[2]) = yyvsp[0].ttype; ;
    break;}
case 604:
{ ((yyval.ttype)->exp.operands[2]) = yyvsp[0].ttype; ;
    break;}
case 605:
{ yyval.ttype = build_parse_node (ARRAY_REF, (tree) 
                                            ((void *)0)
                                                     , yyvsp[-1].ttype); ;
    break;}
case 606:
{ yyval.ttype = build_parse_node (ARRAY_REF, (tree) 
                                            ((void *)0)
                                                     , (tree) 
                                                       ((void *)0)
                                                                ); ;
    break;}
case 612:
{ emit_line_note (input_filename, lineno);
    pushlevel (0);
    clear_last_expr ();
    push_momentary ();
    expand_start_bindings (0); ;
    break;}
case 613:
{ expand_end_bindings (getdecls (), kept_level_p (), 1);
    yyval.ttype = poplevel (kept_level_p (), 1, 0);
    pop_momentary (); ;
    break;}
case 615:
{ if (pedantic)
      pedwarn ("ANSI C++ forbids label declarations"); ;
    break;}
case 618:
{ tree link;
    for (link = yyvsp[-1].ttype; link; link = ((link)->common.chain))
      {
        tree label = shadow_label (((link)->list.value));
        ((label)->common.lang_flag_1) = 1;
        declare_nonlocal_label (label);
      }
  ;
    break;}
case 619:
{;
    break;}
case 621:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 622:
{ cond_stmt_keyword = "if"; ;
    break;}
case 623:
{ emit_line_note (input_filename, lineno);
    expand_start_cond (yyvsp[0].ttype, 0); ;
    break;}
case 625:
{ finish_stmt (); ;
    break;}
case 626:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 627:
{ finish_stmt (); ;
    break;}
case 629:
{ finish_stmt (); ;
    break;}
case 630:
{
    tree expr = yyvsp[-1].ttype;
    emit_line_note (input_filename, lineno);


    if ((((n64_enum_tree_code) (((expr)->common.type))->common.code) == ARRAY_TYPE
         && lvalue_p (expr))
        || ((n64_enum_tree_code) (((expr)->common.type))->common.code) == FUNCTION_TYPE)
      expr = default_conversion (expr);
    cplus_expand_expr_stmt (expr);
    clear_momentary ();
    finish_stmt (); ;
    break;}
case 631:
{ expand_start_else (); ;
    break;}
case 632:
{ expand_end_cond (); ;
    break;}
case 633:
{ finish_stmt (); ;
    break;}
case 634:
{ expand_end_cond ();
    expand_end_bindings (getdecls (), kept_level_p (), 1);
    poplevel (kept_level_p (), 1, 0);
    pop_momentary ();
    finish_stmt (); ;
    break;}
case 635:
{ emit_nop ();
    emit_line_note (input_filename, lineno);
    expand_start_loop (1);
    cond_stmt_keyword = "while"; ;
    break;}
case 636:
{ expand_exit_loop_if_false (0, yyvsp[0].ttype); ;
    break;}
case 637:
{ expand_end_loop ();
    finish_stmt (); ;
    break;}
case 638:
{ emit_nop ();
    emit_line_note (input_filename, lineno);
    expand_start_loop_continue_elsewhere (1); ;
    break;}
case 639:
{ expand_loop_continue_here ();
    cond_stmt_keyword = "do"; ;
    break;}
case 640:
{ emit_line_note (input_filename, lineno);
    expand_exit_loop_if_false (0, yyvsp[-1].ttype);
    expand_end_loop ();
    clear_momentary ();
    finish_stmt (); ;
    break;}
case 641:
{ emit_line_note (input_filename, lineno);
    if (flag_new_for_scope > 0)
      {

        pushlevel (0);
        note_level_for_for ();
        clear_last_expr ();
        push_momentary ();
        expand_start_bindings (0);
      }
  ;
    break;}
case 642:
{ emit_nop ();
    emit_line_note (input_filename, lineno);
    expand_start_loop_continue_elsewhere (1); ;
    break;}
case 643:
{ emit_line_note (input_filename, lineno);
    if (yyvsp[-1].ttype) expand_exit_loop_if_false (0, yyvsp[-1].ttype); ;
    break;}
case 644:
{ push_momentary (); ;
    break;}
case 645:
{ emit_line_note (input_filename, lineno);
    expand_loop_continue_here ();
    if (yyvsp[-4].ttype) cplus_expand_expr_stmt (yyvsp[-4].ttype);
    pop_momentary ();
    expand_end_loop ();
    if (flag_new_for_scope > 0)
      {
        expand_end_bindings (getdecls (), kept_level_p (), 1);
        poplevel (kept_level_p (), 1, 0);
        pop_momentary ();
      }
    finish_stmt (); ;
    break;}
case 646:
{ emit_line_note (input_filename, lineno);
    c_expand_start_case (yyvsp[-1].ttype);
    push_switch ();


    push_momentary (); ;
    break;}
case 647:
{ expand_end_case (yyvsp[-3].ttype);
    pop_momentary ();
    pop_switch (); ;
    break;}
case 648:
{ finish_stmt (); ;
    break;}
case 649:
{ register tree value = check_cp_case_value (yyvsp[-1].ttype);
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );

    if (value != error_mark_node)
      {
        tree duplicate;
        int success = pushcase (value, convert_and_check,
           label, &duplicate);
        if (success == 1)
   cp_error ("case label `%E' not within a switch statement", yyvsp[-1].ttype);
        else if (success == 2)
   {
     cp_error ("duplicate case value `%E'", yyvsp[-1].ttype);
     cp_error_at ("previously used here", duplicate);
   }
        else if (success == 3)
   warning ("case value out of range");
        else if (success == 5)
   cp_error ("case label `%E' within scope of cleanup or variable array", yyvsp[-1].ttype);
      }
    define_case_label (label);
  ;
    break;}
case 651:
{ register tree value1 = check_cp_case_value (yyvsp[-3].ttype);
    register tree value2 = check_cp_case_value (yyvsp[-1].ttype);
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );

    if (pedantic)
      pedwarn ("ANSI C++ forbids range expressions in switch statement");
    if (value1 != error_mark_node
        && value2 != error_mark_node)
      {
        tree duplicate;
        int success = pushcase_range (value1, value2,
          convert_and_check, label,
          &duplicate);
        if (success == 1)
   error ("case label not within a switch statement");
        else if (success == 2)
   {
     error ("duplicate (or overlapping) case value");
     error_with_decl (duplicate, "this is the first entry overlapping that value");
   }
        else if (success == 3)
   warning ("case value out of range");
        else if (success == 4)
   warning ("empty range specified");
        else if (success == 5)
   error ("case label within scope of cleanup or variable array");
      }
    define_case_label (label);
  ;
    break;}
case 653:
{
    tree duplicate;
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );
    int success = pushcase ((tree) 
                           ((void *)0)
                                    , 0, label, &duplicate);
    if (success == 1)
      error ("default label not within a switch statement");
    else if (success == 2)
      {
        error ("multiple default labels in one switch");
        error_with_decl (duplicate, "this is the first default label");
      }
    define_case_label ((tree) 
                      ((void *)0)
                               );
  ;
    break;}
case 655:
{ emit_line_note (input_filename, lineno);
    if ( ! expand_exit_something ())
      error ("break statement not within loop or switch"); ;
    break;}
case 656:
{ emit_line_note (input_filename, lineno);
    if (! expand_continue_loop (0))
      error ("continue statement not within a loop"); ;
    break;}
case 657:
{ emit_line_note (input_filename, lineno);
    c_expand_return ((tree) 
                    ((void *)0)
                             ); ;
    break;}
case 658:
{ emit_line_note (input_filename, lineno);
    c_expand_return (yyvsp[-1].ttype);
    finish_stmt ();
  ;
    break;}
case 659:
{ if (((yyvsp[-2].ttype)->common.chain)) yyvsp[-2].ttype = combine_strings (yyvsp[-2].ttype);
    emit_line_note (input_filename, lineno);
    expand_asm (yyvsp[-2].ttype);
    finish_stmt ();
  ;
    break;}
case 660:
{ if (((yyvsp[-4].ttype)->common.chain)) yyvsp[-4].ttype = combine_strings (yyvsp[-4].ttype);
    emit_line_note (input_filename, lineno);
    c_expand_asm_operands (yyvsp[-4].ttype, yyvsp[-2].ttype, (tree) 
                                                            ((void *)0)
                                                                     , (tree) 
                                                                       ((void *)0)
                                                                                ,
      yyvsp[-6].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno);
    finish_stmt ();
  ;
    break;}
case 661:
{ if (((yyvsp[-6].ttype)->common.chain)) yyvsp[-6].ttype = combine_strings (yyvsp[-6].ttype);
    emit_line_note (input_filename, lineno);
    c_expand_asm_operands (yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype, (tree) 
                                                                             ((void *)0)
                                                                                      ,
      yyvsp[-8].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno);
    finish_stmt ();
  ;
    break;}
case 662:
{ if (((yyvsp[-8].ttype)->common.chain)) yyvsp[-8].ttype = combine_strings (yyvsp[-8].ttype);
    emit_line_note (input_filename, lineno);
    c_expand_asm_operands (yyvsp[-8].ttype, yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype,
      yyvsp[-10].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno);
    finish_stmt ();
  ;
    break;}
case 663:
{ emit_line_note (input_filename, lineno);
    expand_computed_goto (yyvsp[-1].ttype); ;
    break;}
case 664:
{ tree decl;
    emit_line_note (input_filename, lineno);
    decl = lookup_label (yyvsp[-1].ttype);
    ((decl)->common.used_flag) = 1;
    expand_goto (decl); ;
    break;}
case 665:
{ finish_stmt (); ;
    break;}
case 666:
{ error ("label must be followed by statement");
    yyungetc ('}', 0);
    finish_stmt (); ;
    break;}
case 667:
{ finish_stmt (); ;
    break;}
case 669:
{
    if (! current_function_parms_stored)
      store_parm_decls ();
    expand_start_early_try_stmts ();
  ;
    break;}
case 670:
{ expand_end_try_stmts ();
    expand_start_all_catch (); ;
    break;}
case 671:
{
    expand_end_all_catch ();
    finish_function (lineno, (int)yyvsp[-3].itype, 0);
  ;
    break;}
case 672:
{ expand_start_try_stmts (); ;
    break;}
case 673:
{ expand_end_try_stmts ();
    expand_start_all_catch (); ;
    break;}
case 674:
{ expand_end_all_catch (); ;
    break;}
case 676:
{ dont_allow_type_definitions = "inside exception declarations"; ;
    break;}
case 677:
{ dont_allow_type_definitions = 0; ;
    break;}
case 678:
{ expand_end_catch_block (); ;
    break;}
case 682:
{ expand_start_catch_block ((tree) 
                           ((void *)0)
                                    , (tree) 
                                      ((void *)0)
                                               ); ;
    break;}
case 683:
{ expand_start_catch_block (((yyvsp[-1].ttype)->list.purpose),
         ((yyvsp[-1].ttype)->list.value)); ;
    break;}
case 684:
{ tree label;
  do_label:
    label = define_label (input_filename, lineno, yyvsp[-1].ttype);
    if (label)
      expand_label (label);
  ;
    break;}
case 685:
{ goto do_label; ;
    break;}
case 686:
{ goto do_label; ;
    break;}
case 687:
{ if (yyvsp[-1].ttype) cplus_expand_expr_stmt (yyvsp[-1].ttype); ;
    break;}
case 690:
{ emit_line_note (input_filename, lineno);
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 691:
{ emit_line_note (input_filename, lineno); ;
    break;}
case 692:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 694:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 695:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 698:
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 699:
{ yyval.ttype = build_tree_list (yyval.ttype, yyvsp[-1].ttype); ;
    break;}
case 700:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyval.ttype, (tree) 
                                                  ((void *)0)
                                                           ); ;
    break;}
case 701:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 702:
{
    if (strict_prototype)
      yyval.ttype = void_list_node;
    else
      yyval.ttype = (tree) 
                   ((void *)0)
                            ;
  ;
    break;}
case 704:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyval.ttype, void_list_node);
    ((yyval.ttype)->common.unsigned_flag) = 1; ;
    break;}
case 705:
{
    yyval.ttype = chainon (yyval.ttype, void_list_node);
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 706:
{
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 707:
{
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 708:
{
    yyval.ttype = build_tree_list ((tree) 
                                  ((void *)0)
                                           , yyval.ttype);
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 709:
{

    if (pedantic)
      warning ("use of `...' without a first argument is non-portable");
    yyval.ttype = (tree) 
                 ((void *)0)
                          ;
  ;
    break;}
case 710:
{
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 711:
{
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 712:
{
    yyval.ttype = build_tree_list ((tree) 
                                  ((void *)0)
                                           , yyval.ttype);
    ((yyval.ttype)->common.unsigned_flag) = 1;
  ;
    break;}
case 713:
{



    yyerror ("possibly missing ')'");
    yyval.ttype = chainon (yyval.ttype, void_list_node);
    ((yyval.ttype)->common.unsigned_flag) = 1;
    yyungetc (':', 0);
    yychar = ')';
  ;
    break;}
case 714:
{



    yyerror ("possibly missing ')'");
    yyval.ttype = tree_cons ((tree) 
                            ((void *)0)
                                     , yyval.ttype, void_list_node);
    ((yyval.ttype)->common.unsigned_flag) = 1;
    yyungetc (':', 0);
    yychar = ')';
  ;
    break;}
case 715:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 716:
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 717:
{ yyval.ttype = chainon (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 718:
{ yyval.ttype = chainon (yyval.ttype, build_tree_list ((tree) 
                                                      ((void *)0)
                                                               , yyvsp[0].ttype)); ;
    break;}
case 719:
{ yyval.ttype = chainon (yyval.ttype, build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype)); ;
    break;}
case 721:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyval.ttype); ;
    break;}
case 722:
{ tree specs = strip_attrs (yyvsp[-1].ttype);
    yyval.ttype = build_tree_list (specs, yyvsp[0].ttype); ;
    break;}
case 723:
{ yyval.ttype = build_tree_list (yyval.ttype, yyvsp[0].ttype); ;
    break;}
case 724:
{ yyval.ttype = build_tree_list (get_decl_list (yyval.ttype), yyvsp[0].ttype); ;
    break;}
case 725:
{ tree specs = strip_attrs (yyvsp[-1].ttype);
    yyval.ttype = build_tree_list (specs, yyvsp[0].ttype); ;
    break;}
case 726:
{ tree specs = strip_attrs (yyvsp[0].ttype);
    yyval.ttype = build_tree_list (specs, (tree) 
                                         ((void *)0)
                                                  ); ;
    break;}
case 727:
{ tree specs = strip_attrs (yyvsp[-1].ttype);
    yyval.ttype = build_tree_list (specs, yyvsp[0].ttype); ;
    break;}
case 728:
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyval.ttype); ;
    break;}
case 731:
{ see_typename (); ;
    break;}
case 732:
{
    error ("type specifier omitted for parameter");
    yyval.ttype = build_tree_list (integer_type_node, (tree) 
                                                     ((void *)0)
                                                              );
  ;
    break;}
case 733:
{
    error ("type specifier omitted for parameter");
    yyval.ttype = build_tree_list (integer_type_node, yyval.ttype);
  ;
    break;}
case 734:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 735:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 736:
{ yyval.ttype = build_decl_list ((tree) 
                                ((void *)0)
                                         , (tree) 
                                           ((void *)0)
                                                    ); ;
    break;}
case 737:
{ yyval.ttype = build_decl_list ((tree) 
                                ((void *)0)
                                         , groktypename(yyval.ttype)); ;
    break;}
case 739:
{
    ((yyvsp[0].ttype)->common.chain) = yyval.ttype;
    yyval.ttype = yyvsp[0].ttype;
  ;
    break;}
case 740:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 741:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 742:
{ yyval.ttype = make_reference_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 743:
{ tree arg = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype);
    yyval.ttype = build_parse_node (SCOPE_REF, yyvsp[-2].ttype, arg);
  ;
    break;}
case 744:
{ got_scope = (tree) 
             ((void *)0)
                      ; ;
    break;}
case 745:
{ yyval.ttype = ansi_opname[MULT_EXPR]; ;
    break;}
case 746:
{ yyval.ttype = ansi_opname[TRUNC_DIV_EXPR]; ;
    break;}
case 747:
{ yyval.ttype = ansi_opname[TRUNC_MOD_EXPR]; ;
    break;}
case 748:
{ yyval.ttype = ansi_opname[PLUS_EXPR]; ;
    break;}
case 749:
{ yyval.ttype = ansi_opname[MINUS_EXPR]; ;
    break;}
case 750:
{ yyval.ttype = ansi_opname[BIT_AND_EXPR]; ;
    break;}
case 751:
{ yyval.ttype = ansi_opname[BIT_IOR_EXPR]; ;
    break;}
case 752:
{ yyval.ttype = ansi_opname[BIT_XOR_EXPR]; ;
    break;}
case 753:
{ yyval.ttype = ansi_opname[BIT_NOT_EXPR]; ;
    break;}
case 754:
{ yyval.ttype = ansi_opname[COMPOUND_EXPR]; ;
    break;}
case 755:
{ yyval.ttype = ansi_opname[yyvsp[0].code]; ;
    break;}
case 756:
{ yyval.ttype = ansi_opname[LT_EXPR]; ;
    break;}
case 757:
{ yyval.ttype = ansi_opname[GT_EXPR]; ;
    break;}
case 758:
{ yyval.ttype = ansi_opname[yyvsp[0].code]; ;
    break;}
case 759:
{ yyval.ttype = ansi_assopname[yyvsp[0].code]; ;
    break;}
case 760:
{ yyval.ttype = ansi_opname [MODIFY_EXPR]; ;
    break;}
case 761:
{ yyval.ttype = ansi_opname[yyvsp[0].code]; ;
    break;}
case 762:
{ yyval.ttype = ansi_opname[yyvsp[0].code]; ;
    break;}
case 763:
{ yyval.ttype = ansi_opname[POSTINCREMENT_EXPR]; ;
    break;}
case 764:
{ yyval.ttype = ansi_opname[PREDECREMENT_EXPR]; ;
    break;}
case 765:
{ yyval.ttype = ansi_opname[TRUTH_ANDIF_EXPR]; ;
    break;}
case 766:
{ yyval.ttype = ansi_opname[TRUTH_ORIF_EXPR]; ;
    break;}
case 767:
{ yyval.ttype = ansi_opname[TRUTH_NOT_EXPR]; ;
    break;}
case 768:
{ yyval.ttype = ansi_opname[COND_EXPR]; ;
    break;}
case 769:
{ yyval.ttype = ansi_opname[yyvsp[0].code]; ;
    break;}
case 770:
{ yyval.ttype = ansi_opname[COMPONENT_REF]; ;
    break;}
case 771:
{ yyval.ttype = ansi_opname[MEMBER_REF]; ;
    break;}
case 772:
{ yyval.ttype = ansi_opname[CALL_EXPR]; ;
    break;}
case 773:
{ yyval.ttype = ansi_opname[ARRAY_REF]; ;
    break;}
case 774:
{ yyval.ttype = ansi_opname[NEW_EXPR]; ;
    break;}
case 775:
{ yyval.ttype = ansi_opname[DELETE_EXPR]; ;
    break;}
case 776:
{ yyval.ttype = ansi_opname[VEC_NEW_EXPR]; ;
    break;}
case 777:
{ yyval.ttype = ansi_opname[VEC_DELETE_EXPR]; ;
    break;}
case 778:
{ yyval.ttype = grokoptypename (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 779:
{ yyval.ttype = ansi_opname[ERROR_MARK]; ;
    break;}
}

  yyvsp -= yylen;
  yyssp -= yylen;





  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (
              (__acrt_iob_func(2))
                    , "state stack now");
      while (ssp1 != yyssp)
 fprintf (
         (__acrt_iob_func(2))
               , " %d", *++ssp1);
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }


  *++yyvsp = yyval;
  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - 109] + *yyssp;
  if (yystate >= 0 && yystate <= 9543 && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - 109];

  goto yynewstate;

yyerrlab:

  if (! yyerrstatus)

    {
      ++yynerrs;
 yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:

  if (yyerrstatus == 3)
    {



      if (yychar == 0)
 return(1);


      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Discarding token %d (%s).\n", yychar, yytname[yychar1]);


      yychar = -2;
    }




  yyerrstatus = 3;

  goto yyerrhandle;

yyerrdefault:
yyerrpop:

  if (yyssp == yyss) return(1);
  yyvsp--;
  yystate = *--yyssp;





  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (
              (__acrt_iob_func(2))
                    , "Error: state stack now");
      while (ssp1 != yyssp)
 fprintf (
         (__acrt_iob_func(2))
               , " %d", *++ssp1);
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }


yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yyerrdefault;

  yyn += 1;
  if (yyn < 0 || yyn > 9543 || yycheck[yyn] != 1)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == 1399)
    return(0);


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Shifting error token, ");


  *++yyvsp = yylval;




  yystate = yyn;
  goto yynewstate;
}

