// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/decl.c
/* Process declarations and variables for C compiler.
   Copyright (C) 1988, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Hacked by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <signal.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int sorry(...) asm("_sorry");
extern int push_function_context(...) asm("_push_function_context");
extern int output_inline_function(...) asm("_output_inline_function");
extern int pop_function_context(...) asm("_pop_function_context");
extern int remember_end_note(...) asm("_remember_end_note");
extern int print_node_brief(...) asm("_print_node_brief");
extern int simple_cst_equal(...) asm("_simple_cst_equal");
extern int push_obstacks(...) asm("_push_obstacks");
extern int fatal(...) asm("_fatal");
extern int warning(...) asm("_warning");
extern int id_in_current_class(...) asm("_id_in_current_class");
extern int rest_of_decl_compilation(...) asm("_rest_of_decl_compilation");
extern int error(...) asm("_error");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int init_init_processing(...) asm("_init_init_processing");
extern int init_cadillac(...) asm("_init_cadillac");
extern int make_function_rtl(...) asm("_make_function_rtl");
extern int pedwarn(...) asm("_pedwarn");
extern int temporary_allocation(...) asm("_temporary_allocation");
extern int cadillac_start_decl(...) asm("_cadillac_start_decl");
extern int extract_init(...) asm("_extract_init");
extern int make_decl_rtl(...) asm("_make_decl_rtl");
extern int resume_temporary_allocation(...) asm("_resume_temporary_allocation");
extern int store_expr(...) asm("_store_expr");
extern int signature_error(...) asm("_signature_error");
extern int expand_decl(...) asm("_expand_decl");
extern int expand_cleanups_to(...) asm("_expand_cleanups_to");
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int cadillac_finish_decl(...) asm("_cadillac_finish_decl");
extern int expand_assignment(...) asm("_expand_assignment");
extern int do_pending_stack_adjust(...) asm("_do_pending_stack_adjust");
extern int preserve_initializer(...) asm("_preserve_initializer");
extern int copy_assignment_arg_p(...) asm("_copy_assignment_arg_p");
extern int cadillac_start_enum(...) asm("_cadillac_start_enum");
extern int cadillac_start_struct(...) asm("_cadillac_start_struct");
extern int min_precision(...) asm("_min_precision");
extern int fixup_signed_type(...) asm("_fixup_signed_type");
extern int cadillac_finish_enum(...) asm("_cadillac_finish_enum");
extern int cadillac_start_function(...) asm("_cadillac_start_function");
extern int announce_function(...) asm("_announce_function");
extern int init_function_start(...) asm("_init_function_start");
extern int expand_function_start(...) asm("_expand_function_start");
extern int expand_main_function(...) asm("_expand_main_function");
extern int start_eh_unwinder(...) asm("_start_eh_unwinder");
extern int emit_jump(...) asm("_emit_jump");
extern int expand_function_end(...) asm("_expand_function_end");
extern int setjmp_protect(...) asm("_setjmp_protect");
extern int rest_of_compilation(...) asm("_rest_of_compilation");
extern int cadillac_finish_function(...) asm("_cadillac_finish_function");
extern int repo_template_used(...) asm("_repo_template_used");
extern int preserve_data(...) asm("_preserve_data");
extern int cadillac_finish_stmt(...) asm("_cadillac_finish_stmt");
extern int push_function_context_to(...) asm("_push_function_context_to");
extern int pop_function_context_from(...) asm("_pop_function_context_from");
struct n64_tag__obstack_chunk;
struct n64_tag_binding_level;
struct n64_tag_cp_function;
struct n64_tag_cp_switch;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_saved_scope;
struct n64_tag_stack_level;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
enum n64_cpp_enum_decl_context{ NORMAL,
  FUNCDEF,
  PARM,
  CATCHPARM,
  FIELD,
  BITFIELD,
  TYPENAME,
  MEMFUNCDEF
};
typedef __underlying_type(enum n64_cpp_enum_decl_context) n64_enum_decl_context;



extern tree grokdeclarator (tree, tree, n64_enum_decl_context, int, tree, tree) asm("_grokdeclarator");




extern tree this_identifier, in_charge_identifier;



extern tree last_function_parms;




extern tree pending_statics;





extern tree static_aggregates;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_BOOL,
  RID_CHAR,
  RID_WCHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,


  RID_CLASS,
  RID_RECORD,
  RID_UNION,
  RID_ENUM,
  RID_LONGLONG,





  RID_EXTERN,
  RID_CONST,
  RID_LONG,
  RID_TYPEDEF,
  RID_UNSIGNED,
  RID_SHORT,
  RID_INLINE,

  RID_STATIC,

  RID_REGISTER,
  RID_VOLATILE,
  RID_FRIEND,
  RID_VIRTUAL,
  RID_EXPLICIT,
  RID_SIGNED,
  RID_AUTO,
  RID_MUTABLE,



  RID_PUBLIC,
  RID_PRIVATE,
  RID_PROTECTED,
  RID_EXCEPTION,
  RID_TEMPLATE,
  RID_SIGNATURE,


  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

typedef struct { unsigned long idata[2]; }
     RID_BIT_TYPE;
extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;


extern int looking_for_typename;
extern int looking_for_template;


extern tree got_scope;
extern tree got_object;



extern int pending_lang_change;

extern tree make_pointer_declarator (...) asm("_make_pointer_declarator"), make_reference_declarator (...) asm("_make_reference_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern void reinit_parse_for_method(...) asm("_reinit_parse_for_method");
extern int yylex(void) asm("_yylex");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");




extern tree builtin_return_address_fndecl;

extern struct n64_tag_obstack permanent_obstack;

extern int current_class_depth;

extern tree cleanups_this_call;

extern tree static_ctors, static_dtors;





struct n64_tag_stack_level
{

  struct n64_tag_stack_level *prev;


  struct n64_tag_obstack *obstack;


  tree *first;



  int limit;
};

struct n64_tag_stack_level *push_stack_level (struct n64_tag_obstack *, char *, int) asm("_push_stack_level");
struct n64_tag_stack_level *pop_stack_level (struct n64_tag_stack_level *) asm("_pop_stack_level");
static struct n64_tag_obstack decl_obstack;
static struct n64_tag_stack_level *decl_stack;
static tree grokparms (tree, int) asm("_grokparms");
static tree lookup_nested_type (tree, tree) asm("_lookup_nested_type");
static char *redeclaration_error_message (tree, tree) asm("_redeclaration_error_message");
static void grok_op_properties (tree, int, int) asm("_grok_op_properties");

tree define_function
 (char *, tree, n64_enum_built_in_function, void (*)(...), char *) asm("_define_function");







tree error_mark_node;


tree error_mark_list;



tree short_integer_type_node;
tree integer_type_node;
tree long_integer_type_node;
tree long_long_integer_type_node;

tree short_unsigned_type_node;
tree unsigned_type_node;
tree long_unsigned_type_node;
tree long_long_unsigned_type_node;

tree ptrdiff_type_node;

tree unsigned_char_type_node;
tree signed_char_type_node;
tree char_type_node;
tree wchar_type_node;
tree signed_wchar_type_node;
tree unsigned_wchar_type_node;

tree wchar_decl_node;

tree float_type_node;
tree double_type_node;
tree long_double_type_node;

tree intQI_type_node;
tree intHI_type_node;
tree intSI_type_node;
tree intDI_type_node;

tree unsigned_intQI_type_node;
tree unsigned_intHI_type_node;
tree unsigned_intSI_type_node;
tree unsigned_intDI_type_node;



tree void_type_node, void_list_node;
tree void_zero_node;



tree ptr_type_node, const_ptr_type_node;



tree string_type_node, const_string_type_node;




tree char_array_type_node;




tree int_array_type_node;




tree wchar_array_type_node;


tree boolean_type_node, boolean_true_node, boolean_false_node;



tree default_function_type;



tree double_ftype_double, double_ftype_double_double;
tree int_ftype_int, long_ftype_long;



tree void_ftype_ptr_ptr_int, int_ftype_ptr_ptr_int, void_ftype_ptr_int_int;


tree string_ftype_ptr_ptr, int_ftype_string_string;


tree sizet_ftype_string;


tree int_ftype_cptr_cptr_sizet;


tree vtable_entry_type;
tree delta_type_node;






tree __t_desc_type_node, __tp_desc_type_node;
tree __access_mode_type_node;
tree __bltn_desc_type_node, __user_desc_type_node, __class_desc_type_node;
tree __ptr_desc_type_node, __attr_desc_type_node, __func_desc_type_node;
tree __ptmf_desc_type_node, __ptmd_desc_type_node;







tree class_star_type_node;
tree class_type_node, record_type_node, union_type_node, enum_type_node;
tree unknown_type_node;
tree opaque_type_node, signature_type_node;
tree sigtable_entry_type;
tree maybe_gc_cleanup;


tree vtbl_type_node;




tree dtor_label;




tree ctor_label;





tree abort_fndecl;

extern rtx cleanup_label, return_label;





rtx original_result_rtx;


tree base_init_expr;




tree this_identifier, in_charge_identifier;

tree pfn_identifier, index_identifier, delta_identifier, delta2_identifier;
tree pfn_or_delta2_identifier, tag_identifier;
tree vb_off_identifier, vt_off_identifier;
static tree named_label_uses;





tree static_aggregates;






tree integer_zero_node;
tree null_pointer_node;



tree integer_one_node, integer_two_node, integer_three_node;




tree pending_invalid_xref;

char *pending_invalid_xref_file;
int pending_invalid_xref_line;




static tree enum_next_value;



static int enum_overflow;




tree last_function_parms;




static tree last_function_parm_tags;





static tree current_function_parms;


static tree current_function_parm_tags;





static tree named_labels;



static tree shadowed_labels;
tree current_function_decl;




int current_function_returns_value;




int current_function_returns_null;






tree current_function_return_value;




static int warn_about_return_type;



extern int flag_short_double;



extern int flag_no_builtin;




extern int flag_no_nonansi_builtin;




extern int flag_ansi;



extern int flag_huge_objects;





extern int flag_conserve_space;



extern tree *current_lang_base, *current_lang_stack;






int current_function_assigns_this;
int current_function_just_assigned_this;




int current_function_parms_stored;



int current_function_obstack_index;



int current_function_obstack_usage;



extern int spew_debug;




extern tree previous_class_values;



struct n64_tag_stack_level *
push_decl_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack) asm("_push_decl_level");
struct n64_tag_stack_level *
push_decl_level(struct n64_tag_stack_level *stack, struct n64_tag_obstack *obstack)
{
  struct n64_tag_stack_level tem;
  tem.prev = stack;

  return push_stack_level (obstack, (char *)&tem, sizeof (tem));
}
struct n64_tag_binding_level
  {



    tree names;
    tree tags;





    tree shadowed;


    tree class_shadowed;


    tree type_shadowed;




    tree blocks;



    tree this_block;


    struct n64_tag_binding_level *level_chain;



    tree incomplete;




    tree dead_vars_from_for;




    unsigned parm_flag : 4;



    unsigned keep : 3;


    unsigned tag_transparent : 1;



    unsigned more_cleanups_ok : 1;
    unsigned have_cleanups : 1;



    unsigned accept_any : 1;






    unsigned pseudo_global : 1;


    unsigned namespace_p : 1;


    unsigned is_for_scope : 1;







  };





static struct n64_tag_binding_level *current_binding_level;



static struct n64_tag_binding_level *class_binding_level;
static struct n64_tag_binding_level *free_binding_level;





static struct n64_tag_binding_level *global_binding_level;



static struct n64_tag_binding_level clear_binding_level;



static int keep_next_level_flag;
static tree pushdecl_with_scope (tree, struct n64_tag_binding_level *) asm("_pushdecl_with_scope");

static void
push_binding_level(struct n64_tag_binding_level *newlevel, int tag_transparent, int keep) asm("_push_binding_level");
static void
push_binding_level(struct n64_tag_binding_level *newlevel, int tag_transparent, int keep)
{


  *newlevel = clear_binding_level;
  if (class_binding_level)
    {
      newlevel->level_chain = class_binding_level;
      class_binding_level = (struct n64_tag_binding_level *)0;
    }
  else
    {
      newlevel->level_chain = current_binding_level;
    }
  current_binding_level = newlevel;
  newlevel->tag_transparent = tag_transparent;
  newlevel->more_cleanups_ok = 1;
  newlevel->keep = keep;
}

static void
pop_binding_level(void) asm("_pop_binding_level");
static void
pop_binding_level(void)
{
  if (class_binding_level)
    current_binding_level = class_binding_level;

  if (global_binding_level)
    {

      if (current_binding_level == global_binding_level)
 my_friendly_abort (123);
    }
  {
    register struct n64_tag_binding_level *level = current_binding_level;
    current_binding_level = current_binding_level->level_chain;
    level->level_chain = free_binding_level;




      free_binding_level = level;

    class_binding_level = current_binding_level;
    if (class_binding_level->parm_flag != 2)
      class_binding_level = 0;
    while (current_binding_level->parm_flag == 2)
      current_binding_level = current_binding_level->level_chain;
  }
}

static void
suspend_binding_level(void) asm("_suspend_binding_level");
static void
suspend_binding_level(void)
{
  if (class_binding_level)
    current_binding_level = class_binding_level;

  if (global_binding_level)
    {

      if (current_binding_level == global_binding_level)
 my_friendly_abort (123);
    }
  {
    register struct n64_tag_binding_level *level = current_binding_level;
    current_binding_level = current_binding_level->level_chain;





    class_binding_level = current_binding_level;
    if (class_binding_level->parm_flag != 2)
      class_binding_level = 0;
    while (current_binding_level->parm_flag == 2)
      current_binding_level = current_binding_level->level_chain;
  }
}

void
resume_binding_level(struct n64_tag_binding_level *b) asm("_resume_binding_level");
void
resume_binding_level(struct n64_tag_binding_level *b)
{
  if (class_binding_level)
    {


      sorry ("cannot resume a namespace inside class");
      return;




    }
  else
    {


      if (b->level_chain != current_binding_level)
 {
   sorry ("cannot resume a namespace inside a different namespace");
   return;
 }

      b->level_chain = current_binding_level;
    }
  current_binding_level = b;
}



int
global_bindings_p(void) asm("_global_bindings_p");
int
global_bindings_p(void)
{
  return current_binding_level == global_binding_level;
}





int
toplevel_bindings_p(void) asm("_toplevel_bindings_p");
int
toplevel_bindings_p(void)
{
  struct n64_tag_binding_level *b = current_binding_level;

  while (1)
    {
      if (b == global_binding_level)
 return 1;
      if (! b->namespace_p)
 return 0;
      b=b->level_chain;
    }
}



int
namespace_bindings_p(void) asm("_namespace_bindings_p");
int
namespace_bindings_p(void)
{
  return current_binding_level->namespace_p;
}

void
keep_next_level(void) asm("_keep_next_level");
void
keep_next_level(void)
{
  keep_next_level_flag = 1;
}



int
kept_level_p(void) asm("_kept_level_p");
int
kept_level_p(void)
{
  return (current_binding_level->blocks != (tree) 
                                          ((void *)0)
   
  || current_binding_level->keep
   || current_binding_level->names != (tree) 
                                     ((void *)0)
   
  || (current_binding_level->tags != (tree) 
                                     ((void *)0)
       
      && !current_binding_level->tag_transparent));
}



void
declare_parm_level(void) asm("_declare_parm_level");
void
declare_parm_level(void)
{
  current_binding_level->parm_flag = 1;
}

void
declare_uninstantiated_type_level(void) asm("_declare_uninstantiated_type_level");
void
declare_uninstantiated_type_level(void)
{
  current_binding_level->accept_any = 1;
}

int
uninstantiated_type_level_p(void) asm("_uninstantiated_type_level_p");
int
uninstantiated_type_level_p(void)
{
  return current_binding_level->accept_any;
}

void
declare_pseudo_global_level(void) asm("_declare_pseudo_global_level");
void
declare_pseudo_global_level(void)
{
  current_binding_level->pseudo_global = 1;
}

void
declare_namespace_level(void) asm("_declare_namespace_level");
void
declare_namespace_level(void)
{
  current_binding_level->namespace_p = 1;
}

int
pseudo_global_level_p(void) asm("_pseudo_global_level_p");
int
pseudo_global_level_p(void)
{
  return current_binding_level->pseudo_global;
}

void
set_class_shadows(tree shadows) asm("_set_class_shadows");
void
set_class_shadows(tree shadows)
{
  class_binding_level->class_shadowed = shadows;
}





void
pushlevel(int tag_transparent) asm("_pushlevel");
void
pushlevel(int tag_transparent)
{
  register struct n64_tag_binding_level *newlevel = ((struct n64_tag_binding_level *) 
                                           ((void *)0)
                                           );





  if (current_binding_level == global_binding_level)
    my_friendly_assert (named_labels == (tree) 
                                       ((void *)0)
                                                , 134);






  if (free_binding_level)

    {
      newlevel = free_binding_level;
      free_binding_level = free_binding_level->level_chain;
    }
  else
    {

      newlevel = (struct n64_tag_binding_level *) xmalloc (sizeof (struct n64_tag_binding_level));
    }
  push_binding_level (newlevel, tag_transparent, keep_next_level_flag);
  GNU_xref_start_scope ((int) newlevel);
  keep_next_level_flag = 0;
}

int
note_level_for_for(void) asm("_note_level_for_for");
int
note_level_for_for(void)
{
  current_binding_level->is_for_scope = 1;

  return 0;
}

void
pushlevel_temporary(int tag_transparent) asm("_pushlevel_temporary");
void
pushlevel_temporary(int tag_transparent)
{
  pushlevel (tag_transparent);
  current_binding_level->keep = 2;
  clear_last_expr ();





  expand_start_bindings (0);
}
tree
poplevel(int keep, int reverse, int functionbody) asm("_poplevel");
tree
poplevel(int keep, int reverse, int functionbody)
{
  register tree link;


  tree decls;
  int tmp = functionbody;
  int implicit_try_block = current_binding_level->parm_flag == 3;
  int real_functionbody = current_binding_level->keep == 2
    ? ((functionbody = 0), tmp) : functionbody;
  tree tags = functionbody >= 0 ? current_binding_level->tags : 0;
  tree subblocks = functionbody >= 0 ? current_binding_level->blocks : 0;
  tree block = (tree) 
              ((void *)0)
                       ;
  tree decl;
  int block_previously_created;

  GNU_xref_end_scope ((int) current_binding_level,
        (int) current_binding_level->level_chain,
        current_binding_level->parm_flag,
        current_binding_level->keep,
        current_binding_level->tag_transparent);

  if (current_binding_level->keep == 1)
    keep = 1;
  if (reverse)
    current_binding_level->names
      = decls = nreverse (current_binding_level->names);
  else
    decls = current_binding_level->names;




  for (decl = decls; decl; decl = ((decl)->common.chain))
    if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
 && ! ((decl)->common.asm_written_flag)
 && ((decl)->decl.initial) != (tree) 
                          ((void *)0)
 
&& ((decl)->common.addressable_flag)
 && decl_function_context (decl) == current_function_decl)
      {



 if (((decl)->decl.abstract_origin) != (tree) 
                                   ((void *)0)
                                            )
   ((((decl)->decl.abstract_origin))->common.addressable_flag) = 1;
 else
   {
     push_function_context ();
     output_inline_function (decl);
     pop_function_context ();
   }
      }





  block = (tree) 
         ((void *)0)
                  ;
  block_previously_created = (current_binding_level->this_block != (tree) 
                                                                  ((void *)0)
                                                                           );
  if (block_previously_created)
    block = current_binding_level->this_block;
  else if (keep == 1 || functionbody)
    block = make_node (BLOCK);
  if (block != (tree) 
              ((void *)0)
                       )
    {
      ((block)->block.vars) = decls;
      ((block)->block.type_tags) = tags;
      ((block)->block.subblocks) = subblocks;




      if (! block_previously_created)
 remember_end_note (block);
    }



  if (keep >= 0)
    for (link = subblocks; link; link = ((link)->common.chain))
      ((link)->block.supercontext) = block;



  for (link = current_binding_level->dead_vars_from_for;
       link != (tree) 
              ((void *)0)
                       ; link = ((link)->common.chain))
    {
      if (((link)->decl.lang_flag_7))
 {
   tree id = ((link)->decl.name);
   if ((((struct n64_tag_lang_identifier *)(id))->local_value) == link)
     (((struct n64_tag_lang_identifier *)(id))->local_value) = ((link)->decl.result);
 }
    }

  if (current_binding_level->is_for_scope && flag_new_for_scope == 1)
    {
      for (link = decls; link; link = ((link)->common.chain))
 {
   if (((n64_enum_tree_code) (link)->common.code) == VAR_DECL)
     ((link)->decl.lang_flag_7) = 1;
 }
    }
  else
    {
      for (link = decls; link; link = ((link)->common.chain))
 {
   if (((link)->decl.name) != (tree) 
                          ((void *)0)
                                   )
     {


       if (((link)->decl.external_flag))
  {
    if (((link)->common.used_flag))
      ((((link)->decl.assembler_name))->common.used_flag) = 1;
    if (((link)->common.addressable_flag))
      ((((link)->decl.assembler_name))->common.addressable_flag) = 1;
  }
       (((struct n64_tag_lang_identifier *)(((link)->decl.name)))->local_value) = (tree) 
                                                  ((void *)0)
                                                           ;
     }
 }
    }




  if (current_binding_level->is_for_scope && flag_new_for_scope == 1)
    {
      struct n64_tag_binding_level *outer = current_binding_level->level_chain;
      for (link = current_binding_level->shadowed; link; link = ((link)->common.chain))
 {
   tree id = ((link)->list.purpose);
   tree decl = (((struct n64_tag_lang_identifier *)(id))->local_value);
   if (((decl)->decl.lang_flag_7))
     ((decl)->decl.result) = ((link)->list.value);
   else
     (((struct n64_tag_lang_identifier *)(id))->local_value) = ((link)->list.value);
 }
      outer->dead_vars_from_for
 = chainon (current_binding_level->names, outer->dead_vars_from_for);
    }
  else
    {
      for (link = current_binding_level->shadowed; link; link = ((link)->common.chain))
 (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->local_value) = ((link)->list.value);
    }
  for (link = current_binding_level->class_shadowed;
       link; link = ((link)->common.chain))
    (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->class_value) = ((link)->list.value);
  for (link = current_binding_level->type_shadowed;
       link; link = ((link)->common.chain))
    (((((link)->list.purpose))->common.type)) = ((link)->list.value);




  if (functionbody)
    {





      ((block)->block.vars) = 0;




      for (link = named_labels; link; link = ((link)->common.chain))
 {
   register tree label = ((link)->list.value);

   if (((label)->decl.initial) == (tree) 
                              ((void *)0)
                                       )
     {
       cp_error_at ("label `%D' used but not defined", label);

       define_label (input_filename, 1, ((label)->decl.name));
     }
   else if (warn_unused && !((label)->common.used_flag))
     cp_warning_at ("label `%D' defined but not used", label);
   (((struct n64_tag_lang_identifier *)(((label)->decl.name)))->x == 0 ? ((struct n64_tag_lang_identifier *)(((label)->decl.name)))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(((label)->decl.name)))->x->label_value = ((tree) 
  ((void *)0)
  ));



          ((label)->common.chain) = ((block)->block.vars);
          ((block)->block.vars) = label;
 }

      named_labels = (tree) 
                    ((void *)0)
                             ;
    }



  {
    struct n64_tag_binding_level *level_chain;
    level_chain = current_binding_level->level_chain;
    if (level_chain)
      {
 tree labels;
 for (labels = named_label_uses; labels; labels = ((labels)->common.chain))
   if (((labels)->common.type) == (tree)current_binding_level)
     {
       ((labels)->common.type) = (tree)level_chain;
       ((labels)->list.purpose) = level_chain->names;
     }
      }
  }

  tmp = current_binding_level->keep;

  pop_binding_level ();
  if (functionbody)
    ((current_function_decl)->decl.initial) = block;
  else if (block)
    {
      if (!block_previously_created)
        current_binding_level->blocks
          = chainon (current_binding_level->blocks, block);
    }





  else if (subblocks)
    {
      if (keep == 2)
 current_binding_level->blocks
   = chainon (subblocks, current_binding_level->blocks);
      else
 current_binding_level->blocks
   = chainon (current_binding_level->blocks, subblocks);
    }


  if (tmp == 2)
    {





      expand_end_bindings (getdecls (), keep, 1);



      if (block)
 ((block)->common.used_flag) = 1;
      block = poplevel (keep, reverse, real_functionbody);
    }




  if (block)
    ((block)->common.used_flag) = 1;
  return block;
}


void
resume_level(struct n64_tag_binding_level *b) asm("_resume_level");
void
resume_level(struct n64_tag_binding_level *b)
{
  tree decls, link;

  resume_binding_level (b);


  decls = current_binding_level->names;



  for (link = decls; link; link = ((link)->common.chain))
    {
      if (((link)->decl.name) != (tree) 
                             ((void *)0)
                                      )
 (((struct n64_tag_lang_identifier *)(((link)->decl.name)))->local_value) = link;


      if (((n64_enum_tree_code) (link)->common.code) == TYPE_DECL)
 (((((link)->decl.name))->common.type) = ((link)->common.type));
    }
}





void
delete_block(tree block) asm("_delete_block");
void
delete_block(tree block)
{
  tree t;
  if (current_binding_level->blocks == block)
    current_binding_level->blocks = ((block)->common.chain);
  for (t = current_binding_level->blocks; t;)
    {
      if (((t)->common.chain) == block)
 ((t)->common.chain) = ((block)->common.chain);
      else
 t = ((t)->common.chain);
    }
  ((block)->common.chain) = (tree) 
                      ((void *)0)
                               ;


  ((block)->common.used_flag) = 0;
}





void
insert_block(tree block) asm("_insert_block");
void
insert_block(tree block)
{
  ((block)->common.used_flag) = 1;
  current_binding_level->blocks
    = chainon (current_binding_level->blocks, block);
}


void
add_block_current_level(tree block) asm("_add_block_current_level");
void
add_block_current_level(tree block)
{
  current_binding_level->blocks
    = chainon (current_binding_level->blocks, block);
}




void
set_block(register tree block) asm("_set_block");
void
set_block(register tree block)
{
  current_binding_level->this_block = block;
}


void
pushlevel_class(void) asm("_pushlevel_class");
void
pushlevel_class(void)
{
  register struct n64_tag_binding_level *newlevel;





  if (free_binding_level)

    {
      newlevel = free_binding_level;
      free_binding_level = free_binding_level->level_chain;
    }
  else
    {

      newlevel = (struct n64_tag_binding_level *) xmalloc (sizeof (struct n64_tag_binding_level));
    }





  push_binding_level (newlevel, 0, 0);

  decl_stack = push_decl_level (decl_stack, &decl_obstack);
  class_binding_level = current_binding_level;
  class_binding_level->parm_flag = 2;



  do
    {
      current_binding_level = current_binding_level->level_chain;
    }
  while (current_binding_level->parm_flag == 2);
}



tree
poplevel_class(int force) asm("_poplevel_class");
tree
poplevel_class(int force)
{
  register struct n64_tag_binding_level *level = class_binding_level;
  tree block = (tree) 
              ((void *)0)
                       ;
  tree shadowed;

  my_friendly_assert (level != 0, 354);

  decl_stack = pop_stack_level (decl_stack);
  for (shadowed = level->shadowed; shadowed; shadowed = ((shadowed)->common.chain))
    (((struct n64_tag_lang_identifier *)(((shadowed)->list.purpose)))->local_value) = ((shadowed)->list.value);





  if (current_class_depth != 1 || force)
    for (shadowed = level->class_shadowed;
  shadowed;
  shadowed = ((shadowed)->common.chain))
      (((struct n64_tag_lang_identifier *)(((shadowed)->list.purpose)))->class_value) = ((shadowed)->list.value);
  else


    previous_class_values = class_binding_level->class_shadowed;
  for (shadowed = level->type_shadowed;
       shadowed;
       shadowed = ((shadowed)->common.chain))
    (((((shadowed)->list.purpose))->common.type)) = ((shadowed)->list.value);

  GNU_xref_end_scope ((int) class_binding_level,
        (int) class_binding_level->level_chain,
        class_binding_level->parm_flag,
        class_binding_level->keep,
        class_binding_level->tag_transparent);

  if (class_binding_level->parm_flag != 2)
    class_binding_level = (struct n64_tag_binding_level *)0;







  pop_binding_level ();

  return block;
}


int no_print_functions = 0;
int no_print_builtins = 0;

void
print_binding_level(struct n64_tag_binding_level *lvl) asm("_print_binding_level");
void
print_binding_level(struct n64_tag_binding_level *lvl)
{
  tree t;
  int i = 0, len;
  fprintf (
          (__acrt_iob_func(2))
                , " blocks=");
  fprintf (
          (__acrt_iob_func(2))
                , sizeof (int) == sizeof (char *) ? "%x" : "%lx", lvl->blocks);
  fprintf (
          (__acrt_iob_func(2))
                , " n_incomplete=%d parm_flag=%d keep=%d",
    list_length (lvl->incomplete), lvl->parm_flag, lvl->keep);
  if (lvl->tag_transparent)
    fprintf (
            (__acrt_iob_func(2))
                  , " tag-transparent");
  if (lvl->more_cleanups_ok)
    fprintf (
            (__acrt_iob_func(2))
                  , " more-cleanups-ok");
  if (lvl->have_cleanups)
    fprintf (
            (__acrt_iob_func(2))
                  , " have-cleanups");
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  if (lvl->names)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , " names:\t");

      for (t = lvl->names; t; t = ((t)->common.chain))
 {
   if (no_print_functions && (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL))
     continue;
   if (no_print_builtins
       && (((n64_enum_tree_code) (t)->common.code) == TYPE_DECL)
       && (!strcmp(((t)->decl.filename),"<built-in>")))
     continue;


   if (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL)
     len = 3;
   else
     len = 2;
   i += len;
   if (i > 6)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "\n\t");
       i = len;
     }
   print_node_brief (
                    (__acrt_iob_func(2))
                          , "", t, 0);
   if (((n64_enum_tree_code) (t)->common.code) == ERROR_MARK)
     break;
 }
      if (i)
        fprintf (
                (__acrt_iob_func(2))
                      , "\n");
    }
  if (lvl->tags)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , " tags:\t");
      i = 0;
      for (t = lvl->tags; t; t = ((t)->common.chain))
 {
   if (((t)->list.purpose) == (tree) 
                          ((void *)0)
                                   )
     len = 3;
   else if (((t)->list.purpose) == (((((((t)->list.value))->type.name))->decl.name)))
     len = 2;
   else
     len = 4;
   i += len;
   if (i > 5)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "\n\t");
       i = len;
     }
   if (((t)->list.purpose) == (tree) 
                          ((void *)0)
                                   )
     {
       print_node_brief (
                        (__acrt_iob_func(2))
                              , "<unnamed-typedef", ((t)->list.value), 0);
       fprintf (
               (__acrt_iob_func(2))
                     , ">");
     }
   else if (((t)->list.purpose) == (((((((t)->list.value))->type.name))->decl.name)))
     print_node_brief (
                      (__acrt_iob_func(2))
                            , "", ((t)->list.value), 0);
   else
     {
       print_node_brief (
                        (__acrt_iob_func(2))
                              , "<typedef", ((t)->list.purpose), 0);
       print_node_brief (
                        (__acrt_iob_func(2))
                              , "", ((t)->list.value), 0);
       fprintf (
               (__acrt_iob_func(2))
                     , ">");
     }
 }
      if (i)
 fprintf (
         (__acrt_iob_func(2))
               , "\n");
    }
  if (lvl->shadowed)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , " shadowed:");
      for (t = lvl->shadowed; t; t = ((t)->common.chain))
 {
   fprintf (
           (__acrt_iob_func(2))
                 , " %s ", ((((t)->list.purpose))->identifier.pointer));
 }
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }
  if (lvl->class_shadowed)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , " class-shadowed:");
      for (t = lvl->class_shadowed; t; t = ((t)->common.chain))
 {
   fprintf (
           (__acrt_iob_func(2))
                 , " %s ", ((((t)->list.purpose))->identifier.pointer));
 }
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }
  if (lvl->type_shadowed)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , " type-shadowed:");
      for (t = lvl->type_shadowed; t; t = ((t)->common.chain))
        {
   fprintf (
           (__acrt_iob_func(2))
                 , " %s ", ((((t)->list.purpose))->identifier.pointer));

        }
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }
}

void
print_other_binding_stack(struct n64_tag_binding_level *stack) asm("_print_other_binding_stack");
void
print_other_binding_stack(struct n64_tag_binding_level *stack)
{
  struct n64_tag_binding_level *level;
  for (level = stack; level != global_binding_level; level = level->level_chain)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "binding level ");
      fprintf (
              (__acrt_iob_func(2))
                    , sizeof (int) == sizeof (char *) ? "%x" : "%lx", level);
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
      print_binding_level (level);
    }
}

void
print_binding_stack(void) asm("_print_binding_stack");
void
print_binding_stack(void)
{
  struct n64_tag_binding_level *b;
  fprintf (
          (__acrt_iob_func(2))
                , "current_binding_level=");
  fprintf (
          (__acrt_iob_func(2))
                , sizeof (int) == sizeof (char *) ? "%x" : "%lx", current_binding_level);
  fprintf (
          (__acrt_iob_func(2))
                , "\nclass_binding_level=");
  fprintf (
          (__acrt_iob_func(2))
                , sizeof (int) == sizeof (char *) ? "%x" : "%lx", class_binding_level);
  fprintf (
          (__acrt_iob_func(2))
                , "\nglobal_binding_level=");
  fprintf (
          (__acrt_iob_func(2))
                , sizeof (int) == sizeof (char *) ? "%x" : "%lx", global_binding_level);
  fprintf (
          (__acrt_iob_func(2))
                , "\n");
  if (class_binding_level)
    {
      for (b = class_binding_level; b; b = b->level_chain)
 if (b == current_binding_level)
   break;
      if (b)
 b = class_binding_level;
      else
 b = current_binding_level;
    }
  else
    b = current_binding_level;
  print_other_binding_stack (b);
  fprintf (
          (__acrt_iob_func(2))
                , "global:\n");
  print_binding_level (global_binding_level);
}

extern char * first_global_object_name;



static tree
get_unique_name(void) asm("_get_unique_name");
static tree
get_unique_name(void)
{
  static int temp_name_counter = 0;
  char *buf;
  register char *p;

  if (first_global_object_name)
    p = first_global_object_name;
  else if (main_input_filename)
    p = main_input_filename;
  else
    p = input_filename;



  buf = (char *) 
                __builtin_alloca((
                sizeof ("__%s_%d") + strlen (p)
                ))
                                                                       ;

  sprintf (buf, "__%s_%d", p, temp_name_counter++);


  if (p != first_global_object_name)
    {
      for (p = buf+11; *p; p++)
 if (! ((*p >= '0' && *p <= '9')
        || *p == '.'

        || (*p >= 'A' && *p <= 'Z')
        || (*p >= 'a' && *p <= 'z')))
   *p = '_';
    }

  return get_identifier (buf);
}



void
push_namespace(tree name) asm("_push_namespace");
void
push_namespace(tree name)
{
  extern tree current_namespace;
  tree old_id = get_namespace_id ();
  char *buf;
  tree d = make_node (NAMESPACE_DECL);

  if (! name)
    {

      name = get_unique_name ();
    }

  ((d)->decl.name) = name;
  ((d)->decl.assembler_name) = name;

  ((d)->common.type) = void_type_node;


  ((d)->decl.external_flag) = 1;
  d = pushdecl (d);

  if (((d)->decl.arguments) == 0)
    {

      pushlevel (0);
      declare_namespace_level ();
      ((d)->decl.arguments) = (tree)current_binding_level;
    }
  else
    {
      resume_level ((struct n64_tag_binding_level*)((d)->decl.arguments));
    }


  current_namespace = tree_cons ((tree) 
                                ((void *)0)
                                         , name, current_namespace);
  buf = (char *) 
                __builtin_alloca((
                4 + (old_id ? ((old_id)->identifier.length) : 0) + ((name)->identifier.length)
                ))
                               
                              ;
  sprintf (buf, "%s%s", old_id ? ((old_id)->identifier.pointer) : "",
    ((name)->identifier.pointer));
  ((current_namespace)->list.purpose) = get_identifier (buf);
}


void
pop_namespace(void) asm("_pop_namespace");
void
pop_namespace(void)
{
  extern tree current_namespace;
  tree decls, link;
  current_namespace = ((current_namespace)->common.chain);


  if (! namespace_bindings_p ())
    poplevel (0, 0, 0);

  decls = current_binding_level->names;



  for (link = decls; link; link = ((link)->common.chain))
    {
      if (((link)->decl.name) != (tree) 
                             ((void *)0)
                                      )
 {


   if (((link)->decl.external_flag))
     {
       if (((link)->common.used_flag))
  ((((link)->decl.assembler_name))->common.used_flag) = 1;
       if (((link)->common.addressable_flag))
  ((((link)->decl.assembler_name))->common.addressable_flag) = 1;
     }
   (((struct n64_tag_lang_identifier *)(((link)->decl.name)))->local_value) = (tree) 
                                              ((void *)0)
                                                       ;
 }
    }




  for (link = current_binding_level->shadowed; link; link = ((link)->common.chain))
    (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->local_value) = ((link)->list.value);
  for (link = current_binding_level->class_shadowed;
       link; link = ((link)->common.chain))
    (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->class_value) = ((link)->list.value);
  for (link = current_binding_level->type_shadowed;
       link; link = ((link)->common.chain))
    (((((link)->list.purpose))->common.type)) = ((link)->list.value);


  suspend_binding_level ();
}






struct n64_tag_saved_scope {
  struct n64_tag_binding_level *old_binding_level;
  tree old_bindings;
  struct n64_tag_saved_scope *prev;
  tree class_name, class_type, function_decl;
  tree base_init_list, member_init_list;
  struct n64_tag_binding_level *class_bindings;
  tree previous_class_type;
  tree *lang_base, *lang_stack, lang_name;
  int lang_stacksize;
  tree named_labels;
};
static struct n64_tag_saved_scope *current_saved_scope;
extern tree prev_class_type;

void
push_to_top_level(void) asm("_push_to_top_level");
void
push_to_top_level(void)
{
  extern int current_lang_stacksize;
  struct n64_tag_saved_scope *s =
    (struct n64_tag_saved_scope *) xmalloc (sizeof (struct n64_tag_saved_scope));
  struct n64_tag_binding_level *b = current_binding_level;
  tree old_bindings = (tree) 
                     ((void *)0)
                              ;



  for (; b; b = b->level_chain)
    {
      tree t;

      if (b == global_binding_level)
 continue;

      for (t = b->names; t; t = ((t)->common.chain))
 {
   tree binding, t1, t2 = t;
   tree id = ((t2)->decl.assembler_name);

   if (!id
       || (!(((struct n64_tag_lang_identifier *)(id))->local_value)
    && !(((struct n64_tag_lang_identifier *)(id))->class_value)))
     continue;

   for (t1 = old_bindings; t1; t1 = ((t1)->common.chain))
     if (((t1)->vec.a[0]) == id)
       goto skip_it;

   binding = make_tree_vec (4);
   if (id)
     {
       my_friendly_assert (((n64_enum_tree_code) (id)->common.code) == IDENTIFIER_NODE, 135);
       ((binding)->vec.a[0]) = id;
       ((binding)->vec.a[1]) = (((id)->common.type));
       ((binding)->vec.a[2]) = (((struct n64_tag_lang_identifier *)(id))->local_value);
       ((binding)->vec.a[3]) = (((struct n64_tag_lang_identifier *)(id))->class_value);
       (((struct n64_tag_lang_identifier *)(id))->local_value) = (tree) 
                                    ((void *)0)
                                             ;
       (((struct n64_tag_lang_identifier *)(id))->class_value) = (tree) 
                                    ((void *)0)
                                             ;
     }
   ((binding)->common.chain) = old_bindings;
   old_bindings = binding;
 skip_it:
   ;
 }

      for (t = b->type_shadowed; t; t = ((t)->common.chain))
 (((((t)->list.purpose))->common.type) = ((t)->list.value));
    }

  if (current_binding_level == global_binding_level
      && previous_class_type != (tree) 
                               ((void *)0)
                                        )
    {
      popclass (-1);
      previous_class_type = (tree) 
                           ((void *)0)
                                    ;
    }

  s->old_binding_level = current_binding_level;
  current_binding_level = global_binding_level;

  s->class_name = current_class_name;
  s->class_type = current_class_type;
  s->function_decl = current_function_decl;
  s->base_init_list = current_base_init_list;
  s->member_init_list = current_member_init_list;
  s->class_bindings = class_binding_level;
  s->previous_class_type = previous_class_type;
  s->lang_stack = current_lang_stack;
  s->lang_base = current_lang_base;
  s->lang_stacksize = current_lang_stacksize;
  s->lang_name = current_lang_name;
  s->named_labels = named_labels;
  current_class_name = current_class_type = (tree) 
                                           ((void *)0)
                                                    ;
  current_function_decl = (tree) 
                         ((void *)0)
                                  ;
  class_binding_level = (struct n64_tag_binding_level *)0;
  previous_class_type = (tree) 
                       ((void *)0)
                                ;
  current_lang_stacksize = 10;
  current_lang_stack = current_lang_base
    = (tree *) xmalloc (current_lang_stacksize * sizeof (tree));
  current_lang_name = lang_name_cplusplus;
  strict_prototype = strict_prototypes_lang_cplusplus;
  named_labels = (tree) 
                ((void *)0)
                         ;

  s->prev = current_saved_scope;
  s->old_bindings = old_bindings;
  current_saved_scope = s;
}

void
pop_from_top_level(void) asm("_pop_from_top_level");
void
pop_from_top_level(void)
{
  extern int current_lang_stacksize;
  struct n64_tag_saved_scope *s = current_saved_scope;
  tree t;

  if (previous_class_type)
    previous_class_type = (tree) 
                         ((void *)0)
                                  ;

  current_binding_level = s->old_binding_level;
  current_saved_scope = s->prev;
  for (t = s->old_bindings; t; t = ((t)->common.chain))
    {
      tree id = ((t)->vec.a[0]);
      if (id)
 {
   (((id)->common.type)) = ((t)->vec.a[1]);
   (((struct n64_tag_lang_identifier *)(id))->local_value) = ((t)->vec.a[2]);
   (((struct n64_tag_lang_identifier *)(id))->class_value) = ((t)->vec.a[3]);
 }
    }
  current_class_name = s->class_name;
  current_class_type = s->class_type;
  current_base_init_list = s->base_init_list;
  current_member_init_list = s->member_init_list;
  current_function_decl = s->function_decl;
  class_binding_level = s->class_bindings;
  previous_class_type = s->previous_class_type;
  free (current_lang_base);
  current_lang_base = s->lang_base;
  current_lang_stack = s->lang_stack;
  current_lang_name = s->lang_name;
  current_lang_stacksize = s->lang_stacksize;
  if (current_lang_name == lang_name_cplusplus)
    strict_prototype = strict_prototypes_lang_cplusplus;
  else if (current_lang_name == lang_name_c)
    strict_prototype = strict_prototypes_lang_c;
  named_labels = s->named_labels;

  free (s);
}
static void
set_identifier_type_value_with_scope(tree id, tree type, struct n64_tag_binding_level *b) asm("_set_identifier_type_value_with_scope");
static void
set_identifier_type_value_with_scope(tree id, tree type, struct n64_tag_binding_level *b)
{
  if (b != global_binding_level)
    {
      tree old_type_value = (((id)->common.type));
      b->type_shadowed
 = tree_cons (id, old_type_value, b->type_shadowed);
    }
  (((id)->common.type) = type);
}



void
set_identifier_type_value(tree id, tree type) asm("_set_identifier_type_value");
void
set_identifier_type_value(tree id, tree type)
{
  set_identifier_type_value_with_scope (id, type, (class_binding_level ? class_binding_level : current_binding_level));
}





static void
set_nested_typename(tree decl, tree classname, tree name, tree type) asm("_set_nested_typename");
static void
set_nested_typename(tree decl, tree classname, tree name, tree type)
{
  char *buf;
  my_friendly_assert (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL, 136);


  if ((((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
    {
      ((decl)->decl.arguments) = name;
      return;
    }

  if (classname == (tree) 
                  ((void *)0)
                           )
    classname = get_identifier ("");

  my_friendly_assert (((n64_enum_tree_code) (classname)->common.code) == IDENTIFIER_NODE, 137);
  my_friendly_assert (((n64_enum_tree_code) (name)->common.code) == IDENTIFIER_NODE, 138);
  buf = (char *) 
                __builtin_alloca((
                4 + ((classname)->identifier.length) + ((name)->identifier.length)
                ))
                               
                              ;
  sprintf (buf, "%s::%s", ((classname)->identifier.pointer),
    ((name)->identifier.pointer));
  ((decl)->decl.arguments) = get_identifier (buf);
  (((((decl)->decl.arguments))->common.lang_flag_0)) = 1;



  {
    tree nested, type_decl;
    nested = ((decl)->decl.arguments);
    type_decl = build_decl (TYPE_DECL, nested, type);
    ((type_decl)->decl.arguments) = nested;
    (((type_decl)->decl.artificial_flag) = 1);



    ((type_decl)->decl.ignored_flag) = 1;


    (((nested)->common.type) = type);

    pushdecl_nonclass_level (type_decl);
  }
}




void
pop_everything(void) asm("_pop_everything");
void
pop_everything(void)
{



  while (! toplevel_bindings_p () && ! pseudo_global_level_p ())
    {
      if (class_binding_level)
 pop_nested_class (1);
      else
 poplevel (0, 0, 0);
    }



}
void
pushtag(tree name, tree type, int globalize) asm("_pushtag");
void
pushtag(tree name, tree type, int globalize)
{
  register struct n64_tag_binding_level *b;
  tree context = 0;
  tree c_decl = 0;

  b = (class_binding_level ? class_binding_level : current_binding_level);
  while (b->tag_transparent
  || (globalize && b->parm_flag == 2))
    b = b->level_chain;

  if (toplevel_bindings_p ())
    b->tags = perm_tree_cons (name, type, b->tags);
  else
    b->tags = saveable_tree_cons (name, type, b->tags);

  if (name)
    {
      context = type ? ((type)->type.context) : (tree) 
                                            ((void *)0)
                                                     ;
      if (! context && ! globalize)
        context = current_scope ();
      if (context)
 c_decl = ((n64_enum_tree_code) (context)->common.code) == FUNCTION_DECL
   ? context : (((context)->type.name));
      if ((((name)->common.type)) != type)
        {
          register tree d;
   int newdecl = 0;

   if (b->parm_flag != 2
       || ((current_class_type)->type.size) != (tree) 
                                           ((void *)0)
                                                    )
     {
       d = lookup_nested_type (type, c_decl);

       if (d == (tree) 
               ((void *)0)
                        )
  {
    newdecl = 1;



    d = build_decl (TYPE_DECL, name, type);
    ((d)->decl.assembler_name) = current_namespace_id (((d)->decl.assembler_name));

    (((d)->decl.artificial_flag) = 1);

    if (write_symbols == DWARF_DEBUG)
      {




        ((d)->decl.ignored_flag) = 1;
      }

    set_identifier_type_value_with_scope (name, type, b);
  }
       else
  d = ((d)->type.name);

       ((type)->type.name) = d;



       if (! (((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
  {
    if (b->parm_flag == 2)
      d = pushdecl_class_level (d);
    else
      d = pushdecl_with_scope (d, b);
  }
     }
   else
     {

       newdecl = 1;
       d = build_decl (TYPE_DECL, name, type);
       (((d)->decl.artificial_flag) = 1);

       if (write_symbols == DWARF_DEBUG)
  {




    ((d)->decl.ignored_flag) = 1;
  }


       (((type)->type.name)) = d;





       if (((n64_enum_tree_code) (type)->common.code) == UNINSTANTIATED_P_TYPE)
  pushclass (type, 0);
       d = pushdecl_class_level (d);
       if (((n64_enum_tree_code) (type)->common.code) == UNINSTANTIATED_P_TYPE)
  popclass (0);
     }
   if (newdecl)
     {
       if (write_symbols != DWARF_DEBUG)
  {
    if ((((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
      ((d)->decl.ignored_flag) = 1;
  }

       if (context == (tree) 
                     ((void *)0)
                              )

  set_nested_typename (d, (tree) 
                         ((void *)0)
                                  , name, type);
       else if (context && ((n64_enum_tree_code) (context)->common.code) == FUNCTION_DECL)

  set_nested_typename (d, ((c_decl)->decl.assembler_name),
         name, type);
       else

  set_nested_typename (d, ((c_decl)->decl.arguments),
         name, type);

       ((d)->decl.context) = context;
       ((type)->type.context) = ((d)->decl.context);
       ((d)->decl.assembler_name)
  = get_identifier (build_overload_name (type, 1, 1));
     }
        }
      if (b->parm_flag == 2)
 {
   (((type)->common.lang_flag_0)) = 1;
   if (((current_class_type)->type.size) == (tree) 
                                        ((void *)0)
                                                 )
     (((current_class_type)->type.lang_specific)->tags) = b->tags;
 }
    }

  if (((n64_enum_tree_code) (((type)->type.name))->common.code) == TYPE_DECL)

    (((type)->common.chain)) = ((type)->type.name);
  else
    {
      tree d = build_decl (TYPE_DECL, (tree) 
                                     ((void *)0)
                                              , type);

      (((type)->common.chain)) = pushdecl_with_scope (d, b);
    }
}


static int anon_cnt = 0;



tree
make_anon_name(void) asm("_make_anon_name");
tree
make_anon_name(void)
{
  char buf[32];

  sprintf (buf, "._%d", anon_cnt++);
  return get_identifier (buf);
}



void
clear_anon_tags(void) asm("_clear_anon_tags");
void
clear_anon_tags(void)
{
  register struct n64_tag_binding_level *b;
  register tree tags;
  static int last_cnt = 0;


  if (last_cnt == anon_cnt)
    return;

  b = current_binding_level;
  while (b->tag_transparent)
    b = b->level_chain;
  tags = b->tags;
  while (tags)
    {


      if (((tags)->list.purpose) == (tree) 
                                ((void *)0)
                                         )
 break;
      if ((((((tags)->list.purpose))->identifier.pointer)[0] == '.' && ((((tags)->list.purpose))->identifier.pointer)[1] == '_'))
 ((tags)->list.purpose) = (tree) 
                      ((void *)0)
                               ;
      tags = ((tags)->common.chain);
    }
  last_cnt = anon_cnt;
}







int
decls_match(tree newdecl, tree olddecl) asm("_decls_match");
int
decls_match(tree newdecl, tree olddecl)
{
  int types_match;

  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && ((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL)
    {
      tree f1 = ((newdecl)->common.type);
      tree f2 = ((olddecl)->common.type);
      tree p1 = ((f1)->type.values);
      tree p2 = ((f2)->type.values);





      if (((n64_enum_tree_code) (f1)->common.code) == METHOD_TYPE && (((olddecl)->decl.lang_specific)->decl_flags.static_function))
 revert_static_member_fn (&newdecl, &f1, &p1);
      else if (((n64_enum_tree_code) (f2)->common.code) == METHOD_TYPE
        && (((newdecl)->decl.lang_specific)->decl_flags.static_function))
 revert_static_member_fn (&olddecl, &f2, &p2);





      if (((n64_enum_tree_code) (f1)->common.code) != ((n64_enum_tree_code) (f2)->common.code))
 {
   if (((n64_enum_tree_code) (f1)->common.code) == OFFSET_TYPE)
     cp_compiler_error ("`%D' redeclared as member function", newdecl);
   else
     cp_compiler_error ("`%D' redeclared as non-member function", newdecl);
   return 0;
 }

      if (comptypes (((f1)->common.type), ((f2)->common.type), 1))
 {
   if (! strict_prototypes_lang_c && (((olddecl)->decl.lang_specific)->decl_flags.language) == lang_c
       && p2 == (tree) 
               ((void *)0)
                        )
     {
       types_match = self_promoting_args_p (p1);
       if (p1 == void_list_node)
  ((newdecl)->common.type) = ((olddecl)->common.type);
     }
   else if (!strict_prototypes_lang_c && (((olddecl)->decl.lang_specific)->decl_flags.language)==lang_c
     && (((newdecl)->decl.lang_specific)->decl_flags.language) == lang_c && p1 == (tree) 
                                                  ((void *)0)
                                                           )
     {
       types_match = self_promoting_args_p (p2);
       ((newdecl)->common.type) = ((olddecl)->common.type);
     }
   else
     types_match = compparms (p1, p2, 3);
 }
      else
 types_match = 0;
    }
  else if (((n64_enum_tree_code) (newdecl)->common.code) == TEMPLATE_DECL
    && ((n64_enum_tree_code) (olddecl)->common.code) == TEMPLATE_DECL)
    {
 tree newargs = ((newdecl)->decl.arguments);
 tree oldargs = ((olddecl)->decl.arguments);
 int i, len = ((newargs)->vec.length);

 if (((oldargs)->vec.length) != len)
   return 0;

 for (i = 0; i < len; i++)
   {
     tree newarg = ((((newargs)->vec.a[i]))->list.value);
     tree oldarg = ((((oldargs)->vec.a[i]))->list.value);
     if (((n64_enum_tree_code) (newarg)->common.code) != ((n64_enum_tree_code) (oldarg)->common.code))
       return 0;
     else if (((n64_enum_tree_code) (newarg)->common.code) == TYPE_DECL)
                     ;
     else if (! comptypes (((newarg)->common.type), ((oldarg)->common.type), 1))
       return 0;
   }

 if ((((newdecl)->decl.result) == (tree) 
    ((void *)0)
    )
     != (((olddecl)->decl.result) == (tree) 
       ((void *)0)
       ))
   types_match = 0;
 else if ((((newdecl)->decl.result) == (tree) 
         ((void *)0)
         ))
   types_match = 1;
 else
   types_match = decls_match (((olddecl)->decl.result),
         ((newdecl)->decl.result));
    }
  else
    {
      if (((newdecl)->common.type) == error_mark_node)
 types_match = ((olddecl)->common.type) == error_mark_node;
      else if (((olddecl)->common.type) == (tree) 
                                     ((void *)0)
                                              )
 types_match = ((newdecl)->common.type) == (tree) 
                                     ((void *)0)
                                              ;
      else if (((newdecl)->common.type) == (tree) 
                                     ((void *)0)
                                              )
 types_match = 0;
      else
 types_match = comptypes (((newdecl)->common.type), ((olddecl)->common.type), 1);
    }

  return types_match;
}
static void
warn_extern_redeclared_static(tree newdecl, tree olddecl) asm("_warn_extern_redeclared_static");
static void
warn_extern_redeclared_static(tree newdecl, tree olddecl)
{
  tree name;

  static char *explicit_extern_static_warning
    = "`%D' was declared `extern' and later `static'";
  static char *implicit_extern_static_warning
    = "`%D' was declared implicitly `extern' and later `static'";

  if (flag_traditional
      || ((n64_enum_tree_code) (newdecl)->common.code) == TYPE_DECL)
    return;

  name = ((newdecl)->decl.assembler_name);
  if (((name)->common.public_flag) && (((newdecl)->decl.lang_flag_6)))
    {


      if (! (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && olddecl != (tree) 
                   ((void *)0)
      
     && ((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
      && (((olddecl)->decl.bit_field_flag)
   || ((olddecl)->common.unsigned_flag))))
 {
   cp_pedwarn ((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0)
        ? implicit_extern_static_warning
        : explicit_extern_static_warning, newdecl);
   if (olddecl != (tree) 
                 ((void *)0)
                          )
     cp_pedwarn_at ("previous declaration of `%D'", olddecl);
 }
    }
}
int
duplicate_decls(register tree newdecl, register tree olddecl) asm("_duplicate_decls");
int
duplicate_decls(register tree newdecl, register tree olddecl)
{
  extern struct n64_tag_obstack permanent_obstack;
  unsigned olddecl_uid = ((olddecl)->decl.uid);
  int olddecl_friend = 0, types_match = 0;
  int new_defines_function;
  tree previous_c_decl = (tree) 
                        ((void *)0)
                                 ;

  if ((*tree_code_type[(int) (((n64_enum_tree_code) (olddecl)->common.code))]) == 'd')
    ((newdecl)->decl.machine_attributes) = ((olddecl)->decl.machine_attributes);

  types_match = decls_match (newdecl, olddecl);

  if (((n64_enum_tree_code) (olddecl)->common.code) != TREE_LIST)
    olddecl_friend = ((olddecl)->decl.lang_specific) && (((olddecl)->decl.lang_specific)->decl_flags.friend_attr);






  if ((((newdecl)->common.type)
       && ((n64_enum_tree_code) (((newdecl)->common.type))->common.code) == ERROR_MARK)
      || (((olddecl)->common.type)
   && ((n64_enum_tree_code) (((olddecl)->common.type))->common.code) == ERROR_MARK))
    types_match = 1;

  if (flag_traditional && ((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
      && (((struct n64_tag_lang_identifier *)(((newdecl)->decl.assembler_name)))->x ? ((struct n64_tag_lang_identifier *)(((newdecl)->decl.assembler_name)))->x->implicit_decl : 0) == olddecl)


    ;
  else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
    && ((olddecl)->decl.artificial_flag)
    && (((olddecl)->decl.bit_field_flag) || ((olddecl)->common.unsigned_flag)))
    {



      if (! (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL ? ! (((newdecl)->decl.lang_specific)->decl_flags.c_static) : ((newdecl)->common.public_flag))
   || (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
       && (((newdecl)->decl.lang_specific)->decl_flags.language) != (((olddecl)->decl.lang_specific)->decl_flags.language)))
 {
   if (warn_shadow)
     cp_warning ("shadowing %s function `%#D'",
   ((olddecl)->decl.bit_field_flag) ? "built-in" : "library",
   olddecl);

   return 0;
 }
      else if (! types_match)
 {
   if (((n64_enum_tree_code) (newdecl)->common.code) != FUNCTION_DECL)
     {


       if (! ((olddecl)->decl.bit_field_flag))
  cp_warning ("library function `%#D' redeclared as non-function `%#D'",
       olddecl, newdecl);
       else
  {
    cp_error ("declaration of `%#D'", newdecl);
    cp_error ("conflicts with built-in declaration `%#D'",
       olddecl);
  }
       return 0;
     }

   cp_warning ("declaration of `%#D'", newdecl);
   cp_warning ("conflicts with built-in declaration `%#D'",
        olddecl);
 }
    }
  else if (((n64_enum_tree_code) (olddecl)->common.code) != ((n64_enum_tree_code) (newdecl)->common.code))
    {
      if ((((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
    && ((n64_enum_tree_code) (olddecl)->common.code) == TEMPLATE_DECL
    && ! (((olddecl)->decl.result) == (tree) 
        ((void *)0)
        ))
   || (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
       && ((n64_enum_tree_code) (newdecl)->common.code) == TEMPLATE_DECL
       && ! (((newdecl)->decl.result) == (tree) 
           ((void *)0)
           )))
 return 0;

      cp_error ("`%#D' redeclared as different kind of symbol", newdecl);
      if (((n64_enum_tree_code) (olddecl)->common.code) == TREE_LIST)
 olddecl = ((olddecl)->list.value);
      cp_error_at ("previous declaration of `%#D'", olddecl);




      return 0;
    }
  else if (!types_match)
    {
      if (((n64_enum_tree_code) (newdecl)->common.code) == TEMPLATE_DECL)
 {



   if ((((olddecl)->decl.result) == (tree) 
      ((void *)0)
      )
       || (((newdecl)->decl.result) == (tree) 
         ((void *)0)
         ))
     {
       cp_error ("declaration of template `%#D'", newdecl);
       cp_error_at ("conflicts with previous declaration `%#D'",
      olddecl);
     }
   return 0;
 }
      if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
 {
   if ((((newdecl)->decl.lang_specific)->decl_flags.language) == lang_c
       && (((olddecl)->decl.lang_specific)->decl_flags.language) == lang_c)
     {
       cp_error ("declaration of C function `%#D' conflicts with",
   newdecl);
       cp_error_at ("previous declaration `%#D' here", olddecl);
     }
   else if (compparms (((((newdecl)->common.type))->type.values),
         ((((olddecl)->common.type))->type.values), 3))
     {
       cp_error ("new declaration `%#D'", newdecl);
       cp_error_at ("ambiguates old declaration `%#D'", olddecl);
     }
   else
     return 0;
 }


      else if (current_class_type == (tree) 
                                    ((void *)0)
   
  || (((struct n64_tag_lang_identifier *)(((newdecl)->decl.assembler_name)))->x ? ((struct n64_tag_lang_identifier *)(((newdecl)->decl.assembler_name)))->x->error_locus : 0) != current_class_type)
 {
   cp_error ("conflicting types for `%#D'", newdecl);
   cp_error_at ("previous declaration as `%#D'", olddecl);
 }
    }
  else
    {
      char *errmsg = redeclaration_error_message (newdecl, olddecl);
      if (errmsg)
 {
   cp_error (errmsg, newdecl);
   if (((olddecl)->decl.name) != (tree) 
                             ((void *)0)
                                      )
     cp_error_at ((((olddecl)->decl.initial)
     && current_binding_level == global_binding_level)
    ? "`%#D' previously defined here"
    : "`%#D' previously declared here", olddecl);
 }
      else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
        && ((olddecl)->decl.initial) != (tree) 
                                    ((void *)0)
        
       && ((((olddecl)->common.type))->type.values) == (tree) 
                                                  ((void *)0)
        
       && ((((newdecl)->common.type))->type.values) != (tree) 
                                                  ((void *)0)
                                                           )
 {

   cp_warning_at ("prototype for `%#D'", newdecl);
   cp_warning_at ("follows non-prototype definition here", olddecl);
 }
      else if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL
        && (((newdecl)->decl.lang_specific)->decl_flags.language) != (((olddecl)->decl.lang_specific)->decl_flags.language))
 {



   if (current_lang_stack == current_lang_base)
     (((newdecl)->decl.lang_specific)->decl_flags.language) = (((olddecl)->decl.lang_specific)->decl_flags.language);
   else
     {
       cp_error_at ("previous declaration of `%#D' with %L linkage",
      olddecl, (((olddecl)->decl.lang_specific)->decl_flags.language));
       cp_error ("conflicts with new declaration with %L linkage",
   (((newdecl)->decl.lang_specific)->decl_flags.language));
     }
 }

      if (((n64_enum_tree_code) (olddecl)->common.code) == FUNCTION_DECL)
 {
   tree t1 = ((((olddecl)->common.type))->type.values);
   tree t2 = ((((newdecl)->common.type))->type.values);
   int i = 1;

   if (((n64_enum_tree_code) (((newdecl)->common.type))->common.code) == METHOD_TYPE)
     t1 = ((t1)->common.chain), t2 = ((t2)->common.chain);

   for (; t1 && t1 != void_list_node;
        t1 = ((t1)->common.chain), t2 = ((t2)->common.chain), i++)
     if (((t1)->list.purpose) && ((t2)->list.purpose))
       {
  if (1 == simple_cst_equal (((t1)->list.purpose),
        ((t2)->list.purpose)))
    {
      if (pedantic)
        {
   cp_pedwarn ("default argument given for parameter %d of `%#D'",
        i, newdecl);
   cp_pedwarn_at ("after previous specification in `%#D'",
           olddecl);
        }
    }
  else
    {
      cp_error ("default argument given for parameter %d of `%#D'",
         i, newdecl);
      cp_error_at ("conflicts with previous specification in `%#D'",
     olddecl);
    }
       }

   if ((((newdecl)->decl.lang_specific)->decl_flags.declared_inline) && ! (((olddecl)->decl.lang_specific)->decl_flags.declared_inline))
     {
       if (((olddecl)->common.addressable_flag))
  {
    cp_pedwarn ("`%#D' was used before it was declared inline",
         newdecl);
    cp_pedwarn_at ("previous non-inline declaration here",
     olddecl);
  }
     }
 }

      else if (((newdecl)->common.readonly_flag) != ((olddecl)->common.readonly_flag)
        || ((newdecl)->common.volatile_flag) != ((olddecl)->common.volatile_flag))
 {
   cp_pedwarn ("type qualifiers for `%#D'", newdecl);
   cp_pedwarn_at ("conflict with previous decl `%#D'", olddecl);
 }
    }



  warn_extern_redeclared_static (newdecl, olddecl);


  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {




      if (((olddecl)->decl.vindex))
 ((newdecl)->decl.vindex) = ((olddecl)->decl.vindex);
      if (((olddecl)->decl.context))
 ((newdecl)->decl.context) = ((olddecl)->decl.context);
      if ((((olddecl)->decl.lang_specific)->decl_flags.context))
 (((newdecl)->decl.lang_specific)->decl_flags.context) = (((olddecl)->decl.lang_specific)->decl_flags.context);
      if ((((newdecl)->decl.lang_specific)->chain) == (tree) 
                                 ((void *)0)
                                          )
 (((newdecl)->decl.lang_specific)->chain) = (((olddecl)->decl.lang_specific)->chain);
      if ((((newdecl)->decl.lang_specific)->next_method) == (tree) 
                                       ((void *)0)
                                                )
 (((newdecl)->decl.lang_specific)->next_method) = (((olddecl)->decl.lang_specific)->next_method);
      if ((((newdecl)->decl.lang_specific)->pending_inline_info) == (struct n64_tag_pending_inline *)0)
 (((newdecl)->decl.lang_specific)->pending_inline_info) = (((olddecl)->decl.lang_specific)->pending_inline_info);
      ((newdecl)->decl.static_ctor_flag) |= ((olddecl)->decl.static_ctor_flag);
      ((newdecl)->decl.static_dtor_flag) |= ((olddecl)->decl.static_dtor_flag);
      (((newdecl)->decl.lang_specific)->decl_flags.abstract_virtual) |= (((olddecl)->decl.lang_specific)->decl_flags.abstract_virtual);
    }


  if (((n64_enum_tree_code) (olddecl)->common.code) == TYPE_DECL)
    {
      register tree newtype = ((newdecl)->common.type);
      register tree oldtype = ((olddecl)->common.type);

      ((newdecl)->decl.arguments) = ((olddecl)->decl.arguments);

      if (newtype != error_mark_node && oldtype != error_mark_node
   && ((newtype)->type.lang_specific) && ((oldtype)->type.lang_specific))
 {
   (((newtype)->type.lang_specific)->vsize) = (((oldtype)->type.lang_specific)->vsize);
   (((newtype)->type.lang_specific)->friend_classes)
     = (((oldtype)->type.lang_specific)->friend_classes);
 }
    }


  new_defines_function = (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
     && ((newdecl)->decl.initial) != (tree) 
                                 ((void *)0)
                                          );



  if (warn_redundant_decls
      && ! ((olddecl)->decl.artificial_flag)
      && !(new_defines_function && ((olddecl)->decl.initial) == (tree) 
                                                            ((void *)0)
                                                                     )

      && !(((olddecl)->decl.external_flag) && ! ((newdecl)->decl.external_flag)))
    {
      cp_warning ("redundant redeclaration of `%D' in same scope", newdecl);
      cp_warning_at ("previous declaration of `%D'", olddecl);
    }




  if (types_match)
    {

      tree oldtype = ((olddecl)->common.type);
      tree newtype;


      if (oldtype)
 push_obstacks (((oldtype)->type.obstack), ((oldtype)->type.obstack));
      else
 {
   push_obstacks_nochange ();
   end_temporary_allocation ();
 }


      newtype = common_type (((newdecl)->common.type), ((olddecl)->common.type));

      if (((n64_enum_tree_code) (newdecl)->common.code) == VAR_DECL)
 (((newdecl)->decl.lang_flag_2)) |= (((olddecl)->decl.lang_flag_2));


      else if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL
   && (((((newdecl)->common.type))->type.noncopied_parts)
       != ((((olddecl)->common.type))->type.noncopied_parts)))
 {
   tree ctype = (tree) 
               ((void *)0)
                        ;
   ctype = (((newdecl)->decl.lang_specific)->decl_flags.context);
   ((newdecl)->common.type) = build_exception_variant (newtype,
        ((((newdecl)->common.type))->type.noncopied_parts));
   ((olddecl)->common.type) = build_exception_variant (newtype,
        ((oldtype)->type.noncopied_parts));

   if (! compexcepttypes (((newdecl)->common.type), ((olddecl)->common.type), 0))
     {
       cp_error ("declaration of `%D' throws different exceptions...",
   newdecl);
       cp_error_at ("...from previous declaration here", olddecl);
     }
 }
      ((newdecl)->common.type) = ((olddecl)->common.type) = newtype;


      if (oldtype != ((newdecl)->common.type)
   && ((newdecl)->common.type) != error_mark_node)
 layout_type (((newdecl)->common.type));

      if (((n64_enum_tree_code) (newdecl)->common.code) == VAR_DECL
   || ((n64_enum_tree_code) (newdecl)->common.code) == PARM_DECL
   || ((n64_enum_tree_code) (newdecl)->common.code) == RESULT_DECL
   || ((n64_enum_tree_code) (newdecl)->common.code) == FIELD_DECL
   || ((n64_enum_tree_code) (newdecl)->common.code) == TYPE_DECL)
 layout_decl (newdecl, 0);


      if (((newdecl)->common.readonly_flag))
 ((olddecl)->common.readonly_flag) = 1;
      if (((newdecl)->common.volatile_flag))
 ((olddecl)->common.volatile_flag) = 1;


      if (((newdecl)->decl.initial) == (tree) 
                                   ((void *)0)
   
  && ((olddecl)->decl.initial) != (tree) 
                               ((void *)0)
                                        )
 {
   ((newdecl)->decl.initial) = ((olddecl)->decl.initial);
   ((newdecl)->decl.filename) = ((olddecl)->decl.filename);
   ((newdecl)->decl.linenum) = ((olddecl)->decl.linenum);
 }





      if (((newdecl)->decl.section_name) == (tree) 
                                        ((void *)0)
                                                 )
 ((newdecl)->decl.section_name) = ((olddecl)->decl.section_name);



      if ((((olddecl)->decl.lang_specific)
    && !(((olddecl)->decl.lang_specific)->decl_flags.abstract_virtual))
   || ((olddecl)->decl.rtl) != ((abort_fndecl)->decl.rtl))
 ((newdecl)->decl.rtl) = ((olddecl)->decl.rtl);

      pop_obstacks ();
    }


  else
    {

      tree oldstatic = value_member (olddecl, static_aggregates);
      if (oldstatic)
 ((oldstatic)->list.value) = error_mark_node;

      ((olddecl)->common.type) = ((newdecl)->common.type);
      ((olddecl)->common.readonly_flag) = ((newdecl)->common.readonly_flag);
      ((olddecl)->common.volatile_flag) = ((newdecl)->common.volatile_flag);
      ((olddecl)->common.side_effects_flag) = ((newdecl)->common.side_effects_flag);
    }


  ((newdecl)->decl.weak_flag) |= ((olddecl)->decl.weak_flag);
  ((newdecl)->common.public_flag) = ((olddecl)->common.public_flag);
  ((olddecl)->common.static_flag) = ((newdecl)->common.static_flag) |= ((olddecl)->common.static_flag);
  if (! ((olddecl)->decl.external_flag))
    ((newdecl)->decl.external_flag) = 0;

  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {
      (((newdecl)->decl.lang_specific)->decl_flags.c_static) = (((olddecl)->decl.lang_specific)->decl_flags.c_static);
      ((newdecl)->decl.lang_flag_5) |= ((olddecl)->decl.lang_flag_5);
      (((newdecl)->decl.lang_specific)->decl_flags.not_really_extern) |= (((olddecl)->decl.lang_specific)->decl_flags.not_really_extern);
    }

  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {
      (((newdecl)->decl.lang_specific)->decl_flags.declared_inline) |= (((olddecl)->decl.lang_specific)->decl_flags.declared_inline);



      if (((newdecl)->decl.inline_flag) && ((olddecl)->decl.initial) == (tree) 
                                                            ((void *)0)
                                                                     )
 ((olddecl)->decl.inline_flag) = 1;
      ((newdecl)->decl.inline_flag) = ((olddecl)->decl.inline_flag);

      if (! types_match)
 {
   (((olddecl)->decl.lang_specific)->decl_flags.language) = (((newdecl)->decl.lang_specific)->decl_flags.language);
   ((olddecl)->decl.assembler_name) = ((newdecl)->decl.assembler_name);
   ((olddecl)->decl.arguments) = ((newdecl)->decl.arguments);
   ((olddecl)->decl.result) = ((newdecl)->decl.result);
   ((olddecl)->decl.rtl) = ((newdecl)->decl.rtl);
 }
      if (new_defines_function)


 (((newdecl)->decl.lang_specific)->decl_flags.language) = (((olddecl)->decl.lang_specific)->decl_flags.language);
      else
 {


   if (((olddecl)->decl.bit_field_flag))
     {
       ((newdecl)->decl.bit_field_flag) = 1;
       ((newdecl)->decl.frame_size.f) = ((olddecl)->decl.frame_size.f);


       ((newdecl)->decl.rtl) = ((olddecl)->decl.rtl);
     }
   else
     ((newdecl)->decl.frame_size.i) = ((olddecl)->decl.frame_size.i);

   ((newdecl)->decl.result) = ((olddecl)->decl.result);
   if ((((newdecl)->decl.saved_insns.r) = ((olddecl)->decl.saved_insns.r)))


     ((newdecl)->decl.initial) = ((olddecl)->decl.initial);

   if (((olddecl)->decl.arguments))
     ((newdecl)->decl.arguments) = ((olddecl)->decl.arguments);
 }
      if (((olddecl)->decl.lang_specific))
 (((newdecl)->decl.lang_specific)->main_decl_variant) = (((olddecl)->decl.lang_specific)->main_decl_variant);
    }

  if (((n64_enum_tree_code) (newdecl)->common.code) == NAMESPACE_DECL)
    {
      ((newdecl)->decl.arguments) = ((olddecl)->decl.arguments);
    }

  if (((n64_enum_tree_code) (newdecl)->common.code) == TEMPLATE_DECL)
    {
      if ((((olddecl)->decl.lang_specific)->template_info)->length)
 (((newdecl)->decl.lang_specific)->template_info) = (((olddecl)->decl.lang_specific)->template_info);
      ((newdecl)->decl.size) = ((olddecl)->decl.size);
      ((newdecl)->decl.vindex)
 = ((olddecl)->decl.vindex);
      if ((((newdecl)->decl.lang_specific)->chain) == (tree) 
                                 ((void *)0)
                                          )
 (((newdecl)->decl.lang_specific)->chain) = (((olddecl)->decl.lang_specific)->chain);
    }


  ((newdecl)->common.addressable_flag) = ((olddecl)->common.addressable_flag);
  ((newdecl)->common.asm_written_flag) = ((olddecl)->common.asm_written_flag);
  ((newdecl)->decl.common_flag) = ((olddecl)->decl.common_flag);
  ((newdecl)->decl.assembler_name) = ((olddecl)->decl.assembler_name);



  if (((olddecl)->decl.lang_specific))
    {
      (((newdecl)->decl.lang_flag_3)) = (((olddecl)->decl.lang_flag_3));
      (((newdecl)->decl.lang_specific)->decl_flags.access) = (((olddecl)->decl.lang_specific)->decl_flags.access);
      (((newdecl)->decl.lang_specific)->decl_flags.nonconverting) = (((olddecl)->decl.lang_specific)->decl_flags.nonconverting);
    }

  if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {
      int function_size;
      struct n64_tag_lang_decl *ol = ((olddecl)->decl.lang_specific);
      struct n64_tag_lang_decl *nl = ((newdecl)->decl.lang_specific);

      function_size = sizeof (struct n64_tag_tree_decl);

      memcpy ((char *) olddecl + sizeof (struct n64_tag_tree_common),(char *) newdecl + sizeof (struct n64_tag_tree_common),function_size - sizeof (struct n64_tag_tree_common))

                                                  ;






      if ((char *)newdecl + ((function_size + ((&permanent_obstack)->alignment_mask)) & ~ ((&permanent_obstack)->alignment_mask))
   + ((sizeof (struct n64_tag_lang_decl) + ((&permanent_obstack)->alignment_mask)) & ~ ((&permanent_obstack)->alignment_mask))
   == ((&permanent_obstack)->alloc_failed ? 0 : (&permanent_obstack)->next_free))
 {
   (((newdecl)->decl.lang_specific)->main_decl_variant) = olddecl;
   ((olddecl)->decl.lang_specific) = ol;
   memcpy ((char *)ol,(char *)nl,sizeof (struct n64_tag_lang_decl));

   __extension__ ({ struct n64_tag_obstack *__o = (&permanent_obstack); void *__obj = (newdecl); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
 }
      else if (((ol)->decl_flags.permanent_attr))
 {
   if ((((olddecl)->decl.lang_specific)->main_decl_variant) == olddecl)
     {

       extern tree free_lang_decl_chain;
       tree free_lang_decl = (tree) ol;
       ((free_lang_decl)->common.chain) = free_lang_decl_chain;
       free_lang_decl_chain = free_lang_decl;
     }
   else
     {

     }
 }
    }
  else
    {
      memcpy ((char *) olddecl + sizeof (struct n64_tag_tree_common),(char *) newdecl + sizeof (struct n64_tag_tree_common),sizeof (struct n64_tag_tree_decl) - sizeof (struct n64_tag_tree_common) + tree_code_length [(int)((n64_enum_tree_code) (newdecl)->common.code)] * sizeof (char *))


                                                                      ;
    }

  ((olddecl)->decl.uid) = olddecl_uid;
  if (olddecl_friend)
    (((olddecl)->decl.lang_specific)->decl_flags.friend_attr) = 1;

  return 1;
}
tree
pushdecl(tree x) asm("_pushdecl");
tree
pushdecl(tree x)
{
  register tree t;



  register tree name = ((x)->decl.assembler_name);

  register struct n64_tag_binding_level *b = current_binding_level;
  if (x != current_function_decl

      && (((n64_enum_tree_code) (x)->common.code) != FUNCTION_DECL || !((x)->decl.virtual_flag))
      && ! ((x)->decl.context))
    ((x)->decl.context) = current_function_decl;

  if (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL && ((x)->decl.initial) == 0)
    ((x)->decl.context) = 0;
  if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL || ((n64_enum_tree_code) (x)->common.code) == VAR_DECL
      || ((n64_enum_tree_code) (x)->common.code) == NAMESPACE_DECL)
    name = ((x)->decl.name);


  if (name)
    {
      char *file;
      int line;

      t = lookup_name_current_level (name);
      if (t == error_mark_node)
 {

   t = (tree) 
      ((void *)0)
               ;
   cp_error_at ("`%#D' used prior to declaration", x);
 }

      else if (t != (tree) 
                   ((void *)0)
                            )
 {
   file = ((t)->decl.filename);
   line = ((t)->decl.linenum);
   if (((n64_enum_tree_code) (x)->common.code) == VAR_DECL && ((x)->decl.lang_flag_7))
     ;
   else if (((n64_enum_tree_code) (t)->common.code) == PARM_DECL)
     {
       if (((t)->decl.context) == (tree) 
                              ((void *)0)
                                       )
  fatal ("parse errors have confused me too much");
     }
   else if (((((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL && (((x)->decl.lang_specific)->decl_flags.language) == lang_c)
        || (((n64_enum_tree_code) (x)->common.code) == TEMPLATE_DECL
     && ! (((x)->decl.result) == (tree) 
         ((void *)0)
         )))
       && is_overloaded_fn (t))
                                     ;
   else if (t == wchar_decl_node)
     {
       if (pedantic && ! ((x)->decl.in_system_header_flag))
  cp_pedwarn ("redeclaration of wchar_t as `%T'", ((x)->common.type));


       return t;
     }
   else if (((n64_enum_tree_code) (t)->common.code) != ((n64_enum_tree_code) (x)->common.code))
     {
       if ((((n64_enum_tree_code) (t)->common.code) == TYPE_DECL && ((t)->decl.artificial_flag))
    || (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL && ((x)->decl.artificial_flag)))
  {





    ;
  }
       else if (duplicate_decls (x, t))
  return t;
     }
   else if (duplicate_decls (x, t))
     {
       if (((n64_enum_tree_code) (t)->common.code) == TYPE_DECL)
  (((name)->common.type) = ((t)->common.type));
       else if (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL)
  check_default_args (t);

       return t;
     }
 }

      if (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL && ! (((n64_enum_tree_code) (((x)->common.type))->common.code) == METHOD_TYPE || (((x)->decl.lang_specific)->decl_flags.static_function)))
 {
   t = push_overloaded_decl (x, 1);
   if (t != x || (((x)->decl.lang_specific)->decl_flags.language) == lang_c)
     return t;
 }
      else if (((n64_enum_tree_code) (x)->common.code) == TEMPLATE_DECL && ! (((x)->decl.result) == (tree) 
                                                  ((void *)0)
                                                  ))
 return push_overloaded_decl (x, 0);



      if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
 {
   tree type = ((x)->common.type);
   tree name = (type != error_mark_node) ? ((type)->type.name) : x;

   if (name == (tree) 
              ((void *)0) 
                        || ((n64_enum_tree_code) (name)->common.code) != TYPE_DECL)
     {


              name = x;
              if (global_bindings_p ())
                ((type)->type.name) = x;
     }
   else
     {
       tree tname = ((name)->decl.name);


       if (global_bindings_p () && (((tname)->identifier.pointer)[0] == '.' && ((tname)->identifier.pointer)[1] == '_'))
  {



    ((((x)->common.type))->type.name) = x;
    pushtag (tname, ((x)->common.type), 0);
  }
     }
   my_friendly_assert (((n64_enum_tree_code) (name)->common.code) == TYPE_DECL, 140);




   if (! ((x)->decl.arguments) && ! ((x)->decl.artificial_flag))
     set_nested_typename (x, current_class_name, ((x)->decl.name), type);

   if (type != error_mark_node
       && ((type)->type.name)
       && (((((type)->type.name))->decl.name)))
            set_identifier_type_value_with_scope (((x)->decl.name), type, b);
 }







      if (((x)->common.public_flag) && ((n64_enum_tree_code) (x)->common.code) != FUNCTION_DECL)
 {
   tree decl;

   if ((((struct n64_tag_lang_identifier *)(name))->global_value) != (tree) 
                                        ((void *)0)
       
      && ((((((struct n64_tag_lang_identifier *)(name))->global_value))->decl.external_flag)
    || (((((struct n64_tag_lang_identifier *)(name))->global_value))->common.public_flag)))
     decl = (((struct n64_tag_lang_identifier *)(name))->global_value);
   else
     decl = (tree) 
           ((void *)0)
                    ;

   if (decl

       && ((n64_enum_tree_code) (decl)->common.code) == ((n64_enum_tree_code) (x)->common.code)
       && ! comptypes (((x)->common.type), ((decl)->common.type), 1))
     {
       cp_pedwarn ("type mismatch with previous external decl", x);
       cp_pedwarn_at ("previous external decl of `%#D'", decl);
     }
 }



      if (flag_traditional && ((x)->decl.external_flag)
   && lookup_name (name, 0) == (tree) 
                              ((void *)0)
                                       )
 b = global_binding_level;



      if (b == global_binding_level)
 {




   if ((((struct n64_tag_lang_identifier *)(name))->global_value) == (tree) 
                                        ((void *)0) 
                                                  && (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL ? ! (((x)->decl.lang_specific)->decl_flags.c_static) : ((x)->common.public_flag)))
     ((name)->common.public_flag) = 1;



   if (((n64_enum_tree_code) (x)->common.code) != TYPE_DECL
       || t == (tree) 
              ((void *)0)
       
      || ! ((x)->decl.artificial_flag))
     (((struct n64_tag_lang_identifier *)(name))->global_value) = x;


   if ((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0)
       && (((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0))->common.used_flag))
     ((x)->common.used_flag) = 1;


   if ((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0)
       && (((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0))->common.addressable_flag))
     ((x)->common.addressable_flag) = 1;


   if ((((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->implicit_decl : 0) != (tree) 
                                         ((void *)0)

       
      && ! (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL
      && ((((x)->common.type))->common.type) == integer_type_node))
     cp_warning
       ("`%D' was previously implicitly declared to return `int'", x);



   if (x != (tree) 
           ((void *)0) 
                     && t != (tree) 
                             ((void *)0) 
                                       && decls_match (x, t))
     warn_extern_redeclared_static (x, t);
 }
      else
 {

   tree oldlocal = (((struct n64_tag_lang_identifier *)(name))->local_value);
   tree oldglobal = (((struct n64_tag_lang_identifier *)(name))->global_value);



   if (((n64_enum_tree_code) (x)->common.code) != TYPE_DECL
       || t == (tree) 
              ((void *)0)
       
      || ! ((x)->decl.artificial_flag))
     {
       b->shadowed = tree_cons (name, oldlocal, b->shadowed);
       (((struct n64_tag_lang_identifier *)(name))->local_value) = x;
     }


   if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
     set_identifier_type_value_with_scope (name, ((x)->common.type), b);




   if (((n64_enum_tree_code) (x)->common.code) == NAMESPACE_DECL)
     set_identifier_type_value_with_scope (name, (tree) 
                                                ((void *)0)
                                                         , b);



   if (oldlocal == (tree) 
                  ((void *)0)
       
      && ((x)->decl.external_flag)
       && oldglobal != (tree) 
                      ((void *)0)
       
      && ((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL
       && ((n64_enum_tree_code) (oldglobal)->common.code) == FUNCTION_DECL)
     {

       if (decls_match (x, oldglobal))
          ;
       else
  {
    cp_warning ("extern declaration of `%#D' doesn't match", x);
    cp_warning_at ("global declaration `%#D'", oldglobal);
  }
     }



   if (oldlocal == (tree) 
                  ((void *)0)
       
      && oldglobal == (tree) 
                      ((void *)0)
       
      && ((x)->decl.external_flag)
       && ((x)->common.public_flag))
     {
       ((name)->common.public_flag) = 1;
     }

   if ((((x)->decl.abstract_origin) != (tree) 0))
                                        ;


   else if (oldlocal != (tree) 
                       ((void *)0) 
                                 && !((x)->decl.external_flag)
       && ((n64_enum_tree_code) (oldlocal)->common.code) == PARM_DECL
       && ((n64_enum_tree_code) (x)->common.code) != PARM_DECL)
     {


       struct n64_tag_binding_level *b = current_binding_level->level_chain;

       if (cleanup_label)
  b = b->level_chain;


       if (b->parm_flag == 1)
  cp_error ("declaration of `%#D' shadows a parameter", name);
     }
   else if (oldlocal != (tree) 
                       ((void *)0) 
                                 && b->is_for_scope
     && !((oldlocal)->decl.lang_flag_7))
     {
       warning ("variable `%s' shadows local",
         ((name)->identifier.pointer));
       cp_warning_at ("  this is the shadowed declaration", oldlocal);
     }

   else if (warn_shadow && !((x)->decl.external_flag)

     && ! ((x)->decl.artificial_flag)

     && ! (((x)->decl.abstract_origin) != (tree) 0))
     {
       char *warnstring = 
                         ((void *)0)
                             ;

       if (oldlocal != (tree) 
                      ((void *)0) 
                                && ((n64_enum_tree_code) (oldlocal)->common.code) == PARM_DECL)
  warnstring = "declaration of `%s' shadows a parameter";
       else if ((((struct n64_tag_lang_identifier *)(name))->class_value) != (tree) 
                                                ((void *)0)
         
        && current_class_decl
         && !((name)->common.static_flag))
  warnstring = "declaration of `%s' shadows a member of `this'";
       else if (oldlocal != (tree) 
                           ((void *)0)
                                    )
  warnstring = "declaration of `%s' shadows previous local";
       else if (oldglobal != (tree) 
                            ((void *)0)
                                     )
  warnstring = "declaration of `%s' shadows global declaration";

       if (warnstring)
  warning (warnstring, ((name)->identifier.pointer));
     }
 }

      if (((n64_enum_tree_code) (x)->common.code) == FUNCTION_DECL)
 check_default_args (x);


      if (((n64_enum_tree_code) (x)->common.code) == VAR_DECL
   && ((x)->common.type) != error_mark_node
   && ((((((x)->common.type))->type.size) == (tree) 
                                    ((void *)0)
        
       && (((ARRAY_TYPE) == ((n64_enum_tree_code) (((x)->common.type))->common.code) && (((((((x)->common.type))->common.type))->type.lang_flag_5))) || (((((x)->common.type))->type.lang_flag_5))))

       || (((((x)->common.type))->type.lang_specific)
    && (((((x)->common.type))->type.lang_specific)->type_flags.being_defined))))
 b->incomplete = tree_cons ((tree) 
                           ((void *)0)
                                    , x, b->incomplete);
    }



  ((x)->common.chain) = b->names;
  b->names = x;
  if (! (b != global_binding_level || ((x)->common.permanent_flag)))
    my_friendly_abort (124);

  return x;
}



static tree
pushdecl_with_scope(tree x, struct n64_tag_binding_level *level) asm("_pushdecl_with_scope");
static tree
pushdecl_with_scope(tree x, struct n64_tag_binding_level *level)
{
  register struct n64_tag_binding_level *b = current_binding_level;

  current_binding_level = level;
  x = pushdecl (x);
  current_binding_level = b;
  return x;
}



tree
pushdecl_top_level(tree x) asm("_pushdecl_top_level");
tree
pushdecl_top_level(tree x)
{
  register struct n64_tag_binding_level *b = (class_binding_level ? class_binding_level : current_binding_level);
  register tree t = pushdecl_with_scope (x, global_binding_level);



  if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
    {
      tree name = ((x)->decl.name);
      tree newval;
      tree *ptr = (tree *)0;
      for (; b != global_binding_level; b = b->level_chain)
        {
          tree shadowed = b->type_shadowed;
          for (; shadowed; shadowed = ((shadowed)->common.chain))
            if (((shadowed)->list.purpose) == name)
              {
  ptr = &((shadowed)->list.value);



              }
        }
      newval = ((x)->common.type);
      if (ptr == (tree *)0)
        {


   (((name)->common.type) = newval);
 }
      else
        {







   *ptr = newval;
        }
    }
  return t;
}



void
push_overloaded_decl_top_level(tree x, int forget) asm("_push_overloaded_decl_top_level");
void
push_overloaded_decl_top_level(tree x, int forget)
{
  struct n64_tag_binding_level *b = current_binding_level;

  current_binding_level = global_binding_level;
  push_overloaded_decl (x, forget);
  current_binding_level = b;
}


tree
pushdecl_class_level(tree x) asm("_pushdecl_class_level");
tree
pushdecl_class_level(tree x)
{


  register tree name = ((x)->decl.name);

  if (name)
    {
      if ((((current_class_type)->type.lang_specific)->type_flags.being_defined))
 {



   tree icv = (((struct n64_tag_lang_identifier *)(name))->class_value);

   if (icv

       && id_in_current_class (name)

       && !(((n64_enum_tree_code) (icv)->common.code) == TYPE_DECL
     && ((icv)->decl.context) == current_class_type))
     {
       cp_error ("declaration of identifier `%D' as `%#D'", name, x);
       cp_error_at ("conflicts with previous use in class as `%#D'",
      icv);
     }
 }

      push_class_level_binding (name, x);
      if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL)
 {
   set_identifier_type_value (name, ((x)->common.type));




   if (! ((x)->decl.arguments) && ! ((x)->decl.artificial_flag))
     set_nested_typename (x, current_class_name, name, ((x)->common.type));
 }
    }
  return x;
}




tree
pushdecl_nonclass_level(tree x) asm("_pushdecl_nonclass_level");
tree
pushdecl_nonclass_level(tree x)
{
  struct n64_tag_binding_level *b = current_binding_level;







  my_friendly_assert (b->parm_flag != 2, 180);



  while (b->pseudo_global)
    b = b->level_chain;

  pushdecl_with_scope (x, b);

  return 0;
}



void
push_class_level_binding(tree name, tree x) asm("_push_class_level_binding");
void
push_class_level_binding(tree name, tree x)
{
  if (((n64_enum_tree_code) (x)->common.code) == TYPE_DECL && ((x)->decl.artificial_flag)
      && purpose_member (name, class_binding_level->class_shadowed))
    return;

  maybe_push_cache_obstack ();
  class_binding_level->class_shadowed
      = tree_cons (name, (((struct n64_tag_lang_identifier *)(name))->class_value),
     class_binding_level->class_shadowed);
  pop_obstacks ();
  (((struct n64_tag_lang_identifier *)(name))->class_value) = x;
  __extension__ ({ struct n64_tag_obstack *__o = (&decl_obstack); if (__o->next_free + sizeof (void *) > __o->chunk_limit) _obstack_newchunk (__o, sizeof (void *)); if (!__o->alloc_failed) { *((void **)__o->next_free) = ((void *)x); __o->next_free += sizeof (void *); } (void) 0; });
}



int
overloaded_globals_p(tree list) asm("_overloaded_globals_p");
int
overloaded_globals_p(tree list)
{
  my_friendly_assert (((n64_enum_tree_code) (list)->common.code) == TREE_LIST, 142);


  if ((((list)->common.lang_flag_0)))
    return -1;

  if (((n64_enum_tree_code) (((list)->list.purpose))->common.code) == IDENTIFIER_NODE)
    return 1;

  return 0;
}
tree
push_overloaded_decl(tree decl, int forgettable) asm("_push_overloaded_decl");
tree
push_overloaded_decl(tree decl, int forgettable)
{
  tree orig_name = ((decl)->decl.name);
  tree old;
  int doing_global = (global_bindings_p () || ! forgettable
        || flag_traditional || pseudo_global_level_p ());

  if (doing_global)
    {
      old = (((struct n64_tag_lang_identifier *)(orig_name))->global_value);
      if (old && ((n64_enum_tree_code) (old)->common.code) == FUNCTION_DECL
   && ((old)->decl.artificial_flag)
   && (((old)->decl.bit_field_flag) || ((old)->common.unsigned_flag)))
 {
   if (duplicate_decls (decl, old))
     return old;
   old = (tree) 
        ((void *)0)
                 ;
 }
    }
  else
    {
      old = (((struct n64_tag_lang_identifier *)(orig_name))->local_value);

      if (! purpose_member (orig_name, current_binding_level->shadowed))
 {
   current_binding_level->shadowed
     = tree_cons (orig_name, old, current_binding_level->shadowed);
   old = (tree) 
        ((void *)0)
                 ;
 }
    }

  if (old)
    {
      if (((n64_enum_tree_code) (old)->common.code) == TYPE_DECL && ((old)->decl.artificial_flag))
 {
   tree t = ((old)->common.type);
   if ((((t)->type.lang_flag_5)) && warn_shadow)
     cp_warning ("`%#D' hides constructor for `%#T'", decl, t);
   old = (tree) 
        ((void *)0)
                 ;
 }
      else if (is_overloaded_fn (old))
        {
          tree tmp;

   for (tmp = get_first_fn (old); tmp; tmp = (((tmp)->decl.lang_specific)->chain))
     if (decl == tmp || duplicate_decls (decl, tmp))
       return tmp;
 }
      else
 {
   cp_error_at ("previous non-function declaration `%#D'", old);
   cp_error ("conflicts with function declaration `%#D'", decl);
   return decl;
 }
    }

  if (old || ((n64_enum_tree_code) (decl)->common.code) == TEMPLATE_DECL)
    {
      if (old && is_overloaded_fn (old))
 (((decl)->decl.lang_specific)->chain) = get_first_fn (old);
      else
 (((decl)->decl.lang_specific)->chain) = (tree) 
                    ((void *)0)
                             ;
      old = tree_cons (orig_name, decl, (tree) 
                                       ((void *)0)
                                                );
      ((old)->common.type) = unknown_type_node;
    }
  else

    old = decl;

  if (doing_global)
    (((struct n64_tag_lang_identifier *)(orig_name))->global_value) = old;
  else
    (((struct n64_tag_lang_identifier *)(orig_name))->local_value) = old;

  return decl;
}




tree
implicitly_declare(tree functionid) asm("_implicitly_declare");
tree
implicitly_declare(tree functionid)
{
  register tree decl;
  int temp = allocation_temporary_p ();

  push_obstacks_nochange ();




  if (temp && (flag_traditional || !warn_implicit || toplevel_bindings_p ()))
    end_temporary_allocation ();




  decl = build_lang_decl (FUNCTION_DECL, functionid, default_function_type);

  ((decl)->decl.external_flag) = 1;
  ((decl)->common.public_flag) = 1;




  pushdecl (decl);
  rest_of_decl_compilation (decl, ((void *)0), 0, 0);

  if (warn_implicit

      && (((struct n64_tag_lang_identifier *)(functionid))->x ? ((struct n64_tag_lang_identifier *)(functionid))->x->implicit_decl : 0) == (tree) 
                                                 ((void *)0)
                                                          )
    {
      cp_pedwarn ("implicit declaration of function `%#D'", decl);
    }

  (((struct n64_tag_lang_identifier *)(functionid))->x == 0 ? ((struct n64_tag_lang_identifier *)(functionid))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(functionid))->x->implicit_decl = (decl));

  pop_obstacks ();

  return decl;
}







static char *
redeclaration_error_message(tree newdecl, tree olddecl) asm("_redeclaration_error_message");
static char *
redeclaration_error_message(tree newdecl, tree olddecl)
{
  if (((n64_enum_tree_code) (newdecl)->common.code) == TYPE_DECL)
    {



      if (comptypes (((newdecl)->common.type), ((olddecl)->common.type), 0))
 return 0;
      else
 return "redefinition of `%#D'";
    }
  else if (((n64_enum_tree_code) (newdecl)->common.code) == FUNCTION_DECL)
    {



      if (((olddecl)->decl.lang_specific) && (((olddecl)->decl.lang_specific)->decl_flags.abstract_virtual))
 return 0;





      if (((olddecl)->decl.initial) != (tree) 
                                   ((void *)0)
   
  && ((newdecl)->decl.initial) != (tree) 
                               ((void *)0)
                                        )
 {
   if (((olddecl)->decl.name) == (tree) 
                             ((void *)0)
                                      )
     return "`%#D' not declared in class";
   else
     return "redefinition of `%#D'";
 }
      return 0;
    }
  else if (((n64_enum_tree_code) (newdecl)->common.code) == TEMPLATE_DECL)
    {
      if (((olddecl)->decl.initial) && ((newdecl)->decl.initial))
 return "redefinition of `%#D'";
      return 0;
    }
  else if (current_binding_level == global_binding_level)
    {


      if (((newdecl)->decl.external_flag) || ((olddecl)->decl.external_flag))
 return 0;

      return "redefinition of `%#D'";
    }
  else
    {



      if (!(((newdecl)->decl.external_flag) && ((olddecl)->decl.external_flag)))
 return "redeclaration of `%#D'";
      return 0;
    }
}





tree
lookup_label(tree id) asm("_lookup_label");
tree
lookup_label(tree id)
{
  register tree decl = (((struct n64_tag_lang_identifier *)(id))->x ? ((struct n64_tag_lang_identifier *)(id))->x->label_value : 0);

  if (current_function_decl == (tree) 
                              ((void *)0)
                                       )
    {
      error ("label `%s' referenced outside of any function",
      ((id)->identifier.pointer));
      return (tree) 
            ((void *)0)
                     ;
    }

  if ((decl == (tree) 
              ((void *)0)
      
     || ((decl)->decl.linenum) == 0)
      && (named_label_uses == (tree) 
                             ((void *)0)
   
  || ((named_label_uses)->list.purpose) != current_binding_level->names
   || ((named_label_uses)->list.value) != decl))
    {
      named_label_uses
 = tree_cons (current_binding_level->names, decl, named_label_uses);
      ((named_label_uses)->common.type) = (tree)current_binding_level;
    }


  if (decl != (tree) 
             ((void *)0)
                      )
    {

      if (((decl)->decl.context) != current_function_decl
   && ! ((decl)->common.lang_flag_1))
 return shadow_label (id);
      return decl;
    }

  decl = build_decl (LABEL_DECL, id, void_type_node);


  ((decl)->decl.context) = current_function_decl;

  ((decl)->decl.mode) = VOIDmode;



  ((decl)->decl.linenum) = lineno;
  ((decl)->decl.filename) = input_filename;

  (((struct n64_tag_lang_identifier *)(id))->x == 0 ? ((struct n64_tag_lang_identifier *)(id))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(id))->x->label_value = (decl));

  named_labels = tree_cons ((tree) 
                           ((void *)0)
                                    , decl, named_labels);
  ((named_label_uses)->list.value) = decl;

  return decl;
}
tree
shadow_label(tree name) asm("_shadow_label");
tree
shadow_label(tree name)
{
  register tree decl = (((struct n64_tag_lang_identifier *)(name))->x ? ((struct n64_tag_lang_identifier *)(name))->x->label_value : 0);

  if (decl != (tree) 
             ((void *)0)
                      )
    {
      shadowed_labels = tree_cons ((tree) 
                                  ((void *)0)
                                           , decl, shadowed_labels);
      (((struct n64_tag_lang_identifier *)(name))->x == 0 ? ((struct n64_tag_lang_identifier *)(name))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(name))->x->label_value = ((tree) 
     ((void *)0)
     ));
      (((struct n64_tag_lang_identifier *)(decl))->x == 0 ? ((struct n64_tag_lang_identifier *)(decl))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(decl))->x->label_value = ((tree) 
     ((void *)0)
     ));
    }

  return lookup_label (name);
}





tree
define_label(char *filename, int line, tree name) asm("_define_label");
tree
define_label(char *filename, int line, tree name)
{
  tree decl = lookup_label (name);



  current_binding_level->more_cleanups_ok = 0;


  if (decl != (tree) 
             ((void *)0) 
                       && ((decl)->decl.context) != current_function_decl)
    {
      shadowed_labels = tree_cons ((tree) 
                                  ((void *)0)
                                           , decl, shadowed_labels);
      (((struct n64_tag_lang_identifier *)(name))->x == 0 ? ((struct n64_tag_lang_identifier *)(name))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(name))->x->label_value = ((tree) 
     ((void *)0)
     ));
      decl = lookup_label (name);
    }

  if (name == get_identifier ("wchar_t"))
    cp_pedwarn ("label named wchar_t");

  if (((decl)->decl.initial) != (tree) 
                            ((void *)0)
                                     )
    {
      cp_error ("duplicate label `%D'", decl);
      return 0;
    }
  else
    {
      tree uses, prev;
      int identified = 0;


      ((decl)->decl.initial) = error_mark_node;

      ((decl)->decl.filename) = filename;
      ((decl)->decl.linenum) = line;

      for (prev = (tree) 
                 ((void *)0)
                          , uses = named_label_uses;
    uses;
    prev = uses, uses = ((uses)->common.chain))
 if (((uses)->list.value) == decl)
   {
     struct n64_tag_binding_level *b = current_binding_level;
     while (b)
       {
  tree new_decls = b->names;
  tree old_decls = ((tree)b == ((uses)->common.type)
      ? ((uses)->list.purpose) : (tree) 
                             ((void *)0)
                                      );
  while (new_decls != old_decls)
    {
      if (((n64_enum_tree_code) (new_decls)->common.code) == VAR_DECL




   && ! ((new_decls)->decl.artificial_flag)
   && ((((new_decls)->decl.initial) != (tree) 
                                   ((void *)0)
        
       && ((new_decls)->decl.initial) != error_mark_node)
       || ((((new_decls)->common.type))->type.needs_constructing_flag)))
        {
   if (! identified)
     cp_error ("jump to label `%D'", decl);
   identified = 1;
   cp_error_at ("  crosses initialization of `%#D'",
         new_decls);
        }
      new_decls = ((new_decls)->common.chain);
    }
  if ((tree)b == ((uses)->common.type))
    break;
  b = b->level_chain;
       }

     if (prev)
       ((prev)->common.chain) = ((uses)->common.chain);
     else
       named_label_uses = ((uses)->common.chain);
   }
      current_function_return_value = (tree) 
                                     ((void *)0)
                                              ;
      return decl;
    }
}

struct n64_tag_cp_switch
{
  struct n64_tag_binding_level *level;
  struct n64_tag_cp_switch *next;
};

static struct n64_tag_cp_switch *switch_stack;

void
push_switch(void) asm("_push_switch");
void
push_switch(void)
{
  struct n64_tag_cp_switch *p
    = (struct n64_tag_cp_switch *) oballoc (sizeof (struct n64_tag_cp_switch));
  p->level = current_binding_level;
  p->next = switch_stack;
  switch_stack = p;
}

void
pop_switch(void) asm("_pop_switch");
void
pop_switch(void)
{
  switch_stack = switch_stack->next;
}



void
define_case_label(tree decl) asm("_define_case_label");
void
define_case_label(tree decl)
{
  tree cleanup = last_cleanup_this_contour ();
  struct n64_tag_binding_level *b = current_binding_level;
  int identified = 0;

  if (cleanup)
    {
      static int explained = 0;
      cp_warning_at ("destructor needed for `%#D'", ((cleanup)->list.purpose));
      warning ("where case label appears here");
      if (!explained)
 {
   warning ("(enclose actions of previous case statements requiring");
   warning ("destructors in their own binding contours.)");
   explained = 1;
 }
    }

  for (; b && b != switch_stack->level; b = b->level_chain)
    {
      tree new_decls = b->names;
      for (; new_decls; new_decls = ((new_decls)->common.chain))
 {
   if (((n64_enum_tree_code) (new_decls)->common.code) == VAR_DECL




       && ! ((new_decls)->decl.artificial_flag)
       && ((((new_decls)->decl.initial) != (tree) 
                                       ((void *)0)
     
    && ((new_decls)->decl.initial) != error_mark_node)
    || ((((new_decls)->common.type))->type.needs_constructing_flag)))
     {
       if (! identified)
  error ("jump to case label");
       identified = 1;
       cp_error_at ("  crosses initialization of `%#D'",
      new_decls);
     }
 }
    }




  current_binding_level->more_cleanups_ok = 0;
  current_function_return_value = (tree) 
                                 ((void *)0)
                                          ;
}






tree
getdecls(void) asm("_getdecls");
tree
getdecls(void)
{
  return current_binding_level->names;
}



tree
gettags(void) asm("_gettags");
tree
gettags(void)
{
  return current_binding_level->tags;
}





static void
storedecls(tree decls) asm("_storedecls");
static void
storedecls(tree decls)
{
  current_binding_level->names = decls;
}



static void
storetags(tree tags) asm("_storetags");
static void
storetags(tree tags)
{
  current_binding_level->tags = tags;
}
static tree
lookup_tag(n64_enum_tree_code form, tree name, struct n64_tag_binding_level *binding_level, int thislevel_only) asm("_lookup_tag");
static tree
lookup_tag(n64_enum_tree_code form, tree name, struct n64_tag_binding_level *binding_level, int thislevel_only)
{
  register struct n64_tag_binding_level *level;

  for (level = binding_level; level; level = level->level_chain)
    {
      register tree tail;
      if ((((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
 for (tail = level->tags; tail; tail = ((tail)->common.chain))
   {


     if ((((((((tail)->list.value))->type.name))->decl.name)) == name)
       return ((tail)->list.value);
   }
      else
 for (tail = level->tags; tail; tail = ((tail)->common.chain))
   {
     if (((tail)->list.purpose) == name)
       {
  n64_enum_tree_code code = ((n64_enum_tree_code) (((tail)->list.value))->common.code);


  if (code != form
      && !(form != ENUMERAL_TYPE
    && (code == TEMPLATE_DECL
        || code == UNINSTANTIATED_P_TYPE)))

    {

      cp_error ("`%#D' redeclared as %C", ((tail)->list.value),
         form);
    }
  return ((tail)->list.value);
       }
   }
      if (thislevel_only && ! level->tag_transparent)
 return (tree) 
       ((void *)0)
                ;
      if (current_class_type && level->level_chain == global_binding_level)
 {


   tree context = current_class_type;
   while (context)
     {
       switch ((*tree_code_type[(int) (((n64_enum_tree_code) (context)->common.code))]))
  {
  tree these_tags;
  case 't':
      these_tags = (((context)->type.lang_specific)->tags);
      if ((((name)->identifier.pointer)[0] == '.' && ((name)->identifier.pointer)[1] == '_'))
        while (these_tags)
   {
     if ((((((((these_tags)->list.value))->type.name))->decl.name))
         == name)
       return ((tail)->list.value);
     these_tags = ((these_tags)->common.chain);
   }
      else
        while (these_tags)
   {
     if (((these_tags)->list.purpose) == name)
       {
         if (((n64_enum_tree_code) (((these_tags)->list.value))->common.code) != form)
    {
      cp_error ("`%#D' redeclared as %C in class scope",
         ((tail)->list.value), form);
    }
         return ((tail)->list.value);
       }
     these_tags = ((these_tags)->common.chain);
   }


      if (((context)->type.size) == (tree) 
                                ((void *)0)
                                         )
        goto no_context;

      context = ((((context)->type.name))->decl.context);
      break;
         case 'd':
      context = ((context)->decl.context);
      break;
         default:
      my_friendly_abort (10);
  }
       continue;
       no_context:
       break;
     }
 }
    }
  return (tree) 
        ((void *)0)
                 ;
}

void
set_current_level_tags_transparency(int tags_transparent) asm("_set_current_level_tags_transparency");
void
set_current_level_tags_transparency(int tags_transparent)
{
  current_binding_level->tag_transparent = tags_transparent;
}
static tree
lookup_tag_reverse(tree type, tree name) asm("_lookup_tag_reverse");
static tree
lookup_tag_reverse(tree type, tree name)
{
  register struct n64_tag_binding_level *level;

  for (level = current_binding_level; level; level = level->level_chain)
    {
      register tree tail;
      for (tail = level->tags; tail; tail = ((tail)->common.chain))
 {
   if (((tail)->list.value) == type)
     {
       if (name)
  ((tail)->list.purpose) = name;
       return ((tail)->list.purpose);
     }
 }
    }
  return (tree) 
        ((void *)0)
                 ;
}



tree
typedecl_for_tag(tree tag) asm("_typedecl_for_tag");
tree
typedecl_for_tag(tree tag)
{
  struct n64_tag_binding_level *b = current_binding_level;

  if (((n64_enum_tree_code) (((tag)->type.name))->common.code) == TYPE_DECL)
    return ((tag)->type.name);

  while (b)
    {
      tree decls = b->names;
      while (decls)
 {
   if (((n64_enum_tree_code) (decls)->common.code) == TYPE_DECL && ((decls)->common.type) == tag)
     break;
   decls = ((decls)->common.chain);
 }
      if (decls)
 return decls;
      b = b->level_chain;
    }
  return (tree) 
        ((void *)0)
                 ;
}



static tree
lookup_nested_type(tree type, tree context) asm("_lookup_nested_type");
static tree
lookup_nested_type(tree type, tree context)
{
  if (context == (tree) 
                ((void *)0)
                         )
    return (tree) 
          ((void *)0)
                   ;
  while (context)
    {
      switch (((n64_enum_tree_code) (context)->common.code))
 {
 case TYPE_DECL:
   {
     tree ctype = ((context)->common.type);
     tree match = value_member (type, (((ctype)->type.lang_specific)->tags));
     if (match)
       return ((match)->list.value);
     context = ((context)->decl.context);






     if (context && ((n64_enum_tree_code) (context)->common.code) == RECORD_TYPE)
       context = ((context)->common.chain);
   }
   break;
 case FUNCTION_DECL:
   if (((type)->type.name) && (((((type)->type.name))->decl.name)))
     return lookup_name ((((((type)->type.name))->decl.name)), 1);
   return (tree) 
         ((void *)0)
                  ;
 default:
   my_friendly_abort (12);
 }
    }
  return (tree) 
        ((void *)0)
                 ;
}


tree
lookup_namespace_name(tree cxx_namespace, tree name) asm("_lookup_namespace_name");
tree
lookup_namespace_name(tree cxx_namespace, tree name)
{
  struct n64_tag_binding_level *b = (struct n64_tag_binding_level *)((cxx_namespace)->decl.arguments);
  tree x;

  for (x = (tree) 
          ((void *)0)
                   ; b && !x; b = b->level_chain)
    {
      for (x = b->names; x; x = ((x)->common.chain))
 if (((x)->decl.name) == name || ((x)->decl.assembler_name) == name)
   break;

      break;
    }
  return x;
}
tree
lookup_name_real(tree name, int prefer_type, int nonclass) asm("_lookup_name_real");
tree
lookup_name_real(tree name, int prefer_type, int nonclass)
{
  register tree val;
  int yylex = 0;
  tree from_obj = (tree) 
                 ((void *)0)
                          ;

  if (prefer_type == -2)
    {
      extern int looking_for_typename;
      tree type;

      yylex = 1;
      prefer_type = looking_for_typename;

      if (got_scope)
 type = got_scope;
      else if (got_object != error_mark_node)
 type = got_object;

      if (type)
 {
   if (type == error_mark_node)
     return error_mark_node;
   else if (type == void_type_node)
     val = (((struct n64_tag_lang_identifier *)(name))->global_value);
   else if (((n64_enum_tree_code) (type)->common.code) == TEMPLATE_TYPE_PARM

     || ((n64_enum_tree_code) (type)->common.code) == UNINSTANTIATED_P_TYPE)
     {
       if (prefer_type > 0)
  val = create_nested_upt (type, name);
       else
  val = (tree) 
       ((void *)0)
                ;
     }
   else if (((n64_enum_tree_code) (type)->common.code) == NAMESPACE_DECL)
     {
       val = lookup_namespace_name (type, name);
     }
   else if (! (((type)->type.lang_flag_5)))

     val = (tree) 
          ((void *)0)
                   ;
   else if ((((type)->type.lang_specific)->type_flags.being_defined))
     {
       val = (((struct n64_tag_lang_identifier *)(name))->class_value);
       if (val && ((val)->decl.context) != type)
  {
    struct n64_tag_binding_level *b = class_binding_level;
    for (val = (tree) 
              ((void *)0)
                       ; b; b = b->level_chain)
      {
        tree t = purpose_member (name, b->class_shadowed);
        if (t && ((t)->list.value)
     && ((((t)->list.value))->decl.context) == type)
   {
     val = ((t)->list.value);
     break;
   }
      }
  }
       if (val == (tree) 
                 ((void *)0)
    
   && (((type)->type.lang_specific)->type_flags.local_typedecls))
  val = lookup_field (type, name, 0, 1);
     }
   else if (type == current_class_type)
     val = (((struct n64_tag_lang_identifier *)(name))->class_value);
   else
     val = lookup_field (type, name, 0, prefer_type);
 }
      else
 val = (tree) 
      ((void *)0)
               ;

      if (got_scope)
 goto done;


      else if (got_object && val && ((n64_enum_tree_code) (val)->common.code) == TYPE_DECL)
 from_obj = val;
    }

  if (current_binding_level != global_binding_level
      && (((struct n64_tag_lang_identifier *)(name))->local_value))
    val = (((struct n64_tag_lang_identifier *)(name))->local_value);


  else if (current_class_type && ! nonclass)
    {
      val = (((struct n64_tag_lang_identifier *)(name))->class_value);
      if (val == (tree) 
                ((void *)0)
   
  && (((current_class_type)->type.lang_specific)->type_flags.being_defined)
   && (((current_class_type)->type.lang_specific)->type_flags.local_typedecls))



 val = lookup_field (current_class_type, name, 0, 1);




      if (val == (tree) 
                ((void *)0)
                         )
 val = lookup_nested_field (name, ! yylex);

      if (val == (tree) 
                ((void *)0)
                         )
 val = (((struct n64_tag_lang_identifier *)(name))->global_value);
    }
  else
    val = (((struct n64_tag_lang_identifier *)(name))->global_value);

 done:
  if (val)
    {
      if (from_obj && from_obj != val)
 cp_error ("lookup in the scope of `%#T' does not match lookup in the current scope",
    got_object);

      if ((((n64_enum_tree_code) (val)->common.code) == TEMPLATE_DECL && looking_for_template)
   || ((n64_enum_tree_code) (val)->common.code) == TYPE_DECL || prefer_type <= 0)
 ;
      else if ((((name)->common.type) ? 1 : 0))
 val = (((((name)->common.type)))->type.name);
      else if (((val)->common.type) == error_mark_node)
 val = error_mark_node;
    }
  else if (from_obj)
    val = from_obj;

  return val;
}

tree
lookup_name_nonclass(tree name) asm("_lookup_name_nonclass");
tree
lookup_name_nonclass(tree name)
{
  return lookup_name_real (name, 0, 1);
}

tree
lookup_name(tree name, int prefer_type) asm("_lookup_name");
tree
lookup_name(tree name, int prefer_type)
{
  return lookup_name_real (name, prefer_type, 0);
}



tree
lookup_name_current_level(tree name) asm("_lookup_name_current_level");
tree
lookup_name_current_level(tree name)
{
  register tree t = (tree) 
                   ((void *)0)
                            ;

  if (current_binding_level == global_binding_level)
    {
      t = (((struct n64_tag_lang_identifier *)(name))->global_value);


      if (t != (tree) 
              ((void *)0) 
                        && ((n64_enum_tree_code) (t)->common.code) == TREE_LIST)
 t = ((t)->list.value);
    }
  else if ((((struct n64_tag_lang_identifier *)(name))->local_value) != (tree) 
                                           ((void *)0)
                                                    )
    {
      struct n64_tag_binding_level *b = current_binding_level;
      while (1)
 {
   for (t = b->names; t; t = ((t)->common.chain))
     if (((t)->decl.name) == name || ((t)->decl.assembler_name) == name)
       goto out;
   if (b->keep == 2)
     b = b->level_chain;
   else
     break;
 }
    out:
      ;
    }

  return t;
}
static void
signal_catch(int sig) asm("_signal_catch");
static void
signal_catch(int sig)
{
  signal (
         11
                , 
                  (__p_sig_fn_t)0
                         );




  signal (
         4
               , 
                 (__p_sig_fn_t)0
                        );


  signal (
         22
                , 
                  (__p_sig_fn_t)0
                         );




  my_friendly_abort (0);
}



static tree *builtin_type_tdescs_arr;
static int builtin_type_tdescs_len, builtin_type_tdescs_max;






static void
record_builtin_type(n64_enum_rid rid_index, char *name, tree type) asm("_record_builtin_type");
static void
record_builtin_type(n64_enum_rid rid_index, char *name, tree type)
{
  tree rname = (tree) 
              ((void *)0)
                       , tname = (tree) 
                                 ((void *)0)
                                          ;
  tree tdecl;

  if ((int) rid_index < (int) RID_MAX)
    rname = ridpointers[(int) rid_index];
  if (name)
    tname = get_identifier (name);

  ((type)->type.lang_flag_6) = 1;

  if (tname)
    {



      tdecl = pushdecl (build_decl (TYPE_DECL, tname, type));

      set_identifier_type_value (tname, (tree) 
                                       ((void *)0)
                                                );
      if ((int) rid_index < (int) RID_MAX)
 (((struct n64_tag_lang_identifier *)(tname))->global_value) = tdecl;
    }
  if (rname != (tree) 
              ((void *)0)
                       )
    {
      if (tname != (tree) 
                  ((void *)0)
                           )
 {
   set_identifier_type_value (rname, (tree) 
                                    ((void *)0)
                                             );
   (((struct n64_tag_lang_identifier *)(rname))->global_value) = tdecl;
 }
      else
 {



   tdecl = pushdecl (build_decl (TYPE_DECL, rname, type));

   set_identifier_type_value (rname, (tree) 
                                    ((void *)0)
                                             );
 }
    }

  if (flag_rtti)
    {
      if (builtin_type_tdescs_len+5 >= builtin_type_tdescs_max)
 {
   builtin_type_tdescs_max *= 2;
   builtin_type_tdescs_arr
     = (tree *)xrealloc (builtin_type_tdescs_arr,
    builtin_type_tdescs_max * sizeof (tree));
 }
      builtin_type_tdescs_arr[builtin_type_tdescs_len++] = type;
      if (((n64_enum_tree_code) (type)->common.code) != POINTER_TYPE)
 {
   builtin_type_tdescs_arr[builtin_type_tdescs_len++]
     = build_pointer_type (type);
   builtin_type_tdescs_arr[builtin_type_tdescs_len++]
     = build_pointer_type (build_type_variant (type, 1, 0));
 }
      if (((n64_enum_tree_code) (type)->common.code) != VOID_TYPE)
 {
   builtin_type_tdescs_arr[builtin_type_tdescs_len++]
     = build_reference_type (type);
   builtin_type_tdescs_arr[builtin_type_tdescs_len++]
     = build_reference_type (build_type_variant (type, 1, 0));
 }
    }
}

static void
output_builtin_tdesc_entries(void) asm("_output_builtin_tdesc_entries");
static void
output_builtin_tdesc_entries(void)
{
  extern struct n64_tag_obstack permanent_obstack;


  if (builtin_type_tdescs_arr == 0)
    return;

  push_obstacks (&permanent_obstack, &permanent_obstack);
  while (builtin_type_tdescs_len > 0)
    {
      tree type = builtin_type_tdescs_arr[--builtin_type_tdescs_len];
      tree tdesc = build_t_desc (type, 0);
      ((tdesc)->common.asm_written_flag) = 0;
      build_t_desc (type, 2);
    }
  free (builtin_type_tdescs_arr);
  builtin_type_tdescs_arr = 0;
  pop_obstacks ();
}



static void
push_overloaded_decl_1(tree x) asm("_push_overloaded_decl_1");
static void
push_overloaded_decl_1(tree x)
{
  push_overloaded_decl (x, 0);
}







tree auto_function(tree name, tree type, n64_enum_built_in_function code) asm("_auto_function");
tree auto_function(tree name, tree type, n64_enum_built_in_function code)
{
  return define_function
    (((name)->identifier.pointer), type, code, (void (*)(...))push_overloaded_decl_1,
     ((build_decl_overload (name, ((type)->type.values), 0))->identifier.pointer)
              );
}






void
init_decl_processing(void) asm("_init_decl_processing");
void
init_decl_processing(void)
{
  tree decl;
  register tree endlink, int_endlink, double_endlink, ptr_endlink;
  tree fields[20];

  tree traditional_ptr_type_node;

  tree memcpy_ftype;




  int wchar_type_size;
  tree temp;
  tree array_domain_type;
  extern int flag_strict_prototype;


  lang_name_cplusplus = get_identifier ("C++");
  lang_name_c = get_identifier ("C");

  if (flag_strict_prototype == 2)
    {
      if (pedantic)
 strict_prototypes_lang_c = strict_prototypes_lang_cplusplus;
    }
  else
    strict_prototypes_lang_c = flag_strict_prototype;


  current_lang_name = lang_name_c;

  current_function_decl = (tree) 
                         ((void *)0)
                                  ;
  named_labels = (tree) 
                ((void *)0)
                         ;
  named_label_uses = (tree) 
                    ((void *)0)
                             ;
  current_binding_level = ((struct n64_tag_binding_level *) 
                         ((void *)0)
                         );
  free_binding_level = ((struct n64_tag_binding_level *) 
                      ((void *)0)
                      );




  signal (
         11
                , signal_catch);
  signal (
         4
               , signal_catch);


  signal (
         22
                , signal_catch);





  gcc_obstack_init (&decl_obstack);
  if (flag_rtti)
    {
      builtin_type_tdescs_max = 100;
      builtin_type_tdescs_arr = (tree *)xmalloc (100 * sizeof (tree));
    }


  error_mark_node = make_node (ERROR_MARK);
  ((error_mark_node)->common.permanent_flag) = 1;
  ((error_mark_node)->common.type) = error_mark_node;
  error_mark_list = build_tree_list (error_mark_node, error_mark_node);
  ((error_mark_list)->common.type) = error_mark_node;


  pushlevel (0);
  global_binding_level = current_binding_level;

  this_identifier = get_identifier ("this");
  in_charge_identifier = get_identifier ("__in_chrg");
  pfn_identifier = get_identifier ("__pfn");
  index_identifier = get_identifier ("__index");
  delta_identifier = get_identifier ("__delta");
  delta2_identifier = get_identifier ("__delta2");
  pfn_or_delta2_identifier = get_identifier ("__pfn_or_delta2");
  if (flag_handle_signatures)
    {
      tag_identifier = get_identifier ("__tag");
      vb_off_identifier = get_identifier ("__vb_off");
      vt_off_identifier = get_identifier ("__vt_off");
    }



  integer_type_node = make_signed_type (((target_flags & 0x00000001) ? 64 : 32));
  record_builtin_type (RID_INT, ((void *)0), integer_type_node);




  char_type_node =
    (flag_signed_char
     ? make_signed_type (8)
     : make_unsigned_type (8));
  record_builtin_type (RID_CHAR, "char", char_type_node);

  long_integer_type_node = make_signed_type (((target_flags & 0x00000002) ? 64 : 32));
  record_builtin_type (RID_LONG, "long int", long_integer_type_node);

  unsigned_type_node = make_unsigned_type (((target_flags & 0x00000001) ? 64 : 32));
  record_builtin_type (RID_UNSIGNED, "unsigned int", unsigned_type_node);

  long_unsigned_type_node = make_unsigned_type (((target_flags & 0x00000002) ? 64 : 32));
  record_builtin_type (RID_MAX, "long unsigned int", long_unsigned_type_node);
  record_builtin_type (RID_MAX, "unsigned long", long_unsigned_type_node);

  long_long_integer_type_node = make_signed_type (64);
  record_builtin_type (RID_MAX, "long long int", long_long_integer_type_node);

  long_long_unsigned_type_node = make_unsigned_type (64);
  record_builtin_type (RID_MAX, "long long unsigned int",
         long_long_unsigned_type_node);
  record_builtin_type (RID_MAX, "long long unsigned",
         long_long_unsigned_type_node);





  sizetype
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("unsigned int")))->global_value))->common.type);
  if (flag_traditional && ((sizetype)->common.unsigned_flag))
    sizetype = signed_type (sizetype);

  ptrdiff_type_node
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("int")))->global_value))->common.type);

  ((((integer_type_node)->type.size))->common.type) = sizetype;
  ((((char_type_node)->type.size))->common.type) = sizetype;
  ((((unsigned_type_node)->type.size))->common.type) = sizetype;
  ((((long_unsigned_type_node)->type.size))->common.type) = sizetype;
  ((((long_integer_type_node)->type.size))->common.type) = sizetype;
  ((((long_long_integer_type_node)->type.size))->common.type) = sizetype;
  ((((long_long_unsigned_type_node)->type.size))->common.type) = sizetype;

  short_integer_type_node = make_signed_type (16);
  record_builtin_type (RID_SHORT, "short int", short_integer_type_node);
  short_unsigned_type_node = make_unsigned_type (16);
  record_builtin_type (RID_MAX, "short unsigned int", short_unsigned_type_node);
  record_builtin_type (RID_MAX, "unsigned short", short_unsigned_type_node);


  signed_char_type_node = make_signed_type (8);
  record_builtin_type (RID_MAX, "signed char", signed_char_type_node);
  unsigned_char_type_node = make_unsigned_type (8);
  record_builtin_type (RID_MAX, "unsigned char", unsigned_char_type_node);


  intQI_type_node = make_signed_type ((8 * mode_size[(int)(QImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intQI_type_node));
  intHI_type_node = make_signed_type ((8 * mode_size[(int)(HImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intHI_type_node));
  intSI_type_node = make_signed_type ((8 * mode_size[(int)(SImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intSI_type_node));
  intDI_type_node = make_signed_type ((8 * mode_size[(int)(DImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , intDI_type_node));
  unsigned_intQI_type_node = make_unsigned_type ((8 * mode_size[(int)(QImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intQI_type_node));
  unsigned_intHI_type_node = make_unsigned_type ((8 * mode_size[(int)(HImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intHI_type_node));
  unsigned_intSI_type_node = make_unsigned_type ((8 * mode_size[(int)(SImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intSI_type_node));
  unsigned_intDI_type_node = make_unsigned_type ((8 * mode_size[(int)(DImode)]));
  pushdecl (build_decl (TYPE_DECL, (tree) 
                                  ((void *)0)
                                           , unsigned_intDI_type_node));

  float_type_node = make_node (REAL_TYPE);
  ((float_type_node)->type.precision) = 32;
  record_builtin_type (RID_FLOAT, ((void *)0), float_type_node);
  layout_type (float_type_node);

  double_type_node = make_node (REAL_TYPE);
  if (flag_short_double)
    ((double_type_node)->type.precision) = 32;
  else
    ((double_type_node)->type.precision) = 64;
  record_builtin_type (RID_DOUBLE, ((void *)0), double_type_node);
  layout_type (double_type_node);

  long_double_type_node = make_node (REAL_TYPE);
  ((long_double_type_node)->type.precision) = 64;
  record_builtin_type (RID_MAX, "long double", long_double_type_node);
  layout_type (long_double_type_node);

  integer_zero_node = build_int_2_wide ((int) (0), (int) (0));
  ((integer_zero_node)->common.type) = integer_type_node;
  integer_one_node = build_int_2_wide ((int) (1), (int) (0));
  ((integer_one_node)->common.type) = integer_type_node;
  integer_two_node = build_int_2_wide ((int) (2), (int) (0));
  ((integer_two_node)->common.type) = integer_type_node;
  integer_three_node = build_int_2_wide ((int) (3), (int) (0));
  ((integer_three_node)->common.type) = integer_type_node;

  boolean_type_node = make_unsigned_type (((1) ? (((target_flags & 0x00002000) ? 64 : 32)) : (8)));
  ((boolean_type_node)->common.code = (int) (BOOLEAN_TYPE));
  record_builtin_type (RID_BOOL, "bool", boolean_type_node);
  boolean_false_node = build_int_2_wide ((int) (0), (int) (0));
  ((boolean_false_node)->common.type) = boolean_type_node;
  boolean_true_node = build_int_2_wide ((int) (1), (int) (0));
  ((boolean_true_node)->common.type) = boolean_type_node;


  size_zero_node = size_int (0);
  size_one_node = size_int (1);

  void_type_node = make_node (VOID_TYPE);
  record_builtin_type (RID_VOID, ((void *)0), void_type_node);
  layout_type (void_type_node);
  void_list_node = build_tree_list ((tree) 
                                   ((void *)0)
                                            , void_type_node);
  ((void_list_node)->common.unsigned_flag) = 1;

  null_pointer_node = build_int_2_wide ((int) (0), (int) (0));
  ((null_pointer_node)->common.type) = build_pointer_type (void_type_node);
  layout_type (((null_pointer_node)->common.type));


  void_zero_node = build_int_2_wide ((int) (0), (int) (0));
  ((void_zero_node)->common.type) = void_type_node;

  string_type_node = build_pointer_type (char_type_node);
  const_string_type_node =
    build_pointer_type (build_type_variant (char_type_node, 1, 0));
  record_builtin_type (RID_MAX, ((void *)0), string_type_node);






  array_domain_type = build_index_type (build_int_2_wide ((int) (200), (int) (0)));




  char_array_type_node
    = build_array_type (char_type_node, array_domain_type);

  int_array_type_node
    = build_array_type (integer_type_node, array_domain_type);



  class_star_type_node = build_pointer_type (make_lang_type (RECORD_TYPE));

  default_function_type
    = build_function_type (integer_type_node, (tree) 
                                             ((void *)0)
                                                      );
  build_pointer_type (default_function_type);

  ptr_type_node = build_pointer_type (void_type_node);
  const_ptr_type_node =
    build_pointer_type (build_type_variant (void_type_node, 1, 0));
  record_builtin_type (RID_MAX, ((void *)0), ptr_type_node);
  endlink = void_list_node;
  int_endlink = tree_cons ((tree) 
                          ((void *)0)
                                   , integer_type_node, endlink);
  double_endlink = tree_cons ((tree) 
                             ((void *)0)
                                      , double_type_node, endlink);
  ptr_endlink = tree_cons ((tree) 
                          ((void *)0)
                                   , ptr_type_node, endlink);

  double_ftype_double
    = build_function_type (double_type_node, double_endlink);

  double_ftype_double_double
    = build_function_type (double_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , double_type_node,
          double_endlink));

  int_ftype_int
    = build_function_type (integer_type_node, int_endlink);

  long_ftype_long
    = build_function_type (long_integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , long_integer_type_node,
          endlink));

  void_ftype_ptr_ptr_int
    = build_function_type (void_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , ptr_type_node,
       int_endlink)));

  int_ftype_cptr_cptr_sizet
    = build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , const_ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , const_ptr_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           sizetype,
           endlink))));

  void_ftype_ptr_int_int
    = build_function_type (void_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , integer_type_node,
       int_endlink)));

  string_ftype_ptr_ptr
    = build_function_type (string_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , string_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       const_string_type_node,
       endlink)));
  int_ftype_string_string
    = build_function_type (integer_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , const_string_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       const_string_type_node,
       endlink)));

  sizet_ftype_string
    = build_function_type (sizetype,
      tree_cons ((tree) 
                ((void *)0)
                         , const_string_type_node,
          endlink));

  traditional_ptr_type_node
    = (flag_traditional ? string_type_node : ptr_type_node);

  memcpy_ftype
    = build_function_type (traditional_ptr_type_node,
      tree_cons ((tree) 
                ((void *)0)
                         , ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , const_ptr_type_node,
       tree_cons ((tree) 
                 ((void *)0)
                          ,
           sizetype,
           endlink))));

  if (flag_huge_objects)
    delta_type_node = long_integer_type_node;
  else
    delta_type_node = short_integer_type_node;

  define_function ("__builtin_constant_p", int_ftype_int, BUILT_IN_CONSTANT_P, (void (*)(...))pushdecl, ((void *)0))
                                    ;

  builtin_return_address_fndecl =
  define_function ("__builtin_return_address", build_function_type (ptr_type_node, tree_cons ((tree) 
 ((void *)0)
 , unsigned_type_node, endlink)), BUILT_IN_RETURN_ADDRESS, (void (*)(...))pushdecl, ((void *)0))




                                        ;

  define_function ("__builtin_frame_address", build_function_type (ptr_type_node, tree_cons ((tree) 
 ((void *)0)
 , unsigned_type_node, endlink)), BUILT_IN_FRAME_ADDRESS, (void (*)(...))pushdecl, ((void *)0))




                                       ;


  define_function ("__builtin_alloca", build_function_type (ptr_type_node, tree_cons ((tree) 
 ((void *)0)
 , sizetype, endlink)), BUILT_IN_ALLOCA, (void (*)(...))pushdecl, "alloca")




                                ;


  if (! flag_no_builtin && !flag_no_nonansi_builtin)
    {
      temp = define_function ("alloca", build_function_type (ptr_type_node, tree_cons ((tree) 
            ((void *)0)
            , sizetype, endlink)), BUILT_IN_ALLOCA, (void (*)(...))pushdecl, ((void *)0))




                                    ;

      ((temp)->common.unsigned_flag) = 1;
      temp = define_function ("ffs", int_ftype_int, BUILT_IN_FFS, (void (*)(...))pushdecl, ((void *)0));

      ((temp)->common.unsigned_flag) = 1;
      temp = define_function ("_exit", build_function_type (void_type_node, int_endlink), NOT_BUILT_IN, (void (*)(...))pushdecl, ((void *)0))

                                 ;
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;

      ((temp)->common.unsigned_flag) = 1;
    }

  define_function ("__builtin_abs", int_ftype_int, BUILT_IN_ABS, (void (*)(...))pushdecl, ((void *)0))
                             ;
  define_function ("__builtin_fabs", double_ftype_double, BUILT_IN_FABS, (void (*)(...))pushdecl, ((void *)0))
                              ;
  define_function ("__builtin_labs", long_ftype_long, BUILT_IN_LABS, (void (*)(...))pushdecl, ((void *)0))
                              ;
  define_function ("__builtin_ffs", int_ftype_int, BUILT_IN_FFS, (void (*)(...))pushdecl, ((void *)0))
                             ;
  define_function ("__builtin_fsqrt", double_ftype_double, BUILT_IN_FSQRT, (void (*)(...))pushdecl, ((void *)0))
                               ;
  define_function ("__builtin_sin", double_ftype_double, BUILT_IN_SIN, (void (*)(...))pushdecl, "sin")
                          ;
  define_function ("__builtin_cos", double_ftype_double, BUILT_IN_COS, (void (*)(...))pushdecl, "cos")
                          ;
  define_function ("__builtin_saveregs", build_function_type (ptr_type_node, (tree) 
 ((void *)0)
 ), BUILT_IN_SAVEREGS, (void (*)(...))pushdecl, ((void *)0))

                                  ;
  define_function ("__builtin_classify_type", default_function_type, BUILT_IN_CLASSIFY_TYPE, (void (*)(...))pushdecl, ((void *)0))
                                       ;
  define_function ("__builtin_next_arg", build_function_type (ptr_type_node, (tree) 
 ((void *)0)
 ), BUILT_IN_NEXT_ARG, (void (*)(...))pushdecl, ((void *)0))

                                  ;
  define_function ("__builtin_args_info", build_function_type (integer_type_node, tree_cons ((tree) 
 ((void *)0)
 , integer_type_node, endlink)), BUILT_IN_ARGS_INFO, (void (*)(...))pushdecl, ((void *)0))




                                   ;


  define_function ("__builtin_apply_args", build_function_type (ptr_type_node, (tree) 
 ((void *)0)
 ), BUILT_IN_APPLY_ARGS, (void (*)(...))pushdecl, ((void *)0))

                                    ;

  temp = tree_cons ((tree) 
                   ((void *)0)
                            ,
      build_pointer_type (build_function_type (void_type_node,
            (tree) 
           ((void *)0)
                    )),
      tree_cons ((tree) 
                ((void *)0)
                         ,
          ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             ,
       sizetype,
       endlink)));
  define_function ("__builtin_apply", build_function_type (ptr_type_node, temp), BUILT_IN_APPLY, (void (*)(...))pushdecl, ((void *)0))

                               ;
  define_function ("__builtin_return", build_function_type (void_type_node, tree_cons ((tree) 
 ((void *)0)
 , ptr_type_node, endlink)), BUILT_IN_RETURN, (void (*)(...))pushdecl, ((void *)0))




                                ;


  define_function ("__builtin_memcpy", memcpy_ftype, BUILT_IN_MEMCPY, (void (*)(...))pushdecl, "memcpy")
                                ;
  define_function ("__builtin_memcmp", int_ftype_cptr_cptr_sizet, BUILT_IN_MEMCMP, (void (*)(...))pushdecl, "memcmp")
                                ;
  define_function ("__builtin_strcmp", int_ftype_string_string, BUILT_IN_STRCMP, (void (*)(...))pushdecl, "strcmp")
                                ;
  define_function ("__builtin_strcpy", string_ftype_ptr_ptr, BUILT_IN_STRCPY, (void (*)(...))pushdecl, "strcpy")
                                ;





  define_function ("__builtin_strlen", sizet_ftype_string, BUILT_IN_STRLEN, (void (*)(...))pushdecl, "strlen")
                                ;

  if (!flag_no_builtin)
    {





      define_function ("memcpy", memcpy_ftype, BUILT_IN_MEMCPY, (void (*)(...))pushdecl, ((void *)0));
      define_function ("memcmp", int_ftype_cptr_cptr_sizet, BUILT_IN_MEMCMP, (void (*)(...))pushdecl, ((void *)0))
            ;
      define_function ("strcmp", int_ftype_string_string, BUILT_IN_STRCMP, (void (*)(...))pushdecl, ((void *)0));
      define_function ("strcpy", string_ftype_ptr_ptr, BUILT_IN_STRCPY, (void (*)(...))pushdecl, ((void *)0))
            ;




      define_function ("strlen", sizet_ftype_string, BUILT_IN_STRLEN, (void (*)(...))pushdecl, ((void *)0));
      define_function ("sin", double_ftype_double, BUILT_IN_SIN, (void (*)(...))pushdecl, ((void *)0));
      define_function ("cos", double_ftype_double, BUILT_IN_COS, (void (*)(...))pushdecl, ((void *)0));



      temp = define_function ("abort", build_function_type (void_type_node, endlink), NOT_BUILT_IN, (void (*)(...))pushdecl, ((void *)0))

                                 ;
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;


      ((temp)->common.unsigned_flag) = 1;
      temp = define_function ("exit", build_function_type (void_type_node, int_endlink), NOT_BUILT_IN, (void (*)(...))pushdecl, ((void *)0))

                                 ;
      ((temp)->common.volatile_flag) = 1;
      ((temp)->common.side_effects_flag) = 1;
      ((temp)->common.unsigned_flag) = 1;
    }
  unknown_type_node = make_node (LANG_TYPE);




  decl = pushdecl (build_decl (TYPE_DECL, get_identifier ("unknown type"),
   unknown_type_node));

  ((decl)->decl.ignored_flag) = 1;
  ((decl)->decl.external_flag) = 1;

  ((unknown_type_node)->type.size) = ((void_type_node)->type.size);
  ((unknown_type_node)->type.align) = 1;
  ((unknown_type_node)->type.mode) = ((void_type_node)->type.mode);

  ((unknown_type_node)->common.type) = unknown_type_node;

  ((unknown_type_node)->type.pointer_to) = unknown_type_node;
  ((unknown_type_node)->type.reference_to) = unknown_type_node;


  opaque_type_node = copy_node (ptr_type_node);
  ((opaque_type_node)->type.main_variant) = opaque_type_node;
  record_builtin_type (RID_MAX, 0, opaque_type_node);


  wchar_type_node
    = (((((struct n64_tag_lang_identifier *)(get_identifier ("long int")))->global_value))->common.type);
  wchar_type_size = ((wchar_type_node)->type.precision);
  signed_wchar_type_node = make_signed_type (wchar_type_size);
  unsigned_wchar_type_node = make_unsigned_type (wchar_type_size);
  wchar_type_node
    = ((wchar_type_node)->common.unsigned_flag)
      ? unsigned_wchar_type_node
      : signed_wchar_type_node;
  record_builtin_type (RID_WCHAR, "__wchar_t", wchar_type_node);


  wchar_decl_node = build_decl (TYPE_DECL, get_identifier ("wchar_t"),
    wchar_type_node);
  pushdecl (wchar_decl_node);


  wchar_array_type_node
    = build_array_type (wchar_type_node, array_domain_type);



  if (flag_gc)
    {
      define_function ("__gc_main", default_function_type, NOT_BUILT_IN, (void (*)(...))pushdecl, 0);
      pushdecl (lookup_name (get_identifier ("__gc_main"), 0));
    }

  if (flag_vtable_thunks)
    {


      tree vfunc_type = make_node (FUNCTION_TYPE);
      ((vfunc_type)->common.type) = integer_type_node;
      ((vfunc_type)->type.values) = (tree) 
                                   ((void *)0)
                                            ;
      layout_type (vfunc_type);

      vtable_entry_type = build_pointer_type (vfunc_type);
    }
  else
    {
      vtable_entry_type = make_lang_type (RECORD_TYPE);
      fields[0] = build_lang_field_decl (FIELD_DECL, delta_identifier,
      delta_type_node);
      fields[1] = build_lang_field_decl (FIELD_DECL, index_identifier,
      delta_type_node);
      fields[2] = build_lang_field_decl (FIELD_DECL, pfn_identifier,
      ptr_type_node);
      finish_builtin_type (vtable_entry_type, "__vtbl_ptr_type", fields, 2,
      double_type_node);


      fields[3] = copy_node (fields[2]);
      ((fields[3])->common.type) = delta_type_node;
      ((fields[3])->decl.name) = delta2_identifier;
      ((fields[3])->decl.mode) = ((delta_type_node)->type.mode);
      ((fields[3])->decl.size) = ((delta_type_node)->type.size);
      ((fields[3])->common.unsigned_flag) = 0;
      ((fields[2])->common.chain) = fields[3];
      vtable_entry_type = build_type_variant (vtable_entry_type, 1, 0);
    }
  record_builtin_type (RID_MAX, "__vtbl_ptr_type", vtable_entry_type);

  vtbl_type_node
    = build_array_type (vtable_entry_type, (tree) 
                                          ((void *)0)
                                                   );
  layout_type (vtbl_type_node);
  vtbl_type_node = cp_build_type_variant (vtbl_type_node, 1, 0);
  record_builtin_type (RID_MAX, ((void *)0), vtbl_type_node);




  if (flag_handle_signatures)
    {
      sigtable_entry_type = make_lang_type (RECORD_TYPE);
      fields[0] = build_lang_field_decl (FIELD_DECL, tag_identifier,
      delta_type_node);
      fields[1] = build_lang_field_decl (FIELD_DECL, vb_off_identifier,
      delta_type_node);
      fields[2] = build_lang_field_decl (FIELD_DECL, delta_identifier,
      delta_type_node);
      fields[3] = build_lang_field_decl (FIELD_DECL, index_identifier,
      delta_type_node);
      fields[4] = build_lang_field_decl (FIELD_DECL, pfn_identifier,
      ptr_type_node);



      finish_builtin_type (sigtable_entry_type, "__sigtbl_ptr_type", fields, 4,
      (((ptr_type_node)->type.align) > ((delta_type_node)->type.align))
      ? ptr_type_node
      : delta_type_node);


      fields[5] = copy_node (fields[4]);
      ((fields[5])->common.type) = delta_type_node;
      ((fields[5])->decl.name) = vt_off_identifier;
      ((fields[5])->decl.mode) = ((delta_type_node)->type.mode);
      ((fields[5])->decl.size) = ((delta_type_node)->type.size);
      ((fields[5])->common.unsigned_flag) = 0;
      ((fields[4])->common.chain) = fields[5];

      sigtable_entry_type = build_type_variant (sigtable_entry_type, 1, 0);
      record_builtin_type (RID_MAX, "__sigtbl_ptr_type", sigtable_entry_type);
    }
  current_lang_name = lang_name_cplusplus;

  auto_function (ansi_opname[(int) NEW_EXPR],
   build_function_type (ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , sizetype,
       void_list_node)),
   NOT_BUILT_IN);
  auto_function (ansi_opname[(int) VEC_NEW_EXPR],
   build_function_type (ptr_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , sizetype,
       void_list_node)),
   NOT_BUILT_IN);
  auto_function (ansi_opname[(int) DELETE_EXPR],
   build_function_type (void_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , ptr_type_node,
       void_list_node)),
   NOT_BUILT_IN);
  auto_function (ansi_opname[(int) VEC_DELETE_EXPR],
   build_function_type (void_type_node,
          tree_cons ((tree) 
                    ((void *)0)
                             , ptr_type_node,
       void_list_node)),
   NOT_BUILT_IN);

  abort_fndecl
    = define_function ("__pure_virtual",
         build_function_type (void_type_node, void_list_node),
         NOT_BUILT_IN, 0, 0);


  init_class_processing ();
  init_init_processing ();
  init_search_processing ();

  if (flag_handle_exceptions)
    init_exception_processing ();
  if (flag_gc)
    init_gc_processing ();
  if (flag_no_inline)
    {
      flag_inline_functions = 0;




    }
  if (flag_cadillac)
    init_cadillac ();


  declare_function_name ();


  init_function_format_info ();
}



int
init_type_desc(void) asm("_init_type_desc");
int
init_type_desc(void)
{
  tree tdecl;

  tdecl = lookup_name (get_identifier ("type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __t_desc_type_node = ((tdecl)->common.type);
  __tp_desc_type_node = build_pointer_type (__t_desc_type_node);
  tdecl = lookup_name (get_identifier ("__builtin_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __bltn_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__user_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __user_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__class_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __class_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_field (__class_desc_type_node,
 get_identifier ("access_mode"), 0, 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __access_mode_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__attr_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __attr_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__pointer_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __ptr_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__func_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __func_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__ptmf_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __ptmf_desc_type_node = ((tdecl)->common.type);

  tdecl = lookup_name (get_identifier ("__ptmd_type_info"), 0);
  if (tdecl == (tree) 
              ((void *)0)
                       )
    return 0;
  __ptmd_desc_type_node = ((tdecl)->common.type);

  return 1;
}
tree
define_function(char *name, tree type, n64_enum_built_in_function function_code, void (*pfn) (...), char *library_name) asm("_define_function");
tree
define_function(char *name, tree type, n64_enum_built_in_function function_code, void (*pfn) (...), char *library_name)
{
  tree decl = build_lang_decl (FUNCTION_DECL, get_identifier (name), type);
  ((decl)->decl.external_flag) = 1;
  ((decl)->common.public_flag) = 1;
  ((decl)->decl.artificial_flag) = 1;




  if (pfn) (*pfn) (decl);
  if (library_name)
    ((decl)->decl.assembler_name) = get_identifier (library_name);
  make_function_rtl (decl);
  if (function_code != NOT_BUILT_IN)
    {
      ((decl)->decl.bit_field_flag) = 1;
      ((decl)->decl.frame_size.f) = function_code;
    }
  return decl;
}
void
shadow_tag(tree declspecs) asm("_shadow_tag");
void
shadow_tag(tree declspecs)
{
  int found_tag = 0;
  tree ob_modifier = (tree) 
                    ((void *)0)
                             ;
  register tree link;
  register n64_enum_tree_code code, ok_code = ERROR_MARK;
  register tree t = (tree) 
                   ((void *)0)
                            ;

  for (link = declspecs; link; link = ((link)->common.chain))
    {
      register tree value = ((link)->list.value);

      code = ((n64_enum_tree_code) (value)->common.code);
      if ((code == RECORD_TYPE || code == UNION_TYPE || code == UNINSTANTIATED_P_TYPE) || code == ENUMERAL_TYPE)
 {
   my_friendly_assert (((value)->type.name) != (tree) 
                                           ((void *)0)
                                                    , 261);

   if (code == ENUMERAL_TYPE && ((value)->type.size) == 0)
     cp_error ("forward declaration of `%#T'", value);

   t = value;
   ok_code = code;
   found_tag++;
 }
      else if (value == ridpointers[(int) RID_STATIC]
        || value == ridpointers[(int) RID_EXTERN]
        || value == ridpointers[(int) RID_AUTO]
        || value == ridpointers[(int) RID_REGISTER]
        || value == ridpointers[(int) RID_INLINE]
        || value == ridpointers[(int) RID_VIRTUAL]
        || value == ridpointers[(int) RID_EXPLICIT])
 ob_modifier = value;
    }






  if (ok_code == UNION_TYPE
      && t != (tree) 
             ((void *)0)
      
     && ((((n64_enum_tree_code) (((t)->type.name))->common.code) == IDENTIFIER_NODE
    && (((((t)->type.name))->identifier.pointer)[0] == '.' && ((((t)->type.name))->identifier.pointer)[1] == '_'))
   || (((n64_enum_tree_code) (((t)->type.name))->common.code) == TYPE_DECL
       && ((((((((t)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((t)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))))
    {


      if (((t)->type.values))
 {
   tree decl = grokdeclarator ((tree) 
                              ((void *)0)
                                       , declspecs, NORMAL, 0,
          (tree) 
         ((void *)0)
                  , (tree) 
                    ((void *)0)
                             );
   finish_anon_union (decl);
 }
      else
 error ("anonymous union cannot have a function member");
    }
  else
    {



      if (ob_modifier)
 {
   if (ob_modifier == ridpointers[(int) RID_INLINE]
       || ob_modifier == ridpointers[(int) RID_VIRTUAL])
     cp_error ("`%D' can only be specified for functions", ob_modifier);
   else if (ob_modifier == ridpointers[(int) RID_EXPLICIT])
     cp_error ("`%D' can only be specified for constructors",
        ob_modifier);
   else
     cp_error ("`%D' can only be specified for objects and functions",
        ob_modifier);
 }

      if (found_tag == 0)
 pedwarn ("abstract declarator used as declaration");
      else if (found_tag > 1)
 pedwarn ("multiple types in one declaration");
    }
}



tree
groktypename(tree cxx_typename) asm("_groktypename");
tree
groktypename(tree cxx_typename)
{
  if (((n64_enum_tree_code) (cxx_typename)->common.code) != TREE_LIST)
    return cxx_typename;
  return grokdeclarator (((cxx_typename)->list.value),
    ((cxx_typename)->list.purpose),
    TYPENAME, 0, (tree) 
                ((void *)0)
                         , (tree) 
                           ((void *)0)
                                    );
}
int debug_temp_inits = 1;

tree
start_decl(tree declarator, tree declspecs, int initialized, tree raises) asm("_start_decl");
tree
start_decl(tree declarator, tree declspecs, int initialized, tree raises)
{
  register tree decl;
  register tree type, tem;
  tree context;
  extern int have_extern_spec;
  extern int used_extern_spec;

  int init_written = initialized;


  if (have_extern_spec && !used_extern_spec)
    {
      declspecs = decl_tree_cons ((tree) 
                                 ((void *)0)
                                          , get_identifier ("extern"),
      declspecs);
      used_extern_spec = 1;
    }

  decl = grokdeclarator (declarator, declspecs, NORMAL, initialized, raises,
    (tree) 
   ((void *)0)
            );
  if (decl == (tree) 
             ((void *)0) 
                       || decl == void_type_node)
    return (tree) 
          ((void *)0)
                   ;

  type = ((decl)->common.type);


  if (((decl)->common.static_flag)
      && (((type)->type.lang_flag_4))
      && !((decl)->common.permanent_flag))
    {
      push_obstacks (&permanent_obstack, &permanent_obstack);
      decl = copy_node (decl);
      if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
 {
   tree itype = ((type)->type.values);
   if (itype && ! ((itype)->common.permanent_flag))
     {
       itype = build_index_type (copy_to_permanent (((itype)->type.maxval)));
       type = build_cplus_array_type (((type)->common.type), itype);
       ((decl)->common.type) = type;
     }
 }
      pop_obstacks ();
    }


  push_obstacks_nochange ();

  context
    = (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && ((decl)->decl.virtual_flag))
      ? (((decl)->decl.lang_specific)->decl_flags.context)
      : ((decl)->decl.context);

  if (processing_template_decl)
    {
      tree d;
      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
        {


          tree args;
          args = copy_to_permanent (last_function_parms);
          if (((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE)
            {
       tree t = ((decl)->common.type);

              t = ((t)->type.maxval);
       if (((n64_enum_tree_code) (t)->common.code) != UNINSTANTIATED_P_TYPE)
  {
    t = build_pointer_type (t);


    t = build_type_variant (t, flag_this_is_variable <= 0,
       0);



    t = build (PARM_DECL, t, this_identifier);
    ((t)->common.chain) = args;
    args = t;
  }
     }
          ((decl)->decl.arguments) = args;
        }
      d = build_lang_decl (TEMPLATE_DECL, ((decl)->decl.name), ((decl)->common.type));
      ((d)->common.public_flag) = ((decl)->common.public_flag);
      ((d)->common.static_flag) = ((decl)->common.static_flag);
      ((d)->decl.external_flag) = (((decl)->decl.external_flag)
      && !(context && !(((decl)->decl.lang_flag_2))));
      ((d)->decl.result) = decl;
      decl = d;
    }




  if ((((type)->type.lang_flag_4))
      && current_binding_level->more_cleanups_ok == 0)
    pushlevel_temporary (1);

  if (initialized)



    switch (((n64_enum_tree_code) (decl)->common.code))
      {
      case TYPE_DECL:



 if (pedantic || list_length (declspecs) > 1)
   {
     cp_error ("typedef `%D' is initialized", decl);
     initialized = 0;
   }
 break;

      case FUNCTION_DECL:
 cp_error ("function `%#D' is initialized like a variable", decl);
 initialized = 0;
 break;

      default:


 if (type == error_mark_node)
   ;
 else if (((type)->type.size) != (tree) 
                             ((void *)0)
                                      )
   ;
 else if (((n64_enum_tree_code) (type)->common.code) != ARRAY_TYPE)
   {
     cp_error ("variable `%#D' has initializer but incomplete type",
        decl);
     initialized = 0;
   }
 else if (((((type)->common.type))->type.size) == (tree) 
                                         ((void *)0)
                                                  )
   {
     cp_error ("elements of array `%#D' have incomplete type", decl);
     initialized = 0;
   }
      }

  if (!initialized
      && ((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL
      && ((n64_enum_tree_code) (decl)->common.code) != TEMPLATE_DECL
      && (((type)->type.lang_flag_5)) && ! ((decl)->decl.external_flag))
    {
      if (((type)->type.size) == (tree) 
                             ((void *)0)
                                      )
 {
   cp_error ("aggregate `%#D' has incomplete type and cannot be initialized",
   decl);


   ((decl)->common.type) = error_mark_node;
   type = error_mark_node;
 }
      else
 {






   initialized = ((type)->type.needs_constructing_flag);
 }
    }

  if (initialized)
    {
      if (! toplevel_bindings_p ()
   && ((decl)->decl.external_flag))
 cp_warning ("declaration of `%#D' has `extern' and is initialized",
      decl);
      ((decl)->decl.external_flag) = 0;
      if ( toplevel_bindings_p ())
 ((decl)->common.static_flag) = 1;




      ((decl)->decl.initial) = error_mark_node;
    }

  if (context && ((context)->type.size) != (tree) 
                                       ((void *)0)
                                                )
    {
      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
 {
   tree field = lookup_field (context, ((decl)->decl.name), 0, 0);
   if (field == (tree) 
               ((void *)0) 
                         || ((n64_enum_tree_code) (field)->common.code) != VAR_DECL)
     cp_error ("`%#D' is not a static member of `%#T'", decl, context);
   else if (duplicate_decls (decl, field))
     decl = field;
 }
      else
 {
   tree field = check_classfn (context, (tree) 
                                       ((void *)0)
                                                , decl);
   if (field && duplicate_decls (decl, field))
     decl = field;
 }


      if (((decl)->decl.lang_specific))
 (((decl)->decl.lang_flag_3)) = 0;
      if ((((decl)->decl.lang_specific)->decl_flags.use_template) || (((context)->type.lang_specific)->type_flags.use_template))
 ((((decl)->decl.lang_specific)->decl_flags.use_template) = 2);


      if (pedantic && ((decl)->decl.external_flag)
   && ! ((((decl)->decl.lang_specific)->decl_flags.use_template) == 2))
 cp_pedwarn ("declaration of `%#D' outside of class is not definition",
      decl);

      pushclass (context, 2);
    }





  if ((((n64_enum_tree_code) (decl)->common.code) != PARM_DECL && ((decl)->decl.context) != (tree) 
                                                              ((void *)0)
                                                                       )
      || (((n64_enum_tree_code) (decl)->common.code) == TEMPLATE_DECL && !global_bindings_p ())
      || ((n64_enum_tree_code) (type)->common.code) == LANG_TYPE)
    tem = decl;
  else
    tem = pushdecl (decl);
  ((tem)->decl.common_flag) = flag_conserve_space || ! ((tem)->common.public_flag);
  if (((n64_enum_tree_code) (decl)->common.code) == TEMPLATE_DECL)
    {
      tree result = ((decl)->decl.result);
      if (((result)->decl.context) != (tree) 
                                  ((void *)0)
                                           )
 {
          tree type;
          type = ((result)->decl.context);

   if (((n64_enum_tree_code) (type)->common.code) != UNINSTANTIATED_P_TYPE)
     {
       cp_error ("declaration of `%D' in non-template type `%T'",
   decl, type);
       return (tree) 
             ((void *)0)
                      ;
     }

   if (((n64_enum_tree_code) (result)->common.code) == FUNCTION_DECL)
     return tem;
   else if (((n64_enum_tree_code) (result)->common.code) == VAR_DECL)
     {
       sorry ("static data member templates");
       return (tree) 
             ((void *)0)
                      ;

     }
   else
     my_friendly_abort (13);
        }
      else if (((n64_enum_tree_code) (result)->common.code) == FUNCTION_DECL)
                                               ;
      else if (((n64_enum_tree_code) (result)->common.code) == VAR_DECL)
 {
   cp_error ("data template `%#D' must be member of a class template",
      result);
   return (tree) 
         ((void *)0)
                  ;
 }
      else if (((n64_enum_tree_code) (result)->common.code) == TYPE_DECL)
 {
   cp_error ("invalid template `%#D'", result);
   return (tree) 
         ((void *)0)
                  ;
 }
      else
 my_friendly_abort (14);
    }

  if (init_written
      && ! (((n64_enum_tree_code) (tem)->common.code) == PARM_DECL
     || (((tem)->common.readonly_flag)
  && (((n64_enum_tree_code) (tem)->common.code) == VAR_DECL
      || ((n64_enum_tree_code) (tem)->common.code) == FIELD_DECL))))
    {


      if (toplevel_bindings_p () && debug_temp_inits)
 {
   if (((type)->type.needs_constructing_flag)
       || ((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)


     ;
   else
     temporary_allocation ();
 }
    }

  if (flag_cadillac)
    cadillac_start_decl (tem);

  return tem;
}
static void
grok_reference_init(tree decl, tree type, tree init, tree *cleanupp) asm("_grok_reference_init");
static void
grok_reference_init(tree decl, tree type, tree init, tree *cleanupp)
{
  tree tmp;

  if (init == (tree) 
             ((void *)0)
                      )
    {
      if ((((decl)->decl.lang_specific) == 0
    || (((decl)->decl.lang_flag_3)) == 0)
   && ! (((decl)->decl.lang_flag_2)))
 {
   cp_error ("`%D' declared as reference but not initialized", decl);
   if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
     ((decl)->decl.arguments=error_mark_node);
 }
      return;
    }

  if (init == error_mark_node)
    return;

  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE
      && ((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR)
    {
      cp_error ("ANSI C++ forbids use of initializer list to initialize reference `%D'", decl);
      return;
    }

  if (((n64_enum_tree_code) (init)->common.code) == TREE_LIST)
    init = build_compound_expr (init);

  if (((n64_enum_tree_code) (((init)->common.type))->common.code) == REFERENCE_TYPE)
    init = convert_from_reference (init);

  if (((n64_enum_tree_code) (((type)->common.type))->common.code) != ARRAY_TYPE
      && ((n64_enum_tree_code) (((init)->common.type))->common.code) == ARRAY_TYPE)
    {

      init = default_conversion (init);
    }

  tmp = convert_to_reference
    (type, init, 1, (64)|(3), decl);

  if (tmp == error_mark_node)
    goto fail;
  else if (tmp != (tree) 
                 ((void *)0)
                          )
    {
      tree subtype = ((type)->common.type);
      init = tmp;



      if ((((subtype)->type.lang_flag_4)))
 {
   if (((n64_enum_tree_code) (init)->common.code) == WITH_CLEANUP_EXPR)
     {
       *cleanupp = ((init)->exp.operands[2]);
       ((init)->exp.operands[2]) = error_mark_node;
     }
   else
     {
       if (((n64_enum_tree_code) (tmp)->common.code) == ADDR_EXPR)
  tmp = ((tmp)->exp.operands[0]);
       if (((n64_enum_tree_code) (tmp)->common.code) == TARGET_EXPR)
  {
    *cleanupp = build_delete
      (build_pointer_type (subtype),
       build_unary_op (ADDR_EXPR, ((tmp)->exp.operands[0]), 0),
       integer_two_node, (3)|(512), 0);
    ((tmp)->exp.operands[2]) = error_mark_node;
  }
     }
 }

      ((decl)->decl.initial) = save_expr (init);
    }
  else
    {
      cp_error ("cannot initialize `%T' from `%T'", type, ((init)->common.type));
      goto fail;
    }



  if (((((type)->common.type))->type.size))
    {
      init = convert_from_reference (decl);
      if (((decl)->common.permanent_flag))
 init = copy_to_permanent (init);
      ((decl)->decl.arguments=init);
    }

  if (((decl)->common.static_flag) && ! ((((decl)->decl.initial))->common.constant_flag))
    {
      expand_static_init (decl, ((decl)->decl.initial));
      ((decl)->decl.initial) = (tree) 
                           ((void *)0)
                                    ;
    }
  return;

 fail:
  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
    ((decl)->decl.arguments=error_mark_node);
  return;
}







static tree
obscure_complex_init(tree decl, tree init) asm("_obscure_complex_init");
static tree
obscure_complex_init(tree decl, tree init)
{
  if (! flag_no_inline && ((decl)->common.static_flag))
    {
      if (extract_init (decl, init))
 return (tree) 
       ((void *)0)
                ;
    }

  if (toplevel_bindings_p () && ! ((decl)->decl.common_flag))
    ((decl)->decl.initial) = build (CONSTRUCTOR, ((decl)->common.type), (tree) 
                                                               ((void *)0)
                                                                        ,
     (tree) 
    ((void *)0)
             );
  else
    ((decl)->decl.initial) = error_mark_node;

  return init;
}
void
cp_finish_decl(tree decl, tree init, tree asmspec_tree, int need_pop, int flags) asm("_cp_finish_decl");
void
cp_finish_decl(tree decl, tree init, tree asmspec_tree, int need_pop, int flags)
{
  register tree type;
  tree cleanup = (tree) 
                ((void *)0)
                         , ttype;
  int was_incomplete;
  int temporary = allocation_temporary_p ();
  char *asmspec = 
                 ((void *)0)
                     ;
  int was_readonly = 0;


  if (! decl)
    {
      if (init)
 error ("assignment (not initialization) in declaration");
      return;
    }


  if (asmspec_tree)
      asmspec = ((asmspec_tree)->string.pointer);







  type = ((decl)->common.type);

  if (type == error_mark_node)
    {
      if (toplevel_bindings_p () && temporary)
 end_temporary_allocation ();

      return;
    }

  was_incomplete = (((decl)->decl.size) == (tree) 
                                       ((void *)0)
                                                );


  if (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL)
    {
      if (init && ((decl)->decl.initial))
 {

   ((decl)->common.type) = type = ((init)->common.type);
   ((decl)->decl.initial) = init = (tree) 
                               ((void *)0)
                                        ;
 }
      if (type != error_mark_node
   && (((type)->type.lang_flag_5)) && ((decl)->decl.name))
 {
   if (((((decl)->decl.name))->common.type) && ((decl)->common.type) != type)
     cp_warning ("shadowing previous type declaration of `%#D'", decl);
   set_identifier_type_value (((decl)->decl.name), type);
   (((type)->type.lang_specific)->type_flags.got_semicolon) = 1;
 }
      GNU_xref_decl (current_function_decl, decl);
      rest_of_decl_compilation (decl, ((void *)0),
    ((decl)->decl.context) == (tree) 
                          ((void *)0)
                                   , 0);
      goto finish_end;
    }
  if (((n64_enum_tree_code) (decl)->common.code) != FUNCTION_DECL)
    {
      ttype = target_type (type);
    }

  if (! ((decl)->decl.external_flag) && ((decl)->common.readonly_flag)
      && ((type)->type.needs_constructing_flag))
    {





      was_readonly = 1;
      ((decl)->common.readonly_flag) = 0;
    }

  if (((n64_enum_tree_code) (decl)->common.code) == FIELD_DECL)
    {
      if (init && init != error_mark_node)
 my_friendly_assert (((init)->common.permanent_flag), 147);

      if (asmspec)
 {


   ((((decl)->common.type))->decl.rtl) = (rtx) 0;
   ((decl)->decl.assembler_name) = get_identifier (asmspec);
   make_decl_rtl (decl, asmspec, 0);
 }
    }

  else if (init != (tree) 
                  ((void *)0) 
                            && ((decl)->decl.initial) == (tree) 
                                                      ((void *)0)
                                                               )
    init = (tree) 
          ((void *)0)
                   ;
  else if (((decl)->decl.external_flag))
    ;
  else if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE
    || (((type)->type.lang_specific) && (((type)->type.lang_specific)->type_flags.is_signature_reference)))
    {
      if (((decl)->common.static_flag))
 make_decl_rtl (decl, ((void *)0),
         toplevel_bindings_p ()
         || pseudo_global_level_p ());
      grok_reference_init (decl, type, init, &cleanup);
      init = (tree) 
            ((void *)0)
                     ;
    }

  GNU_xref_decl (current_function_decl, decl);

  if (((n64_enum_tree_code) (decl)->common.code) == FIELD_DECL)
    ;
  else if (((n64_enum_tree_code) (decl)->common.code) == CONST_DECL)
    {
      my_friendly_assert (((n64_enum_tree_code) (decl)->common.code) != REFERENCE_TYPE, 148);

      ((decl)->decl.initial) = init;


      my_friendly_assert (init != (tree) 
                                 ((void *)0)
                                          , 149);
      init = (tree) 
            ((void *)0)
                     ;
    }
  else if (init)
    {
      if ((((type)->type.lang_flag_1)) || ((type)->type.needs_constructing_flag))
 {
   if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
     init = digest_init (type, init, (tree *) 0);
   else if (((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR)
     {
       if (((((type)->type.lang_flag_5)) && (((type)->type.lang_specific)->type_flags.non_aggregate)))
  {
    cp_error ("`%D' must be initialized by constructor, not by `{...}'",
       decl);
    init = error_mark_node;
  }
       else
  goto dont_use_constructor;
     }
 }
      else
 {
 dont_use_constructor:
   if (((n64_enum_tree_code) (init)->common.code) != TREE_VEC)
     init = store_init_value (decl, init);
 }

      if (init)


 init = obscure_complex_init (decl, init);
    }
  else if (((decl)->decl.external_flag))
    ;
  else if ((*tree_code_type[(int) (((n64_enum_tree_code) (type)->common.code))]) == 't'
    && ((((type)->type.lang_flag_5)) || ((type)->type.needs_constructing_flag)))
    {
      tree ctype = type;
      while (((n64_enum_tree_code) (ctype)->common.code) == ARRAY_TYPE)
 ctype = ((ctype)->common.type);
      if (! ((ctype)->type.needs_constructing_flag))
 {
   if ((((ctype)->type.lang_specific)->type_flags.const_needs_init))
     cp_error ("structure `%D' with uninitialized const members", decl);
   if ((((ctype)->type.lang_specific)->type_flags.ref_needs_init))
     cp_error ("structure `%D' with uninitialized reference members",
        decl);
 }

      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
   && !((decl)->decl.initial)
   && !((type)->type.needs_constructing_flag)
   && (((type)->common.readonly_flag) || ((decl)->common.readonly_flag)))
 cp_error ("uninitialized const `%D'", decl);

      if (((type)->type.size) != (tree) 
                             ((void *)0)
   
  && ((type)->type.needs_constructing_flag))
 init = obscure_complex_init (decl, (tree) 
                                   ((void *)0)
                                            );
    }
  else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
    && ((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE
    && (((type)->common.readonly_flag) || ((decl)->common.readonly_flag)))
    {






      if (! ((decl)->decl.initial)
   && ((n64_enum_tree_code) (type)->common.code) != ARRAY_TYPE
   && (!pedantic || !current_class_type))
 cp_error ("uninitialized const `%#D'", decl);
    }






  if (toplevel_bindings_p () && temporary)
    end_temporary_allocation ();



  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
      && ((type)->type.values) == (tree) 
                              ((void *)0)
      
     && ((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
    {
      int do_default
 = (((decl)->common.static_flag)


    ? pedantic && ! ((decl)->decl.external_flag)
    : !((decl)->decl.external_flag));
      tree initializer = init ? init : ((decl)->decl.initial);
      int failure = complete_array_type (type, initializer, do_default);

      if (failure == 1)
 cp_error ("initializer fails to determine size of `%D'", decl);

      if (failure == 2)
 {
   if (do_default)
     cp_error ("array size missing in `%D'", decl);




   else if (!pedantic && ((decl)->common.static_flag) && !((decl)->common.public_flag))
     ((decl)->decl.external_flag) = 1;
 }

      if (pedantic && ((type)->type.values) != (tree) 
                                           ((void *)0)
   
  && tree_int_cst_lt (((((type)->type.values))->type.maxval),
         integer_zero_node))
 cp_error ("zero-size array `%D'", decl);

      layout_decl (decl, 0);
    }

  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
    {
      if (((decl)->decl.size) == (tree) 
                             ((void *)0)
   
  && ((((decl)->common.type))->type.size) != (tree) 
                                     ((void *)0)
                                              )
 layout_decl (decl, 0);

      if (((decl)->common.static_flag) && ((decl)->decl.size) == (tree) 
                                                   ((void *)0)
                                                            )
 {




   if (((decl)->decl.initial) != (tree) 
                             ((void *)0)
                                      )
     cp_error ("storage size of `%D' isn't known", decl);
   init = (tree) 
         ((void *)0)
                  ;
 }
      else if (!((decl)->decl.external_flag) && ((decl)->decl.size) == (tree) 
                                                           ((void *)0)
                                                                    )
 {



   cp_error ("storage size of `%D' isn't known", decl);
   ((decl)->common.type) = error_mark_node;
 }
      else if (!((decl)->decl.external_flag) && (((ttype)->type.lang_flag_5)))

 note_debug_info_needed (ttype);

      if (((decl)->common.static_flag) && ((decl)->decl.context)
   && (*tree_code_type[(int) (((n64_enum_tree_code) (((decl)->decl.context))->common.code))]) == 't')
 note_debug_info_needed (((decl)->decl.context));

      if ((((decl)->decl.external_flag) || ((decl)->common.static_flag))
   && ((decl)->decl.size) != (tree) 
                         ((void *)0)
   
  && ! ((((decl)->decl.size))->common.constant_flag))
 {
   if (((n64_enum_tree_code) (((decl)->decl.size))->common.code) == INTEGER_CST)
     constant_expression_warning (((decl)->decl.size));
   else
     cp_error ("storage size of `%D' isn't constant", decl);
 }

      if (!((decl)->decl.external_flag) && (((type)->type.lang_flag_4)))
 {
   int yes = suspend_momentary ();



   if (init && ((n64_enum_tree_code) (init)->common.code) == WITH_CLEANUP_EXPR
       && comptypes (((decl)->common.type), ((init)->common.type), 1))
     {
       cleanup = ((init)->exp.operands[2]);
       init = ((init)->exp.operands[0]);
       current_binding_level->have_cleanups = 1;
     }
   else
     cleanup = maybe_build_cleanup (decl);
   resume_momentary (yes);
 }
    }

  else if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL && (((type)->type.lang_flag_4)))
    {
      if (temporary)
 end_temporary_allocation ();
      cleanup = maybe_build_cleanup (decl);
      if (temporary)
 resume_temporary_allocation ();
    }





  if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL || ((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
      || ((n64_enum_tree_code) (decl)->common.code) == RESULT_DECL)
    {

      int toplev = toplevel_bindings_p () || pseudo_global_level_p ();
      int was_temp
 = ((flag_traditional
     || (((decl)->common.static_flag) && (((type)->type.lang_flag_4))))
    && allocation_temporary_p ());

      if (was_temp)
 end_temporary_allocation ();

      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
   && ! toplevel_bindings_p ()
   && ! ((decl)->common.static_flag)
   && type_needs_gc_entry (type))
 ((decl)->decl.result) = size_int (++current_function_obstack_index);

      if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && ((decl)->decl.virtual_flag))
 make_decl_rtl (decl, ((void *)0), toplev);
      else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
        && ((decl)->common.readonly_flag)
        && ((decl)->decl.initial) != (tree) 
                                 ((void *)0)
        
       && ((decl)->decl.initial) != error_mark_node
        && ! (((n64_enum_tree_code) (((decl)->decl.initial))->common.code) == CONSTRUCTOR && ((((decl)->decl.initial))->exp.operands[1]) == (tree) 
            ((void *)0)
            ))
 {
   ((decl)->decl.initial) = save_expr (((decl)->decl.initial));

   if (asmspec)
     ((decl)->decl.assembler_name) = get_identifier (asmspec);

   if (! toplev
       && ((decl)->common.static_flag)
       && ! ((decl)->common.side_effects_flag)
       && ! ((decl)->common.public_flag)
       && ! ((decl)->decl.external_flag)
       && ! (((type)->type.lang_flag_4))
       && ((decl)->decl.mode) != BLKmode)
     {




       ((decl)->decl.rtl) = gen_reg_rtx (((decl)->decl.mode));
       store_expr (((decl)->decl.initial), ((decl)->decl.rtl), 0);
       ((decl)->common.asm_written_flag) = 1;
     }
   else if (toplev && ! ((decl)->common.public_flag))
     {


       if (!interface_unknown)
  {
    ((decl)->common.public_flag) = 1;
    ((decl)->decl.external_flag) = interface_only;
  }
       make_decl_rtl (decl, asmspec, toplev);
     }
   else
     rest_of_decl_compilation (decl, asmspec, toplev, 0);
 }
      else if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
        && ((decl)->decl.lang_specific)
        && (((decl)->decl.lang_flag_3)))
 {
   if (((decl)->common.static_flag))
     {
       if (init == (tree) 
                  ((void *)0)






    
   )
  {
    ((decl)->decl.external_flag) = 1;
    make_decl_rtl (decl, asmspec, 1);
  }
       else
  rest_of_decl_compilation (decl, asmspec, toplev, 0);
     }
   else

     goto finish_end0;
 }
      else
 rest_of_decl_compilation (decl, asmspec, toplev, 0);

      if (was_temp)
 resume_temporary_allocation ();

      if (type != error_mark_node
   && ((type)->type.lang_specific)
   && (((type)->type.lang_specific)->abstract_virtuals))
 abstract_virtuals_error (decl, type);
      else if ((((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
        && ((((type)->common.type))->type.lang_specific)
        && (((((type)->common.type))->type.lang_specific)->abstract_virtuals))
 abstract_virtuals_error (decl, ((type)->common.type));

      if (((type)->type.lang_specific) && (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
 signature_error (decl, type);
      else if ((((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
        && ((((type)->common.type))->type.lang_specific)
        && (((((type)->common.type))->type.lang_specific)?((((type)->common.type))->type.lang_specific)->type_flags.is_signature:0))
 signature_error (decl, ((type)->common.type));

      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 ;
      else if (((decl)->decl.external_flag))
 ;
      else if (((decl)->common.static_flag) && type != error_mark_node)
 {

   if (((type)->type.needs_constructing_flag) || init != (tree) 
                                                ((void *)0)
       
      || (((type)->type.lang_flag_4)))
     expand_static_init (decl, init);


   if (flag_gc && type_needs_gc_entry (type))
     build_static_gc_entry (decl, type);
 }
      else if (! toplev)
 {
   tree old_cleanups = cleanups_this_call;





   if (was_incomplete && ! ((decl)->common.static_flag))
     {

       ((decl)->common.addressable_flag) = ((decl)->common.used_flag);

       if (((decl)->decl.size) == (tree) 
                              ((void *)0)
                                       )
  ((decl)->decl.initial) = (tree) 
                       ((void *)0)
                                ;
       expand_decl (decl);
     }
   else if (! ((decl)->common.asm_written_flag)
     && (((type)->type.size) != (tree) 
                            ((void *)0)
         
        || ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE))
     {


       if (((decl)->decl.rtl) == (rtx) 0)
  expand_decl (decl);
       else if (cleanup)
  {


    if (! cp_expand_decl_cleanup ((tree) 
                                 ((void *)0)
                                          , cleanup))
      cp_error ("parser lost in parsing declaration of `%D'",
         decl);

    cleanup = (tree) 
             ((void *)0)
                      ;
  }
     }

   if (((decl)->decl.size) && type != error_mark_node)
     {

       expand_decl_init (decl);

       if (init || ((type)->type.needs_constructing_flag))
  {
    emit_line_note (((decl)->decl.filename),
      ((decl)->decl.linenum));
    expand_aggr_init (decl, init, 0, flags);
  }





       if (((type)->type.needs_constructing_flag) && cleanup == (tree) 
                                                       ((void *)0)
                                                                )
  ((decl)->common.used_flag) = 0;


       if (cleanup)
  {
    if (! cp_expand_decl_cleanup (decl, cleanup))
      cp_error ("parser lost in parsing declaration of `%D'",
         decl);
  }
     }

   expand_cleanups_to (old_cleanups);
 }
    finish_end0:




      {
 tree context = ((((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL && (((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE || (((decl)->decl.lang_specific)->decl_flags.static_function))) ? (((decl)->decl.lang_specific)->decl_flags.context) : ((decl)->decl.context));
 if (context
     && (*tree_code_type[(int) (((n64_enum_tree_code) (context)->common.code))]) == 't'
     && (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL


  || (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL



      && ((context)->type.size) != (tree) 
                               ((void *)0)





      
     && context == current_class_type
      )))
   popclass (1);
      }
    }

 finish_end:



  if (warn_larger_than
      && (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL || ((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
      && !((decl)->decl.external_flag))
    {
      register tree decl_size = ((decl)->decl.size);

      if (decl_size && ((n64_enum_tree_code) (decl_size)->common.code) == INTEGER_CST)
 {
   unsigned units = ((decl_size)->int_cst.int_cst_low) / 8;

   if (units > larger_than_size)
     warning_with_decl (decl, "size of `%s' is %u bytes", units);
 }
    }

  if (need_pop)
    {



      pop_obstacks ();
    }

  if (was_readonly)
    ((decl)->common.readonly_flag) = 1;

  if (flag_cadillac)
    cadillac_finish_decl (decl);
}


void
finish_decl(tree decl, tree init, tree asmspec_tree) asm("_finish_decl");
void
finish_decl(tree decl, tree init, tree asmspec_tree)
{
  cp_finish_decl (decl, init, asmspec_tree, 1, 0);
}

void
expand_static_init(tree decl, tree init) asm("_expand_static_init");
void
expand_static_init(tree decl, tree init)
{
  tree oldstatic = value_member (decl, static_aggregates);
  tree old_cleanups;

  if (oldstatic)
    {
      if (((oldstatic)->list.purpose) && init != (tree) 
                                             ((void *)0)
                                                      )
 cp_error ("multiple initializations given for `%D'", decl);
    }
  else if (! toplevel_bindings_p () && ! pseudo_global_level_p ())
    {

      tree temp;


      push_obstacks (&permanent_obstack, &permanent_obstack);


      temp = get_temp_name (integer_type_node, 1);
      rest_of_decl_compilation (temp, ((void *)0), 0, 0);
      expand_start_cond (build_binary_op (EQ_EXPR, temp,
       integer_zero_node, 1), 0);
      old_cleanups = cleanups_this_call;
      expand_assignment (temp, integer_one_node, 0, 0);
      if (((((decl)->common.type))->type.needs_constructing_flag)
   || (init && ((n64_enum_tree_code) (init)->common.code) == TREE_LIST))
 {
   expand_aggr_init (decl, init, 0, 0);
   do_pending_stack_adjust ();
 }
      else if (init)
 expand_assignment (decl, init, 0, 0);


      expand_cleanups_to (old_cleanups);
      expand_end_cond ();
      if ((((((decl)->common.type))->type.lang_flag_4)))
 {
   static_aggregates = perm_tree_cons (temp, decl, static_aggregates);
   ((static_aggregates)->common.static_flag) = 1;
 }


      pop_obstacks ();
    }
  else
    {




      if (! ((((decl)->common.type))->type.needs_constructing_flag))
 preserve_initializer ();
      static_aggregates = perm_tree_cons (init, decl, static_aggregates);
    }
}





int
complete_array_type(tree type, tree initial_value, int do_default) asm("_complete_array_type");
int
complete_array_type(tree type, tree initial_value, int do_default)
{
  register tree maxindex = (tree) 
                          ((void *)0)
                                   ;
  int value = 0;

  if (initial_value)
    {


      if (((n64_enum_tree_code) (initial_value)->common.code) == STRING_CST)
 {
   int eltsize
     = int_size_in_bytes (((((initial_value)->common.type))->common.type));
   maxindex = build_int_2_wide ((int) ((((initial_value)->string.length) / eltsize) - 1), (int) (0))
                         ;
 }
      else if (((n64_enum_tree_code) (initial_value)->common.code) == CONSTRUCTOR)
 {
   tree elts = ((initial_value)->exp.operands[1]);
   maxindex = size_binop (MINUS_EXPR, integer_zero_node, size_one_node);
   for (; elts; elts = ((elts)->common.chain))
     {
       if (((elts)->list.purpose))
  maxindex = ((elts)->list.purpose);
       else
  maxindex = size_binop (PLUS_EXPR, maxindex, size_one_node);
     }
   maxindex = copy_node (maxindex);
 }
      else
 {

   if (initial_value != error_mark_node)
     value = 1;


   maxindex = build_int_2_wide ((int) (0), (int) (0));
 }
    }

  if (!maxindex)
    {
      if (do_default)
 maxindex = build_int_2_wide ((int) (0), (int) (0));
      value = 2;
    }

  if (maxindex)
    {
      tree itype;

      ((type)->type.values) = build_index_type (maxindex);
      if (! ((maxindex)->common.type))
 ((maxindex)->common.type) = ((type)->type.values);
      if (initial_value)
        itype = ((initial_value)->common.type);
      else
 itype = 
        ((void *)0)
            ;
      if (itype && !((itype)->type.values))
 ((itype)->type.values) = ((type)->type.values);



      if (! ((((type)->type.main_variant))->type.values))
 ((((type)->type.main_variant))->type.values) = ((type)->type.values);
    }



  layout_type (type);

  return value;
}




static int
member_function_or_else(tree ctype, tree cur_type, char *string) asm("_member_function_or_else");
static int
member_function_or_else(tree ctype, tree cur_type, char *string)
{
  if (ctype && ctype != cur_type)
    {
      error (string, ((((((((ctype)->type.name))->decl.name)))->identifier.pointer)));
      return 0;
    }
  return 1;
}





static void
bad_specifiers(tree object, char *type, int virtualp, int quals, int inlinep, int friendp, int raises) asm("_bad_specifiers");
static void
bad_specifiers(tree object, char *type, int virtualp, int quals, int inlinep, int friendp, int raises)
{
  if (virtualp)
    cp_error ("`%D' declared as a `virtual' %s", object, type);
  if (inlinep)
    cp_error ("`%D' declared as an `inline' %s", object, type);
  if (quals)
    cp_error ("`const' and `volatile' function specifiers on `%D' invalid in %s declaration",
       object, type);
  if (friendp)
    cp_error_at ("invalid friend declaration", object);
  if (raises)
    cp_error_at ("invalid exception specifications", object);
}
static tree
grokfndecl(tree ctype, tree type, tree declarator, int virtualp, n64_enum_overload_flags flags, tree quals, tree raises, tree attrlist, int check, int publicp, int inlinep) asm("_grokfndecl");
static tree
grokfndecl(tree ctype, tree type, tree declarator, int virtualp, n64_enum_overload_flags flags, tree quals, tree raises, tree attrlist, int check, int publicp, int inlinep)
{
  tree cname, decl;
  int staticp = ctype && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE;

  if (ctype)
    cname = ((n64_enum_tree_code) (((ctype)->type.name))->common.code) == TYPE_DECL
      ? (((((ctype)->type.name))->decl.name)) : ((ctype)->type.name);
  else
    cname = (tree) 
           ((void *)0)
                    ;

  if (raises)
    {
      type = build_exception_variant (type, raises);
      raises = ((type)->type.noncopied_parts);
    }
  decl = build_lang_decl (FUNCTION_DECL, declarator, type);

  if (((type)->common.volatile_flag))
      ((decl)->common.volatile_flag) = 1;


  if (staticp)
    {
      (((decl)->decl.lang_specific)->decl_flags.static_function) = 1;
      ((decl)->decl.context) = ctype;
      (((decl)->decl.lang_specific)->decl_flags.context) = ctype;
    }



  ((decl)->common.public_flag) = 1;

  if (ctype == (tree) 
              ((void *)0) 
                        && ! strcmp (((declarator)->identifier.pointer), "main"))
    {
      if (inlinep)
 error ("cannot declare `main' to be inline");
      else if (! publicp)
 error ("cannot declare `main' to be static");
      inlinep = 0;
      publicp = 1;
    }

  if (! publicp)
    (((decl)->decl.lang_specific)->decl_flags.c_static) = 1;

  if (inlinep)
    (((decl)->decl.lang_specific)->decl_flags.declared_inline) = ((decl)->decl.inline_flag) = 1;

  ((decl)->decl.external_flag) = 1;
  if (quals != (tree) 
              ((void *)0) 
                        && ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
    {
      cp_error ("%smember function `%D' cannot have `%T' method qualifier",
  (ctype ? "static " : "non-"), decl, ((quals)->list.value));
      quals = (tree) 
             ((void *)0)
                      ;
    }

  if (((((decl)->decl.name))->common.lang_flag_2))
    grok_op_properties (decl, virtualp, check < 0);


  if (check < 0)
    return decl;

  if (flags == NO_SPECIAL && ctype && constructor_name (cname) == declarator)
    {
      tree tmp;





      (((decl)->decl.lang_specific)->decl_flags.constructor_attr) = 1;

      grokclassfn (ctype, declarator, decl, flags, quals);
      if (check)
 check_classfn (ctype, declarator, decl);
      if (! grok_ctor_properties (ctype, decl))
 return (tree) 
       ((void *)0)
                ;

      if (check == 0 && ! current_function_decl)
 {


   tmp = lookup_name (((decl)->decl.assembler_name), 0);
   if (tmp == (tree) 
             ((void *)0)
                      )
     (((struct n64_tag_lang_identifier *)(((decl)->decl.assembler_name)))->global_value) = decl;
   else if (((n64_enum_tree_code) (tmp)->common.code) != ((n64_enum_tree_code) (decl)->common.code))
     cp_error ("inconsistent declarations for `%D'", decl);
   else
     {
       duplicate_decls (decl, tmp);
       decl = tmp;

       (((decl)->decl.lang_specific)->chain) = (tree) 
                          ((void *)0)
                                   ;
     }
   make_decl_rtl (decl, ((void *)0), 1);
 }
    }
  else
    {
      tree tmp;




      if (ctype != (tree) 
                  ((void *)0)
                           )
 grokclassfn (ctype, cname, decl, flags, quals);

      if (ctype != (tree) 
                  ((void *)0) 
                            && check)
 check_classfn (ctype, cname, decl);

      if (ctype == (tree) 
                  ((void *)0) 
                            || check)
 return decl;




      if (! current_function_decl)
 {


   tmp = lookup_name (((decl)->decl.assembler_name), 0);
   if (tmp == (tree) 
             ((void *)0)
                      )
     (((struct n64_tag_lang_identifier *)(((decl)->decl.assembler_name)))->global_value) = decl;
   else if (((n64_enum_tree_code) (tmp)->common.code) != ((n64_enum_tree_code) (decl)->common.code))
     cp_error ("inconsistent declarations for `%D'", decl);
   else
     {
       duplicate_decls (decl, tmp);
       decl = tmp;

       (((decl)->decl.lang_specific)->chain) = (tree) 
                          ((void *)0)
                                   ;
     }

   if (attrlist)
     cplus_decl_attributes (decl, ((attrlist)->list.purpose),
       ((attrlist)->list.value));
   make_decl_rtl (decl, ((void *)0), 1);
 }




      {
 tree binfos = (((((ctype)->type.binfo)))->vec.a[4]);
 int i, n_baselinks = binfos ? ((binfos)->vec.length) : 0;

 for (i = 0; i < n_baselinks; i++)
   {
     tree base_binfo = ((binfos)->vec.a[i]);
     if ((((((base_binfo)->common.type))->common.lang_flag_2))
  || flag_all_virtual == 1)
       {
  tmp = get_matching_virtual (base_binfo, decl,
         flags == DTOR_FLAG);
  if (tmp)
    {



      ((decl)->decl.virtual_flag) = 1;





      if (staticp)
        {
   cp_error ("method `%D' may not be declared static",
      decl);
   cp_error_at ("(since `%D' declared virtual in base class.)",
         tmp);
   break;
        }
      virtualp = 1;

      {

        tree argtypes = ((((decl)->common.type))->type.values);
        tree base_variant = ((((argtypes)->list.value))->common.type);

        argtypes = commonparms (((((((tmp)->common.type))->type.values))->common.chain),
           ((argtypes)->common.chain));

        type = build_cplus_method_type (base_variant, ((type)->common.type), argtypes);
        if (raises)
   {
     type = build_exception_variant (type, raises);
     raises = ((type)->type.noncopied_parts);
   }
        ((decl)->common.type) = type;
        ((decl)->decl.vindex)
   = tree_cons ((tree) 
               ((void *)0)
                        , tmp, ((decl)->decl.vindex));
      }
      break;
    }
       }
   }
      }
      if (virtualp)
 {
   if (((decl)->decl.vindex) == (tree) 
                            ((void *)0)
                                     )
     ((decl)->decl.vindex) = error_mark_node;
   ((((decl)->decl.name))->common.lang_flag_1) = 1;
   if (ctype && (((ctype)->type.lang_specific)->type_flags.vtable_needs_writing)




       && (((struct n64_tag_lang_identifier *)((((((ctype)->type.name))->decl.name))))->class_template_info) == (tree) 
                                                          ((void *)0)
       
      && (write_virtuals == 2
    || (write_virtuals == 3
        && (((ctype)->type.lang_specific)->type_flags.interface_unknown == 0))))
     ((decl)->common.public_flag) = 1;
 }
    }
  return decl;
}

static tree
grokvardecl(tree type, tree declarator, RID_BIT_TYPE specbits, int initialized, int constp) asm("_grokvardecl");
static tree
grokvardecl(tree type, tree declarator, RID_BIT_TYPE specbits, int initialized, int constp)
{
  tree decl;

  if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
    {


      tree basetype = ((type)->type.maxval);
      type = ((type)->common.type);
      decl = build_lang_field_decl (VAR_DECL, declarator, type);
      ((decl)->decl.context) = basetype;
      (((decl)->decl.lang_specific)->decl_flags.context) = basetype;
      ((decl)->decl.assembler_name) = build_static_name (basetype, declarator);
    }
  else
    decl = build_decl (VAR_DECL, declarator, type);

  ((decl)->decl.assembler_name) = current_namespace_id (((decl)->decl.assembler_name));

  if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32]))
    {
      (((decl)->decl.lang_flag_2)) = 1;
      ((decl)->decl.external_flag) = !initialized;
    }



  if (((decl)->decl.context) != (tree) 
                                  ((void *)0)
      
     && (((((decl)->decl.context))->type.lang_flag_5)))
    {
      ((decl)->common.public_flag) = 1;
      ((decl)->common.static_flag) = 1;
      ((decl)->decl.external_flag) = 0;
    }


  else if (toplevel_bindings_p ())
    {
      ((decl)->common.public_flag) = ((! (((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]))
       && ((((decl)->decl.lang_flag_2)) || ! constp));
      ((decl)->common.static_flag) = ! ((decl)->decl.external_flag);
    }

  else
    {
      ((decl)->common.static_flag) = !! (((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]);
      ((decl)->common.public_flag) = ((decl)->decl.external_flag);
    }
  return decl;
}



tree
build_ptrmemfunc_type(tree type) asm("_build_ptrmemfunc_type");
tree
build_ptrmemfunc_type(tree type)
{
  tree fields[4];
  tree t;
  tree u;





  if ((t = ((tree)((type)->type.lang_specific))))
    return t;

  push_obstacks (((type)->type.obstack), ((type)->type.obstack));

  u = make_lang_type (UNION_TYPE);
  (((u)->type.lang_flag_5)) = 0;
  fields[0] = build_lang_field_decl (FIELD_DECL, pfn_identifier, type);
  fields[1] = build_lang_field_decl (FIELD_DECL, delta2_identifier,
         delta_type_node);
  finish_builtin_type (u, "__ptrmemfunc_type", fields, 1, ptr_type_node);
  ((u)->type.name) = (tree) 
                 ((void *)0)
                          ;

  t = make_lang_type (RECORD_TYPE);


  (((t)->type.lang_specific)->type_flags.ptrmemfunc_flag) = 1;

  (((t)->type.lang_flag_5)) = 0;

  fields[0] = build_lang_field_decl (FIELD_DECL, delta_identifier,
         delta_type_node);
  fields[1] = build_lang_field_decl (FIELD_DECL, index_identifier,
         delta_type_node);
  fields[2] = build_lang_field_decl (FIELD_DECL, pfn_or_delta2_identifier, u);
  finish_builtin_type (t, "__ptrmemfunc_type", fields, 2, ptr_type_node);

  pop_obstacks ();



  ((t)->type.name) = (tree) 
                 ((void *)0)
                          ;

  (((type)->type.lang_specific) = ((struct n64_tag_lang_type *)(void*)(t)));


  (((t)->type.lang_specific)->type_flags.got_semicolon) = 1;
  return t;
}
enum n64_cpp_enum_return_types{ return_normal, return_ctor, return_dtor, return_conversion };
typedef __underlying_type(enum n64_cpp_enum_return_types) n64_enum_return_types;


tree
grokdeclarator(tree declarator, tree declspecs, n64_enum_decl_context decl_context, int initialized, tree raises, tree attrlist) asm("_grokdeclarator");
tree
grokdeclarator(tree declarator, tree declspecs, n64_enum_decl_context decl_context, int initialized, tree raises, tree attrlist)
{
  RID_BIT_TYPE specbits;
  int nclasses = 0;
  tree spec;
  tree type = (tree) 
             ((void *)0)
                      ;
  int longlong = 0;
  int constp;
  int volatilep;
  int virtualp, explicitp, friendp, inlinep, staticp;
  int explicit_int = 0;
  int explicit_char = 0;
  int opaque_typedef = 0;
  tree typedef_decl = (tree) 
                     ((void *)0)
                              ;
  char *name;
  tree typedef_type = (tree) 
                     ((void *)0)
                              ;
  int funcdef_flag = 0;
  n64_enum_tree_code innermost_code = ERROR_MARK;
  int bitfield = 0;
  int size_varies = 0;
  tree decl_machine_attr = (tree) 
                          ((void *)0)
                                   ;


  tree init = (tree) 
             ((void *)0)
                      ;




  n64_enum_return_types return_type = return_normal;

  tree dname = (tree) 
              ((void *)0)
                       ;
  tree ctype = current_class_type;
  tree ctor_return_type = (tree) 
                         ((void *)0)
                                  ;
  n64_enum_overload_flags flags = NO_SPECIAL;
  tree quals = (tree) 
              ((void *)0)
                       ;

  do { (specbits).idata[0] = 0; (specbits).idata[1] = 0; } while (0);
  if (decl_context == FUNCDEF)
    funcdef_flag = 1, decl_context = NORMAL;
  else if (decl_context == MEMFUNCDEF)
    funcdef_flag = -1, decl_context = FIELD;
  else if (decl_context == BITFIELD)
    bitfield = 1, decl_context = FIELD;

  if (flag_traditional && allocation_temporary_p ())
    end_temporary_allocation ();



  {
    tree last = (tree) 
               ((void *)0)
                        ;
    register tree decl = declarator;
    name = 
          ((void *)0)
              ;

    while (decl)
      switch (((n64_enum_tree_code) (decl)->common.code))
        {
 case COND_EXPR:
   ctype = (tree) 
          ((void *)0)
                   ;
   decl = ((decl)->exp.operands[0]);
   break;

 case BIT_NOT_EXPR:
   {
     tree name = ((decl)->exp.operands[0]);
     tree rename = (tree) 
                  ((void *)0)
                           ;

     my_friendly_assert (flags == NO_SPECIAL, 152);
     flags = DTOR_FLAG;
     return_type = return_dtor;
     my_friendly_assert (((n64_enum_tree_code) (name)->common.code) == IDENTIFIER_NODE, 153);
     if (ctype == (tree) 
                 ((void *)0)
                          )
       {
  if (current_class_type == (tree) 
                           ((void *)0)
                                    )
    {
      error ("destructors must be member functions");
      flags = NO_SPECIAL;
    }
  else
    {
      tree t = constructor_name (current_class_name);
      if (t != name)
        rename = t;
    }
       }
     else
       {
  tree t = constructor_name (ctype);
  if (t != name)
    rename = t;
       }

     if (rename)
       {
  error ("destructor `%s' must match class name `%s'",
         ((name)->identifier.pointer),
         ((rename)->identifier.pointer));
  ((decl)->exp.operands[0]) = rename;
       }
     decl = name;
   }
   break;

 case ADDR_EXPR:

 case ARRAY_REF:
 case INDIRECT_REF:
   ctype = (tree) 
          ((void *)0)
                   ;
   innermost_code = ((n64_enum_tree_code) (decl)->common.code);
   last = decl;
   decl = ((decl)->exp.operands[0]);
   break;

 case CALL_EXPR:
   if (parmlist_is_exprlist (((decl)->exp.operands[1])))
     {




       if (last)


  ((last)->exp.operands[0]) = ((decl)->exp.operands[0]);
       else
  declarator = ((decl)->exp.operands[0]);

       init = ((decl)->exp.operands[1]);

       decl = start_decl (declarator, declspecs, 1, (tree) 
                                                   ((void *)0)
                                                            );
       finish_decl (decl, init, (tree) 
                               ((void *)0)
                                        );
       return 0;
     }
   innermost_code = ((n64_enum_tree_code) (decl)->common.code);
   if (decl_context == FIELD && ctype == (tree) 
                                        ((void *)0)
                                                 )
     ctype = current_class_type;
   if (ctype
       && ((decl)->exp.operands[0]) == constructor_name_full (ctype))
     ((decl)->exp.operands[0]) = constructor_name (ctype);
   decl = ((decl)->exp.operands[0]);
   if (ctype != (tree) 
               ((void *)0)
       
      && decl != (tree) 
                 ((void *)0) 
                           && flags != DTOR_FLAG
       && decl == constructor_name (ctype))
     {
       return_type = return_ctor;
       ctor_return_type = ctype;
     }
   ctype = (tree) 
          ((void *)0)
                   ;
   break;

 case IDENTIFIER_NODE:
   dname = decl;
   decl = (tree) 
         ((void *)0)
                  ;

   if (! ((dname)->common.lang_flag_2)

       || (! strncmp (((dname)->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.length))) && ! ((dname)->common.type))
     name = ((dname)->identifier.pointer);
   else
     {
       if ((! strncmp (((dname)->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.length))))
  {
    my_friendly_assert (flags == NO_SPECIAL, 154);
    flags = TYPENAME_FLAG;
    ctor_return_type = ((dname)->common.type);
    return_type = return_conversion;
  }
       name = operator_name_string (dname);
     }
   break;

 case RECORD_TYPE:
 case UNION_TYPE:
 case ENUMERAL_TYPE:


   error ("declarator name missing");
   dname = ((decl)->type.name);
   if (dname && ((n64_enum_tree_code) (dname)->common.code) == TYPE_DECL)
     dname = ((dname)->decl.name);
   name = dname ? ((dname)->identifier.pointer) : "<nameless>";
   declspecs = temp_tree_cons ((tree) 
                              ((void *)0)
                                       , decl, declspecs);
   decl = (tree) 
         ((void *)0)
                  ;
   break;


 case SCOPE_REF:
   {




     tree cname = ((decl)->exp.operands[0]);
     if (cname == (tree) 
                 ((void *)0)
                          )
       ctype = (tree) 
              ((void *)0)
                       ;

     else if ((((n64_enum_tree_code) (cname)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (cname)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (cname)->common.code) == UNINSTANTIATED_P_TYPE)
       || ((n64_enum_tree_code) (cname)->common.code) == UNINSTANTIATED_P_TYPE)
       ctype = cname;
     else if (! is_aggr_typedef (cname, 1))
       {
  ((decl)->exp.operands[0]) = (tree) 
                          ((void *)0)
                                   ;
       }


     else if (((decl)->exp.operands[1])
       && ((n64_enum_tree_code) (((decl)->exp.operands[1]))->common.code) == INDIRECT_REF)
       {
  ((decl)->exp.operands[0]) = (((cname)->common.type));
       }
     else if (ctype == (tree) 
                      ((void *)0)
                               )
       {
  ctype = (((cname)->common.type));
  ((decl)->exp.operands[0]) = ctype;
       }
     else if (((decl)->exp.complexity) == current_class_depth)
       ((decl)->exp.operands[0]) = ctype;
     else
       {
  if (! (get_base_distance ((((cname)->common.type)), ctype, 0, (tree *)0) >= 0)
                  )
    {
      cp_error ("type `%T' is not derived from type `%T'",
         (((cname)->common.type)), ctype);
      ((decl)->exp.operands[0]) = (tree) 
                              ((void *)0)
                                       ;
    }
  else
    {
      ctype = (((cname)->common.type));
      ((decl)->exp.operands[0]) = ctype;
    }
       }

     if (ctype
  && ((decl)->exp.operands[1]) == constructor_name_full (ctype))
       ((decl)->exp.operands[1]) = constructor_name (ctype);
     decl = ((decl)->exp.operands[1]);
     if (ctype)
       {
  if (((n64_enum_tree_code) (decl)->common.code) == IDENTIFIER_NODE
      && constructor_name (ctype) == decl)
    {
      return_type = return_ctor;
      ctor_return_type = ctype;
    }
  else if (((n64_enum_tree_code) (decl)->common.code) == BIT_NOT_EXPR
    && ((n64_enum_tree_code) (((decl)->exp.operands[0]))->common.code) == IDENTIFIER_NODE
    && (constructor_name (ctype) == ((decl)->exp.operands[0])
        || constructor_name_full (ctype) == ((decl)->exp.operands[0])))
    {
      return_type = return_dtor;
      ctor_return_type = ctype;
      flags = DTOR_FLAG;
      decl = ((decl)->exp.operands[0]) = constructor_name (ctype);
    }
       }
   }
   break;

 case ERROR_MARK:
   decl = (tree) 
         ((void *)0)
                  ;
   break;

 default:
   return 0;
 }
    if (name == 
               ((void *)0)
                   )
      name = "type name";
  }




  if (funcdef_flag && innermost_code != CALL_EXPR)
    return 0;

  if (((dname && ((dname)->common.lang_flag_2)) || flags == TYPENAME_FLAG)
      && innermost_code != CALL_EXPR
      && ! (ctype && declspecs == (tree) 
                                 ((void *)0)
                                          ))
    {
      cp_error ("declaration of `%D' as non-function", dname);
      return void_type_node;
    }
  if (decl_context == NORMAL && ! namespace_bindings_p ())
    {
      struct n64_tag_binding_level *b = current_binding_level;
      current_binding_level = b->level_chain;
      if (current_binding_level != 0 && toplevel_bindings_p ())
 decl_context = PARM;
      current_binding_level = b;
    }
  for (spec = declspecs; spec; spec = ((spec)->common.chain))
    {
      register int i;
      register tree id;




      if (((n64_enum_tree_code) (spec)->common.code) != TREE_LIST)
 return 0;

      id = ((spec)->list.value);

      if (((n64_enum_tree_code) (id)->common.code) == IDENTIFIER_NODE)
 {
   if (id == ridpointers[(int) RID_INT]
       || id == ridpointers[(int) RID_CHAR]
       || id == ridpointers[(int) RID_BOOL]
       || id == ridpointers[(int) RID_WCHAR])
     {
       if (type)
  {
    if (id == ridpointers[(int) RID_BOOL])
      error ("`bool' is now a keyword");
    else
      cp_error ("extraneous `%T' ignored", id);
  }
       else
  {
    if (id == ridpointers[(int) RID_INT])
      explicit_int = 1;
    else if (id == ridpointers[(int) RID_CHAR])
      explicit_char = 1;
    type = (((((struct n64_tag_lang_identifier *)(id))->global_value))->common.type);
  }
       goto found;
     }

   if ((((id)->common.type) ? 1 : 0))
     {
       if (type)
  cp_error ("multiple declarations `%T' and `%T'", type, id);
       else
  type = (((id)->common.type));
       goto found;
     }

   for (i = (int) RID_EXTERN; i <= (int) RID_MUTABLE; i++)
     {
       if (ridpointers[i] == id)
  {
    if (i == (int) RID_LONG && (((unsigned long)1 << (int) ((i)%32)) & (specbits).idata[(i)/32]))
      {
        if (pedantic && ! in_system_header)
   pedwarn ("ANSI C++ does not support `long long'");
        else if (longlong)
   error ("`long long long' is too long for GCC");
        else
   longlong = 1;
      }
    else if ((((unsigned long)1 << (int) ((i)%32)) & (specbits).idata[(i)/32]))
      pedwarn ("duplicate `%s'", ((id)->identifier.pointer));
    do { (specbits).idata[(i)/32] |= ((unsigned long)1 << (int) ((i)%32)); } while (0);
    goto found;
  }
     }
 }
      if (type)
 error ("two or more data types in declaration of `%s'", name);
      else if (((n64_enum_tree_code) (id)->common.code) == IDENTIFIER_NODE)
 {
   register tree t = lookup_name (id, 1);
   if (!t || ((n64_enum_tree_code) (t)->common.code) != TYPE_DECL)
     error ("`%s' fails to be a typedef or built in type",
     ((id)->identifier.pointer));
   else
     {
       type = ((t)->common.type);
       decl_machine_attr = ((id)->decl.machine_attributes);
       typedef_decl = t;
     }
 }
      else if (((n64_enum_tree_code) (id)->common.code) != ERROR_MARK)

 type = id;

    found: ;
    }

  typedef_type = type;







  if (type == (tree) 
             ((void *)0)
      
     && ((((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32])
   || (((unsigned long)1 << (int) ((RID_UNSIGNED)%32)) & (specbits).idata[(RID_UNSIGNED)/32])
   || (((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
   || (((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32])))
    {

      type = integer_type_node;
      explicit_int = 1;
    }

  if (type == (tree) 
             ((void *)0)
                      )
    {
      explicit_int = -1;
      if (return_type == return_dtor)
 type = void_type_node;
      else if (return_type == return_ctor)
 type = build_pointer_type (ctor_return_type);
      else if (return_type == return_conversion)
 type = ctor_return_type;
      else if (current_class_type
        && (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
        && ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32])
     || (((current_class_type)->type.lang_specific)->type_flags.grokking_typedef))
        && (decl_context == FIELD || decl_context == NORMAL))
 {
   explicit_int = 0;
   opaque_typedef = 1;
   type = copy_node (opaque_type_node);
 }

      else if (decl_context == FIELD && declarator
        && ((n64_enum_tree_code) (declarator)->common.code) == SCOPE_REF)
 type = void_type_node;
      else
 {
   if (funcdef_flag)
     {
       if (warn_return_type
    && return_type == return_normal)

  warn_about_return_type = 1;
     }
   else if ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]))
     pedwarn ("ANSI C++ forbids typedef which does not specify a type");
   else if (declspecs == (tree) 
                        ((void *)0) 
                                  &&
     (innermost_code != CALL_EXPR || pedantic))
     cp_pedwarn ("ANSI C++ forbids declaration `%D' with no type or storage class",
   dname);
   type = integer_type_node;
 }
    }
  else if (return_type == return_dtor)
    {
      error ("return type specification for destructor invalid");
      type = void_type_node;
    }
  else if (return_type == return_ctor)
    {
      error ("return type specification for constructor invalid");
      type = build_pointer_type (ctor_return_type);
    }
  else if (return_type == return_conversion)
    {
      if (comptypes (type, ctor_return_type, 1) == 0)
 cp_error ("operator `%T' declared to return `%T'",
    ctor_return_type, type);
      else
 cp_pedwarn ("return type specified for `operator %T'",
      ctor_return_type);

      type = ctor_return_type;
    }

  else if ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]) && declarator == (tree) 
                                                               ((void *)0)
                                                                        )
    {

      if (processing_template_defn)
 return void_type_node;
    }

  ctype = (tree) 
         ((void *)0)
                  ;






  if ((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
      && ((type)->type.main_variant) == double_type_node)
    {
      do { (specbits).idata[(RID_LONG)/32] &= ~((unsigned long)1 << (int) ((RID_LONG)%32)); } while (0);
      type = build_type_variant (long_double_type_node, ((type)->common.readonly_flag),
     ((type)->common.volatile_flag));
    }



  if ((((unsigned long)1 << (int) ((RID_UNSIGNED)%32)) & (specbits).idata[(RID_UNSIGNED)/32])
      || (((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32])
      || (((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
      || (((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
    {
      int ok = 0;

      if (((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
 error ("short, signed or unsigned invalid for `%s'", name);
      else if (((n64_enum_tree_code) (type)->common.code) != INTEGER_TYPE)
 error ("long, short, signed or unsigned invalid for `%s'", name);
      else if ((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
        && (((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
 error ("long and short specified together for `%s'", name);
      else if (((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
  || (((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
        && explicit_char)
 error ("long or short specified with char for `%s'", name);
      else if (((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32])
  || (((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
        && ((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
 error ("long or short specified with floating type for `%s'", name);
      else if ((((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32])
        && (((unsigned long)1 << (int) ((RID_UNSIGNED)%32)) & (specbits).idata[(RID_UNSIGNED)/32]))
 error ("signed and unsigned given together for `%s'", name);
      else
 {
   ok = 1;
   if (!explicit_int && !explicit_char && pedantic)
     {
       pedwarn ("long, short, signed or unsigned used invalidly for `%s'",
         name);
       if (flag_pedantic_errors)
  ok = 0;
     }
 }


      if (! ok)
 {
   do { (specbits).idata[(RID_UNSIGNED)/32] &= ~((unsigned long)1 << (int) ((RID_UNSIGNED)%32)); } while (0);
   do { (specbits).idata[(RID_SIGNED)/32] &= ~((unsigned long)1 << (int) ((RID_SIGNED)%32)); } while (0);
   do { (specbits).idata[(RID_LONG)/32] &= ~((unsigned long)1 << (int) ((RID_LONG)%32)); } while (0);
   do { (specbits).idata[(RID_SHORT)/32] &= ~((unsigned long)1 << (int) ((RID_SHORT)%32)); } while (0);
   longlong = 0;
 }
    }



  if ((((unsigned long)1 << (int) ((RID_UNSIGNED)%32)) & (specbits).idata[(RID_UNSIGNED)/32])

      || (bitfield && flag_traditional)
      || (bitfield && ! flag_signed_bitfields
   && (explicit_int || explicit_char


       || ! (typedef_decl != (tree) 
                            ((void *)0)
      
     && (((typedef_decl))->decl.lang_flag_1)))
   && ((n64_enum_tree_code) (type)->common.code) != ENUMERAL_TYPE
   && (! (((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32]))))
    {
      if (longlong)
 type = long_long_unsigned_type_node;
      else if ((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32]))
 type = long_unsigned_type_node;
      else if ((((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
 type = short_unsigned_type_node;
      else if (type == char_type_node)
 type = unsigned_char_type_node;
      else if (typedef_decl)
 type = unsigned_type (type);
      else
 type = unsigned_type_node;
    }
  else if ((((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32])
    && type == char_type_node)
    type = signed_char_type_node;
  else if (longlong)
    type = long_long_integer_type_node;
  else if ((((unsigned long)1 << (int) ((RID_LONG)%32)) & (specbits).idata[(RID_LONG)/32]))
    type = long_integer_type_node;
  else if ((((unsigned long)1 << (int) ((RID_SHORT)%32)) & (specbits).idata[(RID_SHORT)/32]))
    type = short_integer_type_node;





  constp = !! (((unsigned long)1 << (int) ((RID_CONST)%32)) & (specbits).idata[(RID_CONST)/32]) + ((type)->common.readonly_flag);
  volatilep = !! (((unsigned long)1 << (int) ((RID_VOLATILE)%32)) & (specbits).idata[(RID_VOLATILE)/32]) + ((type)->common.volatile_flag);
  staticp = 0;
  inlinep = !! (((unsigned long)1 << (int) ((RID_INLINE)%32)) & (specbits).idata[(RID_INLINE)/32]);







  virtualp = (((unsigned long)1 << (int) ((RID_VIRTUAL)%32)) & (specbits).idata[(RID_VIRTUAL)/32]);
  do { (specbits).idata[(RID_VIRTUAL)/32] &= ~((unsigned long)1 << (int) ((RID_VIRTUAL)%32)); } while (0);
  explicitp = (((unsigned long)1 << (int) ((RID_EXPLICIT)%32)) & (specbits).idata[(RID_EXPLICIT)/32]) != 0;
  do { (specbits).idata[(RID_EXPLICIT)/32] &= ~((unsigned long)1 << (int) ((RID_EXPLICIT)%32)); } while (0);

  if ((((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]))
    staticp = 1 + (decl_context == FIELD);

  if (virtualp && staticp == 2)
    {
      cp_error ("member `%D' cannot be declared both virtual and static",
  dname);
      staticp = 0;
    }
  friendp = (((unsigned long)1 << (int) ((RID_FRIEND)%32)) & (specbits).idata[(RID_FRIEND)/32]);
  do { (specbits).idata[(RID_FRIEND)/32] &= ~((unsigned long)1 << (int) ((RID_FRIEND)%32)); } while (0);

  if ((((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
    {
      if (decl_context == PARM)
 {
   error ("non-member `%s' cannot be declared `mutable'", name);
   do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
 }
      else if (friendp || decl_context == TYPENAME)
 {
   error ("non-object member `%s' cannot be declared `mutable'", name);
   do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
 }
    }



  if (((specbits).idata[0] || (specbits).idata[1]))
    {
      if ((((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32])) nclasses++;
      if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32])) nclasses++;
      if (decl_context == PARM && nclasses > 0)
 error ("storage class specifiers invalid in parameter declarations");
      if ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]))
 {
   if (decl_context == PARM)
     error ("typedef declaration invalid in parameter declaration");
   nclasses++;
 }
      if ((((unsigned long)1 << (int) ((RID_AUTO)%32)) & (specbits).idata[(RID_AUTO)/32])) nclasses++;
      if ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32])) nclasses++;
    }


  if (virtualp
      && (current_class_name == (tree) 
                               ((void *)0) 
                                         || decl_context != FIELD))
    {
      error ("virtual outside class declaration");
      virtualp = 0;
    }
  if (current_class_name == (tree) 
                           ((void *)0) 
                                     && (((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
    {
      error ("only members can be declared mutable");
      do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
    }


  if (staticp && decl_context == TYPENAME
      && ((n64_enum_tree_code) (declspecs)->common.code) == TREE_LIST
      && ((n64_enum_tree_code) (((declspecs)->list.value))->common.code) == UNION_TYPE
      && ((((((((((declspecs)->list.value))->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((((declspecs)->list.value))->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
    decl_context = FIELD;



  if (decl_context == FIELD
      && (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
      && (! (((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]))
      && !(((current_class_type)->type.lang_specific)->type_flags.grokking_typedef))
    {
      if (constp)
 {
   error ("`const' specified for signature member function `%s'", name);
   constp = 0;
 }
      if (volatilep)
 {
   error ("`volatile' specified for signature member function `%s'",
   name);
   volatilep = 0;
 }
      if (inlinep)
 {
   error ("`inline' specified for signature member function `%s'", name);

   inlinep = 0;
 }
      if (friendp)
 {
   error ("`friend' declaration in signature definition");
   friendp = 0;
 }
      if (virtualp)
 {
   error ("`virtual' specified for signature member function `%s'",
   name);

   virtualp = 0;
 }
    }




  if (nclasses > 1)
    error ("multiple storage classes in declaration of `%s'", name);
  else if (decl_context != NORMAL && nclasses > 0)
    {
      if ((decl_context == PARM || decl_context == CATCHPARM)
   && ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32])
       || (((unsigned long)1 << (int) ((RID_AUTO)%32)) & (specbits).idata[(RID_AUTO)/32])))
 ;
      else if (decl_context == FIELD
        && (((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]))
 {


   register tree scanner;
   register tree previous_declspec;
     tree loc_typedecl;

   if (initialized)
     error ("typedef declaration includes an initializer");
   for (previous_declspec = (tree) 
                           ((void *)0)
                                    , scanner = declspecs;
        scanner;
        previous_declspec = scanner, scanner = ((scanner)->common.chain))
       {
       if (((scanner)->list.value) == ridpointers[(int) RID_TYPEDEF])
  break;
       }

   if (previous_declspec)
     ((previous_declspec)->common.chain) = ((scanner)->common.chain);
   else
     declspecs = ((scanner)->common.chain);

   declspecs = tree_cons ((tree) 
                         ((void *)0)
                                  , ridpointers[(int) RID_STATIC],
     declspecs);



   if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
     (((current_class_type)->type.lang_specific)->type_flags.grokking_typedef) = 1;

   loc_typedecl =
     grokdeclarator (declarator, declspecs, FIELD, 0, (tree) 
                                                     ((void *)0)
                                                              , (tree) 
                                                                ((void *)0)
                                                                         );

   if (previous_declspec)
     ((previous_declspec)->common.chain) = scanner;

   if (loc_typedecl != error_mark_node)
       {
       register int i = sizeof (struct n64_tag_lang_decl_flags) / sizeof (int);
       register int *pi;

       ((loc_typedecl)->common.code = (int) (TYPE_DECL));


       ((loc_typedecl)->decl.arguments) = 0;

       pi = (int *) permalloc (sizeof (struct n64_tag_lang_decl_flags));
       while (i > 0)
         pi[--i] = 0;
       ((loc_typedecl)->decl.lang_specific) = (struct n64_tag_lang_decl *) pi;
     }

   if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
     {
       (((current_class_type)->type.lang_specific)->type_flags.grokking_typedef) = 0;
       if (loc_typedecl != error_mark_node && opaque_typedef)
  (((current_class_type)->type.lang_specific)->type_flags.has_opaque_typedecls) = 1;
     }

     return loc_typedecl;
 }
      else if (decl_context == FIELD
        && (! (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
     || (((current_class_type)->type.lang_specific)->type_flags.grokking_typedef))

         && (((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]))


 ;
      else
 {
   if (decl_context == FIELD)
     {
       tree tmp = (tree) 
                 ((void *)0)
                          ;
       register int op = 0;

       if (declarator)
  {
    tmp = ((declarator)->exp.operands[0]);
    op = ((tmp)->common.lang_flag_2);
  }
       error ("storage class specified for %s `%s'",
       (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
       ? (op
   ? "signature member operator"
   : "signature member function")
       : (op ? "member operator" : "field"),
       op ? operator_name_string (tmp) : name);
     }
   else
     error (((decl_context == PARM || decl_context == CATCHPARM)
      ? "storage class specified for parameter `%s'"
      : "storage class specified for typename"), name);
   do { (specbits).idata[(RID_REGISTER)/32] &= ~((unsigned long)1 << (int) ((RID_REGISTER)%32)); } while (0);
   do { (specbits).idata[(RID_AUTO)/32] &= ~((unsigned long)1 << (int) ((RID_AUTO)%32)); } while (0);
   do { (specbits).idata[(RID_EXTERN)/32] &= ~((unsigned long)1 << (int) ((RID_EXTERN)%32)); } while (0);

   if (decl_context == FIELD && (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
     {
       do { (specbits).idata[(RID_STATIC)/32] &= ~((unsigned long)1 << (int) ((RID_STATIC)%32)); } while (0);
       staticp = 0;
     }
 }
    }
  else if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32]) && initialized && !funcdef_flag)
    {
      if (toplevel_bindings_p ())
 {


   if (! constp)
     warning ("`%s' initialized and declared `extern'", name);
 }
      else
 error ("`%s' has both `extern' and initializer", name);
    }
  else if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32]) && funcdef_flag
    && ! toplevel_bindings_p ())
    error ("nested function `%s' declared `extern'", name);
  else if (toplevel_bindings_p ())
    {
      if ((((unsigned long)1 << (int) ((RID_AUTO)%32)) & (specbits).idata[(RID_AUTO)/32]))
 error ("top-level declaration of `%s' specifies `auto'", name);
    }





  while (declarator && ((n64_enum_tree_code) (declarator)->common.code) != IDENTIFIER_NODE)
    {
      if (((n64_enum_tree_code) (type)->common.code) == ERROR_MARK)
 {
   if (((n64_enum_tree_code) (declarator)->common.code) == SCOPE_REF)
     declarator = ((declarator)->exp.operands[1]);
   else
     declarator = ((declarator)->exp.operands[0]);
   continue;
 }
      if (quals != (tree) 
                  ((void *)0)
   
  && (declarator == (tree) 
                    ((void *)0)
       
      || ((n64_enum_tree_code) (declarator)->common.code) != SCOPE_REF))
 {
   if (ctype == (tree) 
               ((void *)0) 
                         && ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
     ctype = ((type)->type.maxval);
   if (ctype != (tree) 
               ((void *)0)
                        )
     {



       tree dummy = build_decl (TYPE_DECL, (tree) 
                                          ((void *)0)
                                                   , type);

       ctype = grok_method_quals (ctype, dummy, quals);
       type = ((dummy)->common.type);
       quals = (tree) 
              ((void *)0)
                       ;
     }
 }
      switch (((n64_enum_tree_code) (declarator)->common.code))
 {
 case ARRAY_REF:
   {
     register tree itype = (tree) 
                          ((void *)0)
                                   ;
     register tree size = ((declarator)->exp.operands[1]);

     tree index_type = signed_type (sizetype);

     declarator = ((declarator)->exp.operands[0]);



     if (((type)->type.main_variant) == void_type_node)
       {
  cp_error ("declaration of `%D' as array of voids", dname);
  type = error_mark_node;
       }

     if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
       {
  cp_error ("declaration of `%D' as array of functions", dname);
  type = error_mark_node;
       }





     if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
       {
  if (decl_context == TYPENAME)
    cp_error ("cannot make arrays of references");
  else
    cp_error ("declaration of `%D' as array of references",
       dname);
  type = error_mark_node;
       }

     if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
       {
    cp_error ("declaration of `%D' as array of data members",
       dname);
  type = error_mark_node;
       }

     if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
       {
  cp_error ("declaration of `%D' as array of function members",
     dname);
  type = error_mark_node;
       }

     if (size == error_mark_node)
       type = error_mark_node;

     if (type == error_mark_node)
       continue;

     if (size)
       {






  int yes = suspend_momentary ();

  if (((n64_enum_tree_code) (size)->common.code) == NOP_EXPR
      && ((size)->common.type) == ((((size)->exp.operands[0]))->common.type))
    size = ((size)->exp.operands[0]);



  if (((n64_enum_tree_code) (size)->common.code) == TEMPLATE_CONST_PARM)
    goto dont_grok_size;

  if (((n64_enum_tree_code) (((size)->common.type))->common.code) != INTEGER_TYPE
      && ((n64_enum_tree_code) (((size)->common.type))->common.code) != ENUMERAL_TYPE)
    {
      cp_error ("size of array `%D' has non-integer type",
         dname);
      size = integer_one_node;
    }
  if ((((size)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (size)->common.code))]) == 'd'))
    size = decl_constant_value (size);
  if (pedantic && integer_zerop (size))
    cp_pedwarn ("ANSI C++ forbids zero-size array `%D'", dname);
  if (((size)->common.constant_flag))
    {
      int old_flag_pedantic_errors = flag_pedantic_errors;
      int old_pedantic = pedantic;
      pedantic = flag_pedantic_errors = 1;

      constant_expression_warning (size);
      pedantic = old_pedantic;
      flag_pedantic_errors = old_flag_pedantic_errors;
      if ((((size)->int_cst.int_cst_high) < ((integer_zero_node)->int_cst.int_cst_high) || (((size)->int_cst.int_cst_high) == ((integer_zero_node)->int_cst.int_cst_high) && ((unsigned int) ((size)->int_cst.int_cst_low) < (unsigned int) ((integer_zero_node)->int_cst.int_cst_low)))))
        {
   cp_error ("size of array `%D' is negative", dname);
   size = integer_one_node;
        }
    }
  else
    {
      if (pedantic)
        {
   if (dname)
     cp_pedwarn ("ANSI C++ forbids variable-size array `%D'",
          dname);
   else
     cp_pedwarn ("ANSI C++ forbids variable-size array");
        }


      size_varies = 1;
    }

       dont_grok_size:
  itype =
    fold (build_binary_op (MINUS_EXPR,
      convert (index_type, size),
      convert (index_type,
        integer_one_node), 1));
  if (! ((itype)->common.constant_flag))
    itype = variable_size (itype);
  itype = build_index_type (itype);
  resume_momentary (yes);
       }






     type = build_cplus_array_type (type, itype);
     if (constp || volatilep)
       type = cp_build_type_variant (type, constp, volatilep);

     ctype = (tree) 
            ((void *)0)
                     ;
   }
   break;

 case CALL_EXPR:
   {
     tree arg_types;
     int funcdecl_p;
     tree inner_parms = ((declarator)->exp.operands[1]);
     tree inner_decl = ((declarator)->exp.operands[0]);
     if (constp || volatilep)
       {
  type = cp_build_type_variant (type, constp, volatilep);
  if ((((type)->type.lang_flag_5)))
    build_pointer_type (type);
  constp = 0;
  volatilep = 0;
       }




     if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
       {
  error ("`%s' declared as function returning a function", name);
  type = integer_type_node;
       }
     if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
       {
  error ("`%s' declared as function returning an array", name);
  type = integer_type_node;
       }

     if (inner_decl && ((n64_enum_tree_code) (inner_decl)->common.code) == SCOPE_REF)
       inner_decl = ((inner_decl)->exp.operands[1]);


     quals = ((declarator)->exp.operands[2]);



     funcdecl_p =
       inner_decl && (((n64_enum_tree_code) (inner_decl)->common.code) == IDENTIFIER_NODE
        || ((n64_enum_tree_code) (inner_decl)->common.code) == BIT_NOT_EXPR);

     if (ctype == (tree) 
                 ((void *)0)
  
 && decl_context == FIELD
  && funcdecl_p
  && (friendp == 0 || dname == current_class_name))
       ctype = current_class_type;

     if (ctype && return_type == return_conversion)
       (((ctype)->type.lang_specific)->type_flags.has_type_conversion) = 1;
     if (ctype && constructor_name (ctype) == dname)
       {





  if (flags == DTOR_FLAG)
    {



      if (staticp == 2)
        error ("destructor cannot be static member function");
      if (quals)
        {
   error ("destructors cannot be declared `const' or `volatile'");
   return void_type_node;
        }
      if (decl_context == FIELD)
        {
   if (! member_function_or_else (ctype, current_class_type,
             "destructor for alien class `%s' cannot be a member"))
     return void_type_node;
        }
    }
  else
    {
      if (explicitp == 1)
        explicitp = 2;



      if (staticp == 2)
        error ("constructor cannot be static member function");
      if (virtualp)
        {
   pedwarn ("constructors cannot be declared virtual");
   virtualp = 0;
        }
      if (quals)
        {
   error ("constructors cannot be declared `const' or `volatile'");
   return void_type_node;
         }
      {
        RID_BIT_TYPE tmp_bits;
        memcpy ((void*)&tmp_bits,(void*)&specbits,sizeof(RID_BIT_TYPE));
        do { (tmp_bits).idata[(RID_INLINE)/32] &= ~((unsigned long)1 << (int) ((RID_INLINE)%32)); } while (0);
        do { (tmp_bits).idata[(RID_STATIC)/32] &= ~((unsigned long)1 << (int) ((RID_STATIC)%32)); } while (0);
        if (((tmp_bits).idata[0] || (tmp_bits).idata[1]))
   error ("return value type specifier for constructor ignored");
      }
      type = build_pointer_type (ctype);
      if (decl_context == FIELD &&
   (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
        {
   error ("constructor not allowed in signature");
   return void_type_node;
        }
      else if (decl_context == FIELD)
        {
   if (! member_function_or_else (ctype, current_class_type,
             "constructor for alien class `%s' cannot be member"))
     return void_type_node;
   (((ctype)->type.lang_flag_1)) = 1;
   if (return_type != return_ctor)
     return (tree) 
           ((void *)0)
                    ;
        }
    }
  if (decl_context == FIELD)
    staticp = 0;
       }
     else if (friendp)
       {
  if (initialized)
    error ("can't initialize friend function `%s'", name);
  if (virtualp)
    {

      error ("virtual functions cannot be friends");
      do { (specbits).idata[(RID_FRIEND)/32] &= ~((unsigned long)1 << (int) ((RID_FRIEND)%32)); } while (0);
      friendp = 0;
    }
  if (decl_context == NORMAL)
    error ("friend declaration not in class definition");
  if (current_function_decl && funcdef_flag)
    cp_error ("can't define friend function `%s' in a local class definition",
       name);
       }



     if (flag_traditional
  && ((type)->type.main_variant) == float_type_node)
       {
  type = build_type_variant (double_type_node,
        ((type)->common.readonly_flag),
        ((type)->common.volatile_flag));
       }




     declarator = ((declarator)->exp.operands[0]);




     arg_types = grokparms (inner_parms, funcdecl_p ? funcdef_flag : 0);

     if (declarator)
       {




  if (((n64_enum_tree_code) (declarator)->common.code) == BIT_NOT_EXPR)
    {
      declarator = ((declarator)->exp.operands[0]);

      if (strict_prototype == 0 && arg_types == (tree) 
                                               ((void *)0)
                                                        )
        arg_types = void_list_node;
      else if (arg_types == (tree) 
                           ((void *)0)
        
       || arg_types != void_list_node)
        {
   error ("destructors cannot be specified with parameters");
   arg_types = void_list_node;
        }
    }
       }



     type = build_function_type (type,
     flag_traditional ? 0 : arg_types);
   }
   break;

 case ADDR_EXPR:
 case INDIRECT_REF:



   if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
     {
       error ("cannot declare %s to references",
       ((n64_enum_tree_code) (declarator)->common.code) == ADDR_EXPR
       ? "references" : "pointers");
       declarator = ((declarator)->exp.operands[0]);
       continue;
     }

   if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE
       && (((n64_enum_tree_code) (((type)->common.type))->common.code) == VOID_TYPE
    || ((n64_enum_tree_code) (((type)->common.type))->common.code) == REFERENCE_TYPE))
     {
       cp_error ("cannot declare pointer to `%#T' member",
   ((type)->common.type));
       type = ((type)->common.type);
     }




   if (constp || volatilep)
     {




       if (! (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
  {
    type = cp_build_type_variant (type, constp, volatilep);
    if ((((type)->type.lang_flag_5)))
      build_pointer_type (type);
    constp = 0;
    volatilep = 0;
  }
     }

   if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
     {
       if (((n64_enum_tree_code) (declarator)->common.code) == ADDR_EXPR)
  {
    if (((type)->type.maxval) == (tree) 
                                      ((void *)0)
        
       && ((type)->type.size))
      cp_warning ("empty signature `%T' used in signature reference declaration",
    type);




    sorry ("signature reference");
    return (tree) 
          ((void *)0)
                   ;

  }
       else
  {
    if (((type)->type.maxval) == (tree) 
                                      ((void *)0)
        
       && ((type)->type.size))
      cp_warning ("empty signature `%T' used in signature pointer declaration",
    type);
    type = build_signature_pointer_type (type,
             constp, volatilep);
  }
       constp = 0;
       volatilep = 0;
     }
   else if (((n64_enum_tree_code) (declarator)->common.code) == ADDR_EXPR)
     {
       if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
  {
    error ("cannot declare references to functions; use pointer to function instead");
    type = build_pointer_type (type);
  }
       else
  {
    if (((type)->type.main_variant) == void_type_node)
      error ("invalid type: `void &'");
    else
      type = build_reference_type (type);
  }
     }
   else if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
     {
       type = build_ptrmemfunc_type (build_pointer_type (type));
     }
   else
     type = build_pointer_type (type);




   if (((declarator)->common.type))
     {
       register tree typemodlist;
       int erred = 0;
       for (typemodlist = ((declarator)->common.type); typemodlist;
     typemodlist = ((typemodlist)->common.chain))
  {
    if (((typemodlist)->list.value) == ridpointers[(int) RID_CONST])
      constp++;
    else if (((typemodlist)->list.value) == ridpointers[(int) RID_VOLATILE])
      volatilep++;
    else if (!erred)
      {
        erred = 1;
        error ("invalid type modifier within %s declarator",
        ((n64_enum_tree_code) (declarator)->common.code) == ADDR_EXPR
        ? "reference" : "pointer");
      }
  }
       if (constp > 1)
  pedwarn ("duplicate `const'");
       if (volatilep > 1)
  pedwarn ("duplicate `volatile'");
       if (((n64_enum_tree_code) (declarator)->common.code) == ADDR_EXPR
    && (constp || volatilep))
  {
    if (constp)
      pedwarn ("discarding `const' applied to a reference");
    if (volatilep)
      pedwarn ("discarding `volatile' applied to a reference");
    constp = volatilep = 0;
  }
     }
   declarator = ((declarator)->exp.operands[0]);
   ctype = (tree) 
          ((void *)0)
                   ;
   break;

 case SCOPE_REF:
   {






     tree sname = ((declarator)->exp.operands[1]);

     if (((n64_enum_tree_code) (sname)->common.code) == BIT_NOT_EXPR)
       sname = ((sname)->exp.operands[0]);

     if (((declarator)->exp.complexity) == 0)

                       ;
     else if (friendp && (((declarator)->exp.complexity) < 2))
                                                                        ;
     else if (((declarator)->exp.complexity) == current_class_depth)
       {




  pop_nested_class (1);
  ((declarator)->exp.complexity) = current_class_depth;
       }
     else
       my_friendly_abort (16);

     if (((declarator)->exp.operands[0]) == (tree) 
                                        ((void *)0)
                                                 )
       {




  declarator = sname;
  continue;
       }
     ctype = ((declarator)->exp.operands[0]);

     if (sname == (tree) 
                 ((void *)0)
                          )
       goto done_scoping;

     if (((n64_enum_tree_code) (sname)->common.code) == IDENTIFIER_NODE)
       {



  if (ctype == current_class_type)
    {






      if (pedantic)
        cp_pedwarn ("extra qualification `%T::' on member `%s' ignored",
      ctype, name);
    }
  else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
    {
      if (current_class_type == (tree) 
                               ((void *)0)
   
  || friendp)
        type = build_cplus_method_type (build_type_variant (ctype, constp, volatilep),
            ((type)->common.type), ((type)->type.values));
      else
        {
   cp_error ("cannot declare member function `%T::%s' within `%T'",
      ctype, name, current_class_type);
   return void_type_node;
        }
    }
  else if (((ctype)->type.size) != (tree) 
                               ((void *)0)
    
   || ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32])))
    {
      tree t;





      if (explicit_int == -1 && decl_context == FIELD
   && funcdef_flag == 0)
        {


   t = lookup_field (ctype, sname, 0, 0);
   if (t)
     {
       t = build_lang_field_decl (FIELD_DECL, build_nt (SCOPE_REF, ctype, t), type);
       ((t)->decl.initial) = init;
       return t;
     }

   t = lookup_fnfields (((ctype)->type.binfo), sname, 0);
   if (t)
     {
       if (flags == DTOR_FLAG)
         t = ((t)->list.value);
       else if (((ctype)->type.maxval)
         && ((t)->list.value) == ((((ctype)->type.maxval))->vec.a[0]))
         {

    t = (((((t)->list.value))->decl.lang_specific)->chain);
    if (t == (tree) 
            ((void *)0)
                     )
      cp_error ("`%T' does not have any constructors",
         ctype);
    t = build_tree_list ((tree) 
                        ((void *)0)
                                 , t);
         }
       t = build_lang_field_decl (FIELD_DECL, build_nt (SCOPE_REF, ctype, t), type);
       ((t)->decl.initial) = init;
       return t;
     }

   cp_error
     ("field `%D' is not a member of structure `%T'",
      sname, ctype);
        }

      if (current_class_type)
        {
   cp_error ("cannot declare member `%T::%s' within `%T'",
      ctype, name, current_class_type);
   return void_type_node;
        }
      type = build_offset_type (ctype, type);
    }
  else if (uses_template_parms (ctype))
    {
                    n64_enum_tree_code c;
                    if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
        {
   type = build_cplus_method_type (build_type_variant (ctype, constp, volatilep),
       ((type)->common.type),
       ((type)->type.values));
   c = FUNCTION_DECL;
        }
      }
  else
    {
      cp_error ("structure `%T' not yet defined", ctype);
      return error_mark_node;
    }

  declarator = sname;
       }
     else if (((n64_enum_tree_code) (sname)->common.code) == SCOPE_REF)
       my_friendly_abort (17);
     else
       {
       done_scoping:
  declarator = ((declarator)->exp.operands[1]);
  if (declarator && ((n64_enum_tree_code) (declarator)->common.code) == CALL_EXPR)

    ;
  else
    {
      if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
        type = build_cplus_method_type (build_type_variant (ctype, constp, volatilep), ((type)->common.type), ((type)->type.values));
      else
        type = build_offset_type (ctype, type);
    }
       }
   }
   break;

 case BIT_NOT_EXPR:
   declarator = ((declarator)->exp.operands[0]);
   break;

 case RECORD_TYPE:
 case UNION_TYPE:
 case ENUMERAL_TYPE:
   declarator = (tree) 
               ((void *)0)
                        ;
   break;

 case ERROR_MARK:
   declarator = (tree) 
               ((void *)0)
                        ;
   break;

 default:
   my_friendly_abort (158);
 }
    }

  if (explicitp == 1)
    {
      error ("only constructors can be declared `explicit'");
      explicitp = 0;
    }





  if ((((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
    {
      if (constp)
 {
   error ("const `%s' cannot be declared `mutable'", name);
   do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
 }
      else if (staticp)
 {
   error ("static `%s' cannot be declared `mutable'", name);
   do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
 }
    }

  if ((((unsigned long)1 << (int) ((RID_TYPEDEF)%32)) & (specbits).idata[(RID_TYPEDEF)/32]))
    {
      tree decl;



      if (constp || volatilep)
 type = cp_build_type_variant (type, constp, volatilep);





      if (type != error_mark_node
   && ((type)->type.name)
   && ((n64_enum_tree_code) (((type)->type.name))->common.code) == TYPE_DECL
   && ((((((((type)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((type)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
 {

   lookup_tag_reverse (type, declarator);
   (((((type)->type.name))->decl.name)) = declarator;

   if (((type)->type.lang_specific))
     (((type)->type.lang_specific)->type_flags.was_anonymous) = 1;

   {
     tree d = ((type)->type.name), c = ((d)->decl.context);

     if (!c)
       set_nested_typename (d, 0, declarator, type);
     else if (((n64_enum_tree_code) (c)->common.code) == FUNCTION_DECL)
       set_nested_typename (d, ((c)->decl.assembler_name),
       declarator, type);
     else
       set_nested_typename (d, (((((c)->type.name))->decl.arguments)), declarator, type);

     ((d)->decl.assembler_name) = ((d)->decl.name);
     ((d)->decl.assembler_name)
       = get_identifier (build_overload_name (type, 1, 1));
   }
 }




      decl = build_decl (TYPE_DECL, declarator, type);

      if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
 {
   cp_error_at ("typedef name may not be class-qualified", decl);
   return (tree) 
         ((void *)0)
                  ;
 }
      else if (quals)
 {
   if (ctype == (tree) 
               ((void *)0)
                        )
     {
       if (((n64_enum_tree_code) (type)->common.code) != METHOD_TYPE)
  cp_error_at ("invalid type qualifier for non-method type", decl);
       else
  ctype = ((type)->type.maxval);
     }
   if (ctype != (tree) 
               ((void *)0)
                        )
     grok_method_quals (ctype, decl, quals);
 }

      if ((((unsigned long)1 << (int) ((RID_SIGNED)%32)) & (specbits).idata[(RID_SIGNED)/32])
   || (typedef_decl && (((typedef_decl))->decl.lang_flag_1)))
 (((decl))->decl.lang_flag_1) = 1;

      if ((((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
 {
   error ("non-object member `%s' cannot be declared mutable", name);
 }

      return decl;
    }







  if (type == typedef_type && ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
      && ((type)->type.values) == (tree) 
                              ((void *)0)
                                       )
    {
      type = build_cplus_array_type (((type)->common.type), ((type)->type.values));
    }




  if (decl_context == TYPENAME)
    {


      if (constp || volatilep)
 if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
   error ("`const' or `volatile' specified with signature type");
 else
   type = cp_build_type_variant (type, constp, volatilep);


      if (friendp)
 {
   if (volatilep)
     {
       cp_error ("`volatile' specified for friend class declaration");
       volatilep = 0;
     }
   if (inlinep)
     {
       cp_error ("`inline' specified for friend class declaration");
       inlinep = 0;
     }


   if (type != integer_type_node)
     {

       if (current_class_type)
  make_friend_class (current_class_type, ((type)->type.main_variant));
       else
  error ("trying to make class `%s' a friend of global scope",
         ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
       type = void_type_node;
     }
 }
      else if (quals)
 {



   tree dummy = build_decl (TYPE_DECL, declarator, type);

   if (ctype == (tree) 
               ((void *)0)
                        )
     {
       my_friendly_assert (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE, 159);
       ctype = ((type)->type.maxval);
     }
   grok_method_quals (ctype, dummy, quals);
   type = ((dummy)->common.type);
 }

      return type;
    }
  else if (declarator == (tree) 
                        ((void *)0) 
                                  && decl_context != PARM
    && decl_context != CATCHPARM
    && ((n64_enum_tree_code) (type)->common.code) != UNION_TYPE
    && ! bitfield)
    {
      cp_error ("abstract declarator `%T' used as declaration", type);
      declarator = make_anon_name ();
    }






  if (((type)->type.main_variant) == void_type_node && decl_context != PARM)
    {
      if (! declarator)
 error ("unnamed variable or field declared void");
      else if (((n64_enum_tree_code) (declarator)->common.code) == IDENTIFIER_NODE)
 {
   if (((declarator)->common.lang_flag_2))




     my_friendly_abort (356);

   else
     error ("variable or field `%s' declared void", name);
 }
      else
 error ("variable or field declared void");
      type = integer_type_node;
    }




  {
    register tree decl;

    if (decl_context == PARM)
      {
 if (ctype)
   error ("cannot use `::' in parameter declaration");





 if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
   {

     type = build_pointer_type
       (cp_build_type_variant (((type)->common.type), constp, volatilep));
     volatilep = constp = 0;
   }
 else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
   type = build_pointer_type (type);
 else if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
   type = build_pointer_type (type);
 else if (type == void_type_node && declarator)
   {
     error ("declaration of `%s' as void", name);
     return (tree) 
           ((void *)0)
                    ;
   }

 decl = build_decl (PARM_DECL, declarator, type);

 bad_specifiers (decl, "parameter", virtualp, quals != (tree) 
                                                      ((void *)0)
                                                               ,
   inlinep, friendp, raises != (tree) 
                              ((void *)0)
                                       );
 if (current_class_type
     && (((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
   {
     if (inlinep)
       error ("parameter of signature member function declared `inline'");
     if ((((unsigned long)1 << (int) ((RID_AUTO)%32)) & (specbits).idata[(RID_AUTO)/32]))
       error ("parameter of signature member function declared `auto'");
     if ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32]))
       error ("parameter of signature member function declared `register'");
   }






 ((decl)->decl.initial) = type_promotes_to (type);
      }
    else if (decl_context == FIELD)
      {
 if (type == error_mark_node)
   {


     decl = (tree) 
           ((void *)0)
                    ;
   }
 else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
   {
     int publicp = 0;

     if (friendp == 0)
       {
  if (ctype == (tree) 
              ((void *)0)
                       )
    ctype = current_class_type;

  if (ctype == (tree) 
              ((void *)0)
                       )
    {
      cp_error ("can't make `%D' into a method -- not in a class",
         declarator);
      return void_type_node;
    }



  if (virtualp && ((n64_enum_tree_code) (ctype)->common.code) == UNION_TYPE)
    {
      cp_error ("function `%D' declared virtual inside a union",
         declarator);
      return void_type_node;
    }

  if (declarator == ansi_opname[(int) NEW_EXPR]
      || declarator == ansi_opname[(int) VEC_NEW_EXPR]
      || declarator == ansi_opname[(int) DELETE_EXPR]
      || declarator == ansi_opname[(int) VEC_DELETE_EXPR])
    {
      if (virtualp)
        {
   cp_error ("`%D' cannot be declared virtual, since it is always static",
      declarator);
   virtualp = 0;
        }
    }
  else if (staticp < 2)
    type = build_cplus_method_type (build_type_variant (ctype, constp, volatilep),
        ((type)->common.type), ((type)->type.values));
       }


     publicp = (! friendp
         || (((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32])
         || ! (funcdef_flag < 0 || inlinep));
     decl = grokfndecl (ctype, type, declarator,
          virtualp, flags, quals, raises, attrlist,
          friendp ? -1 : 0, publicp, inlinep);
     if (decl == (tree) 
                ((void *)0)
                         )
       return (tree) 
             ((void *)0)
                      ;
     decl = build_decl_attribute_variant (decl, decl_machine_attr);

     if (explicitp == 2)
       (((decl)->decl.lang_specific)->decl_flags.nonconverting) = 1;
   }
 else if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
   {




     decl = grokfndecl (ctype, type, declarator,
          virtualp, flags, quals, raises, attrlist,
          friendp ? -1 : 0, 1, 0);
     if (decl == (tree) 
                ((void *)0)
                         )
       return (tree) 
             ((void *)0)
                      ;
   }
 else if (((type)->type.size) == (tree) 
                             ((void *)0) 
                                       && !staticp
   && (((n64_enum_tree_code) (type)->common.code) != ARRAY_TYPE || initialized == 0))
   {
     if (declarator)
       cp_error ("field `%D' has incomplete type", declarator);
     else
       cp_error ("name `%T' has incomplete type", type);



     if (current_class_type
  && ((current_class_type)->type.name)
  && (((struct n64_tag_lang_identifier *)(((((current_class_type)->type.name))->decl.name)))->class_template_info)
  && declspecs && ((declspecs)->list.value)
  && ((((declspecs)->list.value))->common.type) == type)
       cp_error ("  in instantiation of template `%T'",
   current_class_type);

     type = error_mark_node;
     decl = (tree) 
           ((void *)0)
                    ;
   }
 else
   {
     if (friendp)
       {
  error ("`%s' is neither function nor method; cannot be declared friend",
         ((declarator)->identifier.pointer));
  friendp = 0;
       }
     decl = (tree) 
           ((void *)0)
                    ;
   }

 if (friendp)
   {

     if (ctype == current_class_type)
       warning ("member functions are implicitly friends of their class");
     else
       {
  tree t = (tree) 
          ((void *)0)
                   ;
  if (decl && ((decl)->decl.name))
    t = do_friend (ctype, declarator, decl,
     last_function_parms, flags, quals);
  if (t && funcdef_flag)
    return t;

  return void_type_node;
       }
   }



 if (decl == (tree) 
            ((void *)0)
                     )
   {
     if (initialized)
       {







  if (staticp)
    {
      if (pedantic)
        {
   if (! constp)
     cp_pedwarn ("ANSI C++ forbids in-class initialization of non-const static member `%D'",
          declarator);

   else if (! (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE))
     cp_pedwarn ("ANSI C++ forbids member constant `%D' of non-integral type `%T'", declarator, type);
        }
    }







  else if (pedantic || ! constp)
    cp_pedwarn ("ANSI C++ forbids initialization of %s `%D'",
         constp ? "const member" : "member", declarator);
       }

     if (staticp || (constp && initialized))
       {

  if (staticp && declarator == current_class_name)
    cp_pedwarn ("ANSI C++ forbids static member `%D' with same name as enclosing class",
         declarator);





  decl = build_lang_field_decl (VAR_DECL, declarator, type);
  ((decl)->common.static_flag) = 1;

  ((decl)->common.public_flag) = ((decl)->decl.external_flag) = !!staticp;
       }
     else
       {
  decl = build_lang_field_decl (FIELD_DECL, declarator, type);
  if ((((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
    {
      (((decl)->decl.lang_specific)->decl_flags.mutable_flag) = 1;
      do { (specbits).idata[(RID_MUTABLE)/32] &= ~((unsigned long)1 << (int) ((RID_MUTABLE)%32)); } while (0);
    }
       }

     bad_specifiers (decl, "field", virtualp, quals != (tree) 
                                                      ((void *)0)
                                                               ,
       inlinep, friendp, raises != (tree) 
                                  ((void *)0)
                                           );
   }
      }
    else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
      {
 tree original_name = declarator;
 int publicp = 0;

 if (! declarator)
   return (tree) 
         ((void *)0)
                  ;

 if ((((unsigned long)1 << (int) ((RID_AUTO)%32)) & (specbits).idata[(RID_AUTO)/32]))
   error ("storage class `auto' invalid for function `%s'", name);
 else if ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32]))
   error ("storage class `register' invalid for function `%s'", name);




 if (! toplevel_bindings_p ()
     && ! processing_template_decl
     && ((((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32])
  || (((unsigned long)1 << (int) ((RID_INLINE)%32)) & (specbits).idata[(RID_INLINE)/32]))
     && pedantic)
   {
     if ((((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]))
       pedwarn ("storage class `static' invalid for function `%s' declared out of global scope", name);
     else
       pedwarn ("storage class `inline' invalid for function `%s' declared out of global scope", name);
   }

 if (ctype == (tree) 
             ((void *)0)
                      )
   {
     if (virtualp)
       {
  error ("virtual non-class function `%s'", name);
  virtualp = 0;
       }

     if (current_lang_name == lang_name_cplusplus
  && ! (((original_name)->identifier.length) == 4
        && ((original_name)->identifier.pointer)[0] == 'm'
        && strcmp (((original_name)->identifier.pointer), "main") == 0)
  && ! (((original_name)->identifier.length) > 10
        && ((original_name)->identifier.pointer)[0] == '_'
        && ((original_name)->identifier.pointer)[1] == '_'
        && strncmp (((original_name)->identifier.pointer)+2, "builtin_", 8) == 0))

       declarator = build_decl_overload (dname, ((type)->type.values), 0);
   }
 else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE && staticp < 2)
   type = build_cplus_method_type (build_type_variant (ctype, constp, volatilep),
       ((type)->common.type), ((type)->type.values));


 publicp = (ctype != (tree) 
                    ((void *)0)
     
    || (((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32])
     || (!(((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32])
         && !(((unsigned long)1 << (int) ((RID_INLINE)%32)) & (specbits).idata[(RID_INLINE)/32])));

 decl = grokfndecl (ctype, type, original_name,
      virtualp, flags, quals, raises, attrlist,
      processing_template_decl ? 0 : friendp ? 2 : 1,
      publicp, inlinep);
 if (decl == (tree) 
            ((void *)0)
                     )
   return (tree) 
         ((void *)0)
                  ;

 if (ctype == (tree) 
             ((void *)0) 
                       && (((decl)->decl.lang_specific)->decl_flags.language) != lang_c)
   ((decl)->decl.assembler_name) = current_namespace_id (declarator);

 if (staticp == 1)
   {
     int illegal_static = 0;



     if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
       {
  cp_pedwarn ("cannot declare member function `%D' to have static linkage", decl);
  illegal_static = 1;
       }
     else if (current_function_decl)
       {

  error ("cannot declare static function inside another function");
  illegal_static = 1;
       }

     if (illegal_static)
       {
  staticp = 0;
  do { (specbits).idata[(RID_STATIC)/32] &= ~((unsigned long)1 << (int) ((RID_STATIC)%32)); } while (0);
       }
   }
      }
    else
      {


 if (decl_context == CATCHPARM)
   {
     if (ctype)
       {
  ctype = (tree) 
         ((void *)0)
                  ;
  error ("cannot use `::' in parameter declaration");
       }





     if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
       {

  type = build_pointer_type
    (cp_build_type_variant (((type)->common.type), constp, volatilep));
  volatilep = constp = 0;
       }
     else if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
       type = build_pointer_type (type);
     else if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
       type = build_pointer_type (type);
   }


 decl = grokvardecl (type, declarator, specbits, initialized, constp);
 bad_specifiers (decl, "variable", virtualp, quals != (tree) 
                                                     ((void *)0)
                                                              ,
   inlinep, friendp, raises != (tree) 
                              ((void *)0)
                                       );

 if (ctype)
   {
     ((decl)->decl.context) = ctype;
     if (staticp == 1)
       {
         cp_pedwarn ("static member `%D' re-declared as static", decl);
         staticp = 0;
  do { (specbits).idata[(RID_STATIC)/32] &= ~((unsigned long)1 << (int) ((RID_STATIC)%32)); } while (0);
       }
     if ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32]) && ((decl)->common.static_flag))
       {
  cp_error ("static member `%D' declared `register'", decl);
  do { (specbits).idata[(RID_REGISTER)/32] &= ~((unsigned long)1 << (int) ((RID_REGISTER)%32)); } while (0);
       }
     if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32]) && pedantic)
       {
         cp_pedwarn ("cannot explicitly declare member `%#D' to have extern linkage",
       decl);
  do { (specbits).idata[(RID_EXTERN)/32] &= ~((unsigned long)1 << (int) ((RID_EXTERN)%32)); } while (0);
       }
   }
      }

    if ((((unsigned long)1 << (int) ((RID_MUTABLE)%32)) & (specbits).idata[(RID_MUTABLE)/32]))
      {
 error ("`%s' cannot be declared mutable", name);
      }




    if ((((unsigned long)1 << (int) ((RID_REGISTER)%32)) & (specbits).idata[(RID_REGISTER)/32]))
      ((decl)->decl.regdecl_flag) = 1;

    if ((((unsigned long)1 << (int) ((RID_EXTERN)%32)) & (specbits).idata[(RID_EXTERN)/32]))
      (((decl)->decl.lang_flag_2)) = 1;

    if ((((unsigned long)1 << (int) ((RID_STATIC)%32)) & (specbits).idata[(RID_STATIC)/32]))
      (((decl)->decl.lang_flag_6)) = 1;



    if (constp)
      ((decl)->common.readonly_flag) = ((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE;
    if (volatilep)
      {
 ((decl)->common.side_effects_flag) = 1;
 ((decl)->common.volatile_flag) = 1;
      }

    return decl;
  }
}





int
parmlist_is_exprlist(tree exprs) asm("_parmlist_is_exprlist");
int
parmlist_is_exprlist(tree exprs)
{
  if (exprs == (tree) 
              ((void *)0) 
                        || ((exprs)->common.unsigned_flag))
    return 0;

  if (toplevel_bindings_p ())
    {


      while (exprs)
 {
   if (((n64_enum_tree_code) (((exprs)->list.value))->common.code) != IDENTIFIER_NODE)
     return 1;
   exprs = ((exprs)->common.chain);
 }
      return 0;
    }
  return 1;
}





static void
require_complete_types_for_parms(tree parms) asm("_require_complete_types_for_parms");
static void
require_complete_types_for_parms(tree parms)
{
  while (parms)
    {
      tree type = ((parms)->common.type);
      if (((type)->type.size) == (tree) 
                             ((void *)0)
                                      )
 {
   if (((parms)->decl.name))
     error ("parameter `%s' has incomplete type",
     ((((parms)->decl.name))->identifier.pointer));
   else
     error ("parameter has incomplete type");
   ((parms)->common.type) = error_mark_node;
 }
      parms = ((parms)->common.chain);
    }
}
static tree
grokparms(tree first_parm, int funcdef_flag) asm("_grokparms");
static tree
grokparms(tree first_parm, int funcdef_flag)
{
  tree result = (tree) 
               ((void *)0)
                        ;
  tree decls = (tree) 
              ((void *)0)
                       ;

  if (first_parm != (tree) 
                   ((void *)0)
      
     && ((n64_enum_tree_code) (((first_parm)->list.value))->common.code) == IDENTIFIER_NODE)
    {
      if (! funcdef_flag)
 pedwarn ("parameter names (without types) in function declaration");
      last_function_parms = first_parm;
      return (tree) 
            ((void *)0)
                     ;
    }
  else if (first_parm != (tree) 
                        ((void *)0)
    
   && ((n64_enum_tree_code) (((first_parm)->list.value))->common.code) != TREE_LIST
    && ((first_parm)->list.value) != void_type_node)
    my_friendly_abort (145);
  else
    {


      register tree parm, chain;
      int any_init = 0, any_error = 0, saw_void = 0;

      if (first_parm != (tree) 
                       ((void *)0)
                                )
 {
   tree last_result = (tree) 
                     ((void *)0)
                              ;
   tree last_decl = (tree) 
                   ((void *)0)
                            ;

   for (parm = first_parm; parm != (tree) 
                                  ((void *)0)
                                           ; parm = chain)
     {
       tree type, list_node = parm;
       register tree decl = ((parm)->list.value);
       tree init = ((parm)->list.purpose);

       chain = ((parm)->common.chain);

       if (decl != void_type_node && ((n64_enum_tree_code) (decl)->common.code) != TREE_LIST)
  {

    if (((n64_enum_tree_code) (decl)->common.code) == STRING_CST)
      error ("invalid string constant `%s'",
      ((decl)->string.pointer));
    else if (((n64_enum_tree_code) (decl)->common.code) == INTEGER_CST)
      error ("invalid integer constant in parameter list, did you forget to give parameter name?");
    continue;
  }

       if (decl != void_type_node)
  {

    decl = grokdeclarator (((decl)->list.value),
      ((decl)->list.purpose),
      PARM, init != (tree) 
                   ((void *)0)
                            ,
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         );
    if (! decl)
      continue;
    type = ((decl)->common.type);
    if (((type)->type.main_variant) == void_type_node)
      decl = void_type_node;
    else if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
      {
        if (((decl)->decl.name))


   error ("parameter `%s' invalidly declared method type",
          ((((decl)->decl.name))->identifier.pointer));
        else
   error ("parameter invalidly declared method type");
        type = build_pointer_type (type);
        ((decl)->common.type) = type;
      }
    else if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
      {
        if (((decl)->decl.name))
   error ("parameter `%s' invalidly declared offset type",
          ((((decl)->decl.name))->identifier.pointer));
        else
   error ("parameter invalidly declared offset type");
        type = build_pointer_type (type);
        ((decl)->common.type) = type;
      }
                  else if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
                           && ((type)->type.lang_specific)
                           && (((type)->type.lang_specific)->abstract_virtuals))
                    {
                      abstract_virtuals_error (decl, type);
                      any_error = 1;
                    }
                  else if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
                           && ((type)->type.lang_specific)
                           && (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
                    {
                      signature_error (decl, type);
                      any_error = 1;
                    }
  }

       if (decl == void_type_node)
  {
    if (result == (tree) 
                 ((void *)0)
                          )
      {
        result = void_list_node;
        last_result = result;
      }
    else
      {
        ((last_result)->common.chain) = void_list_node;
        last_result = void_list_node;
      }
    saw_void = 1;
    if (chain
        && (chain != void_list_node || ((chain)->common.chain)))
      error ("`void' in parameter list must be entire list");
    break;
  }


       ((decl)->decl.initial) = ((decl)->common.type);

       if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
     || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
    && ((type)->type.precision) < ((integer_type_node)->type.precision))
  ((decl)->decl.initial) = integer_type_node;

       if (!any_error)
  {
    if (init)
      {
        any_init++;
        if (((n64_enum_tree_code) (init)->common.code) == SAVE_EXPR)
   (((init)->common.lang_flag_2)) = 1;
        else if (((n64_enum_tree_code) (init)->common.code) == VAR_DECL
          || ((n64_enum_tree_code) (init)->common.code) == PARM_DECL)
   {
     if ((((struct n64_tag_lang_identifier *)(((init)->decl.name)))->local_value))
       {





         cp_error ("local variable `%D' may not be used as a default argument", init);
         any_error = 1;
       }
     else if ((((init)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (init)->common.code))]) == 'd'))
       init = decl_constant_value (init);
   }
        else
   init = require_instantiated_type (type, init, integer_zero_node);
     }
  }
       else
  init = (tree) 
        ((void *)0)
                 ;

       if (decls == (tree) 
                   ((void *)0)
                            )
  {
    decls = decl;
    last_decl = decls;
  }
       else
  {
    ((last_decl)->common.chain) = decl;
    last_decl = decl;
  }
       if (((list_node)->common.permanent_flag))
  {
    ((list_node)->list.purpose) = init;
    ((list_node)->list.value) = type;
    ((list_node)->common.chain) = (tree) 
                            ((void *)0)
                                     ;
  }
       else
  list_node = saveable_tree_cons (init, type, (tree) 
                                             ((void *)0)
                                                      );
       if (result == (tree) 
                    ((void *)0)
                             )
  {
    result = list_node;
    last_result = result;
  }
       else
  {
    ((last_result)->common.chain) = list_node;
    last_result = list_node;
  }
     }
   if (last_result)
     ((last_result)->common.chain) = (tree) 
                               ((void *)0)
                                        ;


   if (last_decl != (tree) 
                   ((void *)0)
                            )
     ((last_decl)->common.chain) = (tree) 
                             ((void *)0)
                                      ;
 }
    }

  last_function_parms = decls;


  if (funcdef_flag > 0)
    require_complete_types_for_parms (last_function_parms);

  return result;
}
int
grok_ctor_properties(tree ctype, tree decl) asm("_grok_ctor_properties");
int
grok_ctor_properties(tree ctype, tree decl)
{
  tree parmtypes = (((((((decl)->common.type))->type.values))->common.chain));
  tree parmtype = parmtypes ? ((parmtypes)->list.value) : void_type_node;





  if (parmtypes
      && ((parmtypes)->list.value) == integer_type_node
      && (((ctype)->common.lang_flag_3)))
    {
      parmtypes = ((parmtypes)->common.chain);
      parmtype = ((parmtypes)->list.value);
    }

  if (((n64_enum_tree_code) (parmtype)->common.code) == REFERENCE_TYPE
      && ((((parmtype)->common.type))->type.main_variant) == ctype)
    {
      if (((parmtypes)->common.chain) == (tree) 
                                   ((void *)0)
   
  || ((parmtypes)->common.chain) == void_list_node
   || ((((parmtypes)->common.chain))->list.purpose))
 {
   (((ctype)->type.lang_specific)->type_flags.has_init_ref) = 1;
   if (((((parmtype)->common.type))->common.readonly_flag))
     (((ctype)->type.lang_specific)->type_flags.has_const_init_ref) = 1;
 }
      else
 (((ctype)->type.lang_specific)->type_flags.gets_init_aggr) = 1;
    }
  else if (((parmtype)->type.main_variant) == ctype)
    {
      if (((parmtypes)->common.chain) != (tree) 
                                   ((void *)0)
   
  && ((parmtypes)->common.chain) == void_list_node)
 {
   cp_error ("invalid constructor; you probably meant `%T (%T&)'",
      ctype, ctype);
   (((struct n64_tag_lang_identifier *)(((decl)->decl.name)))->x == 0 ? ((struct n64_tag_lang_identifier *)(((decl)->decl.name)))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(((decl)->decl.name)))->x->error_locus = (ctype));

   return 0;
 }
      else
 (((ctype)->type.lang_specific)->type_flags.gets_init_aggr) = 1;
    }
  else if (((n64_enum_tree_code) (parmtype)->common.code) == VOID_TYPE
    || ((parmtypes)->list.purpose) != (tree) 
                                  ((void *)0)
                                           )
    (((ctype)->type.lang_specific)->type_flags.has_default_ctor) = 1;

  return 1;
}


static int
ambi_op_p(tree name) asm("_ambi_op_p");
static int
ambi_op_p(tree name)
{
  return (name == ansi_opname [(int) INDIRECT_REF]
   || name == ansi_opname [(int) ADDR_EXPR]
   || name == ansi_opname [(int) NEGATE_EXPR]
   || name == ansi_opname[(int) POSTINCREMENT_EXPR]
   || name == ansi_opname[(int) POSTDECREMENT_EXPR]
   || name == ansi_opname [(int) CONVERT_EXPR]);
}


static int
unary_op_p(tree name) asm("_unary_op_p");
static int
unary_op_p(tree name)
{
  return (name == ansi_opname [(int) TRUTH_NOT_EXPR]
   || name == ansi_opname [(int) BIT_NOT_EXPR]
   || name == ansi_opname [(int) COMPONENT_REF]
   || (((name)->identifier.pointer)[0] == '_' && ((name)->identifier.pointer)[1] == '_' && ((name)->identifier.pointer)[2] == 'o' && ((name)->identifier.pointer)[3] == 'p'));
}


static void
grok_op_properties(tree decl, int virtualp, int friendp) asm("_grok_op_properties");
static void
grok_op_properties(tree decl, int virtualp, int friendp)
{
  tree argtypes = ((((decl)->common.type))->type.values);
  int methodp = (((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE);
  tree name = ((decl)->decl.name);

  if (current_class_type == (tree) 
                           ((void *)0)
                                    )
    friendp = 1;

  if (! friendp)
    {
      if (name == ansi_opname[(int) MODIFY_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.has_assignment) = 1;
      else if (name == ansi_opname[(int) CALL_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.has_call_overloaded) = 1;
      else if (name == ansi_opname[(int) ARRAY_REF])
 (((current_class_type)->type.lang_specific)->type_flags.has_array_ref_overloaded) = 1;
      else if (name == ansi_opname[(int) COMPONENT_REF]
        || name == ansi_opname[(int) MEMBER_REF])
 (((current_class_type)->type.lang_specific)->type_flags.has_arrow_overloaded) = 1;
      else if (name == ansi_opname[(int) NEW_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.gets_new) |= 1;
      else if (name == ansi_opname[(int) DELETE_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.gets_delete) |= 1;
      else if (name == ansi_opname[(int) VEC_NEW_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.gets_new) |= 2;
      else if (name == ansi_opname[(int) VEC_DELETE_EXPR])
 (((current_class_type)->type.lang_specific)->type_flags.gets_delete) |= 2;
    }

  if (name == ansi_opname[(int) NEW_EXPR]
      || name == ansi_opname[(int) VEC_NEW_EXPR])
    {


      if (methodp)
 revert_static_member_fn (&decl, 
                                ((void *)0)
                                    , 
                                      ((void *)0)
                                          );


      if (argtypes == (tree) 
                     ((void *)0)
                              )
 ((decl)->common.type) =
   build_function_type (ptr_type_node,
          hash_tree_chain (integer_type_node,
      void_list_node));
      else
 ((decl)->common.type) = coerce_new_type (((decl)->common.type));
    }
  else if (name == ansi_opname[(int) DELETE_EXPR]
    || name == ansi_opname[(int) VEC_DELETE_EXPR])
    {
      if (methodp)
 revert_static_member_fn (&decl, 
                                ((void *)0)
                                    , 
                                      ((void *)0)
                                          );

      if (argtypes == (tree) 
                     ((void *)0)
                              )
 ((decl)->common.type) =
   build_function_type (void_type_node,
          hash_tree_chain (ptr_type_node,
      void_list_node));
      else
 {
   ((decl)->common.type) = coerce_delete_type (((decl)->common.type));

   if (! friendp && name == ansi_opname[(int) VEC_DELETE_EXPR]
       && (((((((decl)->common.type))->type.values))->common.chain)
    != void_list_node))
     (((current_class_type)->type.lang_specific)->type_flags.vec_delete_takes_size) = 1;
 }
    }
  else
    {



      if (! methodp || (((decl)->decl.lang_specific)->decl_flags.static_function))
 {
   if ((((name)->identifier.pointer)[0] == '_' && ((name)->identifier.pointer)[1] == '_' && ((name)->identifier.pointer)[2] == 'o' && ((name)->identifier.pointer)[3] == 'p')
       || name == ansi_opname[(int) CALL_EXPR]
       || name == ansi_opname[(int) MODIFY_EXPR]
       || name == ansi_opname[(int) COMPONENT_REF]
       || name == ansi_opname[(int) ARRAY_REF])
     cp_error ("`%D' must be a nonstatic member function", decl);
   else
     {
       tree p = argtypes;

       if ((((decl)->decl.lang_specific)->decl_flags.static_function))
  cp_error ("`%D' must be either a non-static member function or a non-member function", decl);

       if (p)
  for (; ((p)->list.value) != void_type_node ; p = ((p)->common.chain))
    {
      tree arg = ((p)->list.value);
      if (((n64_enum_tree_code) (arg)->common.code) == REFERENCE_TYPE)
        arg = ((arg)->common.type);


      if ((((arg)->type.lang_flag_5))
   || ((n64_enum_tree_code) (arg)->common.code) == ENUMERAL_TYPE
   || ((n64_enum_tree_code) (arg)->common.code) == TEMPLATE_TYPE_PARM)
        goto foundaggr;
    }
       cp_error
  ("`%D' must have an argument of class or enumerated type",
   decl);
     foundaggr:
       ;
     }
 }

      if (name == ansi_opname[(int) CALL_EXPR]
   || name == ansi_opname[(int) METHOD_CALL_EXPR])
 return;

      if ((! strncmp (((name)->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.pointer), ((ansi_opname[(int) TYPE_EXPR])->identifier.length))))
 {
   tree t = ((name)->common.type);
   if (((n64_enum_tree_code) (t)->common.code) == VOID_TYPE)
     pedwarn ("void is not a valid type conversion operator");
   else if (! friendp)
     {
       int ref = (((n64_enum_tree_code) (t)->common.code) == REFERENCE_TYPE);
       char *what = 0;
       if (ref)
  t = ((((t)->common.type))->type.main_variant);

       if (t == current_class_type)
  what = "the same type";
       else if ((((t)->type.lang_flag_5))
         && (get_base_distance (t, current_class_type, 0, (tree *)0) != -1))
  what = "a base class";

       if (what)
  warning ("conversion to %s%s will never use a type conversion operator",
    ref ? "a reference to " : "", what);
     }
 }

      if (name == ansi_opname[(int) MODIFY_EXPR])
 {
   tree parmtype;

   if (list_length (argtypes) != 3 && methodp)
     {
       cp_error ("`%D' must take exactly one argument", decl);
       return;
     }
   parmtype = ((((argtypes)->common.chain))->list.value);

   if (copy_assignment_arg_p (parmtype, virtualp)
       && ! friendp)
     {
       (((current_class_type)->type.lang_specific)->type_flags.has_assign_ref) = 1;
       if (((n64_enum_tree_code) (parmtype)->common.code) != REFERENCE_TYPE
    || ((((parmtype)->common.type))->common.readonly_flag))
  (((current_class_type)->type.lang_specific)->type_flags.has_const_assign_ref) = 1;




     }
 }
      else if (name == ansi_opname[(int) COND_EXPR])
 {

   pedwarn ("ANSI C++ prohibits overloading operator ?:");
   if (list_length (argtypes) != 4)
     cp_error ("`%D' must take exactly three arguments", decl);
 }
      else if (ambi_op_p (name))
 {
   if (list_length (argtypes) == 2)
                 ;
   else if (list_length (argtypes) == 3)
     {
       if ((name == ansi_opname[(int) POSTINCREMENT_EXPR]
     || name == ansi_opname[(int) POSTDECREMENT_EXPR])
    && ((((argtypes)->common.chain))->list.value) != integer_type_node)
  {
    if (methodp)
      cp_error ("postfix `%D' must take `int' as its argument",
         decl);
    else
      cp_error
        ("postfix `%D' must take `int' as its second argument",
         decl);
  }
     }
   else
     {
       if (methodp)
  cp_error ("`%D' must take either zero or one argument", decl);
       else
  cp_error ("`%D' must take either one or two arguments", decl);
     }
 }
      else if (unary_op_p (name))
 {
   if (list_length (argtypes) != 2)
     {
       if (methodp)
  cp_error ("`%D' must take `void'", decl);
       else
  cp_error ("`%D' must take exactly one argument", decl);
     }
 }
      else
 {
   if (list_length (argtypes) != 3)
     {
       if (methodp)
  cp_error ("`%D' must take exactly one argument", decl);
       else
  cp_error ("`%D' must take exactly two arguments", decl);
     }
 }


      if (argtypes)
 for (; argtypes != void_list_node ; argtypes = ((argtypes)->common.chain))
   if (((argtypes)->list.purpose))
     {
       ((argtypes)->list.purpose) = (tree) 
                                ((void *)0)
                                         ;
       if (name == ansi_opname[(int) POSTINCREMENT_EXPR]
    || name == ansi_opname[(int) POSTDECREMENT_EXPR])
  {
    if (pedantic)
      cp_pedwarn ("`%D' cannot have default arguments", decl);
  }
       else
  cp_error ("`%D' cannot have default arguments", decl);
     }
    }
}
tree
xref_tag(tree code_type_node, tree name, tree binfo, int globalize) asm("_xref_tag");
tree
xref_tag(tree code_type_node, tree name, tree binfo, int globalize)
{
  n64_enum_tag_types tag_code;
  n64_enum_tree_code code;
  int temp = 0;
  int i;
  register tree ref, t;
  struct n64_tag_binding_level *b = (class_binding_level ? class_binding_level : current_binding_level);

  tag_code = (n64_enum_tag_types) ((code_type_node)->int_cst.int_cst_low);
  switch (tag_code)
    {
    case record_type:
    case class_type:
    case signature_type:
      code = RECORD_TYPE;
      break;
    case union_type:
      code = UNION_TYPE;
      break;
    case enum_type:
      code = ENUMERAL_TYPE;
      break;
    default:
      my_friendly_abort (18);
    }



  t = (((name)->common.type));
  if (t && ((n64_enum_tree_code) (t)->common.code) != code)
    t = (tree) 
       ((void *)0)
                ;

  if (! globalize)
    {


      if (t && ((t)->type.context) && (((name)->common.lang_flag_0)))
 ref = t;
      else
       ref = lookup_tag (code, name, b, 1);
    }
  else
    {
      if (t)
 ref = t;
      else
        ref = lookup_tag (code, name, b, 0);

      if (! ref)
 {

   ref = lookup_name (name, 1);
   if (ref && ((n64_enum_tree_code) (ref)->common.code) == TYPE_DECL
       && ((n64_enum_tree_code) (((ref)->common.type))->common.code) == code)
     ref = ((ref)->common.type);
   else
     ref = (tree) 
          ((void *)0)
                   ;
 }
    }

  push_obstacks_nochange ();

  if (! ref)
    {
      temp = allocation_temporary_p ();
      if (temp)
 end_temporary_allocation ();

      if (code == ENUMERAL_TYPE)
 {
   ref = make_node (ENUMERAL_TYPE);



   ((ref)->type.mode) = ((unsigned_type_node)->type.mode);
   ((ref)->type.align) = ((unsigned_type_node)->type.align);
   ((ref)->common.unsigned_flag) = 1;
   ((ref)->type.precision) = ((unsigned_type_node)->type.precision);
   ((ref)->type.minval) = ((unsigned_type_node)->type.minval);
   ((ref)->type.maxval) = ((unsigned_type_node)->type.maxval);






   pushtag (name, ref, globalize);
   if (flag_cadillac)
     cadillac_start_enum (ref);
 }
      else
 {
   struct n64_tag_binding_level *old_b = class_binding_level;

   ref = make_lang_type (code);

   if (tag_code == signature_type)
     {
       (((ref)->type.lang_specific)->type_flags.is_signature=1);


       (((ref)->type.lang_specific)->type_flags.interface_only) = 0;
       (((ref)->type.lang_specific)->type_flags.interface_unknown = 0);

       (((ref)->type.lang_specific)->type_flags.vtable_needs_writing) = 0;
     }





   pushtag (name, ref, globalize);
   class_binding_level = old_b;

   if (flag_cadillac)
     cadillac_start_struct (ref);
 }
    }
  else
    {


      if (b == global_binding_level && !class_binding_level
   && (((struct n64_tag_lang_identifier *)(name))->global_value) == (tree) 
                                       ((void *)0)
                                                )
 (((struct n64_tag_lang_identifier *)(name))->global_value) = ((ref)->type.name);
    }

  if (binfo)
    xref_basetypes (code_type_node, name, ref, binfo);

 just_return:



  if (((ref)->type.size) == (tree) 
                        ((void *)0)
      
     && ref != current_class_type

      && (((n64_enum_tree_code) (ref)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (ref)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (ref)->common.code) == UNINSTANTIATED_P_TYPE))
    {
      if (tag_code == class_type)
 (((ref)->type.lang_specific)->type_flags.declared_class) = 1;
      else if (tag_code == record_type || tag_code == signature_type)
 (((ref)->type.lang_specific)->type_flags.declared_class) = 0;
    }

  pop_obstacks ();

  return ref;
}

void
xref_basetypes(tree code_type_node, tree name, tree ref, tree binfo) asm("_xref_basetypes");
void
xref_basetypes(tree code_type_node, tree name, tree ref, tree binfo)
{


  tree binfos;
  int i, len;
  n64_enum_tag_types tag_code = (n64_enum_tag_types) ((code_type_node)->int_cst.int_cst_low);

  if (tag_code == union_type)
    {
      cp_error ("derived union `%T' invalid", ref);
      return;
    }

  len = list_length (binfo);
  push_obstacks (((ref)->type.obstack), ((ref)->type.obstack));

  ((((ref)->type.lang_specific)->type_flags.marked) = 1);
  (((((ref)->type.binfo)))->vec.a[4]) = binfos = make_tree_vec (len);

  for (i = 0; binfo; binfo = ((binfo)->common.chain))
    {

      int via_public
 = (((binfo)->list.purpose) == (tree)access_public
    || ((binfo)->list.purpose) == (tree)access_public_virtual
    || (tag_code != class_type
        && (((binfo)->list.purpose) == (tree)access_default
     || ((binfo)->list.purpose) == (tree)access_default_virtual)));
      int via_protected = ((binfo)->list.purpose) == (tree)access_protected;
      int via_virtual
 = (((binfo)->list.purpose) == (tree)access_private_virtual
    || ((binfo)->list.purpose) == (tree)access_public_virtual
    || ((binfo)->list.purpose) == (tree)access_default_virtual);
      tree basetype = ((((binfo)->list.value))->common.type);
      tree base_binfo;

      GNU_xref_hier (((name)->identifier.pointer),
       ((((binfo)->list.value))->identifier.pointer),
       via_public, via_virtual, 0);

      if (basetype && ((n64_enum_tree_code) (basetype)->common.code) == TYPE_DECL)
 basetype = ((basetype)->common.type);
      if (!basetype || ((n64_enum_tree_code) (basetype)->common.code) != RECORD_TYPE)
 {
   cp_error ("base type `%T' fails to be a struct or class type",
      ((binfo)->list.value));
   continue;
 }


      else if ((((basetype)->type.size) == (tree) 
              ((void *)0) 
              && ((n64_enum_tree_code) (basetype)->common.code) != TEMPLATE_TYPE_PARM))
 {
   cp_error ("base class `%T' has incomplete type", basetype);
   continue;
 }

      else
 {
   if ((((basetype)->type.lang_specific)->type_flags.marked))
     {
       if (basetype == ref)
  cp_error ("recursive type `%T' undefined", basetype);
       else
  cp_error ("duplicate base type `%T' invalid", basetype);
       continue;
     }
   base_binfo = make_binfo (integer_zero_node, basetype,
       (((((basetype)->type.binfo)))->vec.a[2]),
       (((((basetype)->type.binfo)))->vec.a[3]), (tree) 
                                      ((void *)0)
                                               );

   ((binfos)->vec.a[i]) = base_binfo;
   ((base_binfo)->common.public_flag) = via_public;
   ((base_binfo)->common.protected_flag) = via_protected;
   ((base_binfo)->common.static_flag) = via_virtual;
   (((base_binfo))->vec.a[0]) = ((ref)->type.binfo);

   ((((basetype)->type.lang_specific)->type_flags.marked) = 1);
   if (via_virtual || (((basetype)->common.lang_flag_3)))
     {
       (((ref)->common.lang_flag_3)) = 1;
       (((ref)->common.lang_flag_1)) = 1;
     }

   (((ref)->type.lang_specific)->type_flags.has_method_call_overloaded) |= (((basetype)->type.lang_specific)->type_flags.has_method_call_overloaded);
   (((ref)->type.lang_specific)->type_flags.gets_new) |= (((basetype)->type.lang_specific)->type_flags.gets_new);
   (((ref)->type.lang_specific)->type_flags.gets_delete) |= (((basetype)->type.lang_specific)->type_flags.gets_delete);
   (((ref)->type.lang_specific)->type_flags.local_typedecls) |= (((basetype)->type.lang_specific)->type_flags.local_typedecls);
   i += 1;
 }
    }
  if (i)
    ((binfos)->vec.length) = i;
  else
    (((((ref)->type.binfo)))->vec.a[4]) = (tree) 
                                        ((void *)0)
                                                 ;

  if (i > 1)
    (((ref)->type.lang_specific)->type_flags.uses_multiple_inheritance) = 1;
  else if (i == 1)
    (((ref)->type.lang_specific)->type_flags.uses_multiple_inheritance)
      = (((((((binfos)->vec.a[0]))->common.type))->type.lang_specific)->type_flags.uses_multiple_inheritance);
  if ((((ref)->type.lang_specific)->type_flags.uses_multiple_inheritance))
    (((ref)->common.lang_flag_1)) = 1;


  while (--i >= 0)
    ((((((((binfos)->vec.a[i]))->common.type))->type.lang_specific)->type_flags.marked) = 0);
  ((((ref)->type.lang_specific)->type_flags.marked) = 0);

  pop_obstacks ();
}


static tree current_local_enum = (tree) 
                                ((void *)0)
                                         ;







tree
start_enum(tree name) asm("_start_enum");
tree
start_enum(tree name)
{
  register tree enumtype = (tree) 
                          ((void *)0)
                                   ;
  struct n64_tag_binding_level *b = (class_binding_level ? class_binding_level : current_binding_level);





  if (name != (tree) 
             ((void *)0)
                      )
    enumtype = lookup_tag (ENUMERAL_TYPE, name, b, 1);

  if (enumtype != (tree) 
                 ((void *)0) 
                           && ((n64_enum_tree_code) (enumtype)->common.code) == ENUMERAL_TYPE)
    cp_error ("multiple definition of enum `%T'", enumtype);
  else
    {
      enumtype = make_node (ENUMERAL_TYPE);
      pushtag (name, enumtype, 0);
    }

  if (current_class_type)
    ((b->tags)->common.addressable_flag) = 1;
  current_local_enum = (tree) 
                      ((void *)0)
                               ;
  enum_next_value = copy_node (integer_zero_node);
  enum_overflow = 0;

  GNU_xref_decl (current_function_decl, enumtype);
  return enumtype;
}






tree
finish_enum(register tree enumtype, register tree values) asm("_finish_enum");
tree
finish_enum(register tree enumtype, register tree values)
{
  register tree minnode, maxnode;


  if (values)
    {
      register tree pair;
      register tree value = ((((values)->list.value))->decl.initial);


      ((((values)->list.value))->common.type) = enumtype;
      ((value)->common.type) = enumtype;
      ((values)->list.value) = value;
      minnode = maxnode = value;

      for (pair = ((values)->common.chain); pair; pair = ((pair)->common.chain))
 {
   value = ((((pair)->list.value))->decl.initial);
   ((((pair)->list.value))->common.type) = enumtype;
   ((value)->common.type) = enumtype;
   ((pair)->list.value) = value;
   if (tree_int_cst_lt (maxnode, value))
     maxnode = value;
   else if (tree_int_cst_lt (value, minnode))
     minnode = value;
 }
    }
  else
    maxnode = minnode = integer_zero_node;

  ((enumtype)->type.values) = values;

  {
    int unsignedp = tree_int_cst_sgn (minnode) >= 0;
    int lowprec = min_precision (minnode, unsignedp);
    int highprec = min_precision (maxnode, unsignedp);
    int precision = ((lowprec) > (highprec) ? (lowprec) : (highprec));

    ((enumtype)->type.size) = (tree) 
                          ((void *)0)
                                   ;



    ((enumtype)->type.precision) = precision;
    if (unsignedp)
      fixup_unsigned_type (enumtype);
    else
      fixup_signed_type (enumtype);

    if (flag_short_enums || precision > ((integer_type_node)->type.precision))

      ((enumtype)->type.precision) = ((type_for_size (precision, 1))->type.precision)
                       ;
    else
      ((enumtype)->type.precision) = ((integer_type_node)->type.precision);

    ((enumtype)->type.size) = 0;
    layout_type (enumtype);
  }

  if (flag_cadillac)
    cadillac_finish_enum (enumtype);

  {
    register tree tem;


    for (tem = ((enumtype)->type.main_variant); tem;
  tem = ((tem)->type.next_variant))
      {
 ((tem)->type.values) = ((enumtype)->type.values);
 ((tem)->type.minval) = ((enumtype)->type.minval);
 ((tem)->type.maxval) = ((enumtype)->type.maxval);
 ((tem)->type.size) = ((enumtype)->type.size);
 ((tem)->type.mode) = ((enumtype)->type.mode);
 ((tem)->type.precision) = ((enumtype)->type.precision);
 ((tem)->type.align) = ((enumtype)->type.align);
 ((tem)->common.unsigned_flag) = ((enumtype)->common.unsigned_flag);
      }
  }







    rest_of_type_compilation (enumtype, global_bindings_p ());

  return enumtype;
}






tree
build_enumerator(tree name, tree value) asm("_build_enumerator");
tree
build_enumerator(tree name, tree value)
{
  tree decl, result;

  int shareable = 1;


  if (value)
    while ((((n64_enum_tree_code) (value)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (value)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR) && (((value)->common.type) == ((((value)->exp.operands[0]))->common.type))) (value) = ((value)->exp.operands[0]);;


  if (value != (tree) 
              ((void *)0)
                       )
    {
      if ((((value)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (value)->common.code))]) == 'd'))
 {
   value = decl_constant_value (value);
   shareable = 0;
 }

      if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST)
 {
   value = default_conversion (value);
   constant_expression_warning (value);
 }
      else
 {
   cp_error ("enumerator value for `%D' not integer constant", name);
   value = (tree) 
          ((void *)0)
                   ;
 }
    }





  if (value == (tree) 
              ((void *)0)
                       )
    {
      value = enum_next_value;
      if (enum_overflow)
 cp_error ("overflow in enumeration values at `%D'", name);
    }


  if (value)
    while ((((n64_enum_tree_code) (value)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (value)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (value)->common.code) == NON_LVALUE_EXPR) && (((value)->common.type) == ((((value)->exp.operands[0]))->common.type))) (value) = ((value)->exp.operands[0]);;


  if (value == integer_zero_node)
    value = build_int_2_wide ((int) (0), (int) (0));
  else if (value == integer_one_node)
    value = build_int_2_wide ((int) (1), (int) (0));
  else if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST
    && (shareable == 0
        || ((n64_enum_tree_code) (((value)->common.type))->common.code) == ENUMERAL_TYPE))
    {
      value = copy_node (value);
      ((value)->common.type) = integer_type_node;
    }



  decl = current_scope ();
  if (decl && decl == current_class_type)
    {


      decl = build_lang_field_decl (CONST_DECL, name, integer_type_node);
      ((decl)->decl.initial) = value;
      ((decl)->common.readonly_flag) = 1;
      pushdecl_class_level (decl);
      ((decl)->common.chain) = current_local_enum;
      current_local_enum = decl;
    }
  else
    {


      decl = build_decl (CONST_DECL, name, integer_type_node);
      ((decl)->decl.initial) = value;

      pushdecl (decl);
      GNU_xref_decl (current_function_decl, decl);
    }


  enum_next_value = build_binary_op_nodefault (PLUS_EXPR, value,
            integer_one_node, PLUS_EXPR);
  enum_overflow = tree_int_cst_lt (enum_next_value, value);

  if (enum_next_value == integer_one_node)
    enum_next_value = copy_node (enum_next_value);

  result = saveable_tree_cons (name, decl, (tree) 
                                          ((void *)0)
                                                   );
  return result;
}

tree
grok_enum_decls(tree type, tree decl) asm("_grok_enum_decls");
tree
grok_enum_decls(tree type, tree decl)
{
  tree d = current_local_enum;

  if (d == (tree) 
          ((void *)0)
                   )
    return decl;

  while (1)
    {
      ((d)->common.type) = type;
      if (((d)->common.chain) == (tree) 
                           ((void *)0)
                                    )
 {
   ((d)->common.chain) = decl;
   break;
 }
      d = ((d)->common.chain);
    }

  decl = current_local_enum;
  current_local_enum = (tree) 
                      ((void *)0)
                               ;

  return decl;
}
int
start_function(tree declspecs, tree declarator, tree raises, tree attrs, int pre_parsed_p) asm("_start_function");
int
start_function(tree declspecs, tree declarator, tree raises, tree attrs, int pre_parsed_p)
{
  tree decl1, olddecl;
  tree ctype = (tree) 
              ((void *)0)
                       ;
  tree fntype;
  tree restype;
  extern int have_extern_spec;
  extern int used_extern_spec;
  int doing_friend = 0;


  my_friendly_assert (((void_list_node)->list.value) == void_type_node, 160);
  my_friendly_assert (((void_list_node)->common.chain) == (tree) 
                                                    ((void *)0)
                                                             , 161);


  current_function_returns_value = 0;
  current_function_returns_null = 0;
  warn_about_return_type = 0;
  named_labels = 0;
  shadowed_labels = 0;
  current_function_assigns_this = 0;
  current_function_just_assigned_this = 0;
  current_function_parms_stored = 0;
  original_result_rtx = (rtx) 0;
  current_function_obstack_index = 0;
  current_function_obstack_usage = 0;
  base_init_expr = (tree) 
                  ((void *)0)
                           ;
  protect_list = (tree) 
                ((void *)0)
                         ;
  current_base_init_list = (tree) 
                          ((void *)0)
                                   ;
  current_member_init_list = (tree) 
                            ((void *)0)
                                     ;
  ctor_label = dtor_label = (tree) 
                           ((void *)0)
                                    ;

  clear_temp_name ();


  if (have_extern_spec && !used_extern_spec)
    {
      declspecs = decl_tree_cons ((tree) 
                                 ((void *)0)
                                          , get_identifier ("extern"), declspecs);
      used_extern_spec = 1;
    }

  if (pre_parsed_p)
    {
      decl1 = declarator;

      if (! ((decl1)->decl.arguments)
   && !(((decl1)->decl.lang_specific)->decl_flags.static_function)
   && ((decl1)->decl.context)
   && ((((((decl1)->decl.context))->type.name))->decl.name)
   && (((struct n64_tag_lang_identifier *)(((((((decl1)->decl.context))->type.name))->decl.name)))->class_template_info))
 {
   cp_error ("redeclaration of `%#D'", decl1);
   if ((((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->class_value))
     cp_error_at ("previous declaration here", (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->class_value));
   else if ((((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->global_value))
     cp_error_at ("previous declaration here", (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->global_value));
 }





      if (((decl1)->decl.initial) != (tree) 
                                 ((void *)0)
                                          )
 {
   cp_error_at ("specialization of `%#D' not supported", decl1);
   cp_error ("when defined in the class template body", decl1);
 }

      last_function_parms = ((decl1)->decl.arguments);
      last_function_parm_tags = (tree) 
                               ((void *)0)
                                        ;
      fntype = ((decl1)->common.type);
      if (((n64_enum_tree_code) (fntype)->common.code) == METHOD_TYPE)
 ctype = ((fntype)->type.maxval);




      if (!ctype && (((decl1)->decl.lang_specific)->decl_flags.friend_attr))
 {
   ctype = (((decl1)->decl.lang_specific)->decl_flags.context);




   if (ctype && ((n64_enum_tree_code) (ctype)->common.code) != RECORD_TYPE)
     ctype = (tree) 
            ((void *)0)
                     ;
   else
     doing_friend = 1;
 }

      raises = ((fntype)->type.noncopied_parts);


      require_complete_types_for_parms (last_function_parms);



      {
 tree t = last_function_parms;
 for (; t; t = ((t)->common.chain))
   layout_decl (t, 0);
      }
    }
  else
    {
      decl1 = grokdeclarator (declarator, declspecs, FUNCDEF, 1, raises,
         (tree) 
        ((void *)0)
                 );


      if (decl1 == (tree) 
                  ((void *)0) 
                            || ((n64_enum_tree_code) (decl1)->common.code) != FUNCTION_DECL) return 0;

      fntype = ((decl1)->common.type);

      restype = ((fntype)->common.type);
      if ((((restype)->type.lang_flag_5)) && ! (((n64_enum_tree_code) (restype)->common.code) == RECORD_TYPE && ((restype)->type.lang_specific)->type_flags.ptrmemfunc_flag)
   && ! (((restype)->type.lang_specific)->type_flags.got_semicolon))
 {
   cp_error ("semicolon missing after declaration of `%#T'", restype);
   shadow_tag (build_tree_list ((tree) 
                               ((void *)0)
                                        , restype));
   (((restype)->type.lang_specific)->type_flags.got_semicolon) = 1;
   if (((n64_enum_tree_code) (fntype)->common.code) == FUNCTION_TYPE)
     fntype = build_function_type (integer_type_node,
       ((fntype)->type.values));
   else
     fntype = build_cplus_method_type (build_type_variant (((fntype)->type.maxval), ((decl1)->common.readonly_flag), ((decl1)->common.side_effects_flag)),
           integer_type_node,
           ((fntype)->type.values));
   ((decl1)->common.type) = fntype;
 }

      if (((n64_enum_tree_code) (fntype)->common.code) == METHOD_TYPE)
 ctype = ((fntype)->type.maxval);
      else if (((((decl1)->decl.name))->identifier.length) == 4
        && ! strcmp (((((decl1)->decl.name))->identifier.pointer), "main")
        && ((decl1)->decl.context) == (tree) 
                                  ((void *)0)
                                           )
 {

   if (((((decl1)->common.type))->common.type) != integer_type_node)
     {
       if (pedantic || warn_return_type)
  pedwarn ("return type for `main' changed to integer type");
       ((decl1)->common.type) = fntype = default_function_type;
     }
   warn_about_return_type = 0;
 }
    }



  if (! warn_implicit
      && (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->x ? ((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->x->implicit_decl : 0) != (tree) 
                                                        ((void *)0)
                                                                 )
    cp_warning_at ("`%D' implicitly declared before its definition", (((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->x ? ((struct n64_tag_lang_identifier *)(((decl1)->decl.name)))->x->implicit_decl : 0));

  current_function_decl = decl1;

  if (flag_cadillac)
    cadillac_start_function (decl1);
  else
    announce_function (decl1);

  if (((((fntype)->common.type))->type.size) == (tree) 
                                       ((void *)0)
                                                )
    {
      if ((((((fntype)->common.type))->type.lang_flag_5)))
 error_with_aggr_type (((fntype)->common.type),
         "return-type `%s' is an incomplete type");
      else
 error ("return-type is an incomplete type");



      if (ctype)
 ((decl1)->common.type)
   = build_cplus_method_type (build_type_variant (ctype,
        ((decl1)->common.readonly_flag),
        ((decl1)->common.side_effects_flag)),
         void_type_node,
         (((((((decl1)->common.type))->type.values))->common.chain)));
      else
 ((decl1)->common.type)
   = build_function_type (void_type_node,
     ((((decl1)->common.type))->type.values));
      ((decl1)->decl.result)
 = build_decl (RESULT_DECL, 0, ((((fntype)->common.type))->type.main_variant));
      ((((decl1)->decl.result))->common.readonly_flag) = ((((fntype)->common.type))->common.readonly_flag);
      ((((decl1)->decl.result))->common.volatile_flag) = ((((fntype)->common.type))->common.volatile_flag);
    }

  if (((((fntype)->common.type))->type.lang_specific)
      && (((((fntype)->common.type))->type.lang_specific)->abstract_virtuals))
    abstract_virtuals_error (decl1, ((fntype)->common.type));

  if (warn_about_return_type)
    warning ("return-type defaults to `int'");



  ((decl1)->decl.initial) = error_mark_node;


  olddecl = (tree) 
           ((void *)0)
                    ;



  ((decl1)->common.static_flag) = 1;





  if (pre_parsed_p == 0)
    {
      current_function_decl = decl1 = pushdecl (decl1);
      (((decl1)->decl.lang_specific)->main_decl_variant) = decl1;
      fntype = ((decl1)->common.type);
    }
  else
    current_function_decl = decl1;

  if (((decl1)->decl.lang_flag_5))
    {
      if ((((decl1)->decl.lang_specific)->decl_flags.not_really_extern))
 ((decl1)->decl.external_flag) = 0;
    }



  else if (interface_unknown == 0)
    {
      if ((((decl1)->decl.lang_specific)->decl_flags.declared_inline) || ((((decl1)->decl.lang_specific)->decl_flags.use_template) & 1))
 ((decl1)->decl.external_flag)
   = (interface_only
      || ((((decl1)->decl.lang_specific)->decl_flags.declared_inline) && ! flag_implement_inlines));
      else
 ((decl1)->decl.external_flag) = 0;
      (((decl1)->decl.lang_specific)->decl_flags.not_really_extern) = 0;
      ((decl1)->decl.lang_flag_5) = 1;
    }
  else
    {


      ((decl1)->decl.external_flag) = 0;

      if ((((decl1)->decl.lang_specific)->decl_flags.declared_inline) && ! ((decl1)->decl.lang_flag_5))
 ((decl1)->decl.defer_output) = 1;
      else
 {
   ((decl1)->decl.lang_flag_5) = 1;
   if ((((decl1)->decl.lang_specific)->decl_flags.c_static))
     ((decl1)->common.public_flag) = 0;
 }
    }

  if (ctype != (tree) 
              ((void *)0) 
                        && (((decl1)->decl.lang_specific)->decl_flags.static_function))
    {
      if (((n64_enum_tree_code) (fntype)->common.code) == METHOD_TYPE)
 ((decl1)->common.type) = fntype
   = build_function_type (((fntype)->common.type),
     ((((fntype)->type.values))->common.chain));
      last_function_parms = ((last_function_parms)->common.chain);
      ((decl1)->decl.arguments) = last_function_parms;
      ctype = (tree) 
             ((void *)0)
                      ;
    }
  restype = ((fntype)->common.type);

  if (ctype)
    {
      push_nested_class (ctype, 1);



      if (! doing_friend)
 {





   tree t = last_function_parms;

   my_friendly_assert (t != (tree) 
                           ((void *)0)
         
        && ((n64_enum_tree_code) (t)->common.code) == PARM_DECL, 162);

   if (((n64_enum_tree_code) (((t)->common.type))->common.code) == POINTER_TYPE)
     {
       int i = suspend_momentary ();


       current_class_decl = (tree) 
                           ((void *)0)
                                    ;
       C_C_D = build_indirect_ref (t, ((void *)0));
       current_class_decl = t;
       resume_momentary (i);
     }
   else

     C_C_D = current_class_decl = t;

 }
    }
  else
    {
      if ((((decl1)->decl.lang_specific)->decl_flags.static_function))
 push_nested_class (((decl1)->decl.context), 2);
      else
 push_memoized_context (0, 1);
      current_class_decl = C_C_D = (tree) 
                                  ((void *)0)
                                           ;
    }

  pushlevel (0);
  current_binding_level->parm_flag = 1;



  current_function_parms = last_function_parms;
  current_function_parm_tags = last_function_parm_tags;

  GNU_xref_function (decl1, current_function_parms);

  if (attrs)
    cplus_decl_attributes (decl1, (tree) 
                                 ((void *)0)
                                          , attrs);
  make_function_rtl (decl1);



  temporary_allocation ();


  if ((((n64_enum_tree_code) ((restype))->common.code) == INTEGER_TYPE && (((restype)->type.main_variant) == char_type_node || ((restype)->type.main_variant) == signed_char_type_node || ((restype)->type.main_variant) == unsigned_char_type_node || ((restype)->type.main_variant) == short_integer_type_node || ((restype)->type.main_variant) == short_unsigned_type_node)))
    {


      if (((restype)->common.unsigned_flag)
   && (flag_traditional
       || ((restype)->type.precision)
     == ((integer_type_node)->type.precision)))
 restype = unsigned_type_node;
      else
 restype = integer_type_node;
    }
  if (((decl1)->decl.result) == (tree) 
                            ((void *)0)
                                     )
    {
      ((decl1)->decl.result)
 = build_decl (RESULT_DECL, 0, ((restype)->type.main_variant));
      ((((decl1)->decl.result))->common.readonly_flag) = ((restype)->common.readonly_flag);
      ((((decl1)->decl.result))->common.volatile_flag) = ((restype)->common.volatile_flag);
    }

  if ((((((decl1)->decl.assembler_name))->identifier.pointer)[1] == '.' && ((((decl1)->decl.assembler_name))->identifier.pointer)[2] == '_')
      && (((decl1)->decl.lang_specific)->decl_flags.language) == lang_cplusplus)
    {
      dtor_label = build_decl (LABEL_DECL, (tree) 
                                          ((void *)0)
                                                   , (tree) 
                                                     ((void *)0)
                                                              );
      ctor_label = (tree) 
                  ((void *)0)
                           ;
    }
  else
    {
      dtor_label = (tree) 
                  ((void *)0)
                           ;
      if ((((decl1)->decl.lang_specific)->decl_flags.constructor_attr))
 ctor_label = build_decl (LABEL_DECL, (tree) 
                                     ((void *)0)
                                              , (tree) 
                                                ((void *)0)
                                                         );
    }



  if (((((decl1)->decl.assembler_name))->common.addressable_flag))
    ((decl1)->common.addressable_flag) = 1;

  return 1;
}

void
expand_start_early_try_stmts(void) asm("_expand_start_early_try_stmts");
void
expand_start_early_try_stmts(void)
{
  rtx insns;
  start_sequence ();
  expand_start_try_stmts ();
  insns = get_insns ();
  end_sequence ();
  store_in_parms (insns);
}

void
store_in_parms(rtx insns) asm("_store_in_parms");
void
store_in_parms(rtx insns)
{
  rtx last_parm_insn;

  last_parm_insn = get_first_nonparm_insn ();
  if (last_parm_insn == (rtx) 0)
    emit_insns (insns);
  else
    emit_insns_before (insns, previous_insn (last_parm_insn));
}







void
store_parm_decls(void) asm("_store_parm_decls");
void
store_parm_decls(void)
{
  register tree fndecl = current_function_decl;
  register tree parm;
  int parms_have_cleanups = 0;


  tree specparms = current_function_parms;


  tree parmtags = current_function_parm_tags;




  tree nonparms = (tree) 
                 ((void *)0)
                          ;

  if (toplevel_bindings_p ())
    fatal ("parse errors have confused me too much");


  init_function_start (fndecl, input_filename, lineno);


  declare_function_name ();


  expand_start_bindings (0);

  if (specparms != (tree) 
                  ((void *)0)
                           )
    {





      register tree next;



      storedecls ((tree) 
                 ((void *)0)
                          );
      for (parm = nreverse (specparms); parm; parm = next)
 {
   next = ((parm)->common.chain);
   if (((n64_enum_tree_code) (parm)->common.code) == PARM_DECL)
     {
       tree cleanup = maybe_build_cleanup (parm);
       if (((parm)->decl.name) == (tree) 
                              ((void *)0)
                                       )
  {




    pushdecl (parm);

  }
       else if (((((parm)->common.type))->type.main_variant) == void_type_node)
  cp_error ("parameter `%D' declared void", parm);
       else
  {
    if (((n64_enum_tree_code) (((parm)->common.type))->common.code) == REFERENCE_TYPE
        && ((((((parm)->common.type))->common.type))->type.size))
      ((parm)->decl.arguments=convert_from_reference (parm));

    pushdecl (parm);
  }
       if (cleanup)
  {
    expand_decl (parm);
    if (! cp_expand_decl_cleanup (parm, cleanup))
      cp_error ("parser lost in parsing declaration of `%D'",
         parm);
    parms_have_cleanups = 1;
  }
     }
   else
     {


       ((parm)->common.chain) = (tree) 
                          ((void *)0)
                                   ;
       nonparms = chainon (nonparms, parm);
     }
 }




      ((fndecl)->decl.arguments) = getdecls ();

      storetags (chainon (parmtags, gettags ()));
    }
  else
    ((fndecl)->decl.arguments) = (tree) 
                             ((void *)0)
                                      ;






  storedecls (chainon (nonparms, ((fndecl)->decl.arguments)));


  ((fndecl)->decl.saved_insns.r) = (rtx) 0;
  expand_function_start (fndecl, parms_have_cleanups);




  if (parms_have_cleanups)
    {
      pushlevel (0);
      expand_start_bindings (0);
    }

  current_function_parms_stored = 1;

  if (flag_gc)
    {
      maybe_gc_cleanup = build_tree_list ((tree) 
                                         ((void *)0)
                                                  , error_mark_node);
      if (! cp_expand_decl_cleanup ((tree) 
                                   ((void *)0)
                                            , maybe_gc_cleanup))
 cp_error ("parser lost in parsing declaration of `%D'", fndecl);
    }



  if (((fndecl)->decl.name)
      && ((((fndecl)->decl.name))->identifier.length) == 4
      && strcmp (((((fndecl)->decl.name))->identifier.pointer), "main") == 0
      && ((fndecl)->decl.context) == (tree) 
                                 ((void *)0)
                                          )
    {
      expand_main_function ();

      if (flag_gc)
 expand_expr (build_function_call (lookup_name (get_identifier ("__gc_main"), 0), (tree) 
                                                                                 ((void *)0)
                                                                                          ),
       0, VOIDmode, 0);





    }


  if (flag_handle_exceptions)
    {
      rtx insns;
      start_sequence ();


      start_eh_unwinder ();


      if (((((current_function_decl)->common.type))->type.noncopied_parts))
 expand_start_eh_spec ();

      insns = get_insns ();
      end_sequence ();

      if (insns)
 store_in_parms (insns);
    }
}



void
store_return_init(tree return_id, tree init) asm("_store_return_init");
void
store_return_init(tree return_id, tree init)
{
  tree decl = ((current_function_decl)->decl.result);

  if (pedantic)



    pedwarn ("ANSI C++ does not permit named return values");

  if (return_id != (tree) 
                  ((void *)0)
                           )
    {
      if (((decl)->decl.name) == (tree) 
                             ((void *)0)
                                      )
 {
   ((decl)->decl.name) = return_id;
   ((decl)->decl.assembler_name) = return_id;
 }
      else
 error ("return identifier `%s' already in place",
        ((((decl)->decl.name))->identifier.pointer));
    }


  if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
    {
      error ("can't redefine default return value for constructors");
      return;
    }


  if (((decl)->decl.name) != (tree) 
                         ((void *)0)
                                  )
    {


      if (((decl)->decl.regdecl_flag))
 {
   original_result_rtx = ((decl)->decl.rtl);
   ((decl)->decl.rtl) = gen_reg_rtx (((decl)->decl.mode));
 }


      ((decl)->decl.initial) = init;
      pushdecl (decl);
      cp_finish_decl (decl, init, (tree) 
                                 ((void *)0)
                                          , 0, (128));
    }
}
void
finish_function(int lineno, int call_poplevel, int nested) asm("_finish_function");
void
finish_function(int lineno, int call_poplevel, int nested)
{
  register tree fndecl = current_function_decl;
  tree fntype, ctype = (tree) 
                      ((void *)0)
                               ;
  rtx last_parm_insn, insns;

  tree no_return_label = (tree) 
                        ((void *)0)
                                 ;
  tree decls = (tree) 
              ((void *)0)
                       ;



  if (fndecl == (tree) 
               ((void *)0)
                        )
    return;

  fntype = ((fndecl)->common.type);






  if (! current_function_parms_stored)
    {
      call_poplevel = 0;
      store_parm_decls ();
    }

  if (write_symbols != NO_DEBUG )
    {
      tree ttype = target_type (fntype);
      tree parmdecl;

      if ((((ttype)->type.lang_flag_5)))

 note_debug_info_needed (ttype);

      for (parmdecl = ((fndecl)->decl.arguments); parmdecl; parmdecl = ((parmdecl)->common.chain))
 {
   ttype = target_type (((parmdecl)->common.type));
   if ((((ttype)->type.lang_flag_5)))

     note_debug_info_needed (ttype);
 }
    }


  do_pending_stack_adjust ();

  if (dtor_label)
    {
      tree binfo = ((current_class_type)->type.binfo);
      tree cond = integer_one_node;
      tree exprstmt, vfields;
      tree in_charge_node = lookup_name (in_charge_identifier, 0);
      tree virtual_size;
      int ok_to_optimize_dtor = 0;

      if (current_function_assigns_this)
 cond = build (NE_EXPR, boolean_type_node,
        current_class_decl, integer_zero_node);
      else
 {
   int n_baseclasses = (((((current_class_type)->type.binfo))->vec.a[4]) ? ((((((current_class_type)->type.binfo))->vec.a[4]))->vec.length) : 0);



   if ((flag_this_is_variable & 1) == 0)
     ok_to_optimize_dtor = 1;
   else if (get_last_insn () == get_first_nonparm_insn ())
     ok_to_optimize_dtor
       = (n_baseclasses == 0
   || (n_baseclasses == 1
       && ((((((((((((current_class_type)->type.binfo)))->vec.a[4]))->vec.a[(0)]))->common.type))->type.lang_flag_2))));
 }



      pushlevel (0);
      expand_start_bindings (0);

      if (current_function_assigns_this)
 {
   current_function_assigns_this = 0;
   current_function_just_assigned_this = 0;
 }
      (((current_class_type)->type.lang_flag_2)) = 0;


      if ((((current_class_type)->common.lang_flag_3))
   || ((((current_class_type)->type.lang_specific)->type_flags.gets_delete) & 1))
 exprstmt = build_delete (current_class_type, C_C_D, integer_zero_node,
     (8)|(512), 0);
      else
 exprstmt = build_delete (current_class_type, C_C_D, in_charge_node,
     (8)|(512), 0);







      if (exprstmt != error_mark_node
   && (((n64_enum_tree_code) (exprstmt)->common.code) != NOP_EXPR
       || ((exprstmt)->exp.operands[0]) != integer_zero_node
       || (((current_class_type)->common.lang_flag_3))))
 {
   expand_label (dtor_label);
   if (cond != integer_one_node)
     expand_start_cond (cond, 0);
   if (exprstmt != void_zero_node)


     expand_expr_stmt (exprstmt);


   if ((((current_class_type)->common.lang_flag_3)))
     {
       tree vbases = nreverse (copy_list ((((current_class_type)->type.lang_specific)->vbases)));
       expand_start_cond (build (BIT_AND_EXPR, integer_type_node,
     in_charge_node, integer_two_node), 0);
       while (vbases)
  {
    if ((((((vbases)->common.type))->type.lang_flag_4)))
      {
        tree ptr = convert_pointer_to_vbase (((vbases)->common.type), current_class_decl);
        expand_expr_stmt (build_delete (build_pointer_type (((vbases)->common.type)),
            ptr, integer_zero_node,
            (8)|(512)|(32), 0));
      }
    vbases = ((vbases)->common.chain);
  }
       expand_end_cond ();
     }

   do_pending_stack_adjust ();
   if (cond != integer_one_node)
     expand_end_cond ();
 }

      (((current_class_type)->type.lang_flag_2)) = 1;

      virtual_size = c_sizeof (current_class_type);


      if (((((current_class_type)->type.lang_specific)->type_flags.gets_delete) & 1))

 exprstmt =
   build_method_call
     (build_indirect_ref
      (build1 (NOP_EXPR, build_pointer_type (current_class_type),
        error_mark_node),
       ((void *)0)),
      ansi_opname[(int) DELETE_EXPR],
      tree_cons ((tree) 
                ((void *)0)
                         , current_class_decl,
   build_tree_list ((tree) 
                   ((void *)0)
                            , virtual_size)),
      (tree) 
     ((void *)0)
              , (3));
      else if ((((current_class_type)->common.lang_flag_3)))
 exprstmt = build_x_delete (ptr_type_node, current_class_decl, 0,
       virtual_size);
      else
 exprstmt = (tree) 
           ((void *)0)
                    ;

      if (exprstmt)
 {
   cond = build (BIT_AND_EXPR, integer_type_node,
   in_charge_node, integer_one_node);
   expand_start_cond (cond, 0);
   expand_expr_stmt (exprstmt);
   expand_end_cond ();
 }


      expand_end_bindings ((tree) 
                          ((void *)0)
                                   , getdecls() != (tree) 
                                                   ((void *)0)
                                                            , 0);
      poplevel (2, 0, 0);




      start_sequence ();




      expand_direct_vtbls_init (binfo, binfo, 1, 0, current_class_decl);
      if ((((current_class_type)->common.lang_flag_3)))
 expand_indirect_vtbls_init (binfo, C_C_D, current_class_decl, 0);
      if (! ok_to_optimize_dtor)
 {
   cond = build_binary_op (NE_EXPR,
      current_class_decl, integer_zero_node, 1);
   expand_start_cond (cond, 0);
 }

      insns = get_insns ();
      end_sequence ();

      last_parm_insn = get_first_nonparm_insn ();
      if (last_parm_insn == (rtx) 0)
 last_parm_insn = get_last_insn ();
      else
 last_parm_insn = previous_insn (last_parm_insn);

      emit_insns_after (insns, last_parm_insn);

      if (! ok_to_optimize_dtor)
 expand_end_cond ();
    }
  else if (current_function_assigns_this)
    {




      if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
 {
   end_protect_partials ();
   expand_label (ctor_label);
   ctor_label = (tree) 
               ((void *)0)
                        ;

   if (call_poplevel)
     {
       decls = getdecls ();
       expand_end_bindings (decls, decls != (tree) 
                                           ((void *)0)
                                                    , 0);
       poplevel (decls != (tree) 
                         ((void *)0)
                                  , 0, 0);
     }
   c_expand_return (current_class_decl);
 }
      else if (((((((current_function_decl)->decl.result))->common.type))->type.main_variant)
                                         != void_type_node
        && return_label != (rtx) 0)
 no_return_label = build_decl (LABEL_DECL, (tree) 
                                          ((void *)0)
                                                   , (tree) 
                                                     ((void *)0)
                                                              );

      current_function_assigns_this = 0;
      current_function_just_assigned_this = 0;
      base_init_expr = (tree) 
                      ((void *)0)
                               ;
    }
  else if ((((fndecl)->decl.lang_specific)->decl_flags.constructor_attr))
    {
      tree allocated_this;
      tree cond, thenclause;


      tree abstract_virtuals = (((current_class_type)->type.lang_specific)->abstract_virtuals);
      (((current_class_type)->type.lang_specific)->abstract_virtuals) = (tree) 
                                                        ((void *)0)
                                                                 ;

      (((fndecl)->decl.lang_specific)->decl_flags.returns_first_arg) = 1;

      if (flag_this_is_variable > 0)
 {
   cond = build_binary_op (EQ_EXPR,
      current_class_decl, integer_zero_node, 1);
   thenclause = build_modify_expr (current_class_decl, NOP_EXPR,
       build_new ((tree) 
                 ((void *)0)
                          , current_class_type, void_type_node, 0));
 }

      (((current_class_type)->type.lang_specific)->abstract_virtuals) = abstract_virtuals;

      start_sequence ();

      if (flag_this_is_variable > 0)
 {
   expand_start_cond (cond, 0);
   expand_expr_stmt (thenclause);
   expand_end_cond ();
 }
      if (base_init_expr)
 {
   expand_expr_stmt (base_init_expr);
   base_init_expr = (tree) 
                   ((void *)0)
                            ;
 }

      insns = get_insns ();
      end_sequence ();







      last_parm_insn = get_first_nonparm_insn ();
      if (last_parm_insn == (rtx) 0)
 last_parm_insn = get_last_insn ();
      else
 last_parm_insn = previous_insn (last_parm_insn);

      emit_insns_after (insns, last_parm_insn);

      end_protect_partials ();


      expand_label (ctor_label);
      ctor_label = (tree) 
                  ((void *)0)
                           ;

      if (call_poplevel)
 {
   decls = getdecls ();
   expand_end_bindings (decls, decls != (tree) 
                                       ((void *)0)
                                                , 0);
   poplevel (decls != (tree) 
                     ((void *)0)
                              , 1, 0);
 }

      c_expand_return (current_class_decl);

      current_function_assigns_this = 0;
      current_function_just_assigned_this = 0;
    }
  else if (((((fndecl)->decl.name))->identifier.length) == 4
    && ! strcmp (((((fndecl)->decl.name))->identifier.pointer), "main")
    && ((fndecl)->decl.context) == (tree) 
                               ((void *)0)
                                        )
    {




      c_expand_return (integer_zero_node);

    }
  else if (return_label != (rtx) 0
    && current_function_return_value == (tree) 
                                       ((void *)0)
    
   && ! ((((current_function_decl)->decl.result))->decl.name))
    no_return_label = build_decl (LABEL_DECL, (tree) 
                                             ((void *)0)
                                                      , (tree) 
                                                        ((void *)0)
                                                                 );

  if (flag_gc)
    expand_gc_prologue_and_epilogue ();
  if (no_return_label)
    {
      ((no_return_label)->decl.context) = fndecl;
      ((no_return_label)->decl.initial) = error_mark_node;
      ((no_return_label)->decl.filename) = input_filename;
      ((no_return_label)->decl.linenum) = lineno;
      expand_goto (no_return_label);
    }

  if (cleanup_label)
    {


      expand_end_bindings (0, 0, 0);
      poplevel (0, 0, 0);
    }

  if (cleanup_label)

    emit_label (cleanup_label);


  if (original_result_rtx)
    fixup_result_decl (((fndecl)->decl.result), original_result_rtx);



  if (no_return_label || cleanup_label)
    emit_jump (return_label);
  if (no_return_label)
    {



      expand_label (no_return_label);
    }


  expand_function_end (input_filename, lineno, 1);

  if (flag_handle_exceptions)
    expand_exception_blocks ();




  if (current_binding_level->parm_flag != 1)
    my_friendly_abort (122);
  poplevel (1, 0, 1);






  if (current_class_name)
    {
      ctype = current_class_type;
      pop_nested_class (1);
    }
  else
    pop_memoized_context (1);


  ((((fndecl)->decl.result))->decl.context) = ((fndecl)->decl.initial);


  if (flag_traditional && current_function_calls_setjmp)
    setjmp_protect (((fndecl)->decl.initial));



  ((((fndecl)->decl.initial))->block.supercontext) = fndecl;


  can_reach_end = 0;


  rest_of_compilation (fndecl);

  if (((fndecl)->decl.saved_insns.r) && ! ((fndecl)->common.asm_written_flag))
    {


      if (! ((fndecl)->decl.external_flag))
 (((fndecl)->decl.lang_specific)->decl_flags.not_really_extern) = 1;
      ((fndecl)->decl.external_flag) = 1;
      mark_inline_for_output (fndecl);
    }

  if (ctype && ((fndecl)->common.asm_written_flag))
    note_debug_info_needed (ctype);

  current_function_returns_null |= can_reach_end;





  if ((((fndecl)->decl.lang_specific)->decl_flags.constructor_attr)
      || ((((fndecl)->decl.result))->decl.name) != (tree) 
                                            ((void *)0)
                                                     )
    current_function_returns_null = 0;

  if (((fndecl)->common.volatile_flag) && current_function_returns_null)
    cp_warning ("`noreturn' function `%D' does return", fndecl);
  else if ((warn_return_type || pedantic)
    && current_function_returns_null
    && ((((fntype)->common.type))->type.main_variant) != void_type_node)
    {


      cp_pedwarn ("control reaches end of non-void function `%D'", fndecl);
    }


  else if (extra_warnings
    && current_function_returns_value && current_function_returns_null)
    warning ("this function may return with or without a value");




  if (! nested)
    permanent_allocation (1);

  if (flag_cadillac)
    cadillac_finish_function (fndecl);

  if (((fndecl)->decl.saved_insns.r) == (rtx) 0)
    {



      ((fndecl)->decl.initial) = error_mark_node;
      if (! (((fndecl)->decl.lang_specific)->decl_flags.constructor_attr)
   || !(((((fntype)->type.maxval))->common.lang_flag_3)))
 ((fndecl)->decl.arguments) = (tree) 
                          ((void *)0)
                                   ;
    }

  if (((fndecl)->decl.static_ctor_flag))
    static_ctors = perm_tree_cons ((tree) 
                                  ((void *)0)
                                           , fndecl, static_ctors);
  if (((fndecl)->decl.static_dtor_flag))
    static_dtors = perm_tree_cons ((tree) 
                                  ((void *)0)
                                           , fndecl, static_dtors);

  if (! nested)
    {



      current_function_decl = (tree) 
                             ((void *)0)
                                      ;
    }

  named_label_uses = (tree) 
                    ((void *)0)
                             ;
  current_class_decl = (tree) 
                      ((void *)0)
                               ;
}
tree
start_method(tree declspecs, tree declarator, tree raises) asm("_start_method");
tree
start_method(tree declspecs, tree declarator, tree raises)
{
  tree fndecl = grokdeclarator (declarator, declspecs, MEMFUNCDEF, 0, raises,
    (tree) 
   ((void *)0)
            );


  if (fndecl == (tree) 
               ((void *)0)
                        )
    return (tree) 
          ((void *)0)
                   ;


  if (((fndecl)->type.main_variant) == void_type_node)
    return fndecl;

  if (((n64_enum_tree_code) (fndecl)->common.code) != FUNCTION_DECL)

    return (tree) 
          ((void *)0)
                   ;

  if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
    {
      (((fndecl)->decl.lang_specific)->decl_flags.is_default_implementation) = 1;

      (((current_class_type)->type.lang_specific)->type_flags.has_default_implementation) = 1;
    }

  if ((((fndecl)->decl.lang_flag_3)))
    {
      if ((((struct n64_tag_lang_identifier *)(((fndecl)->decl.assembler_name)))->x ? ((struct n64_tag_lang_identifier *)(((fndecl)->decl.assembler_name)))->x->error_locus : 0) != current_class_type)
 {
   if (((fndecl)->decl.context))
     cp_error ("`%D' is already defined in class %s", fndecl,
        ((((((((((fndecl)->decl.context))->type.name))->decl.name)))->identifier.pointer)));
 }
      return void_type_node;
    }

  (((fndecl)->decl.lang_specific)->decl_flags.declared_inline) = 1;

  if (flag_default_inline)
    ((fndecl)->decl.inline_flag) = 1;

  if (processing_template_defn)
    {
      ((((fndecl)->decl.lang_specific)->decl_flags.use_template) = 1);
      repo_template_used (fndecl);
    }





  preserve_data ();

  if (! (((fndecl)->decl.lang_specific)->decl_flags.friend_attr))
    {
      if ((((fndecl)->decl.lang_specific)->chain) != (tree) 
                                ((void *)0)
                                         )
 {




   fndecl = copy_node (fndecl);
 }
      if (((fndecl)->common.chain))
 {
   fndecl = copy_node (fndecl);
   ((fndecl)->common.chain) = (tree) 
                        ((void *)0)
                                 ;
 }

      if ((((fndecl)->decl.lang_specific)->decl_flags.constructor_attr))
 {
   if (! grok_ctor_properties (current_class_type, fndecl))
     return void_type_node;
 }
      else if (((((fndecl)->decl.name))->common.lang_flag_2))
 grok_op_properties (fndecl, ((fndecl)->decl.virtual_flag), 0);
    }

  cp_finish_decl (fndecl, (tree) 
                         ((void *)0)
                                  , (tree) 
                                    ((void *)0)
                                             , 0, 0);


  pushlevel (0);
  current_binding_level->parm_flag = 1;

  (((fndecl)->decl.lang_flag_3)) = 1;
  return fndecl;
}
tree
finish_method(tree decl) asm("_finish_method");
tree
finish_method(tree decl)
{
  register tree fndecl = decl;
  tree old_initial;

  register tree link;

  if (((decl)->type.main_variant) == void_type_node)
    return decl;

  old_initial = ((fndecl)->decl.initial);
  for (link = current_binding_level->names; link; link = ((link)->common.chain))
    {
      if (((link)->decl.name) != (tree) 
                             ((void *)0)
                                      )
 (((struct n64_tag_lang_identifier *)(((link)->decl.name)))->local_value) = 0;
      my_friendly_assert (((n64_enum_tree_code) (link)->common.code) != FUNCTION_DECL, 163);
      ((link)->decl.context) = (tree) 
                           ((void *)0)
                                    ;
    }




  for (link = current_binding_level->shadowed; link; link = ((link)->common.chain))
      (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->local_value) = ((link)->list.value);
  for (link = current_binding_level->class_shadowed;
       link; link = ((link)->common.chain))
    (((struct n64_tag_lang_identifier *)(((link)->list.purpose)))->class_value) = ((link)->list.value);
  for (link = current_binding_level->type_shadowed;
       link; link = ((link)->common.chain))
    (((((link)->list.purpose))->common.type)) = ((link)->list.value);

  GNU_xref_end_scope ((int) current_binding_level,
        (int) current_binding_level->level_chain,
        current_binding_level->parm_flag,
        current_binding_level->keep,
        current_binding_level->tag_transparent);

  poplevel (0, 0, 0);

  ((fndecl)->decl.initial) = old_initial;




  if ((((fndecl)->decl.lang_specific)->decl_flags.friend_attr))
    {
      (((current_class_type)->type.noncopied_parts))
 = tree_cons ((tree) 
             ((void *)0)
                      , fndecl, (((current_class_type)->type.noncopied_parts)));
      decl = void_type_node;
    }

  return decl;
}





void
hack_incomplete_structures(tree type) asm("_hack_incomplete_structures");
void
hack_incomplete_structures(tree type)
{
  tree *list;

  if (current_binding_level->incomplete == (tree) 
                                          ((void *)0)
                                                   )
    return;

  if (!type)
    return;

  for (list = &current_binding_level->incomplete; *list; )
    {
      tree decl = ((*list)->list.value);
      if (decl && ((decl)->common.type) == type
   || (((decl)->common.type)
       && ((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE
       && ((((decl)->common.type))->common.type) == type))
 {
   int toplevel = toplevel_bindings_p ();
   if (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE
       && ((((decl)->common.type))->common.type) == type)
     layout_type (((decl)->common.type));
   layout_decl (decl, 0);
   rest_of_decl_compilation (decl, ((void *)0), toplevel, 0);
   if (! toplevel)
     {
       tree cleanup;
       expand_decl (decl);
       cleanup = maybe_build_cleanup (decl);
       expand_decl_init (decl);
       if (! cp_expand_decl_cleanup (decl, cleanup))
  cp_error ("parser lost in parsing declaration of `%D'",
     decl);
     }
   *list = ((*list)->common.chain);
 }
      else
 list = &((*list)->common.chain);
    }
}
int building_cleanup;







tree
maybe_build_cleanup(tree decl) asm("_maybe_build_cleanup");
tree
maybe_build_cleanup(tree decl)
{
  tree type = ((decl)->common.type);
  if ((((type)->type.lang_flag_4)))
    {
      int temp = 0, flags = (3)|(512);
      tree rval;
      int old_building_cleanup = building_cleanup;
      building_cleanup = 1;

      if (((n64_enum_tree_code) (decl)->common.code) != PARM_DECL)
 temp = suspend_momentary ();

      if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
 rval = decl;
      else
 {
   mark_addressable (decl);
   rval = build_unary_op (ADDR_EXPR, decl, 0);
 }


      if (! (((type)->common.lang_flag_3))
   || flag_expensive_optimizations)
 flags |= (8);

      rval = build_delete (((rval)->common.type), rval, integer_two_node, flags, 0);

      if ((((type)->common.lang_flag_3))
   && ! (((type)->type.lang_flag_2)))
 rval = build_compound_expr (tree_cons ((tree) 
                                       ((void *)0)
                                                , rval,
            build_tree_list ((tree) 
                            ((void *)0)
                                     , build_vbase_delete (type, decl))));

      if (((n64_enum_tree_code) (decl)->common.code) != PARM_DECL)
 resume_momentary (temp);

      building_cleanup = old_building_cleanup;

      return rval;
    }
  return 0;
}
void
cplus_expand_expr_stmt(tree exp) asm("_cplus_expand_expr_stmt");
void
cplus_expand_expr_stmt(tree exp)
{
  if (((exp)->common.type) == unknown_type_node)
    {
      if (((n64_enum_tree_code) (exp)->common.code) == ADDR_EXPR || ((n64_enum_tree_code) (exp)->common.code) == TREE_LIST)
 error ("address of overloaded function with no contextual type information");
      else if (((n64_enum_tree_code) (exp)->common.code) == COMPONENT_REF)
 warning ("useless reference to a member function name, did you forget the ()?");
    }
  else
    {
      int remove_implicit_immediately = 0;

      if (((n64_enum_tree_code) (exp)->common.code) == FUNCTION_DECL)
 {
   cp_warning ("reference, not call, to function `%D'", exp);
   warning ("at this point in file");
 }






      expand_expr_stmt (break_out_cleanups (exp));
    }



  expand_cleanups_to ((tree) 
                     ((void *)0)
                              );
}







void
finish_stmt(void) asm("_finish_stmt");
void
finish_stmt(void)
{
  extern struct nesting *cond_stack, *loop_stack, *case_stack;


  if (current_function_assigns_this
      || ! current_function_just_assigned_this)
    return;
  if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
    {


      if (cond_stack || loop_stack || case_stack)
 return;
      expand_expr_stmt (base_init_expr);
      check_base_init (current_class_type);
    }
  current_function_assigns_this = 1;

  if (flag_cadillac)
    cadillac_finish_stmt ();
}
void
revert_static_member_fn(tree *decl, tree *fn, tree *argtypes) asm("_revert_static_member_fn");
void
revert_static_member_fn(tree *decl, tree *fn, tree *argtypes)
{
  tree tmp;
  tree function = fn ? *fn : ((*decl)->common.type);
  tree args = argtypes ? *argtypes : ((function)->type.values);

  if (((((((args)->list.value))->common.type))->common.readonly_flag))
    cp_error ("static member function `%#D' declared const", *decl);
  if (((((((args)->list.value))->common.type))->common.volatile_flag))
    cp_error ("static member function `%#D' declared volatile", *decl);

  args = ((args)->common.chain);
  tmp = build_function_type (((function)->common.type), args);
  tmp = build_type_variant (tmp, ((function)->common.readonly_flag),
       ((function)->common.volatile_flag));
  tmp = build_exception_variant (tmp,
     ((function)->type.noncopied_parts));
  ((*decl)->common.type) = tmp;
  if (((*decl)->decl.arguments))
    ((*decl)->decl.arguments) = ((((*decl)->decl.arguments))->common.chain);
  (((*decl)->decl.lang_specific)->decl_flags.static_function) = 1;
  if (fn)
    *fn = tmp;
  if (argtypes)
    *argtypes = args;
}

int
id_in_current_class(tree id) asm("_id_in_current_class");
int
id_in_current_class(tree id)
{
  return !!purpose_member (id, class_binding_level->class_shadowed);
}

struct n64_tag_cp_function
{
  int returns_value;
  int returns_null;
  int warn_about_return_type;
  int assigns_this;
  int just_assigned_this;
  int parms_stored;
  int temp_name_counter;
  tree named_labels;
  tree shadowed_labels;
  tree ctor_label;
  tree dtor_label;
  tree protect_list;
  tree base_init_list;
  tree member_init_list;
  tree base_init_expr;
  tree class_decl;
  tree C_C_D;
  rtx result_rtx;
  struct n64_tag_cp_function *next;
  struct n64_tag_binding_level *binding_level;
};

struct n64_tag_cp_function *cp_function_chain;

extern int temp_name_counter;




void
push_cp_function_context(tree context) asm("_push_cp_function_context");
void
push_cp_function_context(tree context)
{
  struct n64_tag_cp_function *p
    = (struct n64_tag_cp_function *) xmalloc (sizeof (struct n64_tag_cp_function));

  push_function_context_to (context);

  p->next = cp_function_chain;
  cp_function_chain = p;

  p->named_labels = named_labels;
  p->shadowed_labels = shadowed_labels;
  p->returns_value = current_function_returns_value;
  p->returns_null = current_function_returns_null;
  p->warn_about_return_type = warn_about_return_type;
  p->binding_level = current_binding_level;
  p->ctor_label = ctor_label;
  p->dtor_label = dtor_label;
  p->assigns_this = current_function_assigns_this;
  p->just_assigned_this = current_function_just_assigned_this;
  p->parms_stored = current_function_parms_stored;
  p->result_rtx = original_result_rtx;
  p->base_init_expr = base_init_expr;
  p->protect_list = protect_list;
  p->temp_name_counter = temp_name_counter;
  p->base_init_list = current_base_init_list;
  p->member_init_list = current_member_init_list;
  p->class_decl = current_class_decl;
  p->C_C_D = C_C_D;
}



void
pop_cp_function_context(tree context) asm("_pop_cp_function_context");
void
pop_cp_function_context(tree context)
{
  struct n64_tag_cp_function *p = cp_function_chain;
  tree link;


  for (link = shadowed_labels; link; link = ((link)->common.chain))
    if (((((link)->list.value))->decl.name) != 0)
      (((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->x == 0 ? ((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(((((link)->list.value))->decl.name)))->x->label_value = (((link)->list.value)))
                        ;
  pop_function_context_from (context);

  cp_function_chain = p->next;

  named_labels = p->named_labels;
  shadowed_labels = p->shadowed_labels;
  current_function_returns_value = p->returns_value;
  current_function_returns_null = p->returns_null;
  warn_about_return_type = p->warn_about_return_type;
  current_binding_level = p->binding_level;
  ctor_label = p->ctor_label;
  dtor_label = p->dtor_label;
  protect_list = p->protect_list;
  current_function_assigns_this = p->assigns_this;
  current_function_just_assigned_this = p->just_assigned_this;
  current_function_parms_stored = p->parms_stored;
  original_result_rtx = p->result_rtx;
  base_init_expr = p->base_init_expr;
  temp_name_counter = p->temp_name_counter;
  current_base_init_list = p->base_init_list;
  current_member_init_list = p->member_init_list;
  current_class_decl = p->class_decl;
  C_C_D = p->C_C_D;

  free (p);
}
void
split_specs_attrs(tree specs_attrs, tree *declspecs, tree *prefix_attributes) asm("_split_specs_attrs");
void
split_specs_attrs(tree specs_attrs, tree *declspecs, tree *prefix_attributes)
{
  tree t, s, a, next, specs, attrs;


  if (specs_attrs != (tree) 
                    ((void *)0)
      
     && ((n64_enum_tree_code) (specs_attrs)->common.code) != TREE_LIST)
    {
      *declspecs = specs_attrs;
      *prefix_attributes = (tree) 
                          ((void *)0)
                                   ;
      return;
    }



  specs = s = (tree) 
             ((void *)0)
                      ;
  attrs = a = (tree) 
             ((void *)0)
                      ;
  for (t = specs_attrs; t; t = next)
    {
      next = ((t)->common.chain);

      if (((t)->list.value) != (tree) 
                           ((void *)0)
                                    )
 {
   if (specs == (tree) 
               ((void *)0)
                        )
     specs = s = t;
   else
     {
       ((s)->common.chain) = t;
       s = t;
     }
 }
      else
 {
   if (attrs == (tree) 
               ((void *)0)
                        )
     attrs = a = ((t)->list.purpose);
   else
     {
       ((a)->common.chain) = ((t)->list.purpose);
       a = ((t)->list.purpose);
     }
 }
    }


  if (s != (tree) 
          ((void *)0)
                   )
    ((s)->common.chain) = (tree) 
                    ((void *)0)
                             ;
  if (a != (tree) 
          ((void *)0)
                   )
    ((a)->common.chain) = (tree) 
                    ((void *)0)
                             ;


  *declspecs = specs;
  *prefix_attributes = attrs;
}







tree
strip_attrs(tree specs_attrs) asm("_strip_attrs");
tree
strip_attrs(tree specs_attrs)
{
  tree specs, attrs;

  split_specs_attrs (specs_attrs, &specs, &attrs);

  while (attrs)
    {
      warning ("`%s' attribute ignored",
        ((((attrs)->list.purpose))->identifier.pointer));
      attrs = ((attrs)->common.chain);
    }

  return specs;
}

