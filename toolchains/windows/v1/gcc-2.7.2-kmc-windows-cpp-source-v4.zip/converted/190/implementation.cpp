// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/binutils/objcopy.c
/* objcopy.c -- copy object file from input to output, optionally massaging it.
   Copyright (C) 1991, 92, 93, 94 Free Software Foundation, Inc.

   This file is part of GNU Binutils.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_lineno_cache_entry;
struct n64_tag_name_list;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_section_add;
struct n64_tag_section_list;
struct n64_tag_symbol_cache_entry;
struct n64_tag_symlist;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct bfd_link_info;
struct bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct bfd_link_info *, struct bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct bfd_link_order *link_order_head;
   struct bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct bfd_link_info *, struct bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct bfd_link_info *, struct bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct bfd_link_info *, boolean *again)
                                                            ;



  struct bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");
















void bfd_nonfatal (const char *) asm("_bfd_nonfatal");

void bfd_fatal (const char *) asm("_bfd_fatal");

void fatal (const char *, ...) asm("_fatal");

void list_matching_formats (char **p) asm("_list_matching_formats");

void list_supported_targets (const char *, FILE *) asm("_list_supported_targets");

void print_arelt_descr (FILE *file, bfd *abfd, boolean verbose) asm("_print_arelt_descr");

char *make_tempname (char *) asm("_make_tempname");

bfd_vma parse_vma (const char *, const char *) asm("_parse_vma");

extern char *program_name;


void mode_string (unsigned long mode, char *buf) asm("_mode_string");


void * xmalloc (size_t) asm("_xmalloc");

void * xrealloc (char *, size_t) asm("_xrealloc");





extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");


static flagword parse_flags (const char *) asm("_parse_flags");
static struct n64_tag_section_list *find_section_list (const char *, boolean) asm("_find_section_list");
static void setup_section (bfd *, asection *, void *) asm("_setup_section");
static void copy_section (bfd *, asection *, void *) asm("_copy_section");
static void get_sections (bfd *, asection *, void *) asm("_get_sections");
static int compare_section_vma (const void *, const void *) asm("_compare_section_vma");
static void add_strip_symbol (const char *) asm("_add_strip_symbol");
static boolean is_strip_symbol (const char *) asm("_is_strip_symbol");
static boolean is_strip_section (bfd *, asection *) asm("_is_strip_section");
static unsigned int filter_symbols
  (bfd *, asymbol **, asymbol **, long) asm("_filter_symbols");
static void mark_symbols_used_in_relocations (bfd *, asection *, void *) asm("_mark_symbols_used_in_relocations");



static asymbol **isympp = 
                         ((void *)0)
                             ;
static asymbol **osympp = 
                         ((void *)0)
                             ;


static int copy_byte = -1;
static int interleave = 4;

static boolean verbose;
static int status = 0;

enum n64_cpp_enum_strip_action{
    strip_undef,
    strip_none,
    strip_debug,
    strip_unneeded,
    strip_all
  };
typedef __underlying_type(enum n64_cpp_enum_strip_action) n64_enum_strip_action;



static n64_enum_strip_action strip_symbols;

enum n64_cpp_enum_locals_action{
    locals_undef,
    locals_start_L,
    locals_all
  };
typedef __underlying_type(enum n64_cpp_enum_locals_action) n64_enum_locals_action;



static n64_enum_locals_action discard_locals;



enum n64_cpp_enum_anonymous_12{ ignore_vma, adjust_vma, set_vma };
typedef __underlying_type(enum n64_cpp_enum_anonymous_12) n64_enum_anonymous_12;
struct n64_tag_section_list
{

  struct n64_tag_section_list *next;

  const char *name;

  boolean used;

  boolean remove;

  n64_enum_anonymous_12 adjust;

  bfd_vma val;

  boolean set_flags;

  flagword flags;
};

static struct n64_tag_section_list *adjust_sections;
static boolean sections_removed;


static bfd_vma adjust_start = 0;
static boolean set_start_set = cxx_false;
static bfd_vma set_start;


static bfd_vma adjust_section_vma = 0;


static boolean gap_fill_set = cxx_false;
static bfd_byte gap_fill = 0;


static boolean pad_to_set = cxx_false;
static bfd_vma pad_to;



struct n64_tag_section_add
{

  struct n64_tag_section_add *next;

  const char *name;

  const char *filename;

  size_t size;

  bfd_byte *contents;

  asection *section;
};

static struct n64_tag_section_add *add_sections;
static struct option strip_options[] =
{
  {"discard-all", 
                 0
                            , 0, 'x'},
  {"discard-locals", 
                    0
                               , 0, 'X'},
  {"format", 
            1
                             , 0, 'F'},
  {"help", 
          0
                     , 0, 'h'},
  {"input-format", 
                  1
                                   , 0, 'I'},
  {"input-target", 
                  1
                                   , 0, 'I'},
  {"keep-symbol", 
                 1
                                  , 0, 'K'},
  {"output-format", 
                   1
                                    , 0, 'O'},
  {"output-target", 
                   1
                                    , 0, 'O'},
  {"remove-section", 
                    1
                                     , 0, 'R'},
  {"strip-all", 
               0
                          , 0, 's'},
  {"strip-debug", 
                 0
                            , 0, 'S'},
  {"strip-unneeded", 
                    0
                               , 0, ((((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1)},
  {"strip-symbol", 
                  1
                                   , 0, 'N'},
  {"target", 
            1
                             , 0, 'F'},
  {"verbose", 
             0
                        , 0, 'v'},
  {"version", 
             0
                        , 0, 'V'},
  {0, 
     0
                , 0, 0}
};



static struct option copy_options[] =
{
  {"add-section", 
                 1
                                  , 0, 150},
  {"adjust-start", 
                  1
                                   , 0, (150 + 1)},
  {"adjust-vma", 
                1
                                 , 0, ((150 + 1) + 1)},
  {"adjust-section-vma", 
                        1
                                         , 0, (((150 + 1) + 1) + 1)},
  {"adjust-warnings", 
                     0
                                , 0, ((((150 + 1) + 1) + 1) + 1)},
  {"byte", 
          1
                           , 0, 'b'},
  {"discard-all", 
                 0
                            , 0, 'x'},
  {"discard-locals", 
                    0
                               , 0, 'X'},
  {"format", 
            1
                             , 0, 'F'},
  {"gap-fill", 
              1
                               , 0, (((((150 + 1) + 1) + 1) + 1) + 1)},
  {"help", 
          0
                     , 0, 'h'},
  {"input-format", 
                  1
                                   , 0, 'I'},
  {"input-target", 
                  1
                                   , 0, 'I'},
  {"interleave", 
                1
                                 , 0, 'i'},
  {"keep-symbol", 
                 1
                                  , 0, 'K'},
  {"no-adjust-warnings", 
                        0
                                   , 0, ((((((150 + 1) + 1) + 1) + 1) + 1) + 1)},
  {"output-format", 
                   1
                                    , 0, 'O'},
  {"output-target", 
                   1
                                    , 0, 'O'},
  {"pad-to", 
            1
                             , 0, (((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1)},
  {"remove-section", 
                    1
                                     , 0, 'R'},
  {"set-section-flags", 
                       1
                                        , 0, ((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1)},
  {"set-start", 
               1
                                , 0, (((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1)},
  {"strip-all", 
               0
                          , 0, 'S'},
  {"strip-debug", 
                 0
                            , 0, 'g'},
  {"strip-unneeded", 
                    0
                               , 0, ((((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1)},
  {"strip-symbol", 
                  1
                                   , 0, 'N'},
  {"target", 
            1
                             , 0, 'F'},
  {"verbose", 
             0
                        , 0, 'v'},
  {"version", 
             0
                        , 0, 'V'},
  {0, 
     0
                , 0, 0}
};


extern char *program_name;
extern char *program_version;




extern int is_strip;


static void
copy_usage(FILE *stream, int exit_status) asm("_copy_usage");
static void
copy_usage(FILE *stream, int exit_status)
{
  fprintf (stream, "Usage: %s [-vVSgxX] [-I bfdname] [-O bfdname] [-F bfdname] [-b byte]\n       [-R section] [-i interleave] [--interleave=interleave] [--byte=byte]\n       [--input-target=bfdname] [--output-target=bfdname] [--target=bfdname]\n       [--strip-all] [--strip-debug] [--strip-unneeded] [--discard-all]\n       [--discard-locals] [--remove-section=section] [--gap-fill=val]\n",





    program_name);
  fprintf (stream, "       [--pad-to=address] [--set-start=val] [--adjust-start=incr]\n       [--adjust-vma=incr] [--adjust-section-vma=section{=,+,-}val]\n       [--adjust-warnings] [--no-adjust-warnings]\n       [--set-section-flags=section=flags] [--add-section=sectionname=filename]\n       [--keep-symbol symbol] [-K symbol] [--strip-symbol symbol] [-N symbol]\n       [--verbose] [--version] [--help]\n       in-file [out-file]\n");







  list_supported_targets (program_name, stream);
  exit (exit_status);
}

static void
strip_usage(FILE *stream, int exit_status) asm("_strip_usage");
static void
strip_usage(FILE *stream, int exit_status)
{
  fprintf (stream, "Usage: %s [-vVsSgxX] [-I bfdname] [-O bfdname] [-F bfdname] [-R section]\n       [--input-target=bfdname] [--output-target=bfdname] [--target=bfdname]\n       [--strip-all] [--strip-debug] [--strip-unneeded] [--discard-all]\n       [--discard-locals] [--keep-symbol symbol] [-K symbol]\n       [--strip-symbol symbol] [-N symbol] [--remove-section=section]\n       [--verbose] [--version] [--help] file...\n",






    program_name);
  list_supported_targets (program_name, stream);
  exit (exit_status);
}




static flagword
parse_flags(const char *s) asm("_parse_flags");
static flagword
parse_flags(const char *s)
{
  flagword ret;
  const char *snext;
  int len;

  ret = 0x000;

  do
    {
      snext = strchr (s, ',');
      if (snext == 
                  ((void *)0)
                      )
 len = strlen (s);
      else
 {
   len = snext - s;
   ++snext;
 }


      if (strncmp ("alloc", s, len) == 0) ret |= 0x001;;
      if (strncmp ("load", s, len) == 0) ret |= 0x002;;
      if (strncmp ("readonly", s, len) == 0) ret |= 0x010;;
      if (strncmp ("code", s, len) == 0) ret |= 0x020;;
      if (strncmp ("data", s, len) == 0) ret |= 0x040;;
      if (strncmp ("rom", s, len) == 0) ret |= 0x080;;


      s = snext;
    }
  while (s != 
             ((void *)0)
                 );

  return ret;
}



static struct n64_tag_section_list *
find_section_list(const char *name, boolean add) asm("_find_section_list");
static struct n64_tag_section_list *
find_section_list(const char *name, boolean add)
{
  register struct n64_tag_section_list *p;

  for (p = adjust_sections; p != 
                                ((void *)0)
                                    ; p = p->next)
    if (strcmp (p->name, name) == 0)
      return p;

  if (! add)
    return 
          ((void *)0)
              ;

  p = (struct n64_tag_section_list *) xmalloc (sizeof (struct n64_tag_section_list));
  p->name = name;
  p->used = cxx_false;
  p->remove = cxx_false;
  p->adjust = ignore_vma;
  p->val = 0;
  p->set_flags = cxx_false;
  p->flags = 0;

  p->next = adjust_sections;
  adjust_sections = p;

  return p;
}






struct n64_tag_symlist
{
  const char *name;
  struct n64_tag_symlist *next;
};



static struct n64_tag_symlist *strip_specific_list = 
                                            ((void *)0)
                                                ;




static boolean keep_symbols = cxx_false;



static void
add_strip_symbol(const char *name) asm("_add_strip_symbol");
static void
add_strip_symbol(const char *name)
{
  struct n64_tag_symlist *tmp_list;

  tmp_list = (struct n64_tag_symlist *) xmalloc (sizeof (struct n64_tag_symlist));
  tmp_list->name = name;
  tmp_list->next = strip_specific_list;
  strip_specific_list = tmp_list;
}




static boolean
is_strip_symbol(const char *name) asm("_is_strip_symbol");
static boolean
is_strip_symbol(const char *name)
{
  struct n64_tag_symlist *tmp_list;

  for (tmp_list = strip_specific_list; tmp_list; tmp_list = tmp_list->next)
    {
      if (strcmp (name, tmp_list->name) == 0)
 return keep_symbols ? cxx_false : cxx_true;
    }
  return keep_symbols;
}



static boolean
is_strip_section(bfd *abfd, asection *sec) asm("_is_strip_section");
static boolean
is_strip_section(bfd *abfd, asection *sec)
{
  struct n64_tag_section_list *p;

  if ((((sec)->flags + 0) & 0x10000) != 0
      && (strip_symbols == strip_debug
   || strip_symbols == strip_unneeded
   || strip_symbols == strip_all
   || discard_locals == locals_all))
    return cxx_true;

  if (! sections_removed)
    return cxx_false;
  p = find_section_list (((sec)->name + 0), cxx_false);
  return p != 
             ((void *)0) 
                  && p->remove ? cxx_true : cxx_false;
}





static unsigned int
filter_symbols(bfd *abfd, asymbol **osyms, asymbol **isyms, long int symcount) asm("_filter_symbols");
static unsigned int
filter_symbols(bfd *abfd, asymbol **osyms, asymbol **isyms, long int symcount)
{
  register asymbol **from = isyms, **to = osyms;
  long src_count = 0, dst_count = 0;

  for (; src_count < symcount; src_count++)
    {
      asymbol *sym = from[src_count];
      flagword flags = sym->flags;
      int keep;

      if ((flags & 0x20) != 0)
 keep = 1;
      else if ((flags & 0x02) != 0
        || ((((sym)->section)) == ((asection *) &bfd_und_section))
        || (((((sym)->section))->flags & 0x8000) != 0))
 keep = strip_symbols != strip_unneeded;
      else if ((flags & 0x08) != 0)
 keep = (strip_symbols != strip_debug
  && strip_symbols != strip_unneeded);
      else
 keep = (strip_symbols != strip_unneeded
  && (discard_locals != locals_all
      && (discard_locals != locals_start_L
   || ! ((*((abfd)->xvec->_bfd_is_local_label)) (abfd, sym)))));

      if (keep && is_strip_symbol (((sym)->name)))
 keep = 0;
      if (keep && is_strip_section (abfd, ((sym)->section)))
 keep = 0;

      if (keep)
 to[dst_count++] = sym;
    }

  return dst_count;
}




void
filter_bytes(char *memhunk, bfd_size_type *size) asm("_filter_bytes");
void
filter_bytes(char *memhunk, bfd_size_type *size)
{
  char *from = memhunk + copy_byte, *to = memhunk, *end = memhunk + *size;

  for (; from < end; from += interleave)
    *to++ = *from;
  *size /= interleave;
}



static void
copy_object(bfd *ibfd, bfd *obfd) asm("_copy_object");
static void
copy_object(bfd *ibfd, bfd *obfd)
{
  bfd_vma start;
  long symcount;
  asection **osections = 
                        ((void *)0)
                            ;
  bfd_size_type *gaps = 
                       ((void *)0)
                           ;
  bfd_size_type max_gap = 0;

  if (!bfd_set_format (obfd, ((ibfd)->format)))
    {
      {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
    }

  if (verbose)
    printf ("copy from %s(%s) to %s(%s)\n",
     ((char *) (ibfd)->filename), ((ibfd)->xvec->name),
     ((char *) (obfd)->filename), ((obfd)->xvec->name));

  if (set_start_set)
    start = set_start;
  else
    start = ((ibfd)->start_address);
  start += adjust_start;

  if (!bfd_set_start_address (obfd, start)
      || !bfd_set_file_flags (obfd,
         (((ibfd)->flags)
          & ((obfd)->xvec->object_flags))))
    {
      {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
    }


  if (!((*((obfd)->xvec->_bfd_set_arch_mach)) (obfd, bfd_get_arch (ibfd), bfd_get_mach (ibfd)))
                         )
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "Output file cannot represent architecture %s\n",
        bfd_printable_arch_mach (bfd_get_arch (ibfd),
     bfd_get_mach (ibfd)));
    }
  if (!bfd_set_format (obfd, ((ibfd)->format)))
    {
      {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
    }

  if (isympp)
    free (isympp);
  if (osympp != isympp)
    free (osympp);



  bfd_map_over_sections (ibfd, setup_section, (void *) obfd);

  if (add_sections != 
                     ((void *)0)
                         )
    {
      struct n64_tag_section_add *padd;
      struct n64_tag_section_list *pset;

      for (padd = add_sections; padd != 
                                       ((void *)0)
                                           ; padd = padd->next)
 {
   padd->section = bfd_make_section (obfd, padd->name);
   if (padd->section == 
                       ((void *)0)
                           )
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: can't create section `%s': %s\n",
         program_name, padd->name,
         bfd_errmsg (bfd_get_error ()));
       status = 1;
       return;
     }
   else
     {
       flagword flags;

       if (! bfd_set_section_size (obfd, padd->section, padd->size))
  {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};

       pset = find_section_list (padd->name, cxx_false);
       if (pset != 
                  ((void *)0)
                      )
  pset->used = cxx_true;

       if (pset != 
                  ((void *)0) 
                       && pset->set_flags)
  flags = pset->flags | 0x200;
       else
  flags = 0x200 | 0x010 | 0x040;
       if (! bfd_set_section_flags (obfd, padd->section, flags))
  {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};

       if (pset != 
                  ((void *)0)
    
   && (pset->adjust == adjust_vma
        || pset->adjust == set_vma))
  {
    if (! (((padd->section)->vma = (padd->section)->lma= (pset->val)), ((padd->section)->user_set_vma = (boolean)cxx_true), cxx_true))
      {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
  }
     }
 }
    }

  if (gap_fill_set || pad_to_set)
    {
      asection **set;
      unsigned int c, i;







      c = ((obfd)->section_count);
      osections = (asection **) xmalloc (c * sizeof (asection *));
      set = osections;
      bfd_map_over_sections (obfd, get_sections, (void *) &set);

      qsort (osections, c, sizeof (asection *), compare_section_vma);

      gaps = (bfd_size_type *) xmalloc (c * sizeof (bfd_size_type));
      memset (gaps, 0, c * sizeof (bfd_size_type));

      if (gap_fill_set)
 {
   for (i = 0; i < c - 1; i++)
     {
       flagword flags;
       bfd_size_type size;
       bfd_vma gap_start, gap_stop;

       flags = ((osections[i])->flags + 0);
       if ((flags & 0x200) == 0
    || (flags & 0x002) == 0)
  continue;

       size = ((osections[i]->reloc_done ? (abort(),1): (osections[i])->_raw_size));
       gap_start = ((osections[i])->vma) + size;
       gap_stop = ((osections[i + 1])->vma);
       if (gap_start < gap_stop)
  {
    if (! bfd_set_section_size (obfd, osections[i],
           size + (gap_stop - gap_start)))
      {
        fprintf (
                (__acrt_iob_func(2))
                      , "%s: Can't fill gap after %s: %s\n",
          program_name,
          ((osections[i])->name + 0),
          bfd_errmsg (bfd_get_error()));
        status = 1;
        break;
      }
    gaps[i] = gap_stop - gap_start;
    if (max_gap < gap_stop - gap_start)
      max_gap = gap_stop - gap_start;
  }
     }
 }

      if (pad_to_set)
 {
   bfd_vma vma;
   bfd_size_type size;

   vma = ((osections[c - 1])->vma);
   size = ((osections[c - 1]->reloc_done ? (abort(),1): (osections[c - 1])->_raw_size));
   if (vma + size < pad_to)
     {
       if (! bfd_set_section_size (obfd, osections[c - 1],
       pad_to - vma))
  {
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: Can't add padding to %s: %s\n",
      program_name,
      ((osections[c - 1])->name + 0),
      bfd_errmsg (bfd_get_error ()));
    status = 1;
  }
       else
  {
    gaps[c - 1] = pad_to - (vma + size);
    if (max_gap < pad_to - (vma + size))
      max_gap = pad_to - (vma + size);
  }
     }
 }
    }



  if (strip_symbols == strip_all)
    {
      osympp = isympp = 
                       ((void *)0)
                           ;
      symcount = 0;
    }
  else
    {
      long symsize;

      symsize = ((*((ibfd)->xvec->_bfd_get_symtab_upper_bound)) (ibfd));
      if (symsize < 0)
 {
   {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
 }

      osympp = isympp = (asymbol **) xmalloc (symsize);
      symcount = ((*((ibfd)->xvec->_bfd_canonicalize_symtab)) (ibfd, isympp));
      if (symcount < 0)
 {
   {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
 }

      if (strip_symbols == strip_debug
   || strip_symbols == strip_unneeded
   || discard_locals != locals_undef
   || strip_specific_list != 
                            ((void *)0)
   
  || sections_removed)
 {
   bfd_map_over_sections (ibfd,
     mark_symbols_used_in_relocations,
     (void *)isympp);
   osympp = (asymbol **) xmalloc (symcount * sizeof (asymbol *));
   symcount = filter_symbols (ibfd, osympp, isympp, symcount);
 }
    }

  bfd_set_symtab (obfd, osympp, symcount);


  bfd_map_over_sections (ibfd, copy_section, (void *) obfd);

  if (add_sections != 
                     ((void *)0)
                         )
    {
      struct n64_tag_section_add *padd;

      for (padd = add_sections; padd != 
                                       ((void *)0)
                                           ; padd = padd->next)
 {
   if (! bfd_set_section_contents (obfd, padd->section,
       (void *) padd->contents,
       (file_ptr) 0,
       (bfd_size_type) padd->size))
     {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
 }
    }

  if (gap_fill_set || pad_to_set)
    {
      bfd_byte *buf;
      int c, i;



      if (max_gap > 8192)
 max_gap = 8192;
      buf = (bfd_byte *) xmalloc (max_gap);
      memset (buf, gap_fill, (size_t) max_gap);

      c = ((obfd)->section_count);
      for (i = 0; i < c; i++)
 {
   if (gaps[i] != 0)
     {
       bfd_size_type left;
       file_ptr off;

       left = gaps[i];
       off = ((osections[i]->reloc_done ? (abort(),1): (osections[i])->_raw_size)) - left;
       while (left > 0)
  {
    bfd_size_type now;

    if (left > 8192)
      now = 8192;
    else
      now = left;
    if (! bfd_set_section_contents (obfd, osections[i], buf,
        off, now))
      {
        {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
      }
    left -= now;
    off += now;
  }
     }
 }
    }





  if (!((*((ibfd)->xvec->_bfd_copy_private_bfd_data)) (ibfd, obfd)))
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: %s: error copying private BFD data: %s\n",
        program_name, ((char *) (obfd)->filename),
        bfd_errmsg (bfd_get_error ()));
      status = 1;
      return;
    }
}

static char *
cat(char *a, char *b, char *c) asm("_cat");
static char *
cat(char *a, char *b, char *c)
{
  size_t size = strlen (a) + strlen (b) + strlen (c);
  char *r = xmalloc (size + 1);

  strcpy (r, a);
  strcat (r, b);
  strcat (r, c);
  return r;
}




static void
copy_archive(bfd *ibfd, bfd *obfd, char *output_target) asm("_copy_archive");
static void
copy_archive(bfd *ibfd, bfd *obfd, char *output_target)
{
  struct n64_tag_name_list
    {
      struct n64_tag_name_list *next;
      char *name;
      bfd *obfd;
    } *list, *l;
  bfd **ptr = &obfd->archive_head;
  bfd *this_element;
  char *dir = make_tempname (((char *) (obfd)->filename));



  if (mkdir (dir) != 0)



    {
      fatal ("cannot mkdir %s for archive copying (error: %s)",
      dir, strerror (
                    (*_errno())
                         ));
    }
  obfd->has_armap = ibfd->has_armap;

  list = 
        ((void *)0)
            ;

  this_element = bfd_openr_next_archived_file (ibfd, 
                                                    ((void *)0)
                                                        );
  while (this_element != (bfd *) 
                                ((void *)0)
                                    )
    {

      char *output_name = cat (dir, "/", ((char *) (this_element)->filename));
      bfd *output_bfd = bfd_openw (output_name, output_target);
      bfd *last_element;

      l = (struct n64_tag_name_list *) xmalloc (sizeof (struct n64_tag_name_list));
      l->name = output_name;
      l->next = list;
      list = l;

      if (output_bfd == (bfd *) 
                               ((void *)0)
                                   )
 {
   {bfd_nonfatal(output_name); status = 1; return;};
 }
      if (!bfd_set_format (obfd, ((ibfd)->format)))
 {
   {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
 }

      if (bfd_check_format (this_element, bfd_object) == cxx_true)
 {
   copy_object (this_element, output_bfd);
 }

      bfd_close (output_bfd);


      output_bfd = bfd_openr (output_name, output_target);

      l->obfd = output_bfd;

      *ptr = output_bfd;
      ptr = &output_bfd->next;

      last_element = this_element;

      this_element = bfd_openr_next_archived_file (ibfd, last_element);

      bfd_close (last_element);
    }
  *ptr = (bfd *) 
                ((void *)0)
                    ;

  if (!bfd_close (obfd))
    {
      {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
    }

  if (!bfd_close (ibfd))
    {
      {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
    }


  for (l = list; l != 
                     ((void *)0)
                         ; l = l->next)
    {
      bfd_close (l->obfd);
      unlink (l->name);
    }
  rmdir (dir);
}



static void
copy_file(char *input_filename, char *output_filename, char *input_target, char *output_target) asm("_copy_file");
static void
copy_file(char *input_filename, char *output_filename, char *input_target, char *output_target)
{
  bfd *ibfd;
  char **matching;




  ibfd = bfd_openr (input_filename, input_target);
  if (ibfd == 
             ((void *)0)
                 )
    {
      {bfd_nonfatal(input_filename); status = 1; return;};
    }

  if (bfd_check_format (ibfd, bfd_archive))
    {
      bfd *obfd;



      if (output_target == 
                          ((void *)0)
                              )
 output_target = ((ibfd)->xvec->name);

      obfd = bfd_openw (output_filename, output_target);
      if (obfd == 
                 ((void *)0)
                     )
 {
   {bfd_nonfatal(output_filename); status = 1; return;};
 }
      copy_archive (ibfd, obfd, output_target);
    }
  else if (bfd_check_format_matches (ibfd, bfd_object, &matching))
    {
      bfd *obfd;



      if (output_target == 
                          ((void *)0)
                              )
 output_target = ((ibfd)->xvec->name);

      obfd = bfd_openw (output_filename, output_target);
      if (obfd == 
                 ((void *)0)
                     )
 {
   {bfd_nonfatal(output_filename); status = 1; return;};
 }

      copy_object (ibfd, obfd);

      if (!bfd_close (obfd))
 {
   {bfd_nonfatal(output_filename); status = 1; return;};
 }

      if (!bfd_close (ibfd))
 {
   {bfd_nonfatal(input_filename); status = 1; return;};
 }
    }
  else
    {
      bfd_nonfatal (input_filename);
      if (bfd_get_error () == bfd_error_file_ambiguously_recognized)
 {
   list_matching_formats (matching);
   free (matching);
 }
      status = 1;
    }
}




static void
setup_section(bfd *ibfd, sec_ptr isection, void *obfdarg) asm("_setup_section");
static void
setup_section(bfd *ibfd, sec_ptr isection, void *obfdarg)
{
  bfd *obfd = (bfd *) obfdarg;
  struct n64_tag_section_list *p;
  sec_ptr osection;
  bfd_vma vma;
  bfd_vma lma;
  flagword flags;
  char *err;

  if ((((isection)->flags + 0) & 0x10000) != 0
      && (strip_symbols == strip_debug
   || strip_symbols == strip_unneeded
   || strip_symbols == strip_all
   || discard_locals == locals_all))
    return;

  p = find_section_list (((isection)->name), cxx_false);
  if (p != 
          ((void *)0)
              )
    p->used = cxx_true;

  if (p != 
          ((void *)0) 
               && p->remove)
    return;

  osection = bfd_make_section_anyway (obfd, ((isection)->name));
  if (osection == 
                 ((void *)0)
                     )
    {
      err = "making";
      goto loser;
    }

  if (!bfd_set_section_size (obfd,
        osection,
        ((isection->reloc_done ? (abort(),1): (isection)->_raw_size))))
    {
      err = "size";
      goto loser;
    }

  vma = ((isection)->vma);
  if (p != 
          ((void *)0) 
               && p->adjust == adjust_vma)
    vma += p->val;
  else if (p != 
               ((void *)0) 
                    && p->adjust == set_vma)
    vma = p->val;
  else
    vma += adjust_section_vma;
  if (! (((osection)->vma = (osection)->lma= (vma)), ((osection)->user_set_vma = (boolean)cxx_true), cxx_true))
    {
      err = "vma";
      goto loser;
    }

  lma = isection->lma;
  if (p != 
          ((void *)0) 
               && p->adjust == adjust_vma)
    lma += p->val;
  else if (p != 
               ((void *)0) 
                    && p->adjust == set_vma)
    lma = p->val;
  else
    lma += adjust_section_vma;
  osection->lma = lma;

  if ((((osection)->alignment_power = (((isection)->alignment_power))),cxx_true)


      == cxx_false)
    {
      err = "alignment";
      goto loser;
    }

  flags = ((isection)->flags + 0);
  if (p != 
          ((void *)0) 
               && p->set_flags)
    flags = p->flags | (flags & 0x200);
  if (!bfd_set_section_flags (obfd, osection, flags))
    {
      err = "flags";
      goto loser;
    }




  isection->output_section = osection;
  isection->output_offset = 0;



  if (!((*((ibfd)->xvec->_bfd_copy_private_section_data)) (ibfd, isection, obfd, osection)))
    {
      err = "private data";
      goto loser;
    }


  return;

loser:
  fprintf (
          (__acrt_iob_func(2))
                , "%s: %s: section `%s': error in %s: %s\n",
    program_name,
    ((char *) (ibfd)->filename), ((isection)->name),
    err, bfd_errmsg (bfd_get_error ()));
  status = 1;
}





static void
copy_section(bfd *ibfd, sec_ptr isection, void *obfdarg) asm("_copy_section");
static void
copy_section(bfd *ibfd, sec_ptr isection, void *obfdarg)
{
  bfd *obfd = (bfd *) obfdarg;
  struct n64_tag_section_list *p;
  arelent **relpp;
  long relcount;
  sec_ptr osection;
  bfd_size_type size;

  if ((((isection)->flags + 0) & 0x10000) != 0
      && (strip_symbols == strip_debug
   || strip_symbols == strip_unneeded
   || strip_symbols == strip_all
   || discard_locals == locals_all))
    {
      return;
    }

  p = find_section_list (((isection)->name), cxx_false);

  if (p != 
          ((void *)0) 
               && p->remove)
    return;

  osection = isection->output_section;
  size = (isection->reloc_done ? (abort(),1): (isection)->_raw_size);

  if (size == 0 || osection == 0)
    return;

  if (strip_symbols == strip_all)
    bfd_set_reloc (obfd, osection, (arelent **) 
                                               ((void *)0)
                                                   , 0);
  else
    {
      long relsize;

      relsize = bfd_get_reloc_upper_bound (ibfd, isection);
      if (relsize < 0)
 {
   {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
 }
      if (relsize == 0)
 bfd_set_reloc (obfd, osection, (arelent **) 
                                            ((void *)0)
                                                , 0);
      else
 {
   relpp = (arelent **) xmalloc (relsize);
   relcount = bfd_canonicalize_reloc (ibfd, isection, relpp, isympp);
   if (relcount < 0)
     {
       {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
     }
   bfd_set_reloc (obfd, osection, relpp, relcount);
 }
    }

  isection->_cooked_size = isection->_raw_size;
  isection->reloc_done = cxx_true;

  if (((isection)->flags + 0) & 0x200)
    {
      void * memhunk = (void *) xmalloc ((unsigned) size);

      if (!bfd_get_section_contents (ibfd, isection, memhunk, (file_ptr) 0,
         size))
 {
   {bfd_nonfatal(((char *) (ibfd)->filename)); status = 1; return;};
 }

      if (copy_byte >= 0)
        {
   filter_bytes (memhunk, &size);

          if (!bfd_set_section_size (obfd, osection, size))
            {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
        }

      if (!bfd_set_section_contents (obfd, osection, memhunk, (file_ptr) 0,
         size))
 {
   {bfd_nonfatal(((char *) (obfd)->filename)); status = 1; return;};
 }
      free (memhunk);
    }
}




static void
get_sections(bfd *obfd, asection *osection, void *secppparg) asm("_get_sections");
static void
get_sections(bfd *obfd, asection *osection, void *secppparg)
{
  asection ***secppp = (asection ***) secppparg;

  **secppp = osection;
  ++(*secppp);
}





static int
compare_section_vma(const void *arg1, const void *arg2) asm("_compare_section_vma");
static int
compare_section_vma(const void *arg1, const void *arg2)
{
  const asection **sec1 = (const asection **) arg1;
  const asection **sec2 = (const asection **) arg2;
  flagword flags1, flags2;


  flags1 = (*sec1)->flags;
  flags2 = (*sec2)->flags;
  if ((flags1 & 0x200) == 0
      || (flags1 & 0x002) == 0)
    {
      if ((flags2 & 0x200) != 0
   && (flags2 & 0x002) != 0)
 return -1;
    }
  else
    {
      if ((flags2 & 0x200) == 0
   || (flags2 & 0x002) == 0)
 return 1;
    }


  if ((*sec1)->vma > (*sec2)->vma)
    return 1;
  else if ((*sec1)->vma < (*sec2)->vma)
    return -1;


  if ((*sec1)->_raw_size > (*sec2)->_raw_size)
    return 1;
  else if ((*sec1)->_raw_size < (*sec2)->_raw_size)
    return -1;

  return 0;
}






static void
mark_symbols_used_in_relocations(bfd *ibfd, sec_ptr isection, void *symbolsarg) asm("_mark_symbols_used_in_relocations");
static void
mark_symbols_used_in_relocations(bfd *ibfd, sec_ptr isection, void *symbolsarg)
{
  asymbol **symbols = (asymbol **) symbolsarg;
  long relsize;
  arelent **relpp;
  long relcount, i;


  if (isection->output_section == 
                                 ((void *)0)
                                     )
    return;

  relsize = bfd_get_reloc_upper_bound (ibfd, isection);
  if (relsize < 0)
    bfd_fatal (((char *) (ibfd)->filename));

  if (relsize == 0)
    return;

  relpp = (arelent **) xmalloc (relsize);
  relcount = bfd_canonicalize_reloc (ibfd, isection, relpp, symbols);
  if (relcount < 0)
    bfd_fatal (((char *) (ibfd)->filename));



  for (i = 0; i < relcount; i++)
    {
      if (*relpp[i]->sym_ptr_ptr != ((asection *) &bfd_com_section)->symbol
   && *relpp[i]->sym_ptr_ptr != ((asection *) &bfd_abs_section)->symbol
   && *relpp[i]->sym_ptr_ptr != ((asection *) &bfd_und_section)->symbol)
 (*relpp[i]->sym_ptr_ptr)->flags |= 0x20;
    }

  if (relpp != 
              ((void *)0)
                  )
    free (relpp);
}







static int
simple_copy(char *from, char *to) asm("_simple_copy");
static int
simple_copy(char *from, char *to)
{
  int fromfd, tofd, nread;
  int saved;
  char buf[8192];

  fromfd = open (from, 
                      0x0000
                              );
  if (fromfd < 0)
    return -1;
  tofd = creat (to, 0777);
  if (tofd < 0)
    {
      saved = 
             (*_errno())
                  ;
      close (fromfd);
      
     (*_errno()) 
           = saved;
      return -1;
    }
  while ((nread = read (fromfd, buf, sizeof buf)) > 0)
    {
      if (write (tofd, buf, nread) != nread)
 {
   saved = 
          (*_errno())
               ;
   close (fromfd);
   close (tofd);
   
  (*_errno()) 
        = saved;
   return -1;
 }
    }
  saved = 
         (*_errno())
              ;
  close (fromfd);
  close (tofd);
  if (nread < 0)
    {
      
     (*_errno()) 
           = saved;
      return -1;
    }
  return 0;
}
static int
smart_rename(char *from, char *to) asm("_smart_rename");
static int
smart_rename(char *from, char *to)
{
  struct stat s;
  int ret = 0;

  if (stat (to, &s))
    return -1;



  if (!0 && s.st_nlink == 1)
    {
      ret = rename (from, to);
      if (ret == 0)
 {

   chmod (to, s.st_mode & 07777);



 }
      else
 {

   int saved = 
              (*_errno())
                   ;
   fprintf (
           (__acrt_iob_func(2))
                 , "%s: %s: ", program_name, to);
   
  (*_errno()) 
        = saved;
   perror ("rename");
   unlink (from);
 }
    }
  else
    {
      ret = simple_copy (from, to);
      if (ret != 0)
 {
   int saved = 
              (*_errno())
                   ;
   fprintf (
           (__acrt_iob_func(2))
                 , "%s: %s: ", program_name, to);
   
  (*_errno()) 
        = saved;
   perror ("simple_copy");
 }
      unlink (from);
    }
  return ret;
}

static int
strip_main(int argc, char **argv) asm("_strip_main");
static int
strip_main(int argc, char **argv)
{
  char *input_target = 
                      ((void *)0)
                          , *output_target = 
                                             ((void *)0)
                                                 ;
  boolean show_version = cxx_false;
  int c, i;
  struct n64_tag_section_list *p;

  while ((c = getopt_long (argc, argv, "I:O:F:K:N:R:sSgxXVv",
      strip_options, (int *) 0)) != 
                                   (-1)
                                      )
    {
      switch (c)
 {
 case 'I':
   input_target = optarg;
   break;
 case 'O':
   output_target = optarg;
   break;
 case 'F':
   input_target = output_target = optarg;
   break;
 case 'R':
   p = find_section_list (optarg, cxx_true);
   p->remove = cxx_true;
   sections_removed = cxx_true;
   break;
 case 's':
   strip_symbols = strip_all;
   break;
 case 'S':
 case 'g':
   strip_symbols = strip_debug;
   break;
 case ((((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1):
   strip_symbols = strip_unneeded;
   break;
 case 'K':
   if (! keep_symbols && strip_specific_list != 
                                               ((void *)0)
                                                   )
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: Can not specify both -K and -N\n",
         program_name);
       strip_usage (
                   (__acrt_iob_func(2))
                         , 1);
     }
   keep_symbols = cxx_true;
   add_strip_symbol (optarg);
   break;
 case 'N':
   if (keep_symbols)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: Can not specify both -K and -N\n",
         program_name);
       strip_usage (
                   (__acrt_iob_func(2))
                         , 1);
     }
   add_strip_symbol (optarg);
   break;
 case 'x':
   discard_locals = locals_all;
   break;
 case 'X':
   discard_locals = locals_start_L;
   break;
 case 'v':
   verbose = cxx_true;
   break;
 case 'V':
   show_version = cxx_true;
   break;
 case 0:
   break;
 case 'h':
   strip_usage (
               (__acrt_iob_func(1))
                     , 0);
 default:
   strip_usage (
               (__acrt_iob_func(2))
                     , 1);
 }
    }

  if (show_version)
    {
      printf ("GNU %s version %s\n", program_name, program_version);
      exit (0);
    }


  if (strip_symbols == strip_undef
      && discard_locals == locals_undef
      && strip_specific_list == 
                               ((void *)0)
                                   )
    strip_symbols = strip_all;

  if (output_target == (char *) 
                               ((void *)0)
                                   )
    output_target = input_target;

  i = optind;
  if (i == argc)
    strip_usage (
                (__acrt_iob_func(2))
                      , 1);

  for (; i < argc; i++)
    {
      int hold_status = status;

      char *tmpname = make_tempname (argv[i]);
      status = 0;
      copy_file (argv[i], tmpname, input_target, output_target);
      if (status == 0)
 {
   smart_rename (tmpname, argv[i]);
   status = hold_status;
 }
      else
 unlink (tmpname);
      free (tmpname);
    }

  return 0;
}

static int
copy_main(int argc, char **argv) asm("_copy_main");
static int
copy_main(int argc, char **argv)
{
  char *input_filename = 
                        ((void *)0)
                            , *output_filename = 
                                                 ((void *)0)
                                                     ;
  char *input_target = 
                      ((void *)0)
                          , *output_target = 
                                             ((void *)0)
                                                 ;
  boolean show_version = cxx_false;
  boolean adjust_warn = cxx_true;
  int c;
  struct n64_tag_section_list *p;

  while ((c = getopt_long (argc, argv, "b:i:I:K:N:s:O:d:F:R:SgxXVv",
      copy_options, (int *) 0)) != 
                                  (-1)
                                     )
    {
      switch (c)
 {
 case 'b':
   copy_byte = atoi(optarg);
   if (copy_byte < 0)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: byte number must be non-negative\n",
         program_name);
       exit (1);
     }
   break;
 case 'i':
   interleave = atoi(optarg);
   if (interleave < 1)
     {
       fprintf(
              (__acrt_iob_func(2))
                    , "%s: interleave must be positive\n",
        program_name);
       exit (1);
     }
   break;
 case 'I':
 case 's':
   input_target = optarg;
   break;
 case 'O':
 case 'd':
   output_target = optarg;
   break;
 case 'F':
   input_target = output_target = optarg;
   break;
 case 'R':
   p = find_section_list (optarg, cxx_true);
   p->remove = cxx_true;
   sections_removed = cxx_true;
   break;
 case 'S':
   strip_symbols = strip_all;
   break;
 case 'g':
   strip_symbols = strip_debug;
   break;
 case ((((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1):
   strip_symbols = strip_unneeded;
   break;
 case 'K':
   if (! keep_symbols && strip_specific_list != 
                                               ((void *)0)
                                                   )
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: Can not specify both -K and -N\n",
         program_name);
       strip_usage (
                   (__acrt_iob_func(2))
                         , 1);
     }
   keep_symbols = cxx_true;
   add_strip_symbol (optarg);
   break;
 case 'N':
   if (keep_symbols)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: Can not specify both -K and -N\n",
         program_name);
       strip_usage (
                   (__acrt_iob_func(2))
                         , 1);
     }
   add_strip_symbol (optarg);
   break;
 case 'x':
   discard_locals = locals_all;
   break;
 case 'X':
   discard_locals = locals_start_L;
   break;
 case 'v':
   verbose = cxx_true;
   break;
 case 'V':
   show_version = cxx_true;
   break;
 case 150:
   {
     const char *s;
     struct stat st;
     struct n64_tag_section_add *pa;
     int len;
     char *name;
     FILE *f;

     s = strchr (optarg, '=');
     if (s == 
             ((void *)0)
                 )
       {
  fprintf (
          (__acrt_iob_func(2))
                ,
    "%s: bad format for --add-section NAME=FILENAME\n",
    program_name);
  exit (1);
       }

     if (stat (s + 1, &st) < 0)
       {
  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", program_name);
  perror (s + 1);
  exit (1);
       }

     pa = (struct n64_tag_section_add *) xmalloc (sizeof (struct n64_tag_section_add));

     len = s - optarg;
     name = (char *) xmalloc (len + 1);
     strncpy (name, optarg, len);
     name[len] = '\0';
     pa->name = name;

     pa->filename = s + 1;

     pa->size = st.st_size;

     pa->contents = (bfd_byte *) xmalloc (pa->size);
     f = fopen (pa->filename, "rb");
     if (f == 
             ((void *)0)
                 )
       {
  fprintf (
          (__acrt_iob_func(2))
                , "%s: ", program_name);
  perror (pa->filename);
  exit (1);
       }
     if (fread (pa->contents, 1, pa->size, f) == 0
  || ferror (f))
       {
  fprintf (
          (__acrt_iob_func(2))
                , "%s: %s: fread failed\n",
    program_name, pa->filename);
  exit (1);
       }
     fclose (f);

     pa->next = add_sections;
     add_sections = pa;
   }
   break;
 case (150 + 1):
   adjust_start = parse_vma (optarg, "--adjust-start");
   break;
 case (((150 + 1) + 1) + 1):
   {
     const char *s;
     int len;
     char *name;

     s = strchr (optarg, '=');
     if (s == 
             ((void *)0)
                 )
       {
  s = strchr (optarg, '+');
  if (s == 
          ((void *)0)
              )
    {
      s = strchr (optarg, '-');
      if (s == 
              ((void *)0)
                  )
        {
   fprintf (
           (__acrt_iob_func(2))
                 ,
     "%s: bad format for --adjust-section-vma\n",
     program_name);
   exit (1);
        }
    }
       }

     len = s - optarg;
     name = (char *) xmalloc (len + 1);
     strncpy (name, optarg, len);
     name[len] = '\0';

     p = find_section_list (name, cxx_true);

     p->val = parse_vma (s + 1, "--adjust-section-vma");

     if (*s == '=')
       p->adjust = set_vma;
     else
       {
  p->adjust = adjust_vma;
  if (*s == '-')
    p->val = - p->val;
       }
   }
   break;
 case ((150 + 1) + 1):
   adjust_section_vma = parse_vma (optarg, "--adjust-vma");
   adjust_start = adjust_section_vma;
   break;
 case ((((150 + 1) + 1) + 1) + 1):
   adjust_warn = cxx_true;
   break;
 case (((((150 + 1) + 1) + 1) + 1) + 1):
   {
     bfd_vma gap_fill_vma;

     gap_fill_vma = parse_vma (optarg, "--gap-fill");
     gap_fill = (bfd_byte) gap_fill_vma;
     if ((bfd_vma) gap_fill != gap_fill_vma)
       {
  fprintf (
          (__acrt_iob_func(2))
                , "%s: warning: truncating gap-fill from 0x",
    program_name);
  fprintf(
 (__acrt_iob_func(2))
 , "%08lx", gap_fill_vma);
  fprintf (
          (__acrt_iob_func(2))
                , "to 0x%x\n", (unsigned int) gap_fill);
       }
     gap_fill_set = cxx_true;
   }
   break;
 case ((((((150 + 1) + 1) + 1) + 1) + 1) + 1):
   adjust_warn = cxx_false;
   break;
 case (((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1):
   pad_to = parse_vma (optarg, "--pad-to");
   pad_to_set = cxx_true;
   break;
 case ((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1):
   {
     const char *s;
     int len;
     char *name;

     s = strchr (optarg, '=');
     if (s == 
             ((void *)0)
                 )
       {
  fprintf (
          (__acrt_iob_func(2))
                , "%s: bad format for --set-section-flags\n",
    program_name);
  exit (1);
       }

     len = s - optarg;
     name = (char *) xmalloc (len + 1);
     strncpy (name, optarg, len);
     name[len] = '\0';

     p = find_section_list (name, cxx_true);

     p->set_flags = cxx_true;
     p->flags = parse_flags (s + 1);
   }
   break;
 case (((((((((150 + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1):
   set_start = parse_vma (optarg, "--set-start");
   set_start_set = cxx_true;
   break;
 case 0:
   break;
 case 'h':
   copy_usage (
              (__acrt_iob_func(1))
                    , 0);
 default:
   copy_usage (
              (__acrt_iob_func(2))
                    , 1);
 }
    }

  if (show_version)
    {
      printf ("GNU %s version %s\n", program_name, program_version);
      exit (0);
    }

  if (copy_byte >= interleave)
    {
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: byte number must be less than interleave\n",
        program_name);
      exit (1);
    }

  if (optind == argc || optind + 2 < argc)
    copy_usage (
               (__acrt_iob_func(2))
                     , 1);

  input_filename = argv[optind];
  if (optind + 1 < argc)
    output_filename = argv[optind + 1];


  if (strip_symbols == strip_undef && discard_locals == locals_undef)
    strip_symbols = strip_none;

  if (output_target == (char *) 
                               ((void *)0)
                                   )
    output_target = input_target;




  if (output_filename == (char *) 
                                 ((void *)0)
                                     )
    {
      char *tmpname = make_tempname (input_filename);
      copy_file (input_filename, tmpname, input_target, output_target);
      if (status == 0)
 smart_rename (tmpname, input_filename);
      else
 unlink (tmpname);
    }
  else
    {
      copy_file (input_filename, output_filename, input_target, output_target);
    }

  if (adjust_warn)
    {
      for (p = adjust_sections; p != 
                                    ((void *)0)
                                        ; p = p->next)
 {
   if (! p->used && p->adjust != ignore_vma)
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "%s: warning: --adjust-section-vma %s%c0x",
         program_name, p->name,
         p->adjust == set_vma ? '=' : '+');
       fprintf(
      (__acrt_iob_func(2))
      , "%08lx", p->val);
       fprintf (
               (__acrt_iob_func(2))
                     , " never used\n");
     }
 }
    }

  return 0;
}

int
main(int argc, char **argv) asm("_main");
int
main(int argc, char **argv)
{
  program_name = argv[0];
  xmalloc_set_program_name (program_name);

  ;

  strip_symbols = strip_undef;
  discard_locals = locals_undef;

  bfd_init ();

  if (is_strip < 0)
    {
      int i = strlen (program_name);
      is_strip = (i >= 5 && strcmp (program_name + i - 5, "strip") == 0);
    }

  if (is_strip)
    strip_main (argc, argv);
  else
    copy_main (argc, argv);

  ;

  return status;
}

