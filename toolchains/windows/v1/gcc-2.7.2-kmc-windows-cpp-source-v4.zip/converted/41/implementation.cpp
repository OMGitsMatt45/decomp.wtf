// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/flow.c
/* Data flow analysis for GNU compiler.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int simplejump_p(...) asm("_simplejump_p");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int volatile_refs_p(...) asm("_volatile_refs_p");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int side_effects_p(...) asm("_side_effects_p");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int dead_or_set_regno_p(...) asm("_dead_or_set_regno_p");
struct n64_tag__obstack_chunk;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sometimes;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;


struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");




extern rtx forced_labels;







static int max_uid_for_flow;







static int *uid_block_number;




static char *uid_volatile;



int n_basic_blocks;



int max_regno;



int max_scratch;



static int num_scratch;
int *reg_basic_block;






int *reg_n_refs;





char *reg_changes_size;





short *reg_n_deaths;





int *reg_n_calls_crossed;
int *reg_live_length;





static rtx *reg_next_use;




int regset_bytes;
int regset_size;




rtx *basic_block_head;




rtx *basic_block_end;





regset *basic_block_live_at_start;



regset regs_live_at_setjmp;





rtx regs_may_share;




static char *basic_block_drops_in;




static short *basic_block_loop_depth;




static char *block_live_static;




static int loop_depth;



static int cc0_live;




static rtx last_mem_set;




static HARD_REG_SET elim_reg_set;


static void find_basic_blocks (rtx, rtx) asm("_find_basic_blocks");
static int uses_reg_or_mem (rtx) asm("_uses_reg_or_mem");
static void mark_label_ref (rtx, rtx, int) asm("_mark_label_ref");
static void life_analysis (rtx, int) asm("_life_analysis");
void allocate_for_life_analysis (void) asm("_allocate_for_life_analysis");
static void init_regset_vector (regset *, regset, int, int) asm("_init_regset_vector");
static void propagate_block (regset, rtx, rtx, int, regset, int) asm("_propagate_block")
                         ;
static rtx flow_delete_insn (rtx) asm("_flow_delete_insn");
static int insn_dead_p (rtx, regset, int) asm("_insn_dead_p");
static int libcall_dead_p (rtx, regset, rtx, rtx) asm("_libcall_dead_p");
static void mark_set_regs (regset, regset, rtx, rtx, regset) asm("_mark_set_regs")
                         ;
static void mark_set_1 (regset, regset, rtx, rtx, regset) asm("_mark_set_1")
                         ;
static void find_auto_inc (regset, rtx, rtx) asm("_find_auto_inc");
static void mark_used_regs (regset, regset, rtx, int, rtx) asm("_mark_used_regs");
static int try_pre_increment_1 (rtx) asm("_try_pre_increment_1");
static int try_pre_increment (rtx, rtx, int) asm("_try_pre_increment");
static rtx find_use_as_address (rtx, rtx, int) asm("_find_use_as_address");
void dump_flow_info (FILE *) asm("_dump_flow_info");





void
flow_analysis(rtx f, int nregs, FILE *file) asm("_flow_analysis");
void
flow_analysis(rtx f, int nregs, FILE *file)
{
  register rtx insn;
  register int i;
  rtx nonlocal_label_list = nonlocal_label_rtx_list ();


  static struct {int from, to; } eliminables[] = {{ 0, (0 + 29)}, { 0, (0 + 30)}, { (0 + 30), (0 + 29)}};





  do { register HARD_REG_ELT_TYPE *scan_tp_ = (elim_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);


  for (i = 0; i < sizeof eliminables / sizeof eliminables[0]; i++)
    ((elim_reg_set)[(eliminables[i].from) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((eliminables[i].from) % ((unsigned) 32)));






  {
    register n64_enum_rtx_code prev_code = JUMP_INSN;
    register n64_enum_rtx_code code;

    max_uid_for_flow = 0;

    for (insn = f, i = 0; insn; insn = ((insn)->fld[2].rtx))
      {
 code = ((insn)->code);
 if (((insn)->fld[0].rtint) > max_uid_for_flow)
   max_uid_for_flow = ((insn)->fld[0].rtint);
 if (code == CODE_LABEL
     || ((rtx_class[(int)(code)]) == 'i'
  && (prev_code == JUMP_INSN
      || (prev_code == CALL_INSN
   && nonlocal_label_list != 0)
      || prev_code == BARRIER)))
   i++;
 if (code != NOTE)
   prev_code = code;
      }
  }
  n_basic_blocks = i;
  basic_block_head = (rtx *) oballoc (n_basic_blocks * sizeof (rtx));
  basic_block_end = (rtx *) oballoc (n_basic_blocks * sizeof (rtx));
  basic_block_drops_in = (char *) 
                                 __builtin_alloca((
                                 n_basic_blocks
                                 ))
                                                        ;
  basic_block_loop_depth = (short *) 
                                    __builtin_alloca((
                                    n_basic_blocks * sizeof (short)
                                    ))
                                                                            ;
  uid_block_number
    = (int *) 
             __builtin_alloca((
             (max_uid_for_flow + 1) * sizeof (int)
             ))
                                                           ;
  uid_volatile = (char *) 
                         __builtin_alloca((
                         max_uid_for_flow + 1
                         ))
                                                      ;
  memset (uid_volatile,0,max_uid_for_flow + 1);

  find_basic_blocks (f, nonlocal_label_list);
  life_analysis (f, nregs);
  if (file)
    dump_flow_info (file);

  basic_block_drops_in = 0;
  uid_block_number = 0;
  basic_block_loop_depth = 0;
}
static void
find_basic_blocks(rtx f, rtx nonlocal_label_list) asm("_find_basic_blocks");
static void
find_basic_blocks(rtx f, rtx nonlocal_label_list)
{
  register rtx insn;
  register int i;
  register char *block_live = (char *) 
                                      __builtin_alloca((
                                      n_basic_blocks
                                      ))
                                                             ;
  register char *block_marked = (char *) 
                                        __builtin_alloca((
                                        n_basic_blocks
                                        ))
                                                               ;


  rtx label_value_list;
  rtx x, note;
  n64_enum_rtx_code prev_code, code;
  int depth, pass;

  pass = 1;
 restart:

  label_value_list = 0;
  block_live_static = block_live;
  memset (block_live,0,n_basic_blocks);
  memset (block_marked,0,n_basic_blocks);


  if (n_basic_blocks > 0)
    block_live[0] = 1;






  for (insn = f, i = -1, prev_code = JUMP_INSN, depth = 1;
       insn; insn = ((insn)->fld[2].rtx))
    {
      code = ((insn)->code);
      if (code == NOTE)
 {
   if (((insn)->fld[4].rtint) == -4)
     depth++;
   else if (((insn)->fld[4].rtint) == -5)
     depth--;
 }


      else if (code == CODE_LABEL
        || ((rtx_class[(int)(code)]) == 'i'
     && (prev_code == JUMP_INSN
         || (prev_code == CALL_INSN
      && nonlocal_label_list != 0)
         || prev_code == BARRIER)))
 {
   basic_block_head[++i] = insn;
   basic_block_end[i] = insn;
   basic_block_loop_depth[i] = depth;

   if (code == CODE_LABEL)
     {
  ((insn)->fld[5].rtx) = insn;


  if (((insn)->in_struct))
    block_live[i] = 1;
       }
 }

      else if ((rtx_class[(int)(code)]) == 'i')
 {
   basic_block_end[i] = insn;
   basic_block_loop_depth[i] = depth;
 }

      if ((rtx_class[(int)(code)]) == 'i')
 {

   for (note = ((insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
     if (((n64_enum_reg_note) ((note)->mode)) == REG_LABEL)
       label_value_list = gen_rtx (EXPR_LIST, VOIDmode, ((note)->fld[0].rtx),
       label_value_list);
 }

      uid_block_number[((insn)->fld[0].rtint)] = i;

      if (code != NOTE)
 prev_code = code;
    }




  if (pass == 1 && i + 1 != n_basic_blocks)
    abort ();
  n_basic_blocks = i + 1;




  for (x = label_value_list; x; x = ((x)->fld[1].rtx))
    if (! ((x)->volatil))
      block_live[uid_block_number[((((x)->fld[0].rtx))->fld[0].rtint)]] = 1;

  for (x = forced_labels; x; x = ((x)->fld[1].rtx))
    if (! ((x)->volatil))
      block_live[uid_block_number[((((x)->fld[0].rtx))->fld[0].rtint)]] = 1;



  for (i = 0; i < n_basic_blocks; i++)
    {
      for (insn = ((basic_block_head[i])->fld[1].rtx);
    insn && ((insn)->code) == NOTE; insn = ((insn)->fld[1].rtx))
 ;

      basic_block_drops_in[i] = insn && ((insn)->code) != BARRIER;
    }





  if (n_basic_blocks > 0)
    {
      int something_marked = 1;
      int deleted;
      for (insn = f; insn; insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == JUMP_INSN)
   {
     rtx pat = ((insn)->fld[3].rtx);
     int computed_jump = 0;

     if (((pat)->code) == PARALLEL)
       {
  int len = ((pat)->fld[0].rtvec->num_elem);
  int has_use_labelref = 0;

  for (i = len - 1; i >= 0; i--)
    if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) == USE
        && (((((((pat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))->code)
     == LABEL_REF))
      has_use_labelref = 1;

  if (! has_use_labelref)
    for (i = len - 1; i >= 0; i--)
      if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) == SET
   && ((((pat)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx) == pc_rtx
   && uses_reg_or_mem (((((pat)->fld[0].rtvec->elem[i].rtx))->fld[1].rtx)))
        computed_jump = 1;
       }
     else if (((pat)->code) == SET
       && ((pat)->fld[0].rtx) == pc_rtx
       && uses_reg_or_mem (((pat)->fld[1].rtx)))
       computed_jump = 1;

     if (computed_jump)
       {
  for (x = label_value_list; x; x = ((x)->fld[1].rtx))
    mark_label_ref (gen_rtx (LABEL_REF, VOIDmode, ((x)->fld[0].rtx)),
      insn, 0);

  for (x = forced_labels; x; x = ((x)->fld[1].rtx))
    mark_label_ref (gen_rtx (LABEL_REF, VOIDmode, ((x)->fld[0].rtx)),
         insn, 0);
       }
   }




      for (insn = f; insn; insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == CALL_INSN)
   {
     for (x = nonlocal_label_list; x; x = ((x)->fld[1].rtx))
       mark_label_ref (gen_rtx (LABEL_REF, VOIDmode, ((x)->fld[0].rtx)),
         insn, 0);
   }







      while (something_marked)
 {
   something_marked = 0;
   for (i = 0; i < n_basic_blocks; i++)
     if (block_live[i] && !block_marked[i])
       {
  block_marked[i] = 1;
  something_marked = 1;
  if (i + 1 < n_basic_blocks && basic_block_drops_in[i + 1])
    block_live[i + 1] = 1;
  insn = basic_block_end[i];
  if (((insn)->code) == JUMP_INSN)
    mark_label_ref (((insn)->fld[3].rtx), insn, 0);
       }
 }
      for (i = 1; i < n_basic_blocks; i++)
 if (block_live[i] && ! basic_block_drops_in[i]
     && ((basic_block_head[i])->code) == CODE_LABEL
     && ((basic_block_head[i])->fld[5].rtx) == basic_block_head[i])
   basic_block_drops_in[i] = 1;





      deleted = 0;
      for (i = 0; i < n_basic_blocks; i++)
 if (!block_live[i])
   {
     deleted++;
     if (basic_block_head[i] != basic_block_end[i])
       {



  insn = ((basic_block_head[i])->fld[2].rtx);
  while (insn != basic_block_end[i])
    {
      if (((insn)->code) == BARRIER)
        abort ();
      else if (((insn)->code) != NOTE)
        insn = flow_delete_insn (insn);
      else
        insn = ((insn)->fld[2].rtx);
    }
       }
     insn = basic_block_head[i];
     if (((insn)->code) != NOTE)
       {

  if (((insn)->code) == BARRIER)
    abort ();
  ((insn)->code = (NOTE));
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[3].rtstr) = 0;
       }
     insn = basic_block_end[i];
     if (((insn)->code) != NOTE)
       {

  if (((insn)->code) == BARRIER)
    abort ();
  ((insn)->code = (NOTE));
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[3].rtstr) = 0;
       }





     if (((insn)->fld[2].rtx) != 0
  && ((((insn)->fld[2].rtx))->code) == BARRIER)
       delete_insn (((insn)->fld[2].rtx));





     if (block_live[i - 1])
       {
  register int j;
  for (j = i + 1; j < n_basic_blocks; j++)
    if (block_live[j])
      {
        rtx label;
        insn = basic_block_end[i - 1];
        if (((insn)->code) == JUMP_INSN



     && simplejump_p (insn)
     && (label = ((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx), 1)
     && ((label)->fld[0].rtint) != 0
     && uid_block_number[((label)->fld[0].rtint)] == j)
   {
     ((insn)->code = (NOTE));
     ((insn)->fld[4].rtint) = -1;
     ((insn)->fld[3].rtstr) = 0;
     if (((((insn)->fld[2].rtx))->code) != BARRIER)
       abort ();
     delete_insn (((insn)->fld[2].rtx));
   }
        break;
      }
       }
   }
      if (pass == 1
   && deleted > 200)
 {
   pass++;
   n_basic_blocks -= deleted;




   goto restart;
 }
    }
}





static int
uses_reg_or_mem(rtx x) asm("_uses_reg_or_mem");
static int
uses_reg_or_mem(rtx x)
{
  n64_enum_rtx_code code = ((x)->code);
  int i, j;
  char *fmt;

  if (code == REG
      || (code == MEM
   && ! (((((x)->fld[0].rtx))->code) == SYMBOL_REF
  && ((((x)->fld[0].rtx))->unchanging))))
    return 1;

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e'
   && uses_reg_or_mem (((x)->fld[i].rtx)))
 return 1;

      if (fmt[i] == 'E')
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   if (uses_reg_or_mem (((x)->fld[i].rtvec->elem[j].rtx)))
     return 1;
    }

  return 0;
}
static void
mark_label_ref(rtx x, rtx insn, int checkdup) asm("_mark_label_ref");
static void
mark_label_ref(rtx x, rtx insn, int checkdup)
{
  register n64_enum_rtx_code code;
  register int i;
  register char *fmt;


  if (x == 0)
    return;

  code = ((x)->code);
  if (code == LABEL_REF)
    {
      register rtx label = ((x)->fld[0].rtx);
      register rtx y;
      if (((label)->code) != CODE_LABEL)
 abort ();




      if (((label)->fld[0].rtint) == 0)
 return;
      ((x)->fld[2].rtx) = insn;


      if (checkdup)
 for (y = ((label)->fld[5].rtx); y != label; y = ((y)->fld[1].rtx))
   if (((y)->fld[2].rtx) == insn)
     return;
      ((x)->fld[1].rtx) = ((label)->fld[5].rtx);
      ((label)->fld[5].rtx) = x;
      block_live_static[uid_block_number[((label)->fld[0].rtint)]] = 1;
      return;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 mark_label_ref (((x)->fld[i].rtx), insn, 0);
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     mark_label_ref (((x)->fld[i].rtvec->elem[j].rtx), insn, 1);
 }
    }
}




static rtx
flow_delete_insn(rtx insn) asm("_flow_delete_insn");
static rtx
flow_delete_insn(rtx insn)
{


  ((((insn)->fld[1].rtx))->fld[2].rtx) = ((insn)->fld[2].rtx);
  ((((insn)->fld[2].rtx))->fld[1].rtx) = ((insn)->fld[1].rtx);
  return ((insn)->fld[2].rtx);
}
static void
life_analysis(rtx f, int nregs) asm("_life_analysis");
static void
life_analysis(rtx f, int nregs)
{
  register regset tem;
  int first_pass;
  int changed;


  regset *basic_block_live_at_end;




  regset *basic_block_new_live_at_end;





  regset *basic_block_significant;
  register int i;
  rtx insn;

  struct n64_tag_obstack flow_obstack;

  gcc_obstack_init (&flow_obstack);

  max_regno = nregs;

  memset (regs_ever_live,0,sizeof regs_ever_live);




  allocate_for_life_analysis ();

  reg_next_use = (rtx *) 
                        __builtin_alloca((
                        nregs * sizeof (rtx)
                        ))
                                                     ;
  memset ((char *) reg_next_use,0,nregs * sizeof (rtx));




  basic_block_live_at_end
    = (regset *) 
                __builtin_alloca((
                n_basic_blocks * sizeof (regset)
                ))
                                                         ;





  tem = (regset) __extension__ ({ struct n64_tag_obstack *__h = (&flow_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((n_basic_blocks * regset_bytes)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  memset ((char *) tem,0,n_basic_blocks * regset_bytes);
  init_regset_vector (basic_block_live_at_end, tem,
        n_basic_blocks, regset_bytes);

  basic_block_new_live_at_end
    = (regset *) 
                __builtin_alloca((
                n_basic_blocks * sizeof (regset)
                ))
                                                         ;
  tem = (regset) __extension__ ({ struct n64_tag_obstack *__h = (&flow_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((n_basic_blocks * regset_bytes)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  memset ((char *) tem,0,n_basic_blocks * regset_bytes);
  init_regset_vector (basic_block_new_live_at_end, tem,
        n_basic_blocks, regset_bytes);

  basic_block_significant
    = (regset *) 
                __builtin_alloca((
                n_basic_blocks * sizeof (regset)
                ))
                                                         ;
  tem = (regset) __extension__ ({ struct n64_tag_obstack *__h = (&flow_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((n_basic_blocks * regset_bytes)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  memset ((char *) tem,0,n_basic_blocks * regset_bytes);
  init_regset_vector (basic_block_significant, tem,
        n_basic_blocks, regset_bytes);





  for (insn = f; insn; insn = ((insn)->fld[2].rtx))
    {
      n64_enum_rtx_code code1 = ((insn)->code);
      if (code1 == CALL_INSN)
 uid_volatile[((insn)->fld[0].rtint)] = 1;
      else if (code1 == INSN || code1 == JUMP_INSN)
 {

   if (((((insn)->fld[3].rtx))->code) == SET
       && ((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == REG
       && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == REG
       && ((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtint) ==
   ((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtint)

       && ! find_reg_note (insn, REG_EQUAL, (rtx) 0))
     {
       ((insn)->code = (NOTE));
       ((insn)->fld[4].rtint) = -1;
       ((insn)->fld[3].rtstr) = 0;
     }
   else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
     {


       for (i = 0; i < ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem); i++)
  {
    rtx tem = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);

    if (((tem)->code) == USE
        || ((tem)->code) == CLOBBER)
      continue;

    if (((tem)->code) != SET
        || ((((tem)->fld[0].rtx))->code) != REG
        || ((((tem)->fld[1].rtx))->code) != REG
        || ((((tem)->fld[0].rtx))->fld[0].rtint) != ((((tem)->fld[1].rtx))->fld[0].rtint))
      break;
  }

       if (i == ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem)

    && ! find_reg_note (insn, REG_EQUAL, (rtx) 0))
  {
    ((insn)->code = (NOTE));
    ((insn)->fld[4].rtint) = -1;
    ((insn)->fld[3].rtstr) = 0;
  }
       else
  uid_volatile[((insn)->fld[0].rtint)] = volatile_refs_p (((insn)->fld[3].rtx));
     }
   else if (((((insn)->fld[3].rtx))->code) != USE)
     uid_volatile[((insn)->fld[0].rtint)] = volatile_refs_p (((insn)->fld[3].rtx));






   else if (code1 == INSN && ((((insn)->fld[3].rtx))->code) == SET
     && ((((insn)->fld[3].rtx))->fld[0].rtx) == stack_pointer_rtx

     && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == MINUS



     && ((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx) == stack_pointer_rtx)
     uid_volatile[((insn)->fld[0].rtint)] = 1;
 }
    }

  if (n_basic_blocks > 0)

    if (! 1
 || (! (current_function_calls_alloca) && flag_omit_frame_pointer))

      {


 basic_block_live_at_end[n_basic_blocks - 1]
   [(0 + 29) / 32]
     |= (unsigned int) 1 << ((0 + 29) % 32);
 basic_block_new_live_at_end[n_basic_blocks - 1]
   [(0 + 29) / 32]
     |= (unsigned int) 1 << ((0 + 29) % 32);
      }





  if (n_basic_blocks > 0)
    {
      basic_block_live_at_end[n_basic_blocks - 1]
 [(0 + 30) / 32]
   |= (unsigned int) 1 << ((0 + 30) % 32);
      basic_block_new_live_at_end[n_basic_blocks - 1]
 [(0 + 30) / 32]
   |= (unsigned int) 1 << ((0 + 30) % 32);
      }




  if (n_basic_blocks > 0)
    for (i = 0; i < 68; i++)
      if (global_regs[i])
 {
   basic_block_live_at_end[n_basic_blocks - 1]
     [i / 32]
       |= (unsigned int) 1 << (i % 32);
   basic_block_new_live_at_end[n_basic_blocks - 1]
     [i / 32]
       |= (unsigned int) 1 << (i % 32);
 }
  first_pass = 1;
  changed = 1;
  while (changed)
    {
      changed = 0;
      for (i = n_basic_blocks - 1; i >= 0; i--)
 {
   int consider = first_pass;
   int must_rescan = first_pass;
   register int j;

   if (!first_pass)
     {
       for (j = 0; j < regset_size; j++)
  {
    register unsigned int x
      = (basic_block_new_live_at_end[i][j]
         & ~basic_block_live_at_end[i][j]);
    if (x)
      consider = 1;
    if (x & basic_block_significant[i][j])
      {
        must_rescan = 1;
        consider = 1;
        break;
      }
  }

       if (! consider)
  continue;
     }



   changed = 1;

   if (! must_rescan)
     {



       for (j = 0; j < regset_size; j++)
  {
    register unsigned int x
      = (basic_block_new_live_at_end[i][j]
         & ~basic_block_live_at_end[i][j]);
    basic_block_live_at_start[i][j] |= x;
    basic_block_live_at_end[i][j] |= x;
  }
     }
   else
     {


       memcpy ((char *) basic_block_live_at_end[i],(char *) basic_block_new_live_at_end[i],regset_bytes)
                                                         ;
       memcpy ((char *) basic_block_live_at_start[i],(char *) basic_block_live_at_end[i],regset_bytes)
                                                           ;
       propagate_block (basic_block_live_at_start[i],
          basic_block_head[i], basic_block_end[i], 0,
          first_pass ? basic_block_significant[i]
          : (regset) 0,
          i);
     }

   {
     register rtx jump, head;



     head = basic_block_head[i];
     if (basic_block_drops_in[i])
       {
  register int j;
  for (j = 0; j < regset_size; j++)
    basic_block_new_live_at_end[i-1][j]
      |= basic_block_live_at_start[i][j];
       }



     if (((head)->code) == CODE_LABEL)
       for (jump = ((head)->fld[5].rtx);
     jump != head;
     jump = ((jump)->fld[1].rtx))
  {
    register int from_block = uid_block_number[((((jump)->fld[2].rtx))->fld[0].rtint)];
    register int j;
    for (j = 0; j < regset_size; j++)
      basic_block_new_live_at_end[from_block][j]
        |= basic_block_live_at_start[i][j];
  }
   }



 }
      first_pass = 0;
    }






  if (n_basic_blocks > 0)
    for (i = 68; i < max_regno; i++)
      if (basic_block_live_at_start[0][i / 32]
   & ((unsigned int) 1 << (i % 32)))
 reg_basic_block[i] = -2;
  max_scratch = 0;

  for (i = 0; i < n_basic_blocks; i++)
    {
      propagate_block (basic_block_live_at_end[i],
         basic_block_head[i], basic_block_end[i], 1,
         (regset) 0, i);



    }
  for (i = 68; i < nregs; i++)
    if ((regs_live_at_setjmp[i / 32]
  & ((unsigned int) 1 << (i % 32)))
 && regno_reg_rtx[i] != 0)
      {
 reg_live_length[i] = -1;
 reg_basic_block[i] = -1;
      }

  __extension__ ({ struct n64_tag_obstack *__o = (&flow_obstack); void *__obj = (((void *)0)); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
}






void
allocate_for_life_analysis(void) asm("_allocate_for_life_analysis");
void
allocate_for_life_analysis(void)
{
  register int i;
  register regset tem;

  regset_size = ((max_regno + 32 - 1) / 32);
  regset_bytes = regset_size * sizeof (*(regset)0);

  reg_n_refs = (int *) oballoc (max_regno * sizeof (int));
  memset ((char *) reg_n_refs,0,max_regno * sizeof (int));

  reg_n_sets = (short *) oballoc (max_regno * sizeof (short));
  memset ((char *) reg_n_sets,0,max_regno * sizeof (short));

  reg_n_deaths = (short *) oballoc (max_regno * sizeof (short));
  memset ((char *) reg_n_deaths,0,max_regno * sizeof (short));

  reg_changes_size = (char *) oballoc (max_regno * sizeof (char));
  memset (reg_changes_size,0,max_regno * sizeof (char));;

  reg_live_length = (int *) oballoc (max_regno * sizeof (int));
  memset ((char *) reg_live_length,0,max_regno * sizeof (int));

  reg_n_calls_crossed = (int *) oballoc (max_regno * sizeof (int));
  memset ((char *) reg_n_calls_crossed,0,max_regno * sizeof (int));

  reg_basic_block = (int *) oballoc (max_regno * sizeof (int));
  for (i = 0; i < max_regno; i++)
    reg_basic_block[i] = -1;

  basic_block_live_at_start
    = (regset *) oballoc (n_basic_blocks * sizeof (regset));
  tem = (regset) oballoc (n_basic_blocks * regset_bytes);
  memset ((char *) tem,0,n_basic_blocks * regset_bytes);
  init_regset_vector (basic_block_live_at_start, tem,
        n_basic_blocks, regset_bytes);

  regs_live_at_setjmp = (regset) oballoc (regset_bytes);
  memset ((char *) regs_live_at_setjmp,0,regset_bytes);
}






static void
init_regset_vector(regset *vector, regset space, int nelts, int bytes_per_elt) asm("_init_regset_vector");
static void
init_regset_vector(regset *vector, regset space, int nelts, int bytes_per_elt)
{
  register int i;
  register regset p = space;

  for (i = 0; i < nelts; i++)
    {
      vector[i] = p;
      p += bytes_per_elt / sizeof (*p);
    }
}
static void
propagate_block(register regset old, rtx first, rtx last, int final, regset significant, int bnum) asm("_propagate_block");
static void
propagate_block(register regset old, rtx first, rtx last, int final, regset significant, int bnum)
{
  register rtx insn;
  rtx prev;
  regset live;
  regset dead;
  register struct n64_tag_sometimes { short offset; short bit; } *regs_sometimes_live;
  int sometimes_max = 0;


  regset maxlive;




  loop_depth = basic_block_loop_depth[bnum];

  dead = (regset) 
                 __builtin_alloca((
                 regset_bytes
                 ))
                                      ;
  live = (regset) 
                 __builtin_alloca((
                 regset_bytes
                 ))
                                      ;

  cc0_live = 0;
  last_mem_set = 0;




  while (((last)->fld[2].rtx) != 0 && ((((last)->fld[2].rtx))->code) == NOTE)
    {

      last = ((last)->fld[2].rtx);
      if (((last)->fld[4].rtint) == -4)
 loop_depth++;
      else if (((last)->fld[4].rtint) == -5)
 loop_depth--;
    }

  if (final)
    {
      register int i, offset;
      unsigned int bit;

      num_scratch = 0;
      maxlive = (regset) 
                        __builtin_alloca((
                        regset_bytes
                        ))
                                             ;
      memcpy ((char *) maxlive,(char *) old,regset_bytes);
      regs_sometimes_live
 = (struct n64_tag_sometimes *) 
                       __builtin_alloca((
                       max_regno * sizeof (struct n64_tag_sometimes)
                       ))
                                                                     ;





      for (offset = 0, i = 0; offset < regset_size; offset++)
 for (bit = 1; bit; bit <<= 1, i++)
   {
     if (i == max_regno)
       break;
     if (old[offset] & bit)
       {
  reg_basic_block[i] = -2;
  regs_sometimes_live[sometimes_max].offset = offset;
  regs_sometimes_live[sometimes_max].bit = i % 32;
  sometimes_max++;
       }
   }
    }



  for (insn = last; ; insn = prev)
    {
      prev = ((insn)->fld[1].rtx);

      if (((insn)->code) == NOTE)
 {


   if (((insn)->fld[4].rtint) == -5)
     loop_depth++;
   else if (((insn)->fld[4].rtint) == -4)
     loop_depth--;



   if (loop_depth == 0)
     abort ();




   if (final && ((insn)->fld[4].rtint) == -7)
     {
       int i;
       for (i = 0; i < regset_size; i++)
  regs_live_at_setjmp[i] |= old[i];
     }
 }
      else if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   register int i;
   rtx note = find_reg_note (insn, REG_RETVAL, (rtx) 0);
   int insn_is_dead
     = (insn_dead_p (((insn)->fld[3].rtx), old, 0)

        && ! uid_volatile[((insn)->fld[0].rtint)]);
   int libcall_is_dead
     = (insn_is_dead && note != 0
        && libcall_dead_p (((insn)->fld[3].rtx), old, note, insn));





   if (final && insn_is_dead)
     {
       ((insn)->code = (NOTE));
       ((insn)->fld[4].rtint) = -1;
       ((insn)->fld[3].rtstr) = 0;




       cc0_live = 0;



       if (libcall_is_dead)
  {
    rtx first = ((note)->fld[0].rtx);
    rtx p = insn;
    while (((first)->volatil))
      first = ((first)->fld[2].rtx);
    while (p != first)
      {
        p = ((p)->fld[1].rtx);
        ((p)->code = (NOTE));
        ((p)->fld[4].rtint) = -1;
        ((p)->fld[3].rtstr) = 0;
      }
  }
       goto flushed;
     }

   for (i = 0; i < regset_size; i++)
     {
       dead[i] = 0;
       live[i] = 0;
     }
   if (libcall_is_dead)
     {

       mark_set_regs (old, dead, ((insn)->fld[3].rtx), (rtx) 0, significant);

       insn = ((note)->fld[0].rtx);
       prev = ((insn)->fld[1].rtx);
     }
   else if (((((insn)->fld[3].rtx))->code) == SET
     && ((((insn)->fld[3].rtx))->fld[0].rtx) == stack_pointer_rtx
     && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == PLUS
     && ((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx) == stack_pointer_rtx
     && ((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT)




     ;
   else
     {




       mark_set_regs (old, dead, ((insn)->fld[3].rtx),
        final ? insn : (rtx) 0, significant);




       cc0_live = 0;

       if (! insn_is_dead)
  mark_used_regs (old, live, ((insn)->fld[3].rtx), final, insn);
       if (! insn_is_dead && ((insn)->code) == CALL_INSN)
  {
    register int i;

    rtx note;

           for (note = ((insn)->fld[7].rtx);
         note;
         note = ((note)->fld[1].rtx))
      if (((((note)->fld[0].rtx))->code) == USE)
        mark_used_regs (old, live, ((((note)->fld[0].rtx))->fld[0].rtx),
          final, insn);






    for (i = 0; i < 68; i++)
      if (call_used_regs[i] && ! global_regs[i])
        dead[i / 32]
   |= ((unsigned int) 1 << (i % 32));


    live[(0 + 29) / 32]
      |= ((unsigned int) 1
   << ((0 + 29) % 32));



    for (i = 0; i < 68; i++)
      if (global_regs[i])
        mark_used_regs (old, live,
          gen_rtx (REG, reg_raw_mode[i], i),
          final, insn);


    last_mem_set = 0;
  }


       for (i = 0; i < regset_size; i++)
  {
    old[i] &= ~dead[i];
    old[i] |= live[i];
  }

       if (((insn)->code) == CALL_INSN && final)
  {




    register struct n64_tag_sometimes *p = regs_sometimes_live;

    for (i = 0; i < sometimes_max; i++, p++)
      if (old[p->offset] & ((unsigned int) 1 << p->bit))
        reg_n_calls_crossed[p->offset * 32 + p->bit]+= 1;
  }
     }





   if (final)
     {
       for (i = 0; i < regset_size; i++)
  {
    register unsigned int diff = live[i] & ~maxlive[i];

    if (diff)
      {
        register int regno;
        maxlive[i] |= diff;
        for (regno = 0; diff && regno < 32; regno++)
   if (diff & ((unsigned int) 1 << regno))
     {
       regs_sometimes_live[sometimes_max].offset = i;
       regs_sometimes_live[sometimes_max].bit = regno;
       diff &= ~ ((unsigned int) 1 << regno);
       sometimes_max++;
     }
      }
  }

       {
  register struct n64_tag_sometimes *p = regs_sometimes_live;
  for (i = 0; i < sometimes_max; i++, p++)
    {
      if (old[p->offset] & ((unsigned int) 1 << p->bit))
        reg_live_length[p->offset * 32 + p->bit]++;
    }
       }
     }
 }
    flushed: ;
      if (insn == first)
 break;
    }

  if (num_scratch > max_scratch)
    max_scratch = num_scratch;
}







static int
insn_dead_p(rtx x, regset needed, int call_ok) asm("_insn_dead_p");
static int
insn_dead_p(rtx x, regset needed, int call_ok)
{
  register n64_enum_rtx_code code = ((x)->code);



  if (code == SET)
    {
      register rtx r = ((x)->fld[0].rtx);

      if (! call_ok && ((((x)->fld[1].rtx))->code) == CALL)
 return 0;






      if (((r)->code) == MEM && last_mem_set && ! ((r)->volatil)
   && rtx_equal_p (r, last_mem_set))
 return 1;

      while (((r)->code) == SUBREG
      || ((r)->code) == STRICT_LOW_PART
      || ((r)->code) == ZERO_EXTRACT
      || ((r)->code) == SIGN_EXTRACT)
 r = ((r)->fld[0].rtx);

      if (((r)->code) == REG)
 {
   register int regno = ((r)->fld[0].rtint);
   register int offset = regno / 32;
   register unsigned int bit
     = (unsigned int) 1 << (regno % 32);


   if ((regno < 68 && global_regs[regno])

       || regno == (0 + 30)







       || (regno == 0 && fixed_regs[regno])

       || (needed[offset] & bit) != 0)
     return 0;



   if (regno < 68)
     {
       int n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((r)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((r)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

       while (--n > 0)
  if ((needed[(regno + n) / 32]
       & ((unsigned int) 1
   << ((regno + n) % 32))) != 0)
    return 0;
     }

   return 1;
 }
    }




  else if (code == PARALLEL)
    {
      register int i = ((x)->fld[0].rtvec->num_elem);
      for (i--; i >= 0; i--)
 {
   rtx elt = ((x)->fld[0].rtvec->elem[i].rtx);
   if (!insn_dead_p (elt, needed, call_ok)
       && ((elt)->code) != CLOBBER
       && ((elt)->code) != USE)
     return 0;
 }
      return 1;
    }



  return 0;
}
static int
libcall_dead_p(rtx x, regset needed, rtx note, rtx insn) asm("_libcall_dead_p");
static int
libcall_dead_p(rtx x, regset needed, rtx note, rtx insn)
{
  register n64_enum_rtx_code code = ((x)->code);

  if (code == SET)
    {
      register rtx r = ((x)->fld[1].rtx);
      if (((r)->code) == REG)
 {
   rtx call = ((note)->fld[0].rtx);
   register int i;


   while (call != insn && ((call)->code) != CALL_INSN)
     call = ((call)->fld[2].rtx);



   if (call == insn)
     return 0;



   call = ((call)->fld[3].rtx);
   if (((call)->code) == PARALLEL)
     {
       for (i = ((call)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
  if (((((call)->fld[0].rtvec->elem[i].rtx))->code) == SET
      && ((((((call)->fld[0].rtvec->elem[i].rtx))->fld[1].rtx))->code) == CALL)
    break;




       if (i < 0)
  return 0;

       call = ((call)->fld[0].rtvec->elem[i].rtx);
     }

   return insn_dead_p (call, needed, 1);
 }
    }
  return 1;
}





int
regno_uninitialized(int regno) asm("_regno_uninitialized");
int
regno_uninitialized(int regno)
{
  if (n_basic_blocks == 0
      || (regno < 68 && global_regs[regno]))
    return 0;

  return (basic_block_live_at_start[0][regno / 32]
   & ((unsigned int) 1 << (regno % 32)));
}





int
regno_clobbered_at_setjmp(int regno) asm("_regno_clobbered_at_setjmp");
int
regno_clobbered_at_setjmp(int regno)
{
  if (n_basic_blocks == 0)
    return 0;

  return ((reg_n_sets[regno] > 1
    || (basic_block_live_at_start[0][regno / 32]
        & ((unsigned int) 1 << (regno % 32))))
   && (regs_live_at_setjmp[regno / 32]
       & ((unsigned int) 1 << (regno % 32))));
}
static void
mark_set_regs(regset needed, regset dead, rtx x, rtx insn, regset significant) asm("_mark_set_regs");
static void
mark_set_regs(regset needed, regset dead, rtx x, rtx insn, regset significant)
{
  register n64_enum_rtx_code code = ((x)->code);

  if (code == SET || code == CLOBBER)
    mark_set_1 (needed, dead, x, insn, significant);
  else if (code == PARALLEL)
    {
      register int i;
      for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   code = ((((x)->fld[0].rtvec->elem[i].rtx))->code);
   if (code == SET || code == CLOBBER)
     mark_set_1 (needed, dead, ((x)->fld[0].rtvec->elem[i].rtx), insn, significant);
 }
    }
}



static void
mark_set_1(regset needed, regset dead, rtx x, rtx insn, regset significant) asm("_mark_set_1");
static void
mark_set_1(regset needed, regset dead, rtx x, rtx insn, regset significant)
{
  register int regno;
  register rtx reg = ((x)->fld[0].rtx);
  while (((reg)->code) == SUBREG || ((reg)->code) == ZERO_EXTRACT
  || ((reg)->code) == SIGN_EXTRACT
  || ((reg)->code) == STRICT_LOW_PART)
    reg = ((reg)->fld[0].rtx);





  if (((reg)->code) == MEM
      || (((reg)->code) == REG
   && last_mem_set != 0 && reg_overlap_mentioned_p (reg, last_mem_set)))
    last_mem_set = 0;

  if (((reg)->code) == MEM && ! side_effects_p (reg)



      && ! reg_mentioned_p (stack_pointer_rtx, reg))
    last_mem_set = reg;

  if (((reg)->code) == REG
      && (regno = ((reg)->fld[0].rtint), regno != (0 + 30))




      && ! (regno == 0 && fixed_regs[regno])

      && ! (regno < 68 && global_regs[regno]))

    {
      register int offset = regno / 32;
      register unsigned int bit
 = (unsigned int) 1 << (regno % 32);
      unsigned int all_needed = (needed[offset] & bit);
      unsigned int some_needed = (needed[offset] & bit);


      if (significant)
 significant[offset] |= bit;


      dead[offset] |= bit;



      if (regno < 68)
 {
   int n;



   if (regno == (0 + 29))
     return;

   n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   while (--n > 0)
     {
       if (significant)
  significant[(regno + n) / 32]
    |= (unsigned int) 1 << ((regno + n) % 32);
       dead[(regno + n) / 32]
  |= (unsigned int) 1 << ((regno + n) % 32);
       some_needed
  |= (needed[(regno + n) / 32]
      & (unsigned int) 1 << ((regno + n) % 32));
       all_needed
  &= (needed[(regno + n) / 32]
      & (unsigned int) 1 << ((regno + n) % 32));
     }
 }

      if (insn)
 {
   register rtx y = reg_next_use[regno];
   register int blocknum = uid_block_number[((insn)->fld[0].rtint)];



   if (regno < 68)
     {
       register int i;
       int endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

       for (i = regno; i < endregno; i++)
  {


    reg_next_use[i] = 0;

    regs_ever_live[i] = 1;
    reg_n_sets[i]++;
  }
     }
   else
     {


       reg_next_use[regno] = 0;



       if (reg_basic_block[regno] == -1)
  reg_basic_block[regno] = blocknum;
       else if (reg_basic_block[regno] != blocknum)
  reg_basic_block[regno] = -2;



       reg_n_sets[regno]++;

       reg_n_refs[regno] += loop_depth;





       reg_live_length[regno]++;
     }

   if (all_needed)
     {
       if (y && (uid_block_number[((y)->fld[0].rtint)] == blocknum)
    && (regno >= 68
        || asm_noperands (((y)->fld[3].rtx)) < 0))
  ((y)->fld[5].rtx)
    = gen_rtx (INSN_LIST, VOIDmode, insn, ((y)->fld[5].rtx));
     }
   else if (! some_needed)
     {




       ((insn)->fld[6].rtx)
  = gen_rtx (EXPR_LIST, REG_UNUSED, reg, ((insn)->fld[6].rtx));
       reg_n_deaths[((reg)->fld[0].rtint)]++;
     }
   else
     {






       int i;

       for (i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1;
     i >= 0; i--)
  if ((needed[(regno + i) / 32]
       & ((unsigned int) 1
   << ((regno + i) % 32))) == 0)
    ((insn)->fld[6].rtx)
      = gen_rtx (EXPR_LIST, REG_UNUSED,
          gen_rtx (REG, reg_raw_mode[regno + i],
     regno + i),
          ((insn)->fld[6].rtx));
     }
 }
    }
  else if (((reg)->code) == REG)
    reg_next_use[regno] = 0;



  else if (((reg)->code) == SCRATCH && insn != 0)
    {
      ((insn)->fld[6].rtx)
 = gen_rtx (EXPR_LIST, REG_UNUSED, reg, ((insn)->fld[6].rtx));
      num_scratch++;
    }
}
static void
mark_used_regs(regset needed, regset live, rtx x, int final, rtx insn) asm("_mark_used_regs");
static void
mark_used_regs(regset needed, regset live, rtx x, int final, rtx insn)
{
  register n64_enum_rtx_code code;
  register int regno;
  int i;

 retry:
  code = ((x)->code);
  switch (code)
    {
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_INT:
    case CONST:
    case CONST_DOUBLE:
    case PC:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case ASM_INPUT:
      return;







    case CLOBBER:


      if (((((x)->fld[0].rtx))->code) == MEM)
 mark_used_regs (needed, live, ((((x)->fld[0].rtx))->fld[0].rtx), final, insn);
      return;

    case MEM:


      last_mem_set = 0;





      break;

    case SUBREG:
      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) >= 68
   && ((mode_size[(int)(((x)->mode))])
       != (mode_size[(int)(((((x)->fld[0].rtx))->mode))])))
 reg_changes_size[((((x)->fld[0].rtx))->fld[0].rtint)] = 1;


      x = ((x)->fld[0].rtx);


      if (((x)->code) != REG)
 {
   mark_used_regs (needed, live, x, final, insn);
   return;
 }



    case REG:



      regno = ((x)->fld[0].rtint);
      {
 register int offset = regno / 32;
 register unsigned int bit
   = (unsigned int) 1 << (regno % 32);
 unsigned int all_needed = needed[offset] & bit;
 unsigned int some_needed = needed[offset] & bit;

 live[offset] |= bit;


 if (regno < 68)
   {
     int n;



     if (regno == (0 + 29)




  || (regno == 0 && fixed_regs[regno])

  || regno == (0 + 30))
       {







  if (! ((elim_reg_set)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
    regs_ever_live[regno] = 1;
  return;
       }


     if (global_regs[regno])
       {
  if (final)
    reg_next_use[regno] = insn;
  return;
       }

     n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
     while (--n > 0)
       {
  live[(regno + n) / 32]
    |= (unsigned int) 1 << ((regno + n) % 32);
  some_needed
    |= (needed[(regno + n) / 32]
        & (unsigned int) 1 << ((regno + n) % 32));
  all_needed
    &= (needed[(regno + n) / 32]
        & (unsigned int) 1 << ((regno + n) % 32));
       }
   }
 if (final)
   {



     reg_next_use[regno] = insn;

     if (regno < 68)
       {



  i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  if (i == 0)
    i = 1;
  do
    regs_ever_live[regno + --i] = 1;
  while (i > 0);
       }
     else
       {


  register int blocknum = uid_block_number[((insn)->fld[0].rtint)];

  if (reg_basic_block[regno] == -1)
    reg_basic_block[regno] = blocknum;
  else if (reg_basic_block[regno] != blocknum)
    reg_basic_block[regno] = -2;



  reg_n_refs[regno] += loop_depth;
       }







     if (! all_needed
  && ! dead_or_set_p (insn, x)



  )
       {


  if (regno < 68
      && (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > 1)
    {
      int n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
      while (--n >= 0)
        some_needed |= dead_or_set_regno_p (insn, regno + n);
    }



  if (! some_needed)
    {
      ((insn)->fld[6].rtx)
        = gen_rtx (EXPR_LIST, REG_DEAD, x, ((insn)->fld[6].rtx));
      reg_n_deaths[regno]++;
    }
  else
    {
      int i;




      for (i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1;
    i >= 0; i--)
        if ((needed[(regno + i) / 32]
      & ((unsigned int) 1
         << ((regno + i) % 32))) == 0
     && ! dead_or_set_regno_p (insn, regno + i))
   ((insn)->fld[6].rtx)
     = gen_rtx (EXPR_LIST, REG_DEAD,
         gen_rtx (REG, reg_raw_mode[regno + i],
           regno + i),
         ((insn)->fld[6].rtx));
    }
       }
   }
      }
      return;

    case SET:
      {
 register rtx testreg = ((x)->fld[0].rtx);
 int mark_dest = 0;



 if (((testreg)->code) == MEM)
   {




     mark_used_regs (needed, live, ((testreg)->fld[0].rtx), final, insn);
     mark_used_regs (needed, live, ((x)->fld[1].rtx), final, insn);
     return;
   }
 while (((testreg)->code) == STRICT_LOW_PART
        || ((testreg)->code) == ZERO_EXTRACT
        || ((testreg)->code) == SIGN_EXTRACT
        || ((testreg)->code) == SUBREG)
   {
     if (((testreg)->code) == SUBREG
  && ((((testreg)->fld[0].rtx))->code) == REG
  && ((((testreg)->fld[0].rtx))->fld[0].rtint) >= 68
  && ((mode_size[(int)(((testreg)->mode))])
      != (mode_size[(int)(((((testreg)->fld[0].rtx))->mode))])))
       reg_changes_size[((((testreg)->fld[0].rtx))->fld[0].rtint)] = 1;




     if (((testreg)->code) == SUBREG
  && !(((mode_size[(int) ((((testreg)->fld[0].rtx))->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) > ((mode_size[(int) ((testreg)->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4))))
       ;
     else
       mark_dest = 1;

     testreg = ((testreg)->fld[0].rtx);
   }




 if (((testreg)->code) == REG
     && (regno = ((testreg)->fld[0].rtint), regno != (0 + 30))




     && ! (regno == 0 && fixed_regs[regno])

     )


   {
     mark_used_regs (needed, live, ((x)->fld[1].rtx), final, insn);
     if (mark_dest)
       mark_used_regs (needed, live, ((x)->fld[0].rtx), final, insn);
     return;
   }
      }
      break;

    case RETURN:





      if (! 1
   || (! (current_function_calls_alloca) && flag_omit_frame_pointer))

 live[(0 + 29) / 32]
   |= (unsigned int) 1 << ((0 + 29) % 32);

      for (i = 0; i < 68; i++)
 if (global_regs[i])
   live[i / 32]
     |= (unsigned int) 1 << (i % 32);
      break;
    }



  {
    register char *fmt = (rtx_format[(int)(code)]);
    register int i;

    for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
      {
 if (fmt[i] == 'e')
   {

     if (i == 0)
       {
  x = ((x)->fld[0].rtx);
  goto retry;
       }
     mark_used_regs (needed, live, ((x)->fld[i].rtx), final, insn);
   }
 else if (fmt[i] == 'E')
   {
     register int j;
     for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
       mark_used_regs (needed, live, ((x)->fld[i].rtvec->elem[j].rtx), final, insn);
   }
      }
  }
}
static rtx
find_use_as_address(register rtx x, rtx reg, int plusconst) asm("_find_use_as_address");
static rtx
find_use_as_address(register rtx x, rtx reg, int plusconst)
{
  n64_enum_rtx_code code = ((x)->code);
  char *fmt = (rtx_format[(int)(code)]);
  register int i;
  register rtx value = 0;
  register rtx tem;

  if (code == MEM && ((x)->fld[0].rtx) == reg && plusconst == 0)
    return x;

  if (code == MEM && ((((x)->fld[0].rtx))->code) == PLUS
      && ((((x)->fld[0].rtx))->fld[0].rtx) == reg
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
      && ((((((x)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) == plusconst)
    return x;

  if (code == SIGN_EXTRACT || code == ZERO_EXTRACT)
    {


      if (find_use_as_address (((x)->fld[0].rtx), reg, 0) != 0)
 return (rtx) (int) 1;
    }

  if (x == reg)
    return (rtx) (int) 1;

  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   tem = find_use_as_address (((x)->fld[i].rtx), reg, plusconst);
   if (value == 0)
     value = tem;
   else if (tem != 0)
     return (rtx) (int) 1;
 }
      if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     {
       tem = find_use_as_address (((x)->fld[i].rtvec->elem[j].rtx), reg, plusconst);
       if (value == 0)
  value = tem;
       else if (tem != 0)
  return (rtx) (int) 1;
     }
 }
    }

  return value;
}




void
dump_flow_info(FILE *file) asm("_dump_flow_info");
void
dump_flow_info(FILE *file)
{
  register int i;
  static char *reg_class_names[] = { "NO_REGS", "GR_REGS", "FP_REGS", "HI_REG", "LO_REG", "HILO_REG", "MD_REGS", "ST_REGS", "ALL_REGS" };

  fprintf (file, "%d registers.\n", max_regno);

  for (i = 68; i < max_regno; i++)
    if (reg_n_refs[i])
      {
 n64_enum_reg_class cxx_class, altclass;
 fprintf (file, "\nRegister %d used %d times across %d insns",
   i, reg_n_refs[i], reg_live_length[i]);
 if (reg_basic_block[i] >= 0)
   fprintf (file, " in block %d", reg_basic_block[i]);
 if (reg_n_deaths[i] != 1)
   fprintf (file, "; dies in %d places", reg_n_deaths[i]);
 if (reg_n_calls_crossed[i] == 1)
   fprintf (file, "; crosses 1 call");
 else if (reg_n_calls_crossed[i])
   fprintf (file, "; crosses %d calls", reg_n_calls_crossed[i]);
 if ((mode_size[(int)(((regno_reg_rtx[i])->mode))]) != ((target_flags & 0x00002000) ? 8 : 4))
   fprintf (file, "; %d bytes", (mode_size[(int)(((regno_reg_rtx[i])->mode))]));
 cxx_class = reg_preferred_class (i);
 altclass = reg_alternate_class (i);
 if (cxx_class != GR_REGS || altclass != ALL_REGS)
   {
     if (altclass == ALL_REGS || cxx_class == ALL_REGS)
       fprintf (file, "; pref %s", reg_class_names[(int) cxx_class]);
     else if (altclass == NO_REGS)
       fprintf (file, "; %s or none", reg_class_names[(int) cxx_class]);
     else
       fprintf (file, "; pref %s, else %s",
         reg_class_names[(int) cxx_class],
         reg_class_names[(int) altclass]);
   }
 if (regno_pointer_flag[i])
   fprintf (file, "; pointer");
 fprintf (file, ".\n");
      }
  fprintf (file, "\n%d basic blocks.\n", n_basic_blocks);
  for (i = 0; i < n_basic_blocks; i++)
    {
      register rtx head, jump;
      register int regno;
      fprintf (file, "\nBasic block %d: first insn %d, last %d.\n",
        i,
        ((basic_block_head[i])->fld[0].rtint),
        ((basic_block_end[i])->fld[0].rtint));



      if (basic_block_drops_in)
 {
   fprintf (file, "Reached from blocks: ");
   head = basic_block_head[i];
   if (((head)->code) == CODE_LABEL)
     for (jump = ((head)->fld[5].rtx);
   jump != head;
   jump = ((jump)->fld[1].rtx))
       {
  register int from_block = uid_block_number[((((jump)->fld[2].rtx))->fld[0].rtint)];
  fprintf (file, " %d", from_block);
       }
   if (basic_block_drops_in[i])
     fprintf (file, " previous");
 }
      fprintf (file, "\nRegisters live at start:");
      for (regno = 0; regno < max_regno; regno++)
 {
   register int offset = regno / 32;
   register unsigned int bit
     = (unsigned int) 1 << (regno % 32);
   if (basic_block_live_at_start[i][offset] & bit)
       fprintf (file, " %d", regno);
 }
      fprintf (file, "\n");
    }
  fprintf (file, "\n");
}

