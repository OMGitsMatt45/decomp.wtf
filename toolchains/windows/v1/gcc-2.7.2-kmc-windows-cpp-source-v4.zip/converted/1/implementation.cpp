// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/c-parse.c
/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <errno.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int pedwarn(...) asm("_pedwarn");
extern int finish_file(...) asm("_finish_file");
extern int assemble_asm(...) asm("_assemble_asm");
extern int error(...) asm("_error");
extern int warning(...) asm("_warning");
extern int assemble_external(...) asm("_assemble_external");
extern int pop_momentary_nofree(...) asm("_pop_momentary_nofree");
extern int emit_line_note(...) asm("_emit_line_note");
extern int declare_nonlocal_label(...) asm("_declare_nonlocal_label");
extern int position_after_white_space(...) asm("_position_after_white_space");
extern int emit_nop(...) asm("_emit_nop");
extern int warning_with_file_and_line(...) asm("_warning_with_file_and_line");
extern int expand_computed_goto(...) asm("_expand_computed_goto");
extern int error_with_decl(...) asm("_error_with_decl");
struct n64_tag_file_stack;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_yyltype;



extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *input_filename;


extern char *main_input_filename;


extern int lineno;


extern FILE *finput;

struct n64_tag_file_stack
  {
    char *name;
    struct n64_tag_file_stack *next;
    int line;
  };



extern struct n64_tag_file_stack *input_file_stack;


extern int input_file_stack_tick;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_CHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,
  RID_UNUSED1,

  RID_UNSIGNED,
  RID_SHORT,
  RID_LONG,
  RID_AUTO,
  RID_STATIC,
  RID_EXTERN,
  RID_REGISTER,
  RID_TYPEDEF,
  RID_SIGNED,
  RID_CONST,
  RID_VOLATILE,
  RID_INLINE,
  RID_NOALIAS,
  RID_ITERATOR,
  RID_COMPLEX,

  RID_IN,
  RID_OUT,
  RID_INOUT,
  RID_BYCOPY,
  RID_ONEWAY,
  RID_ID,

  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;

extern tree make_pointer_declarator(...) asm("_make_pointer_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern int yylex(void) asm("_yylex");

extern char *get_directive_line(...) asm("_get_directive_line");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value, label_value, implicit_decl;
  tree error_locus, limbo_value;
};
extern int pedantic;
struct n64_tag_lang_type
{
  int len;
  tree elts[1];
};
extern tree lookup_interface (tree) asm("_lookup_interface");
extern tree is_class_name (tree) asm("_is_class_name");
extern void maybe_objc_check_decl (tree) asm("_maybe_objc_check_decl");
extern int maybe_objc_comptypes (tree, tree, int) asm("_maybe_objc_comptypes");
extern tree maybe_building_objc_message_expr (void) asm("_maybe_building_objc_message_expr");
extern tree maybe_objc_method_name (tree) asm("_maybe_objc_method_name");
extern int recognize_objc_keyword (void) asm("_recognize_objc_keyword");
extern tree build_objc_string (int, char *) asm("_build_objc_string");


extern void gen_aux_info_record (tree, int, int, int) asm("_gen_aux_info_record");


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree convert (tree, tree) asm("_convert");



extern tree char_array_type_node;
extern tree char_type_node;
extern tree const_ptr_type_node;
extern tree const_string_type_node;
extern tree default_function_type;
extern tree double_ftype_double;
extern tree double_ftype_double_double;
extern tree double_type_node;
extern tree float_type_node;
extern tree intDI_type_node;
extern tree intHI_type_node;
extern tree intQI_type_node;
extern tree intSI_type_node;
extern tree int_array_type_node;
extern tree int_ftype_cptr_cptr_sizet;
extern tree int_ftype_int;
extern tree int_ftype_ptr_ptr_int;
extern tree int_ftype_string_string;
extern tree integer_type_node;
extern tree long_double_type_node;
extern tree long_ftype_long;
extern tree long_integer_type_node;
extern tree long_long_integer_type_node;
extern tree long_long_unsigned_type_node;
extern tree long_unsigned_type_node;
extern tree complex_integer_type_node;
extern tree complex_float_type_node;
extern tree complex_double_type_node;
extern tree complex_long_double_type_node;
extern tree ptr_type_node;
extern tree ptrdiff_type_node;
extern tree short_integer_type_node;
extern tree short_unsigned_type_node;
extern tree signed_char_type_node;
extern tree signed_wchar_type_node;
extern tree string_ftype_ptr_ptr;
extern tree string_type_node;
extern tree unsigned_char_type_node;
extern tree unsigned_intDI_type_node;
extern tree unsigned_intHI_type_node;
extern tree unsigned_intQI_type_node;
extern tree unsigned_intSI_type_node;
extern tree unsigned_type_node;
extern tree unsigned_wchar_type_node;
extern tree void_ftype_ptr_int_int;
extern tree void_ftype_ptr_ptr_int;
extern tree void_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node;
extern tree boolean_type_node;
extern tree boolean_true_node;
extern tree boolean_false_node;

extern tree build_enumerator (tree, tree) asm("_build_enumerator");

extern tree builtin_function (char *, tree, n64_enum_built_in_function function_, char *) asm("_builtin_function");

extern tree c_build_type_variant (tree, int, int) asm("_c_build_type_variant");
extern int c_decode_option (char *) asm("_c_decode_option");
extern void c_mark_varargs (void) asm("_c_mark_varargs");
extern tree check_identifier (tree, tree) asm("_check_identifier");
extern void clear_parm_order (void) asm("_clear_parm_order");
extern tree combine_parm_decls (tree, tree, int) asm("_combine_parm_decls");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern void declare_parm_level (int) asm("_declare_parm_level");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void delete_block (tree) asm("_delete_block");
extern void finish_decl (tree, tree, tree) asm("_finish_decl");
extern void finish_decl_top_level (tree, tree, tree) asm("_finish_decl_top_level");
extern tree finish_enum (tree, tree, tree) asm("_finish_enum");
extern void finish_function (int) asm("_finish_function");
extern tree finish_struct (tree, tree, tree) asm("_finish_struct");
extern tree get_parm_info (int) asm("_get_parm_info");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern int global_bindings_p (void) asm("_global_bindings_p");
extern tree grokfield (char *, int, tree, tree, tree) asm("_grokfield");
extern tree groktypename (tree) asm("_groktypename");
extern tree groktypename_in_parm_context (tree) asm("_groktypename_in_parm_context");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern int in_parm_level_p (void) asm("_in_parm_level_p");
extern void init_decl_processing (void) asm("_init_decl_processing");
extern void insert_block (tree) asm("_insert_block");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree lookup_name (tree) asm("_lookup_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern tree lookup_name_current_level_global (tree) asm("_lookup_name_current_level_global");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void parmlist_tags_warning (void) asm("_parmlist_tags_warning");
extern void pending_xref_error (void) asm("_pending_xref_error");
extern void pop_c_function_context (void) asm("_pop_c_function_context");
extern void pop_label_level (void) asm("_pop_label_level");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void print_lang_decl (FILE *, tree, int) asm("_print_lang_decl")
                 ;
extern void print_lang_identifier (FILE *, tree, int) asm("_print_lang_identifier")
                 ;
extern void print_lang_type (FILE *, tree, int) asm("_print_lang_type")
                 ;
extern void push_c_function_context (void) asm("_push_c_function_context");
extern void push_label_level (void) asm("_push_label_level");
extern void push_parm_decl (tree) asm("_push_parm_decl");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void pushlevel (int) asm("_pushlevel");
extern void pushtag (tree, tree) asm("_pushtag");
extern void set_block (tree) asm("_set_block");
extern tree shadow_label (tree) asm("_shadow_label");
extern void shadow_record_fields (tree) asm("_shadow_record_fields");
extern void shadow_tag (tree) asm("_shadow_tag");
extern void shadow_tag_warned (tree, int) asm("_shadow_tag_warned");
extern tree start_enum (tree) asm("_start_enum");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function")
                        ;
extern tree start_decl (tree, tree, int, tree, tree) asm("_start_decl")
                         ;
extern tree start_struct (n64_enum_tree_code, tree) asm("_start_struct");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern tree xref_tag (n64_enum_tree_code, tree) asm("_xref_tag");


extern tree require_complete_type (tree) asm("_require_complete_type");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");


extern tree common_type (tree, tree) asm("_common_type");
extern int comptypes (tree, tree) asm("_comptypes");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_size_in_bytes (tree) asm("_c_size_in_bytes");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree c_alignof_expr (tree) asm("_c_alignof_expr");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_component_ref (tree, tree) asm("_build_component_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree parser_build_binary_op (n64_enum_tree_code, tree, tree) asm("_parser_build_binary_op")
                         ;
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op")
                              ;
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op")
                        ;
extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern void readonly_warning (tree, char *) asm("_readonly_warning");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_c_cast (tree, tree) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr")
                   ;
extern tree initializer_constant_valid_p (tree, tree) asm("_initializer_constant_valid_p");
extern void store_init_value (tree, tree) asm("_store_init_value");
extern void error_init (char *, char *, char *) asm("_error_init")
                     ;
extern void pedwarn_init (char *, char *, char *) asm("_pedwarn_init")
                     ;
extern void start_init (tree, tree, int) asm("_start_init");
extern void finish_init (void) asm("_finish_init");
extern void really_start_incremental_init (tree) asm("_really_start_incremental_init");
extern void push_init_level (int) asm("_push_init_level");
extern tree pop_init_level (int) asm("_pop_init_level");
extern void set_init_index (tree, tree) asm("_set_init_index");
extern void set_init_label (tree) asm("_set_init_label");
extern void process_init_element (tree) asm("_process_init_element");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands")
                               ;
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");


extern void iterator_expand (tree) asm("_iterator_expand");
extern void iterator_for_loop_start (tree) asm("_iterator_for_loop_start");
extern void iterator_for_loop_end (tree) asm("_iterator_for_loop_end");
extern void iterator_for_loop_record (tree) asm("_iterator_for_loop_record");
extern void push_iterator_stack (void) asm("_push_iterator_stack");
extern void pop_iterator_stack (void) asm("_pop_iterator_stack");




extern int current_function_returns_value;




extern int current_function_returns_null;



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_no_ident;



extern int warn_implicit;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;




extern int warn_redundant_decls;







extern int warn_nested_externs;




extern int warn_cast_qual;





extern int warn_bad_function_cast;



extern int warn_traditional;



extern int warn_format;



extern int warn_char_subscripts;



extern int warn_conversion;



extern int flag_traditional;



extern int flag_allow_single_precision;



extern int warn_parentheses;



extern int warn_missing_braces;




extern int (*comptypes_record_hook)(...);



extern int system_header_p;



extern int doing_objc_thang;
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
char *language_string = "GNU C";





void yyerror(...) asm("_yyerror");
typedef union {long itype; tree ttype; n64_enum_tree_code code;
 char *filename; int lineno; int ends_in_label; } YYSTYPE;


static int stmt_count;



static char *if_stmt_file;
static int if_stmt_line;


static tree current_declspecs;
static tree prefix_attributes = (tree) 
                               ((void *)0)
                                        ;


static tree declspec_stack;


static int undeclared_variable_notice;





extern void yyprint(...) asm("_yyprint");


typedef
  struct n64_tag_yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
static const char yytranslate[] = { 0,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 80, 2, 2, 2, 52, 43, 2, 59,
    76, 50, 48, 81, 49, 58, 51, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 38, 77, 2,
    36, 2, 37, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    60, 2, 83, 42, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 82, 41, 78, 79, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 1, 2, 3, 4, 5,
     6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
    39, 40, 44, 45, 46, 47, 53, 54, 55, 56,
    57, 61, 62, 63, 64, 65, 66, 67, 68, 69,
    70, 71, 72, 73, 74, 75
};


static const short yyprhs[] = { 0,
     0, 1, 3, 4, 7, 8, 12, 14, 16, 22,
    26, 31, 36, 39, 42, 45, 48, 50, 51, 52,
    60, 65, 66, 67, 75, 80, 81, 82, 89, 93,
    95, 97, 99, 101, 103, 105, 107, 109, 111, 113,
   114, 116, 118, 122, 124, 127, 128, 132, 135, 138,
   141, 146, 149, 154, 157, 160, 162, 167, 168, 176,
   178, 182, 186, 190, 194, 198, 202, 206, 210, 214,
   218, 222, 226, 230, 234, 240, 244, 248, 250, 252,
   254, 258, 262, 263, 268, 273, 278, 282, 286, 289,
   292, 294, 297, 298, 300, 303, 307, 309, 311, 314,
   317, 322, 327, 330, 333, 337, 339, 341, 344, 347,
   348, 349, 354, 359, 363, 367, 370, 373, 376, 380,
   381, 384, 387, 389, 391, 394, 397, 400, 404, 405,
   408, 410, 412, 414, 419, 424, 426, 428, 430, 432,
   436, 438, 442, 443, 448, 449, 456, 460, 461, 468,
   472, 473, 475, 477, 480, 487, 489, 493, 494, 496,
   501, 508, 513, 515, 517, 519, 521, 523, 524, 529,
   531, 532, 535, 537, 541, 543, 544, 549, 551, 552,
   561, 562, 569, 570, 576, 577, 582, 583, 589, 590,
   591, 597, 598, 599, 605, 607, 609, 613, 617, 622,
   626, 630, 634, 636, 640, 645, 649, 653, 657, 659,
   663, 667, 671, 676, 680, 684, 686, 687, 695, 701,
   704, 705, 713, 719, 722, 723, 732, 733, 741, 744,
   745, 747, 748, 750, 752, 755, 756, 760, 763, 767,
   769, 773, 775, 777, 779, 783, 788, 795, 801, 803,
   807, 809, 811, 815, 818, 821, 822, 824, 826, 829,
   830, 833, 837, 841, 844, 848, 853, 857, 860, 864,
   867, 871, 873, 875, 878, 881, 882, 884, 887, 888,
   889, 891, 893, 896, 900, 902, 905, 908, 915, 921,
   927, 930, 933, 938, 939, 944, 945, 946, 950, 955,
   959, 961, 963, 965, 967, 970, 971, 976, 978, 982,
   983, 984, 992, 998, 1001, 1002, 1003, 1004, 1017, 1018,
  1025, 1028, 1031, 1034, 1038, 1045, 1054, 1065, 1078, 1082,
  1087, 1089, 1091, 1092, 1099, 1103, 1109, 1112, 1115, 1116,
  1118, 1119, 1121, 1122, 1124, 1126, 1130, 1135, 1137, 1141,
  1142, 1145, 1148, 1149, 1154, 1157, 1158, 1160, 1162, 1166,
  1168, 1172, 1177, 1182, 1187, 1192, 1197, 1198, 1201, 1203,
  1206, 1208, 1212, 1214
};

static const short yyrhs[] = { -1,
    85, 0, 0, 86, 88, 0, 0, 85, 87, 88,
     0, 90, 0, 89, 0, 27, 59, 99, 76, 77,
     0, 116, 127, 77, 0, 121, 116, 127, 77, 0,
   119, 116, 126, 77, 0, 121, 77, 0, 119, 77,
     0, 1, 77, 0, 1, 78, 0, 77, 0, 0,
     0, 119, 116, 156, 91, 110, 92, 187, 0, 119,
   116, 156, 1, 0, 0, 0, 121, 116, 159, 93,
   110, 94, 187, 0, 121, 116, 159, 1, 0, 0,
     0, 116, 159, 95, 110, 96, 187, 0, 116, 159,
     1, 0, 3, 0, 4, 0, 43, 0, 49, 0,
    48, 0, 54, 0, 55, 0, 79, 0, 80, 0,
   101, 0, 0, 101, 0, 106, 0, 101, 81, 106,
     0, 107, 0, 50, 104, 0, 0, 31, 103, 104,
     0, 98, 104, 0, 40, 97, 0, 11, 102, 0,
    11, 59, 174, 76, 0, 29, 102, 0, 29, 59,
   174, 76, 0, 33, 104, 0, 34, 104, 0, 102,
     0, 59, 174, 76, 104, 0, 0, 59, 174, 76,
    82, 105, 141, 78, 0, 104, 0, 106, 48, 106,
     0, 106, 49, 106, 0, 106, 50, 106, 0, 106,
    51, 106, 0, 106, 52, 106, 0, 106, 46, 106,
     0, 106, 47, 106, 0, 106, 45, 106, 0, 106,
    44, 106, 0, 106, 43, 106, 0, 106, 41, 106,
     0, 106, 42, 106, 0, 106, 40, 106, 0, 106,
    39, 106, 0, 106, 37, 211, 38, 106, 0, 106,
    36, 106, 0, 106, 35, 106, 0, 3, 0, 8,
     0, 109, 0, 59, 99, 76, 0, 59, 1, 76,
     0, 0, 59, 108, 188, 76, 0, 107, 59, 100,
    76, 0, 107, 60, 99, 83, 0, 107, 58, 97,
     0, 107, 57, 97, 0, 107, 54, 0, 107, 55,
     0, 9, 0, 109, 9, 0, 0, 112, 0, 112,
    10, 0, 193, 194, 113, 0, 111, 0, 182, 0,
   112, 111, 0, 111, 182, 0, 119, 116, 126, 77,
     0, 121, 116, 127, 77, 0, 119, 77, 0, 121,
    77, 0, 193, 194, 118, 0, 114, 0, 182, 0,
   115, 114, 0, 114, 182, 0, 0, 0, 119, 116,
   126, 77, 0, 121, 116, 127, 77, 0, 119, 116,
   150, 0, 121, 116, 153, 0, 119, 77, 0, 121,
    77, 0, 124, 120, 0, 121, 124, 120, 0, 0,
   120, 125, 0, 120, 5, 0, 7, 0, 5, 0,
   121, 7, 0, 121, 5, 0, 124, 123, 0, 176,
   124, 123, 0, 0, 123, 125, 0, 6, 0, 160,
     0, 4, 0, 28, 59, 99, 76, 0, 28, 59,
   174, 76, 0, 6, 0, 7, 0, 160, 0, 129,
     0, 126, 81, 129, 0, 131, 0, 127, 81, 129,
     0, 0, 27, 59, 109, 76, 0, 0, 156, 128,
   133, 36, 130, 139, 0, 156, 128, 133, 0, 0,
   159, 128, 133, 36, 132, 139, 0, 159, 128, 133,
     0, 0, 134, 0, 135, 0, 134, 135, 0, 30,
    59, 59, 136, 76, 76, 0, 137, 0, 136, 81,
   137, 0, 0, 138, 0, 138, 59, 3, 76, 0,
   138, 59, 3, 81, 101, 76, 0, 138, 59, 100,
    76, 0, 97, 0, 5, 0, 6, 0, 7, 0,
   106, 0, 0, 82, 140, 141, 78, 0, 1, 0,
     0, 142, 165, 0, 143, 0, 142, 81, 143, 0,
   106, 0, 0, 82, 144, 141, 78, 0, 1, 0,
     0, 60, 106, 10, 106, 83, 36, 145, 143, 0,
     0, 60, 106, 83, 36, 146, 143, 0, 0, 60,
   106, 83, 147, 143, 0, 0, 97, 38, 148, 143,
     0, 0, 58, 97, 36, 149, 143, 0, 0, 0,
   156, 151, 110, 152, 188, 0, 0, 0, 159, 154,
   110, 155, 188, 0, 157, 0, 159, 0, 59, 157,
    76, 0, 157, 59, 223, 0, 157, 60, 99, 83,
     0, 157, 60, 83, 0, 50, 177, 157, 0, 134,
   117, 157, 0, 4, 0, 158, 59, 223, 0, 158,
    60, 99, 83, 0, 158, 60, 83, 0, 50, 177,
   158, 0, 134, 117, 158, 0, 4, 0, 159, 59,
   223, 0, 59, 159, 76, 0, 50, 177, 159, 0,
   159, 60, 99, 83, 0, 159, 60, 83, 0, 134,
   117, 159, 0, 3, 0, 0, 13, 97, 82, 161,
   167, 78, 133, 0, 13, 82, 167, 78, 133, 0,
    13, 97, 0, 0, 14, 97, 82, 162, 167, 78,
   133, 0, 14, 82, 167, 78, 133, 0, 14, 97,
     0, 0, 12, 97, 82, 163, 172, 166, 78, 133,
     0, 0, 12, 82, 164, 172, 166, 78, 133, 0,
    12, 97, 0, 0, 81, 0, 0, 81, 0, 168,
     0, 168, 169, 0, 0, 168, 169, 77, 0, 168,
    77, 0, 122, 116, 170, 0, 122, 0, 176, 116,
   170, 0, 176, 0, 1, 0, 171, 0, 170, 81,
   171, 0, 193, 194, 156, 133, 0, 193, 194, 156,
    38, 106, 133, 0, 193, 194, 38, 106, 133, 0,
   173, 0, 172, 81, 173, 0, 1, 0, 97, 0,
    97, 36, 106, 0, 122, 175, 0, 176, 175, 0,
     0, 178, 0, 7, 0, 176, 7, 0, 0, 177,
     7, 0, 59, 178, 76, 0, 50, 177, 178, 0,
    50, 177, 0, 178, 59, 216, 0, 178, 60, 99,
    83, 0, 178, 60, 83, 0, 59, 216, 0, 60,
    99, 83, 0, 60, 83, 0, 134, 117, 178, 0,
   180, 0, 196, 0, 180, 196, 0, 180, 182, 0,
     0, 179, 0, 1, 77, 0, 0, 0, 185, 0,
   186, 0, 185, 186, 0, 32, 227, 77, 0, 188,
     0, 1, 188, 0, 82, 78, 0, 82, 183, 184,
   115, 181, 78, 0, 82, 183, 184, 1, 78, 0,
    82, 183, 184, 179, 78, 0, 190, 195, 0, 190,
     1, 0, 15, 59, 99, 76, 0, 0, 18, 192,
   195, 17, 0, 0, 0, 193, 194, 198, 0, 193,
   194, 209, 195, 0, 193, 194, 197, 0, 198, 0,
   209, 0, 188, 0, 206, 0, 99, 77, 0, 0,
   189, 16, 199, 195, 0, 189, 0, 189, 16, 1,
     0, 0, 0, 17, 200, 59, 99, 76, 201, 195,
     0, 191, 59, 99, 76, 77, 0, 191, 1, 0,
     0, 0, 0, 19, 59, 211, 77, 202, 211, 77,
   203, 211, 76, 204, 195, 0, 0, 20, 59, 99,
    76, 205, 195, 0, 23, 77, 0, 24, 77, 0,
    25, 77, 0, 25, 99, 77, 0, 27, 210, 59,
    99, 76, 77, 0, 27, 210, 59, 99, 38, 212,
    76, 77, 0, 27, 210, 59, 99, 38, 212, 38,
   212, 76, 77, 0, 27, 210, 59, 99, 38, 212,
    38, 212, 38, 215, 76, 77, 0, 26, 97, 77,
     0, 26, 50, 99, 77, 0, 77, 0, 207, 0,
     0, 19, 59, 107, 76, 208, 195, 0, 21, 106,
    38, 0, 21, 106, 10, 106, 38, 0, 22, 38,
     0, 97, 38, 0, 0, 7, 0, 0, 99, 0,
     0, 213, 0, 214, 0, 213, 81, 214, 0, 9,
    59, 99, 76, 0, 109, 0, 215, 81, 109, 0,
     0, 217, 218, 0, 220, 76, 0, 0, 221, 77,
   219, 218, 0, 1, 76, 0, 0, 10, 0, 221,
     0, 221, 81, 10, 0, 222, 0, 221, 81, 222,
     0, 119, 116, 158, 133, 0, 119, 116, 159, 133,
     0, 119, 116, 175, 133, 0, 121, 116, 159, 133,
     0, 121, 116, 175, 133, 0, 0, 224, 225, 0,
   218, 0, 226, 76, 0, 3, 0, 226, 81, 3,
     0, 97, 0, 227, 81, 97, 0
};




static const short yyrline[] = { 0,
   233, 238, 252, 254, 254, 255, 257, 259, 260, 270,
   281, 286, 291, 293, 295, 296, 297, 302, 309, 311,
   316, 321, 327, 329, 334, 339, 345, 347, 352, 359,
   361, 364, 366, 368, 370, 372, 374, 376, 380, 384,
   387, 390, 393, 397, 399, 402, 405, 408, 412, 440,
   445, 447, 449, 451, 453, 457, 459, 462, 466, 493,
   495, 497, 499, 501, 503, 505, 507, 509, 511, 513,
   515, 517, 519, 521, 523, 525, 528, 534, 633, 634,
   636, 642, 644, 658, 681, 683, 685, 689, 695, 697,
   702, 704, 709, 711, 712, 722, 727, 729, 730, 731,
   734, 740, 745, 748, 756, 761, 763, 764, 765, 772,
   782, 786, 792, 797, 802, 807, 809, 817, 820, 824,
   826, 828, 839, 843, 845, 848, 861, 864, 868, 870,
   878, 879, 880, 884, 886, 892, 893, 894, 897, 899,
   902, 904, 907, 910, 916, 923, 925, 932, 939, 942,
   949, 952, 956, 959, 963, 968, 971, 975, 978, 980,
   982, 984, 991, 993, 994, 995, 1000, 1002, 1007, 1015,
  1020, 1024, 1027, 1029, 1034, 1037, 1039, 1041, 1045, 1048,
  1048, 1051, 1051, 1054, 1054, 1057, 1057, 1060, 1062, 1073,
  1081, 1085, 1096, 1104, 1111, 1113, 1118, 1121, 1126, 1128,
  1130, 1132, 1134, 1142, 1148, 1150, 1152, 1154, 1156, 1162,
  1168, 1170, 1172, 1174, 1176, 1178, 1181, 1186, 1188, 1192,
  1194, 1196, 1198, 1202, 1204, 1207, 1210, 1213, 1216, 1220,
  1222, 1225, 1227, 1231, 1234, 1239, 1241, 1243, 1257, 1264,
  1269, 1275, 1280, 1284, 1286, 1290, 1294, 1298, 1308, 1310,
  1315, 1320, 1323, 1327, 1330, 1334, 1337, 1340, 1343, 1347,
  1350, 1354, 1358, 1360, 1362, 1364, 1366, 1368, 1370, 1372,
  1374, 1382, 1390, 1392, 1394, 1398, 1400, 1403, 1406, 1417,
  1419, 1424, 1426, 1429, 1443, 1446, 1449, 1451, 1459, 1467,
  1478, 1483, 1486, 1499, 1507, 1511, 1515, 1519, 1525, 1529,
  1534, 1537, 1542, 1545, 1546, 1563, 1568, 1571, 1583, 1585,
  1595, 1605, 1606, 1614, 1617, 1629, 1633, 1650, 1660, 1669,
  1674, 1679, 1684, 1688, 1692, 1703, 1710, 1717, 1724, 1735,
  1739, 1742, 1747, 1770, 1804, 1829, 1858, 1873, 1884, 1888,
  1892, 1895, 1900, 1902, 1905, 1907, 1911, 1916, 1919, 1925,
  1930, 1935, 1937, 1946, 1947, 1953, 1955, 1965, 1967, 1971,
  1974, 1980, 1990, 1999, 2008, 2018, 2032, 2037, 2042, 2044,
  2053, 2056, 2061, 2064
};

static const char * const yytname[] = { "$","error","$illegal.","IDENTIFIER",
"TYPENAME","SCSPEC","TYPESPEC","TYPE_QUAL","CONSTANT","STRING","ELLIPSIS","SIZEOF",
"ENUM","STRUCT","UNION","IF","ELSE","WHILE","DO","FOR","SWITCH","CASE","DEFAULT",
"BREAK","CONTINUE","RETURN","GOTO","ASM_KEYWORD","TYPEOF","ALIGNOF","ATTRIBUTE",
"EXTENSION","LABEL","REALPART","IMAGPART","ASSIGN","'='","'?'","':'","OROR",
"ANDAND","'|'","'^'","'&'","EQCOMPARE","ARITHCOMPARE","LSHIFT","RSHIFT","'+'",
"'-'","'*'","'/'","'%'","UNARY","PLUSPLUS","MINUSMINUS","HYPERUNARY","POINTSAT",
"'.'","'('","'['","INTERFACE","IMPLEMENTATION","END","SELECTOR","DEFS","ENCODE",
"CLASSNAME","PUBLIC","PRIVATE","PROTECTED","PROTOCOL","OBJECTNAME","CLASS","ALIAS",
"OBJC_STRING","')'","';'","'}'","'~'","'!'","','","'{'","']'","program","extdefs",
"@1","@2","extdef","datadef","fndef","@3","@4","@5","@6","@7","@8","identifier",
"unop","expr","exprlist","nonnull_exprlist","unary_expr","@9","cast_expr","@10",
"expr_no_commas","primary","@11","string","xdecls","lineno_datadecl","datadecls",
"datadecl","lineno_decl","decls","setspecs","setattrs","decl","typed_declspecs",
"reserved_declspecs","declmods","typed_typespecs","reserved_typespecquals","typespec",
"typespecqual_reserved","initdecls","notype_initdecls","maybeasm","initdcl",
"@12","notype_initdcl","@13","maybe_attribute","attributes","attribute","attribute_list",
"attrib","any_word","init","@14","initlist_maybe_comma","initlist1","initelt",
"@15","@16","@17","@18","@19","@20","nested_function","@21","@22","notype_nested_function",
"@23","@24","declarator","after_type_declarator","parm_declarator","notype_declarator",
"structsp","@25","@26","@27","@28","maybecomma","maybecomma_warn","component_decl_list",
"component_decl_list2","component_decl","components","component_declarator",
"enumlist","enumerator","typename","absdcl","nonempty_type_quals","type_quals",
"absdcl1","stmts","lineno_stmt_or_labels","xstmts","errstmt","pushlevel","maybe_label_decls",
"label_decls","label_decl","compstmt_or_error","compstmt","simple_if","if_prefix",
"do_stmt_start","@29","save_filename","save_lineno","lineno_labeled_stmt","lineno_stmt_or_label",
"stmt_or_label","stmt","@30","@31","@32","@33","@34","@35","@36","all_iter_stmt",
"all_iter_stmt_simple","@37","label","maybe_type_qual","xexpr","asm_operands",
"nonnull_asm_operands","asm_operand","asm_clobbers","parmlist","@38","parmlist_1",
"@39","parmlist_2","parms","parm","parmlist_or_identifiers","@40","parmlist_or_identifiers_1",
"identifiers","identifiers_or_typenames",""
};


static const short yyr1[] = { 0,
    84, 84, 86, 85, 87, 85, 88, 88, 88, 89,
    89, 89, 89, 89, 89, 89, 89, 91, 92, 90,
    90, 93, 94, 90, 90, 95, 96, 90, 90, 97,
    97, 98, 98, 98, 98, 98, 98, 98, 99, 100,
   100, 101, 101, 102, 102, 103, 102, 102, 102, 102,
   102, 102, 102, 102, 102, 104, 104, 105, 104, 106,
   106, 106, 106, 106, 106, 106, 106, 106, 106, 106,
   106, 106, 106, 106, 106, 106, 106, 107, 107, 107,
   107, 107, 108, 107, 107, 107, 107, 107, 107, 107,
   109, 109, 110, 110, 110, 111, 112, 112, 112, 112,
   113, 113, 113, 113, 114, 115, 115, 115, 115, 116,
   117, 118, 118, 118, 118, 118, 118, 119, 119, 120,
   120, 120, 121, 121, 121, 121, 122, 122, 123, 123,
   124, 124, 124, 124, 124, 125, 125, 125, 126, 126,
   127, 127, 128, 128, 130, 129, 129, 132, 131, 131,
   133, 133, 134, 134, 135, 136, 136, 137, 137, 137,
   137, 137, 138, 138, 138, 138, 139, 140, 139, 139,
   141, 141, 142, 142, 143, 144, 143, 143, 145, 143,
   146, 143, 147, 143, 148, 143, 149, 143, 151, 152,
   150, 154, 155, 153, 156, 156, 157, 157, 157, 157,
   157, 157, 157, 158, 158, 158, 158, 158, 158, 159,
   159, 159, 159, 159, 159, 159, 161, 160, 160, 160,
   162, 160, 160, 160, 163, 160, 164, 160, 160, 165,
   165, 166, 166, 167, 167, 168, 168, 168, 169, 169,
   169, 169, 169, 170, 170, 171, 171, 171, 172, 172,
   172, 173, 173, 174, 174, 175, 175, 176, 176, 177,
   177, 178, 178, 178, 178, 178, 178, 178, 178, 178,
   178, 179, 180, 180, 180, 181, 181, 182, 183, 184,
   184, 185, 185, 186, 187, 187, 188, 188, 188, 188,
   189, 189, 190, 192, 191, 193, 194, 195, 195, 196,
   197, 197, 198, 198, 198, 199, 198, 198, 198, 200,
   201, 198, 198, 198, 202, 203, 204, 198, 205, 198,
   198, 198, 198, 198, 198, 198, 198, 198, 198, 198,
   198, 206, 208, 207, 209, 209, 209, 209, 210, 210,
   211, 211, 212, 212, 213, 213, 214, 215, 215, 217,
   216, 218, 219, 218, 218, 220, 220, 220, 220, 221,
   221, 222, 222, 222, 222, 222, 224, 223, 225, 225,
   226, 226, 227, 227
};

static const short yyr2[] = { 0,
     0, 1, 0, 2, 0, 3, 1, 1, 5, 3,
     4, 4, 2, 2, 2, 2, 1, 0, 0, 7,
     4, 0, 0, 7, 4, 0, 0, 6, 3, 1,
     1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
     1, 1, 3, 1, 2, 0, 3, 2, 2, 2,
     4, 2, 4, 2, 2, 1, 4, 0, 7, 1,
     3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
     3, 3, 3, 3, 5, 3, 3, 1, 1, 1,
     3, 3, 0, 4, 4, 4, 3, 3, 2, 2,
     1, 2, 0, 1, 2, 3, 1, 1, 2, 2,
     4, 4, 2, 2, 3, 1, 1, 2, 2, 0,
     0, 4, 4, 3, 3, 2, 2, 2, 3, 0,
     2, 2, 1, 1, 2, 2, 2, 3, 0, 2,
     1, 1, 1, 4, 4, 1, 1, 1, 1, 3,
     1, 3, 0, 4, 0, 6, 3, 0, 6, 3,
     0, 1, 1, 2, 6, 1, 3, 0, 1, 4,
     6, 4, 1, 1, 1, 1, 1, 0, 4, 1,
     0, 2, 1, 3, 1, 0, 4, 1, 0, 8,
     0, 6, 0, 5, 0, 4, 0, 5, 0, 0,
     5, 0, 0, 5, 1, 1, 3, 3, 4, 3,
     3, 3, 1, 3, 4, 3, 3, 3, 1, 3,
     3, 3, 4, 3, 3, 1, 0, 7, 5, 2,
     0, 7, 5, 2, 0, 8, 0, 7, 2, 0,
     1, 0, 1, 1, 2, 0, 3, 2, 3, 1,
     3, 1, 1, 1, 3, 4, 6, 5, 1, 3,
     1, 1, 3, 2, 2, 0, 1, 1, 2, 0,
     2, 3, 3, 2, 3, 4, 3, 2, 3, 2,
     3, 1, 1, 2, 2, 0, 1, 2, 0, 0,
     1, 1, 2, 3, 1, 2, 2, 6, 5, 5,
     2, 2, 4, 0, 4, 0, 0, 3, 4, 3,
     1, 1, 1, 1, 2, 0, 4, 1, 3, 0,
     0, 7, 5, 2, 0, 0, 0, 12, 0, 6,
     2, 2, 2, 3, 6, 8, 10, 12, 3, 4,
     1, 1, 0, 6, 3, 5, 2, 2, 0, 1,
     0, 1, 0, 1, 1, 3, 4, 1, 3, 0,
     2, 2, 0, 4, 2, 0, 1, 1, 3, 1,
     3, 4, 4, 4, 4, 4, 0, 2, 1, 2,
     1, 3, 1, 3
};

static const short yydefact[] = { 3,
     5, 0, 0, 0, 133, 124, 131, 123, 0, 0,
     0, 0, 0, 17, 4, 8, 7, 0, 110, 110,
   120, 132, 6, 15, 16, 30, 31, 227, 229, 236,
   220, 236, 224, 0, 0, 216, 0, 260, 0, 0,
   141, 111, 153, 0, 14, 0, 126, 125, 13, 0,
   120, 118, 0, 225, 0, 0, 217, 0, 221, 78,
    79, 91, 0, 0, 46, 0, 0, 0, 32, 34,
    33, 0, 35, 36, 0, 37, 38, 0, 0, 39,
    56, 60, 42, 44, 80, 258, 0, 256, 129, 0,
   256, 0, 0, 0, 10, 0, 0, 154, 29, 0,
   367, 0, 0, 151, 203, 260, 0, 0, 139, 111,
     0, 195, 196, 0, 0, 119, 122, 136, 137, 121,
   138, 251, 252, 232, 249, 0, 151, 243, 238, 110,
   235, 110, 236, 151, 236, 0, 50, 0, 52, 0,
    54, 55, 49, 45, 0, 0, 0, 0, 48, 0,
     0, 0, 0, 341, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 89, 90,
     0, 0, 40, 0, 92, 134, 260, 350, 0, 111,
   254, 257, 127, 135, 259, 129, 255, 158, 261, 212,
   211, 142, 143, 215, 0, 210, 0, 214, 0, 0,
    27, 0, 296, 98, 297, 150, 152, 0, 0, 12,
     0, 0, 21, 0, 151, 367, 0, 11, 25, 0,
     0, 233, 0, 232, 219, 296, 237, 296, 0, 223,
     0, 0, 0, 47, 82, 81, 279, 0, 0, 9,
    43, 77, 76, 342, 0, 74, 73, 71, 72, 70,
    69, 68, 66, 67, 61, 62, 63, 64, 65, 88,
    87, 0, 41, 0, 264, 0, 268, 0, 270, 0,
     0, 350, 0, 130, 128, 164, 165, 166, 163, 0,
   156, 159, 0, 0, 371, 357, 110, 110, 369, 0,
   358, 360, 368, 0, 213, 278, 0, 100, 95, 99,
     0, 148, 201, 197, 140, 202, 19, 147, 198, 200,
     0, 23, 253, 250, 151, 0, 239, 244, 297, 241,
   151, 151, 51, 53, 287, 280, 84, 58, 57, 0,
    85, 86, 263, 262, 351, 269, 271, 265, 267, 0,
     0, 158, 40, 144, 355, 256, 256, 352, 353, 0,
   370, 0, 0, 28, 285, 96, 110, 110, 0, 0,
   145, 199, 0, 228, 151, 296, 0, 218, 222, 0,
     0, 281, 282, 0, 75, 266, 155, 157, 78, 0,
   209, 260, 350, 111, 151, 151, 151, 260, 111, 151,
   151, 0, 359, 361, 372, 286, 103, 0, 104, 0,
   170, 168, 167, 149, 20, 0, 24, 226, 245, 0,
   151, 373, 0, 0, 0, 296, 0, 0, 107, 297,
   273, 283, 178, 78, 0, 0, 176, 0, 175, 0,
   230, 173, 160, 0, 162, 264, 0, 367, 0, 362,
   363, 364, 264, 0, 365, 366, 354, 0, 0, 143,
     0, 146, 151, 0, 246, 284, 0, 289, 109, 108,
   277, 0, 290, 275, 297, 274, 0, 0, 0, 0,
   185, 59, 0, 172, 0, 207, 208, 204, 206, 0,
   101, 102, 0, 248, 151, 374, 288, 0, 133, 0,
   310, 294, 0, 0, 0, 0, 0, 0, 0, 0,
   339, 331, 0, 0, 105, 110, 110, 303, 308, 0,
     0, 300, 301, 304, 332, 302, 187, 0, 183, 0,
     0, 174, 161, 205, 169, 247, 0, 0, 296, 341,
     0, 0, 337, 321, 322, 323, 0, 0, 0, 340,
     0, 338, 305, 116, 0, 117, 0, 0, 292, 297,
   291, 314, 0, 0, 0, 181, 0, 177, 186, 0,
     0, 0, 44, 0, 0, 0, 335, 324, 0, 329,
     0, 0, 114, 189, 0, 115, 192, 309, 296, 0,
     0, 188, 0, 0, 184, 293, 0, 295, 333, 315,
   319, 0, 330, 0, 112, 0, 113, 0, 307, 298,
   296, 0, 179, 182, 311, 296, 341, 296, 336, 343,
     0, 190, 193, 299, 313, 0, 296, 334, 0, 320,
     0, 0, 344, 345, 325, 0, 0, 180, 312, 316,
     0, 343, 0, 0, 191, 194, 341, 0, 0, 326,
   346, 0, 347, 0, 0, 317, 348, 0, 327, 296,
     0, 0, 318, 328, 349, 0, 0, 0
};

static const short yydefgoto[] = { 656,
     1, 2, 3, 15, 16, 17, 214, 360, 220, 363,
   103, 297, 428, 78, 244, 262, 80, 81, 140, 82,
   374, 83, 84, 147, 85, 201, 202, 203, 356, 415,
   416, 18, 97, 505, 287, 52, 288, 88, 183, 21,
   120, 108, 40, 104, 109, 406, 41, 359, 206, 207,
    43, 280, 281, 282, 404, 451, 430, 431, 432, 470,
   616, 584, 557, 521, 554, 573, 596, 626, 576, 598,
   627, 193, 112, 385, 113, 22, 133, 135, 126, 53,
   474, 223, 55, 56, 131, 317, 318, 124, 125, 90,
   181, 91, 93, 182, 417, 418, 462, 204, 326, 371,
   372, 373, 354, 355, 509, 510, 511, 529, 550, 301,
   551, 421, 512, 513, 579, 528, 617, 607, 637, 650,
   608, 514, 515, 606, 516, 541, 245, 622, 623, 624,
   648, 267, 268, 289, 392, 290, 291, 292, 196, 197,
   293, 294, 413
};

static const short yypact[] = { 67,
    76, 1898, 1898, 232,-32768,-32768,-32768,-32768, 62, 91,
   106, 23, 37,-32768,-32768,-32768,-32768, 347, 26, 939,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768, 85,-32768,
   118,-32768, 166, 1760, 1700,-32768, 89,-32768, 347, 83,
-32768, 128,-32768, 1205,-32768, 315,-32768,-32768,-32768, 347,
-32768, 862, 454,-32768, 180, 340,-32768, 185,-32768,-32768,
-32768,-32768, 1787, 1814,-32768, 1760, 1760, 119,-32768,-32768,
-32768, 1760,-32768,-32768, 1017,-32768,-32768, 1760, 110, 190,
-32768,-32768, 2063, 576, 257,-32768, 208, 214,-32768, 210,
  1970, 267, 466, 11,-32768, 315, 347,-32768,-32768, 289,
-32768, 559, 284, 128,-32768,-32768, 315, 113,-32768, 128,
  1284, 178, 264, 170, 1265, 862,-32768,-32768,-32768,-32768,
-32768,-32768, 263, 235,-32768, 454, 128,-32768,-32768, 265,
   278, 859,-32768, 128,-32768, 1017,-32768, 1017,-32768, 1760,
-32768,-32768,-32768,-32768, 282, 294, 307, 319,-32768, 283,
  1760, 1760, 1760, 1760, 1760, 1760, 1760, 1760, 1760, 1760,
  1760, 1760, 1760, 1760, 1760, 1760, 1760, 1760,-32768,-32768,
   119, 119, 1760, 1760,-32768,-32768,-32768, 214, 1319, 128,
-32768, 273, 552,-32768,-32768,-32768,-32768, 912,-32768, 264,
-32768,-32768, 374, 264, 395,-32768, 702,-32768, 343, 358,
-32768, 255, 47,-32768,-32768, 403, 128, 459, 111,-32768,
   315, 315,-32768, 284, 128,-32768, 1346,-32768,-32768, 284,
  1760, 119, 378, 235,-32768,-32768,-32768,-32768, 382,-32768,
   386, 376, 394,-32768,-32768,-32768, 393, 398, 1643,-32768,
  2063, 2063, 2063,-32768, 412, 1945, 1372, 1289, 1043, 1210,
  1257, 1609, 947, 947, 252, 252,-32768,-32768,-32768,-32768,
-32768, 399, 190, 400, 364, 219,-32768, 782,-32768, 401,
   214,-32768, 1401,-32768, 552,-32768,-32768,-32768,-32768, -12,
-32768, 419, 35, 405,-32768,-32768,-32768, 672,-32768, 409,
   240,-32768,-32768, 104,-32768,-32768, 59,-32768,-32768,-32768,
   832,-32768, 178,-32768,-32768, 178,-32768, 450,-32768,-32768,
   407,-32768, 2063,-32768, 128, 413, 414,-32768,-32768, 414,
   128, 128,-32768,-32768,-32768, 467,-32768,-32768,-32768, 1760,
-32768,-32768, 273,-32768,-32768,-32768, 273,-32768,-32768, 420,
   432, 912, 1841,-32768,-32768, 353, 149,-32768,-32768, 752,
-32768, 510, 307,-32768,-32768,-32768, 437, 1568, 1194, 59,
-32768,-32768, 59,-32768, 128,-32768, 55,-32768,-32768, 119,
   720, 467,-32768, 546, 1894,-32768,-32768,-32768, 139, 439,
-32768,-32768, 149, 128, 151, 222, 128,-32768, 128, 222,
   128, 782,-32768,-32768,-32768,-32768,-32768, 315,-32768, 347,
-32768,-32768, 2063,-32768,-32768, 1194,-32768,-32768,-32768, 1760,
   108,-32768, 248, 309, 640, 443, 444, 800,-32768,-32768,
-32768,-32768,-32768, 485, 119, 1760,-32768, 488, 2063, 452,
   447,-32768,-32768, 1760,-32768, 331, 353,-32768, 1428,-32768,
-32768,-32768, 109, 149,-32768,-32768,-32768, 292, 311, 19,
   546,-32768, 2019, 1760,-32768,-32768, 119,-32768,-32768,-32768,
-32768, 455,-32768,-32768,-32768,-32768, 1509, 496, 1919, 546,
-32768,-32768, 1074,-32768, 159, 350, 350,-32768,-32768, 451,
-32768,-32768, 457,-32768, 2019,-32768,-32768, 1589, 500, 482,
-32768,-32768, 484, 486, 1760, 506, 474, 476, 1727, 203,
   549,-32768, 522, 492,-32768, 494, 1902,-32768, 547, 880,
    60,-32768,-32768,-32768,-32768,-32768,-32768, 1760, 536, 495,
  1134,-32768,-32768,-32768,-32768,-32768, 1760, 517,-32768, 1760,
  1760, 1453,-32768,-32768,-32768,-32768, 501, 1760, 504,-32768,
   523,-32768,-32768,-32768, 315,-32768, 347, 960,-32768,-32768,
-32768,-32768, 1760, 1134, 1996,-32768, 1134,-32768,-32768, 507,
  1760, 568, 1004, 514, 527, 1760,-32768,-32768, 521,-32768,
  1760, 330,-32768, 471, 357,-32768, 372,-32768,-32768, 1589,
   534,-32768, 575, 1134,-32768,-32768, 539,-32768,-32768,-32768,
-32768, 2045,-32768, 25,-32768, 284,-32768, 284,-32768,-32768,
-32768, 535,-32768,-32768,-32768,-32768, 1760,-32768,-32768, 607,
   540,-32768,-32768,-32768,-32768, 1134,-32768,-32768, 542,-32768,
   562, 45, 541,-32768,-32768, 307, 307,-32768,-32768,-32768,
  1760, 607, 550, 607,-32768,-32768, 1760, 553, 50,-32768,
-32768, 561,-32768, 395, 563,-32768, 257, 160,-32768,-32768,
   579, 395,-32768,-32768, 257, 670, 675,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768, 669,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768, -6,-32768, -34, 338, -154, 352,-32768, -27,
-32768, 66, 157,-32768, -185, -198, 489,-32768,-32768, 275,
-32768, 5, -83,-32768, 10, 642, 12, 641, 512, 17,
  -147, -367, -41, -94, -61,-32768,-32768,-32768, 57, -16,
    -4,-32768, 354,-32768, 295,-32768, -396,-32768, -423,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768, -40, -65, 9, -7, -32,-32768,-32768,-32768,-32768,
-32768, 478, 21,-32768,-32768, 483, 344, 578, 491, -21,
   -70, 680, -88, -129, 334,-32768,-32768, -173,-32768,-32768,
-32768, 380, -186, -139,-32768,-32768,-32768,-32768, -96, -293,
  -404, 337,-32768, 181,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768, 187,-32768, -474, 140,-32768, 137,
-32768, 505,-32768, -235,-32768,-32768,-32768, 423, -188,-32768,
-32768,-32768,-32768
};





static const short yytable[] = { 79,
    87, 42, 29, 31, 33, 111, 205, 238, 114, 283,
    44, 19, 19, 20, 20, 307, 215, 208, 263, 121,
   187, 312, 42, 46, 50, 367, 212, 309, 298, 110,
   448, 94, 335, 42, 192, 274, 51, 98, 141, 142,
   146, 209, 115, 175, 144, 100, 123, -94, 266, 522,
   149, 89, 58, 148, 483, 564, 299, 36, 105, 353,
   552, 143, 610, 341, 26, 27, -1, 199, 342, 101,
   102, 180, 89, 520, 180, -2, 42, 101, 102, 110,
    42, 34, 632, 121, 37, 190, 191, 644, 265, 194,
   110, 89, 410, 26, 27, 35, 271, 559, 215, 94,
   611, 146, 45, 146, 106, 98, 205, 186, 26, 27,
   344, 36, 234, 107, 232, 189, 233, 205, 553, 123,
   633, 26, 27, 205, 562, 645, 467, 274, -94, 319,
   582, 319, 619, 585, 226, 333, 228, 37, 37, 264,
   237, 337, 303, 28, 270, 454, 306, 92, 186, 305,
   121, 36, 89, 229, 89, 231, 447, 37, 388, 95,
   604, 180, 642, 96, 260, 261, 54, 383, 179, 216,
   217, 488, 30, 405, 599, 98, 407, 572, 37, 351,
    37, 279, 311, 225, 352, 150, 304, 32, 263, 210,
   230, 110, 628, 211, 110, 110, 614, 419, 388, 57,
   190, 618, 98, 620, 194, 26, 27, 383, 179, 438,
   439, 329, 629, 396, 433, 123, 241, 242, 243, 434,
   246, 247, 248, 249, 250, 251, 252, 253, 254, 255,
   256, 257, 258, 259, 523, 651, 216, 217, 340, 151,
   652, 459, 121, 37, 464, 653, 218, 59, 180, 478,
    96, 37, 538, 266, 180, 200, 580, 127, -97, -97,
   -97, -97, 134, 177, -97, 175, -97, -97, -97, 319,
   151, 308, 178, 179, 420, 387, 391, 272, 273, 475,
   101, 102, -97, 176, 200, 184, 313, -296, -296, -296,
  -296, 346, 347, 436, 334, -296, -296, -296, 221, 443,
   437, 166, 167, 168, 51, 444, 333, 337, 24, 25,
   357, -296, 358, 333, 337, 222, 349, 36, 105, 420,
   350, 465, 101, 102, 456, 188, 411, 508, 457, 384,
   389, 272, 273, 36, 381, 279, -97, 189, 386, 390,
   128, -240, -240, 5, 37, 7, 86, 195, 508, 36,
   110, 9, 10, 11, 227, 36, 381, 235, 449, 240,
    37, 398, 400, 412, 106, -93, 389, 13, 481, 236,
   189, 364, 211, 107, 51, 94, 37, 368, 369, 98,
   382, 110, 37, 42, 98, 296, 458, 482, 237, 383,
   179, 96, 450, 37, 239, 375, 38, 612, 100, 613,
   100, -143, 382, 62, 480, 39, 595, -143, 438, 439,
   211, 383, 179, 177, 137, 139, 129, -234, 468, 384,
   384, 408, 178, 179, 403, 295, 389, 389, 190, 194,
   101, 102, 504, 597, 296, 190, 194, 96, 302, 429,
   508, 440, 441, 442, 476, 477, 445, 446, -143, 330,
   486, 323, -143, 504, 122, 315, 26, 27, 647, 321,
   503, 36, 105, 322, 537, 189, 655, 455, 36, 324,
   325, 403, 189, 327, 331, 453, 506, 343, 507, 215,
   345, 503, 332, 336, 348, 361, 635, 636, 37, 362,
   365, 469, 560, 539, 366, 37, 565, 100, 370, 205,
  -143, 205, 376, 569, 574, 575, -143, 377, 106, 484,
   545, 547, 395, 397, 435, 38, 429, 107, 581, 485,
  -276, 463, -30, 51, 39, 471, 587, 473, 110, 472,
    42, 517, 487, 524, 525, 429, 594, -31, 429, 577,
   527, 526, 530, 533, 531, 504, 423, -143, 424, 27,
   534, -143, 535, 61, 62, 540, 63, 118, 119, 542,
   532, 60, 548, 9, 10, 11, 61, 62, 543, 63,
   544, 556, 558, 503, 64, 561, 65, 568, 66, 67,
   570, 571, 586, 555, 588, 68, 429, 64, 69, 65,
   590, 66, 67, 70, 71, 72, 638, 593, 68, 73,
    74, 69, 591, 425, 75, 426, 70, 71, 72, 602,
   603, 615, 73, 74, 605, 621, 625, 75, 630, 429,
   631, 634, 429, -171, 76, 77, 640, 427, 643, 169,
   170, 592, 171, 172, 173, 174, 646, 76, 77, 649,
   200, 198, -106, -106, -106, -106, -106, -106, -106, 429,
  -106, -106, -106, -106, -106, 654, -106, -106, -106, -106,
  -106, -106, -106, -106, -106, -106, -106, -106, -106, 657,
  -106, 23, -106, -106, 658, 5, 47, 7, 48, -106,
   380, 429, -106, 9, 10, 11, 563, -106, -106, -106,
   460, 300, 116, -106, -106, 378, 130, 275, -106, 13,
   452, 316, 284, 224, 285, 5, 6, 7, 8, 409,
   320, 286, 314, 9, 10, 11, -106, -106, -106, -106,
   414, -106, -296, -296, -296, -296, -296, -296, -296, 13,
  -296, -296, -296, -296, -296, 132, -296, -296, -296, -296,
  -296, -296, -296, -296, -296, -296, -296, -296, -296, 461,
  -296, 422, -296, -296, 466, 5, 6, 7, 8, -296,
   600, 393, -296, 9, 10, 11, 601, -296, -296, -296,
   641, 639, 394, -296, -296, 0, 338, -356, -296, 13,
     0, 0, 284, 0, 0, 5, 6, 7, 8, 0,
     0, 286, 0, 9, 10, 11, -296, 0, -296, -296,
   200, -296, -296, -296, 0, 0, 0, -296, -296, 13,
  -296, 0, 0, 0, -296, 0, -296, -296, -296, -296,
  -296, -296, -296, -296, -296, -296, -296, 0, -296, 0,
  -296, 0, -296, -296, 0, 5, 6, 7, 8, -296,
     0, 0, -296, 9, 10, 11, 0, -296, -296, -296,
     0, 0, 0, -296, -296, 0, 0, -356, -296, 13,
     0, 0, 5, 0, 7, 185, 117, 118, 119, 0,
     9, 10, 11, 9, 10, 11, -296, -272, -296, -296,
   549, -296, -296, -296, 0, 0, 13, -296, -296, 0,
  -296, 0, 0, 0, -296, 0, -296, -296, -296, -296,
  -296, -296, -296, -296, -296, -296, -296, 0, -296, 0,
  -296, 0, -296, -296, 26, 27, 276, 277, 278, -296,
     0, 0, -296, 0, 0, 0, 0, -296, -296, -296,
     0, 0, 0, -296, -296, -242, -242, 0, -296, 0,
     0, 0, 5, 47, 7, 48, 0, 0, 0, 0,
     9, 10, 11, 0, 0, 0, -296, 0, -296, -296,
   578, -296, -306, -306, 0, 0, 13, -306, -306, 0,
  -306, 0, 0, 0, -306, 0, -306, -306, -306, -306,
  -306, -306, -306, -306, -306, -306, -306, 0, -306, 0,
  -306, 0, -306, -306, 164, 165, 166, 167, 168, -306,
     0, 0, -306, 0, 0, 0, 0, -306, -306, -306,
     0, 0, 0, -306, -306, 49, 0, 145, -306, 60,
     5, 0, 7, 86, 61, 62, 0, 63, 9, 10,
    11, 0, 0, 0, 0, 0, -306, 0, -306, -306,
     0, -306, 0, 0, 13, 64, 0, 65, 0, 66,
    67, 0, 0, 0, 0, 0, 68, 169, 170, 69,
   171, 172, 173, 174, 70, 71, 72, 0, 0, 0,
    73, 74, 0, 0, 423, 75, 424, 27, 0, 589,
     0, 61, 62, 0, 63, 159, 160, 161, 162, 163,
   164, 165, 166, 167, 168, 76, 77, 0, -83, 0,
     0, 0, 64, 0, 65, 0, 66, 67, 0, 0,
     0, 0, 0, 68, 0, 0, 69, 0, 0, 0,
     0, 70, 71, 72, 0, 0, 0, 73, 74, 0,
     0, 425, 75, 426, 423, 0, 424, 27, 0, 0,
     0, 61, 62, 0, 63, 0, 0, 0, 0, 0,
     0, -231, 76, 77, 0, 427, 0, 0, 0, 0,
     0, 0, 64, 0, 65, 0, 66, 67, 0, 0,
     0, 0, 0, 68, 0, 0, 69, 0, 0, 0,
     0, 70, 71, 72, 0, 0, 0, 73, 74, 0,
     0, 425, 75, 426, 401, 0, 60, 0, 0, 0,
     0, 61, 62, 0, 63, 99, 0, 0, -26, -26,
   -26, -26, 76, 77, 0, 427, -26, -26, -26, 0,
     0, 0, 64, 0, 65, 0, 66, 67, 0, 0,
     0, 100, -26, 68, -143, 0, 69, 0, 0, 0,
  -143, 70, 71, 72, 0, 0, 0, 73, 74, 0,
     0, 0, 75, 160, 161, 162, 163, 164, 165, 166,
   167, 168, 0, 101, 102, 219, 0, 0, -22, -22,
   -22, -22, 76, 77, 0, 402, -22, -22, -22, 0,
     0, -143, 0, 0, 213, -143, -26, -18, -18, -18,
   -18, 100, -22, 0, -143, -18, -18, -18, 0, 0,
  -143, 161, 162, 163, 164, 165, 166, 167, 168, 0,
   100, -18, 0, -143, 0, 0, 0, 0, 0, -143,
     0, 60, 0, 101, 102, 0, 61, 62, 0, 63,
   158, 159, 160, 161, 162, 163, 164, 165, 166, 167,
   168, -143, 0, 0, 0, -143, -22, 64, 60, 65,
     0, 66, 67, 61, 62, 0, 63, 0, 68, 0,
  -143, 69, 0, 0, -143, -18, 70, 71, 72, 0,
     0, 0, 73, 74, 64, 0, 65, 75, 66, 67,
     0, 0, 0, 0, 0, 68, 0, 0, 69, 0,
     0, 0, 0, 70, 71, 72, 0, 76, 77, 73,
    74, 269, 0, 60, 75, 0, 0, 0, 61, 62,
     0, 63, 157, 158, 159, 160, 161, 162, 163, 164,
   165, 166, 167, 168, 76, 77, 0, 0, 310, 64,
    60, 65, 0, 66, 67, 61, 62, 0, 63, 0,
    68, 0, 0, 69, 0, 0, 0, 0, 70, 71,
    72, 0, 0, 0, 73, 74, 64, 0, 65, 75,
    66, 67, 566, 0, 0, 0, 0, 68, 0, 0,
    69, 0, 0, 0, 0, 70, 71, 72, 0, 76,
    77, 73, 74, 339, 0, 0, 75, 152, 153, 154,
   567, 155, 156, 157, 158, 159, 160, 161, 162, 163,
   164, 165, 166, 167, 168, 0, 76, 77, 0, 0,
   479, 424, 489, 6, 7, 8, 61, 62, 0, 63,
     9, 10, 11, 490, 0, 491, 492, 493, 494, 495,
   496, 497, 498, 499, 500, 501, 13, 64, 0, 65,
     0, 66, 67, 0, 0, 0, 0, 0, 68, 0,
     0, 69, 0, 0, 0, 0, 70, 71, 72, 0,
     0, 0, 73, 74, 0, 0, 0, 75, 0, 0,
     0, 5, 47, 7, 48, 0, 0, 0, 0, 9,
    10, 11, 0, 0, 0, 502, 0, 76, 77, 0,
   237, 424, 27, 0, 0, 13, 61, 62, 0, 63,
     0, 0, 0, 490, 0, 491, 492, 493, 494, 495,
   496, 497, 498, 499, 500, 501, 0, 64, 0, 65,
     0, 66, 67, 0, 0, 0, 0, 0, 68, 0,
     0, 69, 0, 0, 0, 0, 70, 71, 72, 0,
     0, 0, 73, 74, 399, 60, 0, 75, 0, 0,
    61, 62, 0, 63, 162, 163, 164, 165, 166, 167,
   168, 0, 0, 0, 0, 502, 0, 76, 77, 0,
   237, 64, 0, 65, 0, 66, 67, 0, 0, 0,
     0, 0, 68, 0, 0, 69, 0, 0, 0, 0,
    70, 71, 72, 0, 0, 0, 73, 74, 0, 0,
     0, 75, 60, 5, 0, 7, 86, 61, 62, 0,
    63, 9, 10, 11, 0, 0, 0, 0, 0, 0,
     0, 76, 77, 0, 328, 0, 0, 13, 64, 60,
    65, 0, 66, 67, 61, 62, 0, 63, 0, 68,
     0, 0, 69, 0, 0, 0, 0, 70, 71, 72,
     0, 0, 0, 73, 74, 64, 0, 65, 75, 66,
    67, 0, 60, 0, 0, 0, 68, 61, 62, 69,
    63, 0, 0, 0, 70, 71, 72, 0, 76, 77,
    73, 74, 0, 0, 0, 75, 0, 0, 64, 60,
    65, 0, 66, 67, 61, 62, 0, 63, 0, 68,
     0, 0, 69, 536, 0, 76, 77, 70, 71, 72,
     0, 0, 0, 73, 74, 64, 60, 65, 75, 66,
    67, 61, 62, 0, 63, 0, 68, 0, 0, 69,
     0, 0, 0, 0, 70, 71, 72, 0, 76, 77,
    73, 74, 64, 379, 65, 136, 66, 67, 61, 62,
     0, 63, 0, 68, 0, 0, 69, 0, 0, 0,
     0, 70, 71, 72, 0, 76, 77, 73, 74, 64,
     0, 65, 138, 66, 67, 0, 0, 0, 0, 0,
    68, 0, 0, 69, 0, 0, 0, 0, 70, 71,
    72, 0, 76, 77, 73, 74, 0, 0, 4, 75,
  -110, 5, 6, 7, 8, 5, 47, 7, 48, 9,
    10, 11, 0, 9, 10, 11, 0, 0, 0, 76,
    77, 0, 0, 0, 12, 13, 0, -110, 518, 13,
   154, 0, 155, 156, 157, 158, 159, 160, 161, 162,
   163, 164, 165, 166, 167, 168, 0, -110, 0, 0,
     0, 0, 0, 152, 153, 154, -110, 155, 156, 157,
   158, 159, 160, 161, 162, 163, 164, 165, 166, 167,
   168, 0, 0, 5, 14, 7, 185, 0, 546, 0,
     0, 9, 10, 11, 156, 157, 158, 159, 160, 161,
   162, 163, 164, 165, 166, 167, 168, 13, 0, 37,
     0, 519, 0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0, 0, 177,
     0, 0, 0, 0, 0, 0, 0, 0, 178, 179,
   152, 153, 154, 0, 155, 156, 157, 158, 159, 160,
   161, 162, 163, 164, 165, 166, 167, 168, 37, 0,
     0, 0, 0, 152, 153, 154, 0, 155, 156, 157,
   158, 159, 160, 161, 162, 163, 164, 165, 166, 167,
   168, 0, 0, 0, 0, 0, 0, 0, 583, 152,
   153, 154, 609, 155, 156, 157, 158, 159, 160, 161,
   162, 163, 164, 165, 166, 167, 168, 152, 153, 154,
     0, 155, 156, 157, 158, 159, 160, 161, 162, 163,
   164, 165, 166, 167, 168
};

static const short yycheck[] = { 34,
    35, 18, 9, 10, 11, 46, 103, 147, 50, 195,
    18, 2, 3, 2, 3, 214, 111, 106, 173, 52,
    91, 220, 39, 19, 20, 319, 110, 216, 202, 46,
   398, 39, 268, 50, 96, 183, 20, 42, 66, 67,
    75, 107, 50, 9, 72, 27, 53, 1, 178, 473,
    78, 35, 32, 75, 451, 530, 10, 3, 4, 1,
     1, 68, 38, 76, 3, 4, 0, 102, 81, 59,
    60, 88, 56, 470, 91, 0, 93, 59, 60, 96,
    97, 59, 38, 116, 30, 93, 76, 38, 177, 97,
   107, 75, 38, 3, 4, 59, 180, 521, 193, 107,
    76, 136, 77, 138, 50, 110, 203, 91, 3, 4,
    76, 3, 140, 59, 136, 7, 138, 214, 59, 126,
    76, 3, 4, 220, 529, 76, 420, 275, 82, 226,
   554, 228, 607, 557, 130, 265, 132, 30, 30, 174,
    82, 271, 208, 82, 179, 38, 212, 59, 132, 211,
   183, 3, 136, 133, 138, 135, 392, 30, 50, 77,
   584, 178, 637, 81, 171, 172, 82, 59, 60, 59,
    60, 465, 82, 360, 579, 180, 363, 545, 30, 76,
    30, 188, 217, 127, 81, 76, 76, 82, 343, 77,
   134, 208, 616, 81, 211, 212, 601, 371, 50, 82,
   208, 606, 207, 608, 212, 3, 4, 59, 60, 59,
    60, 239, 617, 353, 76, 222, 151, 152, 153, 81,
   155, 156, 157, 158, 159, 160, 161, 162, 163, 164,
   165, 166, 167, 168, 76, 76, 59, 60, 273, 81,
    81, 415, 275, 30, 418, 650, 77, 82, 265, 438,
    81, 30, 50, 383, 271, 1, 550, 78, 4, 5,
     6, 7, 78, 50, 10, 9, 12, 13, 14, 366,
    81, 215, 59, 60, 371, 346, 347, 59, 60, 434,
    59, 60, 28, 76, 1, 76, 221, 4, 5, 6,
     7, 287, 288, 382, 76, 12, 13, 14, 36, 388,
   384, 50, 51, 52, 288, 389, 436, 437, 77, 78,
   301, 28, 301, 443, 444, 81, 77, 3, 4, 416,
    81, 418, 59, 60, 77, 59, 367, 467, 81, 346,
   347, 59, 60, 3, 4, 342, 82, 7, 346, 347,
     1, 77, 78, 4, 30, 6, 7, 59, 488, 3,
   367, 12, 13, 14, 77, 3, 4, 76, 400, 77,
    30, 357, 358, 370, 50, 82, 383, 28, 77, 76,
     7, 315, 81, 59, 358, 383, 30, 321, 322, 384,
    50, 398, 30, 400, 389, 77, 78, 77, 82, 59,
    60, 81, 400, 30, 76, 330, 50, 596, 27, 598,
    27, 30, 50, 9, 439, 59, 77, 36, 59, 60,
    81, 59, 60, 50, 63, 64, 77, 78, 425, 436,
   437, 365, 59, 60, 359, 83, 443, 444, 436, 437,
    59, 60, 467, 77, 77, 443, 444, 81, 36, 374,
   580, 385, 386, 387, 436, 437, 390, 391, 77, 38,
   457, 76, 81, 488, 1, 78, 3, 4, 644, 78,
   467, 3, 4, 78, 499, 7, 652, 411, 3, 76,
    78, 406, 7, 76, 76, 410, 467, 59, 467, 574,
    76, 488, 83, 83, 76, 36, 626, 627, 30, 83,
    78, 426, 527, 500, 81, 30, 531, 27, 32, 596,
    30, 598, 83, 538, 545, 547, 36, 76, 50, 453,
   506, 507, 3, 77, 76, 50, 451, 59, 553, 454,
    78, 78, 38, 507, 59, 38, 561, 81, 545, 78,
   547, 36, 78, 83, 78, 470, 571, 38, 473, 547,
    59, 485, 59, 38, 59, 580, 1, 77, 3, 4,
    77, 81, 77, 8, 9, 7, 11, 6, 7, 38,
   495, 3, 16, 12, 13, 14, 8, 9, 77, 11,
    77, 36, 78, 580, 29, 59, 31, 77, 33, 34,
    77, 59, 76, 518, 17, 40, 521, 29, 43, 31,
    77, 33, 34, 48, 49, 50, 631, 77, 40, 54,
    55, 43, 76, 58, 59, 60, 48, 49, 50, 76,
    36, 77, 54, 55, 76, 9, 77, 59, 77, 554,
    59, 81, 557, 78, 79, 80, 77, 82, 76, 54,
    55, 566, 57, 58, 59, 60, 76, 79, 80, 77,
     1, 83, 3, 4, 5, 6, 7, 8, 9, 584,
    11, 12, 13, 14, 15, 77, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 0,
    31, 3, 33, 34, 0, 4, 5, 6, 7, 40,
   343, 616, 43, 12, 13, 14, 530, 48, 49, 50,
   416, 203, 51, 54, 55, 342, 56, 186, 59, 28,
   406, 224, 1, 126, 3, 4, 5, 6, 7, 366,
   228, 10, 222, 12, 13, 14, 77, 78, 79, 80,
     1, 82, 3, 4, 5, 6, 7, 8, 9, 28,
    11, 12, 13, 14, 15, 56, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 416,
    31, 372, 33, 34, 418, 4, 5, 6, 7, 40,
   580, 10, 43, 12, 13, 14, 580, 48, 49, 50,
   634, 632, 350, 54, 55, -1, 272, 76, 59, 28,
    -1, -1, 1, -1, -1, 4, 5, 6, 7, -1,
    -1, 10, -1, 12, 13, 14, 77, -1, 79, 80,
     1, 82, 3, 4, -1, -1, -1, 8, 9, 28,
    11, -1, -1, -1, 15, -1, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, -1, 29, -1,
    31, -1, 33, 34, -1, 4, 5, 6, 7, 40,
    -1, -1, 43, 12, 13, 14, -1, 48, 49, 50,
    -1, -1, -1, 54, 55, -1, -1, 76, 59, 28,
    -1, -1, 4, -1, 6, 7, 5, 6, 7, -1,
    12, 13, 14, 12, 13, 14, 77, 78, 79, 80,
     1, 82, 3, 4, -1, -1, 28, 8, 9, -1,
    11, -1, -1, -1, 15, -1, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, -1, 29, -1,
    31, -1, 33, 34, 3, 4, 5, 6, 7, 40,
    -1, -1, 43, -1, -1, -1, -1, 48, 49, 50,
    -1, -1, -1, 54, 55, 77, 78, -1, 59, -1,
    -1, -1, 4, 5, 6, 7, -1, -1, -1, -1,
    12, 13, 14, -1, -1, -1, 77, -1, 79, 80,
     1, 82, 3, 4, -1, -1, 28, 8, 9, -1,
    11, -1, -1, -1, 15, -1, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, -1, 29, -1,
    31, -1, 33, 34, 48, 49, 50, 51, 52, 40,
    -1, -1, 43, -1, -1, -1, -1, 48, 49, 50,
    -1, -1, -1, 54, 55, 77, -1, 1, 59, 3,
     4, -1, 6, 7, 8, 9, -1, 11, 12, 13,
    14, -1, -1, -1, -1, -1, 77, -1, 79, 80,
    -1, 82, -1, -1, 28, 29, -1, 31, -1, 33,
    34, -1, -1, -1, -1, -1, 40, 54, 55, 43,
    57, 58, 59, 60, 48, 49, 50, -1, -1, -1,
    54, 55, -1, -1, 1, 59, 3, 4, -1, 76,
    -1, 8, 9, -1, 11, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 79, 80, -1, 82, -1,
    -1, -1, 29, -1, 31, -1, 33, 34, -1, -1,
    -1, -1, -1, 40, -1, -1, 43, -1, -1, -1,
    -1, 48, 49, 50, -1, -1, -1, 54, 55, -1,
    -1, 58, 59, 60, 1, -1, 3, 4, -1, -1,
    -1, 8, 9, -1, 11, -1, -1, -1, -1, -1,
    -1, 78, 79, 80, -1, 82, -1, -1, -1, -1,
    -1, -1, 29, -1, 31, -1, 33, 34, -1, -1,
    -1, -1, -1, 40, -1, -1, 43, -1, -1, -1,
    -1, 48, 49, 50, -1, -1, -1, 54, 55, -1,
    -1, 58, 59, 60, 1, -1, 3, -1, -1, -1,
    -1, 8, 9, -1, 11, 1, -1, -1, 4, 5,
     6, 7, 79, 80, -1, 82, 12, 13, 14, -1,
    -1, -1, 29, -1, 31, -1, 33, 34, -1, -1,
    -1, 27, 28, 40, 30, -1, 43, -1, -1, -1,
    36, 48, 49, 50, -1, -1, -1, 54, 55, -1,
    -1, -1, 59, 44, 45, 46, 47, 48, 49, 50,
    51, 52, -1, 59, 60, 1, -1, -1, 4, 5,
     6, 7, 79, 80, -1, 82, 12, 13, 14, -1,
    -1, 77, -1, -1, 1, 81, 82, 4, 5, 6,
     7, 27, 28, -1, 30, 12, 13, 14, -1, -1,
    36, 45, 46, 47, 48, 49, 50, 51, 52, -1,
    27, 28, -1, 30, -1, -1, -1, -1, -1, 36,
    -1, 3, -1, 59, 60, -1, 8, 9, -1, 11,
    42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
    52, 77, -1, -1, -1, 81, 82, 29, 3, 31,
    -1, 33, 34, 8, 9, -1, 11, -1, 40, -1,
    77, 43, -1, -1, 81, 82, 48, 49, 50, -1,
    -1, -1, 54, 55, 29, -1, 31, 59, 33, 34,
    -1, -1, -1, -1, -1, 40, -1, -1, 43, -1,
    -1, -1, -1, 48, 49, 50, -1, 79, 80, 54,
    55, 83, -1, 3, 59, -1, -1, -1, 8, 9,
    -1, 11, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 79, 80, -1, -1, 83, 29,
     3, 31, -1, 33, 34, 8, 9, -1, 11, -1,
    40, -1, -1, 43, -1, -1, -1, -1, 48, 49,
    50, -1, -1, -1, 54, 55, 29, -1, 31, 59,
    33, 34, 10, -1, -1, -1, -1, 40, -1, -1,
    43, -1, -1, -1, -1, 48, 49, 50, -1, 79,
    80, 54, 55, 83, -1, -1, 59, 35, 36, 37,
    38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, -1, 79, 80, -1, -1,
    83, 3, 4, 5, 6, 7, 8, 9, -1, 11,
    12, 13, 14, 15, -1, 17, 18, 19, 20, 21,
    22, 23, 24, 25, 26, 27, 28, 29, -1, 31,
    -1, 33, 34, -1, -1, -1, -1, -1, 40, -1,
    -1, 43, -1, -1, -1, -1, 48, 49, 50, -1,
    -1, -1, 54, 55, -1, -1, -1, 59, -1, -1,
    -1, 4, 5, 6, 7, -1, -1, -1, -1, 12,
    13, 14, -1, -1, -1, 77, -1, 79, 80, -1,
    82, 3, 4, -1, -1, 28, 8, 9, -1, 11,
    -1, -1, -1, 15, -1, 17, 18, 19, 20, 21,
    22, 23, 24, 25, 26, 27, -1, 29, -1, 31,
    -1, 33, 34, -1, -1, -1, -1, -1, 40, -1,
    -1, 43, -1, -1, -1, -1, 48, 49, 50, -1,
    -1, -1, 54, 55, 77, 3, -1, 59, -1, -1,
     8, 9, -1, 11, 46, 47, 48, 49, 50, 51,
    52, -1, -1, -1, -1, 77, -1, 79, 80, -1,
    82, 29, -1, 31, -1, 33, 34, -1, -1, -1,
    -1, -1, 40, -1, -1, 43, -1, -1, -1, -1,
    48, 49, 50, -1, -1, -1, 54, 55, -1, -1,
    -1, 59, 3, 4, -1, 6, 7, 8, 9, -1,
    11, 12, 13, 14, -1, -1, -1, -1, -1, -1,
    -1, 79, 80, -1, 82, -1, -1, 28, 29, 3,
    31, -1, 33, 34, 8, 9, -1, 11, -1, 40,
    -1, -1, 43, -1, -1, -1, -1, 48, 49, 50,
    -1, -1, -1, 54, 55, 29, -1, 31, 59, 33,
    34, -1, 3, -1, -1, -1, 40, 8, 9, 43,
    11, -1, -1, -1, 48, 49, 50, -1, 79, 80,
    54, 55, -1, -1, -1, 59, -1, -1, 29, 3,
    31, -1, 33, 34, 8, 9, -1, 11, -1, 40,
    -1, -1, 43, 77, -1, 79, 80, 48, 49, 50,
    -1, -1, -1, 54, 55, 29, 3, 31, 59, 33,
    34, 8, 9, -1, 11, -1, 40, -1, -1, 43,
    -1, -1, -1, -1, 48, 49, 50, -1, 79, 80,
    54, 55, 29, 3, 31, 59, 33, 34, 8, 9,
    -1, 11, -1, 40, -1, -1, 43, -1, -1, -1,
    -1, 48, 49, 50, -1, 79, 80, 54, 55, 29,
    -1, 31, 59, 33, 34, -1, -1, -1, -1, -1,
    40, -1, -1, 43, -1, -1, -1, -1, 48, 49,
    50, -1, 79, 80, 54, 55, -1, -1, 1, 59,
     3, 4, 5, 6, 7, 4, 5, 6, 7, 12,
    13, 14, -1, 12, 13, 14, -1, -1, -1, 79,
    80, -1, -1, -1, 27, 28, -1, 30, 10, 28,
    37, -1, 39, 40, 41, 42, 43, 44, 45, 46,
    47, 48, 49, 50, 51, 52, -1, 50, -1, -1,
    -1, -1, -1, 35, 36, 37, 59, 39, 40, 41,
    42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
    52, -1, -1, 4, 77, 6, 7, -1, 77, -1,
    -1, 12, 13, 14, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 28, -1, 30,
    -1, 83, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, 50,
    -1, -1, -1, -1, -1, -1, -1, -1, 59, 60,
    35, 36, 37, -1, 39, 40, 41, 42, 43, 44,
    45, 46, 47, 48, 49, 50, 51, 52, 30, -1,
    -1, -1, -1, 35, 36, 37, -1, 39, 40, 41,
    42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
    52, -1, -1, -1, -1, -1, -1, -1, 83, 35,
    36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 35, 36, 37,
    -1, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52
};
int yychar;
YYSTYPE yylval;







int yynerrs;



int yydebug;
int yyparse (void) asm("_yyparse");
int
yyparse(void) asm("_yyparse");
int
yyparse(void)
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;
  int yychar1 = 0;

  short yyssa[200];
  YYSTYPE yyvsa[200];

  short *yyss = yyssa;
  YYSTYPE *yyvs = yyvsa;
  int yystacksize = 200;
  YYSTYPE yyval;



  int yylen;


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Starting parse\n");


  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = -2;






  yyssp = yyss - 1;
  yyvsp = yyvs;







yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {


      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;





      int size = yyssp - yyss + 1;
      if (yystacksize >= 10000)
 {
   yyerror("parser stack overflow");
   return 2;
 }
      yystacksize *= 2;
      if (yystacksize > 10000)
 yystacksize = 10000;
      yyss = (short *) 
                      __builtin_alloca((
                      yystacksize * sizeof (*yyssp)
                      ))
                                                            ;
      __builtin_memcpy((char *)yyss,(char *)yyss1,size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) 
                        __builtin_alloca((
                        yystacksize * sizeof (*yyvsp)
                        ))
                                                              ;
      __builtin_memcpy((char *)yyvs,(char *)yyvs1,size * sizeof (*yyvsp));






      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;





      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Stack size increased to %d\n", yystacksize);


      if (yyssp >= yyss + yystacksize - 1)
 return(1);
    }


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Entering state %d\n", yystate);


  goto yybackup;
 yybackup:







  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yydefault;






  if (yychar == -2)
    {

      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Reading a token: ");

      yychar = yylex();
    }



  if (yychar <= 0)
    {
      yychar1 = 0;
      yychar = 0;


      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Now at end of input.\n");

    }
  else
    {
      yychar1 = ((unsigned)(yychar) <= 316 ? yytranslate[yychar] : 228);


      if (yydebug)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "Next token is %d (%s", yychar, yytname[yychar1]);



   yyprint(
  (__acrt_iob_func(2))
  ,yychar,yylval);

   fprintf (
           (__acrt_iob_func(2))
                 , ")\n");
 }

    }

  yyn += yychar1;
  if (yyn < 0 || yyn > 2115 || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == 658)
    return(0);




  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Shifting token %d (%s), ", yychar, yytname[yychar1]);



  if (yychar != 0)
    yychar = -2;

  *++yyvsp = yylval;





  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;


yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen];


  if (yydebug)
    {
      int i;

      fprintf (
              (__acrt_iob_func(2))
                    , "Reducing via rule %d (line %d), ",
        yyn, yyrline[yyn]);


      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
 fprintf (
         (__acrt_iob_func(2))
               , "%s ", yytname[yyrhs[i]]);
      fprintf (
              (__acrt_iob_func(2))
                    , " -> %s\n", yytname[yyr1[yyn]]);
    }



  switch (yyn) {

case 1:
{ if (pedantic)
      pedwarn ("ANSI C forbids an empty source file");
    finish_file ();
  ;
    break;}
case 2:
{


    while (! global_bindings_p ())
      poplevel (0, 0, 0);
    finish_file ();
  ;
    break;}
case 3:
{yyval.ttype = (tree) 
              ((void *)0)
                       ; ;
    break;}
case 5:
{yyval.ttype = (tree) 
              ((void *)0)
                       ; ;
    break;}
case 9:
{ while ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == NON_LVALUE_EXPR) && (((((yyvsp[-2].ttype)->common.type))->type.mode) == ((((((yyvsp[-2].ttype)->exp.operands[0]))->common.type))->type.mode))) (yyvsp[-2].ttype) = ((yyvsp[-2].ttype)->exp.operands[0]);;
    if ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == ADDR_EXPR
         && ((n64_enum_tree_code) (((yyvsp[-2].ttype)->exp.operands[0]))->common.code) == STRING_CST)
        || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == STRING_CST)
      assemble_asm (yyvsp[-2].ttype);
    else
      error ("argument of `asm' is not a constant string"); ;
    break;}
case 10:
{ if (pedantic)
      error ("ANSI C forbids data definition with no type or storage class");
    else if (!flag_traditional)
      warning ("data definition has no type or storage class");

    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 11:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 12:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 13:
{ pedwarn ("empty declaration"); ;
    break;}
case 14:
{ shadow_tag (yyvsp[-1].ttype); ;
    break;}
case 17:
{ if (pedantic)
      pedwarn ("ANSI C does not allow extra `;' outside of a function"); ;
    break;}
case 18:
{ if (! start_function (yyvsp[-2].ttype, yyvsp[0].ttype, prefix_attributes,
     (tree) 
    ((void *)0)
             , 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function (); ;
    break;}
case 19:
{ store_parm_decls (); ;
    break;}
case 20:
{ finish_function (0);
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-5].itype); ;
    break;}
case 21:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 22:
{ if (! start_function (yyvsp[-2].ttype, yyvsp[0].ttype, prefix_attributes,
     (tree) 
    ((void *)0)
             , 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function (); ;
    break;}
case 23:
{ store_parm_decls (); ;
    break;}
case 24:
{ finish_function (0);
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-5].itype); ;
    break;}
case 25:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 26:
{ if (! start_function ((tree) 
                       ((void *)0)
                                , yyvsp[0].ttype,
     prefix_attributes, (tree) 
                       ((void *)0)
                                , 0))
      { yyerror ("syntax error"); goto yyerrlab1; };
    reinit_parse_for_function (); ;
    break;}
case 27:
{ store_parm_decls (); ;
    break;}
case 28:
{ finish_function (0);
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-5].itype); ;
    break;}
case 29:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 32:
{ yyval.code = ADDR_EXPR; ;
    break;}
case 33:
{ yyval.code = NEGATE_EXPR; ;
    break;}
case 34:
{ yyval.code = CONVERT_EXPR; ;
    break;}
case 35:
{ yyval.code = PREINCREMENT_EXPR; ;
    break;}
case 36:
{ yyval.code = PREDECREMENT_EXPR; ;
    break;}
case 37:
{ yyval.code = BIT_NOT_EXPR; ;
    break;}
case 38:
{ yyval.code = TRUTH_NOT_EXPR; ;
    break;}
case 39:
{ yyval.ttype = build_compound_expr (yyvsp[0].ttype); ;
    break;}
case 40:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 42:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyvsp[0].ttype); ;
    break;}
case 43:
{ chainon (yyvsp[-2].ttype, build_tree_list ((tree) 
                                            ((void *)0)
                                                     , yyvsp[0].ttype)); ;
    break;}
case 45:
{ yyval.ttype = build_indirect_ref (yyvsp[0].ttype, "unary *"); ;
    break;}
case 46:
{ yyvsp[0].itype = pedantic;
    pedantic = 0; ;
    break;}
case 47:
{ yyval.ttype = yyvsp[0].ttype;
    pedantic = yyvsp[-2].itype; ;
    break;}
case 48:
{ yyval.ttype = build_unary_op (yyvsp[-1].code, yyvsp[0].ttype, 0);
    overflow_warning (yyval.ttype); ;
    break;}
case 49:
{ tree label = lookup_label (yyvsp[0].ttype);
    if (pedantic)
      pedwarn ("ANSI C forbids `&&'");
    if (label == 0)
      yyval.ttype = null_pointer_node;
    else
      {
        ((label)->common.used_flag) = 1;
        yyval.ttype = build1 (ADDR_EXPR, ptr_type_node, label);
        ((yyval.ttype)->common.constant_flag) = 1;
      }
  ;
    break;}
case 50:
{ if (((n64_enum_tree_code) (yyvsp[0].ttype)->common.code) == COMPONENT_REF
        && ((((yyvsp[0].ttype)->exp.operands[1]))->decl.bit_field_flag))
      error ("`sizeof' applied to a bit-field");
    yyval.ttype = c_sizeof (((yyvsp[0].ttype)->common.type)); ;
    break;}
case 51:
{ yyval.ttype = c_sizeof (groktypename (yyvsp[-1].ttype)); ;
    break;}
case 52:
{ yyval.ttype = c_alignof_expr (yyvsp[0].ttype); ;
    break;}
case 53:
{ yyval.ttype = c_alignof (groktypename (yyvsp[-1].ttype)); ;
    break;}
case 54:
{ yyval.ttype = build_unary_op (REALPART_EXPR, yyvsp[0].ttype, 0); ;
    break;}
case 55:
{ yyval.ttype = build_unary_op (IMAGPART_EXPR, yyvsp[0].ttype, 0); ;
    break;}
case 57:
{ tree type = groktypename (yyvsp[-2].ttype);
    yyval.ttype = build_c_cast (type, yyvsp[0].ttype); ;
    break;}
case 58:
{ start_init ((tree) 
             ((void *)0)
                      , 
                        ((void *)0)
                            , 0);
    yyvsp[-2].ttype = groktypename (yyvsp[-2].ttype);
    really_start_incremental_init (yyvsp[-2].ttype); ;
    break;}
case 59:
{ char *name;
    tree result = pop_init_level (0);
    tree type = yyvsp[-5].ttype;
    finish_init ();

    if (pedantic)
      pedwarn ("ANSI C forbids constructor expressions");
    if (((type)->type.name) != 0)
      {
        if (((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE)
   name = ((((type)->type.name))->identifier.pointer);
        else
   name = ((((((type)->type.name))->decl.name))->identifier.pointer);
      }
    else
      name = "";
    yyval.ttype = result;
    if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && ((type)->type.size) == 0)
      {
        int failure = complete_array_type (type, yyval.ttype, 1);
        if (failure)
   abort ();
      }
  ;
    break;}
case 61:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 62:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 63:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 64:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 65:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 66:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 67:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 68:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 69:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 70:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 71:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 72:
{ yyval.ttype = parser_build_binary_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 73:
{ yyval.ttype = parser_build_binary_op (TRUTH_ANDIF_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 74:
{ yyval.ttype = parser_build_binary_op (TRUTH_ORIF_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 75:
{ yyval.ttype = build_conditional_expr (yyvsp[-4].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 76:
{ yyval.ttype = build_modify_expr (yyvsp[-2].ttype, NOP_EXPR, yyvsp[0].ttype);
    (((yyval.ttype)->exp.complexity) = (int)(MODIFY_EXPR)); ;
    break;}
case 77:
{ yyval.ttype = build_modify_expr (yyvsp[-2].ttype, yyvsp[-1].code, yyvsp[0].ttype);

    (((yyval.ttype)->exp.complexity) = (int)(ERROR_MARK)); ;
    break;}
case 78:
{
    yyval.ttype = lastiddecl;
    if (!yyval.ttype || yyval.ttype == error_mark_node)
      {
        if (yychar == -2)
   yychar = yylex();
        if (yychar == '(')
   {
       {

         yyval.ttype = implicitly_declare (yyvsp[0].ttype);
         assemble_external (yyval.ttype);
         ((yyval.ttype)->common.used_flag) = 1;
       }
   }
        else if (current_function_decl == 0)
   {
     error ("`%s' undeclared here (not in a function)",
     ((yyvsp[0].ttype)->identifier.pointer));
     yyval.ttype = error_mark_node;
   }
        else
   {
       {
         if ((((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->global_value) != error_mark_node
      || (((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->error_locus) != current_function_decl)
    {
      error ("`%s' undeclared (first use this function)",
      ((yyvsp[0].ttype)->identifier.pointer));

      if (! undeclared_variable_notice)
        {
          error ("(Each undeclared identifier is reported only once");
          error ("for each function it appears in.)");
          undeclared_variable_notice = 1;
        }
    }
         yyval.ttype = error_mark_node;

         (((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->global_value) = error_mark_node;
         (((struct n64_tag_lang_identifier *)(yyvsp[0].ttype))->error_locus) = current_function_decl;
       }
   }
      }
    else if (((yyval.ttype)->common.type) == error_mark_node)
      yyval.ttype = error_mark_node;
    else if ((((yyval.ttype))->decl.lang_flag_3))
      {


        (((yyval.ttype))->decl.lang_flag_3) = 0;
        if (yychar == -2)
   yychar = yylex();
        if (yychar == '(')
   {




       if (((n64_enum_tree_code) (yyval.ttype)->common.code) != FUNCTION_DECL)
         error ("`%s' implicitly declared as function",
         ((((yyval.ttype)->decl.name))->identifier.pointer));
     else if ((((((((yyval.ttype)->common.type))->common.type))->type.mode)
        != ((integer_type_node)->type.mode))
       && (((((yyval.ttype)->common.type))->common.type)
           != void_type_node))
       pedwarn ("type mismatch in implicit declaration for built-in function `%s'",
         ((((yyval.ttype)->decl.name))->identifier.pointer));

     if (((((yyval.ttype)->common.type))->common.type) == void_type_node)
       ((yyval.ttype)->common.type)
         = build_function_type (integer_type_node,
           ((((yyval.ttype)->common.type))->type.values));
   }
        else
   pedwarn ("built-in function `%s' used without declaration",
     ((((yyval.ttype)->decl.name))->identifier.pointer));


        assemble_external (yyval.ttype);
        ((yyval.ttype)->common.used_flag) = 1;
      }
    else
      {
        assemble_external (yyval.ttype);
        ((yyval.ttype)->common.used_flag) = 1;
      }

    if (((n64_enum_tree_code) (yyval.ttype)->common.code) == CONST_DECL)
      {
        yyval.ttype = ((yyval.ttype)->decl.initial);


        yyval.ttype = build1 (NOP_EXPR, ((yyval.ttype)->common.type), yyval.ttype);
        ((yyval.ttype)->common.constant_flag) = 1;
      }
  ;
    break;}
case 80:
{ yyval.ttype = combine_strings (yyvsp[0].ttype); ;
    break;}
case 81:
{ char cxx_class = (*tree_code_type[(int) (((n64_enum_tree_code) (yyvsp[-1].ttype)->common.code))]);
    if (cxx_class == 'e' || cxx_class == '1'
        || cxx_class == '2' || cxx_class == '<')
      (((yyvsp[-1].ttype)->exp.complexity) = (int)(ERROR_MARK));
    yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 82:
{ yyval.ttype = error_mark_node; ;
    break;}
case 83:
{ if (current_function_decl == 0)
      {
        error ("braced-group within expression allowed only inside a function");
        goto yyerrlab1;
      }




    keep_next_level ();
    push_iterator_stack ();
    push_label_level ();
    yyval.ttype = expand_start_stmt_expr (); ;
    break;}
case 84:
{ tree rtl_exp;
    if (pedantic)
      pedwarn ("ANSI C forbids braced-groups within expressions");
    pop_iterator_stack ();
    pop_label_level ();
    rtl_exp = expand_end_stmt_expr (yyvsp[-2].ttype);

    ((rtl_exp)->common.side_effects_flag) = 1;

    if (((n64_enum_tree_code) (yyvsp[-1].ttype)->common.code) == BLOCK)
      {

        yyval.ttype = build (BIND_EXPR, ((rtl_exp)->common.type),
      (tree) 
     ((void *)0)
              , rtl_exp, yyvsp[-1].ttype);



        delete_block (yyvsp[-1].ttype);
      }
    else
      yyval.ttype = yyvsp[-1].ttype;
  ;
    break;}
case 85:
{ yyval.ttype = build_function_call (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 86:
{ yyval.ttype = build_array_ref (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 87:
{
      yyval.ttype = build_component_ref (yyvsp[-2].ttype, yyvsp[0].ttype);
  ;
    break;}
case 88:
{
                  tree expr = build_indirect_ref (yyvsp[-2].ttype, "->");

                    yyval.ttype = build_component_ref (expr, yyvsp[0].ttype);
  ;
    break;}
case 89:
{ yyval.ttype = build_unary_op (POSTINCREMENT_EXPR, yyvsp[-1].ttype, 0); ;
    break;}
case 90:
{ yyval.ttype = build_unary_op (POSTDECREMENT_EXPR, yyvsp[-1].ttype, 0); ;
    break;}
case 92:
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 95:
{ c_mark_varargs ();
    if (pedantic)
      pedwarn ("ANSI C does not permit use of `varargs.h'"); ;
    break;}
case 96:
{ ;
    break;}
case 101:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 102:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 103:
{ shadow_tag_warned (yyvsp[-1].ttype, 1);
    pedwarn ("empty declaration"); ;
    break;}
case 104:
{ pedwarn ("empty declaration"); ;
    break;}
case 105:
{ ;
    break;}
case 110:
{ yyval.itype = suspend_momentary ();
    pending_xref_error ();
    declspec_stack = tree_cons (prefix_attributes,
           current_declspecs,
           declspec_stack);
    current_declspecs = yyvsp[0].ttype;
    prefix_attributes = (tree) 
                       ((void *)0)
                                ; ;
    break;}
case 111:
{ prefix_attributes = chainon (prefix_attributes, yyvsp[0].ttype); ;
    break;}
case 112:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 113:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 114:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-1].itype); ;
    break;}
case 115:
{ current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-1].itype); ;
    break;}
case 116:
{ shadow_tag (yyvsp[-1].ttype); ;
    break;}
case 117:
{ pedwarn ("empty declaration"); ;
    break;}
case 118:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 119:
{ yyval.ttype = chainon (yyvsp[0].ttype, tree_cons ((tree) 
                                                   ((void *)0)
                                                            , yyvsp[-1].ttype, yyvsp[-2].ttype)); ;
    break;}
case 120:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 121:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 122:
{ if (extra_warnings)
      warning ("`%s' is not at beginning of declaration",
        ((yyvsp[0].ttype)->identifier.pointer));
    yyval.ttype = tree_cons ((tree) 
                            ((void *)0)
                                     , yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 123:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              );
    ((yyval.ttype)->common.static_flag) = 1; ;
    break;}
case 124:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 125:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyvsp[-1].ttype);
    ((yyval.ttype)->common.static_flag) = 1; ;
    break;}
case 126:
{ if (extra_warnings && ((yyvsp[-1].ttype)->common.static_flag))
      warning ("`%s' is not at beginning of declaration",
        ((yyvsp[0].ttype)->identifier.pointer));
    yyval.ttype = tree_cons ((tree) 
                            ((void *)0)
                                     , yyvsp[0].ttype, yyvsp[-1].ttype);
    ((yyval.ttype)->common.static_flag) = ((yyvsp[-1].ttype)->common.static_flag); ;
    break;}
case 127:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 128:
{ yyval.ttype = chainon (yyvsp[0].ttype, tree_cons ((tree) 
                                                   ((void *)0)
                                                            , yyvsp[-1].ttype, yyvsp[-2].ttype)); ;
    break;}
case 129:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 130:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 133:
{

    yyval.ttype = lookup_name (yyvsp[0].ttype); ;
    break;}
case 134:
{ yyval.ttype = ((yyvsp[-1].ttype)->common.type); ;
    break;}
case 135:
{ yyval.ttype = groktypename (yyvsp[-1].ttype); ;
    break;}
case 143:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 144:
{ if (((yyvsp[-1].ttype)->common.chain)) yyvsp[-1].ttype = combine_strings (yyvsp[-1].ttype);
    yyval.ttype = yyvsp[-1].ttype;
  ;
    break;}
case 145:
{ yyval.ttype = start_decl (yyvsp[-3].ttype, current_declspecs, 1,
       yyvsp[-1].ttype, prefix_attributes);
    start_init (yyval.ttype, yyvsp[-2].ttype, global_bindings_p ()); ;
    break;}
case 146:
{ finish_init ();
    finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype); ;
    break;}
case 147:
{ tree d = start_decl (yyvsp[-2].ttype, current_declspecs, 0,
           yyvsp[0].ttype, prefix_attributes);
    finish_decl (d, (tree) 
                   ((void *)0)
                            , yyvsp[-1].ttype);
                ;
    break;}
case 148:
{ yyval.ttype = start_decl (yyvsp[-3].ttype, current_declspecs, 1,
       yyvsp[-1].ttype, prefix_attributes);
    start_init (yyval.ttype, yyvsp[-2].ttype, global_bindings_p ()); ;
    break;}
case 149:
{ finish_init ();
    decl_attributes (yyvsp[-1].ttype, yyvsp[-3].ttype, prefix_attributes);
    finish_decl (yyvsp[-1].ttype, yyvsp[0].ttype, yyvsp[-4].ttype); ;
    break;}
case 150:
{ tree d = start_decl (yyvsp[-2].ttype, current_declspecs, 0,
           yyvsp[0].ttype, prefix_attributes);
    finish_decl (d, (tree) 
                   ((void *)0)
                            , yyvsp[-1].ttype); ;
    break;}
case 151:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 152:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 153:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 154:
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 155:
{ yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 156:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 157:
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 158:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 159:
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, (tree) 
                                                ((void *)0)
                                                         ); ;
    break;}
case 160:
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, build_tree_list ((tree) 
                                                                  ((void *)0)
                                                                           , yyvsp[-1].ttype)); ;
    break;}
case 161:
{ yyval.ttype = build_tree_list (yyvsp[-5].ttype, tree_cons ((tree) 
                                                            ((void *)0)
                                                                     , yyvsp[-3].ttype, yyvsp[-1].ttype)); ;
    break;}
case 162:
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 168:
{ really_start_incremental_init ((tree) 
                                ((void *)0)
                                         );


    push_momentary (); ;
    break;}
case 169:
{ yyval.ttype = pop_init_level (0);
    if (yyval.ttype == error_mark_node
        && ! (yychar == 264 || yychar == 263))
      pop_momentary ();
    else
      pop_momentary_nofree (); ;
    break;}
case 170:
{ yyval.ttype = error_mark_node; ;
    break;}
case 171:
{ if (pedantic)
      pedwarn ("ANSI C forbids empty initializer braces"); ;
    break;}
case 175:
{ process_init_element (yyvsp[0].ttype); ;
    break;}
case 176:
{ push_init_level (0); ;
    break;}
case 177:
{ process_init_element (pop_init_level (0)); ;
    break;}
case 179:
{ set_init_index (yyvsp[-4].ttype, yyvsp[-2].ttype); ;
    break;}
case 181:
{ set_init_index (yyvsp[-2].ttype, (tree) 
                                  ((void *)0)
                                           ); ;
    break;}
case 183:
{ set_init_index (yyvsp[-1].ttype, (tree) 
                                  ((void *)0)
                                           ); ;
    break;}
case 185:
{ set_init_label (yyvsp[-1].ttype); ;
    break;}
case 187:
{ set_init_label (yyvsp[-1].ttype); ;
    break;}
case 189:
{ push_c_function_context ();
    if (! start_function (current_declspecs, yyvsp[0].ttype,
     prefix_attributes, (tree) 
                       ((void *)0)
                                , 1))
      {
        pop_c_function_context ();
        { yyerror ("syntax error"); goto yyerrlab1; };
      }
    reinit_parse_for_function (); ;
    break;}
case 190:
{ store_parm_decls (); ;
    break;}
case 191:
{ finish_function (1);
    pop_c_function_context (); ;
    break;}
case 192:
{ push_c_function_context ();
    if (! start_function (current_declspecs, yyvsp[0].ttype,
     prefix_attributes, (tree) 
                       ((void *)0)
                                , 1))
      {
        pop_c_function_context ();
        { yyerror ("syntax error"); goto yyerrlab1; };
      }
    reinit_parse_for_function (); ;
    break;}
case 193:
{ store_parm_decls (); ;
    break;}
case 194:
{ finish_function (1);
    pop_c_function_context (); ;
    break;}
case 197:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 198:
{ yyval.ttype = build_nt (CALL_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype, (tree) 
                                                                     ((void *)0)
                                                                              ); ;
    break;}
case 199:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 200:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-2].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 201:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 202:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 204:
{ yyval.ttype = build_nt (CALL_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype, (tree) 
                                                                     ((void *)0)
                                                                              ); ;
    break;}
case 205:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 206:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-2].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 207:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 208:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 210:
{ yyval.ttype = build_nt (CALL_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype, (tree) 
                                                                     ((void *)0)
                                                                              ); ;
    break;}
case 211:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 212:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 213:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 214:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-2].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 215:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 217:
{ yyval.ttype = start_struct (RECORD_TYPE, yyvsp[-1].ttype);

  ;
    break;}
case 218:
{ yyval.ttype = finish_struct (yyvsp[-3].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 219:
{ yyval.ttype = finish_struct (start_struct (RECORD_TYPE, (tree) 
                                                         ((void *)0)
                                                                  ),
          yyvsp[-2].ttype, yyvsp[0].ttype);
  ;
    break;}
case 220:
{ yyval.ttype = xref_tag (RECORD_TYPE, yyvsp[0].ttype); ;
    break;}
case 221:
{ yyval.ttype = start_struct (UNION_TYPE, yyvsp[-1].ttype); ;
    break;}
case 222:
{ yyval.ttype = finish_struct (yyvsp[-3].ttype, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 223:
{ yyval.ttype = finish_struct (start_struct (UNION_TYPE, (tree) 
                                                        ((void *)0)
                                                                 ),
          yyvsp[-2].ttype, yyvsp[0].ttype);
  ;
    break;}
case 224:
{ yyval.ttype = xref_tag (UNION_TYPE, yyvsp[0].ttype); ;
    break;}
case 225:
{ yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_enum (yyvsp[-1].ttype); ;
    break;}
case 226:
{ yyval.ttype = finish_enum (yyvsp[-4].ttype, nreverse (yyvsp[-3].ttype), yyvsp[0].ttype);
    resume_momentary (yyvsp[-5].itype); ;
    break;}
case 227:
{ yyvsp[0].itype = suspend_momentary ();
    yyval.ttype = start_enum ((tree) 
                             ((void *)0)
                                      ); ;
    break;}
case 228:
{ yyval.ttype = finish_enum (yyvsp[-4].ttype, nreverse (yyvsp[-3].ttype), yyvsp[0].ttype);
    resume_momentary (yyvsp[-5].itype); ;
    break;}
case 229:
{ yyval.ttype = xref_tag (ENUMERAL_TYPE, yyvsp[0].ttype); ;
    break;}
case 233:
{ if (pedantic) pedwarn ("comma at end of enumerator list"); ;
    break;}
case 234:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 235:
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype);
    pedwarn ("no semicolon at end of struct or union"); ;
    break;}
case 236:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 237:
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[-1].ttype); ;
    break;}
case 238:
{ if (pedantic)
      pedwarn ("extra semicolon in struct or union specified"); ;
    break;}
case 239:
{ yyval.ttype = yyvsp[0].ttype;
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-1].itype); ;
    break;}
case 240:
{ if (pedantic)
      pedwarn ("ANSI C forbids member declarations with no members");
    shadow_tag(yyvsp[0].ttype);
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 241:
{ yyval.ttype = yyvsp[0].ttype;
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-1].itype); ;
    break;}
case 242:
{ if (pedantic)
      pedwarn ("ANSI C forbids member declarations with no members");
    shadow_tag(yyvsp[0].ttype);
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 243:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 245:
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 246:
{ yyval.ttype = grokfield (yyvsp[-3].filename, yyvsp[-2].lineno, yyvsp[-1].ttype, current_declspecs, (tree) 
                                                                                                    ((void *)0)
                                                                                                             );
    decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 247:
{ yyval.ttype = grokfield (yyvsp[-5].filename, yyvsp[-4].lineno, yyvsp[-3].ttype, current_declspecs, yyvsp[-1].ttype);
    decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 248:
{ yyval.ttype = grokfield (yyvsp[-4].filename, yyvsp[-3].lineno, (tree) 
                                                                ((void *)0)
                                                                         , current_declspecs, yyvsp[-1].ttype);
    decl_attributes (yyval.ttype, yyvsp[0].ttype, prefix_attributes); ;
    break;}
case 250:
{ if (yyvsp[-2].ttype == error_mark_node)
      yyval.ttype = yyvsp[-2].ttype;
    else
      yyval.ttype = chainon (yyvsp[0].ttype, yyvsp[-2].ttype); ;
    break;}
case 251:
{ yyval.ttype = error_mark_node; ;
    break;}
case 252:
{ yyval.ttype = build_enumerator (yyvsp[0].ttype, (tree) 
                                                 ((void *)0)
                                                          ); ;
    break;}
case 253:
{ yyval.ttype = build_enumerator (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 254:
{ yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 255:
{ yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 256:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 258:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 259:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 260:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 261:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 262:
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 263:
{ yyval.ttype = make_pointer_declarator (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 264:
{ yyval.ttype = make_pointer_declarator (yyvsp[0].ttype, (tree) 
                                                        ((void *)0)
                                                                 ); ;
    break;}
case 265:
{ yyval.ttype = build_nt (CALL_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype, (tree) 
                                                                     ((void *)0)
                                                                              ); ;
    break;}
case 266:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 267:
{ yyval.ttype = build_nt (ARRAY_REF, yyvsp[-2].ttype, (tree) 
                                                     ((void *)0)
                                                              ); ;
    break;}
case 268:
{ yyval.ttype = build_nt (CALL_EXPR, (tree) 
                                    ((void *)0)
                                             , yyvsp[0].ttype, (tree) 
                                                               ((void *)0)
                                                                        ); ;
    break;}
case 269:
{ yyval.ttype = build_nt (ARRAY_REF, (tree) 
                                    ((void *)0)
                                             , yyvsp[-1].ttype); ;
    break;}
case 270:
{ yyval.ttype = build_nt (ARRAY_REF, (tree) 
                                    ((void *)0)
                                             , (tree) 
                                               ((void *)0)
                                                        ); ;
    break;}
case 271:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 272:
{
    if (pedantic && yyvsp[0].ends_in_label)
      pedwarn ("ANSI C forbids label at end of compound statement");
  ;
    break;}
case 274:
{ yyval.ends_in_label = yyvsp[0].ends_in_label; ;
    break;}
case 275:
{ yyval.ends_in_label = 0; ;
    break;}
case 279:
{ emit_line_note (input_filename, lineno);
    pushlevel (0);
    clear_last_expr ();
    push_momentary ();
    expand_start_bindings (0);
  ;
    break;}
case 281:
{ if (pedantic)
      pedwarn ("ANSI C forbids label declarations"); ;
    break;}
case 284:
{ tree link;
    for (link = yyvsp[-1].ttype; link; link = ((link)->common.chain))
      {
        tree label = shadow_label (((link)->list.value));
        ((label)->common.lang_flag_1) = 1;
        declare_nonlocal_label (label);
      }
  ;
    break;}
case 285:
{;
    break;}
case 287:
{ yyval.ttype = convert (void_type_node, integer_zero_node); ;
    break;}
case 288:
{ emit_line_note (input_filename, lineno);
    expand_end_bindings (getdecls (), 1, 0);
    yyval.ttype = poplevel (1, 1, 0);
    if (yychar == 263 || yychar == 264)
      pop_momentary_nofree ();
    else
      pop_momentary (); ;
    break;}
case 289:
{ emit_line_note (input_filename, lineno);
    expand_end_bindings (getdecls (), kept_level_p (), 0);
    yyval.ttype = poplevel (kept_level_p (), 0, 0);
    if (yychar == 263 || yychar == 264)
      pop_momentary_nofree ();
    else
      pop_momentary (); ;
    break;}
case 290:
{ emit_line_note (input_filename, lineno);
    expand_end_bindings (getdecls (), kept_level_p (), 0);
    yyval.ttype = poplevel (kept_level_p (), 0, 0);
    if (yychar == 263 || yychar == 264)
      pop_momentary_nofree ();
    else
      pop_momentary (); ;
    break;}
case 293:
{ emit_line_note (yyvsp[-5].filename, yyvsp[-4].lineno);
    expand_start_cond (truthvalue_conversion (yyvsp[-1].ttype), 0);
    yyval.itype = stmt_count;
    if_stmt_file = yyvsp[-5].filename;
    if_stmt_line = yyvsp[-4].lineno;
    position_after_white_space (); ;
    break;}
case 294:
{ stmt_count++;
    emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);

    emit_nop ();
    expand_start_loop_continue_elsewhere (1);
    position_after_white_space (); ;
    break;}
case 295:
{ expand_loop_continue_here (); ;
    break;}
case 296:
{ yyval.filename = input_filename; ;
    break;}
case 297:
{ yyval.lineno = lineno; ;
    break;}
case 298:
{ ;
    break;}
case 299:
{ ;
    break;}
case 300:
{ yyval.ends_in_label = yyvsp[0].ends_in_label; ;
    break;}
case 301:
{ yyval.ends_in_label = 0; ;
    break;}
case 302:
{ yyval.ends_in_label = 1; ;
    break;}
case 303:
{ stmt_count++; ;
    break;}
case 305:
{ stmt_count++;
    emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
    iterator_expand (yyvsp[-1].ttype);
    clear_momentary (); ;
    break;}
case 306:
{ expand_start_else ();
    yyvsp[-1].itype = stmt_count;
    position_after_white_space (); ;
    break;}
case 307:
{ expand_end_cond ();
    if (extra_warnings && stmt_count == yyvsp[-3].itype)
      warning ("empty body in an else-statement"); ;
    break;}
case 308:
{ expand_end_cond ();




    if (extra_warnings && stmt_count++ == yyvsp[0].itype)
      warning_with_file_and_line (if_stmt_file, if_stmt_line,
      "empty body in an if-statement"); ;
    break;}
case 309:
{ expand_end_cond (); ;
    break;}
case 310:
{ stmt_count++;
    emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);






    emit_nop (); ;
    break;}
case 311:
{


    expand_start_loop (1);
    emit_line_note (input_filename, lineno);
    expand_exit_loop_if_false (((void *)0),
          truthvalue_conversion (yyvsp[-1].ttype));
    position_after_white_space (); ;
    break;}
case 312:
{ expand_end_loop (); ;
    break;}
case 313:
{ emit_line_note (input_filename, lineno);
    expand_exit_loop_if_false (((void *)0),
          truthvalue_conversion (yyvsp[-2].ttype));
    expand_end_loop ();
    clear_momentary (); ;
    break;}
case 314:
{ expand_end_loop ();
    clear_momentary (); ;
    break;}
case 315:
{ stmt_count++;
    emit_line_note (yyvsp[-5].filename, yyvsp[-4].lineno);

    emit_nop ();
    if (yyvsp[-1].ttype) c_expand_expr_stmt (yyvsp[-1].ttype);




  ;
    break;}
case 316:
{ yyvsp[0].lineno = lineno;
    yyval.filename = input_filename; ;
    break;}
case 317:
{


    expand_start_loop_continue_elsewhere (1);

    emit_line_note (yyvsp[-2].filename, yyvsp[-3].lineno);
    if (yyvsp[-4].ttype)
      expand_exit_loop_if_false (((void *)0),
            truthvalue_conversion (yyvsp[-4].ttype));


    push_momentary ();
    yyvsp[-3].lineno = lineno;
    yyvsp[-2].filename = input_filename;
    position_after_white_space (); ;
    break;}
case 318:
{
    emit_line_note (yyvsp[-4].filename, yyvsp[-5].lineno);
    expand_loop_continue_here ();
    if (yyvsp[-3].ttype)
      c_expand_expr_stmt (yyvsp[-3].ttype);
    if (yychar == 263 || yychar == 264)
      pop_momentary_nofree ();
    else
      pop_momentary ();
    expand_end_loop (); ;
    break;}
case 319:
{ stmt_count++;
    emit_line_note (yyvsp[-5].filename, yyvsp[-4].lineno);
    c_expand_start_case (yyvsp[-1].ttype);


    push_momentary ();
    position_after_white_space (); ;
    break;}
case 320:
{ expand_end_case (yyvsp[-3].ttype);
    if (yychar == 263 || yychar == 264)
      pop_momentary_nofree ();
    else
      pop_momentary (); ;
    break;}
case 321:
{ stmt_count++;
    emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
    if ( ! expand_exit_something ())
      error ("break statement not within loop or switch"); ;
    break;}
case 322:
{ stmt_count++;
    emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
    if (! expand_continue_loop (((void *)0)))
      error ("continue statement not within a loop"); ;
    break;}
case 323:
{ stmt_count++;
    emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
    c_expand_return ((tree) 
                    ((void *)0)
                             ); ;
    break;}
case 324:
{ stmt_count++;
    emit_line_note (yyvsp[-4].filename, yyvsp[-3].lineno);
    c_expand_return (yyvsp[-1].ttype); ;
    break;}
case 325:
{ stmt_count++;
    emit_line_note (yyvsp[-7].filename, yyvsp[-6].lineno);
    while ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == NON_LVALUE_EXPR) && (((((yyvsp[-2].ttype)->common.type))->type.mode) == ((((((yyvsp[-2].ttype)->exp.operands[0]))->common.type))->type.mode))) (yyvsp[-2].ttype) = ((yyvsp[-2].ttype)->exp.operands[0]);;
    if ((((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == ADDR_EXPR
         && ((n64_enum_tree_code) (((yyvsp[-2].ttype)->exp.operands[0]))->common.code) == STRING_CST)
        || ((n64_enum_tree_code) (yyvsp[-2].ttype)->common.code) == STRING_CST)
      expand_asm (yyvsp[-2].ttype);
    else
      error ("argument of `asm' is not a constant string"); ;
    break;}
case 326:
{ stmt_count++;
    emit_line_note (yyvsp[-9].filename, yyvsp[-8].lineno);
    c_expand_asm_operands (yyvsp[-4].ttype, yyvsp[-2].ttype, (tree) 
                                                            ((void *)0)
                                                                     , (tree) 
                                                                       ((void *)0)
                                                                                ,
      yyvsp[-6].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno); ;
    break;}
case 327:
{ stmt_count++;
    emit_line_note (yyvsp[-11].filename, yyvsp[-10].lineno);
    c_expand_asm_operands (yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype, (tree) 
                                                                             ((void *)0)
                                                                                      ,
      yyvsp[-8].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno); ;
    break;}
case 328:
{ stmt_count++;
    emit_line_note (yyvsp[-13].filename, yyvsp[-12].lineno);
    c_expand_asm_operands (yyvsp[-8].ttype, yyvsp[-6].ttype, yyvsp[-4].ttype, yyvsp[-2].ttype,
      yyvsp[-10].ttype == ridpointers[(int)RID_VOLATILE],
      input_filename, lineno); ;
    break;}
case 329:
{ tree decl;
    stmt_count++;
    emit_line_note (yyvsp[-4].filename, yyvsp[-3].lineno);
    decl = lookup_label (yyvsp[-1].ttype);
    if (decl != 0)
      {
        ((decl)->common.used_flag) = 1;
        expand_goto (decl);
      }
  ;
    break;}
case 330:
{ stmt_count++;
    emit_line_note (yyvsp[-5].filename, yyvsp[-4].lineno);
    expand_computed_goto (convert (ptr_type_node, yyvsp[-1].ttype)); ;
    break;}
case 333:
{




     yyval.itype = 0;
     if (((n64_enum_tree_code) (yyvsp[-1].ttype)->common.code) != VAR_DECL)
       error ("invalid `for (ITERATOR)' syntax");
     else if (! (((yyvsp[-1].ttype)->decl.lang_flag_4)))
       error ("`%s' is not an iterator",
       ((((yyvsp[-1].ttype)->decl.name))->identifier.pointer));
     else if (((yyvsp[-1].ttype)->common.readonly_flag))
       error ("`for (%s)' inside expansion of same iterator",
       ((((yyvsp[-1].ttype)->decl.name))->identifier.pointer));
     else
       {
  yyval.itype = 1;
  iterator_for_loop_start (yyvsp[-1].ttype);
       }
   ;
    break;}
case 334:
{
     if (yyvsp[-1].itype)
       iterator_for_loop_end (yyvsp[-3].ttype);
   ;
    break;}
case 335:
{ register tree value = check_case_value (yyvsp[-1].ttype);
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );

    stmt_count++;

    if (value != error_mark_node)
      {
        tree duplicate;
        int success = pushcase (value, convert_and_check,
           label, &duplicate);
        if (success == 1)
   error ("case label not within a switch statement");
        else if (success == 2)
   {
     error ("duplicate case value");
     error_with_decl (duplicate, "this is the first entry for that value");
   }
        else if (success == 3)
   warning ("case value out of range");
        else if (success == 5)
   error ("case label within scope of cleanup or variable array");
      }
    position_after_white_space (); ;
    break;}
case 336:
{ register tree value1 = check_case_value (yyvsp[-3].ttype);
    register tree value2 = check_case_value (yyvsp[-1].ttype);
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );

    stmt_count++;

    if (value1 != error_mark_node && value2 != error_mark_node)
      {
        tree duplicate;
        int success = pushcase_range (value1, value2,
          convert_and_check, label,
          &duplicate);
        if (success == 1)
   error ("case label not within a switch statement");
        else if (success == 2)
   {
     error ("duplicate case value");
     error_with_decl (duplicate, "this is the first entry for that value");
   }
        else if (success == 3)
   warning ("case value out of range");
        else if (success == 4)
   warning ("empty case range");
        else if (success == 5)
   error ("case label within scope of cleanup or variable array");
      }
    position_after_white_space (); ;
    break;}
case 337:
{
    tree duplicate;
    register tree label
      = build_decl (LABEL_DECL, (tree) 
                               ((void *)0)
                                        , (tree) 
                                          ((void *)0)
                                                   );
    int success = pushcase ((tree) 
                           ((void *)0)
                                    , 0, label, &duplicate);
    stmt_count++;
    if (success == 1)
      error ("default label not within a switch statement");
    else if (success == 2)
      {
        error ("multiple default labels in one switch");
        error_with_decl (duplicate, "this is the first default label");
      }
    position_after_white_space (); ;
    break;}
case 338:
{ tree label = define_label (input_filename, lineno, yyvsp[-1].ttype);
    stmt_count++;
    emit_nop ();
    if (label)
      expand_label (label);
    position_after_white_space (); ;
    break;}
case 339:
{ emit_line_note (input_filename, lineno);
    yyval.ttype = (tree) 
                 ((void *)0)
                          ; ;
    break;}
case 340:
{ emit_line_note (input_filename, lineno); ;
    break;}
case 341:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 343:
{ yyval.ttype = (tree) 
               ((void *)0)
                        ; ;
    break;}
case 346:
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 347:
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 348:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , combine_strings (yyvsp[0].ttype), (tree) 
                                                                       ((void *)0)
                                                                                ); ;
    break;}
case 349:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , combine_strings (yyvsp[0].ttype), yyvsp[-2].ttype); ;
    break;}
case 350:
{ pushlevel (0);
    clear_parm_order ();
    declare_parm_level (0); ;
    break;}
case 351:
{ yyval.ttype = yyvsp[0].ttype;
    parmlist_tags_warning ();
    poplevel (0, 0, 0); ;
    break;}
case 353:
{ tree parm;
    if (pedantic)
      pedwarn ("ANSI C forbids forward parameter declarations");

    for (parm = getdecls (); parm; parm = ((parm)->common.chain))
      ((parm)->common.asm_written_flag) = 1;
    clear_parm_order (); ;
    break;}
case 354:
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 355:
{ yyval.ttype = tree_cons ((tree) 
                          ((void *)0)
                                   , (tree) 
                                     ((void *)0)
                                              , (tree) 
                                                ((void *)0)
                                                         ); ;
    break;}
case 356:
{ yyval.ttype = get_parm_info (0); ;
    break;}
case 357:
{ yyval.ttype = get_parm_info (0);






    error ("ANSI C requires a named argument before `...'");
  ;
    break;}
case 358:
{ yyval.ttype = get_parm_info (1); ;
    break;}
case 359:
{ yyval.ttype = get_parm_info (0); ;
    break;}
case 360:
{ push_parm_decl (yyvsp[0].ttype); ;
    break;}
case 361:
{ push_parm_decl (yyvsp[0].ttype); ;
    break;}
case 362:
{ yyval.ttype = build_tree_list (build_tree_list (current_declspecs,
        yyvsp[-1].ttype),
     build_tree_list (prefix_attributes,
        yyvsp[0].ttype));
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 363:
{ yyval.ttype = build_tree_list (build_tree_list (current_declspecs,
        yyvsp[-1].ttype),
     build_tree_list (prefix_attributes,
        yyvsp[0].ttype));
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 364:
{ yyval.ttype = build_tree_list (build_tree_list (current_declspecs,
        yyvsp[-1].ttype),
     build_tree_list (prefix_attributes,
        yyvsp[0].ttype));
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 365:
{ yyval.ttype = build_tree_list (build_tree_list (current_declspecs,
        yyvsp[-1].ttype),
     build_tree_list (prefix_attributes,
        yyvsp[0].ttype));
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 366:
{ yyval.ttype = build_tree_list (build_tree_list (current_declspecs,
        yyvsp[-1].ttype),
     build_tree_list (prefix_attributes,
        yyvsp[0].ttype));
    current_declspecs = ((declspec_stack)->list.value);
    prefix_attributes = ((declspec_stack)->list.purpose);
    declspec_stack = ((declspec_stack)->common.chain);
    resume_momentary (yyvsp[-2].itype); ;
    break;}
case 367:
{ pushlevel (0);
    clear_parm_order ();
    declare_parm_level (1); ;
    break;}
case 368:
{ yyval.ttype = yyvsp[0].ttype;
    parmlist_tags_warning ();
    poplevel (0, 0, 0); ;
    break;}
case 370:
{ tree t;
    for (t = yyvsp[-1].ttype; t; t = ((t)->common.chain))
      if (((t)->list.value) == (tree) 
                           ((void *)0)
                                    )
        error ("`...' in old-style identifier list");
    yyval.ttype = tree_cons ((tree) 
                            ((void *)0)
                                     , (tree) 
                                       ((void *)0)
                                                , yyvsp[-1].ttype); ;
    break;}
case 371:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyvsp[0].ttype); ;
    break;}
case 372:
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list ((tree) 
                                                          ((void *)0)
                                                                   , yyvsp[0].ttype)); ;
    break;}
case 373:
{ yyval.ttype = build_tree_list ((tree) 
                                ((void *)0)
                                         , yyvsp[0].ttype); ;
    break;}
case 374:
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list ((tree) 
                                                          ((void *)0)
                                                                   , yyvsp[0].ttype)); ;
    break;}
}

  yyvsp -= yylen;
  yyssp -= yylen;





  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (
              (__acrt_iob_func(2))
                    , "state stack now");
      while (ssp1 != yyssp)
 fprintf (
         (__acrt_iob_func(2))
               , " %d", *++ssp1);
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }


  *++yyvsp = yyval;
  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - 84] + *yyssp;
  if (yystate >= 0 && yystate <= 2115 && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - 84];

  goto yynewstate;

yyerrlab:

  if (! yyerrstatus)

    {
      ++yynerrs;
 yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:

  if (yyerrstatus == 3)
    {



      if (yychar == 0)
 return(1);


      if (yydebug)
 fprintf(
        (__acrt_iob_func(2))
              , "Discarding token %d (%s).\n", yychar, yytname[yychar1]);


      yychar = -2;
    }




  yyerrstatus = 3;

  goto yyerrhandle;

yyerrdefault:
yyerrpop:

  if (yyssp == yyss) return(1);
  yyvsp--;
  yystate = *--yyssp;





  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (
              (__acrt_iob_func(2))
                    , "Error: state stack now");
      while (ssp1 != yyssp)
 fprintf (
         (__acrt_iob_func(2))
               , " %d", *++ssp1);
      fprintf (
              (__acrt_iob_func(2))
                    , "\n");
    }


yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == -32768)
    goto yyerrdefault;

  yyn += 1;
  if (yyn < 0 || yyn > 2115 || yycheck[yyn] != 1)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == -32768)
 goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == 658)
    return(0);


  if (yydebug)
    fprintf(
           (__acrt_iob_func(2))
                 , "Shifting error token, ");


  *++yyvsp = yylval;




  yystate = yyn;
  goto yynewstate;
}

