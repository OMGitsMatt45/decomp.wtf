// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <windows.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);





FILE *windows_tmpfile(void) asm("_windows_tmpfile");
FILE *windows_tmpfile(void) {
    char directory[
                  260 
                           + 1], filename[
                                          260 
                                                   + 1];
    DWORD length = GetTempPathA(sizeof(directory), directory);
    FILE *stream;
    if (length == 0 || length >= sizeof(directory)) return 
                                                          ((void *)0)
                                                              ;
    if (GetTempFileNameA(directory, "kmc", 0, filename) == 0) return 
                                                                    ((void *)0)
                                                                        ;


    stream = fopen(filename, "w+bD");
    if (stream == 
                 ((void *)0)
                     ) DeleteFileA(filename);
    return stream;
}

