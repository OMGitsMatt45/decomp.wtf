// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/typeck.c
/* Build expressions with type checking for C++ compiler.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Hacked by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int simple_cst_equal(...) asm("_simple_cst_equal");
extern int obfree(...) asm("_obfree");
extern int compiler_error(...) asm("_compiler_error");
extern int comp_ptr_ttypes(...) asm("_comp_ptr_ttypes");
extern int comp_target_parms(...) asm("_comp_target_parms");
extern int pedwarn(...) asm("_pedwarn");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int synthesize_method(...) asm("_synthesize_method");
extern int error_with_decl(...) asm("_error_with_decl");
extern int sorry(...) asm("_sorry");
extern int put_var_into_stack(...) asm("_put_var_into_stack");
extern int rest_of_decl_compilation(...) asm("_rest_of_decl_compilation");
extern int real_lvalue_p(...) asm("_real_lvalue_p");
extern int do_pending_stack_adjust(...) asm("_do_pending_stack_adjust");
extern int start_sequence_for_rtl_expr(...) asm("_start_sequence_for_rtl_expr");
extern int expand_asm_operands(...) asm("_expand_asm_operands");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int any_pending_cleanups(...) asm("_any_pending_cleanups");
extern int expand_cleanups_to(...) asm("_expand_cleanups_to");
extern int store_expr(...) asm("_store_expr");
extern int use_variable(...) asm("_use_variable");
extern int expand_assignment(...) asm("_expand_assignment");
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
extern void error(...) asm("_error");
extern void warning(...) asm("_warning");


extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");

enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

int mark_addressable(...) asm("_mark_addressable");
static tree convert_for_assignment(...) asm("_convert_for_assignment");
             tree convert_for_initialization(...) asm("_convert_for_initialization");
extern tree shorten_compare(...) asm("_shorten_compare");
extern void binary_op_error(...) asm("_binary_op_error");
static tree pointer_int_sum(...) asm("_pointer_int_sum");
static tree pointer_diff(...) asm("_pointer_diff");
static tree convert_sequence(...) asm("_convert_sequence");
             tree unary_complex_lvalue(...) asm("_unary_complex_lvalue");
static tree get_delta_difference (tree, tree, int) asm("_get_delta_difference");

extern rtx original_result_rtx;
extern int warn_synth;




tree
target_type(tree type) asm("_target_type");
tree
target_type(tree type)
{
  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    type = ((type)->common.type);
  while (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE
  || ((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
    type = ((type)->common.type);
  return type;
}




tree
require_complete_type(tree value) asm("_require_complete_type");
tree
require_complete_type(tree value)
{
  tree type = ((value)->common.type);


  if (((type)->type.size) != 0
      && type != void_type_node
      && ! (((type)->type.lang_specific)
     && ((((type)->type.lang_specific)->type_flags.is_signature_pointer) || (((type)->type.lang_specific)->type_flags.is_signature_reference))
     && (((((type)->type.lang_specific)->signature))->type.size) == 0))
    return value;




  if (((n64_enum_tree_code) (value)->common.code) == CP_OFFSET_REF
      && C_C_D != 0
      && ((value)->exp.operands[0]) == C_C_D)
    {
      tree base, member = ((value)->exp.operands[1]);
      tree basetype = ((type)->type.maxval);
      my_friendly_assert (((n64_enum_tree_code) (member)->common.code) == FIELD_DECL, 305);
      base = convert_pointer_to (basetype, current_class_decl);
      value = build (COMPONENT_REF, ((member)->common.type),
       build_indirect_ref (base, ((void *)0)), member);
      return require_complete_type (value);
    }

  incomplete_type_error (value, type);
  return error_mark_node;
}


int
type_unknown_p(tree exp) asm("_type_unknown_p");
int
type_unknown_p(tree exp)
{
  return (((n64_enum_tree_code) (exp)->common.code) == TREE_LIST
   || ((exp)->common.type) == unknown_type_node
   || (((n64_enum_tree_code) (((exp)->common.type))->common.code) == OFFSET_TYPE
       && ((((exp)->common.type))->common.type) == unknown_type_node));
}


int
fntype_p(tree t) asm("_fntype_p");
int
fntype_p(tree t)
{
  return (((n64_enum_tree_code) (t)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (t)->common.code) == METHOD_TYPE
   || (((n64_enum_tree_code) (t)->common.code) == POINTER_TYPE
       && (((n64_enum_tree_code) (((t)->common.type))->common.code) == FUNCTION_TYPE
    || ((n64_enum_tree_code) (((t)->common.type))->common.code) == METHOD_TYPE)));
}




tree
require_instantiated_type(tree type, tree exp, tree errval) asm("_require_instantiated_type");
tree
require_instantiated_type(tree type, tree exp, tree errval)
{
  if (((exp)->common.type) == (tree) 
                        ((void *)0)
                                 )
    {
      error ("argument list may not have an initializer list");
      return errval;
    }

  if (((exp)->common.type) == unknown_type_node
      || (((n64_enum_tree_code) (((exp)->common.type))->common.code) == OFFSET_TYPE
   && ((((exp)->common.type))->common.type) == unknown_type_node))
    {
      exp = instantiate_type (type, exp, 1);
      if (((exp)->common.type) == error_mark_node)
 return errval;
    }
  return exp;
}




static tree
qualify_type(tree type, tree like) asm("_qualify_type");
static tree
qualify_type(tree type, tree like)
{
  int constflag = ((type)->common.readonly_flag) || ((like)->common.readonly_flag);
  int volflag = ((type)->common.volatile_flag) || ((like)->common.volatile_flag);

  return cp_build_type_variant (type, constflag, volflag);
}
tree
commonparms(tree p1, tree p2) asm("_commonparms");
tree
commonparms(tree p1, tree p2)
{
  tree oldargs = p1, newargs, n;
  int i, len;
  int any_change = 0;
  char *first_obj = (char *) oballoc (0);

  len = list_length (p1);
  newargs = tree_last (p1);

  if (newargs == void_list_node)
    i = 1;
  else
    {
      i = 0;
      newargs = 0;
    }

  for (; i < len; i++)
    newargs = tree_cons ((tree) 
                        ((void *)0)
                                 , (tree) 
                                   ((void *)0)
                                            , newargs);

  n = newargs;

  for (i = 0; p1;
       p1 = ((p1)->common.chain), p2 = ((p2)->common.chain), n = ((n)->common.chain), i++)
    {
      if (((p1)->list.purpose) && !((p2)->list.purpose))
 {
   ((n)->list.purpose) = ((p1)->list.purpose);
   any_change = 1;
 }
      else if (! ((p1)->list.purpose))
 {
   if (((p2)->list.purpose))
     {
       ((n)->list.purpose) = ((p2)->list.purpose);
       any_change = 1;
     }
 }
      else
 {
   if (1 != simple_cst_equal (((p1)->list.purpose), ((p2)->list.purpose)))
     any_change = 1;
   ((n)->list.purpose) = ((p2)->list.purpose);
 }
      if (((p1)->list.value) != ((p2)->list.value))
 {
   any_change = 1;
   ((n)->list.value) = common_type (((p1)->list.value), ((p2)->list.value));
 }
      else
 ((n)->list.value) = ((p1)->list.value);
    }
  if (! any_change)
    {
      obfree (first_obj);
      return oldargs;
    }

  return newargs;
}
tree
common_type(tree t1, tree t2) asm("_common_type");
tree
common_type(tree t1, tree t2)
{
  register n64_enum_tree_code code1;
  register n64_enum_tree_code code2;
  tree attributes;



  if (t1 == t2) return t1;


  if (t1 == error_mark_node)
    return t2;
  if (t2 == error_mark_node)
    return t1;



  { register tree a1, a2;
    a1 = ((t1)->type.attributes);
    a2 = ((t2)->type.attributes);



    if (!(attributes = a1))
       attributes = a2;



    else if (a2 && !attribute_list_contained (a1, a2))
       if (attribute_list_contained (a2, a1))
   attributes = a2;
       else
 {



   if (list_length (a1) < list_length (a2))
      attributes = a2, a2 = a1;

   for (; a2; a2 = ((a2)->common.chain))
     if (lookup_attribute (((((a2)->list.purpose))->identifier.pointer),
      attributes) == (tree) 
                    ((void *)0)
                             )
       {
  a1 = copy_node (a2);
  ((a1)->common.chain) = attributes;
  attributes = a1;
       }
 }
  }



  if (((n64_enum_tree_code) (t1)->common.code) == ENUMERAL_TYPE)
    t1 = type_for_size (((t1)->type.precision), 1);
  if (((n64_enum_tree_code) (t2)->common.code) == ENUMERAL_TYPE)
    t2 = type_for_size (((t2)->type.precision), 1);

  code1 = ((n64_enum_tree_code) (t1)->common.code);
  code2 = ((n64_enum_tree_code) (t2)->common.code);

  switch (code1)
    {
    case INTEGER_TYPE:
    case REAL_TYPE:


      if (code1 == REAL_TYPE && code2 != REAL_TYPE)
 return build_type_attribute_variant (t1, attributes);

      if (code2 == REAL_TYPE && code1 != REAL_TYPE)
        return build_type_attribute_variant (t2, attributes);



      if (((t1)->type.precision) > ((t2)->type.precision))
 return build_type_attribute_variant (t1, attributes);
      else if (((t2)->type.precision) > ((t1)->type.precision))
        return build_type_attribute_variant (t2, attributes);



      if (((t1)->type.main_variant) == long_unsigned_type_node
   || ((t2)->type.main_variant) == long_unsigned_type_node)
        return build_type_attribute_variant (long_unsigned_type_node,
          attributes);

      if (((t1)->type.main_variant) == long_integer_type_node
   || ((t2)->type.main_variant) == long_integer_type_node)
 {


   if (((t1)->common.unsigned_flag) || ((t2)->common.unsigned_flag))
      t1 = long_unsigned_type_node;
   else
      t1 = long_integer_type_node;
   return build_type_attribute_variant (t1, attributes);
 }

      if (((t1)->type.main_variant) == long_double_type_node
   || ((t2)->type.main_variant) == long_double_type_node)
 return build_type_attribute_variant (long_double_type_node,
          attributes);



      if (((t1)->common.unsigned_flag))
 return build_type_attribute_variant (t1, attributes);
      else
 return build_type_attribute_variant (t2, attributes);

    case POINTER_TYPE:
    case REFERENCE_TYPE:





      {
 tree tt1 = ((((t1)->common.type))->type.main_variant);
 tree tt2 = ((((t2)->common.type))->type.main_variant);
 int constp
   = ((((t1)->common.type))->common.readonly_flag) || ((((t2)->common.type))->common.readonly_flag);
 int volatilep
   = ((((t1)->common.type))->common.volatile_flag) || ((((t2)->common.type))->common.volatile_flag);
 tree target;

 if (tt1 == tt2)
   target = tt1;
 else if (tt1 == void_type_node || tt2 == void_type_node)
   target = void_type_node;
 else
   target = common_type (tt1, tt2);

 target = cp_build_type_variant (target, constp, volatilep);
 if (code1 == POINTER_TYPE)
   t1 = build_pointer_type (target);
 else
   t1 = build_reference_type (target);
 t1 = build_type_attribute_variant (t1, attributes);

 if (((n64_enum_tree_code) (target)->common.code) == METHOD_TYPE)
   t1 = build_ptrmemfunc_type (t1);

 return t1;
      }
    case ARRAY_TYPE:
      {
 tree elt = common_type (((t1)->common.type), ((t2)->common.type));

 if (elt == ((t1)->common.type) && ((t1)->type.values))
   return build_type_attribute_variant (t1, attributes);
 if (elt == ((t2)->common.type) && ((t2)->type.values))
   return build_type_attribute_variant (t2, attributes);

 t1 = build_cplus_array_type (elt, ((((t1)->type.values) ? t1 : t2)->type.values));
 return build_type_attribute_variant (t1, attributes);
      }

    case FUNCTION_TYPE:


      {
 tree valtype = common_type (((t1)->common.type), ((t2)->common.type));
 tree p1 = ((t1)->type.values);
 tree p2 = ((t2)->type.values);
 tree rval, raises;


 if (valtype == ((t1)->common.type) && ! p2)
   return build_type_attribute_variant (t1, attributes);
 if (valtype == ((t2)->common.type) && ! p1)
   return build_type_attribute_variant (t2, attributes);


 if (p1 == (tree) 
          ((void *)0) 
                    || ((p1)->list.value) == void_type_node)
   {
     rval = build_function_type (valtype, p2);
     if ((raises = ((t2)->type.noncopied_parts)))
       rval = build_exception_variant (rval, raises);
     return build_type_attribute_variant (rval, attributes);
   }
 raises = ((t1)->type.noncopied_parts);
 if (p2 == (tree) 
          ((void *)0) 
                    || ((p2)->list.value) == void_type_node)
   {
     rval = build_function_type (valtype, p1);
     if (raises)
       rval = build_exception_variant (rval, raises);
     return build_type_attribute_variant (rval, attributes);
   }

 rval = build_function_type (valtype, commonparms (p1, p2));
 rval = build_exception_variant (rval, raises);
 return build_type_attribute_variant (rval, attributes);
      }

    case RECORD_TYPE:
    case UNION_TYPE:
      my_friendly_assert (((t1)->type.main_variant) == t1
     && ((t2)->type.main_variant) == t2, 306);

      if ((get_base_distance (t1, t2, 0, (tree *)0) != -1) && binfo_or_else (t1, t2))
 return build_type_attribute_variant (t1, attributes);
      else if (binfo_or_else (t2, t1))
 return build_type_attribute_variant (t2, attributes);
      else
 compiler_error ("common_type called with uncommon aggregate types");

    case METHOD_TYPE:
      if (((n64_enum_tree_code) (((t1)->common.type))->common.code) == ((n64_enum_tree_code) (((t2)->common.type))->common.code))
 {


   tree basetype;
   tree raises, t3;

   tree b1 = ((t1)->type.maxval);
   tree b2 = ((t2)->type.maxval);

   if ((get_base_distance (b1, b2, 0, (tree *)0) != -1) && binfo_or_else (b1, b2))
     basetype = ((((((t2)->type.values))->list.value))->common.type);
   else
     {
       if (binfo_or_else (b2, b1) == (tree) 
                                    ((void *)0)
                                             )
  compiler_error ("common_type called with uncommon method types");
       basetype = ((((((t1)->type.values))->list.value))->common.type);
     }

   raises = ((t1)->type.noncopied_parts);




   t1 = build_function_type (((t1)->common.type), ((((t1)->type.values))->common.chain));
   t2 = build_function_type (((t2)->common.type), ((((t2)->type.values))->common.chain));
   t3 = common_type (t1, t2);
   t3 = build_cplus_method_type (basetype, ((t3)->common.type), ((t3)->type.values));
   t1 = build_exception_variant (t3, raises);
 }
      else
        compiler_error ("common_type called with uncommon method types");

      return build_type_attribute_variant (t1, attributes);

    case OFFSET_TYPE:
      if (((t1)->common.type) == ((t2)->common.type))
 {
   tree b1 = ((t1)->type.maxval);
   tree b2 = ((t2)->type.maxval);

   if ((get_base_distance (b1, b2, 0, (tree *)0) != -1) && binfo_or_else (b1, b2))
     return build_type_attribute_variant (t2, attributes);
   else if (binfo_or_else (b2, b1))
     return build_type_attribute_variant (t1, attributes);
 }
      compiler_error ("common_type called with uncommon member types");

    default:
      return build_type_attribute_variant (t1, attributes);
    }
}


int
compexcepttypes(tree t1, tree t2, int strict) asm("_compexcepttypes");
int
compexcepttypes(tree t1, tree t2, int strict)
{
  return ((t1)->type.noncopied_parts) == ((t2)->type.noncopied_parts);
}

static int
comp_array_types(register int (*cmp) (...), tree t1, tree t2, int strict) asm("_comp_array_types");
static int
comp_array_types(register int (*cmp) (...), tree t1, tree t2, int strict)
{
  tree d1 = ((t1)->type.values);
  tree d2 = ((t2)->type.values);


  if (!(((t1)->common.type) == ((t2)->common.type)
 || (*cmp) (((t1)->common.type), ((t2)->common.type), strict)))
    return 0;


  if (d1 == 0 || d2 == 0 || d1 == d2
      || ((n64_enum_tree_code) (((d1)->type.minval))->common.code) != INTEGER_CST
      || ((n64_enum_tree_code) (((d2)->type.minval))->common.code) != INTEGER_CST
      || ((n64_enum_tree_code) (((d1)->type.maxval))->common.code) != INTEGER_CST
      || ((n64_enum_tree_code) (((d2)->type.maxval))->common.code) != INTEGER_CST)
    return 1;

  return ((((((d1)->type.minval))->int_cst.int_cst_low)
    == ((((d2)->type.minval))->int_cst.int_cst_low))
   && (((((d1)->type.minval))->int_cst.int_cst_high)
       == ((((d2)->type.minval))->int_cst.int_cst_high))
   && (((((d1)->type.maxval))->int_cst.int_cst_low)
       == ((((d2)->type.maxval))->int_cst.int_cst_low))
   && (((((d1)->type.maxval))->int_cst.int_cst_high)
       == ((((d2)->type.maxval))->int_cst.int_cst_high)));
}
int
comptypes(tree type1, tree type2, int strict) asm("_comptypes");
int
comptypes(tree type1, tree type2, int strict)
{
  register tree t1 = type1;
  register tree t2 = type2;
  int attrval, val;



  if (t1 == t2)
    return 1;


  my_friendly_assert (t1 != error_mark_node, 307);

  if (t2 == error_mark_node)
    return 0;

  if (strict < 0)
    {


      if (((n64_enum_tree_code) (t1)->common.code) == ENUMERAL_TYPE)
 t1 = type_for_size (((t1)->type.precision), 1);
      if (((n64_enum_tree_code) (t2)->common.code) == ENUMERAL_TYPE)
 t2 = type_for_size (((t2)->type.precision), 1);

      if (t1 == t2)
 return 1;
    }



  if (((n64_enum_tree_code) (t1)->common.code) != ((n64_enum_tree_code) (t2)->common.code))
    {
      if (strict == 2
   && ((((n64_enum_tree_code) (t1)->common.code) == REFERENCE_TYPE)
       ^ (((n64_enum_tree_code) (t2)->common.code) == REFERENCE_TYPE)))
 {
   if (((n64_enum_tree_code) (t1)->common.code) == REFERENCE_TYPE)
     return comptypes (((t1)->common.type), t2, 1);
   return comptypes (t1, ((t2)->common.type), 1);
 }

      return 0;
    }
  if (strict > 1)
    strict = 1;



  if (((t1)->common.readonly_flag) != ((t2)->common.readonly_flag))
    return 0;
  if (((t1)->common.volatile_flag) != ((t2)->common.volatile_flag))
    return 0;





  if (((t1)->type.main_variant) == ((t2)->type.main_variant))
    return 1;






  attrval = 1;



  val = 0;

  switch (((n64_enum_tree_code) (t1)->common.code))
    {
    case RECORD_TYPE:
    case UNION_TYPE:
      if (strict <= 0)
 goto look_hard;
      return 0;

    case OFFSET_TYPE:
      val = (comptypes (build_pointer_type (((t1)->type.maxval)),
   build_pointer_type (((t2)->type.maxval)), strict)
      && comptypes (((t1)->common.type), ((t2)->common.type), strict));
      break;

    case METHOD_TYPE:
      if (! compexcepttypes (t1, t2, strict))
 return 0;






      val = (comptypes (((t1)->common.type), ((t2)->common.type), strict)
      && compparms (((t1)->type.values),
      ((t2)->type.values), strict));
      break;

    case POINTER_TYPE:
    case REFERENCE_TYPE:
      t1 = ((t1)->common.type);
      t2 = ((t2)->common.type);
      if (t1 == t2)
 {
   val = 1;
   break;
 }
      if (strict <= 0)
 {
   if (((n64_enum_tree_code) (t1)->common.code) == RECORD_TYPE && ((n64_enum_tree_code) (t2)->common.code) == RECORD_TYPE)
     {
       int rval;
     look_hard:
       rval = t1 == t2 || (get_base_distance (t1, t2, 0, (tree *)0) >= 0);

       if (rval)
  {
    val = 1;
    break;
  }
       if (strict < 0)
  {
    val = (get_base_distance (t2, t1, 0, (tree *)0) >= 0);
    break;
  }
     }
   return 0;
 }
      else
 val = comptypes (t1, t2, strict);
      break;

    case FUNCTION_TYPE:
      if (! compexcepttypes (t1, t2, strict))
 return 0;

      val = ((((t1)->common.type) == ((t2)->common.type)
       || comptypes (((t1)->common.type), ((t2)->common.type), strict))
      && compparms (((t1)->type.values), ((t2)->type.values), strict));
      break;

    case ARRAY_TYPE:

      val = comp_array_types (comptypes, t1, t2, strict);
      break;

    case TEMPLATE_TYPE_PARM:
      return ((((((t1)->type.values))->list.value))->int_cst.int_cst_low) == ((((((t2)->type.values))->list.value))->int_cst.int_cst_low);

    case UNINSTANTIATED_P_TYPE:
      if (((((t1)->type.values))->list.purpose) != ((((t2)->type.values))->list.purpose))
 return 0;
      {
 int i = ((((((t1)->type.values))->list.value))->vec.length);
 tree *p1 = &((((((t1)->type.values))->list.value))->vec.a[0]);
 tree *p2 = &((((((t2)->type.values))->list.value))->vec.a[0]);

 while (i--)
   {
     if ((*tree_code_type[(int) (((n64_enum_tree_code) (p1[i])->common.code))]) == 't')
       {
  if (! comptypes (p1[i], p2[i], 1))
    return 0;
       }
     else
       {
  if (simple_cst_equal (p1[i], p2[i]) <= 0)
    return 0;
       }
   }
      }
      return 1;
    }
  return attrval == 2 && val == 1 ? 2 : val;
}
int
comp_target_types(tree ttl, tree ttr, int nptrs) asm("_comp_target_types");
int
comp_target_types(tree ttl, tree ttr, int nptrs)
{
  ttl = ((ttl)->type.main_variant);
  ttr = ((ttr)->type.main_variant);
  if (ttl == ttr)
    return 1;

  if (((n64_enum_tree_code) (ttr)->common.code) != ((n64_enum_tree_code) (ttl)->common.code))
    return 0;

  if (((n64_enum_tree_code) (ttr)->common.code) == POINTER_TYPE)
    {
      ttl = ((ttl)->common.type);
      ttr = ((ttr)->common.type);

      if (nptrs > 0)
 {
   if (((n64_enum_tree_code) (ttl)->common.code) == VOID_TYPE
     && ((n64_enum_tree_code) (ttr)->common.code) != FUNCTION_TYPE
     && ((n64_enum_tree_code) (ttr)->common.code) != METHOD_TYPE
     && ((n64_enum_tree_code) (ttr)->common.code) != OFFSET_TYPE)
     return 1;
   else if (((n64_enum_tree_code) (ttr)->common.code) == VOID_TYPE
     && ((n64_enum_tree_code) (ttl)->common.code) != FUNCTION_TYPE
     && ((n64_enum_tree_code) (ttl)->common.code) != METHOD_TYPE
     && ((n64_enum_tree_code) (ttl)->common.code) != OFFSET_TYPE)
     return -1;
   else if (((n64_enum_tree_code) (ttl)->common.code) == POINTER_TYPE
     || ((n64_enum_tree_code) (ttl)->common.code) == ARRAY_TYPE)
     {
       if (comp_ptr_ttypes (ttl, ttr))
  return 1;
       else if (comp_ptr_ttypes (ttr, ttl))
  return -1;
       return 0;
     }
 }



      if (((n64_enum_tree_code) (ttl)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (ttl)->common.code) == METHOD_TYPE)
 return comp_target_types (ttl, ttr, nptrs - 1);



      {
 int t;
 int c = ((ttl)->common.readonly_flag) - ((ttr)->common.readonly_flag);
 int v = ((ttl)->common.volatile_flag) - ((ttr)->common.volatile_flag);

 if ((c > 0 && v < 0) || (c < 0 && v > 0))
   return 0;

 if (((ttl)->type.main_variant) == ((ttr)->type.main_variant))
   return (c + v < 0) ? -1 : 1;

 t = comp_target_types (ttl, ttr, nptrs - 1);
 if ((t == 1 && c + v >= 0) || (t == -1 && c + v <= 0))
   return t;

 return 0;
      }
    }

  if (((n64_enum_tree_code) (ttr)->common.code) == REFERENCE_TYPE)
    return comp_target_types (((ttl)->common.type), ((ttr)->common.type), nptrs);
  if (((n64_enum_tree_code) (ttr)->common.code) == ARRAY_TYPE)
    return comp_array_types (comp_target_types, ttl, ttr, 0);
  else if (((n64_enum_tree_code) (ttr)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (ttr)->common.code) == METHOD_TYPE)
    if (comp_target_types (((ttl)->common.type), ((ttr)->common.type), nptrs))
      switch (comp_target_parms (((ttl)->type.values), ((ttr)->type.values), 1))
 {
 case 0:
   return 0;
 case 1:
   return 1;
 case 2:
   return -1;
 default:
   my_friendly_abort (112);
 }
    else
      return 0;


  else if (((n64_enum_tree_code) (ttr)->common.code) == OFFSET_TYPE)
    {



      if (comptypes (((ttr)->type.maxval), ((ttl)->type.maxval), 0))
 return comp_target_types (((ttl)->common.type), ((ttr)->common.type), nptrs);
      else if (comptypes (((ttl)->type.maxval), ((ttr)->type.maxval), 0)
        && comp_target_types (((ttl)->common.type), ((ttr)->common.type), nptrs))
 return -1;
    }
  else if ((((ttl)->type.lang_flag_5)))
    {
      if (nptrs < 0)
 return 0;
      if (comptypes (build_pointer_type (ttl), build_pointer_type (ttr), 0))
 return 1;
      if (comptypes (build_pointer_type (ttr), build_pointer_type (ttl), 0))
 return -1;
      return 0;
    }

  return 0;
}




tree
common_base_type(tree tt1, tree tt2) asm("_common_base_type");
tree
common_base_type(tree tt1, tree tt2)
{
  tree best = (tree) 
             ((void *)0)
                      , tmp;
  int i;


  if ((get_base_distance (tt1, tt2, 0, (tree *)0) >= 0))
    return tt1;
  if ((get_base_distance (tt2, tt1, 0, (tree *)0) >= 0))
    return tt2;
  for (i = (((((tt1)->type.binfo))->vec.a[4]) ? ((((((tt1)->type.binfo))->vec.a[4]))->vec.length) : 0)-1; i >= 0; i--)
    {
      tree basetype = (((((((((tt1)->type.binfo)))->vec.a[4]))->vec.a[(i)]))->common.type);
      tree trial = common_base_type (basetype, tt2);
      if (trial)
 {
   if (trial == error_mark_node)
     return trial;
   if (best == (tree) 
              ((void *)0)
                       )
     best = trial;
   else if (best != trial)
     return error_mark_node;
 }
    }


  for (i = (((((tt2)->type.binfo))->vec.a[4]) ? ((((((tt2)->type.binfo))->vec.a[4]))->vec.length) : 0)-1; i >= 0; i--)
    {
      tree basetype = (((((((((tt2)->type.binfo)))->vec.a[4]))->vec.a[(i)]))->common.type);
      tree trial = common_base_type (tt1, basetype);
      if (trial)
 {
   if (trial == error_mark_node)
     return trial;
   if (best == (tree) 
              ((void *)0)
                       )
     best = trial;
   else if (best != trial)
     return error_mark_node;
 }
    }
  return best;
}
int
compparms(tree parms1, tree parms2, int strict) asm("_compparms");
int
compparms(tree parms1, tree parms2, int strict)
{
  register tree t1 = parms1, t2 = parms2;




  if (strict <= 0 && t1 == 0)
 return self_promoting_args_p (t2);
  if (strict < 0 && t2 == 0)
 return self_promoting_args_p (t1);

  while (1)
    {
      if (t1 == 0 && t2 == 0)
 return 1;


      if (t1 == 0 || t2 == 0)
 {
   if (strict > 0)
     return 0;
   if (strict < 0)
     return 1;
   if (strict == 0)
     return t1 && ((t1)->list.purpose);
 }
      if (! comptypes (((t2)->list.value), ((t1)->list.value), strict))
 {
   if (strict > 0)
     return 0;
   if (strict == 0)
     return t2 == void_list_node && ((t1)->list.purpose);
   return ((t1)->list.purpose) || ((t2)->list.purpose);
 }
      t1 = ((t1)->common.chain);
      t2 = ((t2)->common.chain);
    }
}



int
comp_target_parms(tree parms1, tree parms2, int strict) asm("_comp_target_parms");
int
comp_target_parms(tree parms1, tree parms2, int strict)
{
  register tree t1 = parms1, t2 = parms2;
  int warn_contravariance = 0;





  if (t1 == 0 && t2 != 0)
    {
      cp_pedwarn ("ANSI C++ prohibits conversion from `(%#T)' to `(...)'",
    parms2);
      return self_promoting_args_p (t2);
    }
  if (t2 == 0)
    return self_promoting_args_p (t1);

  for (; t1 || t2; t1 = ((t1)->common.chain), t2 = ((t2)->common.chain))
    {
      tree p1, p2;



      if (t1 == 0 || t2 == 0)
 {
   if (strict > 0)
     return 0;
   if (strict < 0)
     return 1 + warn_contravariance;
   return ((t1 && ((t1)->list.purpose)) + warn_contravariance);
 }
      p1 = ((t1)->list.value);
      p2 = ((t2)->list.value);
      if (p1 == p2)
 continue;

      if ((((n64_enum_tree_code) (p1)->common.code) == POINTER_TYPE && ((n64_enum_tree_code) (p2)->common.code) == POINTER_TYPE)
   || (((n64_enum_tree_code) (p1)->common.code) == REFERENCE_TYPE && ((n64_enum_tree_code) (p2)->common.code) == REFERENCE_TYPE))
 {
   if (strict <= 0
       && (((((p1)->common.type))->type.main_variant)
    == ((((p2)->common.type))->type.main_variant)))
     continue;



   if (((p1)->common.type) == void_type_node)
     continue;
   if (((p2)->common.type) == void_type_node)
     {
       warn_contravariance = 1;
       continue;
     }
   if ((((((p1)->common.type))->type.lang_flag_5)))
     {
       if (comptypes (p2, p1, 0) == 0)
  {
    if (comptypes (p1, p2, 0) != 0)
      warn_contravariance = 1;
    else
      return 0;
  }
       continue;
     }
 }

      if (comp_target_types (p2, p1, 1) == 0)
 {
   if (comp_target_types (p1, p2, 1))
     {
       warn_contravariance = 1;
       continue;
     }
   if (strict != 0)
     return 0;






 }


      if (((n64_enum_tree_code) (p1)->common.code) == FUNCTION_TYPE || ((n64_enum_tree_code) (p1)->common.code) == METHOD_TYPE)
 switch (comp_target_parms (((p1)->type.values),
       ((p2)->type.values),
       strict))
   {
   case 0:
     return 0;
   case 1:
     break;
   case 2:
     warn_contravariance = 1;
   }

      if (((t1)->list.purpose) && ((t2)->list.purpose))
 {
   int cmp = simple_cst_equal (((t1)->list.purpose), ((t2)->list.purpose));
   if (cmp < 0)
     my_friendly_abort (114);
   if (cmp == 0)
     return 0;
 }
    }
  return 1 + warn_contravariance;
}




int
self_promoting_args_p(tree parms) asm("_self_promoting_args_p");
int
self_promoting_args_p(tree parms)
{
  register tree t;
  for (t = parms; t; t = ((t)->common.chain))
    {
      register tree type = ((t)->list.value);

      if (((t)->common.chain) == 0 && type != void_type_node)
 return 0;

      if (((type)->type.main_variant) == float_type_node)
 return 0;

      if (type == 0)
 return 0;

      if ((((n64_enum_tree_code) ((type))->common.code) == INTEGER_TYPE && (((type)->type.main_variant) == char_type_node || ((type)->type.main_variant) == signed_char_type_node || ((type)->type.main_variant) == unsigned_char_type_node || ((type)->type.main_variant) == short_integer_type_node || ((type)->type.main_variant) == short_unsigned_type_node)))
 return 0;
    }
  return 1;
}





tree
unsigned_type(tree type) asm("_unsigned_type");
tree
unsigned_type(tree type)
{
  tree type1 = ((type)->type.main_variant);
  if (type1 == signed_char_type_node || type1 == char_type_node)
    return unsigned_char_type_node;
  if (type1 == integer_type_node)
    return unsigned_type_node;
  if (type1 == short_integer_type_node)
    return short_unsigned_type_node;
  if (type1 == long_integer_type_node)
    return long_unsigned_type_node;
  if (type1 == long_long_integer_type_node)
    return long_long_unsigned_type_node;
  return type;
}



tree
signed_type(tree type) asm("_signed_type");
tree
signed_type(tree type)
{
  tree type1 = ((type)->type.main_variant);
  if (type1 == unsigned_char_type_node || type1 == char_type_node)
    return signed_char_type_node;
  if (type1 == unsigned_type_node)
    return integer_type_node;
  if (type1 == short_unsigned_type_node)
    return short_integer_type_node;
  if (type1 == long_unsigned_type_node)
    return long_integer_type_node;
  if (type1 == long_long_unsigned_type_node)
    return long_long_integer_type_node;
  return type;
}




tree
signed_or_unsigned_type(int unsignedp, tree type) asm("_signed_or_unsigned_type");
tree
signed_or_unsigned_type(int unsignedp, tree type)
{
  if (! (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE || ((n64_enum_tree_code) (type)->common.code) == BOOLEAN_TYPE || ((n64_enum_tree_code) (type)->common.code) == CHAR_TYPE))
    return type;
  if (((type)->type.precision) == ((signed_char_type_node)->type.precision))
    return unsignedp ? unsigned_char_type_node : signed_char_type_node;
  if (((type)->type.precision) == ((integer_type_node)->type.precision))
    return unsignedp ? unsigned_type_node : integer_type_node;
  if (((type)->type.precision) == ((short_integer_type_node)->type.precision))
    return unsignedp ? short_unsigned_type_node : short_integer_type_node;
  if (((type)->type.precision) == ((long_integer_type_node)->type.precision))
    return unsignedp ? long_unsigned_type_node : long_integer_type_node;
  if (((type)->type.precision) == ((long_long_integer_type_node)->type.precision))
    return (unsignedp ? long_long_unsigned_type_node
     : long_long_integer_type_node);
  return type;
}

tree
c_sizeof(tree type) asm("_c_sizeof");
tree
c_sizeof(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids taking the sizeof a function type");
      return size_int (1);
    }
  if (code == METHOD_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids taking the sizeof a method type");
      return size_int (1);
    }
  if (code == VOID_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids taking the sizeof a void type");
      return size_int (1);
    }
  if (code == ERROR_MARK)
    return size_int (1);



  if (code == REFERENCE_TYPE)
    type = ((type)->common.type);
  if (code == OFFSET_TYPE)
    type = ((type)->common.type);



  if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("`sizeof' applied to a signature type");
      return size_int (0);
    }

  if (((type)->type.size) == 0)
    {
      error ("`sizeof' applied to an incomplete type");
      return size_int (0);
    }


  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
    size_int (((char_type_node)->type.precision)));

  if (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST && force_fit_type (t, 0))
    ((t)->common.static_flag) = ((t)->common.public_flag) = 1;
  return t;
}

tree
c_sizeof_nowarn(tree type) asm("_c_sizeof_nowarn");
tree
c_sizeof_nowarn(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE
      || code == METHOD_TYPE
      || code == VOID_TYPE
      || code == ERROR_MARK)
    return size_int (1);
  if (code == REFERENCE_TYPE)
    type = ((type)->common.type);

  if (((type)->type.size) == 0)
    {





      return size_int (0);
    }


  t = size_binop (CEIL_DIV_EXPR, ((type)->type.size),
    size_int (((char_type_node)->type.precision)));
  force_fit_type (t, 0);
  return t;
}




tree
c_alignof(tree type) asm("_c_alignof");
tree
c_alignof(tree type)
{
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);
  tree t;

  if (code == FUNCTION_TYPE || code == METHOD_TYPE)
    return size_int (32 / 8);

  if (code == VOID_TYPE || code == ERROR_MARK)
    return size_int (1);


  if (code == REFERENCE_TYPE)
    type = ((type)->common.type);



  if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("`__alignof' applied to a signature type");
      return size_int (1);
    }

  t = size_int (((type)->type.align) / 8);
  force_fit_type (t, 0);
  return t;
}
tree
decay_conversion(tree exp) asm("_decay_conversion");
tree
decay_conversion(tree exp)
{
  register tree type = ((exp)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);

  if (code == OFFSET_TYPE )
    {
      if (((n64_enum_tree_code) (exp)->common.code) == CP_OFFSET_REF)
 return decay_conversion (resolve_offset_ref (exp));

      type = ((type)->common.type);
      code = ((n64_enum_tree_code) (type)->common.code);
    }

  if (code == REFERENCE_TYPE)
    {
      exp = convert_from_reference (exp);
      type = ((exp)->common.type);
      code = ((n64_enum_tree_code) (type)->common.code);
    }


  if (((n64_enum_tree_code) (exp)->common.code) == CONST_DECL)
    exp = ((exp)->decl.initial);

  else if ((((exp)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd'))
    {
      exp = decl_constant_value (exp);
      type = ((exp)->common.type);
    }




  if (code == VOID_TYPE)
    {
      error ("void value not ignored as it ought to be");
      return error_mark_node;
    }
  if (code == FUNCTION_TYPE)
    {
      return build_unary_op (ADDR_EXPR, exp, 0);
    }
  if (code == METHOD_TYPE)
    {
      if (((n64_enum_tree_code) (exp)->common.code) == CP_OFFSET_REF)
 {
   my_friendly_assert (((n64_enum_tree_code) (((exp)->exp.operands[1]))->common.code) == FUNCTION_DECL,
         308);
   return build_unary_op (ADDR_EXPR, ((exp)->exp.operands[1]), 0);
 }
      return build_unary_op (ADDR_EXPR, exp, 0);
    }
  if (code == ARRAY_TYPE)
    {
      register tree adr;
      tree restype;
      tree ptrtype;
      int constp, volatilep;

      if (((n64_enum_tree_code) (exp)->common.code) == INDIRECT_REF)
 {


   tree inner = ((exp)->exp.operands[0]);
   if (((n64_enum_tree_code) (((inner)->common.type))->common.code) == REFERENCE_TYPE)
     {
       inner = build1 (CONVERT_EXPR,
         build_pointer_type (((((inner)->common.type))->common.type)),
         inner);
       (((inner)->common.lang_flag_3)) = 1;
     }
   return convert (build_pointer_type (((type)->common.type)), inner);
 }

      if (((n64_enum_tree_code) (exp)->common.code) == COMPOUND_EXPR)
 {
   tree op1 = decay_conversion (((exp)->exp.operands[1]));
   return build (COMPOUND_EXPR, ((op1)->common.type),
   ((exp)->exp.operands[0]), op1);
 }

      if (!lvalue_p (exp)
   && ! (((n64_enum_tree_code) (exp)->common.code) == CONSTRUCTOR && ((exp)->common.static_flag)))
 {
   error ("invalid use of non-lvalue array");
   return error_mark_node;
 }

      constp = volatilep = 0;
      if ((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'r'
   || (*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd')
 {
   constp = ((exp)->common.readonly_flag);
   volatilep = ((exp)->common.volatile_flag);
 }

      restype = ((type)->common.type);
      if (((type)->common.readonly_flag) || ((type)->common.volatile_flag)
   || constp || volatilep)
 restype = cp_build_type_variant (restype,
     ((type)->common.readonly_flag) || constp,
     ((type)->common.volatile_flag) || volatilep);
      ptrtype = build_pointer_type (restype);

      if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL)
 {




   adr = build1 (ADDR_EXPR, ptrtype, exp);
   if (mark_addressable (exp) == 0)
     return error_mark_node;
   ((adr)->common.constant_flag) = staticp (exp);
   ((adr)->common.side_effects_flag) = 0;
   return adr;
 }


      adr = build_unary_op (ADDR_EXPR, exp, 1);
      return convert (ptrtype, adr);
    }

  return exp;
}

tree
default_conversion(tree exp) asm("_default_conversion");
tree
default_conversion(tree exp)
{
  tree type;
  n64_enum_tree_code code;

  exp = decay_conversion (exp);

  type = ((exp)->common.type);
  code = ((n64_enum_tree_code) (type)->common.code);

  if ((code == INTEGER_TYPE || code == ENUMERAL_TYPE || code == BOOLEAN_TYPE))
    {
      tree t = type_promotes_to (type);
      if (t != type)
 return convert (t, exp);
    }
  if (flag_traditional
      && ((type)->type.main_variant) == float_type_node)
    return convert (double_type_node, exp);

  return exp;
}

tree
build_object_ref(tree datum, tree basetype, tree field) asm("_build_object_ref");
tree
build_object_ref(tree datum, tree basetype, tree field)
{
  tree dtype;
  if (datum == error_mark_node)
    return error_mark_node;

  dtype = ((datum)->common.type);
  if (((n64_enum_tree_code) (dtype)->common.code) == REFERENCE_TYPE)
    dtype = ((dtype)->common.type);
  if (! (((n64_enum_tree_code) (dtype)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (dtype)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (dtype)->common.code) == UNINSTANTIATED_P_TYPE))
    {
      cp_error ("request for member `%T::%D' in expression of non-aggregate type `%T'",
  basetype, field, dtype);
      return error_mark_node;
    }
  else if (((((((basetype)->common.type)))->type.lang_specific)?(((((basetype)->common.type)))->type.lang_specific)->type_flags.is_signature:0))
    {
      warning ("signature name in scope resolution ignored");
      return build_component_ref (datum, field, (tree) 
                                               ((void *)0)
                                                        , 1);
    }
  else if (is_aggr_typedef (basetype, 1))
    {
      tree real_basetype = (((basetype)->common.type));
      tree binfo = binfo_or_else (real_basetype, ((datum)->common.type));
      if (binfo)
 return build_component_ref (build_scoped_ref (datum, basetype),
        field, binfo, 1);
    }
  return error_mark_node;
}



tree
build_component_ref_1(tree datum, tree field, int protect) asm("_build_component_ref_1");
tree
build_component_ref_1(tree datum, tree field, int protect)
{
  register tree basetype = ((datum)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (basetype)->common.code);
  register tree ref;

  if (code == REFERENCE_TYPE)
    {
      datum = convert_from_reference (datum);
      basetype = ((datum)->common.type);
      code = ((n64_enum_tree_code) (basetype)->common.code);
    }

  if (! (code == RECORD_TYPE || code == UNION_TYPE || code == UNINSTANTIATED_P_TYPE))
    {
      if (code != ERROR_MARK)
 cp_error ("request for member `%D' in `%E', which is of non-aggregate type `%T'",
    field, datum, basetype);
      return error_mark_node;
    }

  if (((basetype)->type.size) == 0)
    {
      incomplete_type_error (0, basetype);
      return error_mark_node;
    }



  if (field == error_mark_node)
    my_friendly_abort (115);

  if (((field)->common.static_flag))
    return field;

  if (datum == C_C_D)
    {
      n64_enum_access_type access
 = compute_access (((current_class_type)->type.binfo), field);

      if (access == access_private)
 {
   cp_error ("field `%D' is private", field);
   return error_mark_node;
 }
      else if (access == access_protected)
 {
   cp_error ("field `%D' is protected", field);
   return error_mark_node;
 }
    }

  ref = build (COMPONENT_REF, ((field)->common.type), datum, field);

  if (((datum)->common.readonly_flag) || ((field)->common.readonly_flag))
    ((ref)->common.readonly_flag) = 1;
  if (((datum)->common.volatile_flag) || ((field)->common.volatile_flag))
    ((ref)->common.volatile_flag) = 1;
  if ((((field)->decl.lang_specific)->decl_flags.mutable_flag))
    ((ref)->common.readonly_flag) = 0;

  return ref;
}







static tree
rationalize_conditional_expr(n64_enum_tree_code code, tree t) asm("_rationalize_conditional_expr");
static tree
rationalize_conditional_expr(n64_enum_tree_code code, tree t)
{
  return
    build_conditional_expr (((t)->exp.operands[0]),
       build_unary_op (code, ((t)->exp.operands[1]), 0),
       build_unary_op (code, ((t)->exp.operands[2]), 0));
}

tree
build_component_ref(tree datum, tree component, tree basetype_path, int protect) asm("_build_component_ref");
tree
build_component_ref(tree datum, tree component, tree basetype_path, int protect)
{
  register tree basetype = ((datum)->common.type);
  register n64_enum_tree_code code = ((n64_enum_tree_code) (basetype)->common.code);
  register tree field = 
                       ((void *)0)
                           ;
  register tree ref;


  switch (((n64_enum_tree_code) (datum)->common.code))
    {
    case COMPOUND_EXPR:
      {
 tree value = build_component_ref (((datum)->exp.operands[1]), component,
       basetype_path, protect);
 return build (COMPOUND_EXPR, ((value)->common.type),
        ((datum)->exp.operands[0]), value);
      }
    case COND_EXPR:
      return build_conditional_expr
 (((datum)->exp.operands[0]),
  build_component_ref (((datum)->exp.operands[1]), component,
         basetype_path, protect),
  build_component_ref (((datum)->exp.operands[2]), component,
         basetype_path, protect));
    }

  if (code == REFERENCE_TYPE)
    {







 datum = convert_from_reference (datum);
      basetype = ((datum)->common.type);
      code = ((n64_enum_tree_code) (basetype)->common.code);
    }


  if (((n64_enum_tree_code) (component)->common.code) == TREE_LIST)
    {
      my_friendly_assert (!(((component)->common.chain) == (tree) 
                                                     ((void *)0)
  
 && (((((component)->list.value))->decl.lang_specific)->chain) == (tree) 
                                           ((void *)0)
                                                    ), 309);
      return build (COMPONENT_REF, ((component)->common.type), datum, component);
    }





  if (! (code == RECORD_TYPE || code == UNION_TYPE || code == UNINSTANTIATED_P_TYPE))
    {
      if (code != ERROR_MARK)
 cp_error ("request for member `%D' in `%E', which is of non-aggregate type `%T'",
    component, datum, basetype);
      return error_mark_node;
    }

  if (((basetype)->type.size) == 0)
    {
      incomplete_type_error (0, basetype);
      return error_mark_node;
    }

  if (((n64_enum_tree_code) (component)->common.code) == BIT_NOT_EXPR)
    {
      if ((((((basetype)->type.name))->decl.name)) != ((component)->exp.operands[0]))
 {
   cp_error ("destructor specifier `%T::~%T' must have matching names",
      basetype, ((component)->exp.operands[0]));
   return error_mark_node;
 }
      if (! (((basetype)->type.lang_flag_2)))
 {
   cp_error ("type `%T' has no destructor", basetype);
   return error_mark_node;
 }
      return ((((basetype)->type.maxval))->vec.a[0]);
    }


  if (((basetype)->type.minval)
      && ((((basetype)->type.minval))->decl.name) == component)



    field = ((basetype)->type.minval);
  else
    {
      if (basetype_path == (tree) 
                          ((void *)0)
                                   )
 basetype_path = ((basetype)->type.binfo);
      field = lookup_field (basetype_path, component,
       protect && ! (!strncmp (((component)->identifier.pointer), "_vptr.", sizeof("_vptr.")-1)), 0);
      if (field == error_mark_node)
 return error_mark_node;

      if (field == (tree) 
                  ((void *)0)
                           )
 {



   tree fndecls = lookup_fnfields (basetype_path, component, 1);
   if (fndecls == error_mark_node)
     return error_mark_node;
   if (fndecls)
     {
       if (((fndecls)->common.chain) == (tree) 
                                  ((void *)0)
    
   && (((((fndecls)->list.value))->decl.lang_specific)->chain) == (tree) 
                                           ((void *)0)
                                                    )
  {
    n64_enum_access_type access;
    tree fndecl;


    basetype = ((fndecls)->list.purpose);
    fndecl = ((fndecls)->list.value);
    access = compute_access (((fndecls)->list.purpose), fndecl);
    if (access == access_public)
      {
        if (((fndecl)->decl.vindex)
     && ! resolves_to_fixed_type_p (datum, 0))
   {
     tree addr = build_unary_op (ADDR_EXPR, datum, 0);
     addr = convert_pointer_to (((fndecl)->decl.context), addr);
     datum = build_indirect_ref (addr, ((void *)0));
     my_friendly_assert (datum != error_mark_node, 310);
     fndecl = build_vfn_ref (&addr, datum, ((fndecl)->decl.vindex));
   }
        assemble_external (fndecl);
        return fndecl;
      }
    if (access == access_protected)
      cp_error ("member function `%D' is protected", fndecl);
    else
      cp_error ("member function `%D' is private", fndecl);
    return error_mark_node;
  }
       else
  {


    tree t;

    for (t = ((fndecls)->list.value); t; t = (((t)->decl.lang_specific)->chain))
      assemble_external (t);

    t = build_tree_list (error_mark_node, fndecls);
    ((t)->common.type) = build_offset_type (basetype,
           unknown_type_node);
    return t;
  }
     }






     cp_error ("`%#T' has no member named `%D'", basetype, component);
   return error_mark_node;
 }
      else if (((field)->common.type) == error_mark_node)
 return error_mark_node;

      if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
 {
   if (((n64_enum_tree_code) (field)->common.code) == TYPE_DECL)
     {
       cp_error ("invalid use of type decl `%#D' as expression", field);
       return error_mark_node;
     }
    if (((field)->decl.rtl) != 0)
     assemble_external (field);
   ((field)->common.used_flag) = 1;
   return field;
 }
    }

  if (((field)->decl.context) != basetype
      && (((basetype)->common.lang_flag_1)))
    {
      tree addr = build_unary_op (ADDR_EXPR, datum, 0);
      if (integer_zerop (addr))
 {
   error ("invalid reference to NULL ptr, use ptr-to-member instead");
   return error_mark_node;
 }
      addr = convert_pointer_to (((field)->decl.context), addr);
      datum = build_indirect_ref (addr, ((void *)0));
      my_friendly_assert (datum != error_mark_node, 311);
    }
  ref = fold (build (COMPONENT_REF, ((field)->common.type),
       break_out_cleanups (datum), field));

  if (((datum)->common.readonly_flag) || ((field)->common.readonly_flag))
    ((ref)->common.readonly_flag) = 1;
  if (((datum)->common.volatile_flag) || ((field)->common.volatile_flag))
    ((ref)->common.volatile_flag) = 1;
  if ((((field)->decl.lang_specific)->decl_flags.mutable_flag))
    ((ref)->common.readonly_flag) = 0;

  return ref;
}
tree
build_x_indirect_ref(tree ptr, char *errorstring) asm("_build_x_indirect_ref");
tree
build_x_indirect_ref(tree ptr, char *errorstring)
{
  tree rval = build_opfncall (INDIRECT_REF, (3), ptr, (tree) 
                                                               ((void *)0)
                                                                        , (tree) 
                                                                          ((void *)0)
                                                                                   );
  if (rval)
    return rval;
  return build_indirect_ref (ptr, errorstring);
}

tree
build_indirect_ref(tree ptr, char *errorstring) asm("_build_indirect_ref");
tree
build_indirect_ref(tree ptr, char *errorstring)
{
  register tree pointer = (((n64_enum_tree_code) (((ptr)->common.type))->common.code) == REFERENCE_TYPE ?
      ptr : default_conversion (ptr));
  register tree type = ((pointer)->common.type);

  if (ptr == current_class_decl)
    return C_C_D;

  if ((((type)->type.lang_flag_5)))
    {
      ptr = build_expr_type_conversion (8, pointer, 1);

      if (ptr)
 {
   pointer = ptr;
   type = ((pointer)->common.type);
 }
    }

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    {
      if (((n64_enum_tree_code) (pointer)->common.code) == ADDR_EXPR
   && (((((((pointer)->exp.operands[0]))->common.type))->type.main_variant)
       == ((((type)->common.type))->type.main_variant))
   && (((((pointer)->exp.operands[0]))->common.readonly_flag)
       == ((((type)->common.type))->common.readonly_flag))
   && (((((pointer)->exp.operands[0]))->common.volatile_flag)
       == ((((type)->common.type))->common.volatile_flag)))
 return ((pointer)->exp.operands[0]);
      else
 {
   tree t = ((type)->common.type);
   register tree ref = build1 (INDIRECT_REF,
          ((t)->type.main_variant), pointer);

   ((ref)->common.readonly_flag) = ((t)->common.readonly_flag);
   ((ref)->common.volatile_flag) = ((t)->common.volatile_flag);
   ((ref)->common.side_effects_flag)
     = ((t)->common.volatile_flag) || ((pointer)->common.side_effects_flag);
   return ref;
 }
    }


  else if ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    error ("invalid use of `%s' on pointer to member function", errorstring);
  else if (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
    && ((((type)->type.lang_specific)->type_flags.is_signature_pointer) || (((type)->type.lang_specific)->type_flags.is_signature_reference)))
    error ("cannot dereference signature pointer/reference");
  else if (pointer != error_mark_node)
    {
      if (errorstring)
 error ("invalid type argument of `%s'", errorstring);
      else
 error ("invalid type argument");
    }
  return error_mark_node;
}
tree
build_x_array_ref(tree array, tree strchr) asm("_build_x_array_ref");
tree
build_x_array_ref(tree array, tree strchr)
{
  tree rval = build_opfncall (ARRAY_REF, (3), array, strchr, (tree) 
                                                                     ((void *)0)
                                                                              );
  if (rval)
    return rval;
  return build_array_ref (array, strchr);
}

tree
build_array_ref(tree array, tree idx) asm("_build_array_ref");
tree
build_array_ref(tree array, tree idx)
{
  tree itype;

  if (idx == 0)
    {
      error ("subscript missing in array reference");
      return error_mark_node;
    }

  if (((array)->common.type) == error_mark_node
      || ((idx)->common.type) == error_mark_node)
    return error_mark_node;

  itype = ((idx)->common.type);

  if (((n64_enum_tree_code) (((array)->common.type))->common.code) == ARRAY_TYPE
      && ((n64_enum_tree_code) (array)->common.code) != INDIRECT_REF)
    {
      tree rval, type;







      if (warn_char_subscripts
   && ((((idx)->common.type))->type.main_variant) == char_type_node)
 warning ("array subscript has type `char'");


      idx = default_conversion (idx);

      if (((n64_enum_tree_code) (((idx)->common.type))->common.code) != INTEGER_TYPE)
 {
   error ("array subscript is not an integer");
   return error_mark_node;
 }





      if (((n64_enum_tree_code) (idx)->common.code) != INTEGER_CST
   || (((((((array)->common.type))->common.type))->type.size) != 0
       && ((n64_enum_tree_code) (((((((array)->common.type))->common.type))->type.size))->common.code) != INTEGER_CST))
 {
   if (mark_addressable (array) == 0)
     return error_mark_node;
 }




      if (((n64_enum_tree_code) (idx)->common.code) == INTEGER_CST
   && ((((array)->common.type))->type.values)
   && ! int_fits_type_p (idx, ((((array)->common.type))->type.values)))
 {
   if (mark_addressable (array) == 0)
     return error_mark_node;
 }

      if (pedantic && !lvalue_p (array))
 pedwarn ("ANSI C++ forbids subscripting non-lvalue array");




      if (extra_warnings)
 {
   tree foo = array;
   while (((n64_enum_tree_code) (foo)->common.code) == COMPONENT_REF)
     foo = ((foo)->exp.operands[0]);
   if (((n64_enum_tree_code) (foo)->common.code) == VAR_DECL && ((foo)->decl.regdecl_flag))
     warning ("subscripting array declared `register'");
 }

      type = ((((((array)->common.type))->common.type))->type.main_variant);
      rval = build (ARRAY_REF, type, array, idx);


      ((rval)->common.readonly_flag)
 |= (((((((array)->common.type))->common.type))->common.readonly_flag)
     | ((array)->common.readonly_flag));
      ((rval)->common.side_effects_flag)
 |= (((((((array)->common.type))->common.type))->common.volatile_flag)
     | ((array)->common.side_effects_flag));
      ((rval)->common.volatile_flag)
 |= (((((((array)->common.type))->common.type))->common.volatile_flag)




     | ((array)->common.volatile_flag));
      return require_complete_type (fold (rval));
    }

  {
    tree ar = default_conversion (array);
    tree ind = default_conversion (idx);


    if (((n64_enum_tree_code) (((ar)->common.type))->common.code) == INTEGER_TYPE)
      {
 tree temp = ar;
 ar = ind;
 ind = temp;
      }

    if (ar == error_mark_node)
      return ar;

    if (((n64_enum_tree_code) (((ar)->common.type))->common.code) != POINTER_TYPE)
      {
 error ("subscripted value is neither array nor pointer");
 return error_mark_node;
      }
    if (((n64_enum_tree_code) (((ind)->common.type))->common.code) != INTEGER_TYPE)
      {
 error ("array subscript is not an integer");
 return error_mark_node;
      }

    return build_indirect_ref (build_binary_op_nodefault (PLUS_EXPR, ar, ind, PLUS_EXPR),
          "array indexing");
  }
}
tree
build_x_function_call(tree function, tree params, tree decl) asm("_build_x_function_call");
tree
build_x_function_call(tree function, tree params, tree decl)
{
  tree type;
  int is_method;

  if (function == error_mark_node)
    return error_mark_node;

  type = ((function)->common.type);
  is_method = ((((n64_enum_tree_code) (function)->common.code) == TREE_LIST
  && current_class_type != (tree) 
                          ((void *)0)
  
 && (((struct n64_tag_lang_identifier *)(((function)->list.purpose)))->class_value) == function)
        || ((n64_enum_tree_code) (function)->common.code) == IDENTIFIER_NODE
        || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE
        || (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag));


  if (is_method)
    {
      if (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL)
 {
   if (((function)->decl.name))
     function = ((function)->decl.name);
   else
     function = ((((((((function)->decl.lang_specific)->decl_flags.context))->type.name))->decl.name));
 }
      else if (((n64_enum_tree_code) (function)->common.code) == TREE_LIST)
 {






   my_friendly_assert (((n64_enum_tree_code) (((function)->list.value))->common.code) == FUNCTION_DECL, 312);
   function = ((function)->list.purpose);

 }
      else if (((n64_enum_tree_code) (function)->common.code) != IDENTIFIER_NODE)
 {
   if (((n64_enum_tree_code) (function)->common.code) == CP_OFFSET_REF)
     {
       if (((function)->exp.operands[0]))
  decl = ((function)->exp.operands[0]);
     }

   if (decl == (tree) 
              ((void *)0)
                       )
     {
       error ("pointer to member function called, but not in class scope");
       return error_mark_node;
     }

   if (((n64_enum_tree_code) (((function)->common.type))->common.code) != POINTER_TYPE
       && ! (((n64_enum_tree_code) (((function)->common.type))->common.code) == RECORD_TYPE && ((((function)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag)
       && ((n64_enum_tree_code) (function)->common.code) != CP_OFFSET_REF)
     function = build (CP_OFFSET_REF, ((type)->common.type), (tree) 
                                                    ((void *)0)
                                                             , function);
   goto do_x_function;
 }





      if (decl == (tree) 
                 ((void *)0)
                          )
 {
   if (current_class_type == (tree) 
                            ((void *)0)
                                     )
     {
       error ("object missing in call to method `%s'",
       ((function)->identifier.pointer));
       return error_mark_node;
     }

   decl = build1 (NOP_EXPR, build_pointer_type (current_class_type),
    error_mark_node);
   decl = build_indirect_ref (decl, ((void *)0));
 }

      return build_method_call (decl, function, params,
    (tree) 
   ((void *)0)
            , (3));
    }
  else if (((n64_enum_tree_code) (function)->common.code) == COMPONENT_REF
    && type == unknown_type_node)
    {

      if (((n64_enum_tree_code) (((((function)->exp.operands[1]))->list.purpose))->common.code) == TREE_VEC)

 function = ((((((function)->exp.operands[1]))->list.value))->decl.name);
      else
 function = ((((function)->exp.operands[1]))->list.purpose);
      return build_method_call (decl, function, params,
    (tree) 
   ((void *)0)
            , (3));
    }
  else if (((n64_enum_tree_code) (function)->common.code) == TREE_LIST)
    {
      if (((function)->list.value) == (tree) 
                                  ((void *)0)
                                           )
 {
   cp_error ("function `%D' declared overloaded, but no definitions appear with which to resolve it?!?",
      ((function)->list.purpose));
   return error_mark_node;
 }
      else
 {
   tree val = ((function)->list.value);

   if (((n64_enum_tree_code) (val)->common.code) == TEMPLATE_DECL)
     return build_overload_call_maybe
       (function, params, (2), (struct candidate *)0);
   else if ((((val)->decl.lang_specific)->chain) != (tree) 
                               ((void *)0)
                                        )
     return build_overload_call
       (function, params, (2), (struct candidate *)0);
   else
     my_friendly_abort (360);
 }
    }

 do_x_function:
  if (((n64_enum_tree_code) (function)->common.code) == CP_OFFSET_REF)
    {


      tree decl_addr;

      if (((function)->exp.operands[0]))
 decl = ((function)->exp.operands[0]);
      else
 decl = C_C_D;

      decl_addr = build_unary_op (ADDR_EXPR, decl, 0);
      function = get_member_function_from_ptrfunc (&decl_addr,
         ((function)->exp.operands[1]));
      params = tree_cons ((tree) 
                         ((void *)0)
                                  , decl_addr, params);
      return build_function_call (function, params);
    }

  type = ((function)->common.type);
  if (type != error_mark_node)
    {
      if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
 type = ((type)->common.type);

      if (((type)->type.lang_specific) && (((type)->type.lang_specific)->type_flags.has_call_overloaded))
 return build_opfncall (CALL_EXPR, (3), function, params, (tree) 
                                                                   ((void *)0)
                                                                            );
    }

  if (is_method)
    {
      tree fntype = ((function)->common.type);
      tree ctypeptr;


      if (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL)
 ctypeptr = build_pointer_type ((((function)->decl.lang_specific)->decl_flags.context));



      else if ((((n64_enum_tree_code) (fntype)->common.code) == RECORD_TYPE && ((fntype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
 {
   tree rec = (((((((((((((((((fntype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)))->common.type))->type.maxval);
   ctypeptr = build_pointer_type (rec);
 }

      else
 my_friendly_abort (116);
      if (decl == (tree) 
                 ((void *)0)
                          )
 {
   if (current_function_decl
       && (((current_function_decl)->decl.lang_specific)->decl_flags.static_function))
     error ("invalid call to member function needing `this' in static member function scope");
   else
     error ("pointer to member function called, but not in class scope");
   return error_mark_node;
 }
      if (((n64_enum_tree_code) (((decl)->common.type))->common.code) != POINTER_TYPE
   && ! (((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE && ((((decl)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
 {
   decl = build_unary_op (ADDR_EXPR, decl, 0);
   decl = convert_pointer_to (((ctypeptr)->common.type), decl);
 }
      else
 decl = build_c_cast (ctypeptr, decl, 0);
      params = tree_cons ((tree) 
                         ((void *)0)
                                  , decl, params);
    }

  return build_function_call (function, params);
}




tree
get_member_function_from_ptrfunc(tree *instance_ptrptr, tree function) asm("_get_member_function_from_ptrfunc");
tree
get_member_function_from_ptrfunc(tree *instance_ptrptr, tree function)
{
  if (((n64_enum_tree_code) (function)->common.code) == CP_OFFSET_REF)
    {
      function = ((function)->exp.operands[1]);
    }

  if ((((n64_enum_tree_code) (((function)->common.type))->common.code) == RECORD_TYPE && ((((function)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {
      tree fntype, strchr, e1, delta, delta2, e2, e3, aref, vtbl;
      tree instance;

      tree instance_ptr = *instance_ptrptr;

      if (((instance_ptr)->common.side_effects_flag))
 instance_ptr = save_expr (instance_ptr);

      if (((function)->common.side_effects_flag))
 function = save_expr (function);

      fntype = (((((((((((((((function)->common.type))->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      strchr = save_expr (build_component_ref (function,
           index_identifier,
           0, 0));
      e1 = build (GT_EXPR, boolean_type_node, strchr,
    convert (delta_type_node, integer_zero_node));
      delta = convert (ptrdiff_type_node,
         build_component_ref (function, delta_identifier, 0, 0));
      delta2 = (build_component_ref (build_component_ref ((function), pfn_or_delta2_identifier, 0, 0), delta2_identifier, 0, 0));


      instance
 = convert_pointer_to_real (((((fntype)->common.type))->type.maxval),
       instance_ptr);
      if (instance == error_mark_node)
 return instance;

      vtbl = convert_pointer_to (ptr_type_node, instance);
      vtbl
 = build (PLUS_EXPR,
   build_pointer_type (build_pointer_type (vtable_entry_type)),
   vtbl, convert (ptrdiff_type_node, delta2));
      vtbl = build_indirect_ref (vtbl, ((void *)0));
      aref = build_array_ref (vtbl, build_binary_op (MINUS_EXPR,
           strchr,
           integer_one_node, 1));
      if (! flag_vtable_thunks)
 {
   aref = save_expr (aref);



   if ( ((n64_enum_tree_code) (aref)->common.code) == INDIRECT_REF)
     ((aref)->exp.operands[0]) = save_expr (((aref)->exp.operands[0]));

   delta = build_binary_op (PLUS_EXPR,
       build_conditional_expr (e1, build_component_ref (aref, delta_identifier, 0, 0), integer_zero_node),
       delta, 1);
 }

      *instance_ptrptr = build (PLUS_EXPR, ((instance_ptr)->common.type),
    instance_ptr, delta);
      if (flag_vtable_thunks)
 e2 = aref;
      else
 e2 = build_component_ref (aref, pfn_identifier, 0, 0);

      e3 = (build_component_ref (build_component_ref ((function), pfn_or_delta2_identifier, 0, 0), pfn_identifier, 0, 0));
      ((e2)->common.type) = ((e3)->common.type);
      function = build_conditional_expr (e1, e2, e3);



      if (((n64_enum_tree_code) (instance_ptr)->common.code) == SAVE_EXPR)
 function = build (COMPOUND_EXPR, ((function)->common.type),
     instance_ptr, function);
    }
  return function;
}

tree
build_function_call_real(tree function, tree params, int require_complete, int flags) asm("_build_function_call_real");
tree
build_function_call_real(tree function, tree params, int require_complete, int flags)
{
  register tree fntype, fndecl;
  register tree value_type;
  register tree coerced_params;
  tree name = (tree) 
             ((void *)0)
                      , assembler_name = (tree) 
                                         ((void *)0)
                                                  ;
  int is_method;



  if (((n64_enum_tree_code) (function)->common.code) == NOP_EXPR
      && ((function)->common.type) == ((((function)->exp.operands[0]))->common.type))
    function = ((function)->exp.operands[0]);

  if (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL)
    {
      name = ((function)->decl.name);
      assembler_name = ((function)->decl.assembler_name);

      GNU_xref_call (current_function_decl,
       ((name ? name : ((((((((function)->decl.lang_specific)->decl_flags.context))->type.name))->decl.name)))->identifier.pointer)
                                                        );
      assemble_external (function);
      fndecl = function;


      if (pedantic
   && name
   && ((name)->identifier.length) == 4
   && ! strcmp (((name)->identifier.pointer), "main")
   && ((function)->decl.context) == (tree) 
                                ((void *)0)
                                         )
 {
   pedwarn ("ANSI C++ forbids calling `main' from within program");
 }

      if (pedantic && (((function)->decl.lang_specific)->decl_flags.declared_inline) && ! ((function)->decl.initial)
   && ! ((function)->decl.artificial_flag)
   && ! (((function)->decl.lang_specific)->pending_inline_info))
 cp_pedwarn ("inline function `%#D' called before definition",
      function);





      if (((function)->decl.inline_flag))
 {

   if (((function)->decl.artificial_flag) && ! flag_no_inline
       && ! ((function)->decl.initial)

       && current_function_decl)
     synthesize_method (function);

   fntype = build_type_variant (((function)->common.type),
           ((function)->common.readonly_flag),
           ((function)->common.volatile_flag));
   function = build1 (ADDR_EXPR, build_pointer_type (fntype), function);
 }
      else
 {
   assemble_external (function);
   ((function)->common.used_flag) = 1;
   function = default_conversion (function);
 }
    }
  else
    {
      fndecl = (tree) 
              ((void *)0)
                       ;


      if (function == error_mark_node)
 return error_mark_node;
      function = default_conversion (function);
    }

  fntype = ((function)->common.type);

  if ((((n64_enum_tree_code) (fntype)->common.code) == RECORD_TYPE && ((fntype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {
      tree instance_ptr = build_unary_op (ADDR_EXPR, C_C_D, 0);
      fntype = (((((((((((((fntype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      function = get_member_function_from_ptrfunc (&instance_ptr, function);
    }

  is_method = (((n64_enum_tree_code) (fntype)->common.code) == POINTER_TYPE
        && ((n64_enum_tree_code) (((fntype)->common.type))->common.code) == METHOD_TYPE);

  if (!((((n64_enum_tree_code) (fntype)->common.code) == POINTER_TYPE
  && ((n64_enum_tree_code) (((fntype)->common.type))->common.code) == FUNCTION_TYPE)
 || is_method))
    {
      cp_error ("`%E' cannot be used as a function", function);
      return error_mark_node;
    }


  fntype = ((fntype)->common.type);




  if (flags & (2))
    coerced_params = convert_arguments ((tree) 
                                       ((void *)0)
                                                , ((fntype)->type.values),
     params, fndecl, (3));
  else
    coerced_params = convert_arguments ((tree) 
                                       ((void *)0)
                                                , ((fntype)->type.values),
     params, fndecl, 0);

  if (coerced_params == error_mark_node)
    if (flags & (64))
      return (tree) 
            ((void *)0)
                     ;
    else
      return error_mark_node;



  if (warn_format && (name || assembler_name))
    check_function_format (name, assembler_name, coerced_params);





  if (((n64_enum_tree_code) (function)->common.code) == ADDR_EXPR
      && ((n64_enum_tree_code) (((function)->exp.operands[0]))->common.code) == FUNCTION_DECL
      && ((((function)->exp.operands[0]))->decl.bit_field_flag))
    switch (((((function)->exp.operands[0]))->decl.frame_size.f))
      {
      case BUILT_IN_ABS:
      case BUILT_IN_LABS:
      case BUILT_IN_FABS:
 if (coerced_params == 0)
   return integer_zero_node;
 return build_unary_op (ABS_EXPR, ((coerced_params)->list.value), 0);
      }


  value_type = ((fntype)->common.type) ? ((fntype)->common.type) : void_type_node;
  {
    register tree result =
      build (CALL_EXPR, value_type,
      function, coerced_params, (tree) 
                               ((void *)0)
                                        );

    ((result)->common.side_effects_flag) = 1;

    if (! require_complete)
      return convert_from_reference (result);
    if (value_type == void_type_node)
      return result;
    result = require_complete_type (result);
    return convert_from_reference (result);
  }
}

tree
build_function_call(tree function, tree params) asm("_build_function_call");
tree
build_function_call(tree function, tree params)
{
  return build_function_call_real (function, params, 1, (3));
}

tree
build_function_call_maybe(tree function, tree params) asm("_build_function_call_maybe");
tree
build_function_call_maybe(tree function, tree params)
{
  return build_function_call_real (function, params, 0, 0);
}
tree
convert_arguments(tree return_loc, tree typelist, tree values, tree fndecl, int flags) asm("_convert_arguments");
tree
convert_arguments(tree return_loc, tree typelist, tree values, tree fndecl, int flags)
{
  extern tree gc_protect_fndecl;
  register tree typetail, valtail;
  register tree result = (tree) 
                        ((void *)0)
                                 ;
  char *called_thing;
  int i = 0;

  if (! flag_elide_constructors)
    return_loc = 0;

  if (fndecl)
    {
      if (((n64_enum_tree_code) (((fndecl)->common.type))->common.code) == METHOD_TYPE)
 {
   if (((fndecl)->decl.name) == (tree) 
                            ((void *)0)
       
      || (((((fndecl)->decl.name))->common.type) ? 1 : 0))
     called_thing = "constructor";
   else
     called_thing = "member function";
 }
      else
 called_thing = "function";
    }

  for (valtail = values, typetail = typelist;
       valtail;
       valtail = ((valtail)->common.chain), i++)
    {
      register tree type = typetail ? ((typetail)->list.value) : 0;
      register tree val = ((valtail)->list.value);

      if (val == error_mark_node)
 return error_mark_node;

      if (type == void_type_node)
 {
   if (fndecl)
     {
       char *buf = (char *)
                          __builtin_alloca((
                          40 + strlen (called_thing)
                          ))
                                                             ;
       sprintf (buf, "too many arguments to %s `%%s'", called_thing);
       error_with_decl (fndecl, buf);
       error ("at this point in file");
     }
   else
     error ("too many arguments to function");


   if (result)
     ((tree_last (result))->common.type) = error_mark_node;
   break;
 }





      if (type && type_unknown_p (val))
 val = require_instantiated_type (type, val, integer_zero_node);
      else if (type_unknown_p (val))
 {

   if (((n64_enum_tree_code) (val)->common.code) == ADDR_EXPR)
     val = ((val)->exp.operands[0]);
   if (((n64_enum_tree_code) (val)->common.code) == TREE_LIST
       && ((val)->common.chain) == (tree) 
                             ((void *)0)
       
      && ((((val)->list.value))->common.type) != (tree) 
                                         ((void *)0)
       
      && (((val)->common.type) == unknown_type_node
    || (((((val)->list.value))->decl.lang_specific)->chain) == (tree) 
                                       ((void *)0)
                                                ))

     val = ((val)->list.value);
   else
     {
       error ("insufficient type information in parameter list");
       val = integer_zero_node;
     }
 }
      else if (((n64_enum_tree_code) (val)->common.code) == CP_OFFSET_REF
     && ((n64_enum_tree_code) (((val)->common.type))->common.code) == METHOD_TYPE)
 {

   val = build_unary_op (ADDR_EXPR, val, 0);
 }
      else if (((n64_enum_tree_code) (val)->common.code) == CP_OFFSET_REF)
 val = resolve_offset_ref (val);

      {
      }



      if (((n64_enum_tree_code) (val)->common.code) == NOP_EXPR
   && ((val)->common.type) == ((((val)->exp.operands[0]))->common.type)
   && (type == 0 || ((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE))
 val = ((val)->exp.operands[0]);

      if (type == 0 || ((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE)
 {
   if (((n64_enum_tree_code) (((val)->common.type))->common.code) == ARRAY_TYPE
       || ((n64_enum_tree_code) (((val)->common.type))->common.code) == FUNCTION_TYPE
       || ((n64_enum_tree_code) (((val)->common.type))->common.code) == METHOD_TYPE)
     val = default_conversion (val);

   val = require_complete_type (val);
 }

      if (val == error_mark_node)
 return error_mark_node;

      if (type != 0)
 {

   tree parmval;

   if (((type)->type.size) == 0)
     {
       error ("parameter type of called function is incomplete");
       parmval = val;
     }
   else
     {
       parmval = convert_for_initialization (return_loc, type, val, flags,
          "argument passing", fndecl, i);

       if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
     || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
    && (((type)->type.precision) < ((integer_type_node)->type.precision)))
  parmval = default_conversion (parmval);

     }

   if (parmval == error_mark_node)
     return error_mark_node;

   result = tree_cons ((tree) 
                      ((void *)0)
                               , parmval, result);
 }
      else
 {
   if (((n64_enum_tree_code) (((val)->common.type))->common.code) == REFERENCE_TYPE)
     val = convert_from_reference (val);

   if (((n64_enum_tree_code) (((val)->common.type))->common.code) == REAL_TYPE
       && (((((val)->common.type))->type.precision)
    < ((double_type_node)->type.precision)))

     result = tree_cons ((tree) 
                        ((void *)0)
                                 , convert (double_type_node, val), result);
   else if (((((val)->common.type))->type.lang_specific)
     && ! ((((((val)->common.type))->type.lang_specific)->type_flags.has_init_ref) && ! (((((val)->common.type))->type.lang_specific)->type_flags.has_complex_init_ref)))
     {
       cp_warning ("cannot pass objects of type `%T' through `...'",
     ((val)->common.type));
       result = tree_cons ((tree) 
                          ((void *)0)
                                   , val, result);
     }
   else

     result = tree_cons ((tree) 
                        ((void *)0)
                                 , default_conversion (val), result);
 }

      if (flag_gc


   && fndecl != gc_protect_fndecl
   && type_needs_gc_entry (((((result)->list.value))->common.type))
   && ! value_safe_from_gc ((tree) 
                           ((void *)0)
                                    , ((result)->list.value)))


 ((result)->list.value) = protect_value_from_gc ((tree) 
                                             ((void *)0)
                                                      ,
           ((result)->list.value));

      if (typetail)
 typetail = ((typetail)->common.chain);
    }

  if (typetail != 0 && typetail != void_list_node)
    {

      if (((typetail)->list.purpose))
 {
   for (; typetail != void_list_node; ++i)
     {
       tree type = ((typetail)->list.value);
       tree val = break_out_target_exprs (((typetail)->list.purpose));
       tree parmval;

       if (val == (tree) 
                 ((void *)0)
                          )
  parmval = error_mark_node;
       else if (((n64_enum_tree_code) (val)->common.code) == CONSTRUCTOR)
  {
    parmval = digest_init (type, val, (tree *)0);
    parmval = convert_for_initialization (return_loc, type, parmval, flags,
       "default constructor", fndecl, i);
  }
       else
  {

    if ((((val)->common.lang_flag_4)))
      val = copy_node (val);

    parmval = convert_for_initialization (return_loc, type, val, flags,
       "default argument", fndecl, i);

    if ((((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE
         || ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE)
        && (((type)->type.precision) < ((integer_type_node)->type.precision)))
      parmval = default_conversion (parmval);

  }

       if (parmval == error_mark_node)
  return error_mark_node;

       if (flag_gc
    && type_needs_gc_entry (((parmval)->common.type))
    && ! value_safe_from_gc ((tree) 
                            ((void *)0)
                                     , parmval))
  parmval = protect_value_from_gc ((tree) 
                                  ((void *)0)
                                           , parmval);

       result = tree_cons (0, parmval, result);
       typetail = ((typetail)->common.chain);

       if (typetail == (tree) 
                      ((void *)0)
                               )
  break;
     }
 }
      else
 {
   if (fndecl)
     {
       char *buf = (char *)
                          __builtin_alloca((
                          32 + strlen (called_thing)
                          ))
                                                             ;
       sprintf (buf, "too few arguments to %s `%%#D'", called_thing);
       cp_error_at (buf, fndecl);
       error ("at this point in file");
     }
   else
     error ("too few arguments to function");
   return error_mark_list;
 }
    }

  return nreverse (result);
}




tree
build_x_binary_op(n64_enum_tree_code code, tree arg1, tree arg2) asm("_build_x_binary_op");
tree
build_x_binary_op(n64_enum_tree_code code, tree arg1, tree arg2)
{
  tree rval = build_opfncall (code, (64),
         arg1, arg2, (tree) 
                    ((void *)0)
                             );
  if (rval)
    return build_opfncall (code, (3), arg1, arg2, (tree) 
                                                           ((void *)0)
                                                                    );
  if (code == MEMBER_REF)
    return build_m_component_ref (build_indirect_ref (arg1, ((void *)0)),
      arg2);
  return build_binary_op (code, arg1, arg2, 1);
}

tree
build_binary_op(n64_enum_tree_code code, tree arg1, tree arg2, int convert_p) asm("_build_binary_op");
tree
build_binary_op(n64_enum_tree_code code, tree arg1, tree arg2, int convert_p)
{
  tree args[2];

  args[0] = arg1;
  args[1] = arg2;

  if (convert_p)
    {
      tree args_save [2];
      tree type0, type1;
      args[0] = decay_conversion (args[0]);
      args[1] = decay_conversion (args[1]);

      if (args[0] == error_mark_node || args[1] == error_mark_node)
 return error_mark_node;

      type0 = ((args[0])->common.type);
      type1 = ((args[1])->common.type);

      if (type_unknown_p (args[0]))
 {
   args[0] = instantiate_type (type1, args[0], 1);
   args[0] = decay_conversion (args[0]);
 }
      else if (type_unknown_p (args[1]))
 {
   args[1] = require_instantiated_type (type0, args[1],
            error_mark_node);
   args[1] = decay_conversion (args[1]);
 }

      if ((((type0)->type.lang_flag_5)) || (((type1)->type.lang_flag_5)))
 {

   if (! build_default_binary_type_conversion(code, &args[0], &args[1]))
     {
       cp_error ("no match for `%O(%#T, %#T)'", code,
   ((arg1)->common.type), ((arg2)->common.type));
       return error_mark_node;
     }
 }
    }
  return build_binary_op_nodefault (code, args[0], args[1], code);
}
tree
build_binary_op_nodefault(n64_enum_tree_code code, tree orig_op0, tree orig_op1, n64_enum_tree_code error_code) asm("_build_binary_op_nodefault");
tree
build_binary_op_nodefault(n64_enum_tree_code code, tree orig_op0, tree orig_op1, n64_enum_tree_code error_code)
{
  tree op0, op1;
  register n64_enum_tree_code code0, code1;
  tree type0, type1;




  register n64_enum_tree_code resultcode = code;



  register tree result_type = 
                             ((void *)0)
                                 ;




  int converted = 0;



  tree build_type = 0;



  tree final_type = 0;







  int shorten = 0;




  int short_compare = 0;



  int short_shift = 0;


  int common = 0;


  if (code == TRUTH_AND_EXPR || code == TRUTH_ANDIF_EXPR
      || code == TRUTH_OR_EXPR || code == TRUTH_ORIF_EXPR
      || code == TRUTH_XOR_EXPR)
    {
      op0 = decay_conversion (orig_op0);
      op1 = decay_conversion (orig_op1);
    }
  else
    {
      op0 = default_conversion (orig_op0);
      op1 = default_conversion (orig_op1);
    }

  type0 = ((op0)->common.type);
  type1 = ((op1)->common.type);



  code0 = ((n64_enum_tree_code) (type0)->common.code);
  code1 = ((n64_enum_tree_code) (type1)->common.code);


  while ((((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op0)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op0)->common.code) == NON_LVALUE_EXPR) && (((op0)->common.type) == ((((op0)->exp.operands[0]))->common.type))) (op0) = ((op0)->exp.operands[0]);;
  while ((((n64_enum_tree_code) (op1)->common.code) == NOP_EXPR || ((n64_enum_tree_code) (op1)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (op1)->common.code) == NON_LVALUE_EXPR) && (((op1)->common.type) == ((((op1)->exp.operands[0]))->common.type))) (op1) = ((op1)->exp.operands[0]);;




  if (code0 == ERROR_MARK || code1 == ERROR_MARK)
    return error_mark_node;

  switch (code)
    {
    case PLUS_EXPR:

      if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 return pointer_int_sum (PLUS_EXPR, op0, op1);
      else if (code1 == POINTER_TYPE && code0 == INTEGER_TYPE)
 return pointer_int_sum (PLUS_EXPR, op1, op0);
      else
 common = 1;
      break;

    case MINUS_EXPR:


      if (code0 == POINTER_TYPE && code1 == POINTER_TYPE
   && comp_target_types (type0, type1, 1))
 return pointer_diff (op0, op1);

      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 return pointer_int_sum (MINUS_EXPR, op0, op1);
      else
 common = 1;
      break;

    case MULT_EXPR:
      common = 1;
      break;

    case TRUNC_DIV_EXPR:
    case CEIL_DIV_EXPR:
    case FLOOR_DIV_EXPR:
    case ROUND_DIV_EXPR:
    case EXACT_DIV_EXPR:
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 {
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST && integer_zerop (op1))
     cp_warning ("division by zero in `%E / 0'", op0);
   else if (((n64_enum_tree_code) (op1)->common.code) == REAL_CST && real_zerop (op1))
     cp_warning ("division by zero in `%E / 0.'", op0);

   if (!(code0 == INTEGER_TYPE && code1 == INTEGER_TYPE))
     resultcode = RDIV_EXPR;
   else





     shorten = ((((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR
   && ((((((op0)->exp.operands[0]))->common.type))->common.unsigned_flag))
         || (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
      && (((op1)->int_cst.int_cst_low) != -1
          || ((op1)->int_cst.int_cst_high) != -1)));
   common = 1;
 }
      break;

    case BIT_AND_EXPR:
    case BIT_ANDTC_EXPR:
    case BIT_IOR_EXPR:
    case BIT_XOR_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 shorten = -1;





      if (((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (op1)->common.code) == NOP_EXPR
   && ((type1)->type.precision) > ((((((op1)->exp.operands[0]))->common.type))->type.precision)
   && ((((((op1)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   final_type = result_type;
   op1 = ((op1)->exp.operands[0]);
   result_type = ((op1)->common.type);
 }
      if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
   && ((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR
   && ((type0)->type.precision) > ((((((op0)->exp.operands[0]))->common.type))->type.precision)
   && ((((((op0)->exp.operands[0]))->common.type))->common.unsigned_flag))
 {
   final_type = result_type;
   op0 = ((op0)->exp.operands[0]);
   result_type = ((op0)->common.type);
 }
      break;

    case TRUNC_MOD_EXPR:
    case FLOOR_MOD_EXPR:
      if (code1 == INTEGER_TYPE && integer_zerop (op1))
 cp_warning ("division by zero in `%E % 0'", op0);
      else if (code1 == REAL_TYPE && real_zerop (op1))
 cp_warning ("division by zero in `%E % 0.'", op0);

      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {




   shorten = ((((n64_enum_tree_code) (op0)->common.code) == NOP_EXPR
        && ((((((op0)->exp.operands[0]))->common.type))->common.unsigned_flag))
       || (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
    && (((op1)->int_cst.int_cst_low) != -1
        || ((op1)->int_cst.int_cst_high) != -1)));
   common = 1;
 }
      break;

    case TRUTH_ANDIF_EXPR:
    case TRUTH_ORIF_EXPR:
    case TRUTH_AND_EXPR:
    case TRUTH_OR_EXPR:
      result_type = boolean_type_node;
      break;





    case RSHIFT_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_lt (op1, integer_zero_node))
  warning ("right shift count is negative");
       else
  {
    if (((op1)->int_cst.int_cst_low) | ((op1)->int_cst.int_cst_high))
      short_shift = 1;
    if (((op1)->int_cst.int_cst_high) != 0
        || ((unsigned int) ((op1)->int_cst.int_cst_low)
     >= ((type0)->type.precision)))
      warning ("right shift count >= width of type");
  }
     }


   if (((((op1)->common.type))->type.main_variant) != integer_type_node)
     op1 = convert (integer_type_node, op1);

   converted = 1;
 }
      break;

    case LSHIFT_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_lt (op1, integer_zero_node))
  warning ("left shift count is negative");
       else if (((op1)->int_cst.int_cst_high) != 0
         || ((unsigned int) ((op1)->int_cst.int_cst_low)
      >= ((type0)->type.precision)))
  warning ("left shift count >= width of type");
     }


   if (((((op1)->common.type))->type.main_variant) != integer_type_node)
     op1 = convert (integer_type_node, op1);

   converted = 1;
 }
      break;

    case RROTATE_EXPR:
    case LROTATE_EXPR:
      if (code0 == INTEGER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST)
     {
       if (tree_int_cst_lt (op1, integer_zero_node))
  warning ("%s rotate count is negative",
    (code == LROTATE_EXPR) ? "left" : "right");
       else if (((op1)->int_cst.int_cst_high) != 0
         || ((unsigned int) ((op1)->int_cst.int_cst_low)
      >= ((type0)->type.precision)))
  warning ("%s rotate count >= width of type",
    (code == LROTATE_EXPR) ? "left" : "right");
     }


   if (((((op1)->common.type))->type.main_variant) != integer_type_node)
     op1 = convert (integer_type_node, op1);
 }
      break;

    case EQ_EXPR:
    case NE_EXPR:
      build_type = boolean_type_node;
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
   && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 short_compare = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   register tree tt0 = ((((type0)->common.type))->type.main_variant);
   register tree tt1 = ((((type1)->common.type))->type.main_variant);

   if (comp_target_types (type0, type1, 1))
     result_type = common_type (type0, type1);
   else if (tt0 == void_type_node)
     {
       if (pedantic && ((n64_enum_tree_code) (tt1)->common.code) == FUNCTION_TYPE
    && tree_int_cst_lt (((type0)->type.size), ((type1)->type.size)))
  pedwarn ("ANSI C++ forbids comparison of `void *' with function pointer");
       else if (((n64_enum_tree_code) (tt1)->common.code) == OFFSET_TYPE)
  pedwarn ("ANSI C++ forbids conversion of a pointer to member to `void *'");
     }
   else if (tt1 == void_type_node)
     {
       if (pedantic && ((n64_enum_tree_code) (tt0)->common.code) == FUNCTION_TYPE
    && tree_int_cst_lt (((type1)->type.size), ((type0)->type.size)))
  pedwarn ("ANSI C++ forbids comparison of `void *' with function pointer");
     }
   else
     cp_pedwarn ("comparison of distinct pointer types `%T' and `%T' lacks a cast",
   type0, type1);

   if (result_type == (tree) 
                     ((void *)0)
                              )
     result_type = ptr_type_node;
 }
      else if (code0 == POINTER_TYPE && ((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && integer_zerop (op1))
 result_type = type0;
      else if (code1 == POINTER_TYPE && ((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
        && integer_zerop (op0))
 result_type = type1;
      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   error ("ANSI C++ forbids comparison between pointer and integer");
 }
      else if (code0 == INTEGER_TYPE && code1 == POINTER_TYPE)
 {
   result_type = type1;
   error ("ANSI C++ forbids comparison between pointer and integer");
 }
      else if ((((n64_enum_tree_code) (type0)->common.code) == RECORD_TYPE && ((type0)->type.lang_specific)->type_flags.ptrmemfunc_flag) && ((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && integer_zerop (op1))
 {
   op0 = build_component_ref (op0, index_identifier, 0, 0);
   op1 = integer_zero_node;
   result_type = ((op0)->common.type);
 }
      else if ((((n64_enum_tree_code) (type1)->common.code) == RECORD_TYPE && ((type1)->type.lang_specific)->type_flags.ptrmemfunc_flag) && ((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
        && integer_zerop (op0))
 {
   op0 = build_component_ref (op1, index_identifier, 0, 0);
   op1 = integer_zero_node;
   result_type = ((op0)->common.type);
 }
      else if ((((n64_enum_tree_code) (type0)->common.code) == RECORD_TYPE && ((type0)->type.lang_specific)->type_flags.ptrmemfunc_flag) && (((n64_enum_tree_code) (type1)->common.code) == RECORD_TYPE && ((type1)->type.lang_specific)->type_flags.ptrmemfunc_flag)
        && ((((((((((((((type0)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type))
     == (((((((((((((type1)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type))))
 {






   tree index0 = build_component_ref (op0, index_identifier, 0, 0);
   tree index1 = save_expr (build_component_ref (op1, index_identifier, 0, 0));
   tree pfn0 = (build_component_ref (build_component_ref ((op0), pfn_or_delta2_identifier, 0, 0), pfn_identifier, 0, 0));
   tree pfn1 = (build_component_ref (build_component_ref ((op1), pfn_or_delta2_identifier, 0, 0), pfn_identifier, 0, 0));
   tree delta20 = (build_component_ref (build_component_ref ((op0), pfn_or_delta2_identifier, 0, 0), delta2_identifier, 0, 0));
   tree delta21 = (build_component_ref (build_component_ref ((op1), pfn_or_delta2_identifier, 0, 0), delta2_identifier, 0, 0));
   tree e1, e2, e3;
   tree integer_neg_one_node
     = build_binary_op (MINUS_EXPR, integer_zero_node, integer_one_node, 1);
   e1 = build_binary_op (EQ_EXPR, index0, index1, 1);
   e2 = build_binary_op (NE_EXPR, index1, integer_neg_one_node, 1);
   e2 = build_binary_op (TRUTH_ANDIF_EXPR, e2, build_binary_op (EQ_EXPR, delta20, delta21, 1), 1);
   e3 = build_binary_op (EQ_EXPR, pfn0, pfn1, 1);
   e2 = build_binary_op (TRUTH_ORIF_EXPR, e2, e3, 1);
   e2 = build_binary_op (TRUTH_ANDIF_EXPR, e1, e2, 1);
   if (code == EQ_EXPR)
     return e2;
   return build_binary_op (EQ_EXPR, e2, integer_zero_node, 1);
 }
      else if ((((n64_enum_tree_code) (type0)->common.code) == RECORD_TYPE && ((type0)->type.lang_specific)->type_flags.ptrmemfunc_flag)
        && (((((((((((((type0)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)) == type1)
 {
   tree index0 = build_component_ref (op0, index_identifier, 0, 0);
   tree index1;
   tree pfn0 = (build_component_ref (build_component_ref ((op0), pfn_or_delta2_identifier, 0, 0), pfn_identifier, 0, 0));
   tree delta20 = (build_component_ref (build_component_ref ((op0), pfn_or_delta2_identifier, 0, 0), delta2_identifier, 0, 0));
   tree delta21 = integer_zero_node;
   tree e1, e2, e3;
   tree integer_neg_one_node
     = build_binary_op (MINUS_EXPR, integer_zero_node, integer_one_node, 1);
   if (((n64_enum_tree_code) (((op1)->exp.operands[0]))->common.code) == FUNCTION_DECL
       && ((((op1)->exp.operands[0]))->decl.vindex))
     {

       index1 = size_binop (PLUS_EXPR,
       ((((op1)->exp.operands[0]))->decl.vindex),
       integer_one_node);
       op1 = integer_zero_node;
       delta21 = ((((((type1)->common.type))->type.maxval))->type.minval);
       delta21 = ((delta21)->decl.arguments);
       delta21 = size_binop (FLOOR_DIV_EXPR, delta21, size_int (8));
     }
   else
     index1 = integer_neg_one_node;
   {
     tree nop1 = build1 (NOP_EXPR, (((((((((((((type0)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)), op1);
     ((nop1)->common.constant_flag) = ((op1)->common.constant_flag);
     op1 = nop1;
   }
   e1 = build_binary_op (EQ_EXPR, index0, index1, 1);
   e2 = build_binary_op (NE_EXPR, index1, integer_neg_one_node, 1);
   e2 = build_binary_op (TRUTH_ANDIF_EXPR, e2, build_binary_op (EQ_EXPR, delta20, delta21, 1), 1);
   e3 = build_binary_op (EQ_EXPR, pfn0, op1, 1);
   e2 = build_binary_op (TRUTH_ORIF_EXPR, e2, e3, 1);
   e2 = build_binary_op (TRUTH_ANDIF_EXPR, e1, e2, 1);
   if (code == EQ_EXPR)
     return e2;
   return build_binary_op (EQ_EXPR, e2, integer_zero_node, 1);
 }
      else if ((((n64_enum_tree_code) (type1)->common.code) == RECORD_TYPE && ((type1)->type.lang_specific)->type_flags.ptrmemfunc_flag)
        && (((((((((((((type1)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)) == type0)
 {
   return build_binary_op (code, op1, op0, 1);
 }
      break;

    case MAX_EXPR:
    case MIN_EXPR:
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
    && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 shorten = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   if (comp_target_types (type0, type1, 1))
     result_type = common_type (type0, type1);
   else
     {
       cp_pedwarn ("comparison of distinct pointer types `%T' and `%T' lacks a cast",
     type0, type1);
       result_type = ptr_type_node;
     }
 }
      break;

    case LE_EXPR:
    case GE_EXPR:
    case LT_EXPR:
    case GT_EXPR:
      build_type = boolean_type_node;
      if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
    && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
 short_compare = 1;
      else if (code0 == POINTER_TYPE && code1 == POINTER_TYPE)
 {
   if (comp_target_types (type0, type1, 1))
     result_type = common_type (type0, type1);
   else
     {
       cp_pedwarn ("comparison of distinct pointer types `%T' and `%T' lacks a cast",
     type0, type1);
       result_type = ptr_type_node;
     }
 }
      else if (code0 == POINTER_TYPE && ((n64_enum_tree_code) (op1)->common.code) == INTEGER_CST
        && integer_zerop (op1))
 result_type = type0;
      else if (code1 == POINTER_TYPE && ((n64_enum_tree_code) (op0)->common.code) == INTEGER_CST
        && integer_zerop (op0))
 result_type = type1;
      else if (code0 == POINTER_TYPE && code1 == INTEGER_TYPE)
 {
   result_type = type0;
   if (pedantic)
     pedwarn ("ANSI C++ forbids comparison between pointer and integer");
   else if (! flag_traditional)
     warning ("comparison between pointer and integer");
 }
      else if (code0 == INTEGER_TYPE && code1 == POINTER_TYPE)
 {
   result_type = type1;
   if (pedantic)
     pedwarn ("ANSI C++ forbids comparison between pointer and integer");
   else if (! flag_traditional)
     warning ("comparison between pointer and integer");
 }
      break;
    }

  if ((code0 == INTEGER_TYPE || code0 == REAL_TYPE)
      && (code1 == INTEGER_TYPE || code1 == REAL_TYPE))
    {
      if (shorten || common || short_compare)
 result_type = common_type (type0, type1);
      if (shorten)
 {
   int unsigned0, unsigned1;
   tree arg0 = get_narrower (op0, &unsigned0);
   tree arg1 = get_narrower (op1, &unsigned1);

   int uns = ((result_type)->common.unsigned_flag);
   tree type;

   final_type = result_type;




   if (op0 == arg0 && ((op0)->common.type) != final_type)
     unsigned0 = ((((op0)->common.type))->common.unsigned_flag);
   if (op1 == arg1 && ((op1)->common.type) != final_type)
     unsigned1 = ((((op1)->common.type))->common.unsigned_flag);





   if (shorten == -1)
     uns = unsigned0;
   if ((((((arg0)->common.type))->type.precision)
        < ((result_type)->type.precision))
       && (((((arg1)->common.type))->type.precision)
    == ((((arg0)->common.type))->type.precision))
       && unsigned0 == unsigned1
       && (unsigned0 || !uns))
     result_type
       = signed_or_unsigned_type (unsigned0,
      common_type (((arg0)->common.type), ((arg1)->common.type)));
   else if (((n64_enum_tree_code) (arg0)->common.code) == INTEGER_CST
     && (unsigned1 || !uns)
     && (((((arg1)->common.type))->type.precision)
         < ((result_type)->type.precision))
     && (type = signed_or_unsigned_type (unsigned1,
             ((arg1)->common.type)),
         int_fits_type_p (arg0, type)))
     result_type = type;
   else if (((n64_enum_tree_code) (arg1)->common.code) == INTEGER_CST
     && (unsigned0 || !uns)
     && (((((arg0)->common.type))->type.precision)
         < ((result_type)->type.precision))
     && (type = signed_or_unsigned_type (unsigned0,
             ((arg0)->common.type)),
         int_fits_type_p (arg1, type)))
     result_type = type;
 }



      if (short_shift)
 {
   int unsigned_arg;
   tree arg0 = get_narrower (op0, &unsigned_arg);

   final_type = result_type;

   if (arg0 == op0 && final_type == ((op0)->common.type))
     unsigned_arg = ((((op0)->common.type))->common.unsigned_flag);

   if (((((arg0)->common.type))->type.precision) < ((result_type)->type.precision)


       && ((op1)->int_cst.int_cst_high) == 0
       && ((((arg0)->common.type))->type.precision) > ((op1)->int_cst.int_cst_low)







       && (!((final_type)->common.unsigned_flag)
    || unsigned_arg
    || ((unsigned) 2 * ((((arg0)->common.type))->type.precision)
        <= ((result_type)->type.precision))))
     {

       result_type
  = signed_or_unsigned_type (unsigned_arg,
        ((arg0)->common.type));

       if (((op0)->common.type) != result_type)
  op0 = convert (result_type, op0);
       converted = 1;
     }
 }




      if (short_compare)
 {




   tree xop0 = op0, xop1 = op1, xresult_type = result_type;
   n64_enum_tree_code xresultcode = resultcode;
   tree val
     = shorten_compare (&xop0, &xop1, &xresult_type, &xresultcode);
   if (val != 0)
     return convert (boolean_type_node, val);
   op0 = xop0, op1 = xop1;
   converted = 1;
   resultcode = xresultcode;
 }

      if (short_compare && extra_warnings)
 {
   int op0_signed = ! ((((orig_op0)->common.type))->common.unsigned_flag);
   int op1_signed = ! ((((orig_op1)->common.type))->common.unsigned_flag);

   int unsignedp0, unsignedp1;
   tree primop0 = get_narrower (op0, &unsignedp0);
   tree primop1 = get_narrower (op1, &unsignedp1);
   if (! ((result_type)->common.unsigned_flag))
             ;

   else if (op0_signed == op1_signed)
             ;



   else if ((op0_signed && ((n64_enum_tree_code) (orig_op0)->common.code) == INTEGER_CST
      && tree_int_cst_sgn (orig_op0) >= 0)
     || (op1_signed && ((n64_enum_tree_code) (orig_op1)->common.code) == INTEGER_CST
         && tree_int_cst_sgn (orig_op1) >= 0))
             ;



   else if ((resultcode == EQ_EXPR || resultcode == NE_EXPR)
     && ((op0_signed && ((n64_enum_tree_code) (orig_op1)->common.code) == INTEGER_CST
   && int_fits_type_p (orig_op1, signed_type (result_type))
   || (op1_signed && ((n64_enum_tree_code) (orig_op0)->common.code) == INTEGER_CST
       && int_fits_type_p (orig_op0, signed_type (result_type))))))
             ;
   else
     warning ("comparison between signed and unsigned");
   if (((n64_enum_tree_code) (primop0)->common.code) == BIT_NOT_EXPR
       ^ ((n64_enum_tree_code) (primop1)->common.code) == BIT_NOT_EXPR)
     {
       if (((n64_enum_tree_code) (primop0)->common.code) == BIT_NOT_EXPR)
  primop0 = get_narrower (((op0)->exp.operands[0]), &unsignedp0);
       if (((n64_enum_tree_code) (primop1)->common.code) == BIT_NOT_EXPR)
  primop1 = get_narrower (((op1)->exp.operands[0]), &unsignedp1);

       if (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST
    || ((n64_enum_tree_code) (primop1)->common.code) == INTEGER_CST)
  {
    tree primop;
    int constant, mask;
    int unsignedp;
    unsigned bits;

    if (((n64_enum_tree_code) (primop0)->common.code) == INTEGER_CST)
      {
        primop = primop1;
        unsignedp = unsignedp1;
        constant = ((primop0)->int_cst.int_cst_low);
      }
    else
      {
        primop = primop0;
        unsignedp = unsignedp0;
        constant = ((primop1)->int_cst.int_cst_low);
      }

    bits = ((((primop)->common.type))->type.precision);
    if (bits < ((result_type)->type.precision)
        && bits < 32 && unsignedp)
      {
        mask = (~ (int) 0) << bits;
        if ((mask & constant) != mask)
   warning ("comparison of promoted ~unsigned with constant");
      }
  }
       else if (unsignedp0 && unsignedp1
         && (((((primop0)->common.type))->type.precision)
      < ((result_type)->type.precision))
         && (((((primop1)->common.type))->type.precision)
      < ((result_type)->type.precision)))
  warning ("comparison of promoted ~unsigned with unsigned");
     }
 }
    }







  if (!result_type)
    {
      cp_error ("invalid operands `%T' and `%T' to binary `%O'",
  ((orig_op0)->common.type), ((orig_op1)->common.type), error_code);
      return error_mark_node;
    }

  if (! converted)
    {
      if (((op0)->common.type) != result_type)
 op0 = convert (result_type, op0);
      if (((op1)->common.type) != result_type)
 op1 = convert (result_type, op1);
    }

  if (build_type == (tree) 
                   ((void *)0)
                            )
    build_type = result_type;

  {
    register tree result = build (resultcode, build_type, op0, op1);
    register tree folded;

    folded = fold (result);
    if (folded == result)
      ((folded)->common.constant_flag) = ((op0)->common.constant_flag) & ((op1)->common.constant_flag);
    if (final_type != 0)
      return convert (final_type, folded);
    return folded;
  }
}




static tree
pointer_int_sum(n64_enum_tree_code resultcode, register tree ptrop, register tree intop) asm("_pointer_int_sum");
static tree
pointer_int_sum(n64_enum_tree_code resultcode, register tree ptrop, register tree intop)
{
  tree size_exp;

  register tree result;
  register tree folded = fold (intop);



  register tree result_type = ((ptrop)->common.type);

  if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == VOID_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids using pointer of type `void *' in arithmetic");
      size_exp = integer_one_node;
    }
  else if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == FUNCTION_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids using pointer to a function in arithmetic");
      size_exp = integer_one_node;
    }
  else if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == METHOD_TYPE)
    {
      if (pedantic || warn_pointer_arith)
 pedwarn ("ANSI C++ forbids using pointer to a method in arithmetic");
      size_exp = integer_one_node;
    }
  else if (((n64_enum_tree_code) (((result_type)->common.type))->common.code) == OFFSET_TYPE)
    {
      if (pedantic)
 pedwarn ("ANSI C++ forbids using pointer to a member in arithmetic");
      size_exp = integer_one_node;
    }
  else
    size_exp = size_in_bytes (((result_type)->common.type));


  intop = folded;
  if (((n64_enum_tree_code) (intop)->common.code) == INTEGER_CST
      && ((intop)->int_cst.int_cst_low) == 0
      && ((intop)->int_cst.int_cst_high) == 0)
    return ptrop;






  if ((((n64_enum_tree_code) (intop)->common.code) == PLUS_EXPR || ((n64_enum_tree_code) (intop)->common.code) == MINUS_EXPR)
      && ! ((intop)->common.constant_flag)
      && ((((intop)->exp.operands[1]))->common.constant_flag)
      && ((size_exp)->common.constant_flag))
    {
      n64_enum_tree_code subcode = resultcode;
      if (((n64_enum_tree_code) (intop)->common.code) == MINUS_EXPR)
 subcode = (subcode == PLUS_EXPR ? MINUS_EXPR : PLUS_EXPR);
      ptrop = build_binary_op (subcode, ptrop, ((intop)->exp.operands[1]), 1);
      intop = ((intop)->exp.operands[0]);
    }




  if (((((intop)->common.type))->type.precision) != ((target_flags & 0x00000002) ? 64 : 32))
    intop = convert (type_for_size (((target_flags & 0x00000002) ? 64 : 32), 0), intop);





  intop = convert (result_type,
     build_binary_op (MULT_EXPR, intop,
        convert (((intop)->common.type), size_exp), 1));



  result = build (resultcode, result_type, ptrop, intop);

  folded = fold (result);
  if (folded == result)
    ((folded)->common.constant_flag) = ((ptrop)->common.constant_flag) & ((intop)->common.constant_flag);
  return folded;
}




static tree
pointer_diff(register tree op0, register tree op1) asm("_pointer_diff");
static tree
pointer_diff(register tree op0, register tree op1)
{
  register tree result, folded;
  tree restype = ptrdiff_type_node;
  tree target_type = ((((op0)->common.type))->common.type);

  if (pedantic)
    {
      if (((n64_enum_tree_code) (target_type)->common.code) == VOID_TYPE)
 pedwarn ("ANSI C++ forbids using pointer of type `void *' in subtraction");
      if (((n64_enum_tree_code) (target_type)->common.code) == FUNCTION_TYPE)
 pedwarn ("ANSI C++ forbids using pointer to a function in subtraction");
      if (((n64_enum_tree_code) (target_type)->common.code) == METHOD_TYPE)
 pedwarn ("ANSI C++ forbids using pointer to a method in subtraction");
      if (((n64_enum_tree_code) (target_type)->common.code) == OFFSET_TYPE)
 pedwarn ("ANSI C++ forbids using pointer to a member in subtraction");
    }




  op0 = build_binary_op (MINUS_EXPR,
    convert (restype, op0), convert (restype, op1), 1);


  if (((((((op1)->common.type))->common.type))->type.size) == 0)
    error ("arithmetic on pointer to an incomplete type");

  op1 = ((((n64_enum_tree_code) (target_type)->common.code) == VOID_TYPE
   || ((n64_enum_tree_code) (target_type)->common.code) == FUNCTION_TYPE
   || ((n64_enum_tree_code) (target_type)->common.code) == METHOD_TYPE
   || ((n64_enum_tree_code) (target_type)->common.code) == OFFSET_TYPE)
  ? integer_one_node
  : size_in_bytes (target_type));



  result = build (EXACT_DIV_EXPR, restype, op0, convert (restype, op1));

  folded = fold (result);
  if (folded == result)
    ((folded)->common.constant_flag) = ((op0)->common.constant_flag) & ((op1)->common.constant_flag);
  return folded;
}
tree
build_component_addr(tree arg, tree argtype, char *msg) asm("_build_component_addr");
tree
build_component_addr(tree arg, tree argtype, char *msg)
{
  tree field = ((arg)->exp.operands[1]);
  tree basetype = decl_type_context (field);
  tree rval = build_unary_op (ADDR_EXPR, ((arg)->exp.operands[0]), 0);

  if (((field)->decl.bit_field_flag))
    {
      error (msg, ((((field)->decl.name))->identifier.pointer));
      return error_mark_node;
    }

  if (flag_gc)
    cp_warning ("address of `%T::%D' taken", basetype, field);

  if (((n64_enum_tree_code) (field)->common.code) == FIELD_DECL
      && (((basetype)->common.lang_flag_1)))
    {



      rval = build1 (NOP_EXPR, argtype,
       convert_pointer_to (basetype, rval));
      ((rval)->common.constant_flag) = ((((rval)->exp.operands[0]))->common.constant_flag);
    }
  else

    rval = convert_force (argtype, rval, 0);

  if (! integer_zerop (((field)->decl.arguments)))
    {
      tree offset = size_binop (TRUNC_DIV_EXPR, ((field)->decl.arguments),
    size_int (8));
      int flag = ((rval)->common.constant_flag);
      rval = fold (build (PLUS_EXPR, argtype,
     rval, convert (argtype, offset)));
      ((rval)->common.constant_flag) = flag;
    }
  return rval;
}





tree
build_x_unary_op(n64_enum_tree_code code, tree xarg) asm("_build_x_unary_op");
tree
build_x_unary_op(n64_enum_tree_code code, tree xarg)
{


  if (code == ADDR_EXPR
      && (((((n64_enum_tree_code) (((xarg)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((xarg)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((xarg)->common.type))->common.code) == UNINSTANTIATED_P_TYPE)
    && ((((xarg)->common.type))->type.size) == (tree) 
                                      ((void *)0)
                                               )
   || (((n64_enum_tree_code) (xarg)->common.code) == CP_OFFSET_REF)))
                                   ;
  else
    {
      tree rval = build_opfncall (code, (64), xarg,
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         );
      if (rval)
 return build_opfncall (code, (3), xarg,
          (tree) 
         ((void *)0)
                  , (tree) 
                    ((void *)0)
                             );
    }
  return build_unary_op (code, xarg, 0);
}



tree
condition_conversion(tree expr) asm("_condition_conversion");
tree
condition_conversion(tree expr)
{
  tree t = convert (boolean_type_node, expr);
  t = fold (build1 (CLEANUP_POINT_EXPR, boolean_type_node, t));
  return t;
}
tree
build_unary_op(n64_enum_tree_code code, tree xarg, int noconvert) asm("_build_unary_op");
tree
build_unary_op(n64_enum_tree_code code, tree xarg, int noconvert)
{

  register tree arg = xarg;
  register tree argtype = 0;
  char *errstring = 
                   ((void *)0)
                       ;
  tree val;

  if (arg == error_mark_node)
    return error_mark_node;

  switch (code)
    {
    case CONVERT_EXPR:



      if (!(arg = build_expr_type_conversion
     ((1 | 2) | 4 | 8, arg, 1)))
 errstring = "wrong type argument to unary plus";
      else
 {
   if (!noconvert)
    arg = default_conversion (arg);
   arg = build1 (NON_LVALUE_EXPR, ((arg)->common.type), arg);
 }
      break;

    case NEGATE_EXPR:
      if (!(arg = build_expr_type_conversion ((1 | 2) | 4, arg, 1)))
 errstring = "wrong type argument to unary minus";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case BIT_NOT_EXPR:
      if (!(arg = build_expr_type_conversion (1 | 4, arg, 1)))
 errstring = "wrong type argument to bit-complement";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case ABS_EXPR:
      if (!(arg = build_expr_type_conversion ((1 | 2) | 4, arg, 1)))
 errstring = "wrong type argument to abs";
      else if (!noconvert)
 arg = default_conversion (arg);
      break;

    case TRUTH_NOT_EXPR:
      arg = convert (boolean_type_node, arg);
      val = invert_truthvalue (arg);
      if (arg != error_mark_node)
 return val;
      errstring = "in argument to unary !";
      break;

    case NOP_EXPR:
      break;

    case PREINCREMENT_EXPR:
    case POSTINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case POSTDECREMENT_EXPR:



      val = unary_complex_lvalue (code, arg);
      if (val != 0)
 return val;



      if (!(arg = build_expr_type_conversion ((1 | 2) | 8,
           arg, 1)))
 {
   if (code == PREINCREMENT_EXPR)
     errstring ="no pre-increment operator for type";
   else if (code == POSTINCREMENT_EXPR)
     errstring ="no post-increment operator for type";
   else if (code == PREDECREMENT_EXPR)
     errstring ="no pre-decrement operator for type";
   else
     errstring ="no post-decrement operator for type";
   break;
 }



      if (((((arg)->common.type))->common.readonly_flag)
   || ((arg)->common.readonly_flag))
 readonly_error (arg, ((code == PREINCREMENT_EXPR
          || code == POSTINCREMENT_EXPR)
         ? "increment" : "decrement"),
   0);

      {
 register tree inc;
 tree result_type = ((arg)->common.type);

 arg = get_unwidened (arg, 0);
 argtype = ((arg)->common.type);


 if (((n64_enum_tree_code) (argtype)->common.code) == ENUMERAL_TYPE)
   pedwarn ("ANSI C++ forbids %sing an enum",
     (code == PREINCREMENT_EXPR || code == POSTINCREMENT_EXPR)
     ? "increment" : "decrement");



 if (((n64_enum_tree_code) (argtype)->common.code) == POINTER_TYPE)
   {
     n64_enum_tree_code tmp = ((n64_enum_tree_code) (((argtype)->common.type))->common.code);
     if (((((argtype)->common.type))->type.size) == 0)
       cp_error ("cannot %s a pointer to incomplete type `%T'",
   ((code == PREINCREMENT_EXPR
     || code == POSTINCREMENT_EXPR)
    ? "increment" : "decrement"), ((argtype)->common.type));
     else if (tmp == FUNCTION_TYPE || tmp == METHOD_TYPE
       || tmp == VOID_TYPE || tmp == OFFSET_TYPE)
       cp_pedwarn ("ANSI C++ forbids %sing a pointer of type `%T'",
     ((code == PREINCREMENT_EXPR
       || code == POSTINCREMENT_EXPR)
      ? "increment" : "decrement"), argtype);
     inc = c_sizeof_nowarn (((argtype)->common.type));
   }
 else
   inc = integer_one_node;

 inc = convert (argtype, inc);



 switch (((n64_enum_tree_code) (arg)->common.code))
   {
   case NOP_EXPR:
   case CONVERT_EXPR:
   case FLOAT_EXPR:
   case FIX_TRUNC_EXPR:
   case FIX_FLOOR_EXPR:
   case FIX_ROUND_EXPR:
   case FIX_CEIL_EXPR:
     {
       tree incremented, modify, value;
       if (! lvalue_p (arg) && pedantic)
  pedwarn ("cast to non-reference type used as lvalue");
       arg = stabilize_reference (arg);
       if (code == PREINCREMENT_EXPR || code == PREDECREMENT_EXPR)
  value = arg;
       else
  value = save_expr (arg);
       incremented = build (((code == PREINCREMENT_EXPR
         || code == POSTINCREMENT_EXPR)
        ? PLUS_EXPR : MINUS_EXPR),
       argtype, value, inc);
       ((incremented)->common.side_effects_flag) = 1;
       modify = build_modify_expr (arg, NOP_EXPR, incremented);
       return build (COMPOUND_EXPR, ((arg)->common.type), modify, value);
     }
   }


 if (!lvalue_or_else (arg, ((code == PREINCREMENT_EXPR
        || code == POSTINCREMENT_EXPR)
       ? "increment" : "decrement")))
   return error_mark_node;


 if (((arg)->common.type) == boolean_type_node)
   {
     if (code == POSTDECREMENT_EXPR || code == PREDECREMENT_EXPR)
       {
  cp_error ("invalid use of `--' on bool variable `%D'", arg);
  return error_mark_node;
       }





     if (code == POSTINCREMENT_EXPR)
       {
  arg = stabilize_reference (arg);
  val = build (MODIFY_EXPR, ((arg)->common.type), arg,
        boolean_true_node);
  ((val)->common.side_effects_flag) = 1;
  arg = save_expr (arg);
  val = build (COMPOUND_EXPR, ((arg)->common.type), val, arg);
  val = build (COMPOUND_EXPR, ((arg)->common.type), arg, val);
       }
     else
       val = build (MODIFY_EXPR, ((arg)->common.type), arg,
      boolean_true_node);

   }
 else
   val = build (code, ((arg)->common.type), arg, inc);

 ((val)->common.side_effects_flag) = 1;
 return convert (result_type, val);
      }

    case ADDR_EXPR:



      argtype = ((arg)->common.type);
      if (((n64_enum_tree_code) (argtype)->common.code) == REFERENCE_TYPE)
 {
   arg = build1 (CONVERT_EXPR, build_pointer_type (((((arg)->common.type))->common.type)), arg);
   (((arg)->common.lang_flag_3)) = 1;
   return arg;
 }
      else if (pedantic
        && ((n64_enum_tree_code) (arg)->common.code) == FUNCTION_DECL
        && ((arg)->decl.name)
        && ((arg)->decl.context) == (tree) 
                                ((void *)0)
        
       && ((((arg)->decl.name))->identifier.length) == 4
        && ((((arg)->decl.name))->identifier.pointer)[0] == 'm'
        && ! strcmp (((((arg)->decl.name))->identifier.pointer), "main"))

 pedwarn ("taking address of function `main'");


      if (((n64_enum_tree_code) (arg)->common.code) == INDIRECT_REF)
 {


   if (arg == C_C_D)
     return current_class_decl;



   arg = ((arg)->exp.operands[0]);
   if (((n64_enum_tree_code) (((arg)->common.type))->common.code) == REFERENCE_TYPE)
     {
       if (((n64_enum_tree_code) (arg)->common.code) == VAR_DECL && ((arg)->decl.initial)
    && !((((arg)->decl.initial))->common.side_effects_flag))
  arg = ((arg)->decl.initial);
       arg = build1 (CONVERT_EXPR, build_pointer_type (((((arg)->common.type))->common.type)), arg);
       (((arg)->common.lang_flag_3)) = 1;
       ((arg)->common.constant_flag) = ((((arg)->exp.operands[0]))->common.constant_flag);
     }
   else if (lvalue_p (arg))

     return non_lvalue (arg);
   return arg;
 }


      if (((n64_enum_tree_code) (arg)->common.code) == ARRAY_REF)
 {
   if (mark_addressable (((arg)->exp.operands[0])) == 0)
     return error_mark_node;
   return build_binary_op (PLUS_EXPR, ((arg)->exp.operands[0]),
      ((arg)->exp.operands[1]), 1);
 }





      if (((n64_enum_tree_code) (arg)->common.code) == IDENTIFIER_NODE
   && ((arg)->common.lang_flag_2))
 {
   my_friendly_abort (117);


   return build1 (ADDR_EXPR, unknown_type_node, arg);
 }

      if (((n64_enum_tree_code) (arg)->common.code) == TREE_LIST)
 {
   if (((n64_enum_tree_code) (((arg)->list.value))->common.code) == FUNCTION_DECL
       && (((((arg)->list.value))->decl.lang_specific)->chain) == (tree) 
                                          ((void *)0)
                                                   )

     return build_unary_op (ADDR_EXPR, ((arg)->list.value), 0);
   if (((arg)->common.chain) == (tree) 
                          ((void *)0)
       
      && ((n64_enum_tree_code) (((arg)->list.value))->common.code) == TREE_LIST
       && (((((((arg)->list.value))->list.value))->decl.lang_specific)->chain) == (tree) 
                                                       ((void *)0)
                                                                )

     return build_unary_op (ADDR_EXPR, ((((arg)->list.value))->list.value),
       0);
   return build1 (ADDR_EXPR, unknown_type_node, arg);
 }



      val = unary_complex_lvalue (code, arg);
      if (val != 0)
 return val;

      switch (((n64_enum_tree_code) (arg)->common.code))
 {
 case NOP_EXPR:
 case CONVERT_EXPR:
 case FLOAT_EXPR:
 case FIX_TRUNC_EXPR:
 case FIX_FLOOR_EXPR:
 case FIX_ROUND_EXPR:
 case FIX_CEIL_EXPR:
   if (! lvalue_p (arg) && pedantic)
     pedwarn ("taking the address of a cast to non-reference type");
 }



      if (((n64_enum_tree_code) (arg)->common.code) == CONSTRUCTOR && ((arg)->common.constant_flag))
 ;


      else if (((n64_enum_tree_code) (argtype)->common.code) != FUNCTION_TYPE
        && ((n64_enum_tree_code) (argtype)->common.code) != METHOD_TYPE
        && !lvalue_or_else (arg, "unary `&'"))
 return error_mark_node;




      if ((*tree_code_type[(int) (((n64_enum_tree_code) (arg)->common.code))]) == 'd'
   || (*tree_code_type[(int) (((n64_enum_tree_code) (arg)->common.code))]) == 'r')
 {
   if (((arg)->common.readonly_flag) || ((arg)->common.volatile_flag))
     argtype = cp_build_type_variant (argtype,
         ((arg)->common.readonly_flag),
         ((arg)->common.volatile_flag));
 }

      argtype = build_pointer_type (argtype);

      if (mark_addressable (arg) == 0)
 return error_mark_node;

      {
 tree addr;

 if (((n64_enum_tree_code) (arg)->common.code) == COMPONENT_REF)
   addr = build_component_addr (arg, argtype,
           "attempt to take address of bit-field structure member `%s'");
 else
   addr = build1 (code, argtype, arg);



 if (staticp (arg))
   ((addr)->common.constant_flag) = 1;
 return addr;
      }
    }

  if (!errstring)
    {
      if (argtype == 0)
 argtype = ((arg)->common.type);
      return fold (build1 (code, argtype, arg));
    }

  error (errstring);
  return error_mark_node;
}





static tree
convert_sequence(tree conversions, tree arg) asm("_convert_sequence");
static tree
convert_sequence(tree conversions, tree arg)
{
  switch (((n64_enum_tree_code) (conversions)->common.code))
    {
    case NOP_EXPR:
    case CONVERT_EXPR:
    case FLOAT_EXPR:
    case FIX_TRUNC_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_ROUND_EXPR:
    case FIX_CEIL_EXPR:
      return convert (((conversions)->common.type),
        convert_sequence (((conversions)->exp.operands[0]),
     arg));

    default:
      return arg;
    }
}







tree
unary_complex_lvalue(n64_enum_tree_code code, tree arg) asm("_unary_complex_lvalue");
tree
unary_complex_lvalue(n64_enum_tree_code code, tree arg)
{

  if (((n64_enum_tree_code) (arg)->common.code) == COMPOUND_EXPR)
    {
      tree real_result = build_unary_op (code, ((arg)->exp.operands[1]), 0);
      return build (COMPOUND_EXPR, ((real_result)->common.type),
      ((arg)->exp.operands[0]), real_result);
    }


  if (((n64_enum_tree_code) (arg)->common.code) == COND_EXPR)
    return rationalize_conditional_expr (code, arg);

  if (((n64_enum_tree_code) (arg)->common.code) == MODIFY_EXPR
      || ((n64_enum_tree_code) (arg)->common.code) == PREINCREMENT_EXPR
      || ((n64_enum_tree_code) (arg)->common.code) == PREDECREMENT_EXPR)
    return unary_complex_lvalue
      (code, build (COMPOUND_EXPR, ((((arg)->exp.operands[0]))->common.type),
      arg, ((arg)->exp.operands[0])));

  if (code != ADDR_EXPR)
    return 0;


  if (((n64_enum_tree_code) (arg)->common.code) == MODIFY_EXPR
      || ((n64_enum_tree_code) (arg)->common.code) == INIT_EXPR)
    {
      tree real_result = build_unary_op (code, ((arg)->exp.operands[0]), 0);
      return build (COMPOUND_EXPR, ((real_result)->common.type), arg, real_result);
    }

  if (((n64_enum_tree_code) (arg)->common.code) == WITH_CLEANUP_EXPR)
    {
      tree real_result = build_unary_op (code, ((arg)->exp.operands[0]), 0);
      real_result = build (WITH_CLEANUP_EXPR, ((real_result)->common.type),
      real_result, 0, ((arg)->exp.operands[2]));
      return real_result;
    }

  if (((n64_enum_tree_code) (((arg)->common.type))->common.code) == FUNCTION_TYPE
      || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == METHOD_TYPE
      || ((n64_enum_tree_code) (((arg)->common.type))->common.code) == OFFSET_TYPE)
    {



      tree t;
      tree offset;

      my_friendly_assert (((n64_enum_tree_code) (arg)->common.code) != SCOPE_REF, 313);

      if (((n64_enum_tree_code) (arg)->common.code) != CP_OFFSET_REF)
 return 0;

      t = ((arg)->exp.operands[1]);

      if (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL)
 return build_unary_op (ADDR_EXPR, t, 0);
      if (((n64_enum_tree_code) (t)->common.code) == VAR_DECL)
 return build_unary_op (ADDR_EXPR, t, 0);
      else
 {
   if (((arg)->exp.operands[0])
       && (((n64_enum_tree_code) (((arg)->exp.operands[0]))->common.code) != NOP_EXPR
    || ((((arg)->exp.operands[0]))->exp.operands[0]) != error_mark_node))
     if (((n64_enum_tree_code) (t)->common.code) != FIELD_DECL)
       {


  sorry ("address of bound pointer-to-member expression");
  return error_mark_node;
       }

   offset = get_delta_difference (((t)->decl.context),
      ((((arg)->exp.operands[0]))->common.type),
      0);
   offset = size_binop (PLUS_EXPR, offset,
          size_binop (TRUNC_DIV_EXPR,
        ((t)->decl.arguments),
        size_int (8)));
   return convert (build_pointer_type (((arg)->common.type)), offset);
 }
    }

  if (((n64_enum_tree_code) (arg)->common.code) == CP_OFFSET_REF)
    {
      tree left = ((arg)->exp.operands[0]), left_addr;
      tree right_addr = build_unary_op (ADDR_EXPR, ((arg)->exp.operands[1]), 0);

      if (left == 0)
 if (current_class_decl)
   left_addr = current_class_decl;
 else
   {
     error ("no `this' for pointer to member");
     return error_mark_node;
   }
      else
 left_addr = build_unary_op (ADDR_EXPR, left, 0);

      return build (PLUS_EXPR, build_pointer_type (((arg)->common.type)),
      build1 (NOP_EXPR, integer_type_node, left_addr),
      build1 (NOP_EXPR, integer_type_node, right_addr));
    }



  {
    tree targ = arg;

    if (((n64_enum_tree_code) (targ)->common.code) == SAVE_EXPR)
      targ = ((targ)->exp.operands[0]);

    if (((n64_enum_tree_code) (targ)->common.code) == CALL_EXPR && (((((targ)->common.type))->type.lang_flag_5)))
      {
 if (((n64_enum_tree_code) (arg)->common.code) == SAVE_EXPR)
   targ = arg;
 else
   targ = build_cplus_new (((arg)->common.type), arg, 1);
 return build1 (ADDR_EXPR, build_pointer_type (((arg)->common.type)), targ);
      }

    if (((n64_enum_tree_code) (arg)->common.code) == SAVE_EXPR && ((n64_enum_tree_code) (targ)->common.code) == INDIRECT_REF)
      return build (SAVE_EXPR, build_pointer_type (((arg)->common.type)),
       ((targ)->exp.operands[0]), current_function_decl, 
                                                     ((void *)0)
                                                         );



    if (((n64_enum_tree_code) (arg)->common.code) == SAVE_EXPR && ((n64_enum_tree_code) (targ)->common.code) == WITH_CLEANUP_EXPR)
      {




 return unary_complex_lvalue (ADDR_EXPR, targ);
      }
  }


  return 0;
}







int
mark_addressable(tree exp) asm("_mark_addressable");
int
mark_addressable(tree exp)
{
  register tree x = exp;

  if (((x)->common.addressable_flag) == 1)
    return 1;

  while (1)
    switch (((n64_enum_tree_code) (x)->common.code))
      {
      case ADDR_EXPR:
      case COMPONENT_REF:
      case ARRAY_REF:
 x = ((x)->exp.operands[0]);
 break;

      case PARM_DECL:
 if (x == current_class_decl)
   {
     error ("address of `this' not available");
     ((x)->common.addressable_flag) = 1;
     put_var_into_stack (x);
     return 1;
   }
      case VAR_DECL:
 if (((x)->common.static_flag)
     && ((x)->common.readonly_flag)
     && ((x)->decl.rtl) != 0
     && ! decl_in_memory_p (x))
   {


     push_obstacks_nochange ();
     end_temporary_allocation ();

     ((x)->common.asm_written_flag) = 0;
     ((x)->decl.rtl) = 0;
     rest_of_decl_compilation (x, 0, (((struct n64_tag_lang_identifier *)(x))->local_value) == 0, 0);
     ((x)->common.addressable_flag) = 1;

     pop_obstacks ();

     return 1;
   }


 my_friendly_assert (((x)->decl.lang_specific) == 0
       || (((x)->decl.lang_flag_3)) == 0
       || ((x)->common.static_flag)
       || ((x)->decl.external_flag), 314);

      case CONST_DECL:
      case RESULT_DECL:


 put_var_into_stack (x);
 ((x)->common.addressable_flag) = 1;
 return 1;

      case FUNCTION_DECL:



 x = (((x)->decl.lang_specific)->main_decl_variant);
 if (((((x)->decl.lang_specific)->decl_flags.declared_inline) || (((x)->decl.lang_specific)->pending_inline_info))
     && (((x)->decl.context) == (tree) 
                            ((void *)0)
  
 || (*tree_code_type[(int) (((n64_enum_tree_code) (((x)->decl.context))->common.code))]) != 't'
  || ! (((((x)->decl.context))->type.lang_specific)->type_flags.interface_only)))
   {
     mark_inline_for_output (x);
     if (x == current_function_decl)
       ((x)->decl.external_flag) = 0;
   }
 ((x)->common.addressable_flag) = 1;
 ((x)->common.used_flag) = 1;
 ((((x)->decl.assembler_name))->common.addressable_flag) = 1;
 if (asm_out_file)
   assemble_external (x);
 return 1;

      default:
 return 1;
    }
}



tree
build_x_conditional_expr(tree ifexp, tree op1, tree op2) asm("_build_x_conditional_expr");
tree
build_x_conditional_expr(tree ifexp, tree op1, tree op2)
{
  tree rval = (tree) 
             ((void *)0)
                      ;


  if (op1 != 0)
    rval = build_opfncall (COND_EXPR, (64), ifexp, op1, op2);
  if (rval)
    return build_opfncall (COND_EXPR, (3), ifexp, op1, op2);

  return build_conditional_expr (ifexp, op1, op2);
}

tree
build_conditional_expr(tree ifexp, tree op1, tree op2) asm("_build_conditional_expr");
tree
build_conditional_expr(tree ifexp, tree op1, tree op2)
{
  register tree type1;
  register tree type2;
  register n64_enum_tree_code code1;
  register n64_enum_tree_code code2;
  register tree result_type = (tree) 
                             ((void *)0)
                                      ;
  tree orig_op1 = op1, orig_op2 = op2;



  if (op1 == 0)
    {
      if (pedantic)
 pedwarn ("ANSI C++ forbids omitting the middle term of a ?: expression");
      ifexp = op1 = save_expr (ifexp);
    }

  ifexp = convert (boolean_type_node, ifexp);

  if (((n64_enum_tree_code) (ifexp)->common.code) == ERROR_MARK)
    return error_mark_node;

  op1 = require_instantiated_type (((op2)->common.type), op1, error_mark_node);
  if (op1 == error_mark_node)
    return error_mark_node;
  op2 = require_instantiated_type (((op1)->common.type), op2, error_mark_node);
  if (op2 == error_mark_node)
    return error_mark_node;


  type1 = ((op1)->common.type);
  code1 = ((n64_enum_tree_code) (type1)->common.code);
  type2 = ((op2)->common.type);
  code2 = ((n64_enum_tree_code) (type2)->common.code);

  if (code1 == REFERENCE_TYPE)
    {
      op1 = convert_from_reference (op1);
      type1 = ((op1)->common.type);
      code1 = ((n64_enum_tree_code) (type1)->common.code);
    }
  if (code2 == REFERENCE_TYPE)
    {
      op2 = convert_from_reference (op2);
      type2 = ((op2)->common.type);
      code2 = ((n64_enum_tree_code) (type2)->common.code);
    }






  if (((type1)->type.main_variant) == ((type2)->type.main_variant)
      && code2 != ARRAY_TYPE




      && code2 != FUNCTION_TYPE
      && code2 != METHOD_TYPE)
    {
      tree result;

      if (((ifexp)->common.constant_flag)
   && (((n64_enum_tree_code) (ifexp)->common.code) == INTEGER_CST
       || ((n64_enum_tree_code) (ifexp)->common.code) == ADDR_EXPR))
 return (integer_zerop (ifexp) ? op2 : op1);

      if (((n64_enum_tree_code) (op1)->common.code) == CONST_DECL)
 op1 = ((op1)->decl.initial);
      else if ((((op1)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (op1)->common.code))]) == 'd'))
 op1 = decl_constant_value (op1);
      if (((n64_enum_tree_code) (op2)->common.code) == CONST_DECL)
 op2 = ((op2)->decl.initial);
      else if ((((op2)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (op2)->common.code))]) == 'd'))
 op2 = decl_constant_value (op2);
      if (type1 != type2)
 type1 = cp_build_type_variant
   (type1,
    ((op1)->common.readonly_flag) || ((op2)->common.readonly_flag),
    ((op1)->common.volatile_flag) || ((op2)->common.volatile_flag));


      result = fold (build (COND_EXPR, type1, ifexp, op1, op2));
      if (((result)->common.type) != type1)
 result = build1 (NOP_EXPR, type1, result);
      return result;
    }




  if (code1 == ENUMERAL_TYPE)
    {
      if (code2 == ENUMERAL_TYPE)
 {
   cp_error ("enumeral mismatch in conditional expression: `%T' vs `%T'", type1, type2);
   return error_mark_node;
 }
      else if (extra_warnings && ! (code2 == RECORD_TYPE || code2 == UNION_TYPE || code2 == UNINSTANTIATED_P_TYPE)
        && type2 != type_promotes_to (type1))
 warning ("enumeral and non-enumeral type in conditional expression");
    }
  else if (extra_warnings
    && code2 == ENUMERAL_TYPE && ! (code1 == RECORD_TYPE || code1 == UNION_TYPE || code1 == UNINSTANTIATED_P_TYPE)
    && type1 != type_promotes_to (type2))
    warning ("enumeral and non-enumeral type in conditional expression");

  if (code1 != VOID_TYPE)
    {
      op1 = default_conversion (op1);
      type1 = ((op1)->common.type);
      if ((((n64_enum_tree_code) (type1)->common.code) == RECORD_TYPE && ((type1)->type.lang_specific)->type_flags.ptrmemfunc_flag))
 type1 = (((((((((((((type1)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      code1 = ((n64_enum_tree_code) (type1)->common.code);
    }
  if (code2 != VOID_TYPE)
    {
      op2 = default_conversion (op2);
      type2 = ((op2)->common.type);
      if ((((n64_enum_tree_code) (type2)->common.code) == RECORD_TYPE && ((type2)->type.lang_specific)->type_flags.ptrmemfunc_flag))
 type2 = (((((((((((((type2)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      code2 = ((n64_enum_tree_code) (type2)->common.code);
    }

  if (code1 == RECORD_TYPE && code2 == RECORD_TYPE
      && real_lvalue_p (op1) && real_lvalue_p (op2)
      && comptypes (type1, type2, -1))
    {
      type1 = build_reference_type (type1);
      type2 = build_reference_type (type2);
      result_type = common_type (type1, type2);
      op1 = convert_to_reference (result_type, op1, 1,
      (3), (tree) 
                    ((void *)0)
                             );
      op2 = convert_to_reference (result_type, op2, 1,
      (3), (tree) 
                    ((void *)0)
                             );
    }


  else if (((type1)->type.main_variant) == ((type2)->type.main_variant))
    {
      if (type1 == type2)
 result_type = type1;
      else
 result_type = cp_build_type_variant
   (type1,
    ((op1)->common.readonly_flag) || ((op2)->common.readonly_flag),
    ((op1)->common.volatile_flag) || ((op2)->common.volatile_flag));
    }
  else if ((code1 == INTEGER_TYPE || code1 == REAL_TYPE)
           && (code2 == INTEGER_TYPE || code2 == REAL_TYPE))
    {
      result_type = common_type (type1, type2);
    }
  else if (code1 == VOID_TYPE || code2 == VOID_TYPE)
    {
      if (pedantic && (code1 != VOID_TYPE || code2 != VOID_TYPE))
 pedwarn ("ANSI C++ forbids conditional expr with only one void side");
      result_type = void_type_node;
    }
  else if (code1 == POINTER_TYPE && code2 == POINTER_TYPE)
    {
      if (comp_target_types (type1, type2, 1))
 result_type = common_type (type1, type2);
      else if (integer_zerop (op1) && ((type1)->common.type) == void_type_node
        && ((n64_enum_tree_code) (orig_op1)->common.code) != NOP_EXPR)
 result_type = qualify_type (type2, type1);
      else if (integer_zerop (op2) && ((type2)->common.type) == void_type_node
        && ((n64_enum_tree_code) (orig_op2)->common.code) != NOP_EXPR)
 result_type = qualify_type (type1, type2);
      else if (((((type1)->common.type))->type.main_variant) == void_type_node)
 {
   if (pedantic && ((n64_enum_tree_code) (type2)->common.code) == FUNCTION_TYPE)
     pedwarn ("ANSI C++ forbids conditional expr between `void *' and function pointer");
   result_type = qualify_type (type1, type2);
 }
      else if (((((type2)->common.type))->type.main_variant) == void_type_node)
 {
   if (pedantic && ((n64_enum_tree_code) (type1)->common.code) == FUNCTION_TYPE)
     pedwarn ("ANSI C++ forbids conditional expr between `void *' and function pointer");
   result_type = qualify_type (type2, type1);
 }

      else if (comptypes (type2, type1, 0))
 result_type = type2;
      else if ((((((type1)->common.type))->type.lang_flag_5))
        && (((((type2)->common.type))->type.lang_flag_5))
        && (result_type = common_base_type (((type1)->common.type), ((type2)->common.type))))
 {
   if (result_type == error_mark_node)
     {
       cp_error ("common base type of types `%T' and `%T' is ambiguous",
   ((type1)->common.type), ((type2)->common.type));
       result_type = ptr_type_node;
     }
   else
     {
       if (pedantic
    && result_type != ((type1)->common.type)
    && result_type != ((type2)->common.type))
  cp_pedwarn ("`%T' and `%T' converted to `%T *' in conditional expression",
       type1, type2, result_type);

       result_type = build_pointer_type (result_type);
     }
 }
      else
 {
   pedwarn ("pointer type mismatch in conditional expression");
   result_type = ptr_type_node;
 }
    }
  else if (code1 == POINTER_TYPE && code2 == INTEGER_TYPE)
    {
      if (!integer_zerop (op2))
 pedwarn ("pointer/integer type mismatch in conditional expression");
      else
 {
   op2 = null_pointer_node;




 }
      result_type = type1;
    }
  else if (code2 == POINTER_TYPE && code1 == INTEGER_TYPE)
    {
      if (!integer_zerop (op1))
 pedwarn ("pointer/integer type mismatch in conditional expression");
      else
 {
   op1 = null_pointer_node;




 }
      result_type = type2;
    }

  if (!result_type)
    {


      if (code1 == RECORD_TYPE && code2 == RECORD_TYPE)
 {
   cp_error ("aggregate mismatch in conditional expression: `%T' vs `%T'", type1, type2);
   return error_mark_node;
 }
      if (code1 == RECORD_TYPE && (((type1)->type.lang_specific)->type_flags.has_type_conversion))
 {
   tree tmp = build_type_conversion (CONVERT_EXPR, type2, op1, 0);
   if (tmp == (tree) 
             ((void *)0)
                      )
     {
       cp_error ("aggregate type `%T' could not convert on lhs of `:'", type1);
       return error_mark_node;
     }
   if (tmp == error_mark_node)
     error ("ambiguous pointer conversion");
   result_type = type2;
   op1 = tmp;
 }
      else if (code2 == RECORD_TYPE && (((type2)->type.lang_specific)->type_flags.has_type_conversion))
 {
   tree tmp = build_type_conversion (CONVERT_EXPR, type1, op2, 0);
   if (tmp == (tree) 
             ((void *)0)
                      )
     {
       cp_error ("aggregate type `%T' could not convert on rhs of `:'", type2);
       return error_mark_node;
     }
   if (tmp == error_mark_node)
     error ("ambiguous pointer conversion");
   result_type = type1;
   op2 = tmp;
 }
      else if (flag_cond_mismatch)
 result_type = void_type_node;
      else
 {
   error ("type mismatch in conditional expression");
   return error_mark_node;
 }
    }

  if (((n64_enum_tree_code) (result_type)->common.code) == POINTER_TYPE
      && ((n64_enum_tree_code) (((result_type)->common.type))->common.code) == METHOD_TYPE)
    result_type = build_ptrmemfunc_type (result_type);

  if (result_type != ((op1)->common.type))
    op1 = convert_and_check (result_type, op1);
  if (result_type != ((op2)->common.type))
    op2 = convert_and_check (result_type, op2);
  if (((ifexp)->common.constant_flag))
    return integer_zerop (ifexp) ? op2 : op1;

  return convert_from_reference
    (fold (build (COND_EXPR, result_type, ifexp, op1, op2)));
}



tree
build_x_compound_expr(tree list) asm("_build_x_compound_expr");
tree
build_x_compound_expr(tree list)
{
  tree rest = ((list)->common.chain);
  tree result;

  if (rest == (tree) 
             ((void *)0)
                      )
    return build_compound_expr (list);

  result = build_opfncall (COMPOUND_EXPR, (3),
      ((list)->list.value), ((rest)->list.value), (tree) 
                                           ((void *)0)
                                                    );
  if (result)
    return build_x_compound_expr (tree_cons ((tree) 
                                            ((void *)0)
                                                     , result, ((rest)->common.chain)));

  if (! ((((list)->list.value))->common.side_effects_flag))
    {



      if ((extra_warnings || warn_unused)
           && !(((n64_enum_tree_code) (((list)->list.value))->common.code) == CONVERT_EXPR
                && ((((list)->list.value))->common.type) == void_type_node))
        warning("left-hand operand of comma expression has no effect");
    }





  return build_compound_expr (tree_cons ((tree) 
                                        ((void *)0)
                                                 , ((list)->list.value),
      build_tree_list ((tree) 
                      ((void *)0)
                               , build_x_compound_expr (rest))));
}




tree
build_compound_expr(tree list) asm("_build_compound_expr");
tree
build_compound_expr(tree list)
{
  register tree rest;

  if ((((((list)->list.value))->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (((list)->list.value))->common.code))]) == 'd'))
    ((list)->list.value) = decl_constant_value (((list)->list.value));

  if (((list)->common.chain) == 0)
    {


      if (((n64_enum_tree_code) (list)->common.code) == NOP_EXPR
   && ((list)->common.type) == ((((list)->exp.operands[0]))->common.type))
 list = ((list)->exp.operands[0]);


      if (((n64_enum_tree_code) (((((list)->list.value))->common.type))->common.code) == ARRAY_TYPE)
 return default_conversion (((list)->list.value));
      else
 return ((list)->list.value);
    }

  rest = build_compound_expr (((list)->common.chain));


  if (! ((((list)->list.value))->common.side_effects_flag) && ! pedantic)
    return rest;

  return build (COMPOUND_EXPR, ((rest)->common.type),
  break_out_cleanups (((list)->list.value)), rest);
}




int
null_ptr_cst_p(tree t) asm("_null_ptr_cst_p");
int
null_ptr_cst_p(tree t)
{
  return (((n64_enum_tree_code) (t)->common.code) == INTEGER_CST && integer_zerop (t));
}

tree build_static_cast(tree type, tree expr) asm("_build_static_cast");
tree build_static_cast(tree type, tree expr)
{
  return build_c_cast (type, expr, 0);
}

tree build_reinterpret_cast(tree type, tree expr) asm("_build_reinterpret_cast");
tree build_reinterpret_cast(tree type, tree expr)
{
  tree intype = ((expr)->common.type);

  if ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    type = (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
  if ((((n64_enum_tree_code) (intype)->common.code) == RECORD_TYPE && ((intype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    intype = (((((((((((((intype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

  if (! (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE) && ! ((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE)
    {
      cp_error ("reinterpret_cast cannot convert to type `%T'", type);
      return error_mark_node;
    }
  if (! (((n64_enum_tree_code) (intype)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (intype)->common.code) == REFERENCE_TYPE) && ! ((n64_enum_tree_code) (intype)->common.code) == INTEGER_TYPE)
    {
      cp_error ("reinterpret_cast cannot convert from type `%T'", type);
      return error_mark_node;
    }
  if (((n64_enum_tree_code) (type)->common.code) == INTEGER_TYPE && ((n64_enum_tree_code) (intype)->common.code) != POINTER_TYPE)
    {
      cp_error ("reinterpret_cast cannot convert non-pointer type `%T' to `%T'",
  intype, type);
      return error_mark_node;
    }
  if (((n64_enum_tree_code) (intype)->common.code) == INTEGER_TYPE && ((n64_enum_tree_code) (type)->common.code) != POINTER_TYPE)
    {
      cp_error ("reinterpret_cast cannot convert `%T' to non-pointer type `%T'",
  intype, type);
      return error_mark_node;
    }

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE && ((n64_enum_tree_code) (intype)->common.code) == POINTER_TYPE)
    expr = convert (ptr_type_node, expr);

  return build_c_cast (type, expr, 0);
}

tree build_const_cast(tree type, tree expr) asm("_build_const_cast");
tree build_const_cast(tree type, tree expr)
{
  tree intype = ((expr)->common.type);
  tree t1, t2;

  if (type == error_mark_node || expr == error_mark_node)
    return error_mark_node;

  if ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    type = (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
  if ((((n64_enum_tree_code) (intype)->common.code) == RECORD_TYPE && ((intype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    intype = (((((((((((((intype)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));

  if (! (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE || ((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE))
    {
      cp_error ("const_cast cannot convert to non-pointer type `%T'", type);
      return error_mark_node;
    }
  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE && ! real_lvalue_p (expr))
    {
      cp_error ("const_cast cannot convert rvalue to type `%T'", type);
      return error_mark_node;
    }
  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE && ((n64_enum_tree_code) (intype)->common.code) != POINTER_TYPE)
    {
      cp_error ("const_cast cannot convert non-pointer type `%T' to type `%T'",
  intype, type);
      return error_mark_node;
    }

  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    {
      t1 = ((type)->common.type);
      t2 = intype;
    }
  else
    {
      t1 = ((type)->common.type);
      t2 = ((intype)->common.type);

      for (; ((n64_enum_tree_code) (t1)->common.code) == POINTER_TYPE && ((n64_enum_tree_code) (t2)->common.code) == POINTER_TYPE;
    t1 = ((t1)->common.type), t2 = ((t2)->common.type))
 ;
    }

  if (((n64_enum_tree_code) (t1)->common.code) == OFFSET_TYPE && ((n64_enum_tree_code) (t2)->common.code) == OFFSET_TYPE)
    {
      if (((t1)->type.maxval) != ((t2)->type.maxval))
 {
   cp_error ("const_cast cannot convert between pointers to members of different types `%T' and `%T'",
      ((t2)->type.maxval), ((t1)->type.maxval));
   return error_mark_node;
 }
      t1 = ((t1)->common.type);
      t2 = ((t2)->common.type);
    }

  if (((t1)->type.main_variant) != ((t2)->type.main_variant))
    {
      cp_error ("const_cast cannot convert unrelated type `%T' to `%T'",
  t2, t1);
      return error_mark_node;
    }

  return build_c_cast (type, expr, 0);
}






tree
build_c_cast(register tree type, tree expr, int allow_nonconverting) asm("_build_c_cast");
tree
build_c_cast(register tree type, tree expr, int allow_nonconverting)
{
  register tree value = expr;

  if (type == error_mark_node || expr == error_mark_node)
    return error_mark_node;



  if (((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE
      && ((n64_enum_tree_code) (value)->common.code) == NOP_EXPR
      && ((value)->common.type) == ((((value)->exp.operands[0]))->common.type))
    value = ((value)->exp.operands[0]);

  if (((expr)->common.type)
      && ((n64_enum_tree_code) (((expr)->common.type))->common.code) == OFFSET_TYPE
      && ((n64_enum_tree_code) (type)->common.code) != OFFSET_TYPE)
    value = resolve_offset_ref (value);

  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {



      if (((n64_enum_tree_code) (((expr)->common.type))->common.code) == POINTER_TYPE)
 {
   if (pedantic)
     pedwarn ("ANSI C++ forbids casting to an array type");
   type = build_pointer_type (((type)->common.type));
 }
      else
 {
   error ("ANSI C++ forbids casting to an array type");
   return error_mark_node;
 }
    }

  if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
    {
      cp_error ("casting to function type `%T'", type);
      return error_mark_node;
    }

  if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("cast specifies signature type");
      return error_mark_node;
    }



  if (((n64_enum_tree_code) (value)->common.code) == TREE_LIST
      && ((value)->common.chain) == (tree) 
                              ((void *)0)
                                       )
    value = ((value)->list.value);

  if (((n64_enum_tree_code) (type)->common.code) == VOID_TYPE)
    value = build1 (CONVERT_EXPR, type, value);
  else if (((value)->common.type) == (tree) 
                               ((void *)0)
      
     || type_unknown_p (value))
    {
      value = instantiate_type (type, value, 1);

      if (value == error_mark_node)
 return error_mark_node;
    }
  else
    {
      tree otype;
      int flag;




      if (((n64_enum_tree_code) (((value)->common.type))->common.code) == FUNCTION_TYPE
   || ((n64_enum_tree_code) (((value)->common.type))->common.code) == METHOD_TYPE
   || ((n64_enum_tree_code) (((value)->common.type))->common.code) == ARRAY_TYPE
   || ((n64_enum_tree_code) (((value)->common.type))->common.code) == REFERENCE_TYPE)
 value = default_conversion (value);
      otype = ((value)->common.type);



      if (warn_cast_qual
   && ((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == POINTER_TYPE)
 {


   if (((((otype)->common.type))->common.volatile_flag)
       && ! ((((type)->common.type))->common.volatile_flag))
     warning ("cast discards `volatile' from pointer target type");
   if (((((otype)->common.type))->common.readonly_flag)
       && ! ((((type)->common.type))->common.readonly_flag))
     warning ("cast discards `const' from pointer target type");
 }


      if (1 && warn_cast_align
   && ((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (otype)->common.code) == POINTER_TYPE
   && ((n64_enum_tree_code) (((otype)->common.type))->common.code) != VOID_TYPE
   && ((n64_enum_tree_code) (((otype)->common.type))->common.code) != FUNCTION_TYPE
   && ((((type)->common.type))->type.align) > ((((otype)->common.type))->type.align))
 warning ("cast increases required alignment of target type");
      flag = allow_nonconverting ? 32 : 0;

      if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
 value = (convert_from_reference
   (convert_to_reference (type, value, (1 | 2 | 4 | 8)|flag,
     (2), (tree) 
                     ((void *)0)
                              )));
      else
 {
   tree ovalue;

   if ((((value)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (value)->common.code))]) == 'd'))
     value = decl_constant_value (value);

   ovalue = value;
   value = convert_force (type, value, flag);


   if (((n64_enum_tree_code) (value)->common.code) == INTEGER_CST)
     {
       ((value)->common.public_flag) = ((ovalue)->common.public_flag);
       ((value)->common.static_flag) = ((ovalue)->common.static_flag);
     }
 }
    }





  if (((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE
      && (value == expr
   || (pedantic
       && ((n64_enum_tree_code) (value)->common.code) == INTEGER_CST
       && ((n64_enum_tree_code) (expr)->common.code) == INTEGER_CST
       && ((n64_enum_tree_code) (((expr)->common.type))->common.code) != INTEGER_TYPE)))
    value = non_lvalue (value);

  return value;
}
static tree
init_noncopied_parts(tree lhs, tree list) asm("_init_noncopied_parts");
static tree
init_noncopied_parts(tree lhs, tree list)
{
  tree tail;
  tree parts = 0;

  for (tail = list; tail; tail = ((tail)->common.chain))
    if (((n64_enum_tree_code) (((tail)->list.value))->common.code) == TREE_LIST)
      parts = chainon (parts, init_noncopied_parts (lhs, ((tail)->list.value)));
    else
      {
 tree part = ((tail)->list.value);
 tree part_type = ((part)->common.type);
 tree to_be_initialized = build (COMPONENT_REF, part_type, lhs, part);
 parts = tree_cons (((tail)->list.purpose), to_be_initialized, parts);
      }
  return parts;
}

tree
expand_target_expr(tree t) asm("_expand_target_expr");
tree
expand_target_expr(tree t)
{
  tree xval = make_node (RTL_EXPR);
  rtx rtxval;

  do_pending_stack_adjust ();
  start_sequence_for_rtl_expr (xval);
  emit_note (0, -1);
  rtxval = expand_expr (t, 
                          ((void *)0)
                              , VOIDmode, 0);
  do_pending_stack_adjust ();
  ((xval)->common.side_effects_flag) = 1;
  (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[0]) = get_insns ();
  end_sequence ();
  (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[1]) = rtxval;
  ((xval)->common.type) = ((t)->common.type);
  return xval;
}
tree
build_modify_expr(tree lhs, n64_enum_tree_code modifycode, tree rhs) asm("_build_modify_expr");
tree
build_modify_expr(tree lhs, n64_enum_tree_code modifycode, tree rhs)
{
  register tree result;
  tree newrhs = rhs;
  tree lhstype = ((lhs)->common.type);
  tree olhstype = lhstype;
  tree olhs = lhs;


  if (((n64_enum_tree_code) (lhs)->common.code) == ERROR_MARK || ((n64_enum_tree_code) (rhs)->common.code) == ERROR_MARK)
    return error_mark_node;


  lhs = require_complete_type (lhs);



  if (type_needs_gc_entry (((rhs)->common.type))
      && ! value_safe_from_gc (lhs, rhs))
    rhs = protect_value_from_gc (lhs, rhs);

  newrhs = rhs;



  if (((lhstype)->type.lang_specific) &&
      ((((lhstype)->type.lang_specific)->type_flags.is_signature_pointer) || (((lhstype)->type.lang_specific)->type_flags.is_signature_reference)))
    {
      return build_signature_pointer_constructor (lhs, rhs);
    }



  switch (((n64_enum_tree_code) (lhs)->common.code))
    {

    case PREDECREMENT_EXPR:
    case PREINCREMENT_EXPR:
      if (((((lhs)->exp.operands[0]))->common.side_effects_flag))
 lhs = build (((n64_enum_tree_code) (lhs)->common.code), ((lhs)->common.type),
       stabilize_reference (((lhs)->exp.operands[0])));
      return build (COMPOUND_EXPR, lhstype,
      lhs,
      build_modify_expr (((lhs)->exp.operands[0]),
           modifycode, rhs));


    case COMPOUND_EXPR:
      newrhs = build_modify_expr (((lhs)->exp.operands[1]),
      modifycode, rhs);
      if (((n64_enum_tree_code) (newrhs)->common.code) == ERROR_MARK)
 return error_mark_node;
      return build (COMPOUND_EXPR, lhstype,
      ((lhs)->exp.operands[0]), newrhs);

    case MODIFY_EXPR:
      newrhs = build_modify_expr (((lhs)->exp.operands[0]), modifycode, rhs);
      if (((n64_enum_tree_code) (newrhs)->common.code) == ERROR_MARK)
 return error_mark_node;
      return build (COMPOUND_EXPR, lhstype, lhs, newrhs);


    case COND_EXPR:
      rhs = save_expr (rhs);
      {



 tree cond
   = build_conditional_expr (((lhs)->exp.operands[0]),
        build_modify_expr (convert (((lhs)->common.type), ((lhs)->exp.operands[1])),
             modifycode, rhs),
        build_modify_expr (convert (((lhs)->common.type), ((lhs)->exp.operands[2])),
             modifycode, rhs));
 if (((n64_enum_tree_code) (cond)->common.code) == ERROR_MARK)
   return cond;


 return build (COMPOUND_EXPR, ((lhs)->common.type),


        convert (void_type_node, rhs), cond);
      }
    }

  if (((n64_enum_tree_code) (lhs)->common.code) == CP_OFFSET_REF)
    {
      if (((lhs)->exp.operands[0]) == (tree) 
                                  ((void *)0)
                                           )
 {

   tree member = ((lhs)->exp.operands[1]);
   if (((n64_enum_tree_code) (member)->common.code) == VAR_DECL)
     lhs = member;
   else
     {
       compiler_error ("invalid static class member");
       return error_mark_node;
     }
 }
      else
 lhs = resolve_offset_ref (lhs);

      olhstype = lhstype = ((lhs)->common.type);
    }

  if (((n64_enum_tree_code) (lhstype)->common.code) == REFERENCE_TYPE
      && modifycode != INIT_EXPR)
    {
      lhs = convert_from_reference (lhs);
      olhstype = lhstype = ((lhs)->common.type);
    }




  if (modifycode == INIT_EXPR)
    {
      if (! (((lhstype)->type.lang_flag_5)))
                           ;
      else if (! (((lhstype)->type.lang_flag_1)))
 {
   cp_error ("`%T' has no constructors", lhstype);
   return error_mark_node;
 }
      else if (((((lhstype)->type.lang_specific)->type_flags.has_init_ref) && ! (((lhstype)->type.lang_specific)->type_flags.has_complex_init_ref))
        && ((lhstype)->type.main_variant) == ((((newrhs)->common.type))->type.main_variant))
                           ;
      else
 {
   result = build_method_call (lhs, constructor_name_full (lhstype),
          build_tree_list ((tree) 
                          ((void *)0)
                                   , rhs),
          (tree) 
         ((void *)0)
                  , (3));
   if (result == (tree) 
                ((void *)0)
                         )
     return error_mark_node;
   return result;
 }
    }
  else if (modifycode == NOP_EXPR)
    {


      if (! (((lhstype)->type.lang_flag_5)))
                           ;
      else if (! (((lhstype)->type.lang_specific)->type_flags.has_assignment))
 {
   cp_error ("`%T' does not define operator=", lhstype);
   return error_mark_node;
 }
      else if (((((lhstype)->type.lang_specific)->type_flags.has_assign_ref) && ! (((lhstype)->type.lang_specific)->type_flags.has_complex_assign_ref))
        && ((lhstype)->type.main_variant) == ((((newrhs)->common.type))->type.main_variant))
 {
   if (warn_synth)

     build_opfncall (MODIFY_EXPR, (3),
       lhs, rhs, make_node (NOP_EXPR));

                             ;
 }
      else
 {
   result = build_opfncall (MODIFY_EXPR, (3),
       lhs, rhs, make_node (NOP_EXPR));
   if (result == (tree) 
                ((void *)0)
                         )
     return error_mark_node;
   return result;
 }
      lhstype = olhstype;
    }
  else if ((((REFERENCE_TYPE) == ((n64_enum_tree_code) (lhstype)->common.code) && (((((lhstype)->common.type))->type.lang_flag_5))) || (((lhstype)->type.lang_flag_5))))
    {


      tree lhs_tmp = lhs;
      tree rhs_tmp = rhs;
      if (build_default_binary_type_conversion (modifycode, &lhs_tmp, &rhs_tmp))
 {
   lhs = stabilize_reference (lhs_tmp);

   olhstype = lhstype = ((lhs)->common.type);
   newrhs = build_binary_op (modifycode, lhs, rhs_tmp, 1);
 }
      else
 {
   cp_error ("no match for `%O(%#T, %#T)'", modifycode,
      ((lhs)->common.type), ((rhs)->common.type));
   return error_mark_node;
 }
    }
  else
    {
      lhs = stabilize_reference (lhs);
      newrhs = build_binary_op (modifycode, lhs, rhs, 1);
    }
  switch (((n64_enum_tree_code) (lhs)->common.code))
    {
    case NOP_EXPR:
    case CONVERT_EXPR:
    case FLOAT_EXPR:
    case FIX_TRUNC_EXPR:
    case FIX_FLOOR_EXPR:
    case FIX_ROUND_EXPR:
    case FIX_CEIL_EXPR:
      if (((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == ARRAY_TYPE
   || ((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == FUNCTION_TYPE
   || ((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == METHOD_TYPE
   || ((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == OFFSET_TYPE)
 newrhs = default_conversion (newrhs);
      {
 tree inner_lhs = ((lhs)->exp.operands[0]);
 tree result;
 if (! lvalue_p (lhs) && pedantic)
   pedwarn ("cast to non-reference type used as lvalue");

 result = build_modify_expr (inner_lhs, NOP_EXPR,
        convert (((inner_lhs)->common.type),
          convert (lhstype, newrhs)));
 if (((n64_enum_tree_code) (result)->common.code) == ERROR_MARK)
   return result;
 return convert (((lhs)->common.type), result);
      }
    }




  if (!lvalue_or_else (lhs, "assignment"))
    return error_mark_node;

  GNU_xref_assign (lhs);



  if (modifycode != INIT_EXPR


      && ! (((n64_enum_tree_code) (lhs)->common.code) == COMPONENT_REF
     && ((((((((lhs)->exp.operands[0]))->common.type))->type.lang_specific)->type_flags.is_signature_pointer)
  || (((((((lhs)->exp.operands[0]))->common.type))->type.lang_specific)->type_flags.is_signature_reference)))
      && (((lhs)->common.readonly_flag) || ((lhstype)->common.readonly_flag)
   || ((((n64_enum_tree_code) (lhstype)->common.code) == RECORD_TYPE
        || ((n64_enum_tree_code) (lhstype)->common.code) == UNION_TYPE)
       && ((lhstype)->type.lang_flag_0))
   || (((n64_enum_tree_code) (lhstype)->common.code) == REFERENCE_TYPE
       && ((((lhstype)->common.type))->common.readonly_flag))))
    readonly_error (lhs, "assignment", 0);






  if (((n64_enum_tree_code) (lhs)->common.code) == COMPONENT_REF
      && (((n64_enum_tree_code) (lhstype)->common.code) == INTEGER_TYPE
   || ((n64_enum_tree_code) (lhstype)->common.code) == REAL_TYPE
   || ((n64_enum_tree_code) (lhstype)->common.code) == ENUMERAL_TYPE))
    {
      lhstype = ((get_unwidened (lhs, 0))->common.type);




      if (lhstype != ((lhs)->common.type))
 {
   lhs = copy_node (lhs);
   ((lhs)->common.type) = lhstype;
 }
    }


  if (lhs == current_class_decl)
    {
      if (flag_this_is_variable > 0
   && ((current_function_decl)->decl.name) != (tree) 
                                          ((void *)0)
   
  && (((current_function_decl)->decl.name)
       != constructor_name (current_class_type)))
 warning ("assignment to `this' not in constructor or destructor");
      current_function_just_assigned_this = 1;
    }




  rhs = require_instantiated_type (lhstype, newrhs, error_mark_node);
  if (rhs == error_mark_node)
    return error_mark_node;
  newrhs = rhs;

  if (modifycode != INIT_EXPR)
    {

      modifycode = NOP_EXPR;

      if (((n64_enum_tree_code) (lhstype)->common.code) == REFERENCE_TYPE)
 {
   tree tmp = convert_from_reference (lhs);
   lhstype = ((tmp)->common.type);
   if (((lhstype)->type.size) == 0)
     {
       incomplete_type_error (lhs, lhstype);
       return error_mark_node;
     }
   lhs = tmp;
   olhstype = lhstype;
 }
      if (((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == REFERENCE_TYPE)
 {
   tree tmp = convert_from_reference (newrhs);
   if (((((tmp)->common.type))->type.size) == 0)
     {
       incomplete_type_error (newrhs, ((tmp)->common.type));
       return error_mark_node;
     }
   newrhs = tmp;
 }
    }

  if (((lhs)->common.side_effects_flag))
    lhs = stabilize_reference (lhs);
  if (((newrhs)->common.side_effects_flag))
    newrhs = stabilize_reference (newrhs);
  if (((n64_enum_tree_code) (lhstype)->common.code) == ARRAY_TYPE)
    {
      int from_array;

      if (! comptypes (lhstype, ((rhs)->common.type), 0))
 {
   cp_error ("incompatible types in assignment of `%T' to `%T'",
      ((rhs)->common.type), lhstype);
   return error_mark_node;
 }


      if (pedantic && ! ((current_function_decl)->decl.artificial_flag))
 pedwarn ("ANSI C++ forbids assignment of arrays");






      result = make_node (RTL_EXPR);

      ((result)->common.type) = void_type_node;
      do_pending_stack_adjust ();
      start_sequence_for_rtl_expr (result);


      emit_note (0, -1);

      from_array = ((n64_enum_tree_code) (((newrhs)->common.type))->common.code) == ARRAY_TYPE
            ? 1 + (modifycode != INIT_EXPR): 0;
      expand_vec_init (lhs, lhs, array_type_nelts (lhstype), newrhs,
         from_array);

      do_pending_stack_adjust ();

      ((result)->common.side_effects_flag) = 1;
      (*(struct n64_tag_rtx_def **) &(result)->exp.operands[0]) = get_insns ();
      (*(struct n64_tag_rtx_def **) &(result)->exp.operands[1]) = const0_rtx;
      end_sequence ();
      return result;
    }

  if (modifycode == INIT_EXPR)
    {
      newrhs = convert_for_initialization (lhs, lhstype, newrhs, (3),
        "assignment", (tree) 
                     ((void *)0)
                              , 0);
      if (lhs == ((current_function_decl)->decl.result))
 {
   if (((lhs)->decl.initial))
     warning ("return value from function receives multiple initializations");
   ((lhs)->decl.initial) = newrhs;
 }
    }
  else
    {
      if (((n64_enum_tree_code) (olhstype)->common.code) == ENUMERAL_TYPE
   && ((n64_enum_tree_code) (lhstype)->common.code) == INTEGER_TYPE)
 {
   newrhs = convert_for_assignment (olhstype, newrhs, "assignment",
        (tree) 
       ((void *)0)
                , 0);
   newrhs = convert_force (lhstype, newrhs, 0);
 }
      else
 newrhs = convert_for_assignment (lhstype, newrhs, "assignment",
      (tree) 
     ((void *)0)
              , 0);
      if (((n64_enum_tree_code) (newrhs)->common.code) == CALL_EXPR
   && ((lhstype)->type.needs_constructing_flag))
 newrhs = build_cplus_new (lhstype, newrhs, 0);





      if (((n64_enum_tree_code) (newrhs)->common.code) == TARGET_EXPR)
 newrhs = expand_target_expr (newrhs);
    }

  if (((n64_enum_tree_code) (newrhs)->common.code) == ERROR_MARK)
    return error_mark_node;

  if (((n64_enum_tree_code) (newrhs)->common.code) == COND_EXPR)
    {
      tree lhs1;
      tree cond = ((newrhs)->exp.operands[0]);

      if (((lhs)->common.side_effects_flag))
 cond = build_compound_expr (tree_cons
        ((tree) 
        ((void *)0)
                 , lhs,
         build_tree_list ((tree) 
                         ((void *)0)
                                  , cond)));





      lhs1 = break_out_calls (lhs);

      if (lhs == lhs1)

 result = build (modifycode == NOP_EXPR ? MODIFY_EXPR : INIT_EXPR,
   lhstype, lhs, newrhs);
      else
 {
   tree result_type = ((newrhs)->common.type);


   result
     = build (COND_EXPR, result_type, cond,
       build_modify_expr (lhs, modifycode,
     convert (result_type,
       ((newrhs)->exp.operands[1]))),
       build_modify_expr (lhs1, modifycode,
     convert (result_type,
       ((newrhs)->exp.operands[2]))));
 }
    }
  else if (modifycode != INIT_EXPR && ((n64_enum_tree_code) (newrhs)->common.code) == WITH_CLEANUP_EXPR)
    {
      tree cleanup = ((newrhs)->exp.operands[2]);
      tree slot;


      tree exprlist = tree_cons ((tree) 
                                ((void *)0)
                                         , cleanup,
     build_tree_list ((tree) 
                     ((void *)0)
                              , lhs));
      newrhs = ((newrhs)->exp.operands[0]);
      if (((n64_enum_tree_code) (newrhs)->common.code) == TARGET_EXPR)
   slot = ((newrhs)->exp.operands[0]);
      else if (((n64_enum_tree_code) (newrhs)->common.code) == ADDR_EXPR)
 {

   slot = newrhs;
   warning ("address taken of temporary object");
 }
      else
 my_friendly_abort (118);


      exprlist = tree_cons ((tree) 
                           ((void *)0)
                                    ,
       build_modify_expr (lhs, modifycode, slot),
       exprlist);


      exprlist = tree_cons ((tree) 
                           ((void *)0)
                                    , newrhs, exprlist);
      result = convert (lhstype, build_compound_expr (exprlist));
    }
  else
    result = build (modifycode == NOP_EXPR ? MODIFY_EXPR : INIT_EXPR,
      lhstype, lhs, newrhs);
  ((result)->common.side_effects_flag) = 1;






  if (olhstype == ((result)->common.type))
    return result;


  if (((n64_enum_tree_code) (((result)->common.type))->common.code) == INTEGER_TYPE
      && ((n64_enum_tree_code) (olhstype)->common.code) == ENUMERAL_TYPE)
    {
      result = build (COMPOUND_EXPR, olhstype, result, olhs);
      ((result)->common.static_flag) = 1;
      return result;
    }
  return convert_for_assignment (olhstype, result, "assignment",
     (tree) 
    ((void *)0)
             , 0);
}





int
language_lvalue_valid(tree exp) asm("_language_lvalue_valid");
int
language_lvalue_valid(tree exp)
{
  return 1;
}




static tree
get_delta_difference(tree from, tree to, int force) asm("_get_delta_difference");
static tree
get_delta_difference(tree from, tree to, int force)
{
  tree delta = integer_zero_node;
  tree binfo;

  if (to == from)
    return delta;






  binfo = get_binfo (from, to, 1);
  if (binfo == error_mark_node)
    {
      error ("   in pointer to member function conversion");
      return delta;
    }
  if (binfo == 0)
    {
      if (!force)
 {
   error_not_base_type (from, to);
   error ("   in pointer to member function conversion");
   return delta;
 }
      binfo = get_binfo (to, from, 1);
      if (binfo == error_mark_node)
 {
   error ("   in pointer to member function conversion");
   return delta;
 }
      if (binfo == 0)
 {
   error ("cannot convert pointer to member of type %T to unrelated pointer to member of type %T", from, to);
   return delta;
 }
      if (((binfo)->common.static_flag))
 {
   warning ("pointer to member conversion to virtual base class will only work if you are very careful");
 }
      return build_binary_op (MINUS_EXPR,
         integer_zero_node,
         (((binfo))->vec.a[1]), 1);
    }
  if (((binfo)->common.static_flag))
    {
      warning ("pointer to member conversion from virtual base class will only work if you are very careful");
    }
  return (((binfo))->vec.a[1]);
}
tree
build_ptrmemfunc(tree type, tree pfn, int force) asm("_build_ptrmemfunc");
tree
build_ptrmemfunc(tree type, tree pfn, int force)
{
  tree strchr = integer_zero_node;
  tree delta = integer_zero_node;
  tree delta2 = integer_zero_node;
  tree vfield_offset;
  tree npfn;
  tree u;


  if ((((n64_enum_tree_code) (((pfn)->common.type))->common.code) == RECORD_TYPE && ((((pfn)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {
      tree ndelta, ndelta2, nindex;
      if (type == (((((((((((((((pfn)->common.type))->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)))
 return pfn;


      if (((n64_enum_tree_code) (pfn)->common.code) != CONSTRUCTOR)
 {
   tree e1, e2, e3;
   ndelta = convert (ptrdiff_type_node, build_component_ref (pfn, delta_identifier, 0, 0));
   ndelta2 = convert (ptrdiff_type_node, (build_component_ref (build_component_ref ((pfn), pfn_or_delta2_identifier, 0, 0), delta2_identifier, 0, 0)));
   strchr = build_component_ref (pfn, index_identifier, 0, 0);
   delta = get_delta_difference ((((((((((((((((((((pfn)->common.type))->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)))->common.type))->type.maxval),
     ((((type)->common.type))->type.maxval),
     force);
   delta = build_binary_op (PLUS_EXPR, delta, ndelta, 1);
   delta2 = build_binary_op (PLUS_EXPR, ndelta2, delta2, 1);
   e1 = fold (build (GT_EXPR, boolean_type_node, strchr, integer_zero_node));

   u = build_nt (CONSTRUCTOR, 0, tree_cons (delta2_identifier, delta2, (tree) 
                                                                      ((void *)0)
                                                                               ));
   u = build_nt (CONSTRUCTOR, 0, tree_cons ((tree) 
                                           ((void *)0)
                                                    , delta,
         tree_cons ((tree) 
                   ((void *)0)
                            , strchr,
             tree_cons ((tree) 
                       ((void *)0)
                                , u, (tree) 
                                     ((void *)0)
                                              ))));
   e2 = digest_init (((tree)((type)->type.lang_specific)), u, (tree*)0);

   pfn = (build_component_ref (build_component_ref ((pfn), pfn_or_delta2_identifier, 0, 0), pfn_identifier, 0, 0));
   npfn = build1 (NOP_EXPR, type, pfn);
   ((npfn)->common.constant_flag) = ((pfn)->common.constant_flag);

   u = build_nt (CONSTRUCTOR, 0, tree_cons (pfn_identifier, npfn, (tree) 
                                                                 ((void *)0)
                                                                          ));
   u = build_nt (CONSTRUCTOR, 0, tree_cons ((tree) 
                                           ((void *)0)
                                                    , delta,
         tree_cons ((tree) 
                   ((void *)0)
                            , strchr,
             tree_cons ((tree) 
                       ((void *)0)
                                , u, (tree) 
                                     ((void *)0)
                                              ))));
   e3 = digest_init (((tree)((type)->type.lang_specific)), u, (tree*)0);
   return build_conditional_expr (e1, e2, e3);
 }

      ndelta = ((((pfn)->exp.operands[1]))->list.value);
      nindex = ((((((pfn)->exp.operands[1]))->common.chain))->list.value);
      npfn = ((((((((pfn)->exp.operands[1]))->common.chain))->common.chain))->list.value);
      npfn = ((((npfn)->exp.operands[1]))->list.value);
      if (integer_zerop (nindex))
 pfn = integer_zero_node;
      else if (integer_zerop (fold (size_binop (PLUS_EXPR, nindex, integer_one_node))))
 {
   tree e3;
   delta = get_delta_difference ((((((((((((((((((((pfn)->common.type))->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)))->common.type))->type.maxval),
     ((((type)->common.type))->type.maxval),
     force);
   delta = build_binary_op (PLUS_EXPR, delta, ndelta, 1);
   pfn = build1 (NOP_EXPR, type, npfn);
   ((pfn)->common.constant_flag) = ((npfn)->common.constant_flag);

   u = build_nt (CONSTRUCTOR, 0, tree_cons (pfn_identifier, pfn, (tree) 
                                                                ((void *)0)
                                                                         ));
   u = build_nt (CONSTRUCTOR, 0, tree_cons ((tree) 
                                           ((void *)0)
                                                    , delta,
         tree_cons ((tree) 
                   ((void *)0)
                            , nindex,
             tree_cons ((tree) 
                       ((void *)0)
                                , u, (tree) 
                                     ((void *)0)
                                              ))));
   e3 = digest_init (((tree)((type)->type.lang_specific)), u, (tree*)0);
   return e3;
 }
      else
 {
   sorry ("value casting of variable nonnull pointer to member functions not supported");
   return error_mark_node;
 }
    }


  if (integer_zerop (pfn))
    {
      pfn = build_c_cast (type, integer_zero_node, 0);
      u = build_nt (CONSTRUCTOR, 0, tree_cons (pfn_identifier, pfn, (tree) 
                                                                   ((void *)0)
                                                                            ));
      u = build_nt (CONSTRUCTOR, 0, tree_cons ((tree) 
                                              ((void *)0)
                                                       , integer_zero_node,
            tree_cons ((tree) 
                      ((void *)0)
                               , integer_zero_node,
         tree_cons ((tree) 
                   ((void *)0)
                            , u, (tree) 
                                 ((void *)0)
                                          ))));
      return digest_init (((tree)((type)->type.lang_specific)), u, (tree*)0);
    }

  if (((n64_enum_tree_code) (pfn)->common.code) == TREE_LIST
      || (((n64_enum_tree_code) (pfn)->common.code) == ADDR_EXPR
   && ((n64_enum_tree_code) (((pfn)->exp.operands[0]))->common.code) == TREE_LIST))
    {
      pfn = instantiate_type (type, pfn, 1);
      if (pfn == error_mark_node)
 return error_mark_node;
      if (((n64_enum_tree_code) (pfn)->common.code) != ADDR_EXPR)
 pfn = build_unary_op (ADDR_EXPR, pfn, 0);
    }


  delta = get_delta_difference (((((((pfn)->common.type))->common.type))->type.maxval),
    ((((type)->common.type))->type.maxval),
    force);
  delta2 = build_binary_op (PLUS_EXPR, delta2, delta, 1);

  if (((n64_enum_tree_code) (((pfn)->exp.operands[0]))->common.code) != FUNCTION_DECL)
    warning ("assuming pointer to member function is non-virtual");

  if (((n64_enum_tree_code) (((pfn)->exp.operands[0]))->common.code) == FUNCTION_DECL
      && ((((pfn)->exp.operands[0]))->decl.vindex))
    {

      vfield_offset = get_binfo (((((pfn)->exp.operands[0]))->decl.context),
     (((((pfn)->exp.operands[0]))->decl.lang_specific)->decl_flags.context),
     0);
      vfield_offset = get_vfield_offset (vfield_offset);
      delta2 = size_binop (PLUS_EXPR, vfield_offset, delta2);


      strchr = size_binop (PLUS_EXPR,
     ((((pfn)->exp.operands[0]))->decl.vindex),
     integer_one_node);
      u = build_nt (CONSTRUCTOR, 0, tree_cons (delta2_identifier, delta2, (tree) 
                                                                         ((void *)0)
                                                                                  ));
    }
  else
    {
      strchr = size_binop (MINUS_EXPR, integer_zero_node, integer_one_node);

      npfn = build1 (NOP_EXPR, type, pfn);
      ((npfn)->common.constant_flag) = ((pfn)->common.constant_flag);

      u = build_nt (CONSTRUCTOR, 0, tree_cons (pfn_identifier, npfn, (tree) 
                                                                    ((void *)0)
                                                                             ));
    }

  u = build_nt (CONSTRUCTOR, 0, tree_cons ((tree) 
                                          ((void *)0)
                                                   , delta,
        tree_cons ((tree) 
                  ((void *)0)
                           , strchr,
            tree_cons ((tree) 
                      ((void *)0)
                               , u, (tree) 
                                    ((void *)0)
                                             ))));
  return digest_init (((tree)((type)->type.lang_specific)), u, (tree*)0);
}
static tree
convert_for_assignment(tree type, tree rhs, char *errtype, tree fndecl, int parmnum) asm("_convert_for_assignment");
static tree
convert_for_assignment(tree type, tree rhs, char *errtype, tree fndecl, int parmnum)
{
  register n64_enum_tree_code codel = ((n64_enum_tree_code) (type)->common.code);
  register tree rhstype;
  register n64_enum_tree_code coder = ((n64_enum_tree_code) (((rhs)->common.type))->common.code);

  if (coder == LANG_TYPE)
    rhs = instantiate_type (type, rhs, 1);

  if (coder == ERROR_MARK)
    return error_mark_node;

  if (codel == OFFSET_TYPE)
    {
      type = ((type)->common.type);
      codel = ((n64_enum_tree_code) (type)->common.code);
    }


  if (((n64_enum_tree_code) (rhs)->common.code) == NON_LVALUE_EXPR)
    rhs = ((rhs)->exp.operands[0]);

  if (rhs == error_mark_node)
    return error_mark_node;

  if (((rhs)->list.value) == error_mark_node)
    return error_mark_node;

  if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == OFFSET_TYPE)
    {
      rhs = resolve_offset_ref (rhs);
      if (rhs == error_mark_node)
 return error_mark_node;
      rhstype = ((rhs)->common.type);
      coder = ((n64_enum_tree_code) (rhstype)->common.code);
    }

  if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == ARRAY_TYPE
      || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == FUNCTION_TYPE
      || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == METHOD_TYPE)
    rhs = default_conversion (rhs);
  else if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == REFERENCE_TYPE)
    rhs = convert_from_reference (rhs);

  rhstype = ((rhs)->common.type);
  coder = ((n64_enum_tree_code) (rhstype)->common.code);


  if (((n64_enum_tree_code) (rhs)->common.code) == CONST_DECL)
    rhs = ((rhs)->decl.initial);
  else if ((((rhs)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (rhs)->common.code))]) == 'd'))
    rhs = decl_constant_value (rhs);

  if (type == rhstype)
    {
      overflow_warning (rhs);
      return rhs;
    }

  if (coder == VOID_TYPE)
    {
      error ("void value not ignored as it ought to be");
      return error_mark_node;
    }

  if ((codel == INTEGER_TYPE || codel == REAL_TYPE || codel == BOOLEAN_TYPE)
       && (coder == INTEGER_TYPE || coder == REAL_TYPE || coder == BOOLEAN_TYPE))
    {

      if (coder == REAL_TYPE && codel == INTEGER_TYPE)
 {
   if (fndecl)
     cp_warning ("`%T' used for argument %P of `%D'",
   rhstype, parmnum, fndecl);
   else
     cp_warning ("%s to `%T' from `%T'", errtype, type, rhstype);
 }


      else if (((type)->common.unsigned_flag) && codel != BOOLEAN_TYPE)
 {
   if (((n64_enum_tree_code) (rhs)->common.code) == INTEGER_CST
       && (((rhs)->common.lang_flag_0)))
     {
       if (fndecl)
  cp_warning ("negative value `%E' passed as argument %P of `%D'",
       rhs, parmnum, fndecl);
       else
  cp_warning ("%s of negative value `%E' to `%T'",
       errtype, rhs, type);
     }
   overflow_warning (rhs);
   if (((rhs)->common.constant_flag))
     rhs = fold (rhs);
 }

      return convert_and_check (type, rhs);
    }

  else if ((codel == ENUMERAL_TYPE
     && ((coder == INTEGER_TYPE || coder == ENUMERAL_TYPE || coder == BOOLEAN_TYPE) || coder == REAL_TYPE))
    || (coder == ENUMERAL_TYPE
        && ((codel == INTEGER_TYPE || codel == ENUMERAL_TYPE || codel == BOOLEAN_TYPE) || codel == REAL_TYPE)))
    {
      return cp_convert (type, rhs, 1, (3));
    }

  else if (codel == POINTER_TYPE
    && (coder == POINTER_TYPE
        || (coder == RECORD_TYPE
     && ((((rhstype)->type.lang_specific)->type_flags.is_signature_pointer)
         || (((rhstype)->type.lang_specific)->type_flags.is_signature_reference)))))
    {
      register tree ttl = ((type)->common.type);
      register tree ttr;
      int ctt = 0;

      if (coder == RECORD_TYPE)
 {
   rhs = build_optr_ref (rhs);
   rhstype = ((rhs)->common.type);
 }
      ttr = ((rhstype)->common.type);




      if (((n64_enum_tree_code) (ttl)->common.code) == RECORD_TYPE && ((n64_enum_tree_code) (ttr)->common.code) == RECORD_TYPE)
 {
   tree binfo;

   if (((ttl)->type.main_variant) == ((ttr)->type.main_variant)
       || type == class_star_type_node
       || rhstype == class_star_type_node)
     binfo = ((ttl)->type.binfo);
   else
     binfo = get_binfo (ttl, ttr, 1);

   if (binfo == error_mark_node)
     return error_mark_node;
   if (binfo == 0)
     return error_not_base_type (ttl, ttr);

   if (! ((ttl)->common.readonly_flag) && ((ttr)->common.readonly_flag))
     {
       if (fndecl)
  cp_pedwarn ("passing `%T' as argument %P of `%D' discards const",
       rhstype, parmnum, fndecl);
       else
  cp_pedwarn ("%s to `%T' from `%T' discards const",
       errtype, type, rhstype);
     }
   if (! ((ttl)->common.volatile_flag) && ((ttr)->common.volatile_flag))
     {
       if (fndecl)
  cp_pedwarn ("passing `%T' as argument %P of `%D' discards volatile",
       rhstype, parmnum, fndecl);
       else
  cp_pedwarn ("%s to `%T' from `%T' discards volatile",
       errtype, type, rhstype);
     }
 }




      else if (((ttl)->type.main_variant) == void_type_node
        || ((ttr)->type.main_variant) == void_type_node
        || (ctt = comp_target_types (type, rhstype, 1))
        || (unsigned_type (((ttl)->type.main_variant))
     == unsigned_type (((ttr)->type.main_variant))))
 {

   if (((ttl)->type.main_variant) == void_type_node
       && ((n64_enum_tree_code) (ttr)->common.code) == OFFSET_TYPE)
     {
       cp_error ("no standard conversion from `%T' to `void *'", ttr);
       return error_mark_node;
     }

   if (ctt < 0)
     cp_pedwarn ("converting `%T' to `%T' is a contravariance violation",
   rhstype, type);

   if (((ttl)->type.main_variant) != void_type_node
       && ((ttr)->type.main_variant) == void_type_node
       && rhs != null_pointer_node)
     {
       if (coder == RECORD_TYPE)
  cp_pedwarn ("implicit conversion of signature pointer to type `%T'",
       type);
       else
  pedwarn ("ANSI C++ forbids implicit conversion from `void *' in %s",
    errtype);
     }


   else if ((((n64_enum_tree_code) (ttr)->common.code) != FUNCTION_TYPE && ((n64_enum_tree_code) (ttr)->common.code) != METHOD_TYPE)
     || (((n64_enum_tree_code) (ttl)->common.code) != FUNCTION_TYPE && ((n64_enum_tree_code) (ttl)->common.code) != METHOD_TYPE))
     {
       if (((n64_enum_tree_code) (ttl)->common.code) == OFFSET_TYPE
    && binfo_member (((ttr)->type.maxval),
       (((((ttl)->type.maxval))->type.lang_specific)->vbases)))
  {
    sorry ("%s between pointer to members converting across virtual baseclasses", errtype);
    return error_mark_node;
  }
       else if (! ((ttl)->common.readonly_flag) && ((ttr)->common.readonly_flag))
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' discards const",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' discards const",
    errtype, type, rhstype);
  }
       else if (! ((ttl)->common.volatile_flag) && ((ttr)->common.volatile_flag))
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' discards volatile",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' discards volatile",
    errtype, type, rhstype);
  }
       else if (((n64_enum_tree_code) (ttl)->common.code) == ((n64_enum_tree_code) (ttr)->common.code)
         && ! comp_target_types (type, rhstype, 1))
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' changes signedness",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' changes signedness",
    errtype, type, rhstype);
  }
     }
 }
      else if (((n64_enum_tree_code) (ttr)->common.code) == OFFSET_TYPE
        && ((n64_enum_tree_code) (ttl)->common.code) != OFFSET_TYPE)
 {





   if (current_class_decl)
     {
       if (((n64_enum_tree_code) (rhs)->common.code) == INTEGER_CST)
  {
    rhs = build (PLUS_EXPR, build_pointer_type (((ttr)->common.type)),
          current_class_decl, rhs);
    return convert_for_assignment (type, rhs,
       errtype, fndecl, parmnum);
  }
     }
   if (((n64_enum_tree_code) (ttl)->common.code) == METHOD_TYPE)
     error ("%s between pointer-to-method and pointer-to-member types",
     errtype);
   else
     error ("%s between pointer and pointer-to-member types", errtype);
   return error_mark_node;
 }
      else
 {
   int add_quals = 0, const_parity = 0, volatile_parity = 0;
   int left_const = 1;
   int unsigned_parity;
   int nptrs = 0;


   for (; ; ttl = ((ttl)->common.type), ttr = ((ttr)->common.type))
     {
       nptrs -= 1;
       const_parity |= ((ttl)->common.readonly_flag) < ((ttr)->common.readonly_flag);
       volatile_parity |= ((ttl)->common.volatile_flag) < ((ttr)->common.volatile_flag);

       if (! left_const
    && (((ttl)->common.readonly_flag) > ((ttr)->common.readonly_flag)
        || ((ttl)->common.volatile_flag) > ((ttr)->common.volatile_flag)))
  add_quals = 1;
       left_const &= ((ttl)->common.readonly_flag);

       if (((n64_enum_tree_code) (ttl)->common.code) != POINTER_TYPE
    || ((n64_enum_tree_code) (ttr)->common.code) != POINTER_TYPE)
  break;
     }
   unsigned_parity = ((ttl)->common.unsigned_flag) - ((ttr)->common.unsigned_flag);
   if (unsigned_parity)
     {
       if (((ttl)->common.unsigned_flag))
  ttr = unsigned_type (ttr);
       else
  ttl = unsigned_type (ttl);
     }

   if (comp_target_types (ttl, ttr, nptrs) > 0)
     {
       if (add_quals)
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' adds cv-quals without intervening `const'",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' adds cv-quals without intervening `const'",
    errtype, type, rhstype);
  }
       if (const_parity)
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' discards const",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' discards const",
    errtype, type, rhstype);
  }
       if (volatile_parity)
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' discards volatile",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' discards volatile",
    errtype, type, rhstype);
  }
       if (unsigned_parity > 0)
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' changes signed to unsigned",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' changes signed to unsigned",
    errtype, type, rhstype);
  }
       else if (unsigned_parity < 0)
  {
    if (fndecl)
      cp_pedwarn ("passing `%T' as argument %P of `%D' changes unsigned to signed",
    rhstype, parmnum, fndecl);
    else
      cp_pedwarn ("%s to `%T' from `%T' changes unsigned to signed",
    errtype, type, rhstype);
  }



       if (((n64_enum_tree_code) (ttl)->common.code) == FUNCTION_TYPE
    || ((n64_enum_tree_code) (ttl)->common.code) == METHOD_TYPE)
  if (! comptypes (ttl, ttr, 0))
    {
      warning ("conflicting function types in %s:", errtype);
      cp_warning ("\t`%T' != `%T'", type, rhstype);
    }
     }
   else if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == METHOD_TYPE)
     {

       my_friendly_abort (119);

       rhs = build_unary_op (ADDR_EXPR, rhs, 0);
       ((rhs)->common.type) = type;
       return rhs;
     }
   else if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == OFFSET_TYPE)
     {

       my_friendly_abort (120);

       rhs = build_unary_op (ADDR_EXPR, rhs, 0);
       ((rhs)->common.type) = type;
       return rhs;
     }
   else
     {
       if (fndecl)
  cp_error ("passing `%T' as argument %P of `%D'",
     rhstype, parmnum, fndecl);
       else
  cp_error ("%s to `%T' from `%T'", errtype, type, rhstype);
       return error_mark_node;
     }
 }
      return convert (type, rhs);
    }
  else if (codel == POINTER_TYPE && coder == INTEGER_TYPE)
    {


      if (! (((n64_enum_tree_code) (rhs)->common.code) == INTEGER_CST && integer_zerop (rhs)))
 {
   if (fndecl)
     cp_pedwarn ("passing `%T' to argument %P of `%D' lacks a cast",
   rhstype, parmnum, fndecl);
   else
     cp_pedwarn ("%s to `%T' from `%T' lacks a cast",
   errtype, type, rhstype);
   return convert (type, rhs);
 }
      return null_pointer_node;
    }
  else if (codel == INTEGER_TYPE
    && (coder == POINTER_TYPE
        || (coder == RECORD_TYPE
     && ((((rhstype)->type.lang_specific)->type_flags.is_signature_pointer)
         || (((rhstype)->type.lang_specific)->type_flags.ptrmemfunc_flag)
         || (((rhstype)->type.lang_specific)->type_flags.is_signature_reference)))))
    {
      if (fndecl)
 cp_pedwarn ("passing `%T' to argument %P of `%D' lacks a cast",
      rhstype, parmnum, fndecl);
      else
 cp_pedwarn ("%s to `%T' from `%T' lacks a cast",
      errtype, type, rhstype);
      return convert (type, rhs);
    }
  else if (codel == BOOLEAN_TYPE
    && (coder == POINTER_TYPE
        || (coder == RECORD_TYPE
     && ((((rhstype)->type.lang_specific)->type_flags.is_signature_pointer)
         || (((rhstype)->type.lang_specific)->type_flags.ptrmemfunc_flag)
         || (((rhstype)->type.lang_specific)->type_flags.is_signature_reference)))))
    return convert (type, rhs);


  else if (((coder == POINTER_TYPE
      && ((n64_enum_tree_code) (((rhstype)->common.type))->common.code) == METHOD_TYPE)
     || integer_zerop (rhs)
     || (((n64_enum_tree_code) (rhstype)->common.code) == RECORD_TYPE && ((rhstype)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    && (((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE && ((type)->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {
      tree ttl = (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type));
      tree ttr = (((n64_enum_tree_code) (rhstype)->common.code) == POINTER_TYPE ? rhstype
      : (((((((((((((type)->type.values))->common.chain))->common.chain))->common.type))->type.values))->common.type)));
      int ctt = comp_target_types (ttl, ttr, 1);

      if (ctt < 0)
 cp_pedwarn ("converting `%T' to `%T' is a contravariance violation",
      ttr, ttl);
      else if (ctt == 0)
 cp_error ("%s to `%T' from `%T'", errtype, ttl, ttr);


      return build_ptrmemfunc (ttl, rhs, 0);
    }
  else if (codel == ERROR_MARK || coder == ERROR_MARK)
    return error_mark_node;




  else if (codel == REFERENCE_TYPE)
    my_friendly_abort (317);
  else if (((type)->type.main_variant) == ((((rhs)->common.type))->type.main_variant))
    {
      tree nrhs = build1 (NOP_EXPR, type, rhs);
      ((nrhs)->common.constant_flag) = ((rhs)->common.constant_flag);
      return nrhs;
    }
  else if ((((type)->type.lang_flag_1)) || (((((rhs)->common.type))->type.lang_flag_5)))
    return convert (type, rhs);

  cp_error ("%s to `%T' from `%T'", errtype, type, rhstype);
  return error_mark_node;
}
tree
convert_for_initialization(tree exp, tree type, tree rhs, int flags, char *errtype, tree fndecl, int parmnum) asm("_convert_for_initialization");
tree
convert_for_initialization(tree exp, tree type, tree rhs, int flags, char *errtype, tree fndecl, int parmnum)
{
  register n64_enum_tree_code codel = ((n64_enum_tree_code) (type)->common.code);
  register tree rhstype;
  register n64_enum_tree_code coder;



  if (((n64_enum_tree_code) (rhs)->common.code) == NOP_EXPR
      && ((rhs)->common.type) == ((((rhs)->exp.operands[0]))->common.type)
      && codel != REFERENCE_TYPE)
    rhs = ((rhs)->exp.operands[0]);

  if (rhs == error_mark_node
      || (((n64_enum_tree_code) (rhs)->common.code) == TREE_LIST && ((rhs)->list.value) == error_mark_node))
    return error_mark_node;

  if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == OFFSET_TYPE)
    {
      rhs = resolve_offset_ref (rhs);
      if (rhs == error_mark_node)
 return error_mark_node;
    }

  if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == REFERENCE_TYPE)
    rhs = convert_from_reference (rhs);

  if ((((n64_enum_tree_code) (((rhs)->common.type))->common.code) == ARRAY_TYPE
       && ((n64_enum_tree_code) (type)->common.code) != ARRAY_TYPE
       && (((n64_enum_tree_code) (type)->common.code) != REFERENCE_TYPE
    || ((n64_enum_tree_code) (((type)->common.type))->common.code) != ARRAY_TYPE))
      || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == FUNCTION_TYPE
      || ((n64_enum_tree_code) (((rhs)->common.type))->common.code) == METHOD_TYPE)
    rhs = default_conversion (rhs);

  rhstype = ((rhs)->common.type);
  coder = ((n64_enum_tree_code) (rhstype)->common.code);

  if (coder == LANG_TYPE)
    {
      rhs = instantiate_type (type, rhs, 1);
      rhstype = ((rhs)->common.type);
      coder = ((n64_enum_tree_code) (rhstype)->common.code);
    }

  if (coder == ERROR_MARK)
    return error_mark_node;
  if (codel == REFERENCE_TYPE)
    {

      extern int warningcount, errorcount;
      int savew, savee;

      if (fndecl)
 savew = warningcount, savee = errorcount;
      rhs = convert_to_reference (type, rhs, 1, flags,
      exp ? exp : error_mark_node);
      if (fndecl)
 {
   if (warningcount > savew)
     cp_warning_at ("in passing argument %P of `%+D'", parmnum, fndecl);
   else if (errorcount > savee)
     cp_error_at ("in passing argument %P of `%+D'", parmnum, fndecl);
 }
      return rhs;
    }

  rhs = require_complete_type (rhs);
  if (rhs == error_mark_node)
    return error_mark_node;

  if (exp != 0) exp = require_complete_type (exp);
  if (exp == error_mark_node)
    return error_mark_node;

  if (((n64_enum_tree_code) (rhstype)->common.code) == REFERENCE_TYPE)
    rhstype = ((rhstype)->common.type);

  if (((type)->type.lang_specific)
      && ((((type)->type.lang_specific)->type_flags.is_signature_pointer) || (((type)->type.lang_specific)->type_flags.is_signature_reference)))
    return build_signature_pointer_constructor (type, rhs);

  if ((((type)->type.lang_flag_5))
      && (((type)->type.needs_constructing_flag) || (((rhs)->common.lang_flag_4))))
    {
      if (((type)->type.main_variant) == ((rhstype)->type.main_variant))
 {




   if (((n64_enum_tree_code) (rhs)->common.code) == CALL_EXPR)
     {
       rhs = build_cplus_new (type, rhs, 0);
       return rhs;
     }


   else if (((n64_enum_tree_code) (rhs)->common.code) == TARGET_EXPR)
     return rhs;
   else if (((n64_enum_tree_code) (rhs)->common.code) == INDIRECT_REF && (((rhs)->common.lang_flag_4)))
     {
       my_friendly_assert (((n64_enum_tree_code) (((rhs)->exp.operands[0]))->common.code) == CALL_EXPR, 318);
       if (exp)
  {
    my_friendly_assert (((((((rhs)->exp.operands[0]))->exp.operands[1]))->list.value) == (tree) 
                                                                               ((void *)0)
                                                                                        , 316);
    ((((((rhs)->exp.operands[0]))->exp.operands[1]))->list.value)
      = build_unary_op (ADDR_EXPR, exp, 0);
  }
       else
  rhs = build_cplus_new (type, ((rhs)->exp.operands[0]), 0);
       return rhs;
     }
   else if (((((type)->type.lang_specific)->type_flags.has_init_ref) && ! (((type)->type.lang_specific)->type_flags.has_complex_init_ref)))
     return rhs;
 }
      if (((type)->type.main_variant) == ((rhstype)->type.main_variant)
   || ((((rhstype)->type.lang_flag_5)) && (get_base_distance (type, rhstype, 0, (tree *)0) >= 0)))
 {
   if ((((type)->type.lang_specific)->type_flags.has_init_ref))
     {
       tree init = build_method_call (exp, constructor_name_full (type),
          build_tree_list ((tree) 
                          ((void *)0)
                                   , rhs),
          ((type)->type.binfo), (3));

       if (init == error_mark_node)
  return error_mark_node;

       if (exp == 0)
  {
    exp = build_cplus_new (type, init, 0);
    return exp;
  }

       return build (COMPOUND_EXPR, type, init, exp);
     }




   if ((((type)->type.lang_specific)->type_flags.has_assignment))
     cp_warning ("bitwise copy: `%T' defines operator=", type);

   if (((n64_enum_tree_code) (((rhs)->common.type))->common.code) == REFERENCE_TYPE)
     rhs = convert_from_reference (rhs);
   if (type != rhstype)
     {
       tree nrhs = build1 (NOP_EXPR, type, rhs);
       ((nrhs)->common.constant_flag) = ((rhs)->common.constant_flag);
       rhs = nrhs;
     }
   return rhs;
 }

      return cp_convert (type, rhs, (1 | 2 | 4 | 8), flags);
    }

  if (type == ((rhs)->common.type))
    {
      if ((((rhs)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (rhs)->common.code))]) == 'd'))
 rhs = decl_constant_value (rhs);
      return rhs;
    }

  return convert_for_assignment (type, rhs, errtype, fndecl, parmnum);
}
void
c_expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line) asm("_c_expand_asm_operands");
void
c_expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line)
{
  int noutputs = list_length (outputs);
  register int i;

  register tree *o = (tree *) 
                             __builtin_alloca((
                             noutputs * sizeof (tree)
                             ))
                                                              ;
  register tree tail;


  for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
    o[i] = ((tail)->list.value);




  expand_asm_operands (string, outputs, inputs, clobbers, vol, filename, line);


  for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
    {
      if (o[i] != ((tail)->list.value))
 {
   expand_expr (build_modify_expr (o[i], NOP_EXPR, ((tail)->list.value)),
         const0_rtx, VOIDmode, 0);
   free_temp_slots ();
 }


      else
 {
   tree type = ((o[i])->common.type);
   if (((type)->common.readonly_flag)
       || ((((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE
     || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE)
    && ((type)->type.lang_flag_0)))
     readonly_error (o[i], "modification by `asm'", 1);
 }
    }


  emit_queue ();
}
void
c_expand_return(tree retval) asm("_c_expand_return");
void
c_expand_return(tree retval)
{
  extern struct nesting *cond_stack, *loop_stack, *case_stack;
  extern tree dtor_label, ctor_label;
  tree result = ((current_function_decl)->decl.result);
  tree valtype = ((result)->common.type);
  register int use_temp = 0;
  int returns_value = 1;

  if (((current_function_decl)->common.volatile_flag))
    warning ("function declared `noreturn' has a `return' statement");

  if (retval == error_mark_node)
    {
      current_function_returns_null = 1;
      return;
    }

  if (retval == (tree) 
               ((void *)0)
                        )
    {



      if (dtor_label)
 {
   expand_goto (dtor_label);
   return;
 }

      if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
 retval = current_class_decl;
      else if (((result)->decl.name) != (tree) 
                                    ((void *)0)
        
       && ((n64_enum_tree_code) (valtype)->common.code) != VOID_TYPE)
 retval = result;
      else
 {
   current_function_returns_null = 1;

   if (valtype != (tree) 
                 ((void *)0) 
                           && ((n64_enum_tree_code) (valtype)->common.code) != VOID_TYPE)
     {
       if (((((current_function_decl)->decl.result))->decl.name) == (tree) 
                                                             ((void *)0)
                                                                      )
  {
    pedwarn ("`return' with no value, in function returning non-void");



    current_function_returns_null = 0;
  }
     }

   expand_null_return ();
   return;
 }
    }
  else if ((((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr)
    && retval != current_class_decl)
    {
      error ("return from a constructor: use `this = ...' instead");
      retval = current_class_decl;
    }

  if (valtype == (tree) 
                ((void *)0) 
                          || ((n64_enum_tree_code) (valtype)->common.code) == VOID_TYPE)
    {
      current_function_returns_null = 1;


      returns_value = 0;

      if (retval)
 pedwarn ("`return' with a value, in function returning void");
      expand_return (retval);
    }

  else if (((n64_enum_tree_code) (valtype)->common.code) == REFERENCE_TYPE)
    {
      tree whats_returned;
      tree tmp_result = result;





      if (result && ((((tmp_result)->common.type))->type.mode) != BLKmode)
 tmp_result = 0;



      retval = convert_for_initialization (tmp_result, valtype, retval,
        (3), "return",
        (tree) 
       ((void *)0)
                , 0);



      whats_returned = retval;
      if (((n64_enum_tree_code) (whats_returned)->common.code) == COMPOUND_EXPR)
 {
   whats_returned = ((whats_returned)->exp.operands[1]);
   if (((n64_enum_tree_code) (whats_returned)->common.code) == ADDR_EXPR)
     whats_returned = ((whats_returned)->exp.operands[0]);
 }
      if (((n64_enum_tree_code) (whats_returned)->common.code) == ADDR_EXPR)
 {
   whats_returned = ((whats_returned)->exp.operands[0]);
   while (((n64_enum_tree_code) (whats_returned)->common.code) == NEW_EXPR
   || ((n64_enum_tree_code) (whats_returned)->common.code) == TARGET_EXPR
   || ((n64_enum_tree_code) (whats_returned)->common.code) == WITH_CLEANUP_EXPR)
     {

       whats_returned = ((whats_returned)->exp.operands[0]);
       warning ("returning reference to temporary");
     }
 }

      if (((n64_enum_tree_code) (whats_returned)->common.code) == VAR_DECL && ((whats_returned)->decl.name))
 {
   if ((!strncmp (((((whats_returned)->decl.name))->identifier.pointer), "_.tmp_", sizeof ("_.tmp_")-1)))
     warning ("reference to non-lvalue returned");
   else if (! ((whats_returned)->common.static_flag)
     && (((struct n64_tag_lang_identifier *)(((whats_returned)->decl.name)))->local_value))
     cp_warning_at ("reference to local variable `%D' returned", whats_returned);
 }
    }
  else if (((n64_enum_tree_code) (retval)->common.code) == ADDR_EXPR)
    {
      tree whats_returned = ((retval)->exp.operands[0]);

      if (((n64_enum_tree_code) (whats_returned)->common.code) == VAR_DECL
   && ((whats_returned)->decl.name)
   && (((struct n64_tag_lang_identifier *)(((whats_returned)->decl.name)))->local_value)
   && !((whats_returned)->common.static_flag))
 cp_warning_at ("address of local variable `%D' returned", whats_returned);
    }
  if (((n64_enum_tree_code) (retval)->common.code) == TARGET_EXPR
      && ((((retval)->common.type))->type.main_variant) == ((valtype)->type.main_variant)
      && ! current_function_returns_struct)
    retval = expand_target_expr (retval);

  if (retval == result


      || (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
    {

      if (((valtype)->type.size) == (tree) 
                                ((void *)0)
                                         )
 return;

      if (((valtype)->type.mode) != BLKmode
   && any_pending_cleanups (1))
 {
   retval = get_temp_regvar (valtype, retval);
   use_temp = obey_regdecls;
 }
    }
  else if ((((valtype)->type.lang_flag_5)) && current_function_returns_struct)
    {
      expand_aggr_init (result, retval, 0, (128));
      expand_cleanups_to ((tree) 
                         ((void *)0)
                                  );
      ((result)->decl.initial) = (tree) 
                             ((void *)0)
                                      ;
      retval = 0;
    }
  else
    {
      if (((valtype)->type.mode) == VOIDmode)
 {
   if (((((result)->common.type))->type.mode) != VOIDmode
       && warn_return_type)
     warning ("return of void value in function returning non-void");
   expand_expr_stmt (retval);
   retval = 0;
   result = 0;
 }
      else if (((valtype)->type.mode) != BLKmode
        && any_pending_cleanups (1))
 {
   retval = get_temp_regvar (valtype, retval);
   expand_cleanups_to ((tree) 
                      ((void *)0)
                               );
   use_temp = obey_regdecls;
   result = 0;
 }
      else
 {
   retval = convert_for_initialization (result, valtype, retval,
            (3),
            "return", (tree) 
                     ((void *)0)
                              , 0);
   ((result)->decl.initial) = (tree) 
                          ((void *)0)
                                   ;
 }
      if (retval == error_mark_node)
 return;
    }

  emit_queue ();

  if (retval != (tree) 
               ((void *)0)
      
     && (*tree_code_type[(int) (((n64_enum_tree_code) (retval)->common.code))]) == 'd'
      && cond_stack == 0 && loop_stack == 0 && case_stack == 0)
    current_function_return_value = retval;

  if (result)
    {

      if (original_result_rtx)
 {
   store_expr (result, original_result_rtx, 0);
   expand_cleanups_to ((tree) 
                      ((void *)0)
                               );
   use_variable (((result)->decl.rtl));
   if (ctor_label && ((n64_enum_tree_code) (ctor_label)->common.code) != ERROR_MARK)
     expand_goto (ctor_label);
   else
     expand_null_return ();
 }
      else if (retval && retval != result)
 {


   if (((result)->decl.context) == error_mark_node)
     ((result)->decl.context) = (tree) 
                            ((void *)0)
                                     ;



   retval = fold (build1 (CLEANUP_POINT_EXPR, ((result)->common.type),
     retval));


   retval = build (INIT_EXPR, ((result)->common.type), result, retval);
   ((retval)->common.side_effects_flag) = 1;
   expand_return (retval);
 }
      else
 expand_return (result);
    }
  else
    {

      result = ((current_function_decl)->decl.result);
      if (original_result_rtx)
 {


   if (retval)
     expand_assignment (result, retval, 0, 0);
   else
     store_expr (result, original_result_rtx, 0);
   result = make_tree (((result)->common.type), original_result_rtx);
 }
      else if (ctor_label && ((n64_enum_tree_code) (ctor_label)->common.code) != ERROR_MARK)
 {

   expand_goto (ctor_label);
 }
      else if (retval)
 {



   result = build (INIT_EXPR, ((result)->common.type), result, retval);
   ((result)->common.side_effects_flag) = 1;
   expand_return (result);
 }
      else if (((((result)->common.type))->type.mode) != VOIDmode)
 expand_return (result);
    }

  current_function_returns_value = returns_value;
  expand_cleanups_to ((tree) 
                     ((void *)0)
                              );
}




tree
c_expand_start_case(tree exp) asm("_c_expand_start_case");
tree
c_expand_start_case(tree exp)
{
  tree type;
  register n64_enum_tree_code code;


  exp = default_conversion (exp);
  type = ((exp)->common.type);
  code = ((n64_enum_tree_code) (type)->common.code);

  if ((code == RECORD_TYPE || code == UNION_TYPE || code == UNINSTANTIATED_P_TYPE))
    exp = build_type_conversion (CONVERT_EXPR, integer_type_node, exp, 1);

  if (exp == (tree) 
            ((void *)0)
                     )
    {
      error ("switch quantity not an integer");
      exp = error_mark_node;
    }
  type = ((exp)->common.type);
  code = ((n64_enum_tree_code) (type)->common.code);

  if (code != INTEGER_TYPE && code != ENUMERAL_TYPE && code != ERROR_MARK)
    {
      error ("switch quantity not an integer");
      exp = error_mark_node;
    }
  else
    {
      tree strchr;

      exp = default_conversion (exp);
      type = ((exp)->common.type);
      strchr = get_unwidened (exp, 0);




      if (((((exp)->common.type))->common.unsigned_flag)
   == ((((strchr)->common.type))->common.unsigned_flag))
 exp = strchr;
    }

  expand_start_case
    (1, fold (build1 (CLEANUP_POINT_EXPR, ((exp)->common.type), exp)),
     type, "switch statement");

  return exp;
}



int
comp_ptr_ttypes_real(tree to, tree from, int constp) asm("_comp_ptr_ttypes_real");
int
comp_ptr_ttypes_real(tree to, tree from, int constp)
{
  for (; ; to = ((to)->common.type), from = ((from)->common.type))
    {
      if (((n64_enum_tree_code) (to)->common.code) != ((n64_enum_tree_code) (from)->common.code))
 return 0;



      if (((n64_enum_tree_code) (to)->common.code) != FUNCTION_TYPE && ((n64_enum_tree_code) (to)->common.code) != METHOD_TYPE)
 {
   if (((from)->common.readonly_flag) > ((to)->common.readonly_flag)
       || ((from)->common.volatile_flag) > ((to)->common.volatile_flag))
     return 0;

   if (! constp
       && (((to)->common.readonly_flag) > ((from)->common.readonly_flag)
    || ((to)->common.volatile_flag) > ((from)->common.readonly_flag)))
     return 0;
   constp &= ((to)->common.readonly_flag);
 }

      if (((n64_enum_tree_code) (to)->common.code) != POINTER_TYPE)
 return comptypes (((to)->type.main_variant), ((from)->type.main_variant), 1);
    }
}




int
comp_ptr_ttypes(tree to, tree from) asm("_comp_ptr_ttypes");
int
comp_ptr_ttypes(tree to, tree from)
{
  return comp_ptr_ttypes_real (to, from, 1);
}

