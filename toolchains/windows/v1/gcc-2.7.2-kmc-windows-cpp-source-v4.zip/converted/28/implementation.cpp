// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/expmed.c
/* Medium-level subroutines: convert bit-field store and extract
   and shifts, multiplies and divides to rtl instructions.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int rtx_cost(...) asm("_rtx_cost");
extern int init_recog(...) asm("_init_recog");
extern int recog(...) asm("_recog");
extern int obfree(...) asm("_obfree");
extern int delete_insns_since(...) asm("_delete_insns_since");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int preserve_subexpressions_p(...) asm("_preserve_subexpressions_p");
extern int div_and_round_double(...) asm("_div_and_round_double");
struct n64_tag_algorithm;
struct n64_tag_args_size;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;

typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);

extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];

static void store_fixed_bit_field (rtx, int, int, int, rtx, int) asm("_store_fixed_bit_field");
static void store_split_bit_field (rtx, int, int, rtx, int) asm("_store_split_bit_field");
static rtx extract_fixed_bit_field (n64_enum_machine_mode, rtx, int, int, int, rtx, int, int) asm("_extract_fixed_bit_field")
                                     ;
static rtx mask_rtx (n64_enum_machine_mode, int, int, int) asm("_mask_rtx")
                      ;
static rtx lshift_value (n64_enum_machine_mode, rtx, int, int) asm("_lshift_value")
                      ;
static rtx extract_split_bit_field (rtx, int, int, int, int) asm("_extract_split_bit_field");
static int sdiv_pow2_cheap, smod_pow2_cheap;
static int add_cost, negate_cost, zero_cost;
static int shift_cost[64];
static int shiftadd_cost[64];
static int shiftsub_cost[64];
static int mul_cost[(int) MAX_MACHINE_MODE];
static int div_cost[(int) MAX_MACHINE_MODE];
static int mul_widen_cost[(int) MAX_MACHINE_MODE];
static int mul_highpart_cost[(int) MAX_MACHINE_MODE];

void
init_expmed(void) asm("_init_expmed");
void
init_expmed(void)
{
  char *free_point;


  rtx reg = gen_rtx (REG, word_mode, 10000);
  rtx shift_insn, shiftadd_insn, shiftsub_insn;
  int dummy;
  int m;
  n64_enum_machine_mode mode, wider_mode;

  start_sequence ();





  free_point = (char *) oballoc (0);

  zero_cost = rtx_cost (const0_rtx, 0);
  add_cost = rtx_cost (gen_rtx (PLUS, word_mode, reg, reg), SET);

  shift_insn = emit_insn (gen_rtx (SET, VOIDmode, reg,
       gen_rtx (ASHIFT, word_mode, reg,
         const0_rtx)));

  shiftadd_insn = emit_insn (gen_rtx (SET, VOIDmode, reg,
          gen_rtx (PLUS, word_mode,
            gen_rtx (MULT, word_mode,
       reg, const0_rtx),
            reg)));

  shiftsub_insn = emit_insn (gen_rtx (SET, VOIDmode, reg,
          gen_rtx (MINUS, word_mode,
            gen_rtx (MULT, word_mode,
        reg, const0_rtx),
      reg)));

  init_recog ();

  shift_cost[0] = 0;
  shiftadd_cost[0] = shiftsub_cost[0] = add_cost;

  for (m = 1; m < ((target_flags & 0x00002000) ? 64 : 32); m++)
    {
      shift_cost[m] = shiftadd_cost[m] = shiftsub_cost[m] = 32000;

      ((((((shift_insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx) = gen_rtx (CONST_INT, VOIDmode, (int) (m));
      if (recog (((shift_insn)->fld[3].rtx), shift_insn, &dummy) >= 0)
 shift_cost[m] = rtx_cost (((((shift_insn)->fld[3].rtx))->fld[1].rtx), SET);

      ((((((((shiftadd_insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx)
 = gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << m));
      if (recog (((shiftadd_insn)->fld[3].rtx), shiftadd_insn, &dummy) >= 0)
 shiftadd_cost[m] = rtx_cost (((((shiftadd_insn)->fld[3].rtx))->fld[1].rtx), SET);

      ((((((((shiftsub_insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx))->fld[1].rtx)
 = gen_rtx (CONST_INT, VOIDmode, (int) ((int) 1 << m));
      if (recog (((shiftsub_insn)->fld[3].rtx), shiftsub_insn, &dummy) >= 0)
 shiftsub_cost[m] = rtx_cost (((((shiftsub_insn)->fld[3].rtx))->fld[1].rtx), SET);
    }

  negate_cost = rtx_cost (gen_rtx (NEG, word_mode, reg), SET);

  sdiv_pow2_cheap
    = (rtx_cost (gen_rtx (DIV, word_mode, reg, gen_rtx (CONST_INT, VOIDmode, (int) (32))), SET)
       <= 2 * add_cost);
  smod_pow2_cheap
    = (rtx_cost (gen_rtx (MOD, word_mode, reg, gen_rtx (CONST_INT, VOIDmode, (int) (32))), SET)
       <= 2 * add_cost);

  for (mode = class_narrowest_mode[(int)(MODE_INT)];
       mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    {
      reg = gen_rtx (REG, mode, 10000);
      div_cost[(int) mode] = rtx_cost (gen_rtx (UDIV, mode, reg, reg), SET);
      mul_cost[(int) mode] = rtx_cost (gen_rtx (MULT, mode, reg, reg), SET);
      wider_mode = (mode_wider_mode[(int)(mode)]);
      if (wider_mode != VOIDmode)
 {
   mul_widen_cost[(int) wider_mode]
     = rtx_cost (gen_rtx (MULT, wider_mode,
     gen_rtx (ZERO_EXTEND, wider_mode, reg),
     gen_rtx (ZERO_EXTEND, wider_mode, reg)),
   SET);
   mul_highpart_cost[(int) mode]
     = rtx_cost (gen_rtx (TRUNCATE, mode,
     gen_rtx (LSHIFTRT, wider_mode,
       gen_rtx (MULT, wider_mode,
         gen_rtx (ZERO_EXTEND, wider_mode, reg),
         gen_rtx (ZERO_EXTEND, wider_mode, reg)),
       gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(mode)]))))),
   SET);
 }
    }


  end_sequence ();
  obfree (free_point);
}





rtx
negate_rtx(n64_enum_machine_mode mode, rtx x) asm("_negate_rtx");
rtx
negate_rtx(n64_enum_machine_mode mode, rtx x)
{
  if (((x)->code) == CONST_INT)
    {
      int val = - ((x)->fld[0].rtwint);
      if ((8 * mode_size[(int)(mode)]) < 32)
 {

   if (val & ((int) 1 << ((8 * mode_size[(int)(mode)]) - 1)))
     val |= (int) (-1) << (8 * mode_size[(int)(mode)]);
   else
     val &= ((int) 1 << (8 * mode_size[(int)(mode)])) - 1;
 }
      return gen_rtx (CONST_INT, VOIDmode, (int) (val));
    }
  else
    return expand_unop (((x)->mode), neg_optab, x, (rtx) 0, 0);
}
rtx
store_bit_field(rtx str_rtx, register int bitsize, int bitnum, n64_enum_machine_mode fieldmode, rtx value, int align, int total_size) asm("_store_bit_field");
rtx
store_bit_field(rtx str_rtx, register int bitsize, int bitnum, n64_enum_machine_mode fieldmode, rtx value, int align, int total_size)
{
  int unit = (((str_rtx)->code) == MEM) ? 8 : ((target_flags & 0x00002000) ? 64 : 32);
  register int offset = bitnum / unit;
  register int bitpos = bitnum % unit;
  register rtx op0 = str_rtx;

  if (((str_rtx)->code) == MEM && ! ((str_rtx)->in_struct))
    abort ();



  if (total_size >= 0)
    total_size -= (bitpos / 64
     * (64 / 8));

  while (((op0)->code) == SUBREG)
    {





      offset += ((op0)->fld[1].rtint);


      op0 = ((op0)->fld[0].rtx);
    }




  if (((target_flags & 0x00010000) != 0)
      && ((op0)->code) != MEM
      && unit > (8 * mode_size[(int)(((op0)->mode))]))
    bitpos += unit - (8 * mode_size[(int)(((op0)->mode))]);

  value = protect_from_queue (value, 0);

  if (flag_force_mem)
    value = force_not_mem (value);



  if ((mode_size[(int)(fieldmode)]) >= ((target_flags & 0x00002000) ? 8 : 4)
      && (((op0)->code) != MEM
   || ! 1
   || (offset * 8 % bitsize == 0
       && align % (mode_size[(int)(fieldmode)]) == 0))
      && bitpos == 0 && bitsize == (8 * mode_size[(int)(fieldmode)]))
    {


      if (((op0)->mode) != fieldmode)
 {
   if (((op0)->code) == REG)
     op0 = gen_rtx (SUBREG, fieldmode, op0, offset);
   else
     op0 = change_address (op0, fieldmode,
      plus_constant_wide (((op0)->fld[0].rtx), (int) (offset)));
 }
      emit_move_insn (op0, value);
      return value;
    }




  if (((op0)->code) != MEM
      && (((target_flags & 0x00010000) != 0) ? bitpos + bitsize == unit : bitpos == 0)
      && bitsize == (8 * mode_size[(int)(fieldmode)])
      && (((op0)->mode) == fieldmode
   || (movstrict_optab->handlers[(int) fieldmode].insn_code
       != CODE_FOR_nothing)))
    {

      if (((value)->code) == CONST_INT || ((value)->code) == REG)
 value = gen_lowpart (fieldmode, value);
      else if (!(((value)->code) == SYMBOL_REF
   || ((value)->code) == LABEL_REF
   || ((value)->code) == CONST))
 value = convert_to_mode (fieldmode, value, 0);

      if (((op0)->mode) == fieldmode)
 emit_move_insn (op0, value);
      else
 {
   int icode = movstrict_optab->handlers[(int) fieldmode].insn_code;
   if(! (*insn_operand_predicate[icode][1]) (value, fieldmode))
     value = copy_to_mode_reg (fieldmode, value);
   emit_insn ((*insn_gen_function[(int) (icode)])
     (gen_rtx (SUBREG, fieldmode, op0, offset), value));
 }
      return value;
    }



  if (bitsize > ((target_flags & 0x00002000) ? 64 : 32))
    {






      int backwards = ((target_flags & 0x00010000) != 0) && fieldmode != BLKmode;

      int nwords = (bitsize + (((target_flags & 0x00002000) ? 64 : 32) - 1)) / ((target_flags & 0x00002000) ? 64 : 32);
      int i;






      fieldmode = mode_for_size (nwords * ((target_flags & 0x00002000) ? 64 : 32), MODE_INT, 0);

      for (i = 0; i < nwords; i++)
 {


   int wordnum = (backwards ? nwords - i - 1 : i);
   int bit_offset = (backwards
       ? ((bitsize - (i + 1) * ((target_flags & 0x00002000) ? 64 : 32)) > (0) ? (bitsize - (i + 1) * ((target_flags & 0x00002000) ? 64 : 32)) : (0))
       : i * ((target_flags & 0x00002000) ? 64 : 32));
   store_bit_field (op0, ((((target_flags & 0x00002000) ? 64 : 32)) < (bitsize - i * ((target_flags & 0x00002000) ? 64 : 32)) ? (((target_flags & 0x00002000) ? 64 : 32)) : (bitsize - i * ((target_flags & 0x00002000) ? 64 : 32)))
                                     ,
      bitnum + bit_offset, word_mode,
      operand_subword_force (value, wordnum,
        (((value)->mode) == VOIDmode
         ? fieldmode
         : ((value)->mode))),
      align, total_size);
 }
      return value;
    }







  if (((op0)->code) == REG)
    {
      if (offset != 0
   || (mode_size[(int)(((op0)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 op0 = gen_rtx (SUBREG, ((type_for_size (((target_flags & 0x00002000) ? 64 : 32), 0))->type.mode),
         op0, offset);
      offset = 0;
    }
  else
    {
      op0 = protect_from_queue (op0, 1);
    }





  if ((mode_class[(int)(((value)->mode))]) == MODE_FLOAT)
    {
      if (((value)->code) != REG)
 value = copy_to_reg (value);
      value = gen_rtx (SUBREG, word_mode, value, 0);
    }





  if (1
      && !(bitsize == 1 && ((value)->code) == CONST_INT)

      && ((8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_insv][3])])
   >= bitsize)
      && ! ((((op0)->code) == REG || ((op0)->code) == SUBREG)
     && (bitsize + bitpos
  > (8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_insv][3])]))))
    {
      int xbitpos = bitpos;
      rtx value1;
      rtx xop0 = op0;
      rtx last = get_last_insn ();
      rtx pat;
      n64_enum_machine_mode maxmode
 = insn_operand_mode[(int) CODE_FOR_insv][3];

      int save_volatile_ok = volatile_ok;
      volatile_ok = 1;




      if (((op0)->code) == MEM
   && (flag_force_mem
       || ! ((*insn_operand_predicate[(int) CODE_FOR_insv][0])
      (op0, VOIDmode))))
 {
   rtx tempreg;
   n64_enum_machine_mode bestmode;






   if (((op0)->mode) == BLKmode
       || (mode_size[(int)(((op0)->mode))]) > (mode_size[(int)(maxmode)]))
     bestmode
       = get_best_mode (bitsize, bitnum, align * 8, maxmode,
          ((op0)->volatil));
   else
     bestmode = ((op0)->mode);

   if (bestmode == VOIDmode
       || (1 && (mode_size[(int)(bestmode)]) > align))
     goto insv_loses;


   unit = (8 * mode_size[(int)(bestmode)]);

   offset = (bitnum / unit) * (mode_size[(int)(bestmode)]);
   bitpos = bitnum % unit;
   op0 = change_address (op0, bestmode,
    plus_constant_wide (((op0)->fld[0].rtx), (int) (offset)));


   tempreg = copy_to_reg (op0);
   store_bit_field (tempreg, bitsize, bitpos, fieldmode, value,
      align, total_size);
   emit_move_insn (op0, tempreg);
   return value;
 }
      volatile_ok = save_volatile_ok;


      if (((xop0)->code) == MEM)
 xop0 = change_address (xop0, byte_mode,
          plus_constant_wide (((xop0)->fld[0].rtx), (int) (offset)));



      if (((xop0)->code) == SUBREG)


 xop0 = gen_rtx (SUBREG, maxmode, ((xop0)->fld[0].rtx), ((xop0)->fld[1].rtint));
      if (((xop0)->code) == REG && ((xop0)->mode) != maxmode)
 xop0 = gen_rtx (SUBREG, maxmode, xop0, 0);




      if (0 != ((target_flags & 0x00010000) != 0))
 xbitpos = unit - bitsize - xbitpos;



      if (0 && ((xop0)->code) != MEM)
 xbitpos += (8 * mode_size[(int)(maxmode)]) - unit;

      unit = (8 * mode_size[(int)(maxmode)]);


      value1 = value;
      if (((value)->mode) != maxmode)
 {
   if ((8 * mode_size[(int)(((value)->mode))]) >= bitsize)
     {




       if ((mode_size[(int)(((value)->mode))]) < (mode_size[(int)(maxmode)]))
  {

    if (((value1)->code) != REG)
  value1 = copy_to_reg (value1);
    value1 = gen_rtx (SUBREG, maxmode, value1, 0);
  }
       else
  value1 = gen_lowpart (maxmode, value1);
     }
   else if (!(((value)->code) == LABEL_REF || ((value)->code) == SYMBOL_REF || ((value)->code) == CONST_INT || ((value)->code) == CONST_DOUBLE || ((value)->code) == CONST || ((value)->code) == HIGH))




     abort ();
 }



      if (! ((*insn_operand_predicate[(int) CODE_FOR_insv][3])
      (value1, maxmode)))
 value1 = force_reg (maxmode, value1);

      pat = gen_insv (xop0, gen_rtx (CONST_INT, VOIDmode, (int) (bitsize)), gen_rtx (CONST_INT, VOIDmode, (int) (xbitpos)), value1);
      if (pat)
 emit_insn (pat);
      else
        {
   delete_insns_since (last);
   store_fixed_bit_field (op0, offset, bitsize, bitpos, value, align);
 }
    }
  else
    insv_loses:


    store_fixed_bit_field (op0, offset, bitsize, bitpos, value, align);
  return value;
}
static void
store_fixed_bit_field(register rtx op0, register int offset, register int bitsize, register int bitpos, register rtx value, int struct_align) asm("_store_fixed_bit_field");
static void
store_fixed_bit_field(register rtx op0, register int offset, register int bitsize, register int bitpos, register rtx value, int struct_align)
{
  register n64_enum_machine_mode mode;
  int total_bits = ((target_flags & 0x00002000) ? 64 : 32);
  rtx subtarget, temp;
  int all_zero = 0;
  int all_one = 0;
  if (((op0)->code) == REG || ((op0)->code) == SUBREG)
    {
      if (offset != 0)
 abort ();

      if (bitsize + bitpos > ((target_flags & 0x00002000) ? 64 : 32))
 {
   store_split_bit_field (op0, bitsize, bitpos,
     value, ((target_flags & 0x00002000) ? 64 : 32));
   return;
 }
    }
  else
    {




      mode = get_best_mode (bitsize, bitpos + offset * 8,
       struct_align * 8, word_mode,
       ((op0)->code) == MEM && ((op0)->volatil));

      if (mode == VOIDmode)
 {


   store_split_bit_field (op0,
     bitsize, bitpos + offset * 8,
     value, struct_align);
   return;
 }

      total_bits = (8 * mode_size[(int)(mode)]);




      if (bitpos >= total_bits)
 {
   offset += (bitpos / total_bits) * (total_bits / 8);
   bitpos -= ((bitpos / total_bits) * (total_bits / 8)
       * 8);
 }





      bitpos += (offset % (total_bits / 8)) * 8;
      offset -= (offset % (total_bits / 8));
      op0 = change_address (op0, mode,
       plus_constant_wide (((op0)->fld[0].rtx), (int) (offset)));
    }

  mode = ((op0)->mode);







  if (((target_flags & 0x00010000) != 0))



      bitpos = total_bits - bitsize - bitpos;







  if (((value)->code) == CONST_INT)
    {
      register int v = ((value)->fld[0].rtwint);

      if (bitsize < 32)
 v &= ((int) 1 << bitsize) - 1;

      if (v == 0)
 all_zero = 1;
      else if ((bitsize < 32
  && v == ((int) 1 << bitsize) - 1)
        || (bitsize == 32 && v == -1))
 all_one = 1;

      value = lshift_value (mode, value, bitpos, bitsize);
    }
  else
    {
      int must_and = ((8 * mode_size[(int)(((value)->mode))]) != bitsize
        && bitpos + bitsize != (8 * mode_size[(int)(mode)]));

      if (((value)->mode) != mode)
 {
   if ((((value)->code) == REG || ((value)->code) == SUBREG)
       && (mode_size[(int)(mode)]) < (mode_size[(int)(((value)->mode))]))
     value = gen_lowpart (mode, value);
   else
     value = convert_to_mode (mode, value, 1);
 }

      if (must_and)
 value = expand_binop (mode, and_optab, value,
         mask_rtx (mode, 0, bitsize, 0),
         (rtx) 0, 1, OPTAB_LIB_WIDEN);
      if (bitpos > 0)
 value = expand_shift (LSHIFT_EXPR, mode, value,
         build_int_2_wide ((int) (bitpos), (int) (0)), (rtx) 0, 1);
    }




  subtarget = (((op0)->code) == REG || ! flag_force_mem) ? op0 : 0;

  if (! all_one)
    {
      temp = expand_binop (mode, and_optab, op0,
      mask_rtx (mode, bitpos, bitsize, 1),
      subtarget, 1, OPTAB_LIB_WIDEN);
      subtarget = temp;
    }
  else
    temp = op0;



  if (! all_zero)
    temp = expand_binop (mode, ior_optab, temp, value,
    subtarget, 1, OPTAB_LIB_WIDEN);
  if (op0 != temp)
    emit_move_insn (op0, temp);
}
static void
store_split_bit_field(rtx op0, int bitsize, int bitpos, rtx value, int align) asm("_store_split_bit_field");
static void
store_split_bit_field(rtx op0, int bitsize, int bitpos, rtx value, int align)
{
  int unit;
  int bitsdone = 0;



  if (((op0)->code) == REG || ((op0)->code) == SUBREG)
    unit = ((target_flags & 0x00002000) ? 64 : 32);
  else
    unit = ((align * 8) < (((target_flags & 0x00002000) ? 64 : 32)) ? (align * 8) : (((target_flags & 0x00002000) ? 64 : 32)));




  if ((((value)->code) == LABEL_REF || ((value)->code) == SYMBOL_REF || ((value)->code) == CONST_INT || ((value)->code) == CONST_DOUBLE || ((value)->code) == CONST || ((value)->code) == HIGH) && ((value)->code) != CONST_INT)
    {
      rtx word = gen_lowpart_common (word_mode, value);

      if (word && (value != word))
 value = word;
      else
 value = gen_lowpart_common (word_mode,
        force_reg (((value)->mode) != VOIDmode
            ? ((value)->mode)
            : word_mode, value));
    }

  while (bitsdone < bitsize)
    {
      int thissize;
      rtx part, word;
      int thispos;
      int offset;

      offset = (bitpos + bitsdone) / unit;
      thispos = (bitpos + bitsdone) % unit;




      thissize = ((bitsize - bitsdone) < (((target_flags & 0x00002000) ? 64 : 32)) ? (bitsize - bitsdone) : (((target_flags & 0x00002000) ? 64 : 32)));
      thissize = ((thissize) < (unit - thispos) ? (thissize) : (unit - thispos));

      if (((target_flags & 0x00010000) != 0))
 {
   int total_bits;




   if (((value)->code) != MEM)
     total_bits = ((target_flags & 0x00002000) ? 64 : 32);
   else
     total_bits = (8 * mode_size[(int)(((value)->mode))]);


   if (((value)->code) == CONST_INT)
     part = gen_rtx (CONST_INT, VOIDmode, (int) (((unsigned int) (((value)->fld[0].rtwint)) >> (bitsize - bitsdone - thissize)) & (((int) 1 << thissize) - 1)))

                                               ;
   else



     part = extract_fixed_bit_field (word_mode, value, 0, thissize,
         total_bits - bitsize + bitsdone,
         (rtx) 0, 1, align);
 }
      else
 {

   if (((value)->code) == CONST_INT)
     part = gen_rtx (CONST_INT, VOIDmode, (int) (((unsigned int) (((value)->fld[0].rtwint)) >> bitsdone) & (((int) 1 << thissize) - 1)))

                                               ;
   else
     part = extract_fixed_bit_field (word_mode, value, 0, thissize,
         bitsdone, (rtx) 0, 1, align);
 }







      if (((op0)->code) == SUBREG)
 {
   word = operand_subword_force (((op0)->fld[0].rtx),
     ((op0)->fld[1].rtint) + offset,
     ((((op0)->fld[0].rtx))->mode));
   offset = 0;
 }
      else if (((op0)->code) == REG)
 {
   word = operand_subword_force (op0, offset, ((op0)->mode));
   offset = 0;
 }
      else
 word = op0;



      store_fixed_bit_field (word, offset * unit / 8,
        thissize, thispos, part, align);
      bitsdone += thissize;
    }
}
rtx
extract_bit_field(rtx str_rtx, register int bitsize, int bitnum, int unsignedp, rtx target, n64_enum_machine_mode mode, n64_enum_machine_mode tmode, int align, int total_size) asm("_extract_bit_field");
rtx
extract_bit_field(rtx str_rtx, register int bitsize, int bitnum, int unsignedp, rtx target, n64_enum_machine_mode mode, n64_enum_machine_mode tmode, int align, int total_size)
{
  int unit = (((str_rtx)->code) == MEM) ? 8 : ((target_flags & 0x00002000) ? 64 : 32);
  register int offset = bitnum / unit;
  register int bitpos = bitnum % unit;
  register rtx op0 = str_rtx;
  rtx spec_target = target;
  rtx spec_target_subreg = 0;

  if (((str_rtx)->code) == MEM && ! ((str_rtx)->in_struct))
    abort ();



  if (total_size >= 0)
    total_size -= (bitpos / 64
     * (64 / 8));

  if (tmode == VOIDmode)
    tmode = mode;
  while (((op0)->code) == SUBREG)
    {
      int outer_size = (8 * mode_size[(int)(((op0)->mode))]);
      int inner_size = (8 * mode_size[(int)(((((op0)->fld[0].rtx))->mode))]);

      offset += ((op0)->fld[1].rtint);

      if (((target_flags & 0x00010000) != 0) && (outer_size < inner_size))
 {
   bitpos += inner_size - outer_size;
   if (bitpos > unit)
     {
       offset += (bitpos / unit);
       bitpos %= unit;
     }
 }

      op0 = ((op0)->fld[0].rtx);
    }
  if (((target_flags & 0x00010000) != 0) &&
      ((op0)->code) != MEM
      && unit > (8 * mode_size[(int)(((op0)->mode))]))
    bitpos += unit - (8 * mode_size[(int)(((op0)->mode))]);







  if ((((op0)->code) == REG
       || (((op0)->code) == MEM
    && (! 1
        || (offset * 8 % bitsize == 0
     && align * 8 % bitsize == 0))))
      && ((bitsize >= ((target_flags & 0x00002000) ? 64 : 32) && bitsize == (8 * mode_size[(int)(mode)])
    && bitpos % ((target_flags & 0x00002000) ? 64 : 32) == 0)
   || (mode_for_size (bitsize, (mode_class[(int)(tmode)]), 0) != BLKmode
       && (((target_flags & 0x00010000) != 0)
    ? bitpos + bitsize == ((target_flags & 0x00002000) ? 64 : 32)
    : bitpos == 0))))
    {
      n64_enum_machine_mode mode1
 = mode_for_size (bitsize, (mode_class[(int)(tmode)]), 0);

      if (mode1 != ((op0)->mode))
 {
   if (((op0)->code) == REG)
     op0 = gen_rtx (SUBREG, mode1, op0, offset);
   else
     op0 = change_address (op0, mode1,
      plus_constant_wide (((op0)->fld[0].rtx), (int) (offset)));
 }
      if (mode1 != mode)
 return convert_to_mode (tmode, op0, unsignedp);
      return op0;
    }



  if (bitsize > ((target_flags & 0x00002000) ? 64 : 32))
    {





      int nwords = (bitsize + (((target_flags & 0x00002000) ? 64 : 32) - 1)) / ((target_flags & 0x00002000) ? 64 : 32);
      int i;

      if (target == 0 || ((target)->code) != REG)
 target = gen_reg_rtx (mode);

      for (i = 0; i < nwords; i++)
 {



   int wordnum = (((target_flags & 0x00010000) != 0)
    ? (mode_size[(int)(((target)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4) - i - 1
    : i);

   int bit_offset = (((target_flags & 0x00010000) != 0)
       ? ((0) > (bitsize - (i + 1) * ((target_flags & 0x00002000) ? 64 : 32)) ? (0) : (bitsize - (i + 1) * ((target_flags & 0x00002000) ? 64 : 32)))
       : i * ((target_flags & 0x00002000) ? 64 : 32));
   rtx target_part = operand_subword (target, wordnum, 1, VOIDmode);
   rtx result_part
     = extract_bit_field (op0, ((((target_flags & 0x00002000) ? 64 : 32)) < (bitsize - i * ((target_flags & 0x00002000) ? 64 : 32)) ? (((target_flags & 0x00002000) ? 64 : 32)) : (bitsize - i * ((target_flags & 0x00002000) ? 64 : 32)))
                                    ,
     bitnum + bit_offset,
     1, target_part, mode, word_mode,
     align, total_size);

   if (target_part == 0)
     abort ();

   if (result_part != target_part)
     emit_move_insn (target_part, result_part);
 }

      if (unsignedp)
 {


   if ((mode_size[(int)(((target)->mode))]) > nwords * ((target_flags & 0x00002000) ? 8 : 4))
     {
       int i,total_words;

       total_words = (mode_size[(int)(((target)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4);
       for (i = nwords; i < total_words; i++)
  {
    int wordnum = ((target_flags & 0x00010000) != 0) ? total_words - i - 1 : i;
    rtx target_part = operand_subword (target, wordnum, 1, VOIDmode);
    emit_move_insn (target_part, const0_rtx);
  }
     }
   return target;
 }


      target = expand_shift (LSHIFT_EXPR, mode, target,
        build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - bitsize), (int) (0)),
        (rtx) 0, 0);
      return expand_shift (RSHIFT_EXPR, mode, target,
      build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - bitsize), (int) (0)),
      (rtx) 0, 0);
    }
  if (((op0)->code) == REG)
    {
      if (offset != 0
   || (mode_size[(int)(((op0)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 op0 = gen_rtx (SUBREG, ((type_for_size (((target_flags & 0x00002000) ? 64 : 32), 0))->type.mode),
         op0, offset);
      offset = 0;
    }
  else
    {
      op0 = protect_from_queue (str_rtx, 1);
    }



  if (unsignedp)
    {

      if (1
   && ((8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_extzv][0])])
       >= bitsize)
   && ! ((((op0)->code) == REG || ((op0)->code) == SUBREG)
  && (bitsize + bitpos
      > (8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_extzv][0])]))))
 {
   int xbitpos = bitpos, xoffset = offset;
   rtx bitsize_rtx, bitpos_rtx;
   rtx last = get_last_insn();
   rtx xop0 = op0;
   rtx xtarget = target;
   rtx xspec_target = spec_target;
   rtx xspec_target_subreg = spec_target_subreg;
   rtx pat;
   n64_enum_machine_mode maxmode
     = insn_operand_mode[(int) CODE_FOR_extzv][0];

   if (((xop0)->code) == MEM)
     {
       int save_volatile_ok = volatile_ok;
       volatile_ok = 1;


       if (flag_force_mem
    || ! ((*insn_operand_predicate[(int) CODE_FOR_extzv][1])
   (xop0, ((xop0)->mode))))
  {

    n64_enum_machine_mode bestmode;







    if (((xop0)->mode) == BLKmode
        || ((mode_size[(int)(((op0)->mode))])
     > (mode_size[(int)(maxmode)])))
      bestmode = get_best_mode (bitsize, bitnum,
           align * 8, maxmode,
           ((xop0)->volatil));
    else
      bestmode = ((xop0)->mode);

    if (bestmode == VOIDmode
        || (1 && (mode_size[(int)(bestmode)]) > align))
      goto extzv_loses;



    unit = (8 * mode_size[(int)(bestmode)]);
    xoffset = (bitnum / unit) * (mode_size[(int)(bestmode)]);
    xbitpos = bitnum % unit;
    xop0 = change_address (xop0, bestmode,
      plus_constant_wide (((xop0)->fld[0].rtx), (int) (xoffset))
               );

    xop0 = force_reg (bestmode, xop0);


  }
       else

  xop0 = change_address (xop0, byte_mode,
           plus_constant_wide (((xop0)->fld[0].rtx), (int) (xoffset)));

       volatile_ok = save_volatile_ok;
     }



   if (((xop0)->code) == SUBREG && ((xop0)->mode) != maxmode)
     abort ();
   if (((xop0)->code) == REG && ((xop0)->mode) != maxmode)
     xop0 = gen_rtx (SUBREG, maxmode, xop0, 0);



   if (0 != ((target_flags & 0x00010000) != 0))
     xbitpos = unit - bitsize - xbitpos;


   if (0 && ((xop0)->code) != MEM)
     xbitpos += (8 * mode_size[(int)(maxmode)]) - unit;

   unit = (8 * mode_size[(int)(maxmode)]);

   if (xtarget == 0
       || (flag_force_mem && ((xtarget)->code) == MEM))
     xtarget = xspec_target = gen_reg_rtx (tmode);

   if (((xtarget)->mode) != maxmode)
     {
       if (((xtarget)->code) == REG)
  {
    int wider = ((mode_size[(int)(maxmode)])
          > (mode_size[(int)(((xtarget)->mode))]));
    xtarget = gen_lowpart (maxmode, xtarget);
    if (wider)
      xspec_target_subreg = xtarget;
  }
       else
  xtarget = gen_reg_rtx (maxmode);
     }



   if (! ((*insn_operand_predicate[(int) CODE_FOR_extzv][0])
   (xtarget, maxmode)))
     xtarget = gen_reg_rtx (maxmode);

   bitsize_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (bitsize));
   bitpos_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (xbitpos));

   pat = gen_extzv (protect_from_queue (xtarget, 1),
      xop0, bitsize_rtx, bitpos_rtx);
   if (pat)
     {
       emit_insn (pat);
       target = xtarget;
       spec_target = xspec_target;
       spec_target_subreg = xspec_target_subreg;
     }
   else
     {
       delete_insns_since (last);
       target = extract_fixed_bit_field (tmode, op0, offset, bitsize,
      bitpos, target, 1, align);
     }
 }
      else
        extzv_loses:

 target = extract_fixed_bit_field (tmode, op0, offset, bitsize, bitpos,
       target, 1, align);
    }
  else
    {

      if (1
   && ((8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_extv][0])])
       >= bitsize)
   && ! ((((op0)->code) == REG || ((op0)->code) == SUBREG)
  && (bitsize + bitpos
      > (8 * mode_size[(int)(insn_operand_mode[(int) CODE_FOR_extv][0])]))))
 {
   int xbitpos = bitpos, xoffset = offset;
   rtx bitsize_rtx, bitpos_rtx;
   rtx last = get_last_insn();
   rtx xop0 = op0, xtarget = target;
   rtx xspec_target = spec_target;
   rtx xspec_target_subreg = spec_target_subreg;
   rtx pat;
   n64_enum_machine_mode maxmode
     = insn_operand_mode[(int) CODE_FOR_extv][0];

   if (((xop0)->code) == MEM)
     {

       if (! ((*insn_operand_predicate[(int) CODE_FOR_extv][1])
       (xop0, ((xop0)->mode))))
  {

    n64_enum_machine_mode bestmode;







    if (((xop0)->mode) == BLKmode
        || ((mode_size[(int)(((op0)->mode))])
     > (mode_size[(int)(maxmode)])))
      bestmode = get_best_mode (bitsize, bitnum,
           align * 8, maxmode,
           ((xop0)->volatil));
    else
      bestmode = ((xop0)->mode);

    if (bestmode == VOIDmode
        || (1 && (mode_size[(int)(bestmode)]) > align))
      goto extv_loses;



    unit = (8 * mode_size[(int)(bestmode)]);
    xoffset = (bitnum / unit) * (mode_size[(int)(bestmode)]);
    xbitpos = bitnum % unit;
    xop0 = change_address (xop0, bestmode,
      plus_constant_wide (((xop0)->fld[0].rtx), (int) (xoffset))
               );

    xop0 = force_reg (bestmode, xop0);


  }
       else

  xop0 = change_address (xop0, byte_mode,
           plus_constant_wide (((xop0)->fld[0].rtx), (int) (xoffset)));
     }



   if (((xop0)->code) == SUBREG && ((xop0)->mode) != maxmode)
     abort ();
   if (((xop0)->code) == REG && ((xop0)->mode) != maxmode)
     xop0 = gen_rtx (SUBREG, maxmode, xop0, 0);



   if (0 != ((target_flags & 0x00010000) != 0))
     xbitpos = unit - bitsize - xbitpos;



   if (0 && ((xop0)->code) != MEM)
     xbitpos += ((8 * mode_size[(int)(maxmode)]) - unit);

   unit = (8 * mode_size[(int)(maxmode)]);

   if (xtarget == 0
       || (flag_force_mem && ((xtarget)->code) == MEM))
     xtarget = xspec_target = gen_reg_rtx (tmode);

   if (((xtarget)->mode) != maxmode)
     {
       if (((xtarget)->code) == REG)
  {
    int wider = ((mode_size[(int)(maxmode)])
          > (mode_size[(int)(((xtarget)->mode))]));
    xtarget = gen_lowpart (maxmode, xtarget);
    if (wider)
      xspec_target_subreg = xtarget;
  }
       else
  xtarget = gen_reg_rtx (maxmode);
     }



   if (! ((*insn_operand_predicate[(int) CODE_FOR_extv][0])
   (xtarget, maxmode)))
     xtarget = gen_reg_rtx (maxmode);

   bitsize_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (bitsize));
   bitpos_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (xbitpos));

   pat = gen_extv (protect_from_queue (xtarget, 1),
     xop0, bitsize_rtx, bitpos_rtx);
   if (pat)
     {
       emit_insn (pat);
       target = xtarget;
       spec_target = xspec_target;
       spec_target_subreg = xspec_target_subreg;
     }
   else
     {
       delete_insns_since (last);
       target = extract_fixed_bit_field (tmode, op0, offset, bitsize,
      bitpos, target, 0, align);
     }
 }
      else
 extv_loses:

 target = extract_fixed_bit_field (tmode, op0, offset, bitsize, bitpos,
       target, 0, align);
    }
  if (target == spec_target)
    return target;
  if (target == spec_target_subreg)
    return spec_target;
  if (((target)->mode) != tmode && ((target)->mode) != mode)
    {



      if ((mode_class[(int)(tmode)]) == MODE_FLOAT)
 {
   target = convert_to_mode (mode_for_size ((8 * mode_size[(int)(tmode)]),
         MODE_INT, 0),
        target, unsignedp);
   if (((target)->code) != REG)
     target = copy_to_reg (target);
   return gen_rtx (SUBREG, tmode, target, 0);
 }
      else
 return convert_to_mode (tmode, target, unsignedp);
    }
  return target;
}
static rtx
extract_fixed_bit_field(n64_enum_machine_mode tmode, register rtx op0, register int offset, register int bitsize, register int bitpos, register rtx target, int unsignedp, int align) asm("_extract_fixed_bit_field");
static rtx
extract_fixed_bit_field(n64_enum_machine_mode tmode, register rtx op0, register int offset, register int bitsize, register int bitpos, register rtx target, int unsignedp, int align)
{
  int total_bits = ((target_flags & 0x00002000) ? 64 : 32);
  n64_enum_machine_mode mode;

  if (((op0)->code) == SUBREG || ((op0)->code) == REG)
    {

      if (bitsize + bitpos > ((target_flags & 0x00002000) ? 64 : 32))
 return extract_split_bit_field (op0, bitsize, bitpos,
     unsignedp, align);
    }
  else
    {




      mode = get_best_mode (bitsize, bitpos + offset * 8,
       align * 8, word_mode,
       ((op0)->code) == MEM && ((op0)->volatil));

      if (mode == VOIDmode)


 return extract_split_bit_field (op0, bitsize,
     bitpos + offset * 8,
     unsignedp, align);

      total_bits = (8 * mode_size[(int)(mode)]);




      if (bitpos >= total_bits)
 {
   offset += (bitpos / total_bits) * (total_bits / 8);
   bitpos -= ((bitpos / total_bits) * (total_bits / 8)
       * 8);
 }





      bitpos += (offset % (total_bits / 8)) * 8;
      offset -= (offset % (total_bits / 8));
      op0 = change_address (op0, mode,
       plus_constant_wide (((op0)->fld[0].rtx), (int) (offset)));
    }

  mode = ((op0)->mode);

  if (((target_flags & 0x00010000) != 0))
    {



      bitpos = total_bits - bitsize - bitpos;
    }




  if (unsignedp)
    {
      if (bitpos)
 {


   tree amount = build_int_2_wide ((int) (bitpos), (int) (0));


   rtx subtarget = (target != 0 && ((target)->code) == REG
      && !((target)->integrated)
      ? target : 0);
   if (tmode != mode) subtarget = 0;
   op0 = expand_shift (RSHIFT_EXPR, mode, op0, amount, subtarget, 1);
 }

      if (mode != tmode)
 op0 = convert_to_mode (tmode, op0, 1);




      if ((8 * mode_size[(int)(mode)]) != bitpos + bitsize
   )
 return expand_binop (((op0)->mode), and_optab, op0,
        mask_rtx (((op0)->mode), 0, bitsize, 0),
        target, 1, OPTAB_LIB_WIDEN);
      return op0;
    }



  op0 = force_reg (mode, op0);
  if (mode != tmode)
    target = 0;



  for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    if ((8 * mode_size[(int)(mode)]) >= bitsize + bitpos)
      {
 op0 = convert_to_mode (mode, op0, 0);
 break;
      }

  if ((8 * mode_size[(int)(mode)]) != (bitsize + bitpos))
    {
      tree amount = build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - (bitsize + bitpos)), (int) (0));


      rtx subtarget = (target != 0 && ((target)->code) == REG
         && ! ((target)->integrated)
         ? target : 0);
      op0 = expand_shift (LSHIFT_EXPR, mode, op0, amount, subtarget, 1);
    }

  return expand_shift (RSHIFT_EXPR, mode, op0,
         build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - bitsize), (int) (0)),
         target, 0);
}







static rtx
mask_rtx(n64_enum_machine_mode mode, int bitpos, int bitsize, int complement) asm("_mask_rtx");
static rtx
mask_rtx(n64_enum_machine_mode mode, int bitpos, int bitsize, int complement)
{
  int masklow, maskhigh;

  if (bitpos < 32)
    masklow = (int) -1 << bitpos;
  else
    masklow = 0;

  if (bitpos + bitsize < 32)
    masklow &= ((unsigned int) -1
  >> (32 - bitpos - bitsize));

  if (bitpos <= 32)
    maskhigh = -1;
  else
    maskhigh = (int) -1 << (bitpos - 32);

  if (bitpos + bitsize > 32)
    maskhigh &= ((unsigned int) -1
   >> (2 * 32 - bitpos - bitsize));
  else
    maskhigh = 0;

  if (complement)
    {
      maskhigh = ~maskhigh;
      masklow = ~masklow;
    }

  return immed_double_const (masklow, maskhigh, mode);
}




static rtx
lshift_value(n64_enum_machine_mode mode, rtx value, int bitpos, int bitsize) asm("_lshift_value");
static rtx
lshift_value(n64_enum_machine_mode mode, rtx value, int bitpos, int bitsize)
{
  unsigned int v = ((value)->fld[0].rtwint);
  int low, high;

  if (bitsize < 32)
    v &= ~((int) -1 << bitsize);

  if (bitpos < 32)
    {
      low = v << bitpos;
      high = (bitpos > 0 ? (v >> (32 - bitpos)) : 0);
    }
  else
    {
      low = 0;
      high = v << (bitpos - 32);
    }

  return immed_double_const (low, high, mode);
}
static rtx
extract_split_bit_field(rtx op0, int bitsize, int bitpos, int unsignedp, int align) asm("_extract_split_bit_field");
static rtx
extract_split_bit_field(rtx op0, int bitsize, int bitpos, int unsignedp, int align)
{
  int unit;
  int bitsdone = 0;
  rtx result;
  int first = 1;



  if (((op0)->code) == REG || ((op0)->code) == SUBREG)
    unit = ((target_flags & 0x00002000) ? 64 : 32);
  else
    unit = ((align * 8) < (((target_flags & 0x00002000) ? 64 : 32)) ? (align * 8) : (((target_flags & 0x00002000) ? 64 : 32)));

  while (bitsdone < bitsize)
    {
      int thissize;
      rtx part, word;
      int thispos;
      int offset;

      offset = (bitpos + bitsdone) / unit;
      thispos = (bitpos + bitsdone) % unit;




      thissize = ((bitsize - bitsdone) < (((target_flags & 0x00002000) ? 64 : 32)) ? (bitsize - bitsdone) : (((target_flags & 0x00002000) ? 64 : 32)));
      thissize = ((thissize) < (unit - thispos) ? (thissize) : (unit - thispos));







      if (((op0)->code) == SUBREG)
 {
   word = operand_subword_force (((op0)->fld[0].rtx),
     ((op0)->fld[1].rtint) + offset,
     ((((op0)->fld[0].rtx))->mode));
   offset = 0;
 }
      else if (((op0)->code) == REG)
 {
   word = operand_subword_force (op0, offset, ((op0)->mode));
   offset = 0;
 }
      else
 word = op0;





      part = extract_fixed_bit_field (word_mode, word,
          offset * unit / 8,
          thissize, thispos, 0, 1, align);
      bitsdone += thissize;


      if (((target_flags & 0x00010000) != 0))
 {
   if (bitsize != bitsdone)
     part = expand_shift (LSHIFT_EXPR, word_mode, part,
     build_int_2_wide ((int) (bitsize - bitsdone), (int) (0)), 0, 1);
 }
      else
 {
   if (bitsdone != thissize)
     part = expand_shift (LSHIFT_EXPR, word_mode, part,
     build_int_2_wide ((int) (bitsdone - thissize), (int) (0)), 0, 1);
 }

      if (first)
 result = part;
      else


 result = expand_binop (word_mode, ior_optab, part, result, (rtx) 0, 1,
          OPTAB_LIB_WIDEN);

      first = 0;
    }


  if (unsignedp)
    return result;

  result = expand_shift (LSHIFT_EXPR, word_mode, result,
    build_int_2_wide ((int) (((target_flags & 0x00002000) ? 64 : 32) - bitsize), (int) (0)),
    (rtx) 0, 0);
  return expand_shift (RSHIFT_EXPR, word_mode, result,
         build_int_2_wide ((int) (((target_flags & 0x00002000) ? 64 : 32) - bitsize), (int) (0)), (rtx) 0, 0);
}



void
expand_inc(rtx target, rtx inc) asm("_expand_inc");
void
expand_inc(rtx target, rtx inc)
{
  rtx value = expand_binop (((target)->mode), add_optab,
       target, inc,
       target, 0, OPTAB_LIB_WIDEN);
  if (value != target)
    emit_move_insn (target, value);
}



void
expand_dec(rtx target, rtx dec) asm("_expand_dec");
void
expand_dec(rtx target, rtx dec)
{
  rtx value = expand_binop (((target)->mode), sub_optab,
       target, dec,
       target, 0, OPTAB_LIB_WIDEN);
  if (value != target)
    emit_move_insn (target, value);
}
rtx
expand_shift(n64_enum_tree_code code, register n64_enum_machine_mode mode, rtx shifted, tree amount, register rtx target, int unsignedp) asm("_expand_shift");
rtx
expand_shift(n64_enum_tree_code code, register n64_enum_machine_mode mode, rtx shifted, tree amount, register rtx target, int unsignedp)
{
  register rtx op1, temp = 0;
  register int left = (code == LSHIFT_EXPR || code == LROTATE_EXPR);
  register int rotate = (code == LROTATE_EXPR || code == RROTATE_EXPR);
  int cxx_try;





  op1 = expand_expr (amount, (rtx) 0, VOIDmode, 0);


  if (1
      && ((op1)->code) == CONST_INT
      && (unsigned int) ((op1)->fld[0].rtwint) >= (8 * mode_size[(int)(mode)]))
    op1 = gen_rtx (CONST_INT, VOIDmode, (int) ((unsigned int) ((op1)->fld[0].rtwint) % (8 * mode_size[(int)(mode)])))
                               ;


  if (op1 == const0_rtx)
    return shifted;

  for (cxx_try = 0; temp == 0 && cxx_try < 3; cxx_try++)
    {
      n64_enum_optab_methods methods;

      if (cxx_try == 0)
 methods = OPTAB_DIRECT;
      else if (cxx_try == 1)
 methods = OPTAB_WIDEN;
      else
 methods = OPTAB_LIB_WIDEN;

      if (rotate)
 {

   if (methods == OPTAB_WIDEN)
     continue;
   else if (methods == OPTAB_LIB_WIDEN)
     {
       rtx subtarget = target == shifted ? 0 : target;
       rtx temp1;
       tree type = ((amount)->common.type);
       tree new_amount = make_tree (type, op1);
       tree other_amount
  = fold (build (MINUS_EXPR, type,
          convert (type,
     build_int_2_wide ((int) ((8 * mode_size[(int)(mode)])), (int) (0))
             ),
          amount));

       shifted = force_reg (mode, shifted);

       temp = expand_shift (left ? LSHIFT_EXPR : RSHIFT_EXPR,
       mode, shifted, new_amount, subtarget, 1);
       temp1 = expand_shift (left ? RSHIFT_EXPR : LSHIFT_EXPR,
        mode, shifted, other_amount, 0, 1);
       return expand_binop (mode, ior_optab, temp, temp1, target,
       unsignedp, methods);
     }

   temp = expand_binop (mode,
          left ? rotl_optab : rotr_optab,
          shifted, op1, target, unsignedp, methods);




   if (temp == 0 && ((op1)->code) == CONST_INT
       && ((op1)->fld[0].rtwint) > 0 && ((op1)->fld[0].rtwint) < (8 * mode_size[(int)(mode)]))
     temp = expand_binop (mode,
     left ? rotr_optab : rotl_optab,
     shifted,
     gen_rtx (CONST_INT, VOIDmode, (int) ((8 * mode_size[(int)(mode)]) - ((op1)->fld[0].rtwint)))
                      ,
     target, unsignedp, methods);
 }
      else if (unsignedp)
 temp = expand_binop (mode,
        left ? ashl_optab : lshr_optab,
        shifted, op1, target, unsignedp, methods);




      if (temp == 0 && ! rotate
   && (! unsignedp || (! left && methods == OPTAB_WIDEN)))
 {
   n64_enum_optab_methods methods1 = methods;



   if (unsignedp)
     methods1 = OPTAB_MUST_WIDEN;



   temp = expand_binop (mode,
          left ? ashl_optab : ashr_optab,
          shifted, op1, target, unsignedp, methods1);
 }





    }

  if (temp == 0)
    abort ();
  return temp;
}

enum n64_cpp_enum_alg_code{ alg_zero, alg_m, alg_shift,
    alg_add_t_m2, alg_sub_t_m2,
    alg_add_factor, alg_sub_factor,
    alg_add_t2_m, alg_sub_t2_m,
    alg_add, alg_subtract, alg_factor, alg_shiftop };
typedef __underlying_type(enum n64_cpp_enum_alg_code) n64_enum_alg_code;

struct n64_tag_algorithm
{
  short cost;
  short ops;





  n64_enum_alg_code op[64];
  char log[64];
};






static void
synth_mult(struct n64_tag_algorithm *alg_out, unsigned int t, int cost_limit) asm("_synth_mult");
static void
synth_mult(struct n64_tag_algorithm *alg_out, unsigned int t, int cost_limit)
{
  int m;
  struct n64_tag_algorithm *alg_in, *best_alg;
  unsigned int cost;
  unsigned int q;



  alg_out->cost = cost_limit;

  if (cost_limit <= 0)
    return;


  if (t == 1)
    {
      alg_out->ops = 1;
      alg_out->cost = 0;
      alg_out->op[0] = alg_m;
      return;
    }



  if (t == 0)
    {
      if (zero_cost >= cost_limit)
 return;
      else
 {
   alg_out->ops = 1;
   alg_out->cost = zero_cost;
   alg_out->op[0] = alg_zero;
   return;
 }
    }



  alg_in = (struct n64_tag_algorithm *)
                              __builtin_alloca((
                              sizeof (struct n64_tag_algorithm)
                              ))
                                                                ;
  best_alg = (struct n64_tag_algorithm *)
                                __builtin_alloca((
                                sizeof (struct n64_tag_algorithm)
                                ))
                                                                  ;




  if ((t & 1) == 0)
    {
      m = floor_log2_wide ((int) (t & -t));
      q = t >> m;
      cost = shift_cost[m];
      synth_mult (alg_in, q, cost_limit - cost);

      cost += alg_in->cost;
      if (cost < cost_limit)
 {
   struct n64_tag_algorithm *x;
   x = alg_in, alg_in = best_alg, best_alg = x;
   best_alg->log[best_alg->ops] = m;
   best_alg->op[best_alg->ops] = alg_shift;
   cost_limit = cost;
 }
    }


  if ((t & 1) != 0)
    {
      unsigned int w;

      for (w = 1; (w & t) != 0; w <<= 1)
 ;
      if (w > 2


   && t != 3)
 {


   cost = add_cost;
   synth_mult (alg_in, t + 1, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = 0;
       best_alg->op[best_alg->ops] = alg_sub_t_m2;
       cost_limit = cost;
     }
 }
      else
 {


   cost = add_cost;
   synth_mult (alg_in, t - 1, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = 0;
       best_alg->op[best_alg->ops] = alg_add_t_m2;
       cost_limit = cost;
     }
 }
    }
  for (m = floor_log2_wide ((int) (t - 1)); m >= 2; m--)
    {
      unsigned int d;

      d = ((unsigned int) 1 << m) + 1;
      if (t % d == 0 && t > d)
 {
   cost = ((shiftadd_cost[m]) < (add_cost + shift_cost[m]) ? (shiftadd_cost[m]) : (add_cost + shift_cost[m]));
   synth_mult (alg_in, t / d, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = m;
       best_alg->op[best_alg->ops] = alg_add_factor;
       cost_limit = cost;
     }

   break;
 }

      d = ((unsigned int) 1 << m) - 1;
      if (t % d == 0 && t > d)
 {
   cost = ((shiftsub_cost[m]) < (add_cost + shift_cost[m]) ? (shiftsub_cost[m]) : (add_cost + shift_cost[m]));
   synth_mult (alg_in, t / d, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = m;
       best_alg->op[best_alg->ops] = alg_sub_factor;
       cost_limit = cost;
     }
   break;
 }
    }



  if ((t & 1) != 0)
    {
      q = t - 1;
      q = q & -q;
      m = exact_log2_wide ((int) (q));
      if (m >= 0)
 {
   cost = shiftadd_cost[m];
   synth_mult (alg_in, (t - 1) >> m, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = m;
       best_alg->op[best_alg->ops] = alg_add_t2_m;
       cost_limit = cost;
     }
 }

      q = t + 1;
      q = q & -q;
      m = exact_log2_wide ((int) (q));
      if (m >= 0)
 {
   cost = shiftsub_cost[m];
   synth_mult (alg_in, (t + 1) >> m, cost_limit - cost);

   cost += alg_in->cost;
   if (cost < cost_limit)
     {
       struct n64_tag_algorithm *x;
       x = alg_in, alg_in = best_alg, best_alg = x;
       best_alg->log[best_alg->ops] = m;
       best_alg->op[best_alg->ops] = alg_sub_t2_m;
       cost_limit = cost;
     }
 }
    }



  if (cost_limit == alg_out->cost)
    return;



  if (best_alg->ops == 64)
    return;




  alg_out->ops = best_alg->ops + 1;
  alg_out->cost = cost_limit;
  memcpy ((char *) alg_out->op,(char *) best_alg->op,alg_out->ops * sizeof *alg_out->op)
                                     ;
  memcpy ((char *) alg_out->log,(char *) best_alg->log,alg_out->ops * sizeof *alg_out->log)
                                      ;
}
rtx
expand_mult(n64_enum_machine_mode mode, register rtx op0, register rtx op1, register rtx target, int unsignedp) asm("_expand_mult");
rtx
expand_mult(n64_enum_machine_mode mode, register rtx op0, register rtx op1, register rtx target, int unsignedp)
{
  rtx const_op1 = op1;
  if (((op1)->code) == CONST_DOUBLE
      && (mode_class[(int)(((op1)->mode))]) == MODE_INT
      && 32 >= ((target_flags & 0x00002000) ? 64 : 32)
      && ((op1)->fld[3].rtwint) == 0)
    const_op1 = gen_rtx (CONST_INT, VOIDmode, (int) (((op1)->fld[2].rtwint)));
  else if (32 < (8 * mode_size[(int)(mode)])
    && ((op1)->code) == CONST_INT
    && ((op1)->fld[0].rtwint) < 0)
    const_op1 = 0;






  if (const_op1 && ((const_op1)->code) == CONST_INT)
    {
      struct n64_tag_algorithm alg;
      struct n64_tag_algorithm alg2;
      int val = ((op1)->fld[0].rtwint);
      int val_so_far;
      rtx insn;
      int mult_cost;
      enum n64_cpp_enum_anonymous_20{basic_variant, negate_variant, add_variant};
typedef __underlying_type(enum n64_cpp_enum_anonymous_20) n64_enum_anonymous_20;
n64_enum_anonymous_20 variant = basic_variant;





      mult_cost = rtx_cost (gen_rtx (MULT, mode, op0, op1), SET);
      mult_cost = ((12 * add_cost) < (mult_cost) ? (12 * add_cost) : (mult_cost));

      synth_mult (&alg, val, mult_cost);



      if (32 >= (8 * mode_size[(int)(mode)]))
 {
   synth_mult (&alg2, - val,
        (alg.cost < mult_cost ? alg.cost : mult_cost) - negate_cost);
   if (alg2.cost + negate_cost < alg.cost)
     alg = alg2, variant = negate_variant;
 }


      synth_mult (&alg2, val - 1,
    (alg.cost < mult_cost ? alg.cost : mult_cost) - add_cost);
      if (alg2.cost + add_cost < alg.cost)
 alg = alg2, variant = add_variant;

      if (alg.cost < mult_cost)
 {

   int opno;
   rtx accum, tem;

   op0 = protect_from_queue (op0, 0);



   if (((op0)->code) == MEM)
     op0 = force_reg (mode, op0);




   if (alg.op[0] == alg_zero)
     {
       accum = copy_to_mode_reg (mode, const0_rtx);
       val_so_far = 0;
     }
   else if (alg.op[0] == alg_m)
     {
       accum = copy_to_mode_reg (mode, op0);
       val_so_far = 1;
     }
   else
     abort ();

   for (opno = 1; opno < alg.ops; opno++)
     {
       int log = alg.log[opno];
       int preserve = preserve_subexpressions_p ();
       rtx shift_subtarget = preserve ? 0 : accum;
       rtx add_target
  = (opno == alg.ops - 1 && target != 0 && variant != add_variant
    ? target : 0);
       rtx accum_target = preserve ? 0 : accum;

       switch (alg.op[opno])
  {
  case alg_shift:
    accum = expand_shift (LSHIFT_EXPR, mode, accum,
     build_int_2_wide ((int) (log), (int) (0)), (rtx) 0, 0);
    val_so_far <<= log;
    break;

  case alg_add_t_m2:
    tem = expand_shift (LSHIFT_EXPR, mode, op0,
          build_int_2_wide ((int) (log), (int) (0)), (rtx) 0, 0);
    accum = force_operand (gen_rtx (PLUS, mode, accum, tem),
      add_target ? add_target : accum_target);
    val_so_far += (int) 1 << log;
    break;

  case alg_sub_t_m2:
    tem = expand_shift (LSHIFT_EXPR, mode, op0,
          build_int_2_wide ((int) (log), (int) (0)), (rtx) 0, 0);
    accum = force_operand (gen_rtx (MINUS, mode, accum, tem),
      add_target ? add_target : accum_target);
    val_so_far -= (int) 1 << log;
    break;

  case alg_add_t2_m:
    accum = expand_shift (LSHIFT_EXPR, mode, accum,
     build_int_2_wide ((int) (log), (int) (0)), shift_subtarget,
     0);
    accum = force_operand (gen_rtx (PLUS, mode, accum, op0),
      add_target ? add_target : accum_target);
    val_so_far = (val_so_far << log) + 1;
    break;

  case alg_sub_t2_m:
    accum = expand_shift (LSHIFT_EXPR, mode, accum,
     build_int_2_wide ((int) (log), (int) (0)), shift_subtarget,
     0);
    accum = force_operand (gen_rtx (MINUS, mode, accum, op0),
      add_target ? add_target : accum_target);
    val_so_far = (val_so_far << log) - 1;
    break;

  case alg_add_factor:
    tem = expand_shift (LSHIFT_EXPR, mode, accum,
          build_int_2_wide ((int) (log), (int) (0)), (rtx) 0, 0);
    accum = force_operand (gen_rtx (PLUS, mode, accum, tem),
      add_target ? add_target : accum_target);
    val_so_far += val_so_far << log;
    break;

  case alg_sub_factor:
    tem = expand_shift (LSHIFT_EXPR, mode, accum,
          build_int_2_wide ((int) (log), (int) (0)), (rtx) 0, 0);
    accum = force_operand (gen_rtx (MINUS, mode, tem, accum),
      (add_target ? add_target
       : preserve ? 0 : tem));
    val_so_far = (val_so_far << log) - val_so_far;
    break;

  default:
    abort ();;
  }




       insn = get_last_insn ();
       ((insn)->fld[6].rtx)
  = gen_rtx (EXPR_LIST, REG_EQUAL,
      gen_rtx (MULT, mode, op0, gen_rtx (CONST_INT, VOIDmode, (int) (val_so_far))),
      ((insn)->fld[6].rtx));
     }

   if (variant == negate_variant)
     {
       val_so_far = - val_so_far;
       accum = expand_unop (mode, neg_optab, accum, target, 0);
     }
   else if (variant == add_variant)
     {
       val_so_far = val_so_far + 1;
       accum = force_operand (gen_rtx (PLUS, mode, accum, op0), target);
     }

   if (val != val_so_far)
     abort ();

   return accum;
 }
    }



  op0 = expand_binop (mode, smul_optab,
        op0, op1, target, unsignedp, OPTAB_LIB_WIDEN);
  if (op0 == 0)
    abort ();
  return op0;
}



int
ceil_log2(unsigned int x) asm("_ceil_log2");
int
ceil_log2(unsigned int x)
{
  return floor_log2_wide ((int) (x - 1)) + 1;
}
static
unsigned int
choose_multiplier(unsigned int d, int n, int precision, unsigned int *multiplier_ptr, int *post_shift_ptr, int *lgup_ptr) asm("_choose_multiplier");
unsigned int
choose_multiplier(unsigned int d, int n, int precision, unsigned int *multiplier_ptr, int *post_shift_ptr, int *lgup_ptr)
{
  unsigned int mhigh_hi, mhigh_lo;
  unsigned int mlow_hi, mlow_lo;
  int lgup, post_shift;
  int pow, pow2;
  unsigned int nh, nl, dummy1, dummy2;


  lgup = ceil_log2 (d);

  if (lgup > n)
    abort ();

  pow = n + lgup;
  pow2 = n + lgup - precision;

  if (pow == 2 * 32)
    {


      abort ();
    }


 if (pow >= 32)
    {
      nh = (unsigned int) 1 << (pow - 32);
      nl = 0;
    }
  else
    {
      nh = 0;
      nl = (unsigned int) 1 << pow;
    }
  div_and_round_double (TRUNC_DIV_EXPR, 1, nl, nh, d, (int) 0,
   &mlow_lo, &mlow_hi, &dummy1, &dummy2);


  if (pow2 >= 32)
    nh |= (unsigned int) 1 << (pow2 - 32);
  else
    nl |= (unsigned int) 1 << pow2;
  div_and_round_double (TRUNC_DIV_EXPR, 1, nl, nh, d, (int) 0,
   &mhigh_lo, &mhigh_hi, &dummy1, &dummy2);

  if (mhigh_hi && nh - d >= d)
    abort ();
  if (mhigh_hi > 1 || mlow_hi > 1)
    abort ();

  if (! (mlow_hi < mhigh_hi || (mlow_hi == mhigh_hi && mlow_lo < mhigh_lo)))
    abort();





  for (post_shift = lgup; post_shift > 0; post_shift--)
    {
      unsigned int ml_lo = (mlow_hi << (32 - 1)) | (mlow_lo >> 1);
      unsigned int mh_lo = (mhigh_hi << (32 - 1)) | (mhigh_lo >> 1);
      if (ml_lo >= mh_lo)
 break;

      mlow_hi = 0;
      mlow_lo = ml_lo;
      mhigh_hi = 0;
      mhigh_lo = mh_lo;
    }

  *post_shift_ptr = post_shift;
  *lgup_ptr = lgup;
  if (n < 32)
    {
      unsigned int mask = ((unsigned int) 1 << n) - 1;
      *multiplier_ptr = mhigh_lo & mask;
      return mhigh_lo >= mask;
    }
  else
    {
      *multiplier_ptr = mhigh_lo;
      return mhigh_hi;
    }
}




static unsigned int
invert_mod2n(unsigned int x, int n) asm("_invert_mod2n");
static unsigned int
invert_mod2n(unsigned int x, int n)
{






  unsigned int mask;
  unsigned int y = x;
  int nbit = 3;

  mask = (n == 32
   ? ~(unsigned int) 0
   : ((unsigned int) 1 << n) - 1);

  while (nbit < n)
    {
      y = y * (2 - x*y) & mask;
      nbit *= 2;
    }
  return y;
}
rtx
expand_mult_highpart_adjust(n64_enum_machine_mode mode, register rtx adj_operand, register rtx op0, register rtx op1, register rtx target, int unsignedp) asm("_expand_mult_highpart_adjust");
rtx
expand_mult_highpart_adjust(n64_enum_machine_mode mode, register rtx adj_operand, register rtx op0, register rtx op1, register rtx target, int unsignedp)
{
  rtx tem;
  n64_enum_rtx_code adj_code = unsignedp ? PLUS : MINUS;

  tem = expand_shift (RSHIFT_EXPR, mode, op0,
        build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - 1), (int) (0)),
        (rtx) 0, 0);
  tem = expand_and (tem, op1, (rtx) 0);
  adj_operand = force_operand (gen_rtx (adj_code, mode, adj_operand, tem),
          adj_operand);

  tem = expand_shift (RSHIFT_EXPR, mode, op1,
        build_int_2_wide ((int) ((8 * mode_size[(int)(mode)]) - 1), (int) (0)),
        (rtx) 0, 0);
  tem = expand_and (tem, op0, (rtx) 0);
  target = force_operand (gen_rtx (adj_code, mode, adj_operand, tem), target);

  return target;
}
rtx
expand_mult_highpart(n64_enum_machine_mode mode, register rtx op0, unsigned int cnst1, register rtx target, int unsignedp, int max_cost) asm("_expand_mult_highpart");
rtx
expand_mult_highpart(n64_enum_machine_mode mode, register rtx op0, unsigned int cnst1, register rtx target, int unsignedp, int max_cost)
{
  n64_enum_machine_mode wider_mode = (mode_wider_mode[(int)(mode)]);
  optab mul_highpart_optab;
  optab moptab;
  rtx tem;
  int size = (8 * mode_size[(int)(mode)]);
  rtx op1, wide_op1;


  if (size > 32)
    abort ();

  op1 = gen_rtx (CONST_INT, VOIDmode, (int) (cnst1));

  if ((8 * mode_size[(int)(wider_mode)]) <= 32)
    wide_op1 = op1;
  else
    wide_op1
      = immed_double_const (cnst1,
       (unsignedp
        ? (int) 0
        : -(cnst1 >> (32 - 1))),
       wider_mode);



  if (size < ((target_flags & 0x00002000) ? 64 : 32)
      && mul_cost[(int) wider_mode] + shift_cost[size-1] < max_cost)
    {


      op0 = convert_to_mode (wider_mode, op0, unsignedp);

      tem = expand_mult (wider_mode, op0, wide_op1, (rtx) 0, unsignedp);
      tem = expand_shift (RSHIFT_EXPR, wider_mode, tem,
     build_int_2_wide ((int) (size), (int) (0)), (rtx) 0, 1);
      return convert_modes (mode, wider_mode, tem, unsignedp);
    }

  if (target == 0)
    target = gen_reg_rtx (mode);



  if (mul_highpart_cost[(int) mode] < max_cost)
    {
      mul_highpart_optab = unsignedp ? umul_highpart_optab : smul_highpart_optab;
      target = expand_binop (mode, mul_highpart_optab,
        op0, wide_op1, target, unsignedp, OPTAB_DIRECT);
      if (target)
 return target;
    }



  if (mul_highpart_cost[(int) mode] + 2 * shift_cost[size-1] + 4 * add_cost < max_cost)
    {
      mul_highpart_optab = unsignedp ? smul_highpart_optab : umul_highpart_optab;
      target = expand_binop (mode, mul_highpart_optab,
        op0, wide_op1, target, unsignedp, OPTAB_DIRECT);
      if (target)

 return expand_mult_highpart_adjust (mode, target, op0,
         op1, target, unsignedp);
    }


  moptab = unsignedp ? umul_widen_optab : smul_widen_optab;
  if (moptab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing
      && mul_widen_cost[(int) wider_mode] < max_cost)
    goto cxx_try;


  moptab = smul_optab;
  if (smul_optab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing
      && mul_cost[(int) wider_mode] + shift_cost[size-1] < max_cost)
    goto cxx_try;


  moptab = unsignedp ? smul_widen_optab : umul_widen_optab;
  if (moptab->handlers[(int) wider_mode].insn_code != CODE_FOR_nothing
      && (mul_widen_cost[(int) wider_mode]
   + 2 * shift_cost[size-1] + 4 * add_cost < max_cost))
    {
      tem = expand_binop (wider_mode, moptab, op0, wide_op1,
     (rtx) 0, ! unsignedp, OPTAB_WIDEN);
      if (tem != 0)
 {

   tem = expand_shift (RSHIFT_EXPR, wider_mode, tem,
         build_int_2_wide ((int) (size), (int) (0)), (rtx) 0, 1);
   tem = convert_modes (mode, wider_mode, tem, unsignedp);

   return expand_mult_highpart_adjust (mode, tem, op0, op1,
           target, unsignedp);
 }
    }

  return 0;

 cxx_try:

  tem = expand_binop (wider_mode, moptab, op0, wide_op1,
        (rtx) 0, unsignedp, OPTAB_WIDEN);
  if (tem == 0)
    return 0;


  tem = expand_shift (RSHIFT_EXPR, wider_mode, tem,
        build_int_2_wide ((int) (size), (int) (0)), (rtx) 0, 1);
  return convert_modes (mode, wider_mode, tem, unsignedp);
}
rtx
expand_divmod(int rem_flag, n64_enum_tree_code code, n64_enum_machine_mode mode, register rtx op0, register rtx op1, register rtx target, int unsignedp) asm("_expand_divmod");
rtx
expand_divmod(int rem_flag, n64_enum_tree_code code, n64_enum_machine_mode mode, register rtx op0, register rtx op1, register rtx target, int unsignedp)
{
  n64_enum_machine_mode compute_mode;
  register rtx tquotient;
  rtx quotient = 0, remainder = 0;
  rtx last;
  int size;
  rtx insn, set;
  optab optab1, optab2;
  int op1_is_constant, op1_is_pow2;
  int max_cost, extra_cost;

  op1_is_constant = ((op1)->code) == CONST_INT;
  op1_is_pow2 = (op1_is_constant
   && (((((((op1)->fld[0].rtwint)) & ((((op1)->fld[0].rtwint)) - 1)) == 0)
        || (((-((op1)->fld[0].rtwint)) & ((-((op1)->fld[0].rtwint)) - 1)) == 0))));
  if (op1 == const1_rtx)
    return rem_flag ? const0_rtx : op0;

  if (target



      && (((((target)->code) == REG) && ((target)->integrated))

   || ((rem_flag || op1_is_constant)
       && (reg_mentioned_p (target, op0)
    || (((op0)->code) == MEM && ((target)->code) == MEM)))
   || reg_mentioned_p (target, op1)
   || (((op1)->code) == MEM && ((target)->code) == MEM)))
    target = 0;
  optab1 = (op1_is_pow2 ? (unsignedp ? lshr_optab : ashr_optab)
     : (unsignedp ? udiv_optab : sdiv_optab));
  optab2 = (op1_is_pow2 ? optab1 : (unsignedp ? udivmod_optab : sdivmod_optab));

  for (compute_mode = mode; compute_mode != VOIDmode;
       compute_mode = (mode_wider_mode[(int)(compute_mode)]))
    if (optab1->handlers[(int) compute_mode].insn_code != CODE_FOR_nothing
 || optab2->handlers[(int) compute_mode].insn_code != CODE_FOR_nothing)
      break;

  if (compute_mode == VOIDmode)
    for (compute_mode = mode; compute_mode != VOIDmode;
  compute_mode = (mode_wider_mode[(int)(compute_mode)]))
      if (optab1->handlers[(int) compute_mode].libfunc
   || optab2->handlers[(int) compute_mode].libfunc)
 break;



  if (compute_mode == VOIDmode)
    compute_mode = mode;

  if (target && ((target)->mode) == compute_mode)
    tquotient = target;
  else
    tquotient = gen_reg_rtx (compute_mode);

  size = (8 * mode_size[(int)(compute_mode)]);







  max_cost = div_cost[(int) compute_mode]
    - (rem_flag ? mul_cost[(int) compute_mode] + add_cost : 0);


  if (compute_mode != mode)
    {
      op0 = convert_modes (compute_mode, mode, op0, unsignedp);
      op1 = convert_modes (compute_mode, mode, op1, unsignedp);
    }



  if (((op0)->code) == MEM && ((op0)->volatil))
    op0 = force_reg (compute_mode, op0);
  if (((op1)->code) == MEM && ((op1)->volatil))
    op1 = force_reg (compute_mode, op1);



  if (rem_flag || op1_is_constant)
    op0 = force_reg (compute_mode, op0);

  last = get_last_insn ();


  if (unsignedp)
    {
      if (code == FLOOR_DIV_EXPR)
 code = TRUNC_DIV_EXPR;
      if (code == FLOOR_MOD_EXPR)
 code = TRUNC_MOD_EXPR;
    }

  if (op1 != const0_rtx)
    switch (code)
      {
      case TRUNC_MOD_EXPR:
      case TRUNC_DIV_EXPR:
 if (op1_is_constant && 32 >= size)
   {
     if (unsignedp)
       {
  unsigned int mh, ml;
  int pre_shift, post_shift;
  int dummy;
  unsigned int d = ((op1)->fld[0].rtwint);

  if ((((d) & ((d) - 1)) == 0))
    {
      pre_shift = floor_log2_wide ((int) (d));
      if (rem_flag)
        {
   remainder = expand_binop (compute_mode, and_optab, op0,
        gen_rtx (CONST_INT, VOIDmode, (int) (((int) 1 << pre_shift) - 1)),
        remainder, 1,
        OPTAB_LIB_WIDEN);
   if (remainder)
     return gen_lowpart (mode, remainder);
        }
      quotient = expand_shift (RSHIFT_EXPR, compute_mode, op0,
          build_int_2_wide ((int) (pre_shift), (int) (0)),
          tquotient, 1);
    }
  else if (d >= ((unsigned int) 1 << (size - 1)))
    {



      quotient = emit_store_flag (tquotient, GEU, op0, op1,
      compute_mode, 1, 1);
      if (quotient == 0)
        goto fail1;
    }
  else
    {



      mh = choose_multiplier (d, size, size,
         &ml, &post_shift, &dummy);




      if (mh != 0 && (d & 1) == 0)
        {
   pre_shift = floor_log2_wide ((int) (d & -d));
   mh = choose_multiplier (d >> pre_shift, size,
      size - pre_shift,
      &ml, &post_shift, &dummy);
   if (mh)
     abort ();
        }
      else
        pre_shift = 0;

      if (mh != 0)
        {
   rtx t1, t2, t3, t4;

   extra_cost = (shift_cost[post_shift - 1]
          + shift_cost[1] + 2 * add_cost);
   t1 = expand_mult_highpart (compute_mode, op0, ml,
         (rtx) 0, 1,
         max_cost - extra_cost);
   if (t1 == 0)
     goto fail1;
   t2 = force_operand (gen_rtx (MINUS, compute_mode,
           op0, t1),
         (rtx) 0);
   t3 = expand_shift (RSHIFT_EXPR, compute_mode, t2,
        build_int_2_wide ((int) (1), (int) (0)), (rtx) 0, 1);
   t4 = force_operand (gen_rtx (PLUS, compute_mode,
           t1, t3),
         (rtx) 0);
   quotient = expand_shift (RSHIFT_EXPR, compute_mode, t4,
       build_int_2_wide ((int) (post_shift - 1), (int) (0))
               ,
       tquotient, 1);
        }
      else
        {
   rtx t1, t2;

   t1 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
        build_int_2_wide ((int) (pre_shift), (int) (0)),
        (rtx) 0, 1);
   extra_cost = (shift_cost[pre_shift]
          + shift_cost[post_shift]);
   t2 = expand_mult_highpart (compute_mode, t1, ml,
         (rtx) 0, 1,
         max_cost - extra_cost);
   if (t2 == 0)
     goto fail1;
   quotient = expand_shift (RSHIFT_EXPR, compute_mode, t2,
       build_int_2_wide ((int) (post_shift), (int) (0)),
       tquotient, 1);
        }
    }

  insn = get_last_insn ();
  if (insn != last
      && (set = single_set (insn)) != 0
      && ((set)->fld[0].rtx) == quotient)
    ((insn)->fld[6].rtx)
      = gen_rtx (EXPR_LIST, REG_EQUAL,
          gen_rtx (UDIV, compute_mode, op0, op1),
          ((insn)->fld[6].rtx));
       }
     else
       {
  unsigned int ml;
  int lgup, post_shift;
  int d = ((op1)->fld[0].rtwint);
  unsigned int abs_d = d >= 0 ? d : -d;


  if (rem_flag && d < 0)
    {
      d = abs_d;
      op1 = gen_rtx (CONST_INT, VOIDmode, (int) (abs_d));
    }

  if (d == 1)
    quotient = op0;
  else if (d == -1)
    quotient = expand_unop (compute_mode, neg_optab, op0,
       tquotient, 0);
  else if (abs_d == (unsigned int) 1 << (size - 1))
    {

      quotient = emit_store_flag (tquotient, EQ, op0, op1,
      compute_mode, 1, 1);
      if (quotient == 0)
        goto fail1;
    }
  else if ((((d) & ((d) - 1)) == 0)
    && (rem_flag ? smod_pow2_cheap : sdiv_pow2_cheap))
    ;
  else if ((((abs_d) & ((abs_d) - 1)) == 0))
    {
      lgup = floor_log2_wide ((int) (abs_d));
      if (abs_d != 2 && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) < 3)
        {
   rtx label = gen_label_rtx ();
   rtx t1;

   t1 = copy_to_mode_reg (compute_mode, op0);
   emit_cmp_insn (t1, const0_rtx, GE,
           (rtx) 0, compute_mode, 0, 0);
   emit_jump_insn (gen_bge (label));
   expand_inc (t1, gen_rtx (CONST_INT, VOIDmode, (int) (abs_d - 1)));
   emit_label (label);
   quotient = expand_shift (RSHIFT_EXPR, compute_mode, t1,
       build_int_2_wide ((int) (lgup), (int) (0)),
       tquotient, 0);
        }
      else
        {
   rtx t1, t2, t3;
   t1 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
        build_int_2_wide ((int) (size - 1), (int) (0)),
        (rtx) 0, 0);
   t2 = expand_shift (RSHIFT_EXPR, compute_mode, t1,
        build_int_2_wide ((int) (size - lgup), (int) (0)),
        (rtx) 0, 1);
   t3 = force_operand (gen_rtx (PLUS, compute_mode,
           op0, t2),
         (rtx) 0);
   quotient = expand_shift (RSHIFT_EXPR, compute_mode, t3,
       build_int_2_wide ((int) (lgup), (int) (0)),
       tquotient, 0);
        }



      if (d < 0)
        {
   insn = get_last_insn ();
   if (insn != last
       && (set = single_set (insn)) != 0
       && ((set)->fld[0].rtx) == quotient)
     ((insn)->fld[6].rtx)
       = gen_rtx (EXPR_LIST, REG_EQUAL,
           gen_rtx (DIV, compute_mode, op0,
      gen_rtx (CONST_INT, VOIDmode, (int) (abs_d))),
           ((insn)->fld[6].rtx));

   quotient = expand_unop (compute_mode, neg_optab,
      quotient, quotient, 0);
        }
    }
  else
    {
      choose_multiplier (abs_d, size, size - 1,
           &ml, &post_shift, &lgup);
      if (ml < (unsigned int) 1 << (size - 1))
        {
   rtx t1, t2, t3;

   extra_cost = (shift_cost[post_shift]
          + shift_cost[size - 1] + add_cost);
   t1 = expand_mult_highpart (compute_mode, op0, ml,
         (rtx) 0, 0,
         max_cost - extra_cost);
   if (t1 == 0)
     goto fail1;
   t2 = expand_shift (RSHIFT_EXPR, compute_mode, t1,
        build_int_2_wide ((int) (post_shift), (int) (0)), (rtx) 0, 0);
   t3 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
        build_int_2_wide ((int) (size - 1), (int) (0)), (rtx) 0, 0);
   if (d < 0)
     quotient = force_operand (gen_rtx (MINUS, compute_mode, t3, t2),
          tquotient);
   else
     quotient = force_operand (gen_rtx (MINUS, compute_mode, t2, t3),
          tquotient);
        }
      else
        {
   rtx t1, t2, t3, t4;

   ml |= (~(unsigned int) 0) << (size - 1);
   extra_cost = (shift_cost[post_shift]
          + shift_cost[size - 1] + 2 * add_cost);
   t1 = expand_mult_highpart (compute_mode, op0, ml,
         (rtx) 0, 0,
         max_cost - extra_cost);
   if (t1 == 0)
     goto fail1;
   t2 = force_operand (gen_rtx (PLUS, compute_mode, t1, op0),
         (rtx) 0);
   t3 = expand_shift (RSHIFT_EXPR, compute_mode, t2,
        build_int_2_wide ((int) (post_shift), (int) (0)), (rtx) 0, 0);
   t4 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
        build_int_2_wide ((int) (size - 1), (int) (0)), (rtx) 0, 0);
   if (d < 0)
     quotient = force_operand (gen_rtx (MINUS, compute_mode, t4, t3),
          tquotient);
   else
     quotient = force_operand (gen_rtx (MINUS, compute_mode, t3, t4),
          tquotient);
        }
    }

  insn = get_last_insn ();
  if (insn != last
      && (set = single_set (insn)) != 0
      && ((set)->fld[0].rtx) == quotient)
    ((insn)->fld[6].rtx)
      = gen_rtx (EXPR_LIST, REG_EQUAL,
          gen_rtx (DIV, compute_mode, op0, op1),
          ((insn)->fld[6].rtx));
       }
     break;
   }
      fail1:
 delete_insns_since (last);
 break;

      case FLOOR_DIV_EXPR:
      case FLOOR_MOD_EXPR:

 if (op1_is_constant && 32 >= size)
   {
     unsigned int mh, ml;
     int pre_shift, lgup, post_shift;
     int d = ((op1)->fld[0].rtwint);

     if (d > 0)
       {


  if ((((d) & ((d) - 1)) == 0))
    {
      pre_shift = floor_log2_wide ((int) (d));
      if (rem_flag)
        {
   remainder = expand_binop (compute_mode, and_optab, op0,
        gen_rtx (CONST_INT, VOIDmode, (int) (((int) 1 << pre_shift) - 1)),
        remainder, 0, OPTAB_LIB_WIDEN);
   if (remainder)
     return gen_lowpart (mode, remainder);
        }
      quotient = expand_shift (RSHIFT_EXPR, compute_mode, op0,
          build_int_2_wide ((int) (pre_shift), (int) (0)),
          tquotient, 0);
    }
  else
    {
      rtx t1, t2, t3, t4;

      mh = choose_multiplier (d, size, size - 1,
         &ml, &post_shift, &lgup);
      if (mh)
        abort ();

      t1 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
           build_int_2_wide ((int) (size - 1), (int) (0)), (rtx) 0, 0);
      t2 = expand_binop (compute_mode, xor_optab, op0, t1,
           (rtx) 0, 0, OPTAB_WIDEN);
      extra_cost = (shift_cost[post_shift]
      + shift_cost[size - 1] + 2 * add_cost);
      t3 = expand_mult_highpart (compute_mode, t2, ml,
            (rtx) 0, 1,
            max_cost - extra_cost);
      if (t3 != 0)
        {
   t4 = expand_shift (RSHIFT_EXPR, compute_mode, t3,
        build_int_2_wide ((int) (post_shift), (int) (0)),
        (rtx) 0, 1);
   quotient = expand_binop (compute_mode, xor_optab,
       t4, t1, tquotient, 0,
       OPTAB_WIDEN);
        }
    }
       }
     else
       {
  rtx nsign, t1, t2, t3, t4;
  t1 = force_operand (gen_rtx (PLUS, compute_mode,
          op0, constm1_rtx), (rtx) 0);
  t2 = expand_binop (compute_mode, ior_optab, op0, t1, (rtx) 0,
       0, OPTAB_WIDEN);
  nsign = expand_shift (RSHIFT_EXPR, compute_mode, t2,
          build_int_2_wide ((int) (size - 1), (int) (0)), (rtx) 0, 0);
  t3 = force_operand (gen_rtx (MINUS, compute_mode, t1, nsign),
        (rtx) 0);
  t4 = expand_divmod (0, TRUNC_DIV_EXPR, compute_mode, t3, op1,
        (rtx) 0, 0);
  if (t4)
    {
      rtx t5;
      t5 = expand_unop (compute_mode, one_cmpl_optab, nsign,
          (rtx) 0, 0);
      quotient = force_operand (gen_rtx (PLUS, compute_mode,
             t4, t5),
           tquotient);
    }
       }
   }

 if (quotient != 0)
   break;
 delete_insns_since (last);






 if (target == 0)
   target = gen_reg_rtx (compute_mode);

 if (rem_flag)
   {
     remainder
       = ((target)->code) == REG ? target : gen_reg_rtx (compute_mode);
     quotient = gen_reg_rtx (compute_mode);
   }
 else
   {
     quotient
       = ((target)->code) == REG ? target : gen_reg_rtx (compute_mode);
     remainder = gen_reg_rtx (compute_mode);
   }

 if (expand_twoval_binop (sdivmod_optab, op0, op1,
     quotient, remainder, 0))
   {


     rtx tem;
     rtx label = gen_label_rtx ();
     emit_cmp_insn (remainder, const0_rtx, EQ, (rtx) 0,
      compute_mode, 0, 0);
     emit_jump_insn (gen_beq (label));
     tem = expand_binop (compute_mode, xor_optab, op0, op1,
    (rtx) 0, 0, OPTAB_WIDEN);
     emit_cmp_insn (tem, const0_rtx, GE, (rtx) 0, compute_mode, 0, 0);
     emit_jump_insn (gen_bge (label));
     expand_dec (quotient, const1_rtx);
     expand_inc (remainder, op1);
     emit_label (label);
     return gen_lowpart (mode, rem_flag ? remainder : quotient);
   }



 {
   rtx label1, label2, label3, label4, label5;
   rtx adjusted_op0;
   rtx tem;

   quotient = gen_reg_rtx (compute_mode);
   adjusted_op0 = copy_to_mode_reg (compute_mode, op0);
   label1 = gen_label_rtx ();
   label2 = gen_label_rtx ();
   label3 = gen_label_rtx ();
   label4 = gen_label_rtx ();
   label5 = gen_label_rtx ();
   emit_cmp_insn (op1, const0_rtx, LT, (rtx) 0, compute_mode, 0, 0);
   emit_jump_insn (gen_blt (label2));
   emit_cmp_insn (adjusted_op0, const0_rtx, LT, (rtx) 0,
    compute_mode, 0, 0);
   emit_jump_insn (gen_blt (label1));
   tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
         quotient, 0, OPTAB_LIB_WIDEN);
   if (tem != quotient)
     emit_move_insn (quotient, tem);
   emit_jump_insn (gen_jump (label5));
   emit_barrier ();
   emit_label (label1);
   expand_inc (adjusted_op0, const1_rtx);
   emit_jump_insn (gen_jump (label4));
   emit_barrier ();
   emit_label (label2);
   emit_cmp_insn (adjusted_op0, const0_rtx, GT, (rtx) 0,
    compute_mode, 0, 0);
   emit_jump_insn (gen_bgt (label3));
   tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
         quotient, 0, OPTAB_LIB_WIDEN);
   if (tem != quotient)
     emit_move_insn (quotient, tem);
   emit_jump_insn (gen_jump (label5));
   emit_barrier ();
   emit_label (label3);
   expand_dec (adjusted_op0, const1_rtx);
   emit_label (label4);
   tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
         quotient, 0, OPTAB_LIB_WIDEN);
   if (tem != quotient)
     emit_move_insn (quotient, tem);
   expand_dec (quotient, const1_rtx);
   emit_label (label5);
 }
 break;

      case CEIL_DIV_EXPR:
      case CEIL_MOD_EXPR:
 if (unsignedp)
   {
     if (op1_is_constant && (((((op1)->fld[0].rtwint)) & ((((op1)->fld[0].rtwint)) - 1)) == 0))
       {
  rtx t1, t2, t3;
  unsigned int d = ((op1)->fld[0].rtwint);
  t1 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
       build_int_2_wide ((int) (floor_log2_wide ((int) (d))), (int) (0)),
       tquotient, 1);
  t2 = expand_binop (compute_mode, and_optab, op0,
       gen_rtx (CONST_INT, VOIDmode, (int) (d - 1)),
       (rtx) 0, 1, OPTAB_LIB_WIDEN);
  t3 = gen_reg_rtx (compute_mode);
  t3 = emit_store_flag (t3, NE, t2, const0_rtx,
          compute_mode, 1, 1);
  if (t3 == 0)
    {
      rtx lab;
      lab = gen_label_rtx ();
      emit_cmp_insn (t2, const0_rtx, EQ, (rtx) 0,
       compute_mode, 0, 0);
      emit_jump_insn (gen_beq (lab));
      expand_inc (t1, const1_rtx);
      emit_label (lab);
      quotient = t1;
    }
  else
    quotient = force_operand (gen_rtx (PLUS, compute_mode,
           t1, t3),
         tquotient);
  break;
       }






     if (target == 0)
       target = gen_reg_rtx (compute_mode);

     if (rem_flag)
       {
  remainder = (((target)->code) == REG
        ? target : gen_reg_rtx (compute_mode));
  quotient = gen_reg_rtx (compute_mode);
       }
     else
       {
  quotient = (((target)->code) == REG
       ? target : gen_reg_rtx (compute_mode));
  remainder = gen_reg_rtx (compute_mode);
       }

     if (expand_twoval_binop (udivmod_optab, op0, op1, quotient,
         remainder, 1))
       {


  rtx label = gen_label_rtx ();
  emit_cmp_insn (remainder, const0_rtx, EQ, (rtx) 0,
          compute_mode, 0, 0);
  emit_jump_insn (gen_beq (label));
  expand_inc (quotient, const1_rtx);
  expand_dec (remainder, op1);
  emit_label (label);
  return gen_lowpart (mode, rem_flag ? remainder : quotient);
       }



     {
       rtx label1, label2;
       rtx adjusted_op0, tem;

       quotient = gen_reg_rtx (compute_mode);
       adjusted_op0 = copy_to_mode_reg (compute_mode, op0);
       label1 = gen_label_rtx ();
       label2 = gen_label_rtx ();
       emit_cmp_insn (adjusted_op0, const0_rtx, NE, (rtx) 0,
        compute_mode, 0, 0);
       emit_jump_insn (gen_bne (label1));
       emit_move_insn (quotient, const0_rtx);
       emit_jump_insn (gen_jump (label2));
       emit_barrier ();
       emit_label (label1);
       expand_dec (adjusted_op0, const1_rtx);
       tem = expand_binop (compute_mode, udiv_optab, adjusted_op0, op1,
      quotient, 1, OPTAB_LIB_WIDEN);
       if (tem != quotient)
  emit_move_insn (quotient, tem);
       expand_inc (quotient, const1_rtx);
       emit_label (label2);
     }
   }
 else
   {
     if (op1_is_constant && (((((op1)->fld[0].rtwint)) & ((((op1)->fld[0].rtwint)) - 1)) == 0)
  && ((op1)->fld[0].rtwint) >= 0)
       {






  rtx t1, t2, t3;
  unsigned int d = ((op1)->fld[0].rtwint);
  t1 = expand_shift (RSHIFT_EXPR, compute_mode, op0,
       build_int_2_wide ((int) (floor_log2_wide ((int) (d))), (int) (0)),
       tquotient, 0);
  t2 = expand_binop (compute_mode, and_optab, op0,
       gen_rtx (CONST_INT, VOIDmode, (int) (d - 1)),
       (rtx) 0, 1, OPTAB_LIB_WIDEN);
  t3 = gen_reg_rtx (compute_mode);
  t3 = emit_store_flag (t3, NE, t2, const0_rtx,
          compute_mode, 1, 1);
  if (t3 == 0)
    {
      rtx lab;
      lab = gen_label_rtx ();
      emit_cmp_insn (t2, const0_rtx, EQ, (rtx) 0,
       compute_mode, 0, 0);
      emit_jump_insn (gen_beq (lab));
      expand_inc (t1, const1_rtx);
      emit_label (lab);
      quotient = t1;
    }
  else
    quotient = force_operand (gen_rtx (PLUS, compute_mode,
           t1, t3),
         tquotient);
  break;
       }






     if (target == 0)
       target = gen_reg_rtx (compute_mode);
     if (rem_flag)
       {
  remainder= (((target)->code) == REG
       ? target : gen_reg_rtx (compute_mode));
  quotient = gen_reg_rtx (compute_mode);
       }
     else
       {
  quotient = (((target)->code) == REG
       ? target : gen_reg_rtx (compute_mode));
  remainder = gen_reg_rtx (compute_mode);
       }

     if (expand_twoval_binop (sdivmod_optab, op0, op1, quotient,
         remainder, 0))
       {


  rtx tem;
  rtx label = gen_label_rtx ();
  emit_cmp_insn (remainder, const0_rtx, EQ, (rtx) 0,
          compute_mode, 0, 0);
  emit_jump_insn (gen_beq (label));
  tem = expand_binop (compute_mode, xor_optab, op0, op1,
        (rtx) 0, 0, OPTAB_WIDEN);
  emit_cmp_insn (tem, const0_rtx, LT, (rtx) 0,
          compute_mode, 0, 0);
  emit_jump_insn (gen_blt (label));
  expand_inc (quotient, const1_rtx);
  expand_dec (remainder, op1);
  emit_label (label);
  return gen_lowpart (mode, rem_flag ? remainder : quotient);
       }



     {
       rtx label1, label2, label3, label4, label5;
       rtx adjusted_op0;
       rtx tem;

       quotient = gen_reg_rtx (compute_mode);
       adjusted_op0 = copy_to_mode_reg (compute_mode, op0);
       label1 = gen_label_rtx ();
       label2 = gen_label_rtx ();
       label3 = gen_label_rtx ();
       label4 = gen_label_rtx ();
       label5 = gen_label_rtx ();
       emit_cmp_insn (op1, const0_rtx, LT, (rtx) 0,
        compute_mode, 0, 0);
       emit_jump_insn (gen_blt (label2));
       emit_cmp_insn (adjusted_op0, const0_rtx, GT, (rtx) 0,
        compute_mode, 0, 0);
       emit_jump_insn (gen_bgt (label1));
       tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
      quotient, 0, OPTAB_LIB_WIDEN);
       if (tem != quotient)
  emit_move_insn (quotient, tem);
       emit_jump_insn (gen_jump (label5));
       emit_barrier ();
       emit_label (label1);
       expand_dec (adjusted_op0, const1_rtx);
       emit_jump_insn (gen_jump (label4));
       emit_barrier ();
       emit_label (label2);
       emit_cmp_insn (adjusted_op0, const0_rtx, LT, (rtx) 0,
        compute_mode, 0, 0);
       emit_jump_insn (gen_blt (label3));
       tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
      quotient, 0, OPTAB_LIB_WIDEN);
       if (tem != quotient)
  emit_move_insn (quotient, tem);
       emit_jump_insn (gen_jump (label5));
       emit_barrier ();
       emit_label (label3);
       expand_inc (adjusted_op0, const1_rtx);
       emit_label (label4);
       tem = expand_binop (compute_mode, sdiv_optab, adjusted_op0, op1,
      quotient, 0, OPTAB_LIB_WIDEN);
       if (tem != quotient)
  emit_move_insn (quotient, tem);
       expand_inc (quotient, const1_rtx);
       emit_label (label5);
     }
   }
 break;

      case EXACT_DIV_EXPR:
 if (op1_is_constant && 32 >= size)
   {
     int d = ((op1)->fld[0].rtwint);
     unsigned int ml;
     int post_shift;
     rtx t1;

     post_shift = floor_log2_wide ((int) (d & -d));
     ml = invert_mod2n (d >> post_shift, size);
     t1 = expand_mult (compute_mode, op0, gen_rtx (CONST_INT, VOIDmode, (int) (ml)), (rtx) 0,
         unsignedp);
     quotient = expand_shift (RSHIFT_EXPR, compute_mode, t1,
         build_int_2_wide ((int) (post_shift), (int) (0)),
         (rtx) 0, unsignedp);

     insn = get_last_insn ();
     ((insn)->fld[6].rtx)
       = gen_rtx (EXPR_LIST, REG_EQUAL,
    gen_rtx (unsignedp ? UDIV : DIV, compute_mode,
      op0, op1),
    ((insn)->fld[6].rtx));
   }
 break;

      case ROUND_DIV_EXPR:
      case ROUND_MOD_EXPR:
 if (unsignedp)
   {
     rtx tem;
     rtx label;
     label = gen_label_rtx ();
     quotient = gen_reg_rtx (compute_mode);
     remainder = gen_reg_rtx (compute_mode);
     if (expand_twoval_binop (udivmod_optab, op0, op1, quotient, remainder, 1) == 0)
       {
  rtx tem;
  quotient = expand_binop (compute_mode, udiv_optab, op0, op1,
      quotient, 1, OPTAB_LIB_WIDEN);
  tem = expand_mult (compute_mode, quotient, op1, (rtx) 0, 1);
  remainder = expand_binop (compute_mode, sub_optab, op0, tem,
       remainder, 1, OPTAB_LIB_WIDEN);
       }
     tem = plus_constant_wide (op1, (int) (-1));
     tem = expand_shift (RSHIFT_EXPR, compute_mode, tem,
    build_int_2_wide ((int) (1), (int) (0)), (rtx) 0, 1);
     emit_cmp_insn (remainder, tem, LEU, (rtx) 0, compute_mode, 0, 0);
     emit_jump_insn (gen_bleu (label));
     expand_inc (quotient, const1_rtx);
     expand_dec (remainder, op1);
     emit_label (label);
   }
 else
   {
     rtx abs_rem, abs_op1, tem, mask;
     rtx label;
     label = gen_label_rtx ();
     quotient = gen_reg_rtx (compute_mode);
     remainder = gen_reg_rtx (compute_mode);
     if (expand_twoval_binop (sdivmod_optab, op0, op1, quotient, remainder, 0) == 0)
       {
  rtx tem;
  quotient = expand_binop (compute_mode, sdiv_optab, op0, op1,
      quotient, 0, OPTAB_LIB_WIDEN);
  tem = expand_mult (compute_mode, quotient, op1, (rtx) 0, 0);
  remainder = expand_binop (compute_mode, sub_optab, op0, tem,
       remainder, 0, OPTAB_LIB_WIDEN);
       }
     abs_rem = expand_abs (compute_mode, remainder, (rtx) 0, 0, 0);
     abs_op1 = expand_abs (compute_mode, op1, (rtx) 0, 0, 0);
     tem = expand_shift (LSHIFT_EXPR, compute_mode, abs_rem,
    build_int_2_wide ((int) (1), (int) (0)), (rtx) 0, 1);
     emit_cmp_insn (tem, abs_op1, LTU, (rtx) 0, compute_mode, 0, 0);
     emit_jump_insn (gen_bltu (label));
     tem = expand_binop (compute_mode, xor_optab, op0, op1,
    (rtx) 0, 0, OPTAB_WIDEN);
     mask = expand_shift (RSHIFT_EXPR, compute_mode, tem,
    build_int_2_wide ((int) (size - 1), (int) (0)), (rtx) 0, 0);
     tem = expand_binop (compute_mode, xor_optab, mask, const1_rtx,
    (rtx) 0, 0, OPTAB_WIDEN);
     tem = expand_binop (compute_mode, sub_optab, tem, mask,
    (rtx) 0, 0, OPTAB_WIDEN);
     expand_inc (quotient, tem);
     tem = expand_binop (compute_mode, xor_optab, mask, op1,
    (rtx) 0, 0, OPTAB_WIDEN);
     tem = expand_binop (compute_mode, sub_optab, tem, mask,
    (rtx) 0, 0, OPTAB_WIDEN);
     expand_dec (remainder, tem);
     emit_label (label);
   }
 return gen_lowpart (mode, rem_flag ? remainder : quotient);
      }

  if (quotient == 0)
    {
      if (rem_flag)
 {

   remainder = sign_expand_binop (compute_mode, umod_optab, smod_optab,
      op0, op1, target,
      unsignedp, OPTAB_WIDEN);
   if (remainder == 0)
     {


       remainder = gen_reg_rtx (compute_mode);
       if (! expand_twoval_binop ((unsignedp
       ? udivmod_optab
       : sdivmod_optab),
      op0, op1,
      (rtx) 0, remainder, unsignedp))
  remainder = 0;
     }

   if (remainder)
     return gen_lowpart (mode, remainder);
 }



      quotient = sign_expand_binop (compute_mode, udiv_optab, sdiv_optab,
        op0, op1, rem_flag ? (rtx) 0 : target,
        unsignedp, OPTAB_WIDEN);
      if (quotient == 0)
 {


   quotient = gen_reg_rtx (compute_mode);
   if (! expand_twoval_binop (unsignedp ? udivmod_optab : sdivmod_optab,
         op0, op1,
         quotient, (rtx) 0, unsignedp))
     {
       quotient = 0;
       if (! rem_flag)


  quotient = sign_expand_binop (compute_mode,
           udiv_optab, sdiv_optab,
           op0, op1, target,
           unsignedp, OPTAB_LIB_WIDEN);
     }
 }
    }

  if (rem_flag)
    {
      if (quotient == 0)

 remainder = sign_expand_binop (compute_mode, umod_optab, smod_optab,
           op0, op1, target,
           unsignedp, OPTAB_LIB_WIDEN);
      else
 {

   remainder = expand_mult (compute_mode, quotient, op1,
       (rtx) 0, unsignedp);
   remainder = expand_binop (compute_mode, sub_optab, op0,
        remainder, target, unsignedp,
        OPTAB_LIB_WIDEN);
 }
    }

  return gen_lowpart (mode, rem_flag ? remainder : quotient);
}






tree
make_tree(tree type, rtx x) asm("_make_tree");
tree
make_tree(tree type, rtx x)
{
  tree t;

  switch (((x)->code))
    {
    case CONST_INT:
      t = build_int_2_wide ((int) (((x)->fld[0].rtwint)), (int) (((type)->common.unsigned_flag) || ((x)->fld[0].rtwint) >= 0 ? 0 : -1))
                                                          ;
      ((t)->common.type) = type;
      return t;

    case CONST_DOUBLE:
      if (((x)->mode) == VOIDmode)
 {
   t = build_int_2_wide ((int) (((x)->fld[2].rtwint)), (int) (((x)->fld[3].rtwint)));
   ((t)->common.type) = type;
 }
      else
 {
   double d;

   do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((x))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((x))->fld[3].rtwint),(sizeof u) / 2); d = u.d; } while (0);
   t = build_real (type, d);
 }

      return t;

    case PLUS:
      return fold (build (PLUS_EXPR, type, make_tree (type, ((x)->fld[0].rtx)),
     make_tree (type, ((x)->fld[1].rtx))));

    case MINUS:
      return fold (build (MINUS_EXPR, type, make_tree (type, ((x)->fld[0].rtx)),
     make_tree (type, ((x)->fld[1].rtx))));

    case NEG:
      return fold (build1 (NEGATE_EXPR, type, make_tree (type, ((x)->fld[0].rtx))));

    case MULT:
      return fold (build (MULT_EXPR, type, make_tree (type, ((x)->fld[0].rtx)),
     make_tree (type, ((x)->fld[1].rtx))));

    case ASHIFT:
      return fold (build (LSHIFT_EXPR, type, make_tree (type, ((x)->fld[0].rtx)),
     make_tree (type, ((x)->fld[1].rtx))));

    case LSHIFTRT:
      return fold (convert (type,
       build (RSHIFT_EXPR, unsigned_type (type),
       make_tree (unsigned_type (type),
           ((x)->fld[0].rtx)),
       make_tree (type, ((x)->fld[1].rtx)))));

    case ASHIFTRT:
      return fold (convert (type,
       build (RSHIFT_EXPR, signed_type (type),
       make_tree (signed_type (type), ((x)->fld[0].rtx)),
       make_tree (type, ((x)->fld[1].rtx)))));

    case DIV:
      if (((n64_enum_tree_code) (type)->common.code) != REAL_TYPE)
 t = signed_type (type);
      else
 t = type;

      return fold (convert (type,
       build (TRUNC_DIV_EXPR, t,
       make_tree (t, ((x)->fld[0].rtx)),
       make_tree (t, ((x)->fld[1].rtx)))));
    case UDIV:
      t = unsigned_type (type);
      return fold (convert (type,
       build (TRUNC_DIV_EXPR, t,
       make_tree (t, ((x)->fld[0].rtx)),
       make_tree (t, ((x)->fld[1].rtx)))));
   default:
      t = make_node (RTL_EXPR);
      ((t)->common.type) = type;
      (*(struct n64_tag_rtx_def **) &(t)->exp.operands[1]) = x;


      (*(struct n64_tag_rtx_def **) &(t)->exp.operands[0]) = 0;
      return t;
    }
}
rtx
expand_mult_add(rtx x, rtx target, rtx mult, rtx add, n64_enum_machine_mode mode, int unsignedp) asm("_expand_mult_add");
rtx
expand_mult_add(rtx x, rtx target, rtx mult, rtx add, n64_enum_machine_mode mode, int unsignedp)
{
  tree type = type_for_mode (mode, unsignedp);
  tree add_type = (((add)->mode) == VOIDmode
     ? type : type_for_mode (((add)->mode), unsignedp));
  tree result = fold (build (PLUS_EXPR, type,
         fold (build (MULT_EXPR, type,
        make_tree (type, x),
        make_tree (type, mult))),
         make_tree (add_type, add)));

  return expand_expr (result, target, VOIDmode, 0);
}






rtx
expand_and(rtx op0, rtx op1, rtx target) asm("_expand_and");
rtx
expand_and(rtx op0, rtx op1, rtx target)
{
  n64_enum_machine_mode mode = VOIDmode;
  rtx tem;

  if (((op0)->mode) != VOIDmode)
    mode = ((op0)->mode);
  else if (((op1)->mode) != VOIDmode)
    mode = ((op1)->mode);

  if (mode != VOIDmode)
    tem = expand_binop (mode, and_optab, op0, op1, target, 0, OPTAB_LIB_WIDEN);
  else if (((op0)->code) == CONST_INT && ((op1)->code) == CONST_INT)
    tem = gen_rtx (CONST_INT, VOIDmode, (int) (((op0)->fld[0].rtwint) & ((op1)->fld[0].rtwint)));
  else
    abort ();

  if (target == 0)
    target = tem;
  else if (tem != target)
    emit_move_insn (target, tem);
  return target;
}
rtx
emit_store_flag(rtx target, n64_enum_rtx_code code, rtx op0, rtx op1, n64_enum_machine_mode mode, int unsignedp, int normalizep) asm("_emit_store_flag");
rtx
emit_store_flag(rtx target, n64_enum_rtx_code code, rtx op0, rtx op1, n64_enum_machine_mode mode, int unsignedp, int normalizep)
{
  rtx subtarget;
  n64_enum_insn_code icode;
  n64_enum_machine_mode compare_mode;
  n64_enum_machine_mode target_mode = ((target)->mode);
  rtx tem;
  rtx last = get_last_insn ();
  rtx pattern, comparison;




  if (((((op0)->code) == LABEL_REF || ((op0)->code) == SYMBOL_REF || ((op0)->code) == CONST_INT || ((op0)->code) == CONST_DOUBLE || ((op0)->code) == CONST || ((op0)->code) == HIGH) && ! (((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH))
      || (((op0)->code) == CONST_INT && ((op1)->code) != CONST_INT))
    {
      tem = op0;
      op0 = op1;
      op1 = tem;
      code = swap_condition (code);
    }

  if (mode == VOIDmode)
    mode = ((op0)->mode);





  switch (code)
    {
    case LT:
      if (op1 == const1_rtx)
 op1 = const0_rtx, code = LE;
      break;
    case LE:
      if (op1 == constm1_rtx)
 op1 = const0_rtx, code = LT;
      break;
    case GE:
      if (op1 == const1_rtx)
 op1 = const0_rtx, code = GT;
      break;
    case GT:
      if (op1 == constm1_rtx)
 op1 = const0_rtx, code = GE;
      break;
    case GEU:
      if (op1 == const1_rtx)
 op1 = const0_rtx, code = NE;
      break;
    case LTU:
      if (op1 == const1_rtx)
 op1 = const0_rtx, code = EQ;
      break;
    }


  icode = setcc_gen_code[(int) code];



  if (op1 == const0_rtx && (code == LT || code == GE)
      && (mode_class[(int)(mode)]) == MODE_INT
      && (normalizep || 1 == 1
   || ((8 * mode_size[(int)(mode)]) <= 32
       && (1
    == (int) 1 << ((8 * mode_size[(int)(mode)]) - 1)))))
    {
      subtarget = target;




      if ((mode_size[(int)(target_mode)]) > (mode_size[(int)(mode)]))
 {
   op0 = protect_from_queue (op0, 0);
   op0 = convert_modes (target_mode, mode, op0, 0);
   mode = target_mode;
 }

      if (target_mode != mode)
 subtarget = 0;

      if (code == GE)
 op0 = expand_unop (mode, one_cmpl_optab, op0, subtarget, 0);

      if (normalizep || 1 == 1)



 op0 = expand_shift (RSHIFT_EXPR, mode, op0,
       size_int ((8 * mode_size[(int)(mode)]) - 1),
       subtarget, normalizep != -1);

      if (mode != target_mode)
 op0 = convert_modes (target_mode, mode, op0, 0);

      return op0;
    }

  if (icode != CODE_FOR_nothing)
    {






      emit_queue ();
      last = get_last_insn ();

      comparison
 = compare_from_rtx (op0, op1, code, unsignedp, mode, (rtx) 0, 0);
      if (((comparison)->code) == CONST_INT)
 return (comparison == const0_rtx ? const0_rtx
  : normalizep == 1 ? const1_rtx
  : normalizep == -1 ? constm1_rtx
  : const_true_rtx);





      if (((comparison)->code) != code)
 abort ();


      compare_mode = insn_operand_mode[(int) icode][0];
      subtarget = target;
      if (preserve_subexpressions_p ()
   || ! (*insn_operand_predicate[(int) icode][0]) (subtarget, compare_mode))
 subtarget = gen_reg_rtx (compare_mode);

      pattern = (*insn_gen_function[(int) (icode)]) (subtarget);
      if (pattern)
 {
   emit_insn (pattern);
   if ((mode_size[(int)(target_mode)]) > (mode_size[(int)(compare_mode)]))
     {
       convert_move (target, subtarget,
       ((8 * mode_size[(int)(compare_mode)])
        <= 32)
       && 0 == (1
         & ((int) 1
     << ((8 * mode_size[(int)(compare_mode)]) -1))));
       op0 = target;
       compare_mode = target_mode;
     }
   else
     op0 = subtarget;




   if (preserve_subexpressions_p ())
     subtarget = 0;



   if (normalizep == 0 || normalizep == 1)
     ;
   else if (normalizep == - 1)
     op0 = expand_unop (compare_mode, neg_optab, op0, subtarget, 0);




   else if ((8 * mode_size[(int)(compare_mode)]) <= 32
     && (1
         & ((int) 1
     << ((8 * mode_size[(int)(compare_mode)]) - 1))))
     op0 = expand_shift (RSHIFT_EXPR, compare_mode, op0,
    size_int ((8 * mode_size[(int)(compare_mode)]) - 1),
    subtarget, normalizep == 1);
   else if (1 & 1)
     {
       op0 = expand_and (op0, const1_rtx, subtarget);
       if (normalizep == -1)
  op0 = expand_unop (compare_mode, neg_optab, op0, op0, 0);
     }
   else
     abort ();



   if (target_mode != compare_mode)
     {
       convert_move (target, op0, 0);
       return target;
     }
   else
     return op0;
 }
    }

  delete_insns_since (last);




  subtarget = (!flag_expensive_optimizations
        && (target_mode == mode)) ? target : (rtx) 0;
  if (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) > 0
      && (mode_class[(int)(mode)]) == MODE_INT && (code == EQ || code == NE)
      && op1 != const0_rtx)
    {
      tem = expand_binop (mode, xor_optab, op0, op1, subtarget, 1,
     OPTAB_WIDEN);

      if (tem == 0)
 tem = expand_binop (mode, sub_optab, op0, op1, subtarget, 1,
       OPTAB_WIDEN);
      if (tem != 0)
 tem = emit_store_flag (target, code, tem, const0_rtx,
          mode, unsignedp, normalizep);
      if (tem == 0)
 delete_insns_since (last);
      return tem;
    }






  if (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) == 0
      || (mode_class[(int)(mode)]) != MODE_INT || op1 != const0_rtx
      || (code != EQ && code != NE
   && (((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) <= 1 || (code != LE && code != GT))))
    return 0;




  if (normalizep == 0)
    {
      if (1 == 1 || 1 == -1)
 normalizep = 1;

      else if ((8 * mode_size[(int)(mode)]) <= 32
        && (1
     == (int) 1 << ((8 * mode_size[(int)(mode)]) - 1)))
 ;
      else
 return 0;
    }




  tem = 0;




  if (code == LE)
    {

      if (rtx_equal_p (subtarget, op0))
 subtarget = 0;

      tem = expand_binop (mode, sub_optab, op0, const1_rtx, subtarget, 0,
     OPTAB_WIDEN);
      if (tem)
 tem = expand_binop (mode, ior_optab, op0, tem, subtarget, 0,
       OPTAB_WIDEN);
    }




  if (code == GT)
    {
      if (rtx_equal_p (subtarget, op0))
 subtarget = 0;

      tem = expand_shift (RSHIFT_EXPR, mode, op0,
     size_int ((8 * mode_size[(int)(mode)]) - 1),
     subtarget, 0);
      tem = expand_binop (mode, sub_optab, tem, op0, subtarget, 0,
     OPTAB_WIDEN);
    }

  if (code == EQ || code == NE)
    {
      if (abs_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
 tem = expand_unop (mode, abs_optab, op0, subtarget, 1);
      else if (ffs_optab->handlers[(int) mode].insn_code != CODE_FOR_nothing)
 tem = expand_unop (mode, ffs_optab, op0, subtarget, 1);
      else if ((mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4))
 {
   op0 = protect_from_queue (op0, 0);
   tem = convert_modes (word_mode, mode, op0, 1);
   mode = word_mode;
 }

      if (tem != 0)
 {
   if (code == EQ)
     tem = expand_binop (mode, sub_optab, tem, const1_rtx, subtarget,
    0, OPTAB_WIDEN);
   else
     tem = expand_unop (mode, neg_optab, tem, subtarget, 0);
 }






      if (tem == 0 && (code == NE || ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) > 1))
 {
   if (rtx_equal_p (subtarget, op0))
     subtarget = 0;

   tem = expand_unop (mode, neg_optab, op0, subtarget, 0);
   tem = expand_binop (mode, ior_optab, tem, op0, subtarget, 0,
         OPTAB_WIDEN);

   if (tem && code == EQ)
     tem = expand_unop (mode, one_cmpl_optab, tem, subtarget, 0);
 }
    }

  if (tem && normalizep)
    tem = expand_shift (RSHIFT_EXPR, mode, tem,
   size_int ((8 * mode_size[(int)(mode)]) - 1),
   subtarget, normalizep == 1);

  if (tem)
    {
      if (((tem)->mode) != target_mode)
 {
   convert_move (target, tem, 0);
   tem = target;
 }
      else if (!subtarget)
 {
   emit_move_insn (target, tem);
   tem = target;
 }
    }
  else
    delete_insns_since (last);

  return tem;
}

